

# Generated at 2022-06-25 05:24:37.481610
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = b'\xb4\x8a\xa4\x04\xe4\x06\x9f\x04\xfc\xac\xfd\x00\xfd\xaa\xb2\xfc\xfd\x88\xfd\x96\xfd\x8a\x05\xfc\x02\xfa\xfe\x9c \x06\xfc\xfa\xfc\xf8\x02\xfa\xfb\xa8\x02\xfa\xfc\x89\x06\xfc\x84\x02\xfa\xfa\xb9\x02'
    bytes_0 = b'\xff\xff\xff\xff\xff\xff\xff\xff'

# Generated at 2022-06-25 05:24:39.002817
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    process_include_results()


main = test_IncludedFile_process_include_results

# Generated at 2022-06-25 05:24:43.639399
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_file_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    assert included_file_0 == []


# Generated at 2022-06-25 05:24:45.272133
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print(IncludedFile_process_include_results(object, object, object, object))


# Generated at 2022-06-25 05:24:47.439755
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:24:54.157543
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    var_0 = [included_file_0]
    var_1 = var_0
    included_file_0 = IncludedFile.process_include_results(var_1, None, None, None)

# Generated at 2022-06-25 05:25:00.194048
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    if included_file_0.process_include_results(int_0, bytes_0, bytes_0, bytes_0) != int_0:
        raise Exception('Method process_include_results of class IncludedFile returned an inconsistent result')

# Generated at 2022-06-25 05:25:03.087999
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile.process_include_results(test_case_0, test_case_0, test_case_0, test_case_0)

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:08.084867
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:25:17.432548
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 195
    int_1 = 314
    int_2 = -191
    str_0 = 'v'
    str_1 = 'wkz'
    str_2 = '4!1'
    bytes_0 = b'6j\xe6\xbcw\xbc'
    bytes_1 = b'\xab\xb1\x86'
    bytes_2 = b'\xc1\xbd\xfe\x7f\x92\x9b\x12'
    int_3 = -436
    int_4 = -106
    int_5 = 824
    included_file_0 = IncludedFile(int_0, str_0, bytes_0, None)
    included_file_1 = IncludedFile(int_1, int_2, int_3, str_1)


# Generated at 2022-06-25 05:25:38.492276
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:25:41.725638
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results(var_results, var_iterator, var_loader, var_variable_manager)
    except Exception as e:
        print("Exception in IncludedFile.process_include_results(): " + str(e))


# Generated at 2022-06-25 05:25:43.937780
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    args = {}
    kwargs = {}

    # No paramaters passed
    # No return value expected
    IncludedFile.process_include_results(args, **kwargs)

# Generated at 2022-06-25 05:25:50.042685
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("\n!Unit test for method process_include_results of class IncludedFile!")
    print("\n class IncludedFile:")
    from ansible.executor.task_executor import Result
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    play_context_0 = PlayContext()
    variable_manager_0 = VariableManager(loader=None, variables=dict())
    variable_manager_0._extra_vars = dict()
    variable_manager_0._options_vars = dict()
    variable_manager_0._hostvars = dict()
    variable_manager_0._fact_cache = dict

# Generated at 2022-06-25 05:25:51.385502
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert (IncludedFile.process_include_results(test_case_0(), None, None, None) == included_files_test_data)


# Generated at 2022-06-25 05:26:01.391303
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase

    class TestStrategy(StrategyBase):
        def run(self, iterator, play_context):
            results = []
            for result in super(TestStrategy, self).run(iterator, play_context):
                if result._task.action in C._ACTION_ALL_INCLUDES:
                    results.append(result)
                yield result


# Generated at 2022-06-25 05:26:02.872926
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert test_IncludedFile_process_include_results_0() == 0


# Generated at 2022-06-25 05:26:10.759330
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = [{
    'ansible_loop_var': None,
    'changed': False,
    'include': None,
    'include_args': {},
    'skip_reason': 'conditional check failed',
    'skipped': True
    }]
    iterator_0 = TaskInclude()
    iterator_0._play = TaskInclude()
    iterator_0._play._play_context = TaskInclude()
    iterator_0._play._play_context._play = TaskInclude()
    iterator_0._play._play_context._play._variable_manager = TaskInclude()
    iterator_0._play._play_context._play._variable_manager._vars_cache = {}
    loader_0 = TaskInclude()
    variable_manager_0 = TaskInclude()
    variable_manager_0._v

# Generated at 2022-06-25 05:26:13.158994
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, bytes_1)
    assert included_file_0._filename == bytes_0

# Generated at 2022-06-25 05:26:19.415915
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert len(IncludedFile.process_include_results(None, None, None, None)) == 0

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:40.062095
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest2 as unittest

# Generated at 2022-06-25 05:26:42.975335
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = bytes_0
    iterator = bytes_0
    loader = bytes_0
    variable_manager = bytes_0
    var_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:26:49.240648
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    included_file_1 = IncludedFile(1, 1, 1, 1)

    included_file_2 = IncludedFile(2, 2, 2, 2)

    included_file_3 = IncludedFile(3, 3, 3, 3)

    included_file_4 = IncludedFile(4, 4, 4, 4)

    included_file_5 = IncludedFile(5, 5, 5, 5)

    results_0 = [included_file_0, included_file_1, included_file_2, included_file_3, included_file_4, included_file_5]

    IncludedFile.process_include_results(results_0, iterator=1, loader=1, variable_manager=1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:26:53.964599
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_1 = 516
    bytes_1 = b'\x97b\xf6`\x89\x0fS\x11V9\xa32c'
    included_file_1 = IncludedFile(int_1, bytes_1, bytes_1, bytes_1)


# Generated at 2022-06-25 05:27:04.089606
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 237
    bytes_0 = b'\x97b\xf6`W\x0fS\x11V9\xa32c'
    included_file_0 = IncludedFile(int_0, bytes_0, bytes_0, bytes_0)
    included_file_0.add_host(int_0)
    included_file_0.add_host(bytes_0)
    included_file_0.add_host(bytes_0)
    included_file_0.add_host(bytes_0)
    included_file_0.add_host(bytes_0)
    included_file_0.add_host(bytes_0)
    included_file_0.add_host(bytes_0)
    included_file_0.add_host(bytes_0)
    included_file_

# Generated at 2022-06-25 05:27:12.424214
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = -9
    str_0 = '\xec\x97\x18\xec\x1f\x0b\xd0\x9f\x12A\x05'
    int_1 = -34
    str_1 = '\x0c\x9f\x1b\x07\xb2\x961b\xce\xee\x97`\x8b'
    included_file_0 = IncludedFile(int_0, str_0, str_0, str_0)
    included_file_0.add_host(int_1)
    included_file_1 = IncludedFile(int_0, str_0, str_0, str_0)
    included_file_1.add_host(int_1)
    var_0 = included_file_0

# Generated at 2022-06-25 05:27:12.921522
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:27:16.241453
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False


# Generated at 2022-06-25 05:27:23.059222
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 229
    bytes_0 = b'\x0c\x85\x03\x9a\x0b\xbe\x14\x10\x93\xcd\x8a\x91Z\xe2\x11\xfd\x07'
    included_file_0 = IncludedFile(int_0, bytes_0, bytes_0, bytes_0)
    int_1 = 6
    bytes_1 = b't\x89\xb6\x9e\x9c\xa2'
    included_file_1 = IncludedFile(int_1, bytes_1, bytes_1, bytes_1)
    assert included_file_0 != included_file_1


# Generated at 2022-06-25 05:27:33.240676
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import random
    import sys

    bytes_0 = b'\x97b\xf6`W\x0fS\x11V9\xa32c'
    bytes_1 = b'\xc8\x8f\xdc\x99=\t\x8c\xe7\x03\xde\x10'
    bytes_2 = b"\x0fE\x10\xb8\xa9\x0f\xb2\xc6\x98\x11\x0c"
    int_0 = 471

    # Set up arguments and run the test
    results = None
    iterator = None
    loader = None
    variable_manager = None
    # Called function
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:27:55.412078
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:28:00.277750
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = 'results'
    iterator = 'iterator'
    loader = 'loader'
    variable_manager = 'variable_manager'
    try:
        ret = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    except Exception as exc:
        print(exc)

if __name__ == '__main__':
    # test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:08.470301
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 18489

# Generated at 2022-06-25 05:28:14.797520
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for _ in range(8):
        output = True
        return_value_0 = IncludedFile.process_include_results(output, output, output, output)


if __name__ == '__main__':
    import sys
    from logging import basicConfig, DEBUG, INFO

    basicConfig(stream=sys.stderr, level=DEBUG, format='%(asctime)s %(levelname)s %(message)s')

    # This is just a quick test, don't want to actually run the include code, just make sure it behaves
    test_case_0()

    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:24.451184
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 880113
    bytes_0 = b'\xba\xce\xdc\x8a\xbb \xa6\x0f\x11\xf3\xad\xa6\xf3'
    dict_0 = dict()
    dict_0['__ansible_ignore__'] = True
    dict_0['__ansible_no_log__'] = True
    dict_0['__ansible_verbose_always__'] = True
    dict_0['__ansible_verbose_override__'] = True
    dict_0['__ansible_version__'] = 2

    dict_1 = dict()
    dict_1['__ansible_ignore__'] = True
    dict_1['__ansible_no_log__'] = True

# Generated at 2022-06-25 05:28:26.128225
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results(bytes_0, int_0, int_0, int_0)
    assert included_files == included_files


# Generated at 2022-06-25 05:28:36.349244
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''Test process_include_results of class IncludedFile'''
    int_0 = 552
    bytes_0 = b'\x97b\xf6`W\x0fS\x11V9\xa32c'
    included_file_0 = '\x97b\xf6`W\x0fS\x11V9\xa32c(b\x97b\xf6`W\x0fS\x11V9\xa32c): []'
    included_files = [included_file_0]
    results = IncludedFile.process_include_results(range(int_0), int_0, int_0, int_0)
    if results != included_files:
        print(test_case_0.__name__ + ' failed')

# Generated at 2022-06-25 05:28:45.225711
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    included_file_0.process_include_results(None, None, None, None)

if __name__ == "__main__":
    import sys
    import logging
    logger = logging.getLogger("ansible_test")
    logger.setLevel(logging.DEBUG)
    #logger.addHandler(logging.StreamHandler(sys.stdout))
    #unittest.main()
    #test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:51.734481
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    results = included_file_0.process_include_results(None, None, None, None)
    assert None is included_file_0.process_include_results(None, None, None, None)


test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:55.853704
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print('')
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:45.945707
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = -3166307471274577722
    str_0 = '+\x01\x14\x0c)\x00\x1a\x1cJ\x1f\x1d\x0f\x0c\x06\x19\x0f\x1f'
    int_1 = -8589163026195825567
    int_2 = -8591094363934909279
    int_3 = -8589163026195825567
    int_4 = -8591094363934909279
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_

# Generated at 2022-06-25 05:29:51.734306
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    import sys
    import traceback
    try:
        main_function = globals()[sys.argv[1]]
    except KeyError:
        sys.exit("No such test case: " + sys.argv[1])
    try:
        main_function()
    except SystemExit:
        raise
    except:
        traceback.print_exc()
        sys.exit(1)
    else:
        sys.exit(0)

# Generated at 2022-06-25 05:29:52.607981
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert False


# Generated at 2022-06-25 05:30:04.577182
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 658
    bytes_0 = b'\x8f\x01\xba\xfc\xd4\xa6\xb7\xfb\x9f\xcc\x10\x0f\xec\xf0\x11\xce\x95\x85\x18\xce\x8e\xe2d1\xca\x05\xc5\xbeu3\x99\xe9'
    included_file_0 = IncludedFile(int_0, bytes_0, bytes_0, bytes_0)

# Generated at 2022-06-25 05:30:06.959591
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    it = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert_equals(it, IncludedFile.process_include_results(results, iterator, loader, variable_manager))


# Generated at 2022-06-25 05:30:16.156785
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:30:22.554555
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 471
    bytes_0 = b'\x97b\xf6`W\x0fS\x11V9\xa32c'
    included_file_0 = IncludedFile(int_0, bytes_0, bytes_0, bytes_0)
    int_1 = 659
    bytes_1 = b'.\xbf\x83\x8c\xbc\xfb\xcf\xd4\xb8\x1f\x85\xe6\x93\x8f\xaf'
    included_file_1 = IncludedFile(int_1, bytes_1, bytes_1, bytes_1)
    assert included_file_0 != included_file_1



# Generated at 2022-06-25 05:30:26.593080
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = []

    print('START')
    print(included_files)
    
    #print('START2')
    #print(included_files)
    #print(included_files)
    #print(included_files)
    #print(included_files)

# Generated at 2022-06-25 05:30:34.411726
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = None
    int_1 = 0
    bytes_0 = b'\x00'
    int_2 = 0
    bytes_1 = b'\x00'
    int_3 = 0
    bytes_2 = b'\x00'
    int_4 = 0
    int_5 = 1
    bytes_3 = b'\x00'
    result_0 = [IncludedFile(int_1, bytes_1, bytes_1, bytes_1), IncludedFile(int_2, bytes_2, bytes_2, bytes_2)]
    IncludedFile.process_include_results(result_0, None, None, None)
    assert len(result_0[0]._hosts) == int_3
    assert result_0[0]._filename == int_4

# Generated at 2022-06-25 05:30:37.096042
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file = IncludedFile(0,0,0,0)
    test_case_0()
    
if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:32:10.641786
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 471
    bytes_0 = b'\x97b\xf6`W\x0fS\x11V9\xa32c'
    task_0 = bytes_0
    original_host_0 = bytes_0
    original_task_0 = bytes_0
    play_0 = bytes_0
    variable_manager_0 = bytes_0
    include_result_0 = {'failed': False, '_ansible_verbose_always': True, '_ansible_no_log': False, 'changed': True, 'include': 'hello'}
    include_result_1 = {'failed': False, '_ansible_verbose_always': True, '_ansible_no_log': False, 'changed': True, 'include': 'hello'}

# Generated at 2022-06-25 05:32:21.231756
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 215
    bytes_0 = b'\x88\xfaO  \xd5\xf3\x9f\xa3\x8d\x0eH\xbd\xca'
    included_file_0 = IncludedFile(int_0, bytes_0, bytes_0, bytes_0)
    int_1 = 82
    bytes_1 = b'\xaf\x0eS\x95\xc7\xab\x0c\x10\xf8\x93\x9e+\x9d'
    included_file_1 = IncludedFile(int_0, bytes_1, bytes_0, bytes_0)
    bool_0 = included_file_0 == included_file_1
    assert bool_0


# Generated at 2022-06-25 05:32:26.014397
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:32:28.281700
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


# Generated at 2022-06-25 05:32:29.267633
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# Generated at 2022-06-25 05:32:30.267958
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 05:32:31.053310
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()

# Generated at 2022-06-25 05:32:36.532495
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # This is just a sanity check.
    # The method is a static method and it doesn't use any members.
    IncludedFile.process_include_results(included_files=None, loader=None, iterator=None, variable_manager=None)

# Generated at 2022-06-25 05:32:37.989000
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:32:40.333254
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results(IncludedFile)
    except:
        pass
