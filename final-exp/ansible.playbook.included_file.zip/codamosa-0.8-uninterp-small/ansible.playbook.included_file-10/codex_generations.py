

# Generated at 2022-06-25 05:24:34.460600
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Comparison case
    included_file_0 = IncludedFile(None, False, 0.97, None)
    included_file_0.add_host(None)
    assert included_file_0._hosts[0] == None
    results = None
    iterator = None
    loader = None
    variable_manager = None
    var_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    # AssertionError: assert [IncludedFile(None, False, 0.97, None)] == var_0


# Generated at 2022-06-25 05:24:37.390184
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = [ 'tasks', 'tasks', 'tasks', 'tasks' ]
    iterator_0 = IncludedFile.process_include_results(results_0, )

# Generated at 2022-06-25 05:24:45.057950
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = 'recursive'
    bool_1 = False
    float_1 = -896.44
    int_1 = 1359
    included_file_1 = IncludedFile(str_1, bool_1, float_1, int_1)
    var_0 = included_file_0 == included_file_1


# Generated at 2022-06-25 05:24:53.533521
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    included_file_1 = IncludedFile(str_0, bool_0, float_0, int_0)
    int_0 = 740
    included_file_2 = IncludedFile(str_0, bool_0, float_0, int_0)
    float_0 = -985.02
    included_file_3 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_0 = 'independent'
    included_file_4 = IncludedFile(str_0, bool_0, float_0, int_0)
    bool

# Generated at 2022-06-25 05:25:03.774240
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    var_0 = included_file_0.__repr__()
    results_1 = [None]
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_file_1 = IncludedFile.process_include_results(results_1, iterator_0, loader_0, variable_manager_0)
    print(included_file_1)


# Generated at 2022-06-25 05:25:16.029550
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = True
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    bool_1 = False
    float_1 = -896.44
    int_1 = 1359
    included_file_1 = IncludedFile(str_0, bool_1, float_1, int_1)
    bool_2 = bool_1
    float_2 = float_1
    int_2 = int_1
    included_file_2 = IncludedFile(str_0, bool_2, float_2, int_2)
    bool_3 = bool_0
    float_3 = float_0
    int_3 = int_0
    included_file

# Generated at 2022-06-25 05:25:20.482137
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'test-test-test'
    bool_0 = True
    float_0 = -1287.89
    int_0 = 2644
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    included_file_1 = IncludedFile(str_0, bool_0, float_0, int_0)
    bool_1 = included_file_0 == included_file_1
    assert bool_1 == True


# Generated at 2022-06-25 05:25:25.032454
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = 'until'
    bool_1 = False
    str_2 = 'import_playbook'
    int_1 = 1359
    included_file_1 = IncludedFile(str_1, bool_1, float_0, int_1)
    bool_2 = included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:25:34.426417
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'allow_world_readable_tmpfiles'
    bool_0 = True
    int_0 = 2103
    included_file_0 = IncludedFile(str_0, bool_0, None, int_0)
    str_1 = 'allow_world_readable_tmpfiles'
    bool_1 = True
    int_1 = 778
    included_file_1 = IncludedFile(str_1, bool_1, None, int_1)
    included_file_1 = included_file_0
    str_2 = 'allow_world_readable_tmpfiles'
    bool_2 = True
    int_2 = 596
    included_file_2 = IncludedFile(str_2, bool_2, None, int_2)
    included_file_2 = included_file_0

# Generated at 2022-06-25 05:25:45.900737
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 9378
    bool_0 = False
    int_1 = -1023
    str_0 = 'Linear'
    float_0 = 0.68
    included_file_0 = IncludedFile(int_0, bool_0, int_1, str_0, float_0)
    int_2 = 445
    bool_1 = False
    int_3 = -1235
    str_1 = 'Protocol'
    float_1 = 0.96
    included_file_1 = IncludedFile(int_2, bool_1, int_3, str_1, float_1)
    included_file_2 = IncludedFile(int_2, bool_0, int_3, str_1, float_1)

# Generated at 2022-06-25 05:26:14.759014
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("--- test_IncludedFile_process_include_results ---")
    IncludedFile.process_include_results(test_case_0)



# Generated at 2022-06-25 05:26:23.455448
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.utils.display import Display
    display = Display()

    results = []

    # test_case_0
    res = TaskInclude()
    res._host = 'localhost'
    res._task = TaskInclude()
    res._task._parent = IncludeRole()
    res._task._parent._role_path = 'tasks'
    res._task._uuid = res._host
    res._task._action = 'include_tasks'
    res._result = {'include':'tasks/main.yml'}
    results.append(res)

    # test_case_1
    res = TaskInclude()

# Generated at 2022-06-25 05:26:31.323607
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    include_result = {'include': './roles/common/handlers/main.yml', 'include_args': {}, 'ansible_loop_var': 'item', '_ansible_item_label': 'item', '_ansible_no_log': True}
    results = [include_result]
    # No template can be processed at this point, so nothing to test
    assert(True)



# Generated at 2022-06-25 05:26:40.354393
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    obj_0 = IncludedFile_process_include_results()
    for i in xrange(0, 64):
        rand_0 = rand_a()
        rand_1 = rand_a()
        rand_2 = rand_a()
        rand_3 = rand_a()
        rand_4 = rand_a()
        rand_5 = rand_a()
        rand_6 = rand_a()
        rand_7 = rand_a()
        rand_8 = rand_a()
        rand_9 = rand_a()
        rand_10 = rand_a()
        rand_11 = rand_a()
        rand_12 = rand_a()
        rand_13 = rand_a()
        rand_14 = rand_a()
        rand_15 = rand_a()
        rand_16 = rand_a()
        rand

# Generated at 2022-06-25 05:26:42.750051
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test no.1
    str_0 = 'tasks'
    str_1 = [str_0, str_0, str_0, str_0]


# Generated at 2022-06-25 05:26:47.358375
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()
    str_0 = 'tasks'
    str_1 = [str_0, str_0, str_0, str_0]


# Generated at 2022-06-25 05:26:49.712535
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for i in range(10000000):
        test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:57.752594
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'tasks'
    str_1 = [str_0, str_0, str_0, str_0, str_0]
    str_2 = [str_0, str_0, str_0, str_0]
    str_3 = 'tasks'
    str_4 = [str_0, str_0, str_0, str_0, str_0]
    str_5 = [str_0, str_0, str_0, str_0]
    str_6 = 'tasks'
    str_7 = [str_0, str_0, str_0, str_0, str_0]
    str_8 = [str_0, str_0, str_0, str_0]
    str_9 = 'tasks'
    # Testing function body
    object_

# Generated at 2022-06-25 05:27:01.581220
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_1 = 0
    list_1 = []
    IncludedFile.process_include_results(list_1, int_1, int_1, int_1)

# Generated at 2022-06-25 05:27:03.256754
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile.process_include_results()

# check describe of process_include_results

# Generated at 2022-06-25 05:27:28.816013
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'tasks'
    str_1 = [str_0, str_0, str_0, str_0]
    str_2 = 'action'
    dict_0 = dict()
    dict_0['skipped'] = True
    dict_1 = dict()
    dict_1['results'] = str_1
    dict_2 = dict()
    dict_2['skipped'] = True
    dict_2['ansible_loop_var'] = str_2
    dict_2['include'] = str_2
    dict_2['ansible_search_path'] = str_1
    dict_3 = dict()
    dict_3['skipped'] = True
    dict_3['results'] = [dict_2]
    dict_3['ansible_loop_var'] = str_2
    dict_

# Generated at 2022-06-25 05:27:31.185618
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        ansible.playbook.included_file.IncludedFile.process_include_results(str_1, str_1, str_1, str_1)
    except:
        pass

test_case_0()

# Generated at 2022-06-25 05:27:31.698409
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:27:37.141772
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = None
    results = None
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:27:38.238768
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:27:47.268577
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test with one object
    case_0 = IncludedFile(str, str, str, str, str)
    assert case_0.__eq__(str)
    # Test with three objects
    case_1 = IncludedFile(str, str, str, str, str)
    assert case_1.__eq__(str)
    # Test with two objects
    case_2 = IncludedFile(str, str, str, str, str)
    assert case_2.__eq__(str)
    # Test with multiple arguments (1)
    case_3 = IncludedFile(str, str, str, str, str)
    assert case_3.__eq__(str)
    # Test with multiple arguments (2)
    case_4 = IncludedFile(str, str, str, str, str)

# Generated at 2022-06-25 05:27:52.968503
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    inc_file_0 = IncludedFile('tasks' )
    inc_file_1 = IncludedFile('tasks' )
    # Incorrect type for parameter 'other'
    # assert inc_file_0.__eq__(list())

    assert inc_file_0.__eq__(inc_file_0)
    assert inc_file_0.__eq__(inc_file_1)


# Generated at 2022-06-25 05:27:55.668609
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = ['']
    iterator = iterator()
    loader = loader()
    variable_manager = variable_manager()
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:27:58.589695
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Test case 0 set up
    pass
    # Test case 0 call
    test_case_0()


if __name__ == '__main__':
    # Unit test for IncludedFile
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:01.042587
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:25.813547
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = 'recursive'
    bool_1 = False
    float_1 = -896.44
    int_1 = 1359
    included_file_1 = IncludedFile(str_1, bool_1, float_1, int_1)
    if (included_file_1 != included_file_0):
        print('Test failed')
        print('Expected: False')
        print('Received: {}'.format(included_file_1 != included_file_0))
    else:
        print('Test passed')

# Generated at 2022-06-25 05:28:33.871152
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'cbvg'
    bool_0 = False
    float_0 = 882.69
    int_0 = -180
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = ''
    float_1 = -728.433
    included_file_1 = IncludedFile(str_0, bool_0, float_1, int_0)
    assert(not (included_file_0 == included_file_1))


# Generated at 2022-06-25 05:28:39.032123
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [
        # TODO create input
    ]
    iterator = [
        # TODO create input
    ]
    loader = [
        # TODO create input
    ]
    variable_manager = [
        # TODO create input
    ]

    actual = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    return actual


# Generated at 2022-06-25 05:28:41.995838
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None, None)
    included_file_0.process_include_results(None, None, None, None)


# Generated at 2022-06-25 05:28:47.091470
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    assert included_file_0.__eq__(included_file_0) is True


# Generated at 2022-06-25 05:28:49.129189
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:50.280351
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("\n\n")
    print("Test process_include_results()")
    test_case_0()

test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:00.334561
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'rescue'
    float_0 = -423.69
    float_1 = -812.55
    str_1 = 'rescue'
    bool_0 = True
    float_2 = -94.19
    float_3 = -11.25
    int_0 = 1229
    included_file_0 = IncludedFile(str_0, float_0, float_1, int_0)
    int_1 = 1328
    included_file_1 = IncludedFile(str_1, bool_0, float_2, int_1)
    int_2 = 1082
    included_file_2 = IncludedFile(str_1, bool_0, float_3, int_2)
    int_3 = 1328

# Generated at 2022-06-25 05:29:02.899944
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('recursive', False, -896.44, 1359)
    var_0 = IncludedFile.process_include_results([included_file_0], included_file_0, included_file_0, included_file_0)

if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:10.959386
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    results = [{"include": "/tmp/ansible_test/test_cases/test_case_0/playbooks/include.yml", "include_args": (True,)}]
    iterator = 0
    loader = 0
    variable_manager = 0

    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:29:30.076437
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = list()
    assert 'foo' == IncludedFile.process_include_results(results)


# Generated at 2022-06-25 05:29:38.705689
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile('recursive', False, -896.44, 1359)
    var_0.add_host(IncludedFile('recursive', False, -896.44, 1359))
    var_1 = IncludedFile.process_include_results([var_0], var_0, var_0, var_0)
    var_2 = IncludedFile.process_include_results([var_0], var_0, var_0, var_0)
    assert var_1==var_2

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:42.696856
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    var_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    assert var_0 == []

# Generated at 2022-06-25 05:29:43.263266
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:29:50.053207
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Create mock object
    str_0 = 'resolve'
    bool_0 = False
    float_0 = -245.3
    int_0 = 538
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    # Create mock object
    str_1 = 'resolve'
    bool_1 = False
    float_1 = -245.3
    int_1 = 538
    included_file_1 = IncludedFile(str_1, bool_1, float_1, int_1)

    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:29:56.138287
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:30:03.053716
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = False
    float_0 = -2.92
    int_0 = 1447
    included_file_0 = IncludedFile(bool_0, float_0, int_0)
    var_0 = IncludedFile.process_include_results(bool_0, float_0, int_0, included_file_0)

if __name__ == "__main__":
    test_IncludedFile_process_include_results()
    test_case_0()

# Generated at 2022-06-25 05:30:08.605811
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'func'
    bool_0 = True
    float_0 = -135.97
    int_0 = 852
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = 'func'
    bool_1 = True
    float_1 = -135.97
    int_1 = 852
    included_file_1 = IncludedFile(str_1, bool_1, float_1, int_1)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:30:13.154674
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = 'results'
    iterator = 'iterator'
    loader = 'loader'
    variable_manager = 'variable_manager'
    var_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert var_0 is None

# Generated at 2022-06-25 05:30:15.926054
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test case 0
    included_files_0 = IncludedFile.process_include_results(str_0, str_1, bool_0, int_0)

# Generated at 2022-06-25 05:30:56.664330
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("Testing process_include_results()")
    test = IncludedFile.process_include_results()
    print("process_include_results() returned: ", test)
    assert test == 0, "process_include_results() failed"
    print("All tests passed")

if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:31:06.740955
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'maybe'
    bool_0 = True
    float_0 = 0.7046
    int_0 = -10535
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = 'maybe'
    bool_1 = False
    float_1 = 0.7046
    int_1 = -10535
    included_file_1 = IncludedFile(str_1, bool_1, float_1, int_1)
    bool_2 = included_file_0.__eq__(included_file_1)
    int_2 = 0
    int_3 = len(bool_2)
    int_4 = 0
    int_5 = len(bool_2)

# Generated at 2022-06-25 05:31:15.811662
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    host_0 = ''
    host_1 = 'cfgm-controller'
    task_0 = TaskInclude(None)
    task_1 = TaskInclude('hosts')
    task_1._host = host_1
    task_0._parent = task_1
    task_1._parent = task_0
    results_0 = [result_0, result_1]
    result_0 = dict()
    result_1 = dict()
    result_0['_task'] = task_0
    result_1['_task'] = task_1
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_files_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

# Generated at 2022-06-25 05:31:17.218007
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results()
    assert included_files == None

# Generated at 2022-06-25 05:31:20.585045
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


# Generated at 2022-06-25 05:31:28.244297
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'no_log'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = 'no_log'
    bool_1 = False
    float_1 = -896.44
    int_1 = 1359
    result = included_file_0.__eq__(str_1, bool_1, float_1, int_1)
    assert result == included_file_0


# Generated at 2022-06-25 05:31:34.486234
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        results = None
        iterator = None
        loader = None
        variable_manager = None
        included_file_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:31:47.024803
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    included_file_0 = IncludedFile()
    included_file_1 = IncludedFile()
    str_0 = 'include'
    str_1 = 'include'
    str_2 = 'include_role'
    list_0 = [str_0, str_1, str_2]
    dict_0 = {i: i for i in list_0}
    list_1 = ['action', 'name']
    dict_1 = {i: i for i in list_1}
    dict_0[str_1] = dict_1
    list_2 = ['name']
    dict_2 = {i: i for i in list_2}
    dict_3 = {'results': [dict_1, dict_2]}

# Generated at 2022-06-25 05:31:50.821042
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test with normal input
    included_files_1 = IncludedFile.process_include_results()

if __name__ == '__main__':
    test_case_0()
    # Unit test for method process_include_results of class IncludedFile
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:31:53.762082
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results('results', 'iterator', 'loader', 'variable_manager')
    print(included_files)

test_case_0()

# Generated at 2022-06-25 05:33:09.680728
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = "include"
    bool_0 = True
    float_0 = -2.34
    int_0 = 1438
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    str_1 = "include"
    bool_1 = True
    float_1 = -2.34
    int_1 = 1438
    included_file_1 = IncludedFile(str_1, bool_1, float_1, int_1)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:33:15.859041
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    # Regression
    str_1 = 'recursive'
    bool_1 = False
    float_1 = -896.44
    int_1 = 1359
    included_file_1 = IncludedFile(str_1, bool_1, float_1, int_1)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:33:22.665473
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'recursive'
    bool_0 = False
    float_0 = -896.44
    int_0 = 1359
    included_file_0 = IncludedFile(str_0, bool_0, float_0, int_0)
    int_1 = 1359
    included_file_1 = IncludedFile(str_0, bool_0, float_0, int_1)
    test_value = included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:33:29.124570
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'value'
    str_1 = 'value'
    str_2 = 'value'
    str_3 = 'value'
    str_4 = 'value'
    str_5 = 'value'
    str_6 = 'value'
    str_7 = 'value'
    str_8 = 'value'
    str_9 = 'value'
    str_10 = 'value'
    str_11 = 'value'
    str_12 = 'value'
    str_13 = 'value'
    str_14 = 'value'
    str_15 = 'value'
    str_16 = 'value'
    str_17 = 'value'
    str_18 = 'value'
    str_19 = 'value'
    dict_0 = dict()
    dict_1 = dict()
    dict_

# Generated at 2022-06-25 05:33:37.829384
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    string_0 = 'tasks'
    string_1 = 'headers'
    string_2 = 'list'
    string_3 = 'false'
    boolean_0 = False
    boolean_1 = True
    float_0 = -224.849
    int_0 = -1736
    string_4 = 'href'
    string_5 = 'mongo'
    string_6 = 'reject'
    int_1 = 854
    string_7 = 'null'
    float_1 = -569.4

# Generated at 2022-06-25 05:33:39.747200
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # cannot find method process_include_results
    pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:40.455920
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:33:41.738460
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results()


# Generated at 2022-06-25 05:33:43.209042
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results(str_0, bool_0, float_0, int_0)


# Generated at 2022-06-25 05:33:45.737455
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results(arg_0, arg_1, arg_2, arg_3)


if __name__ == '__main__':
    test_case_0()