

# Generated at 2022-06-25 05:24:33.711797
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Init test variables
    bool_0 = False
    bool_1 = True
    float_0 = 511.4900204
    float_1 = -276.7752569
    float_2 = -904.9656650
    int_0 = 674
    int_1 = -213
    int_2 = -208
    int_3 = -964
    int_4 = -234
    str_0 = 'nY'
    str_1 = 'Z'
    str_2 = 'zV'
    str_3 = 'b@M1~Y7'
    str_4 = '_iXX!&'

# Generated at 2022-06-25 05:24:37.161171
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # Check if the function add_host from class IncludedFile is passing the right parameter and returning the correct value
    assert included_file_0.add_host(bool_0) == None



# Generated at 2022-06-25 05:24:43.514261
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    int_0 = 86400
    bool_0 = False
    float_0 = 434.870212
    dict_0 = {bool_0: float_0, int_0: bool_0, float_0: int_0}
    included_file_0 = IncludedFile(int_0, int_0, bool_0, dict_0)
    int_1 = -245.14417453
    included_file_0.add_host(int_1)


# Generated at 2022-06-25 05:24:52.136043
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 86400
    bool_0 = False
    float_0 = 434.870212
    dict_0 = {bool_0: float_0, int_0: bool_0, float_0: int_0}
    # the 2nd parameter is iterator
    included_file_2 = IncludedFile(int_0, int_0, bool_0, dict_0)
    # the 3rd parameter is loader
    included_file_3 = IncludedFile(int_0, int_0, bool_0, dict_0)
    # the 4th parameter is variable_manager
    included_file_4 = IncludedFile(int_0, int_0, bool_0, dict_0)

# Generated at 2022-06-25 05:25:03.830285
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    dict_0 = {'R1': 0, 'R2': 1, 'R3': 2, 'R4': 3, 'R5': 4, 'R6': 5, 'R7': 6, 'R8': 7, 'R9': 8, 'R10': 9, 'R11': 10, 'R12': 11, 'R13': 12, 'R14': 13}
    dict_1 = {'R1': 0, 'R2': 1, 'R3': 2, 'R4': 3, 'R5': 4, 'R6': 5, 'R7': 6, 'R8': 7, 'R9': 8, 'R10': 9, 'R11': 10, 'R12': 11, 'R13': 12, 'R14': 13}

# Generated at 2022-06-25 05:25:13.397322
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # parameters
    included_results = '''
    tests/fixtures/test_include.yml
    '''
    included_results = included_results.split('\n')
    iterator = None
    loader = None
    variable_manager = None
    # calling of method
    IncludedFile_instance = IncludedFile()
    IncludedFile_instance.process_include_results(included_results, iterator, loader, variable_manager)
    # result
    assert not IncludedFile_instance

test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:15.059182
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = test_case_0()
    assert len(included_files) == 4

# Generated at 2022-06-25 05:25:20.260317
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = []
    results_0 = []
    iterator = None
    loader = None
    variable_manager = None
    ansible_test = IncludedFile.process_include_results(results_0, iterator, loader, variable_manager)
    assert ansible_test == included_files_0


# Generated at 2022-06-25 05:25:26.138725
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 86400
    bool_0 = False
    float_0 = 434.870212
    dict_0 = {bool_0: float_0, int_0: bool_0, float_0: int_0}
    included_file_0 = IncludedFile(int_0, int_0, bool_0, dict_0)
    included_file_1 = IncludedFile(int_0, int_0, bool_0, dict_0)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:25:32.036964
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    int_0 = 86400
    bool_0 = False
    float_0 = 434.870212
    dict_0 = {bool_0: float_0, int_0: bool_0, float_0: int_0}
    included_file_0 = IncludedFile(int_0, int_0, bool_0, dict_0)

    included_file_0.add_host(bool_0)


# Generated at 2022-06-25 05:25:45.392573
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:25:56.306083
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 58636
    bool_0 = True
    float_0 = 545.68848
    dict_0 = {int_0: bool_0, bool_0: int_0}
    int_1 = 86400
    dict_1 = {int_0: bool_0, bool_0: int_1}
    included_file_0 = IncludedFile(int_0, int_0, bool_0, dict_0)
    included_file_1 = IncludedFile(int_0, int_0, bool_0, dict_1)
    bool_1 = included_file_0 == included_file_1
    int_2 = 86400
    bool_2 = False
    float_1 = 434.870212

# Generated at 2022-06-25 05:25:57.390521
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    path_0 = IncludedFile.process_include_results()
    assert path_0 == None

# Generated at 2022-06-25 05:26:01.865438
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    int_0 = 86400
    bool_0 = False
    float_0 = 434.870212
    dict_0 = {bool_0: float_0, int_0: bool_0, float_0: int_0}
    included_file_0 = IncludedFile(int_0, int_0, bool_0, dict_0)
    included_file_0.add_host(dict_0)
    assert included_file_0._hosts[0] == dict_0



# Generated at 2022-06-25 05:26:10.277816
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    arg_0 = []
    arg_1 = []
    arg_2 = []
    arg_3 = []
    int_0 = -9789
    float_0 = 582.99
    str_0 = ")bFfZ"
    tuple_0 = (-26875, str_0, "4B0o")
    set_0 = {tuple_0, -54.061, ((str_0, float_0) for i in range(99))}
    dict_0 = {24: set_0, str_0: int_0, tuple_0: -96.422}
    excluded_file_0 = IncludedFile.process_include_results(arg_0, arg_1, arg_2, arg_3)
    # Returns a tuple. Checks type of first and second elements, as well as the length of the

# Generated at 2022-06-25 05:26:13.708986
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    include_file = IncludedFile("IncludedFile", "IncludedFile", "IncludedFile", "IncludedFile")
    display.deprecated("IncludedFile.add_host()", '1.9.0', removed=True)



# Generated at 2022-06-25 05:26:14.866061
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Test cases for setter methods


# Generated at 2022-06-25 05:26:23.238107
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 86400
    bool_0 = False
    float_0 = 434.870212
    dict_0 = {bool_0: float_0, int_0: bool_0, float_0: int_0}
    included_file_0 = IncludedFile(int_0, int_0, bool_0, dict_0)
    included_file_1 = IncludedFile(int_0, int_0, bool_0, dict_0)
    included_file_2 = IncludedFile(int_0, int_0, bool_0, dict_0)
    included_file_2._filename = bool_0
    included_file_3 = IncludedFile(int_0, int_0, bool_0, dict_0)
    included_file_3._args = bool_0

# Generated at 2022-06-25 05:26:26.391862
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:26:36.772022
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(288.26385, 7756, -857.34, 'S6SjVk;/!Q;dg7')
    included_file_1 = IncludedFile(588.7806, 'S6SjVk;/!Q;dg7', 'S6SjVk;/!Q;dg7', 'S6SjVk;/!Q;dg7')
    included_file_2 = IncludedFile('S6SjVk;/!Q;dg7', 588.7806, 'S6SjVk;/!Q;dg7', 'S6SjVk;/!Q;dg7')

# Generated at 2022-06-25 05:26:58.028505
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        test_case_0()
    except ValueError:
        pass
    else:
        raise AssertionError

if __name__ == '__main__':
  test_IncludedFile_process_include_results()
  test_case_0()

# Generated at 2022-06-25 05:27:01.403727
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = included_file_0 = IncludedFile()
    IncludedFile.__eq__(int_0, included_file_0)


# Generated at 2022-06-25 05:27:10.106655
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'qeXc'
    included_file_1 = IncludedFile(str_0, str_0, str_0, str_0)
    included_file_2 = IncludedFile(str_0, str_0, str_0, str_0)
    tuple_0 = (included_file_1, included_file_2)
    int_0 = 86400
    var_0 = IncludedFile.process_include_results(tuple_0, str_0, str_0, int_0)


# Generated at 2022-06-25 05:27:11.488999
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results(int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 05:27:16.780285
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:27:19.485450
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile.__new__(IncludedFile)
    included_file_1 = IncludedFile.__new__(IncludedFile)
    var_0 = included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:27:25.636568
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    include_result_0 = {}
    include_result_1 = {}
    include_result_2 = {}
    include_result_3 = {}
    include_result_4 = {}
    include_result_5 = {}
    include_result_6 = {}
    include_result_7 = {}
    include_result_8 = {}
    include_result_9 = {}
    include_result_10 = {}
    include_result_11 = {}
    include_result_12 = {}
    include_result_13 = {}
    include_result_14 = {}
    include_result_15 = {}
    include_result_16 = {}
    include_result_17 = {}
    include_result_18 = {}
    include_result_19 = {}
    include_result_20 = {}
    include_result_21 = {}
   

# Generated at 2022-06-25 05:27:26.701522
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile.process_include_results()


# Generated at 2022-06-25 05:27:28.368463
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: Implement unit test for method process_include_results of class IncludedFile
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:27:30.240550
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:28:10.495231
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(1.0, 1.0, 1.0, 1.0)
    var_0 = [1]
    var_1 = None
    var_2 = []
    var_3 = None
    var_2.append(var_3)
    var_3 = var_0
    var_3.append(var_1)
    var_3 = var_2
    var_4 = included_file_0.process_include_results(var_3, var_3, var_3, var_3)
    assert var_4 is None, "IncludedFile.process_include_results() did not return expected value"


# Generated at 2022-06-25 05:28:18.176584
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    iterator = None  # iterator should be of type PlayIterator
    loader = None  # loader should be of type DataLoader
    variable_manager = None  # variable_manager should be of type VariableManager
    results = None  # results should be of type HostResult
    return_val = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert return_val == None

# Generated at 2022-06-25 05:28:25.868171
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # simple test for template representation of IncludedFile
    int_0 = 86400
    bool_0 = False
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    str_0 = repr(included_file_0)



if __name__ == "__main__":
    print('Executing unit tests for IncludedFile ...')
    print('Executing test_case_0...')
    try:
        test_case_0()
    except AssertionError:
        print('AssertionError raised in test_case_0.')

    print('Executing test_IncludedFile_process_include_results ...')

# Generated at 2022-06-25 05:28:30.998128
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    obj_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    var_0 = IncludedFile.process_include_results(list_0, int_0, bool_0, bool_0)
    pass


# Generated at 2022-06-25 05:28:35.094618
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 86400
    bool_0 = False
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_1 = IncludedFile(int_0, int_0, bool_0, bool_0)
    assert(included_file_0 == included_file_1)


# Generated at 2022-06-25 05:28:39.429331
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'value'
    list_0 = ['list_0']
    included_file_0 = IncludedFile(str_0, list_0, list_0, list_0)
    IncludedFile_process_include_results(included_file_0)



# Generated at 2022-06-25 05:28:49.344801
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = False
    bool_1 = True
    excluded_task_0 = TaskInclude([], [], [], [], bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_1, bool_0, bool_1, bool_0, bool_0, bool_0, bool_0, bool_1, bool_0, bool_0, bool_0, bool_1, bool_0, bool_0, bool_1)
    included_file_0 = IncludedFile(int(0), int(0), bool_1, excluded_task_0)
    str_0 = 'include_results'

# Generated at 2022-06-25 05:29:00.287448
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    int_0 = 86400
    bool_0 = False
    loader = LOADER
    variable_manager = VARIABLE_MANAGER
    iterator = 0

    # Test case 0


# Generated at 2022-06-25 05:29:04.614321
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 86400
    bool_0 = True
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    bool_1 = True
    bool_2 = False
    included_file_1 = IncludedFile(bool_1, bool_2, bool_0, bool_1)
    var_2 = included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:29:10.611157
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 86400
    bool_0 = False
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_1 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_2 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_2 = IncludedFile.process_include_results(int_0, int_0, int_0, int_0)

if __name__ == '__main__':
    test_case_0()
    test_case_1()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:52.465840
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    arg_0 = None
    arg_1 = None
    arg_2 = None
    arg_3 = None
    var_0 = IncludedFile.process_include_results(arg_0, arg_1, arg_2, arg_3)

# Generated at 2022-06-25 05:29:57.561346
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import mock
    IncludedFile.process_include_results(mock.MagicMock(), mock.MagicMock(), mock.MagicMock(), mock.MagicMock())
    assert True



# Generated at 2022-06-25 05:29:59.680654
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = list()
    pass
    IncludedFile.process_include_results(results, None, None, None)

# Generated at 2022-06-25 05:30:06.114799
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_1 = 5
    bool_0 = True
    bool_1 = True
    int_0 = 1
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    var_1 = IncludedFile.process_include_results(int_1, int_1, int_1, int_1)


# Generated at 2022-06-25 05:30:12.125578
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_1 = IncludedFile(int_0, int_0, bool_1, bool_0)
    included_file_2 = IncludedFile(int_0, int_0, bool_1, bool_1)
    included_file_3 = IncludedFile(int_0, int_1, bool_1, bool_0)
    included_file_4 = IncludedFile(int_1, int_0, bool_0, bool_1)
    included_file_5 = IncludedFile(int_1, int_1, bool_0, bool_1)
    included_file_6 = IncludedFile(int_1, int_0, bool_1, bool_1)

# Generated at 2022-06-25 05:30:13.581651
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_1 = IncludedFile.process_include_results(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 05:30:15.792903
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 86400
    bool_0 = False
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    var_0 = included_file_0.__eq__(int_0)


# Generated at 2022-06-25 05:30:22.933305
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Create a template used to generate the test data

    # Create the test data
    iterator = ''
    loader = ''
    variable_manager = ''
    results = ''

    # Invoke the target method
    ret_val = IncludedFile.process_include_results(results, iterator, loader, variable_manager)


if __name__ == "__main__":
    import sys

    # when this module is called from command line, it runs all its tests
    module_name = sys.modules[__name__].__file__
    testcases = [obj for obj in globals().values() if isinstance(obj, type) and issubclass(obj, unittest.case.TestCase)]

    for testcase in testcases:
        testcase.__str__ = str(testcase)
        suite = unittest.TestLoader().loadTests

# Generated at 2022-06-25 05:30:24.876517
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:26.892763
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = False
    int_0 = 7811
    IncludedFile.__eq__(bool_0, int_0)


# Generated at 2022-06-25 05:31:53.959420
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    data = []
    iterator = IncludedFile
    loader = IncludedFile
    variable_manager = IncludedFile
    ret_obj = IncludedFile.process_include_results(data, iterator, loader, variable_manager)
    assert ret_obj is None

# Generated at 2022-06-25 05:31:59.430195
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 86400
    bool_0 = False
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_1 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_2 = IncludedFile(int_0, included_file_1, bool_0, bool_0)
    var_0 = included_file_0.__eq__(included_file_1)
    var_1 = included_file_0.__eq__(included_file_2)


# Generated at 2022-06-25 05:32:07.101588
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 3
    int_1 = 2
    bool_0 = False
    bool_1 = True
    included_file_0 = IncludedFile(int_0, int_0, bool_0, bool_0)
    included_file_1 = IncludedFile(int_1, int_0, bool_0, bool_0)
    var_0 = included_file_0 == included_file_1


# Generated at 2022-06-25 05:32:08.326519
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:32:12.043002
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    int_0 = 89430
    bool_0 = False
    included_file_0 = IncludedFile(bool_0, int_0, int_0, bool_0)
    bool_1 = __eq__(included_file_0, included_file_0)
    assert bool_1



# Generated at 2022-06-25 05:32:18.032132
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = []
    iterator = IncludedFile
    loader = None
    variable_manager = IncludedFile

    var_0 = IncludedFile.process_include_results(included_files, iterator, loader, variable_manager)
    print(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:32:21.911631
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [1, 2, 3, 4]
    iterator = 1
    loader = 1
    variable_manager = 1
    var_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

if __name__ == '__main__':
    # start unit test
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:32:29.742059
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 5
    dict_0 = dict()
    dict_0['include'] = [ int_0 ]
    dict_2 = dict()
    dict_1 = dict()
    dict_1['results'] = dict_2
    dict_2['include'] = dict_0
    list_0 = list()
    list_0.append(dict_1)
    int_1 = 476
    str_0 = 'set'
    result_0 = IncludedFile.process_include_results(list_0, int_0, int_1, str_0)
    assert len(result_0) == 1



# Generated at 2022-06-25 05:32:35.603489
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    args_0 = 0
    args_1 = 0
    args_2 = 0
    args_3 = 0
    args_4 = 0
    args_5 = 0
    args_6 = 0
    args_7 = 0
    args_8 = 0

    included_file_0 = IncludedFile.process_include_results(args_0, args_1, args_2, args_3)
    #assert included_file_0 == expected_0


if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:32:46.404085
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 427126665
    bool_0 = True
    bool_1 = False
    str_0 = 'tests/fixtures/test_playbook.yml'
    str_1 = 'tests/fixtures/test_playbook.yml'
    str_2 = 'tests/fixtures/test_playbook.yml'
    str_3 = 'tests/fixtures/test_playbook.yml'
    str_4 = 'tests/fixtures/test_playbook.yml'
    str_5 = 'tests/fixtures/test_playbook.yml'
    str_6 = 'tests/fixtures/test_playbook.yml'
    str_7 = 'tests/fixtures/test_playbook.yml'