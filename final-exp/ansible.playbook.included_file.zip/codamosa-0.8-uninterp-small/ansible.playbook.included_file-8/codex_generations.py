

# Generated at 2022-06-25 05:24:50.340718
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    bytes_2 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_3 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_1 = -1115

# Generated at 2022-06-25 05:25:01.869396
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # var_0 should be None
    var_0 = None
    # var_1 should be None
    var_1 = None
    # var_2 should be None
    var_2 = None
    # The test below should raise a TypeError (keyword arguments for call)
    # process_include_results(var_0, var_1=var_0, var_2=var_1)
    # The test below should raise a TypeError (missing 1 required positional argument)
    # process_include_results()
    # The test below should raise a TypeError (too many positional arguments)
    # process_include_results(var_0, var_1, var_2)
    # The test below should raise a TypeError (too many keyword arguments)
    # process_include_results(var_0, var_1, var_2, var_

# Generated at 2022-06-25 05:25:08.228806
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file_0 = IncludedFile(None, None, None, None)
    # No exception should be thrown
    try:
        included_file_0.add_host(None)
    except ValueError:
        # This is a test. The test case should never throw an exception
        raise AssertionError()


# Generated at 2022-06-25 05:25:09.189458
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:25:20.534449
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    bytes_2 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_3 = b'Prob\xb7\xd5\xcdD\x1e\xa1\xb9\xaa\x8e'
    bytes_4 = b'\x89QV\xeb\xacmFr2\xa4\xc3'

# Generated at 2022-06-25 05:25:24.291296
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile()
    included_file_1 = IncludedFile()
    bool_0 = included_file_0.__eq__(included_file_1)
    bool_1 = included_file_0.__eq__(included_file_1)
    bool_2 = included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:25:25.030633
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


# Generated at 2022-06-25 05:25:35.448583
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = random.randint(-99, 99)
    int_1 = random.randint(-99, 99)
    int_2 = random.randint(-99, 99)
    int_3 = random.randint(-99, 99)
    int_4 = random.randint(-99, 99)
    int_5 = random.randint(-99, 99)
    int_6 = random.randint(-99, 99)
    str_0 = '\\' + '"\\0\\t\\r\\n\\x0b\\x1c\\x1d\\x1e\\x85\\u2028\\u2029'
    str_1 = 'Sfn'
    str_2 = 's7]Q!4+4\x02'

# Generated at 2022-06-25 05:25:45.997544
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'E\x99\xe7\xbd\xb8\x81i\x88\xea\x95\x8f\x88\xa2\x08\x01\x8e\x98\x9f'
    int_0 = -6
    exception_0 = None
    try:
        IncludedFile.process_include_results(bytes_0, int_0, FileNotFoundError(), int_0)
    except FileNotFoundError as exception_0:
        pass
    else:
        assert False
    assert exception_0 is not None
    assert isinstance(exception_0, FileNotFoundError)

# Generated at 2022-06-25 05:25:57.145074
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    bytes_2 = b'\xb8\xee\xad\x01\x84\xfa\xdb\x1e\x94\xb4\xdc\xd4'
    int_1 = -1115
    included_file_1 = IncludedFile(bytes_0, bytes_0, bytes_2, int_1)

# Generated at 2022-06-25 05:26:15.563124
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile.process_include_results(included_file_0, int_0, bytes_0, bytes_1)

# Generated at 2022-06-25 05:26:19.082926
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('', '', '', )
    included_file_0.process_include_results()


# Generated at 2022-06-25 05:26:26.945099
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    try:
        included_file_0 = IncludedFile(None, None, None, None)
        included_file_1 = included_file_0
        included_file_2 = IncludedFile(None, None, None, None)
        if (included_file_0 == included_file_1):
            raise Exception('Test fail')
        if not (included_file_0 == included_file_2):
            raise Exception('Test fail')
    except Exception as exceptions_0:
        print(str(exceptions_0))

# Generated at 2022-06-25 05:26:27.593077
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True

# Generated at 2022-06-25 05:26:37.554277
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    included_file_1 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)

# Generated at 2022-06-25 05:26:41.784294
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:46.594747
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    included_file_1 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:26:54.283216
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(b'\xf7\x03\x90\xdb\xed\xeb\xe6\x92\xa0\x91\xc6', '-', '\xa0\x10!\x8e', '\xe2\xbdR\xa9\xc8\xc7m\xa3\xfc\xabr')
    var_0 = {}
    var_1 = {}

# Generated at 2022-06-25 05:26:55.725387
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:56.217179
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False

# Generated at 2022-06-25 05:27:42.788161
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    included_file_1 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    check_true(included_file_0.__eq__(included_file_1))
    check_true(not included_file_0.__eq__(included_file_1))


# Generated at 2022-06-25 05:27:46.781550
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 5
    list_0 = [int_0, int_0]
    IncludedFile.process_include_results(list_0, None, None, None)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:47.733813
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True

main()

# Generated at 2022-06-25 05:27:57.604395
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xfc\x1e\xb7\x9d\xfe\x16\xc1\xd5\xcf\xcd'
    bytes_1 = b'\x80\xe9\xe5\x02\xc2\x1d\x90\xb7\x8a\x87\xd9\xe1\xba\xe5\xda'
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_0, bytes_0)
    included_file_1 = IncludedFile(bytes_1, bytes_1, bytes_1, bytes_0)
    included_file_2 = IncludedFile(bytes_0, bytes_0, bytes_0, bytes_0)

# Generated at 2022-06-25 05:27:58.997570
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    ptr_0 = test_case_0()
    ptr_0.process_include_results(ptr_0, ptr_0, ptr_0, ptr_0)


# Generated at 2022-06-25 05:28:03.948192
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    pass

if __name__ == '__main__':
    import sys
    import traceback

    def format_exception():
        exc_type, exc_value, exc_traceback = sys.exc_info()
        return ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))

    try:
        test_case_0()
    except:
        print(format_exception())
    else:
        print('Success!')

    try:
        test_IncludedFile_process_include_results()
    except:
        print(format_exception())
    else:
        print('Success!')

# Generated at 2022-06-25 05:28:10.852449
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xa3\xcb\x0f\x8f\x1e'
    bytes_1 = b'\x8a\xcf\x1f\xed\xca\x87\x86\xcd\xbd'
    dict_0 = dict()
    dict_0['ansible_loop'] = bytes_0
    dict_0['ansible_index_var'] = bytes_1
    dict_0['ansible_loop_var'] = bytes_0
    dict_0['failed'] = True
    dict_0['skipped'] = True
    dict_0['parsed'] = True
    dict_0['_ansible_parsed'] = True
    dict_0['_ansible_item_result'] = True
    dict_0['item'] = True
    dict

# Generated at 2022-06-25 05:28:11.305043
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:28:14.692292
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:28:19.227321
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    # TODO - implement
    #assert included_file_0.process_include_results(task_result) == 0

if __name__ == "__main__":
    test_case_0()
    #test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:36.039311
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test for non-string types
    IncludedFile.process_include_results(0)

# Generated at 2022-06-25 05:29:40.332452
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    included_file_0.process_include_results(None, None, None, None)

if __name__ == '__main__':
    """
    import cProfile
    cProfile.run('test_case_0()')
    """
    test_case_0()

# Generated at 2022-06-25 05:29:51.316650
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    included_file_0 = IncludedFile(
        '/etc/ansible/hosts',
        'ansible_variable',
        -5.5,
        None,
    )

    try:
        included_files = IncludedFile.process_include_results(
            'password',
            'result',
            'include',
            'variable_manager',
        )
    except TypeError:
        pass

    included_files = IncludedFile.process_include_results(
        'password',
        'result',
        included_file_0,
        'variable_manager',
    )

    included_files = IncludedFile.process_include_results(
        'password',
        'result',
        'include',
        included_file_0,
    )


# Generated at 2022-06-25 05:29:53.699947
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results(None, None, None, None)
    except NameError:
        assert False
    else:
        assert True


# Generated at 2022-06-25 05:30:03.946757
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 1542
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    dict_0 = {'include': bytes_1, 'include_args': dict()}
    results = [dict_0]
    IncludedFile.process_include_results(results, int_0)


if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:13.131895
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = '\x7f\x02\xad\x0f\x81-\x0c\x84'
    iterator = '\x9a\x9a\x9ey\x9a\x9a'
    loader = '\x8a\x99\x87\x9a\x9a\x9a\x9a\x9a'
    variable_manager = '\x9a\x9a\x9a\x9a\x9a'
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:30:20.691594
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\xef\xde\xdb\xbe\xf0m\xda\x1c\x8e\x8a\x12\x9c7*.\x83\xd8\xc1\xc1\xba\xdc\xdc\x05\x9b\xe7\x81\x1d\x8b\xa2\x00\x15\x0b\x04\x9f\x1f\xbe\xe8\xee\xc7\x11\xd1\x8f\xd4\xbb\xcd\x9f\x11\xee\x89\x99\xcb\x8c'

# Generated at 2022-06-25 05:30:23.896324
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        pass
    except:
        assert False


# Generated at 2022-06-25 05:30:32.560592
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    dict_0 = dict()
    bytes_2 = b'\x03\x01\xc7\x0cQO\x98\x06\x00'
    dict_0['include_args'] = bytes_2
    dict_0['include'] = bytes_2
    dict_1 = dict()
    dict_1['results'] = [dict_0]
    included_file_0

# Generated at 2022-06-25 05:30:40.847489
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:33:19.680241
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    included_file_1 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    int_1 = included_file_0.__eq__(included_file_1)
    print(int_1)


# Generated at 2022-06-25 05:33:27.248980
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    excluded_tests = [test_case_0]
    number_of_passed_tests = 0
    number_of_failed_tests = 0

    for test in [x for x in dir(__name__) if x.startswith('test_') and x not in excluded_tests]:
        locals()[test]()
        if locals()[test].__doc__ is None:
            number_of_failed_tests = number_of_failed_tests + 1
        else:
            number_of_passed_tests = number_of_passed_tests + 1

    print('Number of tests passed: ' + number_of_passed_tests)
    print('Number of tests failed: ' + number_of_failed_tests)

test_IncludedFile___eq__()

# Generated at 2022-06-25 05:33:30.356517
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results()
    assert not included_files

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:33:36.173857
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    included_file_1 = IncludedFile(bytes_0, bytes_0, bytes_1, int_0)
    included_file_2 = IncludedFile(bytes_1, bytes_1, bytes_1, Task())

    assert included_file_0 == included_file_1
    assert included_file_1 != included_file_2


# Generated at 2022-06-25 05:33:37.011062
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # not implemented
    pass


# Generated at 2022-06-25 05:33:39.548150
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert callable(IncludedFile.process_include_results)
    assert isinstance(IncludedFile.process_include_results(), list)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:41.181382
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results(None, None, None, None)
    assert isinstance(included_files_0, list)


# Generated at 2022-06-25 05:33:50.654177
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\x89QV\xeb\xacmFr2\xa4\xc3'
    bytes_1 = b'@\x0f\xa3\x7f\xd3iN\xb3\xae\x9ex\x90'
    int_0 = -1115
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    int_1 = -1233
    int_2 = -984
    dict_0 = dict()
    dict_0['include'] = 'xyz'
    dict_0['include_args'] = dict()
    dict_1 = dict()
    dict_1['results'] = list()
    dict_1['results'].append(dict_0)
    dict_2 = dict()
   

# Generated at 2022-06-25 05:33:51.495869
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:34:00.677097
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'_\x88\x85\xf0\x99\x98+\xdb\x9f'
    bytes_1 = b'\xbdU\xf6\xdd\x9b\x96\x8a\xe5O&F\x1b^\x13'
    bytes_2 = b'\xbdU\xf6\xdd\x9b\x96\x8a\xe5O&F\x1b^\x13'
    int_0 = -9846
    included_file_0 = IncludedFile(bytes_0, bytes_1, bytes_2, int_0)