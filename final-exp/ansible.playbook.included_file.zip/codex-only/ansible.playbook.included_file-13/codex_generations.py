

# Generated at 2022-06-23 06:24:03.628020
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-23 06:24:12.426830
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename='/home/vagrant/playbooks/test_playbook.yml'
    args={}
    vars={}
    task={}

    included_file = IncludedFile(filename,args,vars,task)
    host = 'localhost'
    included_file.add_host(host)
    assert len(included_file._hosts) == 1
    included_file.add_host(host)
    assert len(included_file._hosts) == 1


# Generated at 2022-06-23 06:24:22.289947
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader

    # Given
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    display.verbosity = 4


# Generated at 2022-06-23 06:24:28.870636
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    incfile = IncludedFile('/path/to/file',
                           'template_args',
                           'vars',
                           'task')

    assert incfile._filename == '/path/to/file'
    assert incfile._args == 'template_args'
    assert incfile._vars == 'vars'
    assert incfile._task == 'task'
    assert incfile._hosts == []
    assert incfile._is_role == False


# Generated at 2022-06-23 06:24:41.359368
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "test.play"
    args = {"a": "A" }
    vars = {"b": "B" }
    task = None
    inc_file = IncludedFile(filename, args, vars, task)

    # Adding host for the first time
    host1 = "host1"
    inc_file.add_host(host1)
    assert inc_file._hosts[0] == "host1"

    # Adding host for the second time, raise exception
    host2 = "host2"
    try:
        inc_file.add_host(host2)
        assert False
    except ValueError:
        assert True

    # Adding host for the third time, which is the same as the first time, do not raise exception
    inc_file.add_host(host1)
    assert inc_file._hosts

# Generated at 2022-06-23 06:24:50.359285
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('example.yaml', {}, {}, None)
    inc_file.add_host('host1')
    inc_file.add_host('host2')
    inc_file.add_host('host3')
    assert inc_file._hosts == ['host1', 'host2', 'host3']
    assert inc_file.__repr__() == "example.yaml (args={} vars={}): ['host1', 'host2', 'host3']"
    
    # test that trying to add the same host twice fails and raises ValueError
    raised = False
    try:
        inc_file.add_host('host3')
    except ValueError:
        raised = True
    assert raised


# Generated at 2022-06-23 06:25:03.856137
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # this test uses mock.patch, and so can't be run regularly with parallel run
    try:
        import mock
    except ImportError:
        return

    def my_method(*args, **kwargs):
        return True


# Generated at 2022-06-23 06:25:12.052552
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    def _make_include(filename, args, vars, task, is_role=False):
        if is_role:
            include = IncludeRole()
            include.role = Role()
            include.role._role_name = filename
            include.role._role_path = os.path.join(ROLE_PATH, filename)
        else:
            include = TaskInclude()
            include.action = 'include'

# Generated at 2022-06-23 06:25:25.224699
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import constants as C

    from ansible.executor.task_result import TaskResult
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = AnsibleLoader(play_source={'hosts': 'host1'})
    play = Play.load(dict(name=u'test_play'), variable_manager=VariableManager(), loader=loader)
    play._variable_manager.set

# Generated at 2022-06-23 06:25:35.326467
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest

    class FakeLoader(object):
        def path_dwim_relative(self, parent_dir, task_type, name, is_role=False):
            if name == 'role_include':
                return 'fake_role_path/tasks/main.yaml'
            else:
                return '{}/{}/{}/{}'.format(C.DEFAULT_ROLES_PATH, 'faked_role', task_type, name)

    class FakeTask(object):
        def __init__(self, action='include_tasks'):
            self.action = action
            self.loop = False


# Generated at 2022-06-23 06:25:39.979079
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert repr(IncludedFile(
        filename="include.yml",
        args={},
        vars={},
        task=None,
        is_role=False
    )) == "include.yml (args={} vars={}): []"

# Generated at 2022-06-23 06:25:49.449434
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "my_cool_file"
    args = {"arg1": 1, "arg2": 2}
    vars = {"var1": 2, "var2": 3}
    task = TaskInclude("_role_path", "dir_name", "filename")
    is_role = True

    inc_file = IncludedFile(filename, args, vars, task, is_role)

    # all three parameters of the constructor should be set correctly
    assert inc_file._filename == filename
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task == task
    assert inc_file._is_role == is_role

    # the hosts list should be empty
    assert inc_file._hosts == []

    host = "my_host"
    inc_file.add_

# Generated at 2022-06-23 06:25:59.704754
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "some_file.yml"
    args = {'a': 1, 'b': 2}
    vars = {'x': 99, 'y': 199}
    task = {'z': 47, '_parent': 'my_parent'}

    incf = IncludedFile(filename, args, vars, task)

    assert incf._filename == filename
    assert incf._args == args
    assert incf._vars == vars
    assert incf._task == task

    assert incf._hosts == []

    host = "some_host"
    incf.add_host(host)

    assert incf._hosts == [host]

    # This should fail because 'host' is already present in the hosts list.
    host = "other_host"

# Generated at 2022-06-23 06:26:13.445070
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class AnsibleHost:
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

        def __str__(self):
            return self._name

        def __repr__(self):
            return "IncludedFile test host %s" % self._name

    class AnsibleTask:
        def __init__(self):
            self._uuid = id(self)

        def __eq__(self, other):
            return other._uuid == self._uuid

        def __hash__(self):
            return self._uuid

        def __repr__(self):
            return "IncludedFile test task"

        def _parent(self):
            return None

    class AnsiblePlayBook:
        def __init__(self):
            self._

# Generated at 2022-06-23 06:26:23.668964
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    class TestStrategy(StrategyBase):
        def __init__(self, tqm):
            self._tqm = tqm
            self._display = Display()


# Generated at 2022-06-23 06:26:26.635938
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task_include import TaskInclude

    included_file = IncludedFile('filename', 'args', 'vars', TaskInclude('task_include'))
    actual_result = included_file.__repr__()
    expected_result = "filename (args=args vars=vars): []"
    assert actual_result == expected_result


# Generated at 2022-06-23 06:26:37.867112
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # Test method add_host with _hosts = []
    inc_file1 = IncludedFile("/tmp/playbook1.yml", dict(), dict(), None)
    inc_file1.add_host("host1")
    assert inc_file1._hosts == ["host1"]

    # Test method add_host with _hosts = [host1]
    inc_file2 = IncludedFile("/tmp/playbook2.yml", dict(), dict(), None)
    inc_file2.add_host("host1")
    assert inc_file2._hosts == ["host1"]

    # Test method add_host with _hosts = [host1, host2]
    inc_file3 = IncludedFile("/tmp/playbook3.yml", dict(), dict(), None)

# Generated at 2022-06-23 06:26:46.206480
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from collections import namedtuple
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    fake_variable_manager = VariableManager()
    fake_loader = namedtuple('MockLoader', ['path_dwim'])(lambda x: x)

    fake_block = Block()
    fake_block.vars = {'arg1': 'val1', 'arg2': 'val2'}

# Generated at 2022-06-23 06:26:50.748834
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    '''
    Tests for add_host method of class IncludedFile
    '''
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    try:
        ifile = IncludedFile("file", {}, {}, TaskInclude(loader=loader, play=Play().load(dict(name="test", hosts=['127.0.0.1']), variable_manager=variable_manager)))
        ifile.add_host("127.0.0.1")
        ifile.add_host("127.0.0.1")
    except ValueError:
        print("Unit Test: Test for method add_host of class IncludedFile FAILED")
        raise
    else:
        print("Unit Test: Test for method add_host of class IncludedFile SUCCEDED")

# Generated at 2022-06-23 06:26:59.373499
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Test that the add_host method correctly adds a new host to included_files
    # when the host is not already present
    included_file = IncludedFile("filename", "args", "vars", "task")
    included_file.add_host("host1")
    assert(included_file._hosts == ["host1"])

    # Test that the add_host method correctly fails when the host is already
    # present. This can happen when adding the same task multiple times to the
    # same include/role
    try:
        included_file.add_host("host1")
    except ValueError:
        assert(True)
    else:
        assert(False)

# Generated at 2022-06-23 06:27:08.441672
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task

    host1 = Host(name='localhost')
    task1 = Task()
    filename1 = 'test.yml'
    args1 = {
        'x' : 1,
        'y' : 2,
    }
    vars1 = {
        'z' : 3,
        'w' : 4,
    }

    included_file1 = IncludedFile(filename1, args1, vars1, task1)
    included_file1.add_host(host1)
    included_file2 = IncludedFile(filename1, args1, vars1, task1)
    included_file2.add_host(host1)


# Generated at 2022-06-23 06:27:17.692466
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print(">>> test_IncludedFile:")
    f = IncludedFile("/tmp/a.yml", "myargs", "myvars", None)
    print(f)
    try:
        f.add_host("A")
        f.add_host("B")
        f.add_host("A")
        print("Error: should have failed")
    except ValueError:
        print("OK")
    print(f)
    f = IncludedFile("/tmp/a.yml", "myargs", "myvars", None)
    print(f)
    f.add_host("B")
    print(f)


if __name__ == '__main__':
    test_IncludedFile()

# Generated at 2022-06-23 06:27:20.825959
# Unit test for constructor of class IncludedFile
def test_IncludedFile():

    incFile = IncludedFile("/home/ansible/playbook.yml", "", "", "")
    assert incFile is not None

# Generated at 2022-06-23 06:27:23.504876
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    a = IncludedFile('filename', dict(), dict(), dict())
    b = IncludedFile('filename', dict(), dict(), dict())
    assert(a == b)

# Generated at 2022-06-23 06:27:32.937210
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    obj1 = IncludedFile(0, 0, 0, 0)
    obj2 = IncludedFile(1, 1, 1, 1)
    assert(obj1 == obj2)
    obj2._filename = 2
    assert(obj1 != obj2)
    obj2._filename = obj1._filename
    obj2._args = 2
    assert(obj1 != obj2)
    obj2._args = obj1._args
    obj2._vars = 2
    assert(obj1 != obj2)
    obj2._vars = obj1._vars
    obj2._task._uuid = 2
    assert(obj1 != obj2)
    obj2._task._uuid = obj1._task._uuid
    obj2._task._parent._uuid = 2
    assert(obj1 != obj2)


# Generated at 2022-06-23 06:27:35.483191
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert str(IncludedFile("test", 'args', 'vars', 'task')) == "test (args=args vars=vars): []"

# Generated at 2022-06-23 06:27:44.211738
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # use the same static variables loaded by ansible-playbook
    from ansible.constants import DEFAULTS
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.vars.manager import VariableManager

    # use the same data structure loaded by ansible-playbook
    from ansible.executor.task_result import TaskResult

    basedir = 'tests/integration/role_loader_include/'
    hostname = 'localhost'

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'omit': 'fail'}
    variable_manager.options_vars = {'ask_pass': True, 'ask_vault_pass': False}
    variable_manager.set_inventory(Inventory('localhost'))

    loader = DataLoader()

# Generated at 2022-06-23 06:27:47.698243
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile(None, None, None, None)
    assert repr(included_file) == '<None> (args=None vars=None): []'


# Generated at 2022-06-23 06:27:56.049916
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from io import StringIO

    # prepare Ansible objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 06:28:02.879355
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    args = dict()
    vars = dict()
    task = None
    filename = 'roles/my_role/tasks/main.yml'
    incf = IncludedFile(filename, args, vars, task)
    assert incf.__repr__() == 'roles/my_role/tasks/main.yml (args={} vars={}): []'

# Unit tests for method add_host of class IncludedFile

# Generated at 2022-06-23 06:28:16.802823
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Prepare objects to test method add_host of class IncludedFile
    host1 = "foo"
    host2 = "bar"
    host3 = "foo"
    filename = "file"
    args = dict()
    vars = dict()
    task = dict()
    incfile = IncludedFile(filename, args, vars, task)

    # Add host1 to list of hosts
    incfile.add_host(host1)

    # Check if host1 was added to the list successfully
    assert incfile._hosts[0] == host1

    # Add host2 to list of hosts
    incfile.add_host(host2)

    # Check if host2 was added to the list successfully
    assert incfile._hosts[1] == host2

    # Add host3 to list of hosts (that already contains host1)
    #

# Generated at 2022-06-23 06:28:23.784701
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = DummyLoader()
    variable_manager = DummyVarsManager()
    play1 = Play().load(dict(
        name = "Ansible Play 1",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            Task().load(dict(include='main.yml'), variable_manager=variable_manager, loader=loader),
        ]
    ), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:28:29.375880
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'my_file.yml'
    args = {'name': 'joe'}
    vars = {'age': 10}
    task = 'include'
    included_file = IncludedFile(filename, args, vars, task)
    assert isinstance(included_file, IncludedFile)


# Generated at 2022-06-23 06:28:41.602242
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class TestTask(object):
        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent

        def __eq__(self, other):
            return (other._uuid == self._uuid and
                    other._parent._uuid == self._parent._uuid)

    class TestParent(object):
        def __init__(self, uuid):
            self._uuid = uuid

    test_task1 = TestTask('foo', TestParent('bar'))
    test_task2 = TestTask('foo2', TestParent('bar2'))

    test_inc_file = IncludedFile('test_file_name', 'test_args', 'test_vars', test_task1)

# Generated at 2022-06-23 06:28:49.776744
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class DummyVariableManager:
        def get_vars(self, play, host, task):
            assert play == iterator._play
            assert host == original_host
            assert task == original_task
            return dict(a=1, ansible_search_path=[])

    class DummyLoader:
        def get_basedir(self):
            return 'the-basedir'

        def path_dwim(self, filename):
            return filename

        def path_dwim_relative(self, basedir, *args):
            return os.path.join(basedir, *args)

    class DummyHandler:
        def get_search_path(self):
            return 'the-search-path'

    def dummy_templar(s):
        return s

    iterator = DummyHandler()
    original_task = D

# Generated at 2022-06-23 06:28:51.524084
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile("filename", "args", "vars", "task")
    print(included_file)



# Generated at 2022-06-23 06:29:04.345678
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = {'foo': 'bar'}

        def get_vars(self):
            return self.vars

    class HostVariableManager:
        def __init__(self, variables):
            self.variables = variables

        def get_vars(self, **args):
            return self.variables

    class Task:
        def __init__(self, uuid, parent, action, args, loop, no_log=False):
            self._uuid = uuid
            self._parent = parent
            self.action = action
            self._args = args
            self.loop = loop
            self.no_log = no_log

        @property
        def args(self):
            return self._args


# Generated at 2022-06-23 06:29:07.587082
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = TaskInclude()
    task.action = 'include'
    filename = '/tmp/foo'
    args = {'arg1': 1, 'arg2': 'foo'}
    vars = {'var1': 2, 'var2': 'bar'}
    inc1 = IncludedFile(filename, args, vars, task)
    inc2 = IncludedFile(filename, args, vars, task)
    assert inc1 == inc2


# Generated at 2022-06-23 06:29:09.203354
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Test with different arguments.
    assert str(IncludedFile("filename", 1, {1:1}, 1)) == "filename (args=1 vars={1: 1}): []"

# Generated at 2022-06-23 06:29:13.055589
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    f1 = IncludedFile('f1', None, None, None)
    f2 = IncludedFile('f2', None, None, None)
    f3 = IncludedFile('f1', None, None, None)

    assert f1 == f3
    assert not (f1 == f2)


# Generated at 2022-06-23 06:29:18.394894
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    foo = IncludedFile('foo', None, None, None)
    foo.add_host('host1')
    assert foo._hosts == ['host1']
    with pytest.raises(ValueError):
        foo.add_host('host1')
    foo.add_host('host2')
    assert foo._hosts == ['host1', 'host2']

# Generated at 2022-06-23 06:29:28.262638
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Create a host
    host = 'localhost'
    # Create an include file
    inc_file = IncludedFile('/etc/ansible/roles/testing/tasks/main.yml', {}, dict(), dict())
    # Incorrect insertion of a host
    try:
        inc_file.add_host(host)
        inc_file.add_host(host)
    except ValueError:
        # Ok, there is an error
        pass
    else:
        assert False
    # Correct insertion of a host
    inc_file = IncludedFile('/etc/ansible/roles/testing/tasks/main.yml', {}, dict(), dict())
    try:
        inc_file.add_host(host)
    except ValueError:
        # There is an error, this is bad
        assert False

# Generated at 2022-06-23 06:29:37.542301
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    loader = None
    variable_manager = None
    display = Display()
    filename = '/home/vagrant/ansible/lib/ansible/playbooks/sample-playbook.yml'
    args = {
        '_ansible_ignore_errors': True,
        '_ansible_no_log': False,
        '_raw_params': 'Handlers'
    }
    vars = {
        'omit': 'X',
        'ansible_version': {
            'full': '2.2.1.0',
            'major': 2,
            'minor': 2,
            'revision': 1,
            'string': '2.2.1.0'
        },
        'ansible_facts': {}
    }

# Generated at 2022-06-23 06:29:47.414457
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class Dummy(object):
        def __init__(self):
            self.name = 'dummy'
    dummy_host1 = Dummy()
    dummy_host2 = Dummy()
    dummy_task = Dummy()
    inc_file = IncludedFile('filename', {}, {}, dummy_task)

    inc_file.add_host(dummy_host1)
    assert len(inc_file._hosts) == 1
    assert inc_file._hosts[0].name == 'dummy'

    with pytest.raises(ValueError):
        inc_file.add_host(dummy_host1)
        assert len(inc_file._hosts) == 1

    inc_file.add_host(dummy_host2)
    assert len(inc_file._hosts) == 2

# Generated at 2022-06-23 06:29:58.073412
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import os

    def test_exception():
        try:
            incl_file.add_host(host)
        except ValueError:
            pass
        else:
            assert False

    filename = './my_test.yml'
    args = { 'param1' : 'value1' }
    vars = { 'var1' : 'val1' }
    task = IncludedFile(filename, args, vars, None)

    incl_file = IncludedFile(filename, args, vars, task)
    host = '127.0.0.1'
    incl_file.add_host(host)
    test_exception()

    incl_file = IncludedFile(filename, args, vars, task)
    incl_file._filename = './my_test1.yml'
    incl_file.add_host

# Generated at 2022-06-23 06:30:05.301198
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file1 = IncludedFile("/tmp/test_file1", {}, {}, None, False)
    included_file2 = IncludedFile("/tmp/test_file2", {}, {}, None, False)
    included_file3 = IncludedFile("/tmp/test_file1", {}, {}, None, False)
    assert included_file1 == included_file1
    assert not included_file1 == included_file2
    assert included_file1 == included_file3

# Generated at 2022-06-23 06:30:17.224250
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    import json
    import os
    import tempfile
    # Create a playbook executor to be able to create a task queue manager
    pbex = PlaybookExecutor(playbooks=[], inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    # Create a task queue manager

# Generated at 2022-06-23 06:30:25.096113
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    loader = DataLoader()
    play = Play.load(dict(),loader=loader,variable_manager=VariableManager(),host_vars=HostVars())
    tasks = play.get_tasks()
    task = tasks[0]
    hosts = [1]
    inc_file = IncludedFile('filename', 'args', 'vars', 'task')
    inc_file._hosts = hosts
    assert repr(inc_file) == "filename (args=args vars=vars): %s" % hosts

# Generated at 2022-06-23 06:30:25.631327
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-23 06:30:34.556338
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template.vars import VarsModule


# Generated at 2022-06-23 06:30:43.881450
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "myfile.yml"
    args = dict()
    vars = dict()
    task = object()

    inc = IncludedFile(filename, args, vars, task)
    host = object()
    assert 0 == len(inc._hosts)
    inc.add_host(host)
    assert 1 == len(inc._hosts)
    inc2 = IncludedFile(filename, args, vars, task)
    try:
        inc2.add_host(host)
        raise AssertionError("Did not raise an exception when adding a duplicate host")
    except ValueError:
        pass

# Generated at 2022-06-23 06:30:47.826379
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile("foo", "bar", 1, 2) == IncludedFile("foo", "bar", 1, 2)
    assert not (IncludedFile("foo", "bar", 1, 2) != IncludedFile("foo", "bar", 1, 2))
    assert (IncludedFile("foo", "bar", 1, 2) != IncludedFile("foo", "bar", 1, 3))
    assert IncludedFile("foo", "bar", 1, 2) != "foo"


# Generated at 2022-06-23 06:30:55.543634
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    inc_file = IncludedFile("file/name", "args", "vars", "parent_task")
    assert inc_file._filename == "file/name"
    assert inc_file._args == "args"
    assert inc_file._vars == "vars"
    assert inc_file._task == "parent_task"
    assert inc_file._hosts == []
    assert inc_file._is_role == False


# Generated at 2022-06-23 06:31:03.448907
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('some_file',{},{},{})

    # check add host first time
    assert inc_file._hosts == []
    inc_file.add_host('host_1')
    assert inc_file._hosts == ['host_1']

    # check add host second time
    try:
       inc_file.add_host('host_1')
    except ValueError:
       pass


# Generated at 2022-06-23 06:31:15.628163
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.plugins import module_utils
    from ansible.playbook.task import Task

    # Create a template for task
    task_template = dict(
        delegate_to='{{ target }}',
        ignore_errors=True,
        environment='{{ jinja_environment | default(omit) }}',
        when='{{ jinja_when | default(omit) }}',
        loop='{{ jinja_loop | default(omit) }}'
    )

    # Create an instance of class IncludedFile
    included_file = IncludedFile(filename='/home/ansible/nginx/tasks/main.yml', args={},
                                 vars={}, task=Task.load(task_template, module_utils=module_utils))

    # Check that add_host works properly

# Generated at 2022-06-23 06:31:21.473637
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Create a IncludedFile object
    filename = 'test.yml'
    args = {}
    vars = {'var1':'val1'}
    task = IncludeRole()
    is_role = True
    included_file = IncludedFile(filename, args, vars, task, is_role)
    
    # Test the __repr__ method of IncludedFile
    assert repr(included_file) == 'test.yml (args={} vars={\'var1\': \'val1\'}): []'

# Generated at 2022-06-23 06:31:30.394405
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook.task_include as task_include
    import test.utils.local.vault_util as vault_util
    import ansible.vars.manager as vars_manager
    import ansible.vars.unsafe_proxy as unsafe_proxy

    included_file1 = IncludedFile("filename1",
                                  "args1",
                                  "vars1",
                                  task_include.TaskInclude())
    included_file2 = IncludedFile("filename2",
                                  "args2",
                                  "vars2",
                                  task_include.TaskInclude())
    included_file1.add_host("host1")
    included_file1.add_host("host2")
    included_file2.add_host("host1")

    assert included_file1 == included_file1


# Generated at 2022-06-23 06:31:30.989057
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-23 06:31:40.443091
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    values = [
        {'filename': 'test_filename1', 'args': 'test_args1', 'vars': 'test_vars1', 'task': 'test_task1', 'is_role': 'test_is_role1'},
        {'filename': 'test_filename2', 'args': 'test_args2', 'vars': 'test_vars2', 'task': 'test_task2', 'is_role': 'test_is_role2'}
    ]

# Generated at 2022-06-23 06:31:49.286188
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [
        {
            '_host': 'foo',
            '_task': 'bar',
            'item': 'baz',
            'include': 'test.yml',
            'include_args': dict(),
            'result': dict(
                include='test.yml',
                include_args=dict(),
                include_hosts=dict(hosts=['a', 'b']),
                include_vars=dict(a=1, b=2),
            ),
        }
    ]
    iterator = object()
    loader = object()
    variable_manager = object()
    (
        included_files,
    ) = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert len(included_files) == 1
    inc_file = included_files[0]

# Generated at 2022-06-23 06:32:00.759971
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import os
    import tempfile

    # Initialize structures
    loader = None
    variable_manager = None
    iterator = None
    task = TaskInclude()

    # Prepare fake results
    results = []
    results.append(
        FakeResult(
            _host="localhost",
            _task=task,
            _result={
                'include': "tasks/foo.yml",
                '_ansible_item_label': 'foo',
                '_ansible_no_log': False,
                'ansible_loop_var': 'item',
                'ansible_search_path': [],
                'changed': False,
                'invocation': {'module_name': 'include_tasks', 'module_args': None},
                'item': 'foo'
            }
        )
    )

# Generated at 2022-06-23 06:32:08.896755
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    class Task:

        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent

    included_file = IncludedFile("/etc/passwd", None, None, Task("1", Task("2", None)))

    included_file_equal = IncludedFile("/etc/passwd", None, None, Task("1", Task("2", None)))

    included_file_not_equal = IncludedFile("/etc/group", None, None, Task("1", Task("3", None)))

    assert included_file == included_file_equal
    assert included_file != included_file_not_equal


# Generated at 2022-06-23 06:32:20.219233
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class TheTask:
        def __init__(self, the_uuid):
            self._uuid = the_uuid
            self._parent = None

    class TheParentTask:
        def __init__(self, the_uuid):
            self._uuid = the_uuid

    # test case: args and vars are different
    a_task = TheTask('task-a')
    a_task._parent = TheParentTask('parent-a')
    b_task = TheTask('task-b')
    b_task._parent = TheParentTask('parent-b')
    inc_file_a = IncludedFile('filename', {'a': 1}, {'b': 2}, a_task)
    inc_file_b = IncludedFile('filename', {'x': 1}, {'y': 2}, b_task)
   

# Generated at 2022-06-23 06:32:21.175792
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    pass


# Generated at 2022-06-23 06:32:33.186117
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # pylint: disable=unused-variable
    import copy
    import os

    from ansible.errors import AnsibleError
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

# Generated at 2022-06-23 06:32:45.428347
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class Task:
        def __init__(self):
            pass
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    iter = Task()
    iter._play = 'playbook'
    dict_result = dict()
    dict_result['include_args'] = dict()
    dict_result['ansible_loop_var'] = 'item'
    dict_result['ansible_index_var'] = 'test'
    dict_result['ansible_loop'] = 'loop'
    dict_result['include'] = 'include_file'
    dict_result['_ansible_item_label'] = 'item_label'
    dict_result['_ansible_no_log'] = True
    host = 'localhost'
    task = Task()

# Generated at 2022-06-23 06:32:49.466963
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert repr(IncludedFile("filename", "args", "vars", "task")) == "filename (args=args vars=vars): []"
    assert repr(IncludedFile("filename", [], [], "task")) == "filename (args=[] vars=[]): []"


# Generated at 2022-06-23 06:33:01.338305
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from collections import namedtuple

    ProcessedResult = namedtuple('ProcessedResult', ['host', '_task', '_result'])
    Result = namedtuple('Result', ['include_args', 'include', 'ansible_loop_var', 'ansible_index_var', '_ansible_item_label'])
    Task = namedtuple('Task', ['action'])
    Play = namedtuple('Play', [])

    play = Play()

    task = Task('include_role')
    task._parent = None
    task._role_path = None

    play_result = []

    f2 = IncludedFile('my role', {'name': 'role1'}, {}, task, is_role=True)

    f2.add_host('myhost')

# Generated at 2022-06-23 06:33:12.794641
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    pc = PlayContext()
    pc._play = Play()

    task1 = Task()
    task1._task_fields['action'] = 'include_tasks'
    task1._parent = pc._play

    task2 = task1.copy()

    inc1 = IncludedFile('filename', {}, {}, task1)
    inc2 = IncludedFile('filename', {}, {}, task2)
    assert inc1 == inc2

    inc1 = IncludedFile('filename', {}, {'k': 'v'}, task1)
    inc2 = IncludedFile('filename', {}, {'k': 'v'}, task2)
    assert inc1 == inc2


# Generated at 2022-06-23 06:33:28.720457
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.executor.task_result import TaskResult

    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.get_inventory())
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=options)

    context = PlayContext()
    context.network_os = None
    context.remote_addr = None
    context.remote_user = None
    context.password = None
    context.port = None
    context.become = False
    context.become_method = None
    context.become_user = None
    context.become_pass = None
    context.become_exe = None


# Generated at 2022-06-23 06:33:42.109380
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars

    if1 = IncludedFile('/path/to/file1', {'_raw_params': 'file1'}, {}, Task())
    if2 = IncludedFile('/path/to/file1', {'_raw_params': 'file1'}, {}, Task())
    if3 = IncludedFile('/path/to/file2', {'_raw_params': 'file1'}, {}, Task())

# Generated at 2022-06-23 06:33:49.992492
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile('filename', 'args', 'vars', 'task')
    included_file.add_host('host1')
    included_file.add_host('host2')
    included_file.add_host('host3')
    assert set(included_file._hosts) == set(['host1', 'host2', 'host3'])
    try:
        included_file.add_host('host1')
        raise AssertionError('Expected ValueError')
    except ValueError:
        pass



# Generated at 2022-06-23 06:34:00.257394
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []

    class original_task(object):
        def __init__(self, action):
            self.action = action
            self._role = False
            self._role_name = None

        def copy(self):
            return original_task(self.action)

        @staticmethod
        def get_search_path():
            return ['/path/to/ansible/basedir/roles']

    loader = object()
    variable_manager = object()
    iterator = object()
    iterator._play = object()

    class res(object):
        def __init__(self, _host, _task, _result):
            self._host = _host
            self._task = _task
            self._result = _result
