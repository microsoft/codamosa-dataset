

# Generated at 2022-06-23 06:24:03.132728
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # empty results
    results = []
    # assumes the role being tested is always located in ansible/test
    loader = TestLoader()
    # return of get_vars will always be a dict
    variable_manager = TestVariableManager()
    # assume iterator will always return the same dict
    iterator = TestIterator()

    test_IncludedFile = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert len(test_IncludedFile) is 0

    # results with no tasks

# Generated at 2022-06-23 06:24:09.137381
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile("a", {}, {}, None)
    b = IncludedFile("b", {}, {}, None)
    c = IncludedFile("b", {"c":"d"}, {"e":"f"}, None)
    assert a != b
    assert a == a
    assert b != c


# Generated at 2022-06-23 06:24:17.267141
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    inc = IncludedFile("test_filename", "test_args", "test_vars", "test_task", True)
    assert inc._filename == "test_filename"
    assert inc._args == "test_args"
    assert inc._vars == "test_vars"
    assert inc._task == "test_task"
    assert inc._hosts == []
    assert inc._is_role == True
    assert inc.__str__() == "%s (args=%s vars=%s): %s" % ("test_filename", "test_args", "test_vars", [])

# Generated at 2022-06-23 06:24:23.105117
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import ansible.executor.task_queue_manager
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansibles.vars.host_variable

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    variable_manager.set_host_variable(host=ansible.vars.host_variable.HostVars(name='host'), varname='include', value='role.yml')
    variable_manager.set_host_variable(host=ansible.vars.host_variable.HostVars(name='host'), varname='loop', value=['a', 'b'])

# Generated at 2022-06-23 06:24:32.220079
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    host1 = 'host1'
    host2 = 'host2'

    task = 'task'
    filename = 'filename'
    args = 'args'
    vars = 'vars'

    test_obj = IncludedFile(filename, args, vars, task)

    test_obj.add_host(host1)
    assert len(test_obj._hosts) == 1

    test_obj.add_host(host2)
    assert len(test_obj._hosts) == 2

    try:
        test_obj.add_host(host1)
    except ValueError:
        pass
    else:
        # if we get to this point, add_host did not raise the exception
        assert False


# Generated at 2022-06-23 06:24:40.749062
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class TestIncludedFile(IncludedFile):
        def __init__(self):
            super(TestIncludedFile, self).__init__("", None, None, None)
            self._hosts = ["1.0.0.1", "2.0.0.2"]
    inc_file = TestIncludedFile()
    test_string = " (args=None vars=None): ['1.0.0.1', '2.0.0.2']"
    assert repr(inc_file) == test_string

# Generated at 2022-06-23 06:24:44.881535
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """
    ansible.playbook.include.IncludedFile __repr__()
    """
    assert isinstance(IncludedFile('filename', ['args'], 'vars', 'task', True).__repr__(), str)

# Generated at 2022-06-23 06:24:52.434380
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # 1. Test when argument is neither dict nor list
    task = Task()
    task.args = 'test args'
    inc_file = IncludedFile('test_filename.yml', task.args, 'test vars', task)
    assert repr(inc_file) == "'test_filename.yml (args=test args vars=test vars): []"

    # 2. Test when argument is dict
    task.args = {'test arg 1': 'value 1', 'test arg 2': 'value 2'}
    inc_file = IncludedFile('test_filename.yml', task.args, 'test vars', task)

# Generated at 2022-06-23 06:25:03.985470
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'a'
    args = 'b'
    vars = 'c'
    task = 'd'
    is_role = False
    included_file = IncludedFile(filename, args, vars, task, is_role)
    assert str(included_file) == 'a (args=b vars=c): []'

    included_file.add_host('host1')
    included_file.add_host('host2')
    assert str(included_file) == 'a (args=b vars=c): [host1, host2]'



# Generated at 2022-06-23 06:25:12.147967
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-23 06:25:18.176861
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    task = TaskInclude()
    task._parent = ""
    task_include = IncludedFile("file", "args", "vars", task)
    assert task_include.__repr__() == "file (args=args vars=vars): []"

# Generated at 2022-06-23 06:25:28.436865
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins import module_loader
    def _load_recursively(d):
        if isinstance(d, dict):
            # find the tasks and add them to the list
            if 'tasks' in d:
                if not isinstance(d['tasks'], list):
                    raise AnsibleError("error in role format, 'tasks' should be a list")
                for task in d['tasks']:
                    # is the task a list item?
                    if isinstance(task, list) and task:
                        # the list item is a task so use its first member
                        if isinstance(task[0], dict):
                            task = task[0]
                    # add the task to the list
                    _load_recursively(task)
            # find the handlers and add them to the list

# Generated at 2022-06-23 06:25:40.147499
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "/tmp/abc.txt"
    args = {}
    vars = {}
    task = None   # a task object. Not used in __eq__ method and __ne__ method,
                  # so do not need to initialize it.
    # except to initialize the filename, all other parameters are not used in __eq__.
    # not using the all parameters of class IncludedFile
    inc_file = IncludedFile(filename, args, vars, task)

    host = "host1"
    # the first time, add host should add the host to the list _hosts of inc_file.
    inc_file.add_host(host)
    assert (inc_file._hosts[0] == host)

    # the second time, add host should raise ValueError, as the host has already been in the list.
    raised = False

# Generated at 2022-06-23 06:25:52.631132
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play_context import PlayContext

    file_1 = """
    - include: test/play.yaml
    """

    file_2 = """
    - include_role:
        name: test/role
        tasks_from: play.yaml
    """

    file_3 = """
    - include_role:
        name: test/role
        handlers_from: play.yaml
    """

    file_4 = """
    - include_role:
        name: test/role
        vars_from: play.yaml
    """


# Generated at 2022-06-23 06:25:59.453263
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inv)

    tqm = TaskQueueManager(
        inventory=inv,
        variable_manager=variable_manager,
        loader=loader,
        passwords={},
        stdout_callback='default',
    )

    t1 = TaskInclude()
    t1._parent = None
    t1.action = 'include_tasks'
    t1.args = dict(a=1, b=2)
    t1._

# Generated at 2022-06-23 06:26:12.366395
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # Instantiate class object
    inc_file = IncludedFile("role1", {"a": "b"}, {"c": "d"},{"name": "apt", "action": "apt" })

    # Test method
    inc_file.add_host("host1")
    inc_file._hosts[0].should.be.equal("host1")

    # Test exception, host already exists
    try:
        inc_file.add_host("host1")
        raise
    except ValueError:
        pass
    # Test exception, host already exists
    try:
        inc_file._hosts.append("host1")
        inc_file.add_host("host1")
        raise
    except ValueError:
        pass



# Generated at 2022-06-23 06:26:22.940145
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    '''
    Test case to verify that the method add_host of class IncludedFile
    properly appends a host to a list of hosts and throws an exception if
    the host already exists in the list of hosts.
    '''

    filename = 'test_filename'
    args = 'test_args'
    vars = 'test_vars'
    task = 'test_task'
    is_role = 'test_is_role'
    included_file = IncludedFile(filename, args, vars, task, is_role)

    test_host_1 = 'test_host_1'
    included_file.add_host(test_host_1)
    assert test_host_1 in included_file._hosts

    test_host_2 = 'test_host_2'

# Generated at 2022-06-23 06:26:34.682872
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    if2_1 = IncludedFile("if2", "args2", "vars2", "task2")
    if2_2 = IncludedFile("if2", "args2", "vars2", "task2")
    if2_3 = IncludedFile("if2", "args2", "vars2", "task2")
    if3_3 = IncludedFile("if3", "args3", "vars3", "task3")
    if3_4 = IncludedFile("if3", "args3", "vars3", "task3")
    if2_2_bis = IncludedFile("if2", "args2", "vars2", "task2_bis")
    if2_2_bis.__dict__["_hosts"].append("host1")
    if2_2.__dict__["_hosts"].append

# Generated at 2022-06-23 06:26:41.169220
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    expected = "/tmp/test.yml (args=[] vars={}): [u'127.0.0.1', u'127.0.0.2']" # pylint: disable=line-too-long

    obj = IncludedFile("/tmp/test.yml", [], {}, None)
    obj.add_host("127.0.0.1")
    obj.add_host("127.0.0.2")

    assert str(obj) == expected


# Generated at 2022-06-23 06:26:47.201771
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    import ansible.playbook.task_include
    import ansible.template
    import ansible.vars
    included_file = IncludedFile(
        filename='filename',
        args='args',
        vars='vars',
        task=ansible.playbook.task_include.TaskInclude(
            'task_include',
            ansible.template.Templar(loader=None, variables=ansible.vars.VariableManager()),
            PlayContext()
        )
    )
    assert repr(included_file) == "filename (args=args vars=vars): []"


# Generated at 2022-06-23 06:26:57.661205
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file1 = IncludedFile('file1', 'args1', 'vars1', 'task1')
    included_file2 = IncludedFile('file1', 'args1', 'vars1', 'task1')
    
    assert included_file1 == included_file2
    
    included_file1 = IncludedFile('file2', 'args1', 'vars1', 'task1')
    
    assert included_file1 != included_file2
    
    included_file1 = IncludedFile('file1', 'args2', 'vars1', 'task1')
    
    assert included_file1 != included_file2
    
    included_file1 = IncludedFile('file1', 'args1', 'vars2', 'task1')
    
    assert included_file1 != included_file2
    
    included_file1

# Generated at 2022-06-23 06:27:11.317241
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class Task():
        def __init__(self):
            self._uuid = '123'
            class _parent():
                def __init__(self):
                    self._uuid = '456'
            self._parent = _parent()
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = Task()
    inc1 = IncludedFile(filename, args, vars, task)
    inc2 = IncludedFile(filename, args, vars, task)
    assert(inc1.__eq__(inc2))
    assert(inc2.__eq__(inc1))
    inc3 = IncludedFile('wrong', args, vars, task)
    assert(not inc1.__eq__(inc3))
    assert(not inc3.__eq__(inc1))

# Generated at 2022-06-23 06:27:25.470968
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    """IncludedFile unit tests"""
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_iterator import PlaybookIterator
    from ansible.playbook.playbook import Playbook
    # import only required modules to correct initialize variables
    #.                                                              #
    #.                                                              #
    #.                        D A N G E R                           #
    #.                                                              #
    #.                                                              #
    # You should use "import ansible" to test all

# Generated at 2022-06-23 06:27:33.000207
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import os
    import sys

    if not os.path.exists('/tmp/test_IncludedFile.py'):
        with open('/tmp/test_IncludedFile.py', 'w') as fd:
            print('print("test_IncludedFile")', file=fd)
            print('print(len(sys.argv))', file=fd)
            for a in sys.argv:
                print('print("' + a + '")', file=fd)

    f = IncludedFile('/tmp/test_IncludedFile.py', {'x': 1, 'y': 2, 'z': 3}, {}, 'foobar')
    assert f != None

# Generated at 2022-06-23 06:27:42.869618
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult
    from ansible.template import Templar
    from ansible.plugins.loader import find_all_plugin_loaders
    from ansible.plugins.loader import find_plugin_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.vars import combine_vars

    def create_loader():
        plugin_loaders = find_all_plugin_loaders()
        results = get_

# Generated at 2022-06-23 06:27:53.723887
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    i1 = IncludedFile("filename", dict(), dict(), "task")
    i2 = IncludedFile("filename", dict(), dict(), "task")
    assert(i1 == i2)
    assert(i1 != "something else")

    i3 = IncludedFile("filename", dict(a=1), dict(), "task")
    assert(i1 != i3)

    i4 = IncludedFile("filename", dict(), dict(a=1), "task")
    assert(i1 != i4)

    i5 = IncludedFile("otherfilename", dict(), dict(), "task")
    assert(i1 != i5)

    i6 = IncludedFile("filename", dict(), dict(), "othertask")
    assert(i1 != i6)

    assert("filename (args={} vars={}): []" == str(i1))

# Generated at 2022-06-23 06:28:04.415804
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """
    Test if __repr__ returns a string with filename and arg
    """
    # Given
    loader = object()
    variable_manager = object()
    result = object()
    task_action = "include_vars"
    iterator = object()
    filename = "test.txt"
    args = {"foo":"bar"}
    vars = {"bar":"foo"}
    task = object()
    is_role = False
    included_files = IncludedFile(filename, args, vars, task, is_role)

    # When
    result = included_files.__repr__()

    # Then
    assert result == "test.txt (args={'foo': 'bar'} vars={'bar': 'foo'}): []"

# Generated at 2022-06-23 06:28:17.627299
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    include_file = IncludedFile('file1', {'arg1': 'value1', 'arg2': 'value2'}, {'var1': 'value1', 'var2': 'value2'}, 'task1')

    assert not include_file.__eq__(IncludedFile('file1', {'arg1': 'value1', 'arg2': 'value2'}, {'var1': 'value1', 'var2': 'value2'}, 'task1'))
    assert include_file.__eq__(IncludedFile('file1', {'arg1': 'value1', 'arg2': 'value2'}, {'var1': 'value1', 'var2': 'value2'}, 'task2'))

# Generated at 2022-06-23 06:28:28.935862
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    results = [Result(host=Host(name='127.0.0.1'), task=task, result=result)
               for task in ['task1', 'task1', 'task2', 'task2']
               for result in ['result1', 'result2']]
    included_files = IncludedFile.process_include_results(results, [], [], [])

    assert len(included_files) == 2
    assert included_files[0]._filename == 'result1'
    assert included_files[0]._hosts == ['127.0.0.1']
    assert included_files[1]._filename == 'result2'
    assert included_files[1]._hosts == ['127.0.0.1']



# Generated at 2022-06-23 06:28:32.472980
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    inc_file = IncludedFile('foo.yml', {'bar':'baz'}, {'asdf':1}, None)
    if not inc_file:
        raise AssertionError("IncludedFile instantiation test failed")

# Generated at 2022-06-23 06:28:38.656314
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    ifile = IncludedFile()

    ifile.add_host('a')
    ifile.add_host('b')
    ifile.add_host('c')

    assert ifile._hosts == ['a', 'b', 'c']

    try:
        ifile.add_host('b')
    except ValueError:
        return
    assert False  # this should not happen

# Generated at 2022-06-23 06:28:48.098399
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class MockIncludedFile:
        def __init__(self, filename, args, vars, task):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []

    MockIncludedFile('f1', {'a':1, 'b':2}, {'c':3, 'd':4}, 't')._filename
    MockIncludedFile('f2', {'a':1, 'b':2}, {'c':3, 'd':4}, 't')._args
    MockIncludedFile('f3', {'a':1, 'b':2}, {'c':3, 'd':4}, 't')._vars

# Generated at 2022-06-23 06:28:57.446881
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    d = dict()
    d['filename'] = '/somewhere/over/the/rainbow'
    d['args'] = dict()
    d['vars'] = dict()
    d['task'] = 'Task'
    d['hosts'] = ['host1', 'host2']

    # Test constructor
    test1 = IncludedFile(d['filename'], d['args'], d['vars'], d['task'])
    for attr in ['_filename', '_args', '_vars', '_task', '_hosts']:
        if getattr(test1, attr) != d[attr.strip('_')]:
            raise Exception('Attribute %s does not match' % attr)

    # Test add_host
    test1.add_host('host3')

# Generated at 2022-06-23 06:29:01.033748
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc_file = IncludedFile('a', 'b', 'c', 'd', 'e')
    assert inc_file.__repr__() == "a (args=b vars=c): d"

# Generated at 2022-06-23 06:29:06.249995
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "filename"
    args = "args"
    vars = "vars"
    task = "task"
    included_file = IncludedFile(filename, args, vars, task)
    assert repr(included_file) == "%s (args=%s vars=%s): %s" % (filename, args, vars, [])


# Generated at 2022-06-23 06:29:08.865812
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Assign
    inc_file = IncludedFile(filename='filename', args='args', vars='vars', task='task')
    # Action
    actual = inc_file.__repr__()
    # Assert
    assert actual == "filename (args=args vars=vars): []"


# Generated at 2022-06-23 06:29:14.885751
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task

    inc_file_1 = IncludedFile('test', {'test':'test'}, {'test':'test'}, Task())
    inc_file_2 = IncludedFile('test', {'test':'test'}, {'test':'test'}, Task())

    assert inc_file_1 == inc_file_2


# Generated at 2022-06-23 06:29:27.441578
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    display.verbosity = 4

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')


# Generated at 2022-06-23 06:29:37.242735
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class FakeIterator:
        pass

    class FakeLoader:
        def __init__(self):
            self.basedir = '/fake/path/to/a/playbook'

        def get_basedir(self):
            return self.basedir

    class FakeVarsManager:
        def __init__(self):
            self.play = FakeIterator()

        def get_vars(self, play=None, host=None, task=None):
            assert play == self.play
            assert host == original_host
            assert task == original_task

            return vars


# Generated at 2022-06-23 06:29:47.274182
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class TestTask:
        def __init__(self, uuid):
            self._uuid = uuid

        def __eq__(self, other):
            return self._uuid == other._uuid

    class TestHost:
        def __init__(self, uuid):
            self._uuid = uuid

        def __eq__(self, other):
            return self._uuid == other._uuid

        def __hash__(self):
            return hash(self._uuid)

    task_a_uuid = 1234
    task_b_uuid = 4321
    task_a = TestTask(task_a_uuid)
    task_b = TestTask(task_b_uuid)
    host_a_uuid = 4422
    host_b_uuid = 2244
    host_a

# Generated at 2022-06-23 06:29:52.024599
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    '''
    This function unit test the method __repr__ of class IncludedFile.
    :return: None
    '''
    include_file = IncludedFile('filename.yml', 'file_arg', 'file_vars', 'task_instance')
    assert include_file.__repr__() == "filename.yml (args=file_arg vars=file_vars): []"

# Generated at 2022-06-23 06:29:56.575860
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    ifile = IncludedFile("/etc/ansible/blah", {}, {}, None)
    ifile.add_host("localhost")
    ifile.add_host("localhost")
    # Exception should be raised
    assert False


if __name__ == '__main__':
    test_IncludedFile_add_host()

# Generated at 2022-06-23 06:29:57.222079
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    pass

# Generated at 2022-06-23 06:30:02.082351
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    ifile = IncludedFile("/path/to/include/role", dict(), dict(), None)
    ifile.add_host("hostA")
    ifile.add_host("hostB")

    ifile2 = IncludedFile("/path/to/include/role", dict(), dict(), None)
    ifile2.add_host("hostA")
    ifile2.add_host("hostB")

    assert ifile == ifile2

# Generated at 2022-06-23 06:30:06.792492
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    test_obj = IncludedFile('somefile.yml', {}, {}, None)
    test_obj.add_host('host1')
    assert test_obj._hosts == ['host1']
    assert test_obj._hosts.count('host1') == 1


# Generated at 2022-06-23 06:30:17.781362
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []
    iterator = None
    loader = None
    variable_manager = None

    # include_tasks: /etc/ansible/roles/templates/tasks/main.yml
    # include_tasks: /etc/ansible/task/include_task1.yml

# Generated at 2022-06-23 06:30:25.894344
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    args = {"a":"b"}
    vars = {"c":"d"}
    task = {"e":"f"}
    inc_file1 = IncludedFile("/test/file", args, vars, task, is_role=False)
    inc_file2 = IncludedFile("/test/file", args, vars, task, is_role=False)
    inc_file3 = IncludedFile("/test/file", args, vars, task, is_role=True)
    inc_file4 = IncludedFile("/test/file4", args, vars, task, is_role=False)
    inc_file5 = IncludedFile("/test/file", {"a":"c"}, vars, task, is_role=False)

# Generated at 2022-06-23 06:30:28.866310
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert isinstance(IncludedFile('a.yml', {'a': 1}, {'b': 2}, {'c': 3}).__repr__(), str)



# Generated at 2022-06-23 06:30:34.325028
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Data 1:
    results = [('host1', 'task1', 'task-result1'), ('host1', 'task2', 'task-result2')]
    included_files = IncludedFile.process_include_results(results, None, None, None)
    assert 'host1' in included_files[0]._hosts
    assert 'host1' in included_files[1]._hosts
    assert 'task1' in included_files[0]._task
    assert 'task2' in included_files[1]._task


# Generated at 2022-06-23 06:30:44.537404
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'test'
    args = {'a':1}
    vars = dict()
    task = dict()
    included_file = IncludedFile(filename, args, vars, task)

    # getter
    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task
    assert included_file._hosts == []

    # setter
    included_file._filename = 'test222'
    included_file._args = {'b':2}
    included_file._vars = dict()
    included_file._task = dict()

    assert included_file._filename == 'test222'
    assert included_file._args == {'b':2}
    assert included_file._vars == dict()
   

# Generated at 2022-06-23 06:30:57.369077
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from collections import namedtuple

    FakeTask = namedtuple('task', ['_role_name', 'action', 'loop'])

    task = FakeTask(None, 'import_tasks', None)
    included_file = IncludedFile('filename', 'args', 'vars', task)
    assert included_file._filename == 'filename'
    assert included_file._args == 'args'
    assert included_file._vars == 'vars'
    assert included_file._task == task
    assert included_file._hosts == []
    assert included_file._is_role == False

    task = FakeTask('role_name', 'import_role', None)
   

# Generated at 2022-06-23 06:30:58.051562
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    pass

# Generated at 2022-06-23 06:31:02.373430
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    include_file = IncludedFile("test.yml", "", "", "")
    assert include_file._filename == "test.yml"
    assert include_file._args == ""
    assert include_file._vars == ""
    assert include_file._task == ""
    assert include_file._hosts == []
    assert include_file._is_role == False

# Generated at 2022-06-23 06:31:15.292080
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    ifile1 = IncludedFile("file1", {}, {}, None)
    ifile2 = IncludedFile("file2", {}, {}, None)
    ifile1a = IncludedFile("file1", {}, {}, None)
    host1 = "host1"
    host2 = "host2"

    ifile1.add_host(host1)
    assert([host1] == ifile1._hosts)
    ifile1.add_host(host2)
    assert([host1,host2] == ifile1._hosts)

    try:
        ifile1.add_host(host1)
    except ValueError:
        pass
    else:
        assert False, "add same host twice"

    assert([host1] == ifile1a._hosts)

# Generated at 2022-06-23 06:31:25.149551
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class TestHost:
        name = 'test_host'

        def __repr__(self):
            return 'test_host'

    display.verbosity = 3

    class TestIncludedFile(IncludedFile):
        def __init__(self, filename, args, vars, task, is_role=False):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []
            self._is_role = is_role

    class TestTask:
        def __init__(self, action, args, no_log=False, loop=False, parent=None, role=None, name='import_role'):
            self.action = action
            self._args = args
            self.no_log = no_log
            self._parent

# Generated at 2022-06-23 06:31:31.406537
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile('filename', {}, {}, 'task', True)
    assert repr(included_file) == 'filename (args={} vars={}): []'

    included_file = IncludedFile('filename', {"1": "2"}, {"3":"4"}, 'task', True)
    assert repr(included_file) == "filename (args={'1': '2'} vars={'3': '4'}): []"


# Generated at 2022-06-23 06:31:37.058819
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'a.txt'
    args = {'a': 'A'}
    vars = {'var':'Var'}
    task = {'action': 'A'}
    incFile = IncludedFile(filename, args, vars, task)
    assert repr(incFile) == 'a.txt (args={\'a\': \'A\'} vars={\'var\': \'Var\'}): []'

# Generated at 2022-06-23 06:31:47.741890
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = "test_filename"
    args = {"key1": "value1", "key2": "value2"}
    vars = {"var1": "value1", "var2": "value2"}
    task = None
    is_role = False
    inc1 = IncludedFile(filename, args, vars, task, is_role)
    inc2 = IncludedFile(filename, args, vars, task, is_role)
    inc3 = IncludedFile("diff filename", args, vars, task, is_role)
    inc4 = IncludedFile(filename, {"key2": "value2"}, vars, task, is_role)
    inc5 = IncludedFile(filename, args, {"var2": "value2"}, task, is_role)

# Generated at 2022-06-23 06:31:58.580708
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.parsing.dataloader
    import ansible.inventory.manager
    import ansible.vars.manager

    loader = ansible.parsing.dataloader.DataLoader()

    inventory = ansible.inventory.manager.InventoryManager(loader, 'localhost,')
    variable_manager = ansible.vars.manager.VariableManager(loader, inventory)


# Generated at 2022-06-23 06:32:01.878791
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    task = TaskInclude()
    includedFile = IncludedFile("filename", "args", "vars", task)
    assert isinstance(includedFile,IncludedFile)

# Generated at 2022-06-23 06:32:10.801909
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.play import Play

    mock_play = Play().load(dict(
        name="unit test play",
        hosts="all",
        gather_facts="no",
        tasks=[
            dict(action="debug", msg="foo"),
            dict(action="debug", msg="bar")
        ]
    ), variable_manager=None, loader=None)

    # task is a list of dict of 2 tasks in play
    task = mock_play.get_tasks()

    # create two distinct included file with same name and task content
    includefile1 = IncludedFile("foo", dict(), dict(), task[0], is_role=False)
    includefile2 = IncludedFile("foo", dict(), dict(), task[0], is_role=False)

    # create two distinct included file with different name and diffrent task
   

# Generated at 2022-06-23 06:32:18.208973
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile(filename='my_file.yml',
                                 args={'name': 'ansible'},
                                 vars={'my_var': 'my_value'},
                                 task=None)
    assert repr(included_file) == "my_file.yml (args={'name': 'ansible'} vars={'my_var': 'my_value'}): []"

# Generated at 2022-06-23 06:32:25.674632
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    file1 = IncludedFile('/tmp/foo', dict(), dict(), dict())
    file11 = IncludedFile('/tmp/foo', dict(), dict(), dict())
    file2 = IncludedFile('/tmp/bar', dict(), dict(), dict())
    file3 = IncludedFile('/tmp/baz', dict(), dict(), dict(), is_role=True)
    file4 = IncludedFile('/tmp/qux', dict(), dict(), dict(), is_role=True)

    assert(file1 == file11)

    assert(not file1 == file2)
    assert(not file2 == file3)
    assert(not file3 == file4)


# Generated at 2022-06-23 06:32:28.937691
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    IncludedFile("a", "b", "c", "d")

# Generated at 2022-06-23 06:32:37.186335
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class Mock_TaskInclude:
        def __init__(self, uuid, parent):
            self.uuid = uuid
            self.parent = parent
    class Mock_Handler:
        def __init__(self, uuid, parent):
            self.uuid = uuid
            self.parent = parent
    class Mock_Task:
        def __init__(self, uuid, parent):
            self.uuid = uuid
            self.parent = parent
    class Mock_IncludeRole:
        def __init__(self, uuid, parent):
            self.uuid = uuid
            self.parent = parent
    # task
    test1 = IncludedFile('filename', {}, {}, Mock_Task(None, Mock_TaskInclude(1, None)))

# Generated at 2022-06-23 06:32:48.437020
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class TestIncludedFile:
        def __init__(self, filename, args, vars, task, is_role=False):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []
            self._is_role = is_role

        def add_host(self, host):
            if host not in self._hosts:
                self._hosts.append(host)
                return
            raise ValueError()


# Generated at 2022-06-23 06:32:56.594107
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    i1 = IncludedFile("testpath", {}, {}, None)

    assert i1._hosts == []

    i1.add_host("foo")

    assert i1._hosts == ["foo"]

    try:
        i1.add_host("foo")
    except ValueError:
        pass
    else:
        raise Exception("Expected value error for adding host twice")

    assert i1._hosts == ["foo"]

    i2 = IncludedFile("testpath", {}, {}, None)
    i2.add_host("foo")

    assert i1 == i2


# Generated at 2022-06-23 06:33:08.924574
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():

    # Create a mock ansible.palybook.block.Block for use in creating a mock ansible.playbook.task.Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    class MockAnsibleTask:
        def __init__(self, name, args, parent, handler, no_log, search_path=None, loop=None, loop_args=None, any_errors_fatal=None):
            self._uuid = name     # Fake a UUID for testing
            self._parent = parent
            self._handler = handler
            self._no_log = no_log
            self._search_path = search_path
            self._loop = loop
            self._loop_args = loop_args

# Generated at 2022-06-23 06:33:14.645812
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = 'task'
    is_role = 'is_role'
    _hosts = '_hosts'

    included_file = IncludedFile(filename, args, vars, task, is_role)
    included_file._hosts = _hosts


# Generated at 2022-06-23 06:33:30.475771
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    host1 = 'host01'
    host2 = 'host02'
    filename = 'test.yaml'
    args = {'a1': 'arg1'}
    vars = {'v1': 'var1'}
    task = 'include_task'  # mock object
    task._uuid = 'task1'
    task._parent = object()
    task._parent._uuid = 'task2'

    include_file = IncludedFile(filename, args, vars, task)
    include_file.add_host(host1)
    include_file.add_host(host2)

    repr_str = repr(include_file)
    assert repr_str == "%s (args=%s vars=%s): %s" % (filename, args, vars, [host1, host2])

# Generated at 2022-06-23 06:33:37.482437
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile('/etc/hosts', {}, {}, None)
    host1 = dict()
    included_file.add_host(host1)
    included_file.add_host(host1)

    assert len(included_file._hosts) == 1
    assert included_file._hosts[0] == host1

# Generated at 2022-06-23 06:33:49.376353
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook import Play, Task, PlayBook, PlaybookLoader


# Generated at 2022-06-23 06:34:01.483113
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    display.verbosity = 3

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    fake_iter = object()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)