

# Generated at 2022-06-23 06:24:03.105070
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    """
        constructor of class IncludedFile
        parameters:
        filename: absolute path of the included file
        args: args of the include task
        vars: vars of the include task
    """
    # there are 5 parameters in the constructor, filename(required) and args/vars are required.
    # filename should be a string and args/vars should be either a dict or a string

# Generated at 2022-06-23 06:24:08.276773
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import mock
    mock_host = mock.MagicMock()
    inc_file = IncludedFile('include.yml', {}, {}, None)
    inc_file.add_host(mock_host)
    assert mock_host in inc_file._hosts


# Generated at 2022-06-23 06:24:17.683028
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile('test_host', {'test_host': 'test'}, {'test': 'test'}, 'test_task')
    if included_file._filename != 'test_host':
        raise Exception('IncludedFile() failed to set filename')
    if included_file._args['test_host'] != 'test':
        raise Exception('IncludedFile() failed to set args')
    if included_file._vars['test'] != 'test':
        raise Exception('IncludedFile() failed to set vars')
    if included_file._task != 'test_task':
        raise Exception('IncludedFile() failed to set task')


# Generated at 2022-06-23 06:24:31.042904
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakeTaskInclude:
        def __init__(self, filename, args):
            self.args = {'_raw_params': filename}
            self.action = 'include_tasks'
            self.no_log = False
            self.loop = False
            self._parent = None

        def copy(self):
            return self

    class FakeHandlerInclude:
        def __init__(self, filename, args):
            self.args = {'_raw_params': filename}
            self.action = 'include_role'
            self.no_log = False
            self.loop = False
            self._parent = None

        def copy(self):
            return self

    class FakeRole:
        def __init__(self, role_path):
            self._role_path = role_path


# Generated at 2022-06-23 06:24:40.547567
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename'
    args = {'var1': 'value1'}
    vars = {'var2': 'value2'}
    # Create a task object
    task = TaskInclude(action='path', name='my module', args=args, delegate_to='localhost', loop=None,
                       loop_args=None, loop_action='count', loop_with_items=None)

    includedFile = IncludedFile(filename, args, vars, task)
    assert includedFile.__repr__() == 'filename (args={} vars={}): []'



# Generated at 2022-06-23 06:24:46.548032
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile('file1', {}, {}, 'ignore')
    class Host:
        name = 'host'
    assert included_file.add_host(Host()) == None
    assert included_file._hosts == [Host()]
    assert included_file.add_host(Host()) == None
    assert included_file._hosts == [Host()]


# Generated at 2022-06-23 06:24:59.097756
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """Test the method IncludedFile.add_host()"""
    class MockHost:
        pass

    class MockTask:
        def __init__(self, uuid):
            self._uuid = uuid

        def get_search_path(self):
            return ['test_search_path']

    class MockRole:
        def __init__(self):
            self._role_path = 'test_role_path'

    class MockPlay:
        def __init__(self, uuid):
            self._uuid = uuid

        def get_search_path(self):
            return ['test_play_search_path']

    class MockIterator:
        def __init__(self):
            self._play = MockPlay(1)


# Generated at 2022-06-23 06:25:10.344946
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host

    host = Host('test')
    play = Play()
    block = Block()
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()
    task6 = Task()
    task7 = Task()
    task8 = Task()
    task9 = Task()
    task10 = Task()
    task11 = Task()
    task12 = Task()
    task13 = Task()
    task14 = Task()

    play.set_loader(None)
    play.set_variable_manager(None)
   

# Generated at 2022-06-23 06:25:22.319236
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Arrange
    task_include = TaskInclude()
    include_var = IncludedFile("test", "args", "vars", task_include)

    task_include_eq = TaskInclude()
    include_var_eq = IncludedFile("test", "args", "vars", task_include_eq)

    task_include_ne = TaskInclude()
    include_var_ne_1 = IncludedFile("test2", "args", "vars", task_include_ne)
    include_var_ne_2 = IncludedFile("test", "args2", "vars", task_include_ne)
    include_var_ne_3 = IncludedFile("test", "args", "vars2", task_include_ne)
    include_var_ne_4 = IncludedFile("test", "args", "vars", task_include)

# Generated at 2022-06-23 06:25:23.769420
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: Implement test_IncludedFile_process_include_results
    pass

# Generated at 2022-06-23 06:25:29.081785
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    play = Play()
    task = play.add_task(Task())
    filename = "filename"
    args = dict()
    vars = dict()
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file.__repr__() == "filename (args={} vars={}): []"

# Generated at 2022-06-23 06:25:41.326682
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task1 = type('Task', (), {'_uuid': 1, '_parent': type('Parent_Task', (), {'_uuid': 1})})
    task2 = type('Task', (), {'_uuid': 2, '_parent': type('Parent_Task', (), {'_uuid': 2})})
    # IncludedFiles are equal if file name, args, vars and tasks are equal
    inc_file1 = IncludedFile('file1', {'args1': 'val1'}, {'vars1': 'val2'}, task1)
    inc_file2 = IncludedFile('file1', {'args1': 'val1'}, {'vars1': 'val2'}, task1)

# Generated at 2022-06-23 06:25:53.808401
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class MockObj:
        def __init__(self, uuid):
            self._uuid = uuid

    mock_filename1 = 'test_filename'
    mock_filename2 = 'test_filename2'
    mock_args1 = {'mock_args1': 'mock_args_value1'}
    mock_args2 = {'mock_args2': 'mock_args_value2'}
    mock_vars1 = {'mock_vars1': 'mock_vars_value1'}
    mock_vars2 = {'mock_vars2': 'mock_vars_value2'}
    mock_task1 = MockObj('mock_task1_uuid')
    mock_task2 = MockObj('mock_task2_uuid')
    mock_

# Generated at 2022-06-23 06:26:01.058582
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    inc_file_1 = IncludedFile("/path/to/file", {}, {}, {})
    inc_file_2 = IncludedFile("/path/to/file", {}, {}, {})
    assert inc_file_1.__eq__(inc_file_2)
    assert inc_file_2.__eq__(inc_file_1)
    assert not inc_file_1.__eq__(None)
    inc_file_3 = IncludedFile("/path/to/file3", {}, {}, {})
    assert not inc_file_1.__eq__(inc_file_3)
    assert not inc_file_2.__eq__(inc_file_3)


# Generated at 2022-06-23 06:26:14.066657
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = 'include.yml'
    name = 'check'
    args = dict()
    # vars = dict()
    vars = dict({'var1': 'val1', 'var2': 'val2'})
    task = object
    is_role = False
    hostname = 'localhost'

    inc_file1 = IncludedFile(filename, args, vars, task, is_role)
    inc_file1.add_host(hostname)

    inc_file2 = IncludedFile(filename, args, vars, task, is_role)
    inc_file2.add_host(hostname)

    assert  inc_file1 == inc_file2
    assert not (inc_file1 != inc_file2)

    #inc_file1._hosts = ['hostname']
    #inc_file2._

# Generated at 2022-06-23 06:26:25.059104
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    test_filename = "tasks"
    test_hosts = ['testhost']
    test_args = {"test": "arg"}
    test_vars = {"test": "var"}
    test_play_context = PlayContext()
    test_task = Task()
    test_task._play_context = test_play_context
    test_task._role = None

    included_file = IncludedFile(test_filename, test_args, test_vars, test_task)
    assert included_file._filename == test_filename
    assert included_file._args == test_args
    assert included_file._vars == test_vars
    assert included_file._task == test_task
    assert included_file._host

# Generated at 2022-06-23 06:26:26.603215
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # TODO: fix or move this test
    raise Exception("Not implemented")

# Generated at 2022-06-23 06:26:37.812732
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task import Task

    class FakeTask(Task):
        def __init__(self, name):
            super(FakeTask,self).__init__(name)
            self._add_parent()

    _filename = "/tmp/foo.txt"
    _args = ["role", "name"]
    _vars = "vars"
    _task = FakeTask("task_name")
    _hosts = ["host1", "host2"]
    _expected_repr = "/tmp/foo.txt (args=['role', 'name'] vars=vars): ['host1', 'host2']"
    _included_file = IncludedFile(_filename,_args,_vars,_task)
    _included_file._hosts = _hosts
    assert str(_included_file) == _

# Generated at 2022-06-23 06:26:42.137629
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    f = IncludedFile("testfile", {}, {}, None)
    assert f.add_host("host1") is None
    assert f.add_host("host1") is None

if __name__ == '__main__':
    import pytest
    pytest.main([__file__, "-v", "-s"])

# Generated at 2022-06-23 06:26:51.158905
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    import sys
    import unittest

    class A:
        def __init__(self, init_val):
            self._uuid = init_val

    class B:
        def __init__(self, init_val):
            self._parent = init_val

    a = A(1)
    b = A(2)
    c = B(a)

    f = IncludedFile("filename", a, b, c)

    assert repr(f) == "filename (args=1 vars=2): []"



# Generated at 2022-06-23 06:27:03.375295
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    sys.path.append('lib/')
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task_vars = variable_manager.get_vars(play=dict(vars=dict(), connection="local"))


# Generated at 2022-06-23 06:27:15.090161
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "filename"
    args = {"a": "b"}
    vars = {"c": "d"}
    task = "task"
    is_role = True

    obj = IncludedFile(filename, args, vars, task, is_role)
    assert(obj._filename == filename)
    assert(obj._args == args)
    assert(obj._vars == vars)
    assert(obj._task == task)
    assert(obj._is_role == is_role)
    assert(obj._hosts == [])

    host = "host"
    obj.add_host(host)
    assert(obj._hosts[0] == host)

    # Adding a host for the second time should raise an exception
    try:
        obj.add_host(host)
    except ValueError:
        pass

# Generated at 2022-06-23 06:27:17.073913
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert IncludedFile(filename='a', args={}, vars={}, task={})



# Generated at 2022-06-23 06:27:24.923676
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename="db/sql/show_database.sql"
    args="{'host': 'dbserver', 'name': 'database'}"
    vars="{'host': 'dbserver', 'name': 'database'}"
    task="task_uuid"
    test_includedfile = IncludedFile(filename, args, vars, task, False)
    assert test_includedfile.__repr__() == "db/sql/show_database.sql (args={'host': 'dbserver', 'name': 'database'} vars={'host': 'dbserver', 'name': 'database'}): []"

# Unit tests for method add_host

# Generated at 2022-06-23 06:27:30.734870
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    host1 = 'localhost'
    host2 = '127.0.0.1'
    file1 = IncludedFile('file1', {}, {}, None)
    file1.add_host(host1)
    file1.add_host(host2)
    file2 = IncludedFile('file1', {}, {}, None)
    file2.add_host(host2)
    file2.add_host(host1)
    assert file1 == file2


# Generated at 2022-06-23 06:27:42.085462
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    test_play = Play().load({
        'name': 'test play',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {'debug': {'msg': 'Hello World'}},
            {'include_tasks': 'test.yml'},
            {'include_role': {'name': 'test_role'}}
        ]
    }, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:27:50.498645
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename'
    args = {'var1': 'a', 'var2':'b'}
    vars = {'var3':'c', 'var4':'d'}
    task = 'task'
    test_instance = IncludedFile(filename, args, vars, task)
    expected_result = 'filename (args={var1:a, var2:b} vars={var3:c, var4:d}): []'
    actual_result = repr(test_instance)
    assert actual_result == expected_result

# Generated at 2022-06-23 06:27:57.219587
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    sample_file = 'sample_file'
    sample_args = 'sample_args'
    sample_vars = 'sample_vars'
    sample_task = 'sample_task'
    sample_is_role = 'sample_is_role'

    assert(IncludedFile(sample_file, sample_args, sample_vars, sample_task, sample_is_role))

# Generated at 2022-06-23 06:28:06.523363
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # create objects for IncludedFile.__eq__() test
    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeTask:
        def __init__(self, name):
            self._uuid = name
            self._parent = None
            self.action = 'FAKE_TASK'

    class FakeRole:
        def __init__(self, name):
            self.name = name
            self.include_tasks = None
            self._role_path = None

    class FakeIncludeRole(FakeTask):
        def __init__(self, name):
            super(FakeIncludeRole, self).__init__(name)
            self.args = {'name': 'fake_role'}
            self._role = FakeRole('fake_role')
            self.action

# Generated at 2022-06-23 06:28:09.362469
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_files = []
    included_files.append(IncludedFile('/path1', {}, {}, None))
    included_files.append(IncludedFile('/path2', {}, {}, None))
    try:
        included_files[0].add_host('host-0')
        included_files[1].add_host('host-1')
        included_files[0].add_host('host-1')
    except ValueError:
        return True
    return False

# Generated at 2022-06-23 06:28:20.296448
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    import ansible.playbook.play_context
    import ansible.playbook.role
    import ansible.playbook.role_include
    import ansible.playbook.task_include
    import ansible.plugins.loader
    import ansible.template
    import ansible.vars.manager
    import collections

    p = collections.namedtuple('p', ['basedir'])
    p.basedir = '/'
    loader = ansible.plugins.loader.PluginLoader('./', '', p)
    variable_manager = ansible.vars.manager.VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()
    variable_manager._fact_cache = dict()
    variable_manager.host_vars = dict()
    variable_manager

# Generated at 2022-06-23 06:28:24.348289
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    test_object = IncludedFile(
        filename='filename',
        args='args',
        vars='vars',
        task='task'
    )
    assert test_object.__repr__() == "filename (args=args vars=vars): []"


# Generated at 2022-06-23 06:28:29.431443
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    ifn = IncludedFile("path", {}, {}, None)
    assert ifn._filename == "path"
    assert ifn._args == {}
    assert ifn._vars == {}
    assert ifn._task == None
    assert ifn._hosts == []
    assert not ifn._is_role


# Generated at 2022-06-23 06:28:41.696266
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import mock
    import collections
    import ansible.playbook.task_include

    mock_task = mock.create_autospec(ansible.playbook.task_include.TaskInclude, instance=True)
    mock_task._parent = mock_task
    mock_task._uuid = '123'

    mock_vars = collections.MutableMapping()

    if1 = IncludedFile('file1', 'args', 'vars', mock_task)
    if2 = IncludedFile('file1', 'args', 'vars', mock_task)
    if3 = IncludedFile('file2', 'args', 'vars', mock_task)
    if4 = IncludedFile('file2', 'args', 'vars', mock_task)
    if5 = IncludedFile('file2', 'args2', 'vars', mock_task)

# Generated at 2022-06-23 06:28:53.328463
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import unittest

    class test_case(unittest.TestCase):
        def setUp(self):
            self.filename = 'test_file.yml'
            self.args = {'_raw_params': 'test_file.yml'}
            self.vars = {'omit': 'test'}
            self.taskdata = {'action': 'include', '_uuid': '1', '_parent': {'_uuid': '2'}, 'args': self.args}
            self.task = TaskInclude.load(self.taskdata)
            self.task._role_name = None

        def test_add_host(self):
            incfile = IncludedFile(self.filename, self.args, self.vars, self.task)
            incfile.add_host('host1')


# Generated at 2022-06-23 06:28:58.729695
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    file = IncludedFile("test", "ass", "pass", "task")
    assert file._filename == "test"
    assert file._args == "ass"
    assert file._vars == "pass"
    assert file._task == "task"
    assert file._hosts == []


# Generated at 2022-06-23 06:29:09.062959
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Test process_include_results method of IncludeFile class

    """
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    import ansible.constants as C


    action_plugin = action_loader.get('include_tasks', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 06:29:12.259010
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():

    # Construct empty objects to test
    test_object = IncludedFile (None, None, None, None)

    # Validate that test object has the expected result when calling test object with parameter 
    assert test_object.__repr__() == None

# Generated at 2022-06-23 06:29:19.873086
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    y = IncludedFile("abc.yml", {"a": 1, "b": 2}, {"c": 3, "d": 4}, 5)
    z = IncludedFile("abc.yml", {"a": 1, "b": 2}, {"c": 3, "d": 4}, 5)
    assert(y == z)
    assert(y is not z)

    y.add_host(5)
    assert(y._hosts == [5])
    try:
        y.add_host(5)
        assert(False)
    except ValueError:
        pass

# Generated at 2022-06-23 06:29:32.359720
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Create some test objects
    host_names=["host_1", "host_2", "host_3", "host_4", "host_5", "host_6"]
    host_objects = []
    for name in host_names:
        host_objects.append(IncludedFile(name, None, None, None))

    # Check add_host method
    included_file = IncludedFile("filename", "args", "vars", "task")
    # Add the first host
    included_file.add_host(host_objects[0])
    # Check the list of included hosts
    assert included_file._hosts == [host_objects[0]], "Wrong list of hosts"
    # Add the second host
    included_file.add_host(host_objects[1])
    # Check the list of included hosts

# Generated at 2022-06-23 06:29:39.571114
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = TaskInclude()

    assert IncludedFile('/path/to/file', {}, {}, task) == IncludedFile('/path/to/file', {}, {}, task)
    assert IncludedFile('/path/to/file', {'a': 'b'}, {}, task) == IncludedFile('/path/to/file', {'a': 'b'}, {}, task)
    assert IncludedFile('/path/to/file', {}, {'c': 'd'}, task) == IncludedFile('/path/to/file', {}, {'c': 'd'}, task)

    assert IncludedFile('/path/to/file1', {}, {}, task) != IncludedFile('/path/to/file2', {}, {}, task)

# Generated at 2022-06-23 06:29:48.106009
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook
    class Mock_TaskInclude:
        _parent = None

        def __init__(self, loop):
            self.loop = loop
            self.action = 'include'

        def copy(self):
            return self

        def get_search_path(self):
            return ['/fake/path/one', '/fake/path/two']

        @property
        def _role(self):
            return None

    class Mock_TaskIncludeLoop:
        _parent = None

        def __init__(self, loop):
            self.loop = loop
            self.action = 'include'

        def copy(self):
            return self

        def get_search_path(self):
            return ['/fake/path/one', '/fake/path/two']


# Generated at 2022-06-23 06:29:58.573779
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-23 06:30:10.735128
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Unit test of class IncludedFile
    """
    import json
    from .mock import MagicMock
    from .mock import patch

    from ansible.module_utils.six import StringIO

    #mock ansible module loader
    mock_an_module_loader = MagicMock()

    #mock host variable manager
    mock_ho_variable_manager = MagicMock()

    #mock task variable manager
    mock_ta_variable_manager = MagicMock()

    #mock play
    mock_play = MagicMock()

    #mock host
    mock_host = MagicMock()

    #mock task
    mock_task = MagicMock()

    #mock task iterator
    mock_iterator = MagicMock()

    #mock result
    mock_result = MagicMock()

   

# Generated at 2022-06-23 06:30:22.503785
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class test_args:
        def __init__(self, _raw_params=None):
            self._raw_params = _raw_params

    class test_task:
        def __init__(self, _uuid=0, _parent=None, action=None):
            self._uuid = _uuid
            self._parent = _parent
            self.action = action

    class test_host:
        def __init__(self, get_name=None):
            self.get_name = get_name

    class test_loader:
        def __init__(self, get_basedir=None):
            self.get_basedir = get_basedir

    class test_variable_manager:
        def __init__(self):
            pass

        def get_vars(self, play, host, task):
            return

# Generated at 2022-06-23 06:30:24.697585
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    ifil = IncludedFile("/etc/ansible/hosts", None, None, None)
    assert ifil.__repr__() == ("/etc/ansible/hosts (args=None vars=None): []")

# Generated at 2022-06-23 06:30:34.084841
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # this is a simple task, but we need to do some things to make it compatible with IncludedFile
    task = Task()
    task._uuid = '12345'

    # set up a line number
    task.lineno = 1

    # fake a role
    role = type('role', (object,), {'_role_path': 'roles/test', '_name': 'test'})()
    task._role = role

    # fake a play
    play = type('play', (object,), {'_file_name': 'test'})()
    task._play = play

    # fake a parent so we can fake a parent._uuid

# Generated at 2022-06-23 06:30:44.498713
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from collections import namedtuple
    from ansible import variables
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult
    import pytest

    # The objects needed to create a TaskResult
    loader = DataLoader()
    play_context = PlayContext()
    host = 'localhost'
    task = namedtuple('task', ['action', 'args', 'when', 'loop', 'action', '_role_name', '_role_path', '_parent', '_role', '_from_files', '_ds', '_uuid', '_parent', 'no_log', 'get_search_path'])
    task._ds = {}
   

# Generated at 2022-06-23 06:30:57.367502
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    IncludedFile1 = IncludedFile("/path/to/file1", {'key1': 'value1'}, {'key2': 'value2'}, 'task')
    IncludedFile2 = IncludedFile("/path/to/file1", {'key1': 'value1'}, {'key2': 'value2'}, 'task')
    IncludedFile3 = IncludedFile("/path/to/file1", {'key1': 'value1'}, {'key2': 'value3'}, 'task')
    IncludedFile4 = IncludedFile("/path/to/file1", {'key1': 'value1'}, {'key2': 'value2'}, 'task2')
    IncludedFile5 = IncludedFile("/path/to/file1", {}, {'key2': 'value2'}, 'task')
    IncludedFile6 = Included

# Generated at 2022-06-23 06:31:07.319743
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    ifs = IncludedFile(filename='/home/test1', args={'key1': 'value1'}, vars={'var1': 'value1'}, task={'task1': 'value1'})
    assert (ifs._filename == '/home/test1')
    assert (ifs._args == {'key1': 'value1'})
    assert (ifs._vars == {'var1': 'value1'})
    assert (ifs._task == {'task1': 'value1'})


# Generated at 2022-06-23 06:31:09.050055
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile("filename.yml", dict(), dict(), dict())

# Generated at 2022-06-23 06:31:17.929075
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block

    included_files = []

    play_data = dict(
        name="test play",
        hosts="all",
        gather_facts="no",
        roles=[],
    )
    play = Play().load(play_data, variable_manager=None, loader=None)

    task_data = dict(
        action="include",
        name="test task",
    )
    task = Task().load(task_data, play=play, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:31:23.225497
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = TaskInclude()
    file = IncludedFile('name', {}, {}, task)
    file_same = IncludedFile('name', {}, {}, task)
    file_diff = IncludedFile('diff', {}, {}, task)

    assert file == file_same
    assert not file == file_diff

# Generated at 2022-06-23 06:31:30.581051
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('filename.yml', {}, {}, None)

    host_foo = 'foo'
    host_bar = 'bar'
    inc_file.add_host(host_foo)
    inc_file.add_host(host_bar)

    # Adding host_foo again should raise an exception
    try:
        inc_file.add_host(host_foo)
        assert False, "This should not happen"
    except ValueError:
        assert True


# Generated at 2022-06-23 06:31:40.126082
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    IncludedFile.__eq__(other)
    """
    include_file_1 = IncludedFile("file_1",{'arg1':1,'arg2':2},
                                  {'vars1':1,'vars2':2},{"task1":1})
    include_file_2 = IncludedFile("file_1",{'arg1':1,'arg2':2},
                                  {'vars1':1,'vars2':2},{"task1":1})
    assert include_file_1 == include_file_2

    include_file_3 = IncludedFile("file_3",{'arg1':1,'arg2':2},
                                  {'vars1':1,'vars2':2},{"task1":1})
    assert include_file_1 != include_file_3


# Unit test

# Generated at 2022-06-23 06:31:47.250436
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'foo'
    args = ['a', 'b', 'c']
    vars = {'a': 1, 'b': 2, 'c': 3}
    host = 'd'
    hosts = [host]
    task = 'e'
    is_role = False
    included_file = IncludedFile(filename, args, vars, task, is_role)
    included_file._hosts = hosts
    assert repr(included_file) == "{} (args={} vars={}): {}".format(filename, args, vars, hosts)


# Generated at 2022-06-23 06:31:57.108773
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task1 = TaskInclude()
    task1._uuid = 'abc'
    task1.action = 'include'
    task2 = TaskInclude()
    task2._uuid = 'xyz'
    task2.action = 'include_tasks'
    task2._parent = task1
    task1._parent = task1
    included_file1 = IncludedFile('/path/to/file', dict(), dict(), task1)
    included_file2 = IncludedFile('/path/to/file', dict(), dict(), task2)
    included_file3 = IncludedFile('/another/path/to/file', dict(), dict(), task1)
    included_file4 = IncludedFile('/path/to/file', dict(foo='bar'), dict(), task1)

# Generated at 2022-06-23 06:32:01.270543
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    a = IncludedFile("f1", "a1", "v1", "t1")
    b = IncludedFile("f1", "a1", "v1", "t1")
    assert(a == b)


# Generated at 2022-06-23 06:32:10.223226
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    host1 = dict(name='host1')
    host2 = dict(name='host2')
    host3 = dict(name='host3')
    inc_file = IncludedFile(filename='/tmp/ansible-tmp-host1-host2-host3', args='args', vars='vars', task='task')
    inc_file.add_host(host1)
    inc_file.add_host(host2)
    inc_file.add_host(host3)
    try:
        inc_file.add_host(host3)
    except ValueError:
        pass
    assert inc_file._hosts == [host1, host2, host3]


if __name__ == '__main__':
    test_IncludedFile_add_host()

# Generated at 2022-06-23 06:32:17.252083
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = 'a'
    args = 'b'
    vars = 'c'
    task = 'd'
    included_file = IncludedFile(filename, args, vars, task)
    included_file2 = IncludedFile(filename, args, vars, task)

    assert included_file.__eq__(included_file2) is True


# Generated at 2022-06-23 06:32:22.918885
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    ifil1 = IncludedFile("filename1", "args1", "vars1", "task1")
    ifil2 = IncludedFile("filename2", "args2", "vars2", "task2")
    ifil3 = IncludedFile("filename1", "args1", "vars1", "task1")
    assert repr(ifil3) == repr(ifil1)
    assert repr(ifil2) != repr(ifil1)



# Generated at 2022-06-23 06:32:29.895156
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.reserved import Reserved

    task = Task()
    task._role = None
    host = Host(name="hostname", groups=[Group(name="groupname")])
    args = ["arg1", "arg2"]
    tmp_vars = Reserved()
    vars = tmp_vars.get_reserved()
    included_file = IncludedFile("file_name", args, vars, task)


# Generated at 2022-06-23 06:32:34.317868
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    obj = IncludedFile('filename', 'args', 'vars', 'task')
    obj.add_host('host1')
    obj.add_host('host2')
    obj.add_host('host3')
    assert repr(obj) == "filename (args=args vars=vars): ['host1', 'host2', 'host3']"

# Generated at 2022-06-23 06:32:45.926907
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    t = Task()
    b = Block()
    b._uuid = 'abc'
    b._parent = Block()
    b._parent._uuid = 'def'
    t._parent = b
    f = IncludedFile('foo.yml', {'a':1}, {'b':2}, t)
    assert f._filename == 'foo.yml'
    assert f._args == {'a':1}
    assert f._vars == {'b':2}
    assert f._task._uuid == 'abc'
    assert f._task._parent._uuid == 'def'
    assert f._hosts == []
    assert f._is_role == False



# Generated at 2022-06-23 06:32:50.272400
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    '''
    Ansible 2.9.7, module_utils.basic.py
    Unit test for method __repr__ of class IncludedFile
    '''
    # Test case 1
    # TODO: Need to do unit test
    print('Test case 1')

    # Test case 2
    # TODO: Need to do unit test
    print('Test case 2')



# Generated at 2022-06-23 06:33:01.545646
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    a = Block()
    b = Task()
    c = Task()
    c._parent = b
    b._parent = a
    d = Task()
    d._parent = c
    f = IncludedFile('foobar.yml', {}, {}, d)
    g = IncludedFile('foobar.yml', {}, {}, c)
    f2 = IncludedFile('foobar.yml', {}, {}, d)

    assert not (f == g)
    assert f != g
    assert f == f2
    assert not (f != f2)
    assert not (g == f2)
    assert g != f2

# Generated at 2022-06-23 06:33:09.224848
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    iter = MockIterator()
    loader = MockLoader()
    variable_manager = MockVariableManager()
    results = [MockResult(loader=loader, iterator=iter, variable_manager=variable_manager)]
    included_files = IncludedFile.process_include_results(results, iter, loader, variable_manager)
    assert included_files[0] == included_files[1]
    assert included_files[0] != included_files[2]
    assert included_files[0] != included_files[3]


# Generated at 2022-06-23 06:33:12.130338
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file1 = IncludedFile('filename', 'args', 'vars', 'task')
    included_file2 = IncludedFile('filename', 'args', 'vars', 'task')

    assert included_file1 == included_file2

# Generated at 2022-06-23 06:33:18.776676
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print("Testing creating of IncludedFile")
    filename = "test"
    args = "arg1, arg2"
    vars = {"var1":1, "var2":2}
    print("Creating instance of IncludedFile")
    test_instance = IncludedFile(filename, args, vars, None)
    assert test_instance._filename == filename
    assert test_instance._args == args
    assert test_instance._vars == vars

    print("Testing method of __eq__")
    assert test_instance == test_instance
    assert not test_instance == IncludedFile("test_new", "new_arg", "new_vars", None)

    print("Testing method of add_host")
    test_instance.add_host("test_instance")
    assert "test_instance" in test_instance._hosts

# Generated at 2022-06-23 06:33:35.859162
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Setup
    iter = [
        {"hosts": ["host1"], "_result": {"_ansible_item_label": "item1", "include": "some_file", "include_args": {"somearg": "somevalue"}}},
        {"hosts": ["host2"], "_result": {"_ansible_item_label": "item2", "include": "some_file", "include_args": {"somearg": "somevalue"}}},
        {"hosts": ["host3"], "_result": {"_ansible_item_label": "item2", "include": "some_other_file", "include_args": {"otherarg": "othervalue"}}}
    ]
    dummy_task = object()

    # Exercise
    actual = []

# Generated at 2022-06-23 06:33:48.624508
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert(len(IncludedFile.process_include_results(
        [{'_host': '127.0.0.1', '_task': {'loop': 'test_loop', 'args': {'arg1': 'a1', 'arg2': 'a2'},
                                          'action': 'include', 'include': 'arg1=1'}, '_result': {'ansible_loop_var': 'arg1', 'ansible_index_var': 'arg2',
                                                                                      '_ansible_item_label': 'test_loop', 'arg1': 2, 'arg2': '0'}}],
        'iterator', 'loader', 'variable_manager')) == 1)

# Generated at 2022-06-23 06:34:00.930490
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.module_utils.six import string_types
    from ansible.playbook.play_context import PlayContext
