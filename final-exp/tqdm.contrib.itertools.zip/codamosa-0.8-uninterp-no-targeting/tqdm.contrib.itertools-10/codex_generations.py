

# Generated at 2022-06-22 04:56:25.762305
# Unit test for function product
def test_product():
    """
    Test for product for tqdm compatibility.
    """
    from .tests import TestCase, importorskip, SkipTest
    from .tests import closing, nested
    import multiprocessing as mp
    import os
    import sys
    import time

    expect = list(itertools.product(range(10), range(10), range(10)))
    result = list(product(range(10), range(10), range(10)))
    with closing(tqdm_auto(total=len(expect))) as t:
        for i in product(range(10), range(10), range(10)):
            result.append(i)
            t.update()

    len_expect = len(expect)
    len_result = len(result)

# Generated at 2022-06-22 04:56:30.769719
# Unit test for function product
def test_product():
    """Test for utils.itertools.product"""
    assert list(product([1, 2, 3], [4, 5])) == [(1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]

# Generated at 2022-06-22 04:56:37.453285
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    lst = list(product(*[range(10)]*10))
    assert isinstance(lst[0], tuple)
    assert len(lst) == 100000
    assert (0, 0, 0, 0, 0, 0, 0, 0, 0, 0) == lst[0]
    assert (9, 9, 9, 9, 9, 9, 9, 9, 9, 9) == lst[-1]

# Generated at 2022-06-22 04:56:43.066161
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for i in range(1, 5):
        for j in range(1, 5):
            s = list(product(range(i), range(j)))
            assert len(s) == i * j
            assert s == list(itertools.product(range(i), range(j)))

# Generated at 2022-06-22 04:56:47.265271
# Unit test for function product
def test_product():
    import sys
    import doctest
    doctest.testmod(itertools, verbose=False)
    try:
        doctest.testmod(sys.modules[__name__], verbose=False)
    except ImportError:
        print("Need tqdm module for unit tests")

# Generated at 2022-06-22 04:56:58.172513
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests_tqdm import with_setup, FakeTqdmFile, closing, StringIO
    with closing(StringIO()) as our_file:
        # `range` input
        with tqdm_auto(range(3), file=our_file) as t:
            assert list(product(t)) == list(itertools.product(range(3)))
        # `str` input
        with tqdm_auto('abc', file=our_file) as t:
            assert ''.join(product(t)) == ''.join(itertools.product('abc'))
        # `set` input
        with tqdm_auto({1, 2}, file=our_file) as t:
            assert set(product(t)) == (1, 2)
        # `dict` input

# Generated at 2022-06-22 04:57:09.287051
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    assert list(product(range(7))) == [(0,), (1,), (2,), (3,), (4,), (5,), (6,)]

# Generated at 2022-06-22 04:57:19.038004
# Unit test for function product
def test_product():
    from .tests import TestTqdm
    from .tests import lc
    from .tests import naturals

    # Test with defined total
    with TestTqdm(1000000, unit="it"):
        for i in product(lc, repeat=5):
            pass
    # Test without defined total (e.g. infinite iterator)
    with TestTqdm(unit="its"):
        for i in product(naturals(), repeat=5):
            if i == (0, 0, 0, 0, 0):
                break

    # Test with class override
    with TestTqdm(100, bar_format="{l_bar}", tqdm_class=tqdm_auto) as t:
        for i in product(naturals(), repeat=5):
            pass

    # Test with wrong total argument

# Generated at 2022-06-22 04:57:30.058159
# Unit test for function product
def test_product():
    import sys
    import platform
    import random
    from ..utils import nocolor, nogui
    from . import trange

    it = product(range(1000), (None,), 'abcd')
    for _ in it:
        pass

    for _ in product(range(1000), (None,), 'abcd', mininterval=0.0001):
        pass


# Generated at 2022-06-22 04:57:41.524177
# Unit test for function product
def test_product():
    import sys
    import math

    x = [1,2,3]
    y = ["a", "b", "c"]
    z = ["foo", "bar", "baz", "qux"]

    # Totally unoptimal way to calculate the cardinality of cartesian product
    num_elements = math.factorial(len(x)) \
                   * math.factorial(len(y)) \
                   * math.factorial(len(z))

    sys.stderr.write('Expecting {0} elements\n'.format(num_elements))
    i = 0

    for value in product(x,y,z):
        i += 1

    sys.stderr.write('i={0}, num_elements={1}\n'.format(i, num_elements))
    assert i == num_elements