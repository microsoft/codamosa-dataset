

# Generated at 2022-06-22 04:56:16.737413
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests_tqdm import with_setup
    from .tests_tqdm import FakeTqdmType
    from .tests_tqdm import closing

    try:
        from nose.tools import assert_equal, assert_almost_equal
    except ImportError:
        if hasattr(__builtins__, '__IPYTHON__'):
            return  # nose doesn't support IPython
        raise

    # Test 1

# Generated at 2022-06-22 04:56:27.909225
# Unit test for function product
def test_product():
    """ Test that tqdm.itertools.product is identical to real itertools """
    # Check equivalence
    def idem(it, *args, **kwargs):
        return list(it(*args, **kwargs))

    class Foo():
        def __init__(self):
            self.l = 0

        def __len__(self):
            return self.l

    # Check that tqdm_class kwarg works
    assert(idem(product, range(10), range(10), tqdm_class=None) ==
           idem(itertools.product, range(10), range(10)))
    # Check that total can be inferred
    assert(idem(product, range(10), range(10)) ==
           idem(itertools.product, range(10), range(10)))
    # Check that

# Generated at 2022-06-22 04:56:38.674222
# Unit test for function product
def test_product():
    import random
    from ..utils import format_sizeof
    from nose.tools import assert_equal

    iterables = [range(10)] * 10
    items = list(product(*iterables))
    assert_equal(len(items), 10 ** 10)

    iterables = [range(100)] * 100
    items = list(product(*iterables))
    assert_equal(len(items), 100 ** 100)

    iterables = [range(10)] * 10
    items = list(product(*iterables, tqdm_class=tqdm_auto.__main__.tqdm))
    assert_equal(len(items), 10 ** 10)

    iterables = (range(10) for _ in itertools.repeat(0))

# Generated at 2022-06-22 04:56:44.645872
# Unit test for function product
def test_product():
    from numpy.testing import assert_raises
    from numpy.testing import assert_equal
    from tqdm.std import product

    assert_raises(AssertionError, product, range(3), repeat=2)
    assert_raises(AssertionError, product, 'ABC', range(2))

    assert_equal(
        list(product(range(1))),
        [range(1)])
    assert_equal(
        list(product(range(1), repeat=2)),
        [range(1)] * 2)

# Generated at 2022-06-22 04:56:50.519895
# Unit test for function product
def test_product():
    from tqdm.autonotebook import tqdm
    assert tqdm(product((1, 2, 3), (10, 11), (20, 21, 22)),
                desc="testproduct", leave=False)
    assert tqdm(product((10, 11), (20, 21, 22), (1, 2, 3)),
                desc="testproduct_tqdm_class", tqdm_class=tqdm, leave=False)

# Generated at 2022-06-22 04:57:01.621515
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    import pytest  # NOQA


# Generated at 2022-06-22 04:57:14.008065
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .guppy_adapter import nbytes

    from tqdm import trange
    from time import sleep
    from math import prod
    from os import getpid
    from tqdm.utils import _term_move_up

    sleep_time = .1
    n = 10

    for iterable in [range(n), (None,)*n]:
        for leave in [False, True]:
            for ascii in [False, True]:
                for desc in ["", "A", "B", "C"]:
                    for total in [None, n, 0]:
                        t = trange(n, desc=desc, ascii=ascii,
                                   unit="B", unit_scale=True,
                                   miniters=1, leave=leave, total=total)

# Generated at 2022-06-22 04:57:21.261094
# Unit test for function product
def test_product():
    from ..utils import freeze_support
    from ..tests_tqdm import tqdm

    x = list(range(4))
    y = list('abcde')
    z = list(zip(x, y))

    list_args = (x, x, x, x)
    with tqdm(total=24) as t:
        for _ in itertools.product(*list_args):
            t.update(1)
    t.close()

    single_args = (x, 'a', 5, 0.5, None)
    with tqdm(total=5) as t:
        for _ in itertools.product(*single_args):
            t.update(1)
    t.close()

    list_args = (x, y)

# Generated at 2022-06-22 04:57:25.526952
# Unit test for function product
def test_product():
    """Test product"""
    # Test unit test
    assert product([1, 2], [3, 4], [5, 6])
    # Test that product is identical to itertools.product
    assert list(product(range(5), repeat=3)) == \
        list(itertools.product(range(5), repeat=3))


if __name__ == '__main__':
    from ..utils import test_module_docstrings
    test_module_docstrings(__file__, globals())

# Generated at 2022-06-22 04:57:28.332033
# Unit test for function product
def test_product():
    """
    See unit test `test_product` in `tqdm/tests/test_itertools.py`.
    """
    pass