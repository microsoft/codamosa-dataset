

# Generated at 2022-06-22 04:56:13.164305
# Unit test for function product
def test_product():
    import numpy as np
    np.random.seed(0)
    random_vector = np.random.random(10000)
    # Check product range
    assert sum(product(range(10), range(1000))) == 45000000
    assert sum(product(range(10), range(1000), tqdm_class=tqdm_auto)) == 45000000
    # Check that tqdm works without total
    with tqdm_auto(unit_scale=True) as t:
        sum(product((random_vector,) * 2, tqdm=t))  # noqa: F841
        assert t.n == len(random_vector) ** 2
        assert t.total is None

# Generated at 2022-06-22 04:56:25.508643
# Unit test for function product
def test_product():
    """
    Test function product
    """
    from ..utils import format_sizeof
    from collections import Counter
    from sys import getsizeof

    with tqdm_auto() as t:
        li = list(map(list, product(
            list(range(10)), list(range(10)), list(range(10)),
            list(range(10)), list(range(10)), list(range(10)))))
        t.update()  # check that t.update() works in a list context
    assert Counter(map(len, li)) == Counter({6: 1})
    assert len(li) == 10**6
    assert format_sizeof(getsizeof(li)) == format_sizeof(6e+06)
    # leave tqdm_auto handling of "ascii" for last

# Generated at 2022-06-22 04:56:31.884746
# Unit test for function product
def test_product():
    """
    Examples
    --------
    >>> from tqdm import tqdm_notebook
    >>> with tqdm_notebook(total=1) as t:
    ...     for i in product([1, 2], repeat=1, tqdm_class=tqdm_notebook):
    ...         t.update()
    ...
    """

# Generated at 2022-06-22 04:56:41.658128
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ._utils import _test_eq  # noqa
    assert _test_eq(product(range(i + 1) for i in range(4)),
                    itertools.product(range(i + 1) for i in range(4)))
    assert _test_eq(product(range(i + 1) for i in range(4)),
                    itertools.product(range(i + 1) for i in range(4)))
    assert _test_eq(product(range(i + 1) for i in range(4)),
                    itertools.product(range(i + 1) for i in range(4)))
    assert _test_eq(product(range(i + 1) for i in range(4)),
                    itertools.product(range(i + 1) for i in range(4)))


# Generated at 2022-06-22 04:56:53.700263
# Unit test for function product
def test_product():
    """Unit test for function `tqdm.tqdm_itertools.product`"""
    import numpy as np
    from numpy.testing import assert_equal

    # Check configurable counter update
    assert_equal(product(range(4), range(4), range(4)),
                 list(itertools.product(range(4), range(4), range(4))))
    assert_equal(product(range(4), range(4), range(4), tqdm_class=tqdm_auto),
                 list(itertools.product(range(4), range(4), range(4))))
    assert_equal(product(range(4), range(4), range(4), ascii=True),
                 list(itertools.product(range(4), range(4), range(4))))

    # Check error handling


# Generated at 2022-06-22 04:57:03.151729
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..utils import FormatCustomText
    from ..std import StringIO
    try:
        StringIO = StringIO
    except NameError:
        from io import StringIO

    class TestTqdm(FormatCustomText):

        def format_dict(self, d):
            if 'n' in d:
                d['n'] = str(d['n'])
            return d

    with TestTqdm(
            postfix=["foo", "bar", "baz"],
            unit="item",
            file=StringIO()) as t:
        for (i, j, k) in product([1, 2, 3], ['a', 'b'], ["x", "y"]):
            t.set_postfix(i=i, j=j, k=k)



# Generated at 2022-06-22 04:57:14.091975
# Unit test for function product
def test_product():
    from ._deprecated import deprecated
    from .utils import _range
    from .std import time
    deprecated("test_product")

    def brute(x):
        for i in range(x):
            for j in range(x):
                for k in range(x):
                    pass
    for j in _range(20):
        start = time.time()
        brute(2**j)
        print("%d loops, %.3f s" % (2**j, time.time() - start))
    print("Test that empty product still works")
    for i in product([], [], [], tqdm_class=None):
        print(i)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 04:57:20.385047
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.testing import assert_almost_equal
    from .utils import StringIO
    from .std import stdout
    a1 = ['a', 'b', 'c']
    a2 = [1, 2, 3, 4]
    import sys
    sys.stdout = StringIO()
    for i, j in product(a1, a2, tqdm_class=tqdm_auto, miniters=1, mininterval=1e-100):
        pass
    output = sys.stdout.getvalue()
    sys.stdout = stdout
    assert "12/12" in output

# Generated at 2022-06-22 04:57:31.117558
# Unit test for function product
def test_product():
    import operator
    import functools
    import sys

    try:
        from itertools import product
    except ImportError:
        from ..utils import product
    from .. import trange
    from .tests_tqdm import with_setup, pretest, posttest, _range

    # r[0]: short iterable, r[1]: long iterable
    r = _range(4), _range(100)
    assert list(product(*r)) == [(i, j) for i in r[0] for j in r[1]]

    with trange(10, leave=True) as t:
        assert list(product(t)) == [(i,) for i in t]


# Generated at 2022-06-22 04:57:42.313796
# Unit test for function product
def test_product():
    from itertools import product as iproduct
    from .utils import bounded_wraps

    for _ in product(range(2), range(2), range(2),
                     range(2), range(2), range(2)):
        pass
    for _ in iproduct(range(2), range(2), range(2),
                      range(2), range(2), range(2)):
        pass

    for p in (1, 2, 3, 4, 5, 6, 100, 7, 8, 9, 10, 99, 19, 20):
        if p < 0:
            continue  # negative `total` not permitted by tqdm
        iterable = range(p)

# Generated at 2022-06-22 04:57:54.618376
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_allclose
    from ..utils import format_sizeof

    def _gen3():
        for i in product(range(5), range(5), range(5), tqdm_class=tqdm_auto,
                         desc="test_product"):
            yield i

    res = list(_gen3())
    assert len(res) == 125
    it = product(range(15), range(15), range(15), tqdm_class=tqdm_auto,
                 total=3375, desc="test_product")
    assert_allclose(format_sizeof(next(it)), "33B")

# Generated at 2022-06-22 04:58:05.113081
# Unit test for function product
def test_product():
    """Unit test for `itertools.product`"""
    list1 = ["a", "b"]
    list2 = list(range(5))
    list3 = [None]
    assert set(list(product(list1))) == {'a', 'b'}
    assert set(list(product(list2))) == set(range(5))
    assert set(list(product(list1, list2))) == {('a', i) for i in range(5)} | {('b', i) for i in range(5)}
    assert set(list(product(list1, list2, list3))) == {('a', i, None) for i in range(5)} | {('b', i, None) for i in range(5)}

    # Test tqdm_class

# Generated at 2022-06-22 04:58:09.747324
# Unit test for function product

# Generated at 2022-06-22 04:58:20.932932
# Unit test for function product
def test_product():
    """
    Simple unit test for function product.
    """
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # py2

    def check(shape, expected_shape):
        iterables = []
        for dim in shape:
            iterables.append(list(range(dim)))
        with patch("tqdm.std.itertools.product") as patched_itertools_product:
            for _ in tqdm.std.itertools.product(*iterables):
                pass
        assert patched_itertools_product.called
        assert isinstance(_, patched_itertools_product.return_value)
        if expected_shape:
            assert len(_) == expected_shape
            assert _.total == expected_shape


# Generated at 2022-06-22 04:58:26.060739
# Unit test for function product
def test_product():
    kwargs = tqdm_auto.kwargs
    kwargs.setdefault("desc", "test_product")
    assert isinstance(itertools.chain(*tqdm_auto.product(*tqdm_auto.chain(
        [1], range(100)), **kwargs)), type(itertools.chain()))

# Generated at 2022-06-22 04:58:37.310314
# Unit test for function product
def test_product():
    from .tests import closing, FakeTqdmFile, StringIO
    from .tests import range, unicode
    with closing(StringIO()) as our_file:
        with tqdm(total=2 * 3 * 4 * 5 * 6, file=our_file,
                  desc=unicode('product')) as t:
            for i in product(
                    range(2), range(3), range(4), range(5), range(6)):
                t.update()  # NOQA

# Generated at 2022-06-22 04:58:42.111064
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range, closing, pretest

    @with_setup(pretest)
    def wrapper():
        for _ in closing(product(_range(9999), _range(99), _range(9))):
            pass

    wrapper()

# Generated at 2022-06-22 04:58:52.150226
# Unit test for function product
def test_product():
    N = [1, 2, 3]
    M = [11, 22, 33]
    L = [1, 2]
    from hypothesis import given, settings
    from .hypothesis_test_util import floats

    @given(N, M, L)
    @settings(max_examples=10)
    def test_product_len(N, M, L):
        """
        Test that the length of product is the product of the lengths
        """
        assert (len(list(itertools.product(N, M, L))) ==
                len(N) * len(M) * len(L))


# Generated at 2022-06-22 04:59:03.411500
# Unit test for function product
def test_product():
    """Test function `product`."""
    from random import randint, shuffle
    from .tqdm_gui import tqdm


# Generated at 2022-06-22 04:59:07.213519
# Unit test for function product
def test_product():
    """Test function `product()`."""
    from ..utils import nocolours
    iterables = [xrange(1, 4), xrange(1, 4)]
    output = [nocolours(i) for i in product(*iterables)]
    assert output == list(itertools.product(*iterables))

# Generated at 2022-06-22 04:59:19.494435
# Unit test for function product
def test_product():
    """Unit test for the product function"""
    tqdm_kwargs_1 = {"total": 10}
    tqdm_kwargs_2 = {"total": 1000}
    total_1 = 1
    total_2 = 1
    i_list_1 = [3, 5, 2]
    i_list_2 = [100, 100, 100]
    for i in i_list_1:
        total_1 = total_1 * i
    for i in i_list_2:
        total_2 = total_2 * i
    assert product(i_list_1, tqdm_kwargs=tqdm_kwargs_1) == total_1
    assert product(i_list_2, tqdm_kwargs=tqdm_kwargs_2) == total_2

# Generated at 2022-06-22 04:59:28.505153
# Unit test for function product
def test_product():
    """Test for the function `product`."""
    list_i = []
    for i in product([1, 2], ["a", "b"], [10, 20]):
        list_i.append(i)
        if len(list_i) > 10:
            break
    assert list_i  == [(1, 'a', 10), (1, 'a', 20), (1, 'b', 10), (1, 'b', 20),
                       (2, 'a', 10), (2, 'a', 20), (2, 'b', 10), (2, 'b', 20),
                       (1, 'a', 10), (1, 'a', 20)]

# Generated at 2022-06-22 04:59:32.786737
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    res0 = list(itertools.product(*[[1, 2, 3], [4, 5], [6, 7, 8]]))
    res = list(tqdm.tqdm.product(*[[1, 2, 3], [4, 5], [6, 7, 8]]))
    assert res == res0

# Generated at 2022-06-22 04:59:44.400949
# Unit test for function product
def test_product():
    from .tests import pretest_posttest

    class Custom(tqdm_auto.tqdm):
        def __init__(self, *args, **kwargs):
            # Test that we can use different tqdm classes
            # within the same iteration
            super(Custom, self).__init__(*args, **kwargs,
                                         dynamic_ncols=True)

    def test_iter_wrap(tqdm_class=tqdm_auto):
        """
        Test the tqdm.itertools.product wrapper
        """
        # Test basic iterator

# Generated at 2022-06-22 04:59:52.964496
# Unit test for function product
def test_product():
    fl = list(product(range(20), range(10), desc="A"))
    assert fl == [(i1, i2) for i1 in range(20) for i2 in range(10)]
    fl = list(product(range(20), range(10), tqdm_class=tqdm_auto.tqdm, desc="B"))
    assert fl == [(i1, i2) for i1 in range(20) for i2 in range(10)]

# Generated at 2022-06-22 05:00:03.333730
# Unit test for function product
def test_product():
    """Unit test for function product"""
    it = product((1), ('a', 'b', 'c'), ('k', 'l'))
    assert list(it) == list(itertools.product((1), ('a', 'b', 'c'), ('k', 'l')))

    it = product((1, 2), ('a', 'b', 'c'), ('k', 'l'))
    assert list(it) == list(itertools.product((1, 2), ('a', 'b', 'c'), ('k', 'l')))

    it = product(1, ('a', 'b', 'c'), ('k', 'l'))
    assert list(it) == list(itertools.product(1, ('a', 'b', 'c'), ('k', 'l')))


# Generated at 2022-06-22 05:00:04.668982
# Unit test for function product
def test_product():
    import sys
    from .utils import FormatTe

# Generated at 2022-06-22 05:00:09.063045
# Unit test for function product
def test_product():
    assert list(product(range(2), range(2))) == list(itertools.product(range(2), range(2)))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:00:13.693233
# Unit test for function product
def test_product():
    """Test iterable"""
    from ..utils import _range
    output = list()
    for i, j in product(_range(10), _range(10)):
        output.append(i+j)
    assert sum(output) == sum(range(100))
    assert sum(output) / 100 == 4.5

# Generated at 2022-06-22 05:00:24.895361
# Unit test for function product
def test_product():
    """
    Unit test of function product to ensure that it works as expected.
    """
    # Import necessary modules.
    import numpy as np

    # Build test matrix.
    matrix_test_in = np.ones((3,3))

    # Build the test loop.
    for i in product(range(3)):
        for j in product(range(3)):
            matrix_test_in[i,j] = i+j

    # Build the comparison matrix.
    matrix_test_out = np.array([[0,1,2],
                                [1,2,3],
                                [2,3,4]])

    # Compare test and comparison matrix.
    assert np.all(matrix_test_in == matrix_test_out)

# Generated at 2022-06-22 05:00:31.862900
# Unit test for function product
def test_product():
    import sys
    if sys.version_info >= (3,):
        exec("def r(x):\n "
             "    return x")  # Python 3's range is lazy, unlike 2's
    else:
        r = range

    # Without total
    assert list(product(r(10))) == list(itertools.product(r(10)))
    # With total
    assert list(product(r(10), total=10)) == list(itertools.product(r(10)))

# Generated at 2022-06-22 05:00:43.244635
# Unit test for function product
def test_product():
    """Unit tests for `tqdm.itertools.product`"""
    # test inputs
    iterable_list = [[1, 2, 3], ['hello', 'world', 'bye']]
    count_list = [3, 3]
    total = 9
    # without tqdm
    itr = itertools.product(*iterable_list)
    assert [i for i in itr] == list(itertools.product(*iterable_list))
    # with tqdm
    itr = product(*iterable_list)
    assert [i for i in itr] == list(itertools.product(*iterable_list))
    # test with tqdm output
    for pos in range(total):
        input_list = []

# Generated at 2022-06-22 05:00:51.193509
# Unit test for function product
def test_product():
    import operator
    p = product(range(3), range(3), range(3), range(3))
    assert list(map(operator.mul, range(3), range(3))) == [0, 1, 2, 1, 2, 3, 2, 3, 4]
    assert list(p) == list(itertools.product(range(3), range(3), range(3), range(3)))

# Generated at 2022-06-22 05:00:55.088753
# Unit test for function product
def test_product():
    iterables = [range(5)] * 3
    with tqdm_auto(total=125) as t:
        for it in product(*iterables):
            assert it == tuple(map(int, t.format_interval(t.n).split("/")))
            t.update()

# Generated at 2022-06-22 05:01:06.811903
# Unit test for function product
def test_product():
    """Test that product() wrapper matches itertools."""
    import numpy as np
    import types

    assert hasattr(itertools, 'product')
    assert isinstance(product, types.FunctionType)

    iter1 = range(5)
    iter2 = ['a', 'b', 'c']

    assert list(itertools.product(iter1, iter2)) == list(product(iter1, iter2))

    # test that default tqdm is working
    total = 0
    for i in product(range(10), range(10)):
        total += 1
    assert total == 100

    # test that tqdm is working
    from .tqdm import tqdm
    total = 0
    for i in product(range(10), range(10), tqdm=tqdm):
        total += 1


# Generated at 2022-06-22 05:01:15.375670
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import sys
    list(product('ABCD', repeat=2))
    list(product(range(3), repeat=3))
    list(product('ABCD', 'xy'))
    list(product(range(2), repeat=3))
    list(product('ABCD', 'xy'))
    list(product(range(2), range(4)))
    try:
        with tqdm_auto(unit_scale=0) as t:
            list(product(range(100), range(100)))
        sys.stderr.write(t.format_stats())
        assert t.n == 10000
    except:  # noqa
        pass

# Generated at 2022-06-22 05:01:19.608828
# Unit test for function product
def test_product():
    itr = product(
        range(100),
        range(100),
        tqdm_class=tqdm_auto, total=10000, leave=False)
    assert sum(itr) == 328350

# Generated at 2022-06-22 05:01:28.804446
# Unit test for function product
def test_product():
    """Run a unit test for function product"""
    import itertools
    import random
    import sys
    from .utils import format_sizeof

    def total_size(tup):
        """Returns the total size of a tuple"""
        return sum(map(sys.getsizeof, tup))

    # --- test 1
    # Create random iterable of lists of random ints
    test_l = [
        [random.randint(0, i) for i in range(random.randint(0, 10))]
        for _ in range(random.randint(10, 20))
    ]

    # size of original iterable of lists
    orig_size = sum(map(lambda x: sys.getsizeof(x), test_l))

    # prod_size is the product of the sizes of all the lists
    prod_size

# Generated at 2022-06-22 05:01:30.715733
# Unit test for function product
def test_product():
    from .tests import test_product as _test_product
    _test_product(product)

# Generated at 2022-06-22 05:01:40.229681
# Unit test for function product
def test_product():
    import sys
    import unittest
    import io

    from ..utils import FormatStopIteration

    from .tqdm_gui import tqdm as tqdm_gui

    class Tests(unittest.TestCase):
        def setUp(self):
            self.old_stdout = sys.stdout
            self.old_stderr = sys.stderr
            sys.stdout = self.stdout = io.StringIO()
            sys.stderr = self.stderr = io.StringIO()

        def tearDown(self):
            sys.stdout = self.old_stdout
            sys.stderr = self.old_stderr


# Generated at 2022-06-22 05:01:46.783048
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`, using a trivial example.
    """
    from numpy.testing import assert_equal

    l = [0, 1, 2]
    expected_result = itertools.product(l, l, l)
    result = product(l, l, l, tqdm_class=tqdm_auto)
    assert_equal(list(expected_result), list(result))

# Generated at 2022-06-22 05:01:58.989176
# Unit test for function product
def test_product():
    import pytest

    # Test global keyword arguments
    with pytest.raises(TypeError):
        list(product([], [], [], tqdm_class=1))

    # Test *args
    a = product([1, 2])
    b = product([1, 2], [3, 4])
    c = product([1, 2], [3, 4], [5, 6])
    assert next(a) == (1,)
    assert next(b) == (1, 3)
    assert next(c) == (1, 3, 5)
    # Test total
    with tqdm_auto(total=6) as t:
        assert list(t.update() for _ in product([1, 2])) == [1, 2]

# Generated at 2022-06-22 05:02:05.378338
# Unit test for function product
def test_product():
    """Test function product"""
    assert list(product([], range(10), tqdm_class=None)) == []
    assert list(product([1], range(1), tqdm_class=None)) == [(1, 0)]
    assert list(product(range(10), tqdm_class=None)) == list(
        itertools.product(range(10)))
    assert list(product(range(1), range(10), tqdm=None)) == list(
        itertools.product(range(1), range(10)))
    assert list(product(range(2), range(3), range(4))) == list(
        itertools.product(range(2), range(3), range(4)))

# Generated at 2022-06-22 05:02:15.434462
# Unit test for function product
def test_product():
    """
    Unit tests for function `product`.
    """
    # Iterable
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    # Iterables
    assert list(product(range(3), repeat=2)) == \
        [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]
    # Empty
    assert list(product(range(0))) == []
    assert list(product(range(0), repeat=2)) == []
    # Repeat

# Generated at 2022-06-22 05:02:17.085450
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for _ in product(range(10000)):
        pass

# Generated at 2022-06-22 05:02:21.838636
# Unit test for function product
def test_product():
    """
    Example of function product
    """
    for i in product(range(10), range(10),desc="My Product",tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 05:02:24.589229
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    list(product(range(50), range(50), tqdm_class=tqdm_auto))

# Generated at 2022-06-22 05:02:32.990105
# Unit test for function product
def test_product():
    from ..main import TqdmKeyError
    from .tests_common import closing, nolock, StringIO, _range

    with closing(StringIO()) as our_file:
        for i in product(_range(5), "ab", tqdm_class=nolock):
            pass
        assert our_file.getvalue() == ""

    with closing(StringIO()) as our_file:
        for i in product(_range(5), "ab", tqdm_class=nolock,
                         file=our_file):
            pass
        assert our_file.getvalue() == ""

    with closing(StringIO()) as our_file:
        with nolock(total=10, file=our_file):
            for i in product(_range(5), "ab"):
                pass
        assert our_file.getvalue()

# Generated at 2022-06-22 05:02:37.725304
# Unit test for function product
def test_product():
    from ._utils import _range
    for i in product(_range(10), _range(10)):
        pass
    for i in product(_range(100), _range(100), _range(100)):
        pass
    for i in product(_range(1000), _range(1000), _range(1000), _range(1000)):
        pass

# Generated at 2022-06-22 05:02:42.408984
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from pytest import approx

    for i in product(range(10), [0.5, 1.5], ["abc", "def"]):
        assert i == (i[0], approx(i[1]), i[2])

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 05:02:52.570207
# Unit test for function product
def test_product():  # pragma: no cover
    from ..utils import test_gen
    for t in test_gen(product, itertools.product):
        yield t


if __name__ == '__main__':  # pragma: no cover
    import nose
    nose.runmodule()

# Generated at 2022-06-22 05:02:57.005661
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert list(product([0, 1], repeat=3)) == [(0, 0, 0), (0, 0, 1),
                                              (0, 1, 0), (0, 1, 1),
                                              (1, 0, 0), (1, 0, 1),
                                              (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-22 05:02:58.371742
# Unit test for function product
def test_product():
    from .tests import Tests
    Tests.test_tqdm_product(tqdm=product)

# Generated at 2022-06-22 05:03:02.117908
# Unit test for function product
def test_product():
    from ..utils import freeze_support, format_sizeof
    from nose.tools import assert_equal

    iterables = [range(5), range(5)]

    for t in product(*iterables):
        assert_equal(t, (0, 0))
        break

    assert_equal(list(product(*iterables))[-1], (4, 4))
    assert_equal(list(product(*iterables, total=7))[-1], (4, 4))

    with freeze_support():
        assert_equal(list(product(*iterables, total=7))[-1], (4, 4))
        assert_equal(list(product(*iterables, total=7, ascii=True))[-1], (4, 4))

    # Test no crash on bad iterables (see #211)

# Generated at 2022-06-22 05:03:10.691954
# Unit test for function product
def test_product():
    from .utils import RandomTimer
    from . import trange
    from .utils import format_sizeof
    from .utils import format_interval
    from .pandas import read_csv

    list_of_lists = [[1], [1, 2], [1, 2, 3]]
    for tqdm in [tqdm_auto, trange]:
        with RandomTimer() as timer:
            for _ in tqdm(product(list_of_lists)):
                pass
        print("product(list_of_lists):")
        print("  elapsed in %s" % format_interval(timer.interval))


# Generated at 2022-06-22 05:03:22.166124
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval

    import time
    a = [1, 2]

    t0 = time.time()
    for i in product(a, tqdm=tqdm_auto, mininterval=2):
        pass
    print('Elapsed time:', format_interval(time.time() - t0))
    print('')

    t0 = time.time()
    for i in itertools.product(a):
        pass
    print('Elapsed time:', format_interval(time.time() - t0))
    print('')

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:03:30.039636
# Unit test for function product
def test_product():
    from nose.tools import assert_equal, assert_not_equal
    it_product = product(range(3), range(4), tqdm_class=lambda x: x)
    it_product.update = lambda x: None
    prod = list(it_product)
    assert_not_equal(prod, None)
    assert_equal(len(prod), 3*4)
    assert_equal(list(itertools.product(*[range(3), range(4)])), prod)
    it_product.update = lambda x: None
    prod = list(it_product)
    assert_equal(prod, [])

# Generated at 2022-06-22 05:03:38.266259
# Unit test for function product
def test_product():
    """Test itertools.product() emulation."""
    results1 = [x for x in product(range(3), range(3), range(3))]
    results2 = [x for x in product(range(3), range(3), range(3),
                                   tqdm_class=tqdm_auto)]
    assert results1 == results2


if __name__ == '__main__':
    from multiprocessing import Pool
    with Pool() as p:
        list(tqdm_auto(p.imap(test_product, [{} for _ in range(32)])))

# Generated at 2022-06-22 05:03:49.098087
# Unit test for function product
def test_product():
    with tqdm_auto(total=4, miniters=None, mininterval=None,
                   maxinterval=10, leave=False,
                   unit='',
                   unit_scale=False,
                   ascii=None, desc=None, ncols=None,
                   disable=False, dynamic_ncols=False,
                   smoothing=1.0, bar_format=None, initial=0,
                   position=None, postfix=None) as t:
        for i in product(range(2), range(2), tqdm_kwargs={"total": 4}):
            assert i[0] in [0, 1]
            assert i[1] in [0, 1]
            t.update()

# Generated at 2022-06-22 05:04:00.132432
# Unit test for function product
def test_product():
    from ..std import next, filterfalse

    assert (list(product(range(3), range(4), range(5))) ==
            list(itertools.product(range(3), range(4), range(5))))

    # Normal
    assert (list(product(range(10), repeat=2)) ==
            list(itertools.product(range(10), repeat=2)))

    # Total parameter
    assert (list(product(range(10), range(10), total=100)) ==
            list(itertools.product(range(10), range(10))))

    # No side effects
    assert (list(product(range(2), range(2), total=0)) ==
            list(itertools.product(range(2), range(2))))

    # No side effects

# Generated at 2022-06-22 05:04:13.899136
# Unit test for function product
def test_product():
    import sys
    from ..utils import FormatCustomText
    from .. import tqdm
    from .._tqdm import tqdm

    # Test for no total size
    for x in product(range(3), repeat=3, tqdm_class=tqdm):
        pass

    # Test for total size
    for x in product(range(3), repeat=3, tqdm=tqdm):
        pass

    # Test for total size
    items = [[1], [2]]
    for x in product(items, repeat=3, tqdm=tqdm):
        pass

    # Check if total optional argument works properly
    for x in product(range(10), tqdm=tqdm, total=None):
        pass

    # Test for ascii bar

# Generated at 2022-06-22 05:04:19.555174
# Unit test for function product
def test_product():
    if __name__ == '__main__':
        x = product(range(10), range(1, 10), range(2, 10), tqdm_class=tqdm_auto)
        assert sum(c for a, b, c in x) == 19448
        x = product(range(2), range(1, 2), range(2, 3), tqdm_class=tqdm_auto)
        assert sum(c for a, b, c in x) == 3

test_product()

# Generated at 2022-06-22 05:04:31.386701
# Unit test for function product

# Generated at 2022-06-22 05:04:43.645604
# Unit test for function product
def test_product():
    """Test for the tqdm.itertools.product() function"""
    from pytest import approx

    # pylint: disable=cell-var-from-loop, undefined-loop-variable

    # from https://docs.python.org/2/library/itertools.html#itertools.product
    actual = []
    for i in tqdm.itertools.product('ABCD', 'xy'):
        actual.append(i)
    assert actual == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                      ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

    actual = []

# Generated at 2022-06-22 05:04:53.844076
# Unit test for function product
def test_product():
    from .tests.pylint import assert_iter_equal
    assert_iter_equal(product("ab", repeat=2), ["aa", "ab", "ba", "bb"])
    assert_iter_equal(product("abc", repeat=3), [
        "aaa", "aab", "aac", "aba", "abb", "abc", "aca", "acb", "acc",
        "baa", "bab", "bac", "bba", "bbb", "bbc", "bca", "bcb", "bcc",
        "caa", "cab", "cac", "cba", "cbb", "cbc", "cca", "ccb", "ccc",
    ])

# Generated at 2022-06-22 05:04:59.027122
# Unit test for function product
def test_product():
    """Test for function product."""
    from .tests import TestCase, closing

    class TestProduct(TestCase):
        """Test for function product."""
        def test_product(self):
            """Test for function product."""
            with closing(tqdm_auto()) as t:
                list(product(range(10), repeat=10, tqdm_class=tqdm_auto,
                             leave=True))

    # Run tests
    TestProduct().test_product()

# Generated at 2022-06-22 05:05:09.375416
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from math import factorial
    import numpy as np
    from ..auto import tqdm
    from ..utils import format_sizeof

    from .tests import TestCase

    class Tests(TestCase):
        def test_basics(self):
            for L in [1, 10, 100]:
                self.assertTrue(np.all(np.concatenate(itertools.product(
                    *([range(L)] * 5))) ==
                                       np.array(list(product(
                                           *([range(L)] * 5))))))

        def test_total(self):
            for L in [1, 10, 100]:
                with tqdm(total=L, ascii=True) as t:
                    self.assertTrue(t.total == L)

# Generated at 2022-06-22 05:05:20.651881
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    p = product(['a', 'b'], ['1', '2'], ['c', 'd'], tqdm_class=tqdm)
    assert list(p) == [('a', '1', 'c'), ('a', '1', 'd'),
                       ('a', '2', 'c'), ('a', '2', 'd'),
                       ('b', '1', 'c'), ('b', '1', 'd'),
                       ('b', '2', 'c'), ('b', '2', 'd')]

    p = product(['a', 'b'], ['1', '2'], ['c', 'd'], tqdm_class=tqdm, desc="Test")

# Generated at 2022-06-22 05:05:30.011060
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from copy import deepcopy

    class TqdmTypeError(Exception):
        pass

    class ErrorInUpdate(object):
        def __init__(self, *args, **kwargs):
            pass

        def update(self, *args, **kwargs):
            raise TqdmTypeError()

    class ErrorInClose(ErrorInUpdate):
        def close(self, *args, **kwargs):
            raise TqdmTypeError()

    class ErrorInClear(ErrorInUpdate):
        def __getattribute__(self, attr):
            if attr == "clear":
                raise TqdmTypeError()
            return super(ErrorInClear, self).__getattribute__(attr)


# Generated at 2022-06-22 05:05:35.451318
# Unit test for function product
def test_product():
    """Example of `tqdm.itertolls.product`"""
    from tqdm import trange
    for i in trange(4):
        for j in trange(4, leave=False):
            for k in trange(4, leave=False):
                assert i <= 3 and j <= 3 and k <= 3

# Generated at 2022-06-22 05:06:02.006129
# Unit test for function product
def test_product():
    '''
    Tests function product
    '''
    assert ([(i, j) for i, j in product(range(3), range(3),
                                        tqdm_class=PROG_CLASS)] ==
            [(i, j) for i, j in itertools.product(range(3), range(3))])

    assert ([(i, j) for i, j in product(range(3), range(4),
                                        tqdm_class=PROG_CLASS)] ==
            [(i, j) for i, j in itertools.product(range(3), range(4))])