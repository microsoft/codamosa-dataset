

# Generated at 2022-06-22 04:56:14.102919
# Unit test for function product
def test_product():
    import sys

    data = [tuple(range(2))] * 2
    stdout = sys.stdout
    try:
        from io import StringIO
        sys.stdout = StringIO()
        product(*data)
        assert sys.stdout.getvalue().startswith("2it [00:")
        assert sys.stdout.getvalue().endswith("\n")
    finally:
        sys.stdout = stdout

# Generated at 2022-06-22 04:56:16.778345
# Unit test for function product
def test_product():
    list(product(['a', 'b'], [1, 2], [True, False], tqdm_class=None))
    assert 1 == 1

# Generated at 2022-06-22 04:56:22.301511
# Unit test for function product
def test_product():
    """Test for function product"""
    import sys
    from . import _test_args
    if sys.version_info.major < 3:
        from .tests.tests_py2 import TestProduct
    else:
        from .tests.tests_py3 import TestProduct
    TestProduct().test_product()

# Generated at 2022-06-22 04:56:31.726540
# Unit test for function product
def test_product():
    import sys
    import io

    from .utils import _range

    # Simple test
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    assert list(product([1, 2])) == [(1,), (2,)]
    assert list(product(range(1))) == [(0,)]
    assert list(product([])) == [()]

    # Test total counter
    f = io.StringIO()
    t = tqdm_auto(unit='B', unit_scale=True, unit_divisor=1024, file=f)
    assert list(product([1, 2], total=t)) == [(1,), (2,)]
    assert t.n == 2

# Generated at 2022-06-22 04:56:38.046131
# Unit test for function product
def test_product():
    "Test the `tqdm.tqdm_itertools.product` wrapper"
    from .tqdm_gui import tqdm
    for _ in tqdm(itertools.product('ABC', 'xy'),
                  desc='product', leave=False, ascii=True):
        pass


# legacy
try:
    from tqdm import trange
except ImportError:
    pass
else:
    trange = tqdm_auto
    del tqdm

# Generated at 2022-06-22 04:56:42.104664
# Unit test for function product
def test_product():
    for a, b, c in product(range(1000), range(1000), range(1000)):
        assert (a, b, c) == (0, 0, 0)
        break

# Generated at 2022-06-22 04:56:54.051194
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy
    import math
    from ..tqdm_pandas import tqdm_pandas

    with tqdm_pandas(total=None) as pbar:  # Initialise pbar
        assert pbar.total is None

        a = numpy.array([2, 4])
        b = numpy.array([3, 5])
        c = numpy.array([7, 9, 1])
        with pbar.set_description("Numpy broadcast") as pbarNumpy:  # Initialise pbar
            for i in product(a, b, c, tqdm_class=pbarNumpy.__class__):
                pbarNumpy.update()
            assert pbarNumpy.total == 12

        d = [2, 4]

# Generated at 2022-06-22 04:57:03.456435
# Unit test for function product
def test_product():
    from . import trange
    from .utils import format_sizeof

    # First test without tqdm
    def no_tqdm_product(*iterables):
        return list(product(*iterables, tqdm_class=None))

    assert list(itertools.product('ABCD', 'xy')) == \
        no_tqdm_product('ABCD', 'xy')
    assert list(itertools.product(range(2), repeat=3)) == \
        no_tqdm_product(range(2), repeat=3)
    try:
        assert list(itertools.product(range(1000), repeat=10)) == \
            no_tqdm_product(range(1000), repeat=10)
    except MemoryError:
        pass  # Works fine unless no enough memory

    # Second test with t

# Generated at 2022-06-22 04:57:07.778505
# Unit test for function product
def test_product():
    """Test function."""
    from sys import version_info as py_version_info

# Generated at 2022-06-22 04:57:18.021061
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    from . import tnrange
    try:
        from numpy.random import randint
    except ImportError as e:
        NoneType = type(None)
        if not isinstance(e, NoneType):
            raise

        def randint(a, b):
            return random.randint(a, b)

    random.seed(3)
    a = [randint(0, 20) for _ in range(20)]
    b = [randint(0, 20) for _ in range(20)]
    c = [randint(0, 20) for _ in range(20)]
    d = [randint(0, 20) for _ in range(20)]

# Generated at 2022-06-22 04:57:31.117831
# Unit test for function product
def test_product():
    from os import path
    from ..utils import _range
    from ..utils import FormatWidgets
    from ..utils import Unicode
    from .utils import closing
    from .utils import IgnoreKeyboardInterrupt

    try:
        # Python 3
        from functools import reduce
    except ImportError:
        pass
    # Tests
    with closing(IgnoreKeyboardInterrupt()):
        with tqdm_auto(_range(20), desc="desc1", ncols=50,
                       bar_format="{desc}: {bar}") as t:
            for _ in t:
                pass

    with closing(IgnoreKeyboardInterrupt()):
        from .. import trange

# Generated at 2022-06-22 04:57:42.744463
# Unit test for function product
def test_product():
    """Test that the tqdm_imap is equivalent to the stdlib imap"""
    from random import randint, seed
    from itertools import chain, repeat, product
    seed(7)

    def rand_str():
        return ''.join(chr(randint(97, 97 + 25)) for x in range(randint(1, 6)))

    xs = [rand_str() for _ in range(randint(1, 8))]
    ys = [rand_str() for _ in range(randint(2, 3))]

    assert list(product(xs)) == list(product(xs, tqdm_class=tqdm_auto))
    assert list(product(xs, ys)) == list(product(xs, ys, tqdm_class=tqdm_auto))

# Generated at 2022-06-22 04:57:53.595483
# Unit test for function product
def test_product():
    from numpy import prod
    from . import trange
    from .utils import FormatMixin
    from .utils import _range

    class ProductTest(FormatMixin):
        def test(self):
            # Range of size 0
            it = product(range(0), range(3))
            self.assertRaises(StopIteration, next, it)
            # Range of size 1
            it = product(range(1), range(3))
            i = 0
            while True:
                try:
                    x, y = next(it)
                except StopIteration:
                    break
                self.assertEqual(x, 0)
                self.assertIn(y, (0, 1, 2))
                i += 1
                if i > 1000:
                    raise AssertionError("infinite loop suspected")
            self.assertEqual

# Generated at 2022-06-22 04:58:03.657663
# Unit test for function product
def test_product():
    from .tqdm import trange
    from .tests import pretest_posttest, closing

    # Check sizes when no output
    assert len(list(product(range(10), range(10), range(10)))) == 1000

    # Check that iterables are closed
    with closing(pretest_posttest()):
        list(product(pretest_posttest(), range(10), range(10)))

    # Check sizes with tqdm object
    assert len(list(product(range(10), range(10), range(10), tqdm_class=trange))) == 1000
    assert len(list(product(range(10), range(10), range(10), tqdm_class=trange, total=1000))) == 1000

    # Check sizes with tqdm iterator

# Generated at 2022-06-22 04:58:15.551844
# Unit test for function product
def test_product():
    from .iterables import RandomBytesIO
    from .utils import FormatMixin
    t = tqdm_auto(product(['abc', '123'], total=4))
    assert list(t) == list(itertools.product(['abc', '123']))
    assert t.dynamic_messages == ['a1', 'a2', 'a3', 'b1', 'b2', 'b3', 'c1', 'c2', 'c3']

    t = tqdm_auto(product(['abc', '123'], total=5), total=5)
    assert list(t) == list(itertools.product(['abc', '123']))

# Generated at 2022-06-22 04:58:27.476755
# Unit test for function product
def test_product():
    """
    Test for tqdm.itertools.product
    """
    from random import randint
    from ..utils import FormatCustomText
    # The function product() returns cartesian product, which means all
    # combinations of the input iterables. For example:
    try:
        from __builtin__ import xrange as range
    except ImportError:
        pass

    # Test a simple example, it should return the same result as
    # itertools.product
    res = list(product('ABCD', 'xy'))
    sol = list(itertools.product('ABCD', 'xy'))
    assert(res == sol)

    # Test the total variable
    res = list(product(range(2), range(2), range(2)))
    assert(len(res) == 8)

    # Test the custom text
   

# Generated at 2022-06-22 04:58:38.572200
# Unit test for function product
def test_product():
    import numpy as np
    test_data = "xyz"
    versions = [
        np.dtype(type(u'u')) == np.dtype('U1'),  # is unicode character
        np.dtype(type(b'b')) == np.dtype('S1'),  # is byte character
        np.dtype(type(b'b')) == np.dtype('S1') and
        np.dtype(type(u'u')) == np.dtype('U1')  # is byte and unicode
    ]
    ans = [[x, y, z] for x in test_data for y in test_data for z in test_data]

# Generated at 2022-06-22 04:58:49.558961
# Unit test for function product
def test_product():
    from .iterable import _measure_it
    from .main import tqdm, trange
    from .utils import _range

    iterable = [_range(5), _range(10), _range(100)]
    assert _measure_it(itertools.product(*iterable), 'itertools.product') == \
        _measure_it(product(*iterable, tqdm_class=tqdm), 'tqdm.itertools.product')

    iterable = [_range(5), _range(10), _range(100)]
    assert _measure_it(itertools.product(*iterable), 'itertools.product') == \
        _measure_it(product(*iterable, tqdm_class=trange), 'tqdm.itertools.product')

# Generated at 2022-06-22 04:58:59.772606
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from six import StringIO
    from sys import stderr
    kwargs = {"samples": list(range(3))}
    with StringIO() as our_file:
        with FormatCustomText(file=our_file):
            for _ in product(**kwargs):
                pass
        our_out = our_file.getvalue()
    with StringIO() as std_file:
        with FormatCustomText(file=std_file):
            for _ in itertools.product(**kwargs):
                pass
        std_out = std_file.getvalue()
    assert our_out == std_out

# Generated at 2022-06-22 04:59:07.294354
# Unit test for function product
def test_product():
    """Test product"""
    from .tests import RandomDict

    # test_product_with_total
    total = 0
    for _ in tqdm.product(
            *(RandomDict(abs(i)) for i in range(3)),
            tqdm_class=tqdm.tqdm,
            total=8, miniters=1):
        total += 1
    assert total == 8

    # test_product_without_total
    total = 0
    for v in tqdm.product(
            *(RandomDict(abs(i)) for i in range(3)),
            tqdm_class=tqdm.tqdm,
            total=None, miniters=1):
        total += 1
        assert not isinstance(v, tqdm.tqdm_obj)
    assert total

# Generated at 2022-06-22 04:59:20.363737
# Unit test for function product
def test_product():
    try:
        a = [1, 2, 3]
        b = [10, 20, 30]
        c = [100, 200, 300]
        abcs = list(product(a, b, c))
        assert (3 * 3 * 3 == len(abcs))
    except ImportError:
        pass
    else:
        from . import tqdm_gui
        from .._tqdm import trange
        for _ in [trange, tqdm_gui]:
            abcs = list(_(product(a, b, c)))[0]
            assert (3 * 3 * 3 == len(abcs))

# Generated at 2022-06-22 04:59:23.841854
# Unit test for function product
def test_product():
    import numpy as np
    l = np.arange(20)
    np.testing.assert_array_equal(
        list(product(l, l, tqdm_class=None)), list(itertools.product(l, l)))

# Generated at 2022-06-22 04:59:27.503550
# Unit test for function product
def test_product():
    import numpy
    # Very basic smoke test
    assert numpy.array_equal(list(product("ABCD", repeat=2)),
                             list(itertools.product("ABCD", repeat=2)))


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)
    test_product()

# Generated at 2022-06-22 04:59:38.320992
# Unit test for function product
def test_product():
    """
    Unit tests for function product
    """
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))
    assert list(product(range(3), range(3), tqdm_class=None)) == list(itertools.product(range(3), range(3)))
    assert list(product(range(3), range(3), tqdm_class=tqdm_auto)) == list(itertools.product(range(3), range(3)))
    assert list(product(range(3), range(3), tqdm_class=lambda x: x)) == list(itertools.product(range(3), range(3)))

# Generated at 2022-06-22 04:59:47.624486
# Unit test for function product
def test_product():
    '''
    Test for `product`
    '''
    import numpy as np

    # Default
    with tqdm_auto(unit='B', unit_scale=True, miniters=1,
                   mininterval=0.1, ascii=True) as t:
        for i in product(range(5), range(5), tqdm_class=tqdm_auto):
            pass
    assert t.n == 25

    # ascii=False
    with tqdm_auto(unit='B', unit_scale=True, miniters=1,
                   mininterval=0.1, ascii=False) as t:
        for i in product(range(5), range(5), tqdm_class=tqdm_auto):
            pass
    assert t.n == 25

   

# Generated at 2022-06-22 04:59:49.449136
# Unit test for function product
def test_product():
    for i in product(range(7000)):
        pass


# Generated at 2022-06-22 05:00:00.955749
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from .utils import FormatCustomText
    from .tqdm_pandas import tqdm_pandas

    import numpy as np
    n = 10
    a = range(n)
    b = a[::-1]
    c = a[:]
    d = np.arange(n) * 1.  # Will trigger error if range() used

    assert list(product(a, b)) == [(i, j) for i, j in zip(a, b)]

    with tqdm_pandas(total=n * n * n) as pbar:
        def func(df):
            pbar.update()
            return df.shape

# Generated at 2022-06-22 05:00:12.843584
# Unit test for function product
def test_product():
    """
    Because this is a wrapper for a standard library function, tests for
    correct functionality are not included.
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .tqdm_gui import tqdm

    FormatMixin._instances.clear()

# Generated at 2022-06-22 05:00:23.180271
# Unit test for function product
def test_product():  # pragma: no cover
    from ._utils import _range

    # Test that len(p) == len(range(...) ** len(range(...)))
    for i in range(1, 7):
        l = list(_range(i))
        assert sum(1 for _ in product(*l)) == len(_range(_range.size ** i))

    # Test that len(p) == len(range(1000) ** len(range(1000)))
    l = list(_range(_range.size))
    assert sum(1 for _ in product(*l)) == len(_range(_range.size ** _range.size))

# Generated at 2022-06-22 05:00:31.927671
# Unit test for function product
def test_product():
    """Test product wrapper"""
    import random
    import string
    import sys
    import io
    if sys.version > "3":
        from io import StringIO
        unicode_type = str
    else:
        from io import BytesIO as StringIO
        unicode_type = unicode

    orig_stdout = sys.stdout  # Save stdout
    orig_stderr = sys.stderr  # Save stderr

    # Redirect stdout & stderr to StringIO
    sys.stdout = stdout = StringIO()
    sys.stderr = stderr = StringIO()

    from .main import trange
    from .tdqm import tqdm


# Generated at 2022-06-22 05:00:43.611212
# Unit test for function product
def test_product():
    import numpy as np
    n = 10
    m = 20
    assert (
        list(map(sum, product(range(n), range(m)))) ==
        list(map(sum, itertools.product(range(n), range(m)))) ==
        list(np.arange(2).T.dot(np.array([n, m])))
    )

# Generated at 2022-06-22 05:00:50.001263
# Unit test for function product
def test_product():
    try:
        iterable_0 = range(5)
        iterable_1 = range(10)
        iterable_2 = range(15)
        list(product(iterable_0, iterable_1, iterable_2))
    except:
        raise

# Generated at 2022-06-22 05:00:59.245564
# Unit test for function product
def test_product():
    import nose.tools as nt

    @nt.nottest  # pragma: no cover
    def assert_equal_len(a, b):
        assert len(a) == len(b)

    iterables = range(10), range(10), range(10)
    assert_equal_len(
        list(itertools.product(*iterables)),
        list(product(*iterables, tqdm_class=lambda x: x, leave=True))
    )
    iterables = (range(i) for i in range(1, 11))
    assert_equal_len(
        list(itertools.product(*iterables)),
        list(product(*iterables, tqdm_class=lambda x: x, leave=True))
    )

# Generated at 2022-06-22 05:01:02.813793
# Unit test for function product
def test_product():
    from numpy import product

    r = sum(product((range(1000), range(1000), range(1000))))
    t = sum(tqdm_auto.product((range(1000), range(1000), range(1000))))
    assert(r == t)

# Generated at 2022-06-22 05:01:14.839381
# Unit test for function product
def test_product():
    assert list(product(range(4), range(4))) == list(itertools.product(range(4), range(4)))

    class Stdout(object):
        def __init__(self):
            self.stdout = []

        def write(self, s):
            self.stdout += [s]

        def __enter__(self):
            return self

        def __exit__(self, *_):
            pass

    with Stdout() as s:
        list(product(range(6), range(6), tqdm_class=tqdm_auto, file=s))
    assert "6/6" in "".join(s.stdout)

    with Stdout() as s:
        list(product(range(6), range(6), file=s))

# Generated at 2022-06-22 05:01:25.887353
# Unit test for function product
def test_product():
    assert (list(product(range(2), repeat=2)) ==
            list(itertools.product(range(2), repeat=2)))
    assert (list(product([-1, 1], [-2, 2], repeat=2)) ==
            list(itertools.product([-1, 1], [-2, 2], repeat=2)))
    assert (list(product([-1, 1], [-2, 2], [-3, 3], repeat=2)) ==
            list(itertools.product([-1, 1], [-2, 2], [-3, 3], repeat=2)))
    assert (list(product(range(5))) == list(itertools.product(range(5))))
    assert (list(product(range(5), repeat=1)) ==
            list(itertools.product(range(5), repeat=1)))


# Generated at 2022-06-22 05:01:31.445133
# Unit test for function product
def test_product():
    """
    Unit test for function `product`
    """
    # In python3, map always returns a generator, so we need to check is
    # iterable.
    expected_result = "012345"
    result = ""
    for i in product(range(3), range(3), tqdm_class=tqdm_auto):
        result += str(i[0])
        result += str(i[1])
    assert result == expected_result

# Generated at 2022-06-22 05:01:36.424867
# Unit test for function product
def test_product():
    from numpy import prod
    import numpy as np
    for n in [1, 10, 100]:
        iterables = (["a", "b"], list(range(n)))
        assert np.all(list(product(*iterables, total=prod(map(len, iterables)))) ==
                      list(itertools.product(*iterables)))

# Generated at 2022-06-22 05:01:43.938615
# Unit test for function product
def test_product():
    """Test that product wrapper behaves identically to its iterable"""
    def generator(x):
        for i in range(x):
            yield i

    def list_generator(x):
        for i in range(x):
            yield list(range(x))

    # A generator is an iterable, not an iterator
    assert hasattr(generator(5), '__next__')
    assert not hasattr(generator(5), '__iter__')
    assert hasattr(itertools.product(generator(5)), '__iter__')
    assert hasattr(itertools.product(generator(5)), '__next__')
    a = itertools.product(generator(5))
    a_ = product(generator(5))
    assert a.__next__() == a_.__next__()

    # nested

# Generated at 2022-06-22 05:01:55.632226
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    a = []
    assert list(product(['a', 'b'], repeat=2)) == [('a', 'a'), ('a', 'b'),
                                                   ('b', 'a'), ('b', 'b')]
    assert list(product(['a', 'b'], repeat=1)) == [('a',), ('b',)]
    assert list(product(['a', 'b'], repeat=0)) == [()]
    assert list(product(a)) == []
    assert list(product(a, a)) == []
    assert list(product(a, ['a'])) == []
    assert list(product(['a'], a)) == []

# Generated at 2022-06-22 05:03:08.300992
# Unit test for function product
def test_product():
    from . import trange

    total = 0
    for i, j in product(range(5), range(5)):
        total += 1

    total2 = 0
    for i, j in product(trange(5), range(5)):
        total2 += 1

    assert total == total2


if __name__ == "__main__":
    tt = test_product()

# Generated at 2022-06-22 05:03:20.369439
# Unit test for function product
def test_product():
    """Test that `tqdm_class.product` has same output as `itertools.product`"""
    import pytest
    # Empty
    assert list(product(tqdm_class=tqdm_auto, iterable=range(0), repeat=2)) == \
           list(itertools.product(range(0), repeat=2))
    # One item
    assert list(product(tqdm_class=tqdm_auto, iterable=range(1), repeat=2)) == \
           list(itertools.product(range(1), repeat=2))
    # Two items
    assert list(product(tqdm_class=tqdm_auto, iterable=range(2), repeat=2)) == \
           list(itertools.product(range(2), repeat=2))
    # Terminals

# Generated at 2022-06-22 05:03:26.558009
# Unit test for function product
def test_product():
    """Test function `product`"""
    from sys import version_info

    assert any(list(product(range(3), "ABC")))
    assert any(list(product(range(3), "ABC", total=9)))
    assert all(
        list(product(range(10), range(10), tqdm_class=tqdm_auto.tqdm_gui))
    )
    if version_info >= (3,):
        assert all(list(product(range(10), range(10), tqdm_class=tqdm_auto.tqdm)))

# Generated at 2022-06-22 05:03:37.475729
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    # pylint: disable=no-member
    assert list(product([1, 2, 3], ['a', 'b', 'c'], tqdm_class=tqdm_auto)) \
        == [(1, 'a'), (1, 'b'), (1, 'c'),
            (2, 'a'), (2, 'b'), (2, 'c'),
            (3, 'a'), (3, 'b'), (3, 'c')]

# Generated at 2022-06-22 05:03:49.529705
# Unit test for function product
def test_product():
    from .tests import TestCase, closing, nested_helper, namedtuple
    N = 3
    M = 4
    A = ['a']*N
    B = ['b']*M
    C = ['c']*N*M
    with closing(TestCase()) as tc, closing(
            TestCase()) as ntc:
        with tqdm_auto(A) as t:
            for i in product(t):
                tc('', i)
                continue
        with tqdm_auto(B) as t:
            for i in product(t):
                tc('', i)
                continue
        with tqdm_auto(A) as a, tqdm_auto(B) as b:
            for i, j in product(a, b):
                ntc('', i, j)
                continue

# Generated at 2022-06-22 05:04:00.616139
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    total = 1
    for n in range(2, 10):
        total *= n

    loop_range = range(2, 10)
    # Test against itertools.product
    assert(sum(1 for _ in product(*loop_range)) == total)
    assert(sum(1 for _ in product(*loop_range, tqdm_class=False)) == total)
    assert(sum(1 for _ in product(*loop_range, tqdm_class=tqdm_auto)) == total)
    # Test tqdm_class must be tqdm or False
    try:
        sum(1 for _ in product(*loop_range, tqdm_class=None))
    except TypeError:
        pass
    else:
        assert(False)

# Generated at 2022-06-22 05:04:05.119104
# Unit test for function product
def test_product():
    """ test the product function """
    # run the product function
    for _ in product(*[[1, 2], [3, 4]], tqdm_class=tqdm_auto):
        pass
    # run the product function with a string argument
    for _ in product(*[["1", "2"], ["3", "4"]], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 05:04:12.448310
# Unit test for function product
def test_product():
    """
    Unit tests for `product`.
    """
    from ..utils import _range
    assert sum(1 for _ in product([], [], [], [])) == 0
    assert sum(1 for _ in product(_range(5), _range(5))) == 25
    assert list(product([], [], [], [])) == []
    assert list(product(_range(5), _range(5))) == \
        [(x, y) for x in _range(5) for y in _range(5)]

# Generated at 2022-06-22 05:04:17.309918
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal

    array = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    result = []
    for i in product(*array, tqdm_class=tqdm_auto):
        result.append(i)
    assert_array_equal(result, list(itertools.product(*array)))

# Generated at 2022-06-22 05:04:22.840154
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import FormatWrapBase

    class FormatWrap(FormatWrapBase):
        prefix = 'Xy'
        line_format = "{prefix}_format"

    with FormatWrap() as f:
        for _ in product(np.arange(10), np.arange(0, 5, 0.5), range(0, 2),
                         tqdm_class=tqdm_auto):
            pass
    assert f.prefixes == ['Xy'] * 20
    assert f.line_formats == ['Xy_format'] * 20