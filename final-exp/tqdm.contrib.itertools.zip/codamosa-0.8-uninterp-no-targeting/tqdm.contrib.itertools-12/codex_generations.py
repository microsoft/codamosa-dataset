

# Generated at 2022-06-22 04:56:14.104603
# Unit test for function product

# Generated at 2022-06-22 04:56:21.615096
# Unit test for function product
def test_product():
    """ Unit test for function product """
    from .tests import TestCase

    class ProductTest(TestCase):
        def test_product(self):
            """
            Unit test for function product
            """
            with tqdm_auto(desc='Calculating') as t:
                for i in product(tqdm_auto(range(10)), tqdm_auto(range(10))):
                    t.update()

    inner_main('product() test', ProductTest)

# Generated at 2022-06-22 04:56:26.302820
# Unit test for function product
def test_product():
    """Unit test for function product"""
    try:
        assert next(product([1], [2], tqdm_class=tqdm_auto)) == (1, 2)
    except AssertionError:
        next(product([1], [2], tqdm_class=tqdm_auto))  # pragma: no cover

# Generated at 2022-06-22 04:56:37.748669
# Unit test for function product
def test_product():
    from ..tqdm import trange

# Generated at 2022-06-22 04:56:42.237881
# Unit test for function product
def test_product():
    from itertools import product as _product
    from numpy.random import randint
    N = 7
    for i in range(1000):
        a, b, c = [list(randint(0, 100, size=randint(1, N+1)))
                   for j in range(3)]
        assert list(product(a, b, c)) == list(_product(a, b, c))

# Generated at 2022-06-22 04:56:48.658063
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Disclaimer: I'm not sure this is really a unit test but I couldn't find
    #             a better way to test this atm.
    from ..auto import tqdm
    # First test that it works at all
    list(product(range(10), range(10), tqdm_class=tqdm))
    # Then test that it works with the defaults
    list(product(range(10), range(10)))

# Generated at 2022-06-22 04:56:54.378477
# Unit test for function product
def test_product():
    from numpy.testing import assert_approx_equal
    for n in range(10):
        for m in range(10):
            l = []
            for i, v in product(list(range(n)), list(range(m))):
                l.append(v)
            assert_approx_equal(n * m, len(l))

# Generated at 2022-06-22 04:57:01.943090
# Unit test for function product
def test_product():
    from itertools import product

    # Create iterables
    x = list(range(10))
    y = list(range(10))
    z = list(range(10))
    p = list(product(x, y, z))

    # No tqdm
    xyz = list(product(x, y, z))
    assert xyz == p

    # With tqdm
    xyz = list(product(x, y, z, tqdm_class=tqdm_auto))
    assert xyz == p

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:57:06.120935
# Unit test for function product
def test_product():
    from .tests import test_product as _test_product
    _test_product(product)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 04:57:16.590582
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup
    from .tests_tqdm import PretendPager, DiscreteTimer

    with with_setup(PretendPager().__enter__, PretendPager().__exit__):
        with with_setup(DiscreteTimer().__enter__, DiscreteTimer().__exit__):
            for i in product("ABC", "123", tqdm_class=tqdm_auto):
                pass
    with with_setup(PretendPager().__enter__, PretendPager().__exit__):
        with with_setup(DiscreteTimer().__enter__, DiscreteTimer().__exit__):
            i = product("ABC", "123", tqdm_class=tqdm_auto)
            next(i)

# Generated at 2022-06-22 04:57:23.661135
# Unit test for function product
def test_product():
    from .tqdm import tqdm
    for kw in ({}, dict(tqdm_class=tqdm)):
        for e in (1, 2, 10):
            assert sum(1 for _ in product(range(e), **kw)) == e ** 2

# Generated at 2022-06-22 04:57:31.436311
# Unit test for function product
def test_product():
    from .base import TestBaseNoBar

    class TestProduct(TestBaseNoBar):
        """
        Unit test for function product
        """
        def test_product_basic(self):
            """
            Test product basic
            """
            actual = list(product(range(3), repeat=2))
            self.assertEqual(actual, [(0, 0), (0, 1), (0, 2),
                                      (1, 0), (1, 1), (1, 2),
                                      (2, 0), (2, 1), (2, 2)])

    test_product = TestProduct()
    test_product.test_product_basic()

# Generated at 2022-06-22 04:57:42.500509
# Unit test for function product
def test_product():
    iproduct = product("ABCD", "xy", tqdm_class=None)
    assert list(iproduct) == [('A', 'x'), ('A', 'y'), ('B', 'x'),
                              ('B', 'y'), ('C', 'x'), ('C', 'y'),
                              ('D', 'x'), ('D', 'y')]

    iproduct = product("ABCD", "xy", tqdm_class=tqdm_auto)
    assert list(iproduct) == [('A', 'x'), ('A', 'y'), ('B', 'x'),
                              ('B', 'y'), ('C', 'x'), ('C', 'y'),
                              ('D', 'x'), ('D', 'y')]

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:57:47.133263
# Unit test for function product
def test_product():
    """ Test function product """
    from ._utils import _range
    assert list(product(_range(3), "ab")) == [
        (0, "a"), (0, "b"), (1, "a"), (1, "b"), (2, "a"), (2, "b")]

# Generated at 2022-06-22 04:57:54.680361
# Unit test for function product
def test_product():
    try:
        from itertools import product as itertools_product
    except ImportError:
        pass
    else:
        assert list(product([1], [2], [3])) == list(itertools_product([1], [2], [3]))
        assert list(product([1], [2], [3], [4], [5], [6], [7], [8], [9])) == list(itertools_product([1], [2], [3], [4], [5], [6], [7], [8], [9]))

if __name__ == '__main__':
    from . import __main__; __main__._test()

# Generated at 2022-06-22 04:58:05.147943
# Unit test for function product
def test_product():
    """Tests `itertools_recipes.product`"""
    # These exist to be imported by nosetests
    # pylint: disable=unused-variable
    from ..utils import format_sizeof
    # pylint: enable=unused-variable
    from ctypes import c_char_p as cstr

    from nose.tools import assert_equal
    from six.moves import range
    from sys import getsizeof

    for get_len in [None, list]:
        for M in range(1, 5):  # pylint: disable=unused-variable
            with tqdm_auto(disable=None) as t:
                itr = product(range(3), repeat=M, get_len=get_len)
                res = [i for i in itr]

# Generated at 2022-06-22 04:58:12.683412
# Unit test for function product
def test_product():
    assert list(product(range(3), 'ab', (0,1))) == [
        (0, 'a', 0), (0, 'a', 1), (0, 'b', 0), (0, 'b', 1),
        (1, 'a', 0), (1, 'a', 1), (1, 'b', 0), (1, 'b', 1),
        (2, 'a', 0), (2, 'a', 1), (2, 'b', 0), (2, 'b', 1)]

# Generated at 2022-06-22 04:58:24.177160
# Unit test for function product
def test_product():
    import sys
    import pytest
    import numpy as np
    with pytest.raises(Exception):
        product(range(3), range(3), [1, 2], tqdm_class=None)
    with pytest.raises(Exception):
        product(2)
    assert list(product([1, 2], repeat=3)) == [
        (1, 1, 1), (1, 1, 2), (1, 2, 1), (1, 2, 2), (2, 1, 1), (2, 1, 2),
        (2, 2, 1), (2, 2, 2)]

# Generated at 2022-06-22 04:58:28.101519
# Unit test for function product
def test_product():
    """Unit test for function product"""
    with tqdm_auto(total=1 * 2 * 3 * 4) as pbar:
        for _ in product(range(1), range(2), range(3), range(4)):
            pbar.update()

# Generated at 2022-06-22 04:58:35.780539
# Unit test for function product
def test_product():
    import sys
    try:
        from .._tqdm import main_protected
        from .._tqdm_pandas import main_protected as main_protected_pandas
    except ImportError:  # pragma: no cover
        print("Skipping test_product: _tqdm and/or _tqdm_pandas import failed"
              " (tqdm is not a package?)", file=sys.stderr)
        return

# Generated at 2022-06-22 04:58:46.307698
# Unit test for function product
def test_product():
    """Test product"""
    from random import randint
    N = randint(1, 9)
    M = randint(1, 9)
    for _ in product(range(N), range(M)):
        pass
    for _ in product(range(N), range(M), tqdm_class=tqdm_auto.tqdm):
        pass

# Generated at 2022-06-22 04:58:48.485624
# Unit test for function product
def test_product():
    x = list(product(range(10), range(10)))
    assert x == list(itertools.product(range(10), range(10)))

# Generated at 2022-06-22 04:58:52.352385
# Unit test for function product
def test_product():
    """
    Total should be the product of the iterable lens
    """
    from ..deque import tqdm
    lens = [1, 2, 3]
    for i in product(
            *[range(j) for j in lens], tqdm_class=tqdm, miniters=1):
        r = 1
        for j in range(len(lens)):
            r *= i[j]
        assert r == sum(lens)

# Generated at 2022-06-22 04:58:54.940453
# Unit test for function product
def test_product():
    x = product('ABCD', 'xy')
    assert next(x) == ('A', 'x')

# Generated at 2022-06-22 04:59:04.701005
# Unit test for function product
def test_product():
    """
    Test to check if the product wrapper is performing well
    """
    assert [i for i in product(range(1), range(1), tqdm_class=tqdm_auto.tqdm)] == [(0, 0)]

# Generated at 2022-06-22 04:59:08.965403
# Unit test for function product
def test_product():
    """ Unit test for function product """
    a = [1, 2, 3]
    b = ['a', 'b', 'c']

    # Check count
    i = 0
    for c in product(a, b):
        i += 1

    assert i == 9

    # Check count (with added kwargs)
    i = 0
    for c in product(a, b, total=9):
        i += 1

    assert i == 9

# Generated at 2022-06-22 04:59:18.966132
# Unit test for function product
def test_product():
    """
    Tests `tqdm.itertools.product`.
    """
    from ..utils import FormatCustomText, format_sizeof
    from ..tests import pretest_posttest_mock as mocked
    import os

    # closed-range diagonal (not in itertools)
    it = product(range(10), repeat=2)
    for _ in range(10):
        next(it)
    out1 = mocked.stdout.getvalue()
    it = product(range(10), repeat=2)
    for _ in tqdm(it):
        pass
    out2 = mocked.stdout.getvalue()[len(out1):]
    assert out1 == out2, (repr(out1), repr(out2))

    # open-range with total

# Generated at 2022-06-22 04:59:30.147069
# Unit test for function product
def test_product():
    import subprocess
    import sys
    import time
    time.sleep(1)
    args = sys.argv[:] + ['--unit-test']
    p = subprocess.Popen(args, stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)
    output = p.communicate()[0].decode('utf-8')
    for i in output.split('\n'):
        if '100.0%' in i and '\x1b[' not in i:
            return
    raise AssertionError("Unit test for function `product` failed!")



# Generated at 2022-06-22 04:59:32.074385
# Unit test for function product
def test_product():
    for i in product(range(20), range(20), tqdm_class=tqdm_auto):
        continue

# Generated at 2022-06-22 04:59:41.892537
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, pretest, posttest, with_docstring
    from tqdm.utils import _range
    from random import randint

    @with_setup(pretest, posttest)
    def wrapper():
        for t in _range(10):
            iterables = [tuple(randint(0, 10) for _ in _range(t))
                         for _ in _range(randint(1, 5))]
            yield lambda: assert_equals(
                list(product(*iterables)),
                list(itertools.product(*iterables)))

    with_docstring(product, wrapper)

# Generated at 2022-06-22 05:00:02.364905
# Unit test for function product
def test_product():
    import random
    import itertools
    import pytest
    from ..utils import _range
    from ..tqdm_gui import trange

    assert len(list(product(_range(10)))) == 10
    assert len(list(product(_range(10)))) == 10
    assert len(list(product(_range(10), _range(10)))) == 100
    assert len(list(product(_range(10), _range(10)))) == 100

    assert sum(1 for _ in product(_range(10))) == 10
    assert sum(1 for _ in product(_range(10))) == 10
    assert sum(1 for _ in product(_range(10), _range(10))) == 100
    assert sum(1 for _ in product(_range(10), _range(10))) == 100


# Generated at 2022-06-22 05:00:13.794425
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], iter('ab'))) == [
        (1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]

    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    assert list(product([1, 2, 3], repeat=2)) == [
        (1, 1), (1, 2), (1, 3),
        (2, 1),
        (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]


if __name__ == "__main__":
    from .utils import _test
    _test()

# Generated at 2022-06-22 05:00:25.624756
# Unit test for function product
def test_product():
    from .tests import closing, FakeIO
    from .utils import format_sizeof
    from .trange import trange
    from .tqdm import tqdm

    def _test(iterable):
        for i in product(iterable):
            pass

    for iterable in ["asdf", [1, 2, 3], {}]:
        _test(iterable)

    with closing(FakeIO()) as our_file:
        with tqdm(product([1, 2, 3])) as t:
            for i in trange(t, len(t), file=our_file):
                pass


# Generated at 2022-06-22 05:00:29.328883
# Unit test for function product
def test_product():  # pragma: no cover
    import sys
    from .tqdm_gui import tqdm
    for i in product('abcd', '1234', tqdm=tqdm, ascii=True,
                     file=sys.stdout):
        pass

# Generated at 2022-06-22 05:00:30.881315
# Unit test for function product
def test_product():
    from .generate_tests import gen_test_product
    gen_test_product(product)

# Generated at 2022-06-22 05:00:42.254823
# Unit test for function product
def test_product():
    """Test for function product."""
    from .utils import _range

    for A in (range, _range):
        for total in (3, None):
            gen = product(A(3), A(3), tqdm_class=tqdm_auto, total=total)
            assert next(gen) == (0, 0)
            assert next(gen) == (0, 1)
            assert next(gen) == (0, 2)
            assert next(gen) == (1, 0)
            assert next(gen) == (1, 1)
            assert next(gen) == (1, 2)
            assert next(gen) == (2, 0)
            assert next(gen) == (2, 1)
            assert next(gen) == (2, 2)

# Generated at 2022-06-22 05:00:47.587411
# Unit test for function product
def test_product():
    for i in product(range(3), range(3), range(3)):
        pass
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 05:00:58.761635
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from random import randrange

    # Unit test for simple use
    for _ in product(range(2), repeat=2):  # NOQA
        pass

    # Ensure can handle sizes > sys.maxsize
    total = 0
    for _ in product(range(2), repeat=(1 << 64 - 1)):  # NOQA
        total += 1
    assert total == 1, total

    # Ensure can handle partial lengths
    try:
        for _ in product([], range(2)):  # NOQA
            pass
    except TypeError:
        pass

    # Unit test for keyword arguments
    sz = [10, 50, 100, 500, 1000, 5000, 10000, 50000, 100000, 500000, 1000000]
   

# Generated at 2022-06-22 05:01:01.781989
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    for iterable in [
            [1, 2, 3],
            (1, 2, 3),
            range(3)
            ]:
        list(product(iterable))

# Generated at 2022-06-22 05:01:07.223361
# Unit test for function product
def test_product():
    from ..utils import get_tqdm_class
    tqdm_class = get_tqdm_class()
    result = list(product(range(6), tqdm_class=tqdm_class))
    assert result == list(itertools.product(range(6)))

# Generated at 2022-06-22 05:01:30.265469
# Unit test for function product
def test_product():
    from .tqdm import trange
    assert list(product([1, 2, 3], repeat=2)) == list(
        trange(1, 3, desc='product', leave=False))

# Generated at 2022-06-22 05:01:35.701627
# Unit test for function product
def test_product():
    from .tqdm import trange
    L = list(product(trange(100), trange(100)))
    assert len(L) == 10000
    # The same, but now with only 1 tqdm instance:
    L = list(product(trange(100), trange(100), tqdm_class=trange))
    assert len(L) == 10000

# Generated at 2022-06-22 05:01:46.123256
# Unit test for function product
def test_product():
    """
    Test that equivalent of `itertools.product` works
    """
    import sys
    import io
    import inspect
    import contextlib
    with contextlib.redirect_stdout(io.StringIO()):
        iterables = [[0, 1], [0, 1], [0, 1]]
        iterator = product(*iterables, tqdm_class=tqdm_auto)

        assert hasattr(iterator, '__iter__')
        assert hasattr(iterator, '__next__')
        assert inspect.isgenerator(iterator)
        assert sys.version_info.major < 3 or inspect.isgenerator(iterator) is \
               False  # Python 3 is not a generator

        assert list(iterator) == [list(i) for i in itertools.product(*iterables)]

# Generated at 2022-06-22 05:01:56.514631
# Unit test for function product
def test_product():
    from .utils import TestCase, nonda
    class Testproduct(TestCase):
        def test_product_returns_correct_result(self):
            iterables = [
                (1, 2, 3),
                (4, 5),
                (6, 7),
                (8, 9, 10),
                [11, 12, 13, 14]
            ]
            expected = list(itertools.product(*iterables))
            result = list(product(*iterables, tqdm_class=nonda))
            self.assertEqual(result, expected)
    t = Testproduct()
    t.test_product_returns_correct_result()

# Generated at 2022-06-22 05:02:04.162404
# Unit test for function product
def test_product():
    import numpy as np
    A = itertools.product([1,2,3], [10,11], [21,22,23])
    assert list(A) == [(1, 10, 21), (1, 10, 22), (1, 10, 23),
                       (1, 11, 21), (1, 11, 22), (1, 11, 23),
                       (2, 10, 21), (2, 10, 22), (2, 10, 23),
                       (2, 11, 21), (2, 11, 22), (2, 11, 23),
                       (3, 10, 21), (3, 10, 22), (3, 10, 23),
                       (3, 11, 21), (3, 11, 22), (3, 11, 23)]


# Generated at 2022-06-22 05:02:09.532341
# Unit test for function product
def test_product():
    """Unit test for product"""
    # Test with tqdm
    assert list(product(range(3), range(4), tqdm_class=tqdm_auto)) == \
        list(itertools.product(range(3), range(4)))

    # Test with tqdm_gui
    try:
        import tqdm.gui as tqdm_gui
        assert list(product(range(3), range(4), tqdm_class=tqdm_gui.tqdm)) == \
            list(itertools.product(range(3), range(4)))
    except ImportError:
        pass

    # Test with tqdm_notebook

# Generated at 2022-06-22 05:02:17.380284
# Unit test for function product
def test_product():
    try:
        import numpy as np
    except ImportError:
        pass
    else:
        for test in [
                ("x", "ab", "123"),
                ("x", "ab"),
                ("x", "a", "b"),
                ("a", "b", "c"),
                ("a", "b", "c", "d"),
                ("a", "b", "c", "d", "e"),
                ("a", "b", "c", "d", "e", "f"),
                ("a", "b", "c", "d", "e", "f", "g")]:
            assert np.all(
                [i in set(product(*test))
                 for i in itertools.product(*test)])



# Generated at 2022-06-22 05:02:30.008142
# Unit test for function product
def test_product():
    import sys
    import numpy as np
    from numpy.testing import assert_equal
    from .utils import StringIO

    def test_product_with_tqdm(tqdm_cls):
        with StringIO() as our_file:
            for _ in tqdm_cls(product("ABC", "DEF", "GHI"), file=our_file):
                pass
            our_file.seek(0)
            s = our_file.read()

# Generated at 2022-06-22 05:02:39.773285
# Unit test for function product
def test_product():
    import numpy as np

    a = np.arange(10)
    b = np.arange(10, 20)
    c = np.arange(20, 30)

    def linear_product(a, b, c):
        res = []
        for i in a:
            for j in b:
                for k in c:
                    res.append((i, j, k))
        return res

    assert list(product(a, b, c)) == linear_product(a, b, c)
    assert list(product(a, b, c, tqdm_class=None)) == linear_product(a, b, c)

# Generated at 2022-06-22 05:02:46.119604
# Unit test for function product
def test_product():
    from math import ceil
    from ..utils import FormatCustomText
    iterables = [
        [1, 2, 3, 4, 5],
        ["a", "b", "c", "d", "e"],
        [1.0, 2.5, 0.5, 0.25, 0.75]
    ]
    for iterable in iterables:
        for n in range(len(iterable)):
            total = None
            with tqdm_auto(
                    iterable,
                    leave=False,
                    miniters=len(iterable),
                    mininterval=0,
                    dynamic_ncols=True,
                    file=open(os.devnull, "w")) as t:
                total = int(ceil(t.total / t.miniters))

# Generated at 2022-06-22 05:03:01.306039
# Unit test for function product
def test_product():
    """Test product() with the builtin iterables"""
    expected = [(0, 'a'), (0, 'b'), (1, 'a'), (1, 'b'),
                (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]
    assert list(product(range(4), 'ab')) == expected

# Generated at 2022-06-22 05:03:10.210970
# Unit test for function product
def test_product():
    """Unit test for function product"""
    a = '123'
    b = 'abc'
    c = 'xyz'
    prod = product(a, b, c)  # NOQA

# Generated at 2022-06-22 05:03:14.579304
# Unit test for function product
def test_product():
    from . import _test_it
    _test_it(itertools.product, "product", **test_kwargs())
test_product.timer = 3


if __name__ == '__main__':
    _test()

# Generated at 2022-06-22 05:03:25.288622
# Unit test for function product
def test_product():
    from ..tests import _make_dummy_iterable
    assert list(product("ABCD", "xy")) == [
        ('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]
    a = list(range(50000))
    with tqdm_auto(range(5)) as t:
        assert list(product(a, repeat=5, tqdm_class=t.__class__)) == list(itertools.product(a, repeat=5))

# Generated at 2022-06-22 05:03:36.088374
# Unit test for function product
def test_product():
    """
    Usage: `python3 -m tqdm.itertools test_product`
    """
    from numpy.random import randint
    from time import sleep

    for i in product(range(10), repeat=3):
        sleep(0.01)
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        sleep(0.01)

    for i in product(range(10), range(1, 10), range(2, 10),
                     tqdm_class=tqdm_auto):
        sleep(0.01)
    for i in product(range(10), range(1, 10), range(2, 10),
                     tqdm_class=tqdm_auto, total=720):
        sleep(0.01)


# Generated at 2022-06-22 05:03:48.073672
# Unit test for function product
def test_product():
    # Regression test:
    # https://github.com/tqdm/tqdm/issues/467
    # https://github.com/tqdm/tqdm/pull/468
    from .utils import _range, formatted_time
    from datetime import timedelta
    from sys import version_info
    if version_info[0] == 3:
        from collections.abc import Iterator
    else:
        from collections import Iterator

    a = _range(3)
    b = _range(4)
    prod = product(a, b)
    assert isinstance(prod, Iterator)
    for _ in prod:
        pass
    assert str(prod) == "product(range(3), range(4)): 12it [00:00, 12278.18it/s]"

# Generated at 2022-06-22 05:03:58.936010
# Unit test for function product
def test_product():
    """
    Unit tests to ensure that `tqdm.itertools.product` is equivalent of
    `itertools.product`.
    """

# Generated at 2022-06-22 05:04:03.321081
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # Should not raise
    list(product(range(3), repeat=3))
    list(product(range(3), repeat=3, tqdm_class=None))
    list(product(range(3), repeat=3, tqdm_class=tqdm_auto))

# Generated at 2022-06-22 05:04:10.572571
# Unit test for function product
def test_product():
    import math
    import random
    import sys

    random.seed(0)
    N = 10
    l = list(range(N))
    r = list(product(l))
    assert len(r) == int(math.pow(N, 2))
    for i in r:
        assert len(i) == 2
        for j in i:
            assert j in l

    from .tqdm import tqdm
    p = tqdm(product(l, l))
    for i in p:
        assert len(i) == 2
        for j in i:
            assert j in l
    assert p.n == p.total == int(math.pow(N, 2)), 'Test progressbar update'

    out = sys.stdout
    sys.stdout = open('/dev/null', 'w')

# Generated at 2022-06-22 05:04:19.480186
# Unit test for function product
def test_product():
    ''' Unit test for function product '''
    from random import sample, shuffle
    n_tests = 100
    rnd_max = 30
    rnd_min = 3
    for _ in range(n_tests):
        iterables = [tuple(sample(range(100000), randint(rnd_min, rnd_max)))
                     for _ in range(randint(rnd_min, rnd_max))]
        for tqdm_class in [tqdm_auto, None]:
            shuffle(iterables)
            list1 = list(itertools.product(*iterables))
            shuffle(iterables)
            list2 = list(product(*iterables, tqdm_class=tqdm_class))
            assert list1 == list2

# Generated at 2022-06-22 05:04:38.061263
# Unit test for function product
def test_product():
    from .tests import test_product as unit_test
    unit_test()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:04:47.471361
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    from ..compat import StringIO
    from ..pandas import trange

    # Testing with `range`
    with trange(5, file=StringIO()) as t:
        results = []
        for i in product(range(5), range(5)):  # noqa
            results.append(i)
            t.update()
    assert ([(a, b) for a in range(5) for b in range(5)] ==
            results)

    # Testing with `list`
    with trange(5, file=StringIO()) as t:
        results = []
        for i in product(list(range(5)), list(range(5))):  # noqa
            results.append(i)
            t.update()

# Generated at 2022-06-22 05:04:58.021540
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    #test one argument
    num_list = [1,2,3]
    test_list = [1,2,3]
    assert list(product(num_list)) == test_list
    #test two arguments
    test_list2 = [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
    assert list(product(num_list,num_list)) == test_list2
    #test multiple arguments

# Generated at 2022-06-22 05:05:03.220442
# Unit test for function product
def test_product():
    for i in product(range(10), "abcd", tqdm_class=tqdm_auto):
        pass
    for i in product(range(10), "abcd", total=5, tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 05:05:11.218847
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import math
    import random
    from unittest import TestCase
    from .utils import format_time
    from .utils import Random
    from .utils import SimpleTestInst

    class TQDMProdTest(TestCase):
        """
        Unit test for function product
        """
        @staticmethod
        def prod_test(inputs, kwargs, expected_steps=None, expected_total=-1):
            """
            :param inputs:   inputs for product
            :param kwargs:   kwargs for product
            :param expected_total:    number of outputs expected
            :param expected_steps:    sum of all iterations, if not None
            """
            total = expected_total

# Generated at 2022-06-22 05:05:12.638416
# Unit test for function product
def test_product():
    """Test function product"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 05:05:20.377757
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`.
    """
    from ..tqdm_gui import tqdm
    digits = product(range(2), repeat=3)
    for i in tqdm(digits):
        pass
    assert i == (1, 1, 1)
    digits = product(range(2), repeat=3, tqdm_class=tqdm)
    i = None
    for i in digits:
        pass
    assert i == (1, 1, 1)

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:05:30.010440
# Unit test for function product
def test_product():
    from random import randint
    from .itertools import product
    for i in product(range(10), range(2)):
        pass
    for i in product(range(5), range(5), range(5), range(5), range(5),
                     range(5), range(5), range(5), range(5), range(5),
                     tqdm_class=type(u""), total=100000):
        pass

# Generated at 2022-06-22 05:05:32.770369
# Unit test for function product
def test_product():
    list(product(range(3), repeat=3))

# Generated at 2022-06-22 05:05:39.144801
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import sys
    for i in range(4):
        for j in range(4):
            print('i=', i, 'j=', j)
    print('memory usage:', format_sizeof(sys.getsizeof(list(product(range(4), repeat=2)))))  # noqa: E501


if __name__ == "__main__":
    test_product()