

# Generated at 2022-06-22 04:56:15.508731
# Unit test for function product
def test_product():
    """
    Unit test for decorated function ``product``.
    """
    from collections import Counter
    from itertools import product
    r = []
    for i in product([0, 1, 2], [10, 100], repeat=2):
        r.append(i)
    c = Counter(r)

# Generated at 2022-06-22 04:56:27.037727
# Unit test for function product
def test_product():
    from ..std import numpy as np
    import operator
    import itertools

    def random_sample(mu, sigma, n):
        """
        Sample n observations from a normal distribution with mean mu
        and standard deviation sigma.
        """
        sample = np.random.normal(mu, sigma, n)
        return sample

    def calc_prod(prod):
        out = 1
        for i in prod:
            out *= i
        return out

    # Take a random sample of 1000 observations from a distribution with
    # mean = 1 and standard deviation 1
    sample = random_sample(1, 1, 1000)

    # Create a cartesian product of all combinations
    product = calc_prod(sample)
    print("Product of cartesian product: {}".format(product))

    # Calculate the product for each cart

# Generated at 2022-06-22 04:56:32.153443
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy import prod
    for total in [1, 43, 876, 1234]:
        iterables = [randint(0, 10, n) for n in randint(1, 10, total)]
        c = 0
        for i in product(*iterables):
            c += 1
            assert len(i) == len(iterables)
        assert c == prod([len(i) for i in iterables])

# Generated at 2022-06-22 04:56:41.593045
# Unit test for function product
def test_product():
    range_int = 20
    range_int_list = list(range(range_int))
    for n in range(1, range_int):
        t = list(itertools.product(range_int_list, repeat=n))
        for i in product(range_int_list, repeat=n, desc="product unit test",
                         leave=False, ascii=True, ncols=30, mininterval=0,
                         disable=False, unit='it', unit_scale=False,
                         dynamic_ncols=False, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} ['
                         '{rate_fmt}{postfix}]'):
            assert i == t.pop(0)
        assert len(t) == 0

# Generated at 2022-06-22 04:56:52.865184
# Unit test for function product
def test_product():
    """Test module function product."""
    import numpy as np

    res1 = [x for x in product([1, 2], repeat=3, tqdm_class=None)]
    res2 = [x for x in product([1, 2], repeat=3, tqdm_class=tqdm_auto)]
    assert (np.array(res1) == np.array(res2)).all()
    res1 = [x for x in product(range(10), repeat=3, tqdm_class=None)]
    res2 = [x for x in product(range(10), repeat=3, tqdm_class=tqdm_auto)]
    assert (np.array(res1) == np.array(res2)).all()

# Generated at 2022-06-22 04:57:02.937968
# Unit test for function product
def test_product():
    """Test function `product`"""
    from ._utils import ClosedRange
    from ._monitor import Monitor
    m1 = Monitor()
    m2 = Monitor()

    with tqdm_auto(total=100) as t:
        for _ in product(
                ClosedRange(1, 4, m1),
                ClosedRange(1, 4, m2),
                monitor=m1 + m2):
            t.update()

    assert m1.n == 4
    assert m2.n == 16
    assert t.n == 100

    with tqdm_auto() as t:
        for _ in product(
                ClosedRange(1, 4, m1),
                ClosedRange(1, 4, m2),
                monitor=m1 + m2):
            t.update()
    assert t.n == 16

# Generated at 2022-06-22 04:57:06.374847
# Unit test for function product
def test_product():
    "Test function `product`."
    # no expected errors
    for i in product('ABCD', 'xy'):
        pass

# Generated at 2022-06-22 04:57:17.057716
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    try:
        from collections import Iterable
    except ImportError:
        return  # Python 2.6

    # First test: iterating over all possibilities
    res1 = list(product(range(2), range(3), range(4), tqdm_class=lambda x: x))
    res2 = list(itertools.product(range(2), range(3), range(4)))
    assert res1 == res2

    # Second test: iterating over all possibilities (using iterators)
    res1a = list()
    for i in product(range(2), range(3), range(4), tqdm_class=lambda x: x):
        res1a.append(i)
    res2a = list()

# Generated at 2022-06-22 04:57:25.914061
# Unit test for function product
def test_product():
    import numpy as np

    assert (
        list(product([[1], [2]], [[3, 4], [5, 6]])) ==
        list(itertools.product([[1], [2]], [[3, 4], [5, 6]]))
    )

    assert (
        np.asarray(list(product([[1], [2]], [[3, 4], [5, 6]]))).shape ==
        np.asarray(list(itertools.product([[1], [2]], [[3, 4], [5, 6]]))).shape
    )

# Generated at 2022-06-22 04:57:36.418886
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import SimpleNamespace

    iterables = (np.arange(100), np.arange(100), np.arange(200),
                 np.arange(200))
    for tqdm_class in (None, SimpleNamespace(total=None)):
        for tqdm_kwargs in (dict(), dict(ascii=True)):
            if tqdm_kwargs:
                tqdm_kwargs.setdefault("total", 800000)
            with tqdm(product(*iterables,
                              tqdm_class=tqdm_class,
                              **tqdm_kwargs)) as t:
                for _ in t:
                    pass

# Generated at 2022-06-22 04:57:50.415482
# Unit test for function product
def test_product():
    from unittest import TestCase, main

    class TestProduct(TestCase):
        def test_product(self):
            """testing: product"""
            from random import shuffle
            from numpy import allclose
            a, b, c, d = range(2), range(3), range(5), range(7)
            abcd_product = set(itertools.product(a, b, c, d))
            abcd_prod_tqdm = set(product(a, b, c, d))
            self.assertTrue(allclose(abcd_product, abcd_prod_tqdm))
            abcd_product = list(itertools.product(a, b, c, d))
            shuffle(abcd_product)

# Generated at 2022-06-22 04:58:00.390137
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Test for exception `TypeError`
    ip = product([1, 2], [['a', 'b'], ['c', 'd', 'e']], [1], [1], tqdm_class=None)
    assert ip
    # Test for correct iterator
    ip = product([1, 2], [['a', 'b'], ['c', 'd', 'e']], [1], [1], tqdm_class=tqdm_auto)
    assert next(ip) == (1, ['a', 'b'], 1, 1)

# Generated at 2022-06-22 04:58:07.932261
# Unit test for function product
def test_product():
    import sys
    try:
        list(product(['a', 'b', 'c', (3, 4)], ['d', 'e'], ['f', 'g'], tqdm_class=tqdm_auto))
    except AttributeError:  # Old tqdm versions
        class tqdm_class:
            def __init__(self, *args, **kwargs):
                self.status_printer = tqdm_class.status_printer(total=1)
            def update(self, n=1):
                self.status_printer.update(n=n)
            def __enter__(self):
                return self
            def __exit__(self, *exc):
                return
            class status_printer:
                def __init__(self, total):
                    self.total = total
                   

# Generated at 2022-06-22 04:58:17.571012
# Unit test for function product
def test_product():
    """Test """

    import numpy as np

    for tqdm_cls in (tqdm_auto,):
        for i in (1, 5):
            # Default bar
            assert np.allclose(
                np.asarray(tuple(product(range(i), tqdm_class=tqdm_cls))),
                np.asarray(tuple(itertools.product(range(i)))))

            # No bar
            assert np.allclose(
                np.asarray(tuple(product(range(i), disable=True))),
                np.asarray(tuple(itertools.product(range(i)))))

# Generated at 2022-06-22 04:58:27.331066
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`."""
    from ..std import itertools
    import sys

    stdout = sys.stdout

    class DummyTTY:
        def write(self, x):
            pass

        def flush(self):
            pass
    # test with bogus file
    sys.stdout = DummyTTY()
    list(itertools.product([1], [2], [3]))
    # test stderr
    sys.stdout = stdout
    list(itertools.product([1], [2], [3], tqdm_class=tqdm_auto.tqdm_gui,
                           file=sys.stderr))

# Generated at 2022-06-22 04:58:38.406890
# Unit test for function product
def test_product():
    from .main import tqdm, trange
    from .utils import format_sizeof, format_interval

    from time import sleep
    from multiprocessing import Pool

    def estimate_time():
        return 100

    for tqdm_cls in [tqdm, trange]:
        t = tqdm_cls(product(*[range(1, 5)] * 8),
                     desc='test', ascii=True, mininterval=0, miniters=1,
                     total=estimate_time())
        assert format_sizeof(t.total) == '1.00e+8'
        assert t.total == estimate_time()
        assert not t.disable
        sleep(0.01)
        t.update()
        sleep(0.01)
        t.close()

# Generated at 2022-06-22 04:58:44.683838
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import FormatMixin

    # Test with and without TqdmTypeError
    for t in [tqdm_auto, FormatMixin]:
        for k in range(2):
            assert list(t.product(range(k + 1), repeat=3)) == \
                list(product(range(k + 1), repeat=3, tqdm_class=t))

# Generated at 2022-06-22 04:58:56.213768
# Unit test for function product
def test_product():
    """
    Test for edge cases and docstring examples.
    """
    from . import trange
    from .utils import wrapt_import
    if wrapt_import:
        wrapt = wrapt_import.wrapt
    else:
        return
    with trange(1) as t:
        assert tuple(product(t, [1], (2, 3))) == ((0, 1, 2), (0, 1, 3))
        t.close()

    with trange(1) as t:
        assert tuple(product([0, 1], t)) == ((0, 0), (1, 0))
        t.close()

    l = [0, 1, 2, 3]

# Generated at 2022-06-22 04:58:59.454419
# Unit test for function product
def test_product():
    """Test for function `product`."""
    for _ in product(range(10), range(3)):
        pass


# To preserve backward compatibility
tqdm_product = product

# Generated at 2022-06-22 04:59:07.103305
# Unit test for function product
def test_product():
    from .tqdm import tqdm
    from .utils import format_interval

    import time

    delay = 0.01
    for i in product(range(4), repeat=4, tqdm_class=tqdm):
        time.sleep(delay)
    for i in product(range(4), range(4), range(4), range(4), tqdm_class=tqdm):
        time.sleep(delay)

    i = 0
    for _ in tqdm(product(range(4), repeat=4)):
        time.sleep(delay)
        i += 1
    assert i == 4**4

    i = 0
    for _ in tqdm(product(range(4), range(4), range(4), range(4))):
        time.sleep(delay)
        i += 1
   

# Generated at 2022-06-22 04:59:14.794258
# Unit test for function product
def test_product():
    for i in product(range(4), range(4), range(4), tqdm_class=tqdm_auto):
        assert i == (0,) * 3
    for i in product(range(4), range(4), range(4), tqdm_class=False):
        assert i == (0,) * 3

# Generated at 2022-06-22 04:59:21.517477
# Unit test for function product
def test_product():
    """
    Test for tqdm.itertools
    """
    import sys
    from io import StringIO
    with StringIO() as our_file:
        for _ in product(range(3), tqdm_class=tqdm_auto,
                         file=our_file, mininterval=0.01):
            pass
        our_output = our_file.getvalue()

    with StringIO() as py2_file:
        for _ in itertools.product(range(3)):
            sys.stdout.write('.')  # Python 2 workaround for buffered output
            sys.stdout.flush()
        py2_output = py2_file.getvalue()

    assert(our_output == py2_output)

# Generated at 2022-06-22 04:59:32.076612
# Unit test for function product
def test_product():
    """Test_product"""
    from ._utils import nocolor
    # Depending on `tqdm.auto`, it might be
    #   tqdm
    #   tqdm_gui
    #   tqdm_notebook
    #   tqdm_pandas
    #   tqdm_txt
    with tqdm_auto.tqdm(unit='i', miniters=1, mininterval=0,
                        ncols=nocolor) as t:
        assert len(list(t.__iter__())) == 1
        assert len(list(t.__iter__())) == 2
    assert len(list(product([1], repeat=3, tqdm_class=tqdm_auto))) == 1
    assert len(list(product([1, 2], repeat=2))) == 4


# Generated at 2022-06-22 04:59:43.764403
# Unit test for function product
def test_product():
    from itertools import product
    from numpy.testing import assert_equal

    for i in product([1, 2], [4, 5]):
        print(i)

    assert_equal(list(product([1, 2], [4, 5])),
                 list(product([1, 2], [4, 5])))

    for i in product([1, 2, 3], [4, 5], ["a", "b"]):
        print(i)

    assert_equal(list(product([1, 2, 3], [4, 5], ["a", "b"])),
                 list(product([1, 2, 3], [4, 5], ["a", "b"])))

    for i in product([1, 2, 3], [4], ["a", "b"]):
        print(i)


# Generated at 2022-06-22 04:59:49.973473
# Unit test for function product
def test_product():
    """Test that the product of an empty list is empty"""
    assert list(product([])) == [()]

    """Test the product of one list is iterating over that list"""
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    """Test the product of two lists"""
    assert list(product([1, 2, 3], [4, 5])) == [(1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]

    """Test the product of three lists"""

# Generated at 2022-06-22 05:00:01.515440
# Unit test for function product
def test_product():
    import pytest

    from tqdm import trange, tqdm_gui

    for tqdm_cls in [trange, tqdm_gui]:
        def gen():
            for i in product((0, 1), tqdm_class=tqdm_cls):
                yield i

        assert list(gen()) == [(0, 0), (0, 1), (1, 0), (1, 1)]

        def gen():
            for i in product(range(5), range(5), tqdm_class=tqdm_cls):
                yield i

        assert list(gen()) == list(itertools.product(range(5), range(5)))


# Generated at 2022-06-22 05:00:13.693520
# Unit test for function product
def test_product():
    "Test product"
    def test_it(func):
        # fmt: off
        yield func, [], [], []
        yield func, [1], [], []
        yield func, [], [1], []
        yield func, [1], [1], [1]
        yield func, [1, 2], [1], [1, 2]
        yield func, [1], [1, 2], [1, 2]
        yield func, [1, 2], [1, 2], [1, 1, 2, 2]
        # fmt: on

    def test_gen(func):
        # fmt: off
        yield func, ((i, j) for (i, j) in []), []
        yield func, ((i, j) for (i, j) in [1]), []

# Generated at 2022-06-22 05:00:23.262891
# Unit test for function product
def test_product():
    from .tqdm_gui import trange
    from .tqdm import tqdm

    for t_cls in [tqdm, trange]:
        p = product("ABCDE", "xy", tqdm_class=t_cls)
        assert [i for i in p] == [
            ('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'),
            ('C', 'y'), ('D', 'x'), ('D', 'y'), ('E', 'x'), ('E', 'y')]

# Generated at 2022-06-22 05:00:31.989401
# Unit test for function product
def test_product():
    import random
    from . import trange, tqdm
    from .._tqdm import TqdmTypeError
    with trange(5) as t:
        assert t.total == 5
        for x in product(t, range(10)):
            pass
        assert t.n == 5
        assert t.total == 5
    assert t.n == 5
    with tqdm(total=5) as t:
        assert t.total == 5
        for x in product(t, range(10)):
            pass
        assert t.n == 5
        assert t.total == 5
    assert t.n == 5
    with trange(5) as t:
        assert t.total == 5
        for x in product(t, range(1)):
            pass
        assert t.n == 1
        assert t

# Generated at 2022-06-22 05:00:43.369210
# Unit test for function product
def test_product():
    from ..utils import natsorted

# Generated at 2022-06-22 05:00:54.516734
# Unit test for function product
def test_product():
    from numpy.random import randint
    for T in [tqdm, tqdm_gui, tqdm_notebook]:
        for n in [0, 1, 100, 1000]:
            for m in [0, 1, 10, 100]:
                for l in [0, 1, 10, 100]:
                    X = randint(100, size=(n, m, l))
                    assert ([x for x in product(X)] ==
                            [x for x in itertools.product(X)])

# Generated at 2022-06-22 05:01:00.056878
# Unit test for function product
def test_product():
    # Test without tqdm
    for i in product(range(5), repeat=2):
        assert i[0] in range(5) and i[1] in range(5)

    # Test using tqdm
    for i in product(range(5), tqdm_class=tqdm_auto, repeat=2):
        assert i[0] in range(5) and i[1] in range(5)

# Generated at 2022-06-22 05:01:12.642037
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal

    # special case: empty list
    assert_array_equal(list(product([], [])),
                       list(itertools.product([], [])))

    # special case: empty iterator
    assert_array_equal(list(product(iter([]))),
                       list(itertools.product(iter([]))))

    # special case: no argument
    assert_array_equal(list(product()), list(itertools.product()))

    # list of list
    assert_array_equal(list(product([[4], [5, 6, 7]],
                                     [1, 2])),
                       list(itertools.product([[4], [5, 6, 7]],
                                              [1, 2])))

    # list of

# Generated at 2022-06-22 05:01:15.921506
# Unit test for function product
def test_product():
    """Test function `product`"""
    it = product(range(1, 7), "abc", tqdm_class=tqdm_auto)
    expected = list(itertools.product(range(1, 7), "abc"))
    for x, y in zip(it, expected):
        assert x == y

# Generated at 2022-06-22 05:01:26.747262
# Unit test for function product
def test_product():
    from .utils import FormatCustomTqdm, ColorfulTqdm, trange
    from .utils import _range
    from .std import format_tqdm, format_tqdm_with_new_length_desc
    from random import randint
    from ..auto import tqdm as tqdm_auto

    # Check parameters
    for tqdm_cls in (tqdm_auto, trange, ColorfulTqdm, FormatCustomTqdm):
        with tqdm_cls(
                format='{l_bar}{bar}{r_bar}',
                bar_format='{percentage:3.0f}% {desc}') as t:
            t.set_description("test", refresh=False)
            assert t.miniters == 1
            t.update(1)

# Generated at 2022-06-22 05:01:34.196465
# Unit test for function product
def test_product():
    """
    Unit tests for function ``product``
    """
    from ..utils import format_sizeof
    # Test small lists
    assert sum(product([1, 2, 3, 4])) == 4 * 3 * 2 * 1
    # Test big lists
    big = range(129)
    assert sum(product(big)) == 2398462670229248


if __name__ == "__main__":
    from ..utils import _test_env
    _test_env()
    test_product()

# Generated at 2022-06-22 05:01:42.134272
# Unit test for function product
def test_product():
    tqdm_kwargs = {"total": 9, "tqdm_class": tqdm_auto}

# Generated at 2022-06-22 05:01:46.681069
# Unit test for function product
def test_product():
    """Test for `product`"""
    for i in product([1, 2, 3], range(5)):
        assert type(i) is tuple
        prod = 1
        for j in i:
            prod *= j
        assert prod in range(5)
    for i in product([1, 2]):
        assert type(i) is tuple
        assert len(i) is 1
        assert i[0] in [1, 2]

# Generated at 2022-06-22 05:01:55.673017
# Unit test for function product
def test_product():
    from .misc import B
    from .enumerate import _range
    for c in (tqdm_auto, None):
        for m in (10, 100, 1000):
            for n in (1, 2, 3):
                assert list(product(*[B(1, m, n) for _ in _range(n)],
                                     tqdm_class=c)) == list(
                                         itertools.product(*[B(1, m, n)
                                                             for _ in _range(n)]))

# Generated at 2022-06-22 05:02:03.636113
# Unit test for function product
def test_product():
    kwargs = {"desc": "bla", "leave": True}

# Generated at 2022-06-22 05:02:11.350481
# Unit test for function product
def test_product():
    from itertools import product as itertools_product

    for iterables in [[0, 1], [0, 1], [0, 1], [0, 1], [0, 1], [0, 1]]:
        for i, j in zip(product(*iterables), itertools_product(*iterables)):
            assert i == j

# Generated at 2022-06-22 05:02:22.826285
# Unit test for function product
def test_product():
    try:
        from nose.tools import assert_equal, assert_raises_regex
    except ImportError:
        from nose2.tools import assert_equal, assert_raises_regex
    from nose2.tools import such
    from nose_parameterized import parameterized
    from ..utils import FormatCustomText, FormatCustomTextTest, _range

    with such.A("product") as it:
        # Unit test for function product
        @it.should("be iterable and return the same results as itertools")
        def test_product1():
            with it.assertRaises(AssertionError):
                assert_equal(list(product(range(3), repeat=1, as_iterator=True)), list(itertools.product(range(3))))

# Generated at 2022-06-22 05:02:31.515251
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .._tqdm_test_case import _TqdmTestCase
    from six.moves import zip, range
    tqdm_test = _TqdmTestCase()
    with tqdm_test:
        for _ in product(range(10), range(10), range(10)):
            pass
    tqdm_test.assert_lock_unlocked()
    tqdm_test.assert_empty()

    from ..auto import tqdm
    with tqdm(total=100, miniters=0) as t:
        for _ in product(tqdm(range(10)), tqdm(range(10)), tqdm(range(10))):
            pass

# Generated at 2022-06-22 05:02:41.849381
# Unit test for function product
def test_product():
    """
    Test product function
    """
    from random import randint, choice, random
    from time import sleep

    class MockTQDM():
        """
        Mock tqdm object
        """
        def __init__(self, *args, **kwargs):
            self.n = 0
            self.total = kwargs.pop("total", None)

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def update(self, n=1):
            """
            Mock update function
            """
            self.n += n

    length = randint(1, 10)
    iterables = [[random() for _ in range(randint(1, 10))] for _ in range(length)]
    products = itertools.product(*iterables)

   

# Generated at 2022-06-22 05:02:43.879846
# Unit test for function product
def test_product():
    assert list(product("abc", "def", tqdm_class=None)) == list(itertools.product("abc", "def"))

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:02:55.172845
# Unit test for function product
def test_product():
    """Unit test for function product."""
    import os
    import sys
    import random
    sys.modules['tqdm'] = tqdm_auto

    def _stdout_suppressor(native_stdout):
        def stdout_suppressor(*args, **kwargs):
            pass

        return stdout_suppressor

    # Py2/3-compatible
    try:
        UnicodeIO = io.StringIO
    except NameError:
        UnicodeIO = io.BytesIO

    class UnicodeReader(object):
        """
        File-like wrapper that reads unicode strings.
        """
        def __init__(self, f):
            self.f = UnicodeIO(f.read())

        def __iter__(self):
            return self


# Generated at 2022-06-22 05:03:06.575097
# Unit test for function product
def test_product():
    result = list(product([1, 2, 3], ['a', 'b', 'c'], tqdm_class=None))
    assert result == [(1, 'a'), (1, 'b'), (1, 'c'),
                      (2, 'a'), (2, 'b'), (2, 'c'),
                      (3, 'a'), (3, 'b'), (3, 'c')]
    result = list(product([1, 2, 3], ['a', 'b', 'c']))
    assert result == [(1, 'a'), (1, 'b'), (1, 'c'),
                      (2, 'a'), (2, 'b'), (2, 'c'),
                      (3, 'a'), (3, 'b'), (3, 'c')]


if __name__ == "__main__":
    test_

# Generated at 2022-06-22 05:03:15.464995
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy
    from ..std import numpy as tqdm_numpy

    iterables = [
        ["a", "b", "c"], range(10), numpy.arange(100), tqdm_numpy.arange(500),
        "abcde",
    ]

    for total, i, j in product(*iterables, tqdm_class=tqdm_numpy,
                               desc="product"):
        numpy.testing.assert_array_equal(j, i)

# Generated at 2022-06-22 05:03:25.577207
# Unit test for function product
def test_product():
    with tqdm_auto(total=0, unit='B', unit_scale=True, miniters=1) as t:
        assert list(product(t, "ab", "12")) == [('a', '1'), ('a', '2'),
                                                ('b', '1'), ('b', '2')]
        assert t.n == 4
        assert t.smoothing == 0
    with tqdm_auto(total=4, unit='B', unit_scale=True, miniters=1) as t:
        assert list(product(t, "ab", "12")) == [('a', '1'), ('a', '2'),
                                                ('b', '1'), ('b', '2')]
        assert t.n == 4
        assert t.smoothing == 0

# Generated at 2022-06-22 05:03:27.342203
# Unit test for function product
def test_product():
    from .tests import test_product as specific_test
    specific_test(product)

# Generated at 2022-06-22 05:03:43.411946
# Unit test for function product
def test_product():
    """
    Unit test.
    """
    import gc
    import os
    import subprocess
    import sys
    from .._tqdm_gui import tqdm_gui
    from ..tqdm_pandas import tqdm_pandas
    from .._tqdm import _version as __version__

    # Unit tests for function product
    def test_product_parallel(tqdm):
        """
        Unit tests for function product.
        """
        from multiprocessing import Pool

        # Checking product
        res = list(product("ABCD", repeat=2, tqdm=tqdm))

# Generated at 2022-06-22 05:03:53.480968
# Unit test for function product
def test_product():
    from .tqdm_test_cases import range_, tqdm_class_mock
    for tqdm_class in [tqdm_class_mock, tqdm_auto]:
        assert list(product(range_(), tqdm_class=tqdm_class)) ==\
            list(itertools.product(range_()))

        assert list(product(range_(10), range_(100), tqdm_class=tqdm_class)) ==\
            list(itertools.product(range_(10), range_(100)))

        assert list(
            product(range_(10), range_(100), range_(1000), tqdm_class=tqdm_class))\
            == list(itertools.product(range_(10), range_(100), range_(1000)))

# Generated at 2022-06-22 05:04:04.161876
# Unit test for function product
def test_product():
    """ Unit test for function `product` """
    from numpy.testing import assert_array_equal

    def _test(tqdm_instance=None, tqdm_class=tqdm_auto):
        """ Soufflé. """
        it = product(range(3), range(2), range(3), tqdm_class=tqdm_class)

        # Test iterator
        it_list = list(it)

# Generated at 2022-06-22 05:04:12.523255
# Unit test for function product
def test_product():
    """
    Test for the function `product`.
    """
    from ..main import tqdm
    for _ in tqdm_product(range(10), range(10), tqdm_class=tqdm):
        pass
    for _ in tqdm_product(1, 1, tqdm_class=tqdm):
        pass
    from ..gui import tqdm
    for _ in tqdm_product(range(10), range(10), tqdm_class=tqdm):
        pass
    for _ in tqdm_product(1, 1, tqdm_class=tqdm):
        pass

# Generated at 2022-06-22 05:04:20.165457
# Unit test for function product
def test_product():
    """Test the `tqdm.itertools` version of `itertools.product`"""
    from nose.tools import assert_equal
    ilen = 10000

    # Unit test for function product
    def flat_map(A, B):
        return list(product(A, B, tqdm_class=None))

    assert_equal(
        flat_map(range(ilen), range(ilen)),
        flat_map(
            range(ilen),
            range(ilen),
            tqdm_class=tqdm_auto))


if __name__ == "__main__":
    from .trange import _test_it_main
    _test_it_main(__file__)

# Generated at 2022-06-22 05:04:25.938955
# Unit test for function product
def test_product():
    from .utils import TotalSpy

    def per_iter_return(**kwargs):
        return {'total': 19}

    for total, miniters in [
        (None, 1), (1, 1), (19, 1),
        (None, 2), (1, 2), (19, 2),
    ]:
        # Test normal usage
        t = TotalSpy(total=total, miniters=miniters)
        p = product(range(5), repeat=5, tqdm_class=t)
        assert len(list(p)) == 5 ** 5

        # Test normal usage with miniters
        t = TotalSpy(total=total, miniters=miniters)
        p = product(range(5), repeat=5, tqdm_class=t, miniters=10)
       

# Generated at 2022-06-22 05:04:31.386395
# Unit test for function product
def test_product():
    """
    Test `product` against `itertools.product`.
    """
    iterables = [[1, 2], [3, 4, 5], [6, 7]]
    gen1 = product(*iterables)
    gen2 = itertools.product(*iterables)

    next(gen1)  # ignore the first tqdm timer update
    for x, y in zip(gen1, gen2):
        assert x == y

# Generated at 2022-06-22 05:04:43.645162
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    import sys
    import locale
    import subprocess
    # Tests with a tty-like (but non-TTY) system
    sys.stdout = open("/dev/null", "w")
    assert (product(range(2), range(2), tqdm_class=tqdm_auto)
            == itertools.product(range(2), range(2)))
    assert (product(range(2), range(2), tqdm_class=tqdm_auto, total=4)
            == itertools.product(range(2), range(2)))

# Generated at 2022-06-22 05:04:53.843708
# Unit test for function product
def test_product():
    import sys, random
    from nose.tools import assert_equals
    from ..std import next, list

    # Iterator with total

# Generated at 2022-06-22 05:05:00.578839
# Unit test for function product
def test_product():
    import numpy as np
    from itertools import product as _product

    # Test that product yields the same and of the same as itertools.product:
    for itera in (range(1000), ['a', 'b', 'c'], np.arange(100.)):
        for iterb in (range(1000, 2000), ['d', 'e', 'f'], np.arange(100., 200.)):
            # Test the same values:
            a = set(itertools.product(itera, iterb))
            b = set(_product(itera, iterb))
            assert a == b
            # Test the same length (if possible):

# Generated at 2022-06-22 05:05:11.247257
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    res = [i for i in product(['a', 'b', 'c'], repeat=3)]
    assert len(res) == 27
    assert res[0] == ('a', 'a', 'a')
    assert res[-1] == ('c', 'c', 'c')
    res = [i for i in product(['a', 'b', 'c'], [1, 2])]
    assert len(res) == 6
    assert res[0] == ('a', 1)
    assert res[-1] == ('c', 2)
    assert len([i for i in product(xrange(10))]) == 10
    assert len([i for i in product(xrange(10), repeat=2)]) == 100

# Generated at 2022-06-22 05:05:21.370758
# Unit test for function product
def test_product():
    import sys
    from tqdm._utils import _supports_unicode
    from tqdm import tqdm

    *ot, total = product(
        range(1), "ab", [1, 2, 3],
        tqdm_class=tqdm,
        ascii=True, mininterval=0, miniters=None,
        file=sys.stdout)
    assert len(ot) == total == 6
    *ot, total = product(
        range(1), "ab", [1, 2, 3],
        tqdm_class=tqdm,
        ascii=True, mininterval=0,
        file=sys.stdout)
    assert len(ot) == total == 6

# Generated at 2022-06-22 05:05:30.256605
# Unit test for function product
def test_product():
    from ..auto import trange
    # Test that tqdm function is called
    for i in product(trange(), "ab", "12"):  # pragma: no cover
        pass
    # Test with total override
    for i in product(trange(), "ab", "12", total=4):
        pass
    # Test without total
    for i in product(trange(), "ab", "12"):  # pragma: no cover
        pass
    # Test without tqdm function
    for i in product(range(10), range(10)):  # pragma: no cover
        pass
    # Test with callback and total override
    def callback(i, total, **kwargs):
        raise ValueError()


# Generated at 2022-06-22 05:05:41.528341
# Unit test for function product
def test_product():
    """Unit test for function :func:`itertools.product`"""
    import functools
    from tqdm.utils import _supports_unicode

    def test_func(tqdm_instance, *args):
        """Unit test function"""
        lst = list(product(*args, tqdm_class=functools.partial(
            tqdm_instance, ascii=not _supports_unicode)))
        assert lst == list(itertools.product(*args))

    test_func(tqdm_auto)
    test_func(tqdm_auto, range(10))
    test_func(tqdm_auto, "abcd", "efgh")
    test_func(tqdm_auto, range(10), range(-2, 4))

# Generated at 2022-06-22 05:05:51.906032
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import pytest
    from ..utils import format_sizeof

    for i in product('ABC', 'xy', tqdm_class=tqdm_auto, total=15):
        pass

    # unequal length
    for i in product([1, 2, 3], [4, 5], ['A', 'B', 'C'], tqdm_class=tqdm_auto):
        pass

    with pytest.raises(TypeError):
        for i in product((1, 2, 3), (4, 5), (6, 7), tqdm_class=tqdm_auto):
            pass

    # get total
    for i in product(*([xrange(100)] * 10), tqdm_class=tqdm_auto):
        pass

    # no len

# Generated at 2022-06-22 05:05:59.084518
# Unit test for function product
def test_product():
    from .utils import TotalCounter, FormatLazyIterator

    iterables = [
        list(range(10)),
        "abc",
        list(range(10))]

    # Unit test for function product
    for tqdm_class in (tqdm_auto, FormatLazyIterator, TotalCounter):
        list(product(tqdm_class=tqdm_class, *iterables))

# Generated at 2022-06-22 05:06:08.328663
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    from six.moves import zip
    from .utils import FakeTqdmFile

    def product_gen():
        for i, j in product(range(100), range(100)):
            yield i, j

    p = product_gen()
    for i, j in itertools.product(range(100), range(100)):
        assert_equal(next(p), (i, j))

    with FakeTqdmFile(leave=False) as f:
        p = product_gen()
        for _ in p:
            pass
        f.seek(0)
        assert_equal(len(f.readlines()), 100)

    p = product_gen()
    with FakeTqdmFile(leave=False) as f:
        for _ in p:
            pass
       