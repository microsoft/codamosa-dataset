

# Generated at 2022-06-22 04:56:17.561123
# Unit test for function product
def test_product():
    from . import _test_it_any

    def _product(iterables, **kwargs):
        return product(*iterables, **kwargs)

    _test_it_any("product", _product)

# Generated at 2022-06-22 04:56:26.292346
# Unit test for function product
def test_product():
    """Unit test for `product`"""
    from ..contrib.concurrent.thread import ThreadPoolExecutor
    from threading import Lock
    map_iter = ThreadPoolExecutor().map(lambda x: None,
                                        product(range(500),
                                                range(500),
                                                range(500)))
    # Ensure that tqdm is reentrant
    # (i.e. that it doesn't make use of any global variables)
    lock = Lock()
    list(map(lambda x: lock.acquire(), map_iter))
    lock.release()

# Generated at 2022-06-22 04:56:37.746237
# Unit test for function product
def test_product():
    """
    Test :func:`tqdm.itertools.product`.
    """
    assert list(product(range(3), range(10))) == \
        list(product(range(3), range(10)))
    assert list(product(range(4), range(4))) == \
        [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2), (1, 3),
         (2, 0), (2, 1), (2, 2), (2, 3), (3, 0), (3, 1), (3, 2), (3, 3)]
    assert list(product('ab', '12')) == \
        [('a', '1'), ('a', '2'), ('b', '1'), ('b', '2')]
   

# Generated at 2022-06-22 04:56:49.693741
# Unit test for function product
def test_product():
    from .utils import closing, fp_format

    lens = [2, 3, 4]

    with closing(tqdm_auto(total=1, leave=False)) as pbar:
        for i in product(range(l) for l in lens):
            pbar.update()


# Generated at 2022-06-22 04:56:54.243191
# Unit test for function product
def test_product():
    r"""Test"""
    from .._tqdm_test_cases import tqdm_gens
    for gen in tqdm_gens(product, 'ab', 'cd'):
        for j in gen:
            pass

# Generated at 2022-06-22 04:57:03.731248
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    from ..tqdm_gui import tqdm

    assert list(itertools.product([0, 1])) == list(product([0, 1]))
    assert list(itertools.product([0, 1], repeat=3)) == \
        list(product([0, 1], repeat=3))
    assert list(itertools.product([0, 1], [2, 3], repeat=2)) == \
        list(product([0, 1], [2, 3], repeat=2))
    assert list(itertools.product('ABCD', 'xy')) == \
        list(product('ABCD', 'xy'))  # input values must be of length one

    assert tqdm(product([0, 1]))

# Generated at 2022-06-22 04:57:16.062595
# Unit test for function product
def test_product():
    """Test itertools utils functions"""
    from nose.tools import assert_equal

    a = 'abcd'
    b = '123'

    def f(x, y, z=3):
        s = 0
        for i in range(z):
            s += x + y
        return s

    assert_equal(sorted(list(product(a, b))),
                 sorted(list(itertools.product(a, b))))
    assert_equal(sorted(list(product(a, b, repeat=3))),
                 sorted(list(itertools.product(a, b, repeat=3))))
    assert_equal(sorted(list(product(a, b, 3, repeat=2))),
                 sorted(list(itertools.product(a, b, 3, repeat=2))))


# Generated at 2022-06-22 04:57:26.579201
# Unit test for function product
def test_product():
    """
    Unit test of product.
    """
    l0 = list(range(10))
    l1 = list(range(20))
    l2 = list(range(30))
    ll = list(range(60))

    for l in product(l0, l1, l2):
        assert l[0] in l0
        assert l[1] in l1
        assert l[2] in l2

    for l in product(l0, l1, l2):
        assert l[0] in l0
        assert l[1] in l1
        assert l[2] in l2

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:57:38.623523
# Unit test for function product
def test_product():
    import numpy as np
    from sys import version_info as pyver
    from collections import Counter

    from .tqdm import tqdm

    with tqdm(product(range(5), range(5), range(5), range(5),
                      tqdm=tqdm), total=5 ** 4) as t:
        for i, _ in enumerate(t):
            pass
    assert i + 1 == 5 ** 4

    with tqdm(product(np.array(range(5)), tqdm=tqdm), total=5 ** 2) as t:
        for i, _ in enumerate(t):
            pass
    assert i + 1 == 5 ** 2


# Generated at 2022-06-22 04:57:50.372163
# Unit test for function product
def test_product():
    assert list(product([1, 2], [3, 4, 5])) == [(1, 3), (1, 4), (1, 5),
                                                 (2, 3), (2, 4), (2, 5)]
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4),
                                              (2, 3), (2, 4)]
    assert list(product(["a", "b", "c"], [1, 2, 3, 4])) == \
        [('a', 1), ('a', 2), ('a', 3), ('a', 4),
         ('b', 1), ('b', 2), ('b', 3), ('b', 4),
         ('c', 1), ('c', 2), ('c', 3), ('c', 4)]

# Generated at 2022-06-22 04:58:00.968509
# Unit test for function product
def test_product():
    # Test that the product of an empty list and a list of one element is
    # an empty list
    assert list(product([], ['a'])) == []
    # Test that the product of a list of one element and an empty list is
    # an empty list
    assert list(product(['a'], [])) == []
    # Test that the product of two empty lists is an empty list
    assert list(product([], [])) == []
    # Test that the product of two lists of one element is a list with
    # one tuple
    assert list(product(['a'], ['b'])) == [('a', 'b')]

# Generated at 2022-06-22 04:58:12.906476
# Unit test for function product
def test_product():
    """
    Unit test of product.
    """
    from ..utils import format_sizeof
    from ..tqdm_gui import tqdm

    it = tqdm.product("DEFGH", "ABCDE", "XYZ", "12345")
    for _ in it:
        pass
    assert len(it.format_meter()) > 1
    assert it.n == 60
    assert it.total == 60
    assert it.smoothing == 1.0

    it2 = tqdm.product("DEFGH", "ABCDE", "XYZ", "12345",
                       tqdm_class=tqdm, miniters=1)
    for _ in it2:
        pass
    assert len(it2.format_meter()) > 1
    assert it2.n == 60
    assert not it2.total  #

# Generated at 2022-06-22 04:58:24.454199
# Unit test for function product
def test_product():
    """
    Unit test for the `product` function
    """
    from random import randint
    import sys
    from ..std import Timer

    # Check that the wrapper works
    assert sum(product([1, 2], [2, 3])) == 15

    # Check that all the combinations are returned
    max_len = 0
    for i in range(20):
        max_len = max(max_len,
                      len(set((tuple(sorted(i)), tuple(sorted(j)))
                              for i, j in product([randint(0, 9)
                                                    for _ in range(5)],
                                                   [randint(0, 9)
                                                    for _ in range(5)]))))
    assert max_len == 25

    # Check that it works with huge number of combinations

# Generated at 2022-06-22 04:58:35.346720
# Unit test for function product
def test_product():
    assert list(product("ABC", "D")) == [("A", "D"), ("B", "D"), ("C", "D")]

# Generated at 2022-06-22 04:58:41.641225
# Unit test for function product
def test_product():
    import sys
    assert len(list(product([1, 2], [3, 4]))) == 4  # noqa
    assert \
        len([x for x in product(range(5), range(5), range(5))]) == 125  # noqa
    # Check that range returns an iter
    it = product(range(5), range(5), range(5))
    assert list(it) == [x for x in product(range(5), range(5), range(5))]

    # Check proper length
    with tqdm_auto(total=125, file=sys.stdout) as t:
        for _ in product(range(5), range(5), range(5)):
            t.update()

if __name__ == '__main__':
    test_product()  # noqa

# Generated at 2022-06-22 04:58:49.392442
# Unit test for function product
def test_product():
    list(product(range(10)))
    list(product(range(10), range(10)))
    list(product(range(10), range(10), range(10)))
    list(product(range(10), range(10), range(10), range(10)))
    list(product("abcdef", "xyz"))
    list(product("abcd", "xyz"))
    list(product("abc", "xyz"))
    list(product("ab", "xyz"))
    list(product("a", "xyz"))
    list(product("", "xyz"))

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:59:01.549801
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    import sys
    from ..utils import _range

    # Test base cases
    a = _range(10)
    b = _range(10, 20)
    res = product(a)
    assert list(res) == [(i,) for i in a]
    res = product(a, b)
    assert list(res) == [(i, j) for i, j in zip(a, b)]

    # Test with tqdm(total=None)
    for total in [None, -1]:
        res = product(a, b, tqdm_class=lambda i, **kw: tqdm_auto(i, total=total))
        assert list(res) == [(i, j) for i, j in zip(a, b)]

# Generated at 2022-06-22 04:59:07.441959
# Unit test for function product
def test_product():
    assert list(product([10], repeat=3)) == list(itertools.product([10], repeat=3))
    assert list(product([10], repeat=3, tqdm_class=tqdm_auto)) == list(itertools.product([10], repeat=3))
    assert list(product([10], repeat=3, tqdm_class=None)) == list(itertools.product([10], repeat=3))

# Generated at 2022-06-22 04:59:11.981125
# Unit test for function product
def test_product():
    from .tests import TestCase, _range
    with TestCase() as tc:
        for p in product(
                _range(10), _range(20), _range(10), tqdm_class=tc
        ):
            pass

# Generated at 2022-06-22 04:59:18.929733
# Unit test for function product
def test_product():
    """Test function `product`"""
    import random
    iterables = tuple(range(random.randint(1, 10)) for _ in range(2))  # 2-tuples
    it = product(*iterables)
    assert next(it) == (0, 0)
    prod = list(itertools.product(*iterables))
    assert len(prod) == len(list(it))
    it = product(*iterables, total=len(prod))
    assert next(it) == (0, 0)
    assert len(prod) == len(list(it))

# Generated at 2022-06-22 04:59:37.321648
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal
    # Check that it returns the same data
    assert_array_equal(
        np.array(list(product([1, 2, 3], [4, 5]))),
        np.array(list(itertools.product([1, 2, 3], [4, 5]))))
    # Check total
    total = 0
    for _ in product([1, 1], [1, 1, 1], [1, 1, 1], [1, 1], tqdm_class=tqdm_auto, total=None):
        total += 1
    assert total == 2 * 3 * 3 * 2
    # Check unit prefix
    total = 0

# Generated at 2022-06-22 04:59:46.942813
# Unit test for function product
def test_product():
    import pytest

    lst = [list(range(5)), list(range(5)), list(range(5)), list(range(5))]


# Generated at 2022-06-22 04:59:53.505737
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    # Only test cartesian product over lists
    ds = []
    for i in range(1, 5):
        ds.append([])
        for j in range(i):
            ds[i - 1].append(j)
    ds = list(zip(ds, [6, 24, 60, 120]))
    for d, total in ds:
        assert len(list(product(d))) == total

# Generated at 2022-06-22 04:59:57.078267
# Unit test for function product
def test_product():
    """Ensure that auto-wrapping itertools.product works"""
    list(product(range(100), range(100), tqdm_class=tqdm_auto))

# Generated at 2022-06-22 05:00:04.929570
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    from .tests_tqdm import TqdmBaseTestCase
    from .tests_tqdm_gui import _test_cls
    # pylint: disable=protected-access
    for _test_cls in TqdmBaseTestCase._classes.values():
        if _test_cls == TqdmBaseTestCase:
            continue
        cls = getattr(tqdm_auto, _test_cls.__name__)
        # test

# Generated at 2022-06-22 05:00:14.826112
# Unit test for function product
def test_product():
    """
    Test against `itertools.product`.
    """
    from numpy import product
    from sys import stderr

    iterables = [range(3), range(2), range(4)]
    tot = product(range(3), range(2), range(4))
    for i, (x, y, z) in enumerate(product(*iterables), 1):
        if i != tot:
            raise AssertionError("test failed in tqdm_itertools.product")
        try:
            if x == y == z == 1:
                raise Exception
        except:
            print("test passed in tqdm_itertools.product", file=stderr)

# Generated at 2022-06-22 05:00:26.192697
# Unit test for function product
def test_product():
    from .utils import format_sizeof

    from random import randint

    for _ in product(
            range(100000000),
            range(10),
            range(1),
            range(20),
            range(10),
            range(1),
            range(20),
            range(10),
            range(1),
            range(20)):
        pass

# Generated at 2022-06-22 05:00:33.412072
# Unit test for function product
def test_product():
    from .constants import one_to_hundred
    from .utils import off_main_thread

    assert list(product(one_to_hundred, repeat=2)) == list(itertools.product(one_to_hundred, repeat=2))
    assert list(product(one_to_hundred, one_to_hundred)) == list(itertools.product(one_to_hundred, one_to_hundred))

    # Check that ncols is honored
    with off_main_thread():
        p = product(one_to_hundred, one_to_hundred, ncols=20)
        assert isinstance(p, tqdm_auto)
        list(p)

# Generated at 2022-06-22 05:00:44.617204
# Unit test for function product
def test_product():
    from . import test
    import sys
    import re

    # Test on something that doesn't use much memory
    it = product(range(2), repeat=1000)
    test.bar_desc_check(it, "product(range(2), repeat=1000)|time_budget=None|2**1000")
    assert re.sub(r'(itn/s)\s+(it|iterations).*', r'\1\2/s', next(it)[-1]) in ['it/s', 'iterations/s']

# Generated at 2022-06-22 05:00:56.976117
# Unit test for function product
def test_product():
    # unit test for function product()
    import pytest

    a = list(range(10))
    b = list(range(10))
    c = list(range(10))

    def test_list_product():
        prod = None
        for i in product(a, b, c, tqdm_class=None):
            prod = prod or (len(a) * len(b) * len(c))
            assert prod > 0
            assert len(i) == len(a)

    def test_nested_iter_product():
        prod = None
        for i in product((a, b), tqdm_class=None):
            prod = prod or (len(a) * len(b))
            assert prod > 0
            assert len(i) == 2

    def test_nested_list_product():
        prod

# Generated at 2022-06-22 05:01:18.752297
# Unit test for function product
def test_product():
    """Test `tqdm.itertools.product()`"""
    from ..auto import trange
    from ..utils import format_sizeof
    import tempfile
    try:
        import psutil  # NOQA
    except ImportError:
        psutil = None
    # Setup
    f = tempfile.NamedTemporaryFile()
    f.write(b'abcdefghijklmnopqrstuvwxyz')
    f.flush()
    with open(f.name, 'rb') as f2:
        for block_size in [1, 5, 9, 11, 42, 100, 1000]:
            try:
                from os import SEEK_SET  # NOQA
            except ImportError:
                SEEK_SET = 0

# Generated at 2022-06-22 05:01:26.080986
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    assert list(product(range(2), range(2), tqdm_class=None)) == [
        (0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(0), range(0), tqdm_class=None)) == []
    assert list(product([0], [0], tqdm_class=None)) == [(0, 0)]


if __name__ == "__main__":  # pragma: no cover
    test_product()

# Generated at 2022-06-22 05:01:36.424830
# Unit test for function product
def test_product():
    import numpy as np
    from .tqdm import trange
    from .utils import FormatCustomText

    a = np.arange(2)
    b = np.arange(3, 5)
    c = np.arange(5, 8)

    def test(it1, it2, it3, it4, it5):
        assert it1 == it2 == it3 == it4 == it5

    for I in (a, b, c):
        test(list(product(I)), list(itertools.product(I)),
             list(itertools.product(I)),
             list(itertools.product(I)),
             list(trange(len(I), desc='Desc', leave=False,
                         bar_format=FormatCustomText(desc='Desc: '))))


# Generated at 2022-06-22 05:01:43.939545
# Unit test for function product
def test_product():
    """
    Unit test for function product

    Note that we use `list` to consume the `generator` itertools.product.
    """
    assert list(product([1], repeat=3, tqdm_class=tqdm_auto)) == [(1, 1, 1)]

# Generated at 2022-06-22 05:01:49.358692
# Unit test for function product
def test_product():
    """Test for function product."""
    for i, _ in enumerate(product(range(10), range(10), range(10), tqdm_class=tqdm_auto)):
        assert i == sum(map(lambda x: x[0] * x[1] * x[2] * 100 + x[0] * x[1] * 10 + x[0] * 1,
                            zip(range(10), range(10), range(10))))

# Generated at 2022-06-22 05:02:00.713027
# Unit test for function product
def test_product():
    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(2), repeat=2)) == list(product(range(2), range(2)))

    assert (list(product(
        ((i, i), (i + 1, i + 1)) for i in range(2)
    )) == [(0, 0, 0, 1), (0, 0, 1, 1), (0, 1, 0, 1), (0, 1, 1, 1),
           (1, 0, 0, 1), (1, 0, 1, 1), (1, 1, 0, 1), (1, 1, 1, 1)])

# Generated at 2022-06-22 05:02:12.391137
# Unit test for function product
def test_product():
    from . import _test_it
    from .common import _range
    from .tests_tqdm import with_setup, _size, closing
    with closing(tqdm_auto(total=_size, miniters=1)) as t:
        for _ in _test_it(itertools.product(tqdm_auto, _range)):
            t.update()
    with closing(tqdm_auto(total=_size, miniters=1)) as t:
        for _ in _test_it(product(tqdm_auto, _range)):
            t.update()
    # Test printing

# Generated at 2022-06-22 05:02:22.049549
# Unit test for function product
def test_product():
    import numpy as np
    assert np.array(list(product(range(2), range(2), tqdm_class=False))).size == 4
    assert np.array(list(product(range(2), range(2)))).size == 4
    assert np.array(list(product(range(2), range(2), tqdm_class=False))).size == 4
    assert np.array(list(product(range(2), range(2), tqdm_class=tqdm_auto))).size == 4
    assert np.array(list(product(range(2), range(2), tqdm_class=tqdm_auto, total=1))).size == 4

# Generated at 2022-06-22 05:02:31.481324
# Unit test for function product
def test_product():
    """
    Unit tests for `product` function.
    """
    # Iterator with default value
    assert isinstance(product(range(10)), tqdm_auto)
    lst = []
    for i in product(range(10)):
        lst.append(i)
    assert lst == list(range(10))

    # Iterator with custom value
    assert isinstance(
        product(range(10), tqdm_class=tqdm_auto.tqdm_gui),
        tqdm_auto.tqdm_gui)
    lst = []
    for i in product(range(10), tqdm_class=tqdm_auto.tqdm_gui):
        lst.append(i)
    assert lst == list(range(10))

# Generated at 2022-06-22 05:02:37.114810
# Unit test for function product
def test_product():
    """Fast test of `tqdm.itertools.product`"""
    from ..tqdm import __version__ as tqdm_version
    from ._tqdm_test_closure import _test_iterable_progress
    yield lambda: _test_iterable_progress(product,
                                          nested_list(6, 2),
                                          "tqdm.itertools.product")

# Generated at 2022-06-22 05:03:00.031388
# Unit test for function product
def test_product():
    for i in product('abc', repeat=4, tqdm_class=tqdm_auto):
        pass  # NOQA

# Generated at 2022-06-22 05:03:09.017976
# Unit test for function product
def test_product():
    from . import trange
    from .utils import FormatWrapIter

    assert list(product(['a', 'b'], [1, 2], ['c', 'd'])) == \
        list(itertools.product(['a', 'b'], [1, 2], ['c', 'd']))

    total = 5
    assert sum(1 for _ in product(range(total), repeat=2)) == total ** 2
    with trange(total, total=total) as t:
        for _ in product(t, repeat=2):
            pass
    with trange(total, total=total ** 2) as t:
        for _ in FormatWrapIter(t, '{_i:>2}|{_i:<2}', '|'):
            pass

# Generated at 2022-06-22 05:03:20.929620
# Unit test for function product
def test_product():
    from .utils import _range
    assert list(product([1])) == [(1,)]
    assert list(product(_range(3))) == [(0, 1, 2)]
    assert list(product(_range(3), _range(4))) == [(0, 0),
                                                   (0, 1),
                                                   (0, 2),
                                                   (0, 3),
                                                   (1, 0),
                                                   (1, 1),
                                                   (1, 2),
                                                   (1, 3),
                                                   (2, 0),
                                                   (2, 1),
                                                   (2, 2),
                                                   (2, 3)]

# Generated at 2022-06-22 05:03:24.173924
# Unit test for function product
def test_product():
    with tqdm_auto(total=3*3*3) as pbar:
        for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
            pbar.update()
        pbar.close()

# Generated at 2022-06-22 05:03:34.882871
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from nose.tools import assert_equal
    from random import randint
    # Test 1
    it = product([1, 2, 3], ["a", "b", "c"], tqdm_class=None)
    assert_equal(''.join(x for x in it), "1a1b1c2a2b2c3a3b3c")
    # Test 2
    it = product([1, 2, 3], ["a", "b", "c"], tqdm_class=tqdm_auto)
    assert_equal(''.join(x for x in it), "1a1b1c2a2b2c3a3b3c")
    # Test 3

# Generated at 2022-06-22 05:03:45.904549
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    try:
        import random
    except ImportError:
        return
    try:
        from numpy.random import choice
    except ImportError:
        choice = random.choice
    try:
        from numpy import product
    except ImportError:
        def product(seq):
            r = 1
            for _ in seq:
                r *= _
            return r
    for i in range(10):
        a = range(choice(2, 11))
        b = range(choice(2, 11))
        c = range(choice(2, 11))

        p = list(product(a, b, c))
        assert len(p) == product((len(a), len(b), len(c)))

# Generated at 2022-06-22 05:03:57.002945
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # trivial object
    i = iter(range(5))
    t = list(i)
    assert t == list(product(i))

    # itertools.product()
    i = itertools.count()
    assert list(itertools.islice(itertools.product(*[i] * 3), 10)) == \
           list(itertools.islice(product(*[i] * 3), 10))
    i = iter(range(5))
    assert list(itertools.islice(itertools.product(*[i] * 3), 10)) == \
           list(itertools.islice(product(*[i] * 3), 10))
    i = itertools.count()

# Generated at 2022-06-22 05:04:07.244529
# Unit test for function product
def test_product():
    from itertools import repeat
    import random

    class MockTqdm(object):
        def __init__(self, total):
            self.total = total
            self.n = 0

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

        def update(self, n=1):
            self.n += n

    class MockTqdmNoUpdate(object):
        def __init__(self, total):
            self.total = total

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

    random.seed(1)
    # Generator product

# Generated at 2022-06-22 05:04:17.353588
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range, pretest

    @with_setup(pretest)
    def test():
        for tb in [tqdm, tqdm_gui, tqdm_notebook, trange]:
            a = list(product([1, 2, 3], tqdm_class=tb))
            b = [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1),
                 (3, 2), (3, 3)]
            assert a == b, 'product([1, 2, 3], tqdm_class={0})={1} != {2}' \
                .format(tb.__name__, a, b)


# Generated at 2022-06-22 05:04:19.040628
# Unit test for function product
def test_product():
    """
    Unit test for `product`.
    """
    for i in product(range(10), repeat=3):
        pass