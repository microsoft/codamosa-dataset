

# Generated at 2022-06-22 04:56:15.541237
# Unit test for function product
def test_product():
    from .tqdm import tqdm_govhack
    from .utils import format_sizeof
    from itertools import product; from sys import getsizeof
    from time import sleep

    def powerset(iterable):
        "powerset([1,2,3]) --> () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"
        s = list(iterable)
        return chain.from_iterable(combinations(s, r) for r in range(1, len(s)+1))

    def test(n=10, steps=2, desc='', leave=True, langs=False):
        # Test
        x = powerset(range(n))

# Generated at 2022-06-22 04:56:27.036340
# Unit test for function product
def test_product():
    from ._utils import FakeTqdmFile
    from ._utils import StringIO, closing

    def test_eq(it, r):
        for i in it:
            pass
        assert i == r

    with closing(StringIO()) as our_file:
        test_eq(product(A=range(3), tqdm_class=tqdm_auto,
                        file=our_file), (2,))
        test_eq(product(A=range(3), B=range(3), tqdm_class=tqdm_auto,
                        file=our_file), (2, 2))
        test_eq(product(A=range(3), B=range(3), C=range(3), tqdm_class=tqdm_auto,
                        file=our_file), (2, 2, 2))

        test

# Generated at 2022-06-22 04:56:33.523425
# Unit test for function product
def test_product():
    import numpy as np
    import tqdm

    def idx2ij(idx):
        return ((idx // 3) + 1, (idx % 3) + 1)

    for idx, ijv in tqdm.tqdm(
            enumerate(product(range(3), range(3), [1.0, 2.0])),
            total=18,
            desc="Testing"):
        i, j, v = idx2ij(idx), ijv
        assert i[0] == ijv[0]
        assert i[1] == ijv[1]
        assert v == ijv[2]
        np.testing.assert_array_equal(i, idx2ij(idx))

# Generated at 2022-06-22 04:56:40.623986
# Unit test for function product
def test_product():
    assert list(product(range(5), range(1))) == [(0, 0), (1, 0), (2, 0),
                                                (3, 0), (4, 0)]
    assert list(product(range(1), range(3))) == [(0, 0), (0, 1), (0, 2)]
    assert list(product(range(2), repeat=2)) == [(0, 0), (1, 0),
                                                 (0, 1), (1, 1)]
    assert list(product(range(1), range(1), range(2))) == [(0, 0, 0),
                                                           (0, 0, 1)]

# Generated at 2022-06-22 04:56:51.528606
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy.testing import assert_almost_equal

    def test(a, b):
        c = []
        for i in product(a, b):
            c += [i]
        assert c == list(itertools.product(a, b))

    test([1], [])
    test([], [])
    test([], [1])
    test([1, 2], [])
    test([], [1, 2])
    test([1, 2], [1, 2])

    total = 1
    c = 1000  # > len(tqdm._decs), so that desc will be nulled
    a = list(randint(0, 10, size=(c,)))
    b = list(randint(0, 10, size=(c,)))

# Generated at 2022-06-22 04:56:59.892293
# Unit test for function product
def test_product():
    from .tests import closing, in_new_session
    with closing(in_new_session(disable=["tqdm_gui", "tqdm", "tqdm_notebook"])):
        for _ in product([1, 2, 3]):
            pass
    with closing(in_new_session(disable=["tqdm_gui", "tqdm_notebook", "tqdm"])):
        with tqdm_auto(total=27) as t:
            for i in product([1, 2, 3], [1, 2], [1, 2, 3]):
                assert sum(i) <= 6
                t.update()

# Generated at 2022-06-22 04:57:11.619573
# Unit test for function product
def test_product():
    import sys
    import warnings
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    from os import getenv
    from os.path import join
    from os.path import dirname
    from os import listdir
    from os.path import isdir
    from os.path import isfile
    from os.path import exists
    import timeit
    import math

   

# Generated at 2022-06-22 04:57:17.408725
# Unit test for function product
def test_product():
    """
    Tests itertools.product with tqdm
    """
    assert sum(1 for i in product(range(10000), range(10000), tqdm_class=tqdm_auto)) == 100000000
    assert sum(1 for i in product(range(1000), range(1000), tqdm_class=tqdm_auto)) == 1000000
    assert sum(1 for i in product(range(100), range(100), tqdm_class=tqdm_auto)) == 10000
    assert sum(1 for i in product(range(10), range(10), tqdm_class=tqdm_auto)) == 100

# Generated at 2022-06-22 04:57:22.629136
# Unit test for function product
def test_product():
    for x in product([[0, 1], [[1, 2], [3, 4], [5, 6]]], tqdm_class=tqdm_auto,
                     desc="test_product"):
        assert isinstance(x, tuple)

# Generated at 2022-06-22 04:57:33.732885
# Unit test for function product
def test_product():
    """Unit test for product"""
    list(product("ABC", repeat=2,
                 tqdm_class=lambda *x, **k: tqdm_auto(total=9),
                 desc="multi"))
    list(product("ABC", repeat=2,
                 tqdm_class=lambda *x, **k: tqdm_auto(total=9)))

    # See issue #431
    list(product("ABC", repeat=2,
                 tqdm_class=lambda *x, **k: tqdm_auto(total=None),
                 desc="multi"))
    list(product("ABC", repeat=2,
                 tqdm_class=lambda *x, **k: tqdm_auto(total=None)))



# Generated at 2022-06-22 04:57:38.874034
# Unit test for function product
def test_product():  # pragma: no cover
    for i in product(range(10), 'abc', tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 04:57:44.041936
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product(range(2), range(2), range(2))) == [
        (0, 0, 0), (0, 0, 1),
        (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1),
        (1, 1, 0), (1, 1, 1),
    ]

# Generated at 2022-06-22 04:57:54.523126
# Unit test for function product
def test_product():
    """ Test for products """
    from .tests_tqdm import with_setup, _range
    from .tests_tqdm import pretest_posttest

    # setup
    global L, finished_order
    pretest_posttest()
    L = []
    finished_order = set()

    # Simple product
    for _ in product(_range(100), repeat=2, desc="testing",
                     mininterval=0.05):
        assert 0.05 <= _  # check mininterval
        L.append(_)
        finished_order.add(_[0])  # check ordering

    # Nested products
    L = []
    import math

# Generated at 2022-06-22 04:58:00.940669
# Unit test for function product
def test_product():
    prd = product(range(100), desc="Product")
    iprd = itertools.product(range(100))
    for i, j in zip(iprd, prd):
        assert i == j
    prd = product(range(100), range(50), desc="Product")
    iprd = itertools.product(range(100), range(50))
    for i, j in zip(iprd, prd):
        assert i == j

# Generated at 2022-06-22 04:58:12.905826
# Unit test for function product
def test_product():
    """Test function ``product()``"""
    s = '0123456789'
    total = 0
    for i, _ in enumerate(product(s, repeat=2)):
        total += i
    assert total == 2025

    total = 0
    for i, _ in enumerate(product(s, repeat=2, total=5)):
        total += i
    assert total == 10

    total = 0
    for i, _ in enumerate(product(s, repeat=2, total=None)):
        total += i
    assert total == 2025

    total = 0
    for i, _ in enumerate(product(s, repeat=2, total=5)):
        total += i
    assert total == 10

    total = 0

# Generated at 2022-06-22 04:58:24.453440
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    lst1 = [1, 2, 3]
    lst2 = [4, 5, 6]
    lst3 = [7, 8, 9]
    for i, j, k in product(lst1, lst2, lst3):
        it = next(itertools.product(lst1, lst2, lst3))
        assert_equal((i, j, k), it)
    # With `total`
    I, J, K = [], [], []
    for i, j, k in product(lst1, lst2, lst3, total=27):
        I.append(i)
        J.append(j)
        K.append(k)

# Generated at 2022-06-22 04:58:30.849478
# Unit test for function product
def test_product():
    """
    Example of use function product (see tqdm._tqdm_test.test_tqdm)
    """
    from .._tqdm_test import pretest_posttest
    iterables = [range(3), range(3), range(3)]
    out = pretest_posttest(itertools.product, iterables=iterables)
    assert out == pretest_posttest(product, iterables=iterables)

# Generated at 2022-06-22 04:58:42.844675
# Unit test for function product
def test_product():
    """
    Unit testing with py.test
    """
    from pytest import raises

    with raises(TypeError):
        list(product("ABC", range(10)))

    with raises(TypeError):
        list(product("ABC", range(10), total=10))

    with raises(TypeError):
        list(product("ABC", range(10), tqdm_class=int))

    with raises(TypeError):
        list(product("ABC", range(10), tqdm_class=str))


# Generated at 2022-06-22 04:58:50.180386
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    import numpy.testing as npt

    X = np.random.rand(33, 3)
    Y = np.random.rand(33, 5)
    Z = np.random.rand(33, 7)
    for x, y, z in product(X, Y, Z):
        npt.assert_allclose(x, X)
        npt.assert_allclose(y, Y)
        npt.assert_allclose(z, Z)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 04:58:59.227851
# Unit test for function product
def test_product():
    """Simple unit test for `itertools.product`"""
    assert list(product(range(3), repeat=3)) == list(itertools.product(range(3), repeat=3))
    assert list(product([1, 2, 3], repeat=2)) == list(itertools.product([1, 2, 3], repeat=2))
    assert list(product([1, 2, 3], [4, 5], [6, 7])) == list(itertools.product([1, 2, 3], [4, 5], [6, 7]))

# Generated at 2022-06-22 04:59:10.891179
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np
    all_close = lambda x, y: np.allclose(list(x), list(y))
    assert all_close(product([], repeat=3), [])
    assert all_close(product([[],[]], repeat=3), [])

# Generated at 2022-06-22 04:59:20.115756
# Unit test for function product
def test_product():
    import random
    rng = random.Random(42)

    from .utils import TestTqdmTypeError, TestTqdmIOError

    def gen_list(l):
        for i in l:
            yield i

    for tqdm_class in [TestTqdmTypeError, TestTqdmIOError, tqdm_auto]:
        with tqdm_class(total=10) as t:
            for i in product(range(10), [3], range(10, 0, -1), tqdm_class=tqdm_class):
                t.update()

        with tqdm_class(total=10) as t:
            for i in product(range(10), [3], range(10, 0, -1), tqdm_class=tqdm_class):
                t.update()

       

# Generated at 2022-06-22 04:59:30.632452
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.testing import assert_equal
    from six.moves import range
    from .utils import truncate_cr
    with tqdm_auto(total=2310) as t:
        assert_equal(
            list(product(range(10), repeat=2)),
            list(map(tuple, itertools.product(range(10), repeat=2))))
    assert_equal(str(t),
                 '10it [00:00, 191.87it/s]')
    assert_equal(truncate_cr(t.format_meter),
                 '10it [00:00, 191.87it/s]')

# Generated at 2022-06-22 04:59:42.388133
# Unit test for function product
def test_product():
    """ Tests for `product()` """
    from numpy.testing import assert_raises
    with tqdm_auto(total=3) as t:
        # simple
        result = []
        for x in product(range(2), range(2), range(2)):
            result.append(x)
            t.update()
        assert result == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                          (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

        # list
        result = []
        for x in product(range(2), [], range(2)):
            result.append(x)
            t.update()

# Generated at 2022-06-22 04:59:49.430235
# Unit test for function product
def test_product():
    """
    Test `product` function.
    """
    # Disable tqdm output
    from os import devnull
    import sys
    f = open(devnull, 'w')
    _stdout = sys.stdout
    sys.stdout = f

    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import itertools

    def get_size(iterator):
        "Measures size of the given iterable in bytes."
        import os
        import resource
        import sys
        try:
            y = list(iterator)
        except Exception as e:
            raise e
        f = sys._getframe()
        size = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return size - f.f_locals["size"]


# Generated at 2022-06-22 04:59:59.426288
# Unit test for function product
def test_product():
    from io import StringIO
    from random import randint
    from sys import stdin, stdout
    from os import devnull
    fout = StringIO()
    fnull = open(devnull, 'w')
    n = 5
    it = product(range(n), range(n), range(n), range(n),
                 tqdm_class=tqdm_auto, file=fout)
    for _ in it:
        pass
    fout.seek(0)
    assert n ** 4 == len(fout.readlines())
    fout.close()
    fnull.close()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:00:00.754089
# Unit test for function product
def test_product():
    from .tests import test_product
    test_product(product)

# Generated at 2022-06-22 05:00:12.691322
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import numpy as np
    from ..utils import format_sizeof
    from time import time
    t0 = time()
    pro_gen = product(range(500), range(500), tqdm_class=tqdm_auto)
    pro_gen = list(pro_gen)
    assert len(pro_gen) == 500 ** 2
    print("-> {} ok: product of two 500-sized iterables => {} "
          "in {:.4f}s".format(format_sizeof(pro_gen), len(pro_gen),
                              time() - t0))
    t0 = time()
    a = np.arange(5000)
    pro_gen = product(a, tqdm_class=tqdm_auto)

# Generated at 2022-06-22 05:00:20.150085
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    ABC = list("ABC")
    for i in range(4):
        for prod in product(ABC, repeat=i, desc="product(ABC, repeat={}) - {}"
                            .format(i, format_sizeof(len(ABC) ** i)), unit="it"):
            pass

# Generated at 2022-06-22 05:00:29.367600
# Unit test for function product
def test_product():
    # Test 1
    from tqdm.tests import pretest_posttest
    for result in pretest_posttest(
            product, 'ab', 'xy', tqdm_class=tqdm_auto,
            total=None, leave=True, ascii=True):
        assert result == "a x\nab xy\n"

    # Test 2
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        list((f.write(i), f.write(b'\n'))
             for i in product('ab', 'xy', tqdm_class=tqdm_auto))
        f.flush()
        with open(f.name) as f2:
            assert f2.read() == "a x\nab xy\n"



# Generated at 2022-06-22 05:00:43.409248
# Unit test for function product
def test_product():
    from .utils import TestTqdmIter

    assert list(TestTqdmIter(product, range(3), range(3))) == list(itertools.product(range(3), range(3)))

    assert list(TestTqdmIter(product, [], range(3))) == list(itertools.product([], range(3)))

# Generated at 2022-06-22 05:00:56.368395
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys
    try:
        from time import monotonic
    except ImportError:
        from time import time as monotonic

    print('Testing itertools.product + tqdm... ', end='')

# Generated at 2022-06-22 05:00:57.339054
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    list(product([1,2,3], description="testing"))

# Generated at 2022-06-22 05:01:03.051163
# Unit test for function product
def test_product():
    """
    The following is a basic unit test for the itertools.product
    wrapper.
    """
    from .._utils import FakeTQDM

    fake = FakeTQDM()

    a = [1, 2, 3]
    b = [4, 5, 6]
    c = itertools.product(a, b)

    for i in product(a, b, tqdm_class=fake):
        assert i == c.next()

# Generated at 2022-06-22 05:01:06.920498
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    for i in product([1, 2], ['a']):
        print(i)
        break

# Generated at 2022-06-22 05:01:12.203154
# Unit test for function product
def test_product():
    r = product(range(10), repeat=3, tqdm_class=tqdm_auto.tqdm(
        unit_scale=True, miniters=1))
    assert hasattr(r, '__iter__')
    list(r)  # consume for coverage
    assert hasattr(r, 'n')
    assert r.n == 1000

# Generated at 2022-06-22 05:01:23.671354
# Unit test for function product
def test_product():
    """
    Test function product()
    """
    import sys
    import os
    import random
    import time
    import tempfile
    import subprocess
    import _tqdm

    tempdir = tempfile.mkdtemp()
    cwd = os.getcwd()

# Generated at 2022-06-22 05:01:31.121226
# Unit test for function product
def test_product():
    """Test for the function `product`."""
    from nose.tools import assert_equal
    from ..utils import SimpleNamespace

    for tqdm_class in (tqdm_auto,
                       SimpleNamespace(update=lambda x: None,
                                       close=lambda x: None)):
        assert_equal(list(product([1, 2], repeat=2,
                                  tqdm_class=tqdm_class)),
                     [(1, 1), (1, 2), (2, 1), (2, 2)])

        raises = []

# Generated at 2022-06-22 05:01:40.546707
# Unit test for function product
def test_product():
    from itertools import product as it_product
    from .compat import StringIO
    import sys

    try:
        from nose.tools import assert_equal
    except ImportError:
        from .compat import assert_equal

    class UnitestTqdm(tqdm_auto):
        # Testing `total` kwarg
        def __init__(self, *args, **kwargs):
            # Get total items
            self.total = kwargs.get('total', None)
            super(UnitestTqdm, self).__init__(*args, **kwargs)
        # Testing `leave` kwarg
        def __exit__(self, exc_type, exc_val, exc_tb):
            if getattr(self, 'leave', False):
                return super(UnitestTqdm, self).__exit

# Generated at 2022-06-22 05:01:44.549919
# Unit test for function product
def test_product():
    """
    Unit test for function `product`
    """
    from . import common_tests
    common_tests.test_product(
        product, lambda *a, **k: itertools.product(*a, **k),
        lambda *a, **k: list(itertools.product(*a, **k)))

# Generated at 2022-06-22 05:02:16.040343
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    with tqdm_auto(desc="0") as t0:
        assert_equal(list(product(t0, range(3), range(3), range(3))),
                     list(product(range(3), range(3), range(3))))
    with tqdm_auto(desc="1") as t1:
        assert_equal(list(product(range(3), t1, range(3), range(3))),
                     list(product(range(3), range(3), range(3))))
    with tqdm_auto(desc="2") as t2:
        assert_equal(list(product(range(3), range(3), t2, range(3))),
                     list(product(range(3), range(3), range(3))))

# Generated at 2022-06-22 05:02:28.522555
# Unit test for function product
def test_product():
    from random import randint
    from ..utils import freezing_support, write_fileobj
    from .std import format_interval

    def identity(x):
        return x


# Generated at 2022-06-22 05:02:31.783779
# Unit test for function product
def test_product():
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))
    assert list(product(range(3), range(3), tqdm_class=None)) == list(itertools.product(range(3), range(3)))

# Generated at 2022-06-22 05:02:42.016448
# Unit test for function product
def test_product():
    """Test function product"""
    import gc

    def check_eq(a, b):
        """Check if `a == b`"""
        assert a == b
    if hasattr(itertools, "izip"):
        check_eq(list(itertools.izip("abc", "def")),
                 list(itertools.zip("abc", "def")))
    else:
        check_eq(list(itertools.zip("abc", "def")),
                 list(zip("abc", "def")))

    assert len(list(product("abc", "def", repeat=2))) == len("abcdef") ** 2
    assert list(product("abc", "def")) == list(itertools.product("abc", "def"))

# Generated at 2022-06-22 05:02:47.023110
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`."""
    from ..utils import _term_move_up
    from ..tests._utils import format_sizeof
    import tempfile
    import sys
    t = tempfile.TemporaryFile(mode='w+t')
    i = product(range(5), range(5), range(5), tqdm_class=tqdm_auto)
    for ii in i:
        pass
    t.read()
    t.seek(0)
    assert "125it [" in t.read()
    _, N = tqdm_auto.format_interval(0)
    assert "125it" in N
    assert "in" in N

    # unit test for very fast processes
    t = tempfile.TemporaryFile(mode='w+t')

# Generated at 2022-06-22 05:02:57.702552
# Unit test for function product
def test_product():
    import pytest
    from tqdm._utils import _range

    def wrapper(*a, **kw):
        return list(product(*a, **kw))

    for tqdm_cls in [tqdm_auto, tqdm_auto.tqdm]:
        for a in [0, 1, 2, 100]:
            for b in [0, 1, 2, 100]:
                for c in [0, 1, 2, 100]:
                    # Ensure total counter is correct
                    assert wrapper(
                        _range(a),
                        _range(b),
                        _range(c), tqdm_class=tqdm_cls) == list(
                            itertools.product(_range(a),
                                              _range(b),
                                              _range(c)))
                    # Ensure post fix works
                    f = wrapper

# Generated at 2022-06-22 05:03:07.529471
# Unit test for function product
def test_product():
    from .tqdm_gui import trange
    from .utils import FormatCustomTextExtension
    from .._tqdm import tqdm
    from ..std import os
    from ..std import inspect
    from collections import namedtuple
    from ..std.tests import Mock, call

    class TqdmFile(object):
        def __init__(self, name, mode='w'):
            self.name = name
            self.mode = mode
        def close(self):
            pass

    class TqdmIO(object):
        # https://stackoverflow.com/a/48592512/355230
        @staticmethod
        def open(*args, **kwargs):
            return TqdmFile(*args, **kwargs)

    # Monkey patch
    old_cwd = os.getcwd()
    os

# Generated at 2022-06-22 05:03:09.251204
# Unit test for function product
def test_product():
    from . import _test_iters
    _test_iters(itertools.product, product)

# Generated at 2022-06-22 05:03:18.744212
# Unit test for function product
def test_product():
    from .tests_cover import random_state
    for total in [None, 1, 10]:
        for tqdm_class in [tqdm_auto, tqdm_auto.tqdm, tqdm_auto.tqdm_gui,
                           tqdm_auto.trange]:
            out = list(product(range(3), repeat=3, total=total,
                               tqdm_class=tqdm_class))
            assert out == list(itertools.product(range(3), repeat=3))
    assert random_state.check_state()

# Generated at 2022-06-22 05:03:24.369521
# Unit test for function product
def test_product():
    from ..utils import Percentage
    import random

    size = 100
    list1 = [random.randint(0, 1000) for _ in range(size)]
    list2 = [random.randint(0, 1000) for _ in range(size)]
    list3 = [random.randint(0, 1000) for _ in range(size)]

    for l in product(list1, list2, list3, tqdm_class=Percentage):
        pass
    print("Success for function product")

# Generated at 2022-06-22 05:04:16.090815
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..tests.tests_tqdm import StringIO
    from random import randint

    # Shorthand
    product = tqdm_itertools.product

    # Test simple case
    assert list(product(range(3), range(3))) == list(itertools.product(range(3),
                                                                       range(3)))
    # Test with capture_output
    test_str = '123'
    with tqdm_itertools.capture_output() as io:
        for _ in product(test_str, test_str, test_str):
            pass

# Generated at 2022-06-22 05:04:23.064218
# Unit test for function product
def test_product():
    import numpy as np

    # Permutation by group
    keys = ['a', 'b', 'c']
    n = [2, 3, 4]
    # Simple product
    assert list(product(n)) == [(i,) for i in n]
    # Cartesian product
    assert list(product(*[n] * 3)) == [(i, j, k) for i in n for j in n for k in n]
    # Permutation by group
    assert list(product(n, keys)) == [(i, k) for k in keys for i in n]
    assert len(list(product(n, keys))) == 3 * len(n)
    assert list(product(n, [keys])) == list(product(n, keys))
    keys = ('a', 'b')

# Generated at 2022-06-22 05:04:33.200726
# Unit test for function product
def test_product():
    import numpy as np
    assert (list(product(range(2), repeat=2, tqdm_class=None)) ==
            [i for i in itertools.product(range(2), repeat=2)])
    assert (list(product(range(2), repeat=2)) ==
            [i for i in itertools.product(range(2), repeat=2)])
    assert (list(product(range(2), repeat=2, total=4)) ==
            [i for i in itertools.product(range(2), repeat=2)])
    assert (list(product(range(2), repeat=2, total=3)) ==
            [i for i in itertools.product(range(2), repeat=2)])

# Generated at 2022-06-22 05:04:43.967910
# Unit test for function product
def test_product():
    from tqdm.utils import _range
    # No change
    assert list(product(foo=_range(3), bar=_range(3))) == \
        list(itertools.product(_range(3), _range(3)))
    # No total
    assert list(product(foo=_range(3), bar={3, 4})) == \
        list(itertools.product(_range(3), {3, 4}))
    # Total
    assert list(product(foo=_range(5), bar=_range(3))) == \
        list(itertools.product(_range(5), _range(3)))

    # Test total is calculated correctly

# Generated at 2022-06-22 05:04:55.117547
# Unit test for function product
def test_product():
    """Test itertools.product"""
    assert list(product(range(0), range(1), range(2), tqdm_class=None)) == [
        (0, 0, 0), (0, 0, 1)]
    assert list(product(range(1), range(2), tqdm_class=None)) == [
        (0, 0), (0, 1)]
    assert list(product(range(2), tqdm_class=None)) == [(0,), (1,)]
    assert list(product(range(0), tqdm_class=None)) == []
    assert list(tqdm_auto(product(range(0), range(1), range(2)))) == [
        (0, 0, 0), (0, 0, 1)]

# Generated at 2022-06-22 05:05:01.664809
# Unit test for function product
def test_product():
    """Test function product."""
    # Example 1
    iterables = range(10), range(20)

    output = product(*iterables, tqdm_class=tqdm_auto)
    for i in output:
        pass

    # Example 2
    iterables = range(10), range(20)

    output = product(*iterables, tqdm_class=tqdm_auto)
    for i in output:
        pass

# Generated at 2022-06-22 05:05:10.307903
# Unit test for function product
def test_product():
    import numpy as np

    def gen():
        for i in range(10):
            yield i

    assert np.all(np.array(list(product(gen()))) == np.array(list(itertools.product(gen()))))
    it1 = range(10)
    it2 = range(10)
    assert np.all(np.array(list(product(it1, it2))) == np.array(list(itertools.product(it1, it2))))

    # Iterator as input
    it1 = iter(range(10))
    assert np.all(np.array(list(product(it1, it1))) == np.array(list(itertools.product(it1, it1))))
    # Check total

# Generated at 2022-06-22 05:05:12.507158
# Unit test for function product
def test_product():
    import warnings
    warnings.filterwarnings("ignore")  # nosec

    with tqdm_auto(total=4) as t:
        for i in range(4):
            t.update()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:05:14.597147
# Unit test for function product
def test_product():
    from .tests import _test_unit_var_kwargs_loop

    def func(**kwargs):
        it = product(*([1], ), **kwargs)
        for _ in it:
            pass

    _test_unit_var_kwargs_loop(func)

# Generated at 2022-06-22 05:05:18.403812
# Unit test for function product
def test_product():
    """ Unit tests for `itertools.product` wrapper """
    _ = list(product([1, 2], [3]))  # 2
    _ = list(product([1, 2], [3], [4]))  # 8
    _ = list(product([1, 2], [3], [4], [5]))  # 20
    _ = list(product([1, 2], repeat=4))  # 16
    _ = list(product(range(3), repeat=3))  # 27
    _ = list(product([1, 2], [3, 4], [5, 6], [7, 8]))  # 32


if __name__ == '__main__':  # pragma: no cover
    test_product()