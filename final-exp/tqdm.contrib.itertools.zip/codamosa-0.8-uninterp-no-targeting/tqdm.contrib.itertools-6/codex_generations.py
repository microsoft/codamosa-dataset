

# Generated at 2022-06-22 04:56:18.778118
# Unit test for function product
def test_product():
    from ..tests.test_tqdm import has_unicode
    iterables = [[0, 1, 2], [0, 1, 2]]
    results = list(itertools.product(*iterables))
    assert results == list(product(*iterables))
    results = list(itertools.product(*iterables))
    assert results == list(product(*iterables, desc=None))
    results = list(itertools.product(*iterables))
    assert results == list(product(*iterables, desc="f"))
    results = list(itertools.product(*iterables))
    assert results == list(product(*iterables, desc=u"n"))
    results = list(itertools.product(*iterables))
    assert results == list(product(*iterables, desc=u"n"))

# Generated at 2022-06-22 04:56:29.161133
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatWarnings
    with FormatWarnings():
        try:
            import importlib
            importlib.reload(itertools)
        except TypeError:
            # python 2 does not have reload for modules
            from imp import reload as importlib_reload
            importlib_reload(itertools)

    from .tests import TestCase
    from ..utils import BinaryIO

    class ProductTest(TestCase):
        def test_product(self):
            """Test product"""
            from datetime import datetime as dt

            def _test(test_input, test_output, tqdm_kwargs=None,
                      **kwargs):
                it = product(*test_input, **((tqdm_kwargs or {}).copy()))

# Generated at 2022-06-22 04:56:39.617632
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_almost_equal
    from .utils import FakeTqdmFile

    def f(*args, **kwargs):
        """
        args[0] : iterables, args[1] : *,args
        """
        iterables = args[0]
        args = args[1]
        kwargs = kwargs['kwargs']
        if len(args) == 0:
            return itertools.product(*iterables)
        else:
            return itertools.product(*iterables, *args)
    with FakeTqdmFile() as f:
        with tqdm_auto(ascii=True, file=f, miniters=1) as t:
            # Test empty iterable and different iterable lengths
            assert_array_almost_equal

# Generated at 2022-06-22 04:56:45.044870
# Unit test for function product
def test_product():
    """Test for product."""
    assert (list(product(range(1000), range(1000))) ==
            list(itertools.product(range(1000), range(1000))))
    assert (list(product(range(1000), range(1000), total=0)) ==
            [])

# Generated at 2022-06-22 04:56:55.914811
# Unit test for function product
def test_product():
    import operator
    import sys
    assert list(product(range(3))) == [(0,), (1,), (2,)]

# Generated at 2022-06-22 04:57:04.331394
# Unit test for function product
def test_product():
    """Test the function product"""
    from .tests_tqdm_class import TqdmTypeError, TqdmWarning, TqdmExperimentalWarning, TqdmDeprecationWarning
    from .._tqdm import TqdmTypeError, TqdmWarning, TqdmExperimentalWarning, TqdmDeprecationWarning
    list(product(range(10), repeat=2))

    with tqdm_auto.tqdm(total=10) as t:
        list(product(range(10), repeat=2, tqdm_class=type(t)))
    with tqdm_auto.tqdm(total=10) as t:
        list(product(range(10), repeat=2, tqdm_class=type(t), desc="Test"))

# Generated at 2022-06-22 04:57:16.553997
# Unit test for function product
def test_product():
    from sys import version_info
    
    if version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO
    
    from os import linesep
    from tempfile import TemporaryFile
    from contextlib import contextmanager
    from functools import partial
    
    # Check context manager
    with TemporaryFile() as f:
        @contextmanager
        def tgr():
            yield f
        with tgr() as t:
            with tqdm(tgr(), tgr(), tgr(), tgr(),
                      tgr(), tgr(), tgr(), tgr(),
                      tgr(), tgr(), tgr(), tgr(),
                      tgr(), tgr(), tgr(), tgr()) as t:
                for x in t:
                    pass
    
    # Check that errors are not swallowed

# Generated at 2022-06-22 04:57:29.191349
# Unit test for function product
def test_product():
    """Unit test for function product"""
    try:
        import numpy as np
    except ImportError:
        np = None


# Generated at 2022-06-22 04:57:33.971607
# Unit test for function product
def test_product():
    """Test itertools.product wrapper"""
    from numpy import arange
    pr1 = product(arange(5), arange(3))
    pr2 = itertools.product(arange(5), arange(3))
    assert sum(pr1) == sum(pr2)

# Generated at 2022-06-22 04:57:41.459002
# Unit test for function product
def test_product():
    """Simple unit test"""
    assert list(product(["A", "B", "C"], "D", range(3), tqdm_class=None)) == [
        ("A", "D", 0), ("A", "D", 1), ("A", "D", 2),
        ("B", "D", 0), ("B", "D", 1), ("B", "D", 2),
        ("C", "D", 0), ("C", "D", 1), ("C", "D", 2)
    ]

# Generated at 2022-06-22 04:57:54.355568
# Unit test for function product
def test_product():
    from datetime import datetime
    from itertools import count
    from io import BytesIO
    from .tqdm_gui import tqdm

    def test_dummy(tqdm_func, **kwargs):
        iter1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        iter2 = ['a', 'b', 'c', 'd']
        iter3 = ['A', 'B']
        for _ in tqdm_func(itertools.product(iter1, iter2, iter3),
                           desc='foobar', **kwargs):
            pass

    test_dummy(tqdm, mininterval=1)

    # Instanciate a dummy `BytesIO` object to catch stdout
    r_stdout = BytesIO()

    # Test

# Generated at 2022-06-22 04:58:04.936194
# Unit test for function product
def test_product():
    """Test function product"""
    def x():
        # test progressbar position
        yield 'x'
        yield 'y'
        yield 'z'
    def y():
        # test auto-total
        for i in range(10**3):
            yield i
    for i in product(x(), y()):
        pass
    for i in product(range(2**11), range(2**11), tqdm_class=tqdm_auto):
        pass
    from tqdm import trange as tqdm_trange
    for i in product(range(2**11), range(2**11), tqdm_class=tqdm_trange):
        pass
    for i in product(range(2**11), range(2**11), tqdm_class=tqdm_auto):
        pass



# Generated at 2022-06-22 04:58:16.211603
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..pbar import _range
    from .line import _delayed_import
    tqdm_obj = tqdm_auto(format=FormatCustomText(
        "{l_bar} {bar} {n_fmt}/{total_fmt} {postfix}"))
    for i in product(range(2), range(10), tqdm_obj):
        pass
    assert tqdm_obj.total == 20

    # Check nested
    tqdm_obj = tqdm_auto(format=FormatCustomText(
        "{l_bar} {bar} {n_fmt}/{total_fmt} {postfix}"))

# Generated at 2022-06-22 04:58:27.999604
# Unit test for function product
def test_product():
    # Setup
    from numpy.random import random
    from ..utils import format_sizeof
    from ..contrib.concurrent import thread_map

    try:
        from numpy import prod
        has_numpy = True
    except ImportError:
        has_numpy = False

    def prod_helper(args):
        # Helper function for test
        return prod(args)

    def test(args, f, n, **kwargs):
        # Function to be tested, ``f``
        # Arguments, ``args``
        # Expected result, ``n``
        # Optional keyword arguments, ``kwargs``
        assert f(*args, **kwargs) == n
        try:
            assert f(*args, **kwargs, desc='') == n
        except TypeError:
            pass

# Generated at 2022-06-22 04:58:38.994873
# Unit test for function product
def test_product():
    import sys

    # Check if function product runs without error:
    list(product("abc", "123"))

    # Check if function product behaves like itertools.product:
    a = list(product("abc", "123"))
    b = list(itertools.product("abc", "123"))
    assert a == b

    # Check if function product works with short iterables:
    a = list(product("ab", "123"))
    b = list(itertools.product("ab", "123"))
    assert a == b

    # Check if function product works with empty iterables:
    a = list(product("", "123"))
    b = list(itertools.product("", "123"))
    assert a == b

    # Check if function product works with short messages:

# Generated at 2022-06-22 04:58:45.334015
# Unit test for function product
def test_product():
    from contextlib import closing
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    assert next(closing(product(list(range(i)),
                                                list(range(j)),
                                                list(range(k)),
                                                list(range(l))))) == (0, 0, 0, 0)

# Generated at 2022-06-22 04:58:51.009623
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from random import random
    for n, _total in [(lambda: 10**n, lambda n: 10**(n*2))[::-1]
                      for n in range(7)]:
        ns = (random()*n//1 for _ in range(n))
        total = _total(n)
        assert total is None or total == len(list(product(ns)))
    print("Test passed!")

# Generated at 2022-06-22 04:59:02.978152
# Unit test for function product
def test_product():
    import sys
    import math
    from .signals import set_term_title, set_monitor_interval
    try:
        import numpy
    except ImportError:
        numpy = False
    from .utils import format_sizeof
    from . import trange, tnrange
    from .utils import format_interval
    import time

    def test_product(iterables, tqdm_cls, *args, **kwargs):
        if 'numpy' not in tqdm_cls.__module__:
            numpy = False
        n = len(iterables)
        total = 1
        if not numpy:
            lens = list(map(len, iterables))
        else:
            lens = [numpy.prod(i.shape) for i in iterables]

# Generated at 2022-06-22 04:59:10.509152
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from .tests import closing, naturals, naturals_with_total

    assert list(product([1, 2, 3])) == list(itertools.product([1, 2, 3]))
    assert list(naturals(product([1, 2, 3]))) == list(itertools.product([1, 2, 3]))
    assert list(naturals(product([1, 2, 3], range(4)))) == list(itertools.product([1, 2, 3], range(4)))
    assert list(naturals_with_total(product([1, 2, 3], range(4)))) == list(itertools.product([1, 2, 3], range(4)))

# Generated at 2022-06-22 04:59:19.806372
# Unit test for function product
def test_product():
    """
    Test function `product`
    """
    from ..utils import format_sizeof
    import sys

    class MyClass(object):
        "Dummy class for testing product"
        def __init__(self, value1, value2, value3=0):
            self.value1 = value1
            self.value2 = value2
            self.value3 = value3

    def product(*args):
        "Equivalent of itertools.product"
        pools = map(tuple, args) * 2
        result = [[]]
        for pool in pools:
            result = [x + [y] for x in result for y in pool]
        for prod in result:
            yield tuple(prod)


# Generated at 2022-06-22 04:59:27.299489
# Unit test for function product
def test_product():
    """Test that product works like itertools works"""
    def g():
        for i in itertools.product(range(5), range(5)):
            yield i
    assert list(product(range(5), range(5))) == list(g())

# Generated at 2022-06-22 04:59:32.283525
# Unit test for function product
def test_product():
    """Test function product"""
    # Test without tqdm
    iterables = [[1], [2], [3]]
    prods = list(product(*iterables))
    assert prods == [(1, 2, 3)]
    # Test with tqdm
    prods = list(product(*iterables, tqdm_class=tqdm_auto))
    assert prods == [(1, 2, 3)]

# Generated at 2022-06-22 04:59:43.978115
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for i in product('ABCD', range(2), tqdm_class=tqdm_auto):
        assert i in ('A', 0, 'B', 1, 'C', 0, 'D', 1)
    for i in product('ABCD', repeat=2, tqdm_class=tqdm_auto):
        assert len(i) == 2
        assert i[0] in 'ABCD'
        assert i[1] in 'ABCD'
    for i in product(range(4), tqdm_class=tqdm_auto):
        assert i in (0, 1, 2, 3)
    for _ in product(tqdm_class=tqdm_auto):
        raise ValueError('Not empty iterator')

# Generated at 2022-06-22 04:59:52.156863
# Unit test for function product
def test_product():
    """Test for product()"""
    assert list(itertools.product(range(10))) == list(
        product(range(10)))
    assert list(itertools.product(range(10), repeat=2)) == list(
        product(range(10), repeat=2))
    assert list(itertools.product(range(10), range(10))) == list(
        product(range(10), range(10)))

# Generated at 2022-06-22 05:00:02.807528
# Unit test for function product
def test_product():
    """Sample function with PEP 484 type annotations.

    Args:
        param1: The first parameter.
        param2: The second parameter.

    Returns:
        True if successful, False otherwise.

    """
    TASK_FORMAT = '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'

    import time
    import sys

    if sys.version_info[0] > 2:
        input = raw_input
    # 1st test, with auto_display and ncols

# Generated at 2022-06-22 05:00:14.865271
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    from numpy.random import randint
    from numpy.testing import assert_array_equal

    iterables = [(1, 1), randint(0, 2, 10), randint(0, 10, 5)]
    iters = [map(tuple, itertools.product(*iterables[:i+1]))
             for i in range(len(iterables))]
    tqdms = [map(tuple, product(*iterables[:i+1]))
             for i in range(len(iterables))]
    tqdms_auto = [map(tuple, product(*iterables[:i+1], tqdm_class=tqdm_auto))
                  for i in range(len(iterables))]


# Generated at 2022-06-22 05:00:21.281709
# Unit test for function product
def test_product():
    """
        Unit test for product
    """

    def let():
        return list(range(3))

    assert list(product(let(), repeat=3)) == let() ** 3
    assert list(product(let(), repeat=3, tqdm_class=lambda x: x)) == let() ** 3

# Generated at 2022-06-22 05:00:30.296432
# Unit test for function product
def test_product():
    """Test the correctness of the `product` function"""
    from ..utils import format_sizeof
    import math

    def validate_product(iterables):
        # Check that product() generates the right number of elements
        n = 1
        for x in iterables:
            n *= len(list(x))
        res = list(product(*iterables))
        assert (len(res) == n)

        # Check that product() and product_imap() generate the same elements
        res2 = list(product(*iterables))
        assert (len(res2) == n)
        assert (res == res2)

    # Test for n = len(it) * ... * len(it)
    it = [range(i, i + 2) for i in range(3)]  # -> 2**3 = 8
    validate_product(it)

# Generated at 2022-06-22 05:00:34.680910
# Unit test for function product
def test_product():
    l = list(product("ABCD", "xy", tqdm_class=tqdm_auto))
    assert l == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                 ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

# Generated at 2022-06-22 05:00:45.634433
# Unit test for function product
def test_product():
    """
    Test `itertools.product` wrapper.
    """
    iterables_range = range(6)
    iterables_range_set = set(iterables_range)
    iterables_list = [1, 4, 6, 0]
    total = len(iterables_range) * len(iterables_list)
    ran_product = list(product(iterables_range, iterables_list))
    assert len(ran_product) == total
    for tup in ran_product:
        assert tup[0] in iterables_range_set
        assert tup[1] in iterables_list
    for tup in product(iterables_range, iterables_list, tqdm_class=None):
        assert tup[0] in iterables_range_set
        assert tup[1] in iter

# Generated at 2022-06-22 05:00:58.716902
# Unit test for function product
def test_product():
    # No total
    total_true, total_sum = None, 0
    for i, j in product(range(10), range(5)):
        total_sum += 1
    assert total_true is None
    assert total_sum == 50

    # Total
    total_true, total_sum = 1000, 0
    for i, j in product(range(10), range(5), tqdm_class=tqdm_auto, desc="Testing", total=total_true):
        total_sum += 1
    assert total_true == total_sum

# Generated at 2022-06-22 05:01:04.354703
# Unit test for function product
def test_product():
    from ..tqdm import trange
    from random import randint
    from time import sleep
    from ..utils import format_sizeof
    # full example:
    with trange(100) as t:
        for _ in product(range(100),
                         repeat=6,
                         tqdm=t,
                         tqdm_class=t.__class__,
                         miniters=0):
            sleep(0.01)
    # test if miniters=0 works with tqdm
    with trange(100) as t:
        for _ in product(range(100),
                         repeat=6,
                         tqdm=t,
                         tqdm_class=t.__class__,
                         miniters=0):
            sleep(0.01)
    # test that tqdm bar is updated properly
   

# Generated at 2022-06-22 05:01:15.482501
# Unit test for function product
def test_product():
    from random import randint, random
    for i in range(5):
        rng = randint(1, 6)
        kwargs = {"miniters": rng,
                  "total": rng}
        for j in range(5):
            kwargs["unit_scale"] = True
            if j % 2 == 0:
                kwargs["miniters"] = None
            else:
                kwargs["miniters"] = rng
            if j > 2:
                kwargs["total"] = None
            else:
                kwargs["total"] = rng
            iterables = [list(range(randint(500, 1000)))
                         for _ in range(rng)]
            samples = [[randint(0, 9), random()] for _ in range(rng)]

# Generated at 2022-06-22 05:01:21.000959
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..auto import tqdm

    assert sum(1 for _ in product(range(3), range(3), tqdm_class=tqdm)) == 9
    assert sum(1 for _ in product(range(3), range(3))) == 9

# Generated at 2022-06-22 05:01:26.629310
# Unit test for function product
def test_product():
    """Unit test for function product()"""
    assert list(product(range(10), repeat=1)) == list(
        itertools.product(range(10), repeat=1))
    assert list(product(range(10), repeat=2)) == list(
        itertools.product(range(10), repeat=2))
    assert list(product(range(10), repeat=4)) == list(
        itertools.product(range(10), repeat=4))

# Generated at 2022-06-22 05:01:33.247448
# Unit test for function product
def test_product():
    """Test function `product`."""
    # Test 1
    total = 0
    for _ in product(range(20), repeat=2, tqdm_class=tqdm_auto):
        total += 1
    assert total == 400

    # Test 2
    total = 0
    for _ in product(range(30), range(40), tqdm_class=tqdm_auto):
        total += 1
    assert total == 1200

# Generated at 2022-06-22 05:01:37.412133
# Unit test for function product
def test_product():
    from ..auto import trange
    a = trange(10)
    b = trange(10, 20)
    assert list(product(a, b, tqdm_class=lambda *x, **kw: x)) == list(zip(range(10), range(10, 20)))

# Generated at 2022-06-22 05:01:39.936171
# Unit test for function product
def test_product():
    from ..tests import _test_product
    _test_product()


if __name__ != "__main__":
    from .version import __version__
    del absolute_import, tqdm_auto

# Generated at 2022-06-22 05:01:45.124822
# Unit test for function product
def test_product():
    """Test function `product`."""
    import tqdm
    assert (''.join(map(str, i)) for i in product(
        '', '12', '34567', '...', tqdm_class=tqdm.tqdm)) == (
        ''.join(j) for j in product('', '12', '34567', '...'))

# Generated at 2022-06-22 05:01:55.323010
# Unit test for function product
def test_product():
    from ._utils import _range
    p = product(_range(3), _range(3))
    assert repr(p) == "<itertools.product object at 0x%x>" % id(p)
    assert list(p) == list(itertools.product(_range(3), _range(3)))

    p = product(_range(3), _range(3), tqdm_class=tqdm_auto)
    assert repr(p) == "<itertools.product object at 0x%x>" % id(p)
    assert list(p) == list(itertools.product(_range(3), _range(3)))

# Generated at 2022-06-22 05:02:15.131573
# Unit test for function product
def test_product():
    """Test for itertools.product wrapper."""
    from ..utils import FormatMixin
    from numpy.random import randint
    for kwargs in ({}, {"leave": False}):
        total = 0
        for i, _ in enumerate(product("ab", "cd", **kwargs)):
            total += 1
        assert total == 4
        with FormatMixin("{l_bar}{bar}"):
            for i, _ in enumerate(product("ab", "cd", **kwargs)):
                total += 1
        assert total == 8
        total = 0
        for i, _ in enumerate(product("ab", "cd", total=20, **kwargs)):
            total += 1
        assert total == 4

# Generated at 2022-06-22 05:02:23.654130
# Unit test for function product
def test_product():
    """Runs `tqdm.tqdm_gui.product` with 'unit test' as input.

    >>> from tqdm import tqdm_gui
    >>> list(tqdm_gui.product(['a', 'b', 'c'], ['d', 'e'], tqdm_class=tqdm_gui.tqdm))
    """
    for i in product(['a', 'b', 'c'], ['d', 'e'], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 05:02:32.547029
# Unit test for function product
def test_product():
    """Unit test of `product`"""
    # Test standard behaviour
    assert list(tqdm.product(
        range(5), range(5), range(5),
        tqdm_class=tqdm.tqdm.format_meter)) == list(itertools.product(
            range(5), range(5), range(5)))

    # Test total=None
    assert list(tqdm.product(
        range(5), range(5), range(5),
        tqdm_class=tqdm.tqdm.format_meter, total=None)) == list(itertools.product(
            range(5), range(5), range(5)))

    # Test errors
    assert list(tqdm.product(range(5), range(5), range(5), total=0)) == []

# Generated at 2022-06-22 05:02:42.466285
# Unit test for function product
def test_product():
    """
    $ python -m tqdm --test
    """
    from tqdm import tqdm, trange

    for chunksize in [1, 2, 3, 5, 10]:
        for n in trange(chunksize, 100):
            for repeats in [10, 100, 200]:
                t = []

# Generated at 2022-06-22 05:02:53.906091
# Unit test for function product
def test_product():
    """Test function product"""
    test_inputs = ['abc', 'def', 'ghi']
    test_output = ['abcdefghi']
    total = 1
    for i in map(len, test_inputs):
        total *= i
    test_output *= total
    test_output = list(test_output)
    output = list(product(test_inputs))
    assert output == test_output

    test_inputs = ['abcd', 'efgh', 'ijkl']
    test_output = ['abcdefghijkl']
    total = 1
    for i in map(len, test_inputs):
        total *= i
    test_output *= total
    test_output = list(test_output)
    output = list(product(test_inputs))
    assert output == test_output

# Generated at 2022-06-22 05:02:56.474583
# Unit test for function product
def test_product():
    from .tests import tests

    iterables = [range(100), range(100, 200)]
    for kwargs in tests:
        for x in product(*iterables, **kwargs):
            pass

# Generated at 2022-06-22 05:03:07.097387
# Unit test for function product
def test_product():
    """
    Tests that `itertools.product` and `tqdm.product`
    have the same output.
    """
    from nose.tools import assert_equals
    from random import randint

    # Random 2d lists
    for _ in range(1000):
        lens1 = [randint(1, 100) for _ in range(randint(1, 5))]
        lens2 = [randint(1, 100) for _ in range(randint(1, 5))]
        lst1 = [list(range(i)) for i in lens1]
        lst2 = [list(range(i)) for i in lens2]

        tqdm_res = []
        for i in product(lst1, lst2):
            tqdm_res.append(i)


# Generated at 2022-06-22 05:03:11.077575
# Unit test for function product
def test_product():
    for n in [0, 1, 2, 4]:
        for (X, Y) in zip(product(range(n), repeat=n), itertools.product(range(n), repeat=n)):
            assert (X == Y)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:03:23.244952
# Unit test for function product
def test_product():
    """
    Test that `tqdm.itertools.product` works as expected.
    """
    from ..utils import FormatCustomText, FormatCustomSI
    import numpy as np
    l = list(range(100000))

    # Test normal case
    assert np.prod(l) == sum(i for i in product(l))

    # Test output format
    assert (
        sum(i for i in product(l, tqdm_class=FormatCustomText))
        == np.prod(l))
    assert (
        sum(i for i in product(l, tqdm_class=FormatCustomSI))
        == np.prod(l))

    # Test total

# Generated at 2022-06-22 05:03:33.962626
# Unit test for function product
def test_product():
    """
    Tests function `itertools.product` with `tqdm.product`.
    """
    from ..utils import FormatTqdmWarning
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", FormatTqdmWarning)

# Generated at 2022-06-22 05:03:52.125618
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm

    L = range(10000)
    for i in product(L, L, tqdm=tqdm):
        pass

# Generated at 2022-06-22 05:04:03.205555
# Unit test for function product
def test_product():
    """Test function `product`"""
    # Test basic functionality
    i = 0
    for j in product(list(range(200)), list(range(100)), list(range(2)), tqdm_class=None):
        assert(j == (i % 200, i % 100, i % 2))
        i += 1
    assert(i == 200 * 100 * 2)
    # Test total
    with tqdm_auto(total=200 * 100 * 2) as t:
        for j in product(list(range(200)), list(range(100)), list(range(2))):
            pass
    assert (t.n == t.total)
    # Test total == 0

# Generated at 2022-06-22 05:04:06.934351
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from tqdm.contrib.test import closing, tdummy
    for T in [tqdm_auto, tdummy]:
        with closing(T(total=60)) as pbar:
            l = [pbar.update() for x in product(range(2), 'abc', repeat=2)]
        assert pbar.n == 60, pbar

# Generated at 2022-06-22 05:04:09.021049
# Unit test for function product
def test_product():
    from .tests_tqdm import pretest_posttest
    return pretest_posttest(itertools.product, product)

# Generated at 2022-06-22 05:04:13.873899
# Unit test for function product
def test_product():
    res = list(product('ABCD', 'xy', tqdm_class=lambda x, **kwargs: x))
    assert res == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                   ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

# Generated at 2022-06-22 05:04:21.611014
# Unit test for function product
def test_product():
    from .utils import IS_WINDOWS
    import sys

    tqdm_class = tqdm_auto
    tqdm_class.clear()  # reset tqdm instance cache
    it = product("abcdefghijklmnopqrstuvwxyz",
                 "abcdefghijklmnopqrstuvwxyz",
                 tqdm_class=tqdm_class)
    used_bars = set()
    total_bars = 2
    for i in range(total_bars):
        next(it)
        bars = tqdm_class.instances
        if bars:
            bar = list(bars)[0]
            used_bars.add(bar)
            assert 'p' in bar.desc  # desc should be overwritten by product
            assert bar.n == 26 ** i

# Generated at 2022-06-22 05:04:25.961435
# Unit test for function product
def test_product():
    """Simple unit tests for module `itertools_`."""
    # Note: to add more test cases, please also add them manually to
    # `itertools_test.sh`
    # (requires no mangling)
    # Test 1:
    cnt = 0
    for _ in product('AB', '12', tqdm_class=None):
        cnt += 1
    assert cnt == 2*2
    # Test 2:
    cnt = 0
    for _ in product('AB', '12', tqdm_class=tqdm_auto):
        cnt += 1
    assert cnt == 2*2

# Generated at 2022-06-22 05:04:29.850365
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import contextlib
    with contextlib.redirect_stdout(sys.stderr):
        product(range(3), range(3), tqdm_class=tqdm_auto)

# Generated at 2022-06-22 05:04:36.226232
# Unit test for function product
def test_product():
    """Test utility product"""
    import numpy as np
    assert list(product(range(3), [1j, 1 + 1j], repeat=3)) == list(
        itertools.product(range(3), [1j, 1 + 1j], repeat=3))

# Generated at 2022-06-22 05:04:40.757603
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for i in product([1], [2], [3], tqdm_class=tqdm_auto):
        assert i == (1, 2, 3)

# Generated at 2022-06-22 05:05:23.172406
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..._tqdm import tqdm

    assert list(product(range(1000))) == list(itertools.product(range(1000)))
    assert (list(product(range(1000), tqdm_class=tqdm))
            == list(itertools.product(range(1000))))

    assert list(product(range(1000), range(100), tqdm_class=tqdm)) == (
        list(itertools.product(range(1000), range(100))))

    assert list(product(range(1000), range(100), range(10), tqdm_class=tqdm)) == (
        list(itertools.product(range(1000), range(100), range(10))))


# Generated at 2022-06-22 05:05:33.766607
# Unit test for function product
def test_product():
    assert tuple(product("123", "ab")) == (("1", "a"), ("1", "b"),
                                           ("2", "a"), ("2", "b"),
                                           ("3", "a"), ("3", "b"))

    assert tuple(product("123", "ab", tqdm_class=None)) == (("1", "a"), ("1", "b"),
                                                            ("2", "a"), ("2", "b"),
                                                            ("3", "a"), ("3", "b"))

    assert tuple(product("123", "ab", tqdm_class=None, total=None)) == (("1", "a"), ("1", "b"),
                                                                        ("2", "a"), ("2", "b"),
                                                                        ("3", "a"), ("3", "b"))

   

# Generated at 2022-06-22 05:05:44.239547
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from .tests import tests as T
    iterables = ((1, 2), (3, 4))
    T.itertools_equal(T.islice(itertools.product(*iterables), 5),
                      T.islice(product(*iterables, leave=False), 5))
    iterables = ((1, 2), object())
    T.itertools_equal(T.islice(itertools.product(*iterables), 5),
                      T.islice(product(*iterables, leave=False), 5))
    T.itertools_equal(T.islice(itertools.product(*iterables), 5),
                      T.islice(product(*iterables, total=5, leave=False), 5))

# Generated at 2022-06-22 05:05:47.938007
# Unit test for function product
def test_product():
    it = iter(product([1, 2, 3], [3, 4, 5], [2, 3, 4], [3, 4, 5], tqdm_class=tqdm_auto))
    next(it)

# Generated at 2022-06-22 05:05:53.568439
# Unit test for function product
def test_product():
    for i in product([1, 2], ['a', 'b'], tqdm_class=None):
        pass
    for i in product([1, 2], ['a', 'b'], tqdm_class=tqdm_auto):
        pass
    for i in product([1, 2], ['a', 'b'], tqdm_class=tqdm_auto, desc="test"):
        pass
    for i in product([1, 2], ['a', 'b'], tqdm_class=tqdm_auto, desc="test"):
        pass

# Generated at 2022-06-22 05:06:04.084421
# Unit test for function product
def test_product():
    r"""Test for function product()."""
    import random
    import pytest

    # Test with a total
    with tqdm_auto(total=10) as pbar:
        for _ in product(range(10), range(10), tqdm_class=tqdm_auto, total=10):
            pbar.update()

    # Test without a total
    with tqdm_auto() as pbar:
        for _ in product(range(10), range(10), tqdm_class=tqdm_auto):
            pbar.update()

    # Test multiplier
    with tqdm_auto(total=10) as pbar:
        for _ in product(range(10), range(10),
                         tqdm_class=tqdm_auto, total=10,
                         multiplier=100):
            p

# Generated at 2022-06-22 05:06:12.346572
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.random import rand
    from numpy import allclose
    from itertools import product as iproduct
    from collections import Counter

    l = [rand(10) for _ in range(3)]
    l2 = list(product(l[0], l[1], l[2]))
    assert allclose(Counter(l2), Counter(iproduct(l[0], l[1], l[2])))

    l = [rand(10) for _ in range(10)]
    l2 = list(product(*l))
    assert allclose(Counter(l2), Counter(iproduct(*l)))

    assert allclose(len(l2), 1 * 10 * 9 * 8 * 7 * 6 * 5 * 4 * 3 * 2 * 1)