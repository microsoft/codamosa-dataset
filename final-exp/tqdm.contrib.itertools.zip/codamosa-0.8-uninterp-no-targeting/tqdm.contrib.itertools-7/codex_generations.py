

# Generated at 2022-06-22 04:56:13.294722
# Unit test for function product
def test_product():
    from .utils import closing
    import operator
    from six.moves import range
    tqdm_obj = product(range(2), range(2), range(1, 3),
                       tqdm_class=tqdm_auto)
    assert isinstance(tqdm_obj, tqdm_auto)
    assert tqdm_obj.n == 8
    assert len(list(tqdm_obj)) == 8
    assert tqdm_obj.n == 8
    assert tqdm_obj.n_instances == 1

    tqdm_obj = product(range(2), range(2), range(1, 3),
                       tqdm_class=tqdm_auto)
    assert isinstance(tqdm_obj, tqdm_auto)
    assert tqdm_obj.n == 8
   

# Generated at 2022-06-22 04:56:25.509517
# Unit test for function product
def test_product():
    assert list(product([0, 1, 2], [10, 20], repeat=1)) == [(0, 10),
                                                            (0, 20),
                                                            (1, 10),
                                                            (1, 20),
                                                            (2, 10),
                                                            (2, 20)]

# Generated at 2022-06-22 04:56:34.889994
# Unit test for function product
def test_product():
    from random import randint
    from time import sleep
    for n in range(4):
        for m in range(4):
            for k in range(4):
                inp = [
                    [randint(1, 99) for _ in range(n)]
                    for _ in range(m)
                ]
                res = list(product(*inp, tqdm_class=tqdm_auto.tqdm,
                                   desc='test', leave=False))
                assert list(itertools.product(*inp)) == res
                sleep(0.1)

# Generated at 2022-06-22 04:56:41.904567
# Unit test for function product
def test_product():
    from .utils import closing, _range
    from .std import FormatStdout, StringIO

    p = product(_range(3), _range(2))
    for i in p:
        pass
    assert i == (2, 1)

    with closing(StringIO()) as our_file:
        with closing(FormatStdout(our_file)) as fs:
            p = product(_range(3), _range(2))
            for i in p:
                pass
            p.close()
        assert our_file.getvalue() == '  6it [00:00, 49670.36it/s]\n'

# Generated at 2022-06-22 04:56:53.856483
# Unit test for function product
def test_product():
    # Check cases where itertools raises
    try:
        product()
    except TypeError:
        pass
    else:
        assert False, "Empty product should raise"
    try:
        product(iter([]))
    except TypeError:
        pass
    else:
        assert False, "Empty product should raise"
    try:
        product([], [])
    except TypeError:
        pass
    else:
        assert False, "Empty product should raise"

    # Check some simple cases
    assert list(product('ab', [-1, 0, 1])) == [('a', -1), ('a', 0), ('a', 1),
                                               ('b', -1), ('b', 0), ('b', 1)]
    # Check empty case

# Generated at 2022-06-22 04:57:01.728642
# Unit test for function product
def test_product():
    """Simple unit test for tqdm.itertools"""
    from .misc import _range
    for t in (tqdm_auto, tqdm_gui):
        assert list(t.product(_range(2), _range(2))) == [(0, 0), (1, 0),
                                                         (0, 1), (1, 1)]
        assert list(t.product(
            _range(2), _range(2), bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}')) == [(0, 0), (0, 1), (1, 0),
                                                                                    (1, 1)]

# Generated at 2022-06-22 04:57:08.112755
# Unit test for function product
def test_product():
    """
        Example code for testing function product.
    """
    for _ in product(range(1000), range(1200), range(1500),
                  tqdm_class=None):
        pass
    for _ in product(range(1000), range(1200), range(1500), mininterval=1,
                  tqdm_class=None):
        pass

# Generated at 2022-06-22 04:57:18.254528
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText, format_meter
    from .utils import BaseTestTQDM

    class TestProduct(BaseTestTQDM):
        def test_product(self):
            """test tqdm product"""
            from .._tqdm import trange
            from math import factorial

            # Test 1
            with TestProduct.disable_test_bar("test_product"):
                for i in trange(10, desc='1st loop', leave=False):
                    for j in trange(5, desc='2nd loop', leave=True):
                        for k in trange(100, desc='3rd loop',
                                        leave=True, mininterval=0.01):
                            pass
            self.assertEqual(self.out.getvalue().count("\r"), 10)

            # Test 2

# Generated at 2022-06-22 04:57:27.754392
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import nose.tools

    a = range(3)
    b = range(2)
    c = range(1)

    nose.tools.assert_equal(len(list(product(a, b, c))),
                            len(list(itertools.product(a, b, c))))

    nose.tools.assert_equal(len(list(product(a, b, c,
                                             tqdm_class=tqdm_auto.tqdm))),
                            len(list(itertools.product(a, b, c))))

# Generated at 2022-06-22 04:57:33.482929
# Unit test for function product
def test_product():
    "Tests the unit of product"
    from .. import trange

    for _ in trange(3, desc='outer'):
        for _ in trange(2, desc='inner'):
            for _ in product(range(4), range(4), tqdm_class=trange):
                pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:57:40.501801
# Unit test for function product
def test_product():
    """Test wrapping of itertools.product"""
    try:
        from numpy import product
    except ImportError:
        return None

    with tqdm_auto(total=4) as t:
        for i in product(range(3), range(3), tqdm=t):
            t.update(1)

# Generated at 2022-06-22 04:57:51.851826
# Unit test for function product
def test_product():
    from io import BytesIO
    from sys import version_info
    from operator import mul

    with tqdm_auto(total=1) as pbar:
        assert pbar.total == 1
        list(product("", "", tqdm_class=tqdm_auto))
        assert pbar.total == 0

    with tqdm_auto(total=None) as pbar:
        assert pbar.total is None
        list(product("", "", tqdm_class=tqdm_auto))
        assert pbar.total is None

    with tqdm_auto(total=6, miniters=1, mininterval=0) as pbar:
        assert pbar.total == 6
        assert pbar.miniters == 1
        assert pbar.mininterval == 0

# Generated at 2022-06-22 04:58:02.080703
# Unit test for function product
def test_product():
    """
    The product test unit.
    """
    from numpy.random import randint
    a = randint(1, 10, 10)
    b = randint(1, 10, 10)
    s = set()
    for i, j in product(a, b):
        s.add((i, j))
    for i, j in itertools.product(a, b):
        assert (i, j) in s
    s.clear()
    for i, j in product(a, b):
        s.add((i, j))
    for i, j in itertools.product(a, b):
        assert (i, j) in s



# Generated at 2022-06-22 04:58:13.885660
# Unit test for function product
def test_product():
    """
    Unit test for `product()`.
    """
    from ..utils import format_sizeof
    try:
        from collections import Counter
    except:
        from .backports import Counter
    from .utils import byte2str

    lst = range(10)
    for i, _ in tqdm_auto(list(product([lst, lst, lst]))):
        pass
    assert i == (9, 9, 9)

    lst = [byte2str(b'\x00\x00\x00\x00')] * (1 << 20)
    lst2 = [byte2str(b'\x00\x00\x00\x00')] * (1 << 20)
    cnt = Counter()

# Generated at 2022-06-22 04:58:18.049184
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import ArrayAccumulator, format_sizeof
    from .detect import IN_WINDOWS
    from .trange import trange

    if IN_WINDOWS and not format_sizeof:
        return

    for islice in [False, True]:
        for n in [0, 1, 2]:
            with trange(10, ncols=n) as t:
                prd = list(product(tqdm_class=t.__class__,
                                   iterable=range(10)))
                if islice:
                    t.update(5)
                    prd = prd[:5]
                assert prd == list(itertools.product(range(10)))
                assert t.n == 10

# Generated at 2022-06-22 04:58:22.720424
# Unit test for function product
def test_product():
    import numpy as np
    value = []
    for i in product([2, 3, 4], ['a', 'b', 'c', 'd'],
                     range(5), tqdm_class=None):
        value.append(i)
    assert len(value) == 2*3*4*5


# Generated at 2022-06-22 04:58:29.459967
# Unit test for function product
def test_product():
    """Simple unit test for tqdm.utils.product"""
    from nose.tools import eq_
    from ..tests.test_misc import TEST_ITERABLE

    eq_(list(product(['hello', 'world'], TEST_ITERABLE)),
        itertools.product(TEST_ITERABLE, ['hello', 'world']))

    eq_(list(product(range(3), range(3))),
        list(range(9)))

# Generated at 2022-06-22 04:58:32.749148
# Unit test for function product
def test_product():
    from .tests_itertools import test_product as _test_product
    with tqdm_auto() as t:
        _test_product(t)

# Generated at 2022-06-22 04:58:44.684126
# Unit test for function product
def test_product():
    """Test for function `tqdm.tqdm_itertools.product`"""
    from sys import version_info, stdout
    from itertools import product
    from ..auto import tqdm as tqdm_auto
    from .tests import unittest

    try:
        from .._tqdm_gui import tqdm_gui
    except ImportError:
        tqdm_gui = None

    class TqdmTest(unittest.TestCase):
        "Test for `tqdm.tqdm_itertools.product`"

        def test_product_basics(self):
            "Test basic `product` functions."
            n_iter = 10
            n_repeat = 10

# Generated at 2022-06-22 04:58:52.410678
# Unit test for function product
def test_product():
    from .misc import _range

    for k in _range(10):
        for kw in [dict(tqdm_class=None), dict(tqdm_class=tqdm_auto)]:
            len(list(product(range(k), _range(k, 0), range(k), **kw)))
            len(list(product(range(k), _range(k, 0), range(k),
                             total=k*k*k, **kw)))
            len(list(product("abcdefghijklmnopqrstuvwxyz"[:k],
                             total=k, **kw)))
            len(list(product("abcdefghijklmnopqrstuvwxyz"[:k],
                             total=None, **kw)))

# Generated at 2022-06-22 04:58:59.864139
# Unit test for function product
def test_product():
    assert list(product([1, 2], [1, 2], [1, 2])) == [
        (1, 1, 1), (1, 1, 2), (1, 2, 1), (1, 2, 2),
        (2, 1, 1), (2, 1, 2), (2, 2, 1), (2, 2, 2)]

# Generated at 2022-06-22 04:59:06.463302
# Unit test for function product
def test_product():
    """
    Simple function to unit-test the function `product`.
    """
    iterables = [range(0, 5), range(0, 3)]
    print("iterables: ", iterables)
    print("result: ", list(product(*iterables)))

    iterables = [range(0, 5), range(-3, 3)]
    print("iterables: ", iterables)
    print("result: ", list(product(*iterables)))

    iterables = [range(0, 5), range(-1, 1)]
    print("iterables: ", iterables)
    print("result: ", list(product(*iterables)))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:59:18.342813
# Unit test for function product
def test_product():
    """Test function product"""
    from sys import version_info
    if version_info.major >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    from .tqdm import tqdm
    from sys import stdout
    from contextlib import contextmanager
    from os import curdir, sep

    @contextmanager
    def nostdout():
        """Temporarily redirect stdout"""
        import os
        import sys
        save_out, save_err = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = map(StringIO, ('', ''))
        yield
        sys.stdout, sys.stderr = save_out, save_err

    # First check

# Generated at 2022-06-22 04:59:30.065343
# Unit test for function product
def test_product():
    """
    Unit test for function product

    Returns
    -------
    bool
        True if the test ran successfully, False otherwise.
    """
    from ..utils import format_sizeof

    try:
        from itertools import product
    except ImportError:  # pragma: no cover
        # Python 2.6
        from ..itertools import product

    for use_tqdm in (False, True):
        for i in range(4, 7):
            for j in range(4, 7):
                for k in range(4, 7):
                    # Make sure the iterator is consumed, otherwise the
                    # test fails
                    list(product(*([range(i)] * j), **{'tqdm_class': tqdm_auto
                                                      if use_tqdm else None}))

# Generated at 2022-06-22 04:59:36.552009
# Unit test for function product
def test_product():
    """
    Unit tests for function product().
    """
    from tqdm.auto import tqdm

    # unit tests
    list_of_lists = [[1, 10], [11, 20], [21, 30]]
    for xp, p in zip(itertools.product(*list_of_lists),
                     product(*list_of_lists, tqdm_class=tqdm)):
        assert xp == p

# Generated at 2022-06-22 04:59:46.413598
# Unit test for function product

# Generated at 2022-06-22 04:59:57.256124
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy.testing import assert_equal

    expected = list(itertools.product(range(2), range(2)))
    for i, j in zip(expected, product(range(2), range(2))):
        assert_equal(i, j)

    expected = list(itertools.product(randint(0, 100, 10), randint(0, 100, 10)))
    for i, j in zip(expected, product(randint(0, 100, 10),
                                      range(100),
                                      randint(0, 100, 10))):
        assert_equal(i, j)
    print("tqdm.itertools tests passed")


# Generated at 2022-06-22 05:00:02.844580
# Unit test for function product
def test_product():
    import sys
    import numpy as np
    if sys.version_info[0] > 2:
        Z = list(product(range(1000), range(1000), range(1000)))
    else:
        Z = list(product(xrange(1000), xrange(1000), xrange(1000)))
    assert np.alltrue(Z,
                      np.product(np.arange(1000), np.arange(1000),
                                 np.arange(1000)))

# Generated at 2022-06-22 05:00:13.557866
# Unit test for function product
def test_product():          # pragma: no cover
    import numpy as np
    tqdm_auto.tqdm.monitor_interval = 0
    tqdm_auto.tqdm.pandas(desc="tests")
    for i in product(np.linspace(0, 1, 1e4),
                     [np.sin, np.cos],
                     tqdm_class=tqdm_auto.tqdm, desc="product"):
        pass
    for i in product(np.linspace(0, 1, 1e4),
                     [np.sin, np.cos],
                     tqdm_class=tqdm_auto.tqdm, total=2e4):
        pass

# Generated at 2022-06-22 05:00:25.507950
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    iterables = (range(1000), range(1000, 2000),)
    result = next(product(*iterables))
    assert result == (0, 1000)
    result = [next(product(*iterables)) for i in range(3)]
    assert result == [(0, 1000), (1, 1001), (0, 1001)]

# Generated at 2022-06-22 05:00:34.640858
# Unit test for function product
def test_product():
    """
    Test the function `product` from tqdm.itertools
    """
    from .gui import tqdm  # noqa: F401
    from .gui import trange  # noqa: F401

    for tqdm_cls in [tqdm, trange]:
        out = list(product([1, 2, 3], tqdm_cls=tqdm_cls))
        assert out == [(1, 1), (1, 2), (1, 3),
                       (2, 1), (2, 2), (2, 3),
                       (3, 1), (3, 2), (3, 3)]

        out = list(product([1, 2, 3], [1, 2], tqdm_cls=tqdm_cls))

# Generated at 2022-06-22 05:00:45.637011
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    iterables = [["a", "b"], ["c", "d"], ["e", "f", "g", "h"]]

    # Test without total

# Generated at 2022-06-22 05:00:55.634942
# Unit test for function product
def test_product():
    from ..std import tqdm
    import sys

    for tqdm_class in (tqdm, tqdm_auto):
        # Just 1 iterable
        assert sum(product(["a", "b"], tqdm_class=tqdm_class)) == "ab"
        # 2 iterables
        assert sum(product("ab", "12", tqdm_class=tqdm_class)) == "a1b2"
        # 3 iterables
        assert sum(product("abc", "xyz", "123", tqdm_class=tqdm_class)) \
            == "ax1by2bzc3"

    # Si

# Generated at 2022-06-22 05:01:07.439936
# Unit test for function product
def test_product():
    from .tests_check import check_unordered
    from .tests_my3i import test_product as test_product_my3i
    from .utils import FormatCustom

    func = product
    iterable = (range(math.ceil(random.random() * 3)) for _ in range(random.randint(2, 4)))
    check_unordered(test_product_my3i(iterable), func(iterable),
                    "product(zip(range(3), 'abc'))")

    iterable = (range(math.ceil(random.random() * 3)) for _ in range(random.randint(2, 4)))
    check_unordered(test_product_my3i(iterable), func(iterable, tqdm_class=FormatCustom),
                    "product() callable=FormatCustom")
    check_

# Generated at 2022-06-22 05:01:10.055171
# Unit test for function product
def test_product():
    """Test product"""
    assert (list(product(range(3), repeat=3)) ==
            [(i, i, i) for i in range(3)])

# Generated at 2022-06-22 05:01:18.210637
# Unit test for function product
def test_product():
    """Test product."""
    # Test unit
    try:
        import numpy as np
    except ImportError:
        pass
    else:
        assert list(itertools.product([1, 2, 3], [4, 5, 6])) == list(
            product([1, 2, 3], [4, 5, 6]))

        assert list(itertools.product(
            [1, 2, 3], [4, 5, 6], [7, 8, 9])) == list(
                product([1, 2, 3], [4, 5, 6], [7, 8, 9]))


# Generated at 2022-06-22 05:01:27.762209
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    import numpy as np
    from .version import __version__
    exp_version = __version__
    exp_version = __version__.split('.') if '-' in __version__ else exp_version
    from .tqdm import __version__ as TqdmVersion
    imp_version = TqdmVersion
    imp_version = TqdmVersion.split('.') if '-' in TqdmVersion else imp_version
    if int(imp_version[0]) < int(exp_version[0]):
        print("Failed to import the latest tqdm version: %s vs %s" % (
            TqdmVersion, __version__))

# Generated at 2022-06-22 05:01:38.031360
# Unit test for function product
def test_product():
    import doctest
    doctest.testmod(itertools, report=False)
    import sys
    import copy
    import numpy as np
    from tqdm import tqdm
    from .tests import pretest_posttest_validate
    from ..utils import format_sizeof
    range_ = range

    np.random.seed(0)
    sys_argv_backup = copy.copy(sys.argv)

# Generated at 2022-06-22 05:01:41.385830
# Unit test for function product
def test_product():
    assert list(product(range(3), repeat=3)) == list(itertools.product(range(3), repeat=3))
    assert list(product(range(3), range(2), repeat=2)) == list(itertools.product(range(3), range(2), repeat=2))

# Generated at 2022-06-22 05:01:48.554061
# Unit test for function product
def test_product():
    import sys
    import os
    from contextlib import contextmanager
    from random import randint
    from textwrap import dedent

    with open(os.devnull, "wb") as fnull:
        @contextmanager
        def redirect_stdout(target):
            _stdout = sys.stdout
            sys.stdout = target
            yield
            sys.stdout = _stdout

        def product_output(func, *args, **kwargs):
            with redirect_stdout(fnull):
                return list(func(*args, **kwargs))

        # Test 1. No arguments
        assert product_output(product) == [()]
        # Test 2. Single iterable
        assert product_output(product, "ab") == [('a',), ('b',)]
        # Test 3. Multiple iterables
        assert product_