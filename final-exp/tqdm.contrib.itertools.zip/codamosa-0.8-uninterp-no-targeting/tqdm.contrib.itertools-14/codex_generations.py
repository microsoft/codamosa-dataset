

# Generated at 2022-06-22 04:56:26.960970
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    from ._utils import UnitTest
    from ._utils import nose_msg_explanations

    # Initialize tests
    ut = UnitTest()
    ut.start()

    # List of tuples of args and kwargs

# Generated at 2022-06-22 04:56:31.559518
# Unit test for function product
def test_product():
    from .tests import TestCase, n_

    for tqdm_class in [None, lambda **kwargs: None]:
        with TestCase(tqdm_class=tqdm_class):
            for t in (1, 2):
                for j in product(*[range(t + 1)] * 3, tqdm_class=tqdm_class):
                    pass

# Generated at 2022-06-22 04:56:41.460413
# Unit test for function product
def test_product():
    #######################
    # Test valid parameters
    #######################
    from .utils import _range
    from .utils import _iterable
    from .utils import _missingbar
    from .utils import format_sizeof

    #############
    # Unit tests
    #############
    t = tqdm_auto(iterable=iter(product(
                        _range(10), _range(10), _range(10), _range(10))),
                  mininterval=0.01,
                  leave=False)
    assert isinstance(t, tqdm_auto)
    assert t.n == 0
    assert t.miniters == 0
    assert t.maxinterval == 10
    assert t.mininterval == 0.01
    assert t.ascii == True

# Generated at 2022-06-22 04:56:52.088941
# Unit test for function product
def test_product():
    ip = iter(product(xrange(2), xrange(6), xrange(8), xrange(3), xrange(10),
                      tqdm_class=lambda **kwargs: None))
    op = []
    c = 0
    while True:
        try:
            i = ip.next()
        except StopIteration:
            break
        c += 1
        op.append(i)
    assert c == 2 * 6 * 8 * 3 * 10
    assert op == list(itertools.product(xrange(2), xrange(6), xrange(8),
                                        xrange(3), xrange(10)))


if __name__ == '__main__':
    from .common import TestCase

    class TestProduct(TestCase):
        def test_product(self):
            test_product()

# Generated at 2022-06-22 04:56:55.876937
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    iterables = [range(10)] * 3
    r = list(product(*iterables))
    assert r == list(itertools.product(*iterables))

# Generated at 2022-06-22 04:57:04.311254
# Unit test for function product
def test_product():
    from ..tests import closing, test_iter

# Generated at 2022-06-22 04:57:16.515356
# Unit test for function product
def test_product():
    from .tests import nose_msg_exception

    # if we don't use `with`, we have to create and close the tqdm instance
    # manually
    t = tqdm_auto(total=4)
    for j in product([1, 2], [3, 4], tqdm_class=t):
        pass
    t.close()
    assert t.n == 4, "got {} instead of 4".format(t.n)

    # if we use `with`, everything gets closed automatically
    with tqdm_auto(total=4) as t:
        for j in product([1, 2], [3, 4], tqdm_class=t):
            pass
    assert t.n == 4, "got {} instead of 4".format(t.n)

    # if total=None, the bar should run indefinitely
   

# Generated at 2022-06-22 04:57:23.131744
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    list_ = [["a", "b", "c", "d"], ["e", "f", "g", "h"]]
    gen = itertools.product(*list_)
    for actual, expected in zip(product(*list_), gen):
        assert actual == expected

# Generated at 2022-06-22 04:57:30.097476
# Unit test for function product
def test_product():
    """
    Add description here
    """
    from numpy.random import randint
    for i in range(10):
        for j in range(10):
            for k in range(10):
                assert sum(1 for _ in product(range(i), range(j), range(k))) ==\
                    i*j*k
    for i in range(10):
        for j in range(10):
            assert sum(1 for _ in product(randint(0, 10, i),
                                          randint(0, 10, j))) == i*j

# Generated at 2022-06-22 04:57:41.244847
# Unit test for function product
def test_product():
    """Function `product` unit test"""
    ret = list(product(range(3), "ABC"))
    assert ret == [(0, 'A'), (0, 'B'), (0, 'C'),
                   (1, 'A'), (1, 'B'), (1, 'C'),
                   (2, 'A'), (2, 'B'), (2, 'C')]

    ret = list(product(range(3), "ABC", repeat=2))

# Generated at 2022-06-22 05:00:02.383835
# Unit test for function product
def test_product():
    """Test suite for itertools.product"""
    from collections import Iterable

    assert product is not None
    assert isinstance(product([1, 2]), Iterable)
    ## corner cases
    assert list(product([0])) == [0]
    assert list(product([0], repeat=3)) == [0]
    assert list(product([1, 2], repeat=3)) == \
        [1, 2, 1, 2, 1, 2]
    assert list(product(repeat=3)) == []

    assert list(product([1, 2], [3, 4])) == \
        [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-22 05:00:04.034934
# Unit test for function product
def test_product():
    for i in product(range(100), repeat=10):
        pass

# Generated at 2022-06-22 05:00:15.815995
# Unit test for function product
def test_product():
    import pandas as pd
    import numpy as np

    total = 0
    success = 0
    for i in range(1,10):
        for j in range(1,10):
            for k in range(1,10):
                for l in range(1,10):
                    for m in range(1,10):
                        for n in range(1,10):
                            total += 1
                            try:
                                arr = np.array(list(product([i,j,k],
                                                            [l,m,n],
                                                            repeat=2,
                                                            tqdm_class=tqdm_auto)))
                            except TypeError:
                                print("TypeError")

# Generated at 2022-06-22 05:00:26.531162
# Unit test for function product
def test_product():
    """
    Test function `product`.
    """
    from nose.tools import raises
    from ..utils import FormatCustomText, MaxTotalParam
    def product2(*iterables):
        """
        Equivalent of `product` with a simple format custom.
        """
        for i, e in enumerate(product(*iterables, tqdm_class=FormatCustomText)):
            assert len(e) == len(iterables)
            yield e
    def product3(*iterables):
        """
        Equivalent of `product` with a multiple output.
        """
        for i, e in enumerate(product(*iterables, tqdm_class=FormatCustomText)):
            yield e, i

    with raises(TypeError):
        list(product2(range(1000), "abc", tqdm_class=MaxTotalParam))
   

# Generated at 2022-06-22 05:00:34.403489
# Unit test for function product
def test_product():
    import os
    import random
    from .utils import _range
    from .std import format_sizeof

    random.seed(0)
    big = [i.tobytes() for i in [
        _range(1000),
        _range(1000, 2000),
        _range(2000, 3000)]]
    lenbig = sum(map(len, big))

    # unit test
    for tqdm_class in [tqdm, tqdm_gui, tqdm_notebook]:
        for i in tqdm_class(range(10)):
            for j in tqdm_class(range(10), leave=False):
                for k in tqdm_class(range(10), leave=False,
                                    mininterval=0):
                    pass

    # Stress test

# Generated at 2022-06-22 05:00:44.996633
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`
    """
    list(product(
        range(100),
        range(10),
        range(10),
        range(10),
        tqdm_class=tqdm_auto)) == list(itertools.product(
            range(100),
            range(10),
            range(10),
            range(10)))
    # test total kwargs
    list(product(
        range(100),
        range(10),
        range(10),
        range(10))) == list(itertools.product(
            range(100),
            range(10),
            range(10),
            range(10)))

# Generated at 2022-06-22 05:00:49.915968
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import sys

    from . import trange

    def iproduct(*iterables):
        for i in itertools.product(*iterables):
            yield i

    pbar = trange(10, file=sys.stdout, mininterval=0.001, miniters=1)
    assert list(iproduct(pbar, range(10, 20))) == list(product(pbar, range(10, 20)))
    assert list(iproduct(pbar, range(10, 20))) == list(product(range(10), range(10, 20)))



# Generated at 2022-06-22 05:00:55.556650
# Unit test for function product
def test_product():
    return list(product(range(10), range(10))) == list(itertools.product(range(10), range(10)))

# Generated at 2022-06-22 05:01:07.580435
# Unit test for function product
def test_product():
    from unittest import TestCase, main

    class Test(TestCase):
        def test_basics1(self):
            from copy import copy
            from itertools import product

            l1 = [1, 2, 3]
            l2 = ['a', 'b']
            tqdm_l1 = copy(l1)
            tqdm_l2 = copy(l2)
            for x in product(l1, l2):
                self.assertTrue(x in product(tqdm_l1, tqdm_l2))

            self.assertEqual(list(product(l1, l2)),
                             list(product(tqdm_l1, tqdm_l2)))

        def test_basics2(self):
            from functools import reduce

# Generated at 2022-06-22 05:01:10.458615
# Unit test for function product
def test_product():
    from . import _test_itertools_like as _test_itertools_like
    _test_itertools_like(itertools.product, product)

# Generated at 2022-06-22 05:04:31.945808
# Unit test for function product
def test_product():
    assert set(product([1, 2],['a', 'b', 'c'], repeat=1)) == set(itertools.product([1, 2],['a', 'b', 'c']))
    assert set(product([1, 2],['a', 'b', 'c'], repeat=2)) == set(itertools.product([1, 2],['a', 'b', 'c'], repeat=2))
    assert set(product([1, 2],['a', 'b', 'c'], repeat=3)) == set(itertools.product([1, 2],['a', 'b', 'c'], repeat=3))

# Generated at 2022-06-22 05:04:39.271325
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    from itertools import product
    for _i in product(range(3), range(4)):
        _j = itermultiset(_i)
        _k = itermultiset(product(_i))
        assert_array_equal(_j, _k)


# Generated at 2022-06-22 05:04:48.831324
# Unit test for function product
def test_product():
    """
    Test tqdm.product
    """
    from . import trange
    assert list(product("ABCD", repeat=2)) == [
        ("A", "A"), ("A", "B"), ("A", "C"), ("A", "D"),
        ("B", "A"), ("B", "B"), ("B", "C"), ("B", "D"),
        ("C", "A"), ("C", "B"), ("C", "C"), ("C", "D"),
        ("D", "A"), ("D", "B"), ("D", "C"), ("D", "D")]


# Generated at 2022-06-22 05:04:58.596288
# Unit test for function product
def test_product():
    import numpy as np
    assert tuple(tqdm.tproduct([1, 2, 3], ['a', 'b', 'c'])) == tuple(
        itertools.product([1, 2, 3], ['a', 'b', 'c']))
    assert tuple(tqdm.tproduct([1, 2, 3], [1, 2, 3])) == tuple(
        itertools.product([1, 2, 3], [1, 2, 3]))
    assert tuple(tqdm.tproduct([1, 2, 3], [1, 2, 3, 4, 5])) == tuple(
        itertools.product([1, 2, 3], [1, 2, 3, 4, 5]))


# Generated at 2022-06-22 05:05:08.390150
# Unit test for function product
def test_product():
    """Unit test for `product`."""
    import sys
    import io
    try:
        _stdin = sys.stdin.fileno()
        _stdout = sys.stdout.fileno()
        sys.stdin = io.open('test_input', 'rb')
        sys.stdout = io.open('test_output', 'w')
        for i in product(('a', 'b'), repeat=2):
            print(i)
    finally:
        sys.stdin = io.open(_stdin)
        sys.stdout = io.open(_stdout)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:05:14.730530
# Unit test for function product
def test_product():
    iterables = list(range(3))
    assert [i for i in product(*iterables)] == list(itertools.product(*iterables))
    iterables = list(range(10))
    assert [i for i in product(*iterables)] == list(itertools.product(*iterables))

    assert [i for i in product(*iterables, total=None)] == list(itertools.product(*iterables))
    assert [i for i in product(*iterables, total=0)] == list(itertools.product(*iterables))
    assert [i for i in product(*iterables, total=10)] == list(itertools.product(*iterables))

    iterables = list(range(10))

# Generated at 2022-06-22 05:05:23.550488
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal, assert_raises

    def test(ts, *args, **kwargs):
        for tt in ts:
            for expected, kwargs_ in zip(
                    (list, ts, list(ts), ()),
                    (dict(), dict(tqdm_class=tt),
                     dict(tqdm_class=tt), dict(tqdm_class=tt, total=0))):
                with assert_raises(expected) as err:
                    list(product(*args, **dict(kwargs, **kwargs_)))

# Generated at 2022-06-22 05:05:30.042138
# Unit test for function product
def test_product():
    _ = list(product(range(10), range(10)))
    _ = list(product(range(10), range(10), tqdm_class=tqdm_auto))
    pass

# Generated at 2022-06-22 05:05:34.321665
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    s = 0
    for _ in product(range(2), bar=True):
        s += 1
    assert s == 4

# Generated at 2022-06-22 05:05:39.599624
# Unit test for function product
def test_product():
    """test for tqdm.itertools.product"""
    assert list(product(range(1000))) == list(itertools.product(range(1000)))
    assert list(product(range(1000, 0, -1))) == list(itertools.product(range(1000, 0, -1)))