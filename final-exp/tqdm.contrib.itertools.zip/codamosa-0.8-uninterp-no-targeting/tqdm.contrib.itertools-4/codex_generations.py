

# Generated at 2022-06-22 04:56:26.652321
# Unit test for function product
def test_product():
    from .._tqdm import TqdmDefaultWriteLock
    from ..std import _range


# Generated at 2022-06-22 04:56:37.791783
# Unit test for function product
def test_product():
    iter1 = range(20)
    iter2 = range(20)
    assert (
        list(product(iter1, iter2, tqdm_class=None))
        == list(itertools.product(iter1, iter2))
    )
    assert (
        list(product(iter1, iter2, tqdm_class=None))
        == [i for i in product(iter1, iter2, tqdm_class=None)]
    )
    assert (
        list(product(iter1, iter2, tqdm_class=None))
        == [i for i in product(iter1, iter2)]
    )

# Generated at 2022-06-22 04:56:41.526156
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`."""
    from tqdm.auto import trange
    from .tests_tqdm import pretest_posttest

    # unit testing for product
    for x in pretest_posttest(product(trange(10), trange(10))):
        pass

# Generated at 2022-06-22 04:56:49.938866
# Unit test for function product
def test_product():
    """
    Unit tests for function `product`.
    """
    from .tests import closing, closing_to_result, capture_stdout
    with closing_to_result(capture_stdout()) as result:
        list(product(range(3), range(2)))
    tqdm_repr = result.stdout
    assert tqdm_repr.strip().split(tqdm_repr[-1])[0] == " 0%|          | 0/6 [00:00<?, ?it/s]\n"
    for i, j in product(range(3), range(2)):
        pass

# Generated at 2022-06-22 04:57:01.581014
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..tests._utils import FormatCustom
    from ..tests._generate import Wrapper
    from ..tests._deprecate import faker

    class TqdmTest:
        def __init__(self):
            self.n = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.n < 100:
                self.n += 1
                return self.n
            raise StopIteration

    def product_test(a, b, tqdm_class=None, bar_format=None, **tqdm_kwargs):
        bar_format = bar_format or faker.pystr()


# Generated at 2022-06-22 04:57:13.966323
# Unit test for function product
def test_product():
    """
    Unit test for function ``product``.
    """
    import numpy as np
    assert list(product(range(3), tqdm_class=tqdm_auto)) \
        == list(itertools.product(range(3), tqdm_class=tqdm_auto))
    assert list(product(range(3), range(2), tqdm_class=tqdm_auto)) \
        == list(itertools.product(range(3), range(2), tqdm_class=tqdm_auto))
    assert list(product(range(3), range(2), tqdm_class=tqdm_auto)) \
        == list(product(range(2), range(3), tqdm_class=tqdm_auto))
    # test for generators

# Generated at 2022-06-22 04:57:17.710452
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    for i in product(range(4), range(4), tqdm_class=None):
        pass
    for i in product(range(4), range(4), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 04:57:29.357579
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from sys import getsizeof
    try:
        import numpy as np
    except:
        pass
    else:
        iter_arrays = [np.arange(100)] * 6
        for i in product(*iter_arrays):
            assert i[0] == i[-1]
            assert i[0] == 0
            break

    print('Test: function product')
    print('\tTotal: ', end=''),
    t = product(range(10), repeat=6)
    try:
        total = getsizeof(t, 0)
    except:
        total = None
    print(format_sizeof(total))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:57:36.820281
# Unit test for function product
def test_product():
    total = 0
    for i in product("ABC", "123"):
        total += 1
        assert len(i) == 2
    assert total == 6

    total = 0
    for i in product("ABC", "123", "abc"):
        total += 1
        assert len(i) == 3
    assert total == 18

    total = 0
    for i in product("ABC", "123", "abc"):
        total += 1
        assert len(i) == 3
    assert total == 18

# Generated at 2022-06-22 04:57:48.405299
# Unit test for function product
def test_product():
    from .common import closing
    from .contrib.concurrent import thread_map as mp, ProcessBar
    from .contrib.concurrent.thread_map import thread_map
    from .std import format_interval, curate_bar

    if tqdm_auto.gui is not False:
        raise unittest.SkipTest('Using the default tqdm (GUI)')

    def unittest_product(tqdm_class, **kwargs):
        for iterables in ([[1, 2]] * 10, [range(100), range(100)],
                          [range(100), 'abc'], [[], [], []], [[], [[]], [[], []]]):
            with closing(tqdm_class(**kwargs)) as t:
                t.monitor_interval = 0
                assert t.total == len

# Generated at 2022-06-22 04:57:58.859693
# Unit test for function product
def test_product():
    """
    Test module function `product`.
    """
    iterables = [range(10), range(10)]
    total = 0
    with product(*iterables, disable=True) as T:
        for i in T:
            total += 1
            assert len(i) == 2
            for x in i:
                assert (isinstance(x, int) and 0 <= x < 10)
    assert total == 100

# Generated at 2022-06-22 04:58:05.425763
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    # pylint: disable=undefined-variable
    from ..tqdm import trange
    for _ in product(trange(10), trange(10)):
        pass
    for _ in product(trange(10), trange(10), tqdm_class=tqdm_notebook, leave=True):
        pass
    for _ in product(trange(10), trange(10), tqdm_class=tqdm_notebook, leave=True):
        pass

# Generated at 2022-06-22 04:58:11.189901
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.random import randint
    from numpy import product as np_product
    from .utils import FormatCustomText
    from .utils import Time
    from ..pandas import tqdm

    tq_fmt = FormatCustomText(
        desc="Testing custom bar desc", bar_format=" {l_bar}")

    # Testing total parameter
    # =================================================================
    try:
        assert sum(product(list(range(10)), tqdm_class=tqdm)) == 100
    except:
        raise AssertionError("sum(product(list(range(10)))) != 100")
    # =================================================================

    # Testing leave parameter
    # =================================================================
    with tqdm(disable=True) as tq:
        with tq.leave_inner():
            assert sum(range(10))

# Generated at 2022-06-22 04:58:22.412298
# Unit test for function product
def test_product():
    from .utils import SimpleNamespace
    from .tests_tqdm import with_setup, _range

    @with_setup(pretest=True, posttest=True)
    def unit():
        """
        Unit test for `tqdm.itertools.product`.
        """
        from numpy.random import randint
        from numpy.testing import assert_equal, assert_raises_regex

        def ns(**kwargs):
            return SimpleNamespace(**kwargs)

        def foo(i):
            return i

        pbar = ns(n=0, **{'update': lambda *x: setattr(pbar, 'n', pbar.n + 1)})

        # assert len(list(it.product(foo(_range(20))))) == 20
        # assert len(list(it.product(foo

# Generated at 2022-06-22 04:58:33.147958
# Unit test for function product
def test_product():
    """
    Unit test function, requires py.test
    """
    count = 0
    iter_ = product('abcd', 'xy', tqdm_class=tqdm_auto)
    iter_ = iter(iter_)
    assert next(iter_) in [('a', 'x'), ('a', 'y')]
    assert next(iter_) in [('b', 'x'), ('b', 'y')]
    assert next(iter_) in [('c', 'x'), ('c', 'y')]
    assert next(iter_) in [('d', 'x'), ('d', 'y')]
    try:
        next(iter_)
    except StopIteration:
        pass
    else:
        assert 0, "The iterator should be exhausted but it is not"

# Generated at 2022-06-22 04:58:45.103736
# Unit test for function product
def test_product():
    from numpy import product
    from random import randrange
    for N, M in [
            (3, 5),
            (2 ** 10, 2 ** 13),
            (2 ** 8, 2 ** 12),
            (2 ** 2, 2 ** 2),
            (2 ** 2, 2 ** 2)
            ]:
        pdt = 1
        t = tqdm_auto(total=N * M)
        for i in range(10):
            for _ in product(
                    range(N), range(M),
                    tqdm_class=lambda x: t,
                    leave=False
                    ):
                pass
            t.close()
            pdt *= product([N, M])
            assert t.n == pdt
            t = tqdm_auto(total=N * M, mininterval=0.01)

# Generated at 2022-06-22 04:58:56.643551
# Unit test for function product
def test_product():
    from itertools import product
    from ..pandas import pandas_available
    from .utils import ClosingContext
    from .tests.common import TestCase


# Generated at 2022-06-22 04:59:02.703796
# Unit test for function product
def test_product():
    from tqdm import dummy
    try:
        from nose2.tools import assert_equal
    except ImportError:
        from nose.tools import assert_equal
    assert_equal(len(list(product(range(3), tqdm_class=dummy))), 3 ** 2)
    assert_equal(len(list(product(range(3), range(3), tqdm_class=dummy))),
                 3 ** 3)

# Generated at 2022-06-22 04:59:07.912393
# Unit test for function product
def test_product():
    list(product([1, 2, 3], ["a", "b", "c"], tqdm_class=tqdm_auto))
    list(product([1, 2, 3], ["a", "b", "c"], tqdm_class=tqdm_auto))
    # same but with total
    list(product([1, 2, 3], ["a", "b", "c"], tqdm_class=tqdm_auto, total=5))

# Generated at 2022-06-22 04:59:14.749432
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # Create product using pure itertools
    res_g = [x for x in itertools.product(range(2), repeat=3)]

    # Create product using itertools tqdm wrapper
    res_gt = [x for x in product(range(2), repeat=3)]

    assert len(res_g) == len(res_gt)

# Generated at 2022-06-22 04:59:21.565440
# Unit test for function product
def test_product():
    from . import _test_itertools

    assert _test_itertools(itertools.product, product)

# Generated at 2022-06-22 04:59:32.114906
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # Run simple tests
    assert list(product(range(5), range(3))) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (2, 0), (2, 1), (2, 2),
                                                 (3, 0), (3, 1), (3, 2),
                                                 (4, 0), (4, 1), (4, 2)]

# Generated at 2022-06-22 04:59:43.808992
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import numpy_aware_itertools as nai
    assert list(product((1, 2, 3), (10, 11, 12))) == list(itertools.product([1, 2, 3], [10, 11, 12]))
    assert list(product((1, 2, 3), (10, 11, 12))) == list(nai.product_range(1, 3, 10, 12))
    assert list(product((1, 2, 3), (10, 11, 12))) == list(nai.product_range(1, 3, 10, 12, tqdm_class=None))

    assert list(product((1, 2, 3), repeat=2)) == list(itertools.product([1, 2, 3], [1, 2, 3]))

# Generated at 2022-06-22 04:59:48.615121
# Unit test for function product
def test_product():
    # Simple test
    l = [11, 12, 13]
    result = list(product(l))
    assert len(result) == len(l)
    assert result[0] == [11]
    assert result[1] == [12]
    assert result[2] == [13]
    # 2D
    result = list(product(l, l))
    assert len(result) == len(l) ** 2
    assert result[4] == [11, 12]
    assert result[11] == [13, 13]

# Generated at 2022-06-22 05:00:00.176936
# Unit test for function product
def test_product():
    try:
        from numpy import random
        import numpy as np
    except ImportError:
        return  # Skips unit-test if no numpy installed

    if (random.randn(100) < 0).all():
        raise Exception("Numpy's `numpy.random` isn't working!")

    seq = range(10)
    for n in range(1, 4):
        for repeats in range(2, 4):
            for order in [True, False]:
                random.shuffle(seq)
                desired = list(itertools.product(
                    *([seq] * n),
                    repeat=repeats,
                    order=order))
                iters = [seq] * n

# Generated at 2022-06-22 05:00:04.136553
# Unit test for function product
def test_product():
    # Test 1
    list1 = range(200000)
    assert len(list(product(list1, list1))) == len(list(itertools.product(list1, list1)))
    # Test 2
    list2 = range(0, 10, 2)
    assert len(list(product(list2, list2, list2))) == len(list(itertools.product(list2, list2, list2)))

# Generated at 2022-06-22 05:00:11.012169
# Unit test for function product
def test_product():
    for i in product(['a', 'b', 'c'], repeat=3):
        pass


if __name__ == '__main__':
    import unittest
    import doctest

    class TestDoctests(unittest.TestCase):
        def test_doctests(self):
            doctest.testmod()


    unittest.main()

# Generated at 2022-06-22 05:00:14.104566
# Unit test for function product
def test_product():
    """
    Unit tests for function `product`.
    """
    it = product(range(10), range(10), tqdm_class=tqdm_auto)
    assert 100 == sum(1 for _ in it)

# Generated at 2022-06-22 05:00:25.820181
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import math
    import random
    import sys
    random.seed(0)

    for N in range(2, 8):
        for M in range(2, 8):
            L = list(range(N))
            list_prod = []
            for i in product(L, repeat=M):
                list_prod.append(i)

            expected = M * math.log(N)
            observed = sum(len(str(i)) for i in list_prod) / float(len(list_prod))

            assert (expected - 0.2 < observed < expected + 0.2)

    # test that kwargs work with `product`

# Generated at 2022-06-22 05:00:33.383734
# Unit test for function product
def test_product():
    import sys
    def print_unit(unit):
        sys.stdout.write(unit)
    a = range(10)
    b = range(10)
    c = range(10)
    d = [1, 2, 3]
    result = product(a, b, c, d)
    list(result)
    sys.stdout.write("\n")
    result = product(a, b, c, d, tqdm_class = tqdm_auto)
    list(result)
    sys.stdout.write("\n")
    result = product(a, b, c, d, tqdm_class = print_unit)
    list(result)
    sys.stdout.write("\n")


# Generated at 2022-06-22 05:00:55.496993
# Unit test for function product
def test_product():
    """
    Unit tests for function product.
    """
    import sys
    it = product(xrange(2), xrange(2), xrange(2), tqdm_class=tqdm_auto)
    assert next(it) == (0, 0, 0)
    assert next(it) == (0, 0, 1)
    assert next(it) == (0, 1, 0)
    assert next(it) == (0, 1, 1)
    assert next(it) == (1, 0, 0)
    assert next(it) == (1, 0, 1)
    assert next(it) == (1, 1, 0)
    assert next(it) == (1, 1, 1)
    try:
        next(it)
    except StopIteration:
        pass
    else:
        raise Assert

# Generated at 2022-06-22 05:00:58.805701
# Unit test for function product
def test_product():
    """
    Unit test for function product.

    Simple check that this mirrors the original itertools product.
    """
    assert list(product(range(3), repeat=2)) == list(itertools.product(range(3), repeat=2))

# Generated at 2022-06-22 05:01:04.345129
# Unit test for function product
def test_product():
    """Test product function"""
    from ..utils import SimpleNamespace
    a = range(3)
    b = range(4)
    c = range(2)
    d = range(1)
    args = tqdm_auto(list(product(a, b, c, d)), desc="outer", leave=True)
    for (i, (a1, b1, c1, d1)) in enumerate(args):
        assert i == a1 * len(b) * len(c) * len(d) + b1 * len(c) * len(d) + c1 * len(d) + d1

    args = tqdm_auto(product(a, b, c, d), desc="outer", leave=True)

# Generated at 2022-06-22 05:01:09.180933
# Unit test for function product
def test_product():
    list(product([1, 2], [3, 4], [5, 6], tqdm_class=None)) == list(itertools.product([1, 2],
                                                                                    [3, 4],
                                                                                    [5, 6]))

# Generated at 2022-06-22 05:01:12.421435
# Unit test for function product
def test_product():
    """
    Test for the function product
    """
    for _ in tqdm_auto(product(range(10), repeat=2), total=100):
        pass

# Generated at 2022-06-22 05:01:19.016168
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys

    assert list(product(range(10), range(10))) == \
        list(itertools.product(range(10), range(10)))
    assert list(product(range(10), range(10), tqdm_class=None)) == \
        list(itertools.product(range(10), range(10)))
    assert list(product(range(10), range(10), tqdm_class=False)) == \
        list(itertools.product(range(10), range(10)))

    int_big = int(format_sizeof(sys.maxsize)['value'])

# Generated at 2022-06-22 05:01:28.535583
# Unit test for function product
def test_product():
    from operator import eq
    from random import choice, randrange
    from string import ascii_lowercase

    verbose = False

    letters = ascii_lowercase
    trials = 100
    min_iters = 8
    max_iters = 1000
    max_perm_len = 8
    tol = 1e-2
    eps = 1e-8
    i = 0

# Generated at 2022-06-22 05:01:38.951564
# Unit test for function product
def test_product():
    try:
        import pytest
    except ImportError:
        return
    with pytest.raises(TypeError):
        list(product(range(10), "ab"))
    assert list(product(range(10), "ab")) == []
    assert list(product(range(10), [])) == []
    assert list(product([], range(10))) == []
    assert list(product(range(3), range(4))) == [(0, 0), (0, 1), (0, 2),
                                                 (0, 3), (1, 0), (1, 1), (1, 2),
                                                 (1, 3), (2, 0), (2, 1), (2, 2),
                                                 (2, 3)]

# Generated at 2022-06-22 05:01:45.482585
# Unit test for function product
def test_product():
    import gc
    import numpy as np
    from collections import namedtuple

    if not hasattr(itertools, 'product'):
        print('SKIP: itertools.product required for this test')
        return

    with tqdm_auto(product(range(10), repeat=2),
                   ascii=True) as pbar:
        assert sum(1 for _ in pbar) == 100
    with tqdm_auto(product(range(10), range(10), repeat=2),
                   ascii=True, dynamic_ncols=True) as pbar:
        assert sum(1 for _ in pbar) == 200


# Generated at 2022-06-22 05:01:57.499993
# Unit test for function product
def test_product():
    """Test function product"""
    from ..std import numpy as np

    for t in (tqdm_auto, tqdm_no_bar):
        assert sum(item for item in product(range(10), tqdm=t)) == t(range(10)).n // 2
        assert list(product(range(3), range(3), tqdm=t)) == \
               list(t(itertools.product(range(3), range(3))))
        assert list(product(range(3), range(3), repeat=2, tqdm=t)) == \
               list(t(itertools.product(range(3), range(3), repeat=2)))

# Generated at 2022-06-22 05:02:52.739172
# Unit test for function product
def test_product():
    """Unit test for product"""
    from ._utils import _random_data
    iterables = _random_data(8, 2)
    try:
        import pytest
    except ImportError:
        import sys
        pytest = sys.modules.get("pytest")  # NOQA
    if pytest is not None:
        with pytest.raises(Exception):
            list(product(*iterables, total=-999))
        with pytest.raises(Exception):
            list(product(*iterables, total=-2))
    for iterable in iterables:
        assert list(product(iterable)) == list(itertools.product(iterable))
        assert list(product(*iterable)) == list(itertools.product(*iterable))

# Generated at 2022-06-22 05:03:00.585164
# Unit test for function product
def test_product():
    from ..tqdm import trange
    from numpy.random import randint
    from numpy import product as nprod, array_equal

    n = 2 ** (randint(3, 10))
    repeat = randint(3, 10)
    sz = [randint(1, 10) for _ in range(repeat)]
    it = product(range(i) for i in sz)
    with trange(n) as t:
        for _ in t:
            assert array_equal(next(it), product(*(range(i) for i in sz)))
    assert array_equal(list(product(*(range(i) for i in sz))),
                       list(itertools.product(*(range(i) for i in sz))))

# Generated at 2022-06-22 05:03:09.707216
# Unit test for function product
def test_product():
    """
    Unit tests for function `itertools.product`.
    """
    import random
    import string
    import time

    P = __name__ + '.' + test_product.__name__

    try:
        from nose.tools import nottest
    except ImportError:
        def nottest(f):
            return f

    try:
        from numpy.testing import assert_array_equal
    except ImportError:
        def assert_array_equal(a, b):
            assert type(a) == type(b), (type(a), type(b))
            assert a == b, (a, b)

    # `check_equal` is used for all assertions so that nose does not catch
    # the AssertionError and print the huge list in case of failure
    def check_equal(a, b):
        assert a

# Generated at 2022-06-22 05:03:21.837917
# Unit test for function product
def test_product():
    """
    Unit test of `product`.
    """
    # Unit test for function product
    def test_product(tqdm_class=None):
        """
        Unit test of `product`.
        """
        from sys import stderr
        import pytest

        with pytest.raises(TypeError):
            list(tqdm_class.product(range(3)))

        list(tqdm_class.product(range(3), range(4)))

        # test total is None when not all iterables have length
        class NotIterable:
            def __iter__(self):
                yield 1

        for obj in ['hello', 1, b'byte', bytearray('hello')]:
            with pytest.raises(TypeError):
                list(tqdm_class.product(['hello'], obj))
           

# Generated at 2022-06-22 05:03:25.165973
# Unit test for function product
def test_product():
    def test_case_1():
        """Unit test: test_product()"""
        from tqdm import trange
        iterables = ['ABCD', range(4)]
        for _ in trange(10000000):
            for i in product(*iterables):
                pass

# Generated at 2022-06-22 05:03:33.696667
# Unit test for function product
def test_product():
    from .utils import TestReport
    t = TestReport('product')
    assert t.verbosities()
    for tqdm_class in t.tqdm_classes():
        for total in t.totals():
            for args in [
                    (range(4),),
                    (range(4), range(4)),
                    (range(4), range(4), range(4)),
            ]:
                l = list(product(*args, tqdm_class=tqdm_class, total=total))
                assert len(l) == len(set(l)) == 4**len(args)
    t.report()

# Generated at 2022-06-22 05:03:43.321201
# Unit test for function product
def test_product():
    # test with one argument
    items = list(range(10))
    test_iter1 = product(items, total=len(items))
    for i in range(len(items)):
        assert next(test_iter1) == (i,)
    # test with multiple arguments
    items = list(range(10))
    test_iter2 = product(items, items, items, total=len(items) * len(items) * len(items))
    for i in range(len(items)):
        for j in range(len(items)):
            for k in range(len(items)):
                assert next(test_iter2) == (i, j, k)

# Generated at 2022-06-22 05:03:53.774303
# Unit test for function product
def test_product():
    from .itertools import product
    import sys
    from .tests_tqdm import pretest_posttest
    pretest_posttest()
    with tqdm_auto(mininterval=100) as t:
        # next(t)
        def _test_product(iterables, x, total):
            for i, j in zip(product(*iterables), x):
                assert i == j
                t.update(1)
            assert t.total == total

        iterables = [[1], [2, 3], ['a', 'b', 'c']]

# Generated at 2022-06-22 05:03:59.028151
# Unit test for function product
def test_product():
    for i in product([0, 1], tqdm_class=tqdm_auto):
        assert (i == (0, 0)) or (i == (0, 1)) or (i == (1, 0)) or (i == (1, 1))

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:04:08.288978
# Unit test for function product
def test_product():
    """Unit test for itertools_ext.product"""
    from random import randint
    from ..std import next
    from ..utils import format_interval

    def _product(*iterables):
        return [x for x in product(*iterables)]

    def _random_input():
        for _ in range(20):
            n = randint(1, 20)
            yield [randint(0, n) for _ in range(n)]

    def _is_mapping(mapping):
        return all(x in mapping for x in range(6))

    def _sort(lst):
        return sorted(sorted(lst, key=len), key=len)

    def _itertools_product(*args):
        return list(_product(*args))


# Generated at 2022-06-22 05:04:49.076696
# Unit test for function product
def test_product():
    from ..auto import tqdm
    from .utils import format_sizeof

    for i in range(5):
        a = list(range(i))
        b = list(range(i + 1, i + 1 + i))
        with tqdm(product(a, b), total=len(a) * len(b), unit='B', unit_scale=True) as t:
            for _ in t:
                pass

# Generated at 2022-06-22 05:04:58.539788
# Unit test for function product
def test_product():
    from .._utils import _range
    from ..utils import FormatCustomText
    from .._tqdm import tqdm

    for tqdm in [tqdm, tqdm_auto]:
        for kwargs in ({}, {"total": 10000}):
            assert list(product(*[(x, x ** 2, x ** 3) for x in range(2)],
                                tqdm_class=tqdm, **kwargs)) == [
                (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1),
                (1, 1, 0), (1, 1, 1)
            ]
            text = FormatCustomText("%s")

# Generated at 2022-06-22 05:05:08.664891
# Unit test for function product
def test_product():
    from ..utils import FormatWrapBase
    from .utils import TotalSizeMock

    class FormatWrap(FormatWrapBase):
        def __init__(self, iterable):
            super(FormatWrap, self).__init__(iterable)
            self.total_size = iterable.total_size

    prod1 = product(range(3), range(3), tqdm_class=tqdm_auto,
                    total=TotalSizeMock(6))
    prod2 = product(range(3), range(3), tqdm_class=FormatWrap)
    assert prod1.total_size == 6
    assert prod2.total_size == 6
    assert list(prod1) == list(prod2)

# Generated at 2022-06-22 05:05:14.599045
# Unit test for function product
def test_product():
    """
    Test for unit for function `product`.
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import numpy_type_map
    from ..utils import numpy_dtype_bitsize_map
    from os import system
    from sys import platform
    from functools import partial
    from inspect import getsource

    N_TRIALS = 5
    tqdm = partial(product, tqdm_class=tqdm_auto)

    if platform == "win32":
        system("title pytest: function `product`")

    # Test `product` as a direct alternative to `itertools.product`
    # with a simple list
    xs = list(range(10))
    assert list(tqdm(xs)) == list(itertools.product(xs))

# Generated at 2022-06-22 05:05:19.366296
# Unit test for function product
def test_product():
    """Test function product"""
    with tqdm_auto(total=24) as t:
        for i in product(range(3), range(4), range(2)):
            t.update()
    with tqdm_auto(total=10) as t:
        for i in product(range(10)):
            t.update()

# Generated at 2022-06-22 05:05:24.454672
# Unit test for function product
def test_product():
    """ Unit test for function product """
    try:
        __IPYTHON__
    except NameError:
        return
    from IPython.display import HTML, display
    from .tests import test_out

    print("Testing `itertools_ext.product`:")
    test_out(product, "product", "first", "second")

# Generated at 2022-06-22 05:05:33.017774
# Unit test for function product
def test_product():
    assert set(product('ab', 'cd', tqdm_class=None)) == \
        set(itertools.product('ab', 'cd'))

    assert set(product('ab', 'cd')) == \
        set(itertools.product('ab', 'cd'))

    assert set(product('ab', 'cd', 'ef', tqdm_class=None)) == \
        set(itertools.product('ab', 'cd', 'ef'))

    assert set(product('ab', 'cd', 'ef')) == \
        set(itertools.product('ab', 'cd', 'ef'))

# Generated at 2022-06-22 05:05:35.853709
# Unit test for function product
def test_product():
    pass
    # TODO: implement
    #import unittest
    #class TestProduct(unittest.TestCase):
    #    def test_product(self):
    #        self.assertEqual(...)
    #unittest.main()

# Generated at 2022-06-22 05:05:47.141465
# Unit test for function product
def test_product():
    import numpy as np
    # Test that it works
    assert (list(product([[1, 2], [3, 4]], repeat=2))
            == list(itertools.product([[1, 2], [3, 4]], repeat=2)))
    # Test that output is deterministic
    x = np.random.randint(1, high=1000, size=(2, 3, 4)).tolist()
    y = np.random.randint(1, high=1000, size=(2, 3, 4)).tolist()
    z = np.random.randint(1, high=1000, size=(2, 3, 4)).tolist()
    assert (list(product(x, y, z))
            == list(itertools.product(x, y, z)))
    # Test that it works with empty iter

# Generated at 2022-06-22 05:05:52.171122
# Unit test for function product
def test_product():
    """Test that `itertools.product` yields the same result with `product`."""
    assert list(product(range(10), repeat=2)) == list(itertools.product(range(10), repeat=2))
    assert list(product(range(10))) == list(itertools.product(range(10)))
    assert list(product(range(10), range(5))) == list(itertools.product(range(10), range(5)))