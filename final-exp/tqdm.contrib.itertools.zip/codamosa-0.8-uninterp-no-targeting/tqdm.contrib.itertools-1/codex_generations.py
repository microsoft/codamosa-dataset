

# Generated at 2022-06-22 04:56:16.552770
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .utils import FormatCustom
    from .tqdm import tqdm
    from .std import stdout  # NOQA # Needed to monkey patch tqdm
    stdout._set_options = FormatCustom({"bar_format": "TEST |{bar}|"})
    assert list(product(range(2),
                        range(2),
                        range(2),
                        bar_format='{l_bar}TEST{bar}TEST{r_bar}',
                        ascii=True,
                        tqdm=tqdm)) == list(itertools.product(range(2),
                                                              range(2),
                                                              range(2)))

# Generated at 2022-06-22 04:56:17.332636
# Unit test for function product
def test_product():
    from .tests import test_product_
    test_product_(product)

# Generated at 2022-06-22 04:56:21.003495
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for _ in product(range(2), [1, 2]):
        pass
    assert True

# Generated at 2022-06-22 04:56:25.966311
# Unit test for function product
def test_product():
    a = list(range(3))
    b = list(range(3))
    c = list(range(3))
    p = product(a, b, c)
    assert hasattr(p, '__iter__')
    assert all(i == (x,y,z) for i, (x,y,z) in enumerate(itertools.product(a, b, c)))

# Generated at 2022-06-22 04:56:33.800925
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    t = product([1, 2, 3], ('a', 'b', 'c'), desc='desc1')
    assert_equal(list(t), [(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'),
                           (2, 'b'), (2, 'c'), (3, 'a'), (3, 'b'), (3, 'c')])

# Generated at 2022-06-22 04:56:42.608790
# Unit test for function product
def test_product():
    """Unit test for `tqdm.tqdm.product`"""
    if not tqdm_auto._deprecated:
        return
    a = range(2)
    b = range(2)

    # use the class's total attribute to determine length
    p = product(a, b, tqdm_class=tqdm_auto.tqdm)
    assert len(list(p)) == 4

    # explicitly specify total
    p = product(a, b, total=4, tqdm_class=tqdm_auto.tqdm)
    assert len(list(p)) == 4

    # specify total which is too big
    p = product(a, b, total=5, tqdm_class=tqdm_auto.tqdm)
    assert len(list(p)) == 4

    # specify

# Generated at 2022-06-22 04:56:54.455544
# Unit test for function product
def test_product():
    try:
        list(product(range(5), repeat=2))
    except (RuntimeError, TypeError):
        pass
    else:
        raise TypeError("product(range(5), repeat=2) must raise error")

    list(product(range(5), repeat=2))

    assert list(product(range(2))) == [(0,), (1,)]
    assert list(product([1, 2, 3], repeat=1)) == [(1,), (2,), (3,)]
    assert list(product([1, 2, 3], repeat=2)) == [(1, 1), (1, 2),
                                                  (1, 3), (2, 1),
                                                  (2, 2), (2, 3),
                                                  (3, 1), (3, 2),
                                                  (3, 3)]



# Generated at 2022-06-22 04:56:59.818099
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    assert_equal(
        list(product(["a", "b", "c"], [1, 2], [None, "dat"], tqdm_class=tqdm_auto)),
        list(itertools.product(["a", "b", "c"], [1, 2], [None, "dat"])))



# Generated at 2022-06-22 04:57:02.152604
# Unit test for function product
def test_product():
    r = product(range(10), repeat=2, tqdm_class=tqdm_auto)
    assert next(r) == (0, 0)
    assert sum(1 for _ in r) == 81

# Generated at 2022-06-22 04:57:14.050540
# Unit test for function product
def test_product():
    from sys import stdout
    from time import sleep
    with tqdm(total=10, file=stdout) as t:
        for c in product(range(100), range(100), range(100)):  # NOQA
            t.update()
            sleep(0.01)


try:
    # backported from Python 3.5
    from itertools import zip_longest
except ImportError:
    # copy from itertools.zip_longest in Python 3.5
    class zip_longest:
        """Make an iterator that aggregates elements from each of the iterables.
        If the iterables are of uneven length, missing values are filled-in
        with fillvalue. Iteration continues until the longest iterable is
        exhausted.
        """


# Generated at 2022-06-22 04:57:22.379316
# Unit test for function product
def test_product():
    l = (list(range(100)), list(range(10)))
    itertools_product = list(itertools.product(*l))
    tqdm_product = list(product(*l))
    assert itertools_product == tqdm_product

# Generated at 2022-06-22 04:57:24.688763
# Unit test for function product
def test_product():
    # Testing that it accepts iterables of different lengths
    for a, b, c in product('abc', 'def', 'ghi', tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 04:57:36.195688
# Unit test for function product
def test_product():
    try:
        from numpy import arange, array
    except ImportError:
        return

    assert list(product(arange(2))) == [(0,), (1,)]
    assert list(product(arange(2), arange(2))) == [(0, 0), (0, 1), (1, 0), (1, 1)]

    assert list(product(arange(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(arange(3), repeat=2)) == [(0, 0), (0, 1), (0, 2),
                                                  (1, 0), (1, 1), (1, 2),
                                                  (2, 0), (2, 1), (2, 2)]


# Generated at 2022-06-22 04:57:47.766829
# Unit test for function product
def test_product():
    from .tests_tqdm import with_unit_option, _range
    for tqdm_class in [tqdm_auto]:
        for i in range(0, 4):
            assert list(product([])) == [()]
            assert list(product([1])) == [(1,)]
            assert list(product([1, 2])) == [(1, 2), (1, 2)]
            assert list(product(_range(5), repeat=3)) == list(
                itertools.product(_range(5), _range(5), _range(5)))

            res = list(product(
                _range(5),
                repeat=i,
                tqdm_class=with_unit_option(tqdm_class, disable=True)))

# Generated at 2022-06-22 04:57:51.691109
# Unit test for function product
def test_product():
    import numpy as np
    a = list("abc")
    b = range(3)
    c = np.array([0.0, 1.0, 2.0])
    for i in product(a, b, c, tqdm_class=tqdm_auto):
        pass
    return

# Generated at 2022-06-22 04:58:03.311146
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import collections

    def iproduct(tqdm_class, *iterables):
        return list(product(*iterables, tqdm_class=tqdm_class))


# Generated at 2022-06-22 04:58:15.208298
# Unit test for function product
def test_product():
    """
    Unit test for product
    """
    from ..utils import _range
    try:
        import numpy
    except ImportError:
        pass
    else:
        assert list(product(numpy.arange(3), repeat=2)) == \
            list(product(_range(3), _range(3)))
        assert list(product([1, 2], ['a', 'b'], [True, False])) == \
            list(product([1, 2], ['a', 'b'], [True, False]))
        assert list(product(range(4))) == list(product(range(4)))
        assert list(product(range(1, 4), repeat=2)) == \
            list(product(range(1, 4), repeat=2))
    p = product(range(3), range(3), range(3))

# Generated at 2022-06-22 04:58:27.190492
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from numpy.random import randint
    for n, m in [(10, 100), (10, 3), (10, 2), (10, 1), (10, 0)]:
        for i in product(range(n), range(m)):
            assert i
        for i in product(range(n), repeat=m):
            assert i
        for i in product(range(n), range(m), tqdm_class=None):
            assert i
        for i in product(range(n), range(m), tqdm_class=tqdm_auto):
            assert i
        for i in product(range(n), range(m), tqdm_class=tqdm_auto, leave=True):
            assert i

# Generated at 2022-06-22 04:58:38.322988
# Unit test for function product
def test_product():
    import random
    import sys
    import time

    try:
        from nose.tools import assert_equal
    except ImportError:
        def assert_equal(a, b):
            try:
                assert a == b
            except AssertionError:
                raise AssertionError('%r != %r' % (a, b))

    maxsize = 1000000
    maxvalue = 100000
    for i in range(10):
        for j in range(10):
            for k in range(10):
                data = []
                for _ in product(range(i), range(j), range(k)):
                    data.append(_)
                assert_equal(len(data), i*j*k)

# Generated at 2022-06-22 04:58:47.575907
# Unit test for function product
def test_product():
    """Unit test for product"""
    p = product([1, 2, 3], [4, 5], ['alpha', 'beta'])
    expected = [(1, 4, 'alpha'), (1, 4, 'beta'), (1, 5, 'alpha'),
                (1, 5, 'beta'), (2, 4, 'alpha'), (2, 4, 'beta'),
                (2, 5, 'alpha'), (2, 5, 'beta'), (3, 4, 'alpha'),
                (3, 4, 'beta'), (3, 5, 'alpha'), (3, 5, 'beta')]
    observed = list(p)
    assert observed == expected

# Generated at 2022-06-22 04:58:51.339930
# Unit test for function product
def test_product():
    """Unit test for function product"""
    list(product(range(3), range(3)))

# Generated at 2022-06-22 04:59:03.165496
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range
    from .tests_tqdm import pretest, posttest, capture_stdout

    @with_setup(pretest, posttest)
    def base_test_product():
        """base test for function product"""
        for _ in product([1, 2, 3], ['a', 'b', 'c'], range(3)):
            pass

    @with_setup(pretest, posttest)
    def stdout_test_product():
        """test for function product with stdout"""
        with capture_stdout() as stdout:
            for _ in product([1, 2, 3], ['a', 'b', 'c'], range(3)):
                pass
            assert stdout.getvalue().count("\n") == 8


# Generated at 2022-06-22 04:59:10.522895
# Unit test for function product
def test_product():
    import numpy as np
    from .tests import pretest_numpy
    pretest_numpy()
    # Simple unit test based on trivial examples
    # and random sample
    i1 = range(10)
    i2 = range(5)
    i3 = range(3)
    i4 = range(7)
    i5 = range(2)
    p1 = list(product(i1, i2, i3, i4, i5))
    p2 = list(itertools.product(i1, i2, i3, i4, i5))
    assert p1 == p2, "Pure python test failed"
    n1 = np.array(p1)
    n2 = np.array(p2)

# Generated at 2022-06-22 04:59:14.628124
# Unit test for function product
def test_product():
    """
    Test of function product.
    """
    from ..utils import FormatCustomText, format_sizeof
    ia1 = tqdm_auto(range(10))
    ip = product(range(1, 10), range(1, 10), range(1, 10))
    total = sum(1 for _ in ip)
    assert total == 729

    res = []
    for i in product(range(1, 10), range(1, 10), range(1, 10),
                     total=total / 9,
                     bar_format=FormatCustomText(
                         "Test | {desc: <20} {percentage:3.0f}%",
                         ncols=20)):
        res.append(i)
        assert min(i) == 1
        assert max(i) == 9

    assert len(res) == 7

# Generated at 2022-06-22 04:59:23.758988
# Unit test for function product
def test_product():
    """
    Test `itertools.product` from tqdm.
    """
    from nose.tools import assert_raises
    from .tests_tqdm import leaves, total, add_docstrings

    # Test unit
    for lo, hi in ((0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (0, 10)):
        for t in (tqdm_auto, tqdm_gui, tqdm, tqdm_notebook):
            res = list(product(range(lo), range(hi), tqdm_class=t))
            assert res == list(itertools.product(range(lo), range(hi)))
            pbar = t(total=total(t, lo * hi))

# Generated at 2022-06-22 04:59:32.347079
# Unit test for function product
def test_product():
    from ..progressbar import trange
    from ..tests_tqdm import UnicodeIO
    from ..utils import FormatWatcher
    lst = [1, 2]
    for inp in [
            lst,
            iter(lst)
    ]:
        with FormatWatcher() as fw:
            for _ in tqdm_auto(product(inp), file=UnicodeIO(), total=2):
                pass
        output = fw.native_stringify()
        assert output == "  1%|          | 1/2 [00:00<?, ?it/s]\n"
        assert output.encode('utf8') == b"  1%|          | 1/2 [00:00<?, ?it/s]\n"
        assert not output.endswith('\r')


# Generated at 2022-06-22 04:59:42.566762
# Unit test for function product
def test_product():
    it = product(range(10), range(3), tqdm=None)
    assert sum(1 for _ in it) == 10 * 3
    it = product(range(10), range(3), tqdm=None)
    it = product(it, range(4), tqdm=None)
    assert sum(1 for _ in it) == 10 * 3 * 4
    it = product(range(10), range(3), tqdm=None)
    it = product(it, range(4), tqdm=None)
    it = product(it, range(5), tqdm=None)
    assert sum(1 for _ in it) == 10 * 3 * 4 * 5

# Generated at 2022-06-22 04:59:49.531697
# Unit test for function product
def test_product():
    """
    Unit test for the function `product`.
    """
    from .gufunc import product as tqdm_product

    # Make sure it produces the same results
    data_1 = [list(range(4)), list(range(4)), list(range(4))]
    for i1, i2 in zip(tqdm_product(*data_1), product(*data_1)):
        assert(i1 == i2)

    # No exception with None
    for i1, i2 in zip(tqdm_product(*data_1, total=None),
                      product(*data_1, total=None)):
        assert(i1 == i2)

    # Exception with non-integer

# Generated at 2022-06-22 04:59:54.471088
# Unit test for function product
def test_product():
    for i, j in zip(product(range(4), repeat=2),
                    itertools.product(range(4), repeat=2)):
        assert i == j
    for i, j in zip(product(range(8), repeat=3),
                    itertools.product(range(8), repeat=3)):
        assert i == j

# Generated at 2022-06-22 05:00:01.934113
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    import pytest

    iterables = [('ABCD', repeat), range(2), ['ab']]

    with tqdm_auto(ncols=10,
                   total=len(iterables[0]) * len(iterables[1]) *
                   len(iterables[2])) as t:
        results = list(product(*iterables, tqdm_class=t.__class__))
    expected = list(itertools.product(*iterables))
    assert results == expected

# Generated at 2022-06-22 05:00:15.949038
# Unit test for function product
def test_product():
    """Test whether a tqdm instance is returned on every call."""
    assert next(product(range(4))) == (0,)
    for i in product(range(4), range(3), range(2)):
        pass
    assert next(product(range(4),
                        tqdm_class=tqdm_auto.tqdm_gui(leave=False))) == (0,)
    from .tqdm_gui import tqdm_gui
    for i in product(range(4),
                     tqdm_class=tqdm_gui(leave=False)):
        pass
    for i in product(range(4),
                     tqdm_class=tqdm_auto.tqdm_notebook(leave=False)):
        pass
    # Ensure normal progress bar is returned if run from terminal
    tqdm

# Generated at 2022-06-22 05:00:21.615037
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    list(
        product(
            range(1, 10),
            range(0, 100, 10),
            range(10, 200, 100),
            range(1000, 10000, 1000),
            tqdm_class=tqdm_auto))

# Generated at 2022-06-22 05:00:26.845473
# Unit test for function product
def test_product():
    assert list(product([1, 2], repeat=3)) == [
        [1, 1, 1],
        [1, 1, 2],
        [1, 2, 1],
        [1, 2, 2],
        [2, 1, 1],
        [2, 1, 2],
        [2, 2, 1],
        [2, 2, 2]]

###################################################################
# Test
if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:00:29.839453
# Unit test for function product
def test_product():
    """Run unit tests for function product"""
    from ..utils import _range
    list(zip(product(_range(10), _range(5)),
             itertools.product(_range(10), _range(5))))

# Generated at 2022-06-22 05:00:42.072697
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from tqdm import trange
    assert list(product(range(3000))) == list(itertools.product(range(3000)))
    assert list(product(range(3000), range(10))) == list(itertools.product(range(3000), range(10)))
    assert list(product(range(3000), range(10), range(3))) == list(itertools.product(range(3000), range(10), range(3)))
    assert list(product(range(3), range(3000), range(10), range(3))) == list(itertools.product(range(3), range(3000), range(10), range(3)))

# Generated at 2022-06-22 05:00:51.403489
# Unit test for function product
def test_product():
    import numpy as np
    a = np.zeros((3, 2, 4))
    for i in product(range(3), range(2), range(4), total=24, mininterval=0.1):
        a[i] = i
    assert np.all(a == np.arange(24).reshape((3, 2, 4)))
    assert a[0, 0, 0] == 0
    assert a[-1, -1, -1] == 23

# Generated at 2022-06-22 05:00:59.115417
# Unit test for function product

# Generated at 2022-06-22 05:01:09.893231
# Unit test for function product
def test_product():
    from ..tests._utils import closing
    from ..std import time
    for n in (None, 10, 100):
        for cls in (tqdm_auto,):
            with closing(cls(n, unit='it', leave=True)) as t:
                res = 0
                for i in product(t, range(n if n is not None else 5)):
                    res += sum(i)
                    time.sleep(.01)
            assert t.n == n if n is not None else len(t.itertuple)
            if n is None:
                assert t.itertuple == tuple(range(n))
            assert res == (n or 5) * ((n or 5) - 1) / 2

# Generated at 2022-06-22 05:01:16.549246
# Unit test for function product
def test_product():
    l1 = list(product(range(10), range(10)))
    test1 = list(itertools.product(range(10), range(10)))
    assert l1 == test1

    l2 = list(product(range(10), range(10),
                      tqdm_class=tqdm_auto.tqdm, leave=True))
    test2 = list(itertools.product(range(10), range(10),
                                   tqdm_class=tqdm_auto.tqdm, leave=True))
    assert l2 == test2

# Generated at 2022-06-22 05:01:22.493782
# Unit test for function product
def test_product():
    from .utils import TestCase, closing, nested
    with closing(nested(tqdm(product([1, 2, 3]),
                            total=3, ascii=True))):
        pass
    with closing(nested(tqdm(product([1, 2, 3]),
                            total=3, ascii=True, mininterval=1e-9))):
        pass

# Generated at 2022-06-22 05:01:38.907346
# Unit test for function product
def test_product():
    from random import random
    N = 100
    M = 100

    def product_manual(N, M):
        l = []
        for i in range(N):
            for j in range(M):
                l.append((i, j))
        return l

    def product_with_tqdm(*args):
        return list(product(*args, disable=True))

    def product_no_tqdm(*args):
        return list(product(*args, disable=False))

    lst = [range(100), range(100), range(100)]

    assert product_manual(N, M) == product_with_tqdm(range(N), range(M)) == \
           product_no_tqdm(range(N), range(M))
    assert product_manual(*lst) == product_with_

# Generated at 2022-06-22 05:01:45.462041
# Unit test for function product
def test_product():
    from .tests import closing, tqdm
    with closing(product([1, 2], tqdm_class=tqdm)) as prd:
        assert list(prd) == [(1, 1), (1, 2), (2, 1), (2, 2)]

    with closing(product(tqdm([1, 2]), tqdm([1, 2]))) as prd:
        assert list(prd) == [(1, 1), (1, 2), (2, 1), (2, 2)]

    with closing(product(tqdm([1, 2]), tqdm([1, 2]))) as prd:
        assert list(prd) == [(1, 1), (1, 2), (2, 1), (2, 2)]


# Generated at 2022-06-22 05:01:54.231533
# Unit test for function product
def test_product():
    from .core import _range

    for i in product(_range(10), _range(10), _range(10, 20), tqdm_class=tqdm_auto):
        pass

    for i in product(_range(10), tqdm_class=tqdm_auto):
        pass

    for i in product(_range(10), _range(10), tqdm_class=tqdm_auto, ascii=True):
        pass

    for i in _range(10):
        pass

# Generated at 2022-06-22 05:02:02.670944
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from operator import mul
    import math

    class slow_mul(object):
        def __init__(self, n):
            self.n = n

        def __mul__(self, rhs):
            import time
            time.sleep(.1)
            return self.n * rhs

    total = 10


# Generated at 2022-06-22 05:02:09.639774
# Unit test for function product
def test_product():
    """Unit test for this module"""
    import operator
    import functools

    x = range(10)
    y = range(10)
    z = range(10)

    expect = itertools.product(x,y,z)
    expect = list(expect)

    result = product(x,y,z)
    result = list(result)

    assert result == expect, "product failed unit test"

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:02:18.374776
# Unit test for function product
def test_product():
    import numpy
    import os
    global tqdm_class

    def product_tests(tqdm):
        # product_tests is a generator and will yield until StopIteration
        # is raised
        # Simple tests
        assert list(zip(tqdm(range(3), range(4), range(5), range(6)))) == \
            list(zip(range(3), range(4), range(5), range(6)))
        assert list(zip(map(float, tqdm(range(3), range(4), range(5), range(6))))) == \
            list(zip(map(float, range(3), range(4), range(5), range(6))))
        # Adaptive tests
        # Test for adaptivity with long iterable

# Generated at 2022-06-22 05:02:25.038334
# Unit test for function product
def test_product():
    '''
    Checks that tqdm.product gives the same result as itertools.product
    while displaying the progress bar
    '''
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))

# Generated at 2022-06-22 05:02:33.194656
# Unit test for function product
def test_product():
    """ Test function product in module itertools """
    import pandas as pd
    from pandas.util.testing import assert_series_equal
    import numpy as np
    import random
    import sys

    sys.stderr.write("test_product: ")
    test_pd = pd.Series([str(r) for r in np.random.rand(random.randint(1, 10))])
    test_np = np.random.rand(random.randint(1, 10), random.randint(1, 10))
    test_it_pd_np = list(itertools.product(test_pd, test_np))
    test_pd_np = list(product(test_pd, test_np, bar_format='{desc}'))

# Generated at 2022-06-22 05:02:42.969383
# Unit test for function product
def test_product():
    from sys import version_info
    from os import devnull
    from .tests_tqdm_wandb import pretest_posttest
    from .tests_tqdm import closing_environ

    python_version = version_info
    if python_version[0] >= 3 and python_version[1] >= 3:
        with closing_environ():
            with open(devnull, 'w') as devnull:
                def yield_product():
                    for i in product([1, 2, 3], tqdm_class=tqdm_auto,
                                     file=devnull):
                        yield i


# Generated at 2022-06-22 05:02:54.478752
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`
    """
    from ..utils import format_sizeof

# Generated at 2022-06-22 05:03:11.677653
# Unit test for function product
def test_product():
    import sys
    import pytest

    dummy_iterable = [range(5), range(5), range(5)]

    if tqdm_auto.DISABLE:
        tqdm_auto.tqdm = pytest.mark.skip(tqdm_auto.tqdm)

    with pytest.raises(TypeError):
        dummy_iterable.__len__ = None
        list(product(*dummy_iterable, tqdm_class=tqdm_auto.tqdm))
    dummy_iterable.__len__ = list.__len__

    # Test range
    for i1, i2 in zip(itertools.product(*dummy_iterable),
                      product(*dummy_iterable, tqdm_class=tqdm_auto.tqdm)):
        assert i1 == i

# Generated at 2022-06-22 05:03:23.788892
# Unit test for function product
def test_product():
    import pytest
    from ..tqdm import tqdm
    from .._tqdm import __version__
    from ..utils import _term_move_up

    try:
        with tqdm(product([1], [2], [3]), desc='tqdm(product(...))') as t:
            for _ in t:
                pass
    except TypeError:
        assert 'tqdm_class' in __version__

    with tqdm(total=6, desc='product(...)', miniters=6, mininterval=0) as t:
        for i, _ in enumerate(product([1, 2], [3, 4])):
            assert (i + 1) == t.n
            t.update()

    # Test that tqdm product can be called with a tqdm class

# Generated at 2022-06-22 05:03:34.485096
# Unit test for function product
def test_product():
    from .._tqdm_test_case import _TqdmTestCase
    import numpy as np
    with _TqdmTestCase() as t:
        r = list(t.tqdm(product('AB', '12'), desc='outer'))
        assert r == [('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]

        r = list(t.tqdm([-1, 0, 1], product([-1, 0, 1], repeat=2)))

# Generated at 2022-06-22 05:03:45.393134
# Unit test for function product
def test_product():
    """Test for function `product`."""
    from numpy.testing import assert_equal
    from collections import Counter
    from .utils import ComparableStringIO

    def tqdm_get_value(*args, **kwargs):
        return 5

    # Test that simple product is correct
    p = list(product("abcd", repeat=2, tqdm_class=tqdm_get_value))
    assert_equal(len(p), 16)
    assert (("a", "a") in p)
    assert (("a", "d") in p)
    assert (("d", "d") in p)

    # Test that counting product is correct
    s = ComparableStringIO()

# Generated at 2022-06-22 05:03:48.160144
# Unit test for function product
def test_product():
    """Test for product()"""
    from .tests import test_product

    test_product(product)

# Generated at 2022-06-22 05:03:59.030255
# Unit test for function product
def test_product():
    """
    Unit test for function :func:`product`.
    """
    import sys
    import numpy as np
    from ..pandas import trange
    from ..std import tqdm_std

    iterables = [range(10000) for _ in range(10)]

    assert list(product(*iterables)) == list(itertools.product(*iterables))
    assert list(product(iterables[0], iterables[1])) == list(
        itertools.product(iterables[0], iterables[1]))


# Generated at 2022-06-22 05:04:02.698242
# Unit test for function product
def test_product():
    import gc
    from .tqdm_gui import tqdm
    for _ in tqdm(product(range(4), range(4), range(4),
                          tqdm_class=tqdm)):
        pass
    assert (gc.collect()) == 0

# Generated at 2022-06-22 05:04:10.106081
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..pandas import pd
    from ..iter import _range

    try:
        from numpy import empty  # NOQA
    except ImportError:
        # tests are skipped
        return

    # test for product with exact total
    for total in [None, 1, 10, 100]:
        with tqdm_auto(total=total) as t:
            t.update(t.total - 1)
            t.update(t.total)
        with tqdm_auto(total=total) as t:
            t.update(t.total + 1)
        with tqdm_auto(total=total) as t:
            t.update(t.total + 1)
            try:
                t.update(t.total)
            except ValueError:
                pass
           

# Generated at 2022-06-22 05:04:17.114767
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    list_of_lists = [[1, 2], [3], [4, 5, 6]]

    assert list(product(*list_of_lists, tqdm_class=None)) \
        == list(itertools.product(*list_of_lists))

    assert list(product(*list_of_lists, tqdm_class=tqdm_auto)) \
        == list(itertools.product(*list_of_lists))
    return

# Generated at 2022-06-22 05:04:19.951380
# Unit test for function product
def test_product():
    """Test the function product."""
    from tqdm import tqdm
    try:
        from tqdm.contrib import product
    except ImportError:
        return

    list(tqdm(product(range(3), repeat=2), total=9))

# Generated at 2022-06-22 05:04:45.021644
# Unit test for function product
def test_product():
    import numpy as np
    iterlist = [[1, 2, 3], [4, 5, 6]]
    assert list(product(*iterlist, ascii=True, desc="test")) == list(itertools.product(*iterlist))

    dom = np.linspace(0., 1., 21)
    assert list(product(dom, repeat=2, ascii=True, desc="test")) == list(itertools.product(dom, repeat=2))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:04:52.755944
# Unit test for function product
def test_product():
    from .common import Benchmark

    def itertools_product():
        for _ in itertools.product(range(100), range(100), range(100)):
            pass

    def tqdm_product():
        for _ in product(range(100), range(100), range(100)):
            pass

    with Benchmark("itertools.product  "):
        itertools_product()
    with Benchmark("tqdm.product  "):
        tqdm_product()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:04:57.756279
# Unit test for function product
def test_product():
    with tqdm_auto(unit='i', total=1) as t:
        for i in product(range(5), range(5), range(3), tqdm_class=tqdm_auto):
            pass
        assert(t.total == 5 * 5 * 3)
        assert(t.n == 5 * 5 * 3)
        assert(t.last_print_n == 5 * 5 * 3)

# Generated at 2022-06-22 05:05:03.759916
# Unit test for function product
def test_product():
    from .tests.utils import BaseTestTqdmFunctional


# Generated at 2022-06-22 05:05:07.697088
# Unit test for function product
def test_product():
    with tqdm_auto(total=0) as t:
        assert list(product(t, [1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]
        assert t.n == 4
        assert t.total == 4
        assert not t.disable

# Generated at 2022-06-22 05:05:14.865355
# Unit test for function product
def test_product():
    from itertools import product
    for i, j in zip(product(list(range(3)), list(range(3)), list(range(3))),
                    tqdm_itertools.product(list(range(3)), list(range(3)),
                                           list(range(3)))):
        assert i == j
    # should work okay with strings (unlike itertools.product)
    for i in tqdm_itertools.product("abc", "abc"):
        assert i

# Generated at 2022-06-22 05:05:23.441676
# Unit test for function product
def test_product():
    from itertools import product as itertools_product
    for i in range(100):
        for args in [4 * [[0, 1]], [range(3), [-3]], [range(2), range(2), range(2)]]:
            assert list(product(*args, tqdm_class=tqdm_auto)) == \
                   list(itertools_product(*args))
        for args in [4 * [[0, 1]], [range(3), [-3]], [range(2), range(2), range(2)]]:
            assert list(product(*args, tqdm_class=tqdm_auto, ascii=True)) == \
                   list(itertools_product(*args))

# Generated at 2022-06-22 05:05:34.028813
# Unit test for function product
def test_product():
    """
    Tests function `product` with `numpy.arange` and `operator.add()`.
    """
    import operator
    import numpy as np
    import warnings

    # 'ignore' because of numpy deprecation warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        a = np.arange(10)
        res = list(tqdm.product(a, repeat=2, tqdm_class=tqdm.trange))
    assert res == list(itertools.product(a, repeat=2))
    res = list(tqdm.product(a, repeat=2, tqdm_class=tqdm.trange))
    assert res == list(itertools.product(a, repeat=2))
    a = np.arange(10).reshape

# Generated at 2022-06-22 05:05:39.411951
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from . import tqdm
    from .tests import _suppress_stderr

    with _suppress_stderr():
        for i in product(["a", "b", "c", "d"], repeat=2,
                         tqdm_class=tqdm.tnrange):
            pass

# Generated at 2022-06-22 05:05:44.015088
# Unit test for function product
def test_product():
    # Test tqdm for function product
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    # Test tqdm for function product with total=None
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass