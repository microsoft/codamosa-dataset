

# Generated at 2022-06-22 04:56:27.072004
# Unit test for function product
def test_product():
    from .. import trange
    from .tests import closing, _range

    assert list(product(_range(4), _range(4), tqdm_class=trange)) \
        == list(itertools.product(_range(4), _range(4)))

    assert list(product(_range(4), _range(4), _range(4), tqdm_class=trange)) \
        == list(itertools.product(_range(4), _range(4), _range(4)))

    a = closing(product(_range(4), _range(4), tqdm_class=trange))
    b = closing(itertools.product(_range(4), _range(4)))
    assert next(a) == (0, 0)
    assert next(b) == (0, 0)

# Generated at 2022-06-22 04:56:33.537892
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    class TestClass:
        @classmethod
        def method(cls):
            return cls()
        test = method
    for kwargs in [dict(), dict(total=4)]:
        l = 0
        for _ in product([1, 2, 3], ['a', 'b'], **kwargs):
            l += 1
        assert l == 6

        l = 0
        with tqdm_auto(**kwargs) as t:
            for i in product([1, 2, 3], ['a', 'b'], **kwargs):
                l += 1
                t.update()
        assert l == 6

        l = 0
        for _ in product(("a", "b", "c"), repeat=2, **kwargs):
            l += 1
        assert l == 9

       

# Generated at 2022-06-22 04:56:39.197157
# Unit test for function product
def test_product():
    """Test a minimal example with a range of values."""
    # Test the basic case
    minimum = 2
    maximum = 4
    assert list(product(range(minimum, maximum))) == \
        list(itertools.product(range(minimum, maximum)))
    # Test that the length is correct
    minimum = 2
    maximum = 4
    assert len(list(product(range(minimum, maximum)))) == \
        len(list(itertools.product(range(minimum, maximum))))
    # Test that the length is correct for more than one iterator
    minimum = 2
    maximum = 4
    assert len(list(product(range(minimum, maximum),
                            range(minimum, maximum)))) == \
        len(list(itertools.product(range(minimum, maximum),
                                   range(minimum, maximum))))
    # Test that the length

# Generated at 2022-06-22 04:56:51.250275
# Unit test for function product
def test_product():
    """ Test non-ASCII, non-integer iteration """
    p = product(["a", "b", "c", "d"],
                ["e", "f", "g", "h"],
                ["i", "j", "k"],
                tqdm_class=None)

# Generated at 2022-06-22 04:56:56.133102
# Unit test for function product
def test_product():
    """ Unit test for function product """
    from ..tests import test_product
    total = 0
    for i in product([6, 7], [0.1, 0.2, 0.3], tqdm_class=test_product,
                     desc="test product"):
        total += 1
    assert total == 6

# Generated at 2022-06-22 04:57:01.728453
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from ..tests import pretest_posttest_in_tests
    with pretest_posttest_in_tests():
        with tqdm_auto(desc="outer") as outer:
            for i in product(range(3), range(2), tqdm_class=tqdm_auto,
                             desc="inner"):
                outer.update()

# Generated at 2022-06-22 04:57:14.014388
# Unit test for function product
def test_product():
    from .tqdm_test_cases import tqdm_test_case

    def test(iterables, total, leave=True):
        t = list(product(*iterables, leave=leave, tqdm_class=tqdm_test_case))
        assert (total is None) or (len(t) == total)

    test([range(3), range(3), range(3), range(3), range(3), range(3),
          range(3), range(3)],
         729)
    test([range(3), range(3), range(3), range(3), range(3), range(3),
          range(3), range(3)],
         729)

# Generated at 2022-06-22 04:57:21.258346
# Unit test for function product
def test_product():
    try:
        import pytest
        import numpy as np
        from numpy.testing import assert_array_equal
    except ImportError:
        print("numpy or pytest is not installed, skipping test_product")
    else:
        from .tests_tqdm import with_setup, pretest_posttest

        @with_setup(pretest_posttest)
        @pytest.mark.parametrize("tqdm_class", [tqdm_auto])
        def test_product_numpy(tqdm_class):
            x = np.array(range(4))
            y = np.array(range(5))
            exp_x, exp_y = list(zip(*list(itertools.product(x, y))))

# Generated at 2022-06-22 04:57:31.436168
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import sys
    import tqdm

    if '--fast' in sys.argv:
        sys.stderr = tqdm.tqdm(sys.stderr, leave=False)
    else:
        sys.stderr = tqdm.tqdm(
            sys.stderr, leave=True, dynamic_ncols=True)
    n = 10
    print('itertools.product, len/total > 0:')
    for i, _ in zip(range(5), tqdm.tqdm(itertools.product(range(n),
                                                          range(n)),
                                        total=n * n,
                                        leave=False)):
        [i]

# Generated at 2022-06-22 04:57:38.874533
# Unit test for function product
def test_product():
    from .tests import FakeTqdmFile, closing

    with closing(FakeTqdmFile(encoding="utf-8")) as f:
        for i in product(range(1000), tqdm_class=tqdm_auto, file=f):
            pass
        assert f.getvalue().startswith(" 1%|")

        for i in product(range(1000), tqdm_class=tqdm_auto, disable=True):
            pass

# Generated at 2022-06-22 04:57:44.235117
# Unit test for function product
def test_product():
    try:
        list(product(range(5)))
    except TypeError:  # python2
        pass
    else:
        raise Exception("Should raise TypeError: Need more than 1 value to unpack")
    r = list(product(range(5), range(5)))
    assert len(r) == 25
    r = list(product(range(5), range(5), range(5)))
    assert len(r) == 125
    assert r[0] == (0, 0, 0)
    assert r[-1] == (4, 4, 4)

# Generated at 2022-06-22 04:57:54.523686
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Check no change of behaviour
    assert Product(range(10), range(5), range(7)) == list(itertools.product(range(10), range(5), range(7)))
    # Check different behaviour
    from tqdm.contrib.tests.test_itertools import _check_eq_range, _check_neq_range
    _check_neq_range(Product(range(10), range(5), range(7)), None)
    _check_eq_range(Product(range(10), range(5), range(7)))
    _check_eq_range(Product(range(10), range(5), range(7)), total=10 * 5 * 7)

# Generated at 2022-06-22 04:57:58.059386
# Unit test for function product
def test_product():
    for i in product(range(100), range(100), range(100),
                     bar_format="{l_bar}{bar} [ time left: {remaining} ]",
                     leave=False):
        pass

# Generated at 2022-06-22 04:58:06.816038
# Unit test for function product
def test_product():
    """ Unit test for function product """
    # Prepare primes numbers
    def prime_numbers(N):
        """ A generator with the prime numbers up to N """
        primes = []
        num = 2
        while num < N:
            primes.append(num)
            num += 1
            for prime in primes:
                if num % prime == 0:
                    num += 1
                    break
            else:
                continue
            break

        for prime in primes:
            yield prime

    # Test product function
    from ..tqdm import product as tqdm_product
    for N in tqdm_product(range(3, 20), range(4, 20), range(5, 20)):
        assert N == (N[0], N[1], N[2])

    # Test product function with prime numbers

# Generated at 2022-06-22 04:58:19.112609
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import trange
    from .utils import FormatCustomText

    for t in [trange, FormatCustomText]:
        for tt in [t, lambda *a, **k: t(iterable=a, **k)]:
            test_list = ["abc", range(3), range(0, 100, 10)]
            test_list2 = list(range(len(test_list)))
            test_list3 = [list(range(i)) for i in test_list2]

            assert list(product(*test_list3)) == list(itertools.product(*test_list3))

# Generated at 2022-06-22 04:58:30.147144
# Unit test for function product
def test_product():
    import numpy as np
    assert np.array_equal(
        list(product(range(5), repeat=2)), list(itertools.product(range(5), repeat=2))
    )

    assert np.array_equal(
        list(product([1, 2, 3], range(5), repeat=2)),
        list(itertools.product([1, 2, 3], range(5), repeat=2))
    )

if __name__ == '__main__':
    from multiprocessing import Pool
    import numpy as np

    def fun(a):
        return np.sum(a)

    pool = Pool()

# Generated at 2022-06-22 04:58:35.171982
# Unit test for function product
def test_product():
    from ..tests.test_tqdm import with_progbar
    for args in [([0, 1],), ([0, 1], [2, 3]), ([0, 1], [2, 3], [4, 5, 6])]:
        with with_progbar((0,), (len(args),)) as r:
            _ = [i for i in product(*args, ascii=True, tqdm_class=r)]

# Generated at 2022-06-22 04:58:46.785535
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    import tests.test_tqdm
    import sys
    out = [None]
    with tests.test_tqdm.capture_out() as (_, test_out):
        def printer(x):
            out[0] = x
            sys.stdout.write(str(x))

        for _ in product(range(5), repeat=5, tqdm_class=tests.test_tqdm._test_tqdm,
                         desc="test-itertools-product", ascii=True, miniters=1,
                         postfix=lambda: "test-postfix%d" % out[0],
                         ncols=50, leave=False, printer=printer):
            pass

    out = test_out.get

# Generated at 2022-06-22 04:58:54.856807
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    from tqdm.auto import tqdm
    from tqdm._utils import _term_move_up
    from ._utils import FakeTqdmFile, StringIO

    for n in range(1, 6):
        with StringIO() as our_file, StringIO() as true_file:
            for _ in product(n, tqdm=tqdm, file=our_file):
                pass
            for _ in itertools.product(range(n), file=true_file):
                pass
            our_file.seek(0)
            true_file.seek(0)
            assert_equal(_term_move_up() + our_file.read(),
                         true_file.read())

    # test that tqdm_class gets passed to tqdm

# Generated at 2022-06-22 04:59:04.638254
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal

    A = [1, 2, 3]
    B = [4, 5, 6]

    it = product(A, B, tqdm_class=tqdm_auto)
    assert_equal(next(it), (1, 4))
    assert_equal(next(it), (1, 5))
    assert_equal(next(it), (1, 6))
    assert_equal(next(it), (2, 4))
    assert_equal(next(it), (2, 5))
    assert_equal(next(it), (2, 6))
    assert_equal(next(it), (3, 4))
    assert_equal(next(it), (3, 5))
    assert_equal(next(it), (3, 6))


# Generated at 2022-06-22 04:59:15.497820
# Unit test for function product
def test_product():
    ''' Test output of function product '''
    import numpy as np
    list_values = list(range(1, 4))
    product_value = list(product(list_values,
                                 list_values,
                                 list_values,
                                 list_values))
    assert np.array_equal(product_value, np.array(list(itertools.product(list_values,
                                                                         list_values,
                                                                         list_values,
                                                                         list_values))))

# Generated at 2022-06-22 04:59:22.276879
# Unit test for function product
def test_product():
    from .tests_tqdm import closing, with_progbar
    from .utils import TestCase

    class Test(TestCase):
        def test_product(self):
            for i in range(4):
                for j in product(*[range(i)] * 2):
                    pass
                self.assertEqual(i**2, j)
            for i in range(4):
                for j in product(*[range(i)] * 2, tqdm_class=tqdm_auto):
                    pass
                self.assertEqual(i**2, j)
            for i in range(2, 4):
                for j in product(*[range(i)] * 2,
                                tqdm_class=with_progbar(tqdm_auto)):
                    pass

# Generated at 2022-06-22 04:59:32.534140
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import sys
    import os
    import random

    # Check that product works
    assert tuple(product([],)) == (())
    assert tuple(product([1, 2, 3])) == ((1,), (2,), (3,))
    assert tuple(product([1, 2, 3], [4, 5, 6])) == (
        (1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6))

# Generated at 2022-06-22 04:59:44.233081
# Unit test for function product
def test_product():
    from random import randint
    from itertools import product
    from numpy import all as npall
    from numpy import array as nparray
    from pandas import DataFrame
    from pandas import read_csv
    from pandas import concat as pdconcat
    from ..utils import format_sizeof
    from ..utils import format_timesofar

    # Make two different test cases
    N = randint(3, 10)
    M = randint(3, 10)
    lists = [list(range(N)), list(range(M))]
    arrays = [nparray(range(N)), nparray(range(M))]
    df = DataFrame({"A": range(N), "B": range(M)})


# Generated at 2022-06-22 04:59:53.747733
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from unittest import TestCase, main

    class TestProduct(TestCase):
        """
        TestCase for product.
        """
        def test_equivalency(self):
            """
            Test that `product` is equivalent to `itertools.product`.
            """
            foo = range(5)
            bar = range(5)
            self.assertEqual(list(product(foo, bar)),
                             list(itertools.product(foo, bar)))

    main()

# Generated at 2022-06-22 05:00:03.769265
# Unit test for function product
def test_product():
    # Test that product generates the expected output
    for n, x in enumerate(product('ABC', '12')):
        assert(x == ('A', '1'))
        break
    assert(n == 0)
    for n, x in enumerate(product('ABC', '123')):
        assert(x == ('A', '1'))
        break
    assert(n == 0)
    try:
        x = list(product('ABC', '12'))
    except:
        raise AssertionError("Error raised when generating list")
    assert(len(x) == 6)
    try:
        x = list(product('ABC', '123'))
    except:
        raise AssertionError("Error raised when generating list")
    assert(len(x) == 9)

# Generated at 2022-06-22 05:00:08.820907
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    list_ = list(product(range(100), range(100), range(100)))
    assert list_ == list(itertools.product(range(100), range(100), range(100)))

# Generated at 2022-06-22 05:00:17.567885
# Unit test for function product
def test_product():
    from random import randint
    from itertools import product as itertools_product
    from numpy import allclose

    # Test single iterator
    a = [randint(0, 100) for i in range(10)]
    for i in product(a):
        assert i in a

    # Test multiple iterators
    for t in range(10):
        a = [randint(0, 100) for i in range(10)]
        b = [randint(0, 100) for i in range(10)]
        c = [randint(0, 100) for i in range(10)]

        # Test random iterables
        t1 = [i for i in product(a, b, c)]
        t2 = [(i, j, k) for i in a for j in b for k in c]

# Generated at 2022-06-22 05:00:20.831884
# Unit test for function product
def test_product():
    """Test the `product` function."""
    assert list(product(range(3), repeat=2)) == list(itertools.product(range(3), repeat=2))

# Generated at 2022-06-22 05:00:26.804253
# Unit test for function product
def test_product():
    """Test function product"""
    # pylint: disable=protected-access
    from .._tqdm import tqdm
    r = list(tqdm(product(range(10), ['a', 'b', 'c'], tqdm_class=tqdm),
                 total=10*3))
    assert r == list(itertools.product(range(10), ['a', 'b', 'c']))
    r = list(tqdm(product(range(10)), total=10))
    assert r == list(itertools.product(range(10)))

# Generated at 2022-06-22 05:00:39.354997
# Unit test for function product
def test_product():
    import numpy as np

    for i in product(range(3), range(3), range(3), range(3), range(3)):
        pass
    for i in product(range(3), range(3), range(3), range(3), range(3),
                     tqdm_class=tqdm_auto.tqdm_notebook):
        pass

    for i in product(np.arange(3), np.arange(3), np.arange(3), np.arange(3),
                     np.arange(3)):
        pass

# Generated at 2022-06-22 05:00:42.604375
# Unit test for function product
def test_product():
    from .lolesen import lolesen
    p = list(product(range(1000), range(1000), range(1000)))
    lolesen(p)
    lolesen(product(range(1000), range(1000), range(1000)))

# Generated at 2022-06-22 05:00:49.947049
# Unit test for function product
def test_product():
    it = product(range(3), ['a', 'b'], tqdm_class=tqdm_auto, total=12)
    assert list(it) == [(0, 'a'), (0, 'b'),
                        (1, 'a'), (1, 'b'),
                        (2, 'a'), (2, 'b')]

# Generated at 2022-06-22 05:00:51.344162
# Unit test for function product
def test_product():
    from . import _test_it
    return _test_it(product)

# Generated at 2022-06-22 05:01:01.550906
# Unit test for function product
def test_product():
    """Tests for `product`"""
    import random
    import copy
    import sys

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    random.seed(27)

    # Create list
    sizes = [random.randint(100, 100000) for _ in range(10)]
    in_list = [list(range(i)) for i in sizes]
    out_list = list(itertools.product(*in_list))

    # test product
    out_list2 = list(product(*in_list, leave=False, smoothing=1))
    assert out_list == out_list2

    # test product with same iterable but with different **kwargs
    out_list3 = list(product(*in_list, leave=True, smoothing=1))

# Generated at 2022-06-22 05:01:10.196531
# Unit test for function product
def test_product():
    from itertools import product
    for d in [{}, {"tqdm_class": tqdm_auto}]:
        # Test `lazy` (`total=None`)
        assert list(product(range(10), range(20), range(30))) == \
            list(product(range(10), range(20), range(30), **d))
        # Test `total`
        assert list(product(range(10), repeat=5)) == \
            list(product(range(10), repeat=5, **d))

# Generated at 2022-06-22 05:01:16.737137
# Unit test for function product
def test_product():
    for i in product(*[range(3) for _ in range(4)]):
        pass
    for i in product([range(3), None, None, range(4), range(2)],
                     tqdm_class=tqdm_auto,
                     desc="testing product: "):
        pass
    for i in product([range(3), None, None, range(4), range(2)],
                     tqdm_class=tqdm_auto,
                     leave=True,
                     desc="testing product(leave=True): "):
        pass
    assert True

# Generated at 2022-06-22 05:01:24.894649
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from ._tqdm_test_cls import TqdmDefaultWriteBytesIO, TqdmDefaultWriteBytes
    from ._utils import _range
    for tqdm_cls in [TqdmDefaultWriteBytesIO, TqdmDefaultWriteBytes]:
        assert ([x for x in product(_range(3), [b'', b'x'],
                                    tqdm_class=tqdm_cls)] ==
                [(i, s) for i in _range(3) for s in [b'', b'x']])

# Generated at 2022-06-22 05:01:35.583276
# Unit test for function product
def test_product():
    """ Unit tests for product() """
    from pytest import raises
    from numpy.testing import assert_allclose

    def n_th_permutation(n, it):
        """ Return the n-th element of itertools.permutations(range(it)) """
        if n < 0:
            raise ValueError("n must be >= 0")
        ret = []
        for i in reversed(range(1, it + 1)):
            div, mod = divmod(n, i)
            n = div
            ret.append(mod)
        return list(reversed(ret))

    for i in range(10):
        for j in range(10):
            for k in range(10):
                a = range(i)
                b = range(j)
                c = range(k)

                # itertools.product

# Generated at 2022-06-22 05:01:46.026724
# Unit test for function product
def test_product():
    """Test function `product`."""
    import numpy as np
    import math
    with tqdm_auto(total=0) as t:
        assert list(product(t)) == []
        assert list(product(t, [1, 2, 3])) == []
        assert list(product(t, [1, 2, 3], [4, 5])) == []
        assert list(product(t, ["test1", "test2", "test3"], [1, 2])) == []
    with tqdm_auto(total=6) as t:
        assert list(product(t, [1, 2, 3])) == [(1,), (2,), (3,)]

# Generated at 2022-06-22 05:02:02.029032
# Unit test for function product
def test_product():
    for t in product([2, 3, 5], [1, 2]):
        pass
    for t in product([2, 3, 5], [1, 2], tqdm_class=tqdm_auto.tqdm_gui):
        pass
    assert t == (5, 2)
    for t in product("abc", repeat=2):
        pass
    assert t == ('c', 'c')
    for t in product("abc", "de", repeat=2, tqdm_class=tqdm_auto.tqdm_notebook):
        pass
    assert t == ('c', 'e')
    assert list(product("ab", [1, 2, 3])) == [
        ('a', 1), ('a', 2), ('a', 3), ('b', 1), ('b', 2), ('b', 3)]
   

# Generated at 2022-06-22 05:02:08.684116
# Unit test for function product
def test_product():
    import numpy as np
    n = itertools.product([0,1,2], [3,4,5], [6,7,8])
    k = product([0,1,2], [3,4,5], [6,7,8])
    def pbar(i):
        return k.send(i)
    assert (np.array(list(pbar(0))) == np.array(list(n))).all()

# Generated at 2022-06-22 05:02:17.269730
# Unit test for function product
def test_product():
    """Test for tqdm_itertools.product"""
    assert list(product(0, 1)) == []
    assert list(product([], 0)) == []
    assert list(product([[]], 0)) == []
    assert list(product([[], []], 0)) == []
    assert list(product([[], []], 1)) == []
    assert list(product([[], []], 2)) == []
    assert list(product([[], [], []], 0)) == []
    assert list(product([[], [], []], 1)) == []
    assert list(product([[], [], []], 2)) == []
    assert list(product([1], 0)) == []
    assert list(product([1], 1)) == [[1]]
    assert list(product([1], 2)) == [[1, 1]]

# Generated at 2022-06-22 05:02:27.468592
# Unit test for function product
def test_product():
    import sys
    assert list(product(range(1, 3), range(2), tqdm_class=tqdm_auto,
                        file=sys.stderr)) == list(itertools.product(
                            range(1, 3), range(2)))
    assert list(product(range(5), range(5), tqdm_class=tqdm_auto,
                        file=sys.stderr)) == list(itertools.product(
                            range(5), range(5)))

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:02:34.457115
# Unit test for function product
def test_product():
    from random import randint, shuffle
    from itertools import repeat, product

    for max_size in range(1, 6, 2):
        for _ in range(100):
            a = [randint(1, 10) for _ in range(randint(1, max_size))]
            b = [randint(-10, -1) for _ in range(randint(1, max_size))]
            shuffle(a)
            shuffle(b)
            old, new = [], []
            with tqdm_auto(
                    itertools.chain(a, b),
                    unit_scale=True,
                    leave=False,
                    miniters=1) as t:
                for i, j in zip(t, product(a, b)):
                    assert (i == j)
                    old.append(i)


# Generated at 2022-06-22 05:02:43.720305
# Unit test for function product
def test_product():
    """
    Test that `tqdm.itertools.product`

    - returns the same as `itertools.product`
    - has the same performance as `itertools.product`
    """
    import time

    # check output
    assert list(product([1, 2, 3], repeat=2)) == list(itertools.product([1, 2, 3], repeat=2))

    # check performance
    t0 = time.time()
    for _ in product(range(10**7)):
        pass
    t1 = time.time()
    for _ in itertools.product(range(10**7)):
        pass
    t2 = time.time()
    # print "product     :\t{}s".format(t1 - t0)
    # print "itertools.product:\t{

# Generated at 2022-06-22 05:02:48.204499
# Unit test for function product
def test_product():
    """Unit test"""
    import numpy as np

    def assert_equal(x, y):
        assert (x == y).all()

    assert_equal(
        list(product(range(2), repeat=2)),
        list(itertools.product(range(2), repeat=2)))
    assert_equal(
        list(product(range(2), repeat=2, tqdm_class=tqdm_auto)),
        list(itertools.product(range(2), repeat=2)))
    assert_equal(
        np.array(list(product(range(2), repeat=4, tqdm_class=tqdm_auto))),
        np.array(list(itertools.product(range(2), repeat=4))))
    import sys

# Generated at 2022-06-22 05:02:57.796388
# Unit test for function product

# Generated at 2022-06-22 05:03:07.604187
# Unit test for function product
def test_product():
    """Test the product function"""
    with tqdm_auto(total=None) as t:
        assert sum(1 for _ in product(range(3), repeat=2, tqdm_class=t.__class__)) == 9
        t.total = 3 ** 3
        assert sum(1 for _ in product(range(3), repeat=3, tqdm_class=t.__class__)) == 27
        t.total = 3 ** 4
        assert sum(1 for _ in product(range(3), repeat=4, tqdm_class=t.__class__)) == 81
    with tqdm_auto(total=None) as t:
        assert sum(1 for _ in product(range(3), range(2), tqdm_class=t.__class__)) == 6

# Generated at 2022-06-22 05:03:11.000020
# Unit test for function product
def test_product():
    """Unit test for product"""
    import numpy as np
    assert (list(product(range(10), range(10)))
            == list(np.array(np.meshgrid(range(10),
                                         range(10))).T.reshape(-1, 2)))

# Generated at 2022-06-22 05:03:30.933929
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from .core import EmptyTqdmFile
    from .utils import format_sizeof
    from .cli import set_term_title
    from .._utils import _environ_cols_wrapper

    # Check basic functionality and correct sizing
    with tqdm(total=14) as t:
        for i in product(range(7), range(2)):
            t.update()
    assert t.n == 14

    # Check total=None functionality
    with tqdm(total=None) as t:
        for i in product(range(7), range(2)):
            t.update()
    assert t.total is not None

    # Check fast exit (raise StopIteration)

# Generated at 2022-06-22 05:03:42.971599
# Unit test for function product
def test_product():
    from random import shuffle
    from .tests_tqdm import phase_test
    import ast

    phase_test(2, 3, phase=[0, 1, 2, 3], phase_sizes=[16, 64, 256])

    phase_test(
        2, 3, phase=[0, 1, 2, 3], phase_sizes=[16, 64, 256],
        total=lambda x: 2**x,
        bar_format=lambda x: x)

    phase_test(
        2, 3, phase=[0, 1, 2, 3], phase_sizes=[16, 64, 256],
        total=lambda x: 2**x,
        file=None,
        bar_format=lambda x: ast.literal_eval(x))

# Generated at 2022-06-22 05:03:53.381761
# Unit test for function product
def test_product():
    def product_gen(n):
        for i in itertools.product(range(n), repeat=n):
            yield i

    def test_range(n, total=None, **kwargs):
        kwargs["total"] = total
        p = product(range(n), repeat=n, **kwargs)
        # n**n != n!
        assert len(list(p)) == n ** n
        p = product_gen(n)
        # n**n != n!
        assert len(tuple(p)) == n ** n

# Generated at 2022-06-22 05:03:58.632119
# Unit test for function product
def test_product():
    """
    Basic unit test for function product
    """
    assert list(product([1, 2, 3], ['a', 'b'])) == [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]

# Generated at 2022-06-22 05:04:07.705852
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from .._tqdm_gui import tqdm
    from ..std import time

    # static bars
    with tqdm(
            product(range(3), range(2), range(4)),
            desc="test1",
            ascii=True,
            file=None) as t:
        for _ in t:
            time.sleep(0.1)
    # dynamic bars
    with tqdm(
            product(range(3), range(2), range(4)),
            desc="test2",
            dynamic_ncols=True,
            ascii=True,
            file=None) as t:
        for _ in t:
            time.sleep(0.1)

# Generated at 2022-06-22 05:04:17.816126
# Unit test for function product
def test_product():
    for a, b in tqdm_auto(product('abc', [1, 2, 3], repeat=1),
                          total=3*3,
                          ) + tqdm_auto(product('abc', [1, 2, 3], repeat=2),
                                       total=3*3*3*3,
                                       miniters=1,
                                       ):
        pass

# Generated at 2022-06-22 05:04:24.666781
# Unit test for function product
def test_product():
    """Smoke test for function product"""
    from shutil import get_terminal_size as get_terminal_size
    from .utils import FormatCustomText

    # The following should work regardless of optional external packages
    it = product(list(range(10)), list(range(20)), list(range(15)))
    assert hasattr(it, '__iter__') and len(list(it)) == 10*20*15

    # The following should work regardless of optional external packages
    it = product(list(range(1000)), list(range(2000)), list(range(1500)))
    assert hasattr(it, '__iter__') and sum(it) == 999000*999

    # The following should work regardless of optional external packages
    it = iter(product(list(range(1000)), list(range(2000)), list(range(1500))))

# Generated at 2022-06-22 05:04:32.685143
# Unit test for function product
def test_product():
    for p in product((0, 1), repeat=5):
        assert len(p) == 5
        assert isinstance(p[0], int)
        assert 0 <= p[0] <= 1
        assert all(n == 0 or n == 1 for n in p)

    for p in product((0, 1), repeat=5, tqdm_class=lambda i: i):
        pass

    try:
        for p in product(('a', 'b'), repeat=5, tqdm_class=tqdm_auto):
            pass
    finally:
        import warnings
        warnings.resetwarnings()
        warnings.simplefilter('always')

# Generated at 2022-06-22 05:04:43.818665
# Unit test for function product
def test_product():
    from .core import tqdm_deprecated_class
    # init
    tqdm_deprecated_class.close = False
    tqdm_deprecated_class.is_eof = False
    tqdm_deprecated_class.is_py2 = (2, 7, 5) < __import__('sys').version_info[:3] < (2, 7, 9)
    tqdm_deprecated_class.is_pypy = '__pypy__' in __import__('sys').builtin_module_names
    tqdm_deprecated_class.file = __import__('sys').stdout
    # execute

# Generated at 2022-06-22 05:04:54.030152
# Unit test for function product
def test_product():
    """ eg: "test_tqdm_product.test_product() """
    from .tests import pretest_posttest

# Generated at 2022-06-22 05:05:21.264789
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    # Test for different input types
    for data in (range(2), list(range(2)),
                 itertools.chain(range(2)),
                 (i for i in range(2))):
        assert list(product(data)) == [(0,), (1,)]
        assert list(product(data, data)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
        n = 0
        for _ in product(data, data, data):
            n += 1
        with FormatWrapBase(tqdm_class=tqdm_auto) as t:
            assert n == t.total



# Generated at 2022-06-22 05:05:30.010140
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    assert len(list(product([1, 2], ['a', 'b']))) == 4
    assert len(list(product([1, 2], repeat=2))) == 4
    assert len(list(product('abcd', [1, 2]))) == 8
    assert len(list(product([2], 'abcd'))) == 8
    assert len(list(product(range(3), 'abcd'))) == 12
    assert len(list(product([1, 2], ["a", "b", "c"]))) == 6

# Generated at 2022-06-22 05:05:41.662989
# Unit test for function product
def test_product():

    result = list(product(range(1, 5), [10, 20, 30], ['a', 'b']))

# Generated at 2022-06-22 05:05:52.009826
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests_helper import SmartFormatter
    from ._tqdm_gui import tqdm as tqdm_gui

    try:
        range_ = xrange
    except NameError:
        range_ = range

    for tqdm in (tqdm_auto, tqdm_gui):  # , tqdm_notebook, tqdm_nbagg):
        for kwargs in ({}, {"desc": "DESC"}):
            for i in (1, 10**6):
                for desc in ["range(i)", "xrange(i)"]:
                    a = list(range_(i))
                    prod = list(product(a, a, tqdm_class=tqdm, **kwargs))

# Generated at 2022-06-22 05:06:03.232246
# Unit test for function product
def test_product():
    from .tests_helpers import closing, FakeTqdmFile, StringIO, _range

    # Test regular case
    with closing(StringIO()) as our_file:
        kwargs = {"file": our_file, "tqdm_class": tqdm_auto}
        assert list(product(*[["a", "b"], ["c", "d"]], **kwargs)) == \
            [("a", "c"), ("a", "d"), ("b", "c"), ("b", "d")]
        our_file.seek(0)
        assert our_file.read().rstrip() == "4it [00:00, ?it/s]"

    # Test return early `total=None`

# Generated at 2022-06-22 05:06:10.034923
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..tqdm import tnrange
    import sys
    import mock

    # Monkey patch stdout to file to avoid printing
    stdout = sys.stdout
    with mock.patch('sys.stdout', open(os.devnull, 'w')):
        for _ in tnrange(10):
            for i in product(range(5), range(5), range(5)):
                assert (i == itertools.product(range(5), range(5), range(5))
                        .next())

# Generated at 2022-06-22 05:06:15.103598
# Unit test for function product
def test_product():
    """Test for function product"""
    import times
    import math

    output = []
    for i in product(range(100), tqdm_class=None, total=100**2):
        output.append(i)
    assert output == list(itertools.product(range(100), range(100)))

    output = []
    for i in product(range(100), tqdm_class=None):
        output.append(i)
    assert output == list(itertools.product(range(100), range(100)))

    output = []
    for i in product(range(100), repeat=3, tqdm_class=None):
        output.append(i)
    assert output == list(itertools.product(range(100), repeat=3))

    # Disable tqdm bar and set sleep to 0 for fast