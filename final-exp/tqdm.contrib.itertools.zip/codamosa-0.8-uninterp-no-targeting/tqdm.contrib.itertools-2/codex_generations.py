

# Generated at 2022-06-22 04:56:19.281434
# Unit test for function product
def test_product():
    """Test function product."""
    from ..tqdm_gui import tqdm

    assert not len(list(product(range(10), repeat=2, tqdm_class=tqdm)))

    assert not len(list(product(range(10), repeat=2, tqdm_class=tqdm,
                                leave=False)))

    assert not len(list(product(range(10), repeat=2, tqdm_class=tqdm,
                                leave=True)))

    assert not len(list(product(range(10), repeat=2, tqdm_class=tqdm,
                                smoothing=1)))

    assert not len(list(product(range(10), repeat=2, tqdm_class=tqdm,
                                smoothing=1e-5)))


# Generated at 2022-06-22 04:56:29.504952
# Unit test for function product
def test_product():
    import sys
    import numpy
    from ..numpy import trange

    list_ = list(range(100))
    it = product(list_, list_)
    assert list(it) == list(itertools.product(list_, list_))

    value = 0
    for _ in product([1, 2, 3], ["a", "b"]):
        value += 1
    assert value == 6

    def _test_tqdm(tqdm_cls, total=15):
        """
        Sanity check for tqdm(itertools.product),
        check that writing to stderr works correctly.
        """
        try:
            from cStringIO import StringIO
        except:
            from io import StringIO
        orig = sys.stderr

# Generated at 2022-06-22 04:56:39.893871
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import _range
    from ..utils import _progbar
    from .tests_tqdm import pretest_posttest

    iterables = [list(_range(1, 10, 0.2)),
                 list(_range(10, 20, 1)),
                 list(_range(1, 5, 0.3))]
    total = 1
    for i in map(len, iterables):
        total *= i
    iterables.append(list(_range(0, 12, 0.3)))
    g = product(*iterables, tqdm_class=FormatCustomText(**dict(
        desc="product",
        bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]")))

# Generated at 2022-06-22 04:56:51.446045
# Unit test for function product
def test_product():
    """Test function product"""
    # pylint: disable=unused-variable
    from hypothesis import given
    from hypothesis.strategies import lists, integers, dictionaries
    import operator

    # product
    @given(lists(integers()), dictionaries(integers(), integers()))
    def test_product_hypothesis(ls, kwargs):
        """Test function product"""
        def prod(xs):
            """Product"""
            return reduce(operator.mul, xs, 1)
        tqdmed = list(product(*ls, **kwargs))
        iterd = itertools.product(*ls)
        assert list(tqdmed) == list(iterd)
        if len(ls) > 0:
            assert len(tqdmed) == prod(map(len, ls))

# Generated at 2022-06-22 04:57:01.616519
# Unit test for function product
def test_product():
    """Test function product"""
    import numpy as np
    from ..utils import SimpleNamespace as ns
    from ..auto import tqdm_gui, trange

    for tqdm in (tqdm_gui, trange):
        for chunksize in (None, 2):
            with tqdm(
                    total=0, disable=None, smoothing=1.,
                    bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} ') as t:
                np.testing.assert_equal(list(product(
                    range(5), chunksize=chunksize, tqdm_class=tqdm)),
                    list(itertools.product(range(5))))
                t.update()
            np.testing.assert_equal(t.n, 25)

# Generated at 2022-06-22 04:57:14.008061
# Unit test for function product
def test_product():
    """
    Unit test for function product()
    """
    from .utils import format_sizeof
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     unit_scale=True, unit="B"):
        if i[0] == i[1]:
            break
    from sys import getrefcount
    assert getrefcount(i) == 2
    i = product(range(100), range(100), range(100),
                tqdm_class=tqdm_auto,
                unit_scale=True, unit="B")
    assert getrefcount(i) == 2
    del i

# Generated at 2022-06-22 04:57:21.258996
# Unit test for function product
def test_product():
    # Test function product
    # TODO: do it smarter...
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]
    assert list(product([1, 2, 3], repeat=2)) == [(1, 1), (1, 2), (1, 3),
                                                  (2, 1), (2, 2), (2, 3),
                                                  (3, 1), (3, 2), (3, 3)]

# Generated at 2022-06-22 04:57:24.901618
# Unit test for function product
def test_product():
    for p in product(["a", "b"], ["c", "d"]):
        assert p == ("a", "c") or p == ("a", "d") or p == ("b", "c") or p == ("b", "d")

# Generated at 2022-06-22 04:57:36.418860
# Unit test for function product
def test_product():
    from ._deprecate import _deprecate_redirect_nx_itertools

    with _deprecate_redirect_nx_itertools() as redirected:
        import numpy as np
        import numpy.testing as npt

        data1 = [1, 1, 1]
        data2 = [0, 0, 0]

        res1 = list(product(data1, data2))
        npt.assert_array_equal(res1, [(1, 0), (1, 0), (1, 0)])

        res2 = list(product(*[data1, data2]))
        npt.assert_array_equal(res2, [(1, 0), (1, 0), (1, 0)])

        res3 = list(product(data1, data2, repeat=2))

# Generated at 2022-06-22 04:57:41.807072
# Unit test for function product
def test_product():
    from .test_tqdm import with_setup, FakeTqdmType, closing, string_types

    @with_setup(pretest=closing)
    def test():
        for tqdm_cls in [tqdm_auto, FakeTqdmType]:
            for p in product('ABCD', 'xy', tqdm_class=tqdm_cls):
                pass

    test()

# Generated at 2022-06-22 04:57:50.140232
# Unit test for function product
def test_product():
    tqdm_kwargs = {"tqdm_class": tqdm_auto}
    iter_prod_gen = product(range(5), range(5), range(5), range(5), tqdm_kwargs=tqdm_kwargs)
    assert next(iter_prod_gen) == (0, 0, 0, 0)


# Generated at 2022-06-22 04:57:57.207417
# Unit test for function product
def test_product():
    iterables = [range(5), range(9), range(5)]
    tn = 0
    # Cumulative size of iterables
    L = [len(i) for i in iterables]
    total_size = 1
    for i in L:
        total_size *= i
    for i in product(*iterables):
        tn += 1
    assert tn == total_size

# Generated at 2022-06-22 04:58:06.487459
# Unit test for function product
def test_product():
    """Test function product"""
    import numpy

    max_int = 3
    it1 = numpy.arange(max_int)
    it2 = numpy.arange(max_int)
    it3 = numpy.arange(max_int)

    prod = list(product(it1, it2, it3))
    assert prod == [(i, j, k) for i in range(max_int) for j in range(max_int) for k in range(max_int)]
    prod = list(product(it1, it2, it3, tqdm_class=tqdm_auto))
    assert prod == [(i, j, k) for i in range(max_int) for j in range(max_int) for k in range(max_int)]

    # testing nested lazy iterables

# Generated at 2022-06-22 04:58:13.439986
# Unit test for function product
def test_product():
    """
    Test product in comparison with base `itertools` module

    Returns
    -------
    out : bool
        True if test passes
    """
    from ._version import __version__
    iterables = [
        range(10),
        range(10),
        range(10)
    ]

    original = list(itertools.product(*iterables))
    wrapped = list(product(*iterables))

    assert(original == wrapped)
    return True



# Generated at 2022-06-22 04:58:15.801149
# Unit test for function product
def test_product():
    from .utils import _range

    for x in product(_range(4), _range(4), _range(4)):
        pass  # loop for coverage

# Generated at 2022-06-22 04:58:21.263487
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product([5, 6, 7], [1, 2])) == [(5, 1),
                                                (5, 2),
                                                (6, 1),
                                                (6, 2),
                                                (7, 1),
                                                (7, 2)]

# Generated at 2022-06-22 04:58:32.102130
# Unit test for function product
def test_product():
    from numpy import prod
    import copy
    import random

    from .tqdm import trange
    from .std import time
    from .utils import FormatCustomText

    def _product(*args, **kwargs):
        """
        Lightweight function to test the effectivity of the product function
        """
        kwargs = copy.copy(kwargs)
        try:
            kwargs.pop('total')
        except KeyError:
            pass
        kwargs.pop('tqdm_class', None)
        return list(product(*args, **kwargs))

    def _generate_product_test(ncols_max=None, nrows_max=None):
        """
        Generate a random valid input to test product function
        """
        if ncols_max is None:
            ncols_max

# Generated at 2022-06-22 04:58:33.364777
# Unit test for function product
def test_product():
    list(product(range(2), range(3), range(4)))

# Generated at 2022-06-22 04:58:37.162247
# Unit test for function product
def test_product():
    iterables = [range(10), range(10), range(10)]
    p = product(*iterables)
    for i in p:
        pass

# Generated at 2022-06-22 04:58:48.113100
# Unit test for function product
def test_product():
    from .tests import pretest_posttest_capture
    from .tests import closing_disabled
    from .tests import _range

    def test():
        return [x for x in product(_range(10), repeat=2, tqdm_class=tqdm_auto)]


# Generated at 2022-06-22 04:59:02.398327
# Unit test for function product
def test_product():
    """Unit tests for function product"""
    from ._utils import _test_iterator

    def _test_product(iter_, exp):
        """Test helper"""
        _test_iterator(product, iter_, exp)

    _test_product((), [()])
    _test_product((2, 3), [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2)])

# Generated at 2022-06-22 04:59:10.474162
# Unit test for function product

# Generated at 2022-06-22 04:59:15.784476
# Unit test for function product
def test_product():
    """Run `itertools.product` tests"""
    from ..tests.itertools_tests import TestProduct
    from ..tests.utils import report as report_test
    report_test(TestProduct, "product()", tqdm_func=product)


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-22 04:59:21.517317
# Unit test for function product
def test_product():
    import random
    rng = random.Random(42)
    n = rng.randint(10, 30)
    from .utils import FormatWrapBase
    for tqdm_cls in [FormatWrapBase] + tqdm_auto.tqdm._instances:
        tqdm_cls.close()
    for tqdm_cls in tqdm_auto.tqdm._instances:
        tqdm_cls.close()
    for i in product(range(n)):
        pass
    for i in product(range(n), tqdm_class=tqdm_auto.tqdm):
        pass

# Generated at 2022-06-22 04:59:24.842506
# Unit test for function product
def test_product():
    # poor man's test
    with tqdm_auto(total=24) as t:
        for i in product(range(4), range(6), tqdm_class=tqdm_auto):
            t.update()

# Generated at 2022-06-22 04:59:36.412324
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    p = list(product(range(4), repeat=3))

# Generated at 2022-06-22 04:59:46.347392
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import tqdm
    assert (sum(1 for _ in product(range(10), range(10), range(10))) ==
            1000)
    try:
        iter(product(xrange(10), xrange(10), xrange(10)))
    except AttributeError:
        pass
    else:
        raise ValueError("product(xrange(...)) should not be iterable")
    # test `total` behaviour
    pbar = tqdm(product(range(10), range(10), range(10)))
    expected = []
    for i in pbar:
        expected.append(i)
    assert list(product(range(10), range(10), range(10))) == expected



# Generated at 2022-06-22 04:59:50.771020
# Unit test for function product
def test_product():
    ''' Test on product '''
    import sys

    sys.stderr.write(str(list(product(["a", "b", "c"], [1, 2, 3],
                           tqdm_class=tqdm_auto, ascii=True,
                           desc="product test"))))

# Generated at 2022-06-22 04:59:53.989082
# Unit test for function product
def test_product():
    """ Unit test for function product """
    include = [1, 2]
    exclude = [3]
    assert list(product(include, exclude)) == [(1, 3), (2, 3)]

# Generated at 2022-06-22 05:00:03.930409
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from ..tests._deprecated import _TEST_DEPRECATED_ERROR
    import numpy as np
    for tqdm in [tqdm_auto]:
        iterable1 = np.arange(5)
        iterable2 = np.arange(2, 6)
        p = itertools.product(iterable1, iterable2)
        assert len(list(product(iterable1, iterable2, tqdm_class=tqdm))) == \
            len(p)
        for i in (1, 2):
            assert len(list(product(iterable1, iterable2, tqdm_class=tqdm,
                                    miniters=None))) == len(p)

# Generated at 2022-06-22 05:00:16.582523
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal

    for iterable in [
            range(0, 3), [1, 2, 3], dict(a=1, b=2), ('a', 'b', 'c')]:
        # Test accuracy
        assert_array_equal(
            list(itertools.product([iterable])),
            list(product([iterable])))
        assert_array_equal(
            list(itertools.product([iterable])),
            list(product([iterable])))
        # Test total argument
        assert len(list(product([iterable], total=1))) == 1
        assert len(list(product([iterable], total=-1))) == len(iterable)

# Generated at 2022-06-22 05:00:24.022531
# Unit test for function product
def test_product():
    """Test that itertools.product wrapped by `tqdm.itertools.product` yields
    the same elements in the same order
    """
    from itertools import product as itertools_product
    assert list(product(range(3), range(3), range(3))) == list(itertools_product(
        range(3), range(3), range(3)))
    assert list(product(range(8), range(2))) == list(itertools_product(
        range(8), range(2)))

# Generated at 2022-06-22 05:00:31.826428
# Unit test for function product
def test_product():
    from .autonotebook import tqdm_notebook_failsafe
    from .tests_tqdm import pretest_posttest

    pretest_posttest(product,
                     lambda: (([1, 2, 3], [2, 3])),
                     ncols=60,
                     n_iterations=6,
                     total=6,
                     tqdm_class=tqdm_notebook_failsafe)
    pretest_posttest(product,
                     lambda: (([1, 2, 3], [2, 3])),
                     ncols=60,
                     n_iterations=6,
                     total=6,
                     tqdm_class=tqdm_notebook_failsafe)

# Generated at 2022-06-22 05:00:43.217186
# Unit test for function product
def test_product():
    """
    Example of `product(...)` for reference.
    """
    import sys

    # unpack args if required
    if len(sys.argv) > 1:
        (rng, tqdm_class) = map(eval, sys.argv[1:])
    else:
        (rng, tqdm_class) = range(7), tqdm_auto

    from ..main import tqdm
    list(tqdm(product(rng, repeat=3)))
    for i, (a, b, c) in tqdm(list(enumerate(product(rng, repeat=3))),
                             desc='1st loop', leave=False):
        for _ in tqdm(range(99), desc='2nd loop', leave=False):
            pass

# Generated at 2022-06-22 05:00:53.798682
# Unit test for function product
def test_product():
    import os
    import sys
    import time
    import types

    DUMMY_ITER = list(range(1000))
    for tqdm_class in [tqdm_auto, tqdm_auto.tqdm, types.GeneratorType]:
        it = product(DUMMY_ITER, [i * 2 for i in DUMMY_ITER],
                     tqdm_class=tqdm_class)
        t = it.__self__  # for tqdm.auto.tqdm
        for _ in it:
            pass
        assert t.n == t.total

# Generated at 2022-06-22 05:01:01.039630
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy import prod
    import random
    tot = lambda its: prod([len(it) for it in its])
    for i in [1, 2, 3, 4, 10]:
        it = [range(random.randint(1, 10)) for _ in range(i)]
        assert sum(1 for _ in product(*it)) == tot(it)
    with tqdm_auto(total=tot([range(10)])) as pbar:
        assert list(product(range(10))) == list(zip(range(10)))
    assert list(product(range(2), repeat=2)) == list(zip(range(2), range(2)))

# Generated at 2022-06-22 05:01:13.499316
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import SimpleNamespace

    def eq(a, b):
        return a == b

    args1 = iter(range(5))
    args2 = iter(range(5, 10))
    expected = ((0, 5), (0, 6), (0, 7), (0, 8), (0, 9),
                (1, 5), (1, 6), (1, 7), (1, 8), (1, 9),
                (2, 5), (2, 6), (2, 7), (2, 8), (2, 9),
                (3, 5), (3, 6), (3, 7), (3, 8), (3, 9),
                (4, 5), (4, 6), (4, 7), (4, 8), (4, 9))

# Generated at 2022-06-22 05:01:25.242025
# Unit test for function product
def test_product():
    """Unit tests for function `product`"""
    import numpy as np
    from ..utils import format_sizeof
    float_size = format_sizeof(np.float32(0))
    list_size = format_sizeof([])
    total = 0
    for _ in product(range(1000), repeat=2):
        total += 1
    assert (total == 1000000), 'product function failed!'
    with tqdm_auto(range(3), unit_scale=True, unit_divisor=1000) as t:
        for _ in product(range(1000), repeat=2):
            total += 1
            t.update()
    assert (t.unit == float_size + 'B'), 'Unit auto-discovery failed!'

# Generated at 2022-06-22 05:01:35.857565
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import format_sizeof
    for i in product(range(5), range(10), range(2), range(1, 3), tqdm_class=tqdm_auto, desc="test_product", ncols=80):
        pass
    p = product(range(100), range(100), range(100), range(100), range(100), range(100),
                range(100), range(100), range(100), range(100),
                range(100), range(100), range(100), range(100), range(100),
                range(100), range(100), range(100), range(100), range(100),
                tqdm_class=tqdm_auto, ascii=True,
                desc="test_product", ncols=80)

# Generated at 2022-06-22 05:01:46.251691
# Unit test for function product
def test_product():
    """Test product"""
    from ..std import NextIteration

    def _product(*args, **kwargs):
        for _ in product(*args, **kwargs):
            pass
        return _return_value

    for _return_value in [NextIteration, "foo", 42]:
        _ = _product()
        _ = _product([], [])
        _ = _product([1], [2])
        _ = _product([1], [2], total=None)
        _ = _product([1], [2], total=42)

        # Test non-integer total
        try:
            _ = _product([1], [2], total=42.0)
        except AssertionError:
            pass
        else:
            raise AssertionError('TypeError did not raised')

        # Test non-iterable args

# Generated at 2022-06-22 05:02:02.766097
# Unit test for function product
def test_product():
    """
    Test for function `product`:
    """
    def prod(a, b):
        return [[i, j] for i in a for j in b]
    from ..std import mock_filesystem as mockfs
    with mockfs.mock_filesystem() as fs:
        for a, b in zip(product('asdf', 'qwerty'),
                        prod('asdf', 'qwerty')):
            assert a == b
        for a, b in zip(product('asdf', 'qwerty', tqdm_class=tqdm_auto),
                        prod('asdf', 'qwerty')):
            assert a == b

# Generated at 2022-06-22 05:02:09.972996
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    # Basic test
    res = product(list(range(3)), repeat=2)
    res = list(res)
    assert res == [(i, i) for i in range(3)]
    # Test with tqdm class
    res = product(list(range(3)), repeat=2, tqdm_class=tqdm_auto)
    res = list(res)
    assert res == [(i, i) for i in range(3)]

# Generated at 2022-06-22 05:02:15.697977
# Unit test for function product
def test_product():
    results = set()

    try:
        tqdm_auto.get_lock()
    except tqdm_auto.TqdmSyncLock as e:
        tqdm_auto.set_lock(e)

    for i in product(['a', 'b', 'c'], [1, 2], tqdm_class=tqdm_auto):
        results.add(i)

    assert results == set(itertools.product(['a', 'b', 'c'], [1, 2]))

# Generated at 2022-06-22 05:02:25.860306
# Unit test for function product
def test_product():
    """Test for tqdm.tqdm_itertools.product"""
    from .utils import print_test_title

    print_test_title("tqdm.tqdm_itertools.product")

    from .utils import repr_data_size, _range

    with tqdm_auto(total=None) as _t:
        assert repr_data_size(product(_range(100, 300), _range(10),
                                      _range(10, 60), tqdm_class=_t.__class__))\
            == "50,000.00K"
        _t.close()

# Generated at 2022-06-22 05:02:28.687844
# Unit test for function product
def test_product():
    """Test product counting"""
    with tqdm_auto(total=7*27*16) as t:
        for enumerate in product(range(7), range(2,29), range(16)):
            pass

# Generated at 2022-06-22 05:02:33.364584
# Unit test for function product
def test_product():
    l = range(100)
    l = itertools.product(l, l)
    l = product(l, tqdm_class=tqdm_auto)
    l = sum(1 for _ in l)
    assert l == 10000
    l = itertools.product(range(100), range(100), range(100), range(100))
    l = product(l, tqdm_class=tqdm_auto)
    l = sum(1 for _ in l)
    assert l == 100 ** 4

# Generated at 2022-06-22 05:02:40.897762
# Unit test for function product
def test_product():
    import pytest
    from .utils import closing, _range
    for i in _range(10):
        for a in _range(2):
            for b in _range(2):
                with closing(tqdm_auto(total=a * b)) as t:
                    for c, d in product(_range(a), _range(b),
                                        tqdm_class=tqdm_auto):
                        pass
                    assert t.n == a * b
                    assert t.n == t.total

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 05:02:45.475703
# Unit test for function product
def test_product():
    assert list(product([5, 2, 1])) == list(itertools.product([5, 2, 1]))
    assert list(product([5, 2, 1], repeat=2)) == list(
        itertools.product([5, 2, 1], repeat=2))

# Generated at 2022-06-22 05:02:55.132999
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    try:
        # Python 2
        iterable1 = range(10)
    except NameError:
        # Python 3
        iterable1 = list(range(10))

    assert list(product(iterable1)) == list(itertools.product(iterable1))
    assert list(product(iterable1, iterable1)) == \
        list(itertools.product(iterable1, iterable1))
    assert list(product(iterable1, iterable1, iterable1)) == \
        list(itertools.product(iterable1, iterable1, iterable1))

# Generated at 2022-06-22 05:03:06.575738
# Unit test for function product
def test_product():
    from .autonotebook import tqdm
    from .utils import FormatMixin
    from .tests_tqdm import closing, range, StringIO

    class Test(FormatMixin):
        "Test class with `self.format_dict` for `tests_tqdm`"
        def __init__(self):
            FormatMixin.__init__(self)
        def __call__(self, *args, **kwargs):
            kwargs.update(self.format_dict())
            return tqdm(*args, **kwargs)

    # Test basic behavior:
    with closing(StringIO()) as our_file:
        n = 7
        k = 5
        total = n**k

# Generated at 2022-06-22 05:03:34.484959
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import gc
    from math import prod
    from random import randrange, shuffle

    L = [randrange(2, 10) for i in range(10)]

    # Ensure no leaks
    gc.collect()
    assert sum(gc.get_count()) == 0, "Python interpreter not free from leaks."

    # Test list-generator and generator-generator
    for f in (product, itertools.product):
        p = f(*L)
        for i in range(prod(L)):
            next(p)
    for f in (product, itertools.product):
        for i in f(*L, tqdm_leave=True):
            pass

    # Test yield

# Generated at 2022-06-22 05:03:45.392696
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    from ._utils import closing
    with closing(StringIO()) as our_file:
        for i in product([0, 1, 2], total=None, file=our_file):
            pass
        assert_array_equal(our_file.getvalue(),
                           "[0|1|2][0|1|2][0|1|2]\n"
                           "100%|##########|9/9 [00:00<00:00, ?it/s]\n")

    with closing(StringIO()) as our_file:
        for i in product([0, 1, 2], total=None, file=our_file, ncols=1):
            pass

# Generated at 2022-06-22 05:03:56.624035
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import ncols

    R = np.random.rand(10, 10, 10)
    L = int(np.prod(R.shape))
    assert sum(1 for _ in product(R)) == L
    assert sum(1 for _ in product(R, ascii=True, ncols=ncols)) == L
    assert sum(1 for _ in product(R, ascii=False, ncols=ncols)) == L
    # "smoke test"

# Generated at 2022-06-22 05:03:58.975709
# Unit test for function product
def test_product():
    from .tests import test_product
    test_product(itertools, tqdm_auto)

# Generated at 2022-06-22 05:04:01.050566
# Unit test for function product
def test_product():
    for i in product(xrange(1, 10)):
        print(i)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:04:09.107229
# Unit test for function product
def test_product():
    # Tests with pure Python
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    # Tests with tqdm_gui
    assert list(product([1, 2], [3, 4], tqdm_class=tqdm_auto.tqdm_gui)) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    # Tests with tqdm_notebook
    # assert list(product([1, 2], [3, 4], tqdm_class=tqdm_auto.tqdm_notebook)) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    # Tests with tqdm_pandas
    # assert list(product([1,

# Generated at 2022-06-22 05:04:15.451972
# Unit test for function product
def test_product():
    """Test for the `product` function"""
    try:
        from .tests_tqdm import _range
    except (ImportError, ValueError):
        from tqdm._utils import _range  # noqa
    A = list(_range(100))
    B = list(_range(100))
    C = list(_range(100))
    assert set(itertools.product(A, B, C)) == set(product(A, B, C))

# Generated at 2022-06-22 05:04:21.517799
# Unit test for function product
def test_product():
    """
    Unit test for tqdm.itertools.product

    """
    from nose.tools import assert_equal
    assert_equal(
        list(product("ab", repeat=3)),
        [('a', 'a', 'a'), ('a', 'a', 'b'), ('a', 'b', 'a'), ('a', 'b', 'b'),
         ('b', 'a', 'a'), ('b', 'a', 'b'), ('b', 'b', 'a'), ('b', 'b', 'b')])


# Alias for backwards compatibility (replaced by tqdm_gui.main)

# Generated at 2022-06-22 05:04:26.710579
# Unit test for function product
def test_product():
    kwargs = dict(tqdm_class=lambda iterable, **kwargs: iterable)
    assert list(product([0], [1], [2], **kwargs)) == [(0, 1, 2)]
    assert list(product([0, 1], [1], [2], **kwargs)) == [(0, 1, 2), (1, 1, 2)]
    assert list(product([0, 1], [1, 2], [2], **kwargs)) == [
        (0, 1, 2), (0, 2, 2), (1, 1, 2), (1, 2, 2)]
    assert list(product([1, 2, 3], [0, 1], **kwargs)) == [
        (1, 0), (1, 1), (2, 0), (2, 1), (3, 0), (3, 1)]

# Generated at 2022-06-22 05:04:34.374969
# Unit test for function product
def test_product():
    import six
    if six.PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Imports
    import time
    from .utils import FormatMixin
    from .tqdm_gui import tqdm

    # Create a mock read object
    def _mock_read(n=None):
        if n is None:
            out = [b"1", b"2", b"3", b"4"]
        else:
            until = n
            out = [b"1"]
            while until > 1:
                out[-1] += b"0"
                until -= 1
            out.append(b"1")
        return out

    class MockPopen(FormatMixin):
        """
        Mock process to test non-blocking read
        """

# Generated at 2022-06-22 05:05:20.417042
# Unit test for function product
def test_product():
    """ Test product() """
    from ..utils import FormatCustomTextTest

    class TestProduct(FormatCustomTextTest):
        def test_product(self):
            """ Test product() """
            with self.create_monitor(total=9) as monitor:
                expected_values = [0, 1, 2, 3, 4, 5, 6, 7, 8]
                for i in product(range(3), range(3), monitor=monitor):
                    next_val = expected_values.pop(0)
                    monitor.update()
                    assert sum(i) == next_val

    test = TestProduct()
    test.test_product()

# Generated at 2022-06-22 05:05:24.673839
# Unit test for function product
def test_product():
    from .utils import FormatStub
    from .cc import _range
    for cls in (tqdm_auto, tqdm, FormatStub):
        for i, j in zip(product(_range(100), _range(50), tqdm_class=cls),
                        product(_range(100), _range(50))):
            assert i == j

# Generated at 2022-06-22 05:05:32.935366
# Unit test for function product
def test_product():
    import numpy as np
    from random import randint
    for n in range(100):
        n_dims = randint(1, 5)
        n_elems = [randint(1, 10) for _ in range(n_dims)]
        prod_auto = list(product(range(i) for i in n_elems))
        prod_fun = list(itertools.product(*(range(i) for i in n_elems)))
        assert prod_auto == prod_fun
        assert len(prod_auto) == np.prod(n_elems)

# Generated at 2022-06-22 05:05:38.370379
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import random
    random.seed(123)
    arrays = [list(range(i)) for i in range(2, 8)]
    for a in arrays:
        random.shuffle(a)
    it = product(*arrays)
    next(it)
    for _ in it:
        pass

# Generated at 2022-06-22 05:05:40.086510
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    for a, b in product(range(1000000), range(1000)):
        pass

# Generated at 2022-06-22 05:05:48.271096
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # this method is invoked when running `python -m tqdm.utils`
    from tqdm.auto import trange, tqdm
    from tqdm.utils import product

    arr = list(range(6))
    for cls in [tqdm, trange]:
        for _ in product(arr, repeat=3, tqdm_class=cls):
            pass


# Disable `no-member` warnings caused by `itertools.product`
# pylint: disable=no-member
_itertools = itertools.product

# Generated at 2022-06-22 05:05:55.185178
# Unit test for function product
def test_product():
    # Test without tqdm_class
    from six.moves import range
    from ..utils import FormatCustomText
    from .tests_genl import TestFormats

    for t in TestFormats:
        kwargs = t._asdict()
        kwargs.update({'iterable': [range(3)] * 50})

        with tqdm_auto(**kwargs) as pbar:
            for _ in product(*kwargs['iterable']):
                pbar.update()
                text = pbar.format_dict['desc'].lstrip('\r')

# Generated at 2022-06-22 05:06:06.421428
# Unit test for function product
def test_product():
    """
    unit testing with pytest
    """
    import pytest
    from itertools import product

    # test with simple iterators of string and int
    iters = ['abc', [1, 2, 3]]
    result = []
    for z in product(*iters):
        result.append(z)

    assert result == list(product(*iters))


    # test with simple iterator of string and an iterator which raises
    iters = [[1, 2], ['a', 'b', 'c', 'd']]
    result = []
    for z in product(*iters):
        result.append(z)

    assert result == list(product(*iters))


    # test with iterator which raises in tqdm.auto
    iters = [[1, 2], ['a', 'b', 'c', 'd']]


# Generated at 2022-06-22 05:06:07.850696
# Unit test for function product
def test_product():
    from .tests import _test_iter
    _test_iter(product, 'itertools.product')

# Generated at 2022-06-22 05:06:13.614624
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal

    # Test 0D
    t = product([0], [0])
    assert_equal(len(list(t)), 1)

    # Test 1D
    t = product(range(3), range(3))
    assert_equal(len(list(t)), 3 ** 2)

    # Test 2D
    t = product(range(3), repeat=2)
    assert_equal(len(list(t)), 3 ** 2)

    # Test 3D
    t = product(range(3), range(3), range(3))
    assert_equal(len(list(t)), 3 ** 3)

    # Test empty
    t = product()
    assert_equal(len(list(t)), 1)