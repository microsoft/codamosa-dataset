

# Generated at 2022-06-22 04:56:14.107550
# Unit test for function product
def test_product():
    from numpy import allclose
    a = [1, 2, 3, 4]
    b = [5, 6, 7]
    c = [8, 9]
    d = list(product(a, b, c))
    assert len(d) == 24
    for i in d:
        assert len(i) == 3

# Generated at 2022-06-22 04:56:19.012617
# Unit test for function product
def test_product():
    """Test product generator"""
    from nose.tools import assert_equal
    from nose.tools import assert_is_instance
    res = sum(product(range(10), [1,2,3], range(4)))
    assert_equal(res, 4990)  # 0 + 1 + ... + 4989

# Generated at 2022-06-22 04:56:27.574928
# Unit test for function product
def test_product():
    iterables_1 = [["one", "two", "three"], ["four", "five"], ["six", "seven", "eight"]]
    iterables_2 = [["one", "two", "three"], ["four", "five"], ["six", "seven", "eight"], ["nine", "ten"]]
    r_1 = [i for i in itertools.product(*iterables_1)]
    r_2 = [i for i in itertools.product(*iterables_2)]
    assert len(r_1) == len(r_2) == len(list(product(*iterables_1))) == len(list(product(*iterables_2))) == 72

# Generated at 2022-06-22 04:56:38.387724
# Unit test for function product
def test_product():
    def integer_product(*args):
        """Prod without multiprocessing"""
        from operator import mul
        from functools import reduce
        return reduce(mul, args)

    def _test(ns, expected_size=None, **kwargs):
        a = list(range(ns[0]))
        b = list(range(ns[1]))
        c = list(range(ns[2]))

        with tqdm_auto(ascii=True, disable=True) as t:
            # make sure tqdm doesn't affect results
            cp_tqdm_auto = tqdm_auto
            if hasattr(tqdm_auto, '_instances'):
                tqdm_auto._instances.clear()
            tqdm_auto.monitor_interval = 0
            tqdm

# Generated at 2022-06-22 04:56:50.740892
# Unit test for function product
def test_product():
    from pytest import mark, raises
    from tqdm.auto import tqdm, trange
    from tqdm._utils import _term_move_up

# Generated at 2022-06-22 04:57:00.363152
# Unit test for function product
def test_product():
    for i in product(range(4)):
        assert i == (0, 0, 0, 0)
        break
    for i in product(range(4), range(2, 6)):
        assert i == (0, 2, 0, 0)
        break
    for i in product(range(4), range(2), range(3, 5)):
        assert i == (0, 0, 3, 0)
        break
    for i in product(range(4), range(2), range(3, 5), range(6, 8)):
        assert i == (0, 0, 3, 6)
        break

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-22 04:57:07.679038
# Unit test for function product
def test_product():
    r = 2
    c = 3
    results = []
    for i, j in product(range(r), range(c)):
        results.append((i, j))

    assert len(results) == r*c, str(results)
    assert set(results) == set([(i, j) for i in range(r) for j in range(c)]), \
        str(results)

# Generated at 2022-06-22 04:57:15.566110
# Unit test for function product
def test_product():
    iterables = [range(3), range(3)]
    assert list(product(*iterables, total=None)) == list(itertools.product(*iterables))
    assert list(product(*iterables, total=9)) == list(itertools.product(*iterables))
    iterables = [range(1), range(2)]
    assert list(product(*iterables, total=None)) == list(itertools.product(*iterables))
    assert list(product(*iterables, total=2)) == list(itertools.product(*iterables))

# Generated at 2022-06-22 04:57:21.548272
# Unit test for function product
def test_product():
    """
    Run unit tests for `tqdm.iterables.product`.
    """
    from ._tqdm_gui import _test_close_at_end
    from ..std import tqdm_gui
    from ..utils import _range

    with tqdm_gui(
            desc="product",
            dynamic_ncols=True,
            leave=True,
            ascii=True,
            miniters=1,
            mininterval=0,
            maxinterval=0.1) as pbar:
        for i in product(_range(10), pbar=pbar, desc="product"):
            assert i == (0, 0)
            break

# Generated at 2022-06-22 04:57:23.578382
# Unit test for function product
def test_product():
    from .tests import tests_item_count
    tests_item_count(product, itertools.product)

# Generated at 2022-06-22 04:57:38.623235
# Unit test for function product
def test_product():
    from ..tests import common as test_common
    from itertools import count, repeat, product
    # Unit tests
    assert(test_common.repr_close(list(product(range(9), repeat=3)),
                                  product(range(9), repeat=3)))
    assert(test_common.repr_close(list(product(range(10), repeat=5)),
                                  product(range(10), repeat=5)))
    assert(test_common.repr_close(list(product(range(10), repeat=5)),
                                  product(range(10), repeat=5)))
    assert(test_common.repr_close(list(product(range(10), count(), repeat=5)),
                                  product(range(10), count(), repeat=5)))
    # Sanity check

# Generated at 2022-06-22 04:57:47.969042
# Unit test for function product
def test_product():
    from . import _test_itertools_function

    tqdm = tqdm_auto
    with tqdm(total=len(list(range(2)))) as t:
        for i in range(2):
            t.update()
    # Make sure tqdm.__exit__ eats up StopIteration
    with tqdm(total=2) as t:
        _test_itertools_function(tqdm, product, *[range(x) for x in (2, 3, 4)],
                                 tqdm_class=tqdm, desc="product")



# Generated at 2022-06-22 04:57:55.931432
# Unit test for function product
def test_product():
    """
    Test `itertools.product` with tqdm wrapper.
    """
    import pandas as pd
    import numpy.random as rn
    from random import shuffle
    from tqdm import trange


# Generated at 2022-06-22 04:58:03.822411
# Unit test for function product
def test_product():
    from ..tqdm import tqdm
    for tqdm_cls in [tqdm, tqdm_auto]:
        for i in product('ABCD', 'xy', tqdm_class=tqdm_cls):
            assert i
        for i in product(range(1000), range(1000), tqdm_class=tqdm_cls):
            assert i
        for i in product('ABCD', repeat=2, tqdm_class=tqdm_cls):
            assert i
        for i in product('ABCD', repeat=5, tqdm_class=tqdm_cls):
            assert i

# Generated at 2022-06-22 04:58:15.602115
# Unit test for function product
def test_product():
    """
    Unit tests for product.
    """
    from ..utils import closing
    from ..std import StringIO
    from . import trange
    from .tqdm import tqdm

    with closing(StringIO()) as our_file, closing(StringIO()) as their_file:
        for _ in tqdm(product(range(10), range(10), range(10),
                              file=our_file),
                      desc="Testing product()"):
            pass
        for _ in trange(1000, file=their_file):
            pass

        # Test that both files are identical
        our_file.seek(0)
        their_file.seek(0)
        our_lines = our_file.readlines()
        their_lines = their_file.readlines()
        # Removing the progressbars
        our_lines

# Generated at 2022-06-22 04:58:22.929314
# Unit test for function product
def test_product():
    from itertools import zip_longest

    def assertEqual(a, b):
        for i, j in zip_longest(a, b):
            assert i == j

    a = range(10)
    b = range(10, 30)
    assertEqual(product(a, b), itertools.product(a, b))
    assertEqual(product(a, b, tqdm_class=None), itertools.product(a, b))

# Generated at 2022-06-22 04:58:25.803466
# Unit test for function product
def test_product():
    for i in product(range(4), range(4)):
        assert (i[0] < 4 and i[1] < 4)

# Generated at 2022-06-22 04:58:37.063582
# Unit test for function product
def test_product():
    # Unit tests
    from numpy import prod
    from random import randint
    # Examples with fixed arguments
    assert list(product(range(2), repeat=3)) == [(0, 0, 0), (0, 0, 1),
                                                (0, 1, 0), (0, 1, 1),
                                                (1, 0, 0), (1, 0, 1),
                                                (1, 1, 0), (1, 1, 1)]
    assert list(product(range(0), repeat=3)) == []
    assert list(product([], repeat=3)) == []
    assert list(product(range(2), repeat=0)) == [(None,)]

# Generated at 2022-06-22 04:58:48.030570
# Unit test for function product
def test_product():
    """
    Unit tests for function `product`.
    """
    import tqdm

    mytuple = (1, 2, 3)
    mystr = "abc"
    mylist = [1, 2, 3]
    mydict = {1: "a", 2: "b", 3: "c"}

    assert list(product(mytuple)) == [(1,), (2,), (3,)]
    assert list(product(mylist)) == [(1,), (2,), (3,)]
    assert list(product(mystr)) == [('a',), ('b',), ('c',)]
    assert list(product(mydict)) == [(1,), (2,), (3,)]


# Generated at 2022-06-22 04:58:52.719060
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .cli import tqdm
    from ..utils import chunk

    for n in chunk(range(10), 4):  # NOQA
        list(tqdm(product(range(10), range(10)), tqdm_class=tqdm))

# Generated at 2022-06-22 04:59:03.300122
# Unit test for function product
def test_product():
    a = list(range(10))
    b = list(range(100))
    c = list(range(1000))

    assert list(product(a, b, c)) == list(itertools.product(a, b, c))
    assert list(product(a, b, c, tqdm_class=None)) == list(itertools.product(a, b, c))


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-22 04:59:09.152692
# Unit test for function product
def test_product():
    assert list(product("ABCD", repeat=2)) == [("A", "A"), ("A", "B"),
                                                ("A", "C"), ("A", "D"),
                                                ("B", "A"), ("B", "B"),
                                                ("B", "C"), ("B", "D"),
                                                ("C", "A"), ("C", "B"),
                                                ("C", "C"), ("C", "D"),
                                                ("D", "A"), ("D", "B"),
                                                ("D", "C"), ("D", "D")]

# Generated at 2022-06-22 04:59:15.661651
# Unit test for function product
def test_product():
    from .tests import mk_test_tqdm_cls

    for [p1, p2], tqdm_cls in mk_test_tqdm_cls("product"):
        for _ in tqdm_cls(product(p1, p2, tqdm_class=tqdm_cls), leave=None):
            pass


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 04:59:21.041152
# Unit test for function product
def test_product():
    import numpy as np
    from ..std import numpy as tqdm_np
    # noinspection PyTypeChecker
    for iter1, iter2, iter3 in product(tqdm_np.arange(10),
                                       tqdm_np.arange(5),
                                       tqdm_np.arange(2),
                                       tqdm_class=tqdm_auto, desc="foobars"):
        pass
    assert np.array_equal(tuple(tqdm_np.arange(2)), (0, 1))

# Generated at 2022-06-22 04:59:23.758612
# Unit test for function product
def test_product():
    for pro in product(range(1), range(10), "ab", tqdm_class=tqdm_auto):
        pass

    assert pro == ((0, 9, 'b'),)

# Generated at 2022-06-22 04:59:31.613958
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # test product with no iterable
    assert list(product()) == [()]

    assert list(product('a', 'b')) == [('a', 'b')]
    assert list(product('a', 'b', 'c')) == [('a', 'b', 'c')]
    assert list(product(range(2), repeat=3)) == [
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-22 04:59:34.063965
# Unit test for function product
def test_product():
    for x, y in product([1], [2], tqdm_class=tqdm_auto):
        assert(x == 1)
        assert(y == 2)

# Generated at 2022-06-22 04:59:38.501660
# Unit test for function product
def test_product():
    it = product(range(3), range(3), range(3), tqdm_class=tqdm_auto)
    assert list(it) == list(itertools.product(range(3), range(3), range(3)))

# Generated at 2022-06-22 04:59:41.235109
# Unit test for function product
def test_product():
    list(product([0, 1], [0, 1], [0, 1], tqdm_class=tqdm_auto, total=8))

# Generated at 2022-06-22 04:59:44.889671
# Unit test for function product
def test_product():
    from ..main import tqdm
    items = (["a", "b", "c"], [1, 2, 3])
    assert (list(tqdm.itertools.product(*items))
            == list(tqdm.tqdm.product(*items)))

# Generated at 2022-06-22 05:00:02.301535
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tests import TestCase
    import numpy as np
    from ..tqdm import trange

    # Test empty
    with trange(0, dynamic_ncols=True) as t:
        assert list(product(t, range(0))) == []

    # Test 1-dim
    with trange(4, dynamic_ncols=True) as t:
        assert list(product(t, range(4))) == \
            list(zip(range(4), range(4), [t] * 4))

    # Test multi-dim

# Generated at 2022-06-22 05:00:14.395692
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    assert (
        list(product(range(2), repeat=2, tqdm_class=tqdm_auto))
        == list(itertools.product(range(2), repeat=2))
        )
    assert (
        list(product(range(8), repeat=2, tqdm_class=tqdm_auto))
        == list(itertools.product(range(8), repeat=2))
        )
    assert (
        list(product(range(12), (111, 222, 333), tqdm_class=tqdm_auto))
        == list(itertools.product(range(12), (111, 222, 333)))
        )

# Generated at 2022-06-22 05:00:24.101820
# Unit test for function product
def test_product():
    """
    Test function ``product``.
    """
    from .utils import format_sizeof
    from .utils import timed_cm

    x = range(10)
    y = range(5)
    out = product(x, y, tqdm_class=tqdm_auto)
    ref = list(itertools.product(x, y))
    assert list(out) == ref

    print("Memory usage:\n" +
          "\n".join([format_sizeof(s)
                     for s in timed_cm(len(x) * len(y),
                                       product, x, y)]))

# Generated at 2022-06-22 05:00:30.499809
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    from .tests import pretest_posttest
    it = product(range(2), range(2), range(2), tqdm_class=tqdm)
    ret = pretest_posttest(lambda: list(it))

    assert ret == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                   (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-22 05:00:32.032731
# Unit test for function product
def test_product():
    """ Ensure product unit test runs """
    list(product(([1, 2, 3],)))

# Generated at 2022-06-22 05:00:43.409237
# Unit test for function product
def test_product():
    from .misc import crash_cycle
    from .utils import format_sizeof
    import sys
    import tempfile

    test_size = 20
    test_count = 10000

    # Same as: for i in product(range(test_size), range(test_size)):
    for i in product(range(test_size), range(test_size),
                     tqdm_class=tqdm_auto, total=test_size ** 2):
        pass

    # Test crash cycle with first iterator done
    # Note: this fails `(itertools.repeat(None, 0) ** 2)` since
    #       `itertools.repeat(None).__len__()` returns `sys.maxsize`

# Generated at 2022-06-22 05:00:56.367144
# Unit test for function product
def test_product():  # pragma: no cover
    import random
    import string

    def check_equivalent(f, *args, **kwargs):
        res1 = list(itertools.product(*args, **kwargs))
        res2 = list(f(*args, **kwargs))
        assert res1 == res2

    arg = [1, 2, 3]  # ints
    check_equivalent(itertools.product, arg)
    check_equivalent(product, arg)
    assert sum(itertools.product(arg, repeat=2)) == sum(product(arg, repeat=2))
    assert sum(itertools.product(arg, repeat=3)) == sum(product(arg, repeat=3))
    assert sum(itertools.product(arg, repeat=4)) == sum(product(arg, repeat=4))


# Generated at 2022-06-22 05:01:08.032039
# Unit test for function product
def test_product():
    # pylint:disable=protected-access
    exp = [
        (0, 0, 0),
        (0, 0, 1),
        (0, 1, 0),
        (0, 1, 1),
        (1, 0, 0),
        (1, 0, 1),
        (1, 1, 0),
        (1, 1, 1),
    ]
    act = list(product([0, 1], repeat=3))
    assert exp == act

    exp = [
        (0, 0, 0),
        (0, 0, 1),
        (0, 1, 0),
        (0, 1, 1),
        (1, 0, 0),
        (1, 0, 1),
        (1, 1, 0),
        (1, 1, 1),
    ]

# Generated at 2022-06-22 05:01:14.165707
# Unit test for function product
def test_product():
    result_list = []
    for _ in product([0, 1],
                     ['a', 'b'],
                     tqdm=tqdm_auto,
                     total=None,
                     desc="Foo"):
        result_list.append(_)
    assert(result_list == [(0, 'a'),
                           (0, 'b'),
                           (1, 'a'),
                           (1, 'b')])

# Generated at 2022-06-22 05:01:25.693943
# Unit test for function product
def test_product():
    for i in product(((i for i in range(10)) for _ in range(10)),
                     tqdm_class=tqdm_auto):
        pass
    for i in product(((i for i in range(10)) for _ in range(10)),
                     tqdm_class=tqdm_auto):
        pass
    for i in product(((i for i in range(10)) for _ in range(10)),
                     tqdm_class=tqdm_auto):
        pass
    for i in product(((i for i in range(10)) for _ in range(10)),
                     tqdm_class=tqdm_auto):
        pass
    for i in product(((i for i in range(10)) for _ in range(10)),
                     tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-22 05:01:44.287730
# Unit test for function product
def test_product():
    import sys
    for _ in product(range(4), range(4), range(4), tqdm_class=tqdm_auto):
        sys.stderr.flush()
    for _ in product(range(4), range(4), range(4), tqdm_class=tqdm_auto):
        sys.stderr.flush()
    for i in product(range(4), range(4), range(4), tqdm_class=tqdm_auto):
        pass
    for i in product(range(4), range(4), range(4), tqdm_class=tqdm_auto, total=64):
        pass

# Generated at 2022-06-22 05:01:47.571227
# Unit test for function product
def test_product():
    """Unit test for product"""
    expected = [
        (1, 'a'), (2, 'a'), (3, 'a'), (1, 'b'), (2, 'b'), (3, 'b'),
        (1, 'c'), (2, 'c'), (3, 'c')]
    assert list(product(range(1, 4), 'abc')) == expected

# Generated at 2022-06-22 05:01:55.802116
# Unit test for function product
def test_product():
    expected = [
        (0, 0), (0, 1), (1, 0), (1, 1),
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)
    ]
    assert list(product([0, 1], [0, 1], [0, 1])) == expected

# Generated at 2022-06-22 05:02:03.723233
# Unit test for function product
def test_product():
    import numpy
    from ..utils import TestCase, _range

    with TestCase():
        # Test basic iterable
        ret = product(_range(2),
                      _range(3),
                      tqdm_class=tqdm_auto)
        assert (list(ret) ==
                list(itertools.product(_range(2), _range(3))))

        # Test iterator
        ret = product((_range(2) for __ in _range(3)),
                      (_range(3) for __ in _range(3)),
                      tqdm_class=tqdm_auto)
        assert (list(ret) ==
                list(itertools.product((_range(2) for __ in _range(3)),
                                       (_range(3) for __ in _range(3)))))

        # Test unknown length

# Generated at 2022-06-22 05:02:11.917701
# Unit test for function product
def test_product():
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    sio = StringIO()
    orig, sys.stdout = sys.stdout, sio
    try:
        i = product(range(100), range(100), range(100))
        for _ in i:
            pass
        i = product(range(100), range(100), range(100))
        for _ in i:
            pass
    finally:
        sys.stdout = orig
    assert "2 loops" in sio.getvalue()
    sio.close()

# Generated at 2022-06-22 05:02:18.180597
# Unit test for function product
def test_product():
    assert list(product(["a", "b", "c"], repeat=1)) \
        == [('a',), ('b',), ('c',)]
    assert list(product(["a", "b", "c"], repeat=2)) \
        == [('a', 'a'), ('a', 'b'), ('a', 'c'),
            ('b', 'a'), ('b', 'b'), ('b', 'c'),
            ('c', 'a'), ('c', 'b'), ('c', 'c')]


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-22 05:02:22.172430
# Unit test for function product
def test_product():
    for p in product([1], [2], [3]):
        assert p == (1, 2, 3)

# Generated at 2022-06-22 05:02:30.960144
# Unit test for function product
def test_product():
    # Test basic functionality with tqdm set to True
    product_call = product(range(3), range(3), range(3), tqdm_class=tqdm_auto)
    assert sum(1 for _ in product_call) == 27

    # Test basic functionality with tqdm set to False
    product_call = product(range(3), range(3), range(3), tqdm_class=False)
    assert sum(1 for _ in product_call) == 27

    # Test that total is calculated correctly
    product_call = product(range(3), range(3), range(3), tqdm_class=True)
    assert sum(1 for _ in product_call) == 27

# Generated at 2022-06-22 05:02:41.769209
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from ..custom import trange
    from numpy.random import random
    from .tests import pretest_posttest
    # Test 1
    for _ in trange(1, ascii=True):
        for _ in product(range(5), repeat=5):
            pass
    # Test 2
    for _ in trange(1, ascii=True):
        for _ in product(range(5), repeat=5):
            for _ in trange(1000):
                pass
    # Test 3
    for _ in trange(1, ascii=True):
        for _ in product(range(5), repeat=5):
            for _ in trange(10, leave=True):
                pass
    # Test 4

# Generated at 2022-06-22 05:02:53.494074
# Unit test for function product
def test_product():
    from .utils import closing, format_sizeof
    import numpy as np

    n = 9
    sizes = range(1, n + 1)
    tqdms = (tqdm_auto, tqdm_auto.tqdm, tqdm_auto.tqdm.__init__)

    for tqdm in tqdms:
        with closing(tqdm(total=n, disable=False)) as pbar:
            i = 0
            for obj in product((range(j) for j in sizes),
                               tqdm=tqdm, disable=False, postfix=False):
                pbar.set_postfix(obj=format_sizeof(obj))
                i += 1
            assert i == n, "%d != %d" % (i, n)


# Generated at 2022-06-22 05:03:19.376948
# Unit test for function product
def test_product():
    from random import randrange
    from six.moves import range
    for _ in range(50):
        kwargs = {'desc': '', 'miniters': randrange(1000, 10000),
                  'total': randrange(1000, 10000), 'leave': False,
                  'file': None, 'ncols': None, 'mininterval': None,
                  'maxinterval': None, 'ascii': False, 'disable': False,
                  'unit': 'it', 'unit_scale': None, 'dynamic_ncols': True,
                  'smoothing': None, 'avg_time': None, 'bar_format': '{desc}{percentage:3.0f}%|{bar}{r_bar}',
                  'initial': 0, 'position': None, 'postfix': None}
        # the following

# Generated at 2022-06-22 05:03:25.111449
# Unit test for function product
def test_product():
    """
    Simple test for product() wrapper
    """
    try:
        from itertools import product as itertools_product
    except ImportError:
        tqdm.tqdm.write("itertools.product not found!")
        return
    try:
        for i, j in zip(product(range(4), repeat=4),
                        itertools_product(range(4), repeat=4)):
            assert i == j
    except Exception:
        from traceback import print_exc
        print_exc()

# Generated at 2022-06-22 05:03:29.207854
# Unit test for function product
def test_product():
    assert sum(
        1 for _ in product(range(10), repeat=4, tqdm_class=None)) == 10 ** 4
    assert sum(
        1 for _ in product(range(10), range(10), tqdm_class=None)) == 100

# Generated at 2022-06-22 05:03:39.862715
# Unit test for function product
def test_product():
    """Test itertools.product wrapper"""
    import pytest
    from itertools import product as itertools_product
    from shutil import rmtree
    from tempfile import mkdtemp
    from os import mkdir, listdir, scandir

    out = set()
    for i in product('ABCD', 'xy'):
        out.add(i)
    assert out == set(itertools_product('ABCD', 'xy'))

    out = set()
    for i in product('ABCD', 'xy', tqdm_class=None):
        out.add(i)
    assert out == set(itertools_product('ABCD', 'xy'))

    pytest.raises(TypeError, lambda: product(1, 2))

    # Test for None

# Generated at 2022-06-22 05:03:51.401874
# Unit test for function product
def test_product():
    from .._utils import _range
    from . import trange
    from .utils import FormatWrapBase

    class FakeFormatWrap(FormatWrapBase):
        def __init__(self, iterable, *args, **kwargs):
            self.iter = iter(iterable)
            super(FakeFormatWrap, self).__init__(*args, **kwargs)

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.iter)

    with trange(10, file=None) as t:
        for i in product(t, _range(10), [0]):
            pass

# Generated at 2022-06-22 05:04:01.386033
# Unit test for function product
def test_product():  # noqa
    import re
    import sys
    from io import StringIO
    from test_tqdm import with_setup, pretest, posttest, _range

    save_stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        for r in _range(3):
            with with_setup(pretest, posttest):
                for _ in product(*(range(r),)):
                    pass
    finally:
        sys.stderr = save_stderr

    out = sys.stderr.getvalue()
    assert re.findall(r'100%|\n', out) == ['\n', '\n', '\n']

# Generated at 2022-06-22 05:04:09.136631
# Unit test for function product
def test_product():
    from ..tqdm import trange
    import sys

    with trange(10) as t:
        for i in product(*[range(3)]*10, tqdm_class=t):
            pass

    with trange(10, file=sys.stderr) as t:
        for i in product(*[range(3)]*10, tqdm_class=t):
            pass

    with trange(10) as t:
        for i in product(*[range(3)]*10):
            pass

    with trange(10) as t:
        for i in product(*[range(3)]*10, leave=False):
            pass

    with trange(10) as t:
        for i in product(*[range(3)]*10, leave=False, tqdm_class=t):
            pass



# Generated at 2022-06-22 05:04:18.897052
# Unit test for function product
def test_product():
    from tests_tqdm import with_setup, _range
    from numpy.random import randint
    from numpy.random import random
    from numpy import concatenate
    from numpy import sum
    import sys

    # Test length estimates
    for lengths in [None, [2, 3], [2, 3, 4]]:
        if lengths is not None:
            summ = 1
            for l in lengths:
                summ *= l
        else:
            summ = None
        args = [_range(l) if l is not None else randint(0, 100, randint(0, 100)) \
                for l in lengths]
        assert (sum(1 for _ in product(*args)) == summ)

    # Test display

# Generated at 2022-06-22 05:04:24.939346
# Unit test for function product
def test_product():
    from .utils import closing, FakeTqdmFile, StringIO
    from .gui import tqdm

    for tqdm_cls in (tqdm, tqdm_auto):
        for n, desc in enumerate(("A B C", "D E", "F G H I J")):
            with closing(StringIO()) as our_file:
                with tqdm_cls(desc=desc, file=our_file) as t:
                    for i in product("AB", "de", "fghi", tqdm_class=tqdm_cls):
                        t.update()

# Generated at 2022-06-22 05:04:29.704643
# Unit test for function product
def test_product():
    from .tests import test_iterables
    test_iterables.test_product(product)


if __name__ == '__main__':
    import sys
    import pytest
    pytest.main([__file__] + sys.argv[1:])

# Generated at 2022-06-22 05:05:09.059757
# Unit test for function product
def test_product():
    from ..utils import assert_eq
    for i in product(range(10)):
        assert_eq(i, (0, 1, 2, 3, 4, 5, 6, 7, 8, 9))
    for i in product(range(3), range(3)):
        assert_eq(i, (0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2))
    for i in product(range(2), range(2)):
        assert_eq(i, (0, 0), (0, 1), (1, 0), (1, 1))



# Generated at 2022-06-22 05:05:19.197865
# Unit test for function product
def test_product():
    """Test function product."""
    import numpy  # NOQA
    import pyfftw  # NOQA

    N = 16
    data = []
    stride = 2
    for i in product(range(N), range(N//stride), tqdm_class=None):
        data.append(i)
    assert(data == list(itertools.product(range(N), range(N//stride))))

    data = []
    for i in product(range(N), range(N//stride)):
        data.append(i)
    assert(data == list(itertools.product(range(N), range(N//stride))))

# Generated at 2022-06-22 05:05:25.031088
# Unit test for function product
def test_product():
    from tqdm import tqdm
    list(tqdm.tqdm_pandas(tqdm.tqdm_notebook(tqdm.tqdm_gui(tqdm.tnrange(10)))))

# Generated at 2022-06-22 05:05:30.010436
# Unit test for function product
def test_product():
    for iterables in [[[1, 2], ["a", "b"]], [[1, 2], ["a", "b"], [3, 4]]]:
        for tqdm_class in [tqdm_auto]:
            assert(list(product(*iterables, tqdm_class=tqdm_class)) ==
                   list(itertools.product(*iterables)))

# Generated at 2022-06-22 05:05:41.698250
# Unit test for function product
def test_product():
    import numpy as np
    import tqdm

    list_empty = []
    gen_empty = (i for i in [])
    np_empty = np.array([])

    # product with no iterable
    assert list(tqdm.product()) == []
    assert list(tqdm.product(tqdm_class=tqdm.tqdm)) == []

    # product with empty iterables
    assert list(tqdm.product(np_empty)) == []
    assert list(tqdm.product(tqdm_class=tqdm.tqdm,
                             iterable=np_empty)) == []

    # product with single iterable
    assert list(tqdm.product(range(3))) == [(0,), (1,), (2,)]

# Generated at 2022-06-22 05:05:52.011182
# Unit test for function product
def test_product():
    from .utils import FormatWrapBase
    class Mock(FormatWrapBase):
        """
        Override ``display`` for testing purposes.
        """
        def __init__(self, **kwargs):
            super(Mock, self).__init__(**kwargs)
            self.format_dict = {'n': 0}

        @property
        def n(self):
            return self.format_dict['n']

        @n.setter
        def n(self, val):
            self.format_dict['n'] = val

        @n.deleter
        def n(self):
            self.format_dict['n'] = 0

        def display(self):
            self.format_dict['n'] += 1

    iterables1 = list(map(str, [1, 2, 3]))
    iter

# Generated at 2022-06-22 05:06:03.234478
# Unit test for function product