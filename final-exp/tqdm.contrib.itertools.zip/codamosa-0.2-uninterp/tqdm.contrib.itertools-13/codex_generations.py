

# Generated at 2022-06-18 11:10:12.163199
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    def test_product_inner(tqdm_class, iterables, **kwargs):
        """
        Unit test for function product
        """
        kwargs = kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_class)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)

# Generated at 2022-06-18 11:10:23.038084
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .utils import format_interval
    import time
    import sys

    # Test 1
    t = time.time()
    for _ in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False):
        pass
    print("Test 1:", format_interval(time.time() - t))

    # Test 2
    t = time.time()
    for _ in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=False,
                     mininterval=0.1):
        pass

# Generated at 2022-06-18 11:10:34.169556
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    def test_product_gen(iterables, tqdm_class):
        """
        Test generator
        """
        for _ in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class):
        """
        Test list
        """
        list(product(*iterables, tqdm_class=tqdm_class))

    def test_product_set(iterables, tqdm_class):
        """
        Test set
        """
        set(product(*iterables, tqdm_class=tqdm_class))


# Generated at 2022-06-18 11:10:42.188202
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 4
   

# Generated at 2022-06-18 11:10:53.510188
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range
    from .utils import FormatCustomText

    @with_setup(pretest=True, posttest=True)
    def inner(total=None, **kwargs):
        """
        Unit test for function product
        """
        # Test 1
        for i in product(_range(10), _range(10), **kwargs):
            pass

        # Test 2
        for i in product(_range(10), _range(10), total=total, **kwargs):
            pass

        # Test 3
        for i in product(_range(10), _range(10), total=total,
                         bar_format=FormatCustomText(), **kwargs):
            pass

    inner()
    inner(total=100)
    inner(tqdm_class=tqdm_auto)

# Generated at 2022-06-18 11:11:02.805029
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    print("  Generate a list of all possible combinations of [0, 1] with "
          "lengths from 1 to 10.")
    print("  This should take a while.")
    print("  The total number of combinations is 2^10 = 1024.")
    print("  The total size of the list is 1024 * 10 * 4 = 40960 bytes.")
    print("  The total time should be around 1 second.")
    start_time = time.time()
    lst = list(product(range(2), repeat=10))
    end_time = time.time()

# Generated at 2022-06-18 11:11:13.221131
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:11:21.970124
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(100), range(100), range(100)):
        pass
    t1 = time.time()
    print("  Time: %s" % format_interval(t1 - t0))
    print("  Memory: %s" % format_sizeof(sys.getsizeof(i)))
    print("  Iterations: %d" % (100 ** 3))

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:11:31.321574
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_number_short
    from ..utils import format_size_short
    from ..utils import format_speed_short
    from ..utils import format_timespan_short
    from ..utils import format_interval_short
    from ..utils import format_eta_short
    from ..utils import format_naturalsize_short


# Generated at 2022-06-18 11:11:39.645567
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a single iterable
    for i in product(range(10), tqdm_class=tqdm_auto):
        pass

    # Test with multiple iterables
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with multiple iterables and total
    for i in product(range(10), range(10), tqdm_class=tqdm_auto, total=100):
        pass

    # Test with multiple iterables and total
    for i in product(range(10), range(10), tqdm_class=tqdm_auto, total=100):
        pass

    # Test with multiple iterables

# Generated at 2022-06-18 11:11:50.517898
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_dict
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict_fmt
    from ..utils import format_dict_of_dicts_fmt
    from ..utils import format_dict_of_dicts
    from ..utils import format_dict_values

# Generated at 2022-06-18 11:12:00.281098
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:12:08.758876
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Test product generator
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_auto):
        """
        Test product list
        """
        list(product(*iterables, tqdm_class=tqdm_class))

    def test_product_numpy(iterables, tqdm_class=tqdm_auto):
        """
        Test product numpy
        """

# Generated at 2022-06-18 11:12:18.250889
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof
    from itertools import product as itertools_product

    # Test 1
    print("Test 1:")
    t0 = time()
    for i in product(range(10), range(10), range(10)):
        pass
    t1 = time()
    for i in itertools_product(range(10), range(10), range(10)):
        pass
    t2 = time()
    print("tqdm: %s" % format_interval(t1 - t0))
    print("itertools: %s" % format_interval(t2 - t1))
   

# Generated at 2022-06-18 11:12:26.362409
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    # Test with a list of lists
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = ['x', 'y', 'z']
    d = [a, b, c]
    for i in product(d):
        pass

    # Test with a generator of lists
    def gen():
        for i in d:
            yield i
    for i in product(gen()):
        pass

    # Test with a list of generators
    def gen2():
        for i in c:
            yield i
    for i in product(a, b, gen2()):
        pass

    # Test with a generator of

# Generated at 2022-06-18 11:12:35.698457
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     mininterval=0.1):
        time.sleep(0.01)

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:12:43.555921
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("Test 1:", end=' ')
    start_time = time.time()

# Generated at 2022-06-18 11:12:52.314621
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:13:02.408524
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    dt = time.time() - t0
    print("dt = {0}".format(format_interval(dt)))
    print("")

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:13:10.784459
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string

    # Test basic functionality
    assert list(product(range(3), repeat=2)) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-18 11:13:18.974681
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(iterables, **kwargs):
        """
        Test product generator
        """
        for _ in product(*iterables, **kwargs):
            pass

    def test_product_list(iterables, **kwargs):
        """
        Test product list
        """
        list(product(*iterables, **kwargs))

    def test_product_set(iterables, **kwargs):
        """
        Test product set
        """
        set(product(*iterables, **kwargs))

    def test_product_tuple(iterables, **kwargs):
        """
        Test product tuple
        """

# Generated at 2022-06-18 11:13:28.406383
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    # Test with a simple list
    l = list(range(10))
    l_prod = list(product(l, l, l))
    assert len(l_prod) == len(l) ** 3
    assert l_prod[0] == (0, 0, 0)
    assert l_prod[-1] == (9, 9, 9)

    # Test with a huge list
    l = list(range(1000))
    l_prod = list(product(l, l, l))
    assert len(l_prod) == len(l) ** 3
    assert l_

# Generated at 2022-06-18 11:13:36.913137
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_json
    from ..utils import format_dict_pretty_json
    from ..utils import format_dict_yaml

# Generated at 2022-06-18 11:13:43.288589
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint

    def rand_str(length):
        return ''.join(chr(randint(0, 255)) for _ in range(length))

    def rand_list(length):
        return [rand_str(randint(0, 255)) for _ in range(length)]

    def rand_dict(length):
        return dict((rand_str(randint(0, 255)), rand_str(randint(0, 255)))
                    for _ in range(length))

    def rand_tuple(length):
        return tuple(rand_str(randint(0, 255)) for _ in range(length))


# Generated at 2022-06-18 11:13:53.077170
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test 1
    for i in product(range(10), range(10)):
        pass

    # Test 2
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 4", leave=True):
        pass

    # Test 5

# Generated at 2022-06-18 11:14:02.005010
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval

    # Test 1
    print("Test 1:")
    print("  - Test product with no iterables")
    print("  - Expected result: 1")
    print("  - Result: {}".format(list(product())))
    print("  - Test product with one iterable")
    print("  - Expected result: [('a',), ('b',), ('c',)]")
    print("  - Result: {}".format(list(product(['a', 'b', 'c']))))
    print("  - Test product with two iterables")

# Generated at 2022-06-18 11:14:08.893527
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_inner(iterables, **kwargs):
        """
        Unit test for function product
        """
        print("\nTesting `product` with iterables:", iterables)
        print("kwargs:", kwargs)
        t0 = time.time()
        res = list(product(*iterables, **kwargs))
        t1 = time.time()
        print("\nResult:", res)
        print("\nTime: %.3f s" % (t1 - t0))
        print("\nMemory usage: %s" % format_sizeof(sys.getsizeof(res)))


# Generated at 2022-06-18 11:14:17.484758
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_unicode
    from ..utils import format_dict_unicode_fmt
    from ..utils import format_sizeof_fmt_str

# Generated at 2022-06-18 11:14:25.326957
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_inner(iterables, tqdm_class=tqdm_auto):
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_inner_it(iterables, tqdm_class=tqdm_auto):
        for i in itertools.product(*iterables):
            pass

    def test_product_inner_tqdm(iterables, tqdm_class=tqdm_auto):
        for i in tqdm_class(itertools.product(*iterables)):
            pass


# Generated at 2022-06-18 11:14:33.897168
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percentage
    from ..utils import format_time
    from ..utils import format_interval_short
    from ..utils import format_interval_long
    from ..utils import format_interval_full
    from ..utils import format_interval_full_long
   

# Generated at 2022-06-18 11:14:46.309715
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_

# Generated at 2022-06-18 11:14:55.738306
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test basic functionality
    assert list(product(range(3), repeat=2)) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (2, 0), (2, 1), (2, 2)]

    # Test total

# Generated at 2022-06-18 11:15:03.422800
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_to_file
    from .utils import FormatCustomText
    from .std import tqdm

    with closing(tqdm(total=10, file=FormatCustomText(
            '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'))) as pbar:
        for i in product(range(10), range(10), range(10), tqdm_class=tqdm,
                         tqdm_kwargs=dict(file=pbar.file, mininterval=0)):
            pass


# Generated at 2022-06-18 11:15:09.907309
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    from .utils import FormatMixin
    from .utils import StringIO

    class TestProduct(FormatMixin):
        def __init__(self, *args, **kwargs):
            super(TestProduct, self).__init__(*args, **kwargs)
            self.size = 0

        def update(self, n=1):
            self.size += n

    def test_product_with_tqdm(tqdm_class=TestProduct):
        """
        Unit test for function product with tqdm.
        """

# Generated at 2022-06-18 11:15:17.435721
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with tqdm_class=tqdm.tqdm
    t = time.time()
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto):
        pass
    print("product(range(1000), range(1000), range(1000))")
    print("\t-> %s" % format_interval(time.time() - t))
    print("\t-> %s" % format_sizeof(sys.getsizeof(i)))

    # Test with tqdm_class=tqdm.tqdm_gui

# Generated at 2022-06-18 11:15:27.070300
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    # Test with a single iterable
    for i in product(range(10)):
        assert i == (i,)

    # Test with multiple iterables
    for i in product(range(10), range(10), range(10)):
        assert len(i) == 3

    # Test with a single iterable and a total
    for i in product(range(10), total=10):
        assert i == (i,)

    # Test with multiple iterables and a total
    for i in product(range(10), range(10), range(10), total=1000):
        assert len(i) == 3



# Generated at 2022-06-18 11:15:36.337683
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_unicode
    from ..utils import format_dict_unicode_fmt
    from ..utils import format_dict_html
    from ..utils import format_

# Generated at 2022-06-18 11:15:42.138322
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  - Iterating over a product of 3 lists of length 10, 100, 1000")
    print("  - Expecting to iterate over a total of 10*100*1000 = 1e6 items")
    print("  - Expecting to iterate over a total of 1e6 items")
    print("  - Expecting to iterate over a total of 1e6 items")
    print("  - Expecting to iterate over a total of 1e6 items")
    print("  - Expecting to iterate over a total of 1e6 items")

# Generated at 2022-06-18 11:15:51.959859
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_fmtm
    from ..utils import format_interval_fmtm
    from ..utils import format_meter_fmtm
    from ..utils import format_timespan

# Generated at 2022-06-18 11:16:00.066459
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import tempfile
    import shutil
    import random

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write random data to the temporary file
    with open(tmpfile, 'wb') as f:
        for _ in range(10000):
            f.write(os.urandom(random.randint(1, 100)))

    # Get the file size
    file_size = os.path.getsize(tmpfile)

    # Get the file size in human readable format

# Generated at 2022-06-18 11:16:09.581696
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    with StringIO() as our_file:
        for _ in product(range(100), range(100), range(100),
                         tqdm_class=tqdm_auto, file=our_file):
            pass
        output = our_file.getvalue()
    assert output == '100%|██████████| 1000000/1000000 [00:00<00:00, 5191470.13it/s]\n'

    # Test

# Generated at 2022-06-18 11:16:19.093510
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("\nTest 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10)):
        pass
    t1 = time.time()
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("\nTest 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:16:28.246097
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import trange
    from .utils import format_sizeof
    from .std import time

    # Test 1
    for i in product(range(10), range(10), range(10), tqdm_class=trange):
        pass
    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=trange, total=1000):
        pass
    # Test 3
    for i in product(range(10), range(10), range(10),
                     tqdm_class=trange, total=1000,
                     desc="Test 3", leave=True):
        pass
    # Test 4

# Generated at 2022-06-18 11:16:35.550848
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_percentage
    from ..utils import format_count
    from ..utils import format_rate
    from ..utils import format_time
    from ..utils import format_length
    from ..utils import format_interval_short
    from ..utils import format_interval_long
    from ..utils import format_interval_full


# Generated at 2022-06-18 11:16:44.891968
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    try:
        import numpy as np
    except ImportError:
        np = None

    def test_product_generator(iterables, total):
        """
        Unit test for function product generator
        """
        for i in product(*iterables):
            pass

    def test_product_list(iterables, total):
        """
        Unit test for function product list
        """
        list(product(*iterables))

    def test_product_numpy(iterables, total):
        """
        Unit test for function product numpy
        """
        np.array(list(product(*iterables)))


# Generated at 2022-06-18 11:16:53.129786
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import random
    import time
    import gc
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_num
    from ..utils import format_meter
    from ..utils import format_speed
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_num
    from ..utils import format_meter
    from ..utils import format_speed
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_num
    from ..utils import format

# Generated at 2022-06-18 11:17:01.212708
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string
    import tempfile
    import os

    # Test 1: test product with a single iterable
    with tempfile.TemporaryFile(mode='w+') as f:
        sys.stdout = f
        for i in product(range(10)):
            pass
        f.seek(0)
        assert f.read() == '10it [00:00, ?it/s]\n'

    # Test 2: test product with a single iterable and a total
    with tempfile.TemporaryFile(mode='w+') as f:
        sys.stdout = f

# Generated at 2022-06-18 11:17:09.908060
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number

# Generated at 2022-06-18 11:17:17.698357
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from itertools import product
    from random import randint
    from random import shuffle

    # Test 1
    t0 = time()
    for i in product(range(10), range(10), range(10), range(10), range(10)):
        pass
    t1 = time()
    print("itertools.product(range(10), range(10), range(10), range(10), range(10)):")
    print("\t", format_interval(t1 - t0))
    print("\t", format_sizeof(getsizeof(i)))

    # Test 2
    t0 = time()
   

# Generated at 2022-06-18 11:17:26.101816
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 3",
                     leave=False):
        pass

    # Test 4
   

# Generated at 2022-06-18 11:17:37.729490
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import TestCase
    import numpy as np
    from .utils import FormatCustomText

    class TestProduct(TestCase):
        def test_product(self):
            """
            Test for function product.
            """
            # Test for function product
            self.assertEqual(
                list(product(range(5), range(5))),
                list(itertools.product(range(5), range(5))))
            self.assertEqual(
                list(product(range(5), range(5), tqdm_class=FormatCustomText)),
                list(itertools.product(range(5), range(5))))

# Generated at 2022-06-18 11:17:46.806460
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .utils import FormatCustom
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_timesofar
    from .utils import format_transferrate
    from .utils import format_wall
    from .utils import format_wall_short
    from .utils import format_wall_short_desc
    from .utils import format_wall_short_space
    from .utils import format_wall_space
    from .utils import format_wall_space_desc
    from .utils import format_wall_space_short
    from .utils import format_wall_space_short_desc
    from .utils import format_wall_space_short_space

# Generated at 2022-06-18 11:17:56.257500
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    print()

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        pass
    print()

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:18:05.629362
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test for product
    for iterable in [range(10), np.arange(10)]:
        for repeat in [1, 2, 3]:
            for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
                t = tqdm_class(iterable, total=len(iterable) ** repeat,
                               desc="product(range(10), repeat=%d)" % repeat)
                for i in product(iterable, repeat=repeat, tqdm_class=tqdm_class):
                    t.update()
                t.close()

    # Test for product with nested iter

# Generated at 2022-06-18 11:18:14.529525
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
   

# Generated at 2022-06-18 11:18:23.094910
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a small number of iterations
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test product"):
        pass

    # Test with a large number of iterations
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="Test product"):
        pass

    # Test with a large number of iterations and a large format

# Generated at 2022-06-18 11:18:26.994425
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import tqdm
    for i in product(range(10), range(10), tqdm_class=tqdm):
        pass

# Generated at 2022-06-18 11:18:35.921012
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test(iterables, **tqdm_kwargs):
        """
        Unit test for function product
        """
        t0 = time.time()
        for _ in product(*iterables, **tqdm_kwargs):
            pass
        t1 = time.time()

# Generated at 2022-06-18 11:18:44.709495
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    # Test with tqdm(total=None)
    t = tqdm_auto(total=None)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test with tqdm(total=1000)
    t = tqdm_auto(total=1000)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test with tqdm(total=100)

# Generated at 2022-06-18 11:18:53.126780
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False):
        pass
    t1 = time.time()
    print("Elapsed time:", format_interval(t1 - t0))
    print("Memory usage:", format_sizeof(sys.getsizeof(i)))
    print()

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:19:15.876359
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test 1: simple product
    print("\nTest 1: simple product")
    a = range(10)
    b = range(10)
    c = range(10)
    d = range(10)
    e = range(10)
    f = range(10)
    g = range(10)
    h = range(10)
    i = range(10)
    j = range(10)
    k = range(10)
    l = range(10)
    m = range(10)
    n = range(10)
    o = range(10)
    p = range(10)
    q

# Generated at 2022-06-18 11:19:22.767584
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test basic functionality
    assert list(product(range(3), range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1)]

# Generated at 2022-06-18 11:19:26.599486
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_gen(iterables):
        for i in product(*iterables):
            yield i

    def test_product_gen_with_tqdm(iterables):
        for i in product(*iterables, tqdm_class=tqdm_auto):
            yield i

    def test_product_gen_with_tqdm_leave(iterables):
        for i in product(*iterables, tqdm_class=tqdm_auto, leave=True):
            yield i


# Generated at 2022-06-18 11:19:32.843811
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(product(range(10), range(10), range(10)),
                  desc="Test 1", leave=False)
    for _ in t:
        pass

    # Test 2
    t = tqdm_auto(product(range(10), range(10), range(10)),
                  desc="Test 2", leave=False)
    for _ in t:
        time.sleep(0.01)

    # Test 3
    t = tqdm_auto(product(range(10), range(10), range(10)),
                  desc="Test 3", leave=False)
    for _ in t:
        time.sleep

# Generated at 2022-06-18 11:19:42.626535
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import random

    # Test for product
    print("\nTesting function product")
    print("========================")
    print("Generating random list of lists")
    n = random.randint(1, 5)
    print("n =", n)
    l = []
    for i in range(n):
        m = random.randint(1, 5)
        print("m =", m)
        l.append([random.randint(1, 5) for _ in range(m)])
    print("l =", l)
    print("Generating product")
    p = list(product(*l))
    print("p =", p)

# Generated at 2022-06-18 11:19:49.234999
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time

    # Test with numpy arrays
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)

# Generated at 2022-06-18 11:19:57.841918
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

# Generated at 2022-06-18 11:20:07.914415
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_percentage
    from ..utils import format_length
    from ..utils import format_time
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_number_fmt