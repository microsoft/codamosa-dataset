

# Generated at 2022-06-18 11:10:12.775981
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from ..utils import _range

    # Test 1
    with tqdm_auto(total=None) as t:
        for i in product(_range(10), _range(10)):
            sleep(random() / 10)
            t.update()
    assert t.n == 100
    assert t.total is None

    # Test 2
    with tqdm_auto(total=None) as t:
        for i in product(_range(10), _range(10), _range(10)):
            sleep(random() / 10)
            t.update()

# Generated at 2022-06-18 11:10:23.238423
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.cls):
            pass
        tc.assertEqual(tc.n, 100)
        tc.assertEqual(tc.smoothing, 1)
        tc.assertEqual(tc.dynamic_ncols, True)
        tc.assertEqual(tc.leave, True)
        tc.assertEqual(tc.miniters, 1)
        tc.assertEqual(tc.ascii, False)
        tc.assertEqual(tc.desc, None)
        tc.assertEqual(tc.postfix, None)
        tc.assertEqual(tc.unit, None)
        tc.assertEqual

# Generated at 2022-06-18 11:10:34.356530
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:10:42.323179
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  * itertools.product(range(10), repeat=3)")
    print("  * tqdm(itertools.product(range(10), repeat=3))")
    print("  * tqdm.product(range(10), repeat=3)")
    print("  * tqdm.product(range(10), repeat=3, tqdm_class=tqdm.tqdm)")
    print("  * tqdm.product(range(10), repeat=3, tqdm_class=tqdm.tqdm_notebook)")

# Generated at 2022-06-18 11:10:53.520858
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .tests import pretest_posttest_pass

    class TestProduct(FormatMixin):
        def test_product(self):
            """
            Unit test for function product.
            """
            from ..utils import format_sizeof
            from .utils import FormatMixin
            from .tests import pretest_posttest_pass

            class TestProduct(FormatMixin):
                def test_product(self):
                    """
                    Unit test for function product.
                    """
                    from ..utils import format_sizeof
                    from .utils import FormatMixin
                    from .tests import pretest_posttest_pass


# Generated at 2022-06-18 11:11:02.805112
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

# Generated at 2022-06-18 11:11:06.768045
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.cls):
            pass
        tc.assertEqual(tc.sp, tc.total)

# Generated at 2022-06-18 11:11:13.098449
# Unit test for function product
def test_product():
    """Test for function product"""
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        with tqdm_auto(total=None) as t:
            for i in product(range(10), range(10), tqdm_class=t.__class__):
                tc.assertEqual(len(i), 2)
                tc.assertEqual(i[0], i[1])
                t.update()

# Generated at 2022-06-18 11:11:21.856159
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    t = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    t = time.time() - t
    print("Test 1:", format_interval(t))

    # Test 2
    t = time.time()
    for i in itertools.product(range(10), range(10), range(10)):
        pass
    t = time.time() - t
    print("Test 2:", format_interval(t))

    # Test 3
    t = time.time()

# Generated at 2022-06-18 11:11:31.199677
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format

# Generated at 2022-06-18 11:11:39.985827
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(3), repeat=3):
        print(i)
    print()

    # Test 2
    print("Test 2:")
    for i in product(range(3), repeat=3, tqdm_class=tqdm_auto):
        print(i)
    print()

    # Test 3
    print("Test 3:")
    for i in product(range(3), repeat=3, tqdm_class=tqdm_auto,
                     ascii=True, desc="Test 3"):
        print(i)
    print()

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:11:48.824271
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i

# Generated at 2022-06-18 11:11:58.567418
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_inner(iterables, total):
        """
        Unit test for function product
        """
        for tqdm_class in [tqdm_auto, tqdm_auto.tqdm, tqdm_auto.trange]:
            t = tqdm_class(total=total)
            for i in product(*iterables, tqdm_class=tqdm_class):
                t.update()
            t.close()

    # Test 1
    iterables = [range(10)] * 10
    total = 1
    for i in iterables:
        total *= len(i)

# Generated at 2022-06-18 11:12:07.075618
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter

# Generated at 2022-06-18 11:12:16.198593
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=1, unit='B', unit_scale=True, miniters=1,
                  file=sys.stdout)
    for i in product(range(1000), repeat=2, tqdm_class=tqdm_auto):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=1, unit='B', unit_scale=True, miniters=1,
                  file=sys.stdout)
    for i in product(range(1000), repeat=2, tqdm_class=tqdm_auto):
        pass
    t.close

# Generated at 2022-06-18 11:12:24.764772
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_html_fmt
    from ..utils import format_dict_json
    from ..utils import format_dict_

# Generated at 2022-06-18 11:12:33.827844
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_inner(iterables, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    # Test with tqdm_class=None
    test_product_inner([range(100), range(100), range(100)], None)

    # Test with tqdm_class=tqdm.auto.tqdm
    test_product_inner([range(100), range(100), range(100)], tqdm_auto)

    # Test with tqdm_class=tqdm.tqdm

# Generated at 2022-06-18 11:12:42.026209
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.1)

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.1)

    # Test 3
    print("\nTest 3:")

# Generated at 2022-06-18 11:12:49.381604
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number

# Generated at 2022-06-18 11:12:58.545621
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    def product(*iterables):
        for i in itertools_product(*iterables):
            yield i

    def test_product_size(n, m):
        """
        Test that the size of the output of `product` is the same as the
        size of the output of `itertools.product`.
        """
        a = list(product(range(n), range(m)))
        b = list(itertools_product(range(n), range(m)))
        assert getsizeof(a) == getsizeof(b)


# Generated at 2022-06-18 11:13:09.747380
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    import random
    import sys

    def test_product_numpy(iterables):
        """
        Equivalent of `itertools.product` for numpy arrays.
        """
        arrays = [np.asarray(x) for x in iterables]
        dtype = np.result_type(*arrays)
        n = np.prod([x.size for x in arrays])
        if n > sys.maxsize:
            raise ValueError("Size exceeds C int size")
        out = np.zeros([n, len(arrays)], dtype=dtype)
        m = n // arrays[0].size

# Generated at 2022-06-18 11:13:16.758644
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter


# Generated at 2022-06-18 11:13:24.222370
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

# Generated at 2022-06-18 11:13:34.272612
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_inner(iterables, tqdm_class):
        """Test for function product"""
        for _ in tqdm_class.product(*iterables):
            pass

    # Test for memory leaks
    # https://github.com/tqdm/tqdm/issues/349
    # https://github.com/tqdm/tqdm/issues/350
    # https://github.com/tqdm/tqdm/issues/351
    # https://github.com/tqdm/tqdm/issues/352
    # https://github.com/tqdm/tqdm/issues/353
    # https://github.com/tqdm/tqdm/issues/354
   

# Generated at 2022-06-18 11:13:41.211961
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_

# Generated at 2022-06-18 11:13:51.377254
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import os
    import time
    import random

    # Test with a simple iterator
    for i in product(range(10), range(10)):
        pass

    # Test with a generator
    for i in product(range(10), range(10)):
        yield i

    # Test with a generator
    for i in product(range(10), range(10)):
        yield i

    # Test with a generator
    for i in product(range(10), range(10)):
        yield i

    # Test with a generator
    for i in product(range(10), range(10)):
        yield i

    # Test with a generator
    for i in product(range(10), range(10)):
        yield

# Generated at 2022-06-18 11:14:00.667716
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  * Generate all possible combinations of 2 lists of 3 elements")
    print("  * Display the size of the generated list")
    print("  * Display the time taken to generate the list")
    print("")
    start_time = time.time()
    list_of_lists = [range(3), range(3)]
    list_of_combinations = list(product(*list_of_lists))
    print("Size of list of combinations: {}".format(
        format_sizeof(sys.getsizeof(list_of_combinations))))

# Generated at 2022-06-18 11:14:05.130888
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    from numpy import array

    for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
        assert_array_equal(
            array(list(product(range(10), range(10), tqdm_class=tqdm_class))),
            array(list(itertools.product(range(10), range(10)))))

# Generated at 2022-06-18 11:14:14.629765
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import io
    import os
    import tempfile
    import shutil

    def test_product_generator(tqdm_class):
        """
        Unit test for function product
        """
        # Test 1
        with tqdm_class(total=None) as t:
            for _ in product(range(10), repeat=2):
                t.update()
        assert t.n == 100

        # Test 2
        with tqdm_class(total=None) as t:
            for _ in product(range(10), repeat=2):
                t.update()
        assert t.n == 100

        # Test 3

# Generated at 2022-06-18 11:14:21.412384
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = time.time()
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="1st loop"):
        pass
    print("\n1st loop done in %s." % format_interval(time.time() - t))

    # Test 2
    t = time.time()
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="2nd loop", leave=False):
        pass

# Generated at 2022-06-18 11:14:31.345228
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range
    from .tests_tqdm import pretest_posttest, closing, StringIO

    @with_setup(pretest_posttest)
    def test():
        """Test product"""
        with closing(StringIO()) as our_file:
            for _ in product(_range(10), _range(10), _range(10),
                             tqdm_class=tqdm_auto, file=our_file):
                pass
            assert our_file.getvalue() == '100%|██████████| 1000/1000 [00:00<00:00, '\
                '?it/s]\n'

    test()

# Generated at 2022-06-18 11:14:38.855299
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test 1
    print("Test 1:", end=' ')
    sys.stdout.flush()
    a = list(range(10))
    b = list(range(10))
    c = list(range(10))
    d = list(range(10))
    e = list(range(10))
    f = list(range(10))
    g = list(range(10))
    h = list(range(10))
    i = list(range(10))
    j = list(range(10))
    k = list(range(10))
    l = list(range(10))

# Generated at 2022-06-18 11:14:43.856873
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    def test_product_1():
        """
        Unit test for function product
        """
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="test_product_1"):
            pass

    def test_product_2():
        """
        Unit test for function product
        """
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="test_product_2",
                         leave=False):
            pass

    def test_product_3():
        """
        Unit test for function product
        """


# Generated at 2022-06-18 11:14:52.690433
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    # Test simple product
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))

    # Test product with tqdm
    assert list(product(range(3), range(3), tqdm_class=tqdm_auto)) == list(itertools.product(range(3), range(3)))

    # Test product with tqdm and total
    assert list(product(range(3), range(3), tqdm_class=tqdm_auto, total=9)) == list(itertools.product(range(3), range(3)))

    # Test product with tqdm

# Generated at 2022-06-18 11:15:01.118171
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_sizeof_short_f

# Generated at 2022-06-18 11:15:06.469310
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assert_equal(tc.sp, tc.si)

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm,
                         mininterval=0.01):
            pass
        tc.assert_equal(tc.sp, tc.si)

# Generated at 2022-06-18 11:15:13.407727
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    # Test with a list
    lst = list(range(10))

    # Test with a tuple
    tup = tuple(range(10))

    # Test with a set
    st = set(range(10))

    # Test with a dictionary
    dct = dict(zip(range(10), range(10)))

    # Test with a string
    str = "abcdefghij"

    # Test with a range
    rng = range(10)

    # Test with a bytearray
    byt = bytearray(range(10))

    # Test with a memoryview
   

# Generated at 2022-06-18 11:15:21.630695
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    # Test 1
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10), range(10),
                     range(10), range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t = time.time() - t
    print("Test 1:", format_interval(t), format_sizeof(sys.getsizeof(i)))

    # Test 2
    t = time.time()

# Generated at 2022-06-18 11:15:32.298330
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin

    class TestProduct(FormatMixin):
        def test_product(self):
            """
            Unit test for function product.
            """
            for i in product(range(10), range(10), range(10),
                             tqdm_class=self.tqdm_class):
                pass
            for i in product(range(10), range(10), range(10),
                             tqdm_class=self.tqdm_class,
                             desc="test_product"):
                pass
            for i in product(range(10), range(10), range(10),
                             tqdm_class=self.tqdm_class,
                             total=1000):
                pass

# Generated at 2022-06-18 11:15:39.367374
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), tqdm_class=t.__class__):
        time.sleep(0.01)
    t.close()

    # Test 2
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), tqdm_class=t.__class__):
        time.sleep(0.01)
        if i == (5, 5):
            break
    t.close()

    # Test 3
    t = tqdm_auto(total=10)

# Generated at 2022-06-18 11:15:52.683021
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    def _test(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v,
              w, x, y, z, tqdm_class=tqdm_auto, **tqdm_kwargs):
        """
        Unit test for function product.
        """
        # Test 1

# Generated at 2022-06-18 11:16:00.694277
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:16:07.407171
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_

# Generated at 2022-06-18 11:16:16.650428
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:", end=' ')
    t0 = time.time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("OK. Time elapsed:", t1 - t0, "s")

    # Test 2
    print("Test 2:", end=' ')
    t0 = time.time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, mininterval=0.1):
        pass

# Generated at 2022-06-18 11:16:26.380428
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    for i in product(list_of_lists):
        pass

    # Test with a list of arrays
    list_of_arrays = [np.arange(10), np.arange(10), np.arange(10)]
    for i in product(list_of_arrays):
        pass

    # Test with a list of generators
    list_of_generators = [range(10), range(10), range(10)]
    for i in product(list_of_generators):
        pass

    # Test with a list

# Generated at 2022-06-18 11:16:34.164716
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    def test_product_inner(tqdm_class):
        for i in tqdm_class.product(range(10), range(10), range(10)):
            pass

    for tqdm_class in [tqdm_auto, tqdm_auto.tqdm, tqdm_auto.tqdm_gui]:
        test_product_inner(tqdm_class)

    # Test that the total is correctly computed

# Generated at 2022-06-18 11:16:42.617820
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_sizeof_short_fmt
    from ..utils import format

# Generated at 2022-06-18 11:16:51.351892
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("Test 1:")
    print("  - Test product() with a single iterable")
    print("  - Test product() with a single iterable and total=None")
    print("  - Test product() with a single iterable and total=0")
    print("  - Test product() with a single iterable and total=1")
    print("  - Test product() with a single iterable and total=2")
    print("  - Test product() with a single iterable and total=3")
    print("  - Test product() with a single iterable and total=4")

# Generated at 2022-06-18 11:16:59.577883
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string

    # Test 1
    print("Test 1:")
    print("  Generating random strings...")
    random.seed(0)
    n = 100
    m = 10
    iterables = [''.join(random.choice(string.ascii_lowercase)
                        for _ in range(m)) for _ in range(n)]
    print("  Testing itertools.product...")
    start = time.time()
    for i in itertools.product(*iterables):
        pass
    print("    Time elapsed: %s" % format_interval(time.time() - start))

# Generated at 2022-06-18 11:17:06.277438
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_inner(iterables, tqdm_class):
        """Unit test for function product"""
        t = tqdm_class(iterables, leave=False)
        for i in product(*iterables, tqdm_class=tqdm_class):
            t.update()
        t.close()

    # Test with a list of lists
    test_product_inner([[1, 2, 3], [4, 5, 6]], tqdm_auto)

    # Test with a list of generators
    test_product_inner([(i for i in range(10)), (i for i in range(10))],
                       tqdm_auto)

    #

# Generated at 2022-06-18 11:17:19.457717
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percentage
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_size
    from ..utils import format

# Generated at 2022-06-18 11:17:27.907803
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format

# Generated at 2022-06-18 11:17:31.151790
# Unit test for function product
def test_product():
    from .tests import TestCase, closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tc.tqdm_class):
            pass
        tc.assertEqual(tc.sp, tc.si)
        tc.assertEqual(tc.sp, 1000)

# Generated at 2022-06-18 11:17:36.378351
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    import random
    import string
    import time

    # Test 1:
    # Test with a simple product
    # (1, 2, 3) x (4, 5, 6)
    # Expected result:
    # [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = list(product(a, b))
    assert c == [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]

# Generated at 2022-06-18 11:17:39.925102
# Unit test for function product
def test_product():
    from .tests import TestCase, closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:17:48.482776
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint

    # Test 1
    print("Test 1:")
    start_time = time()
    total_size = 0
    for i in product(range(10), range(10), range(10), range(10), range(10)):
        total_size += getsizeof(i)
    print("\tTotal size:", format_sizeof(total_size))
    print("\tTotal time:", format_interval(time() - start_time))

    # Test 2
    print("Test 2:")
    start_time = time()
    total_size = 0

# Generated at 2022-06-18 11:17:58.397789
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:18:07.769740
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    for i in product(range(4), range(4), range(4), range(4), range(4),
                     tqdm_class=tqdm_auto, desc="test 1"):
        pass

    # Test 2
    for i in product(range(4), range(4), range(4), range(4), range(4),
                     tqdm_class=tqdm_auto, desc="test 2",
                     mininterval=0.5, miniters=1):
        pass

    # Test 3

# Generated at 2022-06-18 11:18:15.560106
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    def test_product_inner(iterables, **tqdm_kwargs):
        """
        Unit test for function product
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)

# Generated at 2022-06-18 11:18:20.723058
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    def test_product_inner(iterables, tqdm_class):
        """
        Unit test for function product
        """
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
        t = tqdm_class(total=total)
        for i in itertools.product(*iterables):
            t.update()
        t.close()

    def test_product_outer(iterables, tqdm_class):
        """
        Unit test for function product
        """

# Generated at 2022-06-18 11:18:40.335043
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        sys.stdout.write(".")
        sys.stdout.flush()

    # Test 4

# Generated at 2022-06-18 11:18:48.955049
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_inter

# Generated at 2022-06-18 11:18:56.667744
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:19:05.142666
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Test 1
    try:
        from itertools import product as itertools_product
    except ImportError:
        pass
    else:
        for i in range(5):
            a = list(range(random.randint(1, 10)))
            b = list(range(random.randint(1, 10)))
            c = list(range(random.randint(1, 10)))
            d = list(range(random.randint(1, 10)))
            e = list(range(random.randint(1, 10)))
            f = list(range(random.randint(1, 10)))

# Generated at 2022-06-18 11:19:12.184921
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    import random
    import string

    # Test 1
    print("Test 1:")
    print("  - Generate random strings")
    print("  - Compute cartesian product")
    print("  - Compute cartesian product with tqdm")
    print("  - Compare results")
    print("  - Compare performance")
    print("")
    random.seed(0)
    n = 10
    m = 10
    k = 10
    print("n = {0}".format(n))
    print("m = {0}".format(m))
    print("k = {0}".format(k))
    print

# Generated at 2022-06-18 11:19:20.682808
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with tqdm_class=tqdm.auto.tqdm
    with tqdm_auto(unit="B", unit_scale=True, unit_divisor=1024) as t:
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=tqdm_auto):
            pass
    assert t.n == 1000000000
    assert t.total == 1000000000
    assert t.unit == "B"
    assert t.unit_scale is True
    assert t.unit_divisor == 1024
    assert t.miniters == 1
    assert t.mininterval

# Generated at 2022-06-18 11:19:29.450427
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_inner(iterables, **kwargs):
        """
        Unit test for function product
        """
        print("\nTesting `product` with iterables = {!r}".format(iterables))
        print("kwargs = {!r}".format(kwargs))
        print("sys.version = {!r}".format(sys.version))
        print("sys.platform = {!r}".format(sys.platform))
        print("sys.maxsize = {!r}".format(sys.maxsize))
        print("sys.maxunicode = {!r}".format(sys.maxunicode))

# Generated at 2022-06-18 11:19:38.215511
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1")

# Generated at 2022-06-18 11:19:46.970559
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from ..auto import tqdm

    # Test basic product
    for i in product(range(3), range(4), range(5)):
        assert i == (0, 0, 0)
        break
    for i in tqdm(product(range(3), range(4), range(5))):
        assert i == (0, 0, 0)
        break

    # Test memory usage
    for i in product(range(1000), range(1000)):
        break
    assert format_sizeof(getsizeof(i)) == "0.0 KiB"
   

# Generated at 2022-06-18 11:19:56.320312
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_helper(iterables, total, **tqdm_kwargs):
        """
        Helper function for testing product
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
                t.update()

    # Test 1
    iterables = [range(10), range(10), range(10)]
    total = 1000
    t0 = time.time()