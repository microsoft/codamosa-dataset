

# Generated at 2022-06-18 11:10:17.394958
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:10:27.120404
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  - Iterate over a list of lists")
    print("  - Iterate over a list of lists with total")
    print("  - Iterate over a list of lists with total and dynamic_ncols")
    print("  - Iterate over a list of lists with total and dynamic_ncols=False")
    print("  - Iterate over a list of lists with total and dynamic_ncols=False and smoothing=0")
    print("  - Iterate over a list of lists with total and dynamic_ncols=False and smoothing=0 and mininterval=0")

# Generated at 2022-06-18 11:10:37.664008
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    dt = time.time() - t0
    print("dt = %s" % format_interval(dt))
    print("")

    # Test 2
    print("Test 2:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    dt = time.time() - t0


# Generated at 2022-06-18 11:10:44.272862
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with tqdm_class=tqdm.auto.tqdm
    t0 = time.time()
    for _ in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    dt = time.time() - t0
    print("product(range(10), range(10), range(10)) took %s"
          % format_interval(dt))
    print("Memory usage: %s" % format_sizeof(sys.getsizeof(list(product(
        range(10), range(10), range(10))))))

    # Test with tqdm_

# Generated at 2022-06-18 11:10:55.274618
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10)):
        pass
    t1 = time.time()
    print("\nTest 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))
    print("  Iterations: %d" % (10**4))

# Generated at 2022-06-18 11:11:04.466977
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import numpy as np

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("Test 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(np.prod(i) * 8))
    print("")

    # Test 2
    t0 = time.time()

# Generated at 2022-06-18 11:11:14.832395
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..tests import closing, closing_iter
    from ..utils import FormatCustomText

    with closing(FormatCustomText(desc='test', total=None)) as t:
        for i in product(range(10), range(10), tqdm_class=t.__class__):
            pass
        assert t.n == 100
        assert t.last_print_n == 100

    with closing(FormatCustomText(desc='test', total=None)) as t:
        for i in product(range(10), range(10), tqdm_class=t.__class__):
            pass
        assert t.n == 100
        assert t.last_print_n == 100


# Generated at 2022-06-18 11:11:23.056804
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar

# Generated at 2022-06-18 11:11:33.188501
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_inner(iterables, total, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass
        assert i == (total - 1,) * len(iterables)

    # Test with a large number of iterables
    test_product_inner(
        [range(2)] * 100,
        2 ** 100,
        tqdm_class=tqdm_auto)

    # Test with a large number of iterables
    test_product_inner(
        [range(2)] * 100,
        2 ** 100,
        tqdm_class=tqdm_auto)



# Generated at 2022-06-18 11:11:40.413900
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase, _range
    from .utils import closing, format_sizeof
    from .utils import StringIO, bytesIO
    from .utils import format_interval
    from .utils import time
    from .utils import Random
    from .utils import FakeTqdmFile
    from .utils import UnicodeIO
    from .utils import IS_PYTHON2
    from .utils import IS_WIN
    from .utils import IS_OSX
    from .utils import IS_LINUX
    from .utils import IS_POSIX
    from .utils import IS_LITTLE_ENDIAN
    from .utils import IS_64BIT
    from .utils import PY3
    from .utils import PY36
    from .utils import PY37

# Generated at 2022-06-18 11:11:51.324012
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    print("\nTesting function product...")
    print("Python version: %s" % sys.version)
    print("Python platform: %s" % sys.platform)
    print("")

    print("Testing with a list of lists")
    print("")
    print("Testing with a list of lists")
    print("")
    print("Testing with a list of lists")
    print("")
    print("Testing with a list of lists")
    print("")
    print("Testing with a list of lists")
    print("")
    print("Testing with a list of lists")
    print("")
    print("Testing with a list of lists")
    print("")
    print("Testing with a list of lists")

# Generated at 2022-06-18 11:12:00.984573
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_number_fmt
    from ..utils import format_time_fmt
    from ..utils import format_eta_fmt
    from ..utils import format_speed_fmt
    from ..utils import format_stats_fmt
    from ..utils import format_dict
   

# Generated at 2022-06-18 11:12:09.657999
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys


# Generated at 2022-06-18 11:12:18.882002
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import closing
    from .utils import StringIO

    class FormatWrap(FormatWrapBase):
        def __init__(self, *args, **kwargs):
            super(FormatWrap, self).__init__(*args, **kwargs)
            self.format_dict['desc'] = 'desc'


# Generated at 2022-06-18 11:12:27.175146
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_gen(iterables):
        """
        Generator for testing product
        """
        for i in itertools.product(*iterables):
            yield i

    def test_product_tqdm(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for i in product(*iterables, **tqdm_kwargs):
            yield i

    def test_product_tqdm_total(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """

# Generated at 2022-06-18 11:12:36.326219
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_interval_short_fmt
    from ..utils import format_meter_short_fmt
    from ..utils import format_sizeof_fmt_str
    from ..utils import format_interval_fmt_str
    from ..utils import format_meter_fmt_str
    from ..utils import format_interval_short_fmt_str
    from ..utils import format

# Generated at 2022-06-18 11:12:44.044286
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    from . import trange

    def test_product_equivalence(iterables, tqdm_class):
        """
        Test that tqdm(itertools.product()) is equivalent to
        itertools.product() wrapped in tqdm.
        """
        # Test equivalence
        assert list(tqdm_class(itertools.product(*iterables))) == \
            list(product(*iterables, tqdm_class=tqdm_class))

        # Test that total is correct
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None

# Generated at 2022-06-18 11:12:52.905715
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.01)

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.01)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
       

# Generated at 2022-06-18 11:13:03.245313
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Test 1: simple product
    for i in product(range(10), repeat=2):
        pass

    # Test 2: product with tqdm
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        pass

    # Test 3: product with tqdm and total
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto, total=100):
        pass

    # Test 4: product with tqdm and total

# Generated at 2022-06-18 11:13:11.850314
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test with a single iterable
    for i in product(range(10)):
        assert i == (i,)

    # Test with multiple iterables
    for i in product(range(10), range(10), range(10)):
        assert i == (i[0], i[1], i[2])

    # Test with multiple iterables and a total
    for i in product(range(10), range(10), range(10), total=1000):
        assert i == (i[0], i[1], i[2])

    # Test with a generator

# Generated at 2022-06-18 11:13:24.019471
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_html_fmt
    from ..utils import format_dict_jupyter
    from ..utils import format_dict_jup

# Generated at 2022-06-18 11:13:33.493055
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a single iterable
    assert list(product(range(10))) == list(itertools.product(range(10)))

    # Test with multiple iterables
    assert list(product(range(10), range(10))) == list(itertools.product(range(10), range(10)))

    # Test with multiple iterables and a total
    assert list(product(range(10), range(10), total=100)) == list(itertools.product(range(10), range(10)))

    # Test with multiple iterables and a total

# Generated at 2022-06-18 11:13:40.967540
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test with tqdm_class=tqdm.auto.tqdm
    t0 = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("tqdm_class=tqdm.auto.tqdm:", format_interval(t1 - t0))

    # Test with tqdm_class=tqdm.tqdm
    t0 = time.time()

# Generated at 2022-06-18 11:13:51.006501
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    assert t.total == 1000
    assert t.n == 1000
    assert t.smoothing == 1
    assert t.dynamic_ncols
    t.close()

    # Test 2
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    assert t.total == 1000


# Generated at 2022-06-18 11:14:00.438908
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    from ..utils import _range

    # Test for function product
    print("Testing function product...", end='')
    sys.stdout.flush()
    t0 = time.time()

# Generated at 2022-06-18 11:14:07.761398
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    def test_product_size(n, m):
        """
        Test product size.
        """
        a = list(range(n))
        b = list(range(m))
        c = list(product(a, b))
        return getsizeof(c)

    def test_product_time(n, m):
        """
        Test product time.
        """
        a = list(range(n))
        b = list(range(m))
        t = time()
        c = list(product(a, b))
        return time() - t


# Generated at 2022-06-18 11:14:16.929254
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    import time
    import sys
    import io

    # Test with tqdm_class=tqdm.tqdm

# Generated at 2022-06-18 11:14:22.991695
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        pass

    # Test 3

# Generated at 2022-06-18 11:14:31.974718
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test for product
    print("Testing product...")
    t = time.time()
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="product(range(100), range(100), range(100))"):
        pass
    print("product(range(100), range(100), range(100)) took {}".format(
        format_interval(time.time() - t)))

    # Test for product
    print("Testing product...")
    t = time.time()

# Generated at 2022-06-18 11:14:39.447912
# Unit test for function product
def test_product():
    from .utils import FormatMixin
    from .utils import StringIO
    import sys

    class Tqdm(FormatMixin, tqdm_auto):
        def __init__(self, *args, **kwargs):
            super(Tqdm, self).__init__(*args, **kwargs)
            self.smoothing = 0.

    for n in range(1, 4):
        for m in range(1, 4):
            for k in range(1, 4):
                for l in range(1, 4):
                    with StringIO() as our_file:
                        sys.stdout = our_file
                        for _ in product(range(n), range(m), range(k),
                                         range(l), tqdm_class=Tqdm):
                            pass
                        sys.stdout = sys.__std

# Generated at 2022-06-18 11:14:58.390690
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time

    # Test 1
    t = time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, ascii=True):
        pass
    print("Test 1:", format_interval(time() - t))

    # Test 2
    t = time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, ascii=True, mininterval=0.1):
        pass

# Generated at 2022-06-18 11:15:05.909849
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .utils import closing_iter

    class Test(FormatMixin):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.total = 0

        def __call__(self, *args, **kwargs):
            self.total += 1
            return super(Test, self).__call__(*args, **kwargs)

    with closing_iter(Test()) as t:
        for i in product(range(10), range(10), range(10),
                         tqdm_class=t, ascii=True):
            pass
        assert t.total == 1000


# Generated at 2022-06-18 11:15:11.467921
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=100)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=100)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=100)

# Generated at 2022-06-18 11:15:19.030104
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("\nTest 1:")
    t0 = time.time()
    for i in product(range(10), repeat=3):
        pass
    t1 = time.time()
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("\nTest 2:")
    t0 = time.time()
    for i in product(range(10), repeat=3, tqdm_class=None):
        pass
    t1 = time.time()

# Generated at 2022-06-18 11:15:29.297014
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Test product generator
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)

# Generated at 2022-06-18 11:15:37.968189
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from copy import deepcopy
    from itertools import product
    from ..utils import _range

    # Test basic
    for i in product(_range(3), _range(4), _range(5)):
        pass

    # Test total
    for i in product(_range(3), _range(4), _range(5), tqdm_class=tqdm_auto):
        pass

    # Test memory
    for i in product(_range(3), _range(4), _range(5), tqdm_class=tqdm_auto):
        pass

    # Test dynamic total

# Generated at 2022-06-18 11:15:47.551614
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test 1
    print('Test 1')
    print('------')
    start = time.time()
    for i in product(range(100), range(100), range(100), range(100),
                     tqdm_class=tqdm_auto):
        pass
    end = time.time()
    print('Elapsed time: {}'.format(format_interval(end - start)))
    print('\n')

    # Test 2
    print('Test 2')
    print('------')
    start = time.time()

# Generated at 2022-06-18 11:15:56.605339
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .utils import FormatWrapBase
    from .utils import closing
    from .utils import StringIO
    import sys

    class FormatWrap(FormatWrapBase):
        def __init__(self, *args, **kwargs):
            super(FormatWrap, self).__init__(*args, **kwargs)
            self.n = 0

        def __iter__(self):
            return self

        def __next__(self):
            self.n += 1
            if self.n > 5:
                raise StopIteration
            return self.n

        next = __next__


# Generated at 2022-06-18 11:16:03.999958
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1")
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10)):
        t.update()
    t.close()

    # Test 2
    print("Test 2")
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        t.update()
    t.close()

    # Test 3
    print("Test 3")
    t = tqdm_auto(total=10)

# Generated at 2022-06-18 11:16:10.388192
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=False):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     ascii=True):
        pass

    # Test 4
    print("Test 4:")


# Generated at 2022-06-18 11:16:35.826177
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("Test 1:")
    print("  Iterating over a product of two lists of length 10")
    print("  with no tqdm_class specified")
    print("  (should be equivalent to itertools.product):")
    start_time = time.time()
    for i in product(range(10), range(10)):
        pass
    print("  Elapsed time: %s" % format_interval(time.time() - start_time))

    # Test 2
    print("Test 2:")
    print("  Iterating over a product of two lists of length 10")

# Generated at 2022-06-18 11:16:45.234847
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test with a large number of iterations
    N = 1000000
    t0 = time.time()
    for _ in product(range(N), range(N), range(N)):
        pass
    dt = time.time() - t0
    print("product(range(%d), range(%d), range(%d))" % (N, N, N))
    print("\t-> %s iterations in %s" % (format_sizeof(N ** 3),
                                        format_interval(dt)))

# Generated at 2022-06-18 11:16:53.489373
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_inner(iterables, total):
        """Test for function product"""
        # Test with tqdm
        for i in product(*iterables):
            pass
        # Test with tqdm_gui
        for i in product(*iterables, tqdm_class=tqdm_auto.tqdm_gui):
            pass
        # Test with tqdm_notebook
        for i in product(*iterables, tqdm_class=tqdm_auto.tqdm_notebook):
            pass
        # Test with tqdm_pandas

# Generated at 2022-06-18 11:17:01.537666
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    # Test with a list
    lst = list(range(10))

    # Test with a tuple
    tup = tuple(range(10))

    # Test with a set
    st = set(range(10))

    # Test with a dict
    dct = dict(zip(range(10), range(10)))

    # Test with a string
    strng = "abcdefghij"

    # Test with a range
    rng = range(10)

    # Test with a bytes
    byts = b"abcdefghij"

    # Test with a bytearray
    byt

# Generated at 2022-06-18 11:17:10.590314
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)
    m = np.arange(10)
    n = np

# Generated at 2022-06-18 11:17:18.157248
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), range(10), range(10)):
        time.sleep(0.01)

    # Test 3
    print("\nTest 3:")
    for i in product(range(10), range(10), range(10)):
        sys.stderr.write("\r{}".format(i))
        sys.stderr.flush()
        time.sleep(0.01)

    # Test 4

# Generated at 2022-06-18 11:17:26.532475
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        tc.assertEqual(
            list(product(range(3), repeat=2)),
            list(itertools.product(range(3), repeat=2)))
        tc.assertEqual(
            list(product(range(3), repeat=2, tqdm_class=None)),
            list(itertools.product(range(3), repeat=2)))
        tc.assertEqual(
            list(product(range(3), repeat=2, tqdm_class=tqdm_auto)),
            list(itertools.product(range(3), repeat=2)))

# Generated at 2022-06-18 11:17:33.174957
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_unicode
    from ..utils import format_dict_unicode_fmt
    from ..utils import format_sizeof_unicode

# Generated at 2022-06-18 11:17:41.114116
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10)):
        t.update()
    assert t.n == 1000

    # Test 2
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10)):
        t.update()
    assert t.n == 1000

    # Test 3
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10)):
        t.update()
    assert t.n == 1000

# Generated at 2022-06-18 11:17:49.730127
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import numpy as np

    # Test 1
    print("Test 1:")
    print("  - itertools.product(range(10), range(10), range(10))")
    print("  - tqdm(itertools.product(range(10), range(10), range(10)))")
    print("  - tqdm.product(range(10), range(10), range(10))")
    print("  - tqdm.product(range(10), range(10), range(10), total=1000)")

# Generated at 2022-06-18 11:18:35.577830
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    for i in product(range(10), repeat=2):
        print(i)

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)

    # Test 3
    print("\nTest 3:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)

    # Test 4
    print("\nTest 4:")

# Generated at 2022-06-18 11:18:44.139047
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    start_time = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    print("\tElapsed:", format_interval(time.time() - start_time))

    # Test 2
    print("Test 2:")
    start_time = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("\tElapsed:", format_interval(time.time() - start_time))

    # Test 3
   

# Generated at 2022-06-18 11:18:52.467153
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6]]
    for i in product(list_of_lists):
        assert i == (1, 4) or i == (1, 5) or i == (1, 6) or \
               i == (2, 4) or i == (2, 5) or i == (2, 6) or \
               i == (3, 4) or i == (3, 5) or i == (3, 6)

    # Test with a list of lists and a list of tuples

# Generated at 2022-06-18 11:18:59.050944
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        tc.assertEqual(list(product(range(3), repeat=2)),
                       list(itertools.product(range(3), repeat=2)))
        tc.assertEqual(list(product(range(3), repeat=2, tqdm_class=None)),
                       list(itertools.product(range(3), repeat=2)))
        tc.assertEqual(list(product(range(3), repeat=2, tqdm_class=tqdm_auto)),
                       list(itertools.product(range(3), repeat=2)))

# Generated at 2022-06-18 11:19:07.538325
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product as itertools_product

    def product(*iterables, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1

# Generated at 2022-06-18 11:19:10.746063
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import sys
    import random
    from .utils import FormatMixin
    from .utils import StringIO

    class TestProduct(FormatMixin):
        def __init__(self, *args, **kwargs):
            super(TestProduct, self).__init__(*args, **kwargs)
            self.size = 0
            self.n = 0

        def __call__(self, *args, **kwargs):
            self.size += sys.getsizeof(args)
            self.n += 1
            return args

    class TestProduct2(TestProduct):
        def __call__(self, *args, **kwargs):
            self.size += sys.getsizeof(args)
            self.n += 1
            return args[0]


# Generated at 2022-06-18 11:19:14.152092
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..std import tqdm

    with tqdm(product(range(3), range(3), range(3)),
              desc="test_product",
              bar_format=FormatCustomText('{desc}: {percentage:3.0f}%|{bar}|')) as t:
        for _ in t:
            pass
    assert t.n == 27
    assert t.total == 27
    assert t.last_print_n == 27
    assert t.last_print_refresh_time >= 0.1
    assert t.last_print_t >= 0.1
    assert t.last_print_n_displayed == 27


# Generated at 2022-06-18 11:19:22.541545
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    def test(iterables, tqdm_class=tqdm_auto, **tqdm_kwargs):
        """
        Test function for function product.
        """
        print("\nTesting `product` with {0}".format(tqdm_class))
        print("\n".join(map(str, iterables)))
        t0 = time.time()
        for i in product(*iterables, tqdm_class=tqdm_class, **tqdm_kwargs):
            pass
        t1 = time.time()
        print("\n".join(map(str, iterables)))

# Generated at 2022-06-18 11:19:30.493955
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test with a generator
    gen = (i for i in range(100))
    for i in product(gen, tqdm_class=tqdm_auto):
        pass

    # Test with a generator
    gen = (i for i in range(100))
    for i in product(gen, tqdm_class=tqdm_auto, total=100):
        pass

    # Test with a generator
    gen = (i for i in range(100))
    for i in product(gen, tqdm_class=tqdm_auto, total=100, mininterval=0.1):
        pass

    # Test

# Generated at 2022-06-18 11:19:35.640026
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    print("  * Generate a list of all possible combinations of a list of lists")
    print("  * Show the size of the list")
    print("  * Show the time it takes to generate the list")
    print("  * Show the time it takes to generate the list with tqdm")
    print("  * Show the time it takes to generate the list with tqdm.product")
    print("  * Show the time it takes to generate the list with tqdm.product and disable")
    print("  * Show the time it takes to generate the list with tqdm.product and disable and leave")