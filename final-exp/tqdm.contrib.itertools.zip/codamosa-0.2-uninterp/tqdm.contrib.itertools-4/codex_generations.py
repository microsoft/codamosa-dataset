

# Generated at 2022-06-18 11:10:11.082594
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with tqdm(ascii=True)
    with tqdm_auto(ascii=True) as t:
        for i in product(range(10), repeat=3):
            t.update()
            time.sleep(0.01)
    assert t.n == 1000
    assert t.total == 1000
    assert t.dynamic_ncols
    assert t.smoothing == 1.0
    assert t.ascii
    assert t.unit == 'it'
    assert t.unit_scale
    assert t.miniters == 1
    assert t.mininterval == 0.1
    assert t.maxinter

# Generated at 2022-06-18 11:10:22.229970
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_

# Generated at 2022-06-18 11:10:33.383617
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    from .utils import format_bytes
    from .utils import format_time
    from .utils import format_interval
    from .utils import format_sizeof
    from .utils import format_number
    from .utils import format_meter
    from .utils import format_stats
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_bar
    from .utils import format_line
    from .utils import format_line_desc
    from .utils import format_line_total
    from .utils import format_line_rate
    from .utils import format_line_bar

# Generated at 2022-06-18 11:10:41.530894
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    import time

    # Test 1
    print("Test 1:")
    print("  Product of 2 lists of length 10:")
    start_time = time.time()
    for i in product(range(10), range(10)):
        pass
    print("    Time elapsed: {}".format(format_interval(time.time() - start_time)))

    # Test 2
    print("Test 2:")
    print("  Product of 2 lists of length 100:")
    start_time = time.time()
    for i in product(range(100), range(100)):
        pass

# Generated at 2022-06-18 11:10:53.384887
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for _ in product(*iterables, **tqdm_kwargs):
            pass

    def test_product_list(iterables, **tqdm_kwargs):
        """
        List for testing product
        """
        list(product(*iterables, **tqdm_kwargs))

    def test_product_set(iterables, **tqdm_kwargs):
        """
        Set for testing product
        """
        set(product(*iterables, **tqdm_kwargs))


# Generated at 2022-06-18 11:11:02.668958
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    print("  * Generate random numbers")
    print("  * Compute their product")
    print("  * Compare with numpy.prod")
    print("  * Compare with itertools.product")
    print("  * Compare with tqdm.product")
    print("  * Compare with tqdm.product(tqdm_class=tqdm.tqdm)")
    print("  * Compare with tqdm.product(tqdm_class=tqdm.trange)")

# Generated at 2022-06-18 11:11:13.087575
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof

    # Test 1
    print("Test 1:")
    print("  - Generate all combinations of [1, 2, 3] and ['a', 'b', 'c']")
    print("  - Print the combinations and their sizes")
    for i in product([1, 2, 3], ['a', 'b', 'c']):
        print("    - {}: {}".format(i, format_sizeof(i)))

    # Test 2
    print("Test 2:")
    print("  - Generate all combinations of [1, 2, 3] and ['a', 'b', 'c']")
    print("  - Print the combinations and their sizes")

# Generated at 2022-06-18 11:11:21.857550
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format

# Generated at 2022-06-18 11:11:25.968899
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc):
            pass
        tc.assert_equal(tc.n, 100)
        tc.assert_equal(tc.smoothed, 100)
        tc.assert_equal(tc.last_print_t, 100)

# Generated at 2022-06-18 11:11:36.560701
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_html_fmt
    from ..utils import format_dict_jupyter
    from ..utils import format

# Generated at 2022-06-18 11:11:47.814503
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm_gui import tqdm
    from .utils import FormatCustomTextExtension
    from .std import tqdm as tqdm_std
    from .std import tqdm_notebook as tqdm_notebook_std
    from .gui import tqdm as tqdm_gui
    from .gui import tqdm_notebook as tqdm_notebook_gui
    from .gui import trange
    from .gui import tnrange
    from .auto import tqdm as tqdm_auto
    from .auto import trange as trange_auto
    from .auto import tnrange as tnrange_auto
    from .auto import tqdm_notebook as tqdm_notebook_auto
    from .auto import tqdm

# Generated at 2022-06-18 11:11:56.873146
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    # ======
    # Test with a single iterable
    # ---------------------------
    # Test with a single iterable
    # ---------------------------
    # Create the iterable
    iterable = range(10)
    # Create the expected result
    expected_result = list(itertools.product(iterable))
    # Create the result
    result = list(product(iterable))
    # Check that the result is correct
    assert result == expected_result

    # Test 2
    # ======
    # Test with two iterables
    # -----------------------
    # Create the iterables
    iterable1 = range(10)
    iterable2 = range(10)
   

# Generated at 2022-06-18 11:12:05.919111
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1
    print("Test 1:")
    t = time.time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False,
                     file=sys.stdout):
        pass
    print("\nElapsed:", time.time() - t)

    # Test 2
    print("\nTest 2:")
    t = time.time()
    for _ in itertools.product(range(10), range(10), range(10), range(10)):
        pass

# Generated at 2022-06-18 11:12:14.967381
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        prefix = "Test: "

    with closing(StringIO()) as our_file:
        with tqdm_auto(
                file=our_file, ascii=True, miniters=1,
                mininterval=0.001, desc="Test",
                bar_format=FormatWrap()) as t:
            for i in product(range(10), range(10), range(10),
                             tqdm_class=tqdm_auto):
                t.update()
                assert i == (t.n // 100, t.n // 10 % 10, t.n % 10)

# Generated at 2022-06-18 11:12:23.714094
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1: simple
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2: simple
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3: simple
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="test"):
        pass

    # Test 4: simple
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="test", leave=False):
        pass

   

# Generated at 2022-06-18 11:12:32.680140
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..utils import FormatCustomText
    from ..std import format_interval

    # Test 1
    with tqdm_auto(total=None,
                   bar_format=FormatCustomText(
                       desc="{desc}",
                       total="{total}",
                       elapsed="{elapsed}",
                       ncols=80,
                       )) as t:
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="Test 1"):
            pass
    assert t.total == 1000
    assert t.n == 1000
    assert t.last_print_n == 1000
    assert t.last_print_refresh_time is not None
    assert t.last_print_n == t.n
   

# Generated at 2022-06-18 11:12:41.084690
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     mininterval=0.1, miniters=1):
        time.sleep(0.01)

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:12:47.163965
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import closing
    from .utils import StringIO
    from .utils import _range

    class TestFormatWrap(FormatWrapBase):
        """
        Test class for function product
        """
        @staticmethod
        def format_meter(n, total, elapsed):
            """
            Format the progress meter
            """
            return "|{0:^7}|".format(n)

    with closing(StringIO()) as our_file:
        for _ in product(_range(10), _range(10), tqdm_class=TestFormatWrap,
                         file=our_file):
            pass
        our_file.seek(0)

# Generated at 2022-06-18 11:12:55.781794
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test with a list of lists
    list_of_lists = [list(range(i)) for i in range(1, 10)]
    for i in product(*list_of_lists):
        pass

    # Test with a list of generators
    list_of_generators = [range(i) for i in range(1, 10)]
    for i in product(*list_of_generators):
        pass

    # Test with a list of iterables
    list_of_iterables = [iter(range(i)) for i in range(1, 10)]
    for i in product(*list_of_iterables):
        pass

    # Test with

# Generated at 2022-06-18 11:13:05.776473
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import stderr
    from random import randint
    from itertools import product
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof

# Generated at 2022-06-18 11:13:15.622656
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.1)

    # Test 2
    print("\nTest 2:")

# Generated at 2022-06-18 11:13:22.992842
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter
    with closing(tqdm_auto(total=0)) as t:
        assert list(product(range(3), repeat=2, tqdm_class=tqdm_auto)) == \
            list(itertools.product(range(3), repeat=2))
        assert t.n == 9
        assert t.total == 9
    with closing(tqdm_auto(total=0)) as t:
        assert list(product(range(3), repeat=2, tqdm_class=tqdm_auto,
                            total=9)) == list(itertools.product(range(3),
                                                                repeat=2))
        assert t.n == 9
        assert t.total == 9

# Generated at 2022-06-18 11:13:32.640966
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    def test_product_inner(tqdm_class):
        """
        Unit test for function product
        """
        # Test 1
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass

        # Test 2
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass

        # Test 3
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass

        # Test 4

# Generated at 2022-06-18 11:13:40.290877
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t = time.time() - t
    print("Test 1:")
    print("  Elapsed time: %s" % format_interval(t))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    t = time.time()

# Generated at 2022-06-18 11:13:45.411469
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import version_info
    from itertools import product
    from .utils import _range

    # Test for issue #7
    for i in product(_range(10), _range(10)):
        pass

    # Test for issue #8
    for i in product(_range(10), _range(10)):
        pass

    # Test for issue #9
    for i in product(_range(10), _range(10)):
        pass

    # Test for issue #11
    for i in product(_range(10), _range(10)):
        pass

    # Test for issue #12
    for i in product(_range(10), _range(10)):
        pass

    # Test

# Generated at 2022-06-18 11:13:55.607261
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test basic functionality
    assert list(product(range(5), range(5))) == list(itertools.product(range(5), range(5)))

    # Test total
    assert list(product(range(5), range(5), tqdm_class=tqdm_auto)) == list(itertools.product(range(5), range(5)))

    # Test total
    assert list(product(range(5), range(5), tqdm_class=tqdm_auto, total=25)) == list(itertools.product(range(5), range(5)))

    # Test total

# Generated at 2022-06-18 11:14:03.971135
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    t1 = time.time()
    print("\nElapsed time: %s" % format_interval(t1 - t0))
    print("Peak memory: %s" % format_sizeof(tqdm_auto.peakmem()))
    print("Peak CPU: %s" % format_interval(tqdm_auto.peakcpu()))

# Generated at 2022-06-18 11:14:12.918225
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    import random

    # Test for product
    for i in range(5):
        print("\nTest for product:")
        print("  - tqdm_class = tqdm.auto.tqdm")
        print("  - iterables = [range(10), range(10), range(10)]")
        print("  - total = 1000")
        t0 = time.time()
        for _ in product(range(10), range(10), range(10)):
            pass
        t1 = time.time()
        print("  - elapsed time = %s" % format_interval(t1 - t0))


# Generated at 2022-06-18 11:14:20.179037
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..tests import closing, closing_to_file, closing_to_queue
    from ..tests import closing_to_file_like, closing_to_file_like_obj
    from ..tests import closing_to_file_like_iter, closing_to_file_like_gen
    from ..tests import closing_to_file_like_iter_gen
    from ..tests import closing_to_file_like_iter_gen_exc
    from ..tests import closing_to_file_like_iter_gen_exc_exc
    from ..tests import closing_to_file_like_iter_gen_exc_exc_exc
    from ..tests import closing_to_file_like_iter_gen_exc_exc_exc_exc

# Generated at 2022-06-18 11:14:28.662298
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        """
        Wrapper for FormatWrapBase
        """
        def __init__(self, *args, **kwargs):
            super(FormatWrap, self).__init__(*args, **kwargs)
            self.out = StringIO()

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            return False  # False values do not suppress exceptions

        def write(self, x):
            self.out.write(x)


# Generated at 2022-06-18 11:14:40.652555
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test with a simple product
    with tqdm_auto(total=None) as t:
        for i in product(range(10), range(10)):
            t.update()
    assert t.n == 100

    # Test with a simple product and a total
    with tqdm_auto(total=100) as t:
        for i in product(range(10), range(10)):
            t.update()
    assert t.n == 100

    # Test with a simple product and a total

# Generated at 2022-06-18 11:14:49.241669
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    from .utils import closing
    from .utils import format_meter
    from .utils import format_interval
    from .utils import format_sizeof
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_stats
    from .utils import format_line
    from .utils import format_overhead
    from .utils import format_description
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time

# Generated at 2022-06-18 11:14:58.599030
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Test 1
    with tqdm_auto(total=1, file=sys.stderr) as t:
        for i in product(range(10), repeat=2):
            t.update()
            time.sleep(0.01)
    assert t.n == 100

    # Test 2
    with tqdm_auto(total=1, file=sys.stderr) as t:
        for i in product(range(10), repeat=2):
            t.update()
            time.sleep(0.01)
   

# Generated at 2022-06-18 11:15:06.142219
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  * Test 1.1:")
    start_time = time.time()
    for i in product(range(10), range(10)):
        pass
    print("    - Elapsed time: %s" % format_interval(time.time() - start_time))
    print("  * Test 1.2:")
    start_time = time.time()
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-18 11:15:11.616601
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tqdm import tqdm
    from ..utils import _term_move_up
    from ..std import time
    from ..std import sys
    from ..std import StringIO

    # Test basic functionality
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))

    # Test total
    with tqdm(total=9) as t:
        for _ in product(range(3), range(3)):
            t.update()

    # Test total
    with tqdm(total=9) as t:
        for _ in product(range(3), range(3), tqdm_class=tqdm):
            t.update()

    # Test total

# Generated at 2022-06-18 11:15:19.030243
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1", leave=False):
        pass
    print("Total time:", format_interval(time.time() - t))
    print("Total size:", format_sizeof(sys.getsizeof(i)))
    print("")

    # Test 2
    print("Test 2:")
    t = time.time()

# Generated at 2022-06-18 11:15:29.299458
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof

    def test_product_iter(iterable, total, **tqdm_kwargs):
        """
        Unit test for function product
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        kwargs.setdefault("total", total)
        with tqdm_class(**kwargs) as t:
            for i in iterable:
                t.update()
                yield i

    def test_product_iter_2(iterable, total, **tqdm_kwargs):
        """
        Unit test for function product
        """
        kwargs = tqdm_

# Generated at 2022-06-18 11:15:38.003190
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    from .utils import FormatMixin
    from .utils import StringIO

    class TqdmTest(FormatMixin, tqdm_auto):
        def __init__(self, *args, **kwargs):
            super(TqdmTest, self).__init__(*args, **kwargs)
            self.miniters = 1

    # Test 1
    with TqdmTest(total=10, file=sys.stderr, mininterval=0.01) as t:
        for i in product(range(10), repeat=2):
            t.update()
    assert t.n == 100
    assert t.total == 100

    # Test 2

# Generated at 2022-06-18 11:15:47.591089
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1: simple test
    print("Test 1: simple test")
    for i in product(range(10), range(10)):
        print(i)
        time.sleep(0.1)

    # Test 2: test with total
    print("Test 2: test with total")
    for i in product(range(10), range(10), total=100):
        print(i)
        time.sleep(0.1)

    # Test 3: test with total and unit
    print("Test 3: test with total and unit")
    for i in product(range(10), range(10), total=100, unit="B"):
        print(i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:15:56.641111
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import numpy as np
    from ..utils import format_interval

    # Test for product
    for i in product(range(10), repeat=2):
        pass
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        pass
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="test"):
        pass
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="test", mininterval=0.1):
        pass

# Generated at 2022-06-18 11:16:16.085052
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import time

    # Test 1
    print("Test 1:")
    print("  * Generate all possible combinations of 3 elements from "
          "('a', 'b', 'c', 'd')")
    print("  * Expected result: ('a', 'a', 'a'), ('a', 'a', 'b'), ..., "
          "('d', 'd', 'd')")
    print("  * Expected size: 4^3 = 64")
    print("  * Expected time: ~0.1s")
    print("  * Expected memory usage: ~0.1MB")
    start_time = time()

# Generated at 2022-06-18 11:16:25.776471
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("Test 1:")
    print("  - Test with a list of lists")
    print("  - Test with a list of lists, with total=None")
    print("  - Test with a list of lists, with total=None and miniters=1")
    print("  - Test with a list of lists, with total=None and miniters=1 and smoothing=1")
    print("  - Test with a list of lists, with total=None and miniters=1 and smoothing=1 and leave=True")

# Generated at 2022-06-18 11:16:33.642143
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Generator for testing `product`.
        """
        for _ in product(*iterables, **tqdm_kwargs):
            pass

    # Test 1
    iterables = [range(10)] * 3
    t0 = time.time()
    test_product_generator(iterables, tqdm_class=tqdm_auto)
    t1 = time.time()
    print("\nTest 1:")
    print("  Iterables:", iterables)
    print("  Time:", format_interval(t1 - t0))
   

# Generated at 2022-06-18 11:16:39.093249
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        def __init__(self, iterable, *args, **kwargs):
            super(FormatWrap, self).__init__(iterable, *args, **kwargs)
            self.i = 0

        def __iter__(self):
            return self

        def __next__(self):
            self.i += 1
            return next(self.iterable)

        def __len__(self):
            return len(self.iterable)

        def display(self):
            return "i={}".format(self.i)


# Generated at 2022-06-18 11:16:48.066448
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    import time
    import random
    random.seed(0)
    try:
        from itertools import product as itertools_product
    except ImportError:
        return
    try:
        from numpy import product as numpy_product
    except ImportError:
        numpy_product = None
    try:
        from scipy.misc import comb as scipy_comb
    except ImportError:
        scipy_comb = None

    def test_product_func(func, name, *iterables):
        t0 = time.time()
        for _ in func(*iterables):
            pass
        t1 = time.time()
        return t1 - t

# Generated at 2022-06-18 11:16:56.528714
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test for function product
    print("Testing function product...")
    print("  Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("  Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("  Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("  Test 4:")

# Generated at 2022-06-18 11:17:04.026356
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1
    print("\nTest 1")
    for i in product(range(10), repeat=2):
        print(i)
    print()

    # Test 2
    print("\nTest 2")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
    print()

    # Test 3
    print("\nTest 3")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     ascii=True):
        print(i)
    print()

    # Test 4
    print("\nTest 4")


# Generated at 2022-06-18 11:17:14.113366
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.cls):
            pass
        tc.assertEqual(tc.n, 100)
        tc.pbar.update(0)
        tc.assertEqual(tc.n, 100)
        tc.pbar.update(50)
        tc.assertEqual(tc.n, 150)
        tc.pbar.update(50)
        tc.assertEqual(tc.n, 200)
        tc.pbar.update(50)
        tc.assertEqual(tc.n, 250)
        tc.pbar.update(50)
        tc.assertEqual(tc.n, 300)
        tc.pbar

# Generated at 2022-06-18 11:17:20.017539
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number

# Generated at 2022-06-18 11:17:28.389557
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof

    def test_product_generator(iterables):
        """
        Test product generator.
        """
        for i in product(*iterables):
            pass

    def test_product_list(iterables):
        """
        Test product list.
        """
        list(product(*iterables))

    def test_product_array(iterables):
        """
        Test product array.
        """
        np.array(list(product(*iterables)))

    def test_product_array_flat(iterables):
        """
        Test product array flat.
        """
        np.array(list(product(*iterables))).flatten()


# Generated at 2022-06-18 11:17:50.909075
# Unit test for function product
def test_product():
    from .tests import TestCase

    with TestCase():
        for _ in product(range(10), range(10), range(10)):
            pass

# Generated at 2022-06-18 11:17:58.429520
# Unit test for function product
def test_product():
    """Test for function product"""
    from ._utils import _range
    assert list(product(_range(3), _range(3))) == list(itertools.product(_range(3), _range(3)))
    assert list(product(_range(3), _range(3), tqdm_class=None)) == list(itertools.product(_range(3), _range(3)))
    assert list(product(_range(3), _range(3), tqdm_class=tqdm_auto)) == list(itertools.product(_range(3), _range(3)))

# Generated at 2022-06-18 11:18:07.808028
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=False):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=False, mininterval=0.1):
        pass

    # Test 4
    print

# Generated at 2022-06-18 11:18:15.589828
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import version_info
    from random import randint
    from itertools import product
    from itertools import repeat
    from itertools import chain
    from itertools import islice
    from itertools import tee
    from itertools import starmap
    from itertools import cycle
    from itertools import compress
    from itertools import filterfalse
    from itertools import groupby
    from itertools import zip_longest
    from itertools import combinations
    from itertools import combinations_with_replacement
    from itertools import permutations
    from itertools import product as itertools_product

# Generated at 2022-06-18 11:18:23.765632
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    list_of_lists_product = list(itertools.product(*list_of_lists))
    list_of_lists_product_tqdm = list(product(*list_of_lists))
    assert list_of_lists_product == list_of_lists_product_tqdm

    # Test with a list of iterators
    list_of_iterators = [iter([1, 2, 3]), iter([4, 5, 6]), iter([7, 8, 9])]
    list_of

# Generated at 2022-06-18 11:18:33.706278
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

# Generated at 2022-06-18 11:18:42.133980
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assert_equal(tc.total, 100)
        tc.assert_equal(tc.n, 100)
        tc.assert_equal(tc.last_print_n, 100)

        for i in product(range(10), range(10), tqdm_class=tc.tqdm, total=100):
            pass
        tc.assert_equal(tc.total, 100)
        tc.assert_equal(tc.n, 100)
        tc.assert_equal(tc.last_print_n, 100)


# Generated at 2022-06-18 11:18:51.161041
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:", end=' ')
    t0 = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    dt = time.time() - t0
    print(format_sizeof(sys.getsizeof(i)), "in", dt, "sec")

    # Test 2
    print("Test 2:", end=' ')
    t0 = time.time()
    for i in itertools.product(range(10), range(10), range(10)):
        pass
    dt = time.time() - t0

# Generated at 2022-06-18 11:18:59.051479
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    dt = time.time() - t0
    print("dt = %s" % format_interval(dt))
    print("")

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:19:07.535389
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_wrapper(iterables, **tqdm_kwargs):
        """
        Wrapper for function product
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
               

# Generated at 2022-06-18 11:19:29.418714
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=100, file=sys.stdout)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=100, file=sys.stdout)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=100, file=sys.stdout)


# Generated at 2022-06-18 11:19:38.213278
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from ..utils import _range

    # Test basic functionality
    assert list(product(range(2), range(3))) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2)]

# Generated at 2022-06-18 11:19:46.966211
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:19:56.322529
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)
    m = np.arange(10)
    n = np.arange(10)
    o = np.ar

# Generated at 2022-06-18 11:20:06.102282
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time

    # Test 1:
    # -------
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test with a simple product
    # Test