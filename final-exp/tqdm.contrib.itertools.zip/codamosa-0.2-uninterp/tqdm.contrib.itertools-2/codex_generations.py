

# Generated at 2022-06-18 11:10:22.482288
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import version_info
    from sys import stdout
    from sys import stderr
    from sys import version
    from os import getpid
    from os import getppid
    from os import getcwd
    from os import getloadavg
    from os import getuid
    from os import getgid
    from os import geteuid
    from os import getegid
    from os import getgroups
    from os import getlogin
    from os import getenv
    from os import get_terminal_size
    from os import get_inheritable
    from os import get_blocking
    from os import get_handle_inheritable
    from os import get_

# Generated at 2022-06-18 11:10:33.611471
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for m in range(length))

    def random_list(length):
        return [random.random() for _ in range(length)]

    def random_dict(length):
        return {random_string(5): random_string(5) for _ in range(length)}

    def random_tuple(length):
        return tuple(random_list(length))

    def random_set(length):
        return set(random_list(length))

    def random_frozenset(length):
        return

# Generated at 2022-06-18 11:10:41.733219
# Unit test for function product
def test_product():
    """Test function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_sizeof_short_fmt

# Generated at 2022-06-18 11:10:53.427078
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

# Generated at 2022-06-18 11:11:02.713753
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1
    print("\nTest 1:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10), range(10))"):
        pass

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10), range(10))",
                     unit="it"):
        pass

    # Test 3

# Generated at 2022-06-18 11:11:13.133311
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import _range
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

# Generated at 2022-06-18 11:11:21.891324
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1:
    print("\nTest 1:")
    for i in product(range(10), repeat=2):
        print(i)
    # Test 2:
    print("\nTest 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
    # Test 3:
    print("\nTest 3:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     leave=False):
        print(i)
    # Test 4:
    print("\nTest 4:")

# Generated at 2022-06-18 11:11:31.321727
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    t0 = time.time()
    for _ in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="test1"):
        pass
    t1 = time.time()
    print("\nTest 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(list(range(100)))))

    # Test 2
    t0 = time.time()

# Generated at 2022-06-18 11:11:39.652657
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    def test_product_1():
        """
        Unit test for function product
        """
        print("\nTesting product()")
        print("=================")
        print("\nTesting product(range(10), repeat=2)")
        print("------------------------------------")
        t0 = time.time()
        for _ in product(range(10), repeat=2):
            pass
        t1 = time.time()
        print("\nElapsed time: %s" % format_interval(t1 - t0))
        print("\nTesting product(range(10), repeat=2) with tqdm")

# Generated at 2022-06-18 11:11:48.438435
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import getsizeof

    # Test with no iterable
    assert list(product()) == [()]

    # Test with one iterable
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    # Test with two iterables
    assert list(product([1, 2, 3], [4, 5, 6])) == [(1, 4), (1, 5), (1, 6),
                                                    (2, 4), (2, 5), (2, 6),
                                                    (3, 4), (3, 5), (3, 6)]

    # Test with three iterables
   

# Generated at 2022-06-18 11:11:59.735019
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test for no total
    for i in product(range(10), range(10), range(10)):
        pass

    # Test for total
    for i in product(range(10), range(10), range(10), total=1000):
        pass

    # Test for no total
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test for total
    for i in product(range(10), range(10), range(10), total=1000,
                     tqdm_class=tqdm_auto):
        pass

    # Test for no total
   

# Generated at 2022-06-18 11:12:08.266155
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import closing, closing_iter
    from ..utils import format_sizeof

    # Test 1
    with closing(tqdm_auto(total=10)) as t:
        for i in product(range(10), tqdm_class=tqdm_auto):
            pass

    # Test 2
    with closing(tqdm_auto(total=10)) as t:
        for i in product(range(10), tqdm_class=tqdm_auto):
            pass

    # Test 3
    with closing(tqdm_auto(total=10)) as t:
        for i in product(range(10), tqdm_class=tqdm_auto):
            pass

    # Test 4

# Generated at 2022-06-18 11:12:17.542369
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:", end=' ')
    t = time.time()
    for _ in product(range(10), repeat=3):
        pass
    print("{:.3g}s".format(time.time() - t))

    # Test 2
    print("Test 2:", end=' ')
    t = time.time()
    for _ in itertools.product(range(10), repeat=3):
        pass
    print("{:.3g}s".format(time.time() - t))

    # Test 3
    print("Test 3:", end=' ')
    t = time.time()

# Generated at 2022-06-18 11:12:25.795820
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.01)

    # Test 2
    print("\nTest 2:")

# Generated at 2022-06-18 11:12:35.110749
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys
    import os
    import random

    # Test 1: simple
    for i in product(range(10), repeat=2):
        pass

    # Test 2: total
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        pass

    # Test 3: total
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto, total=100):
        pass

    # Test 4: total

# Generated at 2022-06-18 11:12:43.049364
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product

    # Test 1
    with tqdm_auto(total=10) as t:
        for i in product(range(10), range(10)):
            t.update()
            sleep(0.01)

    # Test 2
    with tqdm_auto(total=10) as t:
        for i in product(range(10), range(10)):
            t.update()
            sleep(0.01)

    # Test 3

# Generated at 2022-06-18 11:12:51.673296
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter


# Generated at 2022-06-18 11:13:01.211458
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof

    import sys
    import time
    import random

    def test_product_inner(tqdm_class, iterables, total, **tqdm_kwargs):
        """
        Unit test for function product.
        """
        kwargs = tqdm_kwargs.copy()
        kwargs.setdefault("total", total)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                t.update()
        return t

    def test_product_outer(tqdm_class, iterables, total, **tqdm_kwargs):
        """
        Unit test for function product.
        """
        kwargs = tqdm_kwargs

# Generated at 2022-06-18 11:13:10.127280
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_line
    from ..utils import format_dict
    from ..utils import format_size
    from ..utils import format_length
    from ..utils import format_length_short
    from ..utils import format_length_long
    from ..utils import format_length_full
    from ..utils import format_length_mixed
    from ..utils import format_length_total
    from ..utils import format_length_total

# Generated at 2022-06-18 11:13:13.845360
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .utils import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assert_equal(tc.sp, tc.si)

# Generated at 2022-06-18 11:13:22.313916
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:13:32.009209
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1
    print("Test 1:")
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)
    m = np.arange(10)

# Generated at 2022-06-18 11:13:39.697824
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import _range
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import _range
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import _range
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import _range
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import _range
    from time import sleep
    from ..utils import format_interval
   

# Generated at 2022-06-18 11:13:45.133000
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint

    # Test with a simple example
    for i in product(range(3), range(3), range(3)):
        pass

    # Test with a large example
    t = time()
    for i in product(range(1000), range(1000), range(1000)):
        pass
    print("product(range(1000), range(1000), range(1000))")
    print("\t-> %s" % format_interval(time() - t))

    # Test with a large example
    t = time()
    for i in product(range(1000), range(1000), range(1000)):
        pass


# Generated at 2022-06-18 11:13:55.348009
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    t0 = time.time()
    for _ in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="1st loop", leave=False):
        pass
    dt = time.time() - t0
    print("\nTest 1:")
    print("  dt = %s" % format_interval(dt))
    print("  mem = %s" % format_sizeof(sys.getsizeof(t0)))

    # Test 2
    t0 = time.time()

# Generated at 2022-06-18 11:14:03.685866
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1")
    t = time.time()

# Generated at 2022-06-18 11:14:11.930997
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:14:16.392381
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tc.tqdm_class):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:14:22.624106
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Test product generator
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_class):
        """
        Test product list
        """
        list(product(*iterables, tqdm_class=tqdm_class))

    def test_product_list_no_tqdm(iterables):
        """
        Test product list without tqdm
        """


# Generated at 2022-06-18 11:14:31.940149
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_generator(iterables, total):
        """
        Unit test for function product
        """
        for i in product(*iterables):
            pass
        assert total == i.n

    def test_product_iterator(iterables, total):
        """
        Unit test for function product
        """
        i = product(*iterables)
        for _ in range(total):
            next(i)
        assert total == i.n

    def test_product_list(iterables, total):
        """
        Unit test for function product
        """
        i = list(product(*iterables))
        assert total == len(i)


# Generated at 2022-06-18 11:14:40.123690
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test 1
    iterables = [[1, 2], [3, 4]]
    res = list(product(*iterables))
    assert res == list(itertools_product(*iterables))

    # Test 2
    iterables = [[1, 2], [3, 4], [5, 6]]
    res = list(product(*iterables))
    assert res == list(itertools_product(*iterables))

    # Test 3
    iterables = [[1, 2], [3, 4], [5, 6], [7, 8]]

# Generated at 2022-06-18 11:14:48.525037
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    a = range(10)
    b = range(10)
    c = range(10)
    d = range(10)
    e = range(10)
    f = range(10)
    g = range(10)
    h = range(10)
    i = range(10)
    j = range(10)
    k = range(10)
    l = range(10)
    m = range(10)
    n = range(10)
    o = range(10)
    p = range(10)
    q = range(10)
    r = range(10)

# Generated at 2022-06-18 11:14:58.066844
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("Test 1:")
    print("  - Test product with a single iterable")
    print("  - Test product with a single iterable and total=None")
    print("  - Test product with a single iterable and total=0")
    print("  - Test product with a single iterable and total=1")
    print("  - Test product with a single iterable and total=2")
    print("  - Test product with a single iterable and total=3")
    print("  - Test product with a single iterable and total=4")
    print("  - Test product with a single iterable and total=5")
   

# Generated at 2022-06-18 11:15:05.644577
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string

    def random_string(length):
        """
        Generate a random string of given length.
        """
        return ''.join(random.choice(string.ascii_letters) for m in range(length))

    def random_list(length):
        """
        Generate a random list of given length.
        """
        return [random_string(random.randint(1, 10)) for _ in range(length)]

    def random_dict(length):
        """
        Generate a random dict of given length.
        """

# Generated at 2022-06-18 11:15:11.286078
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesince
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_over
    from ..utils import format_throughput
    from ..utils import format_percentage
    from ..utils import format_naturalsize
    from ..utils import format_short_sizeof
    from ..utils import format_short_number
    from ..utils import format_short_time
    from ..utils import format_short_eta
    from ..utils import format

# Generated at 2022-06-18 11:15:18.939147
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import random
    import time
    from .utils import format_interval

    def test_product_gen(n):
        """
        Generator for unit test
        """
        for _ in product(range(n), range(n), range(n),
                         tqdm_class=tqdm_auto,
                         desc="test_product_gen",
                         leave=False):
            yield _

    def test_product_gen_noleave(n):
        """
        Generator for unit test
        """

# Generated at 2022-06-18 11:15:29.184474
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import _range
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a list of lists
    for i in product([_range(10), _range(10), _range(10)],
                     tqdm_class=tqdm_auto):
        pass

    # Test with a generator of lists
    for i in product((_range(10), _range(10), _range(10)),
                     tqdm_class=tqdm_auto):
        pass

    # Test with a generator of generators
    for i in product((_range(10), _range(10), _range(10)),
                     tqdm_class=tqdm_auto):
        pass

    # Test with a

# Generated at 2022-06-18 11:15:37.866735
# Unit test for function product
def test_product():
    """Test for function product"""
    import numpy as np
    from ..utils import format_sizeof

    def test_product_iter(iterables, tqdm_class=tqdm_auto):
        """Test for function product"""
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_class):
        """Test for function product"""
        for i in list(product(*iterables, tqdm_class=tqdm_class)):
            pass

    def test_product_np(iterables, tqdm_class=tqdm_class):
        """Test for function product"""

# Generated at 2022-06-18 11:15:47.430413
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_to_file, closing_to_stdout, \
        closing_to_stderr, closing_to_stringio, closing_to_bytesio, \
        closing_to_tempfile, closing_to_tempfile_and_filename, \
        closing_to_tempfile_and_name, closing_to_tempfile_and_path, \
        closing_to_tempfile_and_mode, closing_to_tempfile_and_buffering, \
        closing_to_tempfile_and_encoding, closing_to_tempfile_and_errors, \
        closing_to_tempfile_and_newline, closing_to_tempfile_and_closefd, \
        closing_to_tempfile_and_opener, closing

# Generated at 2022-06-18 11:15:56.496964
# Unit test for function product
def test_product():
    """
    Test function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with tqdm_class=tqdm.auto.tqdm
    print("Test with tqdm_class=tqdm.auto.tqdm")
    print("Test with tqdm_class=tqdm.auto.tqdm")
    print("Test with tqdm_class=tqdm.auto.tqdm")
    print("Test with tqdm_class=tqdm.auto.tqdm")
    print("Test with tqdm_class=tqdm.auto.tqdm")
    print("Test with tqdm_class=tqdm.auto.tqdm")

# Generated at 2022-06-18 11:16:00.832007
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for _ in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assert_empty()

# Generated at 2022-06-18 11:16:07.521164
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof

    # Test with a very large product
    # (to test the total= parameter)
    print("Testing product(range(100), repeat=2)")
    start_t = time.time()
    for i in product(range(100), repeat=2):
        pass
    print("-> %s" % format_interval(time.time() - start_t))

    # Test with a very large product
    # (to test the total= parameter)
    print("Testing product(range(100), repeat=2)")
    start_t = time.time()

# Generated at 2022-06-18 11:16:16.683543
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import stderr
    from random import random
    from itertools import product
    from itertools import repeat
    from itertools import chain
    from itertools import islice
    from itertools import count
    from itertools import cycle
    from itertools import starmap
    from itertools import tee
    from itertools import zip_longest
    from itertools import filterfalse
    from itertools import accumulate
    from itertools import takewhile
    from itertools import dropwhile
    from itertools import groupby
    from itertools import permutations
    from itertools import combinations

# Generated at 2022-06-18 11:16:26.417926
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("Test 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))
    print("")

    # Test 2
    t0 = time.time()

# Generated at 2022-06-18 11:16:34.165463
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test for product
    for n in [1, 2, 3, 4, 5]:
        for m in [1, 2, 3, 4, 5]:
            t = time.time()
            for i in product(range(n), range(m)):
                pass
            t = time.time() - t
            print("product(range({}), range({})) in {}".format(
                n, m, format_interval(t)))
            sys.stdout.flush()

    # Test for product with tqdm
    for n in [1, 2, 3, 4, 5]:
        for m in [1, 2, 3, 4, 5]:
            t = time.time()

# Generated at 2022-06-18 11:16:42.619354
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:16:51.351129
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:16:59.578187
# Unit test for function product
def test_product():
    from .tests import TestCase, closing, nested
    from .utils import FormatCustomText, FormatCustomTextColon
    from .std import tqdm

    with closing(TestCase(tqdm)) as tc:
        for i in tc.assert_iter(product(range(10), range(10), range(10))):
            pass
        tc.assert_equal(tc.tqdm.n, 1000)
        tc.assert_equal(tc.tqdm.total, 1000)
        tc.assert_equal(tc.tqdm.last_print_n, 1000)


# Generated at 2022-06-18 11:17:06.434906
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_percentage
    from ..utils import format_description
    from ..utils import format_as_sizeof
    from ..utils import format_as_sizeof_fraction
    from ..utils import format_as_text
    from ..utils import format_as_timedelta
    from ..utils import format_as_integer

# Generated at 2022-06-18 11:17:15.096627
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    dt = time.time() - t0
    print("\nTest 1:")
    print("  Elapsed time: %s" % format_interval(dt))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    t0 = time.time()

# Generated at 2022-06-18 11:17:25.966410
# Unit test for function product
def test_product():
    """Test for `product`"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
   

# Generated at 2022-06-18 11:17:32.718100
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    dt = time.time() - t0
    print("Test 1:", format_interval(dt), format_sizeof(sys.getsizeof(i)))

    # Test 2
    t0 = time.time()

# Generated at 2022-06-18 11:17:41.080998
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.set

# Generated at 2022-06-18 11:17:49.685654
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=True):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=False):
        pass

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:17:59.612802
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint

    # Test with random data
    for i in range(10):
        # Generate random data
        n = randint(1, 10)
        iterables = [range(randint(1, 10)) for _ in range(n)]
        # Compute expected result
        expected = list(itertools.product(*iterables))
        # Compute actual result
        actual = list(product(*iterables))
        # Check result
        assert actual == expected, "product failed"

    # Test with large data
    n = 100
    iterables = [range(10) for _ in range(n)]
    # Compute

# Generated at 2022-06-18 11:18:09.273536
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    for i in product(gen(), gen(), tqdm_class=tqdm_auto,
                     desc="product(gen(), gen())"):
        pass

    # Test with a list
    for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10))"):
        pass

    # Test with a list and a generator

# Generated at 2022-06-18 11:18:16.369484
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with no total
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with total
    for i in product(range(10), range(10), range(10), total=1000):
        pass

    # Test with total=None
    for i in product(range(10), range(10), range(10), total=None):
        pass

    # Test with total=None and iterable of unknown length
    for i in product(range(10), range(10), range(10), total=None):
        pass

    # Test with total=None and iterable of unknown length

# Generated at 2022-06-18 11:18:25.756139
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    def test_product_inner(iterables, **kwargs):
        """
        Unit test for function product.
        """
        print("\nTesting product(%s, **%s)" % (
            ", ".join(map(repr, iterables)),
            kwargs))
        start_t = time.time()
        for i in product(*iterables, **kwargs):
            pass
        print(" -> %s" % format_interval(time.time() - start_t))

    test_product_inner([range(10)] * 10)

# Generated at 2022-06-18 11:18:34.967952
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a large number of items
    t0 = time.time()
    for _ in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="product(range(100), range(100), range(100))",
                     leave=False):
        pass
    dt = time.time() - t0
    print("product(range(100), range(100), range(100)) took %s" %
          format_interval(dt))
    assert dt < 1.5, "product(range(100), range(100), range(100)) took too long"

    # Test with a

# Generated at 2022-06-18 11:18:42.794289
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

# Generated at 2022-06-18 11:18:55.574751
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("Elapsed time: %s" % format_interval(t1 - t0))
    print("Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:19:03.666262
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import stderr
    from random import random
    from itertools import product
    from numpy import product as npproduct

    # Test 1
    try:
        for _ in product(range(10), repeat=2):
            pass
    except Exception as e:
        raise e
    else:
        print("Test 1 passed")

    # Test 2
    try:
        for _ in product(range(10), repeat=2, tqdm_class=tqdm_auto):
            pass
    except Exception as e:
        raise e
    else:
        print("Test 2 passed")

    # Test 3

# Generated at 2022-06-18 11:19:11.194244
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import _range

    def test_product_unit(iterables, total, **kwargs):
        """
        Unit test for function product
        """
        print("\nTesting `product` with iterables:")
        for i in iterables:
            print("  ", i)
        print("  total:", total)
        print("  kwargs:", kwargs)
        print("  sys.getsizeof(iterables):", format_sizeof(sys.getsizeof(iterables)))
        print("  sys.getsizeof(total):", format_sizeof(sys.getsizeof(total)))

# Generated at 2022-06-18 11:19:19.798552
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    def test_product_unit(iterables, tqdm_class=tqdm_auto, **tqdm_kwargs):
        """
        Unit test for function product
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)

# Generated at 2022-06-18 11:19:28.991331
# Unit test for function product
def test_product():
    """
    Test function `product`.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with tqdm(total=None)
    with tqdm_auto(total=None) as t:
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto):
            pass
    assert t.total == 1000

    # Test with tqdm(total=None) and nested loops

# Generated at 2022-06-18 11:19:34.626589
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(iterables, **tqdm_kwargs):
        """
        Generator for unit test
        """
        for _ in product(*iterables, **tqdm_kwargs):
            yield 1

    def test_product_list(iterables, **tqdm_kwargs):
        """
        List for unit test
        """
        return list(product(*iterables, **tqdm_kwargs))

    def test_product_iter(iterables, **tqdm_kwargs):
        """
        Iterator for unit test
        """
        return iter(product(*iterables, **tqdm_kwargs))


# Generated at 2022-06-18 11:19:43.824345
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .tests_tqdm import pretest_posttest_monkeypatch

    class TestProduct(FormatMixin):
        def test_product(self):
            """Test product"""
            with pretest_posttest_monkeypatch(self):
                for i in product(range(10), range(10), range(10),
                                 tqdm_class=self.tqdm_class):
                    pass
                self.sp(1)
                for i in product(range(10), range(10), range(10),
                                 tqdm_class=self.tqdm_class,
                                 desc="Test product"):
                    pass
                self.sp(1)

# Generated at 2022-06-18 11:19:52.752871
# Unit test for function product
def test_product():
    """Test for function product"""
    from .tests_tqdm import with_setup, pretest, posttest, _range

    @with_setup(pretest, posttest)
    def wrapper():
        """Actual test for function product"""
        # Test basic functionality
        assert list(product(_range(3), _range(4))) == list(itertools.product(_range(3), _range(4)))

        # Test total
        assert list(product(_range(3), _range(4), tqdm_class=tqdm_auto)) == list(itertools.product(_range(3), _range(4)))

        # Test leave

# Generated at 2022-06-18 11:19:59.951859
# Unit test for function product
def test_product():
    """Test function `product`"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_numlist
    from ..utils import format_dict
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_numlist_fmt
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short


# Generated at 2022-06-18 11:20:09.581414
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_gen(a, b, c):
        """
        Generator for unit test
        """
        for i in product(a, b, c, tqdm_class=tqdm_auto):
            yield i

    def test_product_gen_nested(a, b, c):
        """
        Generator for unit test
        """
        for i in product(a, b, c, tqdm_class=tqdm_auto):
            for j in product(a, b, c, tqdm_class=tqdm_auto):
                yield i, j
