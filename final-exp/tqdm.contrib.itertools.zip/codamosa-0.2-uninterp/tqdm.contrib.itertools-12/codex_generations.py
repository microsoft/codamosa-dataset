

# Generated at 2022-06-18 11:10:23.077379
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_interval_short_fmt
    from ..utils import format_meter_short_fmt
    from ..utils import format_sizeof_fmt_unit
    from ..utils import format_interval_fmt_unit
    from ..utils import format_meter_fmt_unit
    from ..utils import format_interval_short_fmt_unit

# Generated at 2022-06-18 11:10:34.205938
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 4
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 5

# Generated at 2022-06-18 11:10:42.206989
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_iter(iterables, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_iter_total(iterables, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(*iterables, tqdm_class=tqdm_class, total=0):
            pass

    def test_product_iter_total_len(iterables, tqdm_class):
        """
        Unit test for function product
        """

# Generated at 2022-06-18 11:10:53.509129
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin

    class Test(FormatMixin):
        def __init__(self):
            self.test_size = 1000000
            self.test_range = range(self.test_size)
            self.test_list = list(self.test_range)
            self.test_product = product(self.test_list, self.test_list)
            self.test_product_size = self.test_size ** 2

        def test_size(self):
            assert len(self.test_list) == self.test_size
            assert len(self.test_product) == self.test_product_size


# Generated at 2022-06-18 11:11:02.810788
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys

    # Test 1
    print("\nTest 1")

# Generated at 2022-06-18 11:11:13.221460
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .utils import StringIO

    class TqdmTest(FormatMixin):
        """
        Minimal class for testing `tqdm.product`.
        """
        @staticmethod
        def format_sizeof(obj):
            return format_sizeof(obj)

    with TqdmTest(unit='B', unit_scale=True, unit_divisor=1024,
                  miniters=1, mininterval=0) as t:
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=t.__class__):
            pass
        assert t.n == 1000000000
        assert t.last_print_n == t.n

# Generated at 2022-06-18 11:11:21.961556
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    # Test with a small number of iterations
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test product"):
        pass

    # Test with a large number of iterations
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="Test product"):
        pass

    # Test with a large number of iterations and a large number of
    # items per iteration

# Generated at 2022-06-18 11:11:26.036764
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, pretest, posttest, _range

    @with_setup(pretest, posttest)
    def test():
        """
        Test for `tqdm.itertools.product`.
        """
        for i in product(_range(10), _range(10), _range(10),
                         tqdm_class=tqdm_auto):
            pass

    test()

# Generated at 2022-06-18 11:11:36.625247
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test with a generator
    gen = (i for i in range(10))
    for i in product(gen, tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product(range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a numpy array
    for i in product(np.arange(10), tqdm_class=tqdm_auto):
        pass

    # Test with a numpy array
    for i in product(np.arange(10), tqdm_class=tqdm_auto):
        pass

    # Test with a numpy array

# Generated at 2022-06-18 11:11:42.170777
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Test with a simple product
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with a simple product
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a simple product
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test"):
        pass

    # Test with a simple product

# Generated at 2022-06-18 11:11:53.959374
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_length
    from ..utils import format_length_short
    from ..utils import format_length_long
    from ..utils import format_length_full
    from ..utils import format_length_mixed
    from ..utils import format_length_full_mixed
    from ..utils import format_length_short_mixed
    from ..utils import format_length_long_mixed
    from ..utils import format_length_full_mixed_short

# Generated at 2022-06-18 11:12:03.349273
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import trange
    from .utils import format_sizeof
    from .std import time

    # Test 1
    for i in product(range(10), range(10), range(10),
                     tqdm_class=trange,
                     desc="Test 1",
                     unit="B",
                     unit_scale=True,
                     unit_divisor=1024,
                     dynamic_ncols=True,
                     leave=True):
        time.sleep(0.01)

    # Test 2

# Generated at 2022-06-18 11:12:12.220966
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:12:20.938104
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with a non-iterable
    try:
        for _ in product(1):
            pass
    except TypeError:
        pass
    else:
        raise AssertionError("product(1) should raise TypeError")

    # Test with a non-iterable
    try:
        for _ in product(1, 2):
            pass
    except TypeError:
        pass
    else:
        raise AssertionError("product(1, 2) should raise TypeError")

    # Test with a non-iterable
    try:
        for _ in product(1, 2, 3):
            pass
    except TypeError:
        pass

# Generated at 2022-06-18 11:12:29.518951
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:12:38.410148
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=1, file=sys.stdout)
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     leave=False):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=1, file=sys.stdout)
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     leave=False,
                     mininterval=0.1):
        pass
    t.close()

# Generated at 2022-06-18 11:12:45.489100
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_generator(iterables):
        """
        Test product generator.
        """
        for i in product(*iterables):
            pass

    def test_product_list(iterables):
        """
        Test product list.
        """
        list(product(*iterables))

    def test_product_list_slicing(iterables):
        """
        Test product list slicing.
        """
        list(product(*iterables))[:10]

    def test_product_list_slicing_step(iterables):
        """
        Test product list slicing step.
        """
        list(product(*iterables))[::10]


# Generated at 2022-06-18 11:12:49.345379
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        with product(range(3), range(3), range(3),
                     tqdm_class=tc.tqdm_class) as p:
            for i in p:
                pass
        tc.assertEqual(tc.sp(0), tc.sp(9))

# Generated at 2022-06-18 11:12:58.544975
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test for tqdm_notebook
    try:
        from tqdm import tqdm_notebook
    except ImportError:
        pass
    else:
        with tqdm_notebook(total=1, leave=False) as t:
            t.write("Testing tqdm_notebook...")
            time.sleep(0.01)
            t.update()

    # Test for tqdm_gui
    try:
        from tqdm import tqdm_gui
    except ImportError:
        pass
    else:
        with tqdm_gui(total=1, leave=False) as t:
            t.write("Testing tqdm_gui...")
           

# Generated at 2022-06-18 11:13:08.839177
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test for total
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test for no total
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test for no total and no tqdm_class
    for i in product(range(10), range(10), range(10)):
        pass

    # Test for no total and no tqdm_class
    for i in product(range(10), range(10), range(10)):
        pass

    # Test for no total and no tqdm_class

# Generated at 2022-06-18 11:13:17.857384
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    from time import sleep
    from random import random
    from itertools import product
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format

# Generated at 2022-06-18 11:13:26.210410
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test 1
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="test_product",
                     leave=True,
                     file=sys.stdout,
                     mininterval=0.1,
                     miniters=1,
                     ascii=True,
                     disable=False,
                     ncols=80,
                     ):
        pass

    # Test 3

# Generated at 2022-06-18 11:13:35.565367
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_html_fmt
    from ..utils import format_dict_json
    from ..utils import format_dict_

# Generated at 2022-06-18 11:13:42.277085
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percentage
    from ..utils import format_size
    from ..utils import format_time
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt

# Generated at 2022-06-18 11:13:51.948835
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test with a large number of small iterables
    n = 10
    m = 10
    iterables = [[random.random() for _ in range(m)] for _ in range(n)]
    for i in product(*iterables, tqdm_class=tqdm_auto,
                     ascii=True, mininterval=0.01):
        pass

    # Test with a small number of large iterables
    n = 3
    m = 1000000
    iterables = [[random.random() for _ in range(m)] for _ in range(n)]

# Generated at 2022-06-18 11:14:01.086043
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_helper(tqdm_class, iterables, total):
        """
        Helper function for testing product
        """
        t0 = time.time()
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass
        t1 = time.time()
        print("\n\n")
        print("tqdm_class:", tqdm_class)
        print("iterables:", iterables)
        print("total:", total)
        print("time:", format_interval(t1 - t0))

# Generated at 2022-06-18 11:14:08.232267
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import gc

    def test(iterables, **kwargs):
        """
        Unit test for function product
        """
        t0 = time.time()
        gc.disable()
        for _ in product(*iterables, **kwargs):
            pass
        gc.enable()
        t1 = time.time()
        print("\n".join([
            "product(*{})".format(iterables),
            "  -> {}".format(format_interval(t1 - t0)),
            "  -> {}".format(format_sizeof(sys.getsizeof(iterables))),
        ]))


# Generated at 2022-06-18 11:14:17.032952
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percentage
    from ..utils import format_rate
    from ..utils import format_time
    from ..utils import format_interval_short
    from ..utils import format_interval_long
    from ..utils import format_interval_full
    from ..utils import format_interval_full_long

# Generated at 2022-06-18 11:14:23.085090
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:14:31.973841
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_length
    from ..utils import format_length_short
    from ..utils import format_length_long
    from ..utils import format_length_full
    from ..utils import format_length_mixed
    from ..utils import format_length_alt
    from ..utils import format_length_full_alt
    from ..utils import format_length_mixed_alt
    from ..utils import format_length_short_alt
    from ..utils import format_length

# Generated at 2022-06-18 11:14:41.235863
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    print("\t", format_interval(time.time() - t))

    # Test 2
    print("Test 2:")
    t = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("\t", format_interval(time.time() - t))

    # Test 3
    print("Test 3:")
    t = time

# Generated at 2022-06-18 11:14:49.576932
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    # Test with a list
    lst = list(range(10))

    # Test with a tuple
    tpl = tuple(range(10))

    # Test with a set
    st = set(range(10))

    # Test with a dict
    dct = dict(zip(range(10), range(10)))

    # Test with a string
    strng = "abcdefghij"

    # Test with a range
    rng = range(10)

    # Test with a bytearray

# Generated at 2022-06-18 11:14:58.767464
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("Test 1:")
    for i in product(range(3), range(3), range(3),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=True):
        time.sleep(0.01)

    # Test 2
    print("Test 2:")
    for i in product(range(3), range(3), range(3),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        time.sleep(0.01)

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:15:06.306695
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..tqdm import trange

    # Test 1
    t = trange(10, desc='test 1', leave=False)
    for i in product(t, range(10)):
        pass
    t.close()

    # Test 2
    t = trange(10, desc='test 2', leave=False)
    for i in product(t, range(10), range(10)):
        pass
    t.close()

    # Test 3
    t = trange(10, desc='test 3', leave=False)
    for i in product(t, range(10), range(10), range(10)):
        pass

# Generated at 2022-06-18 11:15:09.293727
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assert_equal(tc.n, 100)

# Generated at 2022-06-18 11:15:16.604934
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import random
    import sys
    import time

    # Test 1:
    # Test with a simple example
    # (1, 2, 3) x (4, 5)
    # Expected result:
    # (1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)
    #
    # Test 2:
    # Test with a large example
    # (1, 2, 3, ..., 100) x (1, 2, 3, ..., 100)
    # Expected result:
    # (1, 1), (1, 2), (1, 3), ..., (1, 100), (2, 1), (2, 2), ..., (

# Generated at 2022-06-18 11:15:24.901190
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys

    def test_product_gen(iterables):
        for i in product(*iterables):
            pass

    def test_itertools_product_gen(iterables):
        for i in itertools.product(*iterables):
            pass

    def test_product_list(iterables):
        list(product(*iterables))

    def test_itertools_product_list(iterables):
        list(itertools.product(*iterables))

    def test_product_set(iterables):
        set(product(*iterables))

    def test_itertools_product_set(iterables):
        set(itertools.product(*iterables))


# Generated at 2022-06-18 11:15:35.355723
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:15:41.482124
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys
    import os
    import random
    import string

    # Test 1
    print("Test 1:")
    print("  Generating random data...")
    n = 10
    m = 5
    random.seed(0)
    data = [
        [
            ''.join(random.choice(string.ascii_uppercase + string.digits)
                    for _ in range(random.randint(1, 10)))
            for _ in range(m)
        ]
        for _ in range(n)
    ]

# Generated at 2022-06-18 11:15:51.225126
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

# Generated at 2022-06-18 11:16:03.825955
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_inner(iterables, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    # Test with a small number of elements
    test_product_inner([range(10), range(10), range(10)], tqdm_auto)

    # Test with a large number of elements
    test_product_inner([range(100), range(100), range(100)], tqdm_auto)

    # Test with a very large number of elements
    test_product_inner([range(1000), range(1000), range(1000)], tqdm_auto)



# Generated at 2022-06-18 11:16:10.150436
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter
    from .utils import FormatCustomText
    from .std import tqdm

    with closing(tqdm(product(range(10), range(10)),
                      desc="product",
                      ascii=True,
                      bar_format=FormatCustomText("{desc}: {percentage:3.0f}%"))) as pbar:
        for _ in pbar:
            pass
    assert pbar.n == 100
    assert pbar.total == 100
    assert pbar.last_print_n == 100
    assert pbar.last_print_refresh_time > 0


# Generated at 2022-06-18 11:16:19.722002
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string

    # Test 1
    print("Test 1:")
    print("  - Randomly generate a list of lists of random strings")
    print("  - Compute the product of the lists")
    print("  - Compute the product of the lists with tqdm")
    print("  - Compare the results")
    print("  - Compare the memory usage")
    print("  - Compare the time usage")
    print("")
    print("  Note:")
    print("    - The results should be the same")
    print("    - The memory usage should be the same")
    print("    - The time usage should be the same")
    print

# Generated at 2022-06-18 11:16:28.914486
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Iterating over product"):
        pass

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:16:36.068881
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Test product generator.
        """
        for _ in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_class):
        """
        Test product list.
        """
        list(product(*iterables, tqdm_class=tqdm_class))


# Generated at 2022-06-18 11:16:45.538274
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_html_fmt
    from ..utils import format_dict_json
    from ..utils import format_dict_

# Generated at 2022-06-18 11:16:53.922249
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a list of lists
    l = [[1, 2], [3, 4], [5, 6]]
    assert list(product(*l)) == [(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6),
                                 (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)]

    # Test with a list of generators
    l = [range(10), range(10), range(10)]

# Generated at 2022-06-18 11:17:01.826336
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:17:07.634324
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO

    class FormatWrap(FormatWrapBase):
        def __init__(self, *args, **kwargs):
            super(FormatWrap, self).__init__(*args, **kwargs)
            self.format_dict['desc'] = '{desc}'
            self.format_dict['bar'] = '{bar}'
            self.format_dict['n'] = '{n}'
            self.format_dict['total'] = '{total}'
            self.format_dict['rate'] = '{rate}'
            self.format_dict['rate_noinv'] = '{rate_noinv}'

# Generated at 2022-06-18 11:17:15.876803
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test for function product
    def test_product_func(iterables, tqdm_class, **tqdm_kwargs):
        """Test for function product"""
        kwargs = tqdm_kwargs.copy()
        kwargs.setdefault("desc", "test_product_func")
        kwargs.setdefault("unit", "it")
        kwargs.setdefault("unit_scale", True)
        kwargs.setdefault("miniters", 1)
        kwargs.setdefault("leave", True)
        kwargs.setdefault("ascii", True)

# Generated at 2022-06-18 11:17:27.202089
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal

    # Test with no total
    assert_array_equal(
        list(product(range(3), repeat=2)),
        np.array(list(itertools.product(range(3), repeat=2))))

    # Test with total
    assert_array_equal(
        list(product(range(3), repeat=2, total=9)),
        np.array(list(itertools.product(range(3), repeat=2))))

    # Test with total and tqdm_class
    assert_array_equal(
        list(product(range(3), repeat=2, total=9, tqdm_class=tqdm_auto)),
        np.array(list(itertools.product(range(3), repeat=2))))

# Generated at 2022-06-18 11:17:33.649318
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import sys
    import time
    import random
    from ..utils import format_interval

    # Test with no iterables
    assert list(product()) == [()]

    # Test with one iterable
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    # Test with two iterables
    assert list(product([1, 2, 3], [4, 5, 6])) == [(1, 4), (1, 5), (1, 6),
                                                    (2, 4), (2, 5), (2, 6),
                                                    (3, 4), (3, 5), (3, 6)]

    # Test with three iterables

# Generated at 2022-06-18 11:17:41.468827
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test for product

# Generated at 2022-06-18 11:17:50.256570
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for _ in product(*iterables, **tqdm_kwargs):
            pass

    def test_product_generator_nested(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for _ in product(*[test_product_generator(i, **tqdm_kwargs)
                           for i in iterables], **tqdm_kwargs):
            pass


# Generated at 2022-06-18 11:18:00.080881
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_func(iterables, tqdm_class):
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_func_no_tqdm(iterables):
        for i in itertools.product(*iterables):
            pass

    def test_product_func_no_tqdm_no_iter(iterables):
        pass

    def test_product_func_no_tqdm_no_iter_no_args(iterables):
        pass

    def test_product_func_no_tqdm_no_iter_no_args_no_kwargs(iterables):
        pass


# Generated at 2022-06-18 11:18:09.808002
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from itertools import product as itertools_product

    # Test 1
    t0 = time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time()
    t2 = time()
    for i in itertools_product(range(10), range(10), range(10), range(10)):
        pass
    t3 = time()
    print("\nTest 1:")
    print("product(range(10), range(10), range(10), range(10))")


# Generated at 2022-06-18 11:18:16.717709
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:18:26.140862
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

# Generated at 2022-06-18 11:18:35.265036
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase, FormatWrapBytesIO
    from .utils import closing
    from .utils import StringIO

    with closing(StringIO()) as our_file:
        with closing(FormatWrapBase(our_file)) as f:
            for _ in product(range(10), range(10), tqdm_class=tqdm_auto,
                             file=f):
                pass
            assert len(f.file.getvalue()) > 0

    with closing(StringIO()) as our_file:
        with closing(FormatWrapBytesIO(our_file)) as f:
            for _ in product(range(10), range(10), tqdm_class=tqdm_auto,
                             file=f):
                pass

# Generated at 2022-06-18 11:18:43.113225
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_stats
    from .utils import format_line
    from .utils import format_bar
    from .utils import format_over
    from .utils import format_under
    from .utils import format_postfix
    from .utils import format_dict
    from .utils import format_dict_html
    from .utils import format_dict_text
    from .utils import format_

# Generated at 2022-06-18 11:18:56.281502
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(100), range(100), range(100), range(100)):
        pass
    t1 = time.time()
    print("\t", i)
    print("\t", format_interval(t1 - t0))
    print("\t", format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:19:04.386966
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for _ in product(*iterables, **tqdm_kwargs):
            pass

    # Test 1: simple product
    for i in test_product_gen([range(10), range(10)],
                              tqdm_class=tqdm_auto,
                              desc="test 1"):
        pass

    # Test 2: simple product with total

# Generated at 2022-06-18 11:19:11.795177
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np
    import pandas as pd
    import pandas.util.testing as pdt
    import tqdm
    import tqdm.contrib.concurrent
    import tqdm.contrib.test_utils

    # Test 1
    with tqdm.contrib.test_utils.disable_stdout_capturing():
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm.tqdm):
            pass

    # Test 2

# Generated at 2022-06-18 11:19:20.325406
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("Test 1:")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")

# Generated at 2022-06-18 11:19:29.419272
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1")
    t = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False,
                     file=sys.stdout):
        pass
    print("\nElapsed:", format_interval(time.time() - t))

    # Test 2
    print("Test 2")
    t = time.time()

# Generated at 2022-06-18 11:19:38.214120
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

        for i in product(range(10), range(10), tqdm_class=tc.tqdm,
                         mininterval=0.01):
            pass
        tc.assertEqual(tc.sp, tc.si)

        for i in product(range(10), range(10), tqdm_class=tc.tqdm,
                         mininterval=0.01, miniters=1):
            pass
        tc.assertEqual(tc.sp, tc.si)


# Generated at 2022-06-18 11:19:46.965641
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    def rand_list(n):
        return [randint(0, n) for _ in range(n)]

    def rand_list_of_lists(n, m):
        return [rand_list(m) for _ in range(n)]

    def rand_list_of_lists_of_lists(n, m, p):
        return [rand_list_of_lists(m, p) for _ in range(n)]


# Generated at 2022-06-18 11:19:56.320773
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import tqdm
    from .utils import FormatCustomText

    # Test with total
    for i in product(range(10), range(10), tqdm_class=tqdm,
                     desc="Test", ascii=True):
        pass

    # Test without total
    for i in product(range(10), range(10), tqdm_class=tqdm,
                     desc="Test", ascii=True, total=None):
        pass

    # Test with custom format

# Generated at 2022-06-18 11:20:06.058610
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    def test_product_helper(iterables, tqdm_class, total=None):
        """
        Helper function for testing product
        """
        # Test with tqdm
        with tqdm_class(total=total) as t:
            for i in product(*iterables, tqdm_class=tqdm_class):
                t.update()
        # Test without tqdm
        with tqdm_class(total=total) as t:
            for i in product(*iterables):
                t.update()
        # Test with tqdm and total=None

# Generated at 2022-06-18 11:20:13.631836
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]