

# Generated at 2022-06-18 11:10:22.510702
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    assert list(product(gen())) == list(itertools.product(gen()))

    # Test with a list
    assert list(product([1, 2])) == list(itertools.product([1, 2]))

    # Test with a list and a generator
    assert list(product([1, 2], gen())) == list(itertools.product([1, 2], gen()))

    # Test with a list and a generator and a tqdm_class

# Generated at 2022-06-18 11:10:33.648632
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from . import trange

    # Test with trange
    for i in trange(10, desc="product"):
        time.sleep(0.01)

    # Test with product
    for i in product(range(10), range(10), range(10),
                     tqdm_class=trange, desc="product"):
        time.sleep(0.01)

    # Test with product
    for i in product(range(10), range(10), range(10),
                     tqdm_class=trange, desc="product",
                     unit="it", unit_scale=True, unit_divisor=1024):
        time.sleep(0.01)

    # Test with product
   

# Generated at 2022-06-18 11:10:41.765630
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6]]
    list_of_lists_expected = [(1, 4), (1, 5), (1, 6),
                              (2, 4), (2, 5), (2, 6),
                              (3, 4), (3, 5), (3, 6)]
    list_of_lists_result = list(product(list_of_lists))
    assert list_of_lists_result == list_of_lists_expected

    # Test with a list of lists and a tqdm_class

# Generated at 2022-06-18 11:10:53.427242
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

# Generated at 2022-06-18 11:11:02.714275
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_gen():
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=tqdm_auto,
                         desc="test_product",
                         leave=True):
            yield i

    t = test_gen()
    for _ in range(10):
        next(t)
    time.sleep(0.01)
    assert t.n == 10
    assert t.total == 1e6
    assert t.smoothing == 1.0
    assert t.dynamic_ncols
    assert t.unit == "it"
    assert t.unit_scale
    assert t.miniters == 1

# Generated at 2022-06-18 11:11:13.134002
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with tqdm(total=None)
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with tqdm(total=100)
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with tqdm(total=100) and nested loops
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        for j in product(range(10), range(10), tqdm_class=tqdm_auto):
            pass

    # Test with tqdm(total

# Generated at 2022-06-18 11:11:21.890153
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar

# Generated at 2022-06-18 11:11:31.323495
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test for function product
    # -------------------------
    # Test 1
    # ------
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Test with a simple example
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~


# Generated at 2022-06-18 11:11:39.645411
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:", end=' ')
    sys.stdout.flush()
    t = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    t = time.time() - t
    print("{0:.3f}s".format(t))

    # Test 2
    print("Test 2:", end=' ')
    sys.stdout.flush()
    t = time.time()
    for i in itertools.product(range(10), range(10), range(10)):
        pass
    t = time.time() - t

# Generated at 2022-06-18 11:11:48.438626
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_html_fmt
    from ..utils import format_dict_json
    from ..utils import format_dict_json_fmt

# Generated at 2022-06-18 11:12:00.660002
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test for total

# Generated at 2022-06-18 11:12:09.086647
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys
    import os
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_speed
    from .utils import format_size
    from .utils import format_line
    from .utils import format_length
    from .utils import format_naturalsize
    from .utils import format_number
    from .utils import format_interval
    from .utils import format_timespan
    from .utils import format_speed
    from .utils import format_size

# Generated at 2022-06-18 11:12:18.643072
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(1000), range(1000)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(1000), range(1000), tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(1000), range(1000), tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:12:26.698010
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a list of lists
    list_of_lists = [list(range(10)), list(range(10, 20)), list(range(20, 30))]
    list_of_lists_prod = list(itertools.product(*list_of_lists))
    list_of_lists_prod_tqdm = list(product(*list_of_lists))
    assert list_of_lists_prod == list_of_lists_prod_tqdm

    # Test with a list of arrays

# Generated at 2022-06-18 11:12:36.093751
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test with no iterables
    assert list(product()) == [()]

    # Test with one iterable
    assert list(product([1, 2])) == [(1,), (2,)]

    # Test with two iterables
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]

    # Test with three iterables

# Generated at 2022-06-18 11:12:43.865069
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys

    def test_product_generator(iterables, **kwargs):
        """
        Generator for test_product.
        """
        for i in product(*iterables, **kwargs):
            yield i

    def test_product_list(iterables, **kwargs):
        """
        List for test_product.
        """
        return list(product(*iterables, **kwargs))

    def test_product_list_itertools(iterables, **kwargs):
        """
        List for test_product.
        """
        return list(itertools.product(*iterables, **kwargs))


# Generated at 2022-06-18 11:12:52.705208
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    t = tqdm_auto(total=20)
    for i in product(range(5), range(5), tqdm_class=t.__class__):
        time.sleep(0.01)
    assert t.n == 20

    # Test 2
    t = tqdm_auto(total=20)
    for i in product(range(5), range(5), tqdm_class=t.__class__):
        time.sleep(0.01)
    assert t.n == 20

    # Test 3
    t = tqdm_auto(total=20)

# Generated at 2022-06-18 11:13:02.970655
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number

# Generated at 2022-06-18 11:13:11.154970
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from itertools import repeat
    from itertools import chain
    from itertools import islice
    from itertools import starmap
    from itertools import tee
    from itertools import cycle
    from itertools import compress
    from itertools import dropwhile
    from itertools import takewhile
    from itertools import groupby
    from itertools import filterfalse
    from itertools import zip_longest
    from itertools import count
    from itertools import accumulate
    from itertools import chain

# Generated at 2022-06-18 11:13:17.858395
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test 1
    print("Test 1:")
    print("  - Test product() with a single iterable")
    print("  - Test product() with a single iterable and a total")
    print("  - Test product() with a single iterable and a total=None")
    print("  - Test product() with a single iterable and a total=0")
    print("  - Test product() with a single iterable and a total=1")
    print("  - Test product() with a single iterable and a total=2")
    print("  - Test product() with a single iterable and a total=3")

# Generated at 2022-06-18 11:13:29.470848
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_number
    from ..utils import format_percentage
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_as_size
    from ..utils import format_as_length
    from ..utils import format_as_number
    from ..utils import format_as_time
    from ..utils import format

# Generated at 2022-06-18 11:13:37.618833
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_iter(iterables, tqdm_class=None):
        """
        Unit test for function product
        """
        if tqdm_class is None:
            tqdm_class = tqdm_auto
        with tqdm_class(total=len(iterables), file=sys.stderr) as t:
            for i in product(*iterables, tqdm_class=tqdm_class):
                t.update()
                yield i

    def test_product_iter_no_tqdm(iterables):
        """
        Unit test for function product
        """

# Generated at 2022-06-18 11:13:43.766540
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from itertools import product as itertools_product

    # Test with a single iterable
    for n in [10, 100, 1000, 10000]:
        for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
            t0 = time()
            for _ in product(range(n), tqdm_class=tqdm_class):
                pass
            t1 = time()
            for _ in itertools_product(range(n)):
                pass
            t2 = time()

# Generated at 2022-06-18 11:13:53.487880
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import random
    import time
    import numpy as np
    from ..utils import format_interval

    # Create a random list of lists
    random.seed(0)
    N = 100
    M = 10
    L = [random.randint(1, 10) for _ in range(N)]
    L = [list(range(i)) for i in L]

    # Create a random list of lists
    random.seed(0)
    N = 100
    M = 10
    L = [random.randint(1, 10) for _ in range(N)]
    L = [list(range(i)) for i in L]

    # Create a random list of lists
    random.seed(0)
   

# Generated at 2022-06-18 11:14:02.373887
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_

# Generated at 2022-06-18 11:14:05.522230
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:14:15.141378
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1")
    t = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    print("  Elapsed time:", format_interval(time.time() - t))
    print("  Memory usage:", format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2")
    t = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-18 11:14:21.779565
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a list of lists
    list_of_lists = [[1, 2], [3, 4], [5, 6]]
    for i in product(list_of_lists):
        pass

    # Test with a list of generators
    list_of_generators = [xrange(1, 3), xrange(3, 5), xrange(5, 7)]
    for i in product(list_of_generators):
        pass

    # Test with a list of generators and a list of lists
    list_of_generators = [xrange(1, 3), xrange(3, 5), [5, 6]]

# Generated at 2022-06-18 11:14:31.019484
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    dt = time.time() - t0
    print("\nTest 1: dt = %s" % format_interval(dt))
    print("Test 1: memory = %s" % format_sizeof(sys.getsizeof(i)))
    print("Test 1: memory = %s" % format_sizeof(os.times()))

    # Test 2

# Generated at 2022-06-18 11:14:38.597931
# Unit test for function product
def test_product():
    """Test for function product"""
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_size_short
    from ..utils import format_size_long
    from ..utils import format_size_full
    from ..utils import format_size_full_short
    from ..utils import format_size_full_long
    from ..utils import format_size_full_long_short
    from ..utils import format_size_full_long_long
    from ..utils import format_size_full_long_long_short

# Generated at 2022-06-18 11:14:49.618940
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format

# Generated at 2022-06-18 11:14:58.798929
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_inner(a, b, c, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(a, b, c, tqdm_class=tqdm_class):
            pass

    # Test with a large number of items
    a = range(1000)
    b = range(1000)
    c = range(1000)
    test_product_inner(a, b, c, tqdm_auto)

    # Test with a large number of items and a large total
    a = range(1000)
    b = range(1000)
    c = range(1000)

# Generated at 2022-06-18 11:15:06.340172
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with no iterable
    for _ in product():
        pass

    # Test with one iterable
    for _ in product(range(10)):
        pass

    # Test with two iterables
    for _ in product(range(10), range(10)):
        pass

    # Test with three iterables
    for _ in product(range(10), range(10), range(10)):
        pass

    # Test with four iterables
    for _ in product(range(10), range(10), range(10), range(10)):
        pass

    # Test with five iterables

# Generated at 2022-06-18 11:15:13.208371
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time

    # Test 1
    print("Test 1:")
    print("  * Generate a list of all possible combinations of [1, 2, 3] and "
          "['a', 'b', 'c']")
    print("  * Expected result:")
    print("    [(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b'), (2, 'c'), "
          "(3, 'a'), (3, 'b'), (3, 'c')]")
    print("  * Actual result:")

# Generated at 2022-06-18 11:15:21.279057
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test with a simple list
    l = list(range(10))
    for i in product(l):
        assert i in itertools.product(l)

    # Test with a simple list and a tqdm_class
    l = list(range(10))
    for i in product(l, tqdm_class=tqdm_auto):
        assert i in itertools.product(l)

    # Test with a simple list and a tqdm_class
    l = list(range(10))

# Generated at 2022-06-18 11:15:32.072385
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_speed_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_

# Generated at 2022-06-18 11:15:39.188996
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_iter(iterable, tqdm_class=tqdm_auto):
        """
        Test that `product` is equivalent to `itertools.product`
        """
        for i in product(*iterable, tqdm_class=tqdm_class):
            pass

    def test_product_iter_itertools(iterable):
        """
        Test that `product` is equivalent to `itertools.product`
        """
        for i in itertools.product(*iterable):
            pass


# Generated at 2022-06-18 11:15:48.746602
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import numpy as np
    from ..utils import format_interval

    # Test 1
    print("\nTest 1:")
    print("Generating random list of ints")
    list_size = 100000
    list_of_ints = [random.randint(0, 100) for i in range(list_size)]
    print("Size of list:", format_sizeof(sys.getsizeof(list_of_ints)))
    print("Generating cartesian product of list")
    start_time = time.time()
    for i in product(list_of_ints, list_of_ints):
        pass

# Generated at 2022-06-18 11:15:57.673309
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    # Test with a list
    lst = list(range(10))

    # Test with a tuple
    tup = tuple(range(10))

    # Test with a set
    st = set(range(10))

    # Test with a dict
    dct = dict(zip(range(10), range(10)))

    # Test with a string
    strng = "abcdefghij"

    # Test with a range
    rng = range(10)

    # Test with a bytearray
    bytearr = bytearray(range(10))

    # Test with a memory

# Generated at 2022-06-18 11:16:04.973250
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_json
    from ..utils import format_dict_yaml
    from ..utils import format_dict_toml

# Generated at 2022-06-18 11:16:20.128345
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1
    print("Test 1")
    for i in product(range(10), repeat=3):
        print(i)
        time.sleep(0.1)

    # Test 2
    print("Test 2")
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.1)

    # Test 3
    print("Test 3")
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
        time.sleep(0.1)

# Generated at 2022-06-18 11:16:29.376662
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof

    def test_product_generator(iterables, total, **kwargs):
        """
        Test product generator.
        """
        for i, j in zip(product(*iterables, **kwargs),
                        itertools.product(*iterables)):
            assert i == j
            assert i == tuple(j)
        assert i == tuple(j)

    # Test product generator
    test_product_generator([[1, 2, 3], [4, 5, 6]], 18)
    test_product_generator([[1, 2, 3], [4, 5, 6]], 18, tqdm_class=tqdm_auto)

# Generated at 2022-06-18 11:16:34.415888
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    for _ in product(list_of_lists):
        pass

    # Test with a list of generators
    list_of_generators = [range(3), range(4), range(5)]
    for _ in product(list_of_generators):
        pass

    # Test with a generator of lists
    generator_of_lists = (range(3), range(4), range(5))
    for _ in product(generator_of_lists):
        pass

    # Test with a generator of generators

# Generated at 2022-06-18 11:16:43.025978
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import closing, closing_iter
    from .tests import tqdm_class, tqdm_class_inst
    from .tests import tqdm_class_inst_new_total
    from .tests import tqdm_class_inst_new_total_post_iter
    from .tests import tqdm_class_inst_new_total_post_iter_leave
    from .tests import tqdm_class_inst_new_total_post_iter_noleave
    from .tests import tqdm_class_inst_new_total_post_iter_noleave_close
    from .tests import tqdm_class_inst_new_total_post_iter_noleave_close_leave
    from .tests import tqdm_class_inst_

# Generated at 2022-06-18 11:16:51.595828
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import sys
    import os
    import time
    import numpy as np

    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product
    # Test for function product

# Generated at 2022-06-18 11:16:59.835332
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=None, file=sys.stdout)
    for i in product(range(10), range(10), range(10),
                     tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=None, file=sys.stdout)
    for i in product(range(10), range(10), range(10),
                     tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3

# Generated at 2022-06-18 11:17:06.458947
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_dict
    from ..utils import format_interval_dict
    from ..utils import format_meter_dict
    from ..utils import format_timespan_dict

# Generated at 2022-06-18 11:17:15.096067
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(iterables, total=None):
        """
        Generator for testing product
        """
        for i in itertools.product(*iterables):
            yield i

    def test_product_tqdm(iterables, total=None):
        """
        Generator for testing product
        """
        for i in product(*iterables, total=total):
            yield i

    def test_product_tqdm_auto(iterables, total=None):
        """
        Generator for testing product
        """
        for i in product(*iterables, total=total, tqdm_class=tqdm_auto):
            yield i


# Generated at 2022-06-18 11:17:20.380936
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import string

    # Create a list of random strings
    random_strings = [
        ''.join(random.choice(string.ascii_uppercase + string.digits)
                for _ in range(random.randint(1, 10)))
        for _ in range(random.randint(1, 10))]

    # Create a list of random integers
    random_integers = [random.randint(1, 100) for _ in range(random.randint(1, 10))]

    # Create a list of random floats
    random_floats = [random.random() for _ in range(random.randint(1, 10))]

    # Create a list of random boole

# Generated at 2022-06-18 11:17:28.750974
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_interval
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_size
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_interval
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_size
    from ..utils import format_

# Generated at 2022-06-18 11:17:47.826118
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof
    from itertools import product as itertools_product

    def test_product_helper(iterables, tqdm_class=tqdm_auto):
        """
        Helper function for unit test of function product.
        """
        # Test that both product functions return the same results
        tqdm_product = list(product(*iterables, tqdm_class=tqdm_class))
        itertools_product = list(itertools_product(*iterables))
        assert tqdm_product == itertools_product

        # Test that both product functions return the same results
        # (

# Generated at 2022-06-18 11:17:57.731182
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:", end=' ')
    t = time.time()
    for i in product(range(1000), repeat=2):
        pass
    t = time.time() - t
    print("OK" if t < 1 else "FAIL")

    # Test 2
    print("Test 2:", end=' ')
    t = time.time()
    for i in product(range(1000), repeat=2):
        pass
    t = time.time() - t
    print("OK" if t < 1 else "FAIL")

    # Test 3
    print("Test 3:", end=' ')
    t = time.time()

# Generated at 2022-06-18 11:18:07.018862
# Unit test for function product
def test_product():
    """Test for function product"""
    from numpy.testing import assert_equal
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short

# Generated at 2022-06-18 11:18:14.987982
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:18:20.294865
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("Elapsed time: %s" % format_interval(t1 - t0))
    print("Memory usage: %s" % format_sizeof(sys.getsizeof(i)))
    print("")

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:18:30.238326
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_times
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_times
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_times
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_times
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_times
    from ..utils import format_interval
    from ..utils import format_sizeof

# Generated at 2022-06-18 11:18:38.346041
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    with tqdm_auto(unit='B', unit_scale=True) as t:
        for i in product(range(1000), range(1000), range(1000)):
            t.update()
    assert t.n == 1000000000
    assert t.total == 1000000000
    assert t.last_print_n == t.n
    assert t.dynamic_ncols
    assert t.smoothing == 0
    assert t.unit == 'B'
    assert t.unit_scale
    assert t.miniters == 1
    assert t.mininterval == 0.1
    assert t.maxinterval == 10.0
    assert t.file

# Generated at 2022-06-18 11:18:47.328665
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    from ..utils import _range

    # Test 1
    print("Test 1:", end=' ')
    try:
        for _ in tqdm_auto(product(range(10), range(10), range(10))):
            pass
    except:
        print("FAIL")
    else:
        print("PASS")

    # Test 2
    print("Test 2:", end=' ')
    try:
        for _ in tqdm_auto(product(range(10), range(10), range(10)),
                           total=1000):
            pass
    except:
        print("FAIL")

# Generated at 2022-06-18 11:18:55.672617
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1: basic
    for i in product(range(3), range(3), range(3)):
        pass
    # Test 2: total
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto,
                     total=27):
        pass
    # Test 3: nested
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        for j in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
            pass
    # Test 4: nested total

# Generated at 2022-06-18 11:19:03.815222
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test with a simple iterator
    for i in product(range(10), repeat=3):
        pass
    # Test with a simple iterator
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        pass
    # Test with a simple iterator
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto,
                     mininterval=0.1):
        pass
    # Test with a simple iterator

# Generated at 2022-06-18 11:19:30.396465
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(iterables, total, tqdm_class=tqdm_auto):
        """
        Unit test for function product
        """
        kwargs = {}
        kwargs.setdefault("total", total)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
                t.update()

    def test_product_generator_no_total(iterables, tqdm_class=tqdm_auto):
        """
        Unit test for function product
        """
        kwargs = {}

# Generated at 2022-06-18 11:19:39.191085
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .utils import format_time
    from .utils import SimpleNamespace
    import time
    import sys

    # Test with tqdm_class=tqdm.auto.tqdm

# Generated at 2022-06-18 11:19:47.262826
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    def test_product_generator(iterables, tqdm_class):
        """
        Test the product generator.
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_numpy(iterables, tqdm_class):
        """
        Test the product numpy.
        """
        np.product(*iterables)

    def test_product_itertools(iterables, tqdm_class):
        """
        Test the product itertools.
        """
        for i in itertools.product(*iterables):
            pass


# Generated at 2022-06-18 11:19:56.588157
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test with no iterable
    for i in product():
        assert False

    # Test with one iterable
    for i in product(range(10)):
        assert i == (0,)
        break
    for i in product(range(10)):
        assert i == (1,)
        break
    for i in product(range(10)):
        assert i == (9,)
        break

    # Test with two iterables
    for i in product(range(10), range(10)):
        assert i == (0, 0)


# Generated at 2022-06-18 11:20:06.595819
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tqdm import trange
    from ..utils import format_sizeof
    from .tests_tqdm import pretest_posttest

    def test_product_gen(iterables, **kwargs):
        """
        Generator for unit test for function product.
        """
        for i in product(*iterables, **kwargs):
            yield i

    def test_product_size(iterables, **kwargs):
        """
        Generator for unit test for function product.
        """
        for i in product(*iterables, **kwargs):
            yield i, format_sizeof(i)

    def test_product_nested(iterables, **kwargs):
        """
        Generator for unit test for function product.
        """

# Generated at 2022-06-18 11:20:11.082793
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tqdm import tqdm
    from ..utils import _range

    def test_product_range(tqdm_class):
        for i in tqdm_class.product(_range(10), _range(10),
                                    tqdm_class=tqdm_class):
            pass

    test_product_range(tqdm)
    test_product_range(tqdm_auto)