

# Generated at 2022-06-18 11:10:18.385584
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_inter

# Generated at 2022-06-18 11:10:28.104504
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_dict
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict_fmt
    from ..utils import format_custom_text_fmt
    from ..utils import format_custom_text_type
    from ..utils import format_custom_text_dict

# Generated at 2022-06-18 11:10:38.535908
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with tqdm_class=tqdm.tqdm
    tqdm_class = tqdm_auto
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_class):
        pass

    # Test with tqdm_class=tqdm.tqdm_gui
    try:
        from tqdm import tqdm_gui
    except ImportError:
        pass
    else:
        tqdm_class = tqdm_gui
        for i in product(range(10), range(10), range(10), tqdm_class=tqdm_class):
            pass

    # Test with tqdm

# Generated at 2022-06-18 11:10:44.760794
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("\nTest 1:")
    print("  - Test with 3 iterables of sizes 10, 20, 30")
    print("  - Test with total=None")
    print("  - Test with tqdm_class=tqdm_notebook")
    print("  - Test with smoothing=0")
    print("  - Test with dynamic_ncols=True")
    print("  - Test with leave=True")
    print("  - Test with position=0")
    print("  - Test with unit='it'")
    print("  - Test with unit_scale=True")

# Generated at 2022-06-18 11:10:55.800706
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_json
    from ..utils import format_dict_js
    from ..utils import format_dict_latex

# Generated at 2022-06-18 11:11:05.489551
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import numpy as np
    import pandas as pd

    # Test 1
    print("Test 1:")
    print("  * itertools.product(range(10), range(10))")
    print("  * tqdm.product(range(10), range(10))")
    print("  * tqdm.product(range(10), range(10), tqdm_class=tqdm.tqdm_gui)")
    print("  * tqdm.product(range(10), range(10), tqdm_class=tqdm.tqdm_notebook)")

# Generated at 2022-06-18 11:11:15.529640
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 4", miniters=1):
        pass

# Generated at 2022-06-18 11:11:23.509023
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import getsizeof
    from itertools import product
    from ..utils import FormatCustomTextTestResult

    def test_product_generator(tqdm_cls):
        """
        Test that `tqdm.itertools.product` is equivalent to `itertools.product`
        """

# Generated at 2022-06-18 11:11:34.039095
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test 1: simple test
    for i in product(range(10), range(10)):
        pass

    # Test 2: test with total
    for i in product(range(10), range(10), tqdm_class=tqdm_auto, total=100):
        pass

    # Test 3: test with total and leave
    for i in product(range(10), range(10), tqdm_class=tqdm_auto, total=100,
                     leave=True):
        pass

    # Test 4: test with total and leave and mininterval

# Generated at 2022-06-18 11:11:40.625206
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)
        tc.assertEqual(tc.sp, 100)

        for i in product(range(10), range(10), tqdm_class=tc.tqdm,
                         total=100):
            pass
        tc.assertEqual(tc.sp, tc.si)
        tc.assertEqual(tc.sp, 100)

        for i in product(range(10), range(10), tqdm_class=tc.tqdm,
                         total=None):
            pass

# Generated at 2022-06-18 11:11:51.564896
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..std import StringIO
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np
    import random

    # Test with no iterable
    for i in product():
        pass

    # Test with one iterable
    for i in product(range(10)):
        assert i == (0,)
        break

    # Test with two iterables
    for i in product(range(10), range(10)):
        assert i == (0, 0)
        break

    # Test with three iterables
    for i in product(range(10), range(10), range(10)):
        assert i == (0, 0, 0)
        break

    # Test with four iterables

# Generated at 2022-06-18 11:12:01.196792
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1:
    # Check that the total is correctly computed
    # and that the iterator is correctly consumed
    # (i.e. that the progress bar reaches 100%)
    t = time.time()
    for _ in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    t.close()
    assert t.n == 1000
    assert t.total == 1000
    assert t.last_print_n == 1000
    assert t.last_print_refresh_time == t.last_print_t

# Generated at 2022-06-18 11:12:10.504873
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:12:19.249399
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test with a small number of elements
    for iterable in [range(10), range(10)]:
        for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
            for total in [None, 10]:
                for leave in [True, False]:
                    for dynamic_ncols in [True, False]:
                        with tqdm_class(iterable,
                                        total=total,
                                        leave=leave,
                                        dynamic_ncols=dynamic_ncols) as t:
                            for i in t:
                                pass
                        assert t.n == 10

# Generated at 2022-06-18 11:12:20.660614
# Unit test for function product
def test_product():
    from . import _test_itertools
    _test_itertools.test_product(product)

# Generated at 2022-06-18 11:12:29.275632
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True,
                     file=sys.stdout):
        pass

    # Test 3
    print("Test 3")

# Generated at 2022-06-18 11:12:38.123815
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .. import trange

    # Test 1:
    # Test that the total is correctly computed
    # and that the iterator is correctly consumed
    for tqdm_class in [tqdm_auto, trange]:
        with tqdm_class(unit="B", unit_scale=True, miniters=1,
                        desc="test_product") as t:
            for i in product(range(10), repeat=3, tqdm_class=tqdm_class):
                pass
            assert t.total == 1000
            assert t.n == 1000

    # Test 2:
    # Test that the total is correctly computed
    # and that the iterator is correctly consumed

# Generated at 2022-06-18 11:12:45.333576
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def _test_product(iterables, total, tqdm_class, **tqdm_kwargs):
        """
        Unit test for function product.
        """
        tqdm_kwargs.setdefault("desc", "test_product")
        tqdm_kwargs.setdefault("unit", "it")
        tqdm_kwargs.setdefault("leave", True)
        tqdm_kwargs.setdefault("ascii", True)
        tqdm_kwargs.setdefault("miniters", 1)
        tqdm_kwargs.setdefault("smoothing", 0)

# Generated at 2022-06-18 11:12:53.875878
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_line
    from ..utils import format_over
    from ..utils import format_ascii
    from ..utils import format_ascii_speed
    from ..utils import format_ascii_size
    from ..utils import format_ascii_eta
    from ..utils import format_ascii_over
    from ..utils import format_ascii_stats
    from ..utils import format_ascii_line
    from ..utils import format_asci

# Generated at 2022-06-18 11:13:04.133323
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=2):
        print(i)
    print()

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
    print()

    # Test 3
    print("Test 3:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
    print()

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:13:14.696998
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    list_of_lists_product = list(product(list_of_lists))

# Generated at 2022-06-18 11:13:19.947755
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        tc.assertEqual(
            list(product(range(3), range(3), range(3), tqdm_class=tc.tqdm)),
            list(itertools.product(range(3), range(3), range(3))))
        tc.assertEqual(
            list(product(range(3), range(3), range(3), tqdm_class=tc.tqdm)),
            list(itertools.product(range(3), range(3), range(3))))

# Generated at 2022-06-18 11:13:29.876421
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_number

# Generated at 2022-06-18 11:13:37.928516
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test with no iterable
    for i in product():
        pass

    # Test with one iterable
    for i in product(range(10)):
        pass

    # Test with two iterables
    for i in product(range(10), range(10)):
        pass

    # Test with three iterables
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with four iterables
    for i in product(range(10), range(10), range(10), range(10)):
        pass

    # Test with five iterables

# Generated at 2022-06-18 11:13:43.990824
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    import random

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10)):
        pass
    t1 = time.time()
    print("Test 1:", format_interval(t1 - t0))

    # Test 2
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()

# Generated at 2022-06-18 11:13:54.268722
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time
    import random

    # Test for product
    for i in product(range(10), range(10), range(10),
                     tqdm_class=FormatCustomText,
                     desc=format_sizeof(sys.getsizeof(np.arange(1000))),
                     leave=False):
        time.sleep(0.001)
    for i in product(range(10), range(10), range(10),
                     tqdm_class=FormatCustomText,
                     desc=format_sizeof(sys.getsizeof(np.arange(1000))),
                     leave=True):
        time.sleep(0.001)

# Generated at 2022-06-18 11:14:02.593598
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:14:11.116774
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    t0 = time.time()
    for _ in product(range(10000), range(10000), range(10000)):
        pass
    t1 = time.time()
    print("Test 1:", format_interval(t1 - t0), format_sizeof(sys.getsizeof(_)))

    # Test 2
    t0 = time.time()
    for _ in itertools.product(range(10000), range(10000), range(10000)):
        pass
    t1 = time.time()
    print("Test 2:", format_interval(t1 - t0), format_sizeof(sys.getsizeof(_)))



# Generated at 2022-06-18 11:14:19.368648
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import gc

    # Test 1
    print("\nTest 1")
    t0 = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    t1 = time.time()
    print("\nTest 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Garbage created: %s" % format_sizeof(gc.collect()))
    print("  Python version: %s" % sys.version)

    # Test 2

# Generated at 2022-06-18 11:14:27.455247
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .tests_tqdm import pretest_posttest_monkeypatch

    class TestProduct(FormatMixin):
        def test_product(self):
            """
            Unit test for function product
            """
            with pretest_posttest_monkeypatch():
                for i in product(range(10), range(10), range(10),
                                 tqdm_class=self.tqdm_class):
                    pass
                self.assert_empty(self.out)
                self.assert_empty(self.err)


# Generated at 2022-06-18 11:14:39.868790
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timesince
    from ..utils import format_num
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timesince
    from ..utils import format_num
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timesince
    from ..utils import format_num
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:14:44.804833
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval

# Generated at 2022-06-18 11:14:53.621470
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time

    def test_product_speed(iterables, tqdm_class):
        """
        Test speed of product()
        """
        t0 = time()
        for _ in product(*iterables, tqdm_class=tqdm_class):
            pass
        t1 = time()
        return t1 - t0

    def test_product_memory(iterables, tqdm_class):
        """
        Test memory usage of product()
        """
        mem

# Generated at 2022-06-18 11:15:02.048204
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test for function product
    print("Test for function product")
    print("-" * 16)
    print("Test 1:")
    print("-" * 16)
    start_time = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1: ",
                     leave=False,
                     file=sys.stdout):
        pass
    print("Elapsed:", format_interval(time.time() - start_time))
    print("-" * 16)
    print("Test 2:")
    print("-" * 16)


# Generated at 2022-06-18 11:15:08.856264
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    if sys.version_info[0] == 2:
        from itertools import izip as zip
    for i in product(range(10), range(10)):
        assert i == (i[0], i[1])
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        assert i == (i[0], i[1])

    # Test 2
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        assert i == (i[0], i[1])

    # Test 3

# Generated at 2022-06-18 11:15:13.415001
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        print(i)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=False):
        print(i)

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:15:21.630307
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:15:32.298682
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    t = tqdm_auto(total=100)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    assert t.n == 1000
    assert t.total == 1000
    assert t.smoothing == 1
    assert t.dynamic_ncols
    assert t.unit == 'it'
    assert t.unit_scale == True
    assert t.miniters == 1
    assert t.mininterval == 0.1
    assert t.maxinterval == 10.0
    assert t.ascii == False

# Generated at 2022-06-18 11:15:39.367149
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_gen():
        """
        Generator for testing product
        """
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=tqdm_auto,
                         desc="test_product",
                         unit="B",
                         unit_scale=True,
                         unit_divisor=1024,
                         dynamic_ncols=True,
                         leave=True,
                         miniters=1,
                         mininterval=0.1,
                         maxinterval=10.0,
                         file=sys.stdout):
            yield i

    for i in test_product_gen():
        pass

    for i in test_product_gen():
        pass

   

# Generated at 2022-06-18 11:15:49.013032
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test basic function
    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Test with tqdm
    with tqdm_auto(total=4) as t:
        for _ in product(range(2), repeat=2):
            t.update()

    # Test with tqdm and manual total
    with tqdm_auto(total=4) as t:
        for _ in product(range(2), repeat=2, total=4):
            t.update()

    # Test with tqdm and manual total

# Generated at 2022-06-18 11:16:04.648765
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter
    from .utils import FormatCustomText
    from .std import tqdm
    from .gui import tqdm as tqdm_gui
    from .std import trange

    # Test basic functionality
    with closing(tqdm(product(range(10), repeat=2))) as obj:
        for _ in obj:
            pass
    assert obj.n == 100

    # Test custom tqdm class
    with closing(tqdm(product(range(10), repeat=2), tqdm_class=tqdm_gui)) as obj:
        for _ in obj:
            pass
    assert obj.n == 100

    # Test custom tqdm class with custom format

# Generated at 2022-06-18 11:16:11.599062
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    # Test with a list of lists
    l = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

# Generated at 2022-06-18 11:16:21.026436
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_generator(iterables, **kwargs):
        """
        Test for function product generator
        """
        for i in product(*iterables, **kwargs):
            pass

    def test_product_list(iterables, **kwargs):
        """
        Test for function product list
        """
        list(product(*iterables, **kwargs))

    def test_product_set(iterables, **kwargs):
        """
        Test for function product set
        """
        set(product(*iterables, **kwargs))

    def test_product_tuple(iterables, **kwargs):
        """
        Test for function product tuple
        """

# Generated at 2022-06-18 11:16:30.390415
# Unit test for function product
def test_product():
    """Test function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import gc
    import numpy as np

    # Test with a small list
    l = list(range(10))
    for i in product(l, l, l):
        pass

    # Test with a large list
    l = list(range(100))
    for i in product(l, l, l):
        pass

    # Test with a huge list
    l = list(range(1000))
    for i in product(l, l, l):
        pass

    # Test with a huge list and a custom tqdm_class
    l = list(range(1000))

# Generated at 2022-06-18 11:16:36.919589
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a list of lists
    l = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    l_prod = list(product(l))

# Generated at 2022-06-18 11:16:46.634046
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test 1
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2

# Generated at 2022-06-18 11:16:55.092518
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Test 1
    print("Test 1")
    print("------")
    print("Test product(range(10), range(10))")
    print("Expected result: 100")
    print("Result:          {}".format(
        len(list(product(range(10), range(10))))))
    print("")

    # Test 2
    print("Test 2")
    print("------")
    print("Test product(range(10), range(10), range(10))")
    print("Expected result: 1000")

# Generated at 2022-06-18 11:17:02.851736
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_generator(iterables):
        for i in product(*iterables):
            pass

    def test_product_list(iterables):
        list(product(*iterables))

    def test_itertools_product_generator(iterables):
        for i in itertools.product(*iterables):
            pass

    def test_itertools_product_list(iterables):
        list(itertools.product(*iterables))

    def test_itertools_product_generator_no_tqdm(iterables):
        for i in product(*iterables, tqdm_class=None):
            pass


# Generated at 2022-06-18 11:17:13.073003
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    if sys.version_info[0] == 2:
        from itertools import izip as zip
    else:
        from builtins import zip

    # Test 1
    print("\nTest 1:")
    print("  * product(range(10), repeat=2)")
    print("  * product(range(10), repeat=2, tqdm_class=tqdm.tqdm)")
    print("  * product(range(10), repeat=2, tqdm_class=tqdm.tqdm_gui)")

# Generated at 2022-06-18 11:17:19.526311
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test with a small number of elements
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with a large number of elements
    for i in product(range(100), range(100), range(100)):
        pass

    # Test with a large number of elements and a large total
    for i in product(range(100), range(100), range(100), total=1e6):
        pass

    # Test with a large number of elements and a small total
    for i in product(range(100), range(100), range(100), total=1e2):
        pass

# Generated at 2022-06-18 11:18:02.602170
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import random
    import time
    from ..utils import format_interval

    # Test with a large product
    print("\nTesting product with a large product...")
    start_t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, desc="product"):
        pass
    print("\nElapsed:", format_interval(time.time() - start_t))
    print("\nTesting product with a large product...")
    start_t = time.time()

# Generated at 2022-06-18 11:18:11.648654
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    # Test for product
    print("-> test for product")
    for i in range(3):
        n = randint(1, 10)
        m = randint(1, 10)
        print("\n-> test for product({0}, {1})".format(n, m))
        t = time()
        p = list(product(range(n), range(m)))
        t = time() - t
        print("\n-> product({0}, {1}) = {2}".format(n, m, p))

# Generated at 2022-06-18 11:18:18.074013
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from numpy import prod
    from numpy import array
    from numpy import ndarray
    from numpy import zeros
    from numpy import dtype
    from numpy import float32
    from numpy import float64
    from numpy import int8
    from numpy import int16
    from numpy import int32
    from numpy import int64
    from numpy import uint8
    from numpy import uint16
    from numpy import uint32
    from numpy import uint64
    from numpy import bool_
    from numpy import complex64

# Generated at 2022-06-18 11:18:27.967980
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import numpy as np
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval

# Generated at 2022-06-18 11:18:36.656367
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a list of lists
    l = [[1, 2], [3, 4]]
    r = list(product(l))
    assert r == [(1, 3), (1, 4), (2, 3), (2, 4)]

    # Test with a list of lists and a tqdm_class
    l = [[1, 2], [3, 4]]
    r = list(product(l, tqdm_class=tqdm_auto))
    assert r == [(1, 3), (1, 4), (2, 3), (2, 4)]

    # Test with a list of lists and a tqdm_class

# Generated at 2022-06-18 11:18:45.496360
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    start_time = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    print("Elapsed time: %s" % format_interval(time.time() - start_time))
    print("Memory usage: %s\n" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2:")
    start_time = time.time()

# Generated at 2022-06-18 11:18:53.862770
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys

    def test_product_generator(tqdm_class):
        """
        Unit test for function product
        """
        # Test with a generator
        def gen():
            """
            Generator for testing
            """
            for i in range(10):
                time.sleep(0.01)
                yield i
        for i in tqdm_class(gen(), total=10):
            pass

    def test_product_generator_no_total(tqdm_class):
        """
        Unit test for function product
        """
        # Test with a generator
        def gen():
            """
            Generator for testing
            """

# Generated at 2022-06-18 11:19:01.336974
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_json
    from ..utils import format_dict_latex
    from ..utils import format_dict_pretty

# Generated at 2022-06-18 11:19:09.897049
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10)):
        print(i)
    print("")

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        print(i)
    print("")

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
    print("")

    # Test 4

# Generated at 2022-06-18 11:19:15.386396
# Unit test for function product
def test_product():
    """Test for function product"""
    from numpy.testing import assert_equal
    from ..utils import format_sizeof

    # Test 1
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = list(product(a, b))
    assert_equal(c, [(1, 'a'), (1, 'b'), (1, 'c'),
                     (2, 'a'), (2, 'b'), (2, 'c'),
                     (3, 'a'), (3, 'b'), (3, 'c')])

    # Test 2
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = list(product(a, b, tqdm_class=tqdm_auto))

# Generated at 2022-06-18 11:19:38.213414
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_percentage
    from ..utils import format_length
    from ..utils import format_time
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt

# Generated at 2022-06-18 11:19:46.966858
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        """
        Wrap tqdm instance for testing
        """
        def __init__(self, iterable, *args, **kwargs):
            super(FormatWrap, self).__init__(*args, **kwargs)
            self.iter = iter(iterable)

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.iter)

        next = __next__  # Python 2 compatibility

        def update(self, n=1):
            """
            Manually update the progress bar
            """
            self.n = self.n + n


# Generated at 2022-06-18 11:19:56.320937
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test with a list of lists
    a = [[1, 2], [3, 4]]
    b = [1, 2]
    c = [3, 4]
    assert list(product(a)) == list(itertools.product(*a))
    assert list(product(b, c)) == list(itertools.product(b, c))

    # Test with a list of numpy arrays
    a = [np.array([1, 2]), np.array([3, 4])]
    b = np.array([1, 2])
    c = np.array([3, 4])
    assert list(product(a)) == list(itertools.product(*a))

# Generated at 2022-06-18 11:20:02.031940
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)
        tc.assertEqual(tc.sp, 100)
        tc.assertEqual(tc.n, 100)
        tc.assertEqual(tc.last_print_t, tc.n)

# Generated at 2022-06-18 11:20:11.083199
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_sizeof_short_fmt
    from ..utils import format