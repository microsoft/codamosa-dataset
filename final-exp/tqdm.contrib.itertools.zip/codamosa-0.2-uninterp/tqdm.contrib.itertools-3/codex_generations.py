

# Generated at 2022-06-18 11:10:17.213064
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assert_empty()

# Generated at 2022-06-18 11:10:26.907163
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_speed
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_number_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_speed_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_number_short

# Generated at 2022-06-18 11:10:37.465284
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Unit test for function product generator
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_class):
        """
        Unit test for function product list
        """
        list(product(*iterables, tqdm_class=tqdm_class))

    def test_product_list_total(iterables, tqdm_class=tqdm_class):
        """
        Unit test for function product list total
        """

# Generated at 2022-06-18 11:10:44.157363
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import string

    # Test 1
    print("\nTest 1:")
    print("  Generating random string of length 100000")
    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(100000))
    print("  Size of random string: {}".format(format_sizeof(sys.getsizeof(random_string))))
    print("  Generating list of random string of length 100000")
    random_string_list = [random_string for _ in range(100000)]

# Generated at 2022-06-18 11:10:55.192742
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with no iterable
    try:
        for _ in product():
            pass
    except TypeError:
        pass
    else:
        raise AssertionError("product() should raise TypeError")

    # Test with one iterable
    for i in product(range(10)):
        assert i == (0,)
        break

    # Test with two iterables
    for i in product(range(10), range(10)):
        assert i == (0, 0)
        break

    # Test with two iterables and total

# Generated at 2022-06-18 11:11:04.379172
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np

    # Test 1
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 4
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 5

# Generated at 2022-06-18 11:11:14.832008
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    def test_product_1():
        """
        Unit test for function product
        """
        # Test 1
        print("Test 1:")
        for i in product(range(10), range(10), range(10)):
            pass

    def test_product_2():
        """
        Unit test for function product
        """
        # Test 2
        print("Test 2:")
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto):
            pass

    def test_product_3():
        """
        Unit test for function product
        """
        # Test 3
        print("Test 3:")
       

# Generated at 2022-06-18 11:11:23.057090
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    def test(iterables, **tqdm_kwargs):
        """
        Unit test for function product
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)

# Generated at 2022-06-18 11:11:25.792259
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_array_equal
    assert_array_equal(
        list(product(range(3), range(3))),
        list(itertools.product(range(3), range(3))))

# Generated at 2022-06-18 11:11:29.082387
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .utils import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), range(10), tqdm_class=tc):
            pass
        tc.assert_empty()

# Generated at 2022-06-18 11:11:39.746982
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import stderr
    from os import getpid
    from os import getppid
    from os import getcwd
    from os import getloadavg
    from os import getuid
    from os import getgid
    from os import geteuid
    from os import getegid
    from os import getgroups
    from os import getlogin
    from os import getenv
    from os import get_terminal_size
    from os import cpu_count
    from os import get_exec_path
    from os import get_inheritable
    from os import get_blocking
    from os import get_handle_inheritable

# Generated at 2022-06-18 11:11:41.774987
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(100), range(100), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:11:50.482029
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tqdm import trange
    from ..utils import format_sizeof
    import sys
    import time

    for i in trange(10, desc='outer loop'):
        for j in trange(10, desc='inner loop', leave=False):
            time.sleep(0.01)

    for i in trange(10, desc='outer loop'):
        for j in trange(10, desc='inner loop', leave=False):
            time.sleep(0.01)

    for i in trange(10, desc='outer loop'):
        for j in trange(10, desc='inner loop', leave=False):
            time.sleep(0.01)


# Generated at 2022-06-18 11:12:00.242972
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    t = time.time()
    for i in product(gen(), gen(), gen(), tqdm_class=tqdm_auto):
        pass
    print(format_interval(time.time() - t))

    # Test with a list
    t = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print(format_interval(time.time() - t))

    # Test with a list of lists
    t = time.time

# Generated at 2022-06-18 11:12:08.723842
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import tempfile
    import shutil
    import random
    import string
    import io
    import gc
    import atexit
    import warnings
    import contextlib
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from .tqdm_gui import tqdm_notebook
    from .tqdm import tqdm
    from .tqdm import trange
    from .tqdm import TqdmTypeError
    from .tqdm import TqdmKeyError
    from .tqdm import TqdmDeprecationWarning

# Generated at 2022-06-18 11:12:18.208147
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import stderr
    from random import randint
    from itertools import product

    # Test 1
    for i in product(range(10), repeat=3):
        pass

    # Test 2
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4

# Generated at 2022-06-18 11:12:26.328755
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from .utils import closing, FakeTqdmFile, StringIO

    with closing(StringIO()) as our_file:
        with closing(FakeTqdmFile(our_file)) as file_:
            for _ in product(range(5), range(5), range(5),
                             tqdm_class=tqdm_auto, file=file_):
                pass
            assert file_.n == 125
            assert file_.l_total == 125
            assert file_.l_reversed == False
            assert file_.smoothing == 1.0
            assert file_.dynamic_ncols == False
            assert file_.mininterval == 0.1
            assert file_.miniters == None
            assert file_.ascii == False
            assert file_.desc == None
            assert file_.position

# Generated at 2022-06-18 11:12:35.698791
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_fmt

# Generated at 2022-06-18 11:12:43.548258
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    def test_product_generator(iterables):
        """
        Test product generator
        """
        for i in product(*iterables):
            pass

    def test_product_list(iterables):
        """
        Test product list
        """
        list(product(*iterables))

    def test_product_list_tqdm(iterables):
        """
        Test product list with tqdm
        """
        list(product(*iterables, tqdm_class=tqdm_auto))

    def test_product_list_tqdm_total(iterables):
        """
        Test product list with tqdm and total
        """

# Generated at 2022-06-18 11:12:52.347915
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_number

# Generated at 2022-06-18 11:13:05.083295
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 4
    print("Test 4:")
   

# Generated at 2022-06-18 11:13:13.614948
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test 1
    print("Test 1:")

# Generated at 2022-06-18 11:13:19.176996
# Unit test for function product
def test_product():
    from random import randint
    from time import sleep
    from numpy import product as npproduct
    from numpy import array
    from numpy.random import randint as nprandint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import random_integers as nprandint_
    from numpy.random import random_sample as nprand
    from numpy.random import randint as nprandint_
    from numpy.random import randn as nprandn
    from numpy.random import shuffle as npshuffle
    from numpy.random import uniform as nprand
    from numpy.random import uniform as nprand_
    from numpy.random import uniform as nprand__
    from numpy.random import uniform as nprand___


# Generated at 2022-06-18 11:13:28.645122
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_sizeof_short_

# Generated at 2022-06-18 11:13:37.071626
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import numpy as np

    # Test 1: simple product
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2: product with total
    for i in product(range(10), range(10), range(10), total=1000):
        pass

    # Test 3: product with total and miniters
    for i in product(range(10), range(10), range(10), total=1000, miniters=10):
        pass

    # Test 4: product with total and mininterval
    for i in product(range(10), range(10), range(10), total=1000, mininterval=0.1):
        pass

# Generated at 2022-06-18 11:13:43.416336
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("Time: %.3f s" % (t1 - t0))
    print("Memory: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("\nTest 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:13:53.207412
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import tqdm
    from .utils import FormatCustomText

    for i in product(range(3), range(3), range(3), tqdm=tqdm):
        pass

    for i in product(range(3), range(3), range(3), tqdm=tqdm,
                     desc="Testing product"):
        pass

    for i in product(range(3), range(3), range(3), tqdm=tqdm,
                     desc="Testing product", leave=True):
        pass


# Generated at 2022-06-18 11:14:02.118614
# Unit test for function product
def test_product():
    """Test function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)
    m = np.arange(10)
    n = np.arange(10)

# Generated at 2022-06-18 11:14:07.118351
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test product
    print("Test product")
    t = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print(" -> %s" % format_interval(time.time() - t))
    print(" -> %s" % format_sizeof(i))
    print("")

# Generated at 2022-06-18 11:14:16.645717
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_sizeof
    import sys
    from ..utils import _range

    def test_product_1():
        """
        Test product() with a single iterable.
        """
        for i in product(_range(10)):
            pass

    def test_product_2():
        """
        Test product() with two iterables.
        """
        for i in product(_range(10), _range(10)):
            pass

    def test_product_3():
        """
        Test product() with three iterables.
        """
        for i in product(_range(10), _range(10), _range(10)):
            pass


# Generated at 2022-06-18 11:14:30.773475
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_meter

# Generated at 2022-06-18 11:14:38.402171
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test with a small number of elements
    for i in product(range(10), range(10)):
        pass

    # Test with a large number of elements
    for i in product(range(1000), range(1000)):
        pass

    # Test with a large number of elements and a custom tqdm class
    for i in product(range(1000), range(1000), tqdm_class=tqdm_auto):
        pass

    # Test with a large number of elements and a custom tqdm class
    for i in product(range(1000), range(1000), tqdm_class=tqdm_auto):
        pass

    # Test with a large number of elements and a custom t

# Generated at 2022-06-18 11:14:43.522135
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=100, file=sys.stdout)
    for i in product(range(100), range(100), range(100)):
        t.update()
    t.close()

    # Test 2
    t = tqdm_auto(total=100, file=sys.stdout)
    for i in product(range(100), range(100), range(100)):
        t.update()
        time.sleep(0.01)
    t.close()

    # Test 3
    t = tqdm_auto(total=100, file=sys.stdout)

# Generated at 2022-06-18 11:14:52.348203
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random
    random.seed(0)
    for i in range(5):
        n = random.randint(1, 10)
        m = random.randint(1, 10)
        k = random.randint(1, 10)
        l = random.randint(1, 10)
        print("\n\nTesting product(range({0}), range({1}), range({2}), "
              "range({3}))".format(n, m, k, l))
        print("\nWithout tqdm:")
        start = time.time()

# Generated at 2022-06-18 11:15:00.786175
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:15:07.837627
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import stderr
    from random import random
    from time import time

    # Test basic product
    assert list(product(range(3), repeat=3)) == list(itertools.product(range(3), repeat=3))

    # Test tqdm(product())
    assert list(tqdm_auto(product(range(3), repeat=3))) == list(itertools.product(range(3), repeat=3))

    # Test tqdm(product(), leave=True)

# Generated at 2022-06-18 11:15:10.302107
# Unit test for function product
def test_product():
    from .tests import TestCase, closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assert_equal(tc.sp, tc.si)
        tc.assert_equal(tc.sp, tc.si)

# Generated at 2022-06-18 11:15:17.900075
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("Elapsed time: %s" % format_sizeof(t1 - t0))

    # Test 2
    print("Test 2:")
    t0 = time.time()
    for i in itertools.product(range(10), range(10), range(10), range(10)):
        pass
    t1 = time.time()

# Generated at 2022-06-18 11:15:22.079894
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase

    with TestCase() as test:
        for i in product(range(10), range(10), range(10),
                         tqdm_class=test.fake_tqdm):
            pass
        test.assert_total(1000)

# Generated at 2022-06-18 11:15:32.552455
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1:
    # Check that the number of iterations is correct
    # and that the total time is correct
    # (with a random sleep time)
    # and that the total size is correct
    # (with a random size)
    n = 100
    m = 10
    sleep_time = random.random() / 10
    total_size = 0
    for i, j in product(range(n), range(m),
                        tqdm_class=FormatCustomText,
                        desc="Test 1",
                        leave=False):
        total_size += sys.getsizeof(i) + sys.getsizeof(j)
        time.sleep

# Generated at 2022-06-18 11:15:53.794066
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("\nTest 1:")
    print("  - Generate all possible combinations of 3 digits")
    print("  - Print the size of the generator")
    print("  - Print the time it takes to generate all combinations")
    print("  - Print the time it takes to generate all combinations with tqdm")
    print("  - Print the time it takes to generate all combinations with tqdm")
    print("    and disable monitor")
    print("  - Print the time it takes to generate all combinations with tqdm")
    print("    and disable monitor and leave")

# Generated at 2022-06-18 11:16:01.597295
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test 1
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Testing product"):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Testing product",
                     unit="B", unit_scale=True,
                     unit_divisor=1024, miniters=1):
        pass

    # Test 4

# Generated at 2022-06-18 11:16:08.177799
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    print("\tElapsed time:", format_interval(time.time() - t))
    print("\tMemory usage:", format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2:")
    t = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-18 11:16:16.897153
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import stderr
    from random import randint
    from itertools import product
    from itertools import repeat
    from itertools import chain
    from itertools import islice
    from itertools import count
    from itertools import cycle
    from itertools import imap
    from itertools import ifilter
    from itertools import ifilterfalse
    from itertools import compress
    from itertools import izip
    from itertools import izip_longest
    from itertools import starmap
    from itertools import tee
    from itertools import takewhile
    from itertools import drop

# Generated at 2022-06-18 11:16:26.604283
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.1)

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.1)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=False):
        print(i)

# Generated at 2022-06-18 11:16:34.286676
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval

# Generated at 2022-06-18 11:16:42.651482
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen():
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="test_product_gen",
                         leave=True):
            yield i

    def test_product_list():
        for i in list(product(range(10), range(10), range(10),
                              tqdm_class=tqdm_auto,
                              desc="test_product_list",
                              leave=True)):
            yield i


# Generated at 2022-06-18 11:16:51.351502
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_sizeof
    from ..utils import format_interval

    def test_product_speed(iterables, tqdm_class):
        """Test speed of product()"""
        t0 = time()
        for _ in tqdm_class(product(*iterables, tqdm_class=tqdm_class)):
            pass
        t1 = time()
        print("product() speed: %s/s" % format_interval(t1 - t0))

    def test_product_memory(iterables, tqdm_class):
        """Test memory usage of product()"""

# Generated at 2022-06-18 11:16:59.578897
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter
    from .utils import FormatCustomText
    from .utils import StringIO, UnicodeIO

    # Test basic functionality
    for iterable in [range(10), range(10), range(10)]:
        assert list(product(iterable)) == list(itertools.product(iterable))

    # Test total
    for iterable in [range(10), range(10), range(10)]:
        assert list(product(iterable, total=10)) == list(itertools.product(iterable))

    # Test total=None
    for iterable in [range(10), range(10), range(10)]:
        assert list(product(iterable, total=None)) == list(itertools.product(iterable))

    # Test

# Generated at 2022-06-18 11:17:07.118590
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("Test 1:")
    print("  - Test product with no iterables")
    print("  - Expected result: 1")
    print("  - Result:", end=' ')
    sys.stdout.flush()
    start_time = time.time()
    result = list(product())
    print(len(result))
    print("  - Time elapsed:", format_interval(time.time() - start_time))
    print("  - Memory usage:", format_sizeof(sys.getsizeof(result)))
    print()

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:17:24.431053
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    def test_product_generator(tqdm_class=tqdm_auto, **kwargs):
        """
        Test product generator
        """
        # Test product
        iterables = [range(10), range(10), range(10)]
        for i in product(*iterables, tqdm_class=tqdm_class, **kwargs):
            pass

        # Test product with non-iterable
        iterables = [range(10), range(10), range(10), None]
        for i in product(*iterables, tqdm_class=tqdm_class, **kwargs):
            pass

        # Test product with non-iterable

# Generated at 2022-06-18 11:17:31.914399
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .trange import trange

    def test_product_gen(tqdm_cls, iterables, total):
        """
        Unit test for function product
        """
        for _ in tqdm_cls(product(*iterables), total=total):
            pass

    def test_product_iter(tqdm_cls, iterables, total):
        """
        Unit test for function product
        """
        for _ in tqdm_cls(itertools.product(*iterables), total=total):
            pass

    def test_product_trange(tqdm_cls, iterables, total):
        """
        Unit test for function product
        """

# Generated at 2022-06-18 11:17:36.708193
# Unit test for function product
def test_product():
    """Test function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_sizeof_short_fmt

# Generated at 2022-06-18 11:17:45.688259
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_fmt_str
    from ..utils import format_interval_fmt_str
    from ..utils import format_meter_fmt_str
    from ..utils import format

# Generated at 2022-06-18 11:17:55.140260
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test with no iterable
    assert list(product()) == list(itertools_product())

    # Test with one iterable
    assert list(product([1, 2, 3])) == list(itertools_product([1, 2, 3]))

    # Test with multiple iterables
    assert list(product([1, 2, 3], [4, 5, 6])) == list(itertools_product([1, 2, 3], [4, 5, 6]))

    # Test with multiple iterables and repeat

# Generated at 2022-06-18 11:18:04.413740
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=10)

# Generated at 2022-06-18 11:18:13.393310
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from itertools import chain
    from itertools import repeat
    from itertools import islice
    from itertools import count
    from itertools import cycle
    from itertools import starmap
    from itertools import compress
    from itertools import dropwhile
    from itertools import takewhile
    from itertools import groupby
    from itertools import tee
    from itertools import zip_longest
    from itertools import filterfalse
    from itertools import accumulate
    from itertools import permutations

# Generated at 2022-06-18 11:18:20.695834
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time

    # Test 1
    print("Test 1:")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")
    print("  - Test with a simple product")

# Generated at 2022-06-18 11:18:30.689067
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    # Test with a list of lists
    print("Test 1:")
    print("Test with a list of lists")
    print("")
    print("Expected:")
    print("")

# Generated at 2022-06-18 11:18:39.401445
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_sizeof

# Generated at 2022-06-18 11:19:03.596401
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    try:
        from itertools import product
    except ImportError:
        return
    try:
        from numpy import product as npproduct
    except ImportError:
        npproduct = None

    def test(iterables, **kwargs):
        """
        Test function for function product.
        """
        # Test with tqdm
        t0 = time.time()
        for _ in tqdm.product(*iterables, **kwargs):
            pass
        t1 = time.time()
        # Test without tqdm
        t2 = time.time()
        for _ in product(*iterables):
            pass
        t3 = time.time()
        # Test with

# Generated at 2022-06-18 11:19:11.166053
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:19:19.774797
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import TestCase
    from ..utils import format_sizeof

    class TestProduct(TestCase):
        def test_product(self):
            """
            Test function product.
            """
            # Test basic functionality
            self.assertEqual(
                list(product(range(3), range(3))),
                list(itertools.product(range(3), range(3))))
            # Test tqdm_class
            self.assertEqual(
                list(product(range(3), range(3), tqdm_class=tqdm_auto)),
                list(itertools.product(range(3), range(3))))
            # Test total

# Generated at 2022-06-18 11:19:28.961548
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import numpy as np
    import psutil
    import resource

    # Get current process
    p = psutil.Process(os.getpid())

    # Get current memory usage
    mem_before = p.memory_info().rss

    # Get current CPU time
    cpu_time_before = resource.getrusage(resource.RUSAGE_SELF).ru_utime

    # Start timer
    start_time = time.time()

    # Run function

# Generated at 2022-06-18 11:19:34.604032
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    def test_product_gen(iterables, **kwargs):
        """
        Generator for testing product
        """
        for i in product(*iterables, **kwargs):
            yield i

    def test_product_gen_no_tqdm(iterables, **kwargs):
        """
        Generator for testing product without tqdm
        """
        for i in itertools.product(*iterables):
            yield i

    def test_product_gen_no_tqdm_no_yield(iterables, **kwargs):
        """
        Generator for testing product without tqdm and without yield
        """

# Generated at 2022-06-18 11:19:43.787854
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number

# Generated at 2022-06-18 11:19:52.675691
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.1)

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.1)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=True):
        print(i)

# Generated at 2022-06-18 11:19:59.911031
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import version_info
    from itertools import product
    from ..utils import _range

    # Test basic use
    for i in product(_range(3), _range(4), _range(5)):
        pass

    # Test total
    for i in product(_range(3), _range(4), _range(5), tqdm_class=tqdm_auto):
        pass

    # Test leave
    for i in product(_range(3), _range(4), _range(5), tqdm_class=tqdm_auto,
                     leave=True):
        pass

    # Test mininterval

# Generated at 2022-06-18 11:20:09.593519
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 2"):
        pass

    # Test 3
    print("Test 3")

# Generated at 2022-06-18 11:20:16.777838
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    assert list(product(gen())) == list(itertools.product(gen()))

    # Test with a list
    assert list(product([1, 2, 3])) == list(itertools.product([1, 2, 3]))

    # Test with a numpy array
    assert list(product(np.array([1, 2, 3]))) == list(itertools.product(np.array([1, 2, 3])))

    # Test with a list of generators
    def gen2():
        for i in range(10):
            yield i