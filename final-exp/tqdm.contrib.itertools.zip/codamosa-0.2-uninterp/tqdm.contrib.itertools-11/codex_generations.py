

# Generated at 2022-06-18 11:10:22.432563
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("\nTest 1:")
    print("  * Test product(range(10), range(10))")
    print("  * Test product(range(10), range(10), range(10))")
    print("  * Test product(range(10), range(10), range(10), range(10))")
    print("  * Test product(range(10), range(10), range(10), range(10), range(10))")
    print("  * Test product(range(10), range(10), range(10), range(10), range(10), range(10))")

# Generated at 2022-06-18 11:10:33.577445
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test 1
    print("Test 1:")
    print("  Testing product(range(10), range(10))")
    t = time.time()
    for i in product(range(10), range(10)):
        pass
    t = time.time() - t
    print("  -> time: %s" % format_interval(t))
    print("  -> memory: %s" % format_sizeof(sys.getsizeof(i)))
    print("  -> memory diff: %s" % format_sizeof(os.times()[4]))

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:10:41.700910
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(x, y):
        for i in product(x, y, tqdm_class=tqdm_auto,
                         desc="test_product_gen", leave=False):
            yield i

    def test_product_gen_noleave(x, y):
        for i in product(x, y, tqdm_class=tqdm_auto,
                         desc="test_product_gen_noleave", leave=True):
            yield i

    def test_product_gen_noleave_nodesc(x, y):
        for i in product(x, y, tqdm_class=tqdm_auto, leave=True):
            yield i



# Generated at 2022-06-18 11:10:53.427504
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys

    def test_product_gen(iterables):
        """
        Generator for function test_product.
        """
        for i in product(*iterables):
            yield i

    def test_product_gen_no_tqdm(iterables):
        """
        Generator for function test_product.
        """
        for i in itertools.product(*iterables):
            yield i

    def test_product_gen_no_tqdm_no_yield(iterables):
        """
        Generator for function test_product.
        """
        for i in itertools.product(*iterables):
            pass


# Generated at 2022-06-18 11:11:02.716226
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Test that `product` is equivalent to `itertools.product`
        """
        for i, j in zip(product(*iterables, tqdm_class=tqdm_class),
                        itertools.product(*iterables)):
            assert i == j

    # Test that `product` is equivalent to `itertools.product`
    test_product_generator([range(10), range(10), range(10)])
    test_product_generator([range(10), range(10), range(10)], tqdm_class=tqdm_auto)

    # Test that `product` is equivalent to `itertools.

# Generated at 2022-06-18 11:11:13.132960
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .tests import pretest_posttest

    class TestProduct(FormatMixin):
        def test_product(self):
            """
            Unit test for function product
            """
            from ..utils import format_interval
            from ..utils import format_sizeof
            from ..utils import format_timespan
            from ..utils import format_num
            from ..utils import format_meter
            from ..utils import format_size
            from ..utils import format_speed
            from ..utils import format_eta
            from ..utils import format_asizeof
            from ..utils import format_aspeedof
            from ..utils import format_aspeed
            from ..utils import format_asize
            from ..utils import format_

# Generated at 2022-06-18 11:11:21.891536
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percentage
    from ..utils import format_interval_short
    from ..utils import format_timespan_short
    from ..utils import format_size_short
    from ..utils import format_speed_short
    from ..utils import format_eta_short
    from ..utils import format_

# Generated at 2022-06-18 11:11:31.322445
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np

    # Test that product works with iterables
    assert list(product(range(3), range(3))) == [(0, 0), (0, 1), (0, 2),
                                                (1, 0), (1, 1), (1, 2),
                                                (2, 0), (2, 1), (2, 2)]

    # Test that product works with iterators
    assert list(product(range(3), range(3))) == [(0, 0), (0, 1), (0, 2),
                                                (1, 0), (1, 1), (1, 2),
                                                (2, 0), (2, 1), (2, 2)]

    # Test that product works with generators

# Generated at 2022-06-18 11:11:39.645647
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_generator(iterables):
        """Test for function product generator"""
        for _ in product(*iterables):
            pass

    def test_product_list(iterables):
        """Test for function product list"""
        list(product(*iterables))

    def test_product_set(iterables):
        """Test for function product set"""
        set(product(*iterables))

    def test_product_tuple(iterables):
        """Test for function product tuple"""
        tuple(product(*iterables))

    def test_product_dict(iterables):
        """Test for function product dict"""
        dict(product(*iterables))


# Generated at 2022-06-18 11:11:48.438736
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from .. import trange

    for tqdm_class in (tqdm_auto, trange):
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass

# Generated at 2022-06-18 11:12:00.697326
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from .trange import trange
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product

    # Test with tqdm_class

# Generated at 2022-06-18 11:12:09.161844
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np
    from ..utils import format_interval

    def test_product_gen(iterables):
        for i in product(*iterables):
            yield i

    def test_product_list(iterables):
        return list(product(*iterables))

    def test_product_np(iterables):
        return np.array(list(product(*iterables)))

    def test_product_np_fromiter(iterables):
        return np.fromiter(product(*iterables), dtype=np.int)

    def test_product_np_fromiter_chunks(iterables):
        return np.fromiter(product(*iterables), dtype=np.int, count=10)



# Generated at 2022-06-18 11:12:18.673356
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1:
    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    for i in product(gen(), tqdm_class=tqdm_auto):
        pass

    # Test 2:
    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    for i in product(gen(), tqdm_class=tqdm_auto):
        pass

    # Test 3:
    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    for i in product(gen(), tqdm_class=tqdm_auto):
        pass

    # Test

# Generated at 2022-06-18 11:12:26.735103
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys
    import os
    import numpy as np
    import pandas as pd
    import random
    import string
    import tempfile
    import shutil
    import gc
    import psutil
    import multiprocessing
    import threading
    from ..utils import _range
    from ..utils import _enumerate
    from ..utils import _map
    from ..utils import _imap
    from ..utils import _starmap
    from ..utils import _chain
    from ..utils import _chain_from_iterable
    from ..utils import _zip
    from ..utils import _izip
    from ..utils import _

# Generated at 2022-06-18 11:12:36.093486
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test 1: no total
    for i in product(range(10), repeat=3):
        pass

    # Test 2: with total
    for i in product(range(10), repeat=3, total=1000):
        pass

    # Test 3: with total and miniters
    for i in product(range(10), repeat=3, total=1000, miniters=10):
        pass

    # Test 4: with total and mininterval

# Generated at 2022-06-18 11:12:43.864415
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Test 1
    with StringIO() as our_file, StringIO() as true_file:
        for _ in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto, file=our_file):
            pass
        for _ in itertools.product(range(10), range(10), range(10)):
            pass
        assert our_file.getvalue() == true_file.getvalue()

    # Test 2

# Generated at 2022-06-18 11:12:52.705638
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval

    # Test with tqdm_class=tqdm.auto.tqdm
    # ------------------------------------
    # Test with total=None
    # -------------------
    # Test with total=None and leave=False
    # ------------------------------------
    # Test with total=None and leave=True
    # -----------------------------------
    # Test with total=None and leave=True and smoothing=0
    # ----------------------------------------------------
    # Test with total=None and leave=True and smoothing=1
    # ----------------------------------------------------
    # Test with total=None and leave=True and smoothing=1 and dynamic_ncols=True
    # -------------------------------------------------------------------------
    # Test with total=None and

# Generated at 2022-06-18 11:13:02.969534
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test with a small number of elements
    n = 5
    p = list(product(range(n), range(n), range(n)))
    assert len(p) == n**3
    assert p == list(itertools_product(range(n), range(n), range(n)))

    # Test with a large number of elements
    n = 100
    p = list(product(range(n), range(n), range(n)))
    assert len(p) == n**3

# Generated at 2022-06-18 11:13:11.154292
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from itertools import product
    from random import random
    from copy import deepcopy

    # Test with no iterable
    assert list(product()) == [()]

    # Test with one iterable
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    # Test with two iterables

# Generated at 2022-06-18 11:13:17.860002
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys

    # Test for product
    try:
        from itertools import product
    except ImportError:
        from ..utils import product

    # Test for product
    try:
        from itertools import product
    except ImportError:
        from ..utils import product

    # Test for product
    try:
        from itertools import product
    except ImportError:
        from ..utils import product

    # Test for product

# Generated at 2022-06-18 11:13:28.945438
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import randint

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        sleep(0.01)

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:13:37.240945
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(3), range(3), range(3)):
        print(i)
    print("")

    # Test 2
    print("Test 2:")
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        print(i)
    print("")

    # Test 3
    print("Test 3:")
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto,
                     leave=True):
        print(i)
    print("")

    # Test 4

# Generated at 2022-06-18 11:13:43.535405
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_1():
        """
        Unit test for function product
        """
        from ..utils import format_interval
        from time import time

        start_t = time()
        for _ in product(range(1000), range(1000), range(1000)):
            pass
        print("product(range(1000), range(1000), range(1000)) took {}"
              .format(format_interval(time() - start_t)))

    def test_product_2():
        """
        Unit test for function product
        """
        from ..utils import format_interval
        from time import time

        start_t = time()

# Generated at 2022-06-18 11:13:53.289436
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    assert list(product(gen())) == list(itertools.product(gen()))

    # Test with a list
    assert list(product([1, 2, 3])) == list(itertools.product([1, 2, 3]))

    # Test with a numpy array
    assert list(product(np.arange(10))) == list(itertools.product(np.arange(10)))

    # Test with a list of generators
    def gen():
        for i in range(10):
            yield i

# Generated at 2022-06-18 11:14:02.228708
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import randint
    from sys import getsizeof
    from itertools import product as itertools_product
    from itertools import islice

    def random_sleep(i):
        sleep(randint(0, 10) * 1e-3)
        return i

    def random_int(i):
        return randint(0, 10)

    def random_str(i):
        return str(randint(0, 10))

    def random_tuple(i):
        return (randint(0, 10), randint(0, 10))


# Generated at 2022-06-18 11:14:09.043363
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format

# Generated at 2022-06-18 11:14:17.623132
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm_gui import tqdm
    from .utils import format_sizeof
    import sys
    from time import sleep
    from .utils import _range


# Generated at 2022-06-18 11:14:25.360788
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test with tqdm_class=tqdm.auto.tqdm
    t = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    print("product(range(10), range(10), range(10)) took %s" %
          format_interval(time.time() - t))

    # Test with tqdm_class=tqdm.tqdm
    t = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-18 11:14:33.898439
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test 1:
    # -------
    # Test product on a list of lists
    # with a total size of 1GB
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a total number of elements of 1e9
    # and a

# Generated at 2022-06-18 11:14:40.652369
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test with integers
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10), range(10))"):
        pass

    # Test with strings
    for i in product("abc", "def", "ghi",
                     tqdm_class=tqdm_auto,
                     desc="product('abc', 'def', 'ghi')"):
        pass

    # Test with files

# Generated at 2022-06-18 11:14:51.776891
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        time.sleep(0.01)
        sys.stder

# Generated at 2022-06-18 11:15:00.251460
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Test basic function

# Generated at 2022-06-18 11:15:07.479487
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_line
    from ..utils import format_over
    from ..utils import format_ascii
    from ..utils import format_len
    from ..utils import format_dict
    from ..utils import format_dict_html
    from ..utils import format_dict_csv
    from ..utils import format_dict_json
    from ..utils import format_dict_table
    from ..utils import format_dict_prettytable

# Generated at 2022-06-18 11:15:13.944733
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test with a single iterable
    for i in product(range(10)):
        assert i == itertools_product(range(10)).__next__()

    # Test with multiple iterables
    for i in product(range(10), range(10)):
        assert i == itertools_product(range(10), range(10)).__next__()

    # Test with multiple iterables and a total

# Generated at 2022-06-18 11:15:22.462055
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        time.sleep(0.01)
        pass

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        time.sleep(0.01)
        pass

    # Test 3

# Generated at 2022-06-18 11:15:32.978008
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    iterables = [range(10), range(10, 20), range(20, 30)]
    t = time.time()
    for i in product(*iterables):
        pass
    print("Test 1:", format_interval(time.time() - t))

    # Test 2
    iterables = [range(10), range(10, 20), range(20, 30)]
    t = time.time()
    for i in itertools.product(*iterables):
        pass
    print("Test 2:", format_interval(time.time() - t))

    # Test 3

# Generated at 2022-06-18 11:15:39.895418
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from .trange import trange

    # Test for product
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10), range(10))"):
        pass

    # Test for product
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10), range(10))",
                     unit="it"):
        pass

    # Test for product

# Generated at 2022-06-18 11:15:49.139785
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
        with tqdm_class(total=total) as t:
            for i in itertools.product(*iterables):
                yield

# Generated at 2022-06-18 11:15:58.004092
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter

    with closing(tqdm_auto(total=0)) as t:
        assert t.total == 0
        for _ in product(range(3), range(3), tqdm_class=tqdm_auto,
                         total=9):
            pass
        assert t.total == 9

    with closing_iter(tqdm_auto(total=0)) as t:
        assert t.total == 0
        for _ in product(range(3), range(3), tqdm_class=tqdm_auto,
                         total=9):
            pass
        assert t.total == 9

    with closing(tqdm_auto(total=0)) as t:
        assert t.total == 0

# Generated at 2022-06-18 11:16:05.294923
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:16:19.306276
# Unit test for function product
def test_product():
    """Test for function product"""
    from .tests_tqdm import with_setup, pretest, posttest, _range

    @with_setup(pretest, posttest)
    def wrapper():
        """Actual test for function product"""
        from ..utils import format_sizeof

        # Test 1
        for i in product(_range(10), _range(10)):
            pass

        # Test 2
        for i in product(_range(10), _range(10), tqdm_class=tqdm_auto):
            pass

        # Test 3
        for i in product(_range(10), _range(10), tqdm_class=tqdm_auto,
                         desc="test", leave=True):
            pass

        # Test 4

# Generated at 2022-06-18 11:16:28.457134
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_1():
        """Test for function product"""
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=FormatCustomText,
                         desc=format_sizeof(sys.getsizeof(range(1000))),
                         leave=False):
            time.sleep(0.00001)

    def test_product_2():
        """Test for function product"""

# Generated at 2022-06-18 11:16:35.736815
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    for i in product(gen(), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a list of lists
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a list of lists and a generator
    def gen():
        for i in range(10):
            yield i

# Generated at 2022-06-18 11:16:45.121429
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=100)
    for i in product(range(100), range(100), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=100)
    for i in product(range(100), range(100), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=100)
    for i in product(range(100), range(100), tqdm_class=t.__class__):
        pass

# Generated at 2022-06-18 11:16:53.372873
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Test 1
    print("Test 1:")
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = [1.0, 2.0, 3.0]
    for i in product(a, b, c, tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("Test 2:")
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = [1.0, 2.0, 3.0]

# Generated at 2022-06-18 11:17:01.429662
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test for product
    for i in product(range(3), range(3), range(3), range(3), range(3),
                     tqdm_class=tqdm_auto, desc="product"):
        pass

    # Test for product
    for i in product(range(3), range(3), range(3), range(3), range(3),
                     tqdm_class=tqdm_auto, desc="product", leave=True):
        pass

    # Test for product

# Generated at 2022-06-18 11:17:10.384183
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        for _ in product(range(3), range(3), range(3),
                         tqdm_class=FormatCustomText):
            pass
    output = out.getvalue

# Generated at 2022-06-18 11:17:17.990592
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import gc
    from ..utils import _range

    # Test for total
    for i in product(_range(10), _range(10), _range(10)):
        pass
    for i in product(_range(10), _range(10), _range(10),
                     tqdm_class=tqdm_auto, total=None):
        pass
    for i in product(_range(10), _range(10), _range(10),
                     tqdm_class=tqdm_auto, total=1000):
        pass

    # Test for memory usage

# Generated at 2022-06-18 11:17:26.392571
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import tempfile
    import shutil
    import random
    import string

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a random file
    filename = os.path.join(tmp_dir, ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10)))
    with open(filename, 'wb') as f:
        f.write(os.urandom(1024 * 1024))

    # Create a random file

# Generated at 2022-06-18 11:17:33.033831
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesince
    from ..utils import format_numlist
    from ..utils import format_dict
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timesince_fmt
    from ..utils import format_numlist_fmt
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter

# Generated at 2022-06-18 11:17:51.733884
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    def test_product_iter(iterables, **tqdm_kwargs):
        """
        Test product iterator
        """
        for _ in product(*iterables, **tqdm_kwargs):
            pass

    def test_product_list(iterables, **tqdm_kwargs):
        """
        Test product list
        """
        list(product(*iterables, **tqdm_kwargs))

    def test_product_tuple(iterables, **tqdm_kwargs):
        """
        Test product tuple
        """
        tuple(product(*iterables, **tqdm_kwargs))


# Generated at 2022-06-18 11:18:02.067005
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen():
        for i in product(range(10), range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="test_product_gen"):
            yield i

    def test_product_list():
        return list(product(range(10), range(10), range(10), range(10),
                            tqdm_class=tqdm_auto,
                            desc="test_product_list"))


# Generated at 2022-06-18 11:18:11.138541
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_gen(iterables, **kwargs):
        """
        Generator for testing product
        """
        for i in product(*iterables, **kwargs):
            yield i

    def test_product_list(iterables, **kwargs):
        """
        List for testing product
        """
        return list(product(*iterables, **kwargs))

    def test_product_numpy(iterables, **kwargs):
        """
        Numpy array for testing product
        """
        return np.array(list(product(*iterables, **kwargs)))


# Generated at 2022-06-18 11:18:17.714821
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter
    from .utils import FormatCustomText
    from .std import tqdm

    # Test basic functionality
    with closing(tqdm(product(range(10), range(10), range(10)),
                      desc="test_product",
                      leave=False)) as pbar:
        assert len(list(pbar)) == 1000

    # Test total
    with closing(tqdm(product(range(10), range(10), range(10)),
                      desc="test_product",
                      leave=False)) as pbar:
        assert pbar.total == 1000

    # Test nested

# Generated at 2022-06-18 11:18:27.456467
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof

    # Test 1
    t0 = time()
    for i in product(range(10), repeat=2):
        pass
    t1 = time()
    print("Test 1:")
    print("  Time: %s" % format_interval(t1 - t0))
    print("  Size: %s" % format_sizeof(100 * 100 * 8))

    # Test 2
    t0 = time()
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        pass
    t

# Generated at 2022-06-18 11:18:36.296970
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test with a generator
    gen = (i for i in range(10))
    assert list(product(gen)) == list(itertools.product(gen))

    # Test with a list
    lst = list(range(10))
    assert list(product(lst)) == list(itertools.product(lst))

    # Test with a tuple
    tup = tuple(range(10))
    assert list(product(tup)) == list(itertools.product(tup))

    # Test with a set
    st = set(range(10))
    assert list(product(st)) == list(itertools.product(st))

    # Test with a dict

# Generated at 2022-06-18 11:18:45.107601
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="test"):
        pass

    # Test 3
    print("\nTest 3:")

# Generated at 2022-06-18 11:18:53.527090
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import getsizeof
    from itertools import product
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import getsizeof
    from itertools import product

    # Test 1
    print("\nTest 1:")
    for i in product(range(10), repeat=2):
        print(i)
    print("\n")

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=2):
        print(i)
        sleep(random() / 10)

# Generated at 2022-06-18 11:19:00.934129
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    def test_product_inner(tqdm_class):
        """
        Unit test for function product.
        """
        # Test with a single iterable
        assert list(product(range(10), tqdm_class=tqdm_class)) == list(
            itertools.product(range(10)))
        # Test with multiple iterables
        assert list(product(range(10), range(10), tqdm_class=tqdm_class)) == list(
            itertools.product(range(10), range(10)))
        # Test with multiple iterables and repeat

# Generated at 2022-06-18 11:19:09.540533
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import os
    import sys
    from .utils import format_interval
    from .utils import format_sizeof
    from .utils import format_timesofar
    from .utils import format_total
    from .utils import format_virtual_memory
    from .utils import format_wall_clock
    from .utils import format_cpu_times
    from .utils import format_cpu_percent
    from .utils import format_cpu_stats
    from .utils import format_cpu_freq
    from .utils import format_swap_memory
    from .utils import format_disk_usage
    from .utils import format_network_usage
    from .utils import format_network_io_counters

# Generated at 2022-06-18 11:19:34.509908
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:19:43.714939
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a large number of iterations
    n = 100000
    t0 = time.time()
    for _ in product(range(n), range(n), range(n),
                     tqdm_class=tqdm_auto,
                     desc="product(range(n), range(n), range(n))"):
        pass
    t1 = time.time()
    print("\n{} iterations in {} ({}/iter)".format(
        format_sizeof(n**3), format_interval(t1 - t0),
        format_interval((t1 - t0) / (n**3))))

    # Test with a small number of

# Generated at 2022-06-18 11:19:49.937602
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    import time
    import random
    random.seed(0)
    np.random.seed(0)

    def test_product_inner(iterables, tqdm_class):
        t0 = time.time()
        for _ in tqdm_class(product(*iterables),
                            total=np.prod(list(map(len, iterables)))):
            pass
        t1 = time.time()
        return t1 - t0

    def test_product_inner_nontotal(iterables, tqdm_class):
        t0 = time.time()
        for _ in tqdm_class(product(*iterables)):
            pass
        t1 = time.time()
        return t

# Generated at 2022-06-18 11:19:58.341250
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys

    def _test_product(iterables, tqdm_class):
        """
        Test `product` function.
        """
        # Test total
        total = 1
        for i in map(len, iterables):
            total *= i
        # Test iterator
        it = product(*iterables, tqdm_class=tqdm_class)
        assert next(it) == (0, 0, 0)
        assert next(it) == (0, 0, 1)
        assert next(it) == (0, 1, 0)
        assert next(it) == (0, 1, 1)
        assert next(it) == (1, 0, 0)

# Generated at 2022-06-18 11:20:08.391544
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product

    # Test 1
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    d = [10, 11, 12]
    e = [13, 14, 15]
    f = [16, 17, 18]
    g = [19, 20, 21]
    h = [22, 23, 24]
    i = [25, 26, 27]
    j = [28, 29, 30]
    k = [31, 32, 33]
    l = [34, 35, 36]
   

# Generated at 2022-06-18 11:20:10.991963
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    assert_equal(list(product([1, 2], repeat=2)),
                 [(1, 1), (1, 2), (2, 1), (2, 2)])