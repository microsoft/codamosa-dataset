

# Generated at 2022-06-18 11:10:11.073146
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import numpy as np
    import random
    from ..utils import _range

    if sys.version_info[0] == 2:
        from itertools import imap as map
        from itertools import izip as zip
        range = _range

    def test_product_1():
        """Test for function product"""
        for i in product(range(10), range(10), range(10)):
            pass

    def test_product_2():
        """Test for function product"""
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto):
            pass


# Generated at 2022-06-18 11:10:22.232020
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys

    # Test 1: basic
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2: basic
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

    # Test 3: basic
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="test_product"):
        pass

    # Test 4: basic

# Generated at 2022-06-18 11:10:33.384043
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter
    from .utils import FormatCustomText

    with closing(FormatCustomText(desc=None)) as t:
        for _ in product(range(10), range(10), tqdm_class=t.__class__):
            pass
        assert t.n == 100
        assert t.total == 100
        assert t.dynamic_ncols
        assert not t.leave
        assert t.desc is None

    with closing(FormatCustomText(desc=None)) as t:
        for _ in product(range(10), range(10), tqdm_class=t.__class__,
                         total=100):
            pass
        assert t.n == 100
        assert t.total == 100
        assert t.dynamic_ncols

# Generated at 2022-06-18 11:10:41.531630
# Unit test for function product
def test_product():
    from ..utils import _range
    from ..utils import format_sizeof
    import sys
    import time

    # Test for total
    for i in product(_range(10), _range(10), _range(10), _range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(10, 10, 10, 10)"):
        pass

    # Test for no total
    for i in product(_range(10), _range(10), _range(10), _range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(10, 10, 10, 10)"):
        pass

    # Test for no total

# Generated at 2022-06-18 11:10:53.391289
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from ..auto import tqdm

    # Test nested product
    with tqdm(total=10) as t:
        for _ in product(range(10), range(10)):
            sleep(0.01)
            t.update()

    # Test nested product with total
    with tqdm(total=10) as t:
        for _ in product(range(10), range(10), tqdm_class=tqdm):
            sleep(0.01)
            t.update()

    # Test nested product with total

# Generated at 2022-06-18 11:11:02.676086
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    for i in product(range(10), repeat=2):
        print(i)
        time.sleep(0.01)

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.01)

    # Test 3
    print("\nTest 3:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     leave=False, file=sys.stdout):
        print(i)

# Generated at 2022-06-18 11:11:13.087299
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a simple case
    for i in product(range(3), range(3), range(3)):
        pass

    # Test with a large case
    for i in product(range(100), range(100), range(100)):
        pass

    # Test with a very large case
    for i in product(range(1000), range(1000), range(1000)):
        pass

    # Test with a very very large case
    for i in product(range(10000), range(10000), range(10000)):
        pass

    # Test with a very very very large case
    for i in product(range(100000), range(100000), range(100000)):
        pass

    # Test

# Generated at 2022-06-18 11:11:21.856114
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from .tests_tqdm import pretest_posttest

    @pretest_posttest
    def test():
        """
        Unit test for function product
        """
        from ..utils import format_sizeof
        import sys

        def test_product_1():
            """
            Unit test for function product
            """
            for i in product(range(10), range(10), range(10),
                             tqdm_class=tqdm_auto):
                pass

        def test_product_2():
            """
            Unit test for function product
            """

# Generated at 2022-06-18 11:11:31.200606
# Unit test for function product
def test_product():
    from .tests import TestCase
    import numpy as np

    class TestProduct(TestCase):
        def test_product(self):
            for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
                with tqdm_class(total=2 * 3 * 4) as t:
                    for i in product(range(2), range(3), range(4),
                                     tqdm_class=tqdm_class):
                        self.assertEqual(len(i), 3)
                        self.assertEqual(i, tuple(map(int, i)))
                        t.update()


# Generated at 2022-06-18 11:11:39.587713
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_size(n, m):
        """
        Unit test for function product
        """
        # Test product size
        assert format_sizeof(sys.getsizeof(list(itertools.product(range(n),
                                                                 range(m))))) \
            == format_sizeof(sys.getsizeof(list(product(range(n),
                                                        range(m)))))

    def test_product_iter(n, m):
        """
        Unit test for function product
        """
        # Test product iter

# Generated at 2022-06-18 11:11:50.520268
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin, closing

    class TestProduct(FormatMixin):
        def test_product(self):
            """
            Unit test for function product
            """
            with closing(self.cls(unit="B", unit_scale=True,
                                  miniters=1, mininterval=0)) as t:
                for _ in product(range(10), range(10), range(10),
                                 tqdm_class=t.__class__):
                    pass

# Generated at 2022-06-18 11:12:00.281284
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a list of lists
    l = [[1, 2], [3, 4]]
    for i in product(l):
        assert i == (1, 3) or i == (1, 4) or i == (2, 3) or i == (2, 4)

    # Test with a list of lists and a tqdm_class
    l = [[1, 2], [3, 4]]
    for i in product(l, tqdm_class=tqdm_auto):
        assert i == (1, 3) or i == (1, 4) or i == (2, 3) or i == (2, 4)

    # Test with a list of lists and a tqdm_class and a

# Generated at 2022-06-18 11:12:08.758804
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    t1 = time.time()
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:12:14.172488
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        with tqdm_auto(total=10) as t:
            for i in product(range(10), range(10), tqdm_class=t.__class__):
                tc.assertEqual(sum(i), t.n)
                t.update()

# Generated at 2022-06-18 11:12:22.916994
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
    print("  - Test with a simple list")
   

# Generated at 2022-06-18 11:12:24.420239
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import test_product
    test_product(product)

# Generated at 2022-06-18 11:12:33.473678
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    import itertools as it

    # Test 1
    # Test with a simple list
    print("Test 1:")
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]
    print("a =", a)
    print("b =", b)
    print("c =", c)
    print("it.product(a, b, c) =", list(it.product(a, b, c)))
    print("tqdm.product(a, b, c) =", list(product(a, b, c)))

    # Test 2
   

# Generated at 2022-06-18 11:12:41.739902
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval

# Generated at 2022-06-18 11:12:48.980234
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test basic functionality
    assert list(product(range(2), range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Test auto tqdm
    assert list(product(range(2), range(2), tqdm_class=tqdm_auto)) == \
        [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Test total

# Generated at 2022-06-18 11:12:58.021349
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass
    print("\n")

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("\n")

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass
    print("\n")

    # Test 4

# Generated at 2022-06-18 11:13:11.022079
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import string
    import tempfile
    import os
    import shutil
    import gc

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a random string
    rand_str = ''.join(random.choice(string.ascii_uppercase + string.digits)
                       for _ in range(10))

    # Create a random file
    rand_file = os.path.join(tmpdir, rand_str)
    with open(rand_file, "w") as f:
        f.write(rand_str)

    # Create a random file list

# Generated at 2022-06-18 11:13:17.777816
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    # Test 1
    print("\nTest 1:")
    t0 = time.time()
    for i in product(range(10), repeat=3):
        pass
    t1 = time.time()
    print("Time: {0}".format(t1 - t0))

    # Test 2
    print("\nTest 2:")
    t0 = time.time()
    for i in itertools.product(range(10), repeat=3):
        pass
    t1 = time.time()
    print("Time: {0}".format(t1 - t0))

    # Test 3
    print("\nTest 3:")
    t0 = time.time

# Generated at 2022-06-18 11:13:26.096632
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    t0 = time.time()
    for _ in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto):
        pass
    dt = time.time() - t0
    print("\nTest 1:")
    print("  Elapsed time: %s" % format_interval(dt))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(t0)))

    # Test 2
    t0 = time.time()

# Generated at 2022-06-18 11:13:35.430589
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from itertools import product as itertools_product

    # Test 1
    t = time()
    for _ in product(range(10), range(10), range(10)):
        pass
    t = time() - t
    print("Test 1:")
    print("\tTime taken: %s" % format_interval(t))
    print("\tMemory usage: %s" % format_sizeof(0))

    # Test 2
    t = time()
    for _ in itertools_product(range(10), range(10), range(10)):
        pass
    t = time() - t
    print

# Generated at 2022-06-18 11:13:42.169749
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    import time
    import sys
    import os
    import psutil
    import platform
    import locale
    import datetime
    import tempfile
    import shutil
    import subprocess
    import random
    import string
    import math
    import re
    import unicodedata
    import warnings
    import gc
    import inspect
    import threading
    import multiprocessing
    import functools
    import itertools
    import collections
    import contextlib
    import io
    import sys
    import os
    import psutil

# Generated at 2022-06-18 11:13:51.911293
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_line
    from ..utils import format_over
    from ..utils import format_ascii
    from ..utils import format_len
    from ..utils import format_dict
    from ..utils import format_dict_html
    from ..utils import format_dict_csv
    from ..utils import format_dict_string
    from ..utils import format_dict_table
    from ..utils import format_dict_json
    from ..utils import format

# Generated at 2022-06-18 11:14:01.084278
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_number
    from ..utils import format_percentage
    from ..utils import format_time
    from ..utils import format_length
    from ..utils import format_interval
    from ..utils import format_interval_short
    from ..utils import format_interval_long
    from ..utils import format_interval_full


# Generated at 2022-06-18 11:14:04.598787
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.n, 100)

# Generated at 2022-06-18 11:14:10.601658
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np
    from ..utils import format_interval

    # Test 1
    print("Test 1:")
    print("  Iterating over a product of 3 lists of length 10,000,000")
    print("  with a total of 1,000,000,000,000 elements")
    print("  (should take ~1min on a fast machine)")
    start_t = time.time()
    for _ in product(range(10000000), range(10000000), range(10000000)):
        pass
    print("  -> Elapsed time: %s" % format_interval(time.time() - start_t))

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:14:18.916066
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    def test_product_helper(iterables, tqdm_class):
        """
        Helper function for test_product
        """
        t = tqdm_class(iterables, leave=False)
        for i in product(*iterables, tqdm_class=tqdm_class):
            t.update()
        t.close()

    # Test for small iterables
    for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
        iterables = [range(10), range(10), range(10)]

# Generated at 2022-06-18 11:14:36.908221
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    def test_product_gen(iterables, **kwargs):
        """
        Generator for testing product.
        """
        for i in product(*iterables, **kwargs):
            yield i

    def test_product_list(iterables, **kwargs):
        """
        List for testing product.
        """
        return list(product(*iterables, **kwargs))

    def test_product_set(iterables, **kwargs):
        """
        Set for testing product.
        """
        return set(product(*iterables, **kwargs))


# Generated at 2022-06-18 11:14:46.375464
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("Test 1:")
    print("  - Test product with tqdm_class=tqdm.auto.tqdm")
    print("  - Test product with tqdm_class=tqdm.tqdm")
    print("  - Test product with tqdm_class=tqdm.tqdm_gui")
    print("  - Test product with tqdm_class=tqdm.tqdm_notebook")
    print("  - Test product with tqdm_class=tqdm.tqdm_pandas")

# Generated at 2022-06-18 11:14:55.811825
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_inner(iterables, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    # Test with a small iterable
    test_product_inner([range(10), range(10)], tqdm_auto)

    # Test with a large iterable
    test_product_inner([range(1000), range(1000)], tqdm_auto)

    # Test with a huge iterable
    test_product_inner([range(10000), range(10000)], tqdm_auto)

    # Test with a huge iterable

# Generated at 2022-06-18 11:15:03.502535
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    from ..utils import _range

    # Test for total
    for i in product(_range(10), _range(10), _range(10), _range(10),
                     tqdm_class=tqdm_auto):
        pass
    # Test for no total
    for i in product(iter(_range(10)), iter(_range(10)), iter(_range(10)),
                     iter(_range(10)), tqdm_class=tqdm_auto):
        pass

    # Test for no total

# Generated at 2022-06-18 11:15:09.911010
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    t0 = time.time()
    for _ in product(range(100), range(100), range(100)):
        pass
    t1 = time.time()
    print("Test 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(t1 - t0)))

    # Test 2
    t0 = time.time()
    for _ in product(range(100), range(100), range(100), tqdm_class=tqdm_auto):
        pass
    t1

# Generated at 2022-06-18 11:15:17.434671
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test 1
    print("Test 1")
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)


# Generated at 2022-06-18 11:15:27.070705
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test with tqdm_class
    t0 = time()
    for i in product(range(100), range(100), tqdm_class=tqdm_auto):
        pass
    dt = time() - t0
    assert format_interval(dt) == '0:00:00'
    assert format_sizeof(getsizeof(i)) == '0.0 B'

    # Test without tqdm_class
    t0 = time()
    for i in product(range(100), range(100)):
        pass
    dt = time() - t0

# Generated at 2022-06-18 11:15:36.338378
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False):
        pass
    print("\n")

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        pass
    print("\n")

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:15:42.147586
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

    def random_list(length):
        return [random.random() for _ in range(length)]

    def random_dict(length):
        return {random_string(10): random_string(10) for _ in range(length)}

    def random_tuple(length):
        return tuple(random_list(length))

    def random_set(length):
        return set(random_list(length))

    def random_generator(length):
        for _ in range(length):
            yield random.random()


# Generated at 2022-06-18 11:15:51.995391
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("\tTime:", format_interval(t1 - t0))
    print("\tMemory:", format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:16:30.539259
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False):
        pass
    dt = time.time() - t0
    print("\nTotal time:", format_interval(dt))
    print("Total size:", format_sizeof(sys.getsizeof(i) * 1000))

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:16:37.132699
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1")
    t0 = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    t1 = time.time()
    print("Elapsed time: %s" % format_interval(t1 - t0))
    print("Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    t1

# Generated at 2022-06-18 11:16:46.708529
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    def test_product_1():
        """Test product"""
        for i in product(range(10), range(10), range(10)):
            pass

    def test_product_2():
        """Test product with total"""
        for i in product(range(10), range(10), range(10), total=1000):
            pass

    def test_product_3():
        """Test product with total"""
        for i in product(range(10), range(10), range(10), total=1000,
                         desc="test_product_3"):
            pass

    def test_product_4():
        """Test product with total"""

# Generated at 2022-06-18 11:16:55.169881
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof

    # Test 1
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)
    m = np.arange(10)
    n = np.arange(10)
    o = np.arange(10)

# Generated at 2022-06-18 11:17:02.917304
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    a = range(10)
    b = range(10)
    c = range(10)
    d = range(10)
    e = range(10)
    f = range(10)
    g = range(10)
    h = range(10)
    i = range(10)
    j = range(10)
    k = range(10)
    l = range(10)
    m = range(10)
    n = range(10)
    o = range(10)
    p = range(10)
    q = range(10)
    r = range(10)
   

# Generated at 2022-06-18 11:17:13.107726
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    print("  * Generate a list of all possible combinations of a, b, c, d")
    print("  * Print the combinations")
    print("  * Print the total number of combinations")
    print("  * Print the memory usage of the list")
    print("  * Print the time taken to generate the list")
    print("")
    a = ["a", "b", "c", "d"]
    b = ["e", "f", "g", "h"]
    c = ["i", "j", "k", "l"]
    d = ["m", "n", "o", "p"]
    start = time

# Generated at 2022-06-18 11:17:19.524831
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import gc
    import random
    from .utils import FormatCustomTextTestResult
    from .utils import TestCase
    from .utils import run_tests

    class TestProduct(TestCase):
        def test_product(self):
            """
            Unit test for function product
            """
            # Test with a small number of iterables
            for n in range(1, 10):
                iterables = [range(random.randint(1, 10)) for _ in range(n)]
                self.assertEqual(list(product(*iterables)),
                                 list(itertools.product(*iterables)))

            # Test with a large number of iterables

# Generated at 2022-06-18 11:17:27.978229
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    try:
        from collections import Counter
    except ImportError:
        from .._vendor.counter import Counter

    # Test basic functionality
    assert list(product(range(2), repeat=3)) == [(0, 0, 0), (0, 0, 1),
                                                 (0, 1, 0), (0, 1, 1),
                                                 (1, 0, 0), (1, 0, 1),
                                                 (1, 1, 0), (1, 1, 1)]

    # Test that it works with non-iterable arguments
    assert list(product(1, range(2))) == [(1, 0), (1, 1)]

    # Test that it works with iterables of different lengths
   

# Generated at 2022-06-18 11:17:34.169620
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import format_interval
    import time
    import sys

    # Test 1
    t = time.time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, desc="Test 1"):
        pass
    print("Test 1:", format_interval(time.time() - t),
          format_sizeof(sys.getsizeof(_)))

    # Test 2
    t = time.time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, desc="Test 2", leave=True):
        pass

# Generated at 2022-06-18 11:17:41.965148
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import getsizeof

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=3):
        print(i)
    print("\n")

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        print(i)
    print("\n")

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:18:07.983214
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests_tqdm import with_setup, _range, pretest, posttest, closing

    @with_setup(pretest, posttest)
    def wrapper():
        """
        Unit test for function product
        """
        for i in product(_range(10), _range(10), _range(10),
                         tqdm_class=tqdm_auto):
            pass

    wrapper()

# Generated at 2022-06-18 11:18:15.737747
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_len_str
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_length_size
    from ..utils import format_length_str
    from ..utils import format_length_size_str
    from ..utils import format_length_rate
    from ..utils import format_length_rate_str
    from ..utils import format

# Generated at 2022-06-18 11:18:23.859863
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10)):
        t.update()
    assert t.n == 1000

    # Test 2
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10)):
        t.update()
    assert t.n == 1000

    # Test 3
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10)):
        t.update()
    assert t.n == 1000

    # Test 4
    t = t

# Generated at 2022-06-18 11:18:33.741269
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test with no total
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with total
    for i in product(range(10), range(10), range(10), total=1000):
        pass

    # Test with total and no iterable
    for i in product(total=1000):
        pass

    # Test with total and no iterable
    for i in product(total=1000):
        pass

    # Test with total and no iterable
    for i in product(total=1000):
        pass

    # Test with total and no iterable

# Generated at 2022-06-18 11:18:42.164230
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:18:51.194559
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")

# Generated at 2022-06-18 11:18:59.070031
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6]]
    for i in product(list_of_lists):
        pass

    # Test with a list of arrays
    list_of_arrays = [np.arange(1, 4), np.arange(4, 7)]
    for i in product(list_of_arrays):
        pass

    # Test with a list of arrays and a list of lists
    list_of_arrays = [np.arange(1, 4), np.arange(4, 7)]
    list_of_lists = [[1, 2, 3], [4, 5, 6]]


# Generated at 2022-06-18 11:19:07.534721
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import version_info
    from itertools import product as itertools_product
    from itertools import islice

    # Test 1: basic
    assert list(product(range(3), range(4))) == list(itertools_product(range(3), range(4)))

    # Test 2: total
    assert list(product(range(3), range(4), tqdm_class=tqdm_auto, total=12)) == list(itertools_product(range(3), range(4)))

    # Test 3: total=None
    assert list(product(range(3), range(4), tqdm_class=tqdm_auto, total=None)) == list

# Generated at 2022-06-18 11:19:13.675370
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing


# Generated at 2022-06-18 11:19:22.075272
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    for i in product(range(10), repeat=3):
        pass

    # Test 2
    for i in product(range(10), repeat=3, tqdm_class=FormatCustomText):
        pass

    # Test 3
    for i in product(range(10), repeat=3, tqdm_class=FormatCustomText,
                     bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}]"):
        pass

    # Test 4

# Generated at 2022-06-18 11:19:58.828931
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  - itertools.product(range(10), repeat=2)")
    print("  - tqdm(total=100)")
    print("  - tqdm(total=None)")
    print("  - tqdm(total=100, unit='B')")
    print("  - tqdm(total=100, unit='B', unit_scale=True)")
    print("  - tqdm(total=100, unit='B', unit_scale=True, miniters=1)")

# Generated at 2022-06-18 11:20:08.429311
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    print("  - Test that product works with no iterables")
    for i in product():
        print(i)

    # Test 2
    print("\nTest 2:")
    print("  - Test that product works with one iterable")
    for i in product(range(10)):
        print(i)

    # Test 3
    print("\nTest 3:")
    print("  - Test that product works with two iterables")
    for i in product(range(10), range(10)):
        print(i)

    # Test 4
    print("\nTest 4:")