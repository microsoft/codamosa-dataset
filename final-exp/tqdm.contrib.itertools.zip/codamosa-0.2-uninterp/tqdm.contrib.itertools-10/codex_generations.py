

# Generated at 2022-06-18 11:10:11.069714
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1
    print("\nTest 1:")
    print("  Generating 10**6 random numbers in [0, 1]...")
    t0 = time.time()
    for i in product(range(10), repeat=6):
        pass
    t1 = time.time()
    print("  Elapsed time: %s" % (t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("\nTest 2:")
    print("  Generating 10**6 random numbers in [0, 1]...")
    t0 = time.time()

# Generated at 2022-06-18 11:10:22.234043
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        with product(range(3), range(3), tqdm_class=tc.tqdm_class) as p:
            for i in p:
                pass
        tc.assertEqual(tc.sp(0), '0it [00:00, ?it/s]')
        tc.assertEqual(tc.sp(1), '9it [00:00, ?it/s]')
        tc.assertEqual(tc.sp(2), '9it [00:00, ?it/s]')
        tc.assertEqual(tc.sp(3), '9it [00:00, ?it/s]')

# Generated at 2022-06-18 11:10:33.389298
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..std import tqdm
    from ..std import time


# Generated at 2022-06-18 11:10:41.532042
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from itertools import product as itertools_product

    # Test 1
    with tqdm_auto(total=10) as t:
        for i in product(range(10), range(10)):
            assert i == (t.n, t.n)
            t.update()

    # Test 2
    with tqdm_auto(total=10) as t:
        for i in product(range(10), range(10), tqdm_class=tqdm_auto):
            assert i == (t.n, t.n)
            t.update()

    # Test 3

# Generated at 2022-06-18 11:10:53.384506
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_of_dict
    from ..utils import format_dict_of_dict_fmt
    from ..utils import format_sizeof_fmt_str
    from ..utils import format

# Generated at 2022-06-18 11:11:02.668674
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random

    # Test 1: basic
    # -------------
    # Create a list of random numbers
    n = 10
    random_list = [random.random() for _ in range(n)]
    # Create a list of random numbers with tqdm
    random_list_tqdm = list(product(random_list, tqdm_class=tqdm_auto))
    # Check that the two lists are identical
    assert random_list == random_list_tqdm

    # Test 2: memory usage
    # --------------------
    # Create a list of random numbers
    n = 1000000

# Generated at 2022-06-18 11:11:13.087298
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    # Test for no iterable
    assert list(product()) == [()]

    # Test for one iterable
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    # Test for two iterables
    assert list(product([1, 2, 3], [4, 5, 6])) == [(1, 4), (1, 5), (1, 6),
                                                   (2, 4), (2, 5), (2, 6),
                                                   (3, 4), (3, 5), (3, 6)]

    # Test for three iterables

# Generated at 2022-06-18 11:11:21.856130
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesince
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timesince_fmt
    from ..utils import format_number_fmt
    from ..utils import format_time_fmt
    from ..utils import format_speed_fmt
    from ..utils import format_eta_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short

# Generated at 2022-06-18 11:11:31.199989
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint

    # Test 1
    t = time()
    for i in product(range(10), range(10), range(10)):
        pass
    dt = time() - t
    print("Test 1:", format_interval(dt), format_sizeof(getsizeof(i)))

    # Test 2
    t = time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    dt = time() - t

# Generated at 2022-06-18 11:11:35.619416
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:11:42.386902
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    print("Test 2:")
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:11:50.744798
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_helper(iterables, tqdm_class, **tqdm_kwargs):
        """Helper for test_product"""
        kwargs = tqdm_kwargs.copy()
        kwargs.setdefault("tqdm_class", tqdm_class)
        kwargs.setdefault("leave", True)
        kwargs.setdefault("miniters", 1)
        kwargs.setdefault("desc", "test_product")
        kwargs.setdefault("unit_scale", True)
        kwargs.setdefault("unit", "it")
        kwargs.setdefault("ascii", True)

# Generated at 2022-06-18 11:12:00.504181
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin

    class TqdmTest(FormatMixin):
        """
        Minimal class for testing
        """
        @staticmethod
        def format_meter(n, total, elapsed):
            """
            Format the progress meter
            """
            return '%5s' % (n or '?')

    with TqdmTest(unit='B', unit_scale=True, unit_divisor=1024) as t:
        for i in product(range(1000), range(1000),
                         tqdm_class=t.__class__,
                         desc='Looping', leave=False):
            t.set_postfix(i=i, refresh=False)
            t.update()
        assert t.n

# Generated at 2022-06-18 11:12:08.953558
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:12:18.505518
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    def product_test(iterables, tqdm_class=tqdm_auto):
        """
        Test for function product.
        """
        for _ in tqdm_class(product(*iterables, tqdm_class=tqdm_class)):
            pass

    def product_test_nogui(iterables, tqdm_class=tqdm_auto):
        """
        Test for function product.
        """
        for _ in tqdm_class(product(*iterables, tqdm_class=tqdm_class),
                            gui=False):
            pass


# Generated at 2022-06-18 11:12:26.584044
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_generator(iterables, total):
        """
        Test product generator
        """
        for i in product(*iterables):
            pass

    def test_product_list(iterables, total):
        """
        Test product list
        """
        list(product(*iterables))

    def test_product_itertools(iterables, total):
        """
        Test product itertools
        """
        list(itertools.product(*iterables))

    def test_product_itertools_imap(iterables, total):
        """
        Test product itertools imap
        """

# Generated at 2022-06-18 11:12:35.975406
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    # Test with a list of lists
    list_of_lists = [[1, 2], [3, 4], [5, 6]]
    list_of_lists_product = list(product(list_of_lists))
    assert list_of_lists_product == [(1, 3, 5), (1, 3, 6), (1, 4, 5),
                                     (1, 4, 6), (2, 3, 5), (2, 3, 6),
                                     (2, 4, 5), (2, 4, 6)]

    # Test with a list of generators

# Generated at 2022-06-18 11:12:43.770324
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase, closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.cls):
            pass
        tc.assertEqual(tc.n, 100)

        for i in product(range(10), range(10), tqdm_class=tc.cls,
                         miniters=1):
            pass
        tc.assertEqual(tc.n, 100)

        for i in product(range(10), range(10), tqdm_class=tc.cls,
                         miniters=1, mininterval=0):
            pass
        tc.assertEqual(tc.n, 100)


# Generated at 2022-06-18 11:12:52.586162
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test 1
    for i in product(range(10), range(10), range(10), range(10)):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, desc="test"):
        pass

    # Test 4

# Generated at 2022-06-18 11:13:02.832140
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a simple iterator
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    for i in product(gen(), gen(), gen()):
        pass

    # Test with a generator that raises StopIteration
    def gen():
        for i in range(10):
            yield i
        raise StopIteration

    for i in product(gen(), gen(), gen()):
        pass

    # Test with a generator that raises StopIteration
    def gen():
        for i in range(10):
            yield i
        raise

# Generated at 2022-06-18 11:13:12.663302
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        def __init__(self, *args, **kwargs):
            super(FormatWrap, self).__init__(*args, **kwargs)
            self.iterable = iter(self.iterable)

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.iterable)

        def __len__(self):
            return len(self.iterable)


# Generated at 2022-06-18 11:13:18.973411
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import tempfile
    import shutil
    import random
    import string
    import io
    import gc
    import warnings
    import traceback
    import contextlib
    import unittest
    import itertools

    # Suppress warnings during tests
    @contextlib.contextmanager
    def no_stderrout():
        save_stderr = sys.stderr
        save_stdout = sys.stdout
        sys.stderr = io.BytesIO()
        sys.stdout = io.BytesIO()
        yield
        sys.stderr = save_stderr
        sys.stdout = save_stdout

# Generated at 2022-06-18 11:13:28.406383
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    for i in product(gen(), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
            time.sleep(0.01)

    for i in product(gen(), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
            time.sleep(0.01)

# Generated at 2022-06-18 11:13:36.937864
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(iterables):
        for i in product(*iterables):
            yield i

    def test_product_list(iterables):
        return list(product(*iterables))

    def test_product_noloop(iterables):
        return list(product(*iterables, tqdm_class=tqdm_auto.tqdm_gui))

    def test_product_noloop_nogui(iterables):
        return list(product(*iterables, tqdm_class=tqdm_auto.tqdm))


# Generated at 2022-06-18 11:13:43.314853
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:13:53.077373
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import os
    import random
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval


# Generated at 2022-06-18 11:14:02.005403
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys

    # Test with a large number of small lists
    N = 100
    M = 10
    L = [list(range(M)) for _ in range(N)]
    for i in product(*L):
        pass

    # Test with a small number of large lists
    N = 10
    M = 100000
    L = [list(range(M)) for _ in range(N)]
    for i in product(*L):
        pass

    # Test with a small number of large lists
    N = 10
    M = 100000
    L = [list(range(M)) for _ in range(N)]
    for i in product(*L):
        pass

# Generated at 2022-06-18 11:14:08.893762
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_1():
        """
        Unit test for function product
        """
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="product(range(10), range(10), range(10))"):
            pass

    def test_product_2():
        """
        Unit test for function product
        """

# Generated at 2022-06-18 11:14:17.484856
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:14:25.326244
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random

    def test_product_1():
        """
        Unit test for function product
        """
        # Test 1
        print("\nTest 1:")
        for i in product(range(10), range(10), range(10)):
            pass
        print("\nTest 2:")
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto):
            pass

    def test_product_2():
        """
        Unit test for function product
        """
        # Test 2
        print("\nTest 3:")

# Generated at 2022-06-18 11:14:34.925403
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..std import tqdm

    # Test basic functionality
    assert list(product(range(3), range(4))) == list(itertools.product(range(3), range(4)))

    # Test total
    with tqdm(total=12) as t:
        for _ in product(range(3), range(4)):
            t.update()

    # Test total=None
    with tqdm(total=None) as t:
        for _ in product(range(3), range(4)):
            t.update()

    # Test custom tqdm_class

# Generated at 2022-06-18 11:14:41.428871
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test 1
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="test"):
        pass

    # Test 4
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc="test", leave=True):
        pass

    #

# Generated at 2022-06-18 11:14:49.618606
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof

# Generated at 2022-06-18 11:14:58.798995
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np
    import pandas as pd

    # Test 1
    print("Test 1:")
    print("  - Test with a list of lists")
    print("  - Test with a list of arrays")
    print("  - Test with a list of dataframes")
    print("  - Test with a list of lists and arrays")
    print("  - Test with a list of lists, arrays and dataframes")
    print("  - Test with a list of lists, arrays, dataframes and a generator")
    print("  - Test with a list of lists, arrays, dataframes and a generator")
    print("  - Test with a list of lists, arrays, dataframes and a generator")

# Generated at 2022-06-18 11:15:06.340371
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    # Test 1
    print("Test 1:")
    t0 = time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    dt = time() - t0
    print("dt = {0}".format(format_interval(dt)))
    print("")

    # Test 2
    print("Test 2:")
    t0 = time()

# Generated at 2022-06-18 11:15:13.208576
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=3):
        print(i)
    print()

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        print(i)
    print()

    # Test 3
    print("Test 3:")
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
    print()

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:15:21.278778
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i

# Generated at 2022-06-18 11:15:32.073554
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_helper(tqdm_class):
        # Test product
        print("\nTesting `product`:")
        t0 = time.time()
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_class):
            pass
        print("\t-> %s" % format_interval(time.time() - t0))

    test_product_helper(tqdm_auto)
    test_product_helper(tqdm_auto.tqdm)

    # Test product with total
    print("\nTesting `product` with total:")


# Generated at 2022-06-18 11:15:39.188970
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_helper(iterables, tqdm_class=tqdm_auto):
        """
        Helper function for testing product
        """
        # Test that product works
        for _ in product(*iterables, tqdm_class=tqdm_class):
            pass

        # Test that product works with total
        for _ in product(*iterables, tqdm_class=tqdm_class, total=1):
            pass

        # Test that product works with total=None
        for _ in product(*iterables, tqdm_class=tqdm_class, total=None):
            pass

        # Test that product works with total=0

# Generated at 2022-06-18 11:15:48.746357
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fname = os.path.join(tmpdir, 'tmp_file')
    with open(fname, 'w') as fobj:
        for i in range(100):
            fobj.write(''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(100)))
            fobj.write(os.linesep)

    # Test for function product
    print('Test for function product:')
   

# Generated at 2022-06-18 11:16:01.104789
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("Test 1:", end=' ')
    try:
        for _ in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="Test 1",
                         leave=False):
            pass
    except Exception as e:
        print("\nException raised: {}".format(e))
    else:
        print("OK")

    # Test 2
    print("Test 2:", end=' ')

# Generated at 2022-06-18 11:16:07.915663
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import os
    import time
    import numpy as np
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval

# Generated at 2022-06-18 11:16:16.719284
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    print("  - product(range(10), repeat=2)")
    t0 = time.time()
    for i in product(range(10), repeat=2):
        pass
    t1 = time.time()
    print("  - time: %s" % format_interval(t1 - t0))
    print("  - memory: %s" % format_sizeof(sys.getsizeof(i)))
    print("  - memory: %s" % format_sizeof(sys.getsizeof(i) * 100))

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:16:26.454381
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    import time
    import sys

    # Test 1:
    # Test product() with a single iterable
    # Test product() with a single iterable
    t = time.time()
    for i in product(range(10)):
        pass
    t = time.time() - t
    print("Test 1:")
    print("  Product of range(10)")
    print("  Total time: %s" % format_interval(t))
    print("  Total size: %s" % format_sizeof(sys.getsizeof(i)))
    print("  Total items: %s" % format_sizeof(len(i)))
    print

# Generated at 2022-06-18 11:16:34.188521
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(iterables):
        """
        Generator for testing product
        """
        for i in itertools.product(*iterables):
            yield i

    def test_product_tqdm(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for i in product(*iterables, **tqdm_kwargs):
            yield i

    def test_product_tqdm_gen(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for i in product(*iterables, **tqdm_kwargs):
            yield i
            time.sleep(0.001)


# Generated at 2022-06-18 11:16:42.617087
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof

# Generated at 2022-06-18 11:16:51.352883
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_dimensions
    from ..utils import format_speed
    from ..utils import format_speed2
    from ..utils import format_sizeof_fmt
    from ..utils import format_sizeof_fmt2
    from ..utils import format_sizeof_fmt3
    from ..utils import format_sizeof_fmt4
    from ..utils import format_sizeof_fmt5
    from ..utils import format_sizeof_fmt6
    from ..utils import format_sizeof_fmt7

# Generated at 2022-06-18 11:16:59.577859
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_gen(iterables, tqdm_class):
        """
        Unit test for function product
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class):
        """
        Unit test for function product
        """
        list(product(*iterables, tqdm_class=tqdm_class))

    def test_product_np(iterables, tqdm_class):
        """
        Unit test for function product
        """
        np.array(list(product(*iterables, tqdm_class=tqdm_class)))

   

# Generated at 2022-06-18 11:17:06.305077
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 3",
                     leave=True,
                     miniters=1):
        pass

    #

# Generated at 2022-06-18 11:17:15.074957
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    print("Test 1:")
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10)):
        t.update()
    t.close()

    # Test 2
    print("Test 2:")
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        t.update()
    t.close()

    # Test 3
    print("Test 3:")
    t = tqdm_auto(total=10)

# Generated at 2022-06-18 11:17:28.152956
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_helper(iterables, **kwargs):
        """
        Helper function for test_product
        """
        t0 = time.time()
        for _ in product(*iterables, **kwargs):
            pass
        t1 = time.time()
        return t1 - t0

    def test_product_helper_itertools(iterables):
        """
        Helper function for test_product
        """
        t0 = time.time()
        for _ in itertools.product(*iterables):
            pass
        t1 = time.time()
        return t1 - t0


# Generated at 2022-06-18 11:17:33.024128
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10), range(10), range(10))"):
        pass
    print("-> Elapsed time:", format_interval(time.time() - t))
    print("-> Memory usage:", format_sizeof(sys.getsizeof(i)))
    print("-> i:", i)
    print("-> type(i):", type(i))

# Generated at 2022-06-18 11:17:37.803149
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_timesofar
    from .utils import format_transferrate
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_size
    from .utils import format_number
    from .utils import format_time
    from .utils import format_len
    from .utils import format_interval
    from .utils import format_interval
    from .utils import format_interval
    from .utils import format_interval
    from .utils import format_interval
    from .utils import format_interval
    from .utils import format_interval

# Generated at 2022-06-18 11:17:46.806384
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof

    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Testing product"):
        pass

    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Testing product",
                     unit="it"):
        pass

    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Testing product",
                     unit="it",
                     unit_scale=True):
        pass


# Generated at 2022-06-18 11:17:56.258655
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test basic functionality
    assert list(product(range(2), range(3))) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2)]

    # Test total
    assert list(product(range(2), range(3), tqdm_class=tqdm_auto,
                        total=6)) == [(0, 0), (0, 1), (0, 2),
                                      (1, 0), (1, 1), (1, 2)]

    # Test total with non-iterable

# Generated at 2022-06-18 11:18:05.625165
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test 1
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="1. Testing product"):
        pass
    print(" -> Elapsed time:", format_interval(time.time() - t))

    # Test 2
    t = time.time()

# Generated at 2022-06-18 11:18:14.528679
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1:
    # -------
    # Test with a simple product
    #
    # Expected result:
    # ----------------
    # The product of the two iterables
    #
    # Test 2:
    # -------
    # Test with a product of a list and a generator
    #
    # Expected result:
    # ----------------
    # The product of the two iterables
    #
    # Test 3:
    # -------
    # Test with a product of a list and a generator
    #
    # Expected result:
    # ----------------
    # The product of the two iterables
    #
    # Test 4:
    # -------
    # Test

# Generated at 2022-06-18 11:18:23.094937
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_inner(iterables, **tqdm_kwargs):
        """
        Unit test for function product
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
               

# Generated at 2022-06-18 11:18:32.816443
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1:
    # Test with a simple iterator
    print("\nTest 1:")
    print("Test with a simple iterator")
    print("-" * 16)
    for i in product(range(10), range(10)):
        pass

    # Test 2:
    # Test with a simple iterator
    print("\nTest 2:")
    print("Test with a simple iterator")
    print("-" * 16)
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3:
    # Test with a simple iterator
    print("\nTest 3:")

# Generated at 2022-06-18 11:18:41.666616
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("\nTest 1:")
    iterables = [[1, 2, 3], [4, 5, 6]]
    for i in product(*iterables):
        print(i)

    # Test 2
    print("\nTest 2:")
    iterables = [[1, 2, 3], [4, 5, 6]]
    for i in product(*iterables, tqdm_class=tqdm_auto):
        print(i)

    # Test 3
    print("\nTest 3:")
    iterables = [[1, 2, 3], [4, 5, 6]]

# Generated at 2022-06-18 11:18:58.760869
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_unicode
    from ..utils import format_dict_unicode_fmt
    from ..utils import format_dict_html
    from ..utils import format

# Generated at 2022-06-18 11:19:07.251202
# Unit test for function product
def test_product():
    from .utils import FormatMixin
    from .utils import StringIO
    from .utils import closing

    class Tqdm(FormatMixin, tqdm_auto):
        def __init__(self, *args, **kwargs):
            super(Tqdm, self).__init__(*args, **kwargs)
            self.file = StringIO()

    with closing(Tqdm(total=4)) as t:
        for i in product(range(2), range(2), tqdm_class=Tqdm):
            t.update()
    assert t.file.getvalue() == "0/4\r1/4\r2/4\r3/4\r"


# Generated at 2022-06-18 11:19:13.444477
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test 1
    print("Test 1")
    for i in product(range(10), repeat=2):
        print(i)
    print()

    # Test 2
    print("Test 2")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
    print()

    # Test 3
    print("Test 3")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
    print()

    # Test 4
    print("Test 4")

# Generated at 2022-06-18 11:19:21.837030
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from .. import trange

    # Test 1
    with trange(10, desc="test 1") as t:
        for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
            pass

    # Test 2
    with trange(10, desc="test 2") as t:
        for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
            pass

    # Test 3

# Generated at 2022-06-18 11:19:30.365389
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:19:39.153289
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import _range

    def check_product(iterables, tqdm_class=tqdm_auto):
        """
        Check that product is equivalent to itertools.product
        """
        assert list(product(*iterables, tqdm_class=tqdm_class)) == list(
            itertools.product(*iterables))

    check_product([_range(10), _range(10)])
    check_product([_range(10), _range(10), _range(10)])
    check_product([_range(10), _range(10), _range(10), _range(10)])

# Generated at 2022-06-18 11:19:47.233598
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from .utils import format_interval

    # Test with a small number of elements

# Generated at 2022-06-18 11:19:56.589877
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number

# Generated at 2022-06-18 11:20:06.597930
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from ..utils import format_sizeof
    import sys

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Test for function product generator
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_auto):
        """
        Test for function product list
        """
        list(product(*iterables, tqdm_class=tqdm_class))

    def test_product_list_total(iterables, tqdm_class=tqdm_auto):
        """
        Test for function product list with total
        """