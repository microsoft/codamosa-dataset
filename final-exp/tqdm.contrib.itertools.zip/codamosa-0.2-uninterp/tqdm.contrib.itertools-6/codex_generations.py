

# Generated at 2022-06-18 11:10:13.200459
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=100)
    for i in product(range(100), range(100), range(100), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=100)
    for i in product(range(100), range(100), range(100), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=100)

# Generated at 2022-06-18 11:10:23.646511
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=100, file=sys.stdout)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        time.sleep(0.01)
        t.update()
    t.close()

    # Test 2
    t = tqdm_auto(total=100, file=sys.stdout)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        time.sleep(0.01)
        t.update()
    t.close()

# Generated at 2022-06-18 11:10:34.741402
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a list of lists
    l = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    l_prod = list(product(l))

# Generated at 2022-06-18 11:10:42.597206
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import stderr
    from os import getpid
    from os import getppid
    from os import getcwd
    from os import getloadavg
    from os import getuid
    from os import getgid
    from os import geteuid
    from os import getegid
    from os import getgroups
    from os import getlogin
    from os import getenv
    from os import get_terminal_size
    from os import get_inheritable
    from os import get_blocking
    from os import get_handle_inheritable
    from os import get_close_on_exec
    from os import get_terminal

# Generated at 2022-06-18 11:10:45.550748
# Unit test for function product
def test_product():
    from .tests import TestCase
    with TestCase() as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        assert tc.total == 100

# Generated at 2022-06-18 11:10:53.583510
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..tests import TestCase
    from ..tests._utils import _random_data

    for iterable in _random_data(n_iter=10, n_samples=10):
        for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
            with TestCase(tqdm_class=tqdm_class) as tc:
                for _ in product(*iterable, tqdm_class=tqdm_class):
                    tc.assertTrue(True)

# Generated at 2022-06-18 11:11:02.804857
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import random
    import string
    import sys

    def random_string(length):
        """
        Generate a random string of given length.
        """
        return ''.join(random.choice(string.ascii_letters) for m in range(length))

    # Test 1: product of two lists
    list1 = [1, 2, 3, 4]
    list2 = ['a', 'b', 'c']
    list_product = list(product(list1, list2))

# Generated at 2022-06-18 11:11:11.316240
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        def format_meter(self, n, total, elapsed):
            return "|%s|" % self.format_number(n)

    with closing(StringIO()) as our_file:
        for _ in product(range(10), range(10), range(10),
                         tqdm_class=FormatWrap, file=our_file):
            pass
        assert our_file.getvalue() == "|0|\n|100|\n"

# Generated at 2022-06-18 11:11:20.431542
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    # Test with a list of lists
    for n in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]:
        t = time()
        for _ in product(*[[randint(0, 100) for _ in range(n)] for _ in range(n)]):
            pass
        t = time() - t

# Generated at 2022-06-18 11:11:26.043598
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False):
        pass
    print("Test 1:", format_interval(time.time() - t),
          format_sizeof(sys.getsizeof(i)))

    # Test 2
    t = time.time()

# Generated at 2022-06-18 11:11:38.747178
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import os
    import tempfile
    import shutil
    import gc

    # Test with a large number of items
    try:
        tmpdir = tempfile.mkdtemp()
        fname = os.path.join(tmpdir, 'test.txt')
        with open(fname, 'w') as f:
            for i in product(range(1000), range(1000), range(1000)):
                f.write('{}\n'.format(i))
        assert os.path.getsize(fname) == format_sizeof(
            1000**3 * sys.getsizeof(int))
    finally:
        shutil.rmtree(tmpdir)
        gc.collect()

# Generated at 2022-06-18 11:11:47.264822
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        """
        Wrap format to make it easier to test
        """
        @staticmethod
        def format_meter(n, total, elapsed, ncols=None, prefix='',
                         ascii=None, unit='it', unit_scale=False, rate=None,
                         bar_format=None):
            """
            Format the progress bar
            """
            return '%s%s%s' % (prefix, n, unit)


# Generated at 2022-06-18 11:11:56.452418
# Unit test for function product
def test_product():
    """Test for function `product`"""
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test for function `product`
    print("Testing function `product`...")
    print("  Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    print("    Elapsed time: %s" % format_interval(time.time() - t))
    print("  Test 2:")
    t = time.time()

# Generated at 2022-06-18 11:12:05.556406
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import gc
    import numpy as np
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan

# Generated at 2022-06-18 11:12:14.518857
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    from .utils import closing

    # Test for total
    with closing(tqdm_auto(total=10)) as t:
        for _ in product(range(10), range(10)):
            t.update()
    assert t.n == 100

    # Test for total
    with closing(tqdm_auto(total=10)) as t:
        for _ in product(range(10), range(10), range(10)):
            t.update()
    assert t.n == 1000

    # Test for total

# Generated at 2022-06-18 11:12:23.246334
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test with total
    with tqdm_auto(total=10) as t:
        for i in product(range(10), range(10), tqdm_class=tqdm_auto):
            pass
    assert t.n == 10

    # Test without total
    with tqdm_auto() as t:
        for i in product(range(10), range(10), tqdm_class=tqdm_auto):
            pass
    assert t.n == 100

    # Test with total and nested tqdm

# Generated at 2022-06-18 11:12:32.258930
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:12:40.710911
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product
    from itertools import islice

    # Test 1
    t0 = time()
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time()
    t2 = time()
    for i in itertools_product(range(10), range(10), range(10)):
        pass
    t3 = time()
    print("Test 1:")

# Generated at 2022-06-18 11:12:46.932622
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import closing

    class Test(FormatWrapBase):
        def __init__(self, iterable, *args, **kwargs):
            self.iterable = iterable
            super(Test, self).__init__(*args, **kwargs)

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.iterable)

    with closing(Test(product(range(10), range(10), range(10)),
                      total=1000)) as t:
        for _ in t:
            pass


# Generated at 2022-06-18 11:12:49.123622
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tqdm import tqdm

    for i in product(range(10), range(10), tqdm_class=tqdm):
        pass

# Generated at 2022-06-18 11:13:01.865288
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    if os.name == 'nt':
        # Windows doesn't support changing the stream buffer size
        raise unittest.SkipTest("Can't change Windows stream buffer size")

    # Test with a large buffer size
    old_bufsize = -1
    try:
        old_bufsize = os.fstat(sys.stdout.fileno()).st_blksize
        os.fstat(sys.stdout.fileno()).st_blksize = 1024 * 1024
    except (AttributeError, OSError):
        raise unittest.SkipTest("Can't change stream buffer size")

    # Test with a large buffer size
    old_

# Generated at 2022-06-18 11:13:10.473877
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    print("  - Generate a list of all possible combinations of the digits 0, 1, 2, 3, 4, 5, 6, 7, 8, 9")
    print("  - This should take a while")
    start_time = time.time()
    for i in product(range(10), repeat=10):
        pass
    print("  - Time taken: {}".format(time.time() - start_time))
    print("  - Memory usage: {}".format(format_sizeof(sys.getsizeof(i))))

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:13:17.350583
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    import time
    import sys
    import os
    import random
    import string

    def test_product_generator(iterables):
        """
        Test product generator.
        """
        for i in product(*iterables):
            yield i

    def test_product_generator_with_tqdm(iterables):
        """
        Test product generator with tqdm.
        """
        for i in product(*iterables, tqdm_class=tqdm_auto):
            yield i


# Generated at 2022-06-18 11:13:24.886817
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_number_short
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_number_full
    from ..utils import format_timespan_short
    from ..utils import format_size_short
    from ..utils import format_speed_

# Generated at 2022-06-18 11:13:34.854825
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    t = time.time()
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    print("Test 1:", format_interval(time.time() - t))

    # Test 2
    t = time.time()
    for i in itertools.product(range(1000), range(1000), range(1000)):
        pass
    print("Test 2:", format_interval(time.time() - t))

    # Test 3
    t = time.time()
   

# Generated at 2022-06-18 11:13:41.694414
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..tqdm import trange

    # Test 1
    for i in product(range(3), repeat=3):
        pass

    # Test 2
    for i in product(range(3), repeat=3, tqdm_class=trange):
        pass

    # Test 3
    for i in product(range(3), repeat=3, tqdm_class=trange,
                     miniters=1, mininterval=0.1):
        pass

    # Test 4

# Generated at 2022-06-18 11:13:51.760956
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string
    import os

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=2):
        print(i)

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)

    # Test 3
    print("Test 3:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)

    # Test 4

# Generated at 2022-06-18 11:14:00.972148
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from random import random
    from itertools import product
    from ..auto import tqdm

    # Test 1
    for i in tqdm.product(range(10), range(10), range(10),
                          tqdm_class=tqdm.tqdm,
                          desc="test1", leave=False):
        sleep(0.01)
    # Test 2

# Generated at 2022-06-18 11:14:08.176034
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_timesofar
    from .utils import format_transferrate
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_naturalsize
    from .utils import format_number
    from .utils import format_percentage
    from .utils import format_length
    from .utils import format_size
    from .utils import format_time
    from .utils import format_time_short
    from .utils import format_time_long
    from .utils import format_time_full
    from .utils import format_time_precise

# Generated at 2022-06-18 11:14:16.998565
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timesofar_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_of_dict
    from ..utils import format_dict_of_dict_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short

# Generated at 2022-06-18 11:14:31.976160
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Create a random list of lists
    random.seed(0)
    N = 100
    M = 10
    L = [random.sample(string.ascii_letters, random.randint(1, M))
         for _ in range(N)]

    # Compute the size of the output
    total = 1
    for i in L:
        total *= len(i)

    # Compute the output
    start_t = time.time()
    out = list(product(*L))
    end_t = time.time()

    # Print the results
    print("\n\n")
   

# Generated at 2022-06-18 11:14:39.447863
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test with no iterables
    assert list(product()) == [()]

    # Test with one iterable
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    # Test with two iterables
    assert list(product([1, 2, 3], [4, 5])) == [(1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]

    # Test with three iterables

# Generated at 2022-06-18 11:14:41.729896
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range, pretest, posttest, closing

    @with_setup(pretest, posttest)
    def unit_test():
        for i in product(_range(10), _range(10)):
            pass
        closing()

    unit_test()

# Generated at 2022-06-18 11:14:49.774985
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=True,
                     file=sys.stdout):
        pass
    print("\nElapsed:", format_interval(time.time() - t))
    print("Memory usage:", format_sizeof(t.mem_usage))
    print("Peak memory usage:", format_sizeof(t.peak_mem_usage))

    # Test 2

# Generated at 2022-06-18 11:14:58.935999
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        pass

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:15:06.434907
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:15:13.374585
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="Test 1"):
        pass
    print("Time: %s" % format_interval(time.time() - t0))
    print("Memory: %s" % format_sizeof(sys.getsizeof(i)))
    print("")

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:15:21.592946
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)
        tc.assertEqual(tc.sp, 100)
        tc.assertEqual(tc.n, 100)
        tc.assertEqual(tc.last_print_t, tc.n)

        tc.clear()
        for i in product(range(10), range(10), tqdm_class=tc.tqdm, total=100):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:15:32.298725
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_size

# Generated at 2022-06-18 11:15:39.392997
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=2):
        print(i)
        time.sleep(0.01)

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.01)

    # Test 3
    print("\nTest 3:")

# Generated at 2022-06-18 11:15:59.126579
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """Test for function product"""
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_class):
        """Test for function product"""
        list(product(*iterables, tqdm_class=tqdm_class))

    def test_product_list_comp(iterables, tqdm_class=tqdm_class):
        """Test for function product"""
        [i for i in product(*iterables, tqdm_class=tqdm_class)]


# Generated at 2022-06-18 11:16:04.648467
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_1():
        """
        Unit test for function product
        """
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=tqdm_auto):
            pass

    def test_product_2():
        """
        Unit test for function product
        """
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=tqdm_auto,
                         leave=True):
            pass

    def test_product_3():
        """
        Unit test for function product
        """

# Generated at 2022-06-18 11:16:10.366472
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from .trange import trange
    from .tqdm import tqdm

    # Test 1
    with tqdm(product(range(10), range(10)),
              desc="test1", unit="it", leave=False) as t:
        for i in t:
            sleep(0.01)

    # Test 2
    with tqdm(product(range(10), range(10)),
              desc="test2", unit="it", leave=True) as t:
        for i in t:
            sleep(0.01)

    # Test 3

# Generated at 2022-06-18 11:16:19.996596
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("\nTest 1")
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        pass

    # Test 2
    print("\nTest 2")
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        time.sleep(0.01)

    # Test 3
    print("\nTest 3")
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        time.sleep(0.01)

# Generated at 2022-06-18 11:16:29.221476
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    print("\t-> %s" % format_interval(time.time() - t))

    # Test 2
    print("Test 2:")
    t = time.time()

# Generated at 2022-06-18 11:16:36.312057
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=1)
    for i in product(range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=1)
    for i in product(range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=1)
    for i in product(range(10), range(10), tqdm_class=t.__class__):
        pass

# Generated at 2022-06-18 11:16:45.878915
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm import tqdm
    from .utils import FormatCustomText

    # Test basic function
    assert list(product(range(3), range(4))) == list(itertools.product(range(3), range(4)))

    # Test tqdm_class
    assert list(product(range(3), range(4), tqdm_class=tqdm)) == list(itertools.product(range(3), range(4)))

    # Test total
    assert list(product(range(3), range(4), tqdm_class=tqdm)) == list(itertools.product(range(3), range(4)))

    # Test leave

# Generated at 2022-06-18 11:16:54.266177
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        """
        Wrap tqdm to test its format
        """
        def __init__(self, iterable, **kwargs):
            super(FormatWrap, self).__init__(iterable, **kwargs)
            self.dynamic_messages['dynamic_ncols'] = self.dynamic_ncols

        def dynamic_ncols(self, i):
            """
            Return the number of columns of the current bar
            """
            return len(self.format_meter(i, self.n))


# Generated at 2022-06-18 11:17:00.990823
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter

    # Test for total
    with closing(tqdm_auto(total=0)) as pbar:
        for _ in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
            pbar.update()
    assert pbar.n == 27

    # Test for closing
    with closing_iter(product(range(3), range(3), range(3), tqdm_class=tqdm_auto)) as (pbar, it):
        for _ in it:
            pbar.update()
    assert pbar.n == 27

# Generated at 2022-06-18 11:17:09.466611
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_num
    from ..utils import format_size
    from ..utils import format_timespan
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_number
    from ..utils import format_length
    from ..utils import format_interval
    from ..utils import format_interval_short
    from ..utils import format_interval_long
    from ..utils import format_interval_full
    from ..utils import format_interval_fuller
    from ..utils import format_interval_fullest

# Generated at 2022-06-18 11:17:37.506806
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a small number of elements
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test with a small number of elements"):
        pass

    # Test with a large number of elements
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="Test with a large number of elements"):
        pass

    # Test with a large number of elements and a large total

# Generated at 2022-06-18 11:17:46.672318
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval

    # Test 1
    t0 = time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time()
    print("Test 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))

    # Test 2
    t0 = time()
    for i in itertools.product(range(10), range(10), range(10), range(10)):
        pass
    t1 = time()
   

# Generated at 2022-06-18 11:17:56.126062
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_

# Generated at 2022-06-18 11:18:05.486342
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    # Test 1
    print("Test 1:")
    t = time()
    for i in product(range(10), range(10), range(10)):
        pass
    print("\tTime: {}".format(format_interval(time() - t)))

    # Test 2
    print("Test 2:")
    t = time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("\tTime: {}".format(format_interval(time() - t)))

    # Test 3
    print("Test 3:")
   

# Generated at 2022-06-18 11:18:14.390451
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_inner(tqdm_class, *iterables):
        """
        Unit test for function product
        """
        for _ in tqdm_class.product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_inner_nested(tqdm_class, *iterables):
        """
        Unit test for function product
        """
        for _ in tqdm_class.product(*iterables, tqdm_class=tqdm_class):
            for _ in tqdm_class.product(*iterables, tqdm_class=tqdm_class):
                pass

   

# Generated at 2022-06-18 11:18:18.314335
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:18:28.240642
# Unit test for function product
def test_product():
    from .tests import TestCase
    import numpy as np
    from numpy.testing import assert_array_equal

    class TestProduct(TestCase):
        def test_product(self):
            a = np.arange(10)
            b = np.arange(10)
            c = np.arange(10)
            d = np.arange(10)
            e = np.arange(10)
            f = np.arange(10)
            g = np.arange(10)
            h = np.arange(10)
            i = np.arange(10)
            j = np.arange(10)
            k = np.arange(10)
            l = np.arange(10)
            m = np.arange(10)
            n = np.arange(10)

# Generated at 2022-06-18 11:18:36.924625
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval

# Generated at 2022-06-18 11:18:45.731855
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(n, m):
        """
        Generator for test_product
        """
        for i in product(range(n), range(m)):
            yield i

    def test_product_generator_no_tqdm(n, m):
        """
        Generator for test_product
        """
        for i in itertools.product(range(n), range(m)):
            yield i

    n = 100
    m = 100
    t0 = time.time()
    for _ in test_product_generator(n, m):
        pass
    t1 = time.time()

# Generated at 2022-06-18 11:18:53.365238
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.total)

        for i in product(range(10), range(10), tqdm_class=tc.tqdm, total=100):
            pass
        tc.assertEqual(tc.sp, tc.total)

        for i in product(range(10), range(10), tqdm_class=tc.tqdm, total=None):
            pass
        tc.assertEqual(tc.sp, tc.total)