

# Generated at 2022-06-18 11:10:17.927205
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    print("Test with a list of lists")
    print("list_of_lists =", list_of_lists)
    print("list(product(list_of_lists)) =", list(product(list_of_lists)))
    print("list(itertools.product(list_of_lists)) =",
          list(itertools.product(list_of_lists)))

# Generated at 2022-06-18 11:10:27.627989
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    t1 = time.time()
    print("\t", format_interval(t1 - t0))

    # Test 2
    print("Test 2:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("\t", format_interval(t1 - t0))

# Generated at 2022-06-18 11:10:38.143889
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a list of lists
    t = time.time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, leave=False):
        pass
    print("product(range(10), range(10), range(10), range(10))")
    print("\tLap time: %s" % format_interval(time.time() - t))
    print("\tPeak memory: %s" % format_sizeof(sys.maxsize))

    # Test with a list of generators
    t = time.time()

# Generated at 2022-06-18 11:10:46.327004
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.testing import assert_equal
    assert_equal(list(product(range(3), range(3))),
                 list(itertools.product(range(3), range(3))))
    assert_equal(list(product(range(3), range(3), tqdm_class=None)),
                 list(itertools.product(range(3), range(3))))
    assert_equal(list(product(range(3), range(3), tqdm_class=tqdm_auto)),
                 list(itertools.product(range(3), range(3))))

# Generated at 2022-06-18 11:10:57.205239
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    for i in product(gen(), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

   

# Generated at 2022-06-18 11:11:06.945032
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=100)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=100)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=100)

# Generated at 2022-06-18 11:11:16.902302
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test 1
    print("\nTest 1:")
    print("  - Generate random list of lists")
    print("  - Compute product of lists")
    print("  - Print product size")
    print("  - Print product generation time")
    print("  - Print product generation speed")
    print("  - Print product generation speedup")
    print("  - Print product generation speedup (relative to itertools)")
    print("  - Print product generation speedup (relative to itertools)")
    print("  - Print product generation speedup (relative to itertools)")

# Generated at 2022-06-18 11:11:24.325257
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    print("  Elapsed:", format_interval(time.time() - t))
    print("  Memory:", format_sizeof(sys.getsizeof(i)))

    # Test 2
    print("Test 2:")
    t = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-18 11:11:34.928500
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    def _test(iterables, total):
        for i in product(*iterables):
            pass
        assert i is not None  # NOQA
        assert t.n == total  # NOQA

    t = tqdm_auto(leave=False)
    _test([range(10), range(10)], 100)
    _test([range(10), range(10), range(10)], 1000)
    _test([range(10), range(10), range(10), range(10)], 10000)
    _test([range(10), range(10), range(10), range(10), range(10)], 100000)

# Generated at 2022-06-18 11:11:40.560080
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test 1:
    # -------
    # Test with a simple example
    # Expected result:
    #     - The result should be the same as the one from itertools.product
    #     - The total number of iterations should be equal to the total
    #       number of elements in the product
    #     - The total time should be equal to the time taken by itertools.product
    #     - The memory footprint should be equal to the memory footprint of
    #       itertools.product
    #     - The number of iterations should be equal to the

# Generated at 2022-06-18 11:11:51.604281
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_1():
        """
        Test for function product
        """
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="test_product_1"):
            pass

    def test_product_2():
        """
        Test for function product
        """
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto,
                         desc="test_product_2",
                         leave=True):
            pass


# Generated at 2022-06-18 11:12:01.234215
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    import random
    import string

    # Test 1:
    # Check that the total number of iterations is correct
    # and that the time taken is proportional to the number of iterations
    # (with a constant overhead)
    # Also check that the total number of iterations is correct
    # when the total is not specified
    for total in [None, 10**4]:
        for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
            for n in [1, 2, 3]:
                for i in range(n):
                    iterable = [range(10**i)] * n

# Generated at 2022-06-18 11:12:10.545171
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:12:19.289875
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t0 = time.time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1: "):
        pass
    dt = time.time() - t0
    print("dt = {0}".format(format_interval(dt)))
    print("")

    # Test 2
    print("Test 2:")
    t0 = time.time()

# Generated at 2022-06-18 11:12:27.616478
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short
    from ..utils import format_

# Generated at 2022-06-18 11:12:36.720447
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test with a list of lists
    for n in [1, 2, 3, 4, 5]:
        for m in [1, 2, 3, 4, 5]:
            for k in [1, 2, 3, 4, 5]:
                for l in [1, 2, 3, 4, 5]:
                    for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
                        t = time.time()
                        list_of_lists = [list(range(n)), list(range(m)),
                                         list(range(k)), list(range(l))]

# Generated at 2022-06-18 11:12:44.333410
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=10)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=10)

# Generated at 2022-06-18 11:12:53.070867
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(range(100), range(100), range(100)):
        pass
    print("  Elapsed:", format_interval(time.time() - t))
    print("  Memory:", format_sizeof(sys.getsizeof(i)))
    print("  i:", i)

    # Test 2
    print("Test 2:")
    t = time.time()
    for i in product(range(100), range(100), range(100), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-18 11:13:03.441245
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import random
    import time
    import numpy as np

    # Test with random iterables
    for i in range(10):
        iterables = [np.random.randint(0, 100, size=random.randint(1, 10))
                     for _ in range(random.randint(1, 10))]
        assert list(product(*iterables)) == list(itertools.product(*iterables))

    # Test with random iterables and random tqdm_class
    for i in range(10):
        iterables = [np.random.randint(0, 100, size=random.randint(1, 10))
                     for _ in range(random.randint(1, 10))]
        tqdm

# Generated at 2022-06-18 11:13:12.021325
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof

    def test_product_inner(iterables, total, tqdm_class):
        """Test for function product"""
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass
        assert i == (total - 1,) * len(iterables)

    for tqdm_class in [tqdm_auto, None]:
        test_product_inner([range(10), range(10)], 100, tqdm_class)
        test_product_inner([range(10), range(10), range(10)], 1000, tqdm_class)
        test_product_inner([range(10), range(10), range(10), range(10)],
                           10000, tqdm_class)
        test_product

# Generated at 2022-06-18 11:13:19.870093
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(tqdm_class):
        """
        Unit test for function product
        """
        # Test generator
        for i in product(range(1000), range(1000),
                         tqdm_class=tqdm_class):
            pass

    def test_product_iterator(tqdm_class):
        """
        Unit test for function product
        """
        # Test iterator
        for i in product(range(1000), range(1000),
                         tqdm_class=tqdm_class,
                         leave=False):
            pass


# Generated at 2022-06-18 11:13:29.795758
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import random
    import sys
    import time

    # Test 1
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2"):
        pass

    # Test 3
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 3",
                     mininterval=0.5):
        pass

    # Test 4

# Generated at 2022-06-18 11:13:31.352351
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..tests import test_product
    test_product(product)

# Generated at 2022-06-18 11:13:39.076882
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.n, 100)
        tc.pbar.update(0)
        tc.assertEqual(tc.n, 100)
        tc.pbar.update(10)
        tc.assertEqual(tc.n, 110)
        tc.pbar.update(10)
        tc.assertEqual(tc.n, 120)
        tc.pbar.update(70)
        tc.assertEqual(tc.n, 190)
        tc.pbar.update(10)
        tc.assertE

# Generated at 2022-06-18 11:13:46.706910
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from itertools import product
    from random import random
    from math import sqrt

    # Test for total

# Generated at 2022-06-18 11:13:56.844724
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    from ..utils import format_sizeof
    import sys

    # Test with a generator
    assert_equal(list(product(range(2), repeat=2)),
                 [(0, 0), (0, 1), (1, 0), (1, 1)])

    # Test with a list
    assert_equal(list(product(range(2), repeat=2)),
                 [(0, 0), (0, 1), (1, 0), (1, 1)])

    # Test with a tuple
    assert_equal(list(product(range(2), repeat=2)),
                 [(0, 0), (0, 1), (1, 0), (1, 1)])

    # Test with a set

# Generated at 2022-06-18 11:14:04.981430
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_gen(iterables):
        """
        Generator for test_product
        """
        for i in itertools.product(*iterables):
            yield i

    def test_product_tqdm(iterables, **tqdm_kwargs):
        """
        Generator for test_product
        """
        for i in product(*iterables, **tqdm_kwargs):
            yield i

    def test_product_tqdm_class(iterables, tqdm_class):
        """
        Generator for test_product
        """

# Generated at 2022-06-18 11:14:10.893488
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import numpy as np

    # Test 1
    a = np.arange(10)
    b = np.arange(10)
    c = np.arange(10)
    d = np.arange(10)
    e = np.arange(10)
    f = np.arange(10)
    g = np.arange(10)
    h = np.arange(10)
    i = np.arange(10)
    j = np.arange(10)
    k = np.arange(10)
    l = np.arange(10)
    m = np.arange(10)
    n = np.arange(10)
    o = np.ar

# Generated at 2022-06-18 11:14:19.171576
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from ..utils import format_interval
    from time import time
    from ..auto import tqdm

    # Test 1
    print("Test 1")
    t = time()
    for _ in tqdm(product(range(10), repeat=3), total=1000):
        pass
    print("-> %s" % format_interval(time() - t))
    print()

    # Test 2
    print("Test 2")
    t = time()
    for _ in tqdm(product(range(10), repeat=3), total=1000,
                  mininterval=0.01):
        pass
    print("-> %s" % format_interval(time() - t))
    print()



# Generated at 2022-06-18 11:14:24.546932
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     unit_scale=True):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:14:35.550098
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_number
    from .utils import format_time
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_number
    from .utils import format_time
    from .utils import format_meter
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_number
    from .utils import format_time
    from .utils import format_meter


# Generated at 2022-06-18 11:14:46.208635
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     leave=False):
        pass
    print("")

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2",
                     leave=True):
        pass
    print("")

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:14:51.777482
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal
    from .utils import closing, FakeTqdmFile

    with closing(FakeTqdmFile()) as f:
        for _ in product(range(3), range(3), range(3), tqdm_class=tqdm_auto,
                         file=f):
            pass
        assert_array_equal(f.nums, np.arange(27))

# Generated at 2022-06-18 11:15:00.252311
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product

    # Test 1
    t = time()
    for _ in product(range(10), range(10), range(10)):
        pass
    t = time() - t
    print("product(range(10), range(10), range(10)) took %s" %
          format_interval(t))

    # Test 2
    t = time()
    for _ in itertools_product(range(10), range(10), range(10)):
        pass
    t = time() - t

# Generated at 2022-06-18 11:15:07.440564
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from .utils import FormatMixin

    class TqdmType(FormatMixin):
        def __init__(self, *args, **kwargs):
            self.format_dict = kwargs.pop("format_dict", {})
            self.format_dict.setdefault("unit", "it")
            self.format_dict.setdefault("unit_scale", True)
            self.format_dict.setdefault("leave", True)
            self.format_dict.setdefault("ascii", True)
            self.format_dict.setdefault("dynamic_ncols", True)
            self.format_dict.setdefault("miniters", 1)

# Generated at 2022-06-18 11:15:13.913886
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test for product
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="1", leave=False):
        pass
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="2", leave=True):
        pass

    # Test for product with total
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="3", leave=False):
        pass

# Generated at 2022-06-18 11:15:22.426943
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_timespan

    # Test 1
    print("\nTest 1:")
    print("  - Test with no iterables")
    try:
        for i in product():
            print(i)
    except TypeError:
        print("  - TypeError: product expected at least 1 arguments, got 0")

    # Test 2
    print("\nTest 2:")
    print("  - Test with one iterable")
    for i in product([1, 2, 3]):
        print(i)

    # Test 3
    print("\nTest 3:")

# Generated at 2022-06-18 11:15:32.954710
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with no iterable
    for _ in product():
        pass

    # Test with one iterable
    for _ in product(range(10)):
        pass

    # Test with two iterables
    for _ in product(range(10), range(10)):
        pass

    # Test with three iterables
    for _ in product(range(10), range(10), range(10)):
        pass

    # Test with four iterables
    for _ in product(range(10), range(10), range(10), range(10)):
        pass

    # Test with five iterables

# Generated at 2022-06-18 11:15:39.870108
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_generator(iterables):
        """
        Generator for testing product
        """
        for i in product(*iterables):
            yield i

    def test_product_list(iterables):
        """
        List for testing product
        """
        return list(product(*iterables))

    def test_product_list_itertools(iterables):
        """
        List for testing product
        """
        return list(itertools.product(*iterables))

    def test_product_generator_itertools(iterables):
        """
        Generator for testing product
        """
        for i in itertools.product(*iterables):
            yield i


# Generated at 2022-06-18 11:15:49.139356
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_json
    from ..utils import format_dict_pretty_json
    from ..utils import format_dict_yaml

# Generated at 2022-06-18 11:15:59.909399
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..tests import closing, closing_iter
    from ..tests._utils import _random_data

    def test_product_with_tqdm(tqdm_class):
        """
        Unit test for function product with tqdm class
        """
        with closing(tqdm_class(total=100)) as t:
            for _ in product(range(10), range(10), tqdm_class=tqdm_class):
                t.update()

    def test_product_with_tqdm_kwargs(tqdm_class):
        """
        Unit test for function product with tqdm_kwargs
        """

# Generated at 2022-06-18 11:16:06.757385
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    for i in product(gen(), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a list and a generator
    for i in product(range(10), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a generator and a list
    for i in product(gen(), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with

# Generated at 2022-06-18 11:16:15.753685
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import tempfile
    import shutil
    import random
    import string

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file
    fd, tmpfile2 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file
    fd, tmpfile3 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file
    fd

# Generated at 2022-06-18 11:16:25.430273
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .utils import FormatMixin
    import sys

    class TestProduct(FormatMixin):
        def setup(self):
            self.tqdm_cls = tqdm_auto
            self.ncols = 80
            self.iterable = range(10)
            self.iterables = (range(10), range(10))
            self.iterables_nested = (range(10), (range(10), range(10)))
            self.iterables_nested_nested = (range(10), (range(10), (range(10), range(10))))
            self.iterables_nested_nested_nested = (range(10), (range(10), (range(10), (range(10), range(10)))))
            self.iterables_nested_n

# Generated at 2022-06-18 11:16:33.331093
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format

# Generated at 2022-06-18 11:16:38.880071
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with tqdm_class=tqdm.auto.tqdm
    # (default)
    with tqdm_auto(unit='B', unit_scale=True, miniters=1,
                   desc='test_product') as t:
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=tqdm_auto):
            pass
    assert t.n == 1000000000
    assert t.total == 1000000000
    assert t.last_print_n == t.n
    assert t.dynamic_ncols
    assert t.smoothing == 0

    #

# Generated at 2022-06-18 11:16:47.787967
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:16:56.347122
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:17:03.868644
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    # Test 1
    t = time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    print("Test 1:", format_interval(time() - t))

    # Test 2
    t = time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, leave=False):
        pass
    print("Test 2:", format_interval(time() - t))

    # Test 3
    t = time()

# Generated at 2022-06-18 11:17:14.078121
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint
    from itertools import product as itertools_product
    from itertools import chain as itertools_chain

    # Test 1
    t = time()
    p = product(range(10), range(10), range(10), range(10), range(10),
                range(10), range(10), range(10), range(10), range(10),
                tqdm_class=tqdm_auto)
    p = list(p)
    t = time() - t
    assert len(p) == 10 ** 10

# Generated at 2022-06-18 11:17:24.716884
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:17:31.963879
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .._tqdm_test_utils import FakeTqdmFile, StringIO

    with StringIO() as our_file:
        with tqdm_auto(file=our_file) as t:
            for _ in product(range(10), range(10), range(10),
                             tqdm_class=tqdm_auto,
                             file=FakeTqdmFile(our_file)):
                pass
        assert t.total == 1000
        assert t.n == 1000
        assert t.last_print_n == 1000
        assert t.last_print_refresh_time is not None
        assert t.last_print_n == t.total
        assert t.smoothing == 1.0

# Generated at 2022-06-18 11:17:36.713393
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")

# Generated at 2022-06-18 11:17:45.688673
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=False):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:17:55.140962
# Unit test for function product
def test_product():
    """
    Test for `tqdm.itertools.product`.
    """
    from .tests_tqdm import with_setup, _range
    from ..std import next, zip_longest

    @with_setup(pretest=lambda: None, posttest=lambda: None)
    def inner_test():
        """
        Test for `tqdm.itertools.product`.
        """
        for n in _range(1, 4):
            for m in _range(1, 4):
                for i in _range(1, 4):
                    for j in _range(1, 4):
                        a = list(product(range(n), range(m),
                                         range(i), range(j)))

# Generated at 2022-06-18 11:18:04.414291
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test for total
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test for total
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     total=100):
        pass

    # Test for total
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     total=None):
        pass

    # Test for total

# Generated at 2022-06-18 11:18:13.357822
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof

    def test_product_iterator(iterables, **tqdm_kwargs):
        """
        Test product iterator.
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
                t.update()

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Test product generator.
        """

# Generated at 2022-06-18 11:18:20.621793
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a simple product
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with a simple product
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a simple product
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     mininterval=0.1):
        pass

    # Test with a simple product

# Generated at 2022-06-18 11:18:30.580492
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import sys

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Unit test for function product.
        """
        for _ in product(*iterables, **tqdm_kwargs):
            pass

    def test_product_list(iterables, **tqdm_kwargs):
        """
        Unit test for function product.
        """
        list(product(*iterables, **tqdm_kwargs))

    def test_product_set(iterables, **tqdm_kwargs):
        """
        Unit test for function product.
        """

# Generated at 2022-06-18 11:18:39.254622
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from sys import version_info
    from itertools import product
    from collections import Counter
    from ..utils import _range

    # Test basic functionality
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-18 11:18:53.299962
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_size(n, m):
        """
        Test product size
        """
        # Test product size
        assert sum(1 for _ in product(range(n), range(m))) == n * m
        # Test product size with tqdm
        assert sum(1 for _ in product(range(n), range(m),
                                      tqdm_class=tqdm_auto)) == n * m

    def test_product_speed(n, m):
        """
        Test product speed
        """
        # Test product speed
        t = time.time()
        for _ in product(range(n), range(m)):
            pass
        t1 = time.time() - t

# Generated at 2022-06-18 11:19:00.713888
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..tqdm import tqdm

    # Test 1:
    # Check that the total is correctly computed
    # and that the iterator is not consumed

# Generated at 2022-06-18 11:19:09.332535
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print('Test 1')
    t = time.time()
    for i in product(range(10), range(10), range(10), range(10)):
        pass
    print('  Elapsed time: %s' % format_interval(time.time() - t))
    print('  Memory usage: %s' % format_sizeof(sys.getsizeof(i)))
    print('  i = %s' % str(i))

    # Test 2
    print('Test 2')
    t = time.time()

# Generated at 2022-06-18 11:19:14.948424
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(iterables, **tqdm_kwargs):
        """
        Generator for unit test of function product
        """
        for _ in product(*iterables, **tqdm_kwargs):
            yield _

    # Test with a small number of elements

# Generated at 2022-06-18 11:19:22.709305
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = time.time()
    for i in product(range(100), range(100), range(100)):
        pass
    print("Test 1:", format_interval(time.time() - t))

    # Test 2
    t = time.time()
    for i in product(range(100), range(100), range(100), tqdm_class=tqdm_auto):
        pass
    print("Test 2:", format_interval(time.time() - t))

    # Test 3
    t = time.time()

# Generated at 2022-06-18 11:19:26.290716
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_generator():
        for i in product(range(1000), range(1000), range(1000),
                         tqdm_class=tqdm_auto,
                         desc="test_product",
                         leave=False):
            yield i

    t0 = time.time()
    for i in test_generator():
        pass
    t1 = time.time()
    print("\nTotal time: %s" % format_interval(t1 - t0))
    print("Total size: %s" % format_sizeof(sys.getsizeof(i)))

# Generated at 2022-06-18 11:19:32.640549
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys

    # Test 1
    print("Test 1:")
    for i in product(range(3), range(3), range(3)):
        print(i)
    print()

    # Test 2
    print("Test 2:")
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        print(i)
    print()

    # Test 3
    print("Test 3:")
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto,
                     leave=False):
        print(i)
    print()

    # Test 4
    print("Test 4:")
   

# Generated at 2022-06-18 11:19:42.442832
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import gc

    # Test for memory leaks
    gc.collect()
    mem_start = os.statvfs(os.getcwd()).f_bfree * os.statvfs(os.getcwd()).f_bsize
    t0 = time.time()
    for _ in product(range(100), range(100), range(100), range(100),
                     tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    gc.collect()
    mem_end = os.statvfs(os.getcwd()).f_bfree * os.statvfs(os.getcwd()).f_bsize
   

# Generated at 2022-06-18 11:19:49.104768
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_number
    from ..utils import format_percentage
    from ..utils import format_time
    from ..utils import format_length
    from ..utils import format_number_human
    from ..utils import format_length_human
    from ..utils import format_size_human
    from ..utils import format_interval_human
    from ..utils import format_interval_short
    from ..utils import format_interval_long


# Generated at 2022-06-18 11:19:57.840184
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format