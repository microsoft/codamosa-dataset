

# Generated at 2022-06-18 11:10:13.033296
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin

    class TestProduct(FormatMixin):
        def __init__(self, *args, **kwargs):
            super(TestProduct, self).__init__(*args, **kwargs)
            self.n = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.n < 3:
                self.n += 1
                return self.format_sizeof(self.n)
            else:
                raise StopIteration

    for i in product(TestProduct(), TestProduct(), TestProduct()):
        assert i == (format_sizeof(1), format_sizeof(1), format_sizeof(1))
        break

# Generated at 2022-06-18 11:10:22.836235
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test with a very large product
    t0 = time.time()
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="Testing product"):
        pass
    dt = time.time() - t0
    print("\nproduct(range(100), range(100), range(100))")
    print("-> dt = %s" % format_interval(dt))
    print("-> %s" % format_sizeof(sys.getsizeof(i)))

# Generated at 2022-06-18 11:10:26.193300
# Unit test for function product
def test_product():
    from .tests import TestCase, closing

    with closing(TestCase()) as t:
        for i in product(range(10), range(10), tqdm_class=t.cls):
            pass
        t.assertEqual(t.sp, 100)

# Generated at 2022-06-18 11:10:37.178343
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_inter

# Generated at 2022-06-18 11:10:43.992289
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time

    # Test 1
    with tqdm_auto(total=None) as t:
        for i in product(range(10), repeat=3):
            t.update()
    assert t.n == 1000

    # Test 2
    with tqdm_auto(total=None) as t:
        for i in product(range(10), repeat=3):
            t.update()
            time.sleep(0.01)
    assert t.n == 1000

    # Test 3
    with tqdm_auto(total=None) as t:
        for i in product(range(10), repeat=3):
            t.update()
            time.sleep(0.01)


# Generated at 2022-06-18 11:10:55.073487
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:11:04.250401
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from . import trange
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_timesofar
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_timesofar
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_timesofar
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_timesofar
    from .utils import format_sizeof
    from .utils import format_inter

# Generated at 2022-06-18 11:11:14.741086
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_number_short


# Generated at 2022-06-18 11:11:22.992904
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    import string

    # Test 1: simple product
    for i in product(range(10), repeat=2):
        pass

    # Test 2: simple product with total
    for i in product(range(10), repeat=2, total=100):
        pass

    # Test 3: simple product with total and unit
    for i in product(range(10), repeat=2, total=100, unit="it"):
        pass

    # Test 4: simple product with total, unit and desc
    for i in product(range(10), repeat=2, total=100, unit="it", desc="test"):
        pass

    # Test 5

# Generated at 2022-06-18 11:11:32.913316
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import numpy as np
    import pandas as pd
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_meter
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_meter
    from ..utils import format_sizeof

# Generated at 2022-06-18 11:11:41.833423
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1:",
                     leave=False):
        pass
    print()

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 2:",
                     leave=True):
        pass
    print()

    # Test 3
    print("Test 3:")

# Generated at 2022-06-18 11:11:50.480720
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval

# Generated at 2022-06-18 11:12:00.244360
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import time
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
   

# Generated at 2022-06-18 11:12:08.723713
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_html_fmt
    from ..utils import format_dict_json
    from ..utils import format_dict_

# Generated at 2022-06-18 11:12:18.207605
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percentage
    from ..utils import format_time
    from ..utils import format_sizeof
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_interval
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
   

# Generated at 2022-06-18 11:12:26.328339
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format

# Generated at 2022-06-18 11:12:35.659977
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys

    # Test 1
    for i in product(range(1000), range(1000), range(1000)):
        pass

    # Test 2
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto):
        pass

    # Test 3
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    for i in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="Test 4",
                     unit="it"):
        pass

# Generated at 2022-06-18 11:12:43.549625
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt

# Generated at 2022-06-18 11:12:52.314716
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    from ..utils import format_interval

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    # Test with a numpy array
    arr = np.arange(10)

    # Test with a list
    lst = list(range(10))

    # Test with a tuple
    tup = tuple(range(10))

    # Test with a set
    st = set(range(10))

    # Test with a dict
    dct = dict(zip(range(10), range(10)))

    # Test with a string
    str_ = "abcdefghij"

    # Test with a bytes

# Generated at 2022-06-18 11:13:02.403609
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    for i in product(gen(), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a list of lists
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with a list of lists

# Generated at 2022-06-18 11:13:14.839722
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    print("Test 1:", end=' ')
    t0 = time.time()

# Generated at 2022-06-18 11:13:22.053748
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    # Test 1
    t = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    print("Test 1:", format_sizeof(time.time() - t))

    # Test 2
    t = time.time()
    for i in itertools.product(range(10), range(10), range(10)):
        pass
    print("Test 2:", format_sizeof(time.time() - t))

    # Test 3
    t = time.time()

# Generated at 2022-06-18 11:13:31.758793
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    # Test with tqdm_class=tqdm.auto.tqdm
    t = time.time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass
    print("product(range(10), range(10), range(10), range(10)) took %.3f s" %
          (time.time() - t))

    # Test with tqdm_class=tqdm.tqdm
    t = time.time()

# Generated at 2022-06-18 11:13:39.434175
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=False):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:13:44.982666
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_percentage
    from ..utils import format_length
    from ..utils import format_number
    from ..utils import format_length
    from ..utils import format_interval
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_speed
    from ..utils import format_

# Generated at 2022-06-18 11:13:55.134558
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_percentage
    from ..utils import format_length
    from ..utils import format_length_of
    from ..utils import format_length_of_iterable
    from ..utils import format_length_of_generator
    from ..utils import format_length_of_file
    from ..utils import format_length_of_file

# Generated at 2022-06-18 11:14:03.467935
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import stderr
    from random import random

    # Test 1: simple
    for i in product(range(10), range(10)):
        pass

    # Test 2: manual
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test 3: manual

# Generated at 2022-06-18 11:14:11.650268
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing
    from .utils import FakeTqdmFile

    class FormatWrap(FormatWrapBase):
        """
        Format wrapper for testing
        """
        @staticmethod
        def format_meter(n, total, elapsed, ncols=None, prefix='',
                         ascii=None, unit='it', unit_scale=False, rate=None,
                         bar_format=None):
            """
            Format the progress bar
            """
            return "test"


# Generated at 2022-06-18 11:14:19.694840
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string
    import itertools
    import math

    def product_test(iterables, total, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        kwargs.setdefault("total", total)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield

# Generated at 2022-06-18 11:14:24.910413
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    # Test with a large number of elements
    n = randint(10, 20)
    m = randint(10, 20)
    t = time()
    for _ in product(range(n), range(m)):
        pass
    print("product(range({}), range({}))".format(n, m))
    print("\t-> elapsed wall time: {}".format(format_interval(time() - t)))
    print("\t-> estimated memory usage: {}".format(format_sizeof(n * m)))

    # Test with a generator
    n = randint(10, 20)

# Generated at 2022-06-18 11:14:40.041968
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test basic functionality
    assert list(product(range(3), repeat=2)) == list(itertools.product(range(3), repeat=2))

    # Test total
    assert list(product(range(3), repeat=2, tqdm_class=tqdm_auto)) == list(itertools.product(range(3), repeat=2))

    # Test total
    assert list(product(range(3), repeat=2, tqdm_class=tqdm_auto, total=9)) == list(itertools.product(range(3), repeat=2))

    # Test total

# Generated at 2022-06-18 11:14:48.434279
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("\nTest 1:")
    print("  Testing product() with tqdm_class=tqdm_auto")
    print("  Generating list of tuples from product(range(10), repeat=3)")
    print("  This should take about 1 second")
    start_time = time.time()
    result = list(product(range(10), repeat=3))
    elapsed_time = time.time() - start_time
    print("  Elapsed time: %s" % format_interval(elapsed_time))

# Generated at 2022-06-18 11:14:57.996980
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a large number of elements
    n = int(1e6)
    a = np.arange(n)
    b = np.arange(n)
    c = np.arange(n)
    d = np.arange(n)
    e = np.arange(n)
    f = np.arange(n)
    g = np.arange(n)
    h = np.arange(n)
    i = np.arange(n)
    j = np.arange(n)
    k = np.arange(n)
    l = np.arange(n)

# Generated at 2022-06-18 11:15:03.943095
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time

    t0 = time()
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Product of 4 ranges"):
        pass
    t1 = time()
    print("\nElapsed time: %s" % format_interval(t1 - t0))
    print("Total size  : %s" % format_sizeof(10 ** 4))

# Generated at 2022-06-18 11:15:10.105659
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percent
    from ..utils import format_time
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timesofar_fmt
    from ..utils import format_size_fmt
    from ..utils import format_

# Generated at 2022-06-18 11:15:17.654817
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=1)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 2
    t = tqdm_auto(total=1)
    for i in product(range(10), range(10), range(10), tqdm_class=t.__class__):
        pass
    t.close()

    # Test 3
    t = tqdm_auto(total=1)

# Generated at 2022-06-18 11:15:27.326029
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a large product
    print("Test with a large product")
    t = time.time()
    for _ in product(range(1000), range(1000), range(1000),
                     tqdm_class=tqdm_auto,
                     desc="Testing large product",
                     unit="it",
                     unit_scale=True,
                     unit_divisor=1024,
                     leave=False):
        pass
    print("Elapsed:", time.time() - t)

    # Test with a large product
    print("Test with a large product (no unit)")
    t = time.time()

# Generated at 2022-06-18 11:15:36.577071
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test for product

# Generated at 2022-06-18 11:15:47.148463
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:15:56.214606
# Unit test for function product
def test_product():
    from .tests import TestCase, closing
    from .utils import format_sizeof

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.total, 100)
        tc.assertEqual(tc.smoothed, 100)
        tc.assertEqual(tc.last_print_t, 100)
        tc.assertEqual(tc.n, 100)
        tc.assertEqual(tc.dynamic_ncols, True)
        tc.assertEqual(tc.leave, True)
        tc.assertEqual(tc.desc, None)
        tc.assertEqual(tc.ascii, False)

# Generated at 2022-06-18 11:16:15.588814
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_size
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_percentage
    from ..utils import format_time
    from ..utils import format_number
    from ..utils import format_length
    from ..utils import format_timespan
    from ..utils import format_interval
    from ..utils import format_speed
    from ..utils import format_sizeof
    from ..utils import format

# Generated at 2022-06-18 11:16:25.198745
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os
    import random
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import closing
    from .utils import FakeTqdmFile
    from .utils import StringIO

    # Test normal operation
    with closing(StringIO()) as our_file:
        with tqdm_auto(
                file=our_file,
                miniters=1,
                mininterval=0.1,
                maxinterval=0.1,
                leave=True) as t:
            for i in product(range(1000), range(1000), range(1000)):
                t.update()
                time.sleep(0.0001)
        assert t.n == 1000000000

# Generated at 2022-06-18 11:16:33.113187
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a small number of elements
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test product with a small number of elements"):
        pass

    # Test with a large number of elements
    for i in product(range(100), range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="Test product with a large number of elements"):
        pass

    # Test with a huge number of elements

# Generated at 2022-06-18 11:16:38.761625
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    print("  - Iterating over a product of two lists of length 10")
    print("  - Expecting a total of 100 iterations")
    print("  - Expecting a total of 1.0 KiB of memory usage")
    print("  - Expecting a total of 1.0 KiB of memory usage per iteration")
    print("  - Expecting a total of 1.0 KiB of memory usage per iteration")
    print("  - Expecting a total of 1.0 KiB of memory usage per iteration")
    print("  - Expecting a total of 1.0 KiB of memory usage per iteration")

# Generated at 2022-06-18 11:16:47.716360
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.testing import assert_equal
    from ..utils import format_sizeof
    import sys
    import os

    # Test with no iterable
    assert_equal(list(product()), [()])

    # Test with one iterable
    assert_equal(list(product([1, 2, 3])),
                 [(1,), (2,), (3,)])

    # Test with two iterables
    assert_equal(list(product([1, 2, 3], [4, 5, 6])),
                 [(1, 4), (1, 5), (1, 6),
                  (2, 4), (2, 5), (2, 6),
                  (3, 4), (3, 5), (3, 6)])

    # Test with three iterables
    assert_equal

# Generated at 2022-06-18 11:16:56.301671
# Unit test for function product
def test_product():
    """Test for function product"""
    from .tests_tqdm import with_setup, pretest, posttest, _range
    from .tests_tqdm import closing, UnicodeIO

    @with_setup(pretest, posttest)
    def test():
        """Test for function product"""
        # Test simple case
        with closing(UnicodeIO()) as our_file:
            for _ in product(_range(10), _range(10), tqdm_class=tqdm_auto,
                             file=our_file):
                pass
            assert our_file.getvalue().count('\r') == 10

        # Test simple case

# Generated at 2022-06-18 11:17:03.807540
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with total
    for i in product(range(1000), range(1000), tqdm_class=tqdm_auto,
                     desc="Test with total"):
        pass

    # Test without total
    for i in product(range(1000), range(1000), tqdm_class=tqdm_auto,
                     desc="Test without total", total=None):
        pass

    # Test with total=0
    for i in product(range(1000), range(1000), tqdm_class=tqdm_auto,
                     desc="Test with total=0", total=0):
        pass

    # Test with total=1

# Generated at 2022-06-18 11:17:10.347821
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase

    with TestCase() as test:
        for i in product(range(10), range(10), range(10),
                         tqdm_class=test.fake_tqdm):
            pass
        assert test.fake_tqdm.n == 1000
        assert test.fake_tqdm.total == 1000

# Generated at 2022-06-18 11:17:17.991783
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_timespan
    from ..utils import format_meter
    from ..utils import format_speed
    from ..utils import format_size
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_len
    from ..utils import format_naturalsize
    from ..utils import format_percentage
    from ..utils import format_count
    from ..utils import format_rate
    from ..utils import format_interval_average
    from ..utils import format_timespan_average
    from ..utils import format_meter_average
    from ..utils import format_speed_average
    from ..utils import format_

# Generated at 2022-06-18 11:17:26.402362
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1:
    # -------
    # Test with a simple iterable
    # Expected result:
    #  - total: 6
    #  - n: 6
    #  - n/total: 1
    #  - rate: 1/s
    #  - time: 0s
    #  - memory: 0B
    #  - unit: it
    #  - desc: 'it'
    #  - ascii: False
    #  - dynamic_ncols: False
    #  - smoothing: 0
    #  - bar_format: '{l_bar}{bar}| {n_fmt}/{total_fmt

# Generated at 2022-06-18 11:17:48.652043
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np
    import random

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=3):
        pass

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        pass

    # Test 3
    print("Test 3:")
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        pass

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:17:58.569168
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = tqdm_auto(total=1)
    t.set_description("Test 1")
    for i in product(range(10), range(10), range(10)):
        t.update()
    t.close()

    # Test 2
    t = tqdm_auto(total=1)
    t.set_description("Test 2")
    for i in product(range(10), range(10), range(10)):
        t.update()
    t.close()

    # Test 3
    t = tqdm_auto(total=1)
    t.set_description("Test 3")

# Generated at 2022-06-18 11:18:07.949455
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_sizeof
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_line
    from ..utils import format_over
    from ..utils import format_ascii
    from ..utils import format_len
    from ..utils import format_dict
    from ..utils import format_size
    from ..utils import format_bool
    from ..utils import format_cols
    from ..utils import format_col
    from ..utils import format_

# Generated at 2022-06-18 11:18:15.737601
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import random
    import time
    import gc
    from ..utils import format_interval

    # Test with a large number of elements
    # (to test the `total` parameter)
    n = 100000
    a = range(n)
    b = range(n)
    c = range(n)
    d = range(n)
    e = range(n)
    f = range(n)
    g = range(n)
    h = range(n)
    i = range(n)
    j = range(n)
    k = range(n)
    l = range(n)
    m = range(n)
    n = range(n)
    o = range(n)


# Generated at 2022-06-18 11:18:23.860285
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from itertools import product

    # Create iterables
    iterables = [range(10), range(10), range(10)]

    # Create iterator
    iterator = product(*iterables)

    # Get size of iterator
    size = getsizeof(iterator)

    # Get size of iterator
    size_tqdm = getsizeof(product(*iterables, tqdm_class=tqdm_auto))

    # Get size of iterator
    size_tqdm_no_monitor = getsizeof(product(*iterables, tqdm_class=tqdm_auto,
                                             disable=True))

    # Get size of

# Generated at 2022-06-18 11:18:29.284941
# Unit test for function product
def test_product():
    from .tests import TestCase

    class TestProduct(TestCase):
        def test_product(self):
            with tqdm_auto(total=10) as t:
                for _ in product(range(10), range(10), tqdm_class=tqdm_auto):
                    pass
            self.assertEqual(t.n, 100)

    TestProduct().test_product()

# Generated at 2022-06-18 11:18:37.757789
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_num
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_num_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_num_short
    from ..utils import format_sizeof_short_

# Generated at 2022-06-18 11:18:46.497264
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_of_dict
    from ..utils import format_dict_of_dict_fmt
    from ..utils import format_sizeof_short

# Generated at 2022-06-18 11:18:54.926256
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.1)

    # Test 2
    print("\nTest 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.1)

    # Test 3
    print("\nTest 3:")

# Generated at 2022-06-18 11:19:02.894682
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    # Test with tqdm_class=tqdm.auto.tqdm
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with tqdm_class=tqdm.tqdm
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

    # Test with tqdm_class=tqdm.tqdm_notebook
    try:
        from tqdm import tqdm_notebook
    except ImportError:
        pass

# Generated at 2022-06-18 11:19:38.174937
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1:
    # Test that product works with a generator
    # (which is not the case for itertools.product)
    def gen():
        for i in range(10):
            yield i

    assert list(product(gen(), gen())) == list(itertools.product(range(10), range(10)))

    # Test 2:
    # Test that product works with a generator
    # (which is not the case for itertools.product)
    def gen():
        for i in range(10):
            yield i

    assert list(product(gen(), gen())) == list(itertools.product(range(10), range(10)))



# Generated at 2022-06-18 11:19:46.978791
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test with a small number of elements
    for i in product(range(10), range(10), range(10)):
        pass

    # Test with a large number of elements
    for i in product(range(1000), range(1000), range(1000)):
        pass

    # Test with a large number of elements and a large total
    for i in product(range(1000), range(1000), range(1000),
                     total=1e9):
        pass

    # Test with a large number of elements and a small total
    for i in product(range(1000), range(1000), range(1000),
                     total=1e3):
        pass

    # Test with

# Generated at 2022-06-18 11:19:56.353125
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_sizeof_short
    from ..utils import format_interval_short
    from ..utils import format_meter_short
    from ..utils import format_timespan_short
    from ..utils import format_sizeof_short_fmt
    from ..utils import format_interval_short_fmt
    from ..utils import format_meter_short

# Generated at 2022-06-18 11:20:06.097331
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    t1 = time.time()
    print("Test 1:")
    print("  Elapsed time: %s" % format_interval(t1 - t0))
    print("  Memory usage: %s" % format_sizeof(sys.getsizeof(i)))
    print("  i =", i)

    # Test 2
    t0 = time.time()