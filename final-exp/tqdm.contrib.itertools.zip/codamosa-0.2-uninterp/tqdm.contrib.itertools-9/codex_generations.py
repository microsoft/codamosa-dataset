

# Generated at 2022-06-18 11:10:22.836308
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_speed
    from ..utils import format_eta
    from ..utils import format_naturalsize
    from ..utils import format_number
    from ..utils import format_percentage
    from ..utils import format_description
    from ..utils import format_as_text
    from ..utils import format_as_html
    from ..utils import format_as_json
    from ..utils import format_as_dict
    from ..utils import format_as_csv
    from ..utils import format_as_dict_csv

# Generated at 2022-06-18 11:10:33.973764
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random
    import string

    # Test with a small list
    l = list(range(10))
    for i in product(l):
        assert i in itertools.product(l)

    # Test with a large list
    l = list(range(1000))
    for i in product(l):
        assert i in itertools.product(l)

    # Test with a small string
    s = string.ascii_letters
    for i in product(s):
        assert i in itertools.product(s)

    # Test with a large string

# Generated at 2022-06-18 11:10:42.022117
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    def test_product_with_tqdm(iterables, tqdm_class=tqdm_auto):
        """
        Equivalent of `itertools.product` with `tqdm` progress bar.
        """
        with tqdm_class(total=len(iterables),
                        unit="it",
                        unit_scale=True,
                        unit_divisor=1024) as t:
            for i in iterables:
                yield i
                t.update()

    def test_product_without_tqdm(iterables):
        """
        Equivalent of `itertools.product` without `tqdm` progress bar.
        """

# Generated at 2022-06-18 11:10:53.509412
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=2):
        print(i)
    print()

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
    print()

    # Test 3
    print("Test 3:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
    print()

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:11:02.809381
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time
    import random
    import sys

    def test_product_generator(iterables, tqdm_class=tqdm_auto):
        """
        Test the product generator
        """
        for i in product(*iterables, tqdm_class=tqdm_class):
            pass

    def test_product_list(iterables, tqdm_class=tqdm_class):
        """
        Test the product list
        """
        for i in list(product(*iterables, tqdm_class=tqdm_class)):
            pass


# Generated at 2022-06-18 11:11:13.221629
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys

    def test_product_helper(tqdm_class):
        # Test product
        for i in tqdm_class.product(range(10), range(10), range(10)):
            pass
        for i in tqdm_class.product(range(10), range(10), range(10),
                                    tqdm_class=tqdm_class):
            pass

        # Test product with total
        for i in tqdm_class.product(range(10), range(10), range(10),
                                    total=1000):
            pass

# Generated at 2022-06-18 11:11:21.926521
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t0 = time.time()
    for i in product(range(10), range(10), range(10)):
        pass
    t1 = time.time()
    print("Test 1:", format_interval(t1 - t0),
          format_sizeof(sys.getsizeof(i)))

    # Test 2
    t0 = time.time()
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass
    t1 = time.time()

# Generated at 2022-06-18 11:11:31.321706
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_val
    from ..utils import format_dict_val_fmt
    from ..utils import format_dict_attr
    from ..utils import format_dict_attr_fmt


# Generated at 2022-06-18 11:11:39.645503
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random

    # Test 1
    for i in product(range(10), range(10), range(10)):
        sleep(random() * 0.01)

    # Test 2
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        sleep(random() * 0.01)

    # Test 3
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     desc='Test 3', leave=True, file=open('/dev/null', 'w')):
        sleep(random() * 0.01)



# Generated at 2022-06-18 11:11:48.439154
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random
    import numpy as np

    # Test 1:
    # Check that the output is the same as itertools.product
    # and that the total is correctly computed
    for i in range(10):
        iterables = [range(random.randint(1, 10)) for _ in range(random.randint(1, 10))]
        assert list(product(*iterables)) == list(itertools.product(*iterables))

    # Test 2:
    # Check that the total is correctly computed
    for i in range(10):
        iterables = [range(random.randint(1, 10)) for _ in range(random.randint(1, 10))]
        total = 1

# Generated at 2022-06-18 11:12:02.038591
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    def test_product_gen(iterables, tqdm_class=tqdm_auto, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1

# Generated at 2022-06-18 11:12:11.493125
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, closing_iter
    from .utils import FormatCustomText
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_speed
    from .utils import format_sizeof_fmt
    from .utils import format_interval_fmt
    from .utils import format_meter_fmt
    from .utils import format_number_fmt
    from .utils import format_timespan_fmt
    from .utils import format_speed_fmt
    from .utils import format_dict
    from .utils import format_dict_fmt
    from .utils import format_sizeof_fmt_

# Generated at 2022-06-18 11:12:20.171560
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    # Test 1
    t = time.time()
    for _ in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="Test 1",
                     file=sys.stdout):
        pass
    print("Test 1:", format_interval(time.time() - t))

    # Test 2
    t = time.time()
    for _ in itertools.product(range(10), range(10), range(10)):
        pass
    print("Test 2:", format_interval(time.time() - t))

    # Test 3
    t = time.time()


# Generated at 2022-06-18 11:12:28.715313
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_timespan
    from ..utils import format_speed
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_number_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_speed_fmt

    from ..utils import format_custom_text
    from ..utils import format_custom_text_fmt

    from ..utils import format_custom_text_pos
    from ..utils import format_custom_text_pos

# Generated at 2022-06-18 11:12:37.612031
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="1st loop", leave=False):
        time.sleep(0.01)
    print("\n")

    # Test 2
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="2nd loop", leave=True):
        time.sleep(0.01)
    print("\n")

    # Test 3

# Generated at 2022-06-18 11:12:44.979402
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FormatWrapBase
    from .utils import StringIO
    from .utils import closing

    class FormatWrap(FormatWrapBase):
        PREFIX = "prefix"
        SUFFIX = "suffix"
        UNIT = "unit"
        UNIT_SCALE = True
        UNIT_DIVISOR = 1000
        MINITERMS_TRUE = "mininterms_true"
        MINITERMS_FALSE = "mininterms_false"
        AUTO_UNIT = True
        AUTO_UNIT_SCALE = True
        AUTO_UNIT_DIVISOR = 1000
        AUTO_MINITERMS = True


# Generated at 2022-06-18 11:12:53.506673
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    import time

    # Test 1
    print("\nTest 1:")
    print("  Testing product(range(10), range(10))")
    print("  Expected result: 100")
    print("  Actual result:   %d" % len(list(product(range(10), range(10)))))

    # Test 2
    print("\nTest 2:")
    print("  Testing product(range(10), range(10), range(10))")
    print("  Expected result: 1000")
    print("  Actual result:   %d" % len(list(product(range(10), range(10), range(10)))))

    # Test 3

# Generated at 2022-06-18 11:13:03.908431
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ._utils import _range
    from ._tqdm_test_cls import TqdmDefaultWriteBytesIO
    from ._tqdm_test_cls import TqdmDefaultWriteUnicodeIO
    from ._tqdm_test_cls import TqdmDefaultWriteStringIO
    from ._tqdm_test_cls import TqdmDefaultWriteBytes
    from ._tqdm_test_cls import TqdmDefaultWriteUnicode
    from ._tqdm_test_cls import TqdmDefaultWriteString

    # Test total

# Generated at 2022-06-18 11:13:12.592431
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i

    for i in product(gen(), gen(), tqdm_class=tqdm_auto):
        pass

    # Test with a list
    for i in product([1, 2, 3], [4, 5, 6], tqdm_class=tqdm_auto):
        pass

    # Test with a tuple
    for i in product((1, 2, 3), (4, 5, 6), tqdm_class=tqdm_auto):
        pass

    # Test with a set

# Generated at 2022-06-18 11:13:18.973917
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time

    # Test 1
    t0 = time()
    for _ in product(range(10), repeat=2):
        pass
    dt = time() - t0
    print("Test 1:", format_interval(dt))

    # Test 2
    t0 = time()
    for _ in itertools.product(range(10), repeat=2):
        pass
    dt = time() - t0
    print("Test 2:", format_interval(dt))

    # Test 3
    t0 = time()

# Generated at 2022-06-18 11:13:31.549339
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import gc

    # Test with a small number of elements
    for n in range(1, 10):
        for m in range(1, 10):
            t = time.time()
            for _ in product(range(n), range(m)):
                pass
            t = time.time() - t
            print("product(range({}), range({})) in {} ({}/s)".format(
                n, m, format_interval(t), format_sizeof(1 / t)))

    # Test with a large number of elements
    n = 100
    m = 100
    t = time.time()

# Generated at 2022-06-18 11:13:39.272091
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test with a generator
    def gen():
        for i in range(10):
            yield i
    assert list(product(gen())) == list(itertools.product(gen()))

    # Test with a list
    assert list(product([1, 2, 3])) == list(itertools.product([1, 2, 3]))

    # Test with a tuple
    assert list(product((1, 2, 3))) == list(itertools.product((1, 2, 3)))

    # Test with a set
    assert list(product({1, 2, 3})) == list(itertools.product({1, 2, 3}))

    # Test with a dict

# Generated at 2022-06-18 11:13:44.879837
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from sys import getsizeof
    from itertools import product
    from random import random
    from math import sqrt

    # Test basic functionality
    assert list(product([1, 2, 3], [4, 5, 6])) == \
        [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]

    # Test with tqdm

# Generated at 2022-06-18 11:13:55.063076
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("\nTest 1:")
    print("  - Generate all possible combinations of a, b, c, d")
    print("  - Print each combination")
    print("  - Print total number of combinations")
    print("  - Print total time taken")
    print("  - Print total memory used")
    print("  - Print total memory used per combination")
    start_time = time.time()
    total_memory = 0

# Generated at 2022-06-18 11:14:03.431999
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    # Test 1
    t0 = time()
    for i in product(range(10), range(10), range(10), range(10)):
        pass
    t1 = time()
    print("Test 1:", format_interval(t1 - t0))

    # Test 2
    t0 = time()
    for i in itertools.product(range(10), range(10), range(10), range(10)):
        pass
    t1 = time()
    print("Test 2:", format_interval(t1 - t0))

    # Test 3
    t0 = time

# Generated at 2022-06-18 11:14:09.776141
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test with tqdm_class=tqdm
    tqdm_class = tqdm_auto
    for i in product(range(10), range(10), tqdm_class=tqdm_class):
        pass

    # Test with tqdm_class=tqdm_notebook
    try:
        from tqdm import tqdm_notebook
        tqdm_class = tqdm_notebook
    except ImportError:
        pass
    else:
        for i in product(range(10), range(10), tqdm_class=tqdm_class):
            pass

    # Test with tqdm_class=tqdm

# Generated at 2022-06-18 11:14:18.322873
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    import random

    # Test with a list of lists
    l = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    for i in product(l):
        assert len(i) == len(l)
    # Test with a list of generators
    g = (range(10), range(10), range(10))
    for i in product(g):
        assert len(i) == len(g)
    # Test with a list of generators
    g = (range(10), range(10), range(10))
    for i in product(g):
        assert len(i) == len(g)
    # Test with a list of generators

# Generated at 2022-06-18 11:14:26.216432
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    # Test 1
    print("\nTest 1:")
    print("  - itertools.product(range(10), range(10))")
    print("  - tqdm(itertools.product(range(10), range(10)))")
    print("  - tqdm.product(range(10), range(10))")
    print("  - tqdm.product(range(10), range(10), tqdm_class=tqdm.tqdm_gui)")

# Generated at 2022-06-18 11:14:34.677376
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_html
    from ..utils import format_dict_json
    from ..utils import format_dict_csv
    from ..utils import format_dict_latex

# Generated at 2022-06-18 11:14:41.236102
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from ..utils import format_sizeof

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    list_of_lists_product = list(product(list_of_lists))

# Generated at 2022-06-18 11:14:49.903498
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
   

# Generated at 2022-06-18 11:14:59.002207
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval

# Generated at 2022-06-18 11:15:06.469800
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_line
    from ..utils import format_over
    from ..utils import format_ascii
    from ..utils import format_len
    from ..utils import format_size
    from ..utils import format_cols
    from ..utils import format_dim
    from ..utils import format_dim_size
    from ..utils import format_dim_cols
    from ..utils import format_dim_over

# Generated at 2022-06-18 11:15:13.408049
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..utils import format_interval

    def test_product_inner(tqdm_class, iterables, **tqdm_kwargs):
        """
        Unit test for function product.
        """
        kwargs = tqdm_kwargs.copy()
        kwargs.setdefault("tqdm_class", tqdm_class)
        kwargs.setdefault("leave", True)
        kwargs.setdefault("smoothing", 0)
        kwargs.setdefault("mininterval", 0)
        kwargs.setdefault("maxinterval", 0)
        kwargs.setdefault("miniters", 1)

# Generated at 2022-06-18 11:15:21.629774
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    import sys

    # Test 1
    print("Test 1:")
    for i in product(range(10), repeat=2):
        print(i)
    print("")

    # Test 2
    print("Test 2:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto):
        print(i)
    print("")

    # Test 3
    print("Test 3:")
    for i in product(range(10), repeat=2, tqdm_class=tqdm_auto,
                     desc="Test 3"):
        print(i)
    print("")

    # Test 4
    print("Test 4:")

# Generated at 2022-06-18 11:15:32.298419
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys
    from ..utils import format_interval
    from time import time
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_inter

# Generated at 2022-06-18 11:15:39.366744
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof
    from sys import stdout
    from sys import version_info

    # Test with a large number of iterations
    n = 100000
    a = list(range(n))
    b = list(range(n))
    t0 = time()
    for i in product(a, b):
        pass
    t1 = time()
    print("product(a, b) took %s for %s iterations"
          % (format_interval(t1 - t0), n ** 2))

    # Test with a large number of iterations and a large number of items
    n = 100000

# Generated at 2022-06-18 11:15:49.012660
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test for function product
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="product(range(100), range(100), range(100))",
                     leave=False):
        pass

    # Test for function product
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="product(range(100), range(100), range(100))",
                     leave=True):
        pass

    # Test for function product

# Generated at 2022-06-18 11:15:57.895732
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time

    # Test 1
    print("Test 1:")
    for i in product(range(10), range(10), range(10)):
        print(i)
        time.sleep(0.01)

    # Test 2
    print("Test 2:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        print(i)
        time.sleep(0.01)

    # Test 3
    print("Test 3:")
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                     leave=True):
        print(i)

# Generated at 2022-06-18 11:16:05.169740
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with a list of lists
    list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    list_of_lists_product = list(itertools.product(*list_of_lists))
    list_of_lists_product_tqdm = list(product(*list_of_lists))
    assert list_of_lists_product == list_of_lists_product_tqdm

    # Test with a list of tuples

# Generated at 2022-06-18 11:16:23.211199
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time
    # Test with a single iterable
    for i in product(range(10)):
        pass
    # Test with multiple iterables
    for i in product(range(10), range(10), range(10)):
        pass
    # Test with a generator
    for i in product(range(10), range(10), range(10), range(10)):
        pass
    # Test with a generator
    for i in product(range(10), range(10), range(10), range(10), range(10)):
        pass
    # Test with a generator

# Generated at 2022-06-18 11:16:31.302758
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import numpy as np

    def test_product_range(n, m):
        """
        Test product(range(n), range(m))
        """
        t0 = time.time()
        for i in product(range(n), range(m)):
            pass
        t1 = time.time()
        for i in itertools.product(range(n), range(m)):
            pass
        t2 = time.time()
        print("product(range({}), range({}))".format(n, m))
        print("\t{}".format(format_interval(t1 - t0)))

# Generated at 2022-06-18 11:16:37.679303
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timespan
    from ..utils import format_number
    from ..utils import format_sizeof_fmt
    from ..utils import format_interval_fmt
    from ..utils import format_meter_fmt
    from ..utils import format_timespan_fmt
    from ..utils import format_number_fmt
    from ..utils import format_dict
    from ..utils import format_dict_fmt
    from ..utils import format_dict_val
    from ..utils import format_dict_val_fmt
    from ..utils import format_dict_attr
    from ..utils import format_dict_attr_fmt
    from ..utils import format_custom

# Generated at 2022-06-18 11:16:46.818507
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin


# Generated at 2022-06-18 11:16:55.288889
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Generator for testing product
        """
        for i in product(*iterables, **tqdm_kwargs):
            yield i

    def test_product_list(iterables, **tqdm_kwargs):
        """
        List for testing product
        """
        return list(product(*iterables, **tqdm_kwargs))

    def test_product_tqdm(iterables, **tqdm_kwargs):
        """
        Tqdm for testing product
        """
        return tqdm_kwargs.get("tqdm_class")

# Generated at 2022-06-18 11:17:03.016963
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test with a small list
    for i in product(range(3), range(3), range(3)):
        pass

    # Test with a large list
    for i in product(range(100), range(100), range(100)):
        pass

    # Test with a large list and a custom tqdm_class
    class tqdm_class(tqdm_auto):
        def __init__(self, *args, **kwargs):
            super(tqdm_class, self).__init__(*args, **kwargs)
            self.custom_attr = "custom_attr"


# Generated at 2022-06-18 11:17:13.247264
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import random
    import sys

    def test_product_generator(iterables, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1

# Generated at 2022-06-18 11:17:19.606597
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_timesofar

# Generated at 2022-06-18 11:17:28.048198
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import _range
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import os

    # Test 1
    print("Test 1:")
    t = time.time()
    for i in product(_range(100), _range(100), _range(100)):
        pass
    print("\tElapsed:", format_interval(time.time() - t))
    print("\tMemory:", format_sizeof(sys.getsizeof(i)))
    print("\t", i)

    # Test 2
    print("Test 2:")
    t = time.time()

# Generated at 2022-06-18 11:17:34.238740
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from random import random
    from itertools import product
    from numpy import product as npproduct

    # Test with no iterable
    assert list(product()) == [()]

    # Test with one iterable
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    # Test with two iterables
    assert list(product([1, 2, 3], [4, 5, 6])) == [(1, 4), (1, 5), (1, 6),
                                                    (2, 4), (2, 5), (2, 6),
                                                    (3, 4), (3, 5), (3, 6)]

    # Test with three iterables

# Generated at 2022-06-18 11:17:59.808956
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_times

# Generated at 2022-06-18 11:18:09.516794
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint
    from sys import getsizeof

    # Test for product
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product"):
        pass

    # Test for product with total
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     total=1000,
                     desc="product with total"):
        pass

    # Test for product with total

# Generated at 2022-06-18 11:18:16.506259
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import sys
    import time
    from ..tqdm import trange

    # Test 1
    for _ in trange(10, desc='Test 1'):
        time.sleep(0.01)

    # Test 2
    for _ in trange(10, desc='Test 2', leave=True):
        time.sleep(0.01)

    # Test 3
    for _ in trange(10, desc='Test 3', leave=True, mininterval=0.1):
        time.sleep(0.01)

    # Test 4
    for _ in trange(10, desc='Test 4', leave=True, mininterval=0.1,
                    miniters=1):
        time.sleep(0.01)

   

# Generated at 2022-06-18 11:18:25.998010
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    from .utils import FormatMixin

    class Test(FormatMixin):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.n = 0

        def __iter__(self):
            return self

        def __next__(self):
            self.n += 1
            if self.n > 10:
                raise StopIteration
            return self.n

        next = __next__  # Python 2


# Generated at 2022-06-18 11:18:30.465595
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    import time
    import sys
    import random

    # Test for product
    print("Testing product...")
    t0 = time.time()
    for i in product(range(100), range(100), range(100), range(100),
                     tqdm_class=tqdm_auto,
                     desc="product(range(100), range(100), range(100), range(100))"):
        pass
    t1 = time.time()
    print("product(range(100), range(100), range(100), range(100))")
    print("\tElapsed: %s" % format_interval(t1 - t0))

# Generated at 2022-06-18 11:18:39.182074
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from sys import getsizeof
    from random import randint

    # Test 1
    print("Test 1:")
    start_time = time()
    for i in product(range(10), range(10), range(10)):
        pass
    print("  Elapsed time: %s" % format_interval(time() - start_time))
    print("  Memory usage: %s" % format_sizeof(getsizeof(i)))

    # Test 2
    print("Test 2:")
    start_time = time()
    for i in product(range(10), range(10), range(10), tqdm_class=None):
        pass
    print

# Generated at 2022-06-18 11:18:47.587696
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    from ..utils import format_number
    from ..utils import format_time
    from ..utils import format_eta
    from ..utils import format_speed
    from ..utils import format_stats
    from ..utils import format_line
    from ..utils import format_over
    from ..utils import format_ascii
    from ..utils import format_len
    from ..utils import format_size
    from ..utils import format_cols
    from ..utils import format_dimensions
    from ..utils import format_naturalsize
    from ..utils import format_length
    from ..utils import format_width
    from ..utils import format

# Generated at 2022-06-18 11:18:55.927078
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import sys

    def test_product_generator(iterables):
        """
        Unit test for function product
        """
        for _ in product(*iterables):
            pass

    def test_product_list(iterables):
        """
        Unit test for function product
        """
        list(product(*iterables))

    def test_product_numpy(iterables):
        """
        Unit test for function product
        """
        np.array(list(product(*iterables)))

    def test_product_numpy_reshape(iterables):
        """
        Unit test for function product
        """

# Generated at 2022-06-18 11:19:04.026316
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    import numpy as np
    import time

    # Test 1
    print("Test 1:")
    print("  Generating all possible combinations of a, b, c, d, e, f, g, h")
    print("  with repetitions, and printing out the number of combinations")
    print("  and the memory usage of the list of combinations.")
    print("  This should be 8! = 40320 combinations.")
    print("  This should be 40320 * 8 bytes = 322640 bytes.")
    t0 = time.time()
    l = list(product("abcdefgh"))
    t1 = time.time()
    print("  Number of combinations: {}".format(len(l)))

# Generated at 2022-06-18 11:19:07.771556
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:19:43.570759
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import sleep
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval
    from ..utils import format_sizeof
    from ..utils import format_meter
    from ..utils import format_interval

# Generated at 2022-06-18 11:19:49.870186
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from time import time
    from random import randint

    # Test 1
    t0 = time()
    for i in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto,
                     desc="product(range(10), range(10), range(10), range(10)):"):
        pass
    dt = time() - t0
    print("\nTest 1:")
    print("  Elapsed time: %s" % format_interval(dt))
    print("  Memory usage: %s" % format_sizeof(0))

    # Test 2
    t0 = time()

# Generated at 2022-06-18 11:19:58.288794
# Unit test for function product
def test_product():
    """Test for function product"""
    from numpy.random import randint
    from numpy import prod
    from numpy.testing import assert_equal

    for n in range(10):
        for m in range(10):
            for k in range(10):
                a = randint(0, 10, n)
                b = randint(0, 10, m)
                c = randint(0, 10, k)
                assert_equal(list(product(a, b, c)),
                             list(itertools.product(a, b, c)))
                assert_equal(list(product(a, b, c, tqdm_class=None)),
                             list(itertools.product(a, b, c)))

# Generated at 2022-06-18 11:20:02.240196
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as tc:
        for i in product(range(10), range(10), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.sp, tc.si)

# Generated at 2022-06-18 11:20:11.226701
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .tests_tqdm import pretest_posttest_run

    class TestProduct(FormatMixin):
        def __init__(self, *args, **kwargs):
            super(TestProduct, self).__init__(*args, **kwargs)
            self.total = 0
            self.n = 0

        def __call__(self, *args, **kwargs):
            self.total += 1
            self.n += 1
            return self.format_sizeof(self.n)

    def test_product_func(iterables, tqdm_class, total, **kwargs):
        """
        Unit test for function product
        """
        t = TestProduct(**kwargs)