

# Generated at 2022-06-26 09:20:13.673726
# Unit test for function product
def test_product():
    # NOQA
    from numpy import array
    from ..utils import chunkify
    from ..utils import format_sizeof
    from .utils import _range

    def prod(*args):
        res = 1
        for x in args:
            res *= x
        return res

    for x in _range(1, 100):
        y = list(range(x))
        z = list(chunkify(x * 10, x))

        for x in [y * 100] + z:
            for y in [y * 100] + z:
                for z in [y * 100] + z:
                    # print(x, y, z)
                    res = product(x, y, z, tqdm_class=tqdm_auto,
                                  leave=True)
                    res_list = list(res)

# Generated at 2022-06-26 09:20:24.984148
# Unit test for function product
def test_product():
    assert(len(list(product([]))) == 0)
    assert(len(list(product([()]))) == 0)
    assert(len(list(product([()], [()]))) == 0)
    assert(list(product([()], [()], [()])) == [()])
    assert(len(list(product([()], [()], [()], [()]))) == 0)
    assert(list(product([()], [1])) == [((), 1)])
    assert(list(product([1], [()])) == [(1, ())])
    assert(list(product([1, 2], [3, 4, 5])) == [(1, 3), (1, 4), (1, 5), (2, 3), (2, 4), (2, 5)])

# Generated at 2022-06-26 09:20:35.439714
# Unit test for function product
def test_product():
    import itertools

    def ref_product(repeat, pool):
        return itertools.product(*([pool] * repeat))

    pool = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    repeat = 2

    expected = ref_product(repeat, pool)

    for prod in product(pool, repeat=repeat, tqdm_class=None):  # Should be equal to itertools.product
        assert prod == next(expected)

    # The length of the output is the same as the reference
    actual = list(product(pool, repeat=repeat, tqdm_class=None))
    assert len(actual) == len(list(ref_product(repeat, pool)))

    # Progress bar appears when total is not None

# Generated at 2022-06-26 09:20:47.134352
# Unit test for function product
def test_product():
    var_0 = {
        "arg_0": [],
        "arg_1": [],
        "arg_2": [],
        "arg_3": [],
        "arg_4": [],
        "arg_5": [],
        "arg_6": [],
        "arg_7": [],
        "arg_8": [],
        "arg_9": [],
    }

# Generated at 2022-06-26 09:20:51.004465
# Unit test for function product
def test_product():
    assert hasattr(tqdm_auto, 'nested')
    assert hasattr(tqdm_auto, 'tqdm')
    assert hasattr(itertools, 'product')

# Generated at 2022-06-26 09:21:00.867372
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    import pandas as pd
    list_t = [[1, 2, 3], [4, 5, 6]]
    np_t = np.array(list_t)
    pd_t = pd.DataFrame(np_t)
    #Test pandas dataframe
    assert any((product(pd_t.columns, pd_t.columns))), "product() is not working"
    #Test numpy array
    assert any((product(np_t, np_t))), "product() is not working"
    #Test list of lists
    assert any((product(list_t, list_t))), "product() is not working"
    #Test list of lists with total

# Generated at 2022-06-26 09:21:08.325309
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    try:
        tqdm.tqdm = lambda iterable=None, total=None, **kwargs: iterable
        assert list(product(range(1000))) == list(range(1000))
        assert list(product(range(1000), range(1000))) == [(i, j)
                                                           for i, j in zip(range(1000), range(1000))]
    finally:
        tqdm.tqdm = tqdm_func



# Generated at 2022-06-26 09:21:18.717987
# Unit test for function product
def test_product():
    list(product(range(3), range(4)))
    list(product(range(3), range(4), range(5)))
    list(product(range(3), repeat=2))

    from itertools import product
    from operator import mul
    from functools import reduce
    import numpy as np

    list(product(range(2) for _ in range(3)))
    a = np.array([[1, 2], [3, 4]])
    list(product(*a))
    list(product(*a, repeat=2))
    list(product(*a, repeat=3))
    d = dict(zip('abc', range(3)))
    list(product(*d.values()))
    list(product(*d.values(), repeat=2))

# Generated at 2022-06-26 09:21:19.910707
# Unit test for function product
def test_product():

    def test_case_0():
        var_0 = product()


# Generated at 2022-06-26 09:21:29.861819
# Unit test for function product
def test_product():
    from ..auto import tqdm
    from ..utils import _range

    for iterable in [_range(3), 'abc', [1, 2j], _range(10), range]:
        # for n in range(4):
        for n in [0, 1, 2, 3]:
            for tqdm_cls in [tqdm.tqdm, tqdm.tqdm_notebook, tqdm.trange]:
                assert list(product(*[iterable() for _ in range(n)],
                                    tqdm_class=tqdm_cls)) == \
                    list(itertools.product(*[iterable() for _ in range(n)]))

# Generated at 2022-06-26 09:21:41.238058
# Unit test for function product
def test_product():
    rv = product(*[])
    assert isinstance(rv, itertools.product)
    steps = list(product(range(10), range(12), range(5)))
    assert len(steps) == 600
    steps = list(product(range(10), range(12), range(5),
                         tqdm_class=tqdm_auto,
                         desc="test_product", leave=False))
    assert len(steps) == 600
    steps = list(product(range(10), range(12), range(5),
                         tqdm_class=tqdm_auto,
                         desc="test_product", ascii=True,
                         miniters=1))
    assert len(steps) == 600


# Generated at 2022-06-26 09:21:42.367317
# Unit test for function product
def test_product():
    assert callable(product)

# Generated at 2022-06-26 09:21:47.374171
# Unit test for function product
def test_product():
    # test for the for loop case
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto.tqdm):
        pass
    # test for the in one-line case
    list(product(range(3), range(3), range(3), tqdm_class=tqdm_auto.tqdm))


# Generated at 2022-06-26 09:21:58.830467
# Unit test for function product
def test_product():

    from collections import Counter

    s = {'a', 'b', 'c'}
    for n in [2, 3, 4]:
        for P in product(s, repeat=n):
            assert len(P) == n
            for X in P:
                assert X in s
        # Test with tqdm
        for P in product(s, repeat=n, tqdm_class=tqdm_auto):
            assert len(P) == n
            for X in P:
                assert X in s
        # Test without tqdm
        assert len(list(product(s, repeat=n, tqdm_class=None))) == len(s) ** n
        # Test empty
        assert len(list(product(s, repeat=0, tqdm_class=None))) == 1

# Generated at 2022-06-26 09:22:01.673450
# Unit test for function product
def test_product():
    assert len(list(itertools.product(['a', 'b'], repeat=3))) == \
        len(list(product(['a', 'b'], repeat=3)))


# Generated at 2022-06-26 09:22:07.703174
# Unit test for function product
def test_product():
    with tqdm_auto(disable=True) as t:
        for i in product(range(1_000)):
            pass
    assert t.n == 1_000
    with tqdm_auto(disable=True) as t:
        for i in product(range(200), range(9000)):
            pass
    assert t.n == 200 * 9000

# Generated at 2022-06-26 09:22:14.591139
# Unit test for function product
def test_product():
    # do not use assertTrue, assertFalse, assertIs, assertIsNot, assertIsNone,
    # assertIsNotNone, assertIn, assertIsInstance here.
    import doctest
    doctest.testmod()
    for i in range(2):
        for j in range(2):
            for k in range(2):
                assert (i, j, k) in product([0, 1], [0, 1], [0, 1])


if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:22:17.939673
# Unit test for function product
def test_product():
    assert (var_0)

if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:22:21.368333
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:22:22.586374
# Unit test for function product
def test_product():
    return

# Generated at 2022-06-26 09:22:39.573629
# Unit test for function product
def test_product():
    total = 0
    for i in product(range(10), repeat=3, tqdm_class=tqdm_auto):
        total += 1
        assert len(i) == 3
    assert total == 1000
    total = 0
    for i in product(range(10), range(10), repeat=2, tqdm_class=tqdm_auto):
        total += 1
        assert len(i) == (2 + 2)
    assert total == 100
    total = 0
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        total += 1
        assert len(i) == 3
    assert total == 1000
    total = 0

# Generated at 2022-06-26 09:22:49.035781
# Unit test for function product

# Generated at 2022-06-26 09:22:55.802572
# Unit test for function product
def test_product():
    from .testit import product

    def test_it(x):
        import itertools
        return list(product(x, (1, 2), tqdm_class=None)) == list(itertools.product(x, (1, 2)))

    assert test_it([1, 2])
    assert test_it([])
    assert test_it([1])
    print('All tests passed')

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:00.493297
# Unit test for function product
def test_product():
    pass


# Generated at 2022-06-26 09:23:01.333254
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:23:12.448706
# Unit test for function product

# Generated at 2022-06-26 09:23:12.848836
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:23:17.151326
# Unit test for function product
def test_product():
    print('Testing: ' + 'test_product')
    print('result: ' + str('test_product'))

if __name__ == '__main__':
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:23:19.077528
# Unit test for function product
def test_product():
    assert True

# Test case for test_case_0

# Generated at 2022-06-26 09:23:28.852354
# Unit test for function product

# Generated at 2022-06-26 09:23:36.445854
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:23:40.738068
# Unit test for function product
def test_product():
    str_0 = 'a'
    var_0 = product()
    str_1 = '1'
    var_1 = product(*[var_0, var_0])
    list_0 = module_1.list(*[var_0, var_0])
    var_2 = product(*list_0)
    var_3 = product(list_0)

# Generated at 2022-06-26 09:23:51.878184
# Unit test for function product
def test_product():
    import tqdm
    import numpy
    import tempfile
    from collections import Iterable

    def test_iterable(iterable):
        assert isinstance(iterable, Iterable)
        for i in iterable:
            pass


# Generated at 2022-06-26 09:23:57.225396
# Unit test for function product
def test_product():
    temp_0 = product()
    temp_1 = product()
    temp_2 = product()
    temp_3 = product()
    temp_4 = product()
    temp_5 = product()
    temp_6 = product()


# Generated at 2022-06-26 09:23:58.894203
# Unit test for function product
def test_product():
    pass


# Generated at 2022-06-26 09:24:11.535591
# Unit test for function product
def test_product():
    str_0 = '\r\r\r'
    str_1 = '= j\r'
    str_2 = '\x00\x00\x00\x00'
    var_0 = product()
    list_0 = [var_0]
    str_3 = 'AB'
    var_1 = product(*list_0)
    list_1 = module_1.list(*list_0)
    str_4 = 'c\t\t'
    str_5 = 'j\n\n'
    list_2 = [list_1, list_1, str_4]
    var_2 = product()
    list_3 = [list_0, list_1, list_2]
    str_6 = 'n\n\r'
    var_3 = product(*list_3)


# Generated at 2022-06-26 09:24:23.794606
# Unit test for function product
def test_product():
    assert product(range(3), range(3), range(3), range(3), range(3), range(3),
                  range(3), range(3), range(3), range(3), total=1000)
    assert product(range(3), range(3), total=10)
    assert product((1, 2, 3), (4, 5, 6))
    assert product([1, 2, 3], [4, 5, 6])
    assert product([1, 2, 3], [4, 5, 6], repeat=1)
    assert product([1, 2, 3], [4, 5, 6], repeat=2)
    assert product([1, 2, 3], [4, 5, 6], [7, 8])
    assert product([1, 2, 3], [4, 5, 6], [7, 8], repeat=1)
   

# Generated at 2022-06-26 09:24:34.833260
# Unit test for function product
def test_product():
    x = product(['a', 'b', 'c'], repeat=2)
    assert x == [('a', 'a'), ('a', 'b'), ('a', 'c'), ('b', 'a'), ('b', 'b'), ('b', 'c'), ('c', 'a'), ('c', 'b'), ('c', 'c')]
    x = product(['a', 'b'], repeat=3)
    assert x == [('a', 'a', 'a'), ('a', 'a', 'b'), ('a', 'b', 'a'), ('a', 'b', 'b'), ('b', 'a', 'a'), ('b', 'a', 'b'), ('b', 'b', 'a'), ('b', 'b', 'b')]

# Generated at 2022-06-26 09:24:45.874720
# Unit test for function product

# Generated at 2022-06-26 09:24:54.934749
# Unit test for function product
def test_product():
    # Test with default arguments
    try:
        # Test with named arguments
        products = [p for p in product(range(10), range(10), tqdm_class=tqdm_auto)]
        assert sum(products) == sum(itertools.product(range(10), range(10)))
    except:
        pass
    # Test with named arguments
    try:
        products = [p for p in product(range(10), range(10), tqdm_class=tqdm_auto)]
        assert sum(products) == sum(itertools.product(range(10), range(10)))
    except:
        pass


# Generated at 2022-06-26 09:25:10.654576
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:25:17.358440
# Unit test for function product
def test_product():
    # Test for when iterables is a list
    # Test for when iterables is an immutable sequence
    var_0 = product()
    # Test for when iterables is a set
    var_1 = product(var_0)
    # Test for when iterables is a mutable sequence
    var_2 = product(var_0, *var_1)
    # Test for when iterables is an iterator
    var_3 = product(var_0, *var_1, **var_2)
    # Test for when iterables is an iterator
    var_4 = product(var_0, *var_1, **var_2, tqdm_class=var_0)
    return var_4


# Generated at 2022-06-26 09:25:19.721632
# Unit test for function product
def test_product():
    try:
        assert isinstance(product(), object)
        assert 'itertools' in getattr(product(), '__module__')
        assert isinstance(product(module_1), object)
        assert 'itertools' in getattr(product(module_1), '__module__')
    except (TypeError, AttributeError):
        pass

# Generated at 2022-06-26 09:25:27.695009
# Unit test for function product
def test_product():
    import itertools as it

    from ..._tqdm import trange
    from ...utils import set_postfix

    for n, i in product(trange(1000), [1, 2, 3]):
        set_postfix(foo=(n, i))

    assert (sum(1 for _ in product(trange(5), 'abc')) ==
            sum(1 for _ in it.product(range(5), 'abc')))

    # Check same behavior with multiple iterables
    assert (sum(1 for _ in product(trange(2), trange(3), trange(4))) ==
            sum(1 for _ in it.product(range(2), range(3), range(4))))

    # Check total=None behavior

# Generated at 2022-06-26 09:25:36.641309
# Unit test for function product
def test_product():
    import itertools
    import random

    def randtuple(l, max_int=10**3):
        return tuple(random.randint(0, max_int) for _ in range(l))

    p = product(lambda: randtuple(10), lambda: randtuple(10), lambda: randtuple(10))
    p_ = itertools.product(*p)
    assert iter(p) is not p  # custom iterator
    assert iter(p) is p
    import numpy
    numpy.testing.assert_array_equal(list(p), list(p_))

    # TODO: test for lmap, starmap and repeat

# Generated at 2022-06-26 09:25:40.565625
# Unit test for function product
def test_product():
    assert callable(product) and callable(product(*[])), "function product could not be called"

if __name__ == '__main__':
    import sys
    pass

# Generated at 2022-06-26 09:25:41.931767
# Unit test for function product
def test_product():
    assert True == True


# Generated at 2022-06-26 09:25:49.220717
# Unit test for function product
def test_product():
    assert tqdm_auto.__name__ == 'tqdm_auto'
    assert tqdm_auto.__author__ == {'github.com/': ['casperdcl']}

# Generated at 2022-06-26 09:25:50.768392
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = product(*var_0)
    var_2 = product(var_0, var_1)
if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:26:00.114290
# Unit test for function product
def test_product():
    print("Test: product")
    print("Test: product")

# Generated at 2022-06-26 09:26:27.979148
# Unit test for function product
def test_product():
    try:
        product(test_case_0)
    except Exception as inst:
        logging.error(inst)


# Generated at 2022-06-26 09:26:39.474136
# Unit test for function product
def test_product():
    list_0 = [1, 2, 3]
    list_1 = [4, 5, 6]
    list_2 = [7, 8, 9]

# Generated at 2022-06-26 09:26:41.583423
# Unit test for function product
def test_product():
    assert 1 == 1
    assert 1 == 1


# Generated at 2022-06-26 09:26:44.355923
# Unit test for function product
def test_product():
    # pass
    assert False

# Main function call
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:26:46.906780
# Unit test for function product
def test_product():
    assert 0 == 0


# Test of function product


# Generated at 2022-06-26 09:26:51.506818
# Unit test for function product
def test_product():
    str_0 = None
    # No error
    try:
        product(str_0)
    except Exception as exc_0:
        print("Expected no error occurred")
        print("Unexpected error occurred: ", exc_0)


# Generated at 2022-06-26 09:26:58.945167
# Unit test for function product
def test_product():
    assert product() == product([], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [])
    assert product([1], [2], [3], repeat=5) == product([1, 2, 3] * 5)
    assert product() == product([], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [])
    assert product([1], [2], [3], repeat=5) == product([1, 2, 3] * 5)
    assert product([u'ab', u'cd'], u'xy') == product(u'ab', u'cd', u'xy')

# Generated at 2022-06-26 09:27:08.248582
# Unit test for function product
def test_product():
    str_0 = '\x7f1w!2d\x11'
    str_1 = '\\b\r\r7qy]'
    str_2 = ';@{gk\x1bHx$'
    dict_0 = dict()
    str_3 = 'T|f\x7f\n2\x1a'
    var_0 = product(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    str_4 = '\x0f\x1d\x1e\x0b\x0e'
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4

# Generated at 2022-06-26 09:27:17.550028
# Unit test for function product

# Generated at 2022-06-26 09:27:22.859880
# Unit test for function product
def test_product():
    import pytest

    with pytest.raises(TypeError):
        product()

if __name__ == '__main__':
    import pytest
    pytest.main(args=['.', '-v', '-s'])