

# Generated at 2022-06-26 09:20:06.128445
# Unit test for function product
def test_product():
    from ..tests.test_itertools import test_product
    test_product(product)

# Generated at 2022-06-26 09:20:09.315845
# Unit test for function product
def test_product():
	try:
		_ret_0 = product()
		_ret_1 = product(range(10000))
		_ret_2 = product(range(10000), range(10000))
	except Exception:
		pass

# Generated at 2022-06-26 09:20:20.885591
# Unit test for function product
def test_product():
    import random
    import string
    max_len=10
    l=random.randint(1, max_len)
    for dim in (1, 2):
        iterables = [string.ascii_letters for _ in range(dim)]
        iterables = [list(i) for i in iterables]
        iterables = [random.sample(i, random.randint(1, max_len))
                     for i in iterables]
        iterables = [sorted(i) for i in iterables]
        p_prod = list(product(*iterables))
        p_itertools = list(itertools.product(*iterables))
        assert p_prod == p_itertools

# Check that function product does not break itertools

# Generated at 2022-06-26 09:20:30.951275
# Unit test for function product
def test_product():
    from inspect import signature
    from inspect import getdoc
    from inspect import isfunction
    from inspect import isclass
    import numpy as np
    from .test_bar_descriptions import auto_test_descriptions
    from .test_bar_descriptions import manual_test_descriptions
    from .test_bar_positions import auto_test_positions
    from .test_bar_positions import manual_test_positions

    # Auto-test for function-wrapper signature and docstring
    assert isfunction(product)
    assert isclass(tqdm_auto)
    auto_test_descriptions(product())
    auto_test_positions(product())
    assert hasattr(product(), 'pos')
    assert hasattr(product(), 'pos')

# Generated at 2022-06-26 09:20:32.240422
# Unit test for function product
def test_product():
    assert True



# Generated at 2022-06-26 09:20:34.149686
# Unit test for function product
def test_product():
    pass


if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:20:46.090834
# Unit test for function product
def test_product():
  assert all(
      i == p
      for i, p in zip(
          itertools.product("ABC", "xy", repeat=1),
          product("ABC", "xy", repeat=1)))
  assert all(
      i == p
      for i, p in zip(
          itertools.product("ABC", "xy", repeat=3),
          product("ABC", "xy", repeat=3)))
  assert all(
      i == p
      for i, p in zip(
          itertools.product(["A", "B", "C"], "xy", repeat=1),
          product(["A", "B", "C"], "xy", repeat=1)))

# Generated at 2022-06-26 09:20:57.871502
# Unit test for function product
def test_product():
    try:
        from itertools import product as itertools_product
    except ImportError as e:
        pytest.skip(str(e))
    else:
        from tqdm._utils import _term_move_up
        from test_tqdm import closing

        assert list(product([2, 3], [3, 9])) == [
            (2, 3), (2, 9), (3, 3), (3, 9)]
        assert [i for i in product([2, 3], [3, 9])] == [
            (2, 3), (2, 9), (3, 3), (3, 9)]

# Generated at 2022-06-26 09:20:58.750712
# Unit test for function product
def test_product():
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:20:59.624004
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:21:14.078824
# Unit test for function product
def test_product():
    """
    Unit test for function ``product``.
    """
    from ._utils import closing, _range, format_sizeof
    # Unit tests
    with closing(tqdm_auto(disable=None)) as t:
        assert list(t.product(_range(5), _range(5))) == list(product(_range(5), _range(5)))
    with closing(tqdm_auto(disable=True)) as t:
        assert list(t.product(_range(5), _range(5))) == list(product(_range(5), _range(5)))
    with closing(tqdm_auto(disable=False)) as t:
        assert list(t.product(_range(5), _range(5))) == list(product(_range(5), _range(5)))
        t.close()



# Generated at 2022-06-26 09:21:24.613376
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    from math import factorial
    import sys

    for n in range(1, 10):
        nprod = 1
        for r in range(1, n + 1):
            nprod *= factorial(n) // factorial(r) // factorial(n - r)
        print("Verifying:", n, "in", format_sizeof(nprod * sys.getsizeof([0])), end='')
        assert [len(i) for i in product(range(n))] == [n] * n
        assert [len(i) for i in product(range(n), repeat=2)] == [n] * n * n

# Generated at 2022-06-26 09:21:35.543018
# Unit test for function product
def test_product():
    """
    Unit test for `product` function.
    """
    from ..utils import FormatCustomTextTest
    import io
    import sys

    # Test total count
    for tqdm_func in [tqdm_auto, FormatCustomTextTest]:
        stream = io.StringIO()
        with tqdm_func(
                product(
                    ['a', 'b'],
                    ['a', 'b'],
                    ['a', 'b'],
                    ['a', 'b'],
                    ['a', 'b'],
                ),
                file=sys.stderr,
                ) as gen:
            assert len(list(gen)) == 2 ** 5

    # Test total count
    for tqdm_func in [tqdm_auto, FormatCustomTextTest]:
        stream = io.StringIO()

# Generated at 2022-06-26 09:21:43.813359
# Unit test for function product
def test_product():
    import numpy as np

    len1 = 5
    len2 = 10
    assert(np.prod(list(map(len, (np.arange(len1), np.arange(len2))))) ==
           sum(1 for _ in product(np.arange(len1), np.arange(len2))) ==
           len1 * len2)


if __name__ == "__main__":
    from .test_itertools_common import _test_identity
    _test_identity(globals())
    del _test_identity

# Generated at 2022-06-26 09:21:48.163482
# Unit test for function product
def test_product():
    """
    Test function `product`.
    """
    from ..tqdm import trange
    from time import sleep
    a = b = "abcd"
    with trange(10) as t:
        for i in product(a, b, tqdm_class=type(t), total=len(a)*len(b)):
            sleep(0.25)

# Generated at 2022-06-26 09:21:57.018552
# Unit test for function product
def test_product():
    """Test `itertools.product` with tqdm."""
    from itertools import product as itertools_product

    result = list(itertools_product(range(10), repeat=3))
    assert result == list(product(range(10), repeat=3))
    assert len(result) == 1000

    result = list(itertools_product(range(100), range(100)))
    assert result == list(product(range(100), range(100)))
    assert len(result) == 10000


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:08.641374
# Unit test for function product
def test_product():
    """
    Tests the equivalence between tqdm.itertools.product() and
    itertools.product().
    """
    from .tests import testit
    from .tests import IPYTHON_KERNEL
    from sys import platform as _platform

    iterables = [(1, 2, 3), (4, 5, 6), (7, 8, 9)]
    if IPYTHON_KERNEL:
        import numpy as np
        iterables += [np.arange(10), np.arange(10) + 0.5]
    else:
        iterables += [list(range(10)), list(range(10)) + [None]]
    assert testit(product, *iterables)


# Generated at 2022-06-26 09:22:14.467870
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    q = product([1, 2, 3], [4, 5, 6], tqdm_class=tqdm_auto)
    prod = list(q)
    assert prod == [(1, 4), (1, 5), (1, 6),
                    (2, 4), (2, 5), (2, 6),
                    (3, 4), (3, 5), (3, 6)]

# Generated at 2022-06-26 09:22:26.411511
# Unit test for function product
def test_product():
    # initialize all test variables
    total_values = 0
    result = True
    fake_input = [[1, 2], [3, 4], [5, 6]]
    test_output = []
    # iterate over fake_input, calculate the len and append to test_output
    for i in fake_input:
        for x in i:
            test_output.append(x)
        total_values += len(i)
    # iterate over test_output, compare the value to the one returned by
    # product, if wrong at least one time then result = False
    for i in test_output:
        for x in product(*fake_input):
            if i != x:
                result = False
    assert result
    # test the len of product, it must be equal len(test_output)
    counter = 0

# Generated at 2022-06-26 09:22:38.382279
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    import locale
    import locale
    try:
        locale.setlocale(locale.LC_ALL, "en_US")
    except locale.Error:
        pass
    from .utils import format_sizeof

    if sys.version_info[0] < 3:  # py2
        from itertools import izip as zip

    for i in range(10):
        for j in range(10):
            for k in range(10):
                for tqdm_cls in [tqdm_auto, tqdm_auto.tqdm , tqdm_auto.tqdm_gui, tqdm_auto.tqdm_notebook, tqdm_auto.trange]:
                    tqdm_cls_str = t

# Generated at 2022-06-26 09:22:45.974963
# Unit test for function product
def test_product():
    """
    Test for function `product`.
    """
    from ..tests import _test_product as test
    test(product)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:48.361095
# Unit test for function product
def test_product():
    """Test for function product"""
    assert list(product(range(10), repeat=2)) == list(itertools.product(
        range(10), repeat=2))

# Generated at 2022-06-26 09:22:51.888017
# Unit test for function product
def test_product():
    for i in product(["foo", "bar", "baz", "qux"], [1, 2, 3]):
        assert isinstance(i, tuple)
        assert len(i) == 2

# Generated at 2022-06-26 09:23:00.934408
# Unit test for function product
def test_product():
    from ..std import product
    from .utils import AssertEqualAllType

    A = [1, 2, 3, 4]
    B = ['x', 'y']
    i = 0
    for a, b in product(A, B, total=8):
        i += 1
        assert (a,b) == (A[i // 2], B[i % 2])
    assert i == 8

    i = 0
    for a, b in product(A, B, total=None):
        i += 1
        assert (a,b) == (A[i // 2], B[i % 2])
    assert i == 8

    i = 0
    for a, b in product(A, B, tqdm_class=AssertEqualAllType):
        i += 1

# Generated at 2022-06-26 09:23:12.273084
# Unit test for function product
def test_product():
    """Test for function product."""
    from os import remove
    try:
        remove("tqdm.log")
    except OSError:
        pass
    #
    i = 0
    for x in product([0, 1], [2, 3], [4, 5], tqdm_class=tqdm_auto, ascii=True,
                     file=open("tqdm.log", "w+"), miniters=1):
        i += 1
    assert i == 8
    #
    i = 0
    for x in product([0, 1], [2, 3], [4, 5], tqdm_class=tqdm_auto, ascii=True,
                     file=open("tqdm.log", "w+"), miniters=1, desc="desc"):
        i += 1


# Generated at 2022-06-26 09:23:20.809697
# Unit test for function product
def test_product():
    for i in product(range(4), range(3), range(2)):
        pass

    for i in product(range(4), range(3), range(2), tqdm_class=tqdm_auto):
        pass

    for i in product(range(10**5), tqdm_class=tqdm_auto):
        pass

    # Unit test with non-iterable objects
    s = "test"
    for i in product(s, tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-26 09:23:30.312566
# Unit test for function product
def test_product():
    '''
    Basic unit test for function product
    '''
    from itertools import product as iproduct
    from random import random

    for iterables in [
        [random() for _ in range(10)] for _ in range(10)
    ], [
        [random() for _ in range(10)], [random() for _ in range(10)],
        [random() for _ in range(10)]
    ], [
        tuple([random() for _ in range(10)]) for _ in range(10)
    ], [
        tuple([random() for _ in range(10)]),
        tuple([random() for _ in range(10)]),
        tuple([random() for _ in range(10)])
    ]:
        assert list(product(*iterables)) == list(iproduct(*iterables))

# Generated at 2022-06-26 09:23:37.406868
# Unit test for function product
def test_product():
    for i in product(range(3),
                     ["a", "b", "c"],
                     tqdm_class=tqdm_auto,
                     unit="xyz"):
        pass
    for i in tqdm_auto.product(range(3),
                               ["a", "b", "c"],
                               unit="xyz"):
        pass



# Generated at 2022-06-26 09:23:44.818113
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal as AAE
    for t in [tqdm, tqdm_gui, tqdm_notebook]:
        for i in range(1, 6):
            AAE(list(product(range(i), range(i), tqdm_class=t)),
                list(zip(range(i), range(i))))
            AAE(list(product(range(i), range(i**2), tqdm_class=t)),
                list(zip(range(i), range(i**2))))
            AAE(list(product(range(3), range(5), range(7), tqdm_class=t)),
                list(zip(range(3), range(5), range(7))))

# Generated at 2022-06-26 09:23:53.740204
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from tests_tqdm import with_setup, _range
    try:  # Python 3.2
        from tests_tqdm import StringIO
    except ImportError:  # Python 2.6
        from io import BytesIO as StringIO
    import sys

    def product_testing(out, iterable):
        _ = out.getvalue().split('\r')[:-1]
        temp = list(map(len, _))
        for i in zip(temp, temp[1:]):
            assert i[0] < i[1]

        _ = out.getvalue().split('\r')[-1]
        temp = list(map(len, _))
        assert temp.count(temp[-1]) == 1 or not temp


# Generated at 2022-06-26 09:24:13.018602
# Unit test for function product
def test_product():
    from tqdm import tqdm

    items = ['a', 'bb', 'ccc']
    it = product(items, items, items)
    out = [x for x in it]
    # Expected: 3x3x3 = 27 items
    assert (len(out) == 27)
    out = [x for x in tqdm(it)]
    # Expected: no items as iterator is exhausted
    assert (len(out) == 0)
    out = [x for x in tqdm(items, total=2)]
    # Expected: 2 items (total=2)
    assert (len(out) == 2)
    out = [x for x in tqdm(items)]
    # Expected: 3 items (no total=)
    assert (len(out) == 3)

# Generated at 2022-06-26 09:24:23.061950
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests import closing, closing_to_file, ncols, range_, range_infinite
    from .pandas import pandas_range

    with closing(ncols):
        for _ in range_(10):
            for n in range_(1, 3):
                for tqdm_cls in [tqdm_auto, tqdm_auto.tqdm]:
                    for iterable in [range_(100),
                                     range(100),
                                     range(100),
                                     pandas_range(100)]:
                        res = list(product(
                            *(iterable,) * n, tqdm_class=tqdm_cls))
                        assert len(res) == (100 ** n)


# Generated at 2022-06-26 09:24:25.468316
# Unit test for function product
def test_product():
    l = list(product(*[[1, 2], [3, 4]], tqdm_class=tqdm_auto))
    assert l == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-26 09:24:36.058777
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    import pytest
    with pytest.raises(TypeError):
        list(product(range(5), 5, total=10))
    assert list(product(range(5), 5, tqdm_class=None)) == list(
        itertools.product(range(5), range(5)))
    assert list(product(range(5), 5, miniters=0, tqdm_class=None)) == list(
        itertools.product(range(5), range(5)))
    with pytest.raises(TypeError):
        list(product(range(5), 5, tqdm_class=None, desc="test", dynamic_ncols=False))
    # miniters=0 should be ignored

# Generated at 2022-06-26 09:24:41.187410
# Unit test for function product
def test_product():
    """Test function product"""
    iterables = [
        [0, 1],
        [0, 1],
    ]
    expected_result = [(0, 0), (1, 0), (0, 1), (1, 1)]
    assert list(product(*iterables)) == expected_result

# Generated at 2022-06-26 09:24:53.206867
# Unit test for function product
def test_product():
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    assert list(product([0, 1])) == [(0,), (1,)]
    assert list(product([0, 1], range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-26 09:25:00.257924
# Unit test for function product
def test_product():
    from ..tqdm import trange
    with trange(3) as pbar:
        assert list(product(range(10), repeat=2)) == list(
            product(range(10), repeat=2, tqdm_class=pbar.__class__))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:25:03.947258
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tqdm import trange
    for t in trange(20, desc="test_product"):
        assert list(product(range(t), range(t))) == list(itertools.product(range(t), range(t)))

# Generated at 2022-06-26 09:25:15.749041
# Unit test for function product
def test_product():
    """Test for function product"""
    import sys
    import math
    import pickle
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO
    import numpy
    from collections import OrderedDict
    from numpy.random import randint
    from numpy.random import rand
    from numpy.testing import assert_array_equal
    from numpy.testing import assert_array_almost_equal
    from numpy.testing import assert_equal
    from numpy.testing import assert_almost_equal
    from numpy.testing import assert_
    from numpy.testing import assert_raises
    from .tqdm_class import tqdm

    # Test main arguments

# Generated at 2022-06-26 09:25:26.592394
# Unit test for function product
def test_product():
    """
    Test that itertools.product() is equivalent to tqdm.itertools.product()
    """
    # pylint: disable=W0631
    #         Using possibly undefined loop variable 'n'
    for l in range(5, 10, 2):
        for n in range(1, 5):
            for m in range(0, 1000, 137):
                itools_res = list(itertools.product(range(n), repeat=l))
                tqdm_res = list(product(range(n), repeat=l))
                assert len(itools_res) == len(tqdm_res)

# Generated at 2022-06-26 09:25:37.776420
# Unit test for function product
def test_product():
    assert list(product([1])) == [(1,)]
    assert list(product([1, 2])) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product(range(2), repeat=3)) == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-26 09:25:39.265952
# Unit test for function product
def test_product():
    test_case_0()


# Generated at 2022-06-26 09:25:45.863973
# Unit test for function product
def test_product():
    import pytest  # NOQA

    with pytest.raises(TypeError):
        # Test exception for a negative value
        product(-1, 1)

    with pytest.raises(TypeError):
        # Test exception for a float value
        product(1.1, 1)

    with pytest.raises(TypeError):
        # Test exception for a string
        product("r", 1)

    # Test normal case
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]

    # Test normal case
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]

    # Test normal case

# Generated at 2022-06-26 09:25:52.645822
# Unit test for function product
def test_product():
    print(">> Testing product")
    assert(len(list(product(range(10), range(10)))) == 100)
    for i in range(1, 4):
        assert(len(list(product(range(10), repeat=i))) == 1000)

# Generate test cases for function product

# Generated at 2022-06-26 09:26:05.083008
# Unit test for function product
def test_product():
    from ..auto import tqdm
    tqdm.pandas(desc="Loading ...")  # noqa
    for i in product(range(10), range(10)):
        pass
    for i in product(range(10), range(10), tqdm_class=tqdm):
        pass
    for i in product(range(10), range(10), tqdm_class=tqdm):
        pass
    total = 1
    for i in product(range(10), range(10), tqdm_class=tqdm):
        pass
    for i in product(range(10), range(10), tqdm_class=tqdm):
        pass
    total = 1
    for i in product(range(10), range(10), tqdm_class=tqdm):
        pass

# Generated at 2022-06-26 09:26:06.833371
# Unit test for function product
def test_product():
    test_case_0()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:26:14.154883
# Unit test for function product
def test_product():
    int_0 = -9
    int_1 = (int_0, int_0)
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = -1
    int_3 = -27
    int_4 = (int_2, int_3)
    int_5 = 0
    assert var_1[int_5] == int_4

# Generated at 2022-06-26 09:26:20.385265
# Unit test for function product
def test_product():
    assert len(list(product(["a", "b", "c"], [1, 2]))) == 6
    assert list(product([1, 2, 3], [1, 2])) == [(1, 1), (1, 2), (2, 1), (2, 2), (3, 1), (3, 2)]

# Generated at 2022-06-26 09:26:24.267289
# Unit test for function product
def test_product():
    array_0 = [3, 1]
    array_1 = [2, 4]
    var_0 = product(array_0, array_1)
    var_1 = list(var_0)

# Generated at 2022-06-26 09:26:29.304147
# Unit test for function product
def test_product():
    int_0 = 5
    var_0 = product(int_0)
    var_1 = list(var_0)
    assert var_1 == list(itertools.product(range(int_0)))


# Generated at 2022-06-26 09:26:47.632809
# Unit test for function product
def test_product():
    func_name = 'test_product'
    print(func_name)

    # Lists with values of each variable and their corresponging weights.
    int_0 = -9
    int_1 = (int_0, int_0)
    var_0 = product(*int_1)
    var_1 = list(var_0)

    # Lists of values for each variable.
    int_2 = (1, 1)
    int_3 = (0, 0)
    int_4 = (1, 0)
    int_5 = (1, 1)
    list_0 = [int_2, int_3, int_4, int_5]

    # Check if list of tuples are equal.

# Generated at 2022-06-26 09:26:52.715298
# Unit test for function product
def test_product():
    assert product(range(3), range(3)) == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]



# Generated at 2022-06-26 09:26:53.957512
# Unit test for function product
def test_product():
    assert test_case_0() == None

# Generated at 2022-06-26 09:26:56.509015
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:27:07.493598
# Unit test for function product
def test_product():
    var_0 = [1, 2, 3, 4]
    var_1 = [5, 6, 7, 8]
    var_2 = product(var_0, var_1, tqdm_class=tqdm_auto)
    var_3 = list(var_2)
    var_4 = (
        (1, 5),
        (1, 6),
        (1, 7),
        (1, 8),
        (2, 5),
        (2, 6),
        (2, 7),
        (2, 8),
        (3, 5),
        (3, 6),
        (3, 7),
        (3, 8),
        (4, 5),
        (4, 6),
        (4, 7),
        (4, 8)
    )
    assert var_3 == var

# Generated at 2022-06-26 09:27:12.644188
# Unit test for function product
def test_product():
    assert list(product([1, 2], repeat=1)) == [(1,), (2,)], \
        'Basic product'
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)], \
        'Repeat 1 product'
    assert list(product([1, 2], [3, 4], [5, 6])) == [(1, 3, 5), (1, 3, 6),
            (1, 4, 5), (1, 4, 6), (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)], \
        'Repeat 2 product'

# Generated at 2022-06-26 09:27:26.105356
# Unit test for function product
def test_product():
    tqdm_kwargs = {}
    tqdm_class = tqdm_kwargs['tqdm_class'] = tqdm_auto
    assert tqdm_class is None
    tqdm_kwargs['tqdm_class'] = tqdm_auto
    iterables = ()
    var_1 = product(*iterables, **tqdm_kwargs)
    var_2 = list(var_1)
    tqdm_kwargs = {}
    total = None
    tqdm_class = tqdm_kwargs['tqdm_class'] = tqdm_auto
    assert tqdm_class is None
    tqdm_kwargs['tqdm_class'] = tqdm_auto
    iterables = ((), 0, (1, 2, 3))
    len1 = len

# Generated at 2022-06-26 09:27:34.595888
# Unit test for function product
def test_product():
    print("Testing product")
    list1 = [1, 2, 3]
    list2 = ['a', 'b', 'c']
    list3 = ['x', 'y', 'z']

# Generated at 2022-06-26 09:27:45.965252
# Unit test for function product
def test_product():
    int_0 = [1, 2]
    int_1 = [3, 4]
    int_2 = [5, 6]
    list_0 = [int_0, int_1, int_2]
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = (tuple_0, tuple_1, tuple_2)
    int_3 = 0
    for tuple_4 in list_0:
        for int_4 in tuple_4:
            tuple_3[int_3] += (int_4,)
        int_3 += 1
    list_1 = []
    for tuple_4 in list_0:
        for int_4 in tuple_4:
            tuple_3[int_3] += (int_4,)
        int_3 += 1

# Generated at 2022-06-26 09:27:53.811494
# Unit test for function product
def test_product():
    try:
        from itertools import product
    except (ImportError, AttributeError):
        # Python < 2.6
        return None

    int_0 = -9
    int_1 = -3
    int_2 = (int_0, int_0)
    var_0 = product(int_2)
    var_1 = list(var_0)
    var_2 = product(int_1, (1, 2), int_2)
    var_3 = product(int_2, int_2)
    var_4 = list(var_3)



# Generated at 2022-06-26 09:28:15.004505
# Unit test for function product
def test_product():
    from ..tests._utils import closing_to_tqdm
    import itertools

    with closing_to_tqdm() as t:
        assert list(t.wrap(itertools.product)(range(3), repeat=3)) == list(product(range(3), repeat=3))
    assert list(itertools.product(*t.wrap(range)(3), **dict(repeat=3))) == list(product(*t.wrap(range)(3), **dict(repeat=3)))
    assert hasattr(itertools, "product")
    assert callable(itertools.product)

# Generated at 2022-06-26 09:28:23.623525
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    a = [3,5,7]
    b = [1,2,3,4]
    c = list(product(a,b))
    assert c == [(3, 1), (3, 2), (3, 3), (3, 4), (5, 1), (5, 2), (5, 3), (5, 4), (7, 1), (7, 2), (7, 3), (7, 4)]

# Generated at 2022-06-26 09:28:31.576342
# Unit test for function product
def test_product():
    #
    # Case 0
    #
    int_0 = -9
    int_1 = (int_0, int_0)
    var_0 = product(*int_1)
    var_1 = list(var_0)

    #
    # Case 1
    #
    class Class:
        def __len__(self):
            return 6
    var_2 = Class()
    var_3 = product(var_2)
    var_4 = list(var_3)

    #
    # Case 2
    #
    var_5 = product([])
    var_6 = list(var_5)

    #
    # Case 3
    #
    int_2 = -2
    int_3 = 4
    int_4 = (int_2, int_3)

# Generated at 2022-06-26 09:28:37.680976
# Unit test for function product
def test_product():
    # Output: []
    assert list(product(range(0))) == []

    # Output: [(5, 6)]
    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Output: [(1, 2, 3), (2, 3, 4), (3, 4, 5)]
    assert list(product(range(1, 4), range(2, 5))) == [(1, 2), (1, 3), (1, 4),
                                                       (2, 2), (2, 3), (2, 4),
                                                       (3, 2), (3, 3), (3, 4)]

    # Output: [('a', 'b', 'c')]

# Generated at 2022-06-26 09:28:46.078048
# Unit test for function product
def test_product():
    intro_0 = -5
    intro_1 = (intro_0, intro_0)
    var_0 = product(*intro_1)
    var_1 = list(var_0)

# Generated at 2022-06-26 09:28:57.604869
# Unit test for function product
def test_product():
    ans = ('A', 'b')
    assert next(product('A', 'b')) == ans, "First item is not correct"
    assert next(product('A', 'b')) == ans, "Repeated items don't match"
    assert next(product('A', 'b', 'C')) == ans + ('C',), "3-tuple is wrong"

    # Test for non-equal sized iterables
    assert next(product('ABCD', 'xy')) == ('A', 'x')

    # Test for non-equal sized iterables
    assert next(product('ABCD', 'xy')) == ('A', 'x')
    # Test for unusual iterables
    assert next(product(range(3), range(4))) == (0, 0)

# Generated at 2022-06-26 09:29:07.155456
# Unit test for function product
def test_product():
    from os import system
    from math import ceil
    from random import randrange as rr
    from itertools import izip as zip, tee
    base = (1, 2, 3)
    const = (0, 1, 2)
    tbase = tuple
    def listify(generator):
        return list(generator)
    def test_len():
        assert listify(product(*base)) == \
            list(map(tbase, list(itertools.product(base[0], base[1], base[2]))))
        assert listify(product(*base, tqdm_class=None)) == \
            list(map(tbase, list(itertools.product(base[0], base[1], base[2]))))

# Generated at 2022-06-26 09:29:08.885067
# Unit test for function product
def test_product():
    assert (list(product('ab', range(3))) == [('a', 0),
    ('a', 1),
    ('a', 2),
    ('b', 0),
    ('b', 1),
    ('b', 2)])

# Generated at 2022-06-26 09:29:11.170848
# Unit test for function product
def test_product():
    assert True

if __name__ == "__main__":
    pass

# Generated at 2022-06-26 09:29:12.527588
# Unit test for function product
def test_product():
    assert test_case_0() is None

# Generated at 2022-06-26 09:29:38.055478
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    def test_case_0():
        int_0 = -9
        int_1 = (int_0, int_0)
        var_0 = product(*int_1)
        var_1 = list(var_0)
        assert_equal(len(var_1), 81)
        assert_equal(var_1[-1], (int_0, int_0))
    def test_case_1():
        int_0 = -9
        int_1 = (int_0, int_0)
        var_0 = product(*int_1, tqdm_class=None)
        var_1 = list(var_0)
        assert_equal(len(var_1), 81)

# Generated at 2022-06-26 09:29:48.127534
# Unit test for function product
def test_product():
    for iterables in [(), [], ((),)]:
        for tqdm_kwargs in [{}, {"miniters": 0}, {"mininterval": 0},
                            {"miniters": 0, "mininterval": 0}]:
            # No exception
            product(*iterables, **tqdm_kwargs)

            # maxinterval check
            tqdm_auto.write = lambda x: x
            tqdm_auto.monitor_interval = 0.
            tqdm_auto.mininterval = 0.
            tqdm_auto.maxinterval = 1.
            product(*iterables, **tqdm_kwargs)
            assert tqdm_auto.monitor_interval <= tqdm_auto.maxinterval
            tqdm_auto.write = tqdm_auto.write_



# Generated at 2022-06-26 09:29:49.887003
# Unit test for function product
def test_product():
    assert False


# Generated at 2022-06-26 09:29:59.556763
# Unit test for function product
def test_product():
    # Test the case where iterable is empty
    var_0 = product()
    var_1 = list(var_0)
    assert [()] == var_1

    # Test the case where iterable has only single element
    int_0 = 9
    var_2 = product(int_0)
    var_3 = list(var_2)
    assert [(0,), (1,), (2,), (3,), (4,), (5,), (6,), (7,), (8,)] == var_3

    # Test the case where iterable has multiple elements
    int_1 = int_0
    var_4 = product(int_0, int_1)
    var_5 = list(var_4)

# Generated at 2022-06-26 09:30:04.936434
# Unit test for function product
def test_product():
    int_0 = -9
    int_1 = (int_0, int_0)
    var_0 = product(*int_1)
    var_1 = list(var_0)


if __name__ == "__main__":
    test_case_0()
    test_product()