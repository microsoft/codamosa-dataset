

# Generated at 2022-06-26 09:20:14.794226
# Unit test for function product
def test_product():
    iterables = [[1, 2], [3, 4]]
    list(product(*iterables)) == [
        (1, 3),
        (1, 4),
        (2, 3),
        (2, 4)
    ]


if __name__ == "__main__":

    from doctest import testmod
    testmod()

# Generated at 2022-06-26 09:20:20.524528
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # Test tqdm_class = tqdm.auto.tqdm
    with tqdm_auto.tqdm(total=8) as t:
        for i, j in product([1, 2], [3, 4]):
            t.update()
        t.close()


# Generated at 2022-06-26 09:20:22.609324
# Unit test for function product
def test_product():
    for i_0 in product(range(4), range(4)):  # range(4)
        assert i_0  # to suppress warning

# Generated at 2022-06-26 09:20:26.590061
# Unit test for function product
def test_product():
    assert False == False

test_cases = [
    (test_case_0, "tqdm_tqdm_wrapper"),
]

if __name__ == "__main__":
    for f, _ in test_cases:
        f()
    print("done")

# Generated at 2022-06-26 09:20:27.107481
# Unit test for function product
def test_product():
    assert True

# Generated at 2022-06-26 09:20:32.922479
# Unit test for function product
def test_product():
    def _print_msg(case, *args, **kwargs):
        try:
            kwargs['tqdm_class'] = tqdm_auto
        except KeyError:
            pass
        return test_case_0(*args, **kwargs)

    # Test Case: 0
    test_case_0()
    test_case_0(tqdm_class=tqdm_auto)

    # Test Case: 1
    # test_case_1()
    # test_case_1(tqdm_class=tqdm_auto)

    # Test Case: 2
    # test_case_2()
    # test_case_2(tqdm_class=tqdm_auto)

    # Test Case: 3
    # test_case_3()
    # test_case_3(tqdm

# Generated at 2022-06-26 09:20:35.089922
# Unit test for function product
def test_product():
    def test_case():
        for i in product():
            pass
    test_case()

# Unit test

# Generated at 2022-06-26 09:20:46.797735
# Unit test for function product
def test_product():
    """
    Unit test for function product
    See https://docs.pytest.org/en/latest/
    """
    import sys
    import pytest
    import tqdm

    # Test for exceptions
    with pytest.raises(TypeError):
        for _ in product(None):
            pass

    # Test for no exceptions
    try:
        for _ in product():
            pass
    except:  # noqa: E722
        e = sys.exc_info()[0]
        print('Got exception: {}'.format(e))
        pytest.fail()

    # Test for no exception and with default tqdm_class
    try:
        for _ in product():
            pass
    except:  # noqa: E722
        e = sys.exc_info()[0]

# Generated at 2022-06-26 09:20:57.444760
# Unit test for function product
def test_product():  # noqa
    var_0 = product([1, 2, 3], [4, 5, 6], [7, 8, 9])
    var_0 = product([1, 2, 3], [4, 5, 6], [7, 8, 9], total=len(list(product([1, 2, 3], [4, 5, 6], [7, 8, 9]))))
    var_0 = product(range(5), range(5), range(5), total=len(list(product(range(5), range(5), range(5)))))
    var_0 = product(range(3), range(3), range(3), total=len(list(product(range(3), range(3), range(3)))))

# Generated at 2022-06-26 09:21:04.778300
# Unit test for function product
def test_product():
    """Test product function"""
    result = list(product(range(3), range(3)))
    assert result == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2),
                      (2, 0), (2, 1), (2, 2)], result
    assert list(product(range(3), range(3), [0])) == \
        [(0, 0, 0), (0, 1, 0), (0, 2, 0), (1, 0, 0), (1, 1, 0),
         (1, 2, 0), (2, 0, 0), (2, 1, 0), (2, 2, 0)], result

    t = product(range(4), range(4), range(4), [[1]], [[2]])
    assert list(t)

# Generated at 2022-06-26 09:21:14.874635
# Unit test for function product
def test_product():
    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_2, int_2, int_3, int_4]
    var_2 = var_1 == int_5
    assert var_2 == True


# Generated at 2022-06-26 09:21:17.456845
# Unit test for function product
def test_product():
    """
    Test for function product
    """
    test_case_0()

test_product()

# Generated at 2022-06-26 09:21:27.966253
# Unit test for function product
def test_product():
    var_3 = product(range(2), range(2))
    var_4 = list(var_3)
    assert var_4 == [(0, 0), (0, 1), (1, 0), (1, 1)]
    var_5 = product(range(2))
    var_6 = list(var_5)
    assert var_6 == list(range(2))

    def test_raise_total_1():
        var_7 = product(range(3), range(3, 6), tqdm_class=tqdm_auto,
                        desc="test_raise_total_1", total=10)
        var_8 = list(var_7)
        assert var_8 == [(0, 3), (0, 4), (0, 5), (1, 3), (1, 4)]


# Generated at 2022-06-26 09:21:38.358149
# Unit test for function product
def test_product():

    # ~~~ auto ~~~
    from .tests_tqdm import pretest_posttest

    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1, tqdm_class=tqdm_auto)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_2, int_2, int_3, int_4]
    var_2 = var_1 == int_5
    int_6 = 0
    var_3 = (var_2, int_6)

# Generated at 2022-06-26 09:21:39.211461
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:21:44.083353
# Unit test for function product
def test_product():
    import numpy as np
    for i in range(1000):
        iterables = np.random.randint(1, 5, size=np.random.randint(1, 5))
        assert list(product(iterables)) == list(itertools.product(iterables))

# Generated at 2022-06-26 09:21:45.849561
# Unit test for function product
def test_product():
    assert test_case_0() == True

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:21:52.141184
# Unit test for function product
def test_product():
    var_0 = product(*[1, 2, 3])
    assert var_0 == [(1, 2, 3)]
    var_1 = product(*['123', '45'])
    var_2 = var_1 == [('1', '4'), ('1', '5'), ('2', '4'), ('2', '5'), ('3', '4'), ('3', '5')]
    var_3 = product(*[1, 2], *[3, 4], *[5, 6, 7])

# Generated at 2022-06-26 09:22:00.660799
# Unit test for function product
def test_product():
    # Test case 0
    # Test case 0
    # (mock)
    int_6 = -6
    int_7 = [int_6, int_6]
    var_3 = itertools.product(*int_7)
    var_4 = list(var_3)
    int_8 = (int_6, int_7)
    int_9 = (int_8, int_8)
    int_10 = (int_8, int_8)
    int_11 = [int_8, int_8, int_9, int_10]
    var_5 = product(*int_7)
    var_6 = list(var_5)
    var_7 = var_6 == int_11
    return var_7


if __name__ == "__main__":
    import sys
    sys

# Generated at 2022-06-26 09:22:08.426218
# Unit test for function product
def test_product():
    int_0 = -5
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_2, int_2, int_3, int_4]
    var_2 = var_1 == int_5
    return var_2

# Generated at 2022-06-26 09:22:21.107613
# Unit test for function product
def test_product():
    import numpy as np

    def cartesian(*arrays):
        """Compute the Cartesian product of arrays.

        Parameters
        ----------
        arrays : list of array-like
            1-D arrays to form the Cartesian product of.

        Returns
        -------
        out : ndarray
            2-D array of shape (M, len(arrays))  where M is the product of
            the shapes for each of the input arrays.
        """
        arrays = [np.array(a) for a in arrays]
        shapes = [a.shape for a in arrays]
        dtype = arrays[0].dtype

        ix = np.indices(shapes, dtype=dtype)
        ix = ix.reshape(len(arrays), -1).T


# Generated at 2022-06-26 09:22:22.603610
# Unit test for function product
def test_product():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 09:22:23.558534
# Unit test for function product
def test_product():
    assert test_case_0()

# Generated at 2022-06-26 09:22:25.677905
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:22:27.995450
# Unit test for function product
def test_product():
    tqdm_auto.pandas(desc="test product")
    test_case_0()

# Generated at 2022-06-26 09:22:39.058486
# Unit test for function product
def test_product():
    # >>> var_0 = product(*-6)
    var_0 = product(*-6)
    # >>> var_1 = list(var_0)
    var_1 = list(var_0)
    # >>> ((-6, -6), (-6, -6))
    # >>> ((-6, -6), (-6, -6))
    # >>> ((-6, -6), (-6, -6))
    # >>> ((-6, -6), (-6, -6))
    # >>> var_2 = var_1 == [(-6, -6), (-6, -6), ((-6, -6), (-6, -6)), ((-6, -6), (-6, -6))]

# Generated at 2022-06-26 09:22:41.636634
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for _ in range(0, 5):
        test_case_0()

# Generated at 2022-06-26 09:22:50.661285
# Unit test for function product
def test_product():
    from nose import with_setup
    from nose.tools import assert_equal, assert_true

    def test_case_0():
        int_0 = -6
        int_1 = [int_0, int_0]
        var_0 = product(*int_1)
        var_1 = list(var_0)
        int_2 = (int_0, int_1)
        int_3 = (int_2, int_2)
        int_4 = (int_2, int_2)
        int_5 = [int_2, int_2, int_3, int_4]
        var_2 = var_1 == int_5
        assert_equal(var_2, True)

    test_case_0()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:55.176476
# Unit test for function product
def test_product():
    # Test cases unit test
    test_case_0()


if __name__ == "__main__":
    import sys
    import os
    import nose2

    argv = sys.argv[:]
    argv.append("--")
    nose2.main(argv=argv)

# Generated at 2022-06-26 09:23:09.115992
# Unit test for function product
def test_product():
    pass_flag = True
    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_2, int_2, int_3, int_4]
    var_2 = var_1 == int_5
    if (var_2):
        pass
    else:
        pass_flag = False
        print('Function product() FAILED!')
    return pass_flag


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:23:11.632533
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:23:23.414634
# Unit test for function product
def test_product():
    """
    Test function product
    """
    int_0 = 6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = (0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_3, int_4]
    var_2 = var_1 == int_5
    int_6 = 0
    int_7 = 0
    int_8 = 256
    int_9 = 6
    int_10 = 6
    int_11 = [int_9, int_10]
    var_3 = product(*int_11)
    int_12 = 0
    int

# Generated at 2022-06-26 09:23:26.419772
# Unit test for function product
def test_product():
    test_case_0()
    print("Unit test for function product")


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:29.984546
# Unit test for function product
def test_product():
    tqdm_obj = product(["a", "b", "c"], range(2), tqdm_class=tqdm_auto)
    assert tqdm_obj.__sizeof__() == 56

if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:23:33.872704
# Unit test for function product
def test_product():
    """Function that prints the unit test of function product."""
    test_case_0()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:35.917542
# Unit test for function product
def test_product():
    # assert func_return == test_result_0
    assert test_case_0()

# Generated at 2022-06-26 09:23:42.033688
# Unit test for function product
def test_product():
    from .common import visible_tqdm

    for use_tqdm in (False, True):
        for cls in (tqdm_auto, visible_tqdm):
            for total in (False, True):
                for args in (['abc', range(4)], []):
                    _total = None if not total else len(''.join(args))
                    p = product(*args,
                                total=_total,
                                tqdm_class=cls if use_tqdm else None)
                    assert list(p) == list(itertools.product(*args))

# Generated at 2022-06-26 09:23:52.532626
# Unit test for function product
def test_product():
    int_0 = product(range(10), range(10), range(10), range(10), range(10), range(10), range(), range())
    int_1 = (1, 2, 3, 4, 5)
    int_2 = [int_1, int_1, int_1]
    int_3 = product(int_1, int_1, int_1, int_2)
    int_4 = (1, 2, 3, (1, 2, 3), (1, 2, 3), (1, 2, 3))
    int_5 = (1, 2, 3, int_1, int_1, int_1)
    int_6 = [int_4, int_5]
    int_7 = product(int_4, int_5)

# Generated at 2022-06-26 09:23:54.499776
# Unit test for function product
def test_product():
    assert (test_case_0() == True)


# Generated at 2022-06-26 09:23:58.439592
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == '__main__':
    # test_itertools()
    test_product()

# Generated at 2022-06-26 09:24:10.150797
# Unit test for function product
def test_product():
    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_2, int_2, int_3, int_4]
    var_2 = var_1 == int_5
    assert var_2

# Generated at 2022-06-26 09:24:12.526912
# Unit test for function product
def test_product():
    # test case 0
    try:
        test_case_0()
        print('Passed!')
    except:
        print('Failed!')

test_product()

# Generated at 2022-06-26 09:24:22.812479
# Unit test for function product
def test_product():
    from inspect import signature

    # Ensure the function can be called
    try:
        product()
    except TypeError:
        pass

    # Ensure the signature is as expected
    sig = signature(product)
    params = list(sig.parameters.values())
    assert len(params) == 2
    assert params[0].name == "iterables"
    assert params[0].kind == params[0].VAR_POSITIONAL
    assert params[1].name == "tqdm_class"
    assert params[1].kind == params[1].POSITIONAL_OR_KEYWORD
    assert params[1].default == tqdm_auto

# Generated at 2022-06-26 09:24:35.285451
# Unit test for function product
def test_product():
    """
    Function:product
    """
    int_0 = -1
    int_1 = -1
    int_2 = int_0
    var_0 = product(range(int_1, int_2))
    var_1 = list(var_0)
    int_3 = ([int_0, int_0],)
    var_2 = var_1 == int_3
    int_4 = -1
    int_5 = -1
    int_6 = int_4
    int_7 = -1
    int_8 = -1
    int_9 = int_7
    var_3 = product(range(int_5, int_6), range(int_7, int_8))
    var_4 = list(var_3)
    int_10 = [int_4, int_7]

# Generated at 2022-06-26 09:24:42.922294
# Unit test for function product
def test_product():
    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_2, int_2, int_3, int_4]
    var_2 = var_1 == int_5
    assert var_2

# Generated at 2022-06-26 09:24:52.875102
# Unit test for function product
def test_product():
    int_0 = -7
    int_1 = (int_0, int_0)
    int_2 = (int_0, int_0)
    int_3 = [int_1, int_2]
    var_0 = product(*int_3)
    int_4 = (int_0, int_1)
    int_5 = (int_0, int_1)
    int_6 = [int_4, int_5, int_1, int_2]
    var_1 = list(var_0)
    var_2 = var_1 == int_6

if __name__ == "__main__":
    test_case_0()
    test_product()
    print("All tests passed")

# Generated at 2022-06-26 09:25:03.766597
# Unit test for function product
def test_product():
    # Test with tqdm_class set to None so we can test total arg
    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1, tqdm_class=tqdm_auto)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = (int_2, int_2)
    int_5 = [int_2, int_2, int_3, int_4]
    var_2 = var_1 == int_5
    assert var_2

# Generated at 2022-06-26 09:25:05.366480
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:25:08.956164
# Unit test for function product
def test_product():
    assert product((1,2), (1,2)) == [(1,1), (1,2), (2,1), (2,2)]

# Generated at 2022-06-26 09:25:12.239700
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == '__main__':
    test_product()
    print('All test cases passed successfully')

# Generated at 2022-06-26 09:25:26.008982
# Unit test for function product
def test_product():
    from itertools import permutations
    from .test_tqdm import with_setup, FakeTqdmType, pretest, posttest

    @with_setup(pretest, posttest)
    def inner(tqdm_cls=tqdm_auto, **kwargs):
        int_0 = -6
        int_1 = [int_0, int_0]
        var_0 = product(*int_1)
        var_1 = list(var_0)
        int_2 = (int_0, int_1)
        int_3 = (int_2, int_2)
        int_4 = [int_2, int_2, int_3, int_3]

    inner(tqdm_cls=FakeTqdmType, desc="test_product")



# Generated at 2022-06-26 09:25:33.113209
# Unit test for function product
def test_product():
    int_0 = 0
    int_1 = 1
    var_0 = product(*int_1)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = [int_2, int_2, int_3, int_3]
    pass

# Generated at 2022-06-26 09:25:45.941188
# Unit test for function product
def test_product():
  # Creation and initialization of the testing variables
  str_0 = '"%s", %d'
  str_1 = 'th'
  str_2 = '%s and %s'
  str_3 = 'st'
  str_4 = '%s and %s and %s and %s'
  str_5 = 'rd'
  str_6 = '%s, %s, %s, and %s'
  str_7 = 'nd'
  str_8 = '%s, %s, %s, %s, and %s'
  str_9 = 'First'
  str_10 = '%s, %s, %s, %s, %s, and %s'
  str_11 = '%s, %s, %s, %s, %s, %s, and %s'


# Generated at 2022-06-26 09:25:56.416159
# Unit test for function product
def test_product():
    import re
    import operator
    import itertools

    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = [int_2, int_2, int_3, int_3]
    int_5 = list(itertools.product(*int_4))
    var_2 = list(var_0)
    return [var_1, var_2, int_5]

# Generated at 2022-06-26 09:26:04.722677
# Unit test for function product
def test_product():
    # 1
    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    # 2
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = [int_2, int_2, int_3, int_3]
    var_2 = product(*int_4)
    var_3 = list(var_2)

# Generated at 2022-06-26 09:26:06.832555
# Unit test for function product
def test_product():
    # Update this to a test case for your function
    test_case_0()

# Generated at 2022-06-26 09:26:08.234143
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:26:17.299658
# Unit test for function product
def test_product():
    # import needed packages
    import tqdm

    # define function to be tested
    def _product(iterables, tqdm_class=tqdm.auto.tqdm, **tqdm_kwargs):
        '''Equivalent of `itertools.product`.
        '''
        # type: (Iterable[Iterable], Any, **Any) -> Iterable[Tuple[Any, ...]]
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop('tqdm_class', tqdm.auto.tqdm)
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i

# Generated at 2022-06-26 09:26:17.815918
# Unit test for function product
def test_product():
    assert test_case_0() is None

# Generated at 2022-06-26 09:26:24.821487
# Unit test for function product
def test_product():
    tqdm_obj = product(range(3))
    assert next(tqdm_obj) == (0,)
    assert next(tqdm_obj) == (1,)
    assert next(tqdm_obj) == (2,)
    try:
        next(tqdm_obj)
    except StopIteration:
        pass
    else:
        raise AssertionError


test_case_0()
test_product()

# Generated at 2022-06-26 09:26:39.665691
# Unit test for function product
def test_product():

    from ..utils import ncols

    # Test with BaseTqdm
    assert len(list(itertools.product([1, 2, 3], ['a', 'b', 'c']))) == 9
    pbar_0 = product([1, 2, 3], ['a', 'b', 'c'])
    var_0 = list(pbar_0)
    assert len(var_0) == 9

    # Test with tqdm
    assert len(list(itertools.product([1, 2, 3], ['a', 'b', 'c']))) == 9
    pbar_1 = product([1, 2, 3], ['a', 'b', 'c'], tqdm_class=tqdm_auto)
    var_1 = list(pbar_1)
    assert len(var_1) == 9

   

# Generated at 2022-06-26 09:26:43.990530
# Unit test for function product
def test_product():
    var_0 = test_case_0()
    assert var_0 is None
    return None

if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:26:52.444640
# Unit test for function product
def test_product():
    total_len = 0
    for n in range(10):
        for m in range(10):
            int_1 = product(*([range(10)] * n), total=m)
            int_0 = list(int_1)
            int_2 = len(int_0)
            assert int_2 == (m or (10 ** n))
            total_len += int_2
    assert total_len == 1000



# Generated at 2022-06-26 09:26:59.680564
# Unit test for function product
def test_product():
    x = [list(range(10)) for _ in range(10)]
    from tqdm._utils import _term_move_up
    def test(tqdm):
        for _ in tqdm(product(*x)):
            pass
    with tqdm_auto(leave=False, unit="i", miniters=1, mininterval=0) as t:
        _ = test(t)
        
    x = [list(range(10000)) for _ in range(10)]
    def test(tqdm):
        for _ in tqdm(product(*x)):
            pass
    with tqdm_auto(leave=False, unit="i", miniters=1, mininterval=0) as t:
        _ = test(t)

    from .utils import TestCase
    from .utils import __

# Generated at 2022-06-26 09:27:01.039519
# Unit test for function product
def test_product():
    test_case_0()

test_product()

# Generated at 2022-06-26 09:27:09.069976
# Unit test for function product
def test_product():
    from .test_context import TestContext
    from .test_utils import (
        print_test_result,
        print_test_description,
        get_future_pool,
    )
    import time
    import numpy as np
    from .test_utils import custom_itertools
    from .test_utils import product

    test_case_0()

    test_context = TestContext(
        config_file="tqdm_config.cfg",
        log_file="test_tqdm.log",
        log_level="DEBUG",
        fd=sys.stdout,
        default_box_char=u'\u2588'
    )
    test_context.validate()


# Generated at 2022-06-26 09:27:13.567575
# Unit test for function product
def test_product():
    int_0 = 2
    int_1 = 5
    var_0 = product([int_0], [int_1])
    var_1 = list(var_0)
    int_2 = (int_0, int_1)
    int_3 = [int_2]
    var_0 = type(int_1)
    var_1 = type(var_0)
    var_2 = type(var_1)
    var_0 = type(int_1)
    var_3 = type(var_0)
    int_4 = [int_0, int_1]
    int_5 = (int_4, int_4)
    int_6 = [(int_5, int_5)]
    int_7 = ((int_2, int_2), int_6)

# Generated at 2022-06-26 09:27:26.592467
# Unit test for function product

# Generated at 2022-06-26 09:27:28.167469
# Unit test for function product
def test_product():
    test_case_0()


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:27:35.772039
# Unit test for function product
def test_product():
    from six.moves import range
    assert list(product(map(str, range(10)))) == list(map(lambda x: (x[0], x[1]),
                                                         itertools.product(map(str, range(10)), repeat=2)))
    assert list(product(map(str, range(10)), repeat=2)) == list(map(lambda x: (x[0], x[1]),
                                                                   itertools.product(map(str, range(10)), repeat=2)))
    assert list(product([])) == list(map(lambda x: (x[0], x[1]),
                                         itertools.product([], repeat=2)))

# Generated at 2022-06-26 09:27:50.918067
# Unit test for function product
def test_product():
    assert all(a + b == c for a, b, c in product(range(5), range(5), range(5)))
    assert all(a + b == c for a, b, c in product(
        range(5),
        range(5),
        range(5),
        tqdm_class = tqdm_auto))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:27:51.745112
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:28:04.658775
# Unit test for function product
def test_product():
    actual = [
        list(product(range(7), range(5), range(4))),
        list(product(range(7), range(5), range(4), repeat=1)),
        list(product(range(7), range(5), range(4), repeat=2)),
        list(product(range(7), range(5), range(4), repeat=3)),
        list(product(range(7), range(5), range(4), repeat=4))]

# Generated at 2022-06-26 09:28:15.930231
# Unit test for function product
def test_product():
    int_0 = 1
    int_1 = 2
    int_2 = 32
    int_3 = 64

    # Test: int type
    var_0 = product(int_0, int_1, int_2, int_3)
    var_1 = list(var_0)
    var_2 = [(1, 2, 32, 64)]
    assert var_1 == var_2

    # Test: int type, not divisible
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4

    var_0 = product(int_0, int_1, int_2, int_3)
    var_1 = list(var_0)
    var_2 = [(1, 2, 3, 4)]
    assert var_1 == var_2

    # Test

# Generated at 2022-06-26 09:28:26.314866
# Unit test for function product
def test_product():
    import tt
    import math

    def test_case_0():
        int_0 = -6
        int_1 = [int_0, int_0]
        var_0 = product(*int_1)
        var_1 = list(var_0)
        int_2 = (int_0, int_1)
        int_3 = (int_2, int_2)
        int_4 = [int_2, int_2, int_3, int_3]
        return (int_1, var_0, var_1, int_4)

    def test_case_1():
        int_0 = -6
        int_1 = -6
        int_2 = range(int_0, int_1)

# Generated at 2022-06-26 09:28:36.521695
# Unit test for function product
def test_product():

    # Initializate a test list
    test_list = [1, 2, 3]

    # Assert all combinations of list elements
    test_product = product(*test_list)

# Generated at 2022-06-26 09:28:45.898220
# Unit test for function product
def test_product():
    from tqdm import tqdm_gui
    from tqdm import trange
    from tqdm.gui import tqdm
    from tqdm._utils import _term_move_up
    import time
    import sys

    pbar = tqdm(total=100)
    time.sleep(0.1)
    pbar.update(10)
    time.sleep(0.1)
    pbar.close()
    time.sleep(0.1)
    assert pbar.n == 100
    assert pbar.last_print_n == 10
    assert not pbar.disable

    pbar = tqdm(total=100)
    time.sleep(0.1)
    pbar.update(10)
    time.sleep(0.1)
    pbar.close()

# Generated at 2022-06-26 09:28:57.601042
# Unit test for function product
def test_product():
    int_0 = -6
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    str_0 = str(var_1)
    int_2 = (int_0, int_1)
    int_3 = (int_2, int_2)
    int_4 = [int_2, int_2, int_3, int_3]
    var_2 = product(*int_4)
    var_3 = list(var_2)
    str_1 = str(var_3)
    int_5 = -6
    int_6 = [int_5, int_5]
    var_4 = product(*int_6)
    var_5 = list(var_4)
    str_2

# Generated at 2022-06-26 09:29:07.133004
# Unit test for function product
def test_product():
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    assert list(product([1, 2], [3, 4], [5, 6])) == [
        (1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6),
        (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6),
    ]

# Generated at 2022-06-26 09:29:12.672301
# Unit test for function product
def test_product():
    def tqdm(*args, **kwargs):
        """Dummy tqdm"""
        class Tqdm:
            """Dummy tqdm class"""
            @staticmethod
            def update():
                """update dummy"""
                pass
        return Tqdm

    def func(*args):
        """func dummy"""
        return args

    TEST_STRINGS = ['abc', '123', '\u2665']
    assert list(product(TEST_STRINGS)) == list(itertools.product(
        TEST_STRINGS))

    TEST_INTS = [3, 1, 0]
    assert list(product(TEST_INTS)) == list(itertools.product(TEST_INTS))

# Generated at 2022-06-26 09:29:22.567079
# Unit test for function product
def test_product():
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:29:29.179513
# Unit test for function product
def test_product():
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    int_9 = 0
    int_10 = 0
    int_11 = 0
    int_12 = 0
    int_13 = 0
    int_14 = 0
    int_15 = 0
    int_16 = 0
    int_17 = 0
    int_18 = 0
    int_19 = 0
    int_20 = 0
    int_21 = 0
    int_22 = 0
    int_23 = 0
    int_24 = 0
    int_25 = 0
    int_26 = 0
    int_27 = 0
    int_

# Generated at 2022-06-26 09:29:30.976639
# Unit test for function product
def test_product():
    pass # TODO: add your test here if you want

# Generated at 2022-06-26 09:29:37.102780
# Unit test for function product
def test_product():
    from . import tqdm

    int_0 = -6
    int_1 = [int_0, int_0, int_0, int_0, int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)


try:
    import pytest
except ImportError:  # pragma: no cover
    pass
else:
    pytest.main(["-l", __file__])

# Generated at 2022-06-26 09:29:47.729516
# Unit test for function product
def test_product():
    import random
    import pytest

    # Test 1
    with pytest.raises(TypeError):
        product(False, False)

    # Test 2
    with pytest.raises(TypeError):
        product((0, 1), (2, 3))

    # Test 3
    rnd = random.Random(0)
    for i in range(5):
        iters = []
        for j in range(i):
            iters.append(range(rnd.randint(1, j + 2)))
        for j in range(i):
            expected = list(itertools.product(*iters))
            try:
                result = list(product(*iters, ncols=j))
                assert result == expected, "{} != {}".format(result, expected)
            except TypeError:
                pass

# Generated at 2022-06-26 09:29:52.014952
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except Exception as exception:
        assert False, "Exception thrown: " + str(exception)

    print("test_product finished without errors")

# Generated at 2022-06-26 09:29:54.519397
# Unit test for function product
def test_product():
    test_case_0()

# Test a warning is raised when a non-iterable is passed

# Generated at 2022-06-26 09:30:02.815393
# Unit test for function product
def test_product():
    def f(u, v, w, x, y, z):
        return (u*x**3 + v*x**2 + w*x + y) % z

    assert list(product(*[range(5), range(5), range(5), range(5), range(5)])) == \
            list(itertools.product(*[range(5), range(5), range(5), range(5), range(5)]))

    assert list(product([1, 2, 3], [4, 5, 6, 7], [8, 9])) == \
            list(itertools.product([1, 2, 3], [4, 5, 6, 7], [8, 9]))


# Generated at 2022-06-26 09:30:05.119091
# Unit test for function product
def test_product():
    print("TEST CASE 0")
    test_case_0()

# Main function
if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:30:10.884652
# Unit test for function product
def test_product():
    list_0 = [1, 2, 3]
    list_1 = [4, 5, 6]
    list_2 = [7, 8, 9]
    main_0 = product(list_0, list_1, list_2)
    main_1 = list(main_0)
    assert main_1[0] == (1, 4, 7)
    assert main_1[1] == (1, 4, 8)
    assert main_1[2] == (1, 4, 9)
    assert main_1[3] == (1, 5, 7)
    assert main_1[4] == (1, 5, 8)
    assert main_1[5] == (1, 5, 9)
    assert main_1[6] == (1, 6, 7)