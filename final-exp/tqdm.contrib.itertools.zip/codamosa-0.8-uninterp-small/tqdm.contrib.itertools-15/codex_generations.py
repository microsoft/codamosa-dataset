

# Generated at 2022-06-26 09:20:16.652758
# Unit test for function product
def test_product():
    _type_itertools_product = type(itertools.product())
    with tqdm_auto(**{}) as _:
        var_0 = product()
    assert issubclass(type(var_0), _type_itertools_product)
    _type_itertools_product = type(itertools.product())
    with tqdm_auto(**{'tqdm_class': tqdm_auto}) as _:
        var_1 = product()
    assert issubclass(type(var_1), _type_itertools_product)
    _type_itertools_product = type(itertools.product([1, 2, 3]))
    with tqdm_auto(**{'iterable': [1, 2, 3], 'total': 6}) as _:
        var_

# Generated at 2022-06-26 09:20:18.093777
# Unit test for function product

# Generated at 2022-06-26 09:20:20.526289
# Unit test for function product
def test_product():
    var_0 = product()
    assert var_0 is None, "cannot pass the test"

# Generated at 2022-06-26 09:20:30.316224
# Unit test for function product
def test_product():
    for i in product():
        assert i is not None

    for i in product(range(10)):
        assert i is not None

    for i in product(range(10), range(5)):
        assert i is not None

    for i in product(range(10), range(5), range(3)):
        assert i is not None

    for i in product(range(10), range(5), range(3), range(2)):
        assert i is not None

    for i in product(range(10), range(5), range(3), range(2), range(6)):
        assert i is not None

    for i in product(range(10), range(5), range(3), range(2), range(6), range(4)):
        assert i is not None


# Generated at 2022-06-26 09:20:35.390125
# Unit test for function product
def test_product():
    from .common import TestCase
    from .common import gc_collect_if_needed

    with TestCase("product"):
        # Check for gc if needed
        gc_collect_if_needed(test_case_0)
        # Compare with ideal output
        test_case_0()

# Generated at 2022-06-26 09:20:47.086345
# Unit test for function product
def test_product():
    assert callable(product)
    with tqdm_auto() as t:
        var_0 = product(tqdm_class=t.__class__)
        assert t is not var_0
        assert isinstance(var_0, types.GeneratorType)
        with pytest.raises(StopIteration):
            next(var_0)
    with tqdm_auto(total=1) as t:
        var_0 = product([1], tqdm_class=t.__class__)
        assert t is not var_0
        assert isinstance(var_0, types.GeneratorType)
        assert next(var_0) == (1,)
        with pytest.raises(StopIteration):
            next(var_0)

# Generated at 2022-06-26 09:20:52.373311
# Unit test for function product
def test_product():
    assert list(itertools.product('ABCD', 'xy')) == list(product('ABCD', 'xy'))
    r1 = itertools.product('ABCD', 'xy')
    for r2 in product('ABCD', 'xy'):
        pass

# Performance testing for function itertools.product

# Generated at 2022-06-26 09:21:00.705585
# Unit test for function product
def test_product():
    import numpy as np
    for i in product(range(10), range(100), range(1000), range(10000)):
        assert len(i) == 4
    for i in product([0], range(100), range(1000), range(10000)):
        assert len(i) == 4
    for i in product([0], range(100), range(1000), range(10000)):
        assert i[0] == 0
    a = np.array([0, 1])
    for i in product(a, range(100), range(1000), range(10000)):
        assert i[0] in a
    a = np.array([0, 1])
    total = a.shape[0] * 100 * 1000 * 10000

# Generated at 2022-06-26 09:21:04.234544
# Unit test for function product
def test_product():
    for _ in product('ABCD', 'xy'):
        print(_)
    # A x
    # A y
    # B x
    # B y
    # C x
    # C y
    # D x
    # D y


# Generated at 2022-06-26 09:21:07.852343
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = product()
    var_2 = product()
    var_3 = product()
    var_4 = product()
    var_5 = product()

# Generated at 2022-06-26 09:21:19.779599
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import FormatCustomText
    from .. import tqdm

    iterables = [range(10), range(4)]
    for iterable in [iterables, np.transpose(iterables)]:
        with tqdm(total=np.product(iterable),
                  unit_scale=False,
                  bar_format=FormatCustomText('{l_bar}')) as t:
            for i in product(*iterable, tqdm_class=tqdm,
                             postfix={'foo': 3}):
                t.set_postfix(foo=(i[0] * i[1]), refresh=False)

# Generated at 2022-06-26 09:21:22.524375
# Unit test for function product
def test_product():
    from .tests import Test
    with Test(__file__):  # noqa
        for i in product(range(10), range(10)):  # noqa F841
            pass

# Generated at 2022-06-26 09:21:33.493351
# Unit test for function product
def test_product():
    from .main import tqdm_iterable
    import itertools
    from os import linesep
    for n in [0, 1, 2, 3, 4]:
        for n_inner in range(n):
            for dtype in [list, tuple]:
                _iterables = [dtype(range(n_inner)) for i in range(n)]
                with tqdm_iterable(_iterables, ascii=True) as it:
                    for i in product(*it):
                        pass
                assert str(it).endswith(linesep)
                assert it.total == it.n == n_inner ** n
                assert it.n == n_inner ** n

# Generated at 2022-06-26 09:21:44.581364
# Unit test for function product
def test_product():
    from .tests import closing, decorator_wrap_class, range
    for tqdm_cls in (tqdm_auto,
                     decorator_wrap_class(tqdm_auto),
                     lambda: tqdm_auto(close=False)):
        with closing(tqdm_cls()) as t:
            assert list(product(range(3), tqdm=tqdm_cls)) == list(itertools.product(range(3), range(0, 0)))
        with closing(tqdm_cls()) as t:
            assert list(product(range(0, 0), tqdm=tqdm_cls)) == list(itertools.product(range(0, 0), range(0, 0)))

# Generated at 2022-06-26 09:21:48.884198
# Unit test for function product
def test_product():
    """
    Simple test case for function product().
    """
    from tqdm import trange
    with trange(10) as t:
        for _ in product(t, range(t.n)):
            pass
        for _ in product(range(t.n), range(t.n),
                         tqdm_class=tqdm_auto,
                         total=t.n * t.n):
            pass

# Generated at 2022-06-26 09:21:59.206324
# Unit test for function product
def test_product():
    from .tests import TestCase, __file__ as testing_file
    from .tests import closing, closing_nop
    from .tests import FakeTqdmFile, StringIO, _range

    class Tests(TestCase):

        def test_product(self):
            with closing(StringIO()) as our_file:
                with closing(StringIO()) as file:
                    t = tqdm(itertools.product(range(5000), range(10)))
                    for i in t:
                        pass
                    file.write(t.fd.getvalue())
                with closing(StringIO()) as file:
                    t = tqdm(itertools.product(range(5000), range(10)),
                             file=our_file)
                    for i in t:
                        pass
                    file.write(our_file.getvalue())

# Generated at 2022-06-26 09:22:08.083538
# Unit test for function product
def test_product():
    def check_product(iterables, total=None, **kwargs):
        prod1 = list(itertools.product(*iterables))
        prod2 = list(product(*iterables, **kwargs))
        assert prod1 == prod2

    check_product([range(9), range(10), range(11)])
    check_product(["ab", "cd"], total=4)
    check_product(["abc", "d"], total=4, tqdm_class=tqdm_auto)
    check_product([[], [], []], total=0)


# Alias for backwards compatibility
itertools_chain = product

# Generated at 2022-06-26 09:22:15.019011
# Unit test for function product
def test_product():
    from sys import version_info as v
    if v >= (3, 0):  # pragma: no cover
        exec("def irange(start, stop, step):\n"
             "    res = start\n"
             "    while res < stop:\n"
             "        yield res\n"
             "        res += step")
    else:  # pragma: no cover
        from itertools import imap as map
        from itertools import izip as zip

    from .tests import PretendMomentary, PretendPermanent

    # Test total is properly calculated and displayed
    tqdm_kwargs = {"maxinterval": 0, "mininterval": 0}

# Generated at 2022-06-26 09:22:26.522251
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Test normal usage
    import numpy as np
    # Test all get yielded
    a = [1, 2, 3]
    b = [5, 6, 7]
    c = [8, 9, 10]
    d = [0, 1]
    r = product(a, b, c, d, tqdm_class=tqdm_auto)
    ref = np.array(list(itertools.product(a, b, c, d)))
    for Y, R in zip(ref, r):
        assert np.all(np.asarray(Y) == np.asarray(R))
    # Test total
    a = [1, 2, 3]
    r = product(a, a, a, tqdm_class=tqdm_auto)

# Generated at 2022-06-26 09:22:35.967417
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    with tqdm_auto(total=8) as n:
        assert (["U", "D", "d", "d"], ["U", "D", "u", "u"]) \
            in product("UD", "ud", tqdm=n)
        assert (["U", "D", "u", "d"], ["u", "d", "U", "D"]) \
            in product("UD", "ud", tqdm=n)

# Generated at 2022-06-26 09:22:50.262562
# Unit test for function product
def test_product():
    from .utils import FormatMixin
    from .std import tqdm

    for tqdm_cls in (tqdm, tqdm.__class__):
        assert (
            list(product([1, 2], tqdm_class=tqdm_cls)) ==
            list(itertools.product([1, 2])))
        assert (
            list(product([1, 2], [3, 4], tqdm_class=tqdm_cls)) ==
            list(itertools.product([1, 2], [3, 4])))
        assert (
            list(product([1, 2], [3, 4], [5, 6], tqdm_class=tqdm_cls)) ==
            list(itertools.product([1, 2], [3, 4], [5, 6])))

# Generated at 2022-06-26 09:22:56.268454
# Unit test for function product
def test_product():
    assert list(product('AB', range(3))) == list(
        itertools.product('AB', range(3)))
    assert list(product('AB', range(3), tqdm_class=None)) == list(
        itertools.product('AB', range(3)))
    assert list(product('AB', range(3), tqdm_class=lambda x: x)) == list(
        itertools.product('AB', range(3)))

# Generated at 2022-06-26 09:23:00.627855
# Unit test for function product
def test_product():
    """Test function `product`."""
    for i in product(range(4), repeat=4, desc="Test", leave=True):
        pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:09.566777
# Unit test for function product
def test_product():
    from ..utils import chunkate

    def iter(total):
        for i in range(total):
            for j in range(i):
                for k in range(j):
                    yield i, j, k

    with tqdm_auto(total=25, miniters=1,
                   desc='Product3') as t:
        p = product(range(5), range(5), range(5),
                    tqdm_class=t.__class__, total=25)
        for i, j, k in p:
            assert (i, j, k) == next(iter(25))
            t.update()

# Generated at 2022-06-26 09:23:22.265125
# Unit test for function product
def test_product():
    assert (sum(1 for _ in product(range(10), range(20), range(30))) ==
            10 * 20 * 30)
    assert (sum(1 for _ in product(range(3), range(3))) ==
            3 * 3)
    assert (sum(1 for _ in product(range(2))) ==
            2)
    assert (sum(1 for _ in product([1], [1], [1], [1], [1], [1], [1], [1], [1],
                                  [1])) ==
            1)

# Generated at 2022-06-26 09:23:30.792035
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Simple case
    res = [i for i in product('ABCD', 'xy')]
    assert res == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                   ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]
    # Simple case with as_completed
    res = [i for i in product('ABCD', 'xy', tqdm_class=tqdm_auto.tqdm_as_completed)]
    assert res == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                   ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]
    # Simple case with

# Generated at 2022-06-26 09:23:41.590427
# Unit test for function product
def test_product():
    # Imports required for unit testing
    import shutil as sh
    from os import remove, listdir
    from collections import Counter

    # Generate pseudo-random data
    a = list(range(5))
    b = ["a", "b", "c"]
    c = [True, False]

    # Set unit test function
    def test_product_tqdm():
        for elem in product(a, b, c):
            pass

    # Initialize and run test
    test_product_tqdm()
    test_product_tqdm()
    test_product_tqdm()

    # Test with output
    test_product_tqdm()
    test_product_tqdm()
    test_product_tqdm()

    # Test with output and console

# Generated at 2022-06-26 09:23:49.388236
# Unit test for function product
def test_product():
    # noinspection PyUnusedLocal
    def f(x, y, z=3):
        return x + y + z

    assert list((product([0, 1], [1, 2], tqdm_class=None))) == \
        list(itertools.product([0, 1], [1, 2]))
    assert list((product([0, 1], [2, 3, 4], [3, 4], tqdm_class=None))) == \
        lis

# Generated at 2022-06-26 09:24:01.829844
# Unit test for function product
def test_product():
    from .monitor import MockMonitor
    from .utils import BaseTestUtils
    with BaseTestUtils(product) as utils:
        utils.reset()
        # Test that tqdm works with a single iterable
        with utils.capture_output() as (out, _):
            list(utils.genfunc(range(5)))
        assert utils.n == 5
        utils.deinit()

        # Test iterables as args
        with utils.capture_output() as (out, _):
            list(utils.genfunc(range(5), range(8, 10)))
        assert utils.n == 10

        # Test kwargs as args

# Generated at 2022-06-26 09:24:12.647139
# Unit test for function product
def test_product():
    """
    Unit test for :func:`tqdm.itertools.product`.
    """
    import numpy as np
    from ..utils import _term_move_up

    # Regular test
    lr = product(range(3), range(3), range(3))
    assert lr.__length_hint__() == 27

# Generated at 2022-06-26 09:24:29.449376
# Unit test for function product
def test_product():
    """Test for function product."""
    for i in product(range(100), range(100), range(100),
                     tqdm_class=tqdm_auto, miniters=1):
        pass


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:24:37.014315
# Unit test for function product
def test_product():
    from tqdm import trange
    from itertools import product
    assert list(product(range(1), range(2))) == [(0, 0), (0, 1)]

# Generated at 2022-06-26 09:24:49.689929
# Unit test for function product
def test_product():
    """ Test function product. """
    from .common import closing, SimpleText
    from .utils import format_sizeof

    assert product([], total=0, tqdm_class=SimpleText) is not None

    with closing(tqdm_auto(total=10, bar_format="{l_bar}",
                           ascii=True, unit='it',
                           mininterval=0, miniters=1,
                           disable=True)) as pbar:
        for _ in product(range(10), range(10),
                         range(10), range(10),
                         tqdm_class=pbar.__class__):
            pass
        # Test disable

# Generated at 2022-06-26 09:24:57.884283
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..auto import trange

    assert list(product('ABCD', repeat=2)) == [
        ('A', 'A'), ('A', 'B'), ('A', 'C'), ('A', 'D'), ('B', 'A'), ('B', 'B'),
        ('B', 'C'), ('B', 'D'), ('C', 'A'), ('C', 'B'), ('C', 'C'), ('C', 'D'),
        ('D', 'A'), ('D', 'B'), ('D', 'C'), ('D', 'D')
    ]

# Generated at 2022-06-26 09:25:04.416975
# Unit test for function product
def test_product():
    """Test module function product."""
    from ..autonotebook import tqdm
    list(tqdm.tqdm_product([], tqdm_class=tqdm.tqdm_gui, total=1))
    list(tqdm.tqdm_product([], tqdm_class=tqdm.tqdm_notebook, total=1))
    list(tqdm.tqdm_product([], tqdm_class=tqdm.tqdm, total=1))

# Generated at 2022-06-26 09:25:14.357624
# Unit test for function product
def test_product():
    for i in product("ABC", repeat=2):
        assert i in {"AA", "AB", "AC", "BA", "BB", "BC", "CA", "CB", "CC"}
    for i in product("ABC", [1, 2, 3]):
        assert i in {"A1", "A2", "A3", "B1", "B2", "B3", "C1", "C2", "C3"}
    try:
        next(product([1, 2, 3], "ABC", tqdm_class=None))
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-26 09:25:22.693093
# Unit test for function product
def test_product():
    """Test product function"""
    assert list(product([0, 1])) == [(0,), (1,)]
    assert list(product([0, 1], repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product([0, 1], [2, 3])) == [(0, 2), (0, 3), (1, 2), (1, 3)]

# Generated at 2022-06-26 09:25:36.000079
# Unit test for function product
def test_product():
    from numpy import product as mprod
    from random import randint
    from time import sleep
    from numpy.random import randint as nprod

    def random_ints(min_, max_, n, m):
        ''' Return an n * m random array of integers '''
        return nprod(max_ - min_ + 1, size=n * m).reshape(n, m) + min_


# Generated at 2022-06-26 09:25:43.741390
# Unit test for function product
def test_product():
    from random import randint
    from itertools import product
    for i in product(*[iter(range(randint(1, 5)))] * 10, **dict(tqdm_class=tqdm_auto)):
        pass
    for i in product(*[iter(range(randint(1, 5)))] * 10):
        pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:25:56.384269
# Unit test for function product
def test_product():
    # Test case with increasing size
    exp_lens = [2, 3, 4]
    res_lens = []
    for exp_len in exp_lens:
        group_res_lens = []
        for x in product(list(range(exp_len)),
                         list(range(exp_len)),
                         list(range(exp_len)),
                         tqdm_class=tqdm_auto, leave=False):
            group_res_lens.append(x)
        res_lens.append(len(group_res_lens))
    assert exp_lens == res_lens

    # Test case with decreasing size
    exp_lens.reverse()
    res_lens = []
    for exp_len in exp_lens:
        group_res_lens = []

# Generated at 2022-06-26 09:26:25.393768
# Unit test for function product
def test_product():
    """Test the wrapping of itertools.product"""
    from numpy.testing import assert_equal
    import numpy as np
    from numpy import array, arange, reshape
    from tqdm import trange
    import sys

    # product of arange(9) and arange(9)
    size = 81

    # product with trange
    tr = trange(size)
    res = product(arange(9), arange(9), tqdm=tr)
    assert_equal(array(list(res)), reshape(np.arange(size),
                                           (9, 9)))

    # product with trange and small total
    tr = trange(10, total=size)
    res = product(arange(9), arange(9), tqdm=tr)

# Generated at 2022-06-26 09:26:31.793196
# Unit test for function product
def test_product():
    assert list(product(range(2), range(3))) == list(itertools.product(range(2), range(3)))
    assert list(product(range(2), range(3), tqdm_class=tqdm_auto)) == list(itertools.product(range(2), range(3)))

# Generated at 2022-06-26 09:26:40.618907
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal
    from ..std import product

    # https://en.wikipedia.org/wiki/Cartesian_product#Examples
    prod = itertools.product
    assert_array_equal(list(product([], [1, 2, 3])), list(prod([], [1, 2, 3])))
    assert_array_equal(list(product([1], [2])), list(prod([1], [2])))
    assert_array_equal(list(product([1, 2], [3, 4])), list(prod([1, 2], [3, 4])))

# Generated at 2022-06-26 09:26:47.800648
# Unit test for function product
def test_product():
    """Test unit for function `product`"""
    from .tests_tqdm import FakeTqdmType
    from ._tqdm_test_cls import pretest_posttest_decorator

    @pretest_posttest_decorator(tqdm_class=FakeTqdmType)
    def func():
        c = 0
        for i in product(range(3), range(3)):
            c += i[0] * i[1]
        assert c == 9

    func()

# Generated at 2022-06-26 09:26:54.237718
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    def test_eq(iterable):
        assert list(itertools.product(*iterable)) == list(product(*iterable))

    test_eq((range(100),))
    test_eq((range(100), range(5)))
    test_eq((range(100), range(5), range(1, 2)))

# Generated at 2022-06-26 09:27:03.608268
# Unit test for function product
def test_product():
    """ test module """
    from .tests_tqdm import with_setup

    @with_setup(pretest=tqdm_auto.close, posttest=tqdm_auto.reset)
    def inner():
        """ Test all variations """
        for i, j in product(range(2), range(1, 3), tqdm_class=tqdm_auto):
            assert i in range(2) and j in range(1, 3)

    inner()

# Generated at 2022-06-26 09:27:14.601935
# Unit test for function product
def test_product():
    with tqdm_auto(total=float('inf')) as t:
        for _ in product(tqdm_auto, tqdm_auto, tqdm_auto, tqdm_auto,
                         tqdm_auto, tqdm_auto, tqdm_auto, tqdm_auto, tqdm_auto,
                         total=0, unit='foo'):
            pass
        t.total = 0
        for _ in product(tqdm_auto, tqdm_auto, tqdm_auto, tqdm_auto,
                         tqdm_auto, tqdm_auto, tqdm_auto, tqdm_auto, tqdm_auto,
                         total=0, unit='foo'):
            pass

# Generated at 2022-06-26 09:27:25.590835
# Unit test for function product
def test_product():
    """
    "Unit" test for function `product`. Tests both the iteration and
    the progress bar (synchronous)
    """
    gen = product(range(3), range(3), range(3), tqdm_class=tqdm_auto)
    exp = list(itertools.product(range(3), range(3), range(3)))
    assert list(gen) == exp
    gen = product(range(13), range(13), range(13), tqdm_class=tqdm_auto)
    exp = list(itertools.product(range(13), range(13), range(13)))
    assert list(gen) == exp

# Generated at 2022-06-26 09:27:33.077744
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import FormatCustomText, format_sizeof

    it = product(np.linspace(0, 1, 100), np.linspace(0, 1, 100),
                 tqdm_class=FormatCustomText)
    for i in it:
        it.set_description_str("%.3f" % i)

    it = product(np.linspace(0, 1, 100), np.linspace(0, 1, 100),
                 tqdm_class=FormatCustomText)
    for i in it:
        it.set_postfix_str(format_sizeof(i), refresh=False)

# Generated at 2022-06-26 09:27:45.304164
# Unit test for function product
def test_product():
    from ..tqdm import trange
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import datetime
    loops = [trange(20), trange(10)]
    # Loops
    _imap = product(*loops, tqdm_class=trange)
    assert list(_imap) == [(i, j) for i in range(20) for j in range(10)]
    assert _imap.n == len(_imap) == 20 * 10 == _imap.total
    # Size of
    _imap = product(*loops, tqdm_class=trange,
                    bar_format=FormatCustomText(format_sizeof))
    next(_imap)
    assert _imap.format

# Generated at 2022-06-26 09:28:37.190103
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, pretest_posttest, _range

    @with_setup(pretest=pretest_posttest[0], posttest=pretest_posttest[1])
    def test_basic():
        """Test basic product"""
        L = list(product(list("ABC"), list("1a")))
        assert L == list(itertools.product("ABC", "1a"))
        assert L[3][0] == 'A'
        assert L[3][1] == 'a'
        assert L[5][1] == 'a'

    @with_setup(pretest=pretest_posttest[0], posttest=pretest_posttest[1])
    def test_params():
        """Test product params"""

# Generated at 2022-06-26 09:28:45.970545
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import FakeTqdmType, kwargs_key

    class FakeTqdm(FakeTqdmType):
        def update(self, n=1):
            self.n += n
            self.last_print_n = self.n

    def test_eq(iter1, iter2, **kwargs):
        """
        Test if `iter1` is equal to `iter2` using kwargs
        """
        n = kwargs.pop("n", 0)
        kwargs["total"] = len(iter2) - n
        return list(product(iter1, **kwargs)) == list(iter2)[n:]


# Generated at 2022-06-26 09:28:56.369727
# Unit test for function product
def test_product():
    """Test function product"""
    from random import randrange
    from itertools import product
    from ..tqdm import trange
    foo = list(range(100))
    for _ in trange(100):
        args = [foo[:randrange(100)] for _ in range(randrange(10))]
        for i, c in zip(product(*args), product(*args)):
            assert i == c
            break
    for i, c in zip(
            product(*args, tqdm_class=trange), product(*args, tqdm_class=trange)
    ):
        assert i == c
        break

# Generated at 2022-06-26 09:29:06.731107
# Unit test for function product
def test_product():
    from math import factorial
    from .tqdm_test_cases import \
        tqdm_kwargs, BaseTestCase, closing, StringIO
    from ..std import StringIO as PatchedStringIO

    for tqdm_func in (tqdm_auto, tqdm_kwargs):
        with closing(StringIO()) as our_file:
            for _ in product(
                    range(8),
                    range(7),
                    range(6),
                    range(5),
                    tqdm=tqdm_func,
                    file=our_file):
                pass

        with closing(StringIO()) as their_file:
            for _ in itertools.product(
                    range(8),
                    range(7),
                    range(6),
                    range(5)):
                pass


# Generated at 2022-06-26 09:29:12.391607
# Unit test for function product
def test_product():
    from . import trange
    with trange(20) as t:
        for i in product(range(2), range(3), tqdm_class=t.__class__):
            pass
        assert t.n == 2 * 3


# Generated at 2022-06-26 09:29:20.199313
# Unit test for function product
def test_product():
    import numpy as np
    # Test basic functionality
    assert list(product(range(3))) == list(itertools.product(range(3)))
    assert list(product(range(3), range(4))) == list(itertools.product(range(3), range(4)))
    # Test finish upon del
    assert np.allclose(
        len(list(product(range(10), range(50), range(100)))), 10 * 50 * 100
    )
    # Test total argument
    with tqdm_auto(total=0) as pbar:
        assert pbar.total == 0
        list(product(range(3), range(4), tqdm_class=tqdm_auto, total=1))



# Generated at 2022-06-26 09:29:27.970547
# Unit test for function product
def test_product():
    """
    Test that we are able to iterate over a product of length `total`
    without error.
    """
    try:
        import numpy
    except ImportError:
        print("Skipping numpy unit test for function product.")
    else:
        for total in (10, 100, 1000):
            for dtype in ("i4", "i8", "f4", "f8"):
                a = numpy.arange(total, dtype=dtype).reshape((int(total**0.5),) * 2)
                with tqdm_auto(total=a.size) as t:
                    for _ in product(*a):
                        t.update()

# Generated at 2022-06-26 09:29:38.443893
# Unit test for function product
def test_product():
    from ..utils import _range
    list(product(_range(3)))

    with tqdm_auto(miniters=2) as t:
        list(t.product("abcdef", repeat=3))
    list(product("abcdef", repeat=3, disable=True))
    with tqdm_auto(total=6**3) as t:
        list(t.product("abcdef", repeat=3))
    with tqdm_auto(total=6**3) as t:
        list(t.product("abcdef", repeat=3))
    with tqdm_auto(total=6**3, miniters=5) as t:
        list(t.product("abcdef", repeat=3))
    with tqdm_auto(total=6**3, miniters=1) as t:
        list

# Generated at 2022-06-26 09:29:48.253548
# Unit test for function product
def test_product():
    """Unit test for function tqdm"""
    from numpy.testing import assert_equal

    assert_equal(
        list(product([])),
        [])
    assert_equal(
        list(product([], repeat=3)),
        [()])
    assert_equal(
        list(product([1, 2], repeat=3)),
        [(1, 1, 1),
         (1, 1, 2),
         (1, 2, 1),
         (1, 2, 2),
         (2, 1, 1),
         (2, 1, 2),
         (2, 2, 1),
         (2, 2, 2)])
    assert_equal(
        list(product([1], repeat=3)),
        [(1, 1, 1)])

# Generated at 2022-06-26 09:29:54.173978
# Unit test for function product
def test_product():
    """
    Simple unittest for function product.

    Returns
    -------
    bool
        Whether unittest is successful.
    """
    iterables = [range(3), [1, 2, 3, 4], ['a', 'b', 'c', 'd']]
    prod = product(*iterables, tqdm_class=tqdm_auto)
    assert list(prod) == list(itertools.product(*iterables))
    return True


if __name__ == '__main__':  # pragma: no cover
    test_product()