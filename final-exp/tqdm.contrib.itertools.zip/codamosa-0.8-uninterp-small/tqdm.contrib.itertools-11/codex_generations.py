

# Generated at 2022-06-26 09:20:08.507204
# Unit test for function product
def test_product():
    a = [1, 2, 3]
    b = [4, 5, 6]
    for p in product(a, b, tqdm_class=tqdm_auto, total=6):
        print(p)
    assert p == (3, 6)

# Generated at 2022-06-26 09:20:20.393264
# Unit test for function product
def test_product():
    """
    Unit test for function product
    See https://docs.python.org/3/library/itertools.html#itertools.product
    """
    # Test for 0 input case
    test_case_0()

    # Test for list input case
    list_case = ['1', '2', '3']
    list_res = ['123', '132', '213', '231', '312', '321']
    i, j = 0, 0
    it = product(list_case)
    while (i < len(list_res)):
        try:
            it.__next__()
            assert list_res[i] == it.__next__()
            i += 1
        except AssertionError as e:
            j += 1

# Generated at 2022-06-26 09:20:25.130053
# Unit test for function product
def test_product():

    # Check default case
    assert next(product()) == ()

    # Check few examples
    assert next(product([0])) == (0,)
    assert next(product([0], [1])) == (0, 1)
    assert next(product([0], [1], [2])) == (0, 1, 2)



# Generated at 2022-06-26 09:20:26.469427
# Unit test for function product
def test_product():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-26 09:20:27.303056
# Unit test for function product
def test_product():
    assert callable(product)

# Generated at 2022-06-26 09:20:33.056692
# Unit test for function product
def test_product():
    import numpy as np

# Generated at 2022-06-26 09:20:34.195860
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:20:39.213078
# Unit test for function product
def test_product():
    from tqdm.contrib.test_utils import DiscreteTest
    for i in DiscreteTest(product,
                          **{'iterable': list(product(range(10)))},
                          ndigits=9,
                          desc='product'):
        pass

# Generated at 2022-06-26 09:20:51.198866
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-26 09:20:59.823212
# Unit test for function product
def test_product():
    def product_generator_gen(iterable, repeat=1):
        pools = [tuple(iterable)] * repeat
        result = [[]]
        for pool in pools:
            result = [x+[y] for x in result for y in pool]
        for prod in result:
            yield tuple(prod)

    class Foo(object):
        def __len__(self):
            return 3

        def __iter__(self):
            yield 1
            yield 2
            yield 3

    for repeat in range(4):
        assert list(itertools.product([1, 2], repeat=repeat)) == \
            list(product([1, 2], repeat=repeat))


# Generated at 2022-06-26 09:21:13.115718
# Unit test for function product
def test_product():
    # Assert that (*(),) == ()
    assert next(product()) == ()
    # Assert that (*((1,),),) == (1,)
    assert next(product((1,))) == (1,)
    # Assert that (*((1, 2),),) == (1, 2)
    assert next(product((1, 2))) == (1,) + (2,)
    # Assert that (*((1, 2), (3, 4)),) == (1, 3)
    assert next(product((1, 2), (3, 4))) == (1,) + (3,)
    # Assert that (*((1, 2), (3, 4)),) == (1, 4)
    assert next(itertools.product((1, 2), (3, 4))) == (1,) + (4,)
    # Assert that (*((1,

# Generated at 2022-06-26 09:21:23.703770
# Unit test for function product
def test_product():
    import itertools as itt

    for tq_cls in [tqdm, tqdm_gui, tqdm_notebook]:
        var_0 = product(tqdm_class=tq_cls, total=3)
        try:
            var_1 = next(var_0)
        except StopIteration:
            pass
        var_2 = list(var_0)
        assert len(var_2) == 2, type(var_2)

        var_0 = product(range(2), tqdm_class=tq_cls, total=2)
        var_2 = list(var_0)
        assert var_2 == list(itt.product(range(2))), var_2
        for var_3 in var_0:
            pass


# Generated at 2022-06-26 09:21:34.344686
# Unit test for function product
def test_product():
    # Get the length of the iterator
    product_test_0 = itertools.product(range(2), range(2), range(2), range(2))
    product_test_1 = product(range(2), range(2), range(2), range(2))
    # Check if all elements are the same, exit if not
    for item_0, item_1 in zip(product_test_0, product_test_1):
        assert item_0 == item_1
    # Get the length of the iterator
    product_test_2 = itertools.product(range(3))
    product_test_3 = product(range(3))
    # Check if all elements are the same, exit if not
    for item_0, item_1 in zip(product_test_2, product_test_3):
        assert item_0

# Generated at 2022-06-26 09:21:38.971857
# Unit test for function product
def test_product():
    assert product([1, 2], [3, 4], [5, 6]) == [(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6), (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)]


# Generated at 2022-06-26 09:21:40.693556
# Unit test for function product
def test_product():
    assert True


# Generated at 2022-06-26 09:21:43.679414
# Unit test for function product
def test_product():
    var_0 = product(iterable='iterable')
    assert iter(var_0) == var_0
    print(var_0)


# Generated at 2022-06-26 09:21:45.932144
# Unit test for function product
def test_product():
    var_0 = product(range(100), range(100), range(100))
    var_1 = next(var_0)

# Generated at 2022-06-26 09:21:51.069273
# Unit test for function product
def test_product():
    x = product(['a', 'b'], range(2), (2, 3))
    assert iterable_eq(x, iter([('a', 0, 2), ('a', 0, 3), ('a', 1, 2), ('a', 1, 3), ('b', 0, 2), ('b', 0, 3), ('b', 1, 2), ('b', 1, 3)]))
    x = product(['a', 'b'], range(2), (2, 3))
    assert next(x) == ('a', 0, 2)
    assert next(x) == ('a', 0, 3)


# Generated at 2022-06-26 09:22:00.075200
# Unit test for function product
def test_product():
    # Test with all optional args set
    var_1 = [[1, 2], [3, 4], [5, 6]]
    var_2 = product(var_1[0], var_1[1], var_1[2], tqdm_class=tqdm_auto)
    assert next(var_2) == (1, 3, 5)
    assert next(var_2) == (1, 3, 6)
    assert next(var_2) == (1, 4, 5)
    assert next(var_2) == (1, 4, 6)
    assert next(var_2) == (2, 3, 5)
    assert next(var_2) == (2, 3, 6)
    assert next(var_2) == (2, 4, 5)

# Generated at 2022-06-26 09:22:11.374072
# Unit test for function product
def test_product():
    def func_0():
        var_0 = product(range(10))
        var_1 = next(var_0)
        assert var_1 == (0,)
        return var_0
    func_0()
    def func_1():
        var_0 = product(range(10))
        var_1 = next(var_0)
        assert var_1 == (0,)
        return var_0
    func_1()
    def func_2():
        var_0 = product(range(10))
        var_1 = next(var_0)
        assert var_1 == (0,)
        return var_0
    func_2()
    def func_3():
        var_0 = product(range(10))
        var_1 = next(var_0)
        assert var_1 == (0,)

# Generated at 2022-06-26 09:22:16.465240
# Unit test for function product
def test_product():
    try:
        itertools.product()
    except Exception as e:
        var = False
    else:
        var = True
    assert var

    try:
        product()
    except Exception as e:
        var = False
    else:
        var = True
    assert var

# Generated at 2022-06-26 09:22:23.313025
# Unit test for function product
def test_product():
    import unittest
    class TestProduct(unittest.TestCase):
        def test_0(self):
            var_0 = None
            expected_0 = None
            assert var_0 == expected_0
        def test_1(self):
            var_0 = None
            expected_0 = None
            assert var_0 == expected_0
    unittest.main()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:22:26.995471
# Unit test for function product
def test_product():
    # Delete existing pkl file
    try:
        os.remove("/data/pkl/product.pkl")
    except:
        pass
    # Create pickle file of function
    function_name = "product"

# Generated at 2022-06-26 09:22:30.204603
# Unit test for function product
def test_product():
    with tqdm_auto(total=1) as t:
        for i in itertools.product():
            assert i is None
            t.update()

# Generated at 2022-06-26 09:22:37.172607
# Unit test for function product
def test_product():
    from unittest import TestCase
    import sys

    class TestCase(TestCase):
        def test_0(self):
            var_0 = product()
            var_1 = next(var_0)

    tst = TestCase()
    tst.test_0()

    with TestCase().assertRaises(AssertionError):
        pass


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:41.205230
# Unit test for function product
def test_product():
    assert isinstance(product(), itertools.product)

test_case_0()
test_product()
test_product()
test_product()

# Generated at 2022-06-26 09:22:45.013027
# Unit test for function product
def test_product():
    it = product(MyRange())
    assert next(it) == (0, 0)
    assert next(it) == (0, 1)
    assert next(it) == (1, 0)
    assert next(it) == (1, 1)



# Generated at 2022-06-26 09:22:49.663331
# Unit test for function product
def test_product():
    with tqdm_auto.tqdm(total=1) as tqdm_instance_0:
        if isinstance(product(), itertools.product):
            var_1 = next(product()).next()
            assert isinstance(var_1, tuple)
        else:
            var_1 = next(product())
            var_2 = next(product())
            assert var_1 == var_2

# Generated at 2022-06-26 09:22:59.586572
# Unit test for function product
def test_product():
    # test_case_0
    var_0 = product()
    var_1 = next(var_0)
    assert var_1 == None # ""
    # test_case_1
    var_0 = product('abc')
    var_1 = [next(var_0) for i in range(9)]
    assert var_1 == ['a', 'b', 'c', 'aa', 'ab', 'ac', 'ba', 'bb', 'bc'] # "['a', 'b', 'c', 'aa', 'ab', 'ac', 'ba', 'bb', 'bc']"
    # test_case_2
    var_0 = product('abc', repeat=2)
    var_1 = [next(var_0) for i in range(9)]

# Generated at 2022-06-26 09:23:09.305263
# Unit test for function product
def test_product():
    # Setup
    iterables = [range(10), ["a", "b", "c"]]

# Generated at 2022-06-26 09:23:22.933934
# Unit test for function product
def test_product():
    # Arguments used for testcase
    iterables = [(0, 1)]
    total_1 = 1
    total_2 = 1
    tqdm_class = tqdm_auto
    tqdm_kwargs = {'total': total_1}
    tqdm_kwargs_for_func = {'tqdm_class': tqdm_class,
                            'total': total_2}
    
    # Call function
    var_0 = product(iterables, **tqdm_kwargs)
    var_1 = product(*iterables, **tqdm_kwargs_for_func)
    
    # Check return type
    assert isinstance(var_0, itertools.product)
    assert isinstance(var_1, itertools.product)
    
    # Check length
    assert len

# Generated at 2022-06-26 09:23:26.420831
# Unit test for function product
def test_product():
    import pytest

    with pytest.raises(TypeError):
        # TypeError: product() takes at least 1 argument (0 given)
        test_case_0()

# Generated at 2022-06-26 09:23:29.721708
# Unit test for function product
def test_product():
    assert next(product([1, 2, 3])) == (1,)
    assert len(list(product([1, 2, 3], repeat=2))) == 9

if __name__ == '__main__':
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:23:41.244819
# Unit test for function product
def test_product():
    var_2 = str(var_1)
    assert ("(())" == var_2)
    var_3 = product(['a', 'b', 'cd'])
    var_4 = next(var_3)
    var_5 = str(var_4)
    assert ("('a',)" == var_5)
    var_6 = next(var_3)
    var_7 = str(var_6)
    assert ("('b',)" == var_7)
    var_8 = next(var_3)
    var_9 = str(var_8)
    assert ("('c',)" == var_9)
    var_10 = next(var_3)
    var_11 = str(var_10)
    assert ("('d',)" == var_11)

# Generated at 2022-06-26 09:23:41.689380
# Unit test for function product
def test_product():
    assert True

# Generated at 2022-06-26 09:23:42.807581
# Unit test for function product
def test_product():
    with pytest.raises(TypeError):
        var_0 = product()


# Generated at 2022-06-26 09:23:52.929926
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy.random import choice
    from numpy.random import rand
    from numpy.random import shuffle
    from numpy import product as np_prod
    from numpy import array as np_array
    from numpy import asarray as np_asarray
    from numpy import cumsum as np_cumsum
    from numpy import random as np_random
    from numpy import exp as np_exp
    from numpy import linspace as np_linspace
    from numpy import sign as np_sign
    from numpy import maximum as np_maximum
    from numpy import floor as np_floor
    from numpy import set_printoptions as np_set_printoptions
    from types import GeneratorType
    from copy import copy
    from math import floor
    from math import ceil

# Generated at 2022-06-26 09:23:56.854696
# Unit test for function product
def test_product():
    var_4 = list(map(len, (x for x in range(10))))
    var_5 = 1
    for i in var_4:
        var_5 *= i
    var_3 = list(product(x for x in range(10)))
    var_2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert var_2 == var_3
    assert var_2 == var_3

# Compatibility with Python 3.5, 3.4, 3.3, 3.2
# and 2.7

# Generated at 2022-06-26 09:24:04.391446
# Unit test for function product
def test_product():
    a1 = range(10)
    a2 = 'hello'
    with tqdm_auto(unit='B', unit_scale=True, leave=False) as t:
        for i, j in product(a1, a2):
            pass


if __name__ == "__main__":
    from os.path import abspath
    from sys import argv
    if len(argv) > 1:
        file = abspath(argv[1])
    else:
        file = abspath(__file__.replace('_doctest.py', '.py'))
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE, verbose=True)
    # doctest.testfile(filename=file, module_relative=True, optionflags=doctest

# Generated at 2022-06-26 09:24:12.121763
# Unit test for function product
def test_product():
    # Arrange
    import numpy as np
    from tqdm.contrib.itertools import product
    dummy_iterator = np.arange(10).reshape(5,2)
    # Act
    iterator_output = product(dummy_iterator)

    # Assert
    dummy_output = np.array([[0, 0],[0, 1],[1, 0],[1, 1],[2, 0],[2, 1],[3, 0],[3, 1],[4, 0],[4, 1]])
    assert(np.array_equal(np.array(iterator_output).reshape(10,2),dummy_output))

# Generated at 2022-06-26 09:24:16.345249
# Unit test for function product
def test_product():
    iterables = [range(10)]
    product(*iterables)


# Generated at 2022-06-26 09:24:24.054076
# Unit test for function product
def test_product():
    assert next(product()) == ()
    assert list(product([1, 2], [1, 2])) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product(range(3), ['a', 'b', 'c'])) == [
        (0, 'a'), (0, 'b'), (0, 'c'), (1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'),
        (2, 'b'), (2, 'c')]


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:24:35.495952
# Unit test for function product
def test_product():
    import sys
    import shutil


# Generated at 2022-06-26 09:24:36.826623
# Unit test for function product
def test_product():
    # Test function case 0
    test_case_0()

# Generated at 2022-06-26 09:24:42.865558
# Unit test for function product
def test_product():
    # A
    var_0 = product(*[range(10)])
    var_1 = next(var_0)
    var_2 = next(var_0)
    # B
    var_3 = product(*[range(10)], tqdm_class=tqdm_auto)
    var_4 = next(var_3)
    var_5 = next(var_3)
# test_case_0()

# Generated at 2022-06-26 09:24:53.324093
# Unit test for function product
def test_product():
    assert next(product("", range(1))) == ('', 0)
    assert list(product("ABC", "xy")) == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'), ('C', 'y')]
    assert sorted(list(product(range(2), repeat=3))) == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-26 09:25:01.228554
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ...contrib.utils.testing import TestCase

    class test_product(TestCase):
        def test_output_type(self):
            """
            Test output type
            """
            it = product('ABC', '123', 'XY')
            assert isinstance(it, type(iter([])))

        def test_output(self):
            """
            Test output
            """
            it = product('ABC')
            assert set(it) == set('ABC')

            it = product('ABC', '123')
            assert set(it) == set(a + b for a in 'ABC' for b in '123')

            it = product('ABC', '123', 'XY')

# Generated at 2022-06-26 09:25:03.336024
# Unit test for function product
def test_product():
    assert str(product()) == '<generator object product at 0x7f1508e887d0>'

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:25:07.659539
# Unit test for function product
def test_product():
    var_0 = product(range(10), range(1, 10))
    var_1 = next(var_0)
    assert var_1 == (0, 1)

# Generated at 2022-06-26 09:25:14.574460
# Unit test for function product
def test_product():
    """Unit test for function product"""

    from tqdm.test import _range
    assert list(product(_range(3))) == [(0,), (1,), (2,)]
    assert list(product(_range(3), _range(3))) == [(0, 0), (0, 1), (0, 2),
                                                   (1, 0), (1, 1), (1, 2),
                                                   (2, 0), (2, 1), (2, 2)]
    return

# Generated at 2022-06-26 09:25:24.337346
# Unit test for function product
def test_product():
    a = [1, 2, 3, 4, 5]
    b = ['a', 'b', 'c', 'd']
    c = ['!', '@', '#', '$']
    with tqdm_auto(unit_scale=True) as t:
        for i in product(a, b, c, tqdm_class=t.__class__):
            pass

# Generated at 2022-06-26 09:25:29.183691
# Unit test for function product
def test_product():
    for p00 in product([0]):
        assert next((p00,)) == (0,)
    for p00 in product([1]):
        assert next((p00,)) == (1,)
    for p00 in product([1, 2]):
        assert next((p00,)) in [(1,), (2,)]
    for p00 in product([1, 2], repeat=0):
        assert next((p00,)) == ()
    for p00 in product([1, 2]):
        assert next((p00,)) in [(1,), (2,)]
    for p00 in product([1, 2], repeat=1):
        assert next((p00,)) in [(1,), (2,)]

# Generated at 2022-06-26 09:25:34.923312
# Unit test for function product
def test_product():
    ret = product(range(2), range(2))
    assert next(ret) == (0, 0)
    assert next(ret) == (0, 1)
    assert next(ret) == (1, 0)
    assert next(ret) == (1, 1)
    assert next(ret, None) is None  # StopIteration

# Generated at 2022-06-26 09:25:36.969961
# Unit test for function product
def test_product():
    assert test_case_0() is None, "Failed testing case 0"

# Generated at 2022-06-26 09:25:39.700161
# Unit test for function product
def test_product():
    var_0 = product("abcde", "12345")
    var_1 = next(var_0)

# Generated at 2022-06-26 09:25:44.945711
# Unit test for function product
def test_product():
    try:
        # Testing default parameters
        var_1 = product(range(7))
        assert type(var_1) is itertools.product
        assert var_1 is not None
    except Exception as e:
        print(e)
        assert False


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:25:56.916515
# Unit test for function product
def test_product():
    # Test the number of iterables
    assert list(product([])) == []
    assert list(product([0], [1], [2])) == [(0, 1, 2)]

    # Test the iterable values
    assert list(product([0, 1])) == [(0, ), (1, )]
    assert list(product([0, 1], [0, 1], [0, 1])) == [
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0),
        (1, 0, 1), (1, 1, 0), (1, 1, 1)
    ]

    # Test the tqdm_class
    from . import tqdm_class_mod


# Generated at 2022-06-26 09:26:05.212962
# Unit test for function product
def test_product():
    # Unit: default
    #  Expect: list of all combinations (2 by 3).
    #  Result: list of all combinations.
    assert list(
        product(tqdm_class=None,
                iterables=[[0, 1], [-1, 0, 1]])) == [
            (0, -1), (0, 0), (0, 1), (1, -1), (1, 0), (1, 1)]


if __name__ == "__main__":
    import pytest  # NOQA

    pytest.main([__file__])

# Generated at 2022-06-26 09:26:16.350793
# Unit test for function product
def test_product():
    # Get a list of all the results
    results = list(product([1, 2, 3, 4], [5, 6, 7, 8]))

    # Get the expected results
    expected_results = [(1, 5), (1, 6), (1, 7), (1, 8), (2, 5), (2, 6),
                        (2, 7), (2, 8), (3, 5), (3, 6), (3, 7), (3, 8),
                        (4, 5), (4, 6), (4, 7), (4, 8)]
    results = [list(result) for result in results]

    # Compare the results to the expected results
    assert results == expected_results

    # Get a list of all the results
    results = list(product([1, 2, 3], [4, 5]))

    # Get the

# Generated at 2022-06-26 09:26:22.396413
# Unit test for function product
def test_product():
    try:
        assert callable(product)
        assert hasattr(product, "__call__")
    except AssertionError:
        raise AssertionError("<strong>product</strong> is not callable, should be")
    else:
        return True



# Generated at 2022-06-26 09:26:26.847548
# Unit test for function product
def test_product():
    """Unit test for function product"""
    test_case_0()


# Generated at 2022-06-26 09:26:32.486328
# Unit test for function product
def test_product():
    import numpy
    numpy.random.seed(123)  # for reproducibility
    it = product(range(10000), range(10000))
    L = [next(it) for _ in range(1000000)]
    L = numpy.asarray(L)
    assert all(L == numpy.sort(L, axis=0))


if __name__ == "__main__":
    import platform
    print("Python v{0}".format(platform.python_version()))
    import doctest
    doctest.testmod()
    test_product()

# Generated at 2022-06-26 09:26:34.594032
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:26:46.815004
# Unit test for function product
def test_product():
    import tqdm

    for tqdm_class in (tqdm.tqdm, tqdm.trange):
        lst = list(product(
            range(3), repeat=3, tqdm_class=tqdm_class))
        assert len(lst) == 3 * 3 * 3
        lst = list(product(
            range(4), range(4), tqdm_class=tqdm_class))
        assert len(lst) == 4 * 4
        lst = list(product(
            (1, 2), range(4), tqdm_class=tqdm_class))
        assert len(lst) == 2 * 4
        lst = list(product(
            range(3), range(4), range(5), tqdm_class=tqdm_class))
       

# Generated at 2022-06-26 09:26:57.064359
# Unit test for function product
def test_product():
    """
    Unit test for function product

    See Also
    --------
    :func:`tqdm.utils.product`
        Same function with `__name__ == "tqdm.utils.product"`
    """
    try:
        from _tqdm import _product
    except ImportError:
        from ._tqdm_gui import _product

    var_0 = list(range(100))
    var_1 = list(range(100))
    var_2 = list(range(100))

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

        # Check that both behave the same
        from nose.tools import assert_equal
        assert_equal(list(product(var_0, var_1, var_2)),
                     list(_product(var_0, var_1, var_2)))

# Generated at 2022-06-26 09:27:05.798681
# Unit test for function product
def test_product():
    from itertools import product
    def test_iterable(iter_0):
        assert list(product(iter_0)) == [('a', 0), ('a', 1), ('b', 0), ('b', 1)]

    test_iterable(('a', 'b'))
    test_iterable(('a', 'b', 'c', 'd'))
    test_iterable(('a', 'b', 'c', 'd', 'e'))
    test_iterable(('a', 'b', 'c', 'd', 'e', 'f'))
    test_iterable(('a', 'b', 'c', 'd', 'e', 'f', 'g'))
    test_iterable(('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'))
    test

# Generated at 2022-06-26 09:27:13.314431
# Unit test for function product
def test_product():
    inputs = [[1,2,3],[5,6,7]]
    expected_outputs = [(1, 5), (1, 6), (1, 7), \
                        (2, 5), (2, 6), (2, 7), \
                        (3, 5), (3, 6), (3, 7)]

    actual_outputs = list(product(*inputs))

    assert(sorted(expected_outputs) == sorted(actual_outputs))

# Generated at 2022-06-26 09:27:26.497683
# Unit test for function product
def test_product():
    from unittest import TestCase
    from io import StringIO

    class TestCase0(TestCase):
        def test_0(self):
            def f():
                yield 0
            
            var_0 = product(f())
            var_1 = next(var_0)
            self.assertEqual(var_1, 0)
            var_2 = next(var_0, None)
            self.assertEqual(var_2, None)
    

# Generated at 2022-06-26 09:27:34.846024
# Unit test for function product
def test_product():
    var_0 = list(product())
    list_0 = [ () ]
    assert var_0 == list_0
    
    var_1 = list(product([1, 2, 3]))
    list_1 = [(1,), (2,), (3,)]
    assert var_1 == list_1
    
    var_2 = list(product([1, 2, 3], repeat=2))
    list_2 = [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
    assert var_2 == list_2
    
    var_3 = list(product([1, 2, 3], [4, 5]))

# Generated at 2022-06-26 09:27:37.296775
# Unit test for function product
def test_product():
    assert next(product(range(5), repeat=2)) == (0,0)

# Generated at 2022-06-26 09:27:44.493187
# Unit test for function product
def test_product():
    for loop in product(range(10), range(10)):
        assert len(loop) == 2, loop

# Generated at 2022-06-26 09:27:54.569627
# Unit test for function product
def test_product():
    """
    Unit tests for function product
    """
    v1 = product()
    v2 = next(v1)
    assert v2 is None
    v3 = product([0, 1, 2], [0, 1, 2])
    v4 = list(v3)
    v5 = [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]
    assert v4 == v5
    v6 = product(['a', 'b', 'c'], repeat=2)
    v7 = list(v6)

# Generated at 2022-06-26 09:28:04.316050
# Unit test for function product
def test_product():
    # Unit test for function product
    var_0 = product(range(10000), range(10000), range(10000))
    var_1 = next(var_0)
    assert var_1 == (0, 0, 0)
    var_2 = next(var_0)
    assert var_2 == (0, 0, 1)
    var_3 = next(var_0)
    assert var_3 == (0, 0, 2)
    var_4 = next(var_0)
    assert var_4 == (0, 0, 3)
    var_5 = next(var_0)
    assert var_5 == (0, 0, 4)

# Generated at 2022-06-26 09:28:10.861852
# Unit test for function product
def test_product():
    import numpy as np
    from tqdm import tqdm

    for i in tqdm(product(range(10), range(10), range(10),
                         tqdm_class=tqdm,
                         total=1000)):
        pass

# Generated at 2022-06-26 09:28:17.451208
# Unit test for function product
def test_product():
    """
    Unit test of function product
    @return:
    """
    iterable = ["abcdefghijklmnopqrstuvwxyz"]
    var_0 = product(*iterable)
    assert isinstance(var_0, itertools.product)
    var_1 = next(var_0)
    assert isinstance(var_1, tuple)
    assert len(var_1) == len(iterable)
    assert var_1 == ("a", )
    assert next(var_0) == ("b", )
    var_nex = next(var_0)
    assert var_nex == ("c", )
    var_2 = next(var_0)
    assert var_2 == ("d", )
    var_3 = next(var_0)
    assert var_3 == ("e", )


# Generated at 2022-06-26 09:28:29.311552
# Unit test for function product
def test_product():
    assert next(product(range(3))) == (0,)
    assert next(product(range(3), repeat=2)) == (0, 0)
    assert next(product(range(3), range(3), repeat=2)) == (0, 0, 0, 0)
    assert next(product(range(3), range(3), range(3))) == (0, 0, 0)
    assert len(list(product(range(3), range(3), range(3)))) == 3 * 3 * 3
    assert len(list(product(range(10), range(10), range(10), repeat=3))) == 1000
    if __name__ == "__main__":
        test_case_0()

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:28:32.900290
# Unit test for function product
def test_product():
    assert isinstance(product(), itertools.product), "Check that the product() produces a valid output"

# Generated at 2022-06-26 09:28:38.951176
# Unit test for function product
def test_product():
    """Test for product
    """

    data_inp = list('1234')

# Generated at 2022-06-26 09:28:45.657176
# Unit test for function product
def test_product():
    # Arguments used by the caller report template
    test_case_0()

    # Additional tests
    try:
        from itertools import tee
    except ImportError:
        import warnings
        warnings.warn("Cannot test with `itertools.tee`")
        return
    else:
        list_0 = list(tee([0, 1, 2], count=4))
        var_2 = (0, 0, 0, 0)
        for i in product(*list_0):
            assert i == var_2
            var_2 = (var_2[1], var_2[2], var_2[3], var_2[0])

# Generated at 2022-06-26 09:28:57.574918
# Unit test for function product
def test_product():
    import pytest
    import tqdm

    with pytest.raises(TypeError):
        for _ in product(l=[1]):
            pass
    assert [i for i in product([1], [2])] == [(1, 2)]
    assert [i for i in product([1], [2], [3])] == [(1, 2, 3)]
    assert [i for i in product([1], [2], [3])] == [(1, 2, 3)]
    assert [i for i in product([1], [2], repeat=1)] == [(1, 2)]
    assert [i for i in product([1], [2], repeat=2)] == [(1, 1), (1, 2), (2, 1),
                                                        (2, 2)]


# Generated at 2022-06-26 09:29:17.526833
# Unit test for function product
def test_product():
    """
    test_product
    """
    g = product(xrange(1, 9), xrange(1, 5), xrange(1, 5), tqdm_class=tqdm_auto)

# Generated at 2022-06-26 09:29:24.243843
# Unit test for function product
def test_product():
    def test_case_0():
        var_0 = product()
        var_1 = next(var_0)
    def test_case_1():
        var_0 = product('ABCD', 'xy')
        var_1 = next(var_0)
    def test_case_2():
        var_0 = product(range(2), repeat=3)
        var_1 = next(var_0)
    def test_case_3():
        var_0 = product(range(3), repeat=4)
        var_1 = next(var_0)
    def test_case_4():
        var_0 = product(range(5), repeat=6)
        var_1 = next(var_0)
    def test_case_5():
        var_0 = product(range(7), repeat=8)

# Generated at 2022-06-26 09:29:28.127117
# Unit test for function product
def test_product():
    total = 10
    var_0 = product(list(range(total)))
    var_1 = [i for i in var_0]
    var_2 = next(var_0)

    assert var_2 == None,   "The function product is not returning the expected result"
    assert len(var_1) == total,   "The function product is not returning the expected result"




if __name__ == "__main__":
    test_product()
    test_case_0()

# Generated at 2022-06-26 09:29:34.428609
# Unit test for function product
def test_product():
    assert next(product(range(10))) == (0,)
    assert next(product(range(10), range(10))) == (0, 0)
    assert next(product(range(1), range(10))) == (0, 0)
    assert next(product(range(10), range(1))) == (0, 0)

# Generated at 2022-06-26 09:29:38.824599
# Unit test for function product
def test_product():
    from .common import TestCase

    with TestCase() as testcase:
        with testcase.assertRaises(TypeError):
            next(product())

# Generated at 2022-06-26 09:29:48.440621
# Unit test for function product
def test_product():
    # Test no iterables
    var_0 = product()
    var_1 = next(var_0)
    assert var_1 == ()
    # Test one iterable
    var_2 = product('abc')
    var_3 = next(var_2)
    assert var_3 == 'a'
    var_4 = next(var_2)
    assert var_4 == 'b'
    var_5 = next(var_2)
    assert var_5 == 'c'
    # Test two iterables
    # 2
    var_6 = product('abc', '12')
    var_7 = next(var_6)
    assert var_7 == ('a', '1')
    var_8 = next(var_6)
    assert var_8 == ('a', '2')

# Generated at 2022-06-26 09:29:59.051510
# Unit test for function product
def test_product():

    # Test with 0 iterables
    assert list(product()) == [()]

    # Test with 1 iterable
    assert list(product([1], repeat=1)) == [(1,)]
    assert list(product([1, 2], repeat=1)) == [(1,), (2,)]

    # Test with 2 iterables
    assert list(product([1], repeat=2)) == [(1, 1)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]

    # Test with 3 iterables
    assert list(product([1], repeat=3)) == [(1, 1, 1)]

# Generated at 2022-06-26 09:30:02.790760
# Unit test for function product
def test_product():
    assert product(["hello", "world"]) == product(["hello", "world"])

if __name__ == "__main__":
    test_product()