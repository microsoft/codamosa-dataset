

# Generated at 2022-06-26 09:20:01.460963
# Unit test for function product
def test_product():
    assert True



# Generated at 2022-06-26 09:20:11.580975
# Unit test for function product
def test_product():
    from unittest import TestCase
    from ..tests import tqdm_class
    from ..tests import tqdm_class_dict
    from ..tests import tqdm_class_list

    # Base class
    tqdm_class_set = set(tqdm_class_dict.values())
    assert issubclass(tqdm_class, tqdm_class_set)

    # Default instance
    tqdm_default_inst_set = set(tqdm_class_dict.keys())
    assert tqdm_auto.default_inst in tqdm_default_inst_set

    # tqdm_class
    class_str = "tqdm_class"
    test_case = TestCase()

# Generated at 2022-06-26 09:20:23.766391
# Unit test for function product
def test_product():
    from itertools import product, islice
    from ..utils import StringIO, _range

    # test with no iterables
    with _range(101) as rng:
        assert tuple(product()) == ((),)
        assert tuple(islice(product(), 0, 101)) == ()
        assert tuple(rng) == ()

    # test with one iterable
    with _range(101) as rng:
        assert tuple(islice(product('a'), 0, 101)) == tuple('a' for _ in range(101))
        assert tuple(rng) == ()
    with _range(101) as rng:
        assert tuple(product('a')) == ('a',)
        assert tuple(islice(product('a'), 0, 101)) == ('a',)
        assert tuple(rng) == ('a',)


# Generated at 2022-06-26 09:20:24.789438
# Unit test for function product
def test_product():
    var_0 = product()


# Generated at 2022-06-26 09:20:29.431958
# Unit test for function product
def test_product():
    # Test with a tuple as a argument
    # Test with a list as a argument
    # Test with a sequence as a argument
    # Test with a set as a argument
    # Test with a frozenset as a argument
    # Test with a dictionary as a argument
    # Test with a generator as a argument
    # Test with a custom object as a argument
    # Test with a iterable object as a argument
    pass

# Generated at 2022-06-26 09:20:34.688248
# Unit test for function product
def test_product():
  # Set up test inputs
  iterables = ([1, 2], ['a', 'b', 'c'])

  # Call function
  var_out1, var_out2 = product(*iterables)

  # Check function outputs
  assert var_out1 == iter([1, 'a'])
  assert var_out2 == iter([1, 'b'])

# Generated at 2022-06-26 09:20:46.249849
# Unit test for function product
def test_product():
    assert all(i == j for i, j in zip(product(range(n)) for n in range(1, n_test)))
    assert all(i == j for i, j in zip(product(range(n), range(n)) for n in range(1, n_test)))
    assert all(i == j for i, j in zip(product(range(n), range(n)) for n in range(1, n_test)))
    assert all(i == j for i, j in zip(product(range(n), range(n), range(n)) for n in range(1, n_test)))
    assert all(i == j for i, j in zip(product(range(n), repeat=n) for n in range(1, n_test)))


# Generated at 2022-06-26 09:20:51.297866
# Unit test for function product
def test_product():
    for i in product([1, 2], ['a', 'b'], [1, 2, 3]):
        pass
    for i in product(range(100)):
        pass
    for i in product(list(tqdm_auto.trange(100))):
        pass

# Generated at 2022-06-26 09:20:59.823351
# Unit test for function product
def test_product():
    assert len(list(product(range(2), range(2)))) == 4
    assert len(list(product(range(2), range(2), tqdm_class=False))) == 4
    assert len(list(product(range(2), range(2), tqdm_class=True))) == 4
    assert len(list(product(range(2), range(2), tqdm_class=tqdm_auto))) == 4
    assert len(list(product(range(2), range(2), tqdm_class=tqdm_auto, total=3))) == 4
    assert len(list(product(range(2), range(2)))) == 4
    assert len(list(product(range(2), range(2), tqdm_class=False, postfix='__'))) == 4

# Generated at 2022-06-26 09:21:00.721526
# Unit test for function product
def test_product():
    assert True == True

# Generated at 2022-06-26 09:21:07.545886
# Unit test for function product
def test_product():
    try:
        test_case_0()
        print('test_case_0 passed')
    except:
        print('test_case_0 failed')

# Generated at 2022-06-26 09:21:18.730468
# Unit test for function product
def test_product():
    from ...._tqdm import tqdm

    from operator import mul
    from functools import reduce
    from numpy.random import randint
    from numpy import unique

    # Examples

    # >>> lis = [range(10), range(20), range(30)]
    # >>> list(itertools.product(*lis))
    # [(0, 0, 0), (0, 0, 1), (0, 0, 2), ..., (9, 19, 27), (9, 19, 28), (9, 19, 29)]

    # >>> lis2 = [range(12), range(10), range(5), range(8)]
    # >>> list(itertools.product(*lis2))
    # [(0, 0, 0, 0), (0, 0, 0, 1), (0, 0, 0, 2), ...,

# Generated at 2022-06-26 09:21:22.049866
# Unit test for function product
def test_product():
    assert (tuple(product(range(101))) == tuple(itertools.product(range(101))))
    assert (tuple(product(range(101), range(101))) == tuple(itertools.product(range(101), range(101))))

# Generated at 2022-06-26 09:21:33.252935
# Unit test for function product
def test_product():
    from hypothesis import given
    from hypothesis.strategies import lists, integers
    from pymaptools import compose, compose_right
    import itertools
    import operator

    def list_str(x):
        return list(map(str, x))

    def list_product(x):
        return list(map(tuple, x))

    @given(lists(lists(integers(), min_size=1), min_size=1))
    def test_compare_implementations(ls):
        assert list_product(map(list_str, product(*ls))) == list_product(map(list_str, itertools.product(*ls)))

# Generated at 2022-06-26 09:21:39.175393
# Unit test for function product
def test_product():
    from inspections import *
    from tqdm import *

    with redirect_stdout(open(os.devnull, "w")):
        var_0 = product(range(50), range(50), range(50), tqdm=tqdm, total=50000)
        var_1 = tuple(var_0)

    assert_equals(len(var_1), 125000)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:21:46.060626
# Unit test for function product
def test_product():
    var_21 = (("aa","ab"),("X","Y"))
    var_20 = product(*var_21)
    var_22 = list(var_20)
    var_23 = [("aa","X"),("aa","Y"),("ab","X"),("ab","Y")]
    assert var_22 == var_23

if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:21:47.599006
# Unit test for function product
def test_product():
    from tqdm import tqdm
    from .._tqdm import tqdm
    #assert False
    pass

# Generated at 2022-06-26 09:21:52.416201
# Unit test for function product
def test_product():
    with tqdm(total=101) as pbar:
        # Create generator
        pbar.update(101)
        # Assertion
        pbar.update(1)


# Generated at 2022-06-26 09:21:58.306649
# Unit test for function product
def test_product():
    from random import random, randint

    #pylint: disable=undefined-loop-variable
    for i in range(1000):
        num = randint(1, 3)
        iters = [range(randint(1, 10)) for _ in range(num)]
        #pylint: disable=redefined-outer-name
        it = product(*iters)
        assert len(tuple(it)) == len(tuple(itertools.product(*iters)))


# Generated at 2022-06-26 09:22:05.966365
# Unit test for function product
def test_product():
    """
    Test unit for function product
    """
    var_0 = product()
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)
    int_1 = 0
    assert (var_1 == ((),))
    assert (var_2 == range(int_0))
    assert (int_1 == 0)
    print("Passed!")
    
    
if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:08.800219
# Unit test for function product
def test_product():
    test_case_0()

# Create a test case

# Generated at 2022-06-26 09:22:20.776700
# Unit test for function product
def test_product():
    bool_0 = False
    bool_1 = False
    str_0 = '"f8d87d43-e7d8-44e9-93a3-0329c077d8f2"'
    tuple_0 = (1, 2, 3, 4, 5)
    tuple_2 = (2, 2, 2)
    tuple_1 = (tuple_0, tuple_2)
    for var_0 in product(*tuple_1):
        bool_1 = True
    bool_2 = True
    if product():
        bool_2 = False
    bool_3 = not bool_0
    if not bool_3 and bool_2:
        raise ValueError(str_0)
    if not bool_1:
        raise ValueError(str_0)


# Generated at 2022-06-26 09:22:23.353761
# Unit test for function product
def test_product():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 09:22:28.578202
# Unit test for function product
def test_product():
    try:
        from collections import Iterable
    except ImportError:
        from collections.abc import Iterable # Python 3
    # Iterable
    for i in range(10):
        for j in range(i):
            assert tuple(product(range(i), range(j))) == tuple(itertools.product(range(i), range(j)))
    # Non-Iterable
    assert tuple(product(9)) == tuple(itertools.product(9))


# Generated at 2022-06-26 09:22:30.540129
# Unit test for function product
def test_product():
    tqdm_test_fct(lambda: test_case_0())

# Generated at 2022-06-26 09:22:39.750227
# Unit test for function product
def test_product():
    from collections import OrderedDict
    from itertools import permutations

    def test(a, b, kwargs_list):
        for kwargs in kwargs_list:
            with tqdm_auto(**kwargs) as t:
                for i in t:
                    pass
        for kwargs in kwargs_list:
            kwargs['iterable'] = a
            with tqdm_auto(**kwargs) as t:
                for i in t:
                    pass

    def test1(a):
        test(a, None, [{'iterable': a}, OrderedDict()])

    def test2(a, b):
        test(a, b, [{'total': len(i) for i in (a, b)}])

    test1(range(100))
    test

# Generated at 2022-06-26 09:22:44.528378
# Unit test for function product
def test_product():
    from copy import deepcopy
    from random import random, randint
    from itertools import chain, product, repeat
    from math import factorial

    def primes(n=10**4):
        """Sieve of Eratosthenes"""
        sieve = [True] * n
        for i in range(3, int(n ** 0.5) + 1, 2):
            if sieve[i]:
                sieve[i * i::2 * i] = [False] * ((n - i * i - 1) // (2 * i) + 1)
        return [2] + [i for i in range(3, n, 2) if sieve[i]]

    def match_product(it, n, length):
        """Test if `it` matches itertools.product(range(n), repeat=length)"""
       

# Generated at 2022-06-26 09:22:50.906571
# Unit test for function product
def test_product():
    import sys

    saved_stdout = sys.stdout
    try:
        from StringIO import StringIO
        out = StringIO()
        sys.stdout = out
        test_case_0()
        sys.stdout = saved_stdout
    except ImportError:
        from io import StringIO
        out = StringIO()
        sys.stdout = out
        test_case_0()
        sys.stdout = saved_stdout
    output = out.getvalue().strip().split("\n")
    assert(len(output)==1)
    assert(101==len(tuple(product())))

# Generated at 2022-06-26 09:22:58.661080
# Unit test for function product
def test_product():
    var_3 = product(range(10))
    var_4 = tuple(var_3)
    var_5 = product(range(10), range(10))
    var_6 = tuple(var_5)
    var_7 = product(range(10), range(10), range(10))
    var_8 = tuple(var_7)
    int_1 = 1000000
    var_9 = product(range(int_1), range(int_1))
    var_10 = tuple(var_9)

if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:23:02.303539
# Unit test for function product
def test_product():
    var_0 = product((2, 3), (1, 2))
    var_1 = tuple(var_0)
    var_2 = product((2, 3), (1, 2))
    var_3 = tuple(var_2)
    var_4 = product((2, 3), (1, 2), (1, 2), (1, 2))
    var_5 = tuple(var_4)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:10.817111
# Unit test for function product
def test_product():
    # Get the generated objects according to a function.
    # Compare the returned object with its expected value.
    list_0 = []
    list_1 = []
    tuple_0 = (1, 2)
    tuple_1 = (3, 4)
    tuple_2 = (5, 6)
    tuple_3 = (7, 8)
    for var_0 in product(tuple_0, tuple_1, tuple_2, tuple_3):
        list_0.append(var_0)
    
    for var_0 in itertools.product(tuple_0, tuple_1, tuple_2, tuple_3):
        list_1.append(var_0)
    
    assert list_0 == list_1
    
    # Get the generated objects according to a function.
    # Compare the returned object with its expected

# Generated at 2022-06-26 09:23:23.039142
# Unit test for function product
def test_product():
    pass
    # pylint: disable=no-member
    # var_0 = product()
    # var_1 = tuple(var_0)
    # int_0 = 101
    # var_2 = range(int_0)
    # var_3 = list(var_1)
    # var_4 = (var_1,)
    # var_5 = product(var_4, var_2)
    # var_6 = tuple(var_5)
    # var_7 = list(var_6)
    # var_8 = tuple(var_7)
    # var_9 = product()
    # var_10 = tuple(var_9)
    # var_11 = list(var_10)
    # var_12 = (var_7, var_11)
    # var_13 = product(var

# Generated at 2022-06-26 09:23:26.362542
# Unit test for function product
def test_product():
    """Verifies that result from product is correct"""
    expected = [(2, 4), (2, 5), (3, 4), (3, 5)]

    result = product([2, 3], [4, 5])
    assert tuple(result) == expected



# Generated at 2022-06-26 09:23:33.986829
# Unit test for function product
def test_product():
    import random

    iter_0 = range(10)
    iter_1 = range(1000)
    iter_2 = range(10)
    iter_3 = range(100)

    with tqdm_auto(total=10 * 1000 * 10 * 100) as t:
        for i in product(iter_0, iter_1, iter_2, iter_3):
            t.update()

    with tqdm_auto(total=10 * 1000 * 10 * 100) as t:
        for i in product(iter_2, iter_3, iter_0, iter_1):
            t.update()


# Generated at 2022-06-26 09:23:42.894701
# Unit test for function product
def test_product():
    # Try with just *iterables
    var_0 = product(range(2), range(2))
    var_1 = tuple(var_0)
    int_0 = 0
    dict_0 = {int_0: (0, 0), int_0 + 1: (0, 1), int_0 + 2: (1, 0), int_0 + 3: (1, 1)}
    for var_3 in dict_0:
        assert dict_0[var_3] == var_1[var_3]

    # Try with *iterables, tqdm_class
    var_0 = product(range(2), range(2), tqdm_class=tqdm_auto)
    var_1 = tuple(var_0)
    int_0 = 0

# Generated at 2022-06-26 09:23:52.961194
# Unit test for function product
def test_product():
    # Raises tqdm.TqdmTypeError if no iterables provided
    try:
        test_case_0()
    except tqdm_auto.TqdmTypeError:
        bool_0 = True
    else:
        bool_0 = False
    assert bool_0
    # Check total in tqdm if all iterables have fixed length
    var_3 = product(range(100), range(100))
    int_1 = 100
    int_2 = 100
    int_3 = 9901
    assert tqdm_auto.get_total(var_3) == int_1 * int_2

    # Check total in tqdm if some iterable has variable length
    var_4 = product(range(int_1), range(int_3))

# Generated at 2022-06-26 09:23:58.389674
# Unit test for function product
def test_product():
    counter = 0
    for var_3 in product():
        pass
    for var_4 in product():
        pass
    for var_5 in product():
        pass
    for var_6 in product():
        pass
    for var_7 in product():
        pass
    for var_8 in product():
        pass
    for var_9 in product():
        pass
    for var_10 in product():
        pass
    for var_11 in product():
        pass
    for var_12 in product():
        pass
    for var_13 in product():
        pass
    for var_14 in product():
        pass
    for var_15 in product():
        pass
    for var_16 in product():
        pass
    for var_17 in product():
        pass
    for var_18 in product():
        pass

# Generated at 2022-06-26 09:24:00.792443
# Unit test for function product
def test_product():
    try:
        assert ('test_cases_product_test_case_0' in globals())
    except:
        pass
    else:
        test_cases_product_test_case_0()

# Generated at 2022-06-26 09:24:12.375885
# Unit test for function product
def test_product():

    import operator as op
    import numpy as np

    assert tuple(product([1], ["a", "b", "c"])) == ((1, 'a'), (1, 'b'), (1, 'c'))
    assert list(product([1, 2], ["a", "b", "c"])) == [(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b'), (2, 'c')]
    assert tuple(product([1, 2, 3], ["a", "b"])) == ((1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b'))
    assert sum(1 for _ in product(range(1000), repeat=10)) == op.pow(10, 1000)
   

# Generated at 2022-06-26 09:24:13.763903
# Unit test for function product
def test_product():
    product()

# Generated at 2022-06-26 09:24:21.754425
# Unit test for function product
def test_product():
    try:
        assert str(type(product())) == "<class 'itertools.product'>"
    except Exception as exc:
        print('AssertionError:', exc)


# Generated at 2022-06-26 09:24:34.917996
# Unit test for function product
def test_product():
    ## -- Check that mixing iterables and non-iterables is not allowed
    # def runner():
    #     prod = product(range(3), 4, [5, 6], [7])
    #     next(prod)
    # # runner()
    # # -- Check that all those types of sub-iterables are accepted
    # def runner():
    #     prod = product(range(3), (4,), [5, 6], set([7]))
    #     next(prod)
    # # runner()
    ## -- Check that empty product is specified as empty tuple
    var_0 = product(())
    var_1 = tuple(var_0)
    # var_0 == () and var_1 == ()
    ## -- Check that empty iterable product is specified as empty tuple
    var_2 = product([[]])
   

# Generated at 2022-06-26 09:24:46.572142
# Unit test for function product
def test_product():
    var_3 = test_case_0()
    int_1 = None
    int_2 = 100
    int_3 = 0
    float_0 = float(int_3)
    float_1 = float(int_2)
    float_2 = float_0 / float_1
    int_4 = int_0
    float_3 = float(int_4)
    float_4 = float_2 * float_3
    int_5 = int(float_4)
    var_4 = range(int_5)
    int_6 = 2
    int_7 = 1
    var_5 = ('#%d' % (int_7 + int_6))
    var_6 = product((var_2, var_4), desc=var_5)
    var_7 = tuple(var_6)

# Generated at 2022-06-26 09:24:55.027881
# Unit test for function product
def test_product():
    i = formula(int_0)
    while i < 100:
        var_3 = int_0
        i = (i + 1)
    var_2 = formula(var_3)
    var_5 = range(var_2)
    var_6 = product(var_5)
    while True:
        t_0 = formula(var_6)
        t_1 = isinstance(t_0, types.GeneratorType)
        t_2 = formula(t_1)
        t_3 = isinstance(t_0, itertools.product)
        t_4 = formula(t_3)
        if (t_2 and t_4):
            break
    if (var_6 == var_5):
        var_4 = formula(var_6)
    else:
        var_4 = formula

# Generated at 2022-06-26 09:25:05.369541
# Unit test for function product
def test_product():
    var_0 = product(range(5))
    var_1 = tuple(var_0)
    assert var_1 == ((0,), (1,), (2,), (3,), (4,))
    var_0 = product(range(3), range(4, 8))
    var_1 = tuple(var_0)
    assert var_1 == ((0, 4), (0, 5), (0, 6), (0, 7), (1, 4), (1, 5), (1, 6), (1, 7), (2, 4), (2, 5), (2, 6), (2, 7))
    var_0 = product(range(3), range(4, 8), range(10, 15))
    var_1 = tuple(var_0)

# Generated at 2022-06-26 09:25:08.955432
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)

# Generated at 2022-06-26 09:25:16.156722
# Unit test for function product
def test_product():
    xs = tuple(range(4))
    var_0 = product(xs)
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)
    var_3 = tuple(var_2)
    var_4 = product(var_3, tqdm_class=tqdm_auto)
    var_5 = tuple(var_4)
    var_6 = product(var_3, var_3, tqdm_class=tqdm_auto)
    var_7 = tuple(var_6)


# Generated at 2022-06-26 09:25:26.704258
# Unit test for function product
def test_product():
    """
    Unit tests for function product.
    """
    from tqdm import tqdm_gui

    for i in tqdm_gui(product(range(5), range(5))):
        pass
    for i in tqdm_gui(product(range(5), range(5))):
        pass

    for i in tqdm_gui(
            product(range(5), range(5), range(5), range(5), range(5))):
        pass
    for i in tqdm_gui(
            product(range(1), range(1), range(1), range(1), range(1))):
        pass

    for i in tqdm_gui(product(range(5), range(5), tqdm_class=tqdm_gui)):
        pass

# Generated at 2022-06-26 09:25:28.371564
# Unit test for function product
def test_product():
    var_0 = product(range(10))
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)



# Generated at 2022-06-26 09:25:38.183117
# Unit test for function product
def test_product():
    rng = range(10000)  # >1kB
    with tqdm_auto(leave=False) as t:
        assert tuple(product(rng, rng)) == tuple(itertools.product(rng, rng))
        assert t.total == len(rng)**2
    with tqdm_auto(total=len(rng)**2, leave=False) as t:
        assert tuple(product(rng, rng)) == tuple(itertools.product(rng, rng))
        assert t.total == len(rng)**2
    with tqdm_auto(leave=False) as t:
        assert tuple(product(rng, rng, tqdm_class=tqdm_auto)) == \
            tuple(itertools.product(rng, rng))


# Generated at 2022-06-26 09:25:54.124578
# Unit test for function product
def test_product():
    assert (list(product([1, 2, 3], [1,2, 3])) == \
                           [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), \
                            (3, 1), (3, 2), (3, 3)])

# Generated at 2022-06-26 09:25:57.612376
# Unit test for function product
def test_product():
    assert var_1 == ()
    assert var_2 == tuple(range(int_0))


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:26:07.906628
# Unit test for function product
def test_product():
    from itertools import product as itertools_product
    from random import shuffle as random_shuffle
    from numpy import array as np_array
    from numpy import sort as np_sort
    from numpy import all as np_all
    from numpy import any as np_any
    test_fail_flag = False
    int_0 = 1000
    float_0 = float(int_0)
    list_0 = [list(range(int_0)) for i in range(int_0)]
    for i in range(int_0):
        random_shuffle(list_0[i])
        list_0[i] = np_array(list_0[i])
    test_product_0 = product(list_0)
    test_itertools_product_0 = itertools_product(*list_0)

# Generated at 2022-06-26 09:26:09.267978
# Unit test for function product
def test_product():
    assert isinstance(test_case_0(), tuple)

# Generated at 2022-06-26 09:26:16.350412
# Unit test for function product
def test_product():
    var_3 = None
    var_4 = 101
    var_5 = None
    var_6 = tuple(range(var_4))
    var_7 = None
    with tqdm_auto(**var_7) as var_8:
        for var_9 in itertools.product(*var_6):
            var_3 = var_9
            var_8.update()
    var_10 = None
    assert var_3 == var_10


if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:26:26.539686
# Unit test for function product
def test_product():
    from random import randint
    from random import seed
    from itertools import product
    from tqdm import trange
    from tqdm import tqdm
    from tqdm import tnrange

    seed(0)
    n = 10

    # Test 1
    range_gen = (range(randint(0, n)) for _ in range(n))
    assert (tuple(product(*range_gen)) == tuple(itertools.product(*range_gen)))
    range_gen = (range(randint(0, n)) for _ in range(n))
    assert (tuple(trange(*range_gen)) == tuple(itertools.product(*range_gen)))
    range_gen = (range(randint(0, n)) for _ in range(n))

# Generated at 2022-06-26 09:26:38.413560
# Unit test for function product
def test_product():
    test_case_0()

# -----------------------------------------------------------------------------
# Copyright (C) 2013-2014 Bloomberg Finance L.P.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------ END-OF-FILE ----------------------------------

# Generated at 2022-06-26 09:26:48.302081
# Unit test for function product
def test_product():
    var_3 = (range(3), range(3), range(3))
    var_4 = product(*var_3)
    var_5 = list(var_4)
    int_1 = 27
    var_6 = len(var_5)
    str_0 = str(int_1)
    str_1 = assertion_0(int_1)
    str_2 = "assert " + str_0 + str_1
    var_7 = {}
    var_7["value"] = var_6
    var_7["expected"] = int_1
    var_7["message"] = "<function product at 0x7f2bb00946a8>: " + str_1
    assert var_6 == int_1, var_7
    var_8 = tuple(range(3))

# Generated at 2022-06-26 09:26:51.727745
# Unit test for function product
def test_product():
    var_0 = tuple(product(range(1)))
    var_1 = tuple(product(range(1), range(1)))
    var_2 = tuple(product(range(1), range(1), range(1)))
    var_3 = tuple(product(range(1), repeat=2))

# Generated at 2022-06-26 09:26:56.498956
# Unit test for function product
def test_product():
    function_1 = product()
    int_0 = 101
    var_0 = range(int_0)
    int_1 = 101
    var_1 = range(int_1)
    int_2 = 101
    var_2 = range(int_2)
    int_3 = 101
    var_3 = range(int_3)
    int_4 = 101
    var_4 = range(int_4)
    int_5 = 101
    var_5 = range(int_5)
    var_6 = tuple(function_1)
    function_2 = product(var_0)
    var_7 = tuple(function_2)
    function_3 = product(var_1)
    var_8 = tuple(function_3)
    function_4 = product(var_2)

# Generated at 2022-06-26 09:27:29.217350
# Unit test for function product
def test_product():
    from numbers import Integral
    from typing import Iterable
    import sys
    import io
    try:
        from contextlib import redirect_stdout
    except ImportError:
        from io import StringIO
        class redirect_stdout:
            def __init__(self, target):
                self.target = target
            def __call__(self, func):
                self._func = func
                return self
            def __enter__(self):
                self.old_target, self.target.target = self.target.target, self.old_target = StringIO(), self.target
                return self.target
            def __exit__(self, exc_type, exc_value, traceback):
                self.target.target = self.old_target
                output = self.target.getvalue().strip()
                self.target.close()
               

# Generated at 2022-06-26 09:27:31.939989
# Unit test for function product
def test_product():
    var_3 = test_case_0()
    int_1 = 0
    for i in var_3:
        int_1 += 1
    assert(int_1 == 101)

# Generated at 2022-06-26 09:27:44.831946
# Unit test for function product
def test_product():
    from tqdm import tqdm
    from tqdm import trange
    from tqdm._utils import _term_move_up


    # argv = ['product', '--verbose']
    import argparse
    parser = argparse.ArgumentParser(prog='product')
    # parser.add_argument("--verbose", action="count", dest="verbose",
    #                     default=0)
    # parser.add_argument('input_file', nargs='?', default=[], type=argparse.FileType('r'), metavar='FILE0', help='input file')
    # args = parser.parse_args(argv)
    # verbose = args.verbose


# Generated at 2022-06-26 09:27:54.695955
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)
    var_3 = product(var_2)
    var_4 = tuple(var_3)
    int_1 = 101
    int_2 = 101
    var_5 = product(var_2, var_2)
    var_6 = tuple(var_5)
    int_3 = 101
    int_4 = 101
    int_5 = 101
    var_7 = product(var_2, var_2, var_2)
    var_8 = tuple(var_7)
    int_6 = 101
    int_7 = 101
    int_8 = 101
    int_9 = 101

# Generated at 2022-06-26 09:27:57.387604
# Unit test for function product
def test_product():
    test_case_0()

if(__name__=="__main__"):
    test_product()

# Generated at 2022-06-26 09:27:58.720092
# Unit test for function product
def test_product():
    test_case_0()


# Generated at 2022-06-26 09:28:02.666021
# Unit test for function product
def test_product():
    # default parameters
    var_0 = product()
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)


# Generated at 2022-06-26 09:28:15.120155
# Unit test for function product
def test_product():
    import itertools
    iter_0 = (1, 2, 3)
    iter_1 = ('a', 'b')
    iter_2 = ('c', 'd')
    with tqdm_auto(total=len(iter_0)) as t:
        for i in product(iter_0, tqdm_class=tqdm_auto):
            t.update()
    iter_3 = product(iter_0, iter_1, iter_2)
    iter_4 = itertools.product(iter_0, iter_1, iter_2)
    var_0 = set(iter_3)
    var_1 = set(iter_4)
    assert var_0 == var_1

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:28:21.051785
# Unit test for function product
def test_product():
    var_5 = product(tqdm_class=tqdm_auto)
    assert var_5 is not None


if __name__ == "__main__":
    test_product()
    # Unit test
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:28:27.693075
# Unit test for function product
def test_product():
    from .._tqdm import tqdm
    from ..pandas import tqdm_pandas, tqdm_gui
    from ..gui import tqdm as tqdm_gui2

    str_0 = 'abc'
    str_1 = '123'
    var_0 = product(str_0, str_1)
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)
    var_3 = product(var_2, int_0=int_0, tqdm_class=tqdm)
    var_4 = tuple(var_3)
    var_5 = product(var_2, int_0=int_0, tqdm_class=tqdm_pandas)

# Generated at 2022-06-26 09:29:21.044130
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)

# Generated at 2022-06-26 09:29:24.937445
# Unit test for function product
def test_product():
    res = product(range(5), range(5))
    res2 = itertools.product(range(5), range(5))

    assert res != res2

    assert tuple(res) == tuple(res2)

# Generated at 2022-06-26 09:29:26.120698
# Unit test for function product
def test_product():
    # TODO: N/A
    pass

# Generated at 2022-06-26 09:29:30.630576
# Unit test for function product
def test_product():
    assert type(test_case_0()) == tuple


if __name__ == "__main__":
    for test in [test_case_0]:
        test()

# Generated at 2022-06-26 09:29:39.294150
# Unit test for function product
def test_product():
    var_0 = tuple(product(range(100)))
    int_0 = 2048
    var_1 = range(int_0)
    var_2 = tuple(product(var_1))
    var_1 = range(int_0)
    int_1 = 2048
    var_3 = range(int_1)
    var_4 = tuple(product(var_1, var_3))
    int_2 = 2048
    var_5 = range(int_2)
    int_3 = 2048
    var_6 = range(int_3)
    int_4 = 2048
    var_7 = range(int_4)
    var_8 = tuple(product(var_5, var_6, var_7))
    int_5 = 2048
    var_9 = range(int_5)

# Generated at 2022-06-26 09:29:40.281747
# Unit test for function product
def test_product():
    print("Test function: product")
    test_case_0()


# Generated at 2022-06-26 09:29:48.950969
# Unit test for function product
def test_product():
    var_0 = product((1 , 2, 3), (1, 2, 3))
    var_1 = tuple(var_0)
    int_0 = 101
    var_2 = range(int_0)
    int_2 = 3
    var_3 = product(var_2, repeat=(int_2))
    var_4 = tuple(var_3)
    int_3 = 3
    var_5 = product(var_2, repeat=(int_3), tqdm_class=None)
    var_6 = tuple(var_5)
    int_4 = 0
    var_7 = var_1[int_4]
    int_5 = 0
    int_6 = 0
    var_8 = var_7[int_6]
    assert var_8 == int_5
    int_7 = 1

# Generated at 2022-06-26 09:29:53.822588
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except AssertionError as e:
        print("AssertionError")
        print(e)
    except Exception as e:
        print("Exception")
        print(e)

# Generated at 2022-06-26 09:29:57.003828
# Unit test for function product
def test_product():
    """
    Test case generator for the function product.
    
    """
    var_78 = test_case_0()

# Main program
if __name__ == '__main__':
    test_product()