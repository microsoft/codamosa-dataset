

# Generated at 2022-06-26 09:20:10.587639
# Unit test for function product
def test_product():
    assert ("product" in globals())
    assert (callable(product))
    assert (not kwdefault(product, "tqdm_class"))
    try:
        #Product is an iterator that aggregates elements from each of the iterables.
        #gregorian_products = product(range(1,13), range(1,32), [2018, 2019])
        gregorian_products = product(range(1,13), range(1,32), [2018, 2019], tqdm_class = tqdm_auto)
        for item in gregorian_products:
            print(item)
    except Exception as exception:
        assert False

if __name__ == '__main__':
    from sys import argv
    if len(argv) == 1:
        print('Testing...')
        test_product()

# Generated at 2022-06-26 09:20:14.594051
# Unit test for function product
def test_product():
    var_0 = product(range(10000))
    for _ in var_0:
        pass
    assert True

if __name__ == '__main__':
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:20:25.729544
# Unit test for function product
def test_product():
    from random import randint
    from itertools import product

    lst_0 = [randint(0, 100) for i in range(randint(4, 10))]
    lst_1 = [randint(0, 100) for i in range(randint(4, 10))]
    lst_2 = [randint(0, 100) for i in range(randint(4, 10))]
    for i in product(lst_0, lst_1, lst_2):
        assert all(i_var in locals()[i_var].tolist()
                   for i_var_num, i_var in enumerate(['lst_0', 'lst_1', 'lst_2']))

# Generated at 2022-06-26 09:20:32.206146
# Unit test for function product
def test_product():
    from .._utils import _range
    for i in range(10):
        l = list(_range(i + 1))
        p = product(l) * i
        assert (i == 0 and list(p) == [()]) or \
            list(p) == [(t,) * i for t in l]

    p = product(['a', 'b'], [1, 2], [0.5, 0.1])
    assert list(p) == [('a', 1, 0.5),
                       ('a', 1, 0.1),
                       ('a', 2, 0.5),
                       ('a', 2, 0.1),
                       ('b', 1, 0.5),
                       ('b', 1, 0.1),
                       ('b', 2, 0.5),
                       ('b', 2, 0.1)]

    p

# Generated at 2022-06-26 09:20:34.541535
# Unit test for function product
def test_product():
    # Test with no args.
    test_case_0()


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:20:46.507778
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = product()
    var_2 = product()
    var_3 = product()
    var_4 = product()
    var_5 = product()
    var_6 = product()
    var_7 = product()
    var_8 = product()
    var_9 = product()
    var_10 = product()
    var_11 = product()
    var_12 = product()
    var_13 = product()
    var_14 = product()
    var_15 = product()
    var_16 = product()
    var_17 = product()
    var_18 = product()
    var_19 = product()
    var_20 = product()
    var_21 = product()
    var_22 = product()
    var_23 = product()
    var_24 = product()

# Generated at 2022-06-26 09:20:49.635708
# Unit test for function product
def test_product():
    for i in product(range(4), range(4), range(4)):
        pass
    for i in product(range(5), range(5), range(5)):
        pass

# Generated at 2022-06-26 09:21:00.311892
# Unit test for function product
def test_product():
    '''test_product'''
    #test case 0
    var_0 = product()
    var_1 = product('ABCD')
    var_2 = product(range(2), repeat=3)
    var_3 = product('ABCD', 'xy')
    var_4 = product(range(2), range(4))
    var_5 = product(range(2), range(4), range(6))
    var_6 = product(range(2), range(4), range(3))
    var_7 = product(range(2), range(3))
    var_8 = product(range(2), range(3), range(4))

    #test case 1
    list_1 = ['1', '2', '3']
    list_2 = ['a', 'b', 'c']


# Generated at 2022-06-26 09:21:00.815167
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:21:12.526571
# Unit test for function product
def test_product():
    # Test product with generic args
    print("Test product with generic args")
    result = list(product([1, 2], [3, 4]))
    assert result == [(1, 3), (1, 4), (2, 3), (2, 4)]
    result = list(product([1, 2], [3, 4], repeat=2))

# Generated at 2022-06-26 09:21:26.670812
# Unit test for function product
def test_product():
    from .utils import FormatWarnings
    from collections import Counter
    from math import factorial as fac
    from random import randrange
    from string import ascii_lowercase as letters

    with FormatWarnings():
        # Test correct output
        assert Counter(list(product([1, 2, 3], repeat=3))) == Counter(
            itertools.product([1, 2, 3], repeat=3))
        assert Counter(list(product([0, 1], repeat=0))) == Counter(
            itertools.product([0, 1], repeat=0))
        assert Counter(list(product([1, 2, 3], [4, 5, 6]))) == Counter(
            itertools.product([1, 2, 3], [4, 5, 6]))


# Generated at 2022-06-26 09:21:37.009409
# Unit test for function product
def test_product():
    """Test product function"""
    from .tests import TestTQDM
    import sys
    import mock
    import re

    with TestTQDM(disable=False) as t:
        with mock.patch.object(t.pbar, 'update', return_value=None) as fm:
            x = iter(t.func(t, [range(20), ['a'] * 20])())
            for i, i2 in enumerate(x):
                pass
            assert i == 19
            assert fm.call_count == 20
            assert isinstance(re.findall(r'^\[ *\d+%\]', fm.call_args[0][0])[0][1], str)

# Generated at 2022-06-26 09:21:41.066258
# Unit test for function product
def test_product():
    import sys
    import pandas
    if sys.version_info >= (3,):
        for i in product(list(range(4)), list(pandas.Series(range(5))),
                         tqdm_class=tqdm_auto):
            pass



# Generated at 2022-06-26 09:21:49.960272
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    it = (range(4), range(4))
    for i, j in product(*it):
        assert_array_equal([i, j], [j, i])
    it = (range(3), range(4), range(5))
    r = list(product(*it))
    assert_array_equal(r, list(itertools.product(*it)))
    r = list(product(range(10)))
    assert_array_equal(r, list(itertools.product(range(10))))
    prog_bar = product(range(100), total=100)
    if hasattr(prog_bar, "__len__"):
        assert len(prog_bar) == 100


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:21:59.555523
# Unit test for function product
def test_product():
    from .bar import trange
    from .std import trange as trange_std
    from .tqdm import trange as trange_tqdm
    from ..auto import tqdm as tqdm_auto

    tqdm = tqdm_auto()

    def tqdm_disp(it):
        with tqdm(it) as it_tqdm:
            for _ in it_tqdm:
                pass

    it = product(*[range(5, 10), range(10, 15)], tqdm_class=tqdm, desc="product")
    for i, j in it:
        assert i < 10
        assert j >= 10
    try:
        it.__length_hint__()
    except AttributeError:
        pass


# Generated at 2022-06-26 09:22:07.700339
# Unit test for function product
def test_product():
    # example from https://docs.python.org/3/library/itertools.html#itertools.product
    from .utils import StringIO
    with StringIO() as our_file, StringIO() as true_file:
        for i in product("ABCD", repeat=2, tqdm_class=tqdm_auto,
                         file=our_file):
            true_file.write(str(i) + "\n")
        our_output = our_file.getvalue()
    true_output = true_file.getvalue()

    assert our_output == true_output

# Generated at 2022-06-26 09:22:13.266804
# Unit test for function product
def test_product():
    """
    Unit test for tqdm.itertools.product.
    """
    from ..utils import FormatCustomText
    values = []
    for i in product("AB", "12", tqdm_class=FormatCustomText):
        values.append(i)
    assert values == [('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]

# Generated at 2022-06-26 09:22:25.113386
# Unit test for function product
def test_product():
    from .test_itertools import TestItrtls

    class TestProduct(TestItrtls):
        """
        Equivalent of `test_product` in `test_itertools`.
        """
        def setUp(self):
            self.it = product(range(5), range(3), range(10),
                              tqdm_class=self.tqdm_cls)
            self.lofl = []
            for i in itertools.product(range(5), range(3), range(10)):
                self.lofl.append(i)
        # Needs to be redefined because of `TestItrtls.test_update`
        def test_update(self):
            """
            Equivalent of `test_update` in `test_itertools`.
            """
            self.setUp()

# Generated at 2022-06-26 09:22:35.489288
# Unit test for function product
def test_product():
    """
    Sample function to test product function.
    """
    import itertools
    import random
    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3
    try:
        from urllib import urlretrieve  # Python 2
    except ImportError:
        from urllib.request import urlretrieve  # Python 3

    # Get test data
    url = "https://codeload.github.com/tqdm/tqdm/legacy.zip/master"
    filename = "tqdm.zip"
    urlretrieve(url, filename)
    with open(filename, 'rb') as f:
        data = list(f.read())
    random.shuffle(data)
    data = bytearray(data)

   

# Generated at 2022-06-26 09:22:37.386940
# Unit test for function product
def test_product():
    """Unit test for function product"""
    return  # hidde

# Generated at 2022-06-26 09:22:44.423055
# Unit test for function product
def test_product():
    import numpy.random as random
    from numpy import diff, array, allclose
    from tqdm import trange
    for i in trange(100):
        t = random.randint(0, 9)
        p = array(list(product(range(t), range(t))))
        assert allclose(diff(p), 1)

# Generated at 2022-06-26 09:22:52.182011
# Unit test for function product
def test_product():
    # Test 1
    test_case_0()
    # Test 2
    int_0 = 3
    var_0 = range(int_0)
    int_1 = 2
    var_1 = range(int_1)
    int_2 = 10
    var_2 = range(int_2)
    int_3 = 100
    var_3 = range(int_3)
    int_4 = 100
    var_4 = range(int_4)
    int_5 = 100
    var_5 = range(int_5)
    var_6 = product(*var_0, **{'tqdm_class': tqdm_auto})
    var_7 = list(var_6)
    var_8 = product(*var_1, **{'tqdm_class': tqdm_auto})
   

# Generated at 2022-06-26 09:22:56.098207
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    try:
        test_case_0()
        print("test successful")
    except:
        print("test failed")

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:00.493230
# Unit test for function product
def test_product():
    test_case_0()
    return

# Generated at 2022-06-26 09:23:09.531247
# Unit test for function product
def test_product():
    # Example
    int_0 = 4
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)
    int_1 = 10
    var_3 = range(int_1)
    var_4 = range(int_1)
    int_2 = 100
    var_5 = range(int_2)
    var_6 = product(*var_3, *var_4, *var_5)
    int_3 = 262144
    var_7 = list(var_6)
    int_4 = len(var_7)
    int_5 = len(var_2)
    assert int_3 == var_6.total
    assert int_3 == int_4
    assert int_5 == int_0 ** 3
    #

# Generated at 2022-06-26 09:23:22.227941
# Unit test for function product
def test_product():
    """
    Unit test for function product
    See https://github.com/tqdm/tqdm/pull/645#issuecomment-353621758
    """
    import tqdm

    def product(*iterables):
        """
        Equivalent of `itertools.product`.
        """
        kwargs = {'tqdm_class': tqdm.tqdm}
        lens = list(map(len, iterables))
        total = 1
        for i in lens:
            total *= i
        kwargs.setdefault("total", total)
        with tqdm.tqdm(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
                t.update()


# Generated at 2022-06-26 09:23:30.772099
# Unit test for function product
def test_product():
    """
    Unit test for function product

    itertools.product
    """
    try:
        import itertools
    except ImportError:
        print("Requires Python >= 2.6")
        return

    # Basic test
    int_0 = 4
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)
    int_1 = 10
    var_3 = range(int_1)
    var_4 = range(int_1)
    int_2 = 100
    var_5 = range(int_2)
    var_6 = product(var_3, var_4, var_5)
    var_7 = min(var_6, key=lambda x: x[0])

# Generated at 2022-06-26 09:23:38.383735
# Unit test for function product
def test_product():
    var_0 = [3, 5]
    var_1 = product(var_0)
    var_2 = list(var_1)
    assert len(var_2) == 15
    var_3 = [3, 5, 7]
    var_4 = product(var_3)
    var_5 = list(var_4)
    assert len(var_5) == 105

test_case_0()
test_product()

# Generated at 2022-06-26 09:23:42.336547
# Unit test for function product
def test_product():
    print("Test case: 0")
    test_case_0()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:23:44.343599
# Unit test for function product
def test_product():
    """Test for function product"""
    test_case_0()

# Generated at 2022-06-26 09:23:48.260937
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:23:52.922087
# Unit test for function product
def test_product():
    var_6 = test_case_0()
    str_0 = "test_case_0():"
    print(str_0)
    print(var_6)
    print()

test_product()

# Generated at 2022-06-26 09:23:53.715404
# Unit test for function product
def test_product():
    assert True

# Generated at 2022-06-26 09:23:55.081713
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:23:56.933227
# Unit test for function product
def test_product():
    pass


# Generated at 2022-06-26 09:24:01.829821
# Unit test for function product
def test_product():
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)
    int_1 = 10
    var_3 = range(int_1)
    var_4 = range(int_1)
    int_2 = 100
    var_5 = range(int_2)
test_product()

# Generated at 2022-06-26 09:24:12.648364
# Unit test for function product
def test_product():
    var_0 = range(4)
    var_1 = product(*var_0)
    var_2 = list(var_1)
    var_3 = (0,0,0,0)
    var_4 = (0,0,0,1)
    var_5 = (0,0,0,2)
    var_6 = (0,0,0,3)
    var_7 = (0,0,1,0)
    var_8 = (0,0,1,1)
    var_9 = (0,0,1,2)
    var_10 = (0,0,1,3)
    var_11 = (0,0,2,0)
    var_12 = (0,0,2,1)
    var_13 = (0,0,2,2)


# Generated at 2022-06-26 09:24:15.602250
# Unit test for function product
def test_product():
    print('Starting unit test for product')
    test_case_0()
    print('Finished unit test for product')

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:24:25.041185
# Unit test for function product
def test_product():
  # Test tqdm.itertools.product() with nested for loops
  int_0 = 2
  var_0 = range(int_0)
  var_1 = range(int_0)
  var_2 = list(product(*var_0,tqdm_class=None))
  assert var_2 == [
    (0,0),
    (0,1),
    (1,0),
    (1,1)
  ]
  # Test tqdm.itertools.product() with nested for loops
  int_0 = 5
  var_0 = range(int_0)
  var_1 = range(int_0)
  var_2 = list(product(*var_0))

# Generated at 2022-06-26 09:24:31.928464
# Unit test for function product
def test_product():
    int_0 = 4
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)
    int_1 = 10
    var_3 = range(int_1)
    var_4 = range(int_1)
    int_2 = 100
    var_5 = range(int_2)

# Generated at 2022-06-26 09:24:35.742321
# Unit test for function product
def test_product():
    import numpy as np
    assert sum([1 for i in product(range(3), repeat=3)]) == 27

# Generated at 2022-06-26 09:24:41.049235
# Unit test for function product
def test_product():
    assert product() == itertools.product()
    assert product(range(10)) == itertools.product(range(10))
    assert product(range(10), range(10, 20)) == itertools.product(range(10), range(10, 20))

# Generated at 2022-06-26 09:24:53.157055
# Unit test for function product
def test_product():
    import math
    import itertools
    def check_value(it, correct_value):
        assert (next(it)) == correct_value
    def check_iter(it, l, correct_values):
        for i in range(l):
            check_value(it, correct_values[i])
    for l in range(4):
        for i in range(int(math.pow(2,l))):
            l = []
            for j in range(l):
                if i & (1 << j) != 0:
                    l.append(range(1))
                else:
                    l.append(range(2))
            it = product(*l)
            correct_values = list(itertools.product(*l))
            check_iter(it, len(correct_values), correct_values)
# Test Case Test Case

# Generated at 2022-06-26 09:24:54.993593
# Unit test for function product
def test_product():
    assert test_case_0() is None

# Generated at 2022-06-26 09:25:05.346506
# Unit test for function product

# Generated at 2022-06-26 09:25:16.288993
# Unit test for function product

# Generated at 2022-06-26 09:25:17.950966
# Unit test for function product
def test_product():
    return None


# Generated at 2022-06-26 09:25:23.116533
# Unit test for function product
def test_product():
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = product()
    var_3 = list(var_1)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:25:36.179543
# Unit test for function product
def test_product():
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = product()
    var_3 = list(var_1)

    assert int_0 == 5
    assert var_0 == list(range(5))
    assert var_1 == var_1
    assert var_2 == var_2

# Generated at 2022-06-26 09:25:41.278994
# Unit test for function product
def test_product():
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = product()
    var_3 = list(var_1)


# Generated at 2022-06-26 09:25:51.517016
# Unit test for function product
def test_product():
    var_3 = test_case_0()
    test_pow = pow(5, 5)
    assert(len(var_2) == test_pow)
    assert(var_3 == None)

# Generated at 2022-06-26 09:26:00.422365
# Unit test for function product
def test_product():
    import numpy as np
    for tqdm_class in [tqdm_auto]:
        for var_3 in range(1, 5):
            for var_4 in range(2, 5):
                var_5 = np.random.randint(1, 100, 1000).tolist()
                var_6 = product(*var_5, tqdm_class=tqdm_class)
                var_7 = list(var_6)
                assert var_7 == list(itertools.product(*var_5))

# Generated at 2022-06-26 09:26:08.822230
# Unit test for function product
def test_product():
    # Default case
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)

# Generated at 2022-06-26 09:26:14.580170
# Unit test for function product
def test_product():
    assert product([1, 2, 3], [4, 5, 6]) == (1, 4), 'Failed test 0'
    assert product([1, 2, 3], [4, 5, 6], [7, 8]) == (1, 4, 7), 'Failed test 1'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:26:23.479712
# Unit test for function product
def test_product():
    for _ in range(100):
        with tqdm_auto(unit="B", unit_scale=True, unit_divisor=1024,
                       dynamic_ncols=True) as t:
            for j in product(range(10), range(10), range(10),
                             tqdm_class=t.__class__):
                pass
        tot = 10 ** 3
        assert t.n == tot
        assert t.total == tot

# Generated at 2022-06-26 09:26:31.684804
# Unit test for function product
def test_product():
    from numpy import prod
    from numpy.random import randint

    # simple test
    gen = product([1, 2], [3, 4])
    assert prod(next(gen)) == 3.
    assert prod(next(gen)) == 4.
    assert prod(next(gen)) == 6.
    assert prod(next(gen)) == 8.

    # tqdm test
    total = 1000
    gen = product(range(total))
    res = sum(prod(i) for i in gen)
    assert res == 9.332621544394418e+157

    # random test
    for i in range(5):
        for j in range(5):
            total = randint(10000)
            gen = product(range(total))
            res = sum(prod(i) for i in gen)
           

# Generated at 2022-06-26 09:26:40.601026
# Unit test for function product
def test_product():
    # Testing for product
    from unittest import TestCase
    from collections import defaultdict
    from itertools import product

    def run_product(*args):
        total = 0
        for _ in product(*args):
            total += 1
        return total


# Generated at 2022-06-26 09:26:52.645891
# Unit test for function product
def test_product():
    # Test `tqdm_kwargs` argument
    assert hasattr(product.__kwdefaults__, 'tqdm_class')
    assert hasattr(product.__kwdefaults__, 'total')
    # Test `total` attribute
    total = product.__kwdefaults__['total']
    assert total is None
    # Test `tqdm_class` default argument value
    tqdm_class = product.__kwdefaults__['tqdm_class']
    assert tqdm_class == tqdm_auto
    # Test `tqdm_class` required attributes
    assert hasattr(tqdm_class, 'update')
    assert hasattr(tqdm_class, 'close')
    # Test `product` function
    import tqdm as tqdm_module

# Generated at 2022-06-26 09:26:59.770721
# Unit test for function product
def test_product():
    from itertools import product as itertools_product
    import numpy

    x = numpy.arange(10)
    y = numpy.arange(10, 20)
    z = numpy.arange(20, 30)
    q = numpy.arange(30, 40)
    #

# Generated at 2022-06-26 09:27:11.851420
# Unit test for function product
def test_product():
    assert list(product(range(5))) == [(0,), (1,), (2,), (3,), (4,)]
    assert list(product(range(3), range(2))) == [(0, 0), (0, 1), (1, 0),
                                                 (1, 1), (2, 0), (2, 1)]
    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product('AB', range(2))) == [('A', 0), ('A', 1), ('B', 0),
                                             ('B', 1)]
    pools = [range(2), range(4), range(6)]

# Generated at 2022-06-26 09:27:32.577594
# Unit test for function product
def test_product():
    import numpy
    from numpy.testing import assert_array_equal

    list_0 = [0, 1, 2, 3, 4]
    var_0 = product(list_0)
    var_1 = list(var_0)

# Generated at 2022-06-26 09:27:37.138162
# Unit test for function product
def test_product():
    for i, j in product([1, 2], ['a', 'b'], tqdm_class=tqdm_auto):
        assert (i in [1, 2]) and (j in ['a', 'b'])

# Generated at 2022-06-26 09:27:40.432925
# Unit test for function product
def test_product():
    print("Unit test for function product")
    test_case_0()

# Run unit tests
test_product()

# Generated at 2022-06-26 09:27:42.768283
# Unit test for function product
def test_product():
    """
    Unit tests for product

    Tests
    -----
    - Tests for case 0
    """
    test_case_0()

# Generated at 2022-06-26 09:27:48.728665
# Unit test for function product
def test_product():

    # Check if it works
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)

    assert list(var_1) == list(itertools.product(*var_0))
    # Check if the result is the same to itertools



# Generated at 2022-06-26 09:27:55.905379
# Unit test for function product
def test_product():
    '''Check default call'''
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert len(var_2) == int_0**int_0
    assert var_2[0] == (0, 0, 0, 0, 0)
    assert var_2[-1] == (int_0 - 1, int_0 - 1, int_0 - 1, int_0 - 1, int_0 - 1)

    '''Check custom call'''
    int_1 = 10
    var_3 = range(int_1)
    var_4 = product(var_3, tqdm_class=SimpleTqdm, total=int_1**int_1)
    var_5 = list

# Generated at 2022-06-26 09:28:05.758462
# Unit test for function product
def test_product():
    # Test case 0
    int_0 = 5
    # Test case 1
    int_0 = 5
    # Test case 2
    int_0 = 5
    # Test case 3
    int_0 = 5
    # Test case 4
    int_0 = 5
    # Test case 5
    int_0 = 5
    # Test case 6
    int_0 = 5
    # Test case 7
    int_0 = 5
    # Test case 8
    int_0 = 5
    # Test case 9
    int_0 = 5
    # Test case 10
    int_0 = 5
    # Test case 11
    int_0 = 5
    # Test case 12
    int_0 = 5
    # Test case 13
    int_0 = 5
    # Test case 14
    int_0 = 5
    # Test case

# Generated at 2022-06-26 09:28:06.361615
# Unit test for function product
def test_product():
    assert isinstance(product(*[1, 2, 3]), itertools.product)

# Generated at 2022-06-26 09:28:13.352300
# Unit test for function product
def test_product():
    from hypothesis import strategies as st
    from hypothesis import assume, given
    from hypothesis.extra.itertools import cartesian, product
    from hypothesis.stateful import RuleBasedStateMachine, invariant, rule, precondition

    # Test
    @rule()
    def permutation(self):
        assume(self.var_0)
        assume(self.var_1)


# Generated at 2022-06-26 09:28:23.012683
# Unit test for function product
def test_product():
    # Test case 0
    try:
        test_case_0()
    except:
        assert False
    # Test case 1
    int_0 = 7
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)
    for elem_0 in var_2:
        for elem_1 in elem_0:
            print(elem_1, end=" ")
        print()

# Generated at 2022-06-26 09:28:50.847859
# Unit test for function product
def test_product():
    assert len(list(product("ab", repeat=3))) == 8
    assert list(product("ab", repeat=3)) == [('a', 'a', 'a'), ('a', 'a', 'b'), ('a', 'b', 'a'), ('a', 'b', 'b'), ('b', 'a', 'a'), ('b', 'a', 'b'), ('b', 'b', 'a'), ('b', 'b', 'b')]
    assert list(product("ab", repeat=2)) == [('a', 'a'), ('a', 'b'), ('b', 'a'), ('b', 'b')]
    assert list(product("ab", repeat=1)) == [('a',), ('b',)]
    assert list(product("ab")) == [('a',), ('b',)]

# Generated at 2022-06-26 09:28:53.648464
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except:
        raise AssertionError("Unit test for `product` failed")

# Generated at 2022-06-26 09:29:05.810290
# Unit test for function product
def test_product():
    assert list(product([1], repeat=1)) == [1]
    assert list(product([1], repeat=2)) == [1, 1]
    assert list(product([None], repeat=3)) == [None]
    assert list(product(['abc'], repeat=0)) == [()]
    assert list(product([1, 2], repeat=1)) == [1, 2]
    assert list(product([1, 2], repeat=2)) == [1, 1, 2, 2]
    assert list(product([1, 2], repeat=3)) == [1, 1, 1, 2, 2, 2]
    assert list(product([1, 2], repeat=4)) == [1, 1, 1, 1, 2, 2, 2, 2]


if __name__ == "__main__":
    import pytest
    py

# Generated at 2022-06-26 09:29:14.930948
# Unit test for function product
def test_product():
    """
    Test module level function that wraps itertools.product
    """
    iter1 = range(2)
    iter2 = range(2, 4)
    kwargs = {'tqdm_class': tqdm_auto}
    out = list(product(iter1, iter2, **kwargs))
    expected = [(0, 2), (0, 3), (1, 2), (1, 3)]
    assert out == expected

# Generated at 2022-06-26 09:29:16.497050
# Unit test for function product
def test_product():
    assert test_case_0() == 0

# Generated at 2022-06-26 09:29:23.825241
# Unit test for function product
def test_product():
    test_case_0()
    # Test with total being over-approximated
    # (e.g. permutations vs combinations)
    # https://github.com/tqdm/tqdm/issues/607
    try:
        len(set('abac'))
    except TypeError:
        pass
    else:
        list(product(range(3), 4))

# Generated at 2022-06-26 09:29:26.159726
# Unit test for function product
def test_product():
    # Test case 0
    int_0 = 5
    var_0 = range(int_0)
    var_1 = product(*var_0)
    var_2 = list(var_1)

# Generated at 2022-06-26 09:29:37.895368
# Unit test for function product
def test_product():
    from .._tqdm import tqdm as t

    # ----------
    # itertools.product
    # ----------

    assert(list(product('12', 'ab')) == [
           ('1', 'a'), ('1', 'b'), ('2', 'a'), ('2', 'b')])
    assert(list(product('12', 'ab', tqdm_class=t)) == [
           ('1', 'a'), ('1', 'b'), ('2', 'a'), ('2', 'b')])
    # ----
    assert(list(product('12', ['a', 'b'])) == [
           ('1', 'a'), ('1', 'b'), ('2', 'a'), ('2', 'b')])

# Generated at 2022-06-26 09:29:48.072761
# Unit test for function product
def test_product():
    num = 0
    i = 0
    j = 0
    lcm = 0
    first_number = 0
    second_number = 0
    sum_of_integers = 0
    test_values = [0,0]
    test_list = []
    the_list = []
    total = 0
    int_0 = 5
    var_47 = range(int_0)
    var_48 = product(*var_47)
    var_49 = list(var_48)
    var_49 = [x for x in var_49 if x is not None]
    var_49 = [x for x in var_49 if x is not None]
    var_49 = [x for x in var_49 if x is not None]
    var_49 = [x for x in var_49 if x is not None]
   

# Generated at 2022-06-26 09:29:49.887282
# Unit test for function product
def test_product():
    test_case_0()