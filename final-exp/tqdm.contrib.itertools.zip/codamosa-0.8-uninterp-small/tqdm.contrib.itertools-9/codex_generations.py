

# Generated at 2022-06-26 09:20:08.560279
# Unit test for function product
def test_product():
    import itertools
    import pytest
    import numpy.testing as npt

    def wrapper_product(*iterables):
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
        with tqdm.tqdm(total=total) as t:
            for i in itertools.product(*iterables):
                yield i
                t.update()

    # Testing with itertools.product
    with pytest.raises(TypeError):
        list(product('a', 'b'))
    with pytest.raises(TypeError):
        list(product(['a'], ['b'], [None]))

# Generated at 2022-06-26 09:20:10.669192
# Unit test for function product
def test_product():
    # Test if tqdm is enabled
    var = product(range(10))
    assert(type(var) == type(product(range(10))))

# Generated at 2022-06-26 09:20:14.302848
# Unit test for function product
def test_product():
    try:
        var_0 = product()
    except:
        import traceback
        traceback.print_exc()
        assert False
        return
    assert True


# Generated at 2022-06-26 09:20:25.480434
# Unit test for function product
def test_product():
    # Test with one iterable
    var_0 = [0, 1, 2, 3]
    var_1 = range(4)
    for var_2 in var_1:
        var_3 = var_0[var_2]
        var_4 = var_2
        var_5 = (var_3, )
        var_6 = var_2
        var_7 = var_5
        assert var_3 == var_7[0]
        var_8 = var_2 + 1
        assert var_4 == var_8
        var_9 = var_2 + 1
        assert var_6 == var_9
    var_10 = [0, 1]
    var_11 = product(var_10)
    var_12 = range(2)
    for var_13 in var_12:
        var_

# Generated at 2022-06-26 09:20:25.951920
# Unit test for function product
def test_product():
    var_0 = product()

# Generated at 2022-06-26 09:20:27.610610
# Unit test for function product
def test_product():

    assert False == False
    assert True == True

# Todo: Write unit tests

# Generated at 2022-06-26 09:20:32.182841
# Unit test for function product
def test_product():
    from io import StringIO
    buf = StringIO()
    import sys
    saved_stdout = sys.stdout
    try:
        sys.stdout = buf
        var_0 = product()
        assert var_0 is None
    finally:
        sys.stdout = saved_stdout
    return buf.getvalue()

if __name__ == '__main__':
    print("Unit tests for {0}:".format("itertools_.py"))
    print("Test results for function product:", end="")
    print()
    print(test_product(), end="")
    print("Done testing!")

# Generated at 2022-06-26 09:20:44.115292
# Unit test for function product
def test_product():
    var_0 = product('ABCD', 'xy')
    for var_1 in var_0:
        var_2 = var_1[1]
        var_3 = var_1[0]

# Generated at 2022-06-26 09:20:46.048180
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = product([1,2,3],[1,2,3])


# Generated at 2022-06-26 09:20:48.428024
# Unit test for function product
def test_product():
    len_0 = len(product(range(5)))
    assert len_0 == 5
    len_1 = len(product(range(5), range(5)))
    assert len_1 == 25
    len_2 = len(product(range(5), range(5), range(5)))
    assert len_2 == 125

# Generated at 2022-06-26 09:20:58.551235
# Unit test for function product
def test_product():
    from .base import _range
    assert list(product(_range(3))) == list(itertools.product([0, 1, 2], repeat=1))
    assert list(product(_range(3), _range(3))) == list(itertools.product([0, 1, 2], repeat=2))
    assert list(product(_range(3), _range(3), _range(3))) == list(itertools.product([0, 1, 2], repeat=3))

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:21:04.829276
# Unit test for function product
def test_product():
    from .tests.test_nested import nested_test
    kwargs = {"bar_format": "{desc}{r_bar}", "desc": "Testing product: "}
    nested_test(itertools.product, product,
        iterables=(range(2), "ab", list(range(3))), kwargs=kwargs,
        expected_total=None)
    nested_test(itertools.product, product, iterables=(range(2), range(2)),
        kwargs=kwargs, expected_total=4)
    nested_test(itertools.product, product, iterables=(range(2), range(2),
        range(2)), kwargs=kwargs, expected_total=8)

# Generated at 2022-06-26 09:21:07.701029
# Unit test for function product
def test_product():
    """Test for function product"""
    for i, j in product(range(2), range(2)):
        assert i <= 1
        assert j <= 1

# Generated at 2022-06-26 09:21:18.835962
# Unit test for function product
def test_product():
    """Unit test for function product"""

# Generated at 2022-06-26 09:21:20.366061
# Unit test for function product
def test_product():
    return len(list(product(*range(10), tqdm_class=tqdm_auto))) == 10**10

# Generated at 2022-06-26 09:21:27.546598
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal

    result = list(product(range(3), range(3)))
    assert_array_equal(
        result,
        [
            (0, 0),
            (0, 1),
            (0, 2),
            (1, 0),
            (1, 1),
            (1, 2),
            (2, 0),
            (2, 1),
            (2, 2),
        ]
    )

# Generated at 2022-06-26 09:21:32.196960
# Unit test for function product
def test_product():
    """
    Function `product` tests.
    """
    itr = product(range(i) for i in [1, 2, 3])
    assert list(itr) == list(itertools.product(range(1),
                                               range(2),
                                               range(3)))

# Generated at 2022-06-26 09:21:36.021204
# Unit test for function product
def test_product():
    import itertools
    for args in [
            [range(4), range(5)],
            [range(4), range(5), range(6)],
    ]:
        n = 1
        for i in args:
            n *= len(i)
        assert len(list(product(*args))) == n

# Generated at 2022-06-26 09:21:38.319015
# Unit test for function product
def test_product():
    assert (list(product([1, 2, 3], repeat=2)) ==
            list(itertools.product([1, 2, 3], repeat=2)))

# Generated at 2022-06-26 09:21:48.532150
# Unit test for function product
def test_product():  # pragma: no cover
    from ..utils import FormatCustomText, FormatTelegramBot, StatusPrinter
    from ..auto import trange, tqdm
    from ..std import tqdm as tqdm_std
    for n in [4, 80]:  # , -1]:
        for tqdm_cls in (tqdm, tqdm_std):
            for j in range(5):
                for i in product('abcd', '1234', 'xyz', tqdm_class=tqdm_cls,
                                 leave=False, unit_scale=True):
                    pass

# Generated at 2022-06-26 09:21:56.416035
# Unit test for function product
def test_product():
    iterables = [[1, 2], [3, 4]]
    x = list(product(*iterables))
    assert x == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-26 09:22:01.198235
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText

    # Test normal use
    a = list(product('ABCD', repeat=2, tqdm_class=FormatCustomText))
    # Test total
    b = list(product('ABCD', repeat=2, tqdm_class=FormatCustomText))
    assert a == b

    # Test errors
    try:
        list(product(range(10), tqdm_class=FormatCustomText))
    except TypeError:
        pass
    else:
        assert False, "product(*range(10)) should have failed!"

# Generated at 2022-06-26 09:22:12.559452
# Unit test for function product
def test_product():
    from .tests import TestTqdmIO
    import numpy as np
    for cls in TestTqdmIO.classes.values():
        for i in cls(range(8)):
            assert i == 0
        for i in cls(range(8), range(4)):
            assert i == (0, 0)
        for i in cls(range(2), range(2), range(2), range(2)):
            assert i == (0, 0, 0, 0)
        for i in cls(range(3), range(3), range(3), range(3),
                     tqdm_kwargs=dict(miniters=1)):
            assert i == (0, 0, 0, 0)
        n = 0

# Generated at 2022-06-26 09:22:24.157536
# Unit test for function product
def test_product():
    """Tests for `tqdm.itertools.product`"""
    from .tests_tqdm import with_setup, pretest  # NOQA

    @with_setup(pretest)
    def wrapper():
        """
        Unit test wrapper
        """
        from .tests_tqdm import closing, StringIO  # NOQA


# Generated at 2022-06-26 09:22:28.994099
# Unit test for function product
def test_product():
    from numpy.random import randint

    for nd in range(0, 4):
        iterables = [range(i) for i in randint(1, 5, size=nd)]
        p = product(*iterables)
        assert isinstance(p, type(product(*iterables)))
        loop_product = itertools.product(*iterables)
        try:
            while True:
                assert next(p) == next(loop_product)
        except StopIteration:
            pass

# Generated at 2022-06-26 09:22:36.123289
# Unit test for function product
def test_product():
    """Test function product."""
    assert list(product("ABCD", "xy")) == [("A", "x"),
                                           ("A", "y"),
                                           ("B", "x"),
                                           ("B", "y"),
                                           ("C", "x"),
                                           ("C", "y"),
                                           ("D", "x"),
                                           ("D", "y")]

# Generated at 2022-06-26 09:22:47.713379
# Unit test for function product
def test_product():
    from ._utils import _random_data
    from .utils import format_sizeof

    for t in (1, 2):
        for f in [_random_data(size=size, datatype='c' if i == 0 else 'i')
                  for i, size in enumerate([10000000, 2])]:
            for f_out in [_random_data(size=size, datatype='c')
                          for size in [10000000, 2]]:
                for total in ["unset", 10, 1000]:
                    kwargs = {}
                    if total != "unset":
                        kwargs["total"] = total

# Generated at 2022-06-26 09:22:58.338464
# Unit test for function product
def test_product():
    from .tests_main import _test_tqdm_deprecated

    # list() required due to generator
    assert (list(product([], [], [], [])) ==
            [])
    assert (list(product([1], [2], [3], [])) ==
            [])
    assert (list(product([1, 2], [1, 2], [1], [1, 2])) ==
            [(1, 1, 1, 1), (1, 1, 1, 2), (2, 1, 1, 1), (2, 1, 1, 2),
             (1, 2, 1, 1), (1, 2, 1, 2), (2, 2, 1, 1), (2, 2, 1, 2)])

# Generated at 2022-06-26 09:23:03.645468
# Unit test for function product
def test_product():
    a = [1, 4, 6]
    b = [5, 2, 0]
    c = [0, 7, 3]

    assert list(product(a, b, c)) == list(itertools.product(a, b, c))

# Generated at 2022-06-26 09:23:08.246996
# Unit test for function product
def test_product():
    assert itertools.product([1], [1], [1]) == list(
        product([1], [1], [1], tqdm_class=tqdm_auto.tqdm_pandas))

# Generated at 2022-06-26 09:23:16.884998
# Unit test for function product
def test_product():
    with tqdm_auto(total=1) as t:
        t0 = [t]
        var_0 = product(t0)
        for i in var_0:
            t0[0].update()


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-26 09:23:18.638995
# Unit test for function product
def test_product():
    test_case_0()


# Generated at 2022-06-26 09:23:19.780497
# Unit test for function product
def test_product():
    # No data type checking.
    # No assert testing.
    test_case_0()

# Generated at 2022-06-26 09:23:29.316183
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    def equal(results, items, indices=None):
        """Determine if two lists contains the same items, with the same
        indices."""
        if indices is None:
            indices = list(range(len(items)))
        for result, i in zip(results, indices):
            if result[0] != items[i][0] or result[1] != items[i][1]:
                return False
        return True

    def results_to_items(results, items):
        """Convert the product results back to the original items."""
        return [tuple(items[i] for i in item_indices) for item_indices in results]

    print("Running test_product()...")
    items = [[0, 1], [0, 1], [0, 1]]

# Generated at 2022-06-26 09:23:35.849382
# Unit test for function product
def test_product():
    var_0 = int
    var_0 = product(var_0())
    var_1 = list(var_0)
    var_2 = (2, 4, 7, 8, 4)
    var_3 = product(var_2)
    var_4 = list(var_3)

# Generated at 2022-06-26 09:23:39.819144
# Unit test for function product
def test_product():
    from ..tests.test_itertools import test_case_0
    import sys

    try:
        import pytest
        pytest.skip("pytest is already imported.")
    except ImportError:
        sys.modules["pytest"] = __import__("unittest")
    test_case_0()

# Generated at 2022-06-26 09:23:42.942418
# Unit test for function product
def test_product():
    # Test case with one argument.
    # Test case with two arguments
    # Test case with two arguments that are not iterable.
    test_case_0()

# Generated at 2022-06-26 09:23:52.960901
# Unit test for function product
def test_product():
    import pandas as pd
    import pandas.util.testing as tm
    import pytest

    @pytest.mark.parametrize("func", [test_case_0])
    def test_product_f(func):
        return func()

    test_product_f()

    df = pd.DataFrame(
        [[1, 2], [1, 2], [3, 4]],
        columns=pd.MultiIndex.from_product([['A'], ['a', 'b']])
    )
    with pytest.raises(ValueError) as e_info:
        df.groupby(level=0).sum()
    assert "No axis named 2 for object type" in str(e_info.value)
    df.groupby(level=0, axis=1).sum()

    # GH 275

# Generated at 2022-06-26 09:23:58.423369
# Unit test for function product
def test_product():
    assert next(product([4])) == (4,)
    assert next(product("abc", "def")) == ("a", "d")
    assert next(product("abc", "def")) == ("a", "e")
    assert next(product("abcd", "efg")) == ("a", "e")
    assert next(product("abcd", "efg")) == ("a", "f")
    assert next(product("abcd", "efg")) == ("a", "g")
    assert next(product("abcd", "efg")) == ("b", "e")
    assert next(product("abc", "d")) == ("a", "d")
    assert next(product("abc", "d")) == ("b", "d")
    assert next(product("abc", "d")) == ("c", "d")

# Generated at 2022-06-26 09:23:59.330675
# Unit test for function product
def test_product():
    assert test_case_0() is None

# Generated at 2022-06-26 09:24:03.972262
# Unit test for function product
def test_product():
    # Test for case 0
    test_case_0()

# Generated at 2022-06-26 09:24:13.192258
# Unit test for function product
def test_product():
    with tqdm_auto(total=itertools.product.__length_hint__((1, 5, 2, 3))) as pbar:
        res = [x for x in product(range(1, 5), range(2, 3), tqdm_kwargs={'total': None})]
    assert res == [(1, 2), (1, 2), (1, 2), (1, 2), (1, 2),
                   (2, 2), (2, 2), (2, 2), (2, 2), (2, 2),
                   (3, 2), (3, 2), (3, 2), (3, 2), (3, 2),
                   (4, 2), (4, 2), (4, 2), (4, 2), (4, 2)]
    assert pbar.n == len(res)
    assert pbar

# Generated at 2022-06-26 09:24:24.166417
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy import prod
    from numpy import asarray
    from numpy import inf
    from numpy import array
    from numpy import equal
    from numpy import empty
    from numpy import int64

    # scalar input
    x = [randint(2, size=7)]
    assert list(product(*x)) == [tuple(i) for i in x]

    # list input
    x = [randint(2, size=7) for i in range(4)]
    assert list(product(*x)) == [tuple(i) for i in x]

    # 1d array input
    x = [randint(2, size=7) for i in range(3)]
    assert list(product(*x)) == [tuple(i) for i in x]

   

# Generated at 2022-06-26 09:24:26.772863
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:24:36.400966
# Unit test for function product
def test_product():
    import numpy as np
    # use of `itertools.product` with a generator for `i`
    for i in range(4):
        for j in range(3):
            pass

    # use of `itertools.product` with a generator for `j`
    for i in range(4):
        for j in range(3):
            pass

    # use of `itertools.product` with generators for both `i` and `j`
    for i in range(4):
        for j in range(3):
            pass

    # use of `itertools.product` with a numpy array for `i`
    for i in np.arange(4):
        for j in np.arange(3):
            pass

    # use of `itertools.product` with a numpy array for `j`

# Generated at 2022-06-26 09:24:45.064248
# Unit test for function product
def test_product():
    int_0 = 29
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    var_2 = [83.5, 83.5]
    var_3 = [2, 2]
    var_4 = [83.5, 83.5]
    var_5 = [2, 2]
    var_6 = [83.5, 83.5]
    var_7 = [2, 2]
    var_8 = [83.5, 83.5]
    int_2 = 1
    var_9 = [1, 1]
    var_10 = [83.5, 83.5]
    var_11 = [3, 3]
    var_12 = [83.5, 83.5]
   

# Generated at 2022-06-26 09:24:51.887174
# Unit test for function product
def test_product():
    int_0 = 29
    int_1 = [int_0, int_0]
    var_0 = product(*int_1, tqdm_class=tqdm_auto)
    var_1 = list(var_0)
    assert len(var_1) == int_0 * int_0
    assert var_1[0] == (0, 0)
    assert var_1[-1] == (28, 28)



# Generated at 2022-06-26 09:25:04.448513
# Unit test for function product
def test_product():
    int_0 = [3,3,3,3,3,3,3,3,3,3]
    int_1 = [i for i in product(*int_0,ascii=True,miniters=1,desc='Compute ETA',leave=True)]
    assert len(int_1) == 19683
    int_0 = [3,3,3,3,3,3,3,3,3,3]
    int_1 = [i for i in product(*int_0,ascii=True,miniters=1,desc='Compute ETA',leave=True,position=0)]
    assert len(int_1) == 19683
    int_0 = [3,3,3,3,3,3,3,3,3,3]

# Generated at 2022-06-26 09:25:07.406177
# Unit test for function product
def test_product():
    try:
        product()
        assert(False)
    except:
        assert(True)


# Generated at 2022-06-26 09:25:16.835480
# Unit test for function product
def test_product():

    int_var_0 = 0
    int_var_1 = 1
    int_var_2 = 2
    int_var_3 = 3
    int_var_4 = 4
    int_var_5 = 5
    int_var_6 = 6
    int_var_7 = 7
    int_var_8 = 8
    int_var_9 = 9
    int_var_10 = 10
    int_var_11 = 100
    int_var_12 = 101
    int_var_13 = 102
    int_var_14 = 103
    int_var_15 = 104
    int_var_16 = 105
    int_var_17 = 106
    int_var_18 = 107
    int_var_19 = 108
    int_var_20 = 109
    int_var_21 = 110
   

# Generated at 2022-06-26 09:25:36.001505
# Unit test for function product
def test_product():
    from random import uniform
    for t in [tqdm, tqdm_gui, trange]:
        for total in [None, 0, 1, 2, 10]:
            for mininterval in [0.0, 0.1, 1.0, 2.0]:
                for miniters in [1, 10, 100]:
                    # Test that total is used if miniters is None
                    if miniters is None:
                        tqdm_obj = t(total=total, mininterval=mininterval)
                        assert tqdm_obj.total == total
                        assert list(tqdm_obj) == []
                    # Test that total is used if miniters is not None

# Generated at 2022-06-26 09:25:39.978163
# Unit test for function product
def test_product():
    int_0 = 299
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)

# Generated at 2022-06-26 09:25:44.215451
# Unit test for function product
def test_product():
    from .test_cases import cases

    for args, kwargs in cases(False):
        with tqdm_auto(total=None) as pbar:
            for x in product(*args, **kwargs):
                pbar.update()

# Generated at 2022-06-26 09:25:56.537241
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except:
        import traceback

# Generated at 2022-06-26 09:26:05.048447
# Unit test for function product
def test_product():
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    lows = [0, 1, 2]
    highs = [10, 11, 12]
    labels = ['L', 'H']
    all_params = [lows, highs, labels]
    with tqdm_auto(total=len(lows) * len(highs)) as t:
        for params in product(*all_params):
            print(params[-1], params[0], params[1])
            t.update()

# Generated at 2022-06-26 09:26:05.911184
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:26:10.264646
# Unit test for function product
def test_product():
    var_0 = product([1, 2, 3], ['a', 'b', 'c'], [4, 5, 6])
    var_1 = list(var_0)
    del var_0
    del var_1

# Generated at 2022-06-26 09:26:13.319421
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    try:
        test_case_0()
    except:
        print("Test ERROR")

# Generated at 2022-06-26 09:26:25.796053
# Unit test for function product
def test_product():
    import itertools
    int_0 = 29
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    assert var_1 == list(itertools.product(*int_1))
    # assert str(var_0) == '<itertools.product object at 0x7f12c78d75e8>'
    int_0 = 1
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    assert var_1 == list(itertools.product(*int_1))
    # assert str(var_0) == '<itertools.product object at 0x7f12c78d76d8

# Generated at 2022-06-26 09:26:38.585568
# Unit test for function product
def test_product():
    # Test 1
    int_0 = 29
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)

# Generated at 2022-06-26 09:26:52.251618
# Unit test for function product
def test_product():
    int_0 = 0
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_1 = list(var_0)
    var_2 = list(var_0)
    int_2 = type(var_0)
    int_3 = inspect.getmembers(var_0)
    int_4 = len(var_1)
    int_5 = len(var_2)
    int_6 = var_2 == var_1


# Generated at 2022-06-26 09:26:52.803413
# Unit test for function product
def test_product():
    assert test_case_0() == None

# End of test cases for function product

# Generated at 2022-06-26 09:27:05.535522
# Unit test for function product
def test_product():
    import numpy as np
    from os.path import expandvars as e
    from os.path import expanduser as u
    from tqdm import trange, tqdm_notebook as tnb
    from tqdm.auto import tqdm as tqdm_auto

    assert open(__file__).read().count('yield') == 1, 'Unit test broken'

    try:  # Python 3+
        var_2 = __builtins__.__dict__['range']
        var_0 = __builtins__.__dict__['zip']
    except AttributeError:  # Python 2
        var_0 = __builtins__.zip

    def chk(tqdm_class):
        """Check function"""

# Generated at 2022-06-26 09:27:09.666363
# Unit test for function product
def test_product():
    test_cases = [
        (test_case_0, None),
    ]

    for index, tc in enumerate(test_cases):
        func_runner(tc[0], tc[1], index)


# Generated at 2022-06-26 09:27:14.175112
# Unit test for function product
def test_product():
    assert all(i == (0, 0) for i in product(range(10), range(10)))
    assert not any(i == (0, 3) for i in product(range(10), range(10)))


if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:27:21.788247
# Unit test for function product
def test_product():
    # assert [N/A]
    # assert [N/A]
    # assert [N/A]
    # assert [N/A]
    # assert [N/A]
    # assert [N/A]
    # assert [N/A]
    return


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:27:26.224499
# Unit test for function product
def test_product():
    # Example 1
    int_7 = 29
    int_6 = [int_7, int_7]
    var_3 = product(*int_6)
    var_4 = list(var_3)
#     assert 1 == 0

if __name__ == '__main__':
    # test_case_0()
    test_product()

# Generated at 2022-06-26 09:27:27.039086
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:27:27.980633
# Unit test for function product
def test_product():
    assert test_case_0() == (None)

# Generated at 2022-06-26 09:27:32.252325
# Unit test for function product
def test_product():
    tot = 0
    for el in product([1, 2], (3, 4), tqdm_class=lambda **kwargs: FakeTqdm(**kwargs)):
        tot = tot * 10 + el
    assert tot == 1234
    assert FakeTqdm.counter == 1234


# Generated at 2022-06-26 09:28:05.625672
# Unit test for function product
def test_product():
    from sys import version_info
    from os import getcwd
    from .._cmp_version import _cmp_version
    from ..tqdm import tqdm

    if (_cmp_version(version_info, (3, 5, 0)) < 0 or isinstance(tqdm(0), tqdm)):
        return
    with open(__file__) as current_file:
        current_file.readline()
        current_file.readline()
        for i, _ in enumerate(tqdm(enumerate(current_file),
                                   total=sum(1 for _ in current_file),
                                   desc=getcwd())):
            if (i == 2):
                break

# Generated at 2022-06-26 09:28:10.718486
# Unit test for function product
def test_product():
    test_case_0()

# Test definition of module tqdm.std.itertools
# todo: change field "test_case_0" to "test_case_1"

# Generated at 2022-06-26 09:28:13.549624
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except Exception as e:
        print('Unhandled Exception: {}'.format(e))
        assert False


# Generated at 2022-06-26 09:28:23.869821
# Unit test for function product
def test_product():
    int_0 = 2
    int_1 = 3
    int_2 = 4
    int_3 = 5
    int_4 = int_0 * int_1 * int_2 * int_3
    print(int_4)
    var_0 = [[int_0, int_1, int_2], [int_3]]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    int_5 = len(var_2)
    print(int_5)
    assert (int_4 == int_5)


# Generated at 2022-06-26 09:28:35.634589
# Unit test for function product
def test_product():
    int_0 = 29
    int_1 = 30
    int_2 = 57
    int_3 = 70
    int_4 = 80
    int_5 = int_0 * int_1 * int_2 * int_3 * int_4
    var_0 = product(range(int_0), range(int_1), range(int_2), range(int_3),
                    range(int_4))
    int_6 = 0
    for _ in var_0:
        int_6 += 1
    assert int_6 == int_5
    int_7 = 0
    for _ in product(range(int_0), range(int_1), range(int_2), range(int_3),
                     range(int_4), tqdm_class=tqdm_auto):
        int_7 += 1
   

# Generated at 2022-06-26 09:28:45.774700
# Unit test for function product

# Generated at 2022-06-26 09:28:53.337719
# Unit test for function product
def test_product():
    int_0 = 1000000000
    int_1 = 100000000
    int_2 = [int_0, int_1]
    int_3 = product(*int_2)
    int_4 = False
    for i in int_3:

        # print(i)
        int_4 = True
    assert int_4

# Generated at 2022-06-26 09:29:05.780914
# Unit test for function product
def test_product():
    int_0 = 29
    int_1 = [int_0, int_0]
    var_0 = product(*int_1)
    var_0 = list(var_0)

# Generated at 2022-06-26 09:29:17.395718
# Unit test for function product
def test_product():
    '''
    python -m doctest -v product.py
    '''
    from tqdm import trange
    from collections import Counter

    assert Counter(product(range(10), repeat=2)) == \
        Counter(zip(range(10), range(10)))

    assert Counter(product(range(10), repeat=3)) == \
        Counter(itertools.product(range(10), repeat=3))

    assert len(list(product(range(10), repeat=2))) == \
        10 * 10

    assert len(list(product(range(10), repeat=2))) == \
        10 * 10

    assert len(list(product(range(10), repeat=2))) == \
        trange(10 * 10, desc="product", unit="it").n


# Generated at 2022-06-26 09:29:23.974037
# Unit test for function product
def test_product():
    from itertools import product as it_product
    assert list(product(range(4), repeat=4)) == list(it_product(range(4), repeat=4))
    assert list(product(range(4), repeat=2)) == list(it_product(range(4), repeat=2))
    assert list(product(range(4), repeat=1)) == list(it_product(range(4), repeat=1))
    assert list(product(range(4), repeat=0)) == list(it_product(range(4), repeat=0))
    assert list(product(range(4), repeat=4)) == list(it_product(range(4), repeat=4))


if __name__ == "__main__":
    test_case_0()
    test_product()