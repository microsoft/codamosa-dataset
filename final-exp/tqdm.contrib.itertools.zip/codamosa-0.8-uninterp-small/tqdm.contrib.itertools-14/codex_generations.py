

# Generated at 2022-06-26 09:20:09.264564
# Unit test for function product
def test_product():
    pass


if __name__ == "__main__":
    test_product()
    test_case_0()

# Generated at 2022-06-26 09:20:21.244086
# Unit test for function product
def test_product():
    '''Check returns of `product` func'''
    res = product((1, 2), (3, 4))
    assert res.next() == (1, 3)
    assert res.next() == (1, 4)
    assert res.next() == (2, 3)
    assert res.next() == (2, 4)
    # Default total detection
    res = product((1, 2), (3, 4))
    assert res.next() == (1, 3)
    assert res.next() == (1, 4)
    assert res.next() == (2, 3)
    assert res.next() == (2, 4)
    # Custom total
    res = product((1, 2), (3, 4), total=4)
    assert res.next() == (1, 3)

# Generated at 2022-06-26 09:20:22.927819
# Unit test for function product
def test_product():
    assert hasattr(product(), '__iter__')
    assert isinstance(product(), itertools.product)

# Generated at 2022-06-26 09:20:26.148250
# Unit test for function product
def test_product():
    """
    Function unit testing.
    """
    var_0 = product([])
    var_0 = product()
    assert isinstance(var_0, itertools.product)


# Generated at 2022-06-26 09:20:27.911416
# Unit test for function product
def test_product():
    # check if product works with the output of the np.arange() function
    var_0 = product(np.arange(10))


# Generated at 2022-06-26 09:20:37.035212
# Unit test for function product
def test_product():
    # var_0 = list(product([1,2,3]))
    # var_1 = list(product([1,2,3], repeat=2))
    # var_2 = list(product([1,2,3], [4,5]))
    # var_3 = list(product([1,2,3], [4,5], [6,7]))
    # var_4 = list(product([1,2,3], repeat=3))
    # var_5 = list(product('ab', range(3)))
    pass


# Generated at 2022-06-26 09:20:38.918277
# Unit test for function product
def test_product():
    test_case_0()


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:20:41.615815
# Unit test for function product
def test_product():
    """
    Test itertools.product()
    """
    assert product([1], [2], [3]) == product([1], [2], [3])


# Generated at 2022-06-26 09:20:46.652833
# Unit test for function product
def test_product():
    from collections import Counter

    from .tqdm.tqdm_gui import tqdm_gui

    input = list(zip(range(10), range(10), range(10)))
    out = Counter(product(*input, tqdm_class=tqdm_gui))
    assert out == Counter(itertools.product(*input))

# Generated at 2022-06-26 09:20:58.351193
# Unit test for function product
def test_product():
    # Check that function is callable
    try:
        for i in product():
            break
    except:
        pass
    else:
        assert False, "Cannot call function product"
    # Check that function throws TypeError when called with incorrect argument(s)
    try:
        for i in product(x = 0):
            break
    except:
        pass
    else:
        assert False, "Incorrect argument(s)"
    # Check that function throws TypeError when called with incorrect argument(s)
    try:
        for i in product(x = 0):
            break
    except:
        pass
    else:
        assert False, "Incorrect argument(s)"
    # Check that function throws TypeError when called with incorrect argument(s)

# Generated at 2022-06-26 09:21:12.617645
# Unit test for function product
def test_product():
    from ..std import numpy as np
    from .utils import SimpleNamespace

    class wrapped_product(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.tqdm_instance = SimpleNamespace(
                update=lambda x: True,
                n=None,
                total=None)
            self.ret = None

        def __enter__(self):
            return self.tqdm_instance

        def __exit__(self, *exc):
            self.ret = product(*self.args, **self.kwargs)

    def wrap_prod():
        obj = wrapped_product(range(2), range(3),
                              range(100),
                              tqdm_class=wrapped_product)

# Generated at 2022-06-26 09:21:23.279557
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy import isclose
    from numpy.random import normal
    from .tqdm import tqdm
    from .utils import format_sizeof
    from .utils import format_interval
    from .stats import mean
    from .stats import std
    from .stats import sem
    from .stats import n_samples
    from .stats import n_effective_samples
    from .tests import pretest_numpy
    import math

    def run_product(a, b, c, tqdm_class):
        out = product(range(a), range(b), range(c), tqdm_class=tqdm_class)
        return list(out)

    # TEST: product with iterables of different lengths

# Generated at 2022-06-26 09:21:27.506702
# Unit test for function product
def test_product():
    for x in product([1, 2, 3], ['A', 'B', 'C'], tqdm_class=tqdm_auto):
        pass
    for x in product(range(int(1e5)), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-26 09:21:37.909093
# Unit test for function product
def test_product():
    from operator import add
    import numpy as np
    from ..utils import format_sizeof

    def factorial(n):
        return reduce(add, range(n), 1)

    num_points = 1000000
    num_dims = 7
    total_size = 1
    for dim in range(1, num_dims):
        size = factorial(num_points) / (factorial(dim) * factorial(num_points - dim))
        total_size += size
    print('testing:', num_points, 'points with', num_dims, 'dimensions, total size:',
          format_sizeof(int(total_size)), 'in', end=' ')
    try:
        total_size = np.int64(total_size)
    except MemoryError:
        print('FAIL!')
        return

# Generated at 2022-06-26 09:21:48.199432
# Unit test for function product
def test_product():
    """
    Runs test for function `product`.
    """
    import warnings

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        s = list(product(range(10000)))

        assert len(s) == 10000, "Mismatched lengths: %s" % len(s)
        assert s == list(range(10000)), "Mismatched output: %s ... %s" % \
            (s[:5], s[-5:])
        assert len(w) == 2, "Mismatched warning count: %s" % len(w)
        assert "Usage of product will change" in str(w[0].message)
        assert "Please use tqdm.auto.tqdm instead" in str(w[1].message)



# Generated at 2022-06-26 09:21:51.792834
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from . import _test_itertools
    _test_itertools.test_product(product)

# Generated at 2022-06-26 09:22:00.467430
# Unit test for function product
def test_product():
    """Simple unit test for itertools"""
    from .tqdm_gui import tqdm
    from .itertools import trange

    # Test basic product
    assert list(product([])) == []
    assert list(product([1])) == [(1,)]
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]
    assert list(product([1, 2, 3], [4, 5])) == [(1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]

    # Test with trange in product list
    assert list(product([1, 2, 3], trange(4, 5))) == [(1, 4), (2, 4), (3, 4)]

    # Test with threadsafety

# Generated at 2022-06-26 09:22:11.714220
# Unit test for function product
def test_product():
    """
    Test of function product.
    """
    import sys
    import tqdm
    try:
        from StringIO import StringIO as sio
    except ImportError:  # pragma: no cover
        from io import StringIO as sio
    capture = sio()
    with tqdm.redirect_stdout(capture):
        it = product(range(2), range(3), range(4),
                     tqdm_class=tqdm.tqdm, ascii=True)
        for _ in it:
            pass
    lines = capture.getvalue().split('\n')
    assert len(lines) == 17
    assert lines[-2] == '24it [00:00, 2375.62it/s]'

    # Multi-line
    capture = sio()

# Generated at 2022-06-26 09:22:23.113976
# Unit test for function product
def test_product():
    """ Test the function product """
    from ..auto import trange

    # Test case #1
    list_result = []
    for a in trange(2, desc="1st loop", leave=False):
        for b in trange(2, desc="2nd loop", leave=False):
            for c in trange(2, desc="3rd loop", leave=False):
                list_result.append({'a': a, 'b': b, 'c': c})

    for a, b, c in product(range(2), range(2), range(2)):
        assert list_result.pop({'a': a, 'b': b, 'c': c})

    assert list_result == []

    # Test case #2
    list_result = []

# Generated at 2022-06-26 09:22:30.647161
# Unit test for function product
def test_product():
    from random import random
    from .utils import FormatWrapBase, format_interval
    from .utils import range as trange
    from .utils import StringIO, StringList

    class MyRange(object):
        def __init__(self, n):
            self.n = n

        def __len__(self):
            return self.n

        def __iter__(self):
            return iter(range(self.n))

    class MyList(object):
        def __init__(self, n):
            self.n = n

        def __len__(self):
            return self.n

        def __getitem__(self, i):
            return list(range(self.n))[i]


# Generated at 2022-06-26 09:22:47.172333
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..utils import SimpleNamespace
    import sys
    import os
    import tempfile

    try:
        from resource import getpagesize
    except ImportError:
        getpagesize = lambda: 0
    pagesize = getpagesize()

    def f(a):
        # print("f: start")
        for i in range(a):
            yield i ** 2
            # print("f: yield")
        # print("f: stop")

    def g(a):
        # print("g: start")
        for i in range(a):
            yield i
            # print("g: yield")
        # print("g: stop")

    def h(a):
        # print("h: start")
        for i in range(a):
            yield i
            # print("h:

# Generated at 2022-06-26 09:22:53.638850
# Unit test for function product
def test_product():
    import sys
    import io
    import mock

    with mock.patch('sys.stdout', new_callable=io.StringIO) as mock_stdout:
        for i in product([1, 2], [3, 4],
                         tqdm_class=tqdm_auto,
                         desc="testing",
                         leave=False):
            pass


# Generated at 2022-06-26 09:23:01.550007
# Unit test for function product
def test_product():
    import numpy as np
    try:
        from itertools import count
    except ImportError:
        from tqdm import _tqdm_test_mock as count

    for t in [tqdm_auto, tqdm, trange]:
        with t(total=64) as pbar:
            for _ in product(range(4), range(4), range(4),
                             range(4), tqdm_class=t):
                pbar.update()

        with t(total=64) as pbar:
            for _ in product(range(4), range(4), range(4),
                             range(4), tqdm_class=t):
                pbar.update()
        assert pbar.n == 64
        assert pbar.total == 64

        # itertools returns a generator
        p

# Generated at 2022-06-26 09:23:12.503137
# Unit test for function product
def test_product():
    from ..testing import CUDA, manual_seed
    from ..utils import make_unique

    manual_seed(42)
    for mult in (1, 100, 2 ** 24 - 2):
        it = [list(range(4)) for _ in range(mult)]
        for tqdm_class in (tqdm_auto, CUDA):
            with tqdm_class(total=mult * 4 * 3 * 2 * 1) as t:
                l = make_unique(product(*it, tqdm_class=tqdm_class), return_inverse=True)

# Generated at 2022-06-26 09:23:24.114324
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    # Test without total
    r = list(product("ABCD", "xy"))
    assert r == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                 ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

    # Test with total
    r = list(product("ABCD", "xy", total=8))
    assert r == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                 ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

    # Test non-integer total
    r = list(product("ABCD", "xy", "Z", total=4))
   

# Generated at 2022-06-26 09:23:31.864668
# Unit test for function product
def test_product():
    from ..utils import FormatWrapBase
    from . import trange

    class TestFormatWrap(FormatWrapBase):
        def format_dict(self, d):
            return super(TestFormatWrap, self).format_dict(d)

    for iterable in (range(1000), [], range(10000), self_iterable([])):
        for cls in (tqdm_auto, trange, TestFormatWrap):
            for total in (None, 1000):
                with cls(iterable, total=total) as t:
                    assert list(product(t)) == list(itertools.product(iterable))



# Generated at 2022-06-26 09:23:42.066291
# Unit test for function product
def test_product():
    from .tests import TestCase
    from io import StringIO
    from sys import stdout
    l = range(3, 14)
    n = len(l)

    o = 0
    for _ in product(l, repeat=n):
        o += 1
    assert o == len(l)**n

    o = 0
    with TestCase(stdout=stdout) as testcase:
        for _ in product(l, repeat=n, tqdm_class=testcase.tqdm):
            o += 1
    assert o == len(l)**n

    o = 0

# Generated at 2022-06-26 09:23:52.564239
# Unit test for function product
def test_product():
    import tqdm
    import sys

    def f(a, b, c):
        for i in tqdm.tqdm(product(a, b, c)):
            pass

    f(range(10), range(2), range(3))

    from tqdm import tqdm as tqdm
    from ..main import tqdm as tqdm2
    from tqdm import trange as trange
    from ..main import trange as trange2
    for tqdm_ in (tqdm, tqdm2, trange, trange2):
        for i in tqdm_([1], file=sys.stderr):
            f(range(10), range(2), range(3))

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:57.858764
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal

    from ..utils import format_sizeof

    # Empty
    for i in product():
        assert False

    # Single
    for i in product([1, 2, 3]):
        assert i == (1,), (i, )

    # Two
    for i in range(3):
        for j in range(3):
            assert i * j == next(product([i, j], repeat=2))[0]

    # Three
    for i in range(3):
        for j in range(3):
            for k in range(3):
                assert i * j * k == next(product([i, j, k], repeat=3))[0]

    # Variable

# Generated at 2022-06-26 09:23:59.485802
# Unit test for function product
def test_product():
    for a, b in product(range(2), repeat=2):
        pass

# Generated at 2022-06-26 09:24:18.313770
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except:
        raise ValueError('Test failed')


test_product()

# Generated at 2022-06-26 09:24:25.812461
# Unit test for function product
def test_product():
    # Method to make input parameter
    def sol_input(iterables, **tqdm_kwargs):
        var_0 = product(iterables, **tqdm_kwargs)
        list_0 = [var_0]
        list_1 = module_1.list(*list_0)
        return list_1
    def sol_output(iterables, **tqdm_kwargs):
        var_0 = itertools.product(iterables, **tqdm_kwargs)
        list_0 = [var_0]
        list_1 = module_1.list(*list_0)
        return list_1
    # Test 1
    iterables = [list([1, 2, 3, 4]), list([9, 1]), list([5, 6, 7])]

# Generated at 2022-06-26 09:24:32.007736
# Unit test for function product
def test_product():
    var_0 = product(range(10))
    var_1 = module_1.list(var_0)
    assert var_1 == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

if (__name__ == "__main__"):
    import test
    test.test_product()

# Generated at 2022-06-26 09:24:43.379523
# Unit test for function product
def test_product():
    # TODO: pass
    try:
        from itertools import count
    except ImportError:
        pass
    else:
        iter_0 = count()
        int_0 = next(iter_0)
        int_1 = next(iter_0)
        int_2 = next(iter_0)
        list_0 = [iter_0]
        list_1 = module_1.list(*list_0)
        # TODO: pass
        try:
            from itertools import accumulate
        except ImportError:
            pass
        else:
            # TODO: pass
            functools_0 = module_1.importlib.import_module('functools')
            int_3 = functools_0.reduce((lambda acc, iteration: acc + iteration), list_1)
            var_0 = product

# Generated at 2022-06-26 09:24:49.652086
# Unit test for function product
def test_product():
    import tempfile
    
    # Remove the temporary files
    # You can comment out the following two lines if you don't use them
    #_pbar = tqdm(...)
    #_pbar.close()
    # Remove the temporary files
    #set_file_binary()
    test_case_0()
    test_case_0()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:24:51.949803
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except:
        import traceback
        traceback.print_exc()
        assert (False)


# Generated at 2022-06-26 09:24:52.801219
# Unit test for function product
def test_product():
  pass

# Generated at 2022-06-26 09:24:54.920836
# Unit test for function product
def test_product():
    # Function with no args
    test_case_0()

# Generated at 2022-06-26 09:25:05.321950
# Unit test for function product
def test_product():
    assert [i for i in product(range(2), range(2))] == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert [i for i in product(range(2), range(2), range(2))] == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-26 09:25:13.623101
# Unit test for function product
def test_product():
    list_0 = [1]
    list_1 = [2]
    list_2 = [3]
    list_3 = [4]
    list_4 = [list_2, list_3]
    list_5 = module_1.list(*list_4)
    for var_0 in product(list_0, list_1, *list_5):
        assert (var_0 == 1)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:25:33.964544
# Unit test for function product
def test_product():
    pass



# Generated at 2022-06-26 09:25:46.112108
# Unit test for function product
def test_product():
    import hypothesis
    import hypothesis.strategies
    float_0 = float
    int_0 = int
    none_0 = None
    none_1 = None
    slice_0 = slice(1, 10, 2)
    str_0 = str
    @hypothesis.given(hypothesis.strategies.just(str_0))
    def test_strategy_1(strategy):
        hypothesis.stategy = strategy
        list_0 = strategy
    @hypothesis.given(hypothesis.strategies.just(slice_0))
    def test_strategy_2(strategy):
        hypothesis.stategy = strategy
        list_0 = strategy

# Generated at 2022-06-26 09:25:58.634436
# Unit test for function product
def test_product():
    from unittest import mock
    from itertools import product
    with mock.patch.object(tqdm_auto, "__init__", side_effect=lambda *args, **kwargs: None):
        with mock.patch.object(tqdm_auto, "update", side_effect=lambda *args, **kwargs: None):
            with mock.patch.object(tqdm_auto, "__exit__", side_effect=lambda *args, **kwargs: None):
                with mock.patch.object(tqdm_auto, "__enter__", return_value=mock.Mock()):
                    for n in range(10):
                        assert list(tqdm.product(*[range(n)] * n)) == list(product(*[range(n)] * n))


# Generated at 2022-06-26 09:26:00.065065
# Unit test for function product
def test_product():

    assert type(product()) == itertools.product

# Generated at 2022-06-26 09:26:08.719793
# Unit test for function product
def test_product():
    # Partition into groups based on the type of the track
    prop_0 = product(list_0, iter_0, list_1, iter_1, object_0, object_1)
    prop_1 = product(list_0, list_1, iter_0, iter_1, object_0, object_1)
    prop_2 = product('ABCD', 'xy')
    prop_3 = product(range(2), repeat=3)
    prop_4 = product(range(2), repeat=3)
    prop_5 = product(range(2), repeat=3)
    # Iterate over the groups
    for prop_6 in list_0:
        pass
    # Iterate over the groups
    for prop_7 in list_0:
        pass

# Generated at 2022-06-26 09:26:16.154226
# Unit test for function product
def test_product():
    var_1 = product()
    module_1.print(*var_1)
    var_2 = product(var_1)
    module_1.print(*var_2)
    var_3 = product(var_1, var_2)
    module_1.print(*var_3)
    var_4 = product(var_1, var_2, var_3)
    module_1.print(*var_4)
    var_5 = product(var_1, var_2, var_3, var_4)
    module_1.print(*var_5)


# Generated at 2022-06-26 09:26:26.482736
# Unit test for function product
def test_product():
    assert tqdm(itertools.product((0, 1), (0, 1))) == [0, 0, 0, 1, 1, 0, 1, 1]
    assert tqdm(itertools.product((0,))) == [0]

if __name__ == '__main__':
    list_0 = [1, 2, 3, 4]
    list_1 = [1, 2, 3, 4]
    list_2 = [1, 2, 3, 4]
    list_3 = [1, 2, 3, 4]
    list_4 = [1, 2, 3, 4]
    module_0 = product(list_0, list_1, list_2, list_3, list_4)
    try:
        module_1 = iter(module_0)
    except TypeError:
        pass

# Generated at 2022-06-26 09:26:29.380218
# Unit test for function product
def test_product():
    for var_1 in product():
        pass

for var_2 in product():
    pass

# Generated at 2022-06-26 09:26:33.207498
# Unit test for function product
def test_product():
    var_0 = product('ABCD', 'xy')
    list_0 = [var_0]
    list_1 = module_1.list(*list_0)

# Generated at 2022-06-26 09:26:37.649201
# Unit test for function product
def test_product():
    arg0 = None
    arg1 = None
    arg2 = None

    # Call function
    retval = product(arg0, arg1, arg2)

    # Check type of return value
    assert isinstance(retval, )
    # Check value of return value

# Generated at 2022-06-26 09:26:58.863288
# Unit test for function product
def test_product():
    try:
        product()
    except Exception as e:
        assert("KeyError('total'" in str(e))


# Generated at 2022-06-26 09:26:59.634447
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:27:08.498569
# Unit test for function product
def test_product():
    """
    Unit test for function product

    Returns:

    """
    test_array = [module_1.range(6)]
    list_1 = module_1.list(module_1.range(6))
    var_0 = product(*test_array, tqdm_class=module_1.range)
    list_1 = module_1.list(module_1.range(6))
    module_1.setattr(var_0, module_1.__name__, list_1)
    if module_1.len(list_1) >= 2:
        var_1 = module_1.next(var_0)
        var_2 = list_1[module_1.len(list_1) // 2]
        module_1.assertEqual(var_1, var_2)

# Generated at 2022-06-26 09:27:11.036115
# Unit test for function product
def test_product():
    expected_value_0 = None
    expected_value_1 = None
    return None


# End of test_product

# Generated at 2022-06-26 09:27:11.861301
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:27:14.627814
# Unit test for function product
def test_product():
    assert module_1.isinstance(product("ABCD", "xy"), module_1.list)
    assert module_1.isinstance(product(*["ABCD", "xy"]), module_1.list)
test_case_0()

# Generated at 2022-06-26 09:27:25.143962
# Unit test for function product
def test_product():
    # float() arguments must be a string or a number, not 'filter'
    # TypeError: 'filter' object is not subscriptable
    # list_0 = filter(product, '')
    # list_0 = filter(product, '', )
    # str_0 = str(product, '', )
    # str_0 = str(product, '', )
    # tuple_0 = tuple(product, '', )
    # tuple_0 = tuple(product, '', )
    # list_1 = [product, '', ]
    # list_1 = [product, '', ]
    pass


# Generated at 2022-06-26 09:27:26.984057
# Unit test for function product
def test_product():
    # TODO: implement your test here
    raise NotImplementedError()

# Generated at 2022-06-26 09:27:35.608360
# Unit test for function product
def test_product():
    var_0 = [1, 2, 3]
    var_1 = [4, 5, 6]
    var_2 = [7, 8, 9]

    list_0 = [var_0, var_1, var_2]
    list_1 = [var_1, var_0, var_2]
    list_2 = [var_2, var_1, var_0]
    list_3 = [var_2, var_0, var_1]
    list_4 = [var_1, var_2, var_0]
    list_5 = [var_0, var_2, var_1]

    def func_5(arg_3):
        func_0 = product(*arg_3)
        expected_result = 1
        # assert func_0.__next__() == expected_result


# Generated at 2022-06-26 09:27:37.363306
# Unit test for function product
def test_product():
    assert not product()


# Generated at 2022-06-26 09:28:10.426470
# Unit test for function product
def test_product():
    # Testing with keyword args
    for total in [None, 10]:
        with tqdm_auto(total) as pbar:
            it = product([2, 3, 4], repeat=2, total=total,
                         tqdm_class=tqdm_auto)
            assert [x for x in it] == [(2, 2), (3, 2), (4, 2),
                                       (2, 3), (3, 3), (4, 3),
                                       (2, 4), (3, 4), (4, 4)]
            assert pbar.n == 8

    # Testing with positional args
    with tqdm_auto() as pbar:
        it = product("1234", repeat=2, tqdm_class=tqdm_auto)

# Generated at 2022-06-26 09:28:17.319618
# Unit test for function product
def test_product():
    list_0 = list(product())
    list_1 = list(product(range(3)))
    assert list_0 == [(1, ), (1, )], "Expected [('1', ), ('1', )], got {0}".format(list_0)
    assert list_1 == [(0, ), (1, ), (2, )], "Expected [(0, ), (1, ), (2, )], got {0}".format(list_1)
    list_2 = list(product(range(2), repeat=2))
    list_3 = list(product(range(1, 3), repeat=2))

# Generated at 2022-06-26 09:28:25.051568
# Unit test for function product
def test_product():
    assert [_ for _ in product(range(2), range(4))] == [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2), (1, 3)]
    assert [_ for _ in product(range(2), range(4), tqdm_class=tqdm_auto)] == [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2), (1, 3)]

# Generated at 2022-06-26 09:28:27.404159
# Unit test for function product
def test_product():
    list_0 = product(0, 0)
    list_1 = module_1.list(*list_0)

# Generated at 2022-06-26 09:28:36.938360
# Unit test for function product
def test_product():
    var_1 = iter([1, 2, 3, 4])
    var_2 = iter([4, 3, 2, 1])
    total = 4
    var_3 = tuple(range(0, 2))
    def func_0(a, b):
        return (var_1, var_2, total, var_3)
    var_4 = func_0(*(iter([1, 2, 3, 4])))
    var_5 = func_0(*(iter([4, 3, 2, 1])))
    var_6 = func_0(*(iter([1, 2, 3, 4])))
    var_7 = func_0(*(iter([4, 3, 2, 1])))
    var_8 = func_0(*(iter([1, 2, 3, 4])))

# Generated at 2022-06-26 09:28:45.935324
# Unit test for function product
def test_product():
    result = product(range(3), range(3), range(3))
    assert isinstance(result, itertools.product)
    list_0 = []
    while True:
        try:
            list_0.append(next(result))
        except StopIteration as exc_0:
            break

# Generated at 2022-06-26 09:28:57.606092
# Unit test for function product
def test_product():
    var_2 = product()
    print(var_2)
    print(module_1.type(var_2))
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
    print(var_2.__next__())
   

# Generated at 2022-06-26 09:28:59.791796
# Unit test for function product
def test_product():
    assert True == True


# Generated at 2022-06-26 09:29:06.084517
# Unit test for function product
def test_product():
    import pytest
    import sys
    import os

    fd, temp_file = pytest.build_ood_test_fd(
        os.path.join(os.path.dirname(__file__),
                    'test_product.ood'),
        'test_product')
    try:
        pytest.main(['--ood-file-delete-on-exit', temp_file])
    finally:
        os.close(fd)
    pytest.main(['--ood-file-delete-on-exit', temp_file])

# Generated at 2022-06-26 09:29:07.066361
# Unit test for function product
def test_product():
    pass