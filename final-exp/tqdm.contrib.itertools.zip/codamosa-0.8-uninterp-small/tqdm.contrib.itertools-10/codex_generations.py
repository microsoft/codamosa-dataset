

# Generated at 2022-06-26 09:20:05.378767
# Unit test for function product
def test_product():
    var_0 = product(range(10))
    for i in var_0:
        pass
    product(range(10), total=10)
    product(range(10), tqdm_class=range)
    product([[], []])
    product(range(10), total=10, tqdm_class=range)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:20:06.206393
# Unit test for function product
def test_product():
    assert True


# Generated at 2022-06-26 09:20:09.880991
# Unit test for function product
def test_product():
    iterables = [["abc", "def"], [1, 2]]
    it = product(*iterables)
    for i in it:
        assert isinstance(i, tuple)
        assert len(i) == len(iterables)


# Generated at 2022-06-26 09:20:21.815912
# Unit test for function product
def test_product():
    # automatically set up docstring
    try:
        if 'sf_helpers.itertools_hacks.product' in globals():
            globals()['__doc__'] = globals()['sf_helpers.itertools_hacks.product'].__doc__
    except Exception:
        pass

    # Automatic type checking
    # Call signature: product(*iterables, **tqdm_kwargs)
    # Arguments *iterables: *  .
    # Returns iter
    # Params tqdm_class : [default: tqdm.auto.tqdm].


# Generated at 2022-06-26 09:20:32.189621
# Unit test for function product
def test_product():
    print("Testing product...", end="")
    assert(list(product(range(3))) == [(0,), (1,), (2,)])
    assert(list(product(range(3), repeat=2)) == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)])

# Generated at 2022-06-26 09:20:44.115485
# Unit test for function product
def test_product():
    from .__init__ import tqdm
    from .utils import SimpleTimer

    # Testing all tqdm types (except tqdm_gui and tqdm_notebook)
    for t in [tqdm, tqdm.tqdm, tqdm.trange]:
        # Test unicode
        res = list(t.product(['a', 'b'], repeat=3))
        n = len(res)

# Generated at 2022-06-26 09:20:46.041132
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:20:51.059810
# Unit test for function product

# Generated at 2022-06-26 09:20:59.784692
# Unit test for function product
def test_product():
    f = product((1, 2, 3), ('a', 'b', 'c'))
    assert next(f) == (1, 'a')
    assert next(f) == (1, 'b')
    assert next(f) == (1, 'c')
    assert next(f) == (2, 'a')
    assert next(f) == (2, 'b')
    assert next(f) == (2, 'c')
    assert next(f) == (3, 'a')
    assert next(f) == (3, 'b')
    assert next(f) == (3, 'c')

# Generated at 2022-06-26 09:21:10.678004
# Unit test for function product
def test_product():
    from ..tqdm_test_case import TqdmTestCase
    test = TqdmTestCase()

    for _ in test.iterate_tests(func=test_case_0):
        pass

    with test.disable_atclose():
        test_case_1 = test.start_new_test()
        for x in product(['a', 'b', 'c'], repeat=2):
            assert isinstance(x, tuple)
            assert len(x) == 2
            assert (x[0] in ['a', 'b', 'c'] and
                    x[1] in ['a', 'b', 'c'])
            test_case_1.update()
        test_case_1.close()

        test_case_2 = test.start_new_test()

# Generated at 2022-06-26 09:21:16.245148
# Unit test for function product
def test_product():
    from ..utils import PY3, range_
    iterable = (H for H in range_(10))
    for i in product(iterable, iterable):
        assert i[0] < 10
        assert i[1] < 10

# Generated at 2022-06-26 09:21:27.547450
# Unit test for function product
def test_product():
    from .tests import tqdm_class
    from .tests import range

    def _test(count, iterable, expected_sum, tqdm_class, range):
        assert sum(tqdm_class(range(count), total=count, tqdm_class=tqdm_class)) == expected_sum
        assert sum(tqdm_class(range(count), total=tqdm_class(count), tqdm_class=tqdm_class)) == expected_sum
        assert sum(tqdm_class(range(count), total=len(range(count)), tqdm_class=tqdm_class)) == expected_sum
        assert sum(tqdm_class(range(count), total=None, tqdm_class=tqdm_class)) == expected_sum

# Generated at 2022-06-26 09:21:33.531764
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .utils import FormatMixinTest
    iterables = [[1, 2], [1, 2, 3]]
    with tqdm_auto(total=12, leave=False, mininterval=0) as t:
        for _ in product(*iterables):
            t.update()
    assert t.n == 12
    FormatMixinTest.test_format(t)

# Generated at 2022-06-26 09:21:37.472364
# Unit test for function product
def test_product():
    """Test for product"""
    q = []
    for _ in product(range(5), range(5), tqdm_class=tqdm_auto):
        q.append(1)
    assert sum(q) == 25, "Failed test_product"



# Generated at 2022-06-26 09:21:46.346486
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_raises, assert_equal

    with tqdm_auto(total=3 * 4 * 5) as t:
        for _ in product(range(3), range(4), range(5)):
            t.update()

    with tqdm_auto(total=0) as t:
        for _ in product(range(0), range(0), range(0)):
            t.update()

    with tqdm_auto(total=None) as t:
        for _ in product(np.arange(10)):  # noqa: F841
            t.update()

# Generated at 2022-06-26 09:21:57.902387
# Unit test for function product
def test_product():
    """
    Test for product
    """
    assert (list(product([], [], [], [], tqdm_class=tqdm_auto)) ==
            list(itertools.product([], [], [], [])))
    assert (list(product(range(4), repeat=2, tqdm_class=tqdm_auto)) ==
            list(itertools.product(range(4), repeat=2)))
    it = product(range(4), repeat=2,
                 tqdm_class=tqdm_auto, unit="foobars")
    assert (next(it) ==
            (0, 0))
    assert (list(it) ==
            list(itertools.product(range(1, 4), repeat=2)))


# TODO: unit tests
# product.__doc__ = test

# Generated at 2022-06-26 09:22:08.883704
# Unit test for function product
def test_product():
    import sys
    try:
        from theano.tensor.tests.test_sharedvar import assert_allclose
    except ImportError:
        def assert_allclose(x, y, atol=1e-9, msg=''):
            assert x == y, '%s != %s' % (x, y)

    # https://github.com/tqdm/tqdm/issues/711
    try:
        from itertools import izip as zip
    except ImportError:
        pass
    from tqdm import tqdm

    def product(*iterables, **tqdm_kwargs):
        """
        Equivalent of `itertools.product`.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        k

# Generated at 2022-06-26 09:22:13.419704
# Unit test for function product
def test_product():
    from ..tests import ttest
    r = product(list(range(10)), list(range(10)), tqdm_class=ttest.mock_tqdm)
    ttest.assert_eq(list(r), list(itertools.product(list(range(10)), list(range(10)))))

# Generated at 2022-06-26 09:22:20.735343
# Unit test for function product
def test_product():
    import sys

    canary_i, canary_j = 0, 0
    for i, j in product(range(10), range(30),
                        tqdm_class=tqdm_auto, ascii=True,
                        desc="product test", file=sys.stdout):
        canary_i = i
        canary_j = j
    assert canary_i == 9
    assert canary_j == 29

# Generated at 2022-06-26 09:22:29.337322
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    from ..utils import format_sizeof
    from .utils import format_timesofar

    from time import time

    import numpy as np

    from ..__main__ import main as tqdm_cli
    from .__main__ import main as tqdm_cli_utils

    from .tests_tqdm import pretest_posttest, closing

    # `product`
    for tqdm_cls in [tqdm_auto]:
        def bar(m):
            for ii in product(range(m), repeat=2, tqdm_class=tqdm_cls):
                pass

        pretest_posttest(bar, 10)
        pretest_posttest(bar, 10, 100)

# Generated at 2022-06-26 09:22:40.687571
# Unit test for function product
def test_product():
    try:
        from itertools import product as it_product
    except ImportError:
        # no itertools module, still test our function
        it_product = None
    from collections import Iterable
    assert isinstance(product(range(3)), Iterable)
    assert next(product(range(3))) == (0,)
    assert list(product(range(3))) == list(it_product(xrange(3)))
    assert sorted(list(product(range(3), repeat=1))) == sorted(it_product(xrange(3), repeat=1))
    assert sorted(list(product(range(3), repeat=-1))) == sorted(it_product(xrange(3), repeat=-1))

# Generated at 2022-06-26 09:22:45.930399
# Unit test for function product
def test_product():
    for i in product(*[range(10), range(10), range(10), range(10),
                       range(10), range(10), range(10), range(10),
                       range(10), range(10), range(10), range(10)],
                    ascii=True, miniters=1, mininterval=0.1,
                    maxinterval=0.1, unit_scale=False):
        pass

# Generated at 2022-06-26 09:22:49.843605
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    try:
        tqdm_auto
    except Exception:
        print('No tqdm module found.')
    else:
        try:
            list(product(range(0, 10), range(1, 11)))
            print('Success.')
        except Exception:
            print('Failure.')

# Generated at 2022-06-26 09:22:59.716559
# Unit test for function product
def test_product():
    # Test input format verification
    try:
        list(product(iter(range(10)), {}, tqdm_class=tqdm_auto))
    except TypeError:
        pass
    else:
        assert False, "Test failed: should have raised a TypeError"
    try:
        list(product(iter(range(10)), {}, total=10))
    except TypeError:
        pass
    else:
        assert False, "Test failed: should have raised a TypeError"
    try:
        list(product(iter(range(10)), {}, total=False))
    except TypeError:
        pass
    else:
        assert False, "Test failed: should have raised a TypeError"
    # Test product
    res = product((1, 2), (3, 4), plain=True)

# Generated at 2022-06-26 09:23:09.345956
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.random import rand
    from ..utils import ncols
    from .utils import FormatWarn
    iterables = [[str(i) for i in rand(5)], rand(4), rand(2)]
    for use_tqdm in [False, True]:
        print('Use tqdm: %r' % use_tqdm)
        with FormatWarn(''):
            if use_tqdm:
                aggr = product(*iterables, total=None)
            else:
                aggr = itertools.product(*iterables)
            aggr = list(aggr)
        print('len(agg) = %s' % (len(aggr),))
        aggr = list(aggr)
        print(ncols(aggr, " | "))

# Generated at 2022-06-26 09:23:14.990396
# Unit test for function product
def test_product():
    import sys
    iterables = [[1, 2], [3, 4]]
    for i in product(*iterables, mininterval=0.001,
                     file=sys.stdout,
                     miniters=1):
        pass


# Remove this unit test in future.

# Generated at 2022-06-26 09:23:19.232765
# Unit test for function product
def test_product():
    # Test list
    A = ['0', '1']

    # Test product (more complex, multi-dimensional)
    for a in product(A, repeat=4):
        assert (len(a) == 4)

# Generated at 2022-06-26 09:23:28.951036
# Unit test for function product
def test_product():
    import sys
    import random
    import math
    random.seed(0)
    from .utils import _range
    from .utils import FormatCustomStr

    if sys.version_info[0] == 2:
        from itertools import product as iproduct
    else:
        from functools import reduce
        from itertools import product as iproduct
        try:
            from functools import reduce
        except ImportError:
            pass
        else:
            def product(*iterables):
                return reduce(lambda x, y: x*y, [1]+list(map(len, iterables)))

    # test when postfix not given
    l1 = list(product(_range(10), _range(2), _range(10),
                      tqdm_class=tqdm_auto))

# Generated at 2022-06-26 09:23:40.949577
# Unit test for function product
def test_product():
    import math
    import os
    import sys
    import time

    iproduct = itertools.product
    tproduct = product

    if 'TRAVIS' in os.environ:
        # Travis tests are too slow to test any except the tqdm_auto cases
        # TODO: implement a faster `product` test in the future
        try:
            from tqdm import tqdm
            tqdm.set_lock(False)
        except ImportError:
            _tproduct = tproduct
        else:
            _tproduct = (lambda *args, **kwargs: tproduct(*args,
                                                         tqdm_class=tqdm,
                                                         **kwargs))
    else:
        tqdm.set_lock(False)
        _tproduct = tproduct


# Generated at 2022-06-26 09:23:51.990006
# Unit test for function product
def test_product():
    from .tqdm import trange, tqdm
    from collections import Counter

    for cls in [tqdm, trange]:
        for i in product([0, 1], repeat=3, tqdm_class=cls):
            pass
        for i in product([0, 1], repeat=3, tqdm_class=cls):
            pass

    with tqdm(total=10, mininterval=0) as t:
        res = sum(product('abcd', repeat=3, tqdm_class=tqdm, tqdm=t))
    assert res == 'abcdabcdabcdabcdabcdabcdabcdabcdabcdabcd'


# Generated at 2022-06-26 09:24:09.634607
# Unit test for function product
def test_product():
    import sys
    assert not list(product(range(2), repeat=2,  # noqa: F821
                            tqdm_class=None)) == sys.version_info
    assert list(product(range(2), repeat=2,  # noqa: F821
                        tqdm_class=tqdm_auto)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-26 09:24:17.228279
# Unit test for function product
def test_product():
    import subprocess
    import sys
    out = sys.stdout
    err = sys.stderr

    sys.stdout = subprocess.PIPE
    sys.stderr = subprocess.PIPE
    try:
        assert [u for u in product(range(10), repeat=2)] == \
               [u for u in itertools.product(range(10), repeat=2)]
        print("TEST PASSED")
    except AssertionError:
        print("TEST FAILED")
    finally:
        sys.stdout = out
        sys.stderr = err

# Generated at 2022-06-26 09:24:25.387113
# Unit test for function product
def test_product():
    from collections import Counter

    def rand_iter():
        import random
        for i in range(10):
            yield random.random()

    actual_cnt = Counter(rand_iter())
    weighted_cnt = Counter(rand_iter())
    weighted_cnt.update(rand_iter())
    actual_prod = set(itertools.product(actual_cnt.keys(), repeat=2))
    weighted_prod = set(itertools.product(weighted_cnt.keys(), repeat=2))
    actual_pairs = set(
        (i, j) for (i, j) in actual_prod
        if actual_cnt[i] >= 2 and actual_cnt[j] >= 2
    )

# Generated at 2022-06-26 09:24:36.046494
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .utils import format_interval
    import time
    import os
    import tempfile
    import shutil
    a_max = range(5)
    b_max = range(10)
    c_max = range(20)
    d_max = range(1000)
    e_max = range(1000)
    f_max = range(1000)

    tmp_folder = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_folder, 'temp_file')
    fp = open(tmp_file, 'w')
    print("Unit test for itertools.product.\n"
          "Generating a file with all possible outputs (3 GB of data)\n"
          "This is computationally intensive and may take many minutes...")

    start_

# Generated at 2022-06-26 09:24:44.962060
# Unit test for function product
def test_product():
    from .tqdm import trange
    for i in trange(2, 5):
        for j in trange(3, 6):
            for k in product(range(i), range(j)):
                pass
            for k in product(range(i), range(j)):
                pass
    for i in trange(2, 5):
        for j in trange(3, 6):
            for k in product(range(i), range(j), tqdm_class=trange):
                pass
            for k in product(range(i), range(j), tqdm_class=trange):
                pass

# Generated at 2022-06-26 09:24:51.828587
# Unit test for function product
def test_product():
    """Test whether product() works the same as itertools.product()"""
    from ._utils import TestBuffer

    out1 = []
    out2 = []
    for i in product(range(10), repeat=2, tqdm_class=TestBuffer):
        out1.append(i)
    for i in itertools.product(range(10), repeat=2):
        out2.append(i)
    assert out1 == out2



# Generated at 2022-06-26 09:25:03.880193
# Unit test for function product
def test_product():
    from .tqdm_test_cases import tqdm, range
    assert list(product(tqdm(range(3)), "ABC")) \
        == [(0, 'A'), (0, 'B'), (0, 'C'), (1, 'A'), (1, 'B'), (1, 'C'),
            (2, 'A'), (2, 'B'), (2, 'C')]
    assert list(product([tqdm(range(3)), "ABC"])) \
        == [(0, 'A'), (0, 'B'), (0, 'C'), (1, 'A'), (1, 'B'), (1, 'C'),
            (2, 'A'), (2, 'B'), (2, 'C')]

# Generated at 2022-06-26 09:25:15.749825
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tqdm_pandas import tqdm_pandas
    from ..utils import format_sizeof
    size_arrays = [
        (1, 10000),
        (2, 1000),
        (3, 100),
        (4, 10),
        (5, 1),
        (10, 1),
        (100, 1),
        (1000, 1),
        ]
    for n, m in size_arrays:
        prod_gen = product(range(n), range(m), tqdm_class=tqdm_pandas, tqdm_args={'total': n * m})
        prod = [i for i in prod_gen]
        assert len(prod) == n * m

# Generated at 2022-06-26 09:25:26.591758
# Unit test for function product
def test_product():
    from unittest import main
    import platform
    import sys
    from .tests_tqdm import pretest_posttest, with_unit_option

    def pretest(module):
        module.iterables = [range(3), range(3)]
        module.p = itertools.product(*module.iterables)

        class Mytqdm(tqdm_auto):
            @staticmethod
            def display(*args, **kwargs):
                # disable output
                pass

        module.Mytqdm = Mytqdm

        # unit tests
        try:
            module.assertRegex = module.assertRegexpMatches
        except AttributeError:
            pass

# Generated at 2022-06-26 09:25:31.978915
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests_tqdm import with_setup, pretest, posttest, _range, closing

    @with_setup(pretest, posttest)
    def test():
        """Function product unit test"""
        # Basic test
        with closing(tqdm_auto()) as t:
            assert list(t.__call__(product(_range(5), _range(5)))) == \
                list(product(_range(5), _range(5)))

        assert list(product(_range(5), _range(5))) == \
            list(product(_range(5), _range(5)))

        # Assert that tqdm raises an exception if *lens* is not a list

# Generated at 2022-06-26 09:25:55.292195
# Unit test for function product
def test_product():
    with tqdm_auto(total=None) as t:
        for i in product([1, 2, 3], tqdm_class=t.__class__):
            #print(i)
            pass

# Generated at 2022-06-26 09:26:04.999495
# Unit test for function product
def test_product():
    assert list(product(xrange(3), xrange(3), xrange(3))) == \
        list(itertools.product(xrange(3), xrange(3), xrange(3)))
    assert list(product((None, None))) == [[None, None]]
    assert list(product(*[])) == list(itertools.product())
    assert list(product(range(4), range(4))) == \
        list(itertools.product(range(4), range(4)))


if __name__ == '__main__':
    from .main import _test_itertools
    _test_itertools('product')

# Generated at 2022-06-26 09:26:15.648991
# Unit test for function product
def test_product():
    """Test the product function unit"""
    import sys
    assert list(product([0, 1])) == list(itertools.product([0, 1]))
    assert list(product([0, 1], [0, 1], [0, 1])) == list(itertools.product([0, 1], [0, 1], [0, 1]))
    assert list(product([0, 1], [0, 1], [0, 1], tqdm_class=tqdm_auto, file=sys.stdout)) == list(
        itertools.product([0, 1], [0, 1], [0, 1]))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:26:26.342093
# Unit test for function product
def test_product():
    """ Unit test for function product """
    from .utils import _range
    assert list(product(_range(4), _range(4))) == [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2), (1, 3), (2, 0), (2, 1), (2, 2), (2, 3), (3, 0), (3, 1), (3, 2), (3, 3)]

# Generated at 2022-06-26 09:26:37.409187
# Unit test for function product
def test_product():
    """Test that tqdm.itertools.product == itertools.product"""
    from numpy.testing import assert_equal
    l = list(range(0, 7))
    l2 = list(range(7, 10))
    l3 = list(range(10, 12))
    a = list(product(l, l2, l3, tqdm_class=tqdm_auto))
    b = list(itertools.product(l, l2, l3))
    assert_equal(a, b)


if __name__ == "__main__":
    from .main import _main
    _main(__file__)

# Generated at 2022-06-26 09:26:47.902805
# Unit test for function product
def test_product():
    import decimal
    import math
    import random
    from itertools import product as orig_product

    def product(iterable, repeat=1):
        return orig_product(*[iter(iterable)]*repeat)

    def test_empty():
        res = list(tqdm(product(range(0), repeat=3), miniters=1))
        assert res == []

        res = list(tqdm(product(range(10), range(0), repeat=2), miniters=1))
        assert res == []

    def test_reversed():
        res = list(tqdm(product(reversed(range(10)), repeat=2), miniters=1))
        assert res == list(product(reversed(range(10)), repeat=2))


# Generated at 2022-06-26 09:26:54.542343
# Unit test for function product
def test_product():
    import numpy as np
    assert (list(product(range(3), range(1, 3))) ==
            [x for x in itertools.product(range(3), range(1, 3))])
    assert (list(product(np.array([np.arange(3), np.arange(3)]))) ==
            list(itertools.product(np.arange(3), np.arange(3))))

# Generated at 2022-06-26 09:27:06.629128
# Unit test for function product
def test_product():
    """ Unit test for function product """
    from ..pandas import tqdm_pandas

    def identity(i):
        return i

    expect = range(5)
    assert list(product(range(5))) == expect
    assert list(product(range(5), range(5))) == [(a, b) for a in expect for b in expect]

    for _ in tqdm_pandas(product(range(5), range(5))):
        pass

    for _ in tqdm_pandas(product(range(5), range(5)), leave=True):
        pass

    for _ in tqdm_pandas(product(range(5), range(5)), total=25):
        pass


# Generated at 2022-06-26 09:27:08.548953
# Unit test for function product
def test_product():
    """
    Test for `product`
    """

# Generated at 2022-06-26 09:27:14.841941
# Unit test for function product
def test_product():
    from .utils import closing

    iterables = [[1, 2, 3], ["a", "b", "c"]]

    for total_unit in (None, "step"):
        with closing(tqdm_auto(total=total_unit)) as pbar:
            for i in product(*iterables):  # pytype: disable=not-an-iterable
                assert i in [tuple(j) for j in itertools.product(*iterables)]
                pbar.update()

# Generated at 2022-06-26 09:27:25.291848
# Unit test for function product
def test_product():
    assert test_case_0() == None

# ----


# Generated at 2022-06-26 09:27:34.958313
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], [4, 5, 6])) == [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]
    assert list(product([1, 2, 3], repeat=2)) == [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]

# Generated at 2022-06-26 09:27:46.048010
# Unit test for function product
def test_product():

    var_0 = 8.287
    try:
        var_0 = product([], tqdm_class=var_0)
    finally:
        var_0.close()
    try:
        var_0 = product([], tqdm_class=var_0)
    finally:
        var_0.close()
    var_0 = product([[]], tqdm_class=tqdm_auto)
    var_1 = [i for i in var_0]
    var_0 = product([[[]], [[]]], tqdm_class=tqdm_auto)
    var_2 = [i for i in var_0]
    var_0 = product([[], [[]]], tqdm_class=tqdm_auto)
    var_3 = [i for i in var_0]

# Generated at 2022-06-26 09:27:52.061895
# Unit test for function product
def test_product():
    assert product(*[range(100), range(100)]) == itertools.product(range(100), range(100))
    assert product(*[range(100), range(100)], tqdm_class=tqdm_auto) == itertools.product(range(100), range(100))

if __name__=="__main__":
    print(test_product())

# Generated at 2022-06-26 09:28:04.685228
# Unit test for function product
def test_product():
    from collections import abc
    import random
    try:
        from multiset import Multiset
    except ImportError:
        from .multiset import Multiset

    # Test normal use
    a = [1, 2, 3, 4]
    b = ["a", "b", "c"]
    # Test length == 1
    a1 = [1]
    b1 = ["a"]
    # Test index != 0
    a2 = [1, 2, 3, 4][1:]
    b2 = ["a", "b", "c"][1:]

    def internal_test(a_, b_):
        t = tqdm_auto(total=None, miniters=None, mininterval=0)
        out = product(a_, b_, tqdm_class=t)

# Generated at 2022-06-26 09:28:13.121413
# Unit test for function product
def test_product():
    int_0 = -1169
    str_0 = 'c'
    var_0 = [int_0, str_0]
    var_1 = product(*var_0)
    var_2 = [tuple(j) for j in var_1]
    assert var_2 == list(itertools.product(*var_0))

# vim: set sts=4 sw=4 ts=4 et:

# Generated at 2022-06-26 09:28:20.617472
# Unit test for function product
def test_product():
    _ = product(range(4), range(4), range(4), range(4), range(4), range(4), range(4), range(4), range(4), range(4), range(4), range(4), tqdm_class=tqdm_auto)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:28:22.753028
# Unit test for function product
def test_product():
    # Write test function here.
    ...


# Generated at 2022-06-26 09:28:31.560326
# Unit test for function product
def test_product():
    # Check the itertools usage:
    itertools.product()
    itertools.product(range(3), repeat=2)
    itertools.product(range(3), repeat=3)
    itertools.product(range(3), range(4), range(5), repeat=2)
    # Actual test cases
    range_0 = range(5)
    range_1 = range(4)
    range_2 = range(3)
    range_3 = range(2)
    range_4 = range(1)
    var_0 = range_3, range_4, range_0
    var_1 = product(var_0)
    result_0 = [tuple(j) for j in var_1]
    var_2 = range_2, range_4

# Generated at 2022-06-26 09:28:32.973534
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:28:54.348906
# Unit test for function product
def test_product():
    int_1 = -1173
    int_2 = 5
    var_6 = [int_1, int_2]
    var_7 = product(*var_6)
    var_8 = [tuple(j) for j in var_7]
    print(var_8)

# Generated at 2022-06-26 09:28:55.672757
# Unit test for function product
def test_product():
    # Case 0:
    test_case_0()

# Generated at 2022-06-26 09:29:01.057670
# Unit test for function product
def test_product():
    # Case 0
    int_0 = -1173
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = [tuple(j) for j in var_1]


# Generated at 2022-06-26 09:29:08.115091
# Unit test for function product
def test_product():
    var_0 = [1]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert var_2 == [(1,)]
    var_3 = product(range(1, 10))
    # TODO: change this to ...
    var_4 = list(var_3)
    assert len(var_4) == 362880
    var_5 = product(range(1000))
    try:
        var_6 = len(var_5)  # len() is not supported for generators
        assert False
    except TypeError:
        pass
    assert var_5.n == 0

    # test total
    var_7 = product(range(1000), tqdm_class=tqdm_auto)
    var_8 = len(var_7)
    assert var_7

# Generated at 2022-06-26 09:29:08.680317
# Unit test for function product
def test_product():
    assert type(test_case_0()) == list

# Generated at 2022-06-26 09:29:14.313719
# Unit test for function product
def test_product():
    # Initializations
    var_0 = [(0.1, 0.2), (0.3, 0.4)]
    var_1 = product(*var_0)
    var_2 = [tuple(j) for j in var_1]
    # Assertions
    assert var_1
    assert var_2
    # Assignment
    var_3 = next(var_1)
    # Assertions
    assert var_3
    # Assignment
    var_4 = 0.1
    # Assertions
    assert var_4
    # Assignment
    var_5 = 0.2
    # Assertions
    assert var_5
    # Assignment
    var_6 = [var_4, var_5]
    # Assertions
    assert var_6
    # Assignment
    var_7 = var_3

# Generated at 2022-06-26 09:29:17.347093
# Unit test for function product
def test_product():
    # Test case0
    test_case_0()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:29:20.365051
# Unit test for function product
def test_product():
    assert 1 == 1
    assert 1 != 2

if __name__ == "__main__":
    product()
    test_product()

# Generated at 2022-06-26 09:29:28.721514
# Unit test for function product
def test_product():
    # Test 1
    int_0 = list(range(5))
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = [tuple(j) for j in var_1]
    assert var_2 == [
        (0,),
        (1,),
        (2,),
        (3,),
        (4,),
    ]
    # Test 2
    int_1 = list(range(5))
    int_2 = list(range(2))
    var_3 = [int_1, int_2]
    var_4 = product(*var_3)
    var_5 = [tuple(j) for j in var_4]

# Generated at 2022-06-26 09:29:38.710191
# Unit test for function product
def test_product():
    int_0 = -1173
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = [tuple(j) for j in var_1]
    if (not (var_2 == [(-1173,)] or var_2 == [(1173,)])) :
        print('Failed')
        return False
    int_1 = -1431
    int_2 = 1431
    var_3 = [int_1, int_2]
    var_4 = product(*var_3)
    var_5 = [tuple(j) for j in var_4]
    if (not ((var_5 == [(1173, 1431)] or var_5 == [(-1173, 1431)]))) :
        print('Failed')
        return False
    int_

# Generated at 2022-06-26 09:30:04.936203
# Unit test for function product
def test_product():
    # Setup test module globals
    global tqdm_module
    global tqdm_class
    global tqdm
    global tqdm_auto_class
    global tqdm_auto

    # Setup the test variables
    int_0 = -1173
    var_0 = [int_0]
    var_1 = product(*var_0, tqdm_class=tqdm_auto_class)
    var_2 = [tuple(j) for j in var_1]

    # Check for success
    assert var_2 == []