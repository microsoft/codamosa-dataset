

# Generated at 2022-06-26 09:20:13.744829
# Unit test for function product
def test_product():
    total = 1
    for iterable in [["a", "b"], [1, 2], [("a", 1), ("b", 2)]]:
        total *= len(iterable)
    with tqdm_auto(total=total) as t:
        for i in product(*[["a", "b"], [1, 2], [("a", 1), ("b", 2)]]):
            t.update()
            assert i in [("a", 1, ("a", 1)), ("a", 1, ("b", 2)),
                         ("a", 2, ("a", 1)), ("a", 2, ("b", 2)),
                         ("b", 1, ("a", 1)), ("b", 1, ("b", 2)),
                         ("b", 2, ("a", 1)), ("b", 2, ("b", 2))]

# Generated at 2022-06-26 09:20:19.842320
# Unit test for function product
def test_product():
    for x in range(0, 10):
        for y in range(0, 10):
            for z in range(0, 10):
                for i in range(0, 10):
                    #print(x, y, z, i)
                    assert product(['a', 'b', 'c'], range(0, 10), range(0, 10), range(0, 10))

# Generated at 2022-06-26 09:20:26.064184
# Unit test for function product
def test_product():
    # Test case
    var_0 = product(1, 2, 3)
    # Test case
    var_1 = product(1)
    # Test case
    var_2 = product()


if __name__ == "__main__":
    try:
        test_case_0()
    except SystemExit as e:
        if e.code == 0:  # normal exit
            pass
    except:
        import pdb

        pdb.set_trace()

# Generated at 2022-06-26 09:20:37.581112
# Unit test for function product
def test_product():
    # test_case_0
    var_0 = product(range(3), range(3))
    assert list(var_0) == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1,
                                                                     2), (2, 0), (2, 1), (2, 2)]
    # test_case_1
    var_0 = product(range(3), range(3), range(3))

# Generated at 2022-06-26 09:20:41.866564
# Unit test for function product
def test_product():
    t = tqdm_auto.tqdm(total=6)
    for i in product(['a', 'b', 'c'], [1, 2, 3], tqdm_class=tqdm_auto.tqdm):
        pass
    t.update()


# Test case for the docstring

# Generated at 2022-06-26 09:20:46.895303
# Unit test for function product
def test_product():
    for i in product(range(10), range(10), range(10)):
        pass
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:20:51.527678
# Unit test for function product
def test_product():
    from itertools import product
    for i in range(4):
        for j in range(4):
            for k in range(4):
                assert (i, j, k) == next(product(range(4), range(4), range(4)))

# Generated at 2022-06-26 09:20:52.872053
# Unit test for function product
def test_product():
    from nose.tools import assert_equal, assert_true
    test_case_0()

# Generated at 2022-06-26 09:21:01.063683
# Unit test for function product
def test_product():
    from random import randrange
    from random import randint
    from random import choice
    from random import shuffle
    from itertools import islice
    from itertools import chain
    from itertools import count
    from itertools import repeat
    from itertools import cycle
    from itertools import zip_longest
    from itertools import accumulate
    from itertools import takewhile
    from itertools import dropwhile
    from itertools import filterfalse
    from itertools import groupby
    from itertools import tee
    from collections import Iterable
    from collections import Iterator
    from collections import Generator
    from types import GeneratorType
    assert hasattr(product(), '__iter__')
    assert not hasattr(product(), '__next__')
    assert hasattr(product(), '__next__')
   

# Generated at 2022-06-26 09:21:12.863583
# Unit test for function product
def test_product():
    from tqdm import trange
    from .. import main

    n_epochs = 10
    lr = 1e-3

    with tqdm_auto(ascii=True) as t:
        for epoch in range(n_epochs):
            for param_group in range(10):
                for x, y in main.product(range(1000), range(1000)):
                    pass
            t.set_description('epoch: %i' % epoch)

    with tqdm_auto(ascii=True) as t:
        for epoch in main.trange(n_epochs):
            for param_group in range(10):
                for x, y in main.product(range(1000), range(1000)):
                    pass
            t.set_description('epoch: %i' % epoch)

# Generated at 2022-06-26 09:21:23.372320
# Unit test for function product
def test_product():
    from .utils import _range

    assert list(product(_range(3))) == list(itertools.product(_range(3)))
    assert list(product(_range(3), _range(5))) == list(itertools.product(
        _range(3), _range(5)))
    assert list(product(_range(0))) == list(itertools.product(_range(0)))
    assert list(product(_range(0), _range(5))) == []


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:21:34.058682
# Unit test for function product
def test_product():
    def test_range(x):
        return list(range(x))

    def test_iter_range(x):
        return iter(range(x))


# Generated at 2022-06-26 09:21:45.202493
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, FakeTqdmFile
    from textwrap import dedent

    @with_setup(pretest=tqdm_auto.tqdm_gui.close)
    def inner_test(iterables, desc, total, postfix, leave):
        f = FakeTqdmFile()
        with tqdm_auto(
                iterables,
                ascii=True,
                file=f,
                desc=desc,
                total=total,
                leave=leave,
                postfix=postfix,
                dynamic_ncols=True) as t:
            list(t)

        # Check that purchase order was created correctly
        assert desc in f.buf, "desc not in tqdm"
        assert total in f.buf, "total not in tqdm"

# Generated at 2022-06-26 09:21:51.885237
# Unit test for function product
def test_product():
    from .py3compat import range

    assert list(product([0, 1], [])) == []
    assert list(product([0, 1], [2, 3])) == [(0, 2), (0, 3), (1, 2), (1, 3)]
    assert list(product([0, 1], [2, 3], [4, 5])) == [(0, 2, 4),
                                                     (0, 2, 5),
                                                     (0, 3, 4),
                                                     (0, 3, 5),
                                                     (1, 2, 4),
                                                     (1, 2, 5),
                                                     (1, 3, 4),
                                                     (1, 3, 5)]

# Generated at 2022-06-26 09:21:57.265742
# Unit test for function product
def test_product():
    """
    Unit test for product()
    """
    from .utils import FormatWidget
    for i in product(list(range(3)), list(range(3)), list(range(3)),
                     tqdm_class=FormatWidget,
                     bar_format='{postfix}'):
        assert len(i) == 3


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:22:08.641844
# Unit test for function product
def test_product():
    from ..utils import FormatWrapBase
    from ..main import tqdm, trange

    for cls in (tqdm, trange, tqdm_auto, FormatWrapBase):
        # Test on a dict
        d = dict()
        gen = product("ab", tqdm_class=cls)
        for i in gen:
            d[i] = True
        assert d == {("a",): True, ("b",): True}

        # Test on a file
        f = open(__file__.rstrip("co"), "r")
        gen = product(f, tqdm_class=cls)
        for i in gen:
            f.seek(0)
            break
        f.close()

        # Test on a list
        d = dict(a=True, b=True)
        gen

# Generated at 2022-06-26 09:22:17.148010
# Unit test for function product
def test_product():
    from ..pandas import tqdm_pandas
    from ..gui import tqdm
    from ..std import tqdm as tqdm_std
    for tqdm_cls in [tqdm_auto, tqdm_pandas, tqdm, tqdm_std]:
        res = list(product(range(10), range(10), tqdm_class=tqdm_cls))
        assert len(res) == 10 ** 2
        #~ tqdm_cls.write_version()
        assert str(tqdm_cls.__name__) in str(res)

# Generated at 2022-06-26 09:22:27.451777
# Unit test for function product
def test_product():
    """Unit test for product"""
    import sys
    from .utils import _range, format_sizeof
    from .tests_tqdm import pretest_posttest
    if pretest_posttest():
        return
    # To show the progression, we use a stream which is not sys.stderr, since
    # it is not the final output of the tqdm call.
    # `tqdm(sys.stderr, file=sys.stderr)` is forbidden and would
    # harmlessly print a useless message
    test_stream = sys.stdout
    # test outputs
    format_size = lambda s: format_sizeof(
        s, prefix="{:,}".format, suffix='B')

# Generated at 2022-06-26 09:22:35.158429
# Unit test for function product
def test_product():
    """
    Unit tests for `product`.
    """
    iterables = [['abc', 'def'], [1, 2]]
    gen = product(*iterables, total=None)
    assert isinstance(gen, itertools.product)
    assert list(gen) == [('abc', 1), ('abc', 2), ('def', 1), ('def', 2)]

# Generated at 2022-06-26 09:22:43.731373
# Unit test for function product
def test_product():
    import random
    for n in (10, 51):
        for ranges in ((4,), (3, 4), (2, 3, 4)):
            for reps in (1, 2, 4, 10):
                for tqdm_cls, kwargs in tqdm_auto.tests():
                    assert list(product(*reps * ranges, tqdm_class=tqdm_cls, **kwargs)) == [tuple(random.randrange(r) for r in ranges) for _ in range(n)]

# Generated at 2022-06-26 09:22:47.210736
# Unit test for function product
def test_product():
    # Do not run any test if itertools is not available
    try:
        import itertools
    except ImportError:
        return
    test_case_0()

# Generated at 2022-06-26 09:22:53.639315
# Unit test for function product
def test_product():
    a = [1, 2, 3]
    b = [4, 5]
    c = [6, 7, 8]
    expected = list(itertools.product(a, b, c))
    assert expected == list(product(a, b, c))
    d = [9, 10, 11]
    expected = list(itertools.product(a, b, c, d))
    assert expected == list(product(a, b, c, d))
    e = [12, 13]
    expected = list(itertools.product(a, b, c, d, e))
    assert expected == list(product(a, b, c, d, e))
    f = [14, 15]
    expected = list(itertools.product(a, b, c, d, e, f))

# Generated at 2022-06-26 09:22:54.672295
# Unit test for function product
def test_product():
    test_case_0()

# Un

# Generated at 2022-06-26 09:23:09.108323
# Unit test for function product
def test_product():
    from itertools import product
    import tqdm

    for tqdm_class in (tqdm.tqdm, tqdm.trange, tqdm_test_module.FakeTqdmType):
        for tqdm_iterable in (
                tqdm.tqdm(xrange(int(10**i))),
                tqdm.trange(int(10**i)),
                tqdm_test_module.FakeTqdmType(xrange(int(10**i))),
                xrange(int(10**i))):

            # check equivalent results
            res_tqdm = product(*tqdm_iterable, tqdm_class=tqdm_class)
            res_itertools = product(*tqdm_iterable)
            # list(res) to force complete iteration

# Generated at 2022-06-26 09:23:14.923921
# Unit test for function product
def test_product():
    int_0 = 429
    var_3 = [int_0]
    var_4 = product(*var_3)
    var_5 = list(var_4)


if __name__ == '__main__':
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:23:16.819383
# Unit test for function product
def test_product():
  try:
    test_case_0()
    assert True
  except:
    assert False

# Generated at 2022-06-26 09:23:27.655059
# Unit test for function product
def test_product():
    # Generated from itertools.product_test0.
    int_0 = 1
    int_1 = 3
    var_0 = [int_0, int_1]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    var_3 = []
    for var_4 in range((int_0), (int_1)):
        for var_5 in range((int_0), (int_1)):
            var_3.append((var_4, var_5))
    assert var_2 == var_3
    # Generated from itertools.product_test1.
    int_0 = 1
    int_1 = 3
    list_0 = [1, 2, 3]
    list_1 = [3, 2, 1]

# Generated at 2022-06-26 09:23:39.365104
# Unit test for function product
def test_product():
    with tqdm_auto.tqdm(desc="testing product function") as t:
        for item in product(range(1, 20), range(1, 5), range(1, 6), tqdm_class=tqdm_auto.tqdm):
            assert(len(str(item)) <= 13)
    t.clear()
    with tqdm_auto.tqdm(desc="testing product function", leave=True) as t:
        for item in product(range(1, 20), range(1, 5), range(1, 6), tqdm_class=tqdm_auto.tqdm):
            assert(len(str(item)) <= 13)
            t.update()



# Generated at 2022-06-26 09:23:43.081174
# Unit test for function product
def test_product():
    for i in product([3, 4], range(5)):
        print(i)

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:45.920124
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    print('Test case #0')
    test_case_0()
    print('Test case passed!!!')

# Run the test cases
test_product()

# Generated at 2022-06-26 09:23:54.522073
# Unit test for function product
def test_product():
    int_0 = 429
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert var_2 == [0]
    int_0 = 429
    int_1 = 3
    var_0 = [int_0, int_1]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert var_2 == [0, 0]
    int_0 = 429
    int_1 = 3
    int_2 = 3
    var_0 = [int_0, int_1, int_2]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert var_2 == [0, 0, 0]
    int_0

# Generated at 2022-06-26 09:23:57.615574
# Unit test for function product
def test_product():
    import itertools
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4
    input_0 = [int_0, int_1]
    input_1 = [int_2, int_3]
    output_0 = itertools.product(input_0, input_1)
    output_1 = product(input_0, input_1)
    assert list(output_0) == list(output_1)

# Generated at 2022-06-26 09:24:04.609925
# Unit test for function product
def test_product():
    # Tests with a single argument
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    # Tests with a single argument and total
    assert list(product(range(3), total=3)) == [(0,), (1,), (2,)]
    # Tests with two arguments
    assert list(product(range(2), range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    # Tests with two arguments and total
    assert list(product(range(2), range(2), total=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    # Tests with multiple arguments

# Generated at 2022-06-26 09:24:08.877304
# Unit test for function product
def test_product():
    total = 0
    s = itertools.product(["a", "b", "c"], repeat=3)
    for i in tqdm(s):
        total += 1
    assert total == 27


# Generated at 2022-06-26 09:24:11.390973
# Unit test for function product
def test_product():
    # Example 1
    test_case_0()


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:24:23.270983
# Unit test for function product
def test_product():
    # Test 1 (from man)
    # Given a list of iterables, product() returns a 
    # cartesian product of iterables as tuples
    iter1 = [1,2]
    iter2 = ['a','b']
    iter3 = [1,2]
    expected_result = [(1, 'a', 1),
                       (1, 'a', 2),
                       (1, 'b', 1),
                       (1, 'b', 2),
                       (2, 'a', 1),
                       (2, 'a', 2),
                       (2, 'b', 1),
                       (2, 'b', 2)]
    result = list(product(iter1,iter2,iter3))
    assert(result == expected_result)


# Generated at 2022-06-26 09:24:35.312131
# Unit test for function product
def test_product():
    input_iterables = []
    output_iterables = []
    for i in range(0, 11):
        input_iterables.append([])
        output_iterables.append([])
        for j in range(0, 10):
            input_iterables[i].append(j)
            output_iterables[i].append((j,))
    input_iterables.append([])
    output_iterables.append([])
    for i in range(0, 10):
        input_iterables[11].append(i)
        input_iterables[11].append(i)
        output_iterables[11].append((i, i))
    input_iterables.append([])
    output_iterables.append([])

# Generated at 2022-06-26 09:24:47.447171
# Unit test for function product
def test_product():
    from . import fp_fastmath
    from . import fp_numpy
    from . import fp_pytorch
    from . import fp_tensorflow
    list_0 = [429, 429]
    var_0 = product(*list_0)
    var_1 = list(var_0)
    var_2 = len(var_1)
    fp_fastmath.test_case_0(var_2)
    fp_numpy.test_case_0(var_1)
    var_0 = product(*list_0)
    var_1 = list(var_0)
    fp_pytorch.test_case_0(var_1)
    var_0 = product(*list_0)
    var_1 = list(var_0)
    fp_tensorflow

# Generated at 2022-06-26 09:24:51.765038
# Unit test for function product
def test_product():
    int_0 = 429
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert var_2[0] == 0
    assert len(var_2) == 429

# Generated at 2022-06-26 09:25:03.840214
# Unit test for function product
def test_product():
    import numpy as np
    from numbers import Number

    for i in range(5):
        iterables = []
        lengths = []
        for j in range(i):
            iterables.append(range(np.random.randint(1, 10)))
            lengths.append(len(iterables[-1]))

        func = product(*iterables)
        assert isinstance(func, type(product(*[])))

        prod = 1
        for j, var in enumerate(iterables):
            prod *= lengths[j]

        assert prod == len(list(func))

        func = product(*iterables, total=5)
        assert isinstance(func, type(product(*[])))
        assert prod == len(list(func))


# Generated at 2022-06-26 09:25:11.176288
# Unit test for function product
def test_product():
    int_0 = 429
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert var_2 == list(itertools.product(*var_0))

# Generated at 2022-06-26 09:25:13.556070
# Unit test for function product
def test_product():
    items = [1, 2, 3]
    for i in product(items):
        assert isinstance(i, tuple)
        for j in i:
            assert j in items

# Generated at 2022-06-26 09:25:15.097110
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:25:16.689574
# Unit test for function product
def test_product():

    test_case_0()

# Generated at 2022-06-26 09:25:26.859529
# Unit test for function product
def test_product():
    # Initialize test values
    int_0 = 429
    int_1 = 469
    int_2 = 509
    int_3 = 549
    int_4 = 589
    int_5 = 629
    int_6 = 669
    int_7 = 709
    int_8 = 749
    int_9 = 789
    int_10 = 829
    int_11 = 869
    int_12 = 909
    int_13 = 949
    int_14 = 989
    int_15 = 1029
    int_16 = 1069
    int_17 = 1109
    int_18 = 1149
    int_19 = 1189
    int_20 = 1229
    int_21 = 1269
    int_22 = 1309
    int_23 = 1349
   

# Generated at 2022-06-26 09:25:32.278045
# Unit test for function product
def test_product():
    import pytest
    from hypothesis import given
    from hypothesis.strategies import floats
    from hypothesis.strategies import integers
    @given(integers())
    def test_case_0(arg_0):
        assert arg_0 > 0
        int_0 = arg_0
        var_0 = [int_0]
        var_1 = product(*var_0)
        var_2 = list(var_1)
        assert len(var_2) == arg_0
    @given(integers())
    def test_case_1(arg_0):
        assert arg_0 > 0
        int_0 = arg_0
        var_0 = [int_0]
        var_1 = [0]
        with pytest.raises(AssertionError):
            product(*var_0)

# Generated at 2022-06-26 09:25:34.118624
# Unit test for function product
def test_product():
    return


if __name__ == '__main__':
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:25:34.914691
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:25:36.366369
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:25:46.971597
# Unit test for function product
def test_product():
    """
    Unit test for function :meth:`~itertools_helper.misc.product`.
    """
    # 1)
    # Initialization
    var_0 = 1, 3
    var_1 = product(*var_0)
    # Verification
    var_2 = list(var_1)
    assert (var_2 == [(1, 0), (1, 1), (1, 2)])
    # 2)
    # Initialization
    var_0 = 327
    var_1 = product(*var_0)
    # Verification
    var_2 = list(var_1)
    assert (var_2 == [(1, 0), (1, 1), (1, 2)])
    # 3)
    # Initialization
    var_0 = 100, 3

# Generated at 2022-06-26 09:25:51.811684
# Unit test for function product
def test_product():
    import sys, os
    import numpy

    here = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, here + '/../')
    os.chdir(here)

    test_case_0()

# Generated at 2022-06-26 09:25:55.755142
# Unit test for function product
def test_product():
    total = 32
    rng = range(total)
    p = product(rng, rng)
    assert list(p) == [(i, j) for i in rng for j in rng]

# Generated at 2022-06-26 09:26:06.274446
# Unit test for function product
def test_product():
    int_0 = 1
    int_1 = 0
    for i_1 in range(int_0, int_1 + 1):
        int_2 = 10
        int_3 = 0
        for i_3 in range(int_2, int_3 + 1):
            int_5 = 10
            int_6 = 0
            for i_5 in range(int_5, int_6 + 1):
                list_0 = [i_5, i_3, i_1]
                var_0 = product(*list_0)
                var_1 = list(var_0)
                # assert 2 == len(var_1)

if __name__ == "__main__":
    test_case_0()
    # test_product()

# Generated at 2022-06-26 09:26:13.282192
# Unit test for function product
def test_product():
    v_0 = [3,2],
    v_1 = product(*v_0)
    v_2 = list(v_1)
    assert v_2 == [(0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1)]


# Benchmark for function product
# 1 loops, best of 3: 179 ms per loop

# Generated at 2022-06-26 09:26:16.340163
# Unit test for function product
def test_product():
    assert test_case_0() == None
    pass

# vim: foldmethod=marker

# Generated at 2022-06-26 09:26:17.474355
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:26:25.361536
# Unit test for function product
def test_product():
    int_0 = ["abc", "xyz"]
    int_1 = [1, 5, 10, 20]
    int_2 = product(int_0, int_1)
    int_3 = list(int_2)
    # assert (int_3 == [("abc", 1), ("abc", 5), ("abc", 10), ("abc", 20), ("xyz", 1), ("xyz", 5), ("xyz", 10), ("xyz", 20)]), "Incorrect output."
    print("Correct output.")
# test_product()

# Generated at 2022-06-26 09:26:28.052858
# Unit test for function product
def test_product():
    var_5 = test_case_0()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:26:31.310440
# Unit test for function product
def test_product():
    # Initialise test case data
    int_0 = 10
    int_1 = 0
    int_2 = 20
    int_3 = 2
    int_4 = 1
    int_5 = 0
    int_6 = 10
    int_7 = 2
    int_8 = 20
    int_9 = 10
    int_10 = 5
    int_11 = 5
    int_12 = 0
    int_13 = 10
    int_14 = 2
    int_15 = 20
    int_16 = 10
    int_17 = 0
    int_18 = 5
    int_19 = 10
    str_0 = "cW8gsNxo"
    str_1 = "JWli"
    str_2 = "4"
    str_3 = "8kAO"
    str_4

# Generated at 2022-06-26 09:26:38.543408
# Unit test for function product
def test_product():
    int_0 = 429
    int_1 = 77
    int_2 = 8
    int_3 = 20
    int_4 = [int_0]
    int_5 = [int_1]
    int_6 = [int_2]
    int_7 = [int_3]
    var_0 = [int_4, int_5, int_6, int_7]
    var_1 = product(*var_0)
    var_2 = list(var_1)


# Generated at 2022-06-26 09:26:56.319072
# Unit test for function product
def test_product():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int_11 = 11
    int_12 = 12
    int_13 = 13
    int_14 = 14
    int_15 = 15
    int_16 = 16
    int_17 = 17
    int_18 = 18
    int_19 = 19
    int_20 = 20
    int_21 = 21
    int_22 = 22
    int_23 = 23
    int_24 = 24
    int_25 = 25
    int_26 = 26
    int_27 = 27
    int_

# Generated at 2022-06-26 09:26:59.985919
# Unit test for function product
def test_product():
    assert test_case_0() == None


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:27:08.674826
# Unit test for function product
def test_product():
    int_0 = 429
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    func_0_0 = var_2[0]
    assert func_0_0 == 0
    int_1 = 10
    int_2 = 0
    func_1_0 = var_2[int_1]
    assert func_1_0 == int_1
    int_3 = 100
    func_2_0 = var_2[int_3]
    assert func_2_0 == int_3
    int_4 = -10
    int_5 = 429 + int_4
    func_3_0 = var_2[int_5]
    assert func_3_0 == int_4
    int_6 = 2
    int

# Generated at 2022-06-26 09:27:13.320110
# Unit test for function product
def test_product():
    list_0 = []
    list_1 = []
    list_0.append(list_1)
    list_1.append(0)
    list_1.append(1)
    # list_1.append(2)
    # list_0.append(list_1)
    list_2 = []
    list_2.append(0)
    list_2.append(1)
    # list_2.append(2)
    list_0.append(list_2)
    print('list_0 =', list_0)
    list_3 = product(*list_0)
    print('list_3 =', list_3)
    list_4 = list(list_3)
    print('list_4 =', list_4)

if __name__ == "__main__":
    test_case

# Generated at 2022-06-26 09:27:18.149188
# Unit test for function product
def test_product():
    print('Executing test: test_product...')
    assert(test_case_0())
    print('test_product completed!')

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:27:28.883237
# Unit test for function product
def test_product():
    int_0 = 429
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = list(var_1)

# Generated at 2022-06-26 09:27:33.112769
# Unit test for function product
def test_product():
    test1 = [1, 2]
    test2 = ["a", "b"]

    # tqdm_bar = product(test1, test2)
    #
    # if __name__ == '__main__':
    #     for i in tqdm_bar:
    #         print(i)

# Generated at 2022-06-26 09:27:34.352721
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:27:36.304023
# Unit test for function product
def test_product():
    test_case_0()

# Generated at 2022-06-26 09:27:46.409506
# Unit test for function product
def test_product():
    var_0 = list(range(5))
    var_1 = list(range(5))
    var_2 = list(product(var_0, var_1))

# Generated at 2022-06-26 09:28:06.605667
# Unit test for function product
def test_product():
    from tqdm.contrib import product as product_contrib
    import itertools
    iterables = [range(4), range(4), range(4), range(4), range(4)]
    var_0 = product_contrib(*iterables, tqdm_class=tqdm_auto)
    var_1 = list(var_0)
    var_2 = product(*iterables)
    var_3 = list(var_2)
    var_4 = list(itertools.product(*iterables))
    assert var_3 == var_4
    del var_3, var_4
    var_5 = product_contrib(*iterables, tqdm_class=tqdm_auto)
    var_6 = list(var_5)
    assert var_6 == [None] * 256
    del var

# Generated at 2022-06-26 09:28:10.718772
# Unit test for function product
def test_product():
    int_0 = 429
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = list(var_1)


# Generated at 2022-06-26 09:28:15.308914
# Unit test for function product
def test_product():
    try:
        import pytest
        pytest.skip("For now, just sample test cases.")
    except ImportError:
        print("Could not import pytest; skipping tests.")

    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-26 09:28:20.016891
# Unit test for function product
def test_product():
    print("Test product ...")
    test_case_0()
    print("Test successful !")

# Automatic execution of unit tests
if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:28:23.869032
# Unit test for function product
def test_product():
    int_0 = 429
    var_0 = [int_0]
    var_1 = product(*var_0)
    var_2 = list(var_1)
    assert var_2 == list(itertools.product(*var_0))

# Generated at 2022-06-26 09:28:26.300959
# Unit test for function product
def test_product():
    test_case_0()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:28:28.033591
# Unit test for function product
def test_product():
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 09:28:37.121037
# Unit test for function product
def test_product():
    """ Unit test for function product"""

    # Setup
    int_0 = 429
    list_0 = [int_0]

# Generated at 2022-06-26 09:28:41.242286
# Unit test for function product
def test_product():
    assert len(list(itertools.product([1, 2, 3], [4, 5]))) == 6
    assert len(list(product([1, 2, 3], [4, 5]))) == 6

# Generated at 2022-06-26 09:28:43.715926
# Unit test for function product
def test_product():
    for i in range(100):
        test_case_0()

# Generated at 2022-06-26 09:29:07.177729
# Unit test for function product
def test_product():
    assert len(list(product(range(3), range(3), range(3), range(3), range(3),
                            range(3)))) == 3**6
    assert len(list(product(range(3), range(3), range(3), range(3), range(3),
                            range(3), range(3), range(3), range(3), range(3),
                            range(3), range(3), range(3), range(3), range(3),
                            range(3), range(3), range(3), range(3), range(3),
                            range(3)))) == 3**20

    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]


# Generated at 2022-06-26 09:29:09.934615
# Unit test for function product
def test_product():
    """
    Make sure that `tqdm.tqdm_notebook` works correctly.
    """
    import pytest
    var_0 = [1]
    var_1 = 'var_1 - {0}'.format(var_0)
    var_2 = product(*var_0, desc=var_1)
    var_3 = list(var_2)
    assert True

# Generated at 2022-06-26 09:29:18.773182
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

    assert list(product([1, 2, 3], repeat=2)) == [(1, 1),
                                                  (1, 2),
                                                  (1, 3),
                                                  (2, 1),
                                                  (2, 2),
                                                  (2, 3),
                                                  (3, 1),
                                                  (3, 2),
                                                  (3, 3)]

    assert list(product([1, 2, 3], [4, 5])) == [(1, 4),
                                                (1, 5),
                                                (2, 4),
                                                (2, 5),
                                                (3, 4),
                                                (3, 5)]


# Generated at 2022-06-26 09:29:20.161617
# Unit test for function product
def test_product():
    assert test_case_0() == None

# Generated at 2022-06-26 09:29:28.660946
# Unit test for function product
def test_product():
    from ._utils import TestCase
    import numpy as np
    import pytest

    for tqdm_class in [tqdm_auto]:
        tqdm_kwargs = {"tqdm_class": tqdm_class}

        list_0 = [np.arange(2) for i in range(2)]
        var_0 = list(product(*list_0, **tqdm_kwargs))

        var_1 = product(*list_0, **tqdm_kwargs)

        with pytest.raises(TypeError):
            input_0 = [42]
            list(product(*input_0, **tqdm_kwargs))
        with pytest.raises(ValueError):
            input_1 = 0
            list(product(*input_1, **tqdm_kwargs))

        list

# Generated at 2022-06-26 09:29:31.595921
# Unit test for function product
def test_product():
    test_case_0()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:29:36.564464
# Unit test for function product
def test_product():
    import numpy as np
    int_2 = [np.iinfo(np.int64).min, np.iinfo(np.int64).max]
    var_3 = int_2
    for var_4 in product(*var_3):
        assert var_4 == np.iinfo(np.int64).min or var_4 == np.iinfo(np.int64).max

# Generated at 2022-06-26 09:29:37.356916
# Unit test for function product
def test_product():
    product()

# Generated at 2022-06-26 09:29:47.826627
# Unit test for function product
def test_product():
    __tracebackhide__ = True
    def test_case_0():
        int_0 = 429
        var_0 = [int_0]
        var_1 = product(*var_0)
        var_2 = list(var_1)
        assert var_2 == [[i] for i in range(int_0)], 'Assertion failed, expected: {}, result: {}'
    def test_case_1():
        int_0 = 429
        int_1 = 524
        int_2 = 578
        var_0 = [int_0, int_1, int_2]
        var_1 = product(*var_0)
        var_2 = list(var_1)

# Generated at 2022-06-26 09:29:57.131701
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import close_range

    lst = [[0, 1], [-1, 0, 1], [5, 6, 7]]

    # test total
    with tqdm_auto(total=27) as t:
        for _ in product(*lst):
            t.update()

    # test output
    a = np.array(list(product(*lst)))
    assert (a.shape == (27, 3))
    assert (close_range(a.sum(axis=1), 6, 0, 1))

if __name__ == "__main__":
    test_product()