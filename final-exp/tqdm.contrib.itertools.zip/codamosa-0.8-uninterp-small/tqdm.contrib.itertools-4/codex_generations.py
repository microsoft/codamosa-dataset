

# Generated at 2022-06-26 09:20:13.863808
# Unit test for function product
def test_product():
    import pytest
    assert callable(product)
    assert product(tqdm_class=None)

    # @pytest.mark.skip(reason="TODO")
    def test_case_1():
        var_0 = product((0, 1), (0, 1), (0, 1))
        var_1 = var_0

    # @pytest.mark.skip(reason="TODO")
    def test_case_2():
        var_0 = product((0, 1), (0, 1), (0, 1))
        var_1 = var_0

    # @pytest.mark.skip(reason="TODO")
    def test_case_3():
        var_0 = product((0, 1), (0, 1), (0, 1))
        var_1 = var_0

    #

# Generated at 2022-06-26 09:20:25.179179
# Unit test for function product
def test_product():
    for var_0 in product():
        assert type(var_0) is tuple
        assert len(var_0) is 0
    for var_0 in product(range(2)):
        assert type(var_0) is tuple
        assert len(var_0) is 1
        assert var_0[0] == 0 or var_0[0] == 1
    for var_0 in product(range(2), repeat=2):
        assert type(var_0) is tuple
        assert len(var_0) is 2
        assert var_0[0] == 0 or var_0[0] == 1
        assert var_0[1] == 0 or var_0[1] == 1
    for var_0 in product(range(2), repeat=3):
        assert type(var_0) is tuple

# Generated at 2022-06-26 09:20:31.485899
# Unit test for function product
def test_product():
    import numpy as np
    for i in product(range(5), repeat=2):
        assert type(i) is tuple
        assert len(i) == 2
        for j in i:
            assert j < 5
    assert len(list(product(range(5), repeat=2))) == 5 ** 2
    assert len(list(product(range(5), repeat=3))) == 5 ** 3
    assert len(list(product(range(5), repeat=0))) == 1
    assert len(list(product(range(5), repeat=-1))) == 0
    assert len(list(product([1, 2], [3, 4], [5, 6]))) == 2 ** 3

# Generated at 2022-06-26 09:20:43.622491
# Unit test for function product
def test_product():
    assert callable(product), "it not a function"
    assert hasattr(product, '__doc__'), "function has no docstring"
    var_0 = product(range(2), tqdm_class = tqdm_auto)
    assert isinstance(var_0, itertools.product), "cannot convert product to itertools.product"
    var_1 = product(range(2), tqdm_class = tqdm_auto)
    assert isinstance(var_1, itertools.product), "cannot convert product to itertools.product"
    var_2 = product(range(3), tqdm_class = tqdm_auto)
    assert isinstance(var_2, itertools.product), "cannot convert product to itertools.product"

# Generated at 2022-06-26 09:20:55.531278
# Unit test for function product
def test_product():
    def test_iter():
        for i, j, k in product([1, 2], [3, 4], ['a', 'b'], tqdm_class=None):
            pass
        for i, j, k in product([1, 2], [3, 4], ['a', 'b'], tqdm_class=tqdm_auto):
            pass

    def test_total_0():
        total_0 = [i for i in product([1], [2], [3])]
        assert len(total_0) == 1

    def test_total_1():
        total_1 = [i for i in product([1], [2], [3], [4])]
        assert len(total_1) == 4


# Generated at 2022-06-26 09:21:02.691373
# Unit test for function product
def test_product():
    iterables = [None, None]
    assert dict(product(*iterables)) == dict(itertools.product(*iterables))

    iterables = [None,
                 [('a', 1), ('b', 2)],
                 ]
    assert dict(product(*iterables)) == dict(itertools.product(*iterables))

    iterables = [['a', 'b'], [1, 2]]
    assert dict(product(*iterables)) == dict(itertools.product(*iterables))

    iterables = [['a', 'b'], [1, 2], [True, False]]
    assert dict(product(*iterables)) == dict(itertools.product(*iterables))

# Generated at 2022-06-26 09:21:07.701993
# Unit test for function product
def test_product():
    iterables = product(["foo", "bar", "baz", "qux"], ["fizz", "buzz"], ["wibble", "wobble", "splat", "gronk"], tqdm_class=tqdm_auto)
    assert var_0 == iterables


# Generated at 2022-06-26 09:21:12.617533
# Unit test for function product
def test_product():
    try:
        from tqdm import tqdm
    except ImportError:
        from tqdm import tqdm_gui as tqdm
    assert next(product([1, 2, 3], ["a", "b", "c"], tqdm=tqdm)) == (1, 'a')

# Generated at 2022-06-26 09:21:14.276530
# Unit test for function product
def test_product():
    assert True


if __name__ == '__main__':
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:21:24.943007
# Unit test for function product
def test_product():
    # Test case 0
    var_0 = product()
    # Test case 1
    var_1 = product()
    # Test case 2
    var_2 = product()
    # Test case 3
    var_3 = product()
    # Test case 4
    var_4 = product()
    # Test case 5
    var_5 = product()
    # Test case 6
    var_6 = product()
    # Test case 7
    var_7 = product()
    # Test case 8
    var_8 = product()
    # Test case 9
    var_9 = product()
    # Test case 10
    var_10 = product()
    # Test case 11
    var_11 = product()
    # Test case 12
    var_12 = product()
    # Test case 13
    var_13 = product()
    # Test

# Generated at 2022-06-26 09:21:30.701831
# Unit test for function product
def test_product():
    from .._tqdm_test_cases import tqdm_test_case_product
    for _ in tqdm_test_case_product(tqdm=tqdm_decorator):
        pass

# Generated at 2022-06-26 09:21:32.641786
# Unit test for function product
def test_product():
    print(product([1], ["2"], range(3)))
    print(product([1], ["2"], range(3), tqdm_class=None))

# Generated at 2022-06-26 09:21:40.735350
# Unit test for function product
def test_product():
    try:
        list_0 = [1, 2, 3]
        var_0 = list_0 * 3
        var_1 = product(*var_0)
        list_1 = [None]
        assert any(map(lambda var_2: var_2 == list_1, var_1))
        var_3 = list(product(*[var_2], tqdm_class=None))
        assert all(map(lambda var_4: var_4 == list_1, var_3))
    except AssertionError:
        pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:21:43.722915
# Unit test for function product
def test_product():
    # Test the case where the function is called with no parameters.
    try:
        product()
        assert False, 'Expected AssertionError'
    except AssertionError:
        pass

# Generated at 2022-06-26 09:21:45.637190
# Unit test for function product
def test_product():
    list_1 = [1]
    var_3 = dict(product(list_1))


# Generated at 2022-06-26 09:21:46.186690
# Unit test for function product
def test_product():
    assert True

# Generated at 2022-06-26 09:21:47.411210
# Unit test for function product
def test_product():
    assert True


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:21:52.147903
# Unit test for function product
def test_product():
    """
    @param		t		    t
    @tparam		t		    t
    @param		t		    t
    @tparam		t		    t
    """
    pass

# Generated at 2022-06-26 09:21:57.145109
# Unit test for function product
def test_product():
    list_0 = [3, 4, 5]
    var_0 = list_0
    var_1 = product(*var_0)
    assert var_0 == list_0
    var_2 = product(*var_1)
    assert var_1 == var_2
    list_1 = [var_2, list_0]
    var_3 = dict(var_2)

# Generated at 2022-06-26 09:22:08.640818
# Unit test for function product
def test_product():
    var_4 = test_case_0()
    list_2 = [var_4]
    var_5 = None
    var_6 = dict()
    dict_0 = var_6
    list_3 = [dict_0]
    tuple_0 = list_2
    tuple_1 = list_3
    list_4 = [None, None]
    list_5 = [sorted(dict_0)]
    var_7 = product(*tuple_0, tuple_1=tuple_1, dict_0=dict_0, list_0=list_4, list_1=list_5)
    var_8 = (var_7)
    list_6 = [var_8]
    var_9 = dict(var_7)
    dict_1 = var_9

# Generated at 2022-06-26 09:22:23.313143
# Unit test for function product
def test_product():
    from tqdm import tqdm
    import itertools

    tqdm.write('Test case #0')
    var_0 = None
    list_0 = [var_0]
    var_1 = product(*list_0)
    list_1 = [var_1, list_0]
    var_2 = dict(list_1)
    tqdm.write('Test case #1')
    var_3 = None
    list_2 = [var_3]
    var_4 = product(*list_2)
    list_3 = [var_4, list_2]
    var_5 = dict(list_3)
    tqdm.write('Test case #2')
    dict_0 = dict()
    list_4 = [dict_0]
    var_6 = product(*list_4)

# Generated at 2022-06-26 09:22:30.765612
# Unit test for function product

# Generated at 2022-06-26 09:22:37.832552
# Unit test for function product
def test_product():
    import cProfile
    import io
    import pstats
    pr = cProfile.Profile()
    pr.enable()
    test_case_0()
    pr.disable()
    s = io.StringIO()
    sortby = 'cumulative'
    ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
    ps.print_stats()
    print(s.getvalue())


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:44.252256
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], [4, 5, 6])) == [
        (1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]


if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:22:52.105770
# Unit test for function product
def test_product():
    # List comprehension
    assert not [x for x in product(["a", "b"], [1, 2, 3], [0, 1])]

    # Standard library
    assert not [x for x in itertools.product(["a", "b"], [1, 2, 3], [0, 1])]

    # Equivalence
    assert not [x for x in product(["a", "b"], [1, 2, 3], [0, 1])] !=\
        [x for x in itertools.product(["a", "b"], [1, 2, 3], [0, 1])]

    # Number of iterables
    assert not len([x for x in product(["a", "b"],)]) == 2

# Generated at 2022-06-26 09:22:59.143301
# Unit test for function product
def test_product():
    import sys
    import random
    # Loop over the itertools and tqdm.product functions
    for func in [itertools.product, product]:
        # Loop over a number of test cases
        for args in [[]]:
            iterable = func(*args)
            next(iterable)  # Should not raise StopIteration
            # Loop over a number of test iterations
            for i in range(100):
                random.shuffle(args)  # In-place shuffle
                # Make sure that the iterables match
                assert list(func(*args)) == list(iterable)

# Generated at 2022-06-26 09:23:06.753002
# Unit test for function product
def test_product():
    import sys, os
    sys.path.append(os.path.dirname(__file__))
    import prod_test
    prod_test.test_product(product)
    # prod_test.test_prod_with_tqdm(product)  # not implemented by iTool


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:23:13.373928
# Unit test for function product
def test_product():
    from .__main__ import test_case_0
    from .__main__ import test_case_1
    from .__main__ import test_case_2
    from .__main__ import test_case_3
    from .__main__ import test_case_4
    from .__main__ import test_case_5
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()

# vim : set fileencoding=utf-8 filetype=python ts=4 sw=4 expandtab :

# Generated at 2022-06-26 09:23:17.708988
# Unit test for function product
def test_product():
    assert 0, "Test broken."
    # assert product(*iterables, **tqdm_kwargs)

if __name__ == "__main__":
    test_case_0()
    product()

# Generated at 2022-06-26 09:23:28.108599
# Unit test for function product
def test_product():
    # Try to import
    try:
        from itertools import product
    except ImportError:
        return
    assert next(product(range(3), range(3))) == (0, 0)
    assert next(product(range(3), range(3))) == (0, 1)
    assert next(product(range(3), range(3))) == (0, 2)
    assert next(product(range(3), range(3))) == (1, 0)
    assert next(product(range(3), range(3))) == (1, 1)
    assert next(product(range(3), range(3))) == (1, 2)
    assert next(product(range(3), range(3))) == (2, 0)
    assert next(product(range(3), range(3))) == (2, 1)

# Generated at 2022-06-26 09:23:43.072484
# Unit test for function product
def test_product():
    from tqdm import tqdm
    from inspect import getargspec
    def check_defaults(func, defaults):
        parts = getargspec(func)
        for i, part in enumerate(parts.args):
            if part == "tqdm_class":
                assert defaults[i] == tqdm

    check_defaults(product, [None, None, None, itertools.product])

    from itertools import product
    from tqdm import tqdm

    # TODO: test **tqdm_kwargs
    for i in product(["a", "b", "c", "d", "e"], repeat=7,
                     tqdm_class=tqdm):
        pass


if __name__ == "__main__":
    # Unit test
    test_case_0()


# Generated at 2022-06-26 09:23:48.936719
# Unit test for function product
def test_product():
    from collections import defaultdict
    import numpy as np
    from .utils import numpy_type_map

    def test_dict(d, tqdm_class=tqdm_auto, **kwargs):
        for i, j in product(d, d, **kwargs):
            assert (i >= 0 and j >= 0)
            assert (i < len(d) and j < len(d))
            assert (d[i] == i and d[j] == j)

    def test_zip(d, tqdm_class=tqdm_auto, **kwargs):
        for i, j in product(d.items(), **kwargs):
            assert (i[1] == i[0] and j[1] == j[0])


# Generated at 2022-06-26 09:23:50.403270
# Unit test for function product
def test_product():
    assert isinstance(test_case_0() , dict)

# Generated at 2022-06-26 09:24:02.264964
# Unit test for function product
def test_product():
    # TODO: assign to `kwargs` instead of `kwargs_0` to fix `PEP8`
    # localization
    kwargs_0 = {'tqdm_class': tqdm_auto, 'total': None}
    # TODO: assign to `iterables` instead of `iterables_0` to fix `PEP8`
    # localization

# Generated at 2022-06-26 09:24:12.697736
# Unit test for function product
def test_product():
    assert test_case_0() is None

# Test cases for function product

# Generated at 2022-06-26 09:24:24.112644
# Unit test for function product
def test_product():
    list_0 = [1, 2, 3]
    list_1 = ["h", "i"]
    list_2 = [3.0, 4.0]
    list_3 = [2, 3]
    list_4 = [1, 2, 3]
    list_5 = ["h", "i"]
    list_6 = [3.0, 4.0]
    list_7 = [2, 3]
    list_8 = [1, 2, 3]
    list_9 = ["h", "i"]
    list_10 = [3.0, 4.0]
    list_11 = [1, 2, 3]
    list_12 = ["h", "i"]
    list_13 = [3.0, 4.0]
    list_14 = [2, 3]

# Generated at 2022-06-26 09:24:24.770108
# Unit test for function product
def test_product():
    pass


# Generated at 2022-06-26 09:24:35.788920
# Unit test for function product
def test_product():
    # Test empty string and ones with content
    string = ""
    assert list(product(string)) == [("",)]
    string = "abc"
    assert list(product(string)) == [("a",), ("b",), ("c",)]

    # Test empty list and ones with content
    lst = []
    assert list(product(lst)) == [()]
    lst = [1]
    assert list(product(lst)) == [(1,)]
    lst = [1, 2]
    assert list(product(lst)) == [(1,), (2,)]
    lst = [1, 2, 3]
    assert list(product(lst)) == [(1,), (2,), (3,)]

    # Test empty tuple and ones with content
    tpl = ()

# Generated at 2022-06-26 09:24:42.893206
# Unit test for function product
def test_product():
    in0 = [1,2]
    in1 = [3,4]
    exp_res = [[1,3],[1,4],[2,3],[2,4]]
    act_res = [[1,3],[1,4],[2,3],[2,4]]
    i = 0
    # enumerate offers (index,item) tuples such as (0,[1,3])
    for item in product(in0,in1):
        assert item == exp_res[i]
        i+=1
        

# Generated at 2022-06-26 09:24:47.542824
# Unit test for function product
def test_product():
    var_0 = product(xrange(1,14), xrange(5), xrange(3))
    var_1 = dict(var_0)

if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:25:06.134402
# Unit test for function product
def test_product():
    assert product.__doc__
    try:
        # make it possible to run other tests without `tqdm` installed
        from tqdm.auto import tqdm
    except ImportError:
        # print('Module `tqdm` required for test_product()')
        assert True
        return
    var_0 = None
    list_0 = [var_0, var_0, var_0]
    var_1 = product(*list_0)
    var_2 = dict(var_1)
    assert var_2 == {(None,)*3: None}
    from sys import version_info
    if version_info[0] >= 3:
        list_0 = [map(str, range(3)), map(str, range(3))]

# Generated at 2022-06-26 09:25:16.506548
# Unit test for function product
def test_product():
    import pickle as cPickle
    from io import BytesIO
    pbar = tqdm_auto(total=100, file=BytesIO())
    assert pbar.n == 0
    it = product(list(range(10)), list(range(10)),
                 tqdm_class=type(pbar), file=pbar.file)
    for x in it:
        assert x == (pbar.n // 100, (pbar.n % 100) // 10, pbar.n % 10)
        # Exercise closing the progressbar
        if pbar.n == 50:
            pbar.close()
    assert pbar.n == 100
    assert pbar.last_print_n == 9

    # Verify pickleability
    pickled = cPickle.dumps(pbar)
    assert pbar.n == 100

# Generated at 2022-06-26 09:25:23.435846
# Unit test for function product
def test_product():
    def check(iterables):
        it = product(*iterables)

# Generated at 2022-06-26 09:25:25.650602
# Unit test for function product
def test_product():
    assert ('tqdm._tqdm.tqdm' in globals())

# Generated at 2022-06-26 09:25:31.506438
# Unit test for function product
def test_product():
    list_0 = [10, 10, 10]
    var_1 = product(*list_0, tqdm_class= tqdm_auto)
    var_2 = dict(var_1)
    assert var_2[2, 3, 4] == 1, "Test failed"

# Generated at 2022-06-26 09:25:33.211418
# Unit test for function product
def test_product():
    import numpy as np
    x = np.arange(50000)
    y = np.arange(50000)
    for _ in tqdm_auto(product(x, y)):
        pass

# Generated at 2022-06-26 09:25:45.999751
# Unit test for function product
def test_product():
    import os
    import inspect
    import tqdm
    import itertools
    from tqdm import tqdm
    from tqdm.tests import tests_data
    from itertools import product

    for t in [tqdm, tqdm_auto, tqdm.tqdm]:
        with tqdm(1, disable=True) as tt:
            for i in product((1, 2, 3), ('a', 'b', 'c'), ('x', 'y')):
                tt.update()
                tt.write(i)
                # (1, 'a', 'x')
                # (1, 'a', 'y')
                # (1, 'b', 'x')
                # (1, 'b', 'y')
                # (1, 'c', 'x')
                # (

# Generated at 2022-06-26 09:25:58.555079
# Unit test for function product
def test_product():
    # Setup test data
    str_0 = 'a,b,c'
    tuple_0 = ('a', 'b', 'c')
    set_0 = {'a', 'b', 'c'}
    str_1 = 'A,B,C'
    tuple_1 = ('A', 'B', 'C')
    set_1 = {'A', 'B', 'C'}
    str_2 = '1,2,3'
    tuple_2 = (1, 2, 3)
    set_2 = {1, 2, 3}

    # Call function being tested
    list_0 = product(str_0.split(','), tuple_0, set_0, str_1.split(','), tuple_1, set_1, str_2.split(','), tuple_2, set_2)
   

# Generated at 2022-06-26 09:26:01.648613
# Unit test for function product
def test_product():
    test_case_0()
    print('Unit Test Done')

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:26:08.696754
# Unit test for function product
def test_product():
    import itertools
    for range_, total in [(3, 8), (4, 15), (1, 4), (0, 1), (10, 100)]:
        list_0 = [range(range_)] * 4
        list_1 = itertools.product(*list_0)
        itertools_total = 0
        for item in list_1:
            itertools_total += 1
            assert (item == (0, 0, 0, 0))
        assert (itertools_total == total)
        list_2 = product(*list_0, total=total)
        for item in list_2:
            assert (item == (0, 0, 0, 0))


# Generated at 2022-06-26 09:26:41.029132
# Unit test for function product

# Generated at 2022-06-26 09:26:47.693676
# Unit test for function product
def test_product():
    assert list(product('ABCD', 'xy')) == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]
    assert list(product(range(2), repeat=3)) == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-26 09:26:54.441347
# Unit test for function product
def test_product():
    # has no effect
    # pass
    # print "test_product"
    list_0 = [tqdm_auto, tqdm_auto, tqdm_auto]
    var_0 = product(*list_0)
    # print var_0
    var_1 = dict(var_0)
    # print var_1
    # assert False
    # print "test_product"


# Generated at 2022-06-26 09:26:59.277495
# Unit test for function product
def test_product():
    with tqdm_auto(total=1) as t:
        assert list(product([], repeat=5, tqdm_class=t.__class__)) == [()]
        t.update()


# Generated at 2022-06-26 09:27:09.872585
# Unit test for function product
def test_product():
    assert None == None

    # Testing for TypeError exception
    # assert raises(TypeError, "product()")

    # Testing for TypeError exception
    # assert raises(TypeError, "product(None)")

    # Testing for NumPy array support
    # var_0 = None
    # list_0 = [var_0, var_0, var_0]
    # var_1 = product(*list_0)

    # assert isinstance(var_1, GeneratorType)

    # Testing for type
    # var_2 = dict(var_1)

    # assert isinstance(var_2, dict)

    # Testing for type
    # var_3 = len(var_2)

    # assert isinstance(var_3, int)

# Generated at 2022-06-26 09:27:13.998725
# Unit test for function product
def test_product():
    from hypothesis import given
    from . import strategies
    from .itertools import starmap_product
    @given(strategies.iterables)
    def test(iterables):
        assert list(product(*iterables)) == list(starmap_product(*iterables))
    test()

# Generated at 2022-06-26 09:27:19.531901
# Unit test for function product
def test_product():

    for i in tqdm(product([1, 2, 3], [4, 5], [6, 7, 8], tqdm_class=tqdm_gui)):
        pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:27:21.778833
# Unit test for function product
def test_product():
    for i in product(range(5), range(-5, 0)):
        pass

# Generated at 2022-06-26 09:27:23.769237
# Unit test for function product
def test_product():
    """
    test_product
    """
    assert 1 == 1
    print("test_product")

# Generated at 2022-06-26 09:27:29.336397
# Unit test for function product
def test_product():
    for i in product(*[1, 2, 3], **dict(tqdm_class=None)):
        pass
    for i in product(*[1, 2, 3]):
        pass


if __name__ == "__main__":
    test_case_0()
    test_product()

# Generated at 2022-06-26 09:28:25.050791
# Unit test for function product
def test_product():
  from hypothesis import given
  from hypothesis.strategies import lists, integers
  from itertools import product as it_product
  from . import product as tdt_product

  @given(lists(integers()))
  def _test_product(lst):
    it_prod = list(it_product(*lst))
    tdt_prod = list(tdt_product(lst))
    assert it_prod == tdt_prod

# Generated at 2022-06-26 09:28:26.042659
# Unit test for function product
def test_product():
    assert False

# Generated at 2022-06-26 09:28:31.808409
# Unit test for function product
def test_product():
    import collections
    import operator
    import sys
    list_0 = [range(4), range(4), range(4), range(4)]
    var_0 = product(*list_0)
    var_1 = dict(var_0)

# Generated at 2022-06-26 09:28:34.082490
# Unit test for function product
def test_product():
    assert product(*[]) == dict()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:28:39.693807
# Unit test for function product
def test_product():
    # Setup
    pass

    # Exercise
    test_case_0()

    # Verify
    pass


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:28:43.662247
# Unit test for function product
def test_product():
    # Line with the function you are testing
    assert test_case_0()

# Generated at 2022-06-26 09:28:47.031705
# Unit test for function product
def test_product():
    assert test_case_0() is None
    assert True

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:28:52.958327
# Unit test for function product
def test_product():
    try:
        assert "ab" == "a" + "b"
    except AssertionError as error:
        print("AssertionError")
        return
    product("abc", repeat=2)
    test_case_0()

# Generated at 2022-06-26 09:28:55.734066
# Unit test for function product
def test_product():
    assert test_case_0() is None, "Variable 'var_4' does not exist."

# Generated at 2022-06-26 09:29:06.488588
# Unit test for function product
def test_product():
    # Test that the first argument does not need to be iterable
    assert list(product(1, [1, 2])) == [(1, 1), (1, 2)]
    with tqdm_auto(total=None) as t:
        assert list(product(t, [1, 2])) == t[:2]
    # and that it can be the list of parameters
    assert list(product([1, 2], total=2)) == [(1,), (2,)]
    # Test that tqdm_class works
    assert list(product([1, 2], tqdm_class=tqdm_auto)) == [(1,), (2,)]
    assert list(product([1, 2], tqdm_class=tqdm_auto, total=2)) == [(1,), (2,)]
    # Test that the arguments