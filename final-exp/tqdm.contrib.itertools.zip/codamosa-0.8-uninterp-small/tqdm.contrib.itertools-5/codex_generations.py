

# Generated at 2022-06-26 09:20:14.743400
# Unit test for function product
def test_product():
    # Check the example in the documentation:
    assert(list(product('ABCD', 'xy')) ==
           [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
            ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')])
    assert(list(product(range(3), repeat=2)) ==
           [(i, j) for i in range(3) for j in range(3)])
    # Check the case with no iterables:
    list(product())


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-26 09:20:18.656078
# Unit test for function product
def test_product():
    my_func = product
    try:
        val_0 = my_func()
    except ValueError:
        print('Not equal: product()')
    else:
        raise ValueError('Not equal: product()')

# Generated at 2022-06-26 09:20:26.918774
# Unit test for function product
def test_product():
    # Test tqdm.product
    for n in (4, 5, 8, 10, 12):
        for k in range(3, 10):
            assert(list(product(range(k), repeat=n)) ==
                   list(itertools.product(*([range(k)] * n))))

    # Test tqdm.product with display
    for n in (2, 3, 5, 6, 4):
        for k in range(3, 10):
            assert(list(product(range(k), repeat=n, tqdm_class=tqdm_auto)) ==
                   list(itertools.product(*([range(k)] * n))))

# Generated at 2022-06-26 09:20:31.417117
# Unit test for function product
def test_product():
    try:
        test_case_0()
    except AssertionError as e:
        raise AssertionError(str(e))
    except Exception as e:
        raise AssertionError(str(e))
    else:
        print('pass')


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:20:43.622632
# Unit test for function product
def test_product():
    import sys
    import re
    import os
    import pytest
    import tqdm
    from io import StringIO
    from contextlib import contextmanager
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    def dummy(*args, **kwargs):
        pass
    @contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = None

# Generated at 2022-06-26 09:20:51.915041
# Unit test for function product
def test_product():
    for j in product():
        pass
    for j in product(range(10)):
        pass
    for j in product([1, 2], ['a', 'b']):
        pass
    for j in product('ab', '12'):
        pass
    for j in product({1, 2}, {3, 4}):
        pass
    for j in product(iterables=list(), repeat=0):
        pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:20:53.775971
# Unit test for function product
def test_product():
    assert callable(product)  # Test that function exists
    test_case_0()  # Test 0 arguments

# Checking for __all__

# Generated at 2022-06-26 09:20:55.380195
# Unit test for function product
def test_product():
    assert True is True


# Generated at 2022-06-26 09:20:57.075090
# Unit test for function product
def test_product():
    # Warning: Cannot test functionality, only type
    assert(not isinstance(product(), object))

    assert(not isinstance(product([]), object))



# Generated at 2022-06-26 09:20:58.794389
# Unit test for function product
def test_product():
    assert type(product(xrange(1000000))) == itertools.product


# Generated at 2022-06-26 09:21:04.854586
# Unit test for function product
def test_product():
    for i in range(0, 10):
        for j in range(0, 10):
            var_0 = product(range(0,i),range(0,j))
            var_1 = list(var_0)
            assert var_1 == list(itertools.product(range(0,i),range(0,j)))
    var_0 = product(range(0, 100))
    var_1 = list(var_0)
    assert var_1 == list(itertools.product(range(0,100)))

# Generated at 2022-06-26 09:21:05.426995
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:21:14.798183
# Unit test for function product
def test_product():
    import sys
    import getopt
    import random
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'f:', ['file='])
    except getopt.GetoptError:
        print('test_product.py -f <testfile>')
        sys.exit(2)

    for opt, arg in opts:
        if opt in ('-f', '--file'):
            test_file = arg
    print('Testing file ' + test_file + '.py')
    exec(open(test_file + '.py').read())


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:21:26.383468
# Unit test for function product
def test_product():
    assert list(product()) == [()]
    assert list(product("")) == [()]
    assert list(product("ABCD")) == [('A',), ('B',), ('C',), ('D',)]
    assert list(product("ABCD", "xy")) == [('A', 'x'), ('A', 'y'),
                                           ('B', 'x'), ('B', 'y'),
                                           ('C', 'x'), ('C', 'y'),
                                           ('D', 'x'), ('D', 'y')]

# Generated at 2022-06-26 09:21:34.345269
# Unit test for function product
def test_product():
    from itertools import product as itertools_product

    s = "abcd"
    r = list(product(s))
    assert r == list(itertools_product(s))

    r = list(product(s, repeat=2))
    assert r == list(itertools_product(s, repeat=2))

    r = list(product(s, repeat=3))
    assert r == list(itertools_product(s, repeat=3))


if __name__ == "__main__":
    import os
    pytest.main([os.path.basename(__file__), "--tb=native", "-s"])

# Generated at 2022-06-26 09:21:35.594976
# Unit test for function product
def test_product():
    assert var_1 == []


# Generated at 2022-06-26 09:21:46.544408
# Unit test for function product
def test_product():
    var_0 = product(*[range(10)])
    var_1 = list(var_0)
    assert tuple(var_1[0]) == (0, 0)
    assert tuple(var_1[99]) == (9, 9)
    assert var_1[0] != var_1[99]
    var_0 = product(*[range(10), range(20), range(30), range(40), range(50), range(60), range(70), range(80), range(90), range(100)])
    var_1 = list(var_0)
    assert tuple(var_1[0]) == (0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

# Generated at 2022-06-26 09:21:58.085197
# Unit test for function product
def test_product():
    import numpy.random as rng
    for i in range(10):
        assert not any(
            itertools.product(*(rng.randint(0, 2, size=(rng.randint(1, 5)))
                                for _ in range(rng.randint(1, 4))))
            != product(*(rng.randint(0, 2, size=(rng.randint(1, 5)))
                         for _ in range(rng.randint(1, 4))))
        )

# Generated at 2022-06-26 09:22:02.092775
# Unit test for function product
def test_product():
    import unittest
    class test_cases(unittest.TestCase):
        def test_0(self):
            var_0 = product()
            var_1 = list(var_0)
    unittest.main()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:13.501820
# Unit test for function product
def test_product():
    # check that the length of product(a) == len(a)
    from tqdm import tqdm
    assert len(list(product([1, 2, 3]))) == 3
    # check that total= arg works
    assert len(list(product([1, 2, 3], tqdm_class=tqdm,
                            tqdm_kwargs=dict(total=10)))) == 3
    # check that non-iterable input raises TypeError
    from nose.tools import raises
    @raises(TypeError)
    def f():
        product([1, 2, 3], 1)
        product([1, 2, 3], 1, tqdm_class=tqdm,
                tqdm_kwargs=dict(total=10))
    f()


if __name__ == '__main__':
    test

# Generated at 2022-06-26 09:22:23.676740
# Unit test for function product
def test_product():
    for i, j in product(range(5), repeat=6):
        assert isinstance(i, int)
        assert isinstance(j, int)
        assert i < 5
        assert j < 5
        break
    for i, j in product(range(5), range(5)):
        break
    for i, j in product(range(5), range(5), tqdm_class=tqdm_auto):
        break


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:22:30.919686
# Unit test for function product
def test_product():
    # This is a test of method product
    # It will fail if an exception is raised and may fail if a wrong
    #   result is returned
    # Inputs
    # Outputs
    # Test number: 0
    # Test comment: No arguments
    # Test name: case_0
    # Test description: No arguments
    try:
        var_0 = product()
        var_1 = list(var_0)
    except Exception:
        raise ValueError('Unexpected exception raised!')
    else:
        if var_1 != []:
            raise ValueError('Wrong result returned (%s instead of [])!' % (var_1))
    # Test number: 1
    # Test comment: 1 argument
    # Test name: case_1
    # Test description: 1 argument

# Generated at 2022-06-26 09:22:46.305963
# Unit test for function product
def test_product():
    var_0 = list(range(10))
    var_1 = list(range(10))
    var_2 = list(product(var_0, var_1))

# Generated at 2022-06-26 09:22:47.713593
# Unit test for function product
def test_product():
    if __name__ == "__main__":
        import nose
        nose.runmodule()

# Generated at 2022-06-26 09:22:49.590829
# Unit test for function product
def test_product():
    assert product([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-26 09:22:53.244736
# Unit test for function product
def test_product():
    """Check whether product works."""
    my_iter = product('a', 'b', tqdm_class=tqdm_auto)
    assert list(my_iter) == [('a', 'b')]

# Generated at 2022-06-26 09:22:53.807807
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:23:01.613615
# Unit test for function product
def test_product():
    import math
    import numpy
    var_0 = product()
    var_2 = next(var_0)
    var_3 = product()
    var_4 = next(var_3)
    var_5 = product()
    var_6 = next(var_5)
    var_7 = product()
    var_8 = next(var_7)
    var_9 = product()
    var_10 = next(var_9)
    var_12 = product([2], [3], [5], [7])
    var_13 = next(var_12)
    var_14 = product([2], [3], [5], [7])
    var_15 = next(var_14)
    var_16 = product([2], [3], [5], [7])

# Generated at 2022-06-26 09:23:03.215891
# Unit test for function product
def test_product():
    # Testing the 'product' method.
    product()

# Generated at 2022-06-26 09:23:13.224569
# Unit test for function product
def test_product():
    import numpy as np
    import pandas as pd
    from pandas.util.testing import assert_frame_equal, assert_series_equal

    array_2D = np.array([[1,2,3],[4,5,6]])
    list_1D = [1,2,3,4]
    list_2D = [[1,10],[2,20],[3,30],[4,40]]
    dict_1D = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    dict_2D = {'a': [1,10], 'b': [2,20], 'c': [3,30], 'd': [4,40]}
    series_1D = pd.Series(dict_1D)

# Generated at 2022-06-26 09:23:27.937330
# Unit test for function product
def test_product():
    # Example
    var_1 = list(product("ABCD", "xy"))  # Ax Ay Bx By Cx Cy Dx Dy
    var_2 = list(product(range(2), repeat=3))  # 000 001 010 011 100 101 110 111
    # Example: combine with map()
    range_3 = range(3)
    var_3 = list(map(lambda x, y: (x, y, 3), range_3, product(range_3, repeat=2)))  # (0, 0, 1, 0, 2, 0, 0, 1, 1, 1, 2, 1, 0, 2, 1, 2, 2, 2)

# Generated at 2022-06-26 09:23:40.445350
# Unit test for function product
def test_product():
    from itertools import product as product_orig
    from random import random
    for tqdm_class in [tqdm_auto]:
        for args in [(range(1, random() * 10), "abcd")]:
            var_0 = product(*args, tqdm_class=tqdm_class)
            var_1 = product_orig(*args)
            msg = "product(*{0}).{1} != product_orig(*{0}).{1}"
            assert all(a == b
                       for a, b in zip(var_0, var_1)), msg.format(args, '__next__')
            var_0 = list(product(*args, tqdm_class=tqdm_class))
            var_1 = list(product_orig(*args))

# Generated at 2022-06-26 09:23:51.726103
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """

    # Print function name
    print('\nUnit test for function product')

    # test case 0
    test_case_0()

    # test case 1
    var_0 = product()
    var_1 = list(var_0)
    assert var_1 == [()]

    # test case 2
    var_0 = product((1, 2))
    var_1 = list(var_0)
    assert var_1 == [(1,), (2,)]

    # test case 3
    var_0 = product((1, 2), (3, 4))
    var_1 = list(var_0)
    assert var_1 == [(1, 3), (1, 4), (2, 3), (2, 4)]

    # test case 4

# Generated at 2022-06-26 09:24:02.768863
# Unit test for function product
def test_product():
    var_0 = {'name': 'file', 'mode': 'a', 'buffering': 1,
             'closefd': True, 'encoding': 'utf-8', 'errors': None,
             'newline': '\n', 'opener': None}

# Generated at 2022-06-26 09:24:06.081159
# Unit test for function product
def test_product():
    assert type(test_case_0) == list
    
# Direct run
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:24:07.988319
# Unit test for function product
def test_product():
    assert product() == None, "Return parameter does not match expected return type"

# Generated at 2022-06-26 09:24:18.502651
# Unit test for function product
def test_product():
    var_0 = product('ABCD', 'xy')
    assert var_0 == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]
    var_0 = product(range(2), repeat=3)
    assert var_0 == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
    var_0 = product('ABCD', range(2))

# Generated at 2022-06-26 09:24:24.340493
# Unit test for function product
def test_product():
    var_0 = product(iterable=[0,1,2,3,4,5,6,7,8,9], tqdm_class=None)
    var_1 = list(var_0)
    assert var_1 == [0,1,2,3,4,5,6,7,8,9]


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:24:34.832855
# Unit test for function product
def test_product():
    # Remove this line and define your test inputs.
    test_input_0 = None
    test_input_1 = None
    # Remove this line and define your test outputs.
    test_expected_0 = None
    test_expected_1 = None
    with tqdm_auto(leave=True) as t:
        var_0 = product(test_input_0, test_input_1, tqdm_class=tqdm_auto)
        var_1 = list(var_0)
        t.update()
    # Validate that `var_0` matches expected `var_0`.
    assert var_1 == test_expected_0
    assert var_1 == test_expected_1

# Generated at 2022-06-26 09:24:38.933899
# Unit test for function product
def test_product():
    list_0 = [1,2,3]
    list_1 = ['a','b','c']
    var_0 = product(list_0, list_1)
    var_1 = list(var_0)
    assert var_1 == [(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b'), (2, 'c'), (3, 'a'), (3, 'b'), (3, 'c')]

# Generated at 2022-06-26 09:24:51.665280
# Unit test for function product
def test_product():
    # Testing with strings (TypeError)
    # test_case_0()
    test_case_1()
    # Testing when iterator is empty
    test_case_2()
    # Testing when iterator only has one element
    test_case_3()
    # Testing when iterator has multiple elements
    test_case_4()

    print("All tests passed")


# Generated at 2022-06-26 09:25:04.384591
# Unit test for function product
def test_product():
    # Input parameters
    # str or NoneType tqdm_class = tqdm.auto.tqdm
    # (dynamic) iterable *iterables
    # (dynamic)
    tqdm_class = tqdm_auto
    kwargs = {}
    for arg in tests_product_0_0:
        kwargs.clear()
        kwargs.update(tests_product_0_1)
        kwargs.update(tests_product_0_2)
        var_0 = product(arg[0], arg[1], arg[2], arg[3], tqdm_class=tqdm_class, **kwargs)
        var_1 = list(var_0)
        assert var_1 == arg[4]
    # (dynamic)
    tqdm_class = tqdm

# Generated at 2022-06-26 09:25:09.825921
# Unit test for function product
def test_product():
    @tqdm_auto
    def function_0():
        var_0 = product([1,2,3], [1,2,3])
        var_1 = list(var_0)
    function_0()


# Generated at 2022-06-26 09:25:11.973916
# Unit test for function product
def test_product():
    var_0 = product()
    assert var_0 == None

# Generated at 2022-06-26 09:25:18.249343
# Unit test for function product
def test_product():
    my_list = [[[1, 2, 3]], [4, 5]]
    pr = product(*my_list)
    print("Test case 0:")
    for i in pr:
        print(i)

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:25:24.569453
# Unit test for function product
def test_product():
    with tqdm(total=11, ncols=80) as pbar:
        var_0 = (1, 2)
        var_1 = (3, 4)
        var_2 = product(var_0, var_1, tqdm=pbar)
        var_3 = 0
        for var_4 in var_2:
            var_3 += 1
            print(var_4)

# Generated at 2022-06-26 09:25:28.016404
# Unit test for function product
def test_product():
    lst = list(product([1, 2, 3], [4, 5], [6, 7]))
    assert lst == [(1, 4, 6), (1, 4, 7), (1, 5, 6), (1, 5, 7), (2, 4, 6),
                   (2, 4, 7), (2, 5, 6), (2, 5, 7), (3, 4, 6), (3, 4, 7),
                   (3, 5, 6), (3, 5, 7)]

# Generated at 2022-06-26 09:25:29.435580
# Unit test for function product
def test_product():
    assert product() == iter([])



# Generated at 2022-06-26 09:25:38.790755
# Unit test for function product
def test_product():
    assert list(product([1, 2], repeat=1)) == [(1,), (2,)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]

    # unit test using `numpy.prod`
    N = 50
    I = [list(range(n)) for n in range(1, N)]
    for i in range(1, N):
        # assert len(list(tqdm_product(I, repeat=i))) == numpy.prod(range(1, i))
        assert len(list(product(I, repeat=i))) == numpy.prod(range(1, i))
    return


if __name__ == '__main__':
    import pytest

# Generated at 2022-06-26 09:25:42.508667
# Unit test for function product
def test_product():
    var_0 = product()
    var_1 = list(var_0)


if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-26 09:27:33.177819
# Unit test for function product
def test_product():
    # Literal Tests
    assert list(product([0, 1])) == [(0,), (1,)]
    assert list(product([0, 1], repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Unit test for function product

# Generated at 2022-06-26 09:27:35.878771
# Unit test for function product
def test_product():
    assert product() is not None
    assert product([1, 2, 3, 4]) is not None

# Generated at 2022-06-26 09:27:38.681080
# Unit test for function product
def test_product():
    tmp = list(product([10, 20], repeat=3))
    assert tmp == [(10, 10, 10), (10, 10, 20), (10, 20, 10), (10, 20, 20), (20, 10, 10), (20, 10, 20), (20, 20, 10), (20, 20, 20)]


if __name__ == "__main__":
    from . import _testutil as testutil
    testutil.run_unittests(globals())

# Generated at 2022-06-26 09:27:43.189773
# Unit test for function product
def test_product():
    # Assert that . . .
    assert type(product()) == itertools.product


if __name__ == "__main__":
    from .._utils import gc_collected_test

    gc_collected_test(test_product)

# Generated at 2022-06-26 09:27:54.170636
# Unit test for function product
def test_product():
    for i in product("abcd", "xy"):
        assert i in [("a", "x"), ("a", "y"), ("b", "x"), ("b", "y"), ("c", "x"), ("c", "y"), ("d", "x"), ("d", "y")]

# Generated at 2022-06-26 09:28:05.318808
# Unit test for function product
def test_product():
    # test all_str_args
    assert list(product([0, 1], repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-26 09:28:11.811044
# Unit test for function product
def test_product():
    import sys

    for t in [product(xrange(10), xrange(10), xrange(10))]:
        for i in t:
            pass
        sys.stderr.write("OK\n")


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:28:17.760575
# Unit test for function product
def test_product():
    for i in product(range(10)):
        pass
    for i in product((range(10), range(10))):
        pass
    for i in product(range(10), range(10)):
        pass
    for i in product(range(10), range(10), range(10)):
        pass
    for i in product(range(10), range(10), range(10), range(10)):
        pass
    for i in product(range(10), range(10), range(10), range(10), range(10)):
        pass
    for i in product(*([range(10)] * 10)):
        pass

# Generated at 2022-06-26 09:28:20.497628
# Unit test for function product
def test_product():
    test_case_0()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:28:27.608801
# Unit test for function product
def test_product():
    var_0 = product([1, 2, 3, 4])
    var_1 = list(var_0)
    assert(var_1[0][0]==1)
    assert(var_1[3][0]==4)
    var_2 = product(range(2))
    var_3 = list(var_2)
    assert(var_3[0]==(0,))
    assert(var_3[1]==(1,))
    assert(len(var_3)==2)
    assert(var_3[-1]==(1,))
    var_4 = product((1, 2, 3), (2, 3, 4))
    var_5 = list(var_4)
    assert(var_5[0]==(1, 2))