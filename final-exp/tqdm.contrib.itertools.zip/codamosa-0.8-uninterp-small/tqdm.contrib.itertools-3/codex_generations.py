

# Generated at 2022-06-26 09:20:18.048563
# Unit test for function product
def test_product():
    from pickle import dumps, loads, HIGHEST_PROTOCOL
    from io import BytesIO
    from itertools import product as orig_product
    # Smoke test
    var_0 = product((1,))
    var_1 = orig_product((1,))

    # Time test
    var_2 = product(list(range(10000)))
    var_3 = orig_product(list(range(10000)))
    # Pickling test
    var_4 = product((1,))
    buf = BytesIO()
    var_5 = dumps(var_4, HIGHEST_PROTOCOL)
    buf.write(var_5)
    buf.seek(0)
    var_6 = loads(buf.read())

# Generated at 2022-06-26 09:20:20.480198
# Unit test for function product
def test_product():
    var_0 = product(iterable={})
    var_1 = product(iterable={}, tqdm_class={})

# Generated at 2022-06-26 09:20:25.221050
# Unit test for function product
def test_product():
    var_0 = 2
    var_1 = [var_0, var_0]
    var_2 = product(var_1, tqdm_class = float)
    for i in var_2:
        print(i)

if __name__ == '__main__':
    test_product()
    test_case_0()

# Generated at 2022-06-26 09:20:27.153867
# Unit test for function product
def test_product():
    var_0 = product((1,2,3), (10,100,1000))
    assert var_0
    assert "itertools.product" not in tqdm_auto.__name__

# Generated at 2022-06-26 09:20:27.580362
# Unit test for function product
def test_product():
    pass

# Generated at 2022-06-26 09:20:28.469652
# Unit test for function product
def test_product():
    assert product()



# Generated at 2022-06-26 09:20:35.685706
# Unit test for function product
def test_product():
    """
    Usage: test_product()

    @rtype: 1
    """
    # First test case
    for i in product():
        pass  # First test case


if __name__ == "__main__":
    from ..tests.py.utils import get_test_cases
    for key, val in get_test_cases(__file__).items():
        print("Running {}...".format(key))
        val()
    print("All tests succeeded!")

# Generated at 2022-06-26 09:20:40.188247
# Unit test for function product
def test_product():
    from itertools import product
    from tqdm import trange
    for i in trange(1000):
        for j in trange(1000):
            for _ in product(range(i), range(j)):
                pass

# Generated at 2022-06-26 09:20:44.804468
# Unit test for function product
def test_product():
    if hasattr(test_case_0, "__name__"):
        print(test_case_0.__name__)
    if hasattr(test_case_0, "__doc__"):
        print(test_case_0.__doc__)
    assert test_case_0() is None

# Generated at 2022-06-26 09:20:56.581552
# Unit test for function product
def test_product():
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None is not None
    assert None

# Generated at 2022-06-26 09:21:09.766088
# Unit test for function product
def test_product():
    from .utils import format_sizeof
    from random import uniform
    from time import sleep

    class DummyTqdmFile(object):
        """
        Dummy file-like that will write to tqdm's file.
        """

        file = None

        def __init__(self, file):
            self.file = file

        def write(self, x):
            # Avoid print() second call (useless \n)
            if len(x.rstrip()) > 0:
                tqdm.write(x, file=self.file)

    def prod(iterables, **kwargs):
        """
        Equivalent of `itertools.product` but raises an error
        if the iterations are alreday exhausted.
        """
        iterables = map(iter, iterables)

# Generated at 2022-06-26 09:21:17.599513
# Unit test for function product
def test_product():
    import random
    import string
    from ..utils import format_sizeof
    N = 10
    strs = ''.join(random.choice(string.ascii_uppercase + string.digits)
                   for x in range(N))
    ints = [random.randint(0, N) for x in range(N)]
    for s in product(strs, ints, tqdm_class=tqdm_auto):
        pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:21:21.868149
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    list_product = list(itertools.product([1, 2], [3, 4, 5]))
    assert len(list_product) == 6
    list_product = list(product([1, 2], [3, 4, 5]))
    assert len(list_product) == 6

# Generated at 2022-06-26 09:21:32.432452
# Unit test for function product
def test_product():
    from sys import stdout
    from time import sleep
    from numpy.random import randint
    for i in product(range(100), range(100), tqdm_class=tqdm_auto, desc="1st loop", bar_format="{l_bar}{bar} [ time left: {remaining} ]", dynamic_ncols=True, mininterval=0.5, initial=10):
        sleep(0.001)
        for j in product(range(100), range(100), tqdm_class=tqdm_auto, desc="2nd loop", leave=False, smoothing=0, total=200, dynamic_ncols=True, disable=False):
            sleep(0.001)
            assert randint(2) == 0

# Generated at 2022-06-26 09:21:35.177856
# Unit test for function product
def test_product():
    """Simple test of `tqdm.itertools.product`"""
    assert list(product(range(3), range(3))) == list(itertools.product(
        range(3), range(3)))

# Generated at 2022-06-26 09:21:41.326864
# Unit test for function product
def test_product():
    from ..tests._utils import _random_data_len, _test_equality

    for tqdm_cls in [tqdm_auto, tqdm_gui, tqdm, tqdm_notebook]:
        for tqdm_kwargs in [{}, {"miniters": 1, "mininterval": 0}]:
            for lens in [list(range(3)), [3, 3, 3], [3, 3, 2]]:
                iterables = [_random_data_len(l) for l in lens]

                _test_equality(lambda: product(
                    *iterables, tqdm_class=tqdm_cls, **tqdm_kwargs),
                    lambda: itertools.product(*iterables))

# Generated at 2022-06-26 09:21:44.497144
# Unit test for function product
def test_product():
    from .tqdm import trange
    for i in trange.product([4, 5], [6, 7, 8], tqdm_class=trange):
        pass

# Generated at 2022-06-26 09:21:51.513241
# Unit test for function product
def test_product():
    from ..utils import SimpleNamespace
    from numpy.random import randint
    from numpy import prod
    kwargs = dict(tqdm_class=SimpleNamespace)
    A = [1, 2, 3]
    B = [4, 5, 6]
    it = list(product(A, B, **kwargs))
    assert it == [(a, b) for a in A for b in B]
    assert kwargs['tqdm_class'].total == len(A) * len(B)

    it = product([[1, 2], [3, 4]], [5, 6], **kwargs)
    assert kwargs['tqdm_class'].total == prod([len(a) for a in it])


# Generated at 2022-06-26 09:21:54.684393
# Unit test for function product
def test_product():
    a = list(range(5))
    b = list(product(a, a, a, tqdm_class=tqdm_auto))
    assert (len(a) ** 3) == len(b)

# Generated at 2022-06-26 09:22:00.014708
# Unit test for function product
def test_product():
    import operator
    import sys
    if sys.version_info < (3,):
        zip = itertools.izip  # for py2.7
    for input_, output_ in [(range(2), 8),
                            (range(2), 8),
                            (range(3), 27)]:
        output = [p for p in product(*input_, tqdm_class=tqdm_auto)]
        assert output == list(itertools.product(*input_))
        assert len(output) == output_

# Generated at 2022-06-26 09:22:10.001718
# Unit test for function product
def test_product():
    from numpy.random import randint
    for n in range(1, 10):
        for k in range(1, 10):
            lists = [randint(1, 10000, size=n) for _ in range(k)]
            res = product(*lists, total=None, tqdm_class=tqdm_auto)
            assert list(res) == list(itertools.product(*lists))

# Generated at 2022-06-26 09:22:21.536848
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof

    est = format_sizeof(10**5, unit='B')
    est += '+'
    assert (1,), format_sizeof(np.prod(list(product((10**5,), repeat=1))),
                               total=10**5, unit='B', unit_scale=True,
                               rate=True) == (est, True)
    assert (2,), format_sizeof(np.prod(list(product((10**5,), repeat=2))),
                               total=10**10, unit='B', unit_scale=True,
                               rate=True) == (est, True)


# For backwards-compatibility
from tqdm.utils import _deprec

# Generated at 2022-06-26 09:22:23.732213
# Unit test for function product
def test_product():
    for i in product(
            range(3, 0, -1),
            range(10, 0, -1),
            tqdm_class=tqdm_auto,
            leave=None):
        pass



# Generated at 2022-06-26 09:22:30.918061
# Unit test for function product
def test_product():
    """Unit test for product()"""
    from ..utils import format_sizeof
    r = list(product(range(5), range(5), tqdm_class=tqdm_auto))
    assert len(r) == 25
    assert r[0] == (0, 0)
    assert r[-1] == (4, 4)
    r = list(product(range(5), range(5), range(5), tqdm_class=tqdm_auto))
    assert len(r) == 125
    assert r[0] == (0, 0, 0)
    assert r[-1] == (4, 4, 4)
    r = list(product(range(5), range(3), range(2), range(7),
                     tqdm_class=tqdm_auto))
    assert len(r)

# Generated at 2022-06-26 09:22:42.321111
# Unit test for function product
def test_product():
    """Test for tqdm.itertools.product"""
    import random
    from collections import Counter

    # test product on a random iterable
    random.seed(12345)
    a = [random.randint(1, 8) for i in range(100)]
    assert Counter(a) == Counter(list(product(a)))

    # test product on a list of ranges
    assert Counter(range(100)) == Counter(product(*[range(100)]))

# Generated at 2022-06-26 09:22:45.095880
# Unit test for function product
def test_product():
    assert (list(product([1, 2],
                         ['x', 'y'])) == [
        (1, 'x'), (1, 'y'), (2, 'x'), (2, 'y')])

# Generated at 2022-06-26 09:22:51.027206
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..pandas import tqdm as tqdm_pandas
    assert ([i for i in product(list(range(10000)))] ==
            [i for i in product(list(range(10000)), total=10000)])
    assert ([i for i in product(list(range(10000)), tqdm_class=tqdm_pandas)] ==
            [i for i in product(list(range(10000)),
                                tqdm_class=tqdm_pandas, total=10000)])

# Generated at 2022-06-26 09:23:00.324383
# Unit test for function product
def test_product():
    from .utils import TestIO
    with TestIO() as t:
        # Manually create a verbose itertools.product
        try:
            lens = list(map(len, t.A))
        except TypeError:
            pass
        else:
            t.total = 1
            for i in lens:
                t.total *= i
        # t.total should be 12
        # Total of all digits
        t.sum = 0
        # Total number of digits
        t.count = 0
        for i in itertools.product(*t.A):
            # tqdm.write(str(i))
            for j in i:
                t.sum += j
                t.count += 1
        # Expected output:
        # 1
        # 2
        # 3
        # 1
        # 2
        #

# Generated at 2022-06-26 09:23:04.915018
# Unit test for function product
def test_product():
    from .tests import xrange
    iterables = [range(4), range(4), range(4)]
    for i in xrange(4**3):
        assert i == sum(a * 4**(2 - j) for j, a in enumerate(product(*iterables)))

# Generated at 2022-06-26 09:23:11.107263
# Unit test for function product
def test_product():
    from .tests import TestCase, _range

    with TestCase('itertools_product'):
        assert list(product(_range(3), tqdm_class=tqdm_auto)) == list(itertools.product(_range(3)))
        assert list(product(_range(3), _range(3), tqdm_class=tqdm_auto)) == list(itertools.product(_range(3), _range(3)))

# Generated at 2022-06-26 09:23:24.364300
# Unit test for function product
def test_product():  # pragma: no cover
    """
    Unit test for function product
    """
    import numpy as np
    from ..tqdm_notebook import tqdm_notebook

    a = np.zeros((3, 5))
    for i, j in tqdm_notebook(product(range(3), range(5))):  # pragma: no cover
        # `tqdm_notebook` is not part of the public API
        a[i, j] = i * j
    assert np.all(a == np.arange(15).reshape(3, 5))


# Test for function product

# Generated at 2022-06-26 09:23:32.261106
# Unit test for function product
def test_product():
    for args, total in [
            (("ABC", "123"), 12),
            (("ABC", "123", "xyz"), 36),
            (([], "123"), 0),
            (("ABC", []), 0),
            (([], []), 0),
            ((range(10), range(3)), 30),
            ]:
        count = 0
        tqdm_obj = tqdm_auto(unit_scale=True,
                             desc=u"test_product",
                             total=total)
        for _ in product(*args, tqdm_class=tqdm_auto):
            count += 1
            tqdm_obj.update(1)
        assert count == total

# Generated at 2022-06-26 09:23:38.581715
# Unit test for function product
def test_product():
    """Test that tqdm.itertools.product works"""
    from nose.tools import assert_equal
    ret = []
    for _ in product("abcd", "efg", "hi", tqdm_class=tqdm_auto):
        ret += [_]
    assert_equal(ret, list(itertools.product("abcd", "efg", "hi")))

# Generated at 2022-06-26 09:23:49.650065
# Unit test for function product
def test_product():
    """Runs a simple unit test on function product"""
    import numpy as np
    res = []
    tot = 0
    for i, j in product(range(5), range(5),
                        tqdm_class=tqdm_auto, leave=False):
        res.append((i, j))
        tot += 1
    assert len(res) == np.prod(list(map(len, [range(5), range(5)])))
    assert res[-1][0] == 4
    assert res[-1][1] == 4
    assert tot == np.prod(list(map(len, [range(5), range(5)])))

# Generated at 2022-06-26 09:23:54.073681
# Unit test for function product
def test_product():
    import numpy as np
    # Make sure this does not raise any exception
    for i, j in product(np.linspace(0, 1, 10), range(3)):
        i, j

# Generated at 2022-06-26 09:23:57.223701
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    try:
        from nose.tools import assert_equal
    except ImportError:
        raise SkipTest

    # Test basic use
    it = product(range(3), range(4), range(5), tqdm_class=tqdm_auto)
    it_ = itertools.product(range(3), range(4), range(5))
    for i in it:
        assert_equal(i, next(it_))

# Generated at 2022-06-26 09:24:02.659088
# Unit test for function product
def test_product():
    """
    Test function that wraps around itertools.product
    """
    from numpy.testing import assert_equal

    product_test = list(product(range(3), range(3), tqdm_class=tqdm_auto,
                                leave=False))
    product_true = list(itertools.product(range(3), range(3)))

    for product_test, product_true in zip(product_test, product_true):
        assert_equal(product_test, product_true)

# Generated at 2022-06-26 09:24:12.769843
# Unit test for function product
def test_product():
    "Test for tqdm multiprocessing"
    from .tqdm_test_examples import my_product

    # Test with generator
    list1 = [1, 2, 3]
    list2 = ['a', 'b', 'c']
    assert my_product(list1, list2) == [
        (1, 'a'), (1, 'b'), (1, 'c'),
        (2, 'a'), (2, 'b'), (2, 'c'),
        (3, 'a'), (3, 'b'), (3, 'c'),
    ]

    # Test with list

# Generated at 2022-06-26 09:24:19.055274
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests import _test_iterator_equal
    _test_iterator_equal(product([1, 2], [1, 2]),
                         itertools.product([1, 2], [1, 2]))
    _test_iterator_equal(product([1, 2], [1, 2], [1, 2]),
                         itertools.product([1, 2], [1, 2], [1, 2]))
    _test_iterator_equal(product(range(1000), range(1000)),
                         itertools.product(range(1000), range(1000)))

# Generated at 2022-06-26 09:24:26.164874
# Unit test for function product
def test_product():
    """Test product generator"""
    from numpy.testing import assert_array_equal
    class tqdm(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
            self.count = 0
        def __enter__(self):
            return self
        def __exit__(self, type, value, tb):
            return False
        def __iter__(self):
            return self
        def __next__(self):
            if self.count < self.total:
                self.count += 1
                return self.count - 1
            else:
                raise StopIteration()
        def next(self):
            return self.__next__()
        def update(self):
            self.__next__()

# Generated at 2022-06-26 09:24:51.402164
# Unit test for function product
def test_product():
    """Test `tqdm.itertools.product`"""
    from nose.tools import assert_equal
    result = list(product(range(3), range(4), range(5),
                          tqdm_class=tqdm_auto, leave=False))
    assert_equal(result, list(itertools.product(range(3), range(4), range(5))))

# Generated at 2022-06-26 09:25:03.728399
# Unit test for function product
def test_product():
    import numpy
    numpy.testing.assert_equal(
        list(product(range(10), repeat=1)),
        list(itertools.product(range(10), repeat=1)))
    numpy.testing.assert_equal(
        list(product(range(10), repeat=2)),
        list(itertools.product(range(10), repeat=2)))
    numpy.testing.assert_equal(
        list(product(range(10), repeat=3)),
        list(itertools.product(range(10), repeat=3)))
    numpy.testing.assert_equal(
        list(product(range(10), repeat=4)),
        list(itertools.product(range(10), repeat=4)))

# Generated at 2022-06-26 09:25:09.364195
# Unit test for function product
def test_product():
    for s in product(range(10), range(30), "-x", tqdm_class=None):
        pass
    for s in product(range(10), range(30), "-x", total=10 * 30):
        pass

# Generated at 2022-06-26 09:25:17.557521
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    from .utils import _range
    from . import trange

    assert list(product(_range(10), _range(100), _range(1000))) == \
        list(itertools.product(_range(10), _range(100), _range(1000)))
    for kwargs in [{"leave": True}, {}, {"miniters": 20}]:
        assert list(
            tqdm(product(_range(10), _range(100), _range(1000)), **kwargs)) == \
            list(itertools.product(_range(10), _range(100), _range(1000)))

# Generated at 2022-06-26 09:25:24.907201
# Unit test for function product
def test_product():
    """Test for function product"""
    from numpy.testing import assert_equal
    s = "ABCD"
    r = list(product(s, repeat=2))
    assert_equal(r, [('A', 'A'), ('A', 'B'),
                     ('A', 'C'), ('A', 'D'),
                     ('B', 'A'), ('B', 'B'),
                     ('B', 'C'), ('B', 'D'),
                     ('C', 'A'), ('C', 'B'),
                     ('C', 'C'), ('C', 'D'),
                     ('D', 'A'), ('D', 'B'),
                     ('D', 'C'), ('D', 'D')])

    from random import shuffle
    ls = list(range(100))
    for _ in range(10):
        s = list(range(100))

# Generated at 2022-06-26 09:25:36.535516
# Unit test for function product
def test_product():
    from random import uniform
    from math import sqrt
    subs = [list(range(1, 101)), ['a', 'b', 'c']]
    p = product(*subs)
    for (i, j) in zip(p, itertools.product(*subs)):
        assert i == j
    for _ in range(1000):
        subs_2 = [range(i) for i in map(int, [uniform(1, 1000) for _ in range(3)])]
        p = product(*subs_2)
        for (x, y) in zip(p, itertools.product(*subs_2)):
            assert x == y
    print("test_product passed.")

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-26 09:25:47.043861
# Unit test for function product
def test_product():
    from .utils import TestCase

    with TestCase():
        from itertools import product as itertools_product

        for i in range(2, 5):
            for j in range(2, 5):
                for k in range(2, 5):
                    it = list(
                        itertools_product(range(i), range(j), range(k)))
                    p = list(product(range(i), range(j), range(k)))
                    assert it == p

                    it = list(itertools_product(range(i), range(j), range(k)))
                    p = list(
                        tqdm(
                            range(i),
                            range(j),
                            range(k),
                            tqdm_class=tqdm_gui,
                            leave=False))
                    assert it == p

# Generated at 2022-06-26 09:25:52.092283
# Unit test for function product
def test_product():
    """
    Test for `tqdm.itertools.product`.
    """
    for t, a in [(tqdm_auto, None),
                 (tqdm_auto, 1),
                 (tqdm_auto, 2),
                 (tqdm_auto, 2 ** 8),
                 (tqdm_auto, 2 ** 10),
                 (tqdm_auto, 2 ** 12)]:
        assert sum(product(range(2 ** 8), range(2 ** 8), tqdm_class=t)) == \
            a or a is None
        assert sum(product(range(2 ** 8), range(2 ** 8), tqdm_class=t)) == \
            sum(itertools.product(range(2 ** 8), range(2 ** 8)))

# Generated at 2022-06-26 09:26:04.650405
# Unit test for function product
def test_product():
    from .allovertb import allovertb
    from .tqdm import tqdm, trange

    for nb in (1, 2):
        for tqdm_cls in (tqdm, trange):
            for desc in ('desc', None):
                for total in (100, None):
                    for leave in (True, False):
                        for position in range(-1, 5):
                            t = tqdm_cls(total=total, desc=desc,
                                         leave=leave, position=position)
                            for _ in allovertb(product(t,
                                                      range(nb),
                                                      range(nb),
                                                      range(nb),
                                                      tqdm_class=tqdm_cls)):
                                pass
                            t.close()

# Generated at 2022-06-26 09:26:16.155040
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from sys import version_info
    from .tests import tests_class
    from .tests import setup_tests
    for cls in tests_class:
        setup_tests(cls)
        try:
            cls.close()
        except Exception:
            pass
        with tqdm_auto(leave=False) as t:
            for i in product(range(3), tqdm_class=cls, desc="product test",
                             miniters=1, mininterval=0, maxinterval=0):
                t.update()
                pass
        assert t.n == 3
        assert t.smoothing == 1
        assert t.delta_t == t.last_print_t
        if version_info[0] >= 3:
            assert t

# Generated at 2022-06-26 09:27:06.797389
# Unit test for function product
def test_product():
    from random import shuffle
    from nose.tools import assert_equal
    assert_equal(
        list(product(range(10), repeat=2)),
        [(i, i) for i in range(10)])
    assert_equal(
        list(product(range(3), repeat=3)),
        [(i, i, i) for i in range(3)])
    assert_equal(
        list(product(range(10), repeat=0)),
        [()])
    assert_equal(
        list(product(range(3), repeat=1)),
        [(i,) for i in range(3)])
    assert_equal(
        list(product(range(1), repeat=20)),
        [()])

# Generated at 2022-06-26 09:27:14.370606
# Unit test for function product
def test_product():
    from .utils import TestCase

    with TestCase() as test:
        for idx, x in enumerate(product(range(2), range(2), range(2),
                                        tqdm_class=test.mock_tqdm)):
            test.expected_update(1)
        assert idx == 7


if __name__ == "__main__":
    from ._version import get_versions
    __version__ = get_versions()['version']
    del get_versions
    test_product()

# Generated at 2022-06-26 09:27:24.071271
# Unit test for function product
def test_product():
    from random import shuffle
    from sys import stderr
    for iterable in [
            range(4),
            range(10, 15),
            range(20, 25),
            range(30, 35)]:
        shuffle(iterable)
        print(list(product(iterable, iterable, tqdm_class=tqdm_auto,
                           file=stderr, mininterval=0.01, miniters=1)))
    print(list(product(range(4), range(10, 20))))

# Generated at 2022-06-26 09:27:34.470952
# Unit test for function product
def test_product():
    from .auto import trange
    from .utils import _range
    from .utils import FormatCustomText
    for t in (trange, FormatCustomText):
        p = list(product(['abc', 'def'], tqdm_class=t))
        assert p == [('a', 'd'), ('a', 'e'), ('a', 'f'),
                     ('b', 'd'), ('b', 'e'), ('b', 'f'),
                     ('c', 'd'), ('c', 'e'), ('c', 'f')]
        p = list(product(['abc', 'def'], repeat=2, tqdm_class=t))

# Generated at 2022-06-26 09:27:42.778738
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    for i in product(range(10), repeat=4, tqdm_class=None):
        pass
    from tqdm import trange
    for i in product(range(10), repeat=4, tqdm_class=trange):
        pass
    for i in product(range(10), repeat=4):
        pass
    print(format_sizeof(product(range(10), repeat=4)))

# Generated at 2022-06-26 09:27:53.926398
# Unit test for function product
def test_product():
    """Test product wrapper"""
    from .nested import nested
    import warnings
    with warnings.catch_warnings(record=True) as w:
        for x, y in product('abcd', '1234'):
            pass
        assert len(w) == 0
        for x, y in product('abcd', '1234', total=10):
            pass
        assert len(w) == 1
    with nested(tqdm_auto(total=50), tqdm_auto(total=50)) as (p, q):
        for x, y in product(range(5), range(10), tqdm_class=None, p=p, q=q):
            pass
        for x, y in product(range(5), range(10), p=p, q=q):
            pass

# Generated at 2022-06-26 09:27:59.431331
# Unit test for function product
def test_product():
    assert list(product("ABC", "123", tqdm_class=None)) == list(itertools.product("ABC", "123"))
    assert list(product("ABC", "123", tqdm_class=None)) == list(product("ABC", "123"))

# Generated at 2022-06-26 09:28:03.321314
# Unit test for function product
def test_product():
    it = product(range(10), range(10))
    assert len(list(it)) == 100

    it = product(range(10), range(10), tqdm_class=tqdm_auto())
    assert len(list(it)) == 100

# Generated at 2022-06-26 09:28:13.081164
# Unit test for function product
def test_product():
    import contextlib
    from io import BytesIO
    capture = contextlib.closing(BytesIO())
    list(product(range(10), range(10),
                 desc='Test', file=capture, ascii=True))
    output = capture.getvalue().decode('utf-8')
    exp = ('Test: 100%|###########################################|     '
           '\r', '')

    assert exp[0] in output and exp[1] in output

# Generated at 2022-06-26 09:28:25.447090
# Unit test for function product
def test_product():
    """
    Unit test for `product`.
    """
    from .tests import TestCase
    from .utils import BetterDict, format_dict_diff

    try:
        from itertools import product as itertools_product
        from itertools import tee as itertools_tee
    except ImportError:
        raise SkipTest

    class TestProduct(TestCase):

        def __init__(self):
            self.t = tqdm_auto(ascii=True)

        def test_product(self):
            """
            Test that `self.t.unwrap` returns original product object
            """
            iterables = [range(3), range(3), range(3)]
            expected_result = list(itertools_product(*iterables))
            expected_len = len(expected_result)

# Generated at 2022-06-26 09:30:08.256647
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""