

# Generated at 2022-06-26 09:20:12.558031
# Unit test for function product
def test_product():
    """
    Unit test for function
    :func:`~itertools_tqdm.itertools.product`.
    """
    # check simple case
    i = product('abcd', repeat=3)
    assert next(i) == ('a', 'a', 'a')
    assert sum(1 for _ in i) == 3**3 - 1

    # check total kwarg
    i = product('abcd', repeat=3, tqdm_class=tqdm_auto)
    assert next(i) == ('a', 'a', 'a')
    assert sum(1 for _ in i) == 3**3 - 1

    # check total kwarg
    i = product('abcd', repeat=3, tqdm_class=tqdm_auto)

# Generated at 2022-06-26 09:20:16.405093
# Unit test for function product
def test_product():
    # Example
    list(product(range(2), repeat=3))
    
    # Default usage
    list(product(range(2), repeat=3))
    
    # Test case: 0
    test_case_0()

# Generated at 2022-06-26 09:20:27.068651
# Unit test for function product
def test_product():
    with tqdm_auto(total=1) as t:
        assert len(list(product(range(1000), range(2)))) == 1000*2
        assert len(list(product(range(1000), range(0)))) == 0
        assert len(list(product(range(1000), range(2), tqdm_class=t.__class__))) == 1000*2
        assert len(list(product(tqdm_class=t.__class__, iterable=range(1000), iterable2=range(2)))) == 1000*2
        assert len(list(product(tqdm_class=t.__class__, iterable=range(1000), iterable=range(2)))) == 1000*2
        t.reset()

# Generated at 2022-06-26 09:20:28.468584
# Unit test for function product
def test_product():
    try:
        out = product()
    except:
        out = None

    assert out is None


# Generated at 2022-06-26 09:20:40.780346
# Unit test for function product
def test_product():
    var_0 = list(product())
    assert var_0 == []
    var_1 = list(product([1, 2, 3]))
    assert var_1 == [1, 2, 3]
    var_2 = list(product([1, 2, 3], [4, 5, 6]))
    assert var_2 == [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4),
        (3, 5), (3, 6)]
    var_3 = list(product([1, 2, 3], [4, 5, 6], [7, 8, 9]))

# Generated at 2022-06-26 09:20:42.629497
# Unit test for function product
def test_product():
    for i in product(range(1000)):
        pass
    assert i == 999

# Generated at 2022-06-26 09:20:46.040517
# Unit test for function product
def test_product():
    # get the array of values
    values = range(100)
    # iterate through all of the values using the product method
    assert sum(x for x in product(values)) == sum(values)

# Generated at 2022-06-26 09:20:46.692717
# Unit test for function product
def test_product():
    list(product(range(3), range(3)))

# Generated at 2022-06-26 09:20:53.024846
# Unit test for function product
def test_product():
    # A list of 'random' strings for testing.
    list_of_strings = ['hello', 'world', 'foo', 'bar', 'baz']
    real_output = itertools.product(list_of_strings)
    iter_test = product(list_of_strings, tqdm_class=TestTqdmNone)
    assert next(iter_test) == next(real_output)


# Generated at 2022-06-26 09:20:55.594273
# Unit test for function product
def test_product():
    try:
        for i in product():
            pass
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-26 09:20:57.895637
# Unit test for function product
def test_product():
    assert True


# Generated at 2022-06-26 09:21:08.276529
# Unit test for function product
def test_product():
    import sys
    import tqdm
    iterables = [range(10), range(10)]
    it = product(*iterables, tqdm_class=tqdm.tqdm_cls)
    if sys.version_info[0] == 3:
        fun = next
    else:
        fun = it.next
    assert fun() == (0, 0)
    assert fun() == (0, 1)
    assert fun() == (0, 2)
    assert fun() == (0, 3)
    assert fun() == (0, 4)
    assert fun() == (0, 5)
    assert fun() == (0, 6)
    assert fun() == (0, 7)
    assert fun() == (0, 8)
    assert fun() == (0, 9)

# Generated at 2022-06-26 09:21:11.572166
# Unit test for function product
def test_product():
    """Test case for the function `product`."""
    # Initialize key variables
    expected = 0
    result = 0

    # Do testing
    assert expected == result

# Generated at 2022-06-26 09:21:14.115297
# Unit test for function product
def test_product():
    """
    Unit test for function product:

    :param tqdm_class  : [default: tqdm.auto.tqdm].
    """
    pass

# Generated at 2022-06-26 09:21:24.654609
# Unit test for function product
def test_product():
    # Case 0
    test_case_0()
    # Case 1
    var_2 = product(range(1000))
    var_3 = list(var_2)
    int_3 = 8
    int_4 = -28
    int_5 = [int_4, int_4, int_4]
    # Case 2
    var_4 = product(range(100), range(100), range(100))
    var_5 = list(var_4)
    int_6 = 20
    str_0 = "thx"
    str_1 = ":)"
    str_2 = [str_1, str_1, str_1]
    # Case 3
    var_6 = product([1, 2, 3], repeat=2)
    var_7 = list(var_6)
    int_7 = 100

# Generated at 2022-06-26 09:21:27.123545
# Unit test for function product
def test_product():
    assert test_case_0() == 1

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-26 09:21:37.516017
# Unit test for function product
def test_product():
    try:
        product()
    except Exception as inst:
        assert inst.args[0] == "product() takes at least 1 argument (0 given)"
    try:
        tuple_0 = (0, 0)
        tuple_1 = (tuple_0, )
        tuple_2 = product(tuple_1)
        assert False
    except Exception as inst:
        assert inst.args[0] == "itertools.product() argument #1 must support iteration"
    try:
        list_0 = [1, 2, 3]
        any_2 = product(list_0, int_0)
        assert False
    except Exception as inst:
        assert inst.args[0] == "itertools.product() argument #2 must support iteration"

# Generated at 2022-06-26 09:21:47.883432
# Unit test for function product
def test_product():
    total = 1
    num_iters = 10
    for i in itertools.product(*[range(10)] * num_iters):
        i = list(i)
        assert sum(i) == (num_iters - 1) * sum(i) / (num_iters - 1)
        total += 1
    assert total == 10**num_iters

    var_1 = list(product(*[range(10)] * num_iters))
    assert total == len(var_1) == 10**num_iters

    iterable = range(10)
    total = sum(len(list(itertools.product(iterable, repeat=i)))
                for i in range(10))
    var_2 = list(product(*[iterable] * 10))
    assert total == len(var_2)

    iter

# Generated at 2022-06-26 09:21:57.933484
# Unit test for function product
def test_product():
    assert(product([1, 2, 3], [4, 5, 6], [8]) == list(product([1, 2, 3], [4, 5, 6], [8])))
    assert(product([1, 2, 3], [4, 5, 6], [8]) == [(1, 4, 8), (1, 5, 8), (1, 6, 8), (2, 4, 8), (2, 5, 8), (2, 6, 8), (3, 4, 8), (3, 5, 8), (3, 6, 8)])

if __name__ == '__main__':
    # test_case_0()
    test_product()

# Generated at 2022-06-26 09:22:00.711498
# Unit test for function product
def test_product():
    for int_3 in range(1):
        for int_4 in range(2):
            for int_5 in range(2):
                int_5
                yield int_5
