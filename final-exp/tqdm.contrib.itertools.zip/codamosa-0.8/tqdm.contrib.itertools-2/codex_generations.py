

# Generated at 2022-06-12 14:27:07.095911
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import numpy as np
    assert list(product(xrange(3), repeat=2)) == \
        [(i, j) for i in range(3) for j in range(3)]
    assert list(product(*[xrange(3)] * 2)) == \
        [(i, j) for i in range(3) for j in range(3)]
    assert list(product(*[xrange(3)] * 3)) == \
        [(i, j, k) for i in range(3) for j in range(3) for k in range(3)]
    assert list(product()) == [()]
    assert list(product([0], [0], [0])) == [(0, 0, 0)]
    assert list(product([0])) == [(0,)]

# Generated at 2022-06-12 14:27:16.727957
# Unit test for function product

# Generated at 2022-06-12 14:27:25.314205
# Unit test for function product
def test_product():
    from ..utils import truncate_dict

    assert list(product([], [], [], [], tqdm_class=tqdm_auto)) == []
    assert list(product([1], [], [], [], tqdm_class=tqdm_auto)) == []
    assert list(product([1], [2], [], [], tqdm_class=tqdm_auto)) == []
    assert list(product([1], [2], [3], [], tqdm_class=tqdm_auto)) == []
    assert list(product([1], [2], [3], [4], tqdm_class=tqdm_auto)) == []

    assert list(product([], [], [3], [4], tqdm_class=tqdm_auto)) == []

# Generated at 2022-06-12 14:27:35.272711
# Unit test for function product
def test_product():
    import numpy as np

    def product(*iterables, **kwds):
        # product('ABCD', 'xy') --> Ax Ay Bx By Cx Cy Dx Dy
        # product(range(2), repeat=3) --> 000 001 010 011 100 101 110 111
        pools = map(tuple, iterables) * kwds.get('repeat', 1)
        result = [[]]
        for pool in pools:
            result = [x+[y] for x in result for y in pool]
        for prod in result:
            yield tuple(prod)

    N = 100
    limit = 2**(N+1)
    for r in range(1, N+1):
        for _ in range(100):
            ar = np.random.randint(0, limit, size=r)

# Generated at 2022-06-12 14:27:41.623062
# Unit test for function product

# Generated at 2022-06-12 14:27:51.542828
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from collections import deque
    from random import randint
    from sys import version_info
    from ..utils import SimpleNamespace
    from ..utils import _range

    def rand_iter(n):
        """Randomly yield numbers from [0, n)"""
        while True:
            yield randint(0, n)

    # Test basic functionality
    gen = product(_range(5), _range(3), _range(4))
    assert set(gen) == {(i, j, k)
                        for i in _range(5) for j in _range(3) for k in _range(4)}

    # Test with None total
    gen = product(rand_iter(1000))

# Generated at 2022-06-12 14:27:55.774806
# Unit test for function product
def test_product():
    """Test for function product"""
    iterable1 = "ab"
    iterable2 = range(3)
    assert list(product(iterable1, iterable2)) == [
        ("a", 0), ("a", 1), ("a", 2),
        ("b", 0), ("b", 1), ("b", 2)
    ]

# Generated at 2022-06-12 14:28:03.411524
# Unit test for function product
def test_product():
    """
    Unit test with:
    `python -m tqdm.contrib.itertools --test_product`
    """
    from ..utils import _decode_preferred_encoding

    def listify(gen):
        return list(gen)

    list_ = listify(product(range(4), repeat=4))
    assert len(list_) == 4**4
    assert list_[0] == (0, 0, 0, 0)

    str_ = listify(product(['ab', 'cd'], repeat=3))
    assert len(str_) == 2**3
    assert str_[0] == ('a', 'c', 'a')
    assert str_[-1] == ('b', 'd', 'd')
    assert str_[7] == ('b', 'c', 'b')



# Generated at 2022-06-12 14:28:12.036950
# Unit test for function product
def test_product():
    assert list(product([1, 2], repeat=0)) == [()]
    assert list(product([1, 2], repeat=1)) == [(1,), (2,)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-12 14:28:18.926065
# Unit test for function product
def test_product():
    ''' Test product function '''
    from .utils import TestCase, closing
    from .utils import get_empty_bar, get_bar

    class TestProduct(TestCase):
        """ Test Product (should be the same as itertools.product) """
        def test_product(self):
            """ Test itertools.product """
            with closing(get_bar()) as pbar:
                self.assertEqual(list(itertools.product(pbar, range(5))),
                                 list(product(pbar, range(5))))

        def test_product_empty(self):
            """ Test itertools.product (empty iterator) """
            with closing(get_empty_bar()) as pbar:
                for _ in product(pbar, range(5)):
                    self.fail("No Iteration should occur")

   

# Generated at 2022-06-12 14:28:29.527861
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .utils import closing, silence_stderr

    with closing(TestCase()) as tc:
        with silence_stderr(tc):
            for _ in tqdm(range(10), total=10, desc='A'):
                for _ in product(["a", "b", "c", "d"], ["1", "2", "3", "4"],
                                 tqdm_class=tqdm, desc="B"):
                    sleep(1e-5)
            tc.assertFalse(tc.cleanup())

# Generated at 2022-06-12 14:28:38.554087
# Unit test for function product
def test_product():
    from ..utils import FormatWidgets
    import numpy as np
    for i, p in tqdm_auto(enumerate(product(
            range(10), range(10),
            tqdm_class=tqdm_auto,
            desc='my product',
            leave=False,
            postfix=dict(
                a=1, b=2, c=3)))):
        if i == 17:
            break
        assert p == (i // 10, i % 10)
    assert i == 17

# Generated at 2022-06-12 14:28:39.652219
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    list(product(range(i), i=1000))

# Generated at 2022-06-12 14:28:43.385767
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .utils import FakeTqdmFile
    f = FakeTqdmFile()
    for _ in product(range(1000), range(2000),
                     tqdm_class=tqdm_auto, file=f, ascii=True,
                     disable=False, miniters=100, mininterval=0.1,
                     smoothing=0.1):
        pass
    assert f.getvalue() == b'0%|          | 0/2000000000 [00:00<?, ?it/s]\r'



# Generated at 2022-06-12 14:28:49.587845
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal
    from .utils import closing, FakeTqdmFile

    list1 = list(range(9))
    list2 = list("abc")
    list3 = list("XYZ")

    with closing(FakeTqdmFile()) as f:
        res1 = list(product(list1, list2, list3))
        res2 = list(itertools.product(list1, list2, list3))
        assert_array_equal(res1, res2)

    with closing(FakeTqdmFile()) as f:
        res1 = list(product(list1, list2, list3, tqdm_class=tqdm_auto))
        res2 = list(itertools.product(list1, list2, list3))

# Generated at 2022-06-12 14:28:59.699430
# Unit test for function product
def test_product():
    """Tests product()"""
    # Simple implementation of function 'matrix'
    def matrix(*argv):
        """It makes a matrix (a list of lists)."""
        return [list(arg) for arg in list(argv)]

    # Create 2 iterables
    i1 = range(5)
    i2 = [['a', 'b'], ['c', 'd']]

    # Create 2 matrices from iterables
    m1 = matrix(i1)
    m2 = matrix(i1, i2)

    # The expected results

# Generated at 2022-06-12 14:29:06.226352
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal as assert_ae
    from six.moves import range as xrange
    from ..utils import FakeTqdmFile
    from ..std import format_interval

    def _product(*iterables, **tqdm_kwargs):
        r = []
        for i in product(*iterables, **tqdm_kwargs):
            r.append(i)
        return r

    assert_ae(_product(range(3), range(3), range(3)),
              list(itertools.product(range(3), range(3), range(3))))
    assert_ae(_product(range(3), range(3), range(3), tqdm_class=None),
              list(itertools.product(range(3), range(3), range(3))))

# Generated at 2022-06-12 14:29:16.169566
# Unit test for function product
def test_product():
    """
    test_range
    """
    import sys
    import subprocess

    if sys.version_info[:2] < (3, 5):
        args = [sys.executable, '-u', '-m', 'tqdm.tests.test_product']
        subprocess.check_call(args)
    else:
        from unittest import TestCase, main
        import numpy as np
        import multiprocessing as mp
        try:
            from contextlib import ExitStack
        except ImportError:
            from contextlib2 import ExitStack

        from tqdm.tests.common import with_setup, temporary_file


        class TestProduct(TestCase):
            """Test product() using :func:`unittest.TestCase.assertAlmostEqual`"""

# Generated at 2022-06-12 14:29:17.956084
# Unit test for function product
def test_product():
    assert list(product(range(3), range(3), range(3))) == list(
        itertools.product(range(3), range(3), range(3)))



# Generated at 2022-06-12 14:29:22.223871
# Unit test for function product
def test_product():
    assert list(product((1, 2), repeat=3)) == [
        (1, 1, 1),
        (1, 1, 2),
        (1, 2, 1),
        (1, 2, 2),
        (2, 1, 1),
        (2, 1, 2),
        (2, 2, 1),
        (2, 2, 2)]

# Generated at 2022-06-12 14:29:36.092455
# Unit test for function product
def test_product():
    from unittest import TestCase, main
    from copy import copy

    class ProductTest(TestCase):
        """Tests for product."""

        def test_empty(self):
            """Test product."""
            self.assertEqual([], list(product(range(0), repeat=3)))

        def test_identity(self):
            """Test product."""
            self.assertEqual(
                list(range(10)), list(product(range(10), repeat=1)))

        def test_repeat_zero(self):
            """Test product."""
            self.assertEqual([], list(product((), (), (), repeat=0)))

        def test_repeat_None(self):
            """Test product."""
            self.assertEqual([], list(product((), (), (), repeat=None)))


# Generated at 2022-06-12 14:29:39.255744
# Unit test for function product
def test_product():
    for i in product([1, 2, 3], range(4), ["a", "b", "c"],
                     tqdm_class=tqdm_auto,
                     desc="Progress"):
        if i[0] + i[1] * i[2] == "2a2b2c":
            break

# Generated at 2022-06-12 14:29:43.367700
# Unit test for function product
def test_product():
    """Tests the itertools.product wrapper"""
    iterables = ["ABCD", "xy"]
    assert list(product(iterables)) == [
        ('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'), ('C', 'y'),
        ('D', 'x'), ('D', 'y')]



# Generated at 2022-06-12 14:29:52.233992
# Unit test for function product
def test_product():
    """
    Tests ``itertools.product`` function.
    """
    import sys
    import os
    import pkg_resources
    if "tqdm_gui" in sys.modules:
        del sys.modules["tqdm_gui"]
    # Check ``itertools.product`` equivalent
    tqdm = pkg_resources.load_entry_point('tqdm', 'console_scripts', 'tqdm')
    xrange = range if sys.version_info[0] >= 3 else xrange
    for i in product(xrange(10), xrange(5), tqdm_class=tqdm,
                     desc='test', leave=False):
        pass

# Generated at 2022-06-12 14:30:01.001847
# Unit test for function product
def test_product():
    """ Unit test for function product """
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO


    @product
    def product_test():
        """ Test generator """
        for i in range(10):
            yield i


    @product(tqdm_class=tqdm_auto)
    def product_test_no_tqdm():
        """ Test generator """
        for i in range(10):
            yield i


    @product(tqdm_class=tqdm_auto, total=10)
    def product_test_total():
        """ Test generator """
        for i in range(10):
            yield i



# Generated at 2022-06-12 14:30:05.116109
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    import numpy as np
    with tqdm_auto(total=10) as t:
        assert [i for i in product(range(5), range(2), tqdm_class=t.__class__)] == list(itertools.product(range(5), range(2)))
        t.close()
    with tqdm_auto(total=3, file=sys.stderr) as t:
        assert [i for i in product(np.array([1, 2, 3]), range(2), tqdm_class=t.__class__)] == list(itertools.product(np.array([1, 2, 3]), range(2)))
        t.close()

# Generated at 2022-06-12 14:30:05.854407
# Unit test for function product
def test_product():
    it = product(range(4), range(4), tqdm_class=tqdm_auto)
    for x in it:
        pass

# Generated at 2022-06-12 14:30:13.280893
# Unit test for function product
def test_product():
    assert list(product(
        *((i, i) for i in range(5)), total=1 << 5, tqdm_class=tqdm_auto)) == \
        [
            (0, 0), (1, 1), (2, 2), (3, 3), (4, 4),
            (0, 0), (1, 1), (2, 2), (3, 3), (4, 4),
            (0, 0), (1, 1), (2, 2), (3, 3), (4, 4),
            (0, 0), (1, 1), (2, 2), (3, 3), (4, 4),
            (0, 0), (1, 1), (2, 2), (3, 3), (4, 4),
        ]

# Generated at 2022-06-12 14:30:21.630028
# Unit test for function product
def test_product():
    """Test product"""
    res = []
    for i in product(range(2), range(2), range(2), tqdm_class=tqdm_auto):
        res.append(i)
    assert res == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                   (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
    res = []
    for i in product(range(2), range(2), range(2), tqdm_class=None):
        res.append(i)

# Generated at 2022-06-12 14:30:25.928371
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    iterable = product(range(10),
                       "ABCDEF",
                       [1, 2, 3],
                       tqdm_class=None)
    assert list(iterable) == list(itertools.product(range(10),
                                                    "ABCDEF",
                                                    [1, 2, 3]))

# Generated at 2022-06-12 14:30:42.591764
# Unit test for function product
def test_product():
    from glob import glob
    import os
    import sys

    # Create files

# Generated at 2022-06-12 14:30:45.972232
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy.testing import assert_array_equal
    it_1 = randint(0, 10, size=5)
    it_2 = randint(0, 20, size=6)
    it_3 = randint(0, 30, size=7)
    assert_array_equal(
        list(itertools.product(it_1, it_2, it_3)),
        list(product(it_1, it_2, it_3))
    )

# Generated at 2022-06-12 14:30:47.674148
# Unit test for function product
def test_product():
    lst = list(product(range(10), "ab", tqdm_class=tqdm_auto,
                       desc="testing product"))
    assert lst == list(itertools.product(range(10), "ab"))

# Generated at 2022-06-12 14:30:57.123124
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from . import _range

    with patch('sys.stderr', new_callable=lambda: sys.stdout):
        assert list(product(_range(3), repeat=3)) == list(itertools.product(_range(3), repeat=3))
        assert list(product(_range(3))) == list(itertools.product(_range(3)))
        assert list(product(_range(3), "a")) == list(itertools.product(_range(3), "a"))
        assert list(product(_range(2), repeat=2)) == list(itertools.product(_range(2), repeat=2))

# Generated at 2022-06-12 14:30:59.068535
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    from ..tests import run_for_examples
    run_for_examples(product, itertools.product)

# Generated at 2022-06-12 14:31:01.418014
# Unit test for function product
def test_product():
    from itertools import product as itp
    a = range(3)
    for i, j in zip(itp(a, a, a), product(a, a, a)):
        assert i == j


# Generated at 2022-06-12 14:31:06.599235
# Unit test for function product
def test_product():
    """ test """
    with tqdm_auto(unit='i') as t:
        assert list(product(range(5), range(5))) == list(itertools.product(range(5), range(5)))
        t.update(1)
        assert list(product(
            range(5), range(5), tqdm_class=tqdm_auto, unit='i'
        )) == list(itertools.product(range(5), range(5)))
        t.update(1)

# Generated at 2022-06-12 14:31:08.444155
# Unit test for function product
def test_product():
    """
    Unit test for `product`.
    """
    # TODO

# Generated at 2022-06-12 14:31:16.801159
# Unit test for function product
def test_product():
    from .tqdm_test_cases import tqdm_guru

    # Test list
    with tqdm_guru(total=4) as t:
        for i in product(range(10), range(10)):
            t.update()

    # Test generator
    with tqdm_guru(total=4) as t:
        for i in product(range(10), (x**2 for x in range(10))):
            t.update()

    # Test total override
    with tqdm_guru(total=8) as t:
        for i in product(range(10), (x**2 for x in range(10)), total=8):
            t.update()

    # Test no total

# Generated at 2022-06-12 14:31:23.859281
# Unit test for function product
def test_product():
    import sys
    import numpy as np
    from itertools import product as itertools_product
    d = [1, 2, 3, 4, 5]
    assert list(product(d, ["hello", "world"])) == list(itertools_product(d, ["hello", "world"]))
    with tqdm_auto(total=5 * 2) as t:
        # assert list(product(d, ["hello", "world"], tqdm_kwargs=dict(tqdm_class=tqdm_auto))) == list(itertools_product(d, ["hello", "world"]))
        for x in product(d, ["hello", "world"], tqdm_class=tqdm_auto):
            assert x in itertools_product(d, ["hello", "world"])

# Generated at 2022-06-12 14:31:49.375296
# Unit test for function product
def test_product():
    """
    Test function `itertools.product`
    """
    from pytest import approx
    import numpy as np

    # Test against the base function
    assert tuple(product(range(10), range(10))) == tuple(itertools.product(range(10), range(10)))

    # Test if progress bar is actually considered
    def test_total(l):
        """
        Test `total` parameter of the progress bar.
        """
        for _ in product(range(10), range(20), range(30),
                         tqdm_class=tqdm_auto, total=l):
            pass

    for l in (-10, 0, 100):
        test_total(l)  # should not raise exception

# Generated at 2022-06-12 14:31:56.972959
# Unit test for function product
def test_product():
    '''
    Python 2.7.6 doesn't have assertWarns, so it is this bit of hackery
    '''

    def assert_warning(func, warning, tb_locals):
        import warnings
        with warnings.catch_warnings(record=True) as warn:
            warnings.simplefilter('always')
            func()
            assert len(warn) == 1, "Warning not triggered"
            assert str(warn[0].message) == warning, \
                "Expected warning does not match actual warning"

    from .bar import BarBase
    from .trange import trange

    class MockT(BarBase):
        def update(*args, **kwargs):  # pylint: disable=arguments-differ,unused-argument
            pass
        close = update


# Generated at 2022-06-12 14:32:01.361076
# Unit test for function product
def test_product():
    """Test product() function"""
    from ..nested import tqdm

    # decimal to binary
    assert ''.join(str(i) for i in product(range(2), repeat=3)) == '00010111'
    # multiplication table
    assert ''.join(str(i[0] * i[1]) for i in product(range(3), repeat=2)) == '01234561'

    assert ''.join(str(i) for i in product(range(3), repeat=3, tqdm_class=None)) == '00010111'
    assert ''.join(str(i) for i in product(range(3), repeat=3, tqdm_class=tqdm)) == '00010111'

# Generated at 2022-06-12 14:32:06.614839
# Unit test for function product
def test_product():
    from . import _range

    # test case 1
    assert list(product(_range(4))) == [
        (0, ), (1, ), (2, ), (3, )]
    assert list(product(_range(4), repeat=2)) == [
        (0, 0), (0, 1), (0, 2), (0, 3),
        (1, 0), (1, 1), (1, 2), (1, 3),
        (2, 0), (2, 1), (2, 2), (2, 3),
        (3, 0), (3, 1), (3, 2), (3, 3)]

# Generated at 2022-06-12 14:32:13.108588
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range

    @with_setup(pretest=lambda: None, posttest=lambda: None)
    def inner_test_product():
        # Test aliases
        assert product('abc', repeat=3) == product(range(3), repeat=3)
        assert (product('abc', repeat=3) ==
                list(product((0, 1, 2), repeat=3)))
        assert (list(product('abc', repeat=3)) ==
                list(itertools.product('abc', repeat=3)))

        # Test .total
        list(product('abc', repeat=3, tqdm_class=tqdm_auto))
        assert hasattr(tqdm_auto.default_mininterval, '__call__')

        # Ensure 'leave' is not applied on zero-length

# Generated at 2022-06-12 14:32:19.516660
# Unit test for function product
def test_product():
    """Simple test for product()"""
    cls = tqdm_auto
    assert list(product([1, 2], [3, 4], tqdm_class=cls)) == list(itertools.product([1, 2], [3, 4]))
    x = list(product([1, 2], [3, 4], tqdm_class=cls))
    assert len(x) == 4
    x = list(product([1, 2], [3, 4], repeat=2, tqdm_class=cls))
    assert len(x) == 16

# Generated at 2022-06-12 14:32:22.312411
# Unit test for function product
def test_product():
    itr = product('ABCD', 'xy', tqdm_class=tqdm_auto)
    # Depends on Python version, so just check the length:
    assert len(list(itr)) == 8

# Generated at 2022-06-12 14:32:26.063778
# Unit test for function product
def test_product():
    """Test product method"""
    # Make sure tqdm is being imported
    assert 'tqdm' in globals()
    with tqdm.tqdm(total=50) as t:
        for i in product(xrange(10), xrange(10)):
            t.update()
    assert t.total == 50

# Generated at 2022-06-12 14:32:33.760446
# Unit test for function product
def test_product():
    """
    Test function product() with the following examples:

    1. Simple
    2. With tqdm arguments: tqdm_class, desc, ascii, total
    3. Product with product
    4. Product of three lists
    """
    from ..auto import tqdm

    # 1. Simple
    for _ in product(range(5)):
        pass

    # 2. With tqdm arguments: tqdm_class, desc, ascii, total
    for _ in product(range(5), tqdm_class=tqdm, desc="Test product"):
        pass

    # 3. Product with product
    for _ in product(product(range(5), range(5)), range(5)):
        pass

    # 4. Product of three lists

# Generated at 2022-06-12 14:32:39.855632
# Unit test for function product
def test_product():
    for i in product([1, 2, 3], [4, 5, 6]):
        assert len(i) == 2
        assert i[0] in [1, 2, 3]
        assert i[1] in [4, 5, 6]
    for i in product([1, 2, 3], [4, 5, 6], tqdm_class=None):
        assert len(i) == 2
        assert i[0] in [1, 2, 3]
        assert i[1] in [4, 5, 6]

# Generated at 2022-06-12 14:33:41.641932
# Unit test for function product
def test_product():
    """Test function product()"""
    import numpy as np
    a = np.arange(5)
    b = np.arange(3)
    c = np.arange(3)
    d = np.arange(7)
    e = np.arange(1)
    for x in product(a, b, c):
        pass
    for x in product(a, b, c, d):
        pass
    for x in product(a, b, c, d, e):
        pass
    for x in product(a, b):
        pass
    for x in product(a, b, c, d, e):
        pass

# Generated at 2022-06-12 14:33:50.696596
# Unit test for function product
def test_product():
    from ..auto import tqdm
    list(tqdm.product(range(100), range(100), range(100),
                      miniters=1, tqdm_class=tqdm.tqdm))
    with tqdm.tqdm(total=10, mininterval=0) as t:
        for i in tqdm.product(range(100), range(100), range(100),
                              tqdm_class=tqdm.tqdm):
            t.update()
    try:
        list(tqdm.product(range(100), range(100), range(100),
                          miniters=1, tqdm_class=tqdm_auto))
    except TypeError:
        pass
    else:
        raise ValueError("miniters should break autodetect product")

# Generated at 2022-06-12 14:33:56.225230
# Unit test for function product
def test_product():
    """Test prod_range() function."""
    from numpy.testing import assert_allclose
    import numpy as np

    ns = np.array([99, 99, 99])
    prod = list(product(range(i) for i in ns))
    assert_allclose(np.array(prod), np.mgrid[:ns[0], :ns[1], :ns[2]].reshape(3, -1).transpose())

    ns = np.array([3, 3, 3, 3])
    prod = list(product(range(i) for i in ns))
    assert_allclose(np.array(prod), np.mgrid[:ns[0], :ns[1], :ns[2], :ns[3]].reshape(4, -1).transpose())

# Generated at 2022-06-12 14:33:59.857850
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy import prod
    from random import shuffle
    iterables = [list(range(i)) for i in randint(1, 10, size=randint(1, 10))]
    shuffle(iterables)
    assert prod(map(len, iterables)) == len(list(product(*iterables)))
    assert prod(map(len, iterables)) == len(list(product(*iterables,
                                                         tqdm_class=None)))

# Generated at 2022-06-12 14:34:03.153598
# Unit test for function product
def test_product():
    """Test for function product"""
    iter1 = [1, 2, 3]
    iter2 = [4, 5, 6]
    result = list(product(iter1, iter2))
    assert result == [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6),
                      (3, 4), (3, 5), (3, 6)]

# Generated at 2022-06-12 14:34:13.061596
# Unit test for function product
def test_product():
    import numpy as np
    before = [[i] for i in range(10)]
    after = list(product(before))
    assert after[0] == [0]
    assert after[-1] == [9]
    for i in after:
        assert (type(i) is list)
    assert len(after) == 10

    before = [[i], [i * 1j]]
    after = list(product(before))
    assert len(after) == 10
    for i in after:
        assert len(i) == 2
        assert np.all(np.asarray(i) == np.asarray([i, i * 1j]))
        assert (type(i) is list)

    before = [[i], [i * 1j], [i * 1j + 1]]
    after = list(product(before))


# Generated at 2022-06-12 14:34:16.983826
# Unit test for function product
def test_product():
    for n in range(4):
        assert list(product(range(i) for i in range(1, n + 2))) == \
            list(itertools.product(*(range(i) for i in range(1, n + 2))))

# Generated at 2022-06-12 14:34:23.559315
# Unit test for function product
def test_product():
    """Test product()"""
    from ..tests.common import BaseTestMixin, closing

    class Test(BaseTestMixin):
        def test_product(self):
            from sys import version_info
            with closing(tqdm_auto(total=sum((i for i in range(5))))) \
                    as pbar:
                for i in product("1234", repeat=2,
                                 tqdm_class=pbar.__class__):
                    pbar.update()
                if version_info[0] == 3:
                    self.assertEqual(pbar.n, 16)
            self.output_option_original()

# Generated at 2022-06-12 14:34:27.229981
# Unit test for function product
def test_product():
    """
    Unit test for function product,
    if called directly.
    """
    iterables = [range(i) for i in range(1, 7)]
    it = product(*iterables, tqdm_class=tqdm_auto)
    count = 0
    for i in it:
        count += 1
    assert count == sum(map(len, iterables))

# Generated at 2022-06-12 14:34:31.243844
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    assert list(product(range(10000))) == list(itertools.product(range(10000)))
    assert list(product(range(10000))) == list(tqdm_auto(
        itertools.product(range(10000)), total=10000))
    assert list(product(range(10000))) == list(tqdm_auto(
        itertools.product(range(10000)), total=10000))


if __name__ == "__main__":
    test_product()