

# Generated at 2022-06-12 14:26:56.295636
# Unit test for function product
def test_product():
    iterables = [[1, 2], [1, 2, 3, 4], [1, 2, 3]]
    t = 0
    for i in product(*iterables):
        t += 1
    assert t == 24

# Generated at 2022-06-12 14:27:04.189745
# Unit test for function product
def test_product():
    import sys
    from .tests import tolerance_check
    with tqdm_auto(miniters=1) as t:
        for i in product(range(1), range(1), tqdm=t):
            pass
    assert t.n == 1 and t.total == 1
    with tqdm_auto(miniters=1) as t:
        for i in product(range(3), range(3), tqdm=t):
            pass
    assert t.n == 9 and t.total == 9
    with tqdm_auto(miniters=1) as t:
        for i in product(range(3), range(3), range(3), tqdm=t):
            pass
    assert t.n == 27 and t.total == 27

# Generated at 2022-06-12 14:27:14.114605
# Unit test for function product
def test_product():
    from operator import mul
    from functools import reduce

    def fac(n):
        return reduce(mul, range(1, n + 1), 1)

    def product_from_range():
        for (m, n) in [
                (0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2),
                (2, 0), (2, 1), (2, 2)
        ]:
            p = [list(range(i)) for i in range(m, n + 1)]
            return p, list(product(*p))


# Generated at 2022-06-12 14:27:16.938460
# Unit test for function product
def test_product():
    import numpy as np
    assert np.all(np.array(list(product(np.arange(10), np.arange(10)))) == np.indices((10, 10)).reshape(2, -1).T)

# Generated at 2022-06-12 14:27:25.573224
# Unit test for function product
def test_product():
    """
    """
    import itertools
    import nose.tools as nt
    import numpy as np
    import tqdm as tqdm_module

    # create iterable
    iterable = list(
        itertools.product(range(3), repeat=3))

    # function 1
    def func_1():
        """
        """
        res = []
        for i in tqdm_module.product(range(3), range(3), range(3)):
            res.append(i)
        # minitest
        nt.assert_equal(res, iterable)

    # function 2
    def func_2():
        """
        """
        res = [i for i in tqdm_module.product(
            range(3), range(3), range(3))]
        # min

# Generated at 2022-06-12 14:27:34.705056
# Unit test for function product
def test_product():
    with tqdm_auto(total=10) as t:
        result = [i for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                                     leave=False)]
    assert result == list(itertools.product(range(10), range(10)))
    assert t.n == t.total == 100
    with tqdm_auto(total=None) as t:
        result = [i for i in
                  product(range(10), range(10), tqdm_class=tqdm_auto,
                          leave=False, total=None)]
    assert result == list(itertools.product(range(10), range(10)))
    assert t.n == t.total is None

# Generated at 2022-06-12 14:27:42.427472
# Unit test for function product
def test_product():
    from copy import copy

    def eq(a, b):
        return list(a) == list(b)

    assert eq(product('ABCD', repeat=2),
              itertools.product('ABCD', repeat=2))
    assert eq(product('ABCD', 'xy'),
              itertools.product('ABCD', 'xy'))
    assert eq(product(range(2), repeat=3),
              itertools.product(range(2), repeat=3))
    assert eq(product(A=range(2), repeat=3),
              itertools.product(A=range(2), repeat=3))
    assert eq(product('ABCD', 'wxyz', tqdm_class=None),
              itertools.product('ABCD', 'wxyz'))


# Generated at 2022-06-12 14:27:52.987750
# Unit test for function product
def test_product():
    """
    Simple unit test for function product.
    """
    import tempfile
    import os
    import sys
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    old_path = os.getcwd()
    os.chdir(tmpdir)

    # Create test files
    if not os.path.exists('test_product_output.txt'):
        with open('test_product_output.txt', 'w') as f:
            for i in product(range(3), tqdm_class=tqdm_auto, desc="test_product"):
                f.write("\n{}".format(i))
                f.flush()  # ensure that tqdm is written to file at each iteration

    # Assertions

# Generated at 2022-06-12 14:28:01.560642
# Unit test for function product
def test_product():
    """
    Test for `product`.
    """
    from numpy.testing import assert_array_equal
    from ._tqdm import tqdm

    assert_array_equal(
        [r for r in product(range(2), range(2), range(2), tqdm_class=tqdm)],
        [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
         (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)])

# Generated at 2022-06-12 14:28:04.401577
# Unit test for function product
def test_product():
    import sys
    for i, j in product(["a", "b", "c", "d"], [1, 2, 3], tqdm_class=tqdm_auto):
        sys.stderr.write(str(i) + str(j))

# Generated at 2022-06-12 14:28:09.987413
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    return list(itertools.product([1, 2], [1, 3])), \
        list(product([1, 2], [1, 3]))
    assert test_product()[0] == test_product()[1]

# Generated at 2022-06-12 14:28:11.933046
# Unit test for function product
def test_product():
    assert list(product(range(10), repeat=2)) == list(itertools.product(range(10), repeat=2))

# Generated at 2022-06-12 14:28:18.817799
# Unit test for function product
def test_product():
    """Test for `product`"""
    from collections import Counter
    res = product(range(i) for i in range(1, 6))
    assert Counter(res) == Counter((1, 1, 1, 1, 1))
    res = product(range(i) for i in range(1, 6))
    assert Counter(res) == Counter((1, 1, 1, 1, 1))

# Generated at 2022-06-12 14:28:28.360169
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm

    try:
        from itertools import product as iproduct
    except ImportError:
        return None

    for t in [tqdm, tqdm_gui]:
        for n, i in zip(range(10), iproduct('abcde', repeat=4)):
            assert n == sum(1 for _ in product('abcde', repeat=4,
                                               tqdm_class=t)) - 1
            assert i == next(product('abcde', repeat=4, tqdm_class=t))
        assert n + 1 == sum(1 for _ in product('abcde', repeat=4,
                                               tqdm_class=t))

# Generated at 2022-06-12 14:28:37.117811
# Unit test for function product
def test_product():
    """
    Unit test of product()
    """
    import numpy as np
    from ..utils import format_sizeof

    iterable = (range(100), range(100))
    for _ in product(*iterable, desc="Testing product(...)", ascii=True):
        pass
    for _ in product(*iterable, desc="Testing product(...)", ascii=True,
                     disable=True):
        pass
    for _ in product(*iterable, desc="Testing product(...)", ascii=True,
                     mininterval=0.5):
        pass
    rng = np.random.RandomState(0)
    iterable = (rng.randn(100) for _ in range(4))

# Generated at 2022-06-12 14:28:44.389829
# Unit test for function product
def test_product():

    # Unit tests for itertools.product
    test_lists = [[1, 2, 3], [4, 5, 6]]
    assert list(itertools.product(*test_lists)) == [(1, 4), (1, 5), (1, 6),
             (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]
    # Test (int, int, int) product
    test_lists = [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-12 14:28:54.835993
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .._utils import FormatCustomText

# Generated at 2022-06-12 14:29:00.508112
# Unit test for function product
def test_product():
    from .autonotebook import tqdm

    for i in tqdm([1], tqdm.itertools.product, ([1,2], [3,4]), [5,6],
                                                tqdm_class=tqdm,
                                                ascii=True,
                                                total=4,
                                                leave=True,
                                                ncols=100,
                                                mininterval=.5):
        print(i)

# Generated at 2022-06-12 14:29:05.053088
# Unit test for function product
def test_product():
    from ._utils import _test_iterator_equivalence
    for args in [(([1],)),
                 (([1, 2, 3],)),
                 (([1, 2, 3], [4, 5, 6])),
                 (([1, 2], [4, 5], [7, 8]))]:
        yield _test_iterator_equivalence, product, args
        yield _test_iterator_equivalence, product, args, {
            "tqdm_class": lambda x: tqdm_auto(x, disable=True)}

# Generated at 2022-06-12 14:29:14.741651
# Unit test for function product
def test_product():
    from pytest import approx

    p = list(product(*[[0, 1]] * 2, tqdm_class=tqdm_auto))
    assert p == [(0, 0), (0, 1), (1, 0), (1, 1)]
    p = list(product(*[[0, 1]] * 3, tqdm_class=tqdm_auto))
    assert p == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                 (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
    p = product(*[[0, 1]] * 4, tqdm_class=tqdm_auto)
    assert next(p) == (0, 0, 0, 0)

# Generated at 2022-06-12 14:29:21.635588
# Unit test for function product
def test_product():
    ''' Unit test for function product '''
    L = list(range(20))
    P = list(product(L, L, L, L, L, L))
    assert len(P) == 20**6

# Generated at 2022-06-12 14:29:29.308443
# Unit test for function product
def test_product():
    from test_tqdm import with_setup, pretest, posttest, _range

    with_setup(pretest, posttest)

    list(product(_range(100)))

    list(product(_range(100), tqdm=tqdm_gui))

    list(product(
        _range(1, 10),
        _range(1, 10),
        _range(1, 10),
        _range(1, 10),
        _range(1, 10),
        _range(1, 10),
        _range(1, 10),
        _range(1, 10)))


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-12 14:29:37.316486
# Unit test for function product
def test_product():
    """Test for function `product`."""
    from numpy.testing import assert_equal

    for n in range(3):
        for A in range(3):
            for B in range(3):
                for C in range(3):
                    aa = range(A)
                    bb = range(B)
                    cc = range(C)
                    assert_equal(
                        list(itertools.product(aa, bb, cc)),
                        list(product(aa, bb, cc, tqdm_class=None, total=None)))
                    assert_equal(
                        list(itertools.product(aa, bb, cc)),
                        list(product(aa, bb, cc, tqdm_class=None,
                                     total=A * B * C)))

# Generated at 2022-06-12 14:29:45.145717
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import time
    from numpy.random import randint

    N = 9
    M = 100

    # Start a timer
    start_time = time.time()

    # Generate data list
    data = [[randint(0, M) for _ in range(randint(0, M))]
            for _ in range(N)]

    # Print out all the permutations
    for i in itertools.product(*data):
        pass

    # Calculate the execution time
    end_time = time.time()
    exec_time = end_time - start_time

    # Start a timer
    start_time = time.time()

    # Print out all the permutations
    for i in product(*data):
        pass

    # Calculate the execution time
    end_

# Generated at 2022-06-12 14:29:54.199572
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range, StringIO, closing
    from .utils import FormatCustomTest
    from .tests_tqdm import pretest_posttest

    @with_setup(pretest_posttest)
    def test():
        for out_c, in_c in [
            (None, None),
            (None, StringIO()),
            (StringIO(), None),
            (StringIO(), StringIO()),
            ]:
            with closing(out_c) as out:
                for _ in tqdm_auto(product(_range(100), _range(100),
                                           _range(100),
                                           tqdm_class=FormatCustomTest,
                                           file=in_c,
                                           )):
                    pass
                # Test of in-loop closing
               

# Generated at 2022-06-12 14:30:02.703418
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tqdm import trange
    from .utils import format_sizeof as sizeof
    import time

    it1 = list(range(3))
    it2 = list(range(4))
    it3 = list(range(3))
    it = product(it1, it2, it3)
    assert len(list(it)) == len(it1) * len(it2) * len(it3)
    assert list(it) == list(itertools.product(it1, it2, it3))

    it1 = list(range(1))
    it2 = list(range(4))
    it3 = list(range(3))
    it = product(it1, it2, it3)

# Generated at 2022-06-12 14:30:11.441807
# Unit test for function product
def test_product():
    """
    Test tqdm.product() with different types of iterables.

    We test that:
    - the number of loops is correct
    - the output is correct

    Returns
    -------
    out : bool
        True: if test passed.
        False: if test failed.
    """

    def sum_product(it_lens, product_len):
        # Compute the total number of loops for the product
        # for the given iterables' lengths.
        if product_len is None:
            # There is an iterable that is not sliceable
            return None
        total = 1
        for i in it_lens:
            #print("sum_product: i=%s" % i)
            total *= i
        return total


# Generated at 2022-06-12 14:30:15.328552
# Unit test for function product
def test_product():
    from .tqdm_test_cases import tqdm_test_cases
    test_cases = tqdm_test_cases()

    for t in test_cases:
        for desc in t.descs:
            if t.unit_scale:
                rng = range(5)
            else:
                rng = tqdm_auto._range(0, 5)

            a = list(tqdm_auto(rng, desc=desc, **t.kwargs))
            b = list(product(rng, desc=desc, **t.kwargs))
            assert a == b

# Generated at 2022-06-12 14:30:23.220129
# Unit test for function product
def test_product():
    """Test the module `tqdm.std.itertools`"""
    from .tests_tqdm import with_setup, pretest

    @with_setup(pretest)
    def wrapper():
        """Run module `tqdm.std.itertools` unit test"""
        from numpy import array_equal
        from random import random as r

        class A(object):
            def __init__(self, l):
                self.l = l

            def __len__(self):
                return self.l

        exp = list(itertools.product(range(10), repeat=2))
        assert array_equal(exp, list(product(range(10), repeat=2)))
        assert array_equal(exp, list(product(*[range(10) for _ in range(2)])))

# Generated at 2022-06-12 14:30:26.565553
# Unit test for function product
def test_product():
    from ..utils import FormatMixin

    class Dummy(FormatMixin):
        format_dict = {'counter': '{n}'}

    with Dummy() as d:
        for x in product(range(5), (1, 2), total=12):
            assert x

    assert d.format_dict['counter'] == "12"

# Generated at 2022-06-12 14:30:42.053579
# Unit test for function product
def test_product():
    """Test function `product`."""
    assert list(product(range(10), repeat=2)) == list(itertools.product(range(10), repeat=2))
    assert list(product(range(10), repeat=3)) == list(itertools.product(range(10), repeat=3))
    assert list(product(range(2), repeat=3)) == list(itertools.product(range(2), repeat=3))
    assert list(product(range(10))) == list(itertools.product(range(10)))
    assert list(product(range(10), range(10))) == list(itertools.product(range(10), range(10)))

# Generated at 2022-06-12 14:30:46.538900
# Unit test for function product
def test_product():
    from numpy import prod
    from numpy.random import randint, random
    for sz in [1, 10, 100, 1000]:
        for n in [2, 3, 4, 5]:
            x = [randint(-5, 5, sz) for _ in range(n)]
            y = list(product(*x, total=prod([len(a) for a in x])))
            assert len(y) == prod([len(a) for a in x])
            y = list(product(*x, tqdm_class=tqdm_auto))
            assert len(y) == prod([len(a) for a in x])

# Generated at 2022-06-12 14:30:53.346327
# Unit test for function product
def test_product():
    for i in product(range(10), range(10)):
        assert len(i) == 2
        assert (i[0] >= 0) and (i[0] < 10)
        assert (i[1] >= 0) and (i[1] < 10)
    for i in product(range(10), range(10), tqdm_class=None):
        assert len(i) == 2
        assert (i[0] >= 0) and (i[0] < 10)
        assert (i[1] >= 0) and (i[1] < 10)

# Generated at 2022-06-12 14:30:55.345802
# Unit test for function product
def test_product():
    for x in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:31:01.015309
# Unit test for function product
def test_product():
    from ..utils import freeze_support
    from .std import tqdm_stdout

    with tqdm_stdout(miniters=0):
        for _ in product(range(10), range(10), tqdm_class=tqdm_stdout):
            pass

    freeze_support()
    for _ in product(range(10), range(10), tqdm_class=tqdm_stdout):
        pass

    with tqdm_stdout(total=10):
        for _ in product(range(10), range(10), tqdm_class=tqdm_stdout):
            pass

# Generated at 2022-06-12 14:31:02.542627
# Unit test for function product
def test_product():
    from ..tests import test_itertools_product
    test_itertools_product(product)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:31:05.281576
# Unit test for function product
def test_product():
    from random import randint
    from six.moves import range
    for _ in range(10):
        l = randint(0, 20)
        ll = [randint(0, 5) for _ in range(l)]
        p1 = list(itertools.product(*map(range, ll)))
        p2 = list(product(*map(range, ll)))
        assert p1 == p2

# Generated at 2022-06-12 14:31:11.011167
# Unit test for function product
def test_product():
    import numpy as np
    a = np.arange(1000).reshape((10, 100))
    b = np.arange(1000, 2000).reshape((10, 100))
    c = []
    for i in tqdm.product(a, b):
        c.append(i)
    assert c == list(itertools.product(a, b))

# Generated at 2022-06-12 14:31:18.631082
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import random
    import warnings

    with warnings.catch_warnings(record=True):
        with tqdm_auto() as t:
            for _ in product(range(3), range(3), range(3),
                             tqdm_class=tqdm_auto):
                pass
    assert t.n == 27
    with warnings.catch_warnings(record=True):
        with tqdm_auto() as t:
            for _ in product(range(3), range(3), range(3),
                             tqdm_class=tqdm_auto, total=10):
                pass
    assert t.n == 10


# Generated at 2022-06-12 14:31:19.340826
# Unit test for function product
def test_product():
    """Empty test to satisfy nose."""
    pass

# Generated at 2022-06-12 14:31:46.762998
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product("AB", "12")) == [("A", "1"), ("A", "2"),
                                         ("B", "1"), ("B", "2")]

# Generated at 2022-06-12 14:31:53.993680
# Unit test for function product
def test_product():
    """
    Unit test spining off a `tqdm.tqdm` instance instead of the original
    `itertools.product`, but without stopping it. It acts as a performance
    test.
    """
    import time
    import operator
    import itertools as it
    from ..utils import FormatCustomText as Format
    from .auto import tqdm as tqdm_base

    # Initialise class with defaults
    tqdm_base.format_dict["test_product"].set_postfix("test_product")
    tqdm_base.format_dict["test_product"].format_interval = 1
    tqdm_base.format_dict["test_product"].format_metric = "s"

# Generated at 2022-06-12 14:32:00.359520
# Unit test for function product
def test_product():
    from ..utils import _range
    from string import ascii_letters
    actual = list()
    for p in product(ascii_letters, _range(4)):
        actual.append(p)

# Generated at 2022-06-12 14:32:02.972856
# Unit test for function product
def test_product():
    import random
    from .tqdm import trange

    for i in trange(1000, desc='product(range(600), range(600))'):
        p1 = list(itertools.product(range(600), range(600)))

# Generated at 2022-06-12 14:32:10.235064
# Unit test for function product
def test_product():
    """
    Simple unit test for `product`.
    """
    import sys
    import time
    import numpy as np
    from ..utils import _range
    # Basic test
    assert list(product(range(5))) == [range(5)]
    # Multiple iterables
    assert list(product(_range(3), _range(3))) == [
        (_range(3), _range(3)),
        (_range(3, 6), _range(3, 6)),
        (_range(6, 9), _range(6, 9))]
    # Infinite iterables
    assert list(product(np.inf, repeat=3)) == [np.inf, np.inf, np.inf]
    # Empty iterable
    assert list(product([])) == [tuple()]
    # Reservoir Sampling test

# Generated at 2022-06-12 14:32:14.604154
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    res = list(product([1, 2, 3], ['a', 'b'], tqdm_class=None))
    assert_equal(res, list(itertools.product([1, 2, 3], ['a', 'b'])))

# Generated at 2022-06-12 14:32:18.635521
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # Standard usage
    from tqdm import tqdm
    for _ in tqdm(product(range(3), repeat=3)):
        pass

    # Unit test for total:
    for _ in tqdm(product(range(2), repeat=4), total=16):
        pass

# Generated at 2022-06-12 14:32:26.975617
# Unit test for function product
def test_product():
    """
    Test product
    """
    list_arguments = [range(5), range(5), range(5)]

# Generated at 2022-06-12 14:32:34.613486
# Unit test for function product
def test_product():
    from ..utils import matrices
    from .. import trange
    from .itertools import product

    for kwargs in product({'a': list(range(3)), 'b': list(range(5))},
                          {'a': list(range(2)), 'b': list(range(2)), 'c': list(range(2))}):
        assert len(kwargs) >= 2
        assert len(kwargs) <= 3
        for k in ('a', 'b', 'c'):
            if k in kwargs:
                assert 0 <= kwargs[k] < 2

    for i in trange(1000, **matrices(ncols=10, as_dict=True)):
        pass


# Generated at 2022-06-12 14:32:43.533062
# Unit test for function product
def test_product():
    from random import randint

    import tqdm
    from tqdm._utils import _term_move_up
    from tqdm._utils import _range
    from tqdm.tests.utils import StringIO

    if StringIO is not list:  # Python 2
        from contextlib import nested
    else:  # Python >= 3
        from contextlib import ExitStack as nested

    with nested(tqdm.tests.setup_tests(),
                StringIO()) as (setup, s):
        # Check 1 iteration
        yield lambda s=s: tqdm._instances.clear()
        with tqdm.tests.disable_progress_bar(), nested(s, _range(0)) as (s, g):
            list(product(g))
        assert not s.getvalue()

        yield lambda s=s: tqdm._inst

# Generated at 2022-06-12 14:33:30.655986
# Unit test for function product
def test_product():
    import numpy as np
    x = list(product(range(10), range(10), tqdm_class=tqdm_auto))
    assert len(x) == 100
    x = list(product(range(10), range(10), tqdm_class=tqdm_auto, initial=1))
    assert len(x) == 100
    assert x[0] == (0, 0)
    x = list(product(range(5), range(5), tqdm_class=tqdm_auto,
                     leave=True, disable=True))
    assert len(x) == 25
    x = list(product(range(5), range(5), tqdm_class=tqdm_auto,
                     leave=False, disable=True))
    assert len(x) == 25

# Generated at 2022-06-12 14:33:33.371424
# Unit test for function product
def test_product():
    """ Unit test for function `product` """
    a = list(product(range(10), range(100)))
    b = list(itertools.product(range(10), range(100)))
    assert(a == b)

# Generated at 2022-06-12 14:33:40.172512
# Unit test for function product
def test_product():
    def num_sum(iterable):
        """sum of numbers in an iterable"""
        return sum(iterable)

    assert num_sum(product(range(3), range(3), range(3))) == num_sum(itertools.product(range(3), range(3), range(3)))

    assert num_sum(product(range(10), [10])) == num_sum(itertools.product(range(10), [10]))

    assert num_sum(product(range(10), [1, 2, 3])) == num_sum(itertools.product(range(10), [1, 2, 3]))

# Generated at 2022-06-12 14:33:49.853115
# Unit test for function product
def test_product():
    from numpy import prod

    for cls in [tqdm_auto, tqdm_auto.tqdm, tqdm_auto.tqdm_gui,
                tqdm_auto.tqdm_notebook]:
        total = 0
        a = range(500)
        b = range(300)
        c = range(200)

        def gen():
            """
            Generator of the Cartesian product of lists.
            """
            global total
            total = 0
            for i in itertools.product(a, b, c):
                yield i
                total += 1

        for _ in product(a, b, c, tqdm_class=cls):
            pass
        assert total == prod(map(len, [a, b, c]))


# Generated at 2022-06-12 14:33:57.146756
# Unit test for function product

# Generated at 2022-06-12 14:33:59.806110
# Unit test for function product
def test_product():
    from ..utils import freeze_support
    from ..tests.bad_format_test_cases import canonical_itertools_test_cases

    total = 0
    for args, nargs, ngens in canonical_itertools_test_cases:
        for i in product(*args):
            total += 1
    assert total == sum(nargs)

# Generated at 2022-06-12 14:34:06.621201
# Unit test for function product
def test_product():
    from numpy import arange
    arange(10)
    list(product(arange(10, 10), arange(10, 10)))
    list(product(arange(10, 10), arange(10, 10), tqdm_class=None))
    assert (list(product(range(2), range(2), tqdm_class=None))
            == list(itertools.product(range(2), range(2))))


if __name__ == "__main__":
    from .main import main
    main(__file__)

# Generated at 2022-06-12 14:34:12.048386
# Unit test for function product
def test_product():
    import random
    import string
    s = ''.join(random.choice(string.ascii_lowercase) for _ in range(100))
    assert [''.join(i) for i in product(s, repeat=3)] == \
        [''.join(i) for i in itertools.product(s, repeat=3)]
    assert [''.join(i) for i in product(s, repeat=3, tqdm_class=None)] == \
        [''.join(i) for i in itertools.product(s, repeat=3)]

# Generated at 2022-06-12 14:34:15.288938
# Unit test for function product
def test_product():
    assert(list(product(['a', 'b'], ['c', 'd'])) ==
           [('a', 'c'), ('a', 'd'), ('b', 'c'), ('b', 'd')])

# Generated at 2022-06-12 14:34:23.774518
# Unit test for function product
def test_product():
    import re
    from ..utils import _range
    from .utils import FormatMixin


# Generated at 2022-06-12 14:35:43.074877
# Unit test for function product
def test_product():
    # Test for all/default kwargs
    list(product([1, 2], [3, 4], [5, 6]))

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:35:51.055191
# Unit test for function product
def test_product():
    """
    Tests for `itertools.product` wrapper.
    """
    from ..utils import format_sizeof
    from ..utils import format_interval
    from .utils import closing

    from contextlib import contextmanager
    from operator import mul
    from time import sleep

    from .utils import Random
    from .utils import FakeTqdmFile

    N = 256
    M = 1024
    c = count = 0
    for i in product(sorted(Random.randints(N)),
                     Random.randints(M),
                     Random.sample(N),
                     repeat=2,
                     tqdm_class=tqdm_auto):
        assert i == (i[0], i[1], i[0], i[1])
        count += 1
        c += 1
    assert count == N * M * N


# Generated at 2022-06-12 14:35:55.191379
# Unit test for function product
def test_product():
    """Test for function `product`."""
    from ..std import mock
    for tqdm_class in [None, mock.Mock]:
        for ascii in [True, False]:
            for miniters in ['1', '1e100']:
                product('abc', 'de', tqdm_class=tqdm_class,
                        ascii=ascii, miniters=miniters)

# Generated at 2022-06-12 14:36:01.706522
# Unit test for function product
def test_product():
    ''' test the product function '''
    import numpy as np
    list1 = [i for i in range(1, 100)]
    list2 = [i for i in range(2, 3, 0.01)]

    list1_cartesian = [i for i in itertools.product(list1, list2)]
    list2_cartesian = [i for i in tqdm.product(list1, list2)]

    assert np.allclose(list1_cartesian, list2_cartesian)

test_product()

# Generated at 2022-06-12 14:36:04.398980
# Unit test for function product
def test_product():
    """Test for the :func:`tqdm.itertools.product` function"""
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:36:09.666640
# Unit test for function product
def test_product():
    "Check that tqdm is equivalent to itertools on simple product cases"
    assert list(itertools.product(range(5), range(5))) == list(product(range(5), range(5)))
    assert list(itertools.product(range(5), "abcd")) == list(product(range(5), "abcd"))
    assert list(itertools.product(range(5), "abcd", "efg")) == list(product(range(5), "abcd", "efg"))

# TODO: test_product_slices (only if we choose to implement it)

# Generated at 2022-06-12 14:36:18.492178
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Dummy iterable
    class DummyIterable:
        "Dummy iterable"
        def __iter__(self):
            for x in range(5):
                yield x
            raise Exception("Done")

    # Test 1
    list(product(DummyIterable(), tqdm_class=tqdm_auto))

    # Test 2: 1 iterable
    assert list(product([1, 2] + list(range(3, 101)))) == \
        list(itertools.product([1, 2] + list(range(3, 101))))

    # Test 3: 2 iterables

# Generated at 2022-06-12 14:36:26.348014
# Unit test for function product
def test_product():
    assert list(product("1234", tqdm_class=None)) == list("1234")
    assert list(product("1234", "abcd", tqdm_class=None)) == \
        [i + j for i, j in itertools.product("1234", "abcd")]
    assert list(product("1234", "abcd", "xyz", tqdm_class=None)) == \
        [i + j + k for i, j, k in itertools.product("1234", "abcd", "xyz")]
    assert list(product("1234", "abcd", tqdm_class=None, total=13)) == \
        [i + j for i, j in itertools.product("1234", "abcd")]

# Generated at 2022-06-12 14:36:32.137942
# Unit test for function product
def test_product():
    from random import randint
    from .utils import formatted_timer
    from .utils import BaseTestCase, closing

    class TestProduct(BaseTestCase):
        @classmethod
        def _gen(cls, *args, **kwargs):
            return product(*args, **kwargs)

        @classmethod
        def _pre(cls, *args, **kwargs):
            return list(itertools.product(*args, **kwargs))

        def test_product(self):
            rng = randint(1, 5)
            # self.assertEqual(
            #     list(self._gen(range(rng), repeat=rng,
            #                    tqdm_class=tqdm_gui.tqdm_gui)),
            #     self._pre(range(rng), repeat=rng))  # NO

# Generated at 2022-06-12 14:36:41.912388
# Unit test for function product
def test_product():
    from .utils import FormatLabel
    total = 6
    tqdm_kwargs = {"ascii": True, "dynamic_ncols": True}
    with tqdm_auto(
            3, 4, **tqdm_kwargs,
            desc="Test product",
            total=total,
            miniters=1) as pbar:
        for i in product(range(3), range(4),
                         tqdm_class=FormatLabel,
                         mininterval=0.1,
                         miniters=1,
                         **tqdm_kwargs):
            if pbar.n:  # not the first iteration
                assert len(pbar.format_dict["desc"].split("|")) == 2
                assert pbar.last_print_n < pbar.n
                assert pbar.last_