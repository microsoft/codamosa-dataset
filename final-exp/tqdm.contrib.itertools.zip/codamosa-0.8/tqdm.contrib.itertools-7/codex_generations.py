

# Generated at 2022-06-12 14:27:11.071597
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from .tests import TqdmDeprecationWarning, closing
    from ..utils import _range

    def my_product(*iterables, **tqdm_kwargs):
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
                t.update()

    with closing(tqdm_auto(total=0)) as pbar:
        pbar.clear()

# Generated at 2022-06-12 14:27:18.058148
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    # Test with total
    assert list(product(range(10), range(10), range(10), tqdm_class=tqdm_auto,
                        total=1000)) == list(
        itertools.product(range(10), range(10), range(10)))
    # Test without total
    assert list(product(range(10), range(10), range(10), tqdm_class=tqdm_auto)) == list(
        itertools.product(range(10), range(10), range(10)))
    tqdm_auto().close()

# Generated at 2022-06-12 14:27:26.464653
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    assert list(product(range(5), repeat=5)) == list(itertools.product(range(5), repeat=5))

    q = FormatCustomText(
        format_sizeof(),
        itertools.count(1))

    def tqdm_class(*args, **kwargs):
        return tqdm_auto(*args, unit_scale=True, unit_divisor=1024,
                         format_custom_text=q, **kwargs)

    try:
        import gc
        gc.disable()
        gc.collect()
        test_it = list(product(range(10000), repeat=5, tqdm_class=tqdm_class))
    finally:
        gc.enable()

# Generated at 2022-06-12 14:27:28.282818
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`.
    """
    from ...tests import test_product as _test_product
    _test_product(product)

# Generated at 2022-06-12 14:27:30.348258
# Unit test for function product
def test_product():
    with tqdm_auto(total=3 * 5 * 7) as t:
        for i in product(range(3), range(5), range(7)):
            t.update()
    assert t.n == t.total

# Generated at 2022-06-12 14:27:39.679151
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_equal

    a = list(range(1000))
    b = list(range(1000))
    c = list(range(1000))

    total = sum(1 for _ in product(a, b, c))
    assert_equal(total, 1e6)

    total = sum(1 for _ in product(a, b, c, tqdm_class=None))
    assert_equal(total, 1e6)

    total = sum(1 for _ in product(a))
    assert_equal(total, 1e3)

    total = sum(1 for _ in product(a, b, c, tqdm_class=tqdm_auto))
    assert_equal(total, 1e6)


# Generated at 2022-06-12 14:27:48.536147
# Unit test for function product

# Generated at 2022-06-12 14:27:54.276316
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    try:
        product(range(3), range(2))
        assert False
    except TypeError:
        pass
    assert_array_equal(list(product("ab", repeat=2)),
                       list(itertools.product("ab", repeat=2)))
    assert_array_equal(list(product("abc")),
                       list(itertools.product("abc")))

# Generated at 2022-06-12 14:28:02.422265
# Unit test for function product
def test_product():
    """
    Test function product

    Returns
    -------
    None

    """
    import sys
    from ..utils import _range

    # Test input parameters
    itertools.product(_range(3))

    # Test stdout
    with tqdm.utils.captured_output() as (_, err):
        for _ in tqdm.itertools.product(_range(3)):
            pass
    match = re.search(r', estimated [\d\.]+ s', err.getvalue())
    assert match is None, ("unit test error: expected iteration "
                           "times not to be shown, got:\n" + err.getvalue())

    # Test `position`

# Generated at 2022-06-12 14:28:10.783356
# Unit test for function product
def test_product():
    from .tests import close_obj
    import os
    import sys

    if sys.version_info >= (3, 0):
        range = range


# Generated at 2022-06-12 14:28:22.818170
# Unit test for function product
def test_product():
    """Test function product."""
    from ..auto import trange
    assert list(product([2], [2])) == [(2, 2)]
    assert list(product([2, 3], [4])) == [(2, 4), (3, 4)]
    assert list(product([2, 3], [4, 5])) == [(2, 4), (2, 5), (3, 4), (3, 5)]
    assert list(product([2, None], [None])) == [(2, None), (None, None)]
    assert list(product([2, None])) == [(2,), (None,)]
    assert list(product([], [4])) == []
    assert list(product([], [])) == []
    assert list(product([])) == []


# Generated at 2022-06-12 14:28:27.268605
# Unit test for function product
def test_product():
    from ..utils import _range

    list(_range(3, 0, -1))
    list(_range(1))
    list(product([1], _range(1)))
    list(product(_range(1), [1]))
    list(product(_range(1), [1], _range(1)))


# Alias
prod = product

# Generated at 2022-06-12 14:28:29.880074
# Unit test for function product
def test_product():
    for i in product([1, 2], ["a", "b", "c"], tqdm_class=None):
        pass
    for i in product([1, 2], ["a", "b", "c"], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:28:36.031514
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    try:
        # Python 2
        from itertools import imap as map
    except ImportError:
        pass

    for n in range(1, 5):
        l = [np.arange(10) for i in range(n)]
        q = list(product(*l))
        assert(list(map(list, q)) == list(itertools.product(*l)))

# Generated at 2022-06-12 14:28:43.531907
# Unit test for function product
def test_product():
    from .utils import FakeTqdmFile
    from .tqdm import tqdm

    iterables = [[1, 2, 3, 4], ['a', 'b', 'c', 'd'], [1]]
    total = len(iterables[0]) * len(iterables[1]) * len(iterables[2])

    with tqdm(total=total) as t:
        for i in itertools.product(*iterables):
            t.update()

    with tqdm(total=total) as t:
        for i in product(*iterables, file=t):
            pass

    with tqdm(total=total) as t:
        for i in product(*iterables, tqdm_class=t.__class__):
            pass


# Generated at 2022-06-12 14:28:47.985298
# Unit test for function product
def test_product():
    """Unit tests for function `tqdm.itertools.product`"""
    from ..tests import faux_tqdm
    from nose.tools import assert_equal
    from numpy.testing import assert_array_equal
    from itertools import product

    # Test base cases
    assert_equal(list(faux_tqdm(product, range(3))),
                 list(product(range(3))))
    assert_equal(list(faux_tqdm(product,
                                "ab",
                                "cde",
                                "fghij")),
                 list(product("ab", "cde", "fghij")))

    # Test kwargs
    tqdm_kwargs = dict(desc="test",
                       miniters=1,
                       dynamic_ncols=True)
    assert_

# Generated at 2022-06-12 14:28:58.142685
# Unit test for function product
def test_product():
    """
    Unit test `product`.
    """
    from time import sleep
    from numpy import prod
    from ..tqdm import trange

    # Test loop length
    assert prod([5, 7]) == len(list(trange(5, 7, leave=False)))

    # Test iterator length
    for i in tqdm_auto(range(3)):
        assert len(list(trange(i, leave=False))) == i

    # Test manual override
    for boo in [True, False]:
        assert len(list(trange(3, total=10, leave=boo))) == 10

    # Test iterator
    for boo in [True, False]:
        assert len(list(trange(10, leave=boo))) == 10

    # Test no-iteration

# Generated at 2022-06-12 14:29:04.478754
# Unit test for function product
def test_product():
    """Test function `product`"""
    # Test with no total given
    res = []
    for i in product((1, 2), (3, 4)):
        res.append(i)
    assert res == [(1, 3), (1, 4), (2, 3), (2, 4)]
    # Test with total given
    res = []
    for i in product((1, 2), (3, 4), total=4):
        res.append(i)
    assert res == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-12 14:29:14.066341
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import numpy as np
    np.random.seed(0)

    def f_rand():
        for _ in range(np.random.randint(1, 10)):
            yield np.random.randint(0, 10)

    from ._tqdm import tqdm as tqdm_class

    assert list(product(f_rand(), tqdm_class=tqdm_class)) == \
        list(itertools.product(f_rand(), tqdm_class=tqdm_class))

    # Test for total
    for i in range(1, 5):
        for _ in range(5):
            itrs = [f_rand() for _ in range(i)]

# Generated at 2022-06-12 14:29:20.516600
# Unit test for function product
def test_product():
    """Test function `product`"""
    from ..std import next, suppress

    # Test with non iterable
    with suppress(TypeError):
        t = product(2)
        next(t)

    # Test with 1 iterable
    t = product((2, 3))
    try:
        assert next(t) == (2,)
        assert next(t) == (3,)
        assert next(t)
    except StopIteration:
        pass

    # Test with many iterables
    t = product((2, 3), (4, 5), (6, 7))

# Generated at 2022-06-12 14:29:30.346850
# Unit test for function product
def test_product():
    """Basic tests of product"""
    import numpy as np
    from .utils import FormatWrapBase

    all_zeros = np.zeros((10, 10, 10, 10), dtype=np.int8)
    for i, j, k, l in product(
            range(10), range(10), range(10), range(10),
            postfix={'x': 'y'}, tqdm_class=FormatWrapBase):
        all_zeros[i, j, k, l] += 1
    assert all_zeros.all()


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:29:37.991785
# Unit test for function product
def test_product():
    s = [
        [],
        [1],
        [1, 2],
        [1, 2, 3],
        ["1", "2", "3"],
        list(range(100000)),
    ]
    from random import randint
    for _ in range(100):
        randint(0, 4)
        for _ in range(100):
            randint(0, 4)
        for i in range(100):
            for j in range(100):
                for k in range(100):
                    for l in range(100):
                        for m in range(100):
                            if (m != 0
                                    and i == 0 and j == 0 and k == 0 and l == 0):
                                break

# Generated at 2022-06-12 14:29:45.728997
# Unit test for function product
def test_product():
    for i in product(*[range(3), range(4), range(5)],
                    tqdm_class=tqdm_auto,
                    total=len(list(product(*[range(3), range(4), range(5)])))):
        assert i
    for i in product(*[range(3), range(4), range(5)],
                    tqdm_class=tqdm_auto,
                    total=None):
        assert i
    for i in product(*[],
                    tqdm_class=tqdm_auto,
                    total=0):
        assert i
    def gen():
        yield 1
        yield 2
        yield 3
    for i in product(*[gen(), gen()],
                    tqdm_class=tqdm_auto,
                    total=None):
        assert i

# Generated at 2022-06-12 14:29:55.007961
# Unit test for function product
def test_product():
    from ..auto import tqdm
    for a in [None]:
        for b in [None]:
            for n in [None, 0, 1, 2, 4, 8, 16]:
                tgt = list(itertools.product(a, b, range(n)))
                res = list(product(a, b, range(n)))
                assert res == tgt

    with tqdm(product([1, 2, 3], [1, 2, 3], [1, 2]),
              total=3 * 3 * 2, leave=False) as t:
        for (a, b, c) in t:
            pass
        assert t.n == 3 * 3 * 2


# Generated at 2022-06-12 14:30:03.309096
# Unit test for function product
def test_product():
    """
    unit test for function product
    """
    import sys
    data = itertools.product('ABCD', 'xy')
    data = list(data)
    ldata = len(data)

    out1 = sys.stdout
    out2 = sys.stderr
    sys.stdout = sys.stderr = open('/dev/null', 'w')
    for _ in tqdm_auto(itertools.product('ABCD', 'xy')):
        pass
    for _ in tqdm_auto(itertools.product('ABCD', 'xy'),
                       total=ldata):
        pass
    sys.stdout = out1
    sys.stderr = out2
    assert _ == data[-1]

    data = itertools.product('ABCD', 'xy', '123')

# Generated at 2022-06-12 14:30:12.067220
# Unit test for function product
def test_product():
    import sys
    import math
    import random
    from .utils import FormatWrapBase

    if not sys.platform.startswith('win'):
        import termios
        import tty

        def _term_size():
            with tty.open_pipe('stty size') as (stdin, stdout):
                return tuple(int(_) for _ in next(stdout).split())
        try:
            rows, columns = _term_size()
        except (UnicodeDecodeError, OSError, IOError, StopIteration):
            rows, columns = 25, 80
    else:
        import ctypes

        def _term_size():
            # pylint: disable=no-member,protected-access
            from ctypes.wintypes import STD_OUTPUT_HANDLE

# Generated at 2022-06-12 14:30:19.962613
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from random import randint
    from sys import version_info
    from ..utils import _range as range  # noqa

    # Simple tests
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product([1, 2])) == [(1,), (2,)]
    assert list(product([1, 2], repeat=0)) == [()]

    # Random tests
    _miniters = 1 if version_info[0] == 3 else 10  # UTF-8 encoding fixes
    for _ in range(_miniters):
        base = [randint(0, 100) for _ in range(randint(1, 10))]
        repeat = randint(0, 10)
        expected

# Generated at 2022-06-12 14:30:26.487138
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.tqdm_itertools.product`.
    """
    from .tests import pretest_posttest
    from ..utils import FormatCustomText
    def dummy_product(*iterables, **tqdm_kwargs):
        """Dummy product"""
        n = 1
        for i in iterables:
            n *= len(i)
        with tqdm_auto(**tqdm_kwargs) as t:
            for _ in range(n):
                yield _
                t.update()
    with pretest_posttest() as (cls, sm, _):
        if issubclass(cls, FormatCustomText):
            args = ('x', range(2))

# Generated at 2022-06-12 14:30:33.732881
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # Test 1
    a = [1, 2, 3]
    b = [4, 5, 6]
    r = list(product(a, b))
    try:
        assert r == list(itertools.product(a, b))
    except AssertionError:
        raise

    # Test 2
    a = [1, 2, 3]
    b = [4, 5, 6]
    with tqdm_auto(total=len(a)*len(b)) as t:
        res = list(product(a, b, tqdm_class=t.__class__))
    try:
        assert res == list(itertools.product(a, b))
    except AssertionError:
        raise


# Generated at 2022-06-12 14:30:40.230402
# Unit test for function product
def test_product():
    import math
    import random
    import string
    import sys

    if (3, 0) <= sys.version_info < (3, 4):
        from .compatibility import product as prod
        for _ in range(1000):
            _prod = prod(string.ascii_letters, repeat=random.randint(1, 10))
            for i in product(string.ascii_letters, repeat=random.randint(1, 10)):
                assert i == _prod.next()
    else:
        from .compatibility import product as prod
        for _ in range(1000):
            _prod = prod(string.ascii_letters, repeat=random.randint(1, 10))

# Generated at 2022-06-12 14:30:52.481590
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # skip doctest in non-interactive mode
    import nose
    nose.runmodule(argv=[__file__, '-vvs', '-x', '--pdb', '--pdb-failure'],
                   exit=False)

if __name__ == "__main__":
    from .version import __version__
    from .tqdm import tqdm

    with tqdm(total=10) as t:
        for _ in product(range(10), ['a', 'b'], tqdm_class=t.__class__):
            t.update()

# Generated at 2022-06-12 14:31:00.672498
# Unit test for function product
def test_product():
    """ Unit test for function :obj:`itertools_extras.product` """
    with tqdm_auto(total=1) as pbar:
        assert list(product(range(3))) == list(itertools.product(range(3)))
        pbar.update()
        assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))
        pbar.update()

# Generated at 2022-06-12 14:31:05.857848
# Unit test for function product
def test_product():
    """ Unit tests for :func:`~tqdm.itertools.product` """
    try:
        from numpy.testing import assert_equal
    except ImportError:
        print("No numpy available to test tqdm.itertools.product")
        return

    # Check total is correct for len(iterables) == 1
    for i in range(100):
        it = product(range(i))
        assert_equal(list(it), list(itertools.product(range(i))))

    # Check total is correct for len(iterables) == 2
    for i in range(100):
        for j in range(100):
            it = product(range(i), range(j))
            assert_equal(list(it), list(itertools.product(range(i), range(j))))

    # Check total

# Generated at 2022-06-12 14:31:11.088644
# Unit test for function product
def test_product():
    """Test function `product`."""
    assert list(product(range(10), range(5))) == list(
        itertools.product(range(10), range(5)))
    assert list(product(range(10), range(5), tqdm_class=False)) == list(
        itertools.product(range(10), range(5)))

# Generated at 2022-06-12 14:31:14.249159
# Unit test for function product
def test_product():
    it = product(['a', 'b'], [1, 2, 3], ['X', 'Y'], tqdm_class=lambda x: x)
    assert list(it) == list(itertools.product(['a', 'b'], [1, 2, 3], ['X', 'Y']))

# Generated at 2022-06-12 14:31:21.618384
# Unit test for function product

# Generated at 2022-06-12 14:31:24.977727
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from ..tests import tests
    from ..std import time
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tests.tqdm_class):
        time.sleep(0.01)
    tests.utils.print_testname(tests.utils.funcname())

# Generated at 2022-06-12 14:31:34.119587
# Unit test for function product
def test_product():
    with product(range(1, 5), "abcd", "EFG") as p:
        p = list(p)

# Generated at 2022-06-12 14:31:36.092157
# Unit test for function product
def test_product():
    """ Unit test for function product """
    list_results = [i for i in product([1, 2], [10, 20])]
    assert len(list_results) == 4

# Generated at 2022-06-12 14:31:38.769118
# Unit test for function product
def test_product():
    with tqdm_auto(unit='lines') as t:
        for i in product(range(1000), range(1000),
                         tqdm_class=tqdm_auto, unit='lines'):
            pass

# Generated at 2022-06-12 14:31:51.727627
# Unit test for function product
def test_product():
    """
    Test product
    """
    with tqdm_auto(total=None) as t:
        for i in product(range(2), range(4), range(4), tqdm_class=t):
            pass
    assert t.total == 32

# Generated at 2022-06-12 14:31:58.281454
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`.
    """
    # Test numeric arguments
    assert list(product(range(6), repeat=6)) == list(itertools.product(
        range(6), repeat=6))
    # Test string arguments
    assert list(product("ab", repeat=2)) == list(itertools.product("ab",
                                                                   repeat=2))
    # Test empty argument
    assert list(product()) == list(itertools.product())
    # Test mixed argument
    assert list(product("abc", repeat=3)) == list(itertools.product("abc",
                                                                    repeat=3))
    assert list(product("abc", repeat=2)) == list(itertools.product("abc",
                                                                    repeat=2))

# Generated at 2022-06-12 14:32:04.346993
# Unit test for function product
def test_product():
    import random
    import pytest

    def gen():
        yield random.random()
        yield random.random()
        return

    try:
        list(product(range(10)))
    except TypeError:
        pass
    else:
        pytest.fail()

    try:
        list(product(range(10), range(10), tqdm_class=None))
    except TypeError:
        pass
    else:
        pytest.fail()

    try:
        list(product(xrange(10)))
    except NameError:
        pass
    else:
        pytest.fail()

    assert list(product(range(10), range(10))) == list(itertools.product(range(10), range(10)))

# Generated at 2022-06-12 14:32:07.654068
# Unit test for function product
def test_product():
    """
    Unit test for `product`

    Note
    ----
    This test is a very crude check.
    """
    iterables = [[1, 2, 3], [4, 5, 6]]
    tqdm_kwargs = {"desc": "testing"}
    for prod in product(*iterables, **tqdm_kwargs):
        yield prod

# Generated at 2022-06-12 14:32:10.823228
# Unit test for function product
def test_product():
    with tqdm_auto(unit_scale=True, desc="test", leave=True) as t:
        for _ in product(range(10), range(10),
                         tqdm_class=t.__class__,
                         unit_scale=True):
            pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:32:20.168116
# Unit test for function product
def test_product():
    """ Unit test for function product
    """
    import numpy as np
    from tqdm import tqdm
    import inspect
    # Function-based API
    res = list(tqdm(product([2], [2], tqdm_class=tqdm)))
    assert isinstance(res, list)
    assert np.all(np.asarray(res) == np.asarray([(0, 0), (0, 1), (1, 0),
                                                 (1, 1)]))
    # Class-based API
    for tqdm_class in [tqdm, tqdm.tqdm]:
        with tqdm_class(
                [2], [2], total=4,
                desc=inspect.currentframe().f_code.co_name) as t:
            res = list(t)

# Generated at 2022-06-12 14:32:28.634267
# Unit test for function product
def test_product():
    from .utils import FormatWidget
    from .sysinfo import cpu_count
    import multiprocessing as mp
    from time import time

    def _gen(a, b):
        for i in range(a, b):
            yield i

    def do(a, b):
        total = 0
        with FormatWidget(format_dict=dict(prefix='', postfix=' ', unit=' elem')) as f:
            for i in product(_gen(22, 25), _gen(31, 34), tqdm_class=f, total=360):
                total += len(i)
                assert isinstance(i, tuple)
        return total


# Generated at 2022-06-12 14:32:35.821770
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .pandas import PandasWrapper
    # Simple test on simple types
    for a in [2, 3, 4]:
        for b in [2, 3, 4]:
            for c in [2, 3, 4]:
                iter_dict = {
                    "i": list(range(a)),
                    "j": list(range(b)),
                    "k": list(range(c))}
                for i, j, k in product(iter_dict['i'], iter_dict['j'],
                                       iter_dict['k'], total=a * b * c):
                    pass

    # Test on dict
    dict1 = {'a': list(range(2)), 'b': list(range(3))}

# Generated at 2022-06-12 14:32:44.853902
# Unit test for function product
def test_product():
    with tqdm_auto(total=198) as t:
        assert len(list(product(range(9), repeat=2, tqdm_class=tqdm_auto))) == 81
        t.total = 200
        assert len(list(product(range(10), repeat=2, tqdm_class=tqdm_auto))) == 100
        t.total = 0
        assert len(list(product(range(10), repeat=0, tqdm_class=tqdm_auto))) == 1
        assert len(list(product(range(10), repeat=1, tqdm_class=tqdm_auto))) == 10
        assert len(list(product(range(10), repeat=3, tqdm_class=tqdm_auto))) == 1000


if __name__ == "__main__":
    test

# Generated at 2022-06-12 14:32:50.962209
# Unit test for function product
def test_product():
    """test function `product`"""
    assert list(product([-2, -1, 0, 1, 2])) == [(-2,), (-1,), (0,), (1,), (2,)]

# Generated at 2022-06-12 14:33:12.929705
# Unit test for function product
def test_product():
    for x in product(['a', 'b', 'c'], [1, 2]):
        assert(x[0] + str(x[1]) in ['a1', 'a2', 'b1', 'b2', 'c1', 'c2'])

# Generated at 2022-06-12 14:33:21.379460
# Unit test for function product
def test_product():
    with product(["a", "b", "c"], [1, 2, 3], ["!", "?", "."]) as prod:
        prod_list = [char for char in prod]

# Generated at 2022-06-12 14:33:30.465847
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..nested import nested_iters
    a = [1, 2, 3]
    b = ['a', 'b']
    t = product(a, b, tqdm_class=tqdm_auto)
    assert t.total == 6
    assert list(t) == list(itertools.product(a, b))
    t = product(a, b, nested=True, tqdm_class=tqdm_auto)
    assert t.total == 4
    assert list(t) == [i for _ in a for i in b]
    t = product(a, b, nested=2, tqdm_class=tqdm_auto)
    assert t.total == 4
    assert list(t) == [i for _ in a for i in b]
    t

# Generated at 2022-06-12 14:33:34.486063
# Unit test for function product
def test_product():
    from .utils import FormatWidget
    from .main import TqdmDefaultWriteLock
    for tqdm_class_ in [tqdm_auto, FormatWidget, TqdmDefaultWriteLock]:
        for x, y in product(range(2), range(3),
                            tqdm_class=tqdm_class_):
            pass
        assert x == 1
        assert y == 2

# Generated at 2022-06-12 14:33:39.679281
# Unit test for function product
def test_product():
    import shutil
    with tqdm_auto(total=None, miniters=1, mininterval=0,
                   desc="test_product") as t:
        it = product(*(range(x) for x in range(1, 11)),
                     tqdm_class=t.__class__)
        for i in it:
            t.update()
    shutil.rmtree(t.pos_bar.__class__.__name__)

# Generated at 2022-06-12 14:33:42.502664
# Unit test for function product
def test_product():
    for _ in product(*(range(4), range(4)), **{"total": 16}):
        pass
    for _ in product(range(4), **{"total": 4}):
        pass
    for _ in product(range(4), range(4)):
        pass
    for _ in product(range(4), range(4)):
        pass

# Generated at 2022-06-12 14:33:51.392712
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from random import randrange
    from ..utils import FormatCustomText
    RANGE = 2 ** randrange(8, 20)
    with tqdm_auto(total=RANGE, unit='B', unit_scale=True) as t:
        assert (t.index - t.last_print_n) == 0
        for i in product(range(RANGE)):
            assert i[0] == t.n
            assert i[0] == t.index
            assert t.index == t.last_print_n + 1
            t.update()
    assert t.index == t.last_print_n + 1
    assert t.n == t.last_print_n
    assert t.n == RANGE - 1

# Generated at 2022-06-12 14:33:58.358119
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase()) as t:
        assert list(product([1, 2, 3], ['a', 'b'])) == [
            (1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]
        assert list(product([1, 2], repeat=2)) == [
            (1, 1), (1, 2), (2, 1), (2, 2)]

# Generated at 2022-06-12 14:34:03.693443
# Unit test for function product
def test_product():
    import random
    import string
    import unittest
    import itertools

    class Tests(unittest.TestCase):
        def randomword(self, length):
            return ''.join(random.choice(string.ascii_lowercase)
                           for i in range(length))

        def test_product(self):
            iter1 = [1, 2, 3, 4]
            iter2 = [1, 2, 3, 4]
            iter3 = [1, 2, 3, 4]
            result = (1, 1, 1), (1, 1, 2), (1, 1, 3), (1, 1, 4), (1, 2, 1), \
                (1, 2, 2), (1, 2, 3), (1, 2, 4), (1, 3, 1), (1, 3, 2),

# Generated at 2022-06-12 14:34:13.355230
# Unit test for function product
def test_product():
    """Test product()"""
    import numpy as np

    def gen1():
        for i in range(3):
            yield i

    def gen2():
        for i in range(4):
            yield i

    def gen3():
        for i in range(5):
            yield i

    res_npa = np.array(list(itertools.product(gen1(), gen2(), gen3())))
    res_tq = np.array(list(product(gen1(), gen2(), gen3(), tqdm_class=None)))
    assert np.array_equal(res_tq, res_npa)
    res_tq = np.array(list(product(gen1(), gen2(), gen3())))
    assert np.array_equal(res_tq, res_npa)

    # Non-

# Generated at 2022-06-12 14:35:00.783829
# Unit test for function product
def test_product():
    import sys
    import numpy as np
    if sys.version_info[0] == 3:
        from itertools import zip_longest
        from six.moves import range
    else:
        from itertools import zip_longest as izip_longest
        range = xrange

    def prod(iterable):
        "Equivalent of itertools.product"
        if not (iterable and hasattr(iterable, '__len__') and hasattr(iterable[0], '__len__')):
            return iter(iterable)
        n = len(iterable)
        if n == 0:
            yield ()
            return
        ids = range(n)
        vls = [0] * n
        first = True

# Generated at 2022-06-12 14:35:09.315311
# Unit test for function product
def test_product():
    """
    Test the module
    """
    from tqdm import tqdm
    for i in product(range(10), repeat=2):
        pass
    for i in product(range(10), repeat=2, tqdm_class=tqdm):
        pass
    for i in product(range(10), repeat=2, tqdm_class=tqdm,
            total=100):
        pass
    assert list(product(range(2), repeat=2)) == list(itertools.product(
        range(2), repeat=2))

    assert list(itertools.product([3., 4.], [1, 2], [5, 6])) == list(product(
        [3., 4.], [1, 2], [5, 6]))

# Generated at 2022-06-12 14:35:13.058105
# Unit test for function product
def test_product():
    from .tests import closing, pretest_posttest

    with closing(pretest_posttest()):
        for _ in product(range(10), range(100), range(1000),
                         tqdm_class=tqdm_auto):
            pass
        for _ in product(range(10), range(100), range(1000)):
            pass

# Generated at 2022-06-12 14:35:18.363699
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests_tqdm import pretest_posttest

    def test_fct(a):
        def _fct(b, c):
            return b * c

        l = [i * a for i in range(10)]
        out = []
        for i, j in product(l, repeat=2, tqdm_class=tqdm_auto):
            out.append(_fct(i, j))
        return out

    pretest_posttest(test_fct, 99,
                     post_process=lambda func, out: out.sort())

# Generated at 2022-06-12 14:35:23.758505
# Unit test for function product
def test_product():
    """Test that product is equivalent to itertools.product"""
    import itertools as it
    import numpy as np
    from ..utils import FormatMixin
    class UTProduct(FormatMixin):
        class formatted(FormatMixin._formatted):
            """
            A custom iterator that returns its parent
            when using its `next` method.
            """
            def next(self):
                return next(self._iter)
    L1 = [1, 2, 3]
    L2 = [4, 5, 6]
    L3 = [7, 8, 9]
    # itertools

# Generated at 2022-06-12 14:35:27.185292
# Unit test for function product
def test_product():
    """Test for function product"""
    for _ in product(range(1000), range(7),
                     range(20), tqdm_class=tqdm_auto):
        pass
    for _ in product(range(1000), range(7),
                     range(20), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:35:29.320434
# Unit test for function product
def test_product():
    from .tests_tqdm import with_progbar

    assert with_progbar(lambda n: n, product,
                        range(4), range(4), range(4)) == 4 ** 3

# Generated at 2022-06-12 14:35:34.053982
# Unit test for function product
def test_product():
    assert list(product([1, 2], repeat=3, tqdm_class=tqdm_auto)) == list(
        itertools.product([1, 2], repeat=3))
    assert list(product(range(5), repeat=2, tqdm_class=tqdm_auto)) == list(
        itertools.product(range(5), repeat=2))
# Test suite

# Generated at 2022-06-12 14:35:41.555104
# Unit test for function product
def test_product():
    """
    Unit test for function `tqdm.itertools.product`.
    """
    from ..std import StringIO
    from numpy import prod
    all_kwargs = dict()

# Generated at 2022-06-12 14:35:47.643033
# Unit test for function product
def test_product():
    """Unit test for product"""
    from .main import tqdm
    from .gui import tqdm_gui

    from .utils import _term_move_up
    from nose.tools import assert_equal

    # This is just a smoke test
    for tqdm_cls in [tqdm, tqdm_gui]:
        for i in tqdm_cls.product([[], [1], [1, 2]], [["a", "b"], [], [None]]):
            pass
        assert_equal(_term_move_up() + '\x1b[2A', tqdm_cls.write().strip())