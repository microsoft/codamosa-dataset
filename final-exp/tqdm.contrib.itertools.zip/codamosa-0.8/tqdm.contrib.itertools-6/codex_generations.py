

# Generated at 2022-06-12 14:27:13.538975
# Unit test for function product
def test_product():
    import random
    import itertools
    print('Testing function `tqdm.itertools.product`...')
    input1 = [1, 2, 3, 4, 5]
    input2 = [1, 2, 3, 4, 5]
    output1 = product(input1, input2)
    output2 = itertools.product(input1, input2)
    assert id(output1) != id(output2)
    assert list(output1) == list(output2)
    output3 = product(input1, input2, tqdm_class=tqdm_auto)
    assert output3.total == 25
    assert list(output3) == list(output2)
    input1 = [1, 2, 3, 4, 5]
    input2 = list(range(10))
    output1 = product

# Generated at 2022-06-12 14:27:18.121771
# Unit test for function product
def test_product():
    """Test for function ``product``."""
    from ..utils import _range_  # pylint: disable=protected-access

    assert sum(1 for _ in product(_range_(5), _range_(5))) == 25

    total = 5
    for i, j in product(_range_(5), _range_(5),
                        tqdm_class=tqdm_auto, total=total):
        assert i * 5 + j < total

# Generated at 2022-06-12 14:27:21.912948
# Unit test for function product
def test_product():
    from numpy.random import random
    exp = [i*np.prod(n) for i, n in enumerate(random(10))]

    act = 0
    for i in tqdm.product(range(int(n)) for n in random(10)):
        act += 1
    assert exp == act

# Generated at 2022-06-12 14:27:29.297391
# Unit test for function product
def test_product():
    from ..std import ANY, NO_COLOR, tqdm_notebook

    with tqdm_notebook(
            total=1, leave=False, ascii=True, desc="T") as t:
        try:
            iterable = range(10)
            list(product(iterable, iterable, iterable))
        except ImportError:
            t.update()
        else:
            raise ValueError()

    with tqdm_notebook(
            total=1, leave=False, ascii=True, desc="T") as t:
        try:
            iterable = range(10)
            list(product(iterable, iterable, iterable, tqdm_class=ANY))
        except ValueError:
            t.update()
        else:
            raise ValueError()


# Generated at 2022-06-12 14:27:38.837687
# Unit test for function product
def test_product():
    """
    Test that product works as expected.
    """
    import itertools
    import numpy as np

    for i in range(3):
        for j in range(3):
            for k in range(3):
                for l in range(3):
                    gen = product(range(i), range(j), range(k), range(l),
                                  tqdm_class=tqdm_auto)
                    assert gen == itertools.product(range(i), range(j),
                                                    range(k), range(l))
                    assert gen == product(range(i), range(j), range(k), range(l))

    gen = product(list(range(9)), list(range(9)), list(range(9)),
                  tqdm_class=tqdm_auto)
    assert gen == itert

# Generated at 2022-06-12 14:27:47.341109
# Unit test for function product
def test_product():
    """
    Test module.
    """
    from .._version import __version__
    from ..utils import _term_move_up

    # Test basic
    with tqdm_auto(unit='B', unit_scale=True, miniters=1,
                   desc="Basic test") as t:
        for i in product(['a', 'b', 'c', 'd'], [1, 2, 3]):
            t.update()
    try:
        _term_move_up()
    except Exception:
        pass

    # Test nested

# Generated at 2022-06-12 14:27:53.581359
# Unit test for function product
def test_product():
    """Test the module function `product`"""
    # Test when len() is implemented
    total = 0
    for _ in product([1, 2, 3], ['a', 'b', 'c']):
        total += 1
    assert total == 9

    # Test when len() is not implemented, but total is provided
    total = 0
    for _ in product(range(9), tqdm_class=None, total=9):
        total += 1
    assert total == 9

# Generated at 2022-06-12 14:27:59.035470
# Unit test for function product
def test_product():
    from .utils import BaseTestTqdm

    class TestProductTqdm(BaseTestTqdm, unittest.TestCase):
        def _gen_iterable(self, **kwargs):
            return product(range(100),
                           range(150),
                           range(200),
                           tqdm_class=self.tqdm_cls, **kwargs)

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-12 14:28:03.269164
# Unit test for function product
def test_product():
    try:
        from pytest import raises

        p = product(
            range(5),
            range(5, 10),
            range(10, 15),
            range(15, 20),
            tqdm_class=tqdm_auto)
        assert list(p) == [(i, j, k, l) for i in range(5)
                           for j in range(5, 10)
                           for k in range(10, 15)
                           for l in range(15, 20)]

        with raises(KeyError):
            p = product(range(5), bar="ascii")
    except ImportError:
        pass

# Generated at 2022-06-12 14:28:11.898489
# Unit test for function product
def test_product():
    from .utils import _range

    def func(a, b, c):
        return (10 ** a) * (10 * b + c)

    assert list(product(*map(_range, [3, 2, 1]))) == list(
        map(lambda x: (x[0], x[1], x[2]),
            itertools.product(range(3), range(2), range(1))))


# Generated at 2022-06-12 14:28:24.269799
# Unit test for function product
def test_product():
    """
    Unit tests for product.
    """
    import sys
    import math  # noqa

    # test_equivalent
    assert list(
        product([], [], tqdm_class=lambda l: l)) == \
        list(itertools.product([], []))
    assert list(
        product([1, 2], [3, 4], tqdm_class=lambda l: l)) == \
        list(itertools.product([1, 2], [3, 4]))
    assert list(
        product([1, 2], [3, 4], [5, 6], tqdm_class=lambda l: l)) == \
        list(itertools.product([1, 2], [3, 4], [5, 6]))

    # test_monitor_total
    total = 100

# Generated at 2022-06-12 14:28:29.389283
# Unit test for function product
def test_product():
    l = [1, 2, 3]
    result = [i for i in product(l, repeat=2, tqdm_class=None)]
    assert result == [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)], \
        "product() failed to generate correct cartesian product"


if __name__ == "__main__":
    pass

# Generated at 2022-06-12 14:28:38.370107
# Unit test for function product
def test_product():
    from .tests.utils import TestUnit

    iteration = lambda: product(range(1000), range(1000), tqdm_class=TestUnit)
    assert next(iteration()) == (0, 0)
    TestUnit.bar_desc = ''
    assert next(iteration()) == (1, 0)
    TestUnit.bar_desc = ''
    assert next(iteration()) == (2, 0)
    TestUnit.bar_desc = ''
    assert next(iteration()) == (3, 0)
    TestUnit.bar_desc = ''

    # Test total
    TestUnit.bar_total = 1000000
    for _ in range(4):
        next(iteration())
        TestUnit.bar_desc = ''
    TestUnit.bar_total = None

    # Test optional args

# Generated at 2022-06-12 14:28:45.293518
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup

    with_setup(tqdm_auto(total=0).close)

    a1 = [1, 2, 3]
    a2 = [5, 6]
    # list(zip(*product(a1, a2))) == list(itertools.product(a1, a2))
    assert list(zip(*product(a1, a2))) == list(itertools.product(a1, a2))
    # list(product(a1, a2, tqdm_class=None)) == list(itertools.product(a1, a2))
    assert list(product(a1, a2, tqdm_class=None)) == list(
        itertools.product(a1, a2))
    # list(product(a1, tqdm

# Generated at 2022-06-12 14:28:52.446451
# Unit test for function product
def test_product():
    from tqdm.test import with_unit_option
    from tqdm import tqdm

    from multiprocessing import RLock
    rlock = RLock()

# Generated at 2022-06-12 14:29:02.084179
# Unit test for function product
def test_product():
    import numpy as np
    import sys
    import os
    import itertools
    import warnings

    warnings.filterwarnings('ignore',
                            message='From version 0.18, '
                                    'the only valid positional argument will '
                                    'be `total`, and passing any positional '
                                    'arguments without an explicit '
                                    '\"total\" keyword argument is deprecated.')
    # "Nested product"
    for a in product(range(4), ['a', 'b'], [None, 1.0]):
        pass

    # "Nested product" with total
    for a in product(range(4), ['a', 'b'], [None, 1.0], total=8):
        pass

    # "Empty product"
    for a in product(*([],) * 5):
        pass

    # "

# Generated at 2022-06-12 14:29:07.834521
# Unit test for function product
def test_product():
    from ..utils import _range
    from .internal import format_sizeof
    s = 0
    for i in product(range(1000), repeat=4, ascii=True, mininterval=0.01,
                     miniters=1, postfix=['prod', 'size'],
                     unit_scale=True, unit_divisor=1000, ncols=200,
                     bar_format='{desc}: {percentage:3.0f}%|{bar}|{n_fmt}/{total_fmt}',
                     desc='Test (product)', leave=True):
        s += i[0] + i[1] + i[2] + i[3]
    assert s == 999000000
    assert len(format_sizeof(s, 'B'))

# Generated at 2022-06-12 14:29:17.435933
# Unit test for function product
def test_product():
    """Test function `tqdm.tqdm_itertools.product`"""
    from ..utils import FormatCustomText
    from ..std import tqdm_imap, tqdm_map

    with tqdm_imap(product, [range(10, 1, -1)],
                   bar_format=FormatCustomText("1234567890")) as t:
        assert not t.disable
        assert t.n == 0
        assert t.total == 10
        assert t.last_print_n == 0
        assert t.last_print_t == None
        assert t.last_print_ts == None
        for i in t:
            assert not t.disable
            assert t.total == 10
            if t.n == 1:
                t.set_description("foo", True)

# Generated at 2022-06-12 14:29:21.381069
# Unit test for function product
def test_product():
    import numpy as np
    assert [i for i in product(np.arange(20))] == [(i,) for i in range(20)]
    assert [i for i in product(np.arange(2), np.arange(3))] == list(
        itertools.product(np.arange(2), np.arange(3)))
    assert [i for i in product(np.arange(2), np.arange(3), np.arange(10))] == list(
        itertools.product(np.arange(2), np.arange(3), np.arange(10)))

# Generated at 2022-06-12 14:29:30.272854
# Unit test for function product
def test_product():
    from .tqdm import trange
    import numpy as np

    # Test with trange
    for I in product([1, 2, 3], list(range(4)), tqdm=trange):
        assert len(I) == 2
        assert I[0] in [1, 2, 3]
        assert I[1] in range(4)

    # Test with range
    for I in product([1, 2, 3], range(4), tqdm=range):
        assert len(I) == 2
        assert I[0] in [1, 2, 3]
        assert I[1] in range(4)

    # Test with product_range
    for i in product(range(10), range(10), range(10), tqdm=range):
        assert len(i) == 3
        assert i[0]

# Generated at 2022-06-12 14:29:35.363816
# Unit test for function product
def test_product():
    """Test product"""
    p1 = product("ABCD", "xy", tqdm_class=tqdm_auto)
    assert list(p1) == list(itertools.product("ABCD", "xy"))
    p2 = product("ABCD", "xy", tqdm_class=tqdm_auto, total=0)
    assert list(p2) == list(itertools.product("ABCD", "xy"))

# Generated at 2022-06-12 14:29:38.740967
# Unit test for function product
def test_product():
    import pytest
    for k in range(3):
        for C in [list, itertools.chain.from_iterable, product]:
            for A, B in [([1, 2], [3, 4]),
                         (tqdm_auto(range(100)), tqdm_auto(range(100)))]:
                assert pytest.approx(
                    list(itertools.product(A, B))) == list(C(A, B))

# Generated at 2022-06-12 14:29:47.145436
# Unit test for function product
def test_product():
    from random import randint, shuffle
    from numpy import prod
    from ..utils import FormatCustomTextTestResult
    import unittest
    import sys

    class Tests(unittest.TestCase):
        def test_nested(self):
            """Test for nested product loop"""
            for i in product(product(range(10), range(10)),
                             product(range(10), range(10))):
                pass

        def test_nested_args(self):
            """Test for nested product loop with different arguments"""
            for i in product(range(10), product(range(10), range(10))):
                pass

        def test_misc(self):
            """Test for product of misc iterables"""
            for i in product(["a", "b"], [1, 2], "ab"):
                pass


# Generated at 2022-06-12 14:29:55.822752
# Unit test for function product
def test_product():
    # Check that we can use tqdm like product()
    rough_estimate = int(1e6)
    count = 0
    # Check that we can use tqdm like product()
    for _ in product('abcd', repeat=6, desc="Test product 1",
                     total=rough_estimate):
        count += 1
    assert count == rough_estimate

    # Check that we can use tqdm like product(), but with a tracker
    for i in product('abcd', repeat=5, tqdm_class=tqdm_auto.trange,
                     desc="Test product 2"):
        count += 1
        assert len(''.join(i)) == 5

    # Check that we can use tqdm like product(), but with no total estimate

# Generated at 2022-06-12 14:30:04.203574
# Unit test for function product
def test_product():
    """Unit test for product"""

    # Verify basic product
    assert list(product([1, 2], [3, 4], tqdm_class=tqdm_auto)) == \
        [
            (1, 3),
            (1, 4),
            (2, 3),
            (2, 4),
        ]

    # Verify progress bar
    p = list(product(
        [1, 2], [3, 4],
        tqdm_class=tqdm_auto, unit="s", miniters=1, mininterval=0.01))
    assert p == [
        (1, 3),
        (1, 4),
        (2, 3),
        (2, 4),
    ]

    # Verify progress bar total

# Generated at 2022-06-12 14:30:12.701902
# Unit test for function product
def test_product():
    from .._tqdm_test_mate import _tw
    assert list(product('AB', 'cd')) == [('A', 'c'), ('A', 'd'), ('B', 'c'),
                                         ('B', 'd')]
    assert list(product('AB', 'cd', tqdm_class=_tw)) == [('A', 'c'), ('A', 'd'),
                                                         ('B', 'c'), ('B', 'd')]
    assert list(product()) == [()]
    assert list(product([])) == []
    assert list(product(['A', 'B'], repeat=1)) == [('A',), ('B',)]

# Generated at 2022-06-12 14:30:18.215718
# Unit test for function product
def test_product():
    assert list(product(range(10), [2], [3])) == list(itertools.product(range(10), [2], [3]))
    assert list(product(range(10), [2], [3], tqdm_class=None)) == list(itertools.product(range(10), [2], [3]))
    assert list(product(range(10), [2], [3], tqdm_class=lambda x: x)) == list(itertools.product(range(10), [2], [3]))

# Generated at 2022-06-12 14:30:23.839988
# Unit test for function product
def test_product():
    for i in product(range(5), range(5), range(5)):
        assert len(i) == 3
    for i in product(range(5), range(5), range(10), tqdm_class=tqdm_auto):
        assert len(i) == 3
    for i in product(range(5), range(10), tqdm_class=tqdm_auto):
        assert len(i) == 2
    for i in product(range(10), tqdm_class=tqdm_auto):
        assert len(i) == 1

# Generated at 2022-06-12 14:30:31.132424
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..auto import trange
    from ..utils import FormatCustomText
    from ..utils import format_sizeof

    # Setup variables
    import sys

    arrays = [range(10), range(10), range(10)]

    # Test product

# Generated at 2022-06-12 14:30:38.148103
# Unit test for function product
def test_product():
    from ._utils import _range
    from ._utils import _supports_unicode
    from .pandas import trange

    for tqdm in [tqdm_auto, trange]:
        for iterable in [_range(1), _range(5), _range(10)]:
            for f in [len, sum]:
                assert f(list(tqdm(iterable))) == f(iterable)
                assert f(list(tqdm(iterable, total=f(iterable)))) == f(iterable)

        if not _supports_unicode():
            return


# Generated at 2022-06-12 14:30:45.624471
# Unit test for function product
def test_product():
    """
    Unit test for function tqdm_product.
    """
    from .tests import pretest_posttest
    s = """\
from __future__ import division, print_function
import sys
import time
from tqdm.autonotebook import tqdm
from tqdm.utils import product


for i in product(range(10 ** 3), range(10 ** 2)):
    for _ in range(10):
        time.sleep(0.01)
    sys.stdout.write('.')
"""
    pretest_posttest(s, '.' * 10 * 10 * 1000 * 100)

# Generated at 2022-06-12 14:30:53.687213
# Unit test for function product
def test_product():
    """Test to verify that product works"""
    count = 0
    total = 1
    lens = (3, 4)
    for i in product("ab", "1234", total=9):
        count += 1
    assert count == 9
    count = 0
    for i in product("ab", "1234"):
        count += 1
    assert count == 9
    count = 0
    for i in product("ab", "1234", tqdm_class=None):
        count += 1
    assert count == 9
    count = 0
    for i in product("ab", "1234", tqdm_class=lambda x: x):
        count += 1
    assert count == 9

# Generated at 2022-06-12 14:31:00.365409
# Unit test for function product
def test_product():
    """Tests the `product` function"""
    import random
    # Test without total
    iterable = list(range(int(random.random() * 9 + 1)))
    for _ in product(iterable, iterable):
        pass
    for _ in product(iterable, iterable, tqdm_class=tqdm_auto):
        pass
    # Test with total
    for _ in product(iterable, iterable, total=len(iterable)**2):
        pass
    for _ in product(iterable, iterable, total=len(iterable)**2,
                     tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:31:02.489253
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from .tests import pretest_posttest

    @pretest_posttest
    def foo():
        for _ in product('abcde', repeat=4):
            pass

    foo()
    foo()

# Generated at 2022-06-12 14:31:04.502532
# Unit test for function product
def test_product():
    try:
        from .tests_tqdm import pretest_posttest
        assert pretest_posttest(product, (
            ['abc', range(4)],
            {'tqdm_class': lambda ** kwargs: None},
        ))
    except ImportError:
        pass

# Generated at 2022-06-12 14:31:08.445055
# Unit test for function product
def test_product():
    from itertools import product as itertools_product
    for x in product(range(10), range(10), range(10)):
        assert x in itertools_product(range(10), range(10), range(10))

# Generated at 2022-06-12 14:31:13.830082
# Unit test for function product
def test_product():
    import numpy as np
    assert np.allclose(
        list(product(
            xrange(100), xrange(100), tqdm_class=None)),
        list(itertools.product(
            xrange(100), xrange(100))))
    assert np.allclose(
        list(product(
            xrange(500), xrange(500), tqdm_class=None)),
        list(itertools.product(
            xrange(500), xrange(500))))

# Generated at 2022-06-12 14:31:21.228372
# Unit test for function product
def test_product():
    """Test the itertools.product wrapper"""
    from nose import with_setup
    from nose.tools import assert_equal
    from .tests_tqdm import pretest, posttest

    @with_setup(pretest, posttest)
    def wrapper():
        """Test the itertools.product wrapper"""
        from operator import mul
        from random import randint, shuffle
        from itertools import product, starmap

        def random_list(n, lo, hi):
            """Returns a random list of size n with elements between lo and hi"""
            return [randint(lo, hi) for _ in range(n)]


# Generated at 2022-06-12 14:31:27.451995
# Unit test for function product
def test_product():
    """Test"""
    import random
    import sys
    random.seed(123)

# Generated at 2022-06-12 14:31:32.683800
# Unit test for function product
def test_product():
    import random
    import string

    r = random.Random()
    res = r.sample(string.ascii_letters, 10)
    res_ = []
    for _ in product(res, "ABC", tqdm_class=tqdm_auto):
        res_.append(_)
    assert(res_ == list(itertools.product(res, "ABC")))

# Generated at 2022-06-12 14:31:35.957769
# Unit test for function product
def test_product():
    import numpy
    for i in product(range(4), repeat=4):
        assert numpy.prod(i) == sum(i)

# Generated at 2022-06-12 14:31:44.499176
# Unit test for function product
def test_product():
    import numpy as np
    assert_array_equal = np.testing.assert_array_equal
    # Ensure that product() is consistent with the itertools module

# Generated at 2022-06-12 14:31:49.072662
# Unit test for function product
def test_product():
    from .utils import FormatStdout, _range

    with FormatStdout() as fs:
        for _ in product(_range(), _range()):
            pass
        assert fs.unstripped()[:4] == "[(0, 0", "bad product result"

        for _ in product(_range(), _range(), _range()):
            pass
        assert fs.unstripped()[:4] == "[(0, 0", "bad product result"

# Generated at 2022-06-12 14:31:56.666450
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from random import randint

    # Test with no-generator return
    assert list(product(range(10))) == [
        (0,), (1,), (2,), (3,), (4,), (5,), (6,), (7,), (8,), (9,)]
    # Test with generator return
    def g():
        yield 1
        yield 2

# Generated at 2022-06-12 14:32:01.904742
# Unit test for function product
def test_product():
    """Test for the fast product recipe."""
    from .tests import tests, _range

    # Test with no tqdm arguments
    for n, kwargs in zip(_range(3), tests[:3]):
        for arg in itertools.product(*_range(n), **kwargs):
            pass

    # Test with tqdm arguments
    tqdm_kwargs = {"ascii": True, "desc": "test", "leave": True,
                   "dynamic_ncols": True}
    for n, kwargs in zip(_range(3), tests[:3]):
        for arg in itertools.product(*_range(n), **kwargs):
            pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:32:04.373455
# Unit test for function product
def test_product():
    assert list(product([], repeat=3)) == []
    assert list(product([1], repeat=2)) == [(1, 1)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]

# Generated at 2022-06-12 14:32:11.463043
# Unit test for function product
def test_product():
    import sys

    from ...tests.benchmarks import Bench
    from .utils import FormatMixin

    class FormatMixin2(FormatMixin):  # pragma: no cover
        @classmethod
        def validate(cls):  # pragma: no cover
            if hasattr(cls, 'active'):
                cls.active = False
            else:
                cls.active = True
            FormatMixin.validate()

        @classmethod
        def __exit__(cls, *exc):  # pragma: no cover
            FormatMixin.__exit__(*exc)
            if hasattr(cls, 'active'):
                del cls.active

    class Bench2(Bench):  # pragma: no cover
        def test_product(self):
            """
            Unit test for function `product`.
            """

# Generated at 2022-06-12 14:32:16.183084
# Unit test for function product
def test_product():
    """
    Unit test.

    Test product() against itertools.product().
    """
    args = ((1, 2), (3, 4), (5, 6))
    result = set(product(*args))
    expected = set(itertools.product(*args))
    assert result == expected
    assert repr(result) == repr(expected)  # repr()

# Generated at 2022-06-12 14:32:20.304874
# Unit test for function product
def test_product():
    import pytest
    from sys import version
    py2 = version[0] == '2'
    if py2:
        from itertools import imap
    else:
        imap = map

    def f(n):
        return n ** n
    it = product(range(10), range(10))
    ans = imap(f, it)
    if py2:
        ans = list(ans)
    assert len(ans) == 10000

# Generated at 2022-06-12 14:32:28.742044
# Unit test for function product
def test_product():
    from nose.tools import assert_raises
    from random import randrange

# Generated at 2022-06-12 14:32:35.112613
# Unit test for function product
def test_product():
    """Test for `itertools.product`"""
    import numpy as np
    assert np.array_equal(np.array(tuple(product(range(2), repeat=2))),
                          np.array([[0, 0], [0, 1], [1, 0], [1, 1]]))
    assert np.array_equal(np.array(tuple(product(range(2), range(2)))),
                          np.array([[0, 0], [0, 1], [1, 0], [1, 1]]))

# Generated at 2022-06-12 14:32:44.138729
# Unit test for function product
def test_product():
    from itertools import product as orig_product
    from numpy.random import randint
    assert list(orig_product(*[('a', 'b'), (1, 2), (3, 4)])) == [
        ('a', 1, 3),
        ('a', 1, 4),
        ('a', 2, 3),
        ('a', 2, 4),
        ('b', 1, 3),
        ('b', 1, 4),
        ('b', 2, 3),
        ('b', 2, 4)]
    # Check that order is preserved
    for i in range(10):
        max_value = randint(1, 10)

# Generated at 2022-06-12 14:32:50.761524
# Unit test for function product
def test_product():
    """Test that the output is the same, uniform distribution of data"""
    import numpy as np
    from scipy.stats.distributions import uniform
    # we sample from a uniform distribution
    sample_unif = uniform.rvs(loc=0, scale=1, size=1000)
    # we sample from the same uniform using itertools.product
    sample_product = []
    for _ in tqdm_auto(product(sample_unif, repeat=2), total=len(sample_unif)**2):
        sample_product.append(_)

    assert np.allclose(uniform.rvs(loc=0, scale=1, size=len(sample_product)), sample_product)

# Generated at 2022-06-12 14:32:55.656030
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # import tqdm
    assert list(product('ABCD', 'xy', tqdm_class=tqdm_auto)) == list(itertools.product('ABCD', 'xy'))
    assert list(product('ABCD', None, tqdm_class=tqdm_auto)) == list(itertools.product('ABCD', None))
    assert list(product('ABCD', [], tqdm_class=tqdm_auto)) == list(itertools.product('ABCD', []))
    assert list(product('ABCD', 'xy', tqdm_class=tqdm_auto, mininterval=1)) == list(itertools.product('ABCD', 'xy'))



# Generated at 2022-06-12 14:33:04.580174
# Unit test for function product
def test_product():
    """
    Unit tests of the `itertools.product` wrapper.
    """
    from .utils import closing, StringIO
    from . import trange

    with closing(StringIO()) as our_file:
        for _ in trange(4, file=our_file):
            pass
        assert our_file.getvalue() == "0it [00:00, ?it/s]\n1it [00:00, ?it/s]\n2it [00:00, ?it/s]\n3it [00:00, ?it/s]\n"

    with closing(StringIO()) as our_file:
        list(product(range(4), file=our_file))

# Generated at 2022-06-12 14:33:08.125102
# Unit test for function product
def test_product():
    import numpy as np
    x = range(1000)
    y = range(1000)
    l = []
    for i in product(x, y):
        l.append(i)
    l = np.array(l)
    assert len(l) == len(x) * len(y)

# Generated at 2022-06-12 14:33:11.252641
# Unit test for function product
def test_product():
    try:
        from nose.tools import assert_equal
    except:
        return
    assert_equal(
        product([i for i in range(10)], [i for i in range(20)]),
        itertools.product([i for i in range(10)], [i for i in range(20)]))

# Generated at 2022-06-12 14:33:16.278706
# Unit test for function product
def test_product():
    """Unit test for `product`."""
    from ..utils import any_iter, _range
    
    with tqdm_auto(total=121) as rng:
        for i in product(
            _range(3),
            _range(4),
            _range(5),
            tqdm_class=tqdm_auto,
            leave=False,
            desc='Testing product'
        ):
            rng.update()
    assert rng.n == 121

# Generated at 2022-06-12 14:33:24.212933
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from .utils import BaseTestMixin

    class Test(BaseTestMixin):
        def test_product(self):
            a = range(3)
            b = range(3)
            c = range(3)
            prog = product(a, b, c)
            out = [i for i in prog]

# Generated at 2022-06-12 14:33:33.338507
# Unit test for function product
def test_product():
    import nose.tools as nt
    if tqdm_auto.__name__ == 'tqdm_notebook':
        from IPython.html import widgets
        from IPython.display import display

        nt.assert_is_instance(tqdm_auto(range(10),
                                        leave=False).widget,
                              widgets.IntProgress)

        nt.assert_is_instance(tqdm_auto(range(10),
                                        leave=False).widget,
                              widgets.IntProgress)

        with tqdm_auto(range(10), leave=False) as t:
            nt.assert_is_instance(t.widget, widgets.IntProgress)

        display(tqdm_auto(range(10), leave=False))
        display(tqdm_auto(range(10), leave=False))

# Generated at 2022-06-12 14:33:43.046003
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    from numpy.random import randint
    from numpy.random import rand
    from numpy import prod
    from numpy import array
    from numpy import allclose
    from numpy import arange

    # Basic test
    a = randint(0, 50, size=25)
    b = randint(0, 50, size=25)
    c = randint(0, 50, size=25)
    total = len(a)*len(b)*len(c)

    result = array(list(product(a, b, c)))
    assert allclose(result, array(list(itertools.product(a, b, c))))

# Generated at 2022-06-12 14:33:50.210840
# Unit test for function product
def test_product():
    """Example of using `product`"""
    # Example 1:
    for i in product(['a', 'b'], repeat=3, tqdm_class=tqdm_auto):
        pass
    # Example 2:
    for i in product(range(3), repeat=3):
        pass
    # Example 3:
    for i in product(range(3), range(3), range(3), range(3), range(3),
                     range(3), range(3), range(3), range(3), range(3),
                     range(3), range(3), range(3), range(3), range(3)):
        pass

# Generated at 2022-06-12 14:33:57.485085
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof

    for i in product("abcde", repeat=4):
        assert True
    for i in product("abcde", repeat=4, tqdm_class=None):
        assert True

    from math import factorial
    from .constants import SimpleNamespace
    test = SimpleNamespace(
        n_iters=2,
        repeat_range=range(3, 9),
        total_range=("1", "10", "1e1", "1e2", "1e3", "1e4", "1e5", "1e6",
                     "1e7", "1e8", "1e9"),
    )

# Generated at 2022-06-12 14:33:59.548571
# Unit test for function product
def test_product():
    from .tqdm_test import with_setup, pretest, posttest

    @with_setup(pretest, posttest)
    def _test():
        for i, _ in enumerate(product('ABC', range(2))):
            pass
        assert i == 6

# Generated at 2022-06-12 14:34:04.676651
# Unit test for function product
def test_product():
    try:
        from ..utils import format_sizeof
    except (ImportError, ValueError):
        pass
    else:
        iterables = (range(0, 4), list('abc'))


# Generated at 2022-06-12 14:34:07.858209
# Unit test for function product
def test_product():
    res = []
    for i in product(["a", "b", "c"], [1, 2, 3], tqdm_class=tqdm_auto):
        res.append(i)
    assert(res == [('a', 1), ('a', 2), ('a', 3),
                   ('b', 1), ('b', 2), ('b', 3),
                   ('c', 1), ('c', 2), ('c', 3)])

# Generated at 2022-06-12 14:34:11.410600
# Unit test for function product
def test_product():
    """Unit test for function product"""
    res = list(product(range(3), range(3)))
    assert res == [(0, 0), (0, 1), (0, 2),
                   (1, 0), (1, 1), (1, 2),
                   (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-12 14:34:20.735455
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    try:
        from unittest import mock
    except ImportError:
        import mock
    import sys

    if sys.version_info[0] == 2:
        range = xrange

    with mock.patch('tqdm.itertools.tqdm_class', tqdm_auto):
        with mock.patch('sys.stderr') as stderr:
            for _ in tqdm.product(range(10)):
                pass
            stderr.write.assert_called_with(
                '10it [00:00, ?it/s]\n')

        with mock.patch('sys.stderr') as stderr:
            for _ in tqdm.product(range(10), range(3)):
                pass
           

# Generated at 2022-06-12 14:34:28.344312
# Unit test for function product
def test_product():
    """
    Test product by comparing it with `itertools.product` and testing its
    `total` argument.
    """
    try:
        import numpy as np
    except ImportError:
        return
    assert list(product(['a', 'b'], repeat=2)) == list(itertools.product(['a', 'b'], repeat=2))
    assert list(product(['a', 'b'], repeat=2, tqdm_class=tqdm_auto.tqdm)) == list(itertools.product(['a', 'b'], repeat=2))
    assert list(product([np.array(['a', 'b']), np.array([0, 1])], repeat=2)) == list(
        itertools.product(['a', 'b'], [0, 1]))

# Generated at 2022-06-12 14:34:35.812333
# Unit test for function product
def test_product():

    from ..utils import FormatCustomText

    iterables = range(20), range(20), range(20)
    _check_custom_len(itertools.product(*iterables),
                      product(*iterables),
                      FormatCustomText("PROD"),
                      "PROD |#--------- |"
                      "8.3k/20.0k [00:00<00:00, 49.6ki/s]")
    assert 'PRODUCT' in repr(product)

    iterables = range(20)
    _check_custom_len(itertools.product(*iterables),
                      product(*iterables),
                      FormatCustomText("PROD"),
                      "PROD |#--------- |"
                      "1.0k/20.0k [00:00<00:00, 21.3ki/s]")


# Generated at 2022-06-12 14:34:47.426383
# Unit test for function product
def test_product():
    """
    Test function product
    """
    import numpy as np
    test = np.zeros((2, 2, 2), dtype=np.int)
    for (i, j, k) in product(range(2), range(2), range(2)):
        test[i, j, k] = i * 4 + j * 2 + k
    assert np.all(test == np.arange(8, dtype=np.int).reshape(2, 2, 2))

# Generated at 2022-06-12 14:34:52.042866
# Unit test for function product
def test_product():
    import sys
    import mock

    with mock.patch.object(sys, 'stdout', mock.MagicMock()) as mock_stdout:
        list(product(range(3), range(3), tqdm_class=tqdm_auto, file=sys.stdout))

        assert mock_stdout.write.called
        assert mock_stdout.flush.called
    pytest_helper.repr_runner({
        'name': 'test_product',
        'func': test_product,
        'description': 'Test `product` function',
        'trigger': ('tqdm_itertools', 'itertools', 'product'),
        'param_generator': True,
    })

# Generated at 2022-06-12 14:35:00.007671
# Unit test for function product
def test_product():
    iter_a = list(range(10))
    iter_b = list(range(10))
    iter_c = list(range(10))

    res = list(product(iter_a, iter_b, iter_c))
    assert res == list(itertools.product(iter_a, iter_b, iter_c))

    res = list(product(iter_a, iter_b, iter_c, tqdm_class=tqdm_auto))
    assert res == list(itertools.product(iter_a, iter_b, iter_c))

    res = list(product(iter_a, iter_b, iter_c, tqdm_class=tqdm_auto,
                       total=10))

# Generated at 2022-06-12 14:35:05.498864
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    for i in product(range(2), range(5), range(9)):
        pass
    for i in product(range(2), range(5), range(9), tqdm_class=None):
        pass
    for i in product(range(2), range(5), range(9), total=42):
        pass
    assert_equal(i, (1, 4, 8))

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-12 14:35:14.202725
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from .utils import FormatStub as FS, StringIO

    # check that the tqdm package is available
    # otherwise call normal itertools.product
    try:
        import tqdm
        if hasattr(tqdm, 'auto'):
            assert hasattr(tqdm.auto, 'tqdm')
        else:
            raise ImportError
    except ImportError:
        if 'tqdm_class' in product.__code__.co_varnames:
            pytest.skip('skipping tqdm.auto.utils.product test as tqdm is missing')
        else:
            assert_equal(list(product('ABCD', 'xy')), list(itertools.product('ABCD', 'xy')))
            return

    # check that tqdm

# Generated at 2022-06-12 14:35:21.266071
# Unit test for function product
def test_product():
    # Test ref
    # https://stackoverflow.com/a/13197456/355230
    # https://stackoverflow.com/a/14331794/355230
    def list_product(*args, **kwds):
        "Pure python implementation of itertools.product (for unit test)"
        pools = list(map(tuple, args)) * kwds.get('repeat', 1)
        result = [[]]
        for pool in pools:
            result = [x+[y] for x in result for y in pool]
        for prod in result:
            yield tuple(prod)


# Generated at 2022-06-12 14:35:29.262652
# Unit test for function product
def test_product():
    """Unit test"""
    from ..utils import format_sizeof
    from .utils import format_timesofar

    try:
        from collections import Counter
    except ImportError:
        from .._vendor import Counter
    import time
    import sys

    t0 = time.time()
    for a, b, c in product(range(10), range(20), range(10),
                           desc='(a, b, c)', ascii=True, miniters=1):
        pass
    dt = time.time() - t0
    print(format_timesofar(dt))

    # CORRECTNESS
    counts = Counter()

# Generated at 2022-06-12 14:35:37.839252
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    # Test with counters
    try:
        total = 0
        for e in product(range(2), range(3), range(4)):
            total += 1
        assert total == 2 * 3 * 4
    except:
        raise AssertionError("product: test 1 failed")
    # Test with generators
    try:
        total = 0
        for e in product(range(i) for i in range(2, 5)):
            total += len(e)
        assert total == 2 * 3 * 4
    except:
        raise AssertionError("product: test 2 failed")
    # Test with lists

# Generated at 2022-06-12 14:35:40.970365
# Unit test for function product
def test_product():
    from ..tests import _test_instance

    def product_tester(*iterables, **tqdm_kwargs):
        for _ in product(*iterables, **tqdm_kwargs):
            pass

    test_values = [[] for _ in range(10)]
    _test_instance(product_tester, test_values, test_values)

# Generated at 2022-06-12 14:35:48.554905
# Unit test for function product
def test_product():
    """
    Test that function product() has the same output as itertools.product()
    """
    import pytest

    list1 = [1, 3.2]
    list2 = ['a', 'b', 'c']
    list3 = [0, 'a']

    # Test without a total counter
    test1 = tqdm_class.product(list1, list2)
    iter1 = itertools.product(list1, list2)

    is_proper_iter1 = True
    for a, b in zip(test1, iter1):
        if a != b:
            is_proper_iter1 = False
            break

    if is_proper_iter1:
        assert True
    else:
        assert False

    # Test with a total counter
    test2 = tqdm_class.product

# Generated at 2022-06-12 14:36:07.140097
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert (
        list(product(
            [1, 2, 3],
            tqdm_class=tqdm_auto,
            desc="Testing product",
            miniters=1))
        == list(itertools.product([1, 2, 3])))

# Generated at 2022-06-12 14:36:12.660105
# Unit test for function product
def test_product():
    import numpy as np
    from tqdm.test import avg_test_time, example_test

    def unit_demo():
        for i in product(range(4), range(4),
                         tqdm_class=tqdm_auto,
                         desc="Nested product : ", miniters=1):
            assert i

    avg_test_time(unit_demo, number=100,
                  average_over=10)  # ~2.6s
    example_test("for i in product(range(4),range(4), tqdm_class=tqdm_auto, desc='Nested product : ', miniters=1):")

# Generated at 2022-06-12 14:36:18.700449
# Unit test for function product
def test_product():
    """
    Test for itertools.product.
    """
    li = [[1, 2, 3], [4, 5], [6, 7, 8]]
    # Assert equivalent to itertools.product
    assert list(itertools.product(*li)) == list(product(*li))
    # Assert equivalent to looping over itertools.product
    running_sum = 0
    for i in itertools.product(*li):
        running_sum += 1
    assert running_sum == len(list(product(*li)))

# Generated at 2022-06-12 14:36:26.522976
# Unit test for function product
def test_product():
    """
    Unit tests for function product

    Raises
    ------
    AssertionError
        When unit tests are failed
    """

    from .utils import FormatWrap
    from .utils import StringIO
    from .utils import closing

    def check_product(*args, **kwargs):
        """
        Check the expected and actual outputs of itertools.product()
        """
        expected = []
        for i in itertools.product(*args):
            expected.append(i)
        with closing(StringIO()) as our_file:
            with FormatWrap(our_file, **kwargs) as actual:
                for i in product(*args, **kwargs):
                    actual.append(i)
            assert expected == actual

    check_product('ABCD', 'xy')

# Generated at 2022-06-12 14:36:31.550180
# Unit test for function product
def test_product():
    from sys import version_info as sys_version_info
    if sys_version_info[:2] < (2, 7):
        raise unittest.SkipTest("no yield from in Python 2.6")

    from unittest import TestCase
    import random
    import string

    random.seed(0)

    for tqdm_class in (tqdm_auto, tqdm):

        class Tests(TestCase):

            def setUp(self):
                self.maxDiff = None

            def test_product(self):
                self.assertEqual(
                    list(product(range(n)) for n in range(2, 5)),
                    [list(range(n)) for n in range(2, 5)])


# Generated at 2022-06-12 14:36:39.510311
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..main import tqdm
    assert list(product([1, 2], [3, 4], tqdm_class=tqdm)) == [(1, 3), (1, 4),
                                                              (2, 3), (2, 4)]
    assert list(product([1, 2], [3, 4], [5, 6], tqdm_class=tqdm)) == \
        [(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6),
         (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)]

# Generated at 2022-06-12 14:36:47.101041
# Unit test for function product

# Generated at 2022-06-12 14:36:53.564671
# Unit test for function product
def test_product():
    """
    Test function `product`
    """
    import itertools
    import sys
    import doctest

    import numpy as np

    docs = doctest.DocTestSuite(itertools).__doc__
    exec(docs, globals())
    docs = docs.replace("itertools.", "tqdm.tqdm_itertools.")
    try:
        exec(docs, globals())
    except TypeError:
        # For Python 2.6.5:
        # TypeError: product() takes at most 2 arguments (3 given)
        pass
    else:
        raise AssertionError("tqdm.tqdm_itertools.product should be type "
                             "error for old python")


# Generated at 2022-06-12 14:36:55.933943
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    i = 0
    for j in product(range(2), range(2), tqdm_class=tqdm_auto):
        assert j == (i // 2, i % 2)
        i += 1

# Generated at 2022-06-12 14:37:01.940422
# Unit test for function product
def test_product():
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    assert list(product(range(3), repeat=2)) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2)]
    assert list(product(range(3), repeat=2, tqdm_class=None)) == [(0, 0), (0, 1), (0, 2),
                                                                  (1, 0), (1, 1), (1, 2),
                                                                  (2, 0), (2, 1), (2, 2)]
    assert list(product(range(3))) == [(0,), (1,), (2,)]