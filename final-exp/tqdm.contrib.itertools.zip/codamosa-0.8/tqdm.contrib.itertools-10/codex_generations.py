

# Generated at 2022-06-12 14:27:11.417100
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import tqdm
    # Without total
    a = list(product(range(10),
                     tqdm_class=tqdm.tqdm,
                     total=None))
    assert a == list(itertools.product(range(10), repeat=1))

    # With total
    a = list(product(range(10),
                     tqdm_class=tqdm.tqdm,
                     total=10))
    assert a == list(itertools.product(range(10), repeat=1))

    # Without total
    a = list(product(range(10), range(10),
                     tqdm_class=tqdm.tqdm,
                     total=None))

# Generated at 2022-06-12 14:27:19.674938
# Unit test for function product
def test_product():
    from numpy.random import rand
    from numpy import array
    from numpy.testing import assert_array_equal
    from tqdm import trange
    from tqdm._tqdm.tests.utils import length

# Generated at 2022-06-12 14:27:20.589534
# Unit test for function product
def test_product():
    from .tests import test_product
    test_product()

# Generated at 2022-06-12 14:27:28.316054
# Unit test for function product
def test_product():
    import sys
    try:
        import numpy as np
    except ImportError:
        return
    from ..utils import len_range
    from ..std import product as tqdm_product


# Generated at 2022-06-12 14:27:37.902868
# Unit test for function product
def test_product():
    from os import remove
    from numpy import product, array
    from pandas import concat

    data = [
        ("a", 1, 3),
        ("b", 2, 3),
        ("c", 3, 3)
    ]
    data_ = [
        ("b", 1, 5),
        ("c", 2, 5),
        ("d", 3, 5)
    ]
    data_ = set(data_ + data)

    for order in ["C", "F"]:
        for open_file in [True, False]:
            for read in [False, True]:
                for write in [False, True]:
                    for float_type in [float, int]:
                        filename = "test_product.csv"

                        from pandas import DataFrame

# Generated at 2022-06-12 14:27:40.537658
# Unit test for function product
def test_product():
    import random
    for N in [1, 2, 5]:
        for r in [1, 2, 5]:
            L = [list(range(random.randint(0, N))) for _ in range(r)]
            res = list(product(*L))
            assert res == list(itertools.product(*L))

# Generated at 2022-06-12 14:27:41.998026
# Unit test for function product
def test_product():
    from .tests_collections import test_product

    assert test_product(itertools.product) == test_product(product)

# Generated at 2022-06-12 14:27:51.774052
# Unit test for function product
def test_product():
    """Test for function 'product'"""
    text_input1 = ['ab', 'cd', 'ef']
    text_input2 = ['gh', 'ij', 'kl']
    prod = ('abgh', 'abij', 'abkl', 'cdgh', 'cdij', 'cdkl', 'efgh', 'efij', 'efkl')

    for i in product(text_input1, text_input2):
        assert i in prod
        prod = prod.replace(i, '', 1)

    assert len(prod) == 0
    assert tuple(product((i for i in range(10)))) == tuple(range(10))
    assert tuple(product((i for i in range(10)), repeat=2)) == tuple(itertools.product(range(10), repeat=2))

# Generated at 2022-06-12 14:27:56.705465
# Unit test for function product
def test_product():
    from itertools import product as it_product
    assert list(product('abcd', repeat=2)) == list(it_product('abcd', repeat=2))
    assert list(product(range(3), repeat=2)) == list(it_product(range(3), repeat=2))
    try:
        delattr(product, 'tqdm_metric')
    except AttributeError:
        pass

# Generated at 2022-06-12 14:28:02.033313
# Unit test for function product
def test_product():
    it = product(range(10), range(10))
    l = [i for i in it]
    assert l == [i for i in itertools.product(range(10), range(10))]

    it = product(range(100), range(100), range(100), tqdm_class=tqdm_auto)
    l = [i for i in it]
    assert l == [i for i in itertools.product(range(100), range(100), range(100))]

# Generated at 2022-06-12 14:28:13.102300
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import math
    total = 0
    a = b = c = tqdm_auto(range(10))
    for i in product(a, b, c):
        total += sum(i)
    assert total == 32475
    total = 0
    a = tqdm_auto(range(10))
    b = range(10)
    c = range(10)
    for i in product(a, b, c):
        total += sum(i)
    assert total == 32475
    iterables = [range(i) for i in (1, 2, 3, 4)]
    for n in range(4):
        total = 0
        for i in product(*iterables[:n]):
            total += sum(i)

# Generated at 2022-06-12 14:28:19.687539
# Unit test for function product
def test_product():
    """Test for `itertools.product` wrapper"""
    try:
        iteritems = lambda t: list(t.items())
    except AttributeError:
        iteritems = list
    try:
        itervalues = lambda t: list(t.values())
    except AttributeError:
        itervalues = list

    assert (iteritems(product(range(3), range(3))) ==
            list(itertools.product(range(3), range(3))))
    assert (iteritems(product({'a': 'a', 'b': 'b'})) ==
            list(itertools.product({'a': 'a', 'b': 'b'})))

# Generated at 2022-06-12 14:28:28.857727
# Unit test for function product
def test_product():
    """Unit test for function tqdm.itertools.product()"""
    from .gui import tqdm
    from nose.tools import assert_equal
    assert_equal(list(product(range(4), "abcd", tqdm=tqdm, leave=False)),
                 list(itertools.product(range(4), "abcd")))
    assert_equal(list(product(range(4), "abcd", tqdm=tqdm, leave=True)),
                 list(itertools.product(range(4), "abcd")))
    assert_equal(list(tqdm(product(range(4), "abcd", tqdm=tqdm, leave=False))),
                 list(itertools.product(range(4), "abcd")))

# Generated at 2022-06-12 14:28:37.728163
# Unit test for function product
def test_product():
    import sys
    import math
    import tempfile
    from random import seed, shuffle
    from ..utils import format_sizeof

    # random test
    seed(42)
    res = set()
    for i in range(10):
        for j in range(10):
            for k in range(10):
                res.add((i, j, k))
    iterables = list(map(range, (10, 10, 10)))
    shuffle(iterables)
    prod = product(*iterables, total=1000)
    assert prod is not None
    prod_res = set(prod)
    assert prod_res == res

    # random test 2
    seed(43)
    res = set()

# Generated at 2022-06-12 14:28:44.847039
# Unit test for function product
def test_product():
    from sys import version_info
    from os import linesep
    from ._utils import _range_bar
    _print = py3_print if version_info[0] == 3 else py2_print
    product_ = lambda iterable: list(product(iterable))
    assert product_(range(1)) == [[0]]
    assert product_(range(3), range(3)) == \
        [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]]
    # Test `desc`
    assert [l for l in product(range(9), desc="foo")] == \
        list(product(range(9), desc="foo"))
    # Test `total`

# Generated at 2022-06-12 14:28:50.645938
# Unit test for function product
def test_product():
    try:
        from functools import reduce
    except ImportError:
        from operator import mul
        def reduce(function, iterable):
            return reduce(function, iterable)

    p = product('ABCD', 'xy')
    assert list(p) == [
        ('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
        ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

    p = product(range(2), repeat=3)
    assert list(p) == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                       (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

   

# Generated at 2022-06-12 14:28:56.140345
# Unit test for function product
def test_product():
    from random import randint
    from .tests import _random_gen
    from .utils import format_sizeof
    iterables = [_random_gen(randint(0, 100))
                 for _ in range(randint(1, 4))]
    print("iterables =", [
        [format_sizeof(i) for i in itr] for itr in iterables])

# Generated at 2022-06-12 14:29:04.757600
# Unit test for function product

# Generated at 2022-06-12 14:29:14.407577
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    # Ensure that it behaves like the builtin version
    from sys import version_info
    from itertools import product as it_product
    from six.moves import zip_longest as izip_longest

    # Python 2.x and 3.x
    for i in tqdm_auto.product(*[range(3)] * 3):
        pass
    if version_info[0] == 2:
        for i in tqdm_auto.product(*[xrange(3)] * 3):
            pass
    else:
        for i in tqdm_auto.product(*[range(3)] * 3, tqdm_class=tqdm_auto.trange):
            pass


# Generated at 2022-06-12 14:29:19.373985
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    from .._tqdm import tqdm as tqdm_class
    from .._tqdm import _range
    for A, B, C in product(_range(3), _range(3), _range(3),
                           tqdm_class=tqdm_class):
        pass
    for A, B, C in product(_range(3), _range(3), _range(3),
                           tqdm_class=tqdm_class, unit='item'):
        pass

# Generated at 2022-06-12 14:29:33.347508
# Unit test for function product
def test_product():
    """Test if the `product` function works correctly"""
    list1 = [1, 1, 1, 1]
    list2 = ['a', 'b', 'c', 'd']
    list3 = [1.5, 2.5, 3.5]


# Generated at 2022-06-12 14:29:36.781481
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`
    """
    from numpy.testing import assert_equal

    L = [["Elvis", "Lennon", "Stallone"], ["Presley", "John", "Sly"]]
    result = list(product(*L, tqdm_class=tqdm_auto))
    assert_equal(result[0], ("Elvis", "Presley"))
    result = list(product(*L))
    assert_equal(result[0], ("Elvis", "Presley"))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:29:39.255927
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    result = list(product(range(4), range(4), range(4), tqdm_class=tqdm_auto))
    del result


# Generated at 2022-06-12 14:29:47.950502
# Unit test for function product
def test_product():
    import sys
    import numpy as np

    with tqdm_auto(ascii=True, total=24) as t:
        result = []
        for a in range(1, 4):
            for b in range(1, 4):
                for c in range(1, 4):
                    t.update()
                    result.append((a, b, c))

    def test_prod(it, args, kwargs, ref_size):
        gen = it.product(*args, **kwargs)
        out = list(gen)
        assert len(out) == ref_size, "Failed {0}({1},{2}".format(gen, args, kwargs)
        return out

    try:
        from itertools import product as it_product
    except ImportError:
        it_product = tq

# Generated at 2022-06-12 14:29:54.561253
# Unit test for function product
def test_product():
    """Unit test for product()"""
    from pyprind.tests.common import captured_output
    with captured_output() as (out, err):
        for i in product('AB', '12', tqdm_class=tqdm_auto,
                         desc='Iterating over all pairs'):
            print(i, end=',')
    output = out.getvalue().strip()
    assert (output == '(A, 1),(A, 2),(B, 1),(B, 2),'
            or output == '(A, 1),(B, 1),(A, 2),(B, 2),')

# Generated at 2022-06-12 14:30:02.925993
# Unit test for function product
def test_product():
    """Test `product`."""
    import numpy as np
    from ..utils import format_sizeof
    from .utils import format_timesofar

    it = product(range(10000), range(10), tqdm_class=tqdm_auto)
    assert tuple(it) == tuple(itertools.product(range(10000), range(10)))
    it = product(range(10000), range(10), tqdm_class=tqdm_auto)
    assert tuple(it) == tuple(itertools.product(range(10000), range(10)))
    it = product(range(10000), range(10), tqdm_class=tqdm_auto)
    assert tuple(it) == tuple(itertools.product(range(10000), range(10)))

# Generated at 2022-06-12 14:30:10.851075
# Unit test for function product
def test_product():
    """Test that the product wrapper behaves like itertools"""
    from .itertools import islice

    for i in range(10):
        assert product(range(i)) == itertools.product(range(i))
    for i in range(5):
        for j in range(5):
            assert product(range(i), range(j)) == itertools.product(
                range(i), range(j))

    def ilen(it):
        return sum(1 for i in it)
    assert ilen(product(range(10), repeat=10)) == 100000000
    assert ilen(islice(tqdm_auto(product(range(100), repeat=100)), 1, 11)) == 10

# Generated at 2022-06-12 14:30:13.571535
# Unit test for function product
def test_product():
    """
    Unit tests for product
    """
    import numpy as np
    it = product([1], [2], tqdm_class=None)
    assert next(it) == (1, 2)
    assert len(list(product(np.arange(10), np.arange(10)))) == 100

# Generated at 2022-06-12 14:30:21.953913
# Unit test for function product
def test_product():
    assert list(product(['a', 'b'], [1, 2])) == \
        list(itertools.product(['a', 'b'], [1, 2]))
    assert list(product(['a', 'b'], [1, 2], ['A', 'B'])) == \
        list(itertools.product(['a', 'b'], [1, 2], ['A', 'B']))
    assert list(product('ab', (1, 2))) == \
        list(itertools.product('ab', (1, 2)))
    assert list(product('ab')) == \
        list(itertools.product('ab'))
    assert list(product('')) == \
        list(itertools.product(''))

# Generated at 2022-06-12 14:30:26.775475
# Unit test for function product
def test_product():
    for i in product(range(4), range(4), tqdm_class=tqdm_auto):
        pass
    for i in product(range(2), range(2), range(2), tqdm_class=tqdm_auto):
        pass
    for i in product(range(3), range(3), range(3), range(3),
                     tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:30:37.536943
# Unit test for function product
def test_product():
    for i in product((1, 2), ('a', 'b')):
        print(i)

# Generated at 2022-06-12 14:30:43.161154
# Unit test for function product
def test_product():
    from ._utils import _test_unit_progress_bar

    # Test total
    _test_unit_progress_bar(
        lambda: product(range(3), range(5), range(10)),
        total=150)

    # Test total=None (un-countable iterator)
    _test_unit_progress_bar(
        lambda: product(iter(range(3)), iter(range(5))),
        total=None)

    # Test tqdm_class
    _test_unit_progress_bar(
        lambda: product(range(3), range(5), range(10),
                        tqdm_class=tqdm_auto.tqdm),
        total=150)

# Generated at 2022-06-12 14:30:52.805839
# Unit test for function product
def test_product():
    """Test module `tqdm.itertools`"""

    def test_product_simple():
        iterables = 'ABC', range(3), 'xyz'
        assert list(product(*iterables)) == [
            (x, y, z) for x, y, z in itertools.product(*iterables)]

        iterables = (a, b, c) = 'ABC', 'xyz', range(5)
        assert list(product(*iterables)) == [
            (x, y, z) for x, y, z in itertools.product(*iterables)]

        iterables = (a, b, c, d) = 'ABC', 'xyz', range(2), range(4)

# Generated at 2022-06-12 14:31:00.110137
# Unit test for function product
def test_product():
    p = product('ABCD', 'xy', tqdm_class=tqdm_auto)
    assert next(p) == ('A', 'x')
    assert next(p) == ('A', 'y')
    assert next(p) == ('B', 'x')
    assert next(p) == ('B', 'y')
    assert next(p) == ('C', 'x')
    assert next(p) == ('C', 'y')
    assert next(p) == ('D', 'x')
    assert next(p) == ('D', 'y')
    try:
        next(p)
    except StopIteration:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-12 14:31:04.855483
# Unit test for function product
def test_product():
    """Test the `product` function."""
    from .utils import MatchesStringwiseIn

    def prod(*args, **kwargs):
        with tqdm_auto(*args, **kwargs) as bar:
            for _ in bar:
                pass

    with MatchesStringwiseIn(product, prod, list(range(8)), ascii=True) as m:
        assert "description='8it [00:00, ?it/s]'" in m
    with MatchesStringwiseIn(product, prod, list(range(8))) as m:
        assert "description='8it [00:00, ?it/s]'" in m

# Generated at 2022-06-12 14:31:14.534816
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from .utils import FormatMixin

    def slow_func(x, y):
        return (x, y)

    def fast_func(x, y):
        with tqdm_auto(unit='it', total=len(x)) as t:
            for xv, yv in tqdm_auto.tqdm(product(x, y)):
                yield (xv, yv)
                t.update()

    for x, y in (np.arange(10), np.arange(20)):
        assert list(map(len, (list(product(x, y)), slow_func(x, y), fast_func(x, y)))) == [len(x) * len(y)] * 3

# Generated at 2022-06-12 14:31:21.917092
# Unit test for function product
def test_product():
    assert list(product(range(3), range(3))) == [
        (0, 0), (0, 1), (0, 2),
        (1, 0), (1, 1), (1, 2),
        (2, 0), (2, 1), (2, 2),
    ]

# Generated at 2022-06-12 14:31:27.791044
# Unit test for function product
def test_product():
    from ..utils import ByteStringIO
    with ByteStringIO() as b:
        test = list(product(*[[1, 2, 3], [4, 5], [6, 7]],
                             desc="Foo", file=b))
    assert test == [(1, 4, 6), (1, 4, 7), (1, 5, 6), (1, 5, 7),
                    (2, 4, 6), (2, 4, 7), (2, 5, 6), (2, 5, 7),
                    (3, 4, 6), (3, 4, 7), (3, 5, 6), (3, 5, 7)]
    assert b.getvalue() == \
        b'Foo: 100%|##########| 12/12 [00:00<?, ?it/s]\n'


# Generated at 2022-06-12 14:31:34.370603
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    a = [['a'], ['b', 'c'], ['d', 'e', 'f']]
    a = list(product(*a))
    b = [['a', 'b', 'd'], ['a', 'b', 'e'], ['a', 'b', 'f'],
         ['a', 'c', 'd'], ['a', 'c', 'e'], ['a', 'c', 'f']]
    assert a == b

# Generated at 2022-06-12 14:31:42.998416
# Unit test for function product
def test_product():
    from math import sqrt
    from random import random
    for i in product([None, 1, 2, 3], range(4), range(5), ['x', 'y'], tqdm_class=tqdm_auto):
        assert i[0] in [None, 1, 2, 3]
        assert i[1] in range(4)
        assert i[2] in range(5)
        assert i[3] in ['x', 'y']
    for i in product([None, 1, 2, 3], range(4), range(5), ['x', 'y'], tqdm_class=tqdm_auto, total=None):
        assert i[0] in [None, 1, 2, 3]
        assert i[1] in range(4)
        assert i[2] in range(5)

# Generated at 2022-06-12 14:32:04.426858
# Unit test for function product
def test_product():
    from .typing import range

    for i, j in product(range(4), range(4)):
        assert i <= 3
        assert j <= 3


if __name__ == "__main__":
    from . import util_test
    util_test.test_functions(__file__)

# Generated at 2022-06-12 14:32:11.504232
# Unit test for function product
def test_product():
    import sys
    import types
    import unittest

    try:
        from unittest.mock import MagicMock
        from unittest.mock import patch
    except ImportError:  # Python 2
        from mock import MagicMock
        from mock import patch

    class Test_product(unittest.TestCase):
        def setUp(self):
            self.input = ['ab', 'cd', 'ef']
            self.output = ['abcdef']

        @patch('itertools.product')
        @patch('tqdm._tqdm.tqdm.write')
        def test_product_no_progress(self, patched_write, patched_product):
            # without any arguments
            patched_product.side_effect = self._product_side_effect

# Generated at 2022-06-12 14:32:14.235797
# Unit test for function product
def test_product():
    assert list(product(range(3), range(2))) == [(0, 0), (0, 1),
                                                (1, 0), (1, 1),
                                                (2, 0), (2, 1)]

# Generated at 2022-06-12 14:32:19.593298
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.testing import assert_equal
    result = list(product([1, 2, 3], [1, 2, 3], tqdm_class=tqdm_auto))
    expected = [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
    assert_equal(result, expected)

# Generated at 2022-06-12 14:32:27.987941
# Unit test for function product
def test_product():
    import sys
    import os
    from ..utils import _range
    from .trange import trange
    from .tqdm_gui import tqdm_gui
    from .std import tqdm
    from .tqdm import tqdm_pandas

    # Testing tqdm_pandas with product

# Generated at 2022-06-12 14:32:35.387787
# Unit test for function product
def test_product():
    """
    Simple unit test for `product`
    """
    import inspect
    import io
    import os
    import sys

    d = {'a': 1, 'b': 2, 'c': 3}
    entries = [r['a'] + r['b'] * 2 + r['c'] * 3
               for r in product(d, d, d)]
    assert entries == list(range(3, 28))
    d2 = {(1, 2): 1, (3, 4): 2, (5, 6): 3}
    entries = [r[0][0] + r[0][1] * 2 + r[1] * 3
               for r in product(d2, d2, d2)]
    assert entries == list(range(3, 28))

# Generated at 2022-06-12 14:32:40.056902
# Unit test for function product
def test_product():
    """
    tests the product() wrapper
    """
    from numpy.testing import assert_equal

    with tqdm_auto(total=12) as t:
        for i in product(range(4), range(3)):  # 4*3 = 12
            assert_equal(len(i), 2)
            t.update()

# Generated at 2022-06-12 14:32:47.224469
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    def _test(tqdm_class=None, total=None):
        """
        Unit test for function product, with given tqdm class
        """
        from .tqdm_gui import tnrange
        from .std import tqdm
        from .std import trange
        from .std import tqdm_pandas
        total = total or 1
        for a in range(2):
            for b in range(3):
                for c in range(4):
                    total *= 4

# Generated at 2022-06-12 14:32:50.680631
# Unit test for function product
def test_product():
    """Test function product."""
    from ._tqdm_test import pretest_posttest
    for cls in [tqdm_auto.tqdm, tqdm_auto.trange]:
        for total in [None, 1, 5, 1000]:
            with pretest_posttest(leave=False):
                for _ in product(range(1000), total=total,
                                 tqdm_class=cls):
                    pass

# Generated at 2022-06-12 14:32:55.674756
# Unit test for function product
def test_product():
    """
    Unit tests for python_utils.itertools.product
    """
    from .common import closing, SimpleTqdm, StringIO
    from .tests_tqdm import pretest_posttest

    def test_empty():
        iterables = [range(1),
                     range(2),
                     range(3)]
        for total in [0, None]:
            with closing(StringIO()) as our_file:
                for _ in product(*iterables, total=total,
                                 file=our_file):
                    break
                assert not our_file.getvalue()

    def test_with_list():
        iterables = [range(1), range(2), range(3)]

# Generated at 2022-06-12 14:33:39.450305
# Unit test for function product
def test_product():
    from operator import mul
    from functools import reduce

    it = product(range(i) for i in (3, 6, 2, 3, 2))
    assert reduce(mul, map(len, it.tqdm.iterables)) == sum(1 for _ in it)

    it = product(range(i) for i in (3, 6, 2, 3, 2))
    assert reduce(mul, map(len, it.tqdm.iterables)) == sum(1 for _ in it)

# Generated at 2022-06-12 14:33:44.827559
# Unit test for function product
def test_product():
    from ._utils import _shutup

    try:
        import itertools
        _shutup()
        try:
            itertools.product
        except NameError:
            raise
        finally:
            _shutup(True)
    except NameError:
        # We are probably in Py2
        pass

    import numpy as np

    # Check dimensions 2
    res1 = product(list(range(10)), list(range(20)))
    res2 = itertools.product(list(range(10)), list(range(20)))
    assert list(res1) == list(res2)

    # Check dimensions 3
    res1 = product(list(range(10)), list(range(20)), list(range(30)))

# Generated at 2022-06-12 14:33:53.363118
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    from .tqdm import trange
    from .utils import __interactive__

    # Test basic use case
    x = list(product(range(3), repeat=2, tqdm_class=tqdm))

    # Test basic use case
    x = list(product(range(5), repeat=3, tqdm_class=trange))

    # Test total
    x = list(product(range(5), repeat=3, tqdm_class=tqdm))
    # Test total
    x = list(product(range(1), repeat=1, tqdm_class=tqdm))

    # Test with progress bar disabled

# Generated at 2022-06-12 14:33:59.627302
# Unit test for function product
def test_product():
    """ Unit test for function product """
    assert tuple(product(range(1, 4), range(1, 4))) == tuple(itertools.product(range(1, 4), range(1, 4)))
    assert tuple(product(range(1, 6), range(1, 6))) == tuple(itertools.product(range(1, 6), range(1, 6)))
    assert tuple(product((1, 2, 3), (1, 2, 3))) == tuple(itertools.product((1, 2, 3), (1, 2, 3)))
    assert tuple(product((1, 2, 3), (1, 2, 3), (1, 2, 3))) == tuple(itertools.product((1, 2, 3), (1, 2, 3), (1, 2, 3)))


# Generated at 2022-06-12 14:34:01.172289
# Unit test for function product
def test_product():
    try:
        assert not next(
            product(range(10), range(10), range(10),
                    tqdm_class=tqdm_auto, disable=True))
    except StopIteration:
        pass

# Generated at 2022-06-12 14:34:11.117073
# Unit test for function product
def test_product():
    """
    Doctest for function product.
    """
    from ..auto import tqdm
    import numpy as np

    # test itertools compatbility (no total length available)
    A = np.array([[0], [1], [2]])
    B = np.array([[0, 1, 2]])
    A_tqdm = tqdm(A)
    B_tqdm = tqdm(B)
    for p, q in zip(product(A_tqdm, B_tqdm), itertools.product(A, B)):
        assert p == q

    # test total length
    for p, q in zip(product(A, B, tqdm_class=tqdm), itertools.product(A, B)):
        assert p == q


# Unit

# Generated at 2022-06-12 14:34:20.436597
# Unit test for function product
def test_product():
    import sys
    import random
    from ..utils import _term_move_up
    for N in range(2, 7):
        # Random test (N=2,3,4,5,6)
        a = tuple(range(N))
        b = tuple([random.randint(0, 5) for _ in range(N)])
        # Test
        sys.stderr.write("\n\nTest: 'itertools.product'\n")
        with tqdm_auto(**{'ascii': True}) as t:
            for i in product(a, b, tqdm_class=tqdm_auto):
                assert len(i) == 2
                sleep(0.01)
        # Should be equal to

# Generated at 2022-06-12 14:34:25.759347
# Unit test for function product
def test_product():
    for i in product('ABC', '123'):
        pass
    for i in product(range(10)):
        pass
    for i in product(range(4), range(4)):
        pass
    for i in product(range(4), range(3), 'ABCD'):
        pass
    for i in product('ABCDE', repeat=2):
        pass


# Backward compatibility (for renaming)
itertools_product = product
itertools_product.__doc__ = product.__doc__

# Generated at 2022-06-12 14:34:31.355553
# Unit test for function product
def test_product():
    """Test product"""
    import sys
    try:
        if sys.version_info < (3, 0):
            range = xrange
        first = [4, 5, 6]
        second = [1, 2, 3]
        for _a, _b in product(first, second):
            assert _a in first
            assert _b in second
    finally:
        sys.version_info = (3, 0)

    # test_lists.py is used as it has the correct encoding
    with open('tests/test_lists.py') as f:
        first = f.readlines()
        second = first
        for _a, _b in product(first, second):
            assert _a in first
            assert _b in second

# Generated at 2022-06-12 14:34:35.214850
# Unit test for function product
def test_product():
    from numpy import prod
    for k, p in zip(range(10), product(*(range(i) for i in range(1, 10)))):
        assert k == sum(i * prod(j) for i, j in zip(p, (range(1, i + 2) for i
                                                      in range(1, len(p)))))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:35:37.055379
# Unit test for function product
def test_product():
    try:
        import numpy
        product([1, 2, 3], [4, 5]) == numpy.array([[1, 4], [1, 5],
                                                   [2, 4], [2, 5],
                                                   [3, 4], [3, 5]]).tolist()
    except ImportError:
        pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:35:43.477705
# Unit test for function product
def test_product():
    from ..pandas import tqdm_pandas

    for t in [tqdm_auto, tqdm, tqdm_gui, tqdm_notebook, tqdm_pandas]:
        assert list(product(range(i), tqdm_class=t)) == list(itertools.product(range(i)))
        assert list(product(range(i), repeat=2, tqdm_class=t)) == list(itertools.product(range(i), repeat=2))
        assert list(product(range(i), repeat=3, tqdm_class=t)) == list(itertools.product(range(i), repeat=3))


# Generated at 2022-06-12 14:35:51.319301
# Unit test for function product
def test_product():
    i = product("AB", "12", "XY", tqdm_class=None, total=None)
    assert list(i) == [('A', '1', 'X'), ('A', '1', 'Y'),
                       ('A', '2', 'X'), ('A', '2', 'Y'),
                       ('B', '1', 'X'), ('B', '1', 'Y'),
                       ('B', '2', 'X'), ('B', '2', 'Y')]

    i = product("z", "y", tqdm_class=tqdm_auto, total=None)
    for j in range(100):
        assert next(i) == ("z", "y")

    # Test that total=None works
    i = product("z", "y", tqdm_class=tqdm_auto, total=None)

# Generated at 2022-06-12 14:36:00.174624
# Unit test for function product
def test_product():
    from .main import _PY3
    int_iter = range(3)
    if _PY3:
        str_iter = map(str, int_iter)
    else:
        str_iter = [str(i) for i in int_iter]
    assert list(product(int_iter, repeat=0)) == [()]
    assert list(product(int_iter, repeat=1)) == [(0,), (1,), (2,)]
    assert list(product(int_iter, repeat=2)) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-12 14:36:07.975789
# Unit test for function product
def test_product():
    """
    Equivalent of `itertools.product`.

    Parameters
    ----------
    tqdm_class  : [default: tqdm.auto.tqdm].
    """

    def test_generator(a, b, c):
        """
        test function used in unit test
        """
        for i in range(a):
            for j in range(b):
                for k in range(c):
                    yield i, j, k

    from .tqdm_gui import tqdm

    for i in test_generator(3, 4, 5):
        pass

    for _ in tqdm(test_generator(3, 4, 5), total=60, ncols=100):
        pass


# Generated at 2022-06-12 14:36:12.648564
# Unit test for function product
def test_product():
    """Test the product function."""
    from ..utils import FormatCustomText

    for i, res in tqdm(enumerate(product(
            range(10),
            range(20),
            range(30),
            range(40),
            tqdm=FormatCustomText("PRODUCT {}/{}"))), total=pow(10, 4)):
        assert (10 * 20 * 30 * 40) > i > 0
        assert len(res) == 5

# Generated at 2022-06-12 14:36:15.435490
# Unit test for function product
def test_product():
    for i in product(range(3), tqdm_class=tqdm_auto):
        pass


if __name__ == "__main__":
    from .pandas import tqdm_pandas
    from .pandas import tnrange

# Generated at 2022-06-12 14:36:19.109365
# Unit test for function product
def test_product():
    with product(range(3), range(3), range(3), range(3), _disable=True)\
            as _:
        assert 1 == 1
    with product(range(3), "ab", (1, 2), _disable=True) as _:
        assert 1 == 1

# Generated at 2022-06-12 14:36:26.899781
# Unit test for function product
def test_product():
    import numpy as np
    # Test with out-of-the-box class:
    t = product([0], [1], tqdm_class=tqdm_auto)
    assert list(t) == [(0, 1)]
    # Test with same class for each loop:
    t = product([0], [1], tqdm_class=tqdm_auto)
    assert list(t) == [(0, 1)]
    # Test with integer
    t = product(0, 1, tqdm_class=tqdm_auto)
    assert list(t) == []
    # Test with generator
    t = product(iter(range(10)), [1], tqdm_class=tqdm_auto)
    assert list(t) == [(i, 1) for i in range(10)]

# Generated at 2022-06-12 14:36:32.517738
# Unit test for function product
def test_product():
    from .monitor import unused_port
    from .tty import on_tty
    with unused_port() as port:
        for i in product(range(10), range(10), range(10)):
            pass

        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto.tqdm,
                         miniters=1, mininterval=0.1,
                         leave=False, file=on_tty):
            pass
        for i in product(range(10), range(10), range(10),
                         tqdm_class=tqdm_auto.tqdm_notebook,
                         miniters=1, mininterval=0.1,
                         leave=False, file=on_tty):
            pass