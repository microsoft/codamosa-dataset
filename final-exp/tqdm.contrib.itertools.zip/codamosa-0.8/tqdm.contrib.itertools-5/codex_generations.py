

# Generated at 2022-06-12 14:27:04.823545
# Unit test for function product
def test_product():
    from ._utils import _range

    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]


# Generated at 2022-06-12 14:27:10.206404
# Unit test for function product
def test_product():
    a = range(1, 3)
    b = range(3, 5)
    c = range(5, 7)
    p = list(product(a, b, c))
    assert p == [(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6),
                 (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)], p

# Generated at 2022-06-12 14:27:15.695390
# Unit test for function product
def test_product():
    """
    Test :func:`product`
    """
    # Without tqdm
    assert list(product("ABC", repeat=2)) == list(itertools.product("ABC", repeat=2))
    # With tqdm
    assert list(
        product("ABC", repeat=2, tqdm_class=tqdm_auto)) == list(itertools.product("ABC", repeat=2))

# Generated at 2022-06-12 14:27:17.740642
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))

# Generated at 2022-06-12 14:27:19.808276
# Unit test for function product
def test_product():
    for _ in product('ABC', 'xy'):
        pass
    for _ in product('ABC', 'xy', tqdm_class=None):
        pass

# Generated at 2022-06-12 14:27:21.754804
# Unit test for function product
def test_product():
    for i in product(range(4), range(4), range(4), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:27:27.461816
# Unit test for function product
def test_product():
    """ Unit test for function product. """
    import __builtin__

    print("\n=== Test function product ===")

    stream = __builtin__.raw_input if hasattr(__builtin__, 'raw_input') else \
        __builtin__.input
    it = product(*[[1, 2, 3]] * 3, tqdm_class=tqdm_auto, leave=False)
    for _ in it:
        assert (list(it)) == []
        break
    for _ in it:
        break
    for _ in it:
        break
    for _ in it:
        break
    stream("\n- Press [Enter] to end test")
    stream()

# Generated at 2022-06-12 14:27:34.968166
# Unit test for function product
def test_product():
    """Test that tqdm.product is equivalent to `itertools.product`."""
    from numpy.testing import assert_equal

    a = list(range(3))
    b = list(range(3))
    assert_equal(list(tqdm.product(a, b)),
                 list(itertools.product(a, b)))

    a = list(range(3))
    b = list(range(3))
    assert_equal(list(tqdm.product(a, b, tqdm_class=tqdm.tqdm)),
                 list(itertools.product(a, b)))

# Generated at 2022-06-12 14:27:39.681287
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np

    def test_product_func(a, b):
        for c, d in product(a, b):
            assert(c == a[int(c)])
            assert(d == b[int(d)])

    test_product_func(np.arange(4), np.arange(10, 14))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:27:44.578297
# Unit test for function product
def test_product():
    """ Unit test for `tqdm.itertools.product` """
    from numpy.testing import assert_equal
    list(product(range(10), range(10), tqdm_class=tqdm_auto))
    assert_equal(product(range(10), range(10), tqdm_class=None),
                 itertools.product(range(10), range(10)))
    list(product('abcd', 'xy', tqdm_class=tqdm_auto))
    assert_equal(product('abcd', 'xy', tqdm_class=None),
                 itertools.product('abcd', 'xy'))

# Generated at 2022-06-12 14:27:56.625667
# Unit test for function product

# Generated at 2022-06-12 14:28:03.288504
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    assert list(product(range(5), range(5))) == [(0,0), (0,1), (0,2), (0,3), (0,4),
                                                 (1,0), (1,1), (1,2), (1,3), (1,4),
                                                 (2,0), (2,1), (2,2), (2,3), (2,4),
                                                 (3,0), (3,1), (3,2), (3,3), (3,4),
                                                 (4,0), (4,1), (4,2), (4,3), (4,4)]

# Generated at 2022-06-12 14:28:11.898921
# Unit test for function product
def test_product():
    """Run the unit test for the function `product`"""
    from ..tqdm import trange
    try:
        from itertools import product as itertools_product
    except ImportError:
        from ..exceptions import TqdmDeprecationWarning
        raise TqdmDeprecationWarning(
            "Cannot test `itertools.product` without `itertools`")
    for i in product(range(10000), range(10000), tqdm_class=trange):
        pass
    for i, j in zip(itertools_product(range(10000), range(10000)), product(
            range(10000), range(10000), tqdm_class=trange)):
        assert i == j

# Generated at 2022-06-12 14:28:15.463617
# Unit test for function product
def test_product():
    from operator import mul

    t = range(1, 101)
    r = range(100)

    for _ in product(t, r, tqdm_class=None):
        pass
    for _ in product(t, r, tqdm_class=tqdm.tqdm):
        pass
    for _ in product("abc", "def"):
        pass

# Generated at 2022-06-12 14:28:21.680131
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    old_stdout = sys.stdout
    sys.stdout = output = StringIO()
    for _ in product(range(10), range(20), range(30), tqdm_class=tqdm_auto):
        pass
    sys.stdout = old_stdout

    from .utils import SimpleTqdm
    SimpleTqdm._decr_instances()  # pylint: disable=protected-access
    ref = ("|#" * 30)[:-1] + "|"


# Generated at 2022-06-12 14:28:29.908106
# Unit test for function product
def test_product():
    """
    Unit-test for function `tqdm.itertools.product`.
    """
    from numpy.random import randint
    # Check whether tqdm.itertools.product equals itertools.product
    for _ in range(100):
        l = randint(0, 10)
        product_test = [list(range(randint(0, 10))) for _ in range(l)]

        product_tqdm = product(*product_test, disable=True)
        product_itertools = itertools.product(*product_test)

        for a, b in zip(product_tqdm, product_itertools):
            assert a == b

    # Check whether tqdm.itertools.product works with total argument
    for _ in range(100):
        l = randint(0, 10)

# Generated at 2022-06-12 14:28:34.032684
# Unit test for function product
def test_product():
    r = list(product(range(2), range(2), range(2)))
    assert r == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                 (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)], r

# Generated at 2022-06-12 14:28:37.876973
# Unit test for function product
def test_product():
    # Normal
    iterables = [[1, 2, 3], ["a", "b"]]
    for i in product(*iterables):
        print(i)
    # Empty
    iterables = [[], ["a", "b"]]
    for i in product(*iterables):
        print(i)
    # Empty
    iterables = [[1, 2, 3], []]
    for i in product(*iterables):
        print(i)
    # Empty
    iterables = [[], []]
    for i in product(*iterables):
        print(i)



# Generated at 2022-06-12 14:28:43.352555
# Unit test for function product
def test_product():
    from ..tqdm_gui import tqdm_notebook
    from .tests_tqdm import leaving

    for t in [tqdm_auto, tqdm_notebook]:
        with leaving(tqdm_auto(leave=True,
                               disable=None)):
            for i in product(range(4), range(6), tqdm_class=t):
                assert sum(i) < 10
            for i in product(range(4), range(6), range(100), tqdm_class=t):
                assert sum(i) < 110

# Generated at 2022-06-12 14:28:46.171424
# Unit test for function product
def test_product():
    from ..tests._utils import _random_data_stream
    from ..tests._utils import _test_exact_progress
    for ndata in [0, 1, 1000]:
        _test_exact_progress(lambda: product(*_random_data_stream(ndata)),
                             ndata)

# Generated at 2022-06-12 14:29:00.782845
# Unit test for function product
def test_product():
    from .compat import StringIO
    from ..utils import format_sizeof

    def product_n(n, **tqdm_kwargs):
        return product(*([range(n)] * n), **tqdm_kwargs)

    with StringIO() as our_file:
        for _ in product_n(10, file=our_file):
            pass

    with StringIO() as orig_file:
        for _ in itertools.product(*([range(10)] * 10)):
            pass

        assert our_file.getvalue() == orig_file.getvalue()

    with StringIO() as our_file:
        product_n(2, desc='ABC', file=our_file)


# Generated at 2022-06-12 14:29:06.882457
# Unit test for function product
def test_product():
    """Test for function `product`."""
    from tqdm import trange
    import sys

    try:
        print("    Testing function `product`: ", end='')
        # ---
        _ = list(product(range(100), range(100, 110), range(110, 120)))
        # ---
        _ = list(product(range(100), range(100, 110), range(110, 120),
                         tqdm=trange))
        # ---
        _ = list(product(range(100), range(100, 110), range(110, 120),
                         tqdm_class=trange))
        # ---
        print('OK')
    except:
        print('ERROR')
        print('\n---\nTEST FAILURE\n---\n')
        raise

# Generated at 2022-06-12 14:29:16.822426
# Unit test for function product
def test_product():
    import sys
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        for item in product(range(3), range(3)):
            print(item)


# Generated at 2022-06-12 14:29:21.944113
# Unit test for function product
def test_product():
    from .itertools import product
    for i, _ in zip(enumerate(product('ABCD', 'xy')),
                    [(0, ('A', 'x')), (1, ('A', 'y')), (2, ('B', 'x')),
                     (3, ('B', 'y')), (4, ('C', 'x')), (5, ('C', 'y')),
                     (6, ('D', 'x')), (7, ('D', 'y'))]):
        assert i[0] == i[1][0]
        assert i[1][1] <= 'y'

# Generated at 2022-06-12 14:29:30.892869
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    import sys
    import pytest

    with pytest.raises(TypeError):
        for i in product([1, 2, 3]):
            pass

    for i in product([1, 2, 3], range(3, 6)):
        assert len(i) == 2

    numbers = range(20)
    ref = [(num, letter) for letter in 'abc' for num in numbers]
    out = list(product(numbers, 'abc'))
    assert ref == out

    if sys.version_info[:2] >= (3, 2):  # pragma: no cover
        def prod(a, b, c, d):
            return a + b + c + d
        ref = prod(2, 3, 4, 5)

# Generated at 2022-06-12 14:29:38.372601
# Unit test for function product
def test_product():
    from .main import TqdmDeprecationWarning
    import warnings

    # Test that tqdm.prod doesn't interfere with Python's default behaviour
    assert list(product(["hello", "world"], repeat=2)) == [
        ('hello', 'hello'),
        ('hello', 'world'),
        ('world', 'hello'),
        ('world', 'world'),
    ]

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')  # Trigger all warnings
        assert list(product(range(5), [0, 1])) == [
            (0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1),
            (3, 0), (3, 1), (4, 0), (4, 1)
        ]


# Generated at 2022-06-12 14:29:43.331733
# Unit test for function product
def test_product():
    result_prod = product(range(3), range(3))
    assert list(result_prod) == [(0, 0), (0, 1), (0, 2),
                                 (1, 0), (1, 1), (1, 2),
                                 (2, 0), (2, 1), (2, 2)]

    result_prod = product(range(3))
    assert list(result_prod) == [(i,) for i in range(3)]

# Generated at 2022-06-12 14:29:50.636099
# Unit test for function product
def test_product():
    #pylint: disable=C0103
    from .std import tqdm_std
    for kwargs in [dict(), dict(vmin=10)]:
        assert product(*range(9), tqdm_class=tqdm_std, **kwargs)
        assert product(*range(9), tqdm_class=None, **kwargs)
        assert product(*range(9), tqdm_class=tqdm_std, **kwargs)
        assert product(*range(9), tqdm_class=tqdm_std, **kwargs)
        assert product(*range(9), tqdm_class=tqdm_std, **kwargs)

# Generated at 2022-06-12 14:29:54.198750
# Unit test for function product
def test_product():
    from numpy.random import randint

    for n in range(2, 10):
        for total in (None, randint(1, 2*n)):
            for *args in itertools.product(*(range(n) for _ in range(n))):
                assert args == list(product(*args, total=total))

# Generated at 2022-06-12 14:30:00.773504
# Unit test for function product
def test_product():
    """Simple unit tests for the `itertools.product` wrapper"""
    from tqdm import tqdm
    assert list(product(range(2), range(2), range(2),
                        tqdm_class=tqdm)) ==\
        list(itertools.product(range(2), range(2), range(2)))
    assert list(product(range(2), range(2), range(2),
                        tqdm_class=tqdm, total=3)) ==\
        list(itertools.product(range(2), range(2), range(2)))

# Generated at 2022-06-12 14:30:15.481716
# Unit test for function product
def test_product():
    """
    Test function `product`.
    """
    from collections import OrderedDict
    import numpy as np
    a = np.arange(500)
    inds = []
    with product(a, a, a) as pbar:
        for i in pbar:
            inds.append(i)
    inds = np.array(inds)
    assert np.all(np.diff(np.sort(np.unique(inds[:, 0]))) == 1)
    assert np.all(np.diff(np.sort(np.unique(inds[:, 1]))) == 1)

# Generated at 2022-06-12 14:30:22.268143
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..std import tqdm
    it = product("ABC", "123")
    assert [("A", "1"), ("A", "2"), ("A", "3"), ("B", "1"), ("B", "2"),
            ("B", "3"), ("C", "1"), ("C", "2"), ("C", "3")] == list(it)
    for n in [1, 2, 10, 1000, 10000]:
        assert n == len(list(product(range(n), range(n))))
        assert n == len(list(product(range(n), range(n), tqdm_class=tqdm)))

# Generated at 2022-06-12 14:30:25.598452
# Unit test for function product
def test_product():
    x = list(product([1, 2, 3], [4, 5, 6], tqdm_class=None))
    assert x == list(itertools.product([1, 2, 3], [4, 5, 6]))

# Generated at 2022-06-12 14:30:31.637476
# Unit test for function product
def test_product():
    from nose.tools import eq_
    from .utils import closing, SimpleNamespace

    option_list = [["c", "b", "a"], ["def", "ghi", "abc"], ["100", "200", "300"]]
    opts = SimpleNamespace(**dict(zip(["x", "y", "z"], itertools.product(*option_list))))

# Generated at 2022-06-12 14:30:36.996053
# Unit test for function product
def test_product():
    """Test product()"""
    import numpy as np

    # test output values
    assert list(product(np.arange(2), np.arange(3))) == [(0, 0), (0, 1),
                                                         (0, 2),
                                                         (1, 0), (1, 1),
                                                         (1, 2)]

    # test total
    gen = product(np.arange(2), np.arange(3))
    gen.send(None)
    gen.send(None)
    assert gen.send(gen._total) == 6

# Generated at 2022-06-12 14:30:39.971461
# Unit test for function product
def test_product():
    """Test for function `product`."""
    assert list(product(range(2), repeat=2)) == [
        (0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(3))) == [(0,), (1,), (2,)]

# Generated at 2022-06-12 14:30:42.316653
# Unit test for function product
def test_product():
    """
    Unit test for product
    """
    one = 2
    two = 3
    total = one * two
    actual = 0
    for _ in product(range(one), range(two)):
        actual += 1
    assert actual == total


# Generated at 2022-06-12 14:30:47.082666
# Unit test for function product
def test_product():
    """
    Ensure that product does not raise any exception.

    Also, ensure that `total` keyword is passed to the tqdm object.
    """
    from .monitor import _instances

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    _instances.clear()

    for total in [None, 0, 1, 10]:
        m = Mock()
        product(range(2), range(2), tqdm_class=m, total=total)
        try:
            assert m.call_args[1]['total'] == total
        except AssertionError:
            # Mock call is not picklable
            if total is None and m.call_count == 2:
                continue
            raise

# Generated at 2022-06-12 14:30:51.235083
# Unit test for function product
def test_product():
    input_iterables = [range(5), range(5), range(5), range(5)]
    result_list = list(product(*input_iterables))
    expected_result_list = list(itertools.product(*input_iterables))
    assert result_list == expected_result_list, "Expected identical lists"

# Generated at 2022-06-12 14:30:59.672462
# Unit test for function product
def test_product():
    import numpy as np
    a = np.arange(8).reshape(2, 2, 2)

    # Test normal usage
    assert list(product(a[0, 0])) == [0, 1]
    assert list(product(a[0, 0], repeat=3)) == [(0, 0, 0), (0, 0, 1),
                                                (0, 1, 0), (0, 1, 1),
                                                (1, 0, 0), (1, 0, 1),
                                                (1, 1, 0), (1, 1, 1)]

    # Test `total` parameter
    assert list(product(a[0, 0], tqdm_kwargs=dict(total=3))) == [0, 1]

    # Test `range` argument

# Generated at 2022-06-12 14:31:23.114620
# Unit test for function product
def test_product():
    # test normal functionality
    it = product([1, 2], ["a", "b"])
    for i in itertools.product([1, 2], ["a", "b"]):
        assert next(it) == i

    # test tqdm
    it = product([1, 2], ["a", "b"], tqdm_class=tqdm_auto)
    for i in itertools.product([1, 2], ["a", "b"]):
        assert next(it) == i

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:31:26.020418
# Unit test for function product
def test_product():
    from itertools import product
    from tqdm import trange

    if __name__ == '__main__':
        with trange(1, 0, -0.01) as t:
            for i, j in product(t, t):
                t.set_description(str(i) + ',' + str(j))
                if i == j:
                    break

# Generated at 2022-06-12 14:31:35.367026
# Unit test for function product
def test_product():
    from numpy import product as npproduct
    from numpy import array
    from numpy.random import random
    from tqdm import trange
    for i in trange(100):
        iterables = [range(int(10 * random())) for _ in range(int(10 * random()))]
        r1 = list(product(*iterables))
        r2 = [array(i) for i in itertools.product(*iterables)]
        for i in r2:
            assert (i == r1[r2.index(i)])
    for j in trange(100):
        iterables = [range(int(10 * random())) for _ in range(int(10 * random()))]
        r1 = list(product(*iterables))

# Generated at 2022-06-12 14:31:43.917772
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    # Unit tests are runnable with:
    # $ python -m tqdm.itertools tests/test_itertools.py
    from ..std import format_sizeof
    import sys

    import numpy as np

    def int_max(dtype):
        """
        Calculate the maximum value of a signed integer type.
        """
        return np.iinfo(dtype).max

    # pylint: disable=cell-var-from-loop

# Generated at 2022-06-12 14:31:51.925871
# Unit test for function product
def test_product():
    """test_product"""
    from ..utils import format_sizeof
    from .tests import closing, OrderedResult
    from .utils import TEST_LIKE_PRODUCTS, TEST_LIKE_PRODUCTS_SUB_IT
    # test iterators
    with closing(OrderedResult()) as r:
        for i in product(r):
            pass
        assert r.values == []
    with closing(OrderedResult()) as r:
        for i in product([0], r):
            pass
        assert r.values == []
    with closing(OrderedResult()) as r:
        for i in product([0], [1], r):
            pass
        assert r.values == []
    # test tuples
    with closing(OrderedResult()) as r:
        for i in product(r):
            pass

# Generated at 2022-06-12 14:31:58.629893
# Unit test for function product
def test_product():
    """
    Unit-test the tqdm.itertools.product().
    """
    from numpy.testing import assert_array_equal
    from ..utils import format_sizeof

    # Empty iterator
    assert_array_equal(list(product([])), [()])

    # Single value
    assert_array_equal(list(product([0])), [(0,)])

    # Multiple values
    assert_array_equal(list(product([0, 1])), [(0, 0), (0, 1), (1, 0), (1, 1)])

    # Multiple iterators
    assert_array_equal(list(product([0, 1], [2, 3])),
                       [(0, 2), (0, 3), (1, 2), (1, 3)])

# Generated at 2022-06-12 14:32:04.762575
# Unit test for function product
def test_product():
    from itertools import product
    from ..utils import FormatCustomText
    class TqdmTest(FormatCustomText):
        def __init__(self, *args, **kwargs):
            super(TqdmTest, self).__init__(*args, **kwargs)
            self.format_dict['total'] = None
            self.format_dict['rate'] = None
            self.format_dict['elapsed'] = None

            self.format_dict['desc'] = 'Custom text'
            self.format_dict['n'] = 'Custom n'
            self.format_dict['bar'] = 'Custom bar'

    res1 = list(product('ABCD', 'xy'))
    res2 = list(product(tqdm_class=TqdmTest)('ABCD', 'xy'))
    assert res1 == res2

# Generated at 2022-06-12 14:32:11.799586
# Unit test for function product
def test_product():
    from ..nested import _range
    from ..utils import FormatCustomText

    total = 0
    for i in product(_range(10, 12), _range(1, 4)):
        total += 1

    assert total == 6
    assert str(total) == "6"
    try:
        import numpy as np
    except ImportError:
        return

    # make sure numpy products are iterable
    total = 0
    for i in _range(3):
        for _ in product(np.array([1, 2]), range(i)):
            total += 1
    assert total == 3

    # make sure nested products are counted properly
    total = 0
    for i in _range(3):
        for _ in product(_range(i), _range(i)):
            total += 1
    assert total == 3

    # make

# Generated at 2022-06-12 14:32:20.233033
# Unit test for function product
def test_product():
    import numpy
    a = range(9)
    b = range(9)
    c = range(9)
    # Default behaviour
    assert numpy.array_equal(
        list(product(a, b, c)),
        list(itertools.product(a, b, c)))
    # Auto display
    assert numpy.array_equal(
        list(product(a, b, c, tqdm_class=tqdm_auto)),
        list(itertools.product(a, b, c)))
    # Manual display
    from tqdm import tqdm
    assert numpy.array_equal(
        list(product(a, b, c, tqdm_class=tqdm)),
        list(itertools.product(a, b, c)))

# Generated at 2022-06-12 14:32:28.674457
# Unit test for function product
def test_product():
    """Unit test for product"""
    from ..utils import FormatCustomText

    from .utils import TestTqdmExperimental

    TestTqdmExperimental.extra_coverage = True

    def tuplen(tup):
        return sum(len(str(x)) for x in tup)

    with TestTqdmExperimental(_range=tqdm_auto, bar_format=FormatCustomText(
            "{postfix}")) as t:
        for x in product((1, 2), repeat=2, tqdm_class=tqdm_auto):
            t.write(str(x))
            t.n = tuplen(x)
    assert t.dynamic_messages == ["(1, 1)", "(1, 2)", "(2, 1)", "(2, 2)"]


# Generated at 2022-06-12 14:33:22.690470
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .tests import pretest_posttest, zero_out

    # verbose or not
    for tqdm_class in [tqdm_auto, tqdm_auto(disable=True), tqdm_auto(leave=True)]:
        # Check simple product (2 lists of 3 elements, non-equidistant)
        a = [6.5, 0, -1]
        b = [1000, -5, -10]
        with tqdm_class(total=len(a) * len(b)) as t:
            res = list(product(a, b, tqdm_class=tqdm_class))
            assert res == list(itertools.product(a, b))
        assert zero_out(t.n) == len(a) * len(b)

# Generated at 2022-06-12 14:33:28.575964
# Unit test for function product
def test_product():
    from ._utils import naturals
    import numpy as np

    assert list(product(range(5), range(5), range(5))) == \
        list(itertools.product(range(5), range(5), range(5)))

    assert np.all(np.array(list(product(naturals(), naturals(), naturals())))
                  == np.array(list(itertools.product(naturals(), naturals(),
                                                     naturals()))))

# Generated at 2022-06-12 14:33:37.572201
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], [4, 5], tqdm_class=None)) \
        == list(itertools.product([1, 2, 3], [4, 5]))
    assert list(product([1, 2, 3], [4, 5], tqdm_class=tqdm_auto)) \
        == list(itertools.product([1, 2, 3], [4, 5]))
    assert list(product([1, 2, 3], [4, 5])) \
        == list(itertools.product([1, 2, 3], [4, 5]))

# Generated at 2022-06-12 14:33:43.658088
# Unit test for function product
def test_product():
    import pytest

    # The first one should call tqdm.tqdm.__iter__
    assert list(product(range(10))) == list(itertools.product(range(10)))
    # But the second one should not
    assert list(product(range(10), tqdm_class=None)) == list(itertools.product(range(10)))

    # The third one should not because total=0
    assert list(product(range(10), total=0)) == list(itertools.product(range(10)))

    # The fourth one should show updating tqdm bar
    for i in product(range(10), tqdm_class=tqdm_auto):
        assert i is not None

    # All are equal in length

# Generated at 2022-06-12 14:33:52.210677
# Unit test for function product
def test_product():
    """ Unit test for function product """
    for out, it in zip(
            [[(0, 0), (0, 1), (1, 0), (1, 1)],
             [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
              (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]],
            [itertools.product([0, 1], repeat=2),
             itertools.product([0, 1], repeat=3)]):
        assert list(product(range(2), repeat=2)) == out
        assert list(product(range(2), repeat=2, tqdm_class=None)) == out
        assert list(product(it)) == out

# Generated at 2022-06-12 14:33:59.007752
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import Random
    from .tests_tqdm import with_setup, _range

    @with_setup(PY2=False)
    def product_simple():
        """Test basic `product`"""
        lists = [range(5), range(5)]
        assert list(product(*lists)) == itertools.product(*lists)

    @with_setup(PY2=False)
    def product_array():
        """Test `product` with `tqdm(np.array([...])`"""
        lists = [range(5), range(5)]
        assert list(zip(*product(*lists))) == list(zip(*itertools.product(*lists)))

    @with_setup(PY2=False)
    def product_nested():
        """Test `product` with nested iterator"""

# Generated at 2022-06-12 14:34:00.660302
# Unit test for function product
def test_product():
    with tqdm_auto(unit='it') as t:
        for i in product(range(3), range(3)):
            t.update()
        assert t.n == 9



# Generated at 2022-06-12 14:34:08.953317
# Unit test for function product
def test_product():
    from .tests_wrap import simple_gen
    import numpy as np
    for total in [None, 1, 30]:
        product_obj = product(simple_gen(1), simple_gen(2), tqdm_class=tqdm_auto, total=total)
        assert np.allclose(
            [i for i in product_obj],
            [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
        )

# Generated at 2022-06-12 14:34:18.606534
# Unit test for function product
def test_product():
    import numpy as np
    from tqdm import tqdm
    a = range(1000)
    b = range(1000)
    c = range(1000)
    d = range(1000)
    product_results = [i for i in product(a, b, c, d)]
    product_results_tqdm = [i for i in product(a, b, c, d, tqdm_class=tqdm)]
    assert product_results == product_results_tqdm
    assert product_results == [(i, j, k, l) for i in range(1000) for j in range(1000) for k in range(1000) for l in range(1000)]

# Generated at 2022-06-12 14:34:29.130175
# Unit test for function product
def test_product():
    from pandas import DataFrame
    from pandas import concat
    from pandas import concat as pd_concat
    from pandas import read_csv

    from numpy import arange
    from numpy import array
    from numpy import full
    from numpy import nan
    from numpy import ndarray
    from numpy import ones
    from numpy import random as np_random
    from numpy import Timedelta
    from numpy import vstack as np_vstack

    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randn as randn_
    from numpy.random import randint
    from numpy.random import randint as randint_

    from numpy.testing import assert_array_equal as assert_ae

# Generated at 2022-06-12 14:35:21.147229
# Unit test for function product
def test_product():
    """
    Test for `itertools.product` wrapper.
    """
    try:  # Python 2
        from StringIO import StringIO
    except ImportError:  # Python 3
        from io import StringIO

    with StringIO() as our_file, StringIO() as ref_file:
        with tqdm_auto(desc='our', file=our_file) as our_tqdm:
            for i in product(range(2), range(2), range(2), tqdm_class=tqdm_auto,
                             file=our_tqdm):
                our_tqdm.write(repr(i))

# Generated at 2022-06-12 14:35:28.330627
# Unit test for function product
def test_product():
    from numpy.random import rand

    def calc_sum(it):
        return sum(x+y+z for x, y, z in it)

    def test_equal():
        # Ignores tqdm_args
        assert calc_sum(product(range(1000), range(1000), range(1000))) == \
            calc_sum(itertools.product(range(1000), range(1000), range(1000)))

    test_equal()
    a = rand(1, 1000, 1000)
    b = rand(1, 1000, 1000)
    c = rand(1, 1000, 1000)
    # test with numpy arrays
    for tqdm_cls in (tqdm_auto,):
        test_equal()

# Generated at 2022-06-12 14:35:33.369580
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from itertools import product

    for prod_class in [itertools.product, product]:
        for i in prod_class(range(4), range(4), range(4)):
            pass
        for i in prod_class(range(4), range(4), range(4), tqdm_class=tqdm_auto):
            pass

# Generated at 2022-06-12 14:35:40.913266
# Unit test for function product
def test_product():
    """
    Test ``itertools.product``.

    Negative n is not supported and will raise TqdmDeprecationWarning
    """
    from collections import namedtuple
    from tqdm import tqdm
    from tqdm.utils import TqdmDeprecationWarning

    t = namedtuple("t", "total n unit_scale disable_tqdm")

# Generated at 2022-06-12 14:35:46.061526
# Unit test for function product
def test_product():
    """
    Just test that all the variants work.
    """
    print(list(product(range(2), repeat=2, tqdm_class=None)))
    print(list(product(range(2), repeat=3, tqdm_class=tqdm_auto.tqdm)))
    print(list(product(range(2), range(3), tqdm_class=tqdm_auto.tqdm)))
    print(list(product(range(30), tqdm_class=None)))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:35:53.988383
# Unit test for function product
def test_product():
    # Test the default case
    l1 = [1, 2]
    l2 = [2, 3]
    l3 = [3, 4]
    total = 4
    t = tqdm_auto.tqdm(total=total, desc='test', mininterval=0.01,
                       miniters=1, unit='it')
    for i in product(l1, l2, l3):
        assert True
        t.update()
    t.close()
    if total != t.n:
        raise AssertionError("Mismatched total: {} != {}".format(total, t.n))
    # Test the case where one of the iterables is a generator expression
    l1 = [1, 2, 3]
    l2 = ('a' for i in l1)
    total = 6
    t

# Generated at 2022-06-12 14:36:03.118440
# Unit test for function product
def test_product():
    """Test for itertools.product"""
    from operator import mul
    from functools import reduce


# Generated at 2022-06-12 14:36:10.059237
# Unit test for function product
def test_product():
    assert list(product("AB", "12")) == [('A', '1'), ('A', '2'),
                                         ('B', '1'), ('B', '2')]

# Generated at 2022-06-12 14:36:12.121972
# Unit test for function product
def test_product():
    """Test for function product"""
    list(product(range(3), range(3), range(3), tqdm_class=tqdm_auto))

# Generated at 2022-06-12 14:36:14.356079
# Unit test for function product
def test_product():
    pbar = product(range(10), range(10), tqdm_class=tqdm_auto, leave=False)
    assert sum(1 for _ in pbar) == 100