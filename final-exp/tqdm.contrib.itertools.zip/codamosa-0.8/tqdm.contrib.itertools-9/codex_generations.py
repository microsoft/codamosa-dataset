

# Generated at 2022-06-12 14:27:05.460302
# Unit test for function product
def test_product():
    """Test for `itertools.product` wrapper"""
    for i in product(range(5)):
        pass
    for i in product(range(5), range(5)):
        pass
    for i in product(range(5), range(5), range(5)):
        pass

# Generated at 2022-06-12 14:27:09.100200
# Unit test for function product
def test_product():
    """
    Unit test for product().
    """
    import sys
    iterable = range(10)
    ip = product(iterable, iterable)
    total = 0
    for _ in ip:
        total += 1
    assert total == 100

# Generated at 2022-06-12 14:27:18.212119
# Unit test for function product
def test_product():
    """Test for function `product`."""
    from ..auto import tqdm
    from .test_tqdm import FakeTqdmFile

    # Test that product handles items of uneven length
    with tqdm(total=15, ascii=True, file=FakeTqdmFile(mode='w')) as t1:
        assert t1.total == 15
        for _ in product(range(2), range(3), range(5), tqdm_class=tqdm):
            t1.update()
            assert t1.n <= 15

    # Test that product handles nested items
    with tqdm(total=15, ascii=True, file=FakeTqdmFile(mode='w')) as t2:
        assert t2.total == 15

# Generated at 2022-06-12 14:27:23.931241
# Unit test for function product
def test_product():
    from six.moves import zip
    iterables = [["a", "b", "c"], [1, 2, 3], [4, 5, 6]]
    prod = list(product(iterables, tqdm_class=None))
    assert prod == list(itertools.product(*iterables))
    for i in zip(product(*iterables, tqdm_class=None, leave=False),
                 itertools.product(*iterables)):
        assert i[0] == i[1]

# Generated at 2022-06-12 14:27:28.801787
# Unit test for function product
def test_product():
    """Run doctest on the function `product`"""
    import doctest
    doctest.testmod(verbose=False)
    # Test with no alias
    import tqdm.contrib
    doctest.testmod(tqdm.contrib, verbose=False)
    # Test with simple alias
    import numpy as np
    old_np = np.__version__
    np.__version__ = np.__version__[::-1]
    doctest.testmod(tqdm.contrib, verbose=False)
    np.__version__ = old_np


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:27:33.513420
# Unit test for function product
def test_product():
    """Test `product` function."""
    from numpy import arange
    a = arange(10)
    b = arange(10)
    assert list(product(a, b)) == list(itertools.product(a, b))


if __name__ == "__main__":
    from pytest import main
    main([__file__])

# Generated at 2022-06-12 14:27:41.634833
# Unit test for function product
def test_product():
    """
    Unit test for product().
    """
    import numpy as np
    from numpy.testing import assert_array_equal

    # Test 1
    a = np.array([[0, 1], [2, 3]])
    b = np.array([4, 5])
    expected = np.array([[0, 4], [0, 5], [1, 4], [1, 5],
                         [2, 4], [2, 5], [3, 4], [3, 5]])
    actual = np.array(list(product(a, b)))
    assert_array_equal(expected, actual)

    # Test 2

# Generated at 2022-06-12 14:27:51.581517
# Unit test for function product
def test_product():
    from .tqdm import trange
    from .utils import FormatCustomTextExt
    from .gui import tqdm
    from .std import tqdm as tqdm_std
    from .std import tqdm_notebook
    from .notebook import tqdm as tqdm_nb
    from .notebook import tnrange
    from .contrib.concurrent import process_map as mp
    from .contrib.concurrent import thread_map as th
    from .contrib.concurrent import futures_map as fm

    # Tests with the internal iterable
    assert list(product(range(3), repeat=3, tqdm_class=trange)) == list(itertools.product(range(3), repeat=3))

# Generated at 2022-06-12 14:28:00.635723
# Unit test for function product
def test_product():
    import numpy as np
    N = 10000
    a = np.arange(N)
    l = [0] * N
    for i, _ in enumerate(product(a, a, tqdm_class=lambda x: (yield i))):
        l[i] += 1
    assert l == [1] * N
    for i, _ in enumerate(product(a, a, total=N)):
        l[i] += 1
    assert l == [2] * N

    l = [0] * N
    for i, _ in enumerate(product(a, a, total=None)):
        l[i] += 1
    assert l == [1] * N
    for i, _ in enumerate(product(a, a)):
        l[i] += 1

# Generated at 2022-06-12 14:28:02.629687
# Unit test for function product
def test_product():
    # single iterable
    assert list(product(range(5))) == list(itertools.product(range(5)))
    # multiple iterables
    assert list(product(range(5), range(5))) == list(
        itertools.product(range(5), range(5)))

# Generated at 2022-06-12 14:28:11.861595
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests_tqdm import pretest_posttest
    # verbose = True
    verbose = False
    ranges = [range(3), range(3), range(3)]
    pretest_posttest(ranges, itertools.product, unit='it', verbose=verbose)
    pretest_posttest(ranges, product, unit='it', verbose=verbose)


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:28:18.787710
# Unit test for function product
def test_product():
    """
    Simple unit test for function product.
    """
    from .tests import pretest_posttest
    from .tty_ns import tqdm_stdout_redirected
    from .utils import iterable_to_string

    from .utils import FormatStop
    from .std import tqdm_std

    iterables = [range(1, 4), [1, 2, 3, 4], ['a', 'b']]
    iterators = [itertools.product(*iterables), tqdm_std(product, iterables)]

    for j, i in enumerate(iterators):
        with tqdm_stdout_redirected() as _stdout:  # noqa
            try:
                gen = next(i)
            except FormatStop:
                pass

# Generated at 2022-06-12 14:28:23.995178
# Unit test for function product
def test_product():
    iterables = [[0, 1], [1, 2]]
    result = list(product(*iterables))
    assert result == [(0, 1), (0, 2), (1, 1), (1, 2)]

    def generator():
        for i in range(4):
            yield i

    result = list(product(generator()))
    assert result == [(0,), (1,), (2,), (3,)]

# Generated at 2022-06-12 14:28:31.167842
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import SetupTests
    SetupTests.setup_test()

    from ..auto import tqdm_gui
    from . import trange

    def test_len(*iterables, **tqdm_kwargs):
        return len(list(product(*iterables, **tqdm_kwargs)))

    assert test_len(range(10), range(10), tqdm_class=tqdm_gui.tqdm) == 100
    assert test_len(range(10), range(10), tqdm_class=tqdm_gui.tqdm_gui) == 100

    assert test_len(range(10), range(10)) == 100
    assert test_len(range(10), range(10), tqdm_kwargs={"gui": True}) == 100

   

# Generated at 2022-06-12 14:28:39.928539
# Unit test for function product
def test_product():
    """
    Test the `itertools` wrapper `product` with no `total` argument.
    """
    import numpy as np
    it = product(range(100), range(100))
    assert list(it) == list(itertools.product(range(100), range(100)))

    it = product(range(50))
    assert list(it) == list(itertools.product(range(50)))

    it = product(range(50), tqdm_class=tqdm_auto)
    assert list(it) == list(itertools.product(range(50)))

    it = product(range(50), range(50), tqdm_class=tqdm_auto)
    assert list(it) == list(itertools.product(range(50), range(50)))


# Generated at 2022-06-12 14:28:45.027743
# Unit test for function product
def test_product():
    """
    It tests tqdm.itertools.product
    """
    from .utils import StringIO
    from .gui import tqdm
    from .std import time
    import sys

    if sys.platform == 'win32':
        return  # no bar obtained when redirecting

    old_stdout = sys.stdout
    sys.stdout = StringIO()
    with tqdm(product(range(3), 'ABC'), desc="Test1") as t:
        for _ in t:
            time.sleep(0.01)
        sys.stdout.flush()

    # Test nested progress bar
    sys.stdout = StringIO()

# Generated at 2022-06-12 14:28:47.156983
# Unit test for function product
def test_product():
    for i, j in product(range(4), ['a', 'b', 'c', 'd']):
        pass


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:28:58.064711
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    import sys
    import pytest

    # Test all parameters and return values
    for kwargs in [{}, {"total": 9}, {"bar_format": '{l_bar}'}]:
        for func in [lambda: tqdm_auto, lambda: tqdm_auto(ascii=True)]:
            for range_param in [None, [lambda x: i for i in range(3)]]:
                for func_param in [None, [lambda x: x]]:
                    for x in product(*[range(3), ] * 3,
                                     tqdm_class=func(), **kwargs):
                        if range_param:
                            for i in range_param:
                                x = i(x)

# Generated at 2022-06-12 14:29:03.912874
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    assert list(product(["a", "b"], ["1", "2", "3"], ["!"],
                        tqdm_class=tqdm_auto.tqdm)) == \
        [("a", "1", "!"), ("a", "2", "!"), ("a", "3", "!"),
         ("b", "1", "!"), ("b", "2", "!"), ("b", "3", "!")]

# Generated at 2022-06-12 14:29:12.172840
# Unit test for function product
def test_product():
    """Test the function `product`."""
    from ..std import numpy as np

    def _cmp(x, y):
        return x[0] == y[0] and x[1] == y[1]

    input1 = (1, 2, 3)
    input2 = ('a', 'b')
    expected = [
        (1, 'a'), (1, 'b'),
        (2, 'a'), (2, 'b'),
        (3, 'a'), (3, 'b')]

    result = [x for x in product(input1, input2)]
    assert all([_cmp(x, y) for x, y in zip(expected, result)])

    result = [x for x in product(input1, input2, tqdm_class=None)]

# Generated at 2022-06-12 14:29:22.288482
# Unit test for function product
def test_product():
    import random
    import string
    import operator
    import sys
    # Python2/3 compat
    try:
        range = xrange
    except NameError:
        pass
    try:
        join = ("").join
    except NameError:
        pass

    def randint():
        return random.randint(1, 10)

    def randchoice():
        return random.choice(string.ascii_letters)

    def total(fun, *iterables):
        return reduce(operator.mul, map(fun, iterables))

    for func in [randint, randchoice]:
        for n in range(1, 10):
            for m in range(0, n+1):
                iterables = [func() for _ in range(m)]
                t = list(product(*iterables))

# Generated at 2022-06-12 14:29:31.301504
# Unit test for function product
def test_product():
    from .tests_common import closing, _range

    with closing(tqdm_auto(total=2 * 3 * 4, miniters=1, mininterval=0.01)) as pbar:
        reference = [x * 3 * 4 + y * 4 + z
                     for x in _range(2) for y in _range(3) for z in _range(4)]
        # Test list comprehension
        assert list(pbar(product([_range(2), _range(3), _range(4)]))) == reference
        # Test generator comprehension
        assert list(pbar(product(_range(2), _range(3), _range(4)))) == reference
        # Test exception
        try:
            next(pbar(product(2, 3, 4)))
            raise AssertionError
        except TypeError:
            pass

# Generated at 2022-06-12 14:29:35.801270
# Unit test for function product
def test_product():
    """
    Test for both cases :
    - with a default tqdm
    - with the tqdm_notebook
    """
    # check this doesn't raise an exception
    list(product(range(10), range(10), tqdm_class=tqdm_auto))
    list(product(range(10), range(10), tqdm_class=tqdm_auto._tqdm_notebook))

# Generated at 2022-06-12 14:29:40.762063
# Unit test for function product
def test_product():
    from ..utils import FormatMixin
    from numpy import prod
    for desc in ['', '&nbsp;'*50]:
        for t in [int, float, FormatMixin]:
            tqdm_kwargs = dict(tqdm_class=t, desc=desc, ascii=None)
            assert sum(product(range(10), tqdm_kwargs=tqdm_kwargs)) == 90
            assert sum(product(range(10), tqdm_kwargs=tqdm_kwargs)) == 90

    assert prod(product(range(7), tqdm_kwargs=dict(ascii=None))) == 5040
    assert prod(product(range(7), tqdm_kwargs=dict(ascii=None, total=None))) == 5040

# Generated at 2022-06-12 14:29:49.671356
# Unit test for function product
def test_product():
    import sys
    from .utils import FormatWarningsSupressor

    with FormatWarningsSupressor():
        from .utils import Timer

    # _range = (10 ** 4)
    _range = ((10 ** 8) / 8)
    sys_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    for a in [1, 3, 7, 10]:
        with Timer() as timer:
            for _ in itertools.product(range(_range), range(_range)):
                pass
        print("itertools.product(range(%s), range(%s)): %.3fs" %
              (_range, _range, timer.interval))


# Generated at 2022-06-12 14:29:57.109275
# Unit test for function product
def test_product():
    from .import main
    from . import formatbase

    from .bar import Bar
    from .trange import trange
    from .tqdm_gui import tqdm_gui

    with main.wrap_tqdm() as t:
        for i in t.product(*[range(-1, 4)] * 5, **{"tqdm_class": Bar}):
            assert len(i) == 5
            assert i[0] >= -1
            assert i[0] + i[1] + i[2] + i[3] + i[4] <= 7

        for i in trange(10):
            t.write(formatbase.format_sizeof(i), file=t.file)

# Generated at 2022-06-12 14:30:05.027014
# Unit test for function product
def test_product():
    """Unit test for function product()"""
    import numpy
    from ..utils import FormatCustomText

    iterables = list(range(3)), list(range(3))
    res = [list(x) for x in itertools.product(*iterables)]
    assert list(product(*iterables)) == res

    with tqdm_auto(desc=FormatCustomText('TEST'), unit='b', mininterval=0,
                   leave=False) as t:
        for i in product(*iterables, tqdm_class=tqdm_auto):
            t.set_description(FormatCustomText(i))
            pass  # NOQA
        assert t.n == numpy.prod([len(i) for i in iterables])
    return

# Generated at 2022-06-12 14:30:13.280813
# Unit test for function product
def test_product():
    """ Test suite for function product """
    import numpy as np
    import math
    import pickle
    from .utils import _range

    def prod(A):
        res = 1
        for e in A:
            res *= e
        return res


# Generated at 2022-06-12 14:30:21.630325
# Unit test for function product
def test_product():
    """Test for function product"""
    iter_ = product(range(0, 2), range(0, 2))
    assert list(iter_) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    iter_ = product(range(0, 2), range(0, 2), tqdm_class=None)
    assert list(iter_) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    iter_ = product(range(0, 2), range(0, 2), tqdm_class=lambda *x, **y: None)
    assert list(iter_) == [(0, 0), (0, 1), (1, 0), (1, 1)]

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:30:26.189702
# Unit test for function product
def test_product():
    """
    Unit test (only reused for auto doc).
    """
    from ..tqdm import trange
    from .tests_tqdm import pretest_posttest
    _ = pretest_posttest(itertools.product, product,
                         lambda: (range(2), 'xy'),
                         range(4),
                         kwargs=dict(tqdm_class=trange))
#
# Product unit test end

# Generated at 2022-06-12 14:30:36.528254
# Unit test for function product
def test_product():
    """ Unit test for function product """
    class TestIterator:
        """ Test iterator """
        def __init__(self, val):
            self.val = val

        def __iter__(self):
            yield self.val

    try:
        with tqdm_auto(total=1) as t:
            for i in product(TestIterator(1), tqdm_class=tqdm_auto):
                pass
    except TypeError:
        pass
    else:
        assert False, "Product failed"

# Generated at 2022-06-12 14:30:43.133772
# Unit test for function product
def test_product():
    from .. std import product
    from . import freeze_support
    from . import tgrind
    freeze_support()
    assert list(product('ABCD', 'xy')) == [('A', 'x'), ('A', 'y'),
                                           ('B', 'x'), ('B', 'y'),
                                           ('C', 'x'), ('C', 'y'),
                                           ('D', 'x'), ('D', 'y')]
    assert list(product(range(2), repeat=3)) == [(0, 0, 0), (0, 0, 1),
                                                 (0, 1, 0), (0, 1, 1),
                                                 (1, 0, 0), (1, 0, 1),
                                                 (1, 1, 0), (1, 1, 1)]

    t = tgrind.tgr

# Generated at 2022-06-12 14:30:46.084244
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests_tqdm import with_setup, _range  # NOQA

    @with_setup(pretest=True, posttest=True)
    def unit_test():
        """Unit test for function product"""
        for x in product([1, 2, 3, 4], (2, 3, 4), range(5)):
            yield x

    list(unit_test())

# Generated at 2022-06-12 14:30:52.121154
# Unit test for function product
def test_product():
    import numpy as np
    a = (1, 2, 3, 4, 5)
    b = (10, 20, 30)
    c = (100, 200, 300)

    with tqdm_auto(total=60) as bar:
        for res in product(a, b, c):
            bar.update()
            assert all(res[i] in t for i, t in enumerate((a, b, c)))
            assert len(res) == 3

# Generated at 2022-06-12 14:30:54.994506
# Unit test for function product
def test_product():
    from ._utils import ncycles
    ncycles(lambda: list(product(range(1), range(10), range(100), range(1000))), unit="it")


# Alias
prod = product

# Generated at 2022-06-12 14:31:01.263341
# Unit test for function product
def test_product():
    from ..tests._utils import in_new_session

    expected = list(itertools.product(*map(range, range(5))))
    assert list(itertools.product(*map(range, range(5)))) == expected
    assert list(product(*map(range, range(5)))) == expected
    assert list(product(*map(range, range(5)), ascii=True)) == expected
    assert list(product(*map(range, range(5)), tqdm_class=tqdm_auto)) == expected
    with in_new_session():
        assert (list(product(*map(range, range(5)), postfix="u", ascii=True))
                == expected)

# Generated at 2022-06-12 14:31:04.592536
# Unit test for function product
def test_product():
    """Unit test for product"""
    from ._deprecate import deprecate_kwargs

    with deprecate_kwargs():
        for _ in product(['a', 'b'], [1, 2], tqdm_class=tqdm_auto):
            pass

    for _ in product(['a', 'b'], [1, 2]):
        pass

# Generated at 2022-06-12 14:31:11.612948
# Unit test for function product
def test_product():
    import numpy as np
    data = [[1, 2], [3, 4]]
    true = [[1, 3],
            [1, 4],
            [2, 3],
            [2, 4]]
    assert (list(product(*data)) == true)
    assert (list(product(*data, tqdm_class=tqdm_auto)) == true)
    # Test total
    assert (len(list(product(*data, tqdm_class=tqdm_auto))) ==
            len(true))

# Generated at 2022-06-12 14:31:19.180929
# Unit test for function product
def test_product():
    """Unit test for product"""
    from .version import __version__
    from .tests import Python27TestCase, Python3TestCase, tests_level

    if tests_level() >= 3:
        class Test_product(Python3TestCase):
            klass = product
    elif tests_level() >= 2:
        class Test_product(Python27TestCase):
            klass = product

    def test_product_2_2(self):
        """Test product: 2**2"""
        assert list(self.klass(*[range(2)]*2)) == \
            [p for p in itertools.product(*[range(2)]*2)]

    def test_product_2_3(self):
        """Test product: 2**3"""

# Generated at 2022-06-12 14:31:22.417826
# Unit test for function product
def test_product():
    expected = list((i, j, k)
                    for i in 'ABC' for j in '123' for k in 'XY')
    result = []
    for i in product('ABC', '123', 'XY',
                     tqdm_class=tqdm_auto,
                     desc='test'):
        result.append(i)
    assert expected == result

# Generated at 2022-06-12 14:31:41.436876
# Unit test for function product
def test_product():
    """Test for the coverage of `itertools.product()`"""
    try:
        itertools.product
    except AttributeError:
        return
    lst = list
    prod = product([], repeat=0)
    assert lst(prod) == [()]
    prod = product([], repeat=4)
    assert lst(prod) == [(), (), (), ()]
    prod = product([3], repeat=0)
    assert lst(prod) == [()]
    prod = product([3], repeat=2)
    assert lst(prod) == [(3, 3)]
    prod = product([3, 2], repeat=0)
    assert lst(prod) == [()]
    prod = product([3, 2], repeat=3)

# Generated at 2022-06-12 14:31:49.438285
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .utils import FormatMixin
    from .utils import StringIO
    from .utils import BasicTestCase

    class ProductTestCase(BasicTestCase, FormatMixin):
        def test_product(self):
            """
            Test simple use of the `product` function.
            """
            with tqdm_auto(
                    _range=itertools.product(
                        _range(2), _range(2), _range(2)),
                    leave=False) as t:
                for _ in t:
                    pass

            self.write(t)
            output = self.getvalue()

            if self.bar_desc:
                self.assertIn("itertools.product", output)
            else:
                self.assertNotIn("itertools.product", output)


# Generated at 2022-06-12 14:31:53.810993
# Unit test for function product
def test_product():
    import itertools, random
    r = random.Random(1)
    rgen = lambda: r.random()
    L = [rgen(), rgen(), rgen(), rgen()]
    # Test product iterator
    assert list(itertools.product(*[L] * 4)) == list(product(*[L] * 4))


# Test decorator
if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:32:00.240752
# Unit test for function product
def test_product():
    from random import randrange
    from itertools import product, combinations

    def test_product_1(n, m):
        """
        Test product with no elements
        """
        s = set(combinations(range(n), m))
        s = set(map(lambda x: product(x), s))
        p = product_tqdm(range(n), repeat=m)
        p = set(map(lambda x: tuple(x), p))
        #print(p, s)
        assert s == p

    def test_product_2(n, m):
        """
        Test product with elements
        """
        s = set(combinations(range(n), m))
        s = set(map(lambda x: product(x, "abcd"), s))

# Generated at 2022-06-12 14:32:04.453339
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy
    with tqdm_auto(product(range(10), range(5), range(2))) as pbar:
        for _ in pbar:
            pass
        assert pbar.n == 5 * 10 * 2
    with tqdm_auto(product(range(10), numpy.arange(5), numpy.arange(2))) as pbar:
        for _ in pbar:
            pass
        assert pbar.n == 5 * 10 * 2

# Generated at 2022-06-12 14:32:08.591758
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for _ in product(
            range(30), range(30), range(30),
            tqdm_class=None):
        pass

    for _ in product(range(3), range(3), range(3)):
        pass

    for _ in product(range(100)):
        pass


if __name__ == '__main__':  # pragma: no cover
    test_product()

# Generated at 2022-06-12 14:32:10.691550
# Unit test for function product
def test_product():
    assert list(product(range(2), range(3))) == [(0, 0), (0, 1),
                                                (0, 2), (1, 0),
                                                (1, 1), (1, 2)]

# Generated at 2022-06-12 14:32:16.769948
# Unit test for function product
def test_product():
    """
    Test `product` function.
    """
    i = product(range(10), range(100), tqdm_class=tqdm_auto)
    assert len(list(i)) == 10 * 100

    j = product(*(range(10), ) * 100, tqdm_class=tqdm_auto)
    assert len(list(j)) == 10 ** 100

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:32:25.302792
# Unit test for function product
def test_product():
    "Check that `product` behaves as `itertools.product`"
    from .sizeof import sizeof
    from .utils import format_sizeof
    import sys

    n = 1000

# Generated at 2022-06-12 14:32:33.117158
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # Create a generator
    gen = product(['a', 'b', 'c'], [1,2,3], ['#'])
    # Get elements from generator
    assert next(gen) == ('a', 1, '#')
    assert next(gen) == ('a', 2, '#')
    assert next(gen) == ('a', 3, '#')
    assert next(gen) == ('b', 1, '#')
    assert next(gen) == ('b', 2, '#')
    assert next(gen) == ('b', 3, '#')
    assert next(gen) == ('c', 1, '#')
    assert next(gen) == ('c', 2, '#')
    assert next(gen) == ('c', 3, '#')

# Generated at 2022-06-12 14:33:01.703018
# Unit test for function product
def test_product():
    import numpy
    N = numpy.prod([2] * 9)

    X, Y = [], []
    for i in product(range(2), range(2), range(2), range(2),
                     range(2), range(2), range(2), range(2),
                     range(2), tqdm_class=tqdm_auto):
        X.append(i)
        Y.append(sum(i))

    assert (len(X) == N)
    assert (numpy.amax(Y) == 8)

# Generated at 2022-06-12 14:33:10.182715
# Unit test for function product
def test_product():
    import numpy as np
    # Test product(range(n)) == range(n)**2
    for n in range(1, 10):
        res = list(np.array(np.meshgrid(*([list(range(n))] * 2)))\
              .reshape(2, -1).T)
        assert (list(product(range(n))) == res)
        assert (list(product(range(n), tqdm_class=None)) == res)
    # Test itertools.product(*iterables) == modified_product(*iterables)
    for n in range(1, 10):
        for r in range(2, 7):
            iterables = [range(n) for _ in range(r)]
            itertools_kwargs = dict(repeat=n)

# Generated at 2022-06-12 14:33:12.411218
# Unit test for function product
def test_product():
    # Setup
    import tqdm
    try:
        from itertools import product
    except ImportError:
        pass  # Python 2.6
    else:
        assert tqdm.tqdm.product == product



# Generated at 2022-06-12 14:33:21.081201
# Unit test for function product
def test_product():  # pragma: no cover
    from .utils import closing, PY3
    from sys import stdout
    from .tqdm import tqdm
    from .std import time

    with closing(tqdm(total=1)) as pbar:
        time.sleep(1)
    with closing(tqdm(total=1)) as pbar:  # iterator
        time.sleep(1)
    with closing(tqdm(total=1)) as pbar:  # iterator
        time.sleep(1)
    with closing(tqdm(total=1)) as pbar:  # iterator
        time.sleep(1)
    with closing(tqdm(total=1)) as pbar:  # iterator
        time.sleep(1)

    out = []


# Generated at 2022-06-12 14:33:24.721218
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range

    @with_setup(pretest=tqdm_auto.tnrange.__self__.disable,
                posttest=tqdm_auto.tnrange.__self__.enable)
    def test():
        for i in product(_range(100), _range(100),
                         tqdm_class=tqdm_auto.tnrange):
            pass

    test()

# Generated at 2022-06-12 14:33:30.062998
# Unit test for function product
def test_product():
    import numpy as np
    tot = 1
    for i in range(1, 10):
        tot *= i
    for i in tqdm_auto.product(*(range(i) for i in range(1, 10))):
        pass
    try:
        assert i == tuple([i-1 for i in range(1, 10)])
    except NameError:
        pass


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:33:38.904369
# Unit test for function product
def test_product():
    from ..utils import StringIO
    import sys, io

    N = 1000

    # test no tqdm
    _inputs = [range(10)] * 3
    assert list(product(*_inputs)) == list(itertools.product(*_inputs))

    # test with tqdm
    _inputs = [range(N)] * 3
    _test = list(product(*_inputs, tqdm_class=tqdm_auto))
    assert list(itertools.product(*_inputs)) == _test

    # test with tqdm + desc + leave
    _inputs = [range(N)] * 3
    _test = list(product(*_inputs, tqdm_class=tqdm_auto, desc="test", leave=True))

# Generated at 2022-06-12 14:33:41.445660
# Unit test for function product
def test_product():
    for i in product([1, 2, 3], ['a', 'b', 'c'], total=9,
                     miniters=1, mininterval=0.05, smoothing=0):
        pass


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:33:50.526102
# Unit test for function product
def test_product():
    from numpy.testing import assert_almost_equal

    import random
    import string
    MODULUS = 10000019

    def _random_string(prefix):
        return prefix + ''.join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(6))

    # Use the same seed for repeatable runs.
    random.seed(12345)


# Generated at 2022-06-12 14:33:53.075836
# Unit test for function product
def test_product():
    for _, t in zip(product(*[[1] * 100, range(5), [1, 2]]),
                    itertools.product(*[[1] * 100, range(5), [1, 2]])):
        assert _ == t

# Generated at 2022-06-12 14:34:46.723155
# Unit test for function product
def test_product():
    from operator import mul
    from functools import reduce
    from numpy.random import shuffle

    for _ in range(5):
        lens = []
        for _ in range(5):
            lens.append(int(10*(1+1e-9*tst.BoolStr())))
        iterables = [list(range(i)) for i in lens]
        shuffle(iterables)  # in-place
        # check len()
        tqdm_product = list(product(*iterables))
        assert sum([1 for _ in product(*iterables)]) == \
            reduce(mul, lens, 1)
        product = list(itertools.product(*iterables))
        assert tqdm_product == product
        tqdm_product = list(product(*iterables, total=10**6))
        assert t

# Generated at 2022-06-12 14:34:51.997132
# Unit test for function product
def test_product():
    "Simple unittest to check that `product` wraps `itertools.product`"
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch.object(itertools, "product") as mock_method:
        mock_method.return_value = iter(['a'] * 10)
        foo = product('ab', 'cd')
        assert list(foo) == ['a'] * 10
        mock_method.assert_called_once_with('ab', 'cd')
        foo = product('ab', 'cd', tqdm_class=False)
        assert list(foo) == ['a'] * 10
        mock_method.assert_called_with('ab', 'cd')
        mock_method.reset_mock()

# Generated at 2022-06-12 14:35:00.008088
# Unit test for function product
def test_product():
    import sys
    import io

    def parse_product_output(out):
        # Extract the iterations count line and number of digits of
        # iterations count
        li = -1
        while True:
            try:
                li += out[li+1:].index('\x1b[K') + 1
            except ValueError:
                break
        count = int(out[li+5:].split(',')[0].split()[0])

        # Extract the rate line and extract the number of digits of
        # rate
        li = -1
        while True:
            try:
                li += out[li+1:].index('\r') + 1
            except ValueError:
                break
        rate = float(out[li:].split('it/s')[0].split()[-1])
        return count, rate

# Generated at 2022-06-12 14:35:05.209800
# Unit test for function product
def test_product():
    """
    Test the product function
    """
    a = (1, 2, 3)
    b = (4, 5, 6)

    prod = product(a, b)
    prod_list = list(prod)

    assert(list(prod) == [(1, 4), (1, 5), (1, 6),
                          (2, 4), (2, 5), (2, 6),
                          (3, 4), (3, 5), (3, 6)])

# Generated at 2022-06-12 14:35:08.568416
# Unit test for function product
def test_product():
    assert list(product(
        range(10), range(20), range(30),
        tqdm_class=tqdm_auto.tqdm,
        mininterval=0.0000000001)) == list(itertools.product(
            range(10), range(20), range(30)))

# Generated at 2022-06-12 14:35:16.744640
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from random import randint
    import time
    import sys
    import re
    import subprocess
    import signal
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)  # IOError: Broken pipe
    signal.signal(signal.SIGTSTP, signal.SIG_IGN)  # Ctrl+Z pressed
    signal.signal(signal.SIGINT, signal.SIG_IGN)  # Ctrl+C pressed

    # Check if all possible combinations are generated
    P = list("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    N = len(P)
    for size in (1, 3, 5, 8, 10, 15, 20, 30):
        charset

# Generated at 2022-06-12 14:35:23.046045
# Unit test for function product
def test_product():
    # This also tests that lazy-loading works
    import random
    rand = random.random
    # Sample data
    n = 20
    m = 5
    a = [0.01 * rand() for _ in range(n)]
    b = [0.01 * rand() for _ in range(n)]
    c = [0.01 * rand() for _ in range(n)]
    # Sample function for checking correctness
    def _product(a, b, c):
        for i in a:
            for j in b:
                for k in c:
                    yield (i, j, k)
    def _product_with_tqdm(a, b, c):
        for i in tqdm.product(a, b, c):
            yield i
    # Test correctness

# Generated at 2022-06-12 14:35:30.928396
# Unit test for function product
def test_product():
    """Test function product"""
    import inspect
    import warnings

    # Check function definition
    assert "tqdm_class" in inspect.getargspec(product).args

    # Check no warnings with default args
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        list(product([]))
    assert len(w) == 0

    # Check total
    with tqdm_auto() as t:
        assert t.total is None
        list(product([], []))
        assert t.total == 0
        list(product([], [], tqdm_class=tqdm_auto))
        assert t.total == 0
        list(product([1], [1], tqdm_class=tqdm_auto))
        assert t.total == 1

# Generated at 2022-06-12 14:35:39.115087
# Unit test for function product
def test_product():
    from collections import Iterable
    from numpy.random import randint
    from numpy import product
    for total in range(10):
        L = randint(2, 10, total)
        product_result = product(*(range(i) for i in L))
        tqdm_result = product(*(range(i) for i in L), tqdm_class=None)
        assert tqdm_result == product_result
        tqdm_result = product(*(range(i) for i in L), tqdm_class=tqdm_auto)
        assert tqdm_result == product_result
        tqdm_result = product(*(range(i) for i in L), tqdm_class=False)
        assert tqdm_result == product_result

# Generated at 2022-06-12 14:35:44.726638
# Unit test for function product
def test_product():
    iterables = [[1, 2], ['a', 'b']]
    assert list(product(*iterables)) == \
        [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b')]
    assert list(product(*iterables, **dict(tqdm_class=False))) == \
        [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b')]
    assert list(product(*iterables, ascii=True)) == \
        [b'1', b'2', b'a', b'b']
    assert list(product(*iterables, ascii=True, **dict(tqdm_class=False))) == \
        [b'1', b'2', b'a', b'b']
    # Test total=None
   

# Generated at 2022-06-12 14:36:19.278999
# Unit test for function product
def test_product():
    import numpy as np
    for s in ((-10, -10), (-10, -10, -10), (0, 0), (100, 100, 100)):
        shape = s
        a = np.random.randint(0, 100, size=shape)
        b = np.random.randint(0, 100, size=shape)
        c = np.random.randint(0, 100, size=shape)
        # Test stdlib
        list1 = [i for i in itertools.product(a, b, c)]
        # Test tqdm
        li

# Generated at 2022-06-12 14:36:26.521906
# Unit test for function product
def test_product():
    """
    Unit test for `product`.
    """
    from . import trange

    for cls in (tqdm_auto, trange):
        for a in range(6):
            for b in range(6):
                for c in range(6):
                    with cls(leave=False) as pbar:
                        for prod in product(range(a), range(b), range(c),
                                            tqdm_class=cls):
                            pass
                        assert pbar.n == a * b * c, \
                            "product(range({}), range({}), range({})) = {} != {}" \
                            .format(a, b, c, pbar.n, a * b * c)

# Generated at 2022-06-12 14:36:32.293530
# Unit test for function product
def test_product():
    """Test that the number of iteration is correct"""
    for attr in ["n", "n_disp"]:
        tqdm_kwargs = {"ascii": True, "miniters": 1}
        # test len(iterable)
        with tqdm_auto(**tqdm_kwargs) as t:
            for _ in product(range(5), range(5)):
                pass
        assert getattr(t, attr) == 25
        # test total
        with tqdm_auto(total=25, **tqdm_kwargs) as t:
            for _ in product(range(5), range(5)):
                pass
        assert getattr(t, attr) == 25

    # test tqdm_kwargs

# Generated at 2022-06-12 14:36:42.032270
# Unit test for function product
def test_product():
    for i in product([1, 2, 3, 4], ['a', 'b', 'c']):
        assert i[0] != i[1]
        assert i[0] != i[1]
        assert i[0] != i[1]
        assert i[0] != i[1]
    assert i[0] == 4
    assert i[1] == 'c'

    for i in product([1, 2, 3, 4], ['a', 'b', 'c'], tqdm_class=tqdm_auto):
        assert i[0] != i[1]
        assert i[0] != i[1]
        assert i[0] != i[1]
        assert i[0] != i[1]
    assert i[0] == 4
    assert i[1] == 'c'




# Generated at 2022-06-12 14:36:48.147304
# Unit test for function product
def test_product():
    iterables = list(range(1, 10))

    def test(count=False):
        if count:
            try:
                len(iterables)
            except TypeError:
                total = None
            else:
                total = 1
                for i in iterables:
                    total *= i
            output = list(product(*iterables, tqdm_class=tqdm_auto, total=total))
        else:
            output = list(product(*iterables, tqdm_class=tqdm_auto))
        assert len(output) == 362880
        from math import factorial

# Generated at 2022-06-12 14:36:54.718078
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import types
    list(product([1, 2, 3], [4, 5, 6]))
    list(product(range(4), range(4)))
    list(product(range(4), range(4), range(4)))
    it = product(range(4), range(4), range(4))
    assert isinstance(it, types.GeneratorType)
    assert next(it) == (0, 0, 0)
    assert next(it) == (0, 0, 1)
    assert next(it) == (0, 0, 2)
    assert next(it) == (0, 0, 3)
    assert next(it) == (0, 1, 0)
    assert next(it) == (0, 1, 1)

# Generated at 2022-06-12 14:37:01.132457
# Unit test for function product
def test_product():
    def prod(*args):
        prod = 1
        for arg in args:
            prod *= arg
        return prod

    from .utils import TotalCounter
    t = TotalCounter();
    assert (tuple(product(range(10), total=t)) == tuple(product(range(10))))
    assert (tuple(product(range(10))) == tuple(product(range(10), total=0)))
    assert (tuple(product(range(10), range(10), total=t)) ==
            tuple(product(range(10), range(10))))
    assert (tuple(product(range(10), range(10), range(10), total=t)) ==
            tuple(product(range(10), range(10), range(10))))