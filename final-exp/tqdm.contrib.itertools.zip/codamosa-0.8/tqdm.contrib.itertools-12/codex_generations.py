

# Generated at 2022-06-12 14:27:04.791901
# Unit test for function product
def test_product():
    """
    Unit test for  the function `product`
    """
    # test for tqdm_class
    for cls in (tqdm_auto, ):
        for a, b in cls(product(range(10), ["a", "b"], unit="xyz")):
            pass
        for a, b, c in cls(product(range(10), ["a", "b"], "1"),
                            unit="xyz"):
            pass
        for j in cls(product(range(3), "abcd")):
            pass
        for a in cls(product(range(10), unit="elems")):
            pass
    # test for total

# Generated at 2022-06-12 14:27:08.009827
# Unit test for function product
def test_product():
    """Tests the function `product`."""
    for _ in product([1, 2, 3], repeat=2):
        pass
    for _ in product(tqdm_class=type, iterables=[1, 2, 3], repeat=2):
        pass

# Generated at 2022-06-12 14:27:15.655002
# Unit test for function product
def test_product():
    from .tests import TestCase
    import sys
    import itertools
    import unittest

    class TestProduct(TestCase):

        def test_product(self):
            for n, n2 in zip(
                    tqdm.product(range(4), range(4)),
                    itertools.product(range(4), range(4))):
                self.assertEqual(n, n2)

    unittest.main(argv=sys.argv, verbosity=2)
    del sys, itertools, unittest


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:27:21.635802
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy import prod

    N, M, L = map(int, randint(0, 10, size=3))
    for n in [0, N]:
        for m in [0, M]:
            for l in [0, L]:
                for _ in [0, float('inf')]:
                    t = 0
                    for i in product(range(n), range(m), range(l), total=_):
                        t += 1
                    assert t == prod([n, m, l])

# Generated at 2022-06-12 14:27:29.089700
# Unit test for function product
def test_product():
    import sys
    from pytest import raises
    from .utils import closing, FakeBrokenPipeError
    msg = r"No _tqdm_cls specified"
    with raises(TypeError, match=msg):
        with closing(product) as p:
            next(p)

    with closing(product(range(10))) as p:
        assert next(p) == (0,)
        assert next(p) == (1,)
        assert list(p)[-1] == (9,)

    with closing(product(range(10), range(10))) as p:
        assert next(p) == (0, 0)
        assert next(p) == (0, 1)
        assert list(p)[-1] == (9, 9)

    msg = r"object int can't be used in 'instanceof' expression"
   

# Generated at 2022-06-12 14:27:34.452852
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .monitor import thread_monitor
    from ..utils import format_sizeof
    import time
    import random
    print('-' * 100)
    print('Unit test for function itertools product')

    def f(a, b, t=1):
        time.sleep(t)

    tqdm_class = tqdm_auto

    kwargs = {
        'a': 'a',
        'b': 'b'
    }
    # test with timeout
    with thread_monitor(**kwargs) as tm:
        for _ in product(
                [random.uniform(1e-8, 1) for _ in range(5)],
                tqdm_class=tqdm_class):
            f(**kwargs)

# Generated at 2022-06-12 14:27:42.239674
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import sys
    import tqdm

    with tqdm.tqdm(file=sys.stderr, mininterval=0.1, miniters=0,
                   leave=False) as t:

        for i in product([1, 2, 3], repeat=3,
                         tqdm_class=tqdm.tqdm,
                         desc='product(...)'):
            pass
        assert t.n == 27

        for i in product([1, 2, 3], repeat=3,
                         tqdm_class=tqdm.tqdm_notebook,
                         desc='product(...)'):
            pass
        assert t.n == 54


# Generated at 2022-06-12 14:27:52.738619
# Unit test for function product
def test_product():
    import random
    import time
    a = list(range(5))
    b = list(range(5))

    # Test tqdm(a) case
    time.sleep(0.1)
    R = []
    for i in product(a, tqdm_class=tqdm_auto):
        R.append(i)
    assert R == list(product(a))

    # Test tqdm(a, b) case
    time.sleep(0.1)
    R = []
    for i in product(a, b, tqdm_class=tqdm_auto):
        R.append(i)
    assert R == list(product(a, b))

    # Test tqdm(a, b, c) case
    time.sleep(0.1)

# Generated at 2022-06-12 14:28:01.356635
# Unit test for function product
def test_product():
    """
    Unit test for `product`.
    """
    assert list(product([1, 2, 3], [4, 5, 6])) == \
        [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]

# Generated at 2022-06-12 14:28:08.739384
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    assert list(product(range(3), range(3), range(3))) == list(itertools.product(range(3), range(3), range(3)))
    assert list(product(range(3), range(3), range(3), tqdm_class=tqdm)) == list(itertools.product(range(3), range(3), range(3)))

    class test:
        def __len__(self):
            return 1
    assert list(product(test(), tqdm_class=tqdm)) == list(itertools.product(test()))

# Generated at 2022-06-12 14:28:18.290113
# Unit test for function product
def test_product():
    from sys import version as sys_version
    from os.path import isfile as path_isfile
    from os import remove as path_remove
    from random import randrange, shuffle
    from time import sleep

    if 'PyPy' not in sys_version:
        # xrange not supported on PyPy yet
        xrange = range

    for stream in [None, 'IO', 'Index', 'File']:
        t = tqdm(xrange(10), file=stream)
        for i in t:
            if i == 5:
                t.set_description("i = %i" % i)
                break

        # Avoid dummy tqdm (used by Python < 3)
        if t.total is not None:
            assert t.n == 6
            assert t.n == t.last_print_n + 1
            assert t

# Generated at 2022-06-12 14:28:27.899373
# Unit test for function product
def test_product():
    import numpy as np

    for array, fast_numpy_product in [(range(50000), False),
                                      (np.arange(50000), True)]:
        ans = [tuple(i) for i in product(array, array)]
        if fast_numpy_product:
            np_ans = np.array(ans)
            np_ans = list(np_ans.reshape(len(array), -1))
            ans = [list(q) for q in np_ans]
        np_ans = np.product(array, axis=0)
        assert len(ans) == len(np_ans)
        assert ans[0] == tuple(np_ans[0]), ans[0]
        assert ans[1] == tuple(np_ans[1]), ans[1]

# Generated at 2022-06-12 14:28:34.297335
# Unit test for function product
def test_product():
    """Test function product."""
    from ..utils import is_iterable
    assert len(list(product(
        range(3),
        range(3),
        range(3),
        tqdm_class=lambda x=None: False,
    ))) == 3 ** 3
    assert len(list(product(
        range(3),
        range(3),
        range(3),
        tqdm_class=lambda x=None: None,
    ))) == 3 ** 3
    assert is_iterable(product(
        range(3),
        range(3),
        range(3),
        tqdm_class=lambda x=None: False,
    ))

# Generated at 2022-06-12 14:28:38.552405
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    arr0 = [0, 1]
    arr1 = [10, 11, 12]
    prod = product(arr0, arr1)
    pprod = itertools.product(arr0, arr1)
    for p, pp in zip(prod, pprod):
        assert p == pp

# Generated at 2022-06-12 14:28:41.286503
# Unit test for function product
def test_product():
    import numpy as np
    lista = range(0, 25)
    listb = range(100, 300, 5)
    listc = range(-1000, 1000, 50)
    test_list = [lista, listb, listc]
    for x in product(lista, listb, listc):  # test loop
        assert x in itertools.product(*test_list)  # test conte

# Generated at 2022-06-12 14:28:48.138310
# Unit test for function product
def test_product():
    from pytest import raises
    from .utils import FormatCustom2
    for tqdm_cls in [tqdm_auto, FormatCustom2]:
        # with tqdm_cls() as t:
        with tqdm_cls(unit_scale=True) as t:
            assert isinstance(t, tqdm_cls)

# Generated at 2022-06-12 14:28:54.510648
# Unit test for function product
def test_product():
    """Unit tests."""
    assert list(product('ab', range(3))) == list(itertools.product('ab', range(3)))
    assert list(product('ab', range(3), tqdm_class=False)) == list(itertools.product('ab', range(3)))
    assert list(product('ab' * 99, range(3))) == list(itertools.product('ab' * 99, range(3)))

# Generated at 2022-06-12 14:29:03.495174
# Unit test for function product
def test_product():
    """Unit test for product."""
    if not hasattr(itertools, 'product'):  # pragma: no cover
        import nose
        raise nose.SkipTest
    try:
        # reduce size in case of memory error
        for _ in product((1, 2), repeat=4, tqdm_class=tqdm_auto):
            pass
    except MemoryError as e:
        raise AssertionError(str(e))
    try:
        # reduce size in case of maximum recursion depth exceeded
        for _ in product((1, 2), (1, 2), (1, 2), (1, 2)):
            pass
    except RuntimeError as e:
        raise AssertionError(str(e))
    # known failing test case
    # [(x, y) for x in range(3) for y in range(

# Generated at 2022-06-12 14:29:11.575546
# Unit test for function product
def test_product():
    import numpy as np
    try:
        import itertools as it
        it.product = tqdm.itertools.product
        assert list(it.product(range(3))) == list(tqdm.itertools.product(range(3)))
        assert list(it.product(range(3), range(4))) == list(tqdm.itertools.product(range(3), range(4)))
    except ImportError:
        pass
    # py2.6
    assert list(tqdm.itertools.product()) == list(itertools.product())
    assert list(tqdm.itertools.product([])) == list(itertools.product([]))
    assert list(tqdm.itertools.product([1])) == list(itertools.product([1]))

# Generated at 2022-06-12 14:29:19.790638
# Unit test for function product
def test_product():
    # Test for "total" argument
    _count = 0
    for _ in product([1, 2, 3], repeat=2, tqdm_class=tqdm_auto):
        _count += 1
    assert _count == 9
    _count = 0
    for _ in product([1, 2, 3], repeat=2, tqdm_class=tqdm_auto, total=6):
        _count += 1
    assert _count == 6
    _count = 0
    for _ in product([], repeat=2, tqdm_class=tqdm_auto):
        _count += 1
    assert _count == 0
    _count = 0
    for _ in product([], repeat=2, tqdm_class=tqdm_auto, total=6):
        _count += 1
    assert _count == 0


# Generated at 2022-06-12 14:29:31.629585
# Unit test for function product
def test_product():
    from .main import tqdm
    from .utils import FormatCustomText
    from .gui import tqdm as tqdm_gui
    from time import sleep
    # Input validation
    try:
        for _ in tqdm.product("ab", total=-123):
            pass
    except ValueError:
        pass
    else:
        raise AssertionError("tqdm(..., total=-123) should not be allowed")
    # Basic
    try:
        for _ in tqdm.product("ab", total=None):
            pass
    except Exception:
        raise AssertionError("tqdm(..., total=None) should not raise")
    # Format

# Generated at 2022-06-12 14:29:36.963456
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import gc
    import sys

    if sys.version_info[0] == 2:
        range = xrange  # noqa

    for i in range(4):
        for j in range(4):
            for k in range(4):
                list(product(range(i), range(j), range(k), tqdm_class=tqdm_auto))
        gc.collect()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:29:44.881318
# Unit test for function product
def test_product():
    from itertools import product
    from .utils import format_sizeof

    for i in range(2, 5):
        for j in range(2, 5):
            for k in range(2, 5):
                for l in range(2, 5):
                    a = range(i)
                    b = range(j)
                    c = range(k)
                    d = range(l)
                    total = i * j * k * l
                    print('\nTesting product(a, b, c, d), where a,b,c,d =', i, j, k, l)
                    assert list(product(a, b, c, d)) == list(itertools.product(a, b, c, d))

# Generated at 2022-06-12 14:29:53.877280
# Unit test for function product
def test_product():
    from .._utils import _range
    from .prange import trange
    from .pandas import tqdm_pandas
    from .ipython import tqdm_notebook

    for _ in product('abcd', 'xy'):
        pass
    for _ in product('abcd', _range(2)):
        pass

    for _ in product('abcd', 'xy', total=4):
        pass
    for _ in product('abcd', _range(2), total=4):
        pass

    for _ in product('abcd', 'xy', mininterval=0.01):
        pass

    for _ in product('abcd', 'xy', tqdm_class=trange):
        pass
    for _ in product('abcd', _range(2), tqdm_class=trange):
        pass

# Generated at 2022-06-12 14:29:56.680836
# Unit test for function product
def test_product():
    from ._utils import _test_iterable
    _test_iterable(product(range(100), range(100), tqdm_class=tqdm_auto.tqdm),
                   itertools.product(range(100), range(100)))

# Generated at 2022-06-12 14:30:04.496072
# Unit test for function product
def test_product():
    """Unit test"""
    assert set(product(range(1000), repeat=10)) == set(itertools.product(range(1000), repeat=10))
    assert set(product(range(1000), range(1000), repeat=10)) == set(
        itertools.product(range(1000), range(1000), repeat=10))
    assert set(product(range(1000))) == set(itertools.product(range(1000)))
    assert set(product(range(1000), range(1000))) == \
        set(itertools.product(range(1000), range(1000)))
    assert set(product(range(1000), range(1000), range(1000))) == \
        set(itertools.product(range(1000), range(1000), range(1000)))

# Generated at 2022-06-12 14:30:10.504649
# Unit test for function product
def test_product():
    """ Unit test for function product """
    from ..helpers import ExceptionCatch

    # No exception should be raised upon correct usage
    with ExceptionCatch(all_errors=True):
        for _ in list(product([1, 2], [3, 4])):
            pass

    # Should raise exception upon invalid usage
    with ExceptionCatch(all_errors=True):
        # pylint: disable=expression-not-assigned
        list(product([1, 2], [3, 4], tqdm_class=None))

# Generated at 2022-06-12 14:30:15.808039
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup
    from . import _range

    def t(a, b, c, n):
        with tqdm_auto(_range(a * b * c)) as t:
            for x, y, z in product(_range(a), _range(b), _range(c)):
                t.update()
        assert t.n == a * b * c

    with_setup(t, 3, 5, 7, n=1)
    with_setup(t, 3, 5, 7, n=2)

# Generated at 2022-06-12 14:30:23.605026
# Unit test for function product
def test_product():
    from .tests import closing, pretest_posttest
    from .tests import tqdm_class_generic, tqdm_class_tqdm
    import numpy as np
    import random
    import sys

    # Test that tqdm plays well with the context manager
    with closing(tqdm_class_generic(range(3), leave=False)) as t:
        next(t)
        # Test nested tqdm context managers
        with closing(tqdm_class_generic(range(3))) as t2:
            next(t2)

    # Test that tqdm does not throw when using zip
    for _ in tqdm_class_generic(zip(range(3), range(4)), leave=False):
        pass

    # Test that tqdm does not throw when using map

# Generated at 2022-06-12 14:30:30.900300
# Unit test for function product
def test_product():
    # Depends on numpy, for numpy.prod
    import numpy as np
    import sys
    import time
    from .tqdm import tqdm

    for A in (list, tuple, set):
        for B in (list, tuple, set):
            for C in (list, tuple, set):
                for D in (list, tuple, set):
                    t = A(range(2))
                    u = B(range(2))
                    v = C(range(2))
                    w = D(range(2))
                    # Test without total
                    res = list(product(t, u, v, w))
                    assert res == list(itertools.product(t, u, v, w))
                    # Test with total

# Generated at 2022-06-12 14:30:39.904471
# Unit test for function product
def test_product():
    """Unit test for the `product` function"""
    from .exceptions import TqdmTypeError
    from .utils import _range
    from .gui import trange

    for tqdm in [_range, trange]:
        assert sum(tqdm.product(range(x), repeat=2) for x in [0, 1, 2]) \
            == [0, 1, 4]
        exception_raised = False
        try:
            tqdm.product(range(2), ints=1)
        except TqdmTypeError:
            exception_raised = True
        assert exception_raised
        assert list(tqdm.product([1, 2], repeat=2)) \
            == [(1, 1), (1, 2), (2, 1), (2, 2)]

# Generated at 2022-06-12 14:30:43.364320
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    list(product(range(3), repeat=2, tqdm_class=tqdm_auto)) \
        == list(itertools.product(range(3), repeat=2))
    list(product(range(3), repeat=2, tqdm_class=tqdm_auto)) \
        == [[i, j] for i in range(3) for j in range(3)]

# Generated at 2022-06-12 14:30:52.122778
# Unit test for function product
def test_product():
    """
    Unit test `tqdm.itertools.product`.
    """
    from numpy import product as nprod
    from ..smart_comprehension import printable_frame

    from .tests_tqdm import pretest_posttest_bool

    with printable_frame():
        for i in range(2):
            for j in range(1, 3):
                for k in range(2, 4):
                    with pretest_posttest_bool() as (pt, _):
                        assert pt == (i * j * k == nprod(product(range(i),
                                                               range(1, j + 1),
                                                               range(2, k + 2))))

# Generated at 2022-06-12 14:30:59.563998
# Unit test for function product
def test_product():
    import numpy as np
    np.testing.assert_equal(
        list(product(range(2), tqdm_class=tqdm_auto)),
        list(itertools.product(range(2))))
    np.testing.assert_equal(
        list(product(range(2), range(3), tqdm_class=tqdm_auto)),
        list(itertools.product(range(2), range(3))))
    np.testing.assert_equal(
        list(product(range(2), range(3), range(4), tqdm_class=tqdm_auto)),
        list(itertools.product(range(2), range(3), range(4))))

# Generated at 2022-06-12 14:31:04.746730
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from ..utils import format_sizeof
    from random import randint
    # ------------------------------------------------------------------------
    # Test: https://docs.python.org/3.5/library/itertools.html#itertools.product
    # ------------------------------------------------------------------------
    # Cartesian product of input iterables.
    # Equivalent to nested for-loops in a generator expression.
    # For example, product(A, B) returns the same as ((x,y) for x in A for y in B).
    # The leftmost iterators are in the outermost for-loop, so the output tuples
    # cycle in a manner similar to an odometer (with the rightmost element
    # changing on every iteration).
    # To compute the product of an iterable with itself, specify the number

# Generated at 2022-06-12 14:31:14.427827
# Unit test for function product
def test_product():
    # Test stdout
    assert next(product(range(6), range(6), ['a', 'b', 'c'], tqdm_class=tqdm_auto.tqdm)) == (0, 0, 'a')

    assert next(product(range(3), range(3), ['a', 'b', 'c'], tqdm_class=tqdm_auto.tqdm)) == (0, 1, 'a')


# Generated at 2022-06-12 14:31:16.268235
# Unit test for function product
def test_product():
    list(product(range(3), repeat=3, tqdm_class=tqdm_auto))
    list(product(range(3), range(8)))

# Generated at 2022-06-12 14:31:23.598935
# Unit test for function product
def test_product():
    import sys
    import numpy as np

    if sys.version_info[0] == 2:
        range = xrange
    invalid_inputs = [
        None,
        'abc',
        ['a'],
        range(10)
    ]

    for i in invalid_inputs:
        try:
            list(product(i))
        except Exception:
            pass
        else:
            assert False, "Should raise exception for invalid input"

    # Empty iterator
    list(product([]))

    for dims in range(2, 6):
        for size in range(0, 40):
            for dimsize in range(1, 8):
                inputiterator = [range(dimsize) for i in range(dims)]
                result = list(product(*inputiterator, total=size))

# Generated at 2022-06-12 14:31:27.406332
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    assert list(product('abc', '123')) == [(x, y) for x in 'abc' for y in '123']
    assert list(product('abc', repeat=2)) == list(
        product('abc', 'abc'))
    assert list(product(range(1, 4), 'abc')) == [(1, 'a'), (1, 'b'), (
        1, 'c'), (2, 'a'), (2, 'b'), (2, 'c'), (3, 'a'), (3, 'b'), (3, 'c')]

# Generated at 2022-06-12 14:31:35.541508
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ._utils import format_time
    import time
    len_iterables = [3, 7, 5]
    lens = list(map(len, len_iterables))
    total = 1
    for i in lens:
        total *= i
    iterables = [list(range(i)) for i in len_iterables]
    t0 = time.time()
    for _ in product(*iterables, tqdm_class=tqdm_auto, unit='iB'):
        pass
    total_time = time.time() - t0
    print(format_time(total_time))
    assert total_time > 0

# Generated at 2022-06-12 14:31:49.313641
# Unit test for function product
def test_product():
    """ Test product """
    assert list(product([1, 2], repeat=1)) == list(itertools.product([1, 2], repeat=1))
    assert list(product([1, 2], repeat=2)) == list(itertools.product([1, 2], repeat=2))
    assert list(product([1, 2], repeat=3)) == list(itertools.product([1, 2], repeat=3))
    assert list(product([1, 2], [1, 2], repeat=1)) == list(itertools.product([1, 2], [1, 2], repeat=1))
    assert list(product([1, 2], [1, 2], repeat=2)) == list(itertools.product([1, 2], [1, 2], repeat=2))

# Generated at 2022-06-12 14:31:56.914544
# Unit test for function product
def test_product():
    from .main import tqdm_no_cli
    from .gui import tqdm_notebook

    def unit_test(tqdm):
        assert list(tqdm(product([1, 2], tqdm_class=None))) == [(1, 1), (1, 2),
                                                               (2, 1), (2, 2)]

        assert list(tqdm(product([1, 2], [3, 4],
                                 tqdm_class=None))) == [(1, 3), (1, 4), (2, 3), (2, 4)]

        # unit test for tuple iterables with total
        assert list(tqdm(product((1, 2), tqdm_class=None))) == [(1, 1), (1, 2),
                                                               (2, 1), (2, 2)]


# Generated at 2022-06-12 14:32:02.079470
# Unit test for function product
def test_product():
    import re
    from ._deprecate import deprecated
    from .utils import format_sizeof
    from . import trange
    with trange(1, leave=True) as t:
        for i in product(range(1000), repeat=2):  # noqa
            t.update()

    # Test case with deprecated argument!
    with deprecated(
            'tqdm_instance parameter is deprecated, use tqdm_class instead.'):
        x = list(product(range(10), repeat=2, tqdm_instance=tqdm_auto))
    assert x[0] == (0, 0)

    # Test case with deprecated argument!

# Generated at 2022-06-12 14:32:04.896783
# Unit test for function product
def test_product():
    iterables = ["ABCD", range(4)]
    with tqdm_auto(desc="test_product",
                   leave=False) as t:
        for x in product(*iterables,
                         total=len(iterables)):
            assert x
            t.update()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:32:06.821776
# Unit test for function product
def test_product():

    for it in product('abc', repeat=4):
        assert len(it) == 4
        assert isinstance(it, tuple)
        for i in it:
            assert i in 'abc'

# Generated at 2022-06-12 14:32:13.274701
# Unit test for function product
def test_product():
    from .tests import TqdmSeeInStdoutTestCase
    import sys
    import re

    class TestProduct(TqdmSeeInStdoutTestCase):
        __metaclass__ = TqdmSeeInStdoutTestCase
        __params__ = [['ab', range(6)]]

        def _run(self, tup):
            for i in tqdm.product(*tup):
                pass

    with TestProduct():
        if sys.version_info[:2] < (3, 5):
            assert TqdmSeeInStdoutTestCase.tqdm_cls_found
        else:
            print("tqdm_cls_found: ", TqdmSeeInStdoutTestCase.tqdm_cls_found)
            assert not TqdmSeeInStdoutTestCase

# Generated at 2022-06-12 14:32:19.062790
# Unit test for function product
def test_product():
    """Test product."""
    from ..main import tqdm

    example_generator = product(range(1000), range(1000))
    example_generator = iter(example_generator)

    next(example_generator)
    assert (0, 0) == next(example_generator)

    example_generator = tqdm(example_generator)
    assert (0, 1) == next(example_generator)
    assert (0, 2) == next(example_generator)

# Generated at 2022-06-12 14:32:27.410666
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # Test for trivial case
    try:
        for i, j in product([], [], tqdm_class=None):
            assert False
        for i, j in product([0], [0], tqdm_class=None):
            assert False
        for i, j in product([0], [0], tqdm_class=None):
            assert False
        assert False
    except StopIteration:
        pass
    except:
        assert False

    # Test for non-trivial case
    s = "abcd"
    with tqdm_auto(total=len(s) * len(s)) as t:
        for i, j in product(s, s):
            assert (i, j)
            t.update()


# Generated at 2022-06-12 14:32:32.018415
# Unit test for function product
def test_product():
    """Test ``tqdm.itertools.product``"""
    ret = list(product(range(3), range(3), tqdm_class=None))
    assert ret == list(itertools.product(range(3), range(3)))
    ret = list(product(range(3), range(3), tqdm_class=tqdm_auto))
    assert ret == list(itertools.product(range(3), range(3)))

# Generated at 2022-06-12 14:32:37.670701
# Unit test for function product
def test_product():
    """ Simple unit tests for product() """
    import tempfile
    import os
    import sys
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

# Generated at 2022-06-12 14:32:53.692681
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.testing import assert_array_equal
    assert list(product([1, 2], repeat=2)) == \
        [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product(['a', 'b', 'c'], [1, 2])) == \
        [('a', 1), ('a', 2), ('b', 1), ('b', 2), ('c', 1), ('c', 2)]

#     from numpy import array
#     from numpy.random import random
#     assert_array_equal(array(list(product(random((2, 3, 3)), repeat=2))),
#                        array(list(itertools.product(random((2, 3, 3)),
#                                                    repeat=2))))


# Generated at 2022-06-12 14:33:01.283153
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, pretest, posttest, _range
    if pretest():
        return

# Generated at 2022-06-12 14:33:02.771767
# Unit test for function product
def test_product():
    """
    Test the itertools.product wrapper
    """
    #TODO: Add a test
    pass

# Generated at 2022-06-12 14:33:11.109717
# Unit test for function product
def test_product():
    for i in product(['0'], ['a']):
        assert i == ('0', 'a')

    for i in product(['0', '1'], ['a', 'b']):
        assert i in (('0', 'a'), ('0', 'b'), ('1', 'a'), ('1', 'b'))

    for i in product(['0', '1'], ['a'], ['c']):
        assert i in (('0', 'a', 'c'), ('1', 'a', 'c'))

    for i in product([0, 1], ['a']):
        assert i == (0, 'a') or i == (1, 'a')


# Generated at 2022-06-12 14:33:11.949928
# Unit test for function product
def test_product():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:33:20.809188
# Unit test for function product
def test_product():
    """Test function `tqdm.itertools.product`"""
    from random import randint, seed
    from ..tqdm_gui import tqdm

    seed(1)
    for _ in tqdm.itertools.product(range(1000), repeat=4):
        pass

    for max_len in (1, 10, 50, 100):
        for max_width in (1, 10, 50, 100):
            iterable = []
            for _ in range(randint(0, max_len)):
                iterable.append(range(randint(0, max_width)))

            # Test with auto tqdm
            for _ in tqdm.itertools.product(*iterable):
                pass

            # Test with gui tqdm

# Generated at 2022-06-12 14:33:23.792758
# Unit test for function product
def test_product():
    """Test for product"""
    for _ in product(range(1000), range(1000)):
        pass
    for _ in product(range(1000), range(1000),
                     tqdm_class=lambda x: x):
        pass
    for _ in product():
        pass


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:33:28.408450
# Unit test for function product
def test_product():
    # Smoke test
    assert not hasattr(product([1, 2], [3, 4], tqdm_class=None), 'close')
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    assert hasattr(product([1, 2], [3, 4]), 'close')
    # Functionality test
    result = []
    for i in product([1, 2], [3, 4]):
        result.append(i)
    assert result == [(1, 3), (1, 4), (2, 3), (2, 4)]
    # Test with total argument
    i = product([1, 2], [3, 4], total=3)
    assert hasattr(i, "total")
    assert i.total == 3

# Generated at 2022-06-12 14:33:32.981126
# Unit test for function product
def test_product():
    sample_iterables = [
        'abcd', 'efghi', range(3), range(4), range(5), range(6)]

    target = list(itertools.product(*sample_iterables))
    assert list(product(*sample_iterables)) == target


if __name__ == "__main__":
    from ._utils import _test_wrapper
    _test_wrapper("itertools")

# Generated at 2022-06-12 14:33:41.091327
# Unit test for function product
def test_product():
    "Test `product()` function"
    from ..utils import FormatWrapBase
    from ..utils import format_interval
    from ..._utils import _range
    from ..._tqdm_test_helpers import StringIO, closing
    from ..._tqdm import default_mininterval

    with StringIO() as our_file:
        with closing(
                tqdm_auto(total=1, file=our_file, mininterval=default_mininterval)) \
                as t:
            for i in product(_range(3), tqdm_class=tqdm_auto):
                pass


# Generated at 2022-06-12 14:34:10.882839
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import gc
    from ._utils import TransformIO
    with TransformIO(tqdm_class=tqdm_auto) as transformio:
        with transformio:
            list_ = [list(product(range(100), repeat=i)) for i in range(5)]
        gc.collect()
        assert len(list_) == 5
        assert len(list_[0]) == 100 ** 0
        assert len(list_[1]) == 100 ** 1
        assert len(list_[2]) == 100 ** 2
        assert len(list_[3]) == 100 ** 3
        assert len(list_[4]) == 100 ** 4
        assert list_[4][-1] == (99, 99, 99, 99)

# Generated at 2022-06-12 14:34:17.064691
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], [4, 5], [6, 7])) == [
        (1, 4, 6), (1, 4, 7), (1, 5, 6), (1, 5, 7),
        (2, 4, 6), (2, 4, 7), (2, 5, 6), (2, 5, 7),
        (3, 4, 6), (3, 4, 7), (3, 5, 6), (3, 5, 7),
    ]

# Generated at 2022-06-12 14:34:22.517743
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.tqdm.product`.
    """
    from .gui import tqdm
    from time import sleep

    def double(x):
        """Identity function (with sleep to simulate action)."""
        sleep(0.01)
        return x

    for x in tqdm.product(
            map(double, range(4)),
            map(double, range(4)),
            map(double, range(4)),
            map(double, range(4)),
            bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining},{rate_fmt}{postfix}]"
    ):
        pass
    print("OK")

# Generated at 2022-06-12 14:34:29.808961
# Unit test for function product
def test_product():
    from .tests import tests
    import io
    from .utils import format_sizeof
    from .nested import NestedDict
    from ..pandas import pandas_tqdm

    for kwargs in tests.values():
        kwargs = NestedDict(kwargs)

        buf = io.BytesIO() if hasattr(io, 'BytesIO') else io.StringIO()
        buf.write('product:\n')
        kwargs['file'] = buf
        kwargs['unit'] = 'it'

        with pandas_tqdm(**kwargs) as pbar:
            l = [i for i in product(*[range(i) for i in range(1, 7)],
                                    tqdm_class=pandas_tqdm)]

# Generated at 2022-06-12 14:34:34.271685
# Unit test for function product
def test_product():
    import numpy as np

    A = np.random.randint(0, 100, size=10)
    B = np.random.randint(0, 100, size=10)
    assert np.all(list(product(A, B)) == list(itertools.product(A, B)))


if __name__ == "__main__":
    from ._version import get_versions
    __version__ = get_versions()['version']
    del get_versions

    test_product()

# Generated at 2022-06-12 14:34:41.839836
# Unit test for function product
def test_product():
    """
    Test product(...)
    """
    from nose.tools import eq_
    try:
        _ = range(range(1, 11))
        assert False, "Should not get here"
    except TypeError:
        pass
    else:
        assert False, "Should not get here"

    for _ in product(range(100)):
        pass
    for _ in product(range(100)):
        pass

    for _ in product(range(100)):
        pass
    for _ in product(range(100)):
        pass

    for a, b in product(range(100), repeat=2):
        assert 0 <= a <= 99
        assert 0 <= b <= 99
    eq_(len(list(product(range(100), repeat=2))), 10000)

# Generated at 2022-06-12 14:34:49.969629
# Unit test for function product

# Generated at 2022-06-12 14:34:58.124554
# Unit test for function product
def test_product():
    """
    Tests for function product.
    """
    from .std import product as std_product
    from .tqdm import product as tqdm_product
    from .trange import product as trange_product
    from .tqdm_gui import product as tqdm_gui_product
    from .utils import FormatCustomText, SplitPrinter

    list_a = list(range(5))
    list_b = list(range(5, 9))
    list_c = [["a", "b", "c"], ["d", "e", "f"], ["g", "h", "i"]]

# Generated at 2022-06-12 14:35:00.997159
# Unit test for function product
def test_product():
    A = range(10)
    assert len(list(product(A))) == len(A)
    assert len(list(product(A, A))) == len(A) ** 2
    assert list(product(A, A, A)) == [(i, j, k) for i in A for j in A for k in A]

# Generated at 2022-06-12 14:35:08.868479
# Unit test for function product
def test_product():
    def gen():
        yield 1
        yield 2
        yield 3
    try:
        p1 = product(gen(), inplace=True)
        assert False
    except TypeError:
        pass
    p2 = product(gen(), tqdm_class=None)
    assert p2._size == 6
    p3 = product(gen(), tqdm_class=None, total=10)
    assert p3._size == 6
    assert p3._total == 10
    e = list(enumerate(range(4)))
    p4 = product(e)
    assert p4._size == 24

if __name__ == '__main__':
    from . import util
    util.test_functions(__name__, globals())

# Generated at 2022-06-12 14:35:57.229230
# Unit test for function product
def test_product():
    from . import util

    xvalues = [1, 2, 3]
    yvalues = [4, 5, 6]
    zvalues = [7, 8]
    zvalues = [7, 8]

    test_iter = product(xvalues, yvalues, zvalues, tqdm_class=util.DummyTqdmFile)
    test_list = [x * y * z for x, y, z in test_iter]
    assert test_list == [84, 105, 84, 105, 126, 105, 126, 168, 126]

# Generated at 2022-06-12 14:36:05.709464
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal

    x = [0, 1, 2]
    y = [10, 11]
    z = [20, 21, 22]

    for i, j in itertools.product(x, y):
        assert_array_equal(i * len(y) + j, x.index(i) * len(y) + y.index(j))


# Generated at 2022-06-12 14:36:07.582039
# Unit test for function product
def test_product():
    """Test for product."""
    for res in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:36:13.423953
# Unit test for function product
def test_product():
    """Test for tqdm.product"""
    from ._tqdm_test import pretest_posttest

    @pretest_posttest
    def test1():
        return product(*[range(100)] * 3)

    @pretest_posttest
    def test2():
        return product("ABCD", "xy")

    @pretest_posttest
    def test3():
        n = 0
        for _ in product(range(10), "ABCD", "xy"):
            n += 1
        assert (n == 10 * 4 * 2)


test_product()

# Generated at 2022-06-12 14:36:22.329684
# Unit test for function product
def test_product():
    """Test for tqdm.product"""
    from numpy.random import randint

    for n in range(2):
        for m in range(5):
            for r in [randint(0, n, n * m), range(n * m)]:
                r2 = list(product(range(n),
                                  range(2, 3),
                                  range(16, 18),
                                  range(256, 258),
                                  range(m)))
                assert len(r2) == len(r)

# Generated at 2022-06-12 14:36:26.407601
# Unit test for function product
def test_product():
    """Test for product."""
    for x in product(range(2), range(2), range(2)):
        assert x in [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                     (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

    for x in product("", "", ""):
        assert x == ()

# Generated at 2022-06-12 14:36:32.185328
# Unit test for function product
def test_product():
    """Simple unit test for `product` (others are via `itertools`)"""
    from ..std import next, cumsum, dim
    lst = list(product(range(7), range(3)))
    assert len(lst) == (7 * 3)
    assert lst[-1] == (6, 2)

    lst = list(product(range(7), ['a']))
    assert len(lst) == 7
    assert lst[-1] == (6, 'a')

    lst = list(product(range(7), []))
    assert len(lst) == 0

    lst = list(product(range(7), cumsum(range(3))))
    assert len(lst) == (7 * 3)
    assert lst[-1] == (6, 5)



# Generated at 2022-06-12 14:36:41.957456
# Unit test for function product
def test_product():
    for a, b in zip(product(range(5), repeat=2, tqdm_class=None),
                    itertools.product(range(5), repeat=2)):
        assert a == b
        assert a == tuple(b)
    for a, b in zip(product(range(5), range(10), repeat=2, tqdm_class=None),
                    itertools.product(range(5), range(10), repeat=2)):
        assert a == b
        assert a == tuple(b)

    # Test custom tqdm class
    class CustomTqdm(tqdm_auto):
        def __init__(self, **kwargs):
            super(CustomTqdm, self).__init__(**kwargs)
            self.max_iter = int(self.total)


# Generated at 2022-06-12 14:36:44.608616
# Unit test for function product
def test_product():
    assert list(product(range(3), repeat=3)) == list(itertools.product(range(3), range(3), range(3)))
    assert next(itertools.product(range(100), repeat=100)).count(0) == 100
    assert next(product(range(100), repeat=100)).count(0) == 100

# Generated at 2022-06-12 14:36:46.905900
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    list(product(range(500), range(500), tqdm_class=tqdm_auto, file=sys.stdout))