

# Generated at 2022-06-12 14:27:05.460606
# Unit test for function product
def test_product():
    try:
        from .._tqdm_test_patch import pretest_posttest
    except ImportError:
        pass
    else:
        with pretest_posttest(lambda: None):
            product(*[[1, 2, 4, 7], "ab"])

# Generated at 2022-06-12 14:27:15.493319
# Unit test for function product
def test_product():
    iterables = [range(10), range(10), range(10)]
    iterable = itertools.product(*iterables)

    # No tqdm
    assert (len([x for x in iterable]) == 1000)

    # With tqdm
    iterable = product(*iterables)
    assert (len([x for x in iterable]) == 1000)

    # With tqdm + total
    iterable = product(*iterables, total=1000)
    assert (len([x for x in iterable]) == 1000)

    # With tqdm + total + bar_format
    iterable = product(*iterables, total=1000,
                       bar_format='{desc}{percentage:3.0f}%|{bar}{r_bar} {n_fmt}/{total_fmt}')

# Generated at 2022-06-12 14:27:17.778392
# Unit test for function product
def test_product():
    p = product(range(2), range(2), range(2))
    assert sum(sum(map(sum, p)) == 8)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:27:25.090457
# Unit test for function product
def test_product():
    from .tests import TestCase
    from numpy import product as np_prod

    class TestProduct(TestCase):
        def test_product(self):
            for x in [3, 2, 5]:
                for y in [2, 3, 6]:
                    for z in [4, 2, 5]:
                        self.assertEqual(
                            np_prod(range(x), range(y), range(z)),
                            sum(1 for _ in product(range(x), range(y),
                                                   range(z),
                                                   total=None,
                                                   tqdm_class=tqdm_auto)))

    TestProduct().test_product()
    del TestProduct

# Generated at 2022-06-12 14:27:35.189241
# Unit test for function product
def test_product():
    """
    Test of product
    """
    # Standard usage
    total = 0
    for i, _ in enumerate(product(range(3), range(10), range(5))):
        total += 1
    assert total == 150

    # Iterator with non-int len()
    class Iter(object):
        """Simple iterable class"""
        def __init__(self, end):
            self.end = end
        def __iter__(self):
            return self
        def __len__(self):
            return self.end
        def __next__(self):
            self.end -= 1
            if self.end < 0:
                raise StopIteration
            return self.end
        next = __next__        # Python 2 compatibility
    it = Iter(3)

    total = 0

# Generated at 2022-06-12 14:27:40.661946
# Unit test for function product
def test_product():
    import numpy as np

    for i in product(range(1000)):
        assert i in range(1000)
    for i in product(range(1000), tqdm_class=tqdm_auto):
        assert i in range(1000)
    for i in product(range(1000), product(range(1000), tqdm_class=tqdm_auto)):
        assert i in range(1000)
    assert len(list(product(
        np.zeros((100, 100)), np.zeros((100, 100))))) == 10000

# Generated at 2022-06-12 14:27:46.500165
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z = 26 * [1]

# Generated at 2022-06-12 14:27:56.241251
# Unit test for function product
def test_product():
    import sys
    import pytest
    assert pytest.importorskip("tqdm")
    assert pytest.importorskip("tqdm.auto")
    try:
        import pytest_tqdm  # noqa
    except ImportError:
        pytestmark = pytest.mark.skip

    sys.stdout = open('/dev/null')  # disable printing

    from product import product

    from itertools import product
    prod = product
    for iterables in [prod('AB', 'cd'), prod('ABcd'), prod('ABcd', 'ef')]:
        assert list(product(*iterables)) == \
            list(product(*iterables, tqdm_class=tqdm_auto.tqdm))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:28:03.608212
# Unit test for function product
def test_product():
    """Unit tests for `tqdm.itertools.product()`"""
    # assertFalse(
    #     len(list(product(range(7), repeat=0)))
    #     or len(list(product(range(3), repeat=2))) != 9,
    #     "failed test_product()")

    # assertFalse(
    #     len(list(product(range(3), repeat=3))) != 27,
    #     "failed test_product()")

    # assertFalse(
    #     len(list(product(range(1000), repeat=1))) != 1000,
    #     "failed test_product()")

    # assertFalse(
    #     len(list(product(range(5), 'ABCD'))) != 20,
    #     "failed test_product()")

    # assertFalse(
    #

# Generated at 2022-06-12 14:28:12.175457
# Unit test for function product
def test_product():
    """
    Unit test for function product.

    Notes
    -----
    This is not a true unit-test.

    """
    from ..std import input
    from .main import tqdm

    tqdm(product(range(5), range(5)))
    input('Press Enter to continue')
    tqdm(product(range(5), range(5), tqdm_class=tqdm))
    import sys
    if sys.version_info.major >= 3:
        input('Press Enter to continue')
    tqdm(product(range(10), range(10), tqdm_class=tqdm))
    if sys.version_info.major >= 3:
        input('Press Enter to continue')
    tqdm(product(range(20), range(20), tqdm_class=tqdm))
   

# Generated at 2022-06-12 14:28:24.693597
# Unit test for function product
def test_product():
    from ..utils import FormatMixin
    from sys import stderr

    class TqdmTypeError(TypeError, FormatMixin):
        fmt = "'{0}' was called with redundant argument '{1}'"

    def product_tqdm(*iterables, **tqdm_kwargs):
        kwargs = tqdm_kwargs.copy()
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        try:
            total = kwargs.pop("total")
        except KeyError:
            pass
        else:
            try:
                lens = map(len, iterables)
            except TypeError:
                pass
            else:
                total_prod = 1
                for i in lens:
                    total_prod *= i

# Generated at 2022-06-12 14:28:27.581557
# Unit test for function product
def test_product():
    assert list(product("abc", "de")) == \
        [("a", "d"), ("a", "e"), ("b", "d"), ("b", "e"), ("c", "d"), ("c", "e")]

# Generated at 2022-06-12 14:28:34.023929
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    from numpy import prod
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter
    import time

    print('\n*** Test function `product`')
    t = time.time()
    for _ in product(range(3), repeat=4,
                     tqdm_class=lambda *a, **k: None):
        pass
    print('No progressbar:')
    print('  Elapsed time: %s' % format_interval(time.time() - t))
    print()

    t = time.time()
    for _ in product(range(3), repeat=4):
        pass
    print('With tqdm:')

# Generated at 2022-06-12 14:28:41.727785
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from .tests import MockTqdmFile, closing

    # Test smooth
    with closing(MockTqdmFile()) as m:
        for _ in product(range(2), range(3), _out=m):
            pass
        assert m.write.called
        assert m.total == 6

    # Test exception
    with closing(MockTqdmFile()) as m:
        for _ in tqdm_auto(product(range(2), "abc", _out=m)):
            pass
        assert not m.close.called


if __name__ == "__main__":
    from .tests import tests
    tests(__file__)

# Generated at 2022-06-12 14:28:44.428082
# Unit test for function product
def test_product():
    for i in product([1, 2], ['a', 'b'], tqdm_class=None):
        pass
    for i in product([1, 2], ['a', 'b'], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:28:54.874947
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from random import shuffle
    from numpy import prod
    from ..utils import _range

    it = product(_range(3), _range(4))
    assert (len(list(it)) == 12)

    it = product(_range(3), _range(4))
    assert (len([x for x in it]) == 12)

    it = product(_range(3), _range(4))
    assert (sum(1 for x in it) == 12)

    it = product(_range(3), _range(4))
    assert (all(x[0] >= 0 for x in it))

    it = product(_range(3), _range(4))
    assert (all(x[0] < 3 for x in it))


# Generated at 2022-06-12 14:29:03.854976
# Unit test for function product
def test_product():
    from tqdm.contrib.test import VerboseTestCase, with_setup
    import numpy as np
    from itertools import product as iproduct

    class TestProduct(VerboseTestCase):
        def setUp(self):
            self.l2 = np.random.randint(1, 10)
            self.range = np.random.randint(1, 100)
            self.iterables = [[j for j in range(i, i + self.range)]
                              for i in range(self.l2)]

        @with_setup(setUp)
        def test_product(self):
            """Check that `tqdm.itertools.product`'s output is correct"""
            l1 = np.random.randint(1, 10)

# Generated at 2022-06-12 14:29:12.096528
# Unit test for function product
def test_product():
    """Test function product"""
    assert list(product(range(10), range(10))) == list(itertools.product(range(10), range(10)))
    assert list(product(range(10), range(10), range(10))) == \
        list(itertools.product(range(10), range(10), range(10)))
    assert list(product(range(10), range(10), range(10), range(10))) == \
        list(itertools.product(range(10), range(10), range(10), range(10)))
    assert list(product(range(10), range(10), range(10), range(10), range(10))) == \
        list(itertools.product(range(10), range(10), range(10), range(10), range(10)))

# Generated at 2022-06-12 14:29:19.016821
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    assert_equal(list(itertools.product(['a', 'b'], ['c'])),
                 list(product(['a', 'b'], ['c'])))
    assert_equal(list(itertools.product(['a', 'b'], repeat=3)),
                 list(product(['a', 'b'], repeat=3)))
    assert_equal(sum(1 for _ in product(range(10))), 10)
    assert_equal(sum(1 for _ in product(range(10), tqdm_class=tqdm_auto.tqdm)), 10)

# Generated at 2022-06-12 14:29:25.763529
# Unit test for function product
def test_product():
    """Test function `itertool.product`"""
    assert [*product(range(5), repeat=2)] == \
        [(0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (1, 0), (1, 1), (1, 2), (1, 3),
         (1, 4), (2, 0), (2, 1), (2, 2), (2, 3), (2, 4), (3, 0), (3, 1), (3, 2),
         (3, 3), (3, 4), (4, 0), (4, 1), (4, 2), (4, 3), (4, 4)]

# Generated at 2022-06-12 14:29:37.833274
# Unit test for function product
def test_product():
    import numpy as np
    from sys import version_info
    from itertools import islice

    a = np.arange(1e6)
    b = a * 2

    # np.prod returns 1.0 with an empty iterator
    if version_info[0] == 3:
        assert list(product(a)) == [()]
        assert list(product(a, b)) == [(x, y) for x, y in zip(a, b)]

        # test chunksize
        assert list(islice(product(a, b, chunksize=1), 5)) == \
            [(0, 0), (1, 2), (2, 4), (3, 6), (4, 8)]

# Generated at 2022-06-12 14:29:45.623617
# Unit test for function product
def test_product():
    """Test function product."""
    total = 1
    for i in range(1, 5):
        total *= i
    with tqdm_auto() as t1:
        for i in product(*(range(i) for i in range(1, 5))):
            assert i == (0, 0, 0, 0)
            t1.update()
    with tqdm_auto() as t2:
        for i in product(range(4), tqdm_class=t2.__class__):
            t2.update()

# Generated at 2022-06-12 14:29:49.201438
# Unit test for function product
def test_product():
    iterables = [[0, 1], [2, 3, 4, 5], [6, 7, 8]]
    for x in product(*iterables, total=None):
        pass
    for x in product(*iterables, total=20):
        pass

# Generated at 2022-06-12 14:29:57.450841
# Unit test for function product
def test_product():
    from ..utils import FormatMixin
    class MyTqdm(FormatMixin):
        def __init__(self, total):
            self.n = 0
            self.total = total
            self.format_dict = {}
        def update(self, n=1):
            self.n += n
        @property
        def desc(self):
            return '{desc}: {n_fmt}/{total}'.format(
                n_fmt=self._format_meter(self.n, self.total, is_str=False),
                **self._format_dict)
        def __enter__(self):
            return self
        def __exit__(self, *exc):
            pass

    for total in (9, None):
        t = MyTqdm(total)
        a = [0, 1]
       

# Generated at 2022-06-12 14:30:04.076900
# Unit test for function product
def test_product():
    import random
    import string
    random.seed(0)

    def rand_string(length=6):
        return ''.join(random.choice(string.ascii_lowercase) for i in range(length))

    iterables = [
        range(100),
        rand_string(100),
        rand_string(100),
        rand_string(100),
        rand_string(100),
    ]

    p = product(*iterables, ascii=True, tqdm_class=tqdm_auto)
    for (a, b, c, d, e) in p:
        pass

# Generated at 2022-06-12 14:30:12.609726
# Unit test for function product
def test_product():
    """Unit test for product"""
    from .tests_tqdm import discretize, verdict
    a1 = discretize(range(3), nb_discrete=123)
    a2 = discretize(range(4), nb_discrete=2047)
    a3 = discretize(range(5), nb_discrete=255)
    b1 = product(a1, a2, a3, tqdm_class=tqdm_auto)
    b2 = itertools.product(a1, a2, a3)
    assert verdict(b1, b2)


if __name__ == "__main__":
    r = product(range(10), range(10), tqdm_class=tqdm_auto)
    print(list(r))

# Generated at 2022-06-12 14:30:13.529311
# Unit test for function product
def test_product():
    from .gui import tqdm
    from .utils import FormatTe

# Generated at 2022-06-12 14:30:21.917347
# Unit test for function product
def test_product():
    from .tests import closing, unittest
    from .utils import _range

    class TestProduct(unittest.TestCase):
        def test_normal(self):
            with closing(tqdm_auto()) as t:
                expected = list(_range(6))
                real = list(product(_range(2), _range(3), tqdm_class=tqdm_auto,
                                    total=6))
                self.assertEqual(expected, real)

        @unittest.skip('unexpected "total" kwarg error')
        def test_total(self):
            with closing(tqdm_auto()) as t:
                expected = list(_range(6))
                real = list(product(_range(2), _range(3), tqdm_class=tqdm_auto))
                self.assertE

# Generated at 2022-06-12 14:30:26.287845
# Unit test for function product
def test_product():
    import numpy
    from .tqdm_pandas import tqdm_pandas
    with tqdm_pandas(total=numpy.prod([10] * 2 + [2] * 5)) as t:
        for i in product(*[range(j) for j in [100, 1000, 2, 2, 2, 2, 2]]):
            t.update()

# Generated at 2022-06-12 14:30:27.915724
# Unit test for function product

# Generated at 2022-06-12 14:30:39.699093
# Unit test for function product
def test_product():
    """Unit test for function product."""
    from .__init__ import closing, format_sizeof
    from .tests import FakeTqdmFile
    from io import StringIO
    # Basic smoke test
    for i in range(3):
        output = StringIO()
        with closing(FakeTqdmFile(output)) as f:
            for _ in product(range(10), repeat=i):
                # don't care about actual outputs
                pass
            lines = output.getvalue().split("\n")
        assert any(lines)  # ensures tqdm output was written
    # 2D test
    output = StringIO()

# Generated at 2022-06-12 14:30:44.110934
# Unit test for function product
def test_product():
    """Run `tqdm.tqdm(..., total=?)` == `tqdm.tqdm(...)`"""
    from .gui import trange
    for i in trange(4):
        for j in trange(4):
            for k in trange(4):
                pass
        for j in trange(4):
            pass
    for i in trange(4):
        for j in product(range(4), range(4), range(4), tqdm_class=trange):
            pass
        for j in product(range(4), tqdm_class=trange):
            pass

# Generated at 2022-06-12 14:30:45.311557
# Unit test for function product
def test_product():
    list(product("ABC", repeat=2))

# Generated at 2022-06-12 14:30:54.959590
# Unit test for function product
def test_product():
    """
    Test `product` function.
    """
    import io
    import sys
    import time

    from tqdm import tqdm, __version__

    tup = tuple(range(4)) * 2
    for tqdm_cls in tqdm, tqdm_auto:
        buf = io.StringIO()
        sys.stderr = buf
        for _ in tqdm_cls(product(tup)):
            pass
        sys.stderr = sys.__stderr__
        output = buf.getvalue()
        if hasattr(output, 'decode'):  # Python3
            output = output.decode('utf-8')

# Generated at 2022-06-12 14:31:02.248276
# Unit test for function product
def test_product():
    from .models import test_utils
    iterables = (
        range(-10, 0),
        range(10),
        range(-100, 100, 10),
        range(-100, 100, 10),
        "abcd")
    with test_utils.print_exc(tqdm_auto):
        for i in tqdm_auto.product(*iterables):
            pass
        with tqdm_auto.product(*iterables, ascii=True) as t:
            for i in t:
                pass
        with tqdm_auto.product(*iterables, total=1000,
                               leave=True, unit='it', ascii=True) as t:
            for i in t:
                pass

# Generated at 2022-06-12 14:31:06.917291
# Unit test for function product
def test_product():
    itr = product(range(3), range(3))
    assert next(itr) == (0, 0)
    assert next(itr) == (0, 1)
    assert next(itr) == (0, 2)
    assert next(itr) == (1, 0)
    assert next(itr) == (1, 1)
    assert next(itr) == (1, 2)

# Generated at 2022-06-12 14:31:12.607567
# Unit test for function product
def test_product():
    from ._deprecated import _no_tqdm

    _no_tqdm()
    r = list(product(
        range(4),
        'ABCD',
        range(4),
        'ABCD',
        tqdm_class=tqdm_auto))
    assert(r == list(itertools.product(
        range(4),
        'ABCD',
        range(4),
        'ABCD')))

# Generated at 2022-06-12 14:31:20.029436
# Unit test for function product
def test_product():
    import sys
    import random

    list1 = list(range(1, 50))
    list2 = list(range(1, 50))
    random.shuffle(list1)
    random.shuffle(list2)

    with tqdm_auto(unit="test", dynamic_ncols=True,
                   leave=False, file=sys.stdout) as pbar:
        it = product(list1, list2, tqdm_class=tqdm_auto,
                     bar_format="{l_bar}{bar}{postfix[0]}")
        for i in it:
            assert i == (list1[i[0]], list2[i[1]])
            pbar.set_description(str(i))
            pbar.update()
            pbar.refresh()



# Generated at 2022-06-12 14:31:26.386805
# Unit test for function product
def test_product():
    assert list(product([1, 2], ['a', 'b'])) == \
        list(itertools.product([1, 2], ['a', 'b']))
    assert list(product([1, 2], ['a', 'b'], ['A', 'B'], tqdm_class=tqdm_auto)) == \
        list(itertools.product([1, 2], ['a', 'b'], ['A', 'B']))
    assert list(product([1, 2], ['a', 'b'], ['A', 'B'], tqdm_class=tqdm_auto,
                        desc='test_desc')) == \
        list(itertools.product([1, 2], ['a', 'b'], ['A', 'B']))

# Generated at 2022-06-12 14:31:35.888059
# Unit test for function product
def test_product():
    from ..utils import BasicTestInstances
    for tqdm_cls in BasicTestInstances:
        with tqdm_cls(leave=True, ascii=True) as t:
            t.monitor_interval = 0.01
            assert list(product(range(10), repeat=0)) == [()]

# Generated at 2022-06-12 14:31:47.076826
# Unit test for function product
def test_product():
    """
    Examples
    --------
    >>> import tqdm
    >>> for i in tqdm.itertools.product(range(100), range(100), range(100)):
    ...     pass
    """
    for i in product(range(100), range(100), range(100)):
        pass

# Generated at 2022-06-12 14:31:54.239751
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    a = list(range(2))
    b = list(range(3))
    c = list(range(4))

    assert list(itertools.product(a)) == list(product(a))
    assert list(itertools.product(a, b)) == list(product(a, b))
    assert list(itertools.product(a, b, c)) == list(product(a, b, c))
    assert list(itertools.product(a, repeat=2)) == list(product(a, repeat=2))

    from .std import tqdm as tqdm_std
    assert list(product(a, tqdm_class=tqdm_std)) == list(product(a))

# Generated at 2022-06-12 14:32:00.565444
# Unit test for function product

# Generated at 2022-06-12 14:32:01.183370
# Unit test for function product
def test_product():
    from .utils import FormatTe

# Generated at 2022-06-12 14:32:03.913429
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from .tqdm import trange
    for _ in product(range(100), range(100), range(100)):
        pass
    for _ in product(range(100), range(100), range(100), tqdm_class=trange):
        pass

# Generated at 2022-06-12 14:32:04.541791
# Unit test for function product
def test_product():
    import random

# Generated at 2022-06-12 14:32:11.605746
# Unit test for function product
def test_product():
    from ..tqdm import trange  # NOQA


# Generated at 2022-06-12 14:32:20.359417
# Unit test for function product
def test_product():
    from .tests.test_tqdm import closing, SafeChild, add_docstrings
    from .pandas import tqdm_pandas

    # Test generator wrapper
    for tqdm_cls in [tqdm_auto, tqdm_pandas]:
        out = product([], tqdm_class=tqdm_cls)
        assert not hasattr(out, "__len__")
        assert list(out) == []

        for n in range(2, 6):
            for x in out:
                pass  # pragma: no cover
            out = product(list(range(n)), tqdm_class=tqdm_cls)
            assert len(out) == n**n
            assert list(out) == list(itertools.product(range(n), repeat=n))

   

# Generated at 2022-06-12 14:32:28.807850
# Unit test for function product
def test_product():
    import numpy as np
    import sys
    import io

    a = [range(3), range(0, 9, 2),
         ['a', 'A']]
    a_prod = list(itertools.product(*a))
    a_prod_wrapped = list(product(*a))
    assert len(a_prod) == len(a_prod_wrapped)
    assert a_prod == a_prod_wrapped

    # Unit test `total`
    out = io.StringIO()
    sys.stdout = out
    try:
        product([range(3), range(3)], tqdm_class=tqdm_auto)
    finally:
        sys.stdout = sys.__stdout__

    assert "9it" in out.getvalue()
    out.close()

# Generated at 2022-06-12 14:32:33.904927
# Unit test for function product
def test_product():
    """Test for product"""
    # Test for generator mode
    for a, b in zip(product([1, 2, 3], tqdm_class=tqdm_auto),
                    itertools.product([1, 2, 3])):
        assert a == b
    # Test for iterator mode
    for a, b in zip(product([1, 2, 3], tqdm_class=tqdm_auto),
                    itertools.product([1, 2, 3])):
        assert a == b

# Generated at 2022-06-12 14:32:58.607245
# Unit test for function product
def test_product():
    from .tests import TestCase

    class ProductTest(TestCase):
        def test_product(self):
            for i, _ in enumerate(product(range(100), range(100))):
                self.assertIsInstance(i, int)
                self.assertTrue(0 <= i < 100**2)
            for i, _ in enumerate(product(range(100), range(100),
                                          tqdm_class=self.tqdm_class)):
                self.assertIsInstance(i, int)
                self.assertTrue(0 <= i < 100**2)
    ProductTest().run()

# Generated at 2022-06-12 14:33:07.814928
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from ..utils import _range
    from numpy import prod

    # Test with function tqdm_class=tqdm.auto.tqdm
    with tqdm_auto(total=prod(list(map(len, (list(range(10)),
                                            list(range(10)),
                                            list(range(10))))))) as t:
        for i, j, k in itertools.product(list(range(10)),
                                        list(range(10)),
                                        list(range(10))):
            t.update()

    # Test with function tqdm_class=tqdm.tqdm

# Generated at 2022-06-12 14:33:14.198336
# Unit test for function product
def test_product():
    import sys
    import io
    import os
    from tqdm import trange
    from tqdm import __version__ as v

    save_stdout = sys.stdout

# Generated at 2022-06-12 14:33:17.917789
# Unit test for function product
def test_product():
    """
    Try function product on small set of random data.
    """
    N = 5
    p = product(range(N), range(N), range(N), range(N),
                tqdm_class=tqdm_auto)
    assert len(list(p)) == N**4

# Generated at 2022-06-12 14:33:25.053531
# Unit test for function product
def test_product():
    """
    Unit test with a simple example.
    """
    iterables = [range(3), range(3)]
    p = product(*iterables, tqdm_class=tqdm_auto)
    assert next(p) == (0, 0)
    assert next(p) == (0, 1)
    assert next(p) == (0, 2)
    assert next(p) == (1, 0)
    assert next(p) == (1, 1)
    assert next(p) == (1, 2)
    assert next(p) == (2, 0)
    assert next(p) == (2, 1)
    assert next(p) == (2, 2)
    try:
        next(p)
    except StopIteration:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-12 14:33:30.716092
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product(range(1, 5), range(1, 5))) == \
        list(itertools.product(range(1, 5), range(1, 5)))
    assert list(product(range(1, 5), range(1, 5), tqdm_class=tqdm_auto)) == \
        list(itertools.product(range(1, 5), range(1, 5)))
    # assert False, "Test failed"

# Generated at 2022-06-12 14:33:32.877699
# Unit test for function product
def test_product():
    assert list(product(range(5), repeat=2)) == list(itertools.product(range(5), repeat=2))

# Generated at 2022-06-12 14:33:36.134558
# Unit test for function product
def test_product():
    with tqdm_auto(total=20) as t:
        for i in itertools.product(range(5), repeat=2):
            assert i[0] < 5 and i[1] < 5
            t.update()

# Generated at 2022-06-12 14:33:41.151781
# Unit test for function product
def test_product():
    import numpy as np
    a = [1, 2, 3]
    b_true = list(itertools.product(a, repeat=2))
    b_test = list(product(a, repeat=2))
    assert len(b_test) == len(b_true)
    for i, (b1, b2) in enumerate(zip(b_test, b_true)):
        assert b1 == b2
        assert type(b1) == tuple
        assert type(b2) == tuple

# Generated at 2022-06-12 14:33:50.317717
# Unit test for function product
def test_product():
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import random

    # Test: allclose
    rng = range(3)
    assert allclose(sorted(list(product(rng))),
                    [(0,), (1,), (2,)])
    assert allclose(sorted(list(product(rng, repeat=2))),
                    [(0, 0), (0, 1), (0, 2),
                     (1, 0), (1, 1), (1, 2),
                     (2, 0), (2, 1), (2, 2)])
    assert allclose(sorted(list(product(rng, repeat=2))),
                    sorted(list(product(repeat=2, iterable=rng))))

    # Test: random

# Generated at 2022-06-12 14:34:17.814708
# Unit test for function product
def test_product():
    with tqdm_auto(total=8) as t:
        for _ in product(range(2), range(4)):
            t.update()


# Generated at 2022-06-12 14:34:24.005282
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy import product as p
    from numpy.random import random

    a = random((3, 2, 4))
    t = product(a, tqdm_class=tqdm_auto)
    assert p(a, axis=0).shape == next(t).shape
    assert p(a, axis=1).shape == next(t).shape
    assert p(a, axis=2).shape == next(t).shape
    t = product(a, tqdm_class=tqdm_auto)
    assert p(a) == p(list(t))

# Generated at 2022-06-12 14:34:30.630497
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np
    from ..utils import format_sizeof
    prod = product(range(10), repeat=2, tqdm_class=tqdm_auto)
    assert np.array([next(prod) for _ in range(16)]).sum() == 852
    assert np.array([next(prod) for _ in range(16)]).sum() == 1020
    assert np.array([next(prod) for _ in range(16)]).sum() == 1096
    assert np.array([next(prod) for _ in range(16)]).sum() == 1160
    assert np.array([next(prod) for _ in range(16)]).sum() == 1212

# Generated at 2022-06-12 14:34:35.216381
# Unit test for function product
def test_product():
    from .tests import closing, closing_if_closed
    from .tests import eq_
    iterables = [range(10), range(10), range(10)]
    with closing(product(*iterables)) as p:
        assert p.total == 1000
        assert list(p) == list(itertools.product(*iterables))
    p = product(*iterables, total=100)
    with closing_if_closed(p):
        assert p.total == 100
        eq_(len(list(p)), 100)

# Generated at 2022-06-12 14:34:40.207750
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    from numpy.testing import assert_equal

    a = range(2)
    b = range(3)
    c = range(4)
    assert_equal([i for i in sorted(itertools.product(a, b, c))],
                 [i for i in sorted(product(a, b, c))])


if __name__ == "__main__":
    from numpy.testing import run_module_suite
    run_module_suite()

# Generated at 2022-06-12 14:34:43.355384
# Unit test for function product
def test_product():
    """Test for function `product`."""
    list(product(range(3), "abc", tqdm_class=tqdm_auto))
    list(product(range(3), "abc", tqdm_class=tqdm_auto, leave=True))

# Generated at 2022-06-12 14:34:49.341399
# Unit test for function product
def test_product():
    # Create an iterable with a 100 elements with a range(3)
    iterable = list(range(3))
    iterable = [iterable] * 100
    # Create the same using product
    product_generator = product(*iterable)
    # Create the same using itertools
    itertools_generator = itertools.product(*iterable)
    # Compare the results
    for result in zip(product_generator, itertools_generator):
        if result[0] != result[1]:
            raise ValueError("Bad result from product")

# Generated at 2022-06-12 14:34:54.106171
# Unit test for function product
def test_product():
    assert (list(product("ab", range(3), tqdm_class=tqdm_auto)) ==
            list(itertools.product("ab", range(3))))
    assert (list(product("ab", tqdm_class=tqdm_auto)) ==
            list(itertools.product("ab")))
    assert (list(product("ab", "cd", tqdm_class=tqdm_auto)) ==
            list(itertools.product("ab", "cd")))
    assert (list(product("ab", "cd", "ef", tqdm_class=tqdm_auto)) ==
            list(itertools.product("ab", "cd", "ef")))

# Generated at 2022-06-12 14:34:58.251096
# Unit test for function product
def test_product():
    """Test that product() == itertools.product"""
    assert list(product(range(10), repeat=3)) == list(itertools.product(
        range(10), repeat=3))
    assert list(product(range(10), repeat=3, tqdm_class=lambda x: x)) == \
        list(itertools.product(range(10), repeat=3))

# Generated at 2022-06-12 14:35:06.271963
# Unit test for function product
def test_product():
    from ..tests import closing_iter, unordered_equality
    iterables = [range(5), range(5), range(5)]
    with closing_iter(product(*iterables)) as it:
        tuples = list(it)
    assert len(tuples) == 125, "product() does not return all combinations"
    assert unordered_equality(tuples, list(itertools.product(*iterables))), \
        "product() does not return the same combinations"
    with closing_iter(product(*iterables, tqdm_class=tqdm_auto)) as it:
        tuples2 = list(it)
    assert unordered_equality(tuples, tuples2), \
        "product() with tqdm does not return the same combinations"
    assert tuples == list(product(*iterables))

# Generated at 2022-06-12 14:36:07.547556
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import freeze_it
    from ..utils import format_sizeof
    from .utils import format_interval
    import hashlib
    import sys
    import time
    total = None
    t = time.time()
    for i in product(range(64), range(64), range(64),
                     range(64), range(64), range(64),
                     range(64), range(64), range(64),
                     range(64), range(64), range(64),
                     range(64), range(64), range(64)):
        sys.stdout.buffer.write(bytes(i))
        total = total + 1 if total else 1
    sys.stdout.buffer.write(b"\n")
    t = time.time() - t

# Generated at 2022-06-12 14:36:12.923219
# Unit test for function product
def test_product():
    from numpy.testing import assert_raises
    assert_raises(TypeError, product, 'abc', [1, 2])
    assert_raises(TypeError, product, [1, 2], 'abc')
    assert_raises(TypeError, lambda: list(product(['abc'] * 3)))
    assert_raises(TypeError, lambda: list(product(['abc', 'def', 'ghi'])))
    assert_raises(TypeError, lambda: list(product(map(str, range(10)))))

    assert list(product([])) == [()]
    assert list(product(["abc"])) == [('abc',)]
    assert list(product(["abc", "def"])) == [('abc', 'def')]

# Generated at 2022-06-12 14:36:21.337718
# Unit test for function product
def test_product():
    from math import factorial
    from .tests import TestCase

    class TestItertoolsWrappers(TestCase):
        def test_product(self, tqdm_class=tqdm_auto, iterables=((range(1, 1000),
                                                                 range(1000, 10000)),),
                         total=factorial(999) * factorial(8999), **tqdm_kwargs):
            """
            Test `itertools` wrapper `product()`
            """
            kwargs = tqdm_kwargs.copy()
            kwargs.setdefault("total", total)
            kwargs.setdefault("smoothing", 0)
            with tqdm_class(**kwargs) as t:
                t.update(*[0] * len(iterables))

# Generated at 2022-06-12 14:36:24.531296
# Unit test for function product
def test_product():
    """Test function `tqdm.itertools.product` against `itertools.product`."""
    assert list(product([1, 2], repeat=3, desc="test")) == \
        list(itertools.product([1, 2], repeat=3))

# Generated at 2022-06-12 14:36:30.771899
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_array_equal

    # Test, trivial case
    arr = product([0, 1])
    assert_array_equal(list(arr), [(0,), (1,)])

    # Test, comprehensive case
    arr = product(range(2), range(2), range(2))
    assert_array_equal(list(arr), [(0, 0, 0), (0, 0, 1), (0, 1, 0),
                                   (0, 1, 1), (1, 0, 0), (1, 0, 1),
                                   (1, 1, 0), (1, 1, 1)])

    # Test, Numpy arrays
    arr = product(np.array(range(2)), np.array(range(2)), np.array(range(2)))
    assert_array

# Generated at 2022-06-12 14:36:35.921210
# Unit test for function product
def test_product():
    # No total parameter
    gen = product((1, 2, 3), (3, 4, 5), tqdm_class=tqdm_auto)
    #    with tqdm_auto(total=3*3) as t:
    #        for i in gen: pass
    assert next(gen) == (1, 3)
    gen = product((1, 2, 3), (3, 4, 5), tqdm_class=tqdm_auto)
    #    with tqdm_auto(total=3*3) as t:
    #        for i in gen: pass
    assert next(gen) == (1, 3)
    gen = product((1, 2, 3), (3, 4, 5), tqdm_class=tqdm_auto)
    #    with tqdm_auto(total=3*

# Generated at 2022-06-12 14:36:38.507746
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    sample = list(product(([1, 2], [3, 4])))
    assert sample == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-12 14:36:41.911966
# Unit test for function product
def test_product():
    iterables = range(5), range(5, 8), range(8, 11)
    assert list(product(*iterables)) ==  list(itertools.product(*iterables))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:36:48.031800
# Unit test for function product
def test_product():
    from collections import Counter
    from .utils import StringIO
    import sys
    try:
        import numpy as np
    except ImportError:
        np = None
    # Unit tests are much more convenient without bar display
    tqdm_auto.write = tqdm_auto.write_ = tqdm_auto.write_lvl = \
        tqdm_auto.write_with_levels = lambda *a, **kw: None
    # 1. Test size determination
    assert sum(1 for _ in product(range(2))) == 2
    assert sum(1 for _ in product(range(2))) == 2
    assert sum(1 for _ in product(range(2), range(3))) == 6
    assert sum(1 for _ in product(range(2), range(3), range(4))) == 24

# Generated at 2022-06-12 14:36:54.605893
# Unit test for function product
def test_product():
    # Test that function product works like itertools.product
    i1 = range(1)
    i2 = range(2)
    i3 = range(3)
    product_1 = list(product(i1, i2, i3))
    product_2 = list(itertools.product(i1, i2, i3))
    assert product_1 == product_2

    # Test that function product works with a tqdm parameter
    from ..std import trange
    product_1 = list(product(trange(1), i2, i3))
    product_2 = list(itertools.product(i1, i2, i3))
    assert product_1 == product_2

    # Test that function product works with a tqdm parameter
    from ..std import tqdm