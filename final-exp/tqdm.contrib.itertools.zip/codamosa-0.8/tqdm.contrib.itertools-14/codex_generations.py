

# Generated at 2022-06-12 14:27:12.234161
# Unit test for function product
def test_product():
    """Test for product"""
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    assert list(product(range(3),
                        range(3))) == [(0, 0), (0, 1), (0, 2),
                                       (1, 0), (1, 1), (1, 2),
                                       (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-12 14:27:19.965825
# Unit test for function product
def test_product():
    import cStringIO
    import sys
    from ..utils import format_sizeof
    from .utils import format_interval
    from .std import tqdm

    try:
        for i in xrange(5):
            pass
    except NameError:
        xrange = range

    old = sys.stdout

# Generated at 2022-06-12 14:27:25.090022
# Unit test for function product
def test_product():
    """ Unit test for function product """
    import nose

    def test_gen():
        for i in product((1, 2), (1, 2), (1, 2)):
            yield i

    i = test_gen()
    assert next(i) == (1, 1, 1)
    nose.tools.assert_is_instance(i.__wrapped__, itertools.product)
    nose.tools.assert_is_instance(i, tqdm_auto)

# Generated at 2022-06-12 14:27:35.189181
# Unit test for function product
def test_product():
    """Unit testing for function `product`."""
    import numpy as np
    from ..utils import format_sizeof

    def _size(arr):
        return format_sizeof(arr.size * arr.itemsize)

    # Cartesian product
    A = [np.random.randint(0, 100, size=10000) for x in range(4)]
    gen = product(*A)
    assert np.all(next(gen) == tuple(x[0] for x in A))

    # Total size
    gen = product(np.arange(25), np.arange(10), np.arange(5))
    assert gen.sizeof() == 600  # 25*10*5

    # Generator
    assert isinstance(gen, itertools.product)

    assert gen.tot_size is None
    assert gen

# Generated at 2022-06-12 14:27:42.720005
# Unit test for function product
def test_product():
    """
    Test function product on a mock dataset.
    """
    # This example is borrowed from:
    # https://docs.python.org/3/library/itertools.html
    pa = "ABCDEFGHIJ"
    pb = "abcdefghij"
    pc = "1234"

    # Test w/o tqdm
    pr = product(pa, pb, pc)
    assert sum(1 for _ in pr) == len(pa) * len(pb) * len(pc)

    # Test with tqdm
    pr = product(pa, pb, pc)
    assert sum(1 for _ in pr) == len(pa) * len(pb) * len(pc)

    # Test with total=100
    pr = product(pa, pb, pc)

# Generated at 2022-06-12 14:27:53.152544
# Unit test for function product
def test_product():
    from numpy import prod
    from numpy.random import randint
    from .utils import BasicTestCase, closure_func

    iterables = (randint(10, size=100),
                 randint(10, size=100),
                 randint(10, size=100))

    def count():
        return sum(1 for _ in iterables[0]) * \
               sum(1 for _ in iterables[1]) * \
               sum(1 for _ in iterables[2])

    def test_fn(it, total=None):
        res = 0
        for i in it:
            if i is not None:
                res += 1
        return res

    class TestTqdm(BasicTestCase):
        def test_product(self):
            "Smoke test"
            total = count()

# Generated at 2022-06-12 14:28:01.662221
# Unit test for function product
def test_product():
    """Test for function product"""
    for i in product([1, 2, 3], [4, 5], ['hello', 'world'], tqdm_class=None):
        pass

# Generated at 2022-06-12 14:28:10.242840
# Unit test for function product
def test_product():
    """Test product"""
    from numpy.testing import assert_equal

    lzip = list(zip)

    assert_equal(list(product(list(range(4)), repeat=2)),
                 list(lzip(range(4), range(4))))
    assert_equal(list(product(list(range(4)), repeat=2)),
                 list(lzip(range(4), range(4))))
    assert_equal(list(product(list(range(4)), repeat=3)),
                 list(lzip(range(4), range(4), range(4))))
    assert_equal(list(product(list(range(3)), repeat=3)),
                 list(lzip(range(3), range(3), range(3))))

# Generated at 2022-06-12 14:28:15.802598
# Unit test for function product
def test_product():
    for i in product("abc", "xy"):
        assert len(i) == 2
    for i in product("abc", "xy", tqdm_class=None):
        assert len(i) == 2
    for i in product("abc", "xy", tqdm_class=tqdm_auto, desc="test"):
        assert len(i) == 2
    for i in product("abc", "xy", tqdm_class=tqdm_auto, desc="test",
                     bar_format="{l_bar}{bar}|"):
        assert len(i) == 2

# Generated at 2022-06-12 14:28:18.467275
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # to be implemented: check that total is calculated properly
    list(product(range(3), range(3), range(3)))

# Generated at 2022-06-12 14:28:29.474682
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    from six.moves import range

    # Test range
    a = range(40)
    b = range(40)
    c = range(40)
    assert sum(int(x * y * z) for x, y, z in product(a, b, c, tqdm_class=None)) == \
        (np.array(a) * np.array(b) * np.array(c)).sum()

    # Test list
    a = list(range(40))
    b = list(range(40))
    c = list(range(40))

# Generated at 2022-06-12 14:28:36.705002
# Unit test for function product
def test_product():
    from ..utils import _range
    r = range(3)
    p = product(r, r)
    assert list(p) == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]
    p = product(r, r, tqdm_class=_range)
    assert list(p) == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-12 14:28:40.056860
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests_tqdm import pretest_posttest
    from .tests_tqdm import with_setup, _range

    @with_setup(pretest_posttest)
    def test():
        """
        Unit test for function product.
        """
        for _ in product(_range(10), _range(10), _range(10),
                         tqdm_class=tqdm_auto):
            pass
    test()

# Generated at 2022-06-12 14:28:41.977698
# Unit test for function product
def test_product():
    for i in product([1, 2, 3],
                     tqdm_class=tqdm_auto.tqdm, unit="foo"):
        pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:28:44.948260
# Unit test for function product
def test_product():
    from ._utils import _test_closed_range

    _test_closed_range(product(range(1000)))
    _test_closed_range(product(range(1000), range(1000)))
    _test_closed_range(product(range(1000), range(1, 2)))

# Generated at 2022-06-12 14:28:55.787247
# Unit test for function product
def test_product():
    """Test for the :func:`tqdm.itertools.product` function"""
    from ..std import StringIO
    from ..print_stack import print_stack
    print_stack()
    for elem in product('test', range(3), tqdm_class=None):
        assert isinstance(elem, tuple)
    lst = list(product('test', range(3)))
    assert lst == [('t', 0), ('t', 1), ('t', 2), ('e', 0), ('e', 1), ('e', 2),
                   ('s', 0), ('s', 1), ('s', 2), ('t', 0), ('t', 1), ('t', 2)]
    lst = list(product(range(3000), range(3000)))
    assert len(lst) == 9000000


# Generated at 2022-06-12 14:28:59.404892
# Unit test for function product
def test_product():
   from numpy.testing import assert_array_equal
   assert_array_equal(list(itertools.product([0, 1, 2], [0, 1, 2])),
                      list(tqdm.product([0, 1, 2], [0, 1, 2])))

# Generated at 2022-06-12 14:29:05.949176
# Unit test for function product
def test_product():
    "Test function product()"
    import numpy as np
    try:
        import scipy as sp
    except ImportError:
        return
    # Exercise 1
    for i, j in product(range(3), range(3), total=9):
        assert i * 3 + j == i + j * 3, (i, j)

    # Exercise 2
    for i, j in product(range(2), range(2), range(2)):
        i *= 4
        j *= 2
        assert (i + j) % 8 in [0, 4, 2, 6], (i, j)

    # Exercise 3
    L = np.arange(1000).reshape(100, 10)
    for i, j in product(range(10), range(10), total=100):
        assert (i * 10 + j)

# Generated at 2022-06-12 14:29:11.952338
# Unit test for function product
def test_product():
    """Unit test for function product"""
    try:
        test = (i for i in range(10))
        res = list(product(test, test, test))
        assert len(res) == 1000
        # test with tqdm
        res = list(product(test, test, test, tqdm_class=tqdm_auto))
        assert len(res) == 1000
    except:  # noqa: E722
        raise BaseException("Failed unit test for function product")

# Generated at 2022-06-12 14:29:19.963807
# Unit test for function product
def test_product():
    from ._utils import discard_stdout, utf8_encode


# Generated at 2022-06-12 14:29:30.758630
# Unit test for function product
def test_product():
    assert list(product([range(10**5)])) == list(product([range(10**5)]))
    assert list(product([range(10**5)])) == list(product([range(10**5)]))
    assert list(product([range(10**5)])) == list(product([range(10**5)]))

# Generated at 2022-06-12 14:29:38.298567
# Unit test for function product
def test_product():
    from ..tests.common import Random
    r = Random()
    r.seed_state()

    # Random test cases
    for _ in tqdm_auto(range(1000)):
        try:
            exp = []
            gen = product(r.irange(r.r()), r.irange(r.r()), r.irange(r.r()))
            for i in gen:
                exp.append(i)
            assert exp == list(itertools.product(*(
                r.irange(r.r()) for _ in range(3))))
        except AssertionError:
            from nose.tools import set_trace; set_trace()
            raise

    # Random test cases with non-iterable args

# Generated at 2022-06-12 14:29:46.600764
# Unit test for function product
def test_product():
    """Unit test"""
    from math import factorial as fac

    def _test(a, b, c, total=None):
        r = []
        for i in product(a, b, c):
            r.append(i)
            pass
        assert len(r) == (len(a) * len(b) * len(c))
        assert list(zip(a, b, c)) == r
        assert total is not None, "total of product is len(a) * len(b) * ..."
        assert getattr(total, "n", total) == (len(a) * len(b) * len(c))

    _test('ab', range(3), 'def', total=9)
    _test(range(3), range(3), range(3), total=27)

# Generated at 2022-06-12 14:29:55.292577
# Unit test for function product
def test_product():
    """Test product"""
    import sys
    import random
    # test with tuples
    product(range(10), range(5))
    product(range(10), range(5))
    product(range(5), range(5))
    # test with lists
    list(product(range(10), range(5)))
    # some nested
    list(product(range(5), (list(range(5)), range(5))))
    # test with different lengths
    list(product(range(5), (list(range(5)), range(10), range(1))))
    list(product(range(20), (list(range(5)), range(10), range(0))))
    # test with strings
    expected = sorted(
        ''.join(item) for item in itertools.product('ab', 'cd'))

# Generated at 2022-06-12 14:30:00.924472
# Unit test for function product
def test_product():
    from itertools import islice

    for x in range(2, 5):
        for y in range(2, 5):
            for z in range(2, 5):
                expected = list(itertools.product(range(x),
                                                  range(y),
                                                  range(z)))
                actual = list(islice(product(range(x),
                                             range(y),
                                             range(z)),
                                     None))
                assert expected == actual

# Generated at 2022-06-12 14:30:03.635631
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import _range
    import sys

    with _range(10) as t:
        for i, j in product(t, t, tqdm_class=tqdm_auto, leave=False):
            if sys.version_info >= (3, 0):
                assert i, j
            else:
                assert long(i), long(j)
                assert i, j

# Generated at 2022-06-12 14:30:05.719270
# Unit test for function product
def test_product():
    """Test itertools_wrapper's function product"""
    from .tests import test_product as _test_product
    _test_product()

# Generated at 2022-06-12 14:30:13.596163
# Unit test for function product
def test_product():
    from ..utils import _range
    import numpy as np
    import io

    # Product with no args should return empty generator
    assert(list(product()) == [])

    # Product with 1 arg
    assert (list(product('AB')) == list(zip('AB',)))
    assert (list(product('AB', repeat=1)) == list(zip('AB',)))
    assert (list(product('AB', repeat=2)) == list(zip('AA', 'BB')))

    # Product with 2 args
    assert (list(product('AB', 'CD')) == list(zip('AC', 'AD', 'BC', 'BD')))
    assert (list(product('AB', 'CD', repeat=1)) == list(zip('AC', 'AD', 'BC', 'BD')))

# Generated at 2022-06-12 14:30:22.061506
# Unit test for function product
def test_product():
    from .main import TqdmTypeError
    from .tests.test_utils import ProcessBarBaseIO

    with ProcessBarBaseIO() as (f, s):
        try:
            for _ in product(range(2), range(2), tqdm_class=tqdm_auto):
                pass
        except Exception as e:
            assert isinstance(e, TqdmTypeError)

    with ProcessBarBaseIO() as (f, s):
        for _ in product(range(2), range(2), tqdm_class=tqdm_auto,
                         ) + product(range(2), range(2), tqdm_class=tqdm_auto):
            pass
        assert isinstance(f.getvalue(), str)
        assert 'itertools' in f.getvalue()

# Generated at 2022-06-12 14:30:29.662591
# Unit test for function product
def test_product():
    """Test if `tqdm.itertools.product` matches `itertools.product`
    and is faster with `total` set"""
    from datetime import datetime
    from time import sleep

    for total in [False, None, 4230821]:
        lst = [1, 2, 3]

        t_x_0 = list(product(lst, lst, repeat=1, tqdm_class=None,
                             total=total))
        t_x = list(product(lst, lst, repeat=1, total=total))
        assert t_x == t_x_0

        t_z_0 = list(product(lst, lst, repeat=1, tqdm_class=None))
        t_z = list(product(lst, lst, repeat=1))
       

# Generated at 2022-06-12 14:30:42.822515
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    from random import randint
    from sys import getsizeof
    x = []
    y = []
    a = []
    b = []
    for i in product(range(randint(1, 10)), range(randint(1, 10))):
        x.append(i)
        a.append(i)
    for j in itertools.product(range(randint(1, 10)), range(randint(1, 10))):
        y.append(j)
        b.append(j)
    assert (x == y) and (a == b)
    for i in range(10):
        for j in range(10):
            assert (getsizeof(x) == getsizeof(y))

# Generated at 2022-06-12 14:30:45.999371
# Unit test for function product
def test_product():
    """Equivalent of itertools.product.

    >>> list(product([1, 2], repeat=3))
    [1, 1, 1]
    [1, 1, 2]
    [1, 2, 1]
    [1, 2, 2]
    [2, 1, 1]
    [2, 1, 2]
    [2, 2, 1]
    [2, 2, 2]
    """
    return True

# Generated at 2022-06-12 14:30:50.817856
# Unit test for function product
def test_product():
    from .tests import performance_report
    from . import trange
    from .utils import format_sizeof


# Generated at 2022-06-12 14:30:59.279957
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.

    """
    import sys
    import random
    import string
    # python3 -m tqdm.tests.test_itertools.test_product
    random.seed(0)
    chars = string.ascii_uppercase + string.digits
    a = [''.join(random.choice(chars) for _ in range(random.randint(1, 10)))
         for _ in range(random.randint(1, 4))]
    b = [''.join(random.choice(chars) for _ in range(random.randint(1, 10)))
         for _ in range(random.randint(1, 4))]

# Generated at 2022-06-12 14:31:04.072866
# Unit test for function product
def test_product():
    """Test nested loops with tqdm.product (GH-321)"""
    from ..tests_tqdm import with_setup, pretest, posttest, _range

    # Itertools
    @with_setup(pretest, posttest)
    def test_product1():
        for _ in product(_range(3), _range(3), _range(3)):
            pass

    @with_setup(pretest, posttest)
    def test_product2():
        for _ in product(_range(3), _range(3), _range(3)):
            pass

    test_product1()
    test_product2()

# Generated at 2022-06-12 14:31:13.825773
# Unit test for function product
def test_product():
    from .utils import FormatMixin, TemporaryDirectory

    class _Tqdm(FormatMixin, TemporaryDirectory):
        """Test for `format_meter`s"""
        def __init__(self):
            self.iterations = 50000

        @FormatMixin._no_signal_pool
        def __call__(self, *args, **kwargs):
            format_meter = Product(**kwargs)(range(self.iterations))
            # Check structure
            assert len(format_meter.gui) == 2
            assert len(format_meter.gui[0]) == 6
            # Check format_meter
            self.check_format([format_meter.gui[0][0].text],
                              ["0/50000"])
            # Check  dynamic_messages

# Generated at 2022-06-12 14:31:21.229601
# Unit test for function product
def test_product():
    """Test function product(...)"""
    from numpy import prod
    from numpy.testing import assert_equal
    from ..utils import rn

    for total in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
        for iterations in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            for n in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
                for compare in (False, True):
                    iterables = []
                    for i in range(n):
                        iterables.append(rn(iterations, r_max=total))
                    kwargs = dict(tqdm_class=tqdm_auto)
                    if compare:
                        kwargs['total'] = total
                    p

# Generated at 2022-06-12 14:31:27.449182
# Unit test for function product
def test_product():
    """Unit test for :func:`tqdm.itertools.product`"""
    from pytest import raises
    from ._utils import _random_data
    from .std import _range

    # Without `total`
    with _range(10) as t:
        with raises(RuntimeError):
            list(product(t))

    for dtype in (int, float):
        # With `total`
        for data in _random_data(size=10, dtype=dtype):
            assert [p for p in product(data, total=len(data))] == \
                list(itertools.product(*data))


if __name__ == "__main__":
    from ._utils import _test_it
    _test_it(itertools.product)
    _test_it(product)

# Generated at 2022-06-12 14:31:37.080371
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    tr = product(range(3), range(3), [10])
    assert hasattr(tr, '__iter__')
    for _ in tr:
        pass

    try:
        del tr
    except NameError:
        pass
    tr = product(np.arange(3), range(3), [10])
    assert hasattr(tr, '__iter__')
    for _ in tr:
        pass

    try:
        del tr
    except NameError:
        pass
    tr = product(range(3), range(3), [10], tqdm_class=tqdm_auto.tqdm)
    assert hasattr(tr, '__iter__')
    for _ in tr:
        pass

# Generated at 2022-06-12 14:31:39.875016
# Unit test for function product
def test_product():
    from ..utils import _range
    assert list(product(_range(5))) == list(itertools.product(_range(5)))
    assert list(product(_range(5), _range(3))) == list(itertools.product(_range(5), _range(3)))

# Generated at 2022-06-12 14:31:54.803489
# Unit test for function product
def test_product():
    for i, _ in enumerate(product(range(5), range(5), tqdm_class=None)):
        assert i == 0  # for coverage
    for i, _ in enumerate(product(range(5), range(5), tqdm_class=tqdm_auto)):
        assert i == 0  # for coverage

# Generated at 2022-06-12 14:31:56.389377
# Unit test for function product
def test_product():
    assert (
        sum(1 for _ in product(range(5), repeat=2)) == 5 ** 2
    )

# Generated at 2022-06-12 14:32:01.542163
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from random import choice
    from string import ascii_letters

    def test_eq(total, l):
        l1 = list(itertools.product(ascii_letters, repeat=l))
        l2 = list(product(ascii_letters, repeat=l))
        assert len(l1) == total
        assert len(l2) == total
        assert l1 == l2

    for l in [1, 2, 3, 5, 8, 10, 11, 12, 13, 20, 21, 22, 23, 27, 100]:
        total = len(ascii_letters) ** l
        test_eq(total, l)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:32:06.721107
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import format_sizeof
    import sys
    import numpy as np
    import time

    try:
        import psutil
        sys_mem = psutil.virtual_memory()
        system_memory = format_sizeof(sys_mem.total * sys_mem.available)
    except ImportError:
        # Fallback to guessing total physical memory (usage is not an issue)
        import subprocess

# Generated at 2022-06-12 14:32:10.002382
# Unit test for function product
def test_product():
    for i in product([1], [2], [3], tqdm_class=tqdm_auto):
        assert i == (1, 2, 3)
    for i in product(iter([1]), iter([2]), iter([3]), tqdm_class=tqdm_auto):
        assert i == (1, 2, 3)

# Generated at 2022-06-12 14:32:13.141800
# Unit test for function product
def test_product():
    from .tests import NeedsTestDisplay
    with NeedsTestDisplay():
        i = product('ABCD', 'xy')
        for _ in i:
            pass

# Generated at 2022-06-12 14:32:15.710316
# Unit test for function product
def test_product():
    """ Unit test for function product """
    for i in product("abc", "def", "ghi"):
        assert len(i) == 3
        assert isinstance(i, tuple)

# Generated at 2022-06-12 14:32:22.010851
# Unit test for function product
def test_product():
    from .tests import _test_iterable_equal
    from ..utils import format_sizeof
    for n in [10, 50, 100]:
        for m in [10, 50, 100]:
            expected = tuple(itertools.product(range(n), range(m)))
            assert _test_iterable_equal(expected, product(range(n), range(m)))
    # Test memory usage
    expected = tuple(itertools.product(range(5000), range(5000), range(5000)))
    assert format_sizeof(expected) == format_sizeof(product(range(5000),
                                                            range(5000),
                                                            range(5000)))

# Generated at 2022-06-12 14:32:24.787516
# Unit test for function product
def test_product():
    r = product('ABCD', 'xy', total=None)
    for i in r:
        pass
    assert 'itertools' in r.__name__


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:32:30.416817
# Unit test for function product
def test_product():
    """Test `tqdm.std.itertools.product`"""
    from .tests_tqdm import with_setup, pretest, posttest, _range

    @with_setup(pretest, posttest)
    def inner():
        """Test function"""
        a = _range(4)
        for _ in product(a, repeat=4):
            pass

# For backwards compatibility, add the old API [deprecated]
tqdm_std_itertools = dict(
    itertools=itertools,
    product=product)

# Generated at 2022-06-12 14:33:03.089595
# Unit test for function product
def test_product():
    """Test for function `product`"""
    assert list(product((1, 2), (3, 4))) == [
        (1, 3), (1, 4), (2, 3), (2, 4)]
    assert list(product((1, 2), repeat=2)) == [
        (1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product(range(2), repeat=3)) == [
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
    # Test for kwarg `total`

# Generated at 2022-06-12 14:33:09.410707
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3])) == list(itertools.product([1, 2, 3]))
    assert list(product([1, 2, 3], [4, 5, 6])) == \
        list(itertools.product([1, 2, 3], [4, 5, 6]))
    assert list(product([1, 2, 3], [4, 5, 6], [7, 8, 9])) == \
        list(itertools.product([1, 2, 3], [4, 5, 6], [7, 8, 9]))

# Generated at 2022-06-12 14:33:14.946800
# Unit test for function product
def test_product():
    from .utils import FormatWrapBase

    class FormatWrap(FormatWrapBase):
        @property
        def format_dict(self):
            return self._format_dict


# Generated at 2022-06-12 14:33:20.280314
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.tqdm_itertools.product`
    """
    from nose.plugins.attrib import attr
    from nose import with_setup

    @attr('slow', 'itertools')
    @with_setup(tqdm_auto.setup, tqdm_auto.teardown)
    def test_product():
        for i in product(range(10), repeat=2):
            pass

# Generated at 2022-06-12 14:33:21.312518
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    for _ in product(range(5), repeat=2):
        pass
    for _ in product(range(5), range(5)):
        pass

# Generated at 2022-06-12 14:33:30.465910
# Unit test for function product
def test_product():
    """
    Unit test for `product`
    """
    from numpy.testing import assert_equal
    import itertools
    import math

    def is_tqdm_class(instance):
        return isinstance(instance, type) and issubclass(instance, tqdm_auto)

    for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
        a = ["a", "b", "c", "d", "e"]
        b = [1, 2, 3]
        assert_equal(list(product(a, b)), list(itertools.product(a, b)))
        assert_equal(list(product(a, b, tqdm_class=tqdm_class)),
                     list(itertools.product(a, b)))

# Generated at 2022-06-12 14:33:32.911323
# Unit test for function product
def test_product():
    import types
    assert isinstance(product(range(10)), types.GeneratorType)
    assert list(product(range(10))) == list(itertools.product(range(10)))

# Generated at 2022-06-12 14:33:34.420052
# Unit test for function product
def test_product():
    for i in product(range(4), range(3), range(2), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:33:42.321931
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..contrib.utils import eval_kwargs
    from .utils import format_sizeof
    from sys import getsizeof

    for n in range(3, 6):
        for tqdm_class in (tqdm_auto, tqdm_auto.tqdm_gui, tqdm_auto.trange):
            with tqdm_class(total=2**n,
                            unit="B",
                            unit_scale=True,
                            miniters=1,
                            leave=True) as t:
                product_list = list(product(*[range(2)] * n,
                                            tqdm_class=tqdm_class))
                t.update(2**n)

# Generated at 2022-06-12 14:33:49.556608
# Unit test for function product
def test_product():
    from ..tqdm import trange
    from .common import SimpleTqdmIter

    for total in (None, 10, 1000):
        for length in (1, 2, 3, 4):
            for k in range(length):
                iterables = tuple(range(4) for _ in range(length))
                for it in [SimpleTqdmIter(k, iterables), product(iterables, total=total)]:
                    for i in trange(
                        it, total=total,
                        desc="product test {}/{}".format(k, length)):
                        assert len(i) == length

# Generated at 2022-06-12 14:34:33.137440
# Unit test for function product
def test_product():
    "Unit test for function product"
    from .utils import FormatCustomText

    with tqdm(itertools.product('ABC', 'ab'), ascii=True,
              miniters=1, mininterval=0,
              desc='product(A, a):', leave=False) as t:
        for i in t:
            pass
    assert t.n == 6
    assert t.last_print_n == 6
    assert t.miniters == 1
    assert t.mininterval == 0
    assert t.desc == 'product(A, a):'
    assert t.ascii
    assert not t.dynamic_ncols
    assert t.leave


# Generated at 2022-06-12 14:34:34.801590
# Unit test for function product
def test_product():
    a = [('a', 'e', 'i', 'o', 'u'), ('b', 'c', 'd')]
    assert tuple(itertools.product(*a)) == \
        tuple((tuple(i) for i in product(*a)))

# Generated at 2022-06-12 14:34:39.948793
# Unit test for function product
def test_product():
    result = set()
    it = product(["a", "b", "c"], repeat=2, tqdm_class=None)
    for value in it:
        result.add(value)
        assert len(result) <= len(it.tqdm.total)
    assert result == set([('a', 'a'), ('a', 'b'), ('a', 'c'),
                          ('b', 'a'), ('b', 'b'), ('b', 'c'),
                          ('c', 'a'), ('c', 'b'), ('c', 'c')])

# Generated at 2022-06-12 14:34:47.810860
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy
    N = 1000
    M = 100

    def _test(total=False, tqdm_class=tqdm_auto):
        # Test 1: Check that repeated calls to product results in same result
        P1 = product(range(N), range(M), tqdm_class=tqdm_class, total=total)
        P2 = product(range(N), range(M), tqdm_class=tqdm_class, total=total)
        for i, j in zip(P1, P2):
            assert i == j

        # Test 2: Check that result of product is correct, i.e. same as numpy.meshgrid

# Generated at 2022-06-12 14:34:52.369110
# Unit test for function product
def test_product():
    from .tests_tqdm import PretendTqdm

    # Test for number of calls
    for iterables in (['abc', 'def'], ['abc'], [[1], [2], [3]]):
        assert sum(1 for _ in product(*iterables, tqdm_class=PretendTqdm)) \
            == len(iterables[0]) * len(iterables[1])

# Generated at 2022-06-12 14:35:00.484315
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatStrenuous
    from ..utils import FreezableClass
    from ..utils import WorkerPool
    import shutil
    import os

    class TqdmDefault(object):
        def __init__(self, *args, **kwargs):
            kwargs.setdefault("file", open(os.devnull, 'w'))
            self.bar = tqdm_auto(*args, **kwargs)

        def __iter__(self):
            return iter(self.bar)

        def __enter__(self, *args, **kwargs):
            return self

        def __exit__(self, *args, **kwargs):
            return None

        def update(self, n=1):
            self.bar.update(n)

    # Test for race conditions
   

# Generated at 2022-06-12 14:35:08.907576
# Unit test for function product
def test_product():
    """Test function product
    """
    import numpy as np
    import itertools as itools
    # Test with empty iterables
    np.testing.assert_equal(list(product()), [()])
    # Test with one element
    np.testing.assert_equal(list(product(np.arange(5))),
                            [np.arange(5)])
    # Test with two elements
    np.testing.assert_equal(list(product(np.arange(4), np.arange(2))),
                            [np.arange(4), np.arange(4)])
    # Test with three elements

# Generated at 2022-06-12 14:35:14.960593
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    try:
        from ._version import __version__
        assert product(range(0, 3))
        assert product(range(0, 3), tqdm_class=tqdm_auto.tqdm)
        assert product(range(0, 3), range(0, 3))
        assert product(range(0, 3), range(0, 3), tqdm_class=tqdm_auto.tqdm)
    except AssertionError:
        raise AssertionError
    except Exception:
        raise Exception("Unknown error")

# Generated at 2022-06-12 14:35:18.888376
# Unit test for function product
def test_product():
    assert not list(product([], [], [], tqdm_class=None))
    assert list(product([1], [2], [3], tqdm_class=None)) == [(1, 2, 3)]
    assert not list(product([1], [2], [3], tqdm_class=None, total=1))
    assert not list(product([1], [2], [3], tqdm_class=None, total=0))

# Generated at 2022-06-12 14:35:23.088560
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..utils import in_notebook

    if not in_notebook():
        assert list(product("abcd", "12")) == list(itertools.product("abcd", "12"))

        assert list(product("abcd", "12")) == list(product("abcd", "12", tqdm_class=FormatCustomText))

        assert list(product("abcd", "12", tqdm_class=FormatCustomText)) == list(itertools.product("abcd", "12"))

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:36:31.665228
# Unit test for function product
def test_product():
    """
    Validate that `tqdm.product` wraps `itertools.product` correctly.
    """
    a = tuple(range(3))  # must be iterable for `itertools.product`
    b = tuple(range(4))  # must be iterable for `itertools.product`
    ref = list(itertools.product(a, b))
    out = list(product(a, b, tqdm_class=None))
    assert ref == out
    out = list(product(a, b, tqdm_class=tqdm_auto))
    assert ref == out
    out = list(product(a, b, tqdm_class=tqdm_auto, leave=True))
    assert ref == out

# Generated at 2022-06-12 14:36:36.675989
# Unit test for function product
def test_product():
    assert list(product(range(2), [1, 2], [11, 12])) == \
        [(0, 1, 11), (0, 1, 12), (0, 2, 11), (0, 2, 12),
         (1, 1, 11), (1, 1, 12), (1, 2, 11), (1, 2, 12)]

# Generated at 2022-06-12 14:36:43.215220
# Unit test for function product
def test_product():
    """
    Unit test for function `~tqdm.itertools.product`
    """
    assert list(product([1, 2, 3, 4], [5, 6], [7, 8, 9])) == \
        list(itertools.product([1, 2, 3, 4], [5, 6], [7, 8, 9]))
    assert list(product([1, 2, 3, 4], [5, 6], [7, 8, 9], tqdm_class=tqdm_auto)) == \
        list(itertools.product([1, 2, 3, 4], [5, 6], [7, 8, 9]))

# Generated at 2022-06-12 14:36:47.446947
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    from numpy import product as nproduct

    it = product(range(100), range(200), range(300), tqdm_class=tqdm_auto)
    assert nproduct(100, 200, 300) == sum(1 for _ in it)

    it = product(range(100), range(200), range(300), tqdm_class=tqdm_auto)
    assert nproduct(100, 200, 300) == sum(1 for _ in it)

# Generated at 2022-06-12 14:36:53.986325
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import FormatSize
    import io
    from .itertools import _product_noisy_ifpython2

    def assert_equal(x, y):
        if x != y:
            raise AssertionError(str(x) + ' != ' + str(y))

    for x in ["", " ", "\t  ", "\n"]:
        assert_equal(list(product(x)), [x])

    assert_equal(list(tqdm(product([1]))),
                list(tqdm_gui(product([1]))))

    assert_equal(list(product([1, 2], repeat=2)),
                list(product([1, 2], [1, 2])))


# Generated at 2022-06-12 14:37:00.551887
# Unit test for function product
def test_product():
    """Test pyitertools.product"""