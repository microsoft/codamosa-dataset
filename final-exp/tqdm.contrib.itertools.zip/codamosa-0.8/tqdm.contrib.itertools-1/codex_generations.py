

# Generated at 2022-06-12 14:27:07.241110
# Unit test for function product
def test_product():
    """
    Test that product works.
    """
    from numpy.testing import assert_equal
    from math import factorial
    for n in range(4):
        for tqdm_class in [tqdm_auto, tqdm_auto.tqdm]:
            for perm in tqdm_class.product(range(n), repeat=n,
                                           tqdm_class=tqdm_class):
                pass
    assert_equal(n, 3)
    assert_equal(tqdm_class, tqdm_auto.tqdm)
    assert_equal(len(perm), 3)
    # tqdm_class.product doesn't return a list
    pr1 = tqdm_auto.product(range(5), repeat=5)

# Generated at 2022-06-12 14:27:09.188825
# Unit test for function product
def test_product():
    """Test function `product`"""
    list(product([1, 2], [3, 4]))
    list(product("abc", repeat=2))

# Generated at 2022-06-12 14:27:12.036151
# Unit test for function product
def test_product():
    for x in product(range(3), range(3), range(3)):
        assert len(x) == 3

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:27:19.849346
# Unit test for function product
def test_product():
    """Test for the `tqdm.itertools.product` function"""
    try:
        import pytest
    except ImportError:
        print("pytest not found")
        return
    except SyntaxError:
        print("Skip pytest on Python 2")
        return
    from .tests_tqdm import pretest_posttest

    def test_identity(tqdm_func):
        assert list(tqdm_func(range(2))) == list(range(2))

        for k in [1, 2, 5, 10, 50]:
            assert list(tqdm_func(range(k))) == list(range(k))

            for s in [1, 2, 5, 10, 50]:
                assert list(tqdm_func(range(k), total=s)) == list(range(k))

   

# Generated at 2022-06-12 14:27:27.783806
# Unit test for function product
def test_product():
    # Init test
    from numpy.testing import assert_allclose
    import numpy as np
    r = np.arange(8).reshape((2, 2, 2))
    rr = np.array(list(product(range(2), repeat=3)))
    assert_allclose(r, rr)

    # Test that the iterator is consumed
    r = np.arange(16).reshape((2, 2, 2, 2))
    rr = np.array(list(product(range(2), repeat=4)))
    assert_allclose(r, rr)

    # Test with error
    with tqdm_auto.tqdm(total=4, desc='test') as t:
        for _ in product(range(2), repeat=3):
            t.update()

    # Test that the iterator is

# Generated at 2022-06-12 14:27:37.385626
# Unit test for function product
def test_product():
    """Unit test for `product`"""
    from ..std import next
    from ..utils import format_sizeof
    import random

    num_runs = random.randint(1, 1000)
    sys_iter = itertools.product(*[range(4)] * num_runs)
    tqdm_iter = product(*[range(4)] * num_runs)
    for sys_i, tqdm_i in zip(sys_iter, tqdm_iter):
        assert sys_i == tqdm_i
    assert next(sys_iter, None) is None
    assert next(tqdm_iter, None) is None
    # Check total
    assert next(product(*[range(4)] * num_runs))[0] == 0
    size = format_sizeof(num_runs)

# Generated at 2022-06-12 14:27:42.508858
# Unit test for function product
def test_product():
    import numpy as np
    list1 = list(range(10))
    list2 = list('abc')
    list3 = np.arange(20)

    p = product(list1, list2)
    assert len(list(p)) == 10 * 3
    assert sorted(list(p)) == [(i, j) for i in list1 for j in list2]

    p = product(list2, list1, list3)
    assert len(list(p)) == 10 * 3 * 20
    assert (sorted(list(p)) ==
            [(i, j, k) for j in list1 for i in list2 for k in list3])

# Generated at 2022-06-12 14:27:47.487205
# Unit test for function product
def test_product():
    items = [list(range(3)), ('a', 'b')]
    assert list(product(*items)) == [(0, 'a'),
                                     (0, 'b'),
                                     (1, 'a'),
                                     (1, 'b'),
                                     (2, 'a'),
                                     (2, 'b')]

# Generated at 2022-06-12 14:27:50.956609
# Unit test for function product
def test_product():
    for i in product("abc", "123", tqdm_class=tqdm_auto):
        assert i
    for i in product("abc", "123", "fgh", tqdm_class=tqdm_auto):
        assert i

# Generated at 2022-06-12 14:28:00.048067
# Unit test for function product
def test_product():
    import numpy as np
    from tqdm import tnrange

    # Ensure cache is cleared
    tnrange.clear()

    # Test caching
    try:
        from itertools import product as iproduct
    except:
        from tqdm.compat import iproduct
    for a, b in zip(iproduct(['a', 'b'], '12'), tqdm.product(['a', 'b'], '12')):
        assert a == b

    # Test total
    assert np.all(
        [a == b for a, b in zip(
            iproduct(range(2), range(2), range(2)),
            tqdm.product(range(2), range(2), range(2)))]
    )

    # Test total (fail)

# Generated at 2022-06-12 14:28:12.246272
# Unit test for function product
def test_product():
    import gc
    assert list(product(range(4))) == \
        list(itertools.product(range(4)))
    assert list(product(range(4), tqdm_class=None)) == \
        list(itertools.product(range(4)))
    assert list(product(range(4), tqdm_class=lambda x: x)) == \
        list(itertools.product(range(4)))
    assert list(product(range(4), tqdm_class=tqdm_auto)) == \
        list(itertools.product(range(4)))
    assert list(product(range(2, 4), range(3))) == \
        list(itertools.product(range(2, 4), range(3)))

# Generated at 2022-06-12 14:28:19.087778
# Unit test for function product
def test_product():
    """
    Tests that `product` yields the same values as `itertools.product`.
    """
    a = list(range(4))
    for i in product(a, a, tqdm_class=tqdm_auto):
        assert i == (i[0], i[1], i[2])
    for i in product(a, a):
        assert i == (i[0], i[1], i[2])
    for i in product(a, a, a, tqdm_class=tqdm_auto):
        assert i == (i[0], i[1], i[2], i[3])
    for i in product(a, a, a):
        assert i == (i[0], i[1], i[2], i[3])
    import string

# Generated at 2022-06-12 14:28:27.421364
# Unit test for function product
def test_product():
    """Test `tqdm.itertools.product`"""
    from numpy.testing import assert_equal  # pylint: disable=import-error
    from .utils import TestRepr

    a = str(tuple(product(range(20), range(20))))
    assert_equal(a, repr(tuple(itertools.product(range(20), range(20)))))
    a = tuple(product(range(30)))
    assert_equal(a, tuple(x for x in itertools.product(range(30))))
    a = tuple(product(range(30), tqdm_class=TestRepr))
    assert_equal(len(a), 0)

# Generated at 2022-06-12 14:28:33.940522
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    # Test with total=None
    x = product(list(range(1000)), list(range(100)),
                tqdm_class=tqdm_auto, total=None)
    assert (isinstance(x, itertools.product))
    assert (len(list(x)) == 1000 * 100)

    # Test with total=1000
    x = product(list(range(1000)), list(range(100)),
                tqdm_class=tqdm_auto)
    assert (isinstance(x, itertools.product))
    assert (len(list(x)) == 1000 * 100)

    # Test with total=None and unknown length

# Generated at 2022-06-12 14:28:42.244210
# Unit test for function product
def test_product():
    """Unit test for `tqdm.itertools.product`"""
    import numpy as np

    for _ in product(range(100), range(100), range(100)):
        pass

    assert list(_) == [(99, 99, 99)]

    assert list(product(range(10))) == [(i,) for i in range(10)]

    assert list(product(range(2), range(2), range(2), range(2), range(2),
                        range(2), range(2), range(2), range(2), range(2))
               ) == [(i,) * 10 for i in range(2)]

    assert list(product('abcd')) == [('a',), ('b',), ('c',), ('d',)]


# Generated at 2022-06-12 14:28:46.265928
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import random
    import string

    sample_size = random.randint(0, 20)
    sample_list = list(string.ascii_letters)
    sample_product = itertools.product(sample_list, repeat=sample_size)
    for i, j in zip(product(sample_list, repeat=sample_size), sample_product):
        assert (i == j)

# Generated at 2022-06-12 14:28:51.204671
# Unit test for function product
def test_product():
    """
    Test for function `product`
    """
    # Show that total iterations is correct
    it = product(list(range(100)), tqdm_class=tqdm_auto)
    try:
        assert len(list(it)) == 100**2
    except AssertionError:
        assert False, "total count not correct"

    # Show that output is the same
    it = product(list(range(100)), tqdm_class=tqdm_auto)
    try:
        assert list(it) == list(itertools.product(list(range(100))))
    except AssertionError:
        assert False, "product is not correct"

    # Test keyword arguments
    it = product(list(range(100)), tqdm_class=tqdm_auto, desc="test", key="test")


# Generated at 2022-06-12 14:29:01.012409
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, pretest_posttest
    from .utils import StringIO

    @with_setup(pretest=pretest_posttest[0], posttest=pretest_posttest[1])
    def wrapper():
        for _ in product(range(10), "abcd", [True, False], tqdm_class=tqdm_auto):
            pass

# Generated at 2022-06-12 14:29:07.229570
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText, PartialCustomText
    from .tests_tqdm import pretest_posttest

    def check(tqdm_class, **kwargs):
        def bar(i, last, *args):
            if i == last:
                return "Done."
            return "Iterating"
        kwargs.setdefault("total", 2)
        kwargs.setdefault("bar_format",
                          FormatCustomText(bar,
                                           partial=PartialCustomText(
                                               ncols=40, unit='it',
                                               unit_scale=True, miniters=1,
                                               leave=False)))
        return product(range(2), range(2),
                       tqdm_class=tqdm_class, **kwargs)


# Generated at 2022-06-12 14:29:10.274261
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    for i in range(10):
        for j in range(10):
            for k in range(10):
                assert_equal((i, j, k), next(product(range(10), repeat=3)))

# Generated at 2022-06-12 14:29:19.454557
# Unit test for function product
def test_product():
    from ..std import itertools
    for i in product(range(3), tqdm_class=None):
        assert i == itertools.next(iter(itertools.product(range(3), tqdm_class=None)))
    assert i == (2, 2)

    for i in product('abc', repeat=3, tqdm_class=None):
        assert i == itertools.next(iter(itertools.product('abc', repeat=3, tqdm_class=None)))
    assert i == ('c', 'c', 'c')


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:29:27.270023
# Unit test for function product
def test_product():
    from random import shuffle
    itt = product(range(8), repeat=3)
    a = list(itt)
    b = list(itertools.product(range(8), repeat=3))
    shuffle(a)
    shuffle(b)
    assert set([tuple(i) for i in a]) == set(b)
    assert list(itt) == []

    itt = product(range(8), repeat=3)
    assert list(itt) == list(itertools.product(range(8), repeat=3))

    itt = product(range(8), repeat=3, tqdm_class=lambda *args: None)
    assert list(itt) == list(itertools.product(range(8), repeat=3))


# Generated at 2022-06-12 14:29:35.004018
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from .gui import tqdm
    # Test setup
    list_in = list('abcd')
    expected = list(itertools.product(list_in, list_in))
    # Run tqdm
    out = list(product(list_in, list_in, unit='it', desc='', leave=True))
    #print("in  =", list_in)
    #print("out =", out)
    #print("exp =", expected)
    # Test and clean-up
    assert out == expected
    del tqdm

# Generated at 2022-06-12 14:29:38.469441
# Unit test for function product
def test_product():
    """Tests `tqdm.itertools.product`"""
    from random import randrange
    from string import ascii_lowercase

    for n in range(3, 8):
        for j in range(5):
            for i in product(ascii_lowercase, repeat=n):
                assert i[0] in ascii_lowercase
                if randrange(5):
                    break

# Generated at 2022-06-12 14:29:40.556399
# Unit test for function product
def test_product():
    import sys
    from .tests import test_product

    test_product(product, tqdm_class=tqdm_auto)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:29:49.493866
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    f = lambda x, y: (x, y)
    prod = product(range(3), range(3), tqdm_class=tqdm_auto)
    assert isinstance(prod, tqdm_auto)
    assert list(f(*x) for x in prod) == list(f(*x) for x in itertools.product(range(3), range(3)))
    prod = product(range(3), range(3), tqdm_class=tqdm_auto, desc="Test product")
    assert isinstance(prod, tqdm_auto)
    assert list(f(*x) for x in prod) == list(f(*x) for x in itertools.product(range(3), range(3)))

# Generated at 2022-06-12 14:29:52.233862
# Unit test for function product
def test_product():
    for i in product(
            list(range(1000)),
            list(range(1000)),
            list(range(20)),
            tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:29:57.383572
# Unit test for function product
def test_product():
    with tqdm_auto(total=3 * 2 * 1) as t:
        for i in product(range(3), range(2), range(1)):
            t.update()
    assert t.n == 3 * 2 * 1
    assert t.total == 3 * 2 * 1

    with tqdm_auto() as t:
        for i in product(range(5), range(5), range(5)):
            t.update()
    assert t.n == 5 ** 3

# Generated at 2022-06-12 14:30:06.241536
# Unit test for function product
def test_product():
    from .tests import tests_require
    from .utils import FormatWrapBase

    tests_require()
    input_list_1 = [1, 2, 3, 4, 5]
    input_list_2 = [6, 7, 8, 9]
    input_list_3 = [10, 11, 12]

    class MyTqdm(FormatWrapBase):
        def __init__(self, iterable, **kwargs):
            super(MyTqdm, self).__init__(iterable,
                                         miniters=1,
                                         mininterval=0.1,
                                         maxinterval=10.0,
                                         **kwargs)


# Generated at 2022-06-12 14:30:09.134821
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    r = range(5)
    itr = product(r, r, tqdm_class=tqdm_auto)
    assert len(list(itr)) == len(list(itertools.product(r, r)))

# Generated at 2022-06-12 14:30:23.459436
# Unit test for function product
def test_product():
    from ..utils import _range
    from ..tests.bar_descriptions import BAR_DESCS

    for iterable in ([_range(5)],
                     [_range(5), _range(5)],
                     [_range(5), _range(5), _range(5)],
                     ):
        for iterable2 in [iter(iterable), list(iterable)]:
            for n in [5, 10]:
                for total in [True, False]:
                    for tqdm_class in [tqdm_auto.tqdm, tqdm_auto.tqdm_gui, tqdm_auto.tqdm_notebook]:
                        for bar_desc in BAR_DESCS:
                            tqdm_kwargs = {"desc": bar_desc, "ncols": n, "total": total}
                

# Generated at 2022-06-12 14:30:28.862840
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    import itertools
    import numpy as np

    for s in [
        [],
        [1],
        [1, 2],
        [1, 2, 3],
        [1, 2, 3, 4],
        list('abc'),
        list(range(3)),
        list(range(4)),
        list(range(5)),
        list(range(6)),
        list(range(7)),
        list(range(8)),
        list(range(9)),
        list(range(10)),
    ]:
        for r in range(15):
            assert_array_equal(
                product(*([s] * r), total=None),
                itertools.product(*([s] * r)),
            )

# Generated at 2022-06-12 14:30:36.561459
# Unit test for function product
def test_product():
    """Unit test for product"""
    import numpy as np

    for a in range(1, 4):
        for b in range(1, 4):
            for c in range(1, 4):
                for d in range(1, 4):
                    x = list(range(a))
                    y = list(range(b))
                    z = list(range(c))
                    w = list(range(d))
                    i = [0] * (a * b * c * d)

                    for j1, j2, j3, j4 in product(x, y, z, w):
                        i[j1 * b * c * d + j2 * c * d + j3 * d + j4] = 1
                    np.testing.assert_array_equal(i, np.ones(a * b * c * d))

# Generated at 2022-06-12 14:30:43.190715
# Unit test for function product
def test_product():
    from ._utils import _range, format_sizeof
    import sys
    import tempfile
    from .tqdm import tqdm
    from .std import stdout, stderr

    # Checking length
    assert sum(1 for i in product(['a', 'b', 'c'], repeat=3)) == 27

    # Checking identity (expected and actual)
    exp = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
    for i in tqdm(_range(10), desc='Checking identity', leave=True):
        assert i**2 == exp[i]

    # Checking nested printing
    with stdout(None) as fo:
        with tqdm(total=1, file=fo) as t:
            t.write("tqdm_tests")

# Generated at 2022-06-12 14:30:52.843897
# Unit test for function product
def test_product():
    from .tqdm_gui import trange
    from .tqdm import tqdm

    assert list(product(list('ABC'), [1, 2])) == [
        ('A', 1), ('A', 2), ('B', 1), ('B', 2), ('C', 1), ('C', 2)]
    assert list(i for i in product(trange(10)) if not i) == [(0,), (0,), (0,),
                                                             (0,), (0,), (0,),
                                                             (0,), (0,), (0,),
                                                             (0,)]

# Generated at 2022-06-12 14:30:58.495048
# Unit test for function product
def test_product():
    from pytest import approx
    from itertools import product
    from tqdm import trange

    iterables = [
        range(3), range(3), range(3), range(3)]
    lists = list(itertools.product(*iterables))
    for i in trange(len(lists)):
        assert tuple(lists[i]) == tuple(product(*iterables))[i]
    assert len(lists) == approx(len(list(product(*iterables))), abs=1e-3)

# Generated at 2022-06-12 14:31:04.715485
# Unit test for function product
def test_product():
    """Test function product."""
    # Initialize
    import sys
    import io
    import tempfile
    fd, fname = tempfile.mkstemp()
    try:
        with io.open(fd, 'wt', encoding='utf-8') as fout:
            save_stdout = sys.stdout
            sys.stdout = fout

            # Test
            for _ in product([1, 2, 3], ['a', 'b'], tqdm_class=tqdm_auto,
                             postfix="test"):
                pass

            # Finalize
            sys.stdout = save_stdout
    finally:
        from .._tqdm_gui import _supports_unicode
        if not _supports_unicode:
            from ..utils import _encode
            fname = _encode

# Generated at 2022-06-12 14:31:14.391239
# Unit test for function product
def test_product():
    from .tqdm_test_classes import StupidTestFormat, SecretTestFormat

    from .tests_tqdm import _range

    assert list(product('ABCD', 'xy', _range(5))) == \
        list(itertools.product('ABCD', 'xy', _range(5)))

    assert list(product('ABCD', 'xy', _range(2))) == \
        list(itertools.product('ABCD', 'xy', _range(2)))

    assert list(product('ABCD', _range(2), 'xy')) == \
        list(itertools.product('ABCD', _range(2), 'xy'))


# Generated at 2022-06-12 14:31:21.753302
# Unit test for function product
def test_product():
    """Test for product"""
    import numpy as np
    from .utils import closing, _range

    # Simple test
    res = [x for x in product(_range(10), repeat=3)]
    exp = list(itertools.product(range(10), repeat=3))
    assert res == exp, res

    # Verbosity test

# Generated at 2022-06-12 14:31:24.857267
# Unit test for function product
def test_product():
    from ..utils import closing

    with closing(tqdm_auto(_total=1)) as t:
        for i in product([list(range(2)), list(range(3)), list(range(2))],
                         desc=t):
            pass


if __name__ == "__main__":
    r = test_product()

# Generated at 2022-06-12 14:31:43.918042
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy import prod
    from numpy.random import randint
    from ..utils import format_sizeof
    N = 10**randint(5, 10)
    total = 0
    for i, j in product(range(N), range(N)):
        total += i + j
    assert total == prod([N]*2) * (N - 1) * N / 2
    assert N * 2 * format_sizeof(total) == tqdm_auto("test_product").format_dict


if __name__ == '__main__':
    from ..utils import test_command_line_interface
    test_command_line_interface(__file__)

# Generated at 2022-06-12 14:31:51.916028
# Unit test for function product
def test_product():
    from .common import closing
    from .gui import tqdm
    import sys
    assert list(product(range(5), range(5))) == list(itertools.product(range(5), range(5)))
    assert list(product(range(5), range(5), tqdm_class=tqdm)) == list(itertools.product(range(5), range(5)))
    assert list(product(range(5), range(5), tqdm_class=tqdm, total=10)) == list(itertools.product(range(5), range(5)))
    assert list(closing(product(range(5), range(5)))) == list(itertools.product(range(5), range(5)))
    try:
        None + "str"
    except Exception as e:
        tqdm_err

# Generated at 2022-06-12 14:31:57.282894
# Unit test for function product
def test_product():
    from random import shuffle
    from .utils import FormatStdout
    all_items = list(range(10))
    shuffle(all_items)
    expected = sorted(list(itertools.product(all_items, repeat=3)))
    with FormatStdout() as t:
        all_tqdm_items = list(t.product(all_items, repeat=3))
    try:
        assert all_tqdm_items == expected
    except Exception:
        from pprint import pprint
        pprint(expected)
        pprint(all_tqdm_items)
        raise

# Generated at 2022-06-12 14:32:02.725954
# Unit test for function product
def test_product():
    from .utils import format_diff
    from .utils import on_off

    input_iterables = [range(5), range(5)]
    input_params = {"miniters": 1, "total": 25, "desc": "my tqdm"}

# Generated at 2022-06-12 14:32:09.771147
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from ._utils import _random_data, closing  # NOQA
    # Check if it's not a generator
    assert hasattr(product('abcd'), "__iter__")
    # Check if total is correctly set
    with closing(tqdm_auto(total=4)) as t:
        for _ in product('ab', '12', tqdm=t, total=10):
            pass
        assert t.total == 10
    # Check if all elements are correctly generated
    for rd in _random_data():
        with closing(tqdm_auto(total=9)) as t:
            assert list(product(*rd)) == list(itertools.product(*rd))
            t.update(len(rd))
            assert t.n == t.total


# Generated at 2022-06-12 14:32:14.300938
# Unit test for function product
def test_product():
    from ..utils import _range
    from .misc import _test_env_bool
    if not _test_env_bool("TEST_PRODUCT"):
        return
    it = product("ABCD", "xy")
    assert next(it) == ('A', 'x')
    assert next(it) == ('A', 'y')
    assert next(it) == ('B', 'x')
    # ---
    it = product("ABCD", "xy", tqdm_class=_range)
    assert next(it) == ('A', 'x')
    assert next(it) == ('A', 'y')
    assert next(it) == ('B', 'x')

# Generated at 2022-06-12 14:32:22.126449
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .utils import pbar, pbar_str
    from .utils import StringIO
    import sys

    for tqdm in [pbar, pbar_str]:
        sys.stderr = StringIO()
        try:
            iterable = product(range(1000), range(1000), tqdm_class=tqdm)
            for item in iterable:
                pass
        except SystemExit:
            # HACK: avoid pytest skip
            continue
        pbar_repr = sys.stderr.getvalue()
        sys.stderr = StringIO()

# Generated at 2022-06-12 14:32:29.225523
# Unit test for function product
def test_product():
    from ..utils import FormatBytes
    from .std import format_sizeof
    iterables = [[1, 2], [3, 4]]
    total = 1
    for i in iterables:
        total *= len(i)
        iterables[0] = range(10)
    with tqdm_auto(iterables, bar_format=format_sizeof, unit_scale=True,
                   unit_divisor=1024) as t:
        for i in tqdm_auto(itertools.product(*iterables)):
            pass
    assert t.n == total


try:
    from ..contrib.itertools import *  # NOQA
except ImportError:
    pass

# Generated at 2022-06-12 14:32:35.170869
# Unit test for function product
def test_product():
    """
    Test for function `tqdm.utils.itertools.product`.
    """
    from ..utils import _range
    from .iterables import Iterable

    def _tester(**kwargs):
        for _ in product(_range(4), _range(2), _range(1),
                         tqdm_class=Iterable, **kwargs):
            pass

    _tester(total=None)
    _tester(total=8)
    _tester(total=0)
    try:
        _tester(total=-8)
    except ValueError:
        pass
    else:
        raise ValueError

# Generated at 2022-06-12 14:32:40.096474
# Unit test for function product
def test_product():
    with tqdm_auto(total=19*11*10+1) as pbar:
        for i in product(range(20), range(12), range(9)):
            assert i[0] < 20
            assert i[1] < 12
            assert i[2] < 9
            pbar.update()


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:33:10.536885
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .._tqdm import tqdm, trange, TqdmTypeError, TqdmKeyError

    iproduct = itertools.product
    assert list(iproduct([1,2], [3,4], [5,6])) == [
        (1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6),
        (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)]

    total = float(len(list(iproduct([1,2], [3,4]))))
    with trange(total) as t:
        assert next(t) == 0

# Generated at 2022-06-12 14:33:15.457895
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product` wrapper.
    """
    import sys
    import random
    import warnings
    if sys.version_info[0] == 2:
        from itertools import imap as map  # NOQA
    else:
        from builtins import map  # NOQA

    try:
        import nose
    except ImportError:
        import warnings
        warnings.warn("Could not import nose. Tests may fail.")
        return

    # Invalid parameters
    nose.tools.assert_raises(TypeError, product, None)
    nose.tools.assert_raises(TypeError, product, None)
    nose.tools.assert_raises(TypeError, product, [], [], tqdm_class=None)

# Generated at 2022-06-12 14:33:21.992852
# Unit test for function product
def test_product():
    import multiprocessing as mp

    from .tests_tqdm import with_setup, pretest, posttest, _range

    # `with_setup()` is not able to handle `itertools.product`
    # print('testing itertools.product()')
    pretest()
    for i, j in product(_range(3), _range(1000), desc='test'):
        pass
    posttest()

    # print('testing itertools.product() with multiprocessing')
    pretest()
    mp.Pool(2).map(test_product, [])
    posttest()

# Generated at 2022-06-12 14:33:24.739081
# Unit test for function product
def test_product():
    from .common import closing, SimpleSupervisedModel
    from .tqdm_gui import tqdm

    with closing(SimpleSupervisedModel()) as sm:
        sm.fit(tqdm(product(["a", "b"], range(4))))

# Generated at 2022-06-12 14:33:33.729316
# Unit test for function product
def test_product():
    assert list(product(range(1), range(1), range(1), tqdm_class=None)) == list(itertools.product(range(1), range(1), range(1)))
    assert list(product(range(1), range(1), range(1), tqdm_class=tqdm_auto)) == list(itertools.product(range(1), range(1), range(1)))
    assert list(product(range(3), range(4), range(7), tqdm_class=None)) == list(itertools.product(range(3), range(4), range(7)))
    assert list(product(range(3), range(4), range(7), tqdm_class=tqdm_auto)) == list(itertools.product(range(3), range(4), range(7)))

# Generated at 2022-06-12 14:33:37.257555
# Unit test for function product
def test_product():
    import numpy as np
    arr = product(range(20), tqdm_class=tqdm_auto)
    n_items = 0
    for item in arr:
        n_items += 1
    assert n_items == 400

# Generated at 2022-06-12 14:33:43.117768
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    from collections import Counter
    from ..std import time

    iterables = list(range(100)), list(range(10))

    # Std. itertools
    prev_c = time.time()
    count = Counter(itertools.product(*iterables))
    std_time = time.time() - prev_c

    # tqdm.itertools
    prev_c = time.time()
    count2 = Counter(product(*iterables, tqdm_class=None))
    tqdmt_time = time.time() - prev_c

    assert count == count2
    assert tqdmt_time < std_time / 2

# Generated at 2022-06-12 14:33:44.886486
# Unit test for function product
def test_product():
    for _ in product(["a", "b"], ["1", "2", "3"], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:33:51.685767
# Unit test for function product
def test_product():
    """Test function product"""
    lv = ['2', 3, '4']
    p = product(lv)
    pl = list(p)
    assert pl == [('2', 3, '4')]

    p = product(lv, repeat=2)
    pl = list(p)
    assert pl == [('2', 3, '4'), ('2', 3, '4')]

    p = product(lv, repeat=3)
    pl = list(p)
    assert pl == [('2', 3, '4'), ('2', 3, '4'), ('2', 3, '4')]

# Generated at 2022-06-12 14:33:54.925197
# Unit test for function product
def test_product():
    r = []
    for i in product(range(10), range(10), range(10), tqdm_class=None):
        r.append(i)
    assert len(r) == 1000
    assert r[0] == (0, 0, 0)
    assert r[-1] == (9, 9, 9)

# Generated at 2022-06-12 14:34:42.401784
# Unit test for function product
def test_product():
    """Test function product"""
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase._closing()) as t:
        for _ in t.tqdm(product(range(1000), repeat=2), total=1000000, miniters=10):
            pass
        for _ in t.tqdm(product(range(1000), repeat=2), total=None, miniters=10):
            pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:34:50.418796
# Unit test for function product
def test_product():
    import itertools
    import numpy as np
    from copy import copy
    from .tests import pretest_empty, posttest_empty

    # Check identity
    A = [1, 2, 3, 4]
    assert list(product(A, A, A)) == itertools.product(A, A, A)
    for B, C in zip(product(A, A, A), itertools.product(A, A, A)):
        assert B == C

    # Check exceptions
    pretest_empty("itertools.product")
    try:
        list(product(range(30)))
    except:
        pass
    else:
        raise AssertionError
    posttest_empty()

    # Check no extra iter

# Generated at 2022-06-12 14:34:58.527928
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ._tqdm_test_case import TqdmTestCase

    with TqdmTestCase() as tc:
        tc.assertEqual(list(product(range(4), repeat=2, tqdm_class=tc.cls)),
                       list(itertools.product(range(4), repeat=2)))

    with TqdmTestCase() as tc:
        tc.assertEqual(list(product(range(3), tqdm_class=tc.cls)),
                       list(itertools.product(range(3))))


# Generated at 2022-06-12 14:35:06.595416
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import sys
    import os
    # We are in tqdm/tests
    sys.path.append(os.path.abspath('..'))
    from .tests_tqdm import pretest_posttest  # NOQA

    with pretest_posttest() as (pd, (stdout, stderr)):
        for i in product(range(1), range(2)):
            pass
        assert pd.n == 2
        for i in product(range(1), range(2), range(3),
                         tqdm_class=tqdm_auto):
            pass
        assert pd.n == 2 * 3
        assert pd.total == 6


# import module correctly when, e.g., `python -m tqdm.itertools`

# Generated at 2022-06-12 14:35:07.380716
# Unit test for function product
def test_product():
    from .utils import FormatStrea

# Generated at 2022-06-12 14:35:12.177433
# Unit test for function product
def test_product():
    """
    Example:
        >>> test_product()
    """
    raw_data = [list(range(10)),
                list(range(1, 10)),
                list(range(2, 10))]
    combs = product(*raw_data)
    c = []
    for ele in combs:
        c.append(ele)
    assert len(c) == sum(map(len, raw_data))

# Generated at 2022-06-12 14:35:19.537503
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    try:
        from numpy import prod
    except ImportError:
        return  # Skip test
    from ..tqdm import tqdm

    def _test(r=3, c=3):
        """
        Test product(..., total=X) == X.
        """
        assert sum(1 for _ in product(range(r), range(c))) == r * c
        assert sum(1 for _ in tqdm(product(range(r), range(c)))) == r * c
        assert sum(1 for _ in tqdm(product(range(r), range(c)),
                                   total=prod([r, c]))) == r * c


# Generated at 2022-06-12 14:35:27.488973
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`."""
    from tqdm._utils import _term_move_up

    assert list(product([1], repeat=0)) == [()]
    assert list(product([1], repeat=-1)) == []
    assert list(product([1], repeat=1)) == [(1,)]
    assert list(product([1], repeat=2)) == [(1, 1)]
    assert list(product([1, 2], repeat=0)) == [()]
    assert list(product([1, 2], repeat=-1)) == []
    assert list(product([1, 2], repeat=1)) == [(1,), (2,)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]

   

# Generated at 2022-06-12 14:35:33.084105
# Unit test for function product
def test_product():
    """Test for :func:`tqdm.std.itertools.product`"""
    # Test no total
    assert list(product(range(10), tqdm_class=tqdm_auto)) == \
        list(itertools.product(range(10)))
    # Test total
    assert list(product(range(10), tqdm_class=tqdm_auto)) == \
        list(product(range(10), tqdm_class=tqdm_auto))
    # Test no tota

# Generated at 2022-06-12 14:35:39.860177
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    # Test on 1st arg list
    arg1 = list(range(5))
    assert list(product(arg1)) == list(itertools.product(arg1))
    assert list(product(arg1, tqdm_class=None)) == list(itertools.product(arg1))

    # Test on 2nd arg list
    arg2 = list(range(5))
    assert list(product(arg2, arg2)) == list(itertools.product(arg2, arg2))
    assert list(product(arg2, arg2, tqdm_class=None))\
        == list(itertools.product(arg2, arg2))