

# Generated at 2022-06-12 14:26:59.323118
# Unit test for function product
def test_product():
    import doctest
    doctest.testmod(optionflags=(doctest.NORMALIZE_WHITESPACE |
                                 doctest.ELLIPSIS))

# Generated at 2022-06-12 14:27:02.282762
# Unit test for function product
def test_product():
    import numpy as np
    for _ in product(range(100), range(100), range(100),
                     tqdm=lambda x: x):
        pass
    for _ in np.array(list(product(range(100), range(100), range(100)))):
        pass

# Generated at 2022-06-12 14:27:11.906044
# Unit test for function product
def test_product():
    from collections import defaultdict

    # With simple iterables
    x = []
    for i in product("ABC", "123", tqdm_class=tqdm_auto):
        x.append(i)
    assert x == list(itertools.product("ABC", "123"))

    # With "uncountable" iterables
    x = defaultdict(int)
    for i in product("ABC", "123", tqdm_class=tqdm_auto):
        x["".join(i)] += 1
    assert x == defaultdict(int, {"A1": 1, "A2": 1, "A3": 1,
                                  "B1": 1, "B2": 1, "B3": 1,
                                  "C1": 1, "C2": 1, "C3": 1})

    # With "un

# Generated at 2022-06-12 14:27:19.760527
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`
    """
    from ..pandas import tqdm_pandas
    import pandas as pd
    import numpy as np
    import operator
    import functools
    import sys
    import random
    import time

    def mul(x, y):
        time.sleep(0.00001)
        return x * y

    random.seed(0)
    df1 = pd.DataFrame(np.random.random((4, 2)), columns=['A', 'B'])
    df2 = pd.DataFrame(np.random.random((3, 2)), columns=['A', 'B'])

    # pd.merge(df1, df2, on=['A', 'B'], how='inner')

# Generated at 2022-06-12 14:27:27.716788
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    def _reverse(a):
        for i in range(len(a)):
            a[i] = a[i][::-1]

    # Test args
    assert list(product(range(10))) == list(itertools.product(range(10)))
    assert list(product(range(3), range(3))) == list(itertools.product(
        range(3), range(3)))
    assert list(product(range(3), range(3), range(3))) == list(itertools.product(
        range(3), range(3), range(3)))

# Generated at 2022-06-12 14:27:29.900522
# Unit test for function product
def test_product():
    for a, b in product(range(3), range(2)):
        pass
    for a, b in product(range(15), range(10)):
        pass

# Generated at 2022-06-12 14:27:39.358631
# Unit test for function product
def test_product():
    import numpy as np
    from pytest import raises

    with tqdm_auto(total=2 ** 4) as t:
        assert list(product(range(2), 'XY', tqdm=t)) == \
            [(0, 'X'), (0, 'Y'), (1, 'X'), (1, 'Y')]

    with tqdm_auto(total=2 ** 4) as t:
        assert list(product(range(2), 'XY', tqdm=t)) == \
            [(0, 'X'), (0, 'Y'), (1, 'X'), (1, 'Y')]


# Generated at 2022-06-12 14:27:42.309959
# Unit test for function product
def test_product():
    iterables = [range(10)] * 10
    list_product = list(itertools.product(*iterables))
    length = len(list_product)
    assert length == 10**10
    assert list(product(*iterables)) == list_product
    assert list(product(*iterables, tqdm_class=tqdm_auto)) == list_product

# Generated at 2022-06-12 14:27:47.795719
# Unit test for function product
def test_product():
    from ..utils import FormatWrapBase

    class FakeTqdm(FormatWrapBase):
        @property
        def n(self):
            return self._n

        @n.setter
        def n(self, n):
            self._n = n

        def __call__(self, *args, **kwargs):
            return self

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            pass

        def update(self):
            self.n += 1

    def product_test(n):
        iterables_list = [[i for i in range(3)]] * n
        for iterables in iterables_list:
            p = list(product(*iterables, tqdm_class=FakeTqdm))

# Generated at 2022-06-12 14:27:57.647064
# Unit test for function product
def test_product():
    from ._utils import _fake_streams

    def cmp(output, expected):
        from numpy import setdiff1d
        assert len(output) == len(expected)
        assert not setdiff1d(output, expected).size

    with _fake_streams():
        output = list(product(range(2), repeat=2))
        expected = [(0, 0), (0, 1), (1, 0), (1, 1)]
        cmp(output, expected)

    with _fake_streams():
        output = list(product(range(7), repeat=3))
        expected = [(i, j, k)
                    for i in range(7)
                    for j in range(7)
                    for k in range(7)]
        cmp(output, expected)


# Generated at 2022-06-12 14:28:04.893065
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert list(product(range(3), range(3))) == [
        (0, 0), (0, 1), (0, 2),
        (1, 0), (1, 1), (1, 2),
        (2, 0), (2, 1), (2, 2)]
    assert list(product(range(3), repeat=2)) == [
        (0, 0), (0, 1), (0, 2),
        (1, 0), (1, 1), (1, 2),
        (2, 0), (2, 1), (2, 2)]
    list(product(range(3), range(3))) == list(product(range(3), range(3)))

# Generated at 2022-06-12 14:28:13.447234
# Unit test for function product
def test_product():
    """Unit test function product"""
    import numpy as np
    from ..utils import format_sizeof

    n = 5
    for tqdm_class in [tqdm_auto, None]:
        i1 = np.arange(5)
        i2 = np.arange(5)
        i3 = np.arange(5)
        i3_a = np.arange(5)
        i3_b = np.arange(5)
        it = product(i1, i2, i3, tqdm_class=tqdm_class)

# Generated at 2022-06-12 14:28:19.899139
# Unit test for function product
def test_product():
    """Test for function product"""
    try:
        from numpy import product as npproduct
    except:
        return
    for it in [
            (2, 3, 4),
            (2.0, 3.0, 4.0),
            (2, 3),
            (2,),
            (2.0,),
            (2, 3.0),
            (2.0, 3),
            ('a', 2, 3),
            (2, 'a', 3),
            (2, 3, 'a'),
            ('a', 'b', 'c'),
            ('a', 'b', 'c', 'd'),
            ('a', 'b', 'c', 'd', 'e')]:
        i1 = sorted(map(sorted, itertools.product(*it)))

# Generated at 2022-06-12 14:28:22.083994
# Unit test for function product
def test_product():
    """
    Test for product.
    """
    from ..tqdm import trange
    list(product(range(10), trange=trange))

# Generated at 2022-06-12 14:28:30.151838
# Unit test for function product
def test_product():
    from .itertools import co_product
    from .tests import test_product as tp

    for n in [0, 1, 2, 3, 4]:
        assert list(product(*tp.range_args(n))) \
               == list(itertools.product(*tp.range_args(n)))
        cp = co_product(*tp.range_args(n))
        assert list(product(*tp.range_args(n),
                            tqdm_class=tp.mock_tqdm)) \
               == list(cp.range_product())
        assert tp.mock_tqdm.n == cp.num_products


# Generated at 2022-06-12 14:28:39.111622
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from .utils import closing

    with closing(tqdm_auto(ascii=True)) as pbar:
        for i, j in product([1, 4, 6], [-2, 0, 4], total=9, bar_format="{l_bar}{bar} [ time left: {remaining} ]",
                            leave=False):
            pbar.update()
            assert isinstance(pbar.format_dict['bar'], str)
            assert isinstance(pbar.format_dict['l_bar'], str)
            assert isinstance(pbar.format_dict['remaining'], str)
            assert isinstance(pbar.format_dict['elapsed'], str)
            assert isinstance(pbar.format_dict['l_bar'], str)

# Generated at 2022-06-12 14:28:41.512588
# Unit test for function product
def test_product():  # pragma: no cover
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])
    del sys, doctest

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:28:48.383883
# Unit test for function product
def test_product():
    # This test is derived from one of the examples on itertools.product doc
    list(product("ABCD", "xy"))
    list(product("ABCD", "xy", tqdm_class=None))
    from tqdm import tqdm
    list(product("ABCD", "xy", tqdm_class=tqdm))

    from ..std import product as std_product
    list(std_product("ABCD", "xy"))
    list(std_product("ABCD", "xy", tqdm_class=None))
    list(std_product("ABCD", "xy", tqdm_class=tqdm))

    # Make sure that we do not modify the input iterable
    assert list(std_product("ABCD", repeat=2)) == list(product("ABCD", repeat=2))
    assert list

# Generated at 2022-06-12 14:28:58.298255
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    assert list(product(['a', 'b'], repeat=2)) == [('a', 'a'), ('a', 'b'),
                                                   ('b', 'a'), ('b', 'b')]
    # Test multithreading
    import itertools
    import multiprocessing as mp

    work = list(itertools.product(range(10), repeat=2))
    res_mp = []

    def func(inputs):
        res_mp.extend(inputs)

    p = mp.Pool(2)
    r = p.map_async(func,
                    [list(product(range(10), repeat=2, tqdm_class=None))
                     for i in range(2)])
    r.wait()
    p.close()
   

# Generated at 2022-06-12 14:29:04.845210
# Unit test for function product
def test_product():
    import numpy as np  # noqa
    from .tests_tqdm import pretest_posttest

    # from itertools import product
    # def test_gen(l1, l2):
    #     for i in product(l1, l2):
    #         yield i

    # with tqdm(total=len(list(test_gen([1, 2], [3, 4])))) as t:
    #     for i in product([1, 2], [3, 4]):
    #         t.update()

    @pretest_posttest
    def _test():
        """ Test that tqdm format is not broken with Python 2.6 """
        if not hasattr(itertools, "product"):
            raise unittest.SkipTest("Missing itertools.product")


# Generated at 2022-06-12 14:29:13.880262
# Unit test for function product
def test_product():
    from .tests_tqdm import pretest_posttest

    def wrapper_product(*a, **kw):
        return list(product(*a, **kw))

    pretest_posttest(wrapper_product, product)

# Generated at 2022-06-12 14:29:20.034703
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    # Test with simple list input
    l = ['a', 'b', 'c', 'd', 'e']
    with tqdm_auto(total=len(l) ** 2) as t:
        p = product(l, tqdm_class=tqdm_auto, total=len(l) ** 2)
        for i in p:
            assert len(i) == 2
    # Test with iterable input
    with tqdm_auto(total=len(l) ** 2) as t:
        p = product(l, tqdm_class=tqdm_auto, total=len(l) ** 2)
        for i in p:
            assert len(i) == 2

# Generated at 2022-06-12 14:29:28.190498
# Unit test for function product
def test_product():  # pragma: no cover
    from ..std import StringIO
    from ..utils import format_sizeof
    from six.moves import range as xrange

    try:
        from sklearn.datasets import fetch_20newsgroups
        from sklearn.feature_extraction.text import CountVectorizer
    except ImportError:  # pragma: no cover
        return

    categories = [
        'alt.atheism',
        'talk.religion.misc',
    ]
    twenty_train = fetch_20newsgroups(
        data_home=".",
        categories=categories,
        subset='train',
        shuffle=True,
        random_state=42
    )
    count_vect = CountVectorizer()
    X_train_counts = count_vect.fit_transform(twenty_train.data)
   

# Generated at 2022-06-12 14:29:36.868400
# Unit test for function product
def test_product():
    with tqdm_auto(total=12, desc="test_product") as t:
        for i in product(range(3), repeat=2):
            assert i == (i[0],) + (i[1],)
            t.update()
    with tqdm_auto(total=12, desc="test_product") as t:
        for i in product(range(3), repeat=3):
            assert i == (i[0],) + (i[1],) + (i[2],)
            t.update()
    with tqdm_auto(total=4, desc="test_product") as t:
        for i in product(range(3), range(3), range(3)):
            assert i == (i[0],) + (i[1],) + (i[2],)

# Generated at 2022-06-12 14:29:44.881651
# Unit test for function product
def test_product():
    """Test function product"""
    import numpy as np
    from pandas import np as pnp

    try:
        from itertools import izip
    except ImportError:
        from itertools import zip as izip
    try:
        range = xrange
    except:
        pass

    for n, m in [(3, 2), (2, 3), (2, 2), (1, 3), (3, 1)]:
        for x in range(n):
            for y in range(m):
                assert list(product(range(n), range(m))) == list(itertools.product(range(n), range(m)))
                assert list(product(range(n), range(m), tqdm_class=tqdm_auto)) == list(itertools.product(range(n), range(m)))

# Generated at 2022-06-12 14:29:53.877262
# Unit test for function product
def test_product():
    """
    Test for `product`.
    """
    from ..utils import format_sizeof
    from .tests_tqdm import RandomList

    def test(size, *iterables, **tqdm_kwargs):
        """
        Internal test.
        """
        iterables = [range(i) for i in iterables]
        total = 1
        for i in map(len, iterables):
            total *= i

        rl = RandomList(size)
        for _ in product(*iterables, **tqdm_kwargs):
            rl.consume()
        assert rl.size == size
        assert rl.lst == sorted(rl.lst)
        return total

    # `tqdm` should not affect results
    assert test(100, 10, 20, 30) == 6000
    assert test

# Generated at 2022-06-12 14:30:02.517301
# Unit test for function product
def test_product():
    from .tests_tqdm import discretize_range, UnicodeIO

    for tqdm_cls, range_cls in discretize_range():
        with UnicodeIO() as our_file, tqdm_cls(
                file=our_file, desc="product", unit="it",
                leave=False) as t:
            list(tqdm.product(t, range_cls(2)))
        assert our_file.getvalue().count('\r') == 3


# Generated at 2022-06-12 14:30:11.290822
# Unit test for function product
def test_product():
    """
    Unit test for function :func:`tqdm.itertools.product`.
    """
    from .tests_tqdm import StringIO, closing, _range

    for i in _range(4, tqdm_class=lambda *x, **kw: x + (kw,),
                    leave=None):
        assert i == (0, 1, 2, 3, ({'desc': 'itertools.product'},))

# Generated at 2022-06-12 14:30:16.301910
# Unit test for function product
def test_product():
    assert list(product(range(4))) == [(0,), (1,), (2,), (3,)]
    assert list(product(range(2), range(5))) == [(0, 0), (0, 1), (0, 2),
                                                 (0, 3), (0, 4),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (1, 3), (1, 4)]


# Generated at 2022-06-12 14:30:24.012796
# Unit test for function product
def test_product():
    from numpy.testing import assert_array_equal
    from ..utils import _range

    for i in range(2, 10):
        for j in range(i):
            for k in range(i, 10):
                assert_array_equal(
                    list(_range(i)),
                    list(itertools.product(_range(i), repeat=j))[k])


if __name__ == '__main__':  # pragma: no cover
    from ..utils import _range
    import sys
    if len(sys.argv) > 1:
        prog = sys.argv[1]
        if prog == "v":
            for i in product(_range(3), _range(3), _range(3),
                             tqdm_class=tqdm_auto):
                print(i)

# Generated at 2022-06-12 14:30:40.535483
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .utils import PYv
    from .tests_tqdm import with_setup, pretest

    @with_setup(pretest)
    def unit_test():
        """
        Unit test for function product.
        """
        for _ in product(range(1000), repeat=2, tqdm_class=tqdm_auto):
            pass
        t = tqdm_auto(total=1000 * 1000, miniters=100 * 1000)
        for _ in product(range(1000), repeat=2, tqdm_class=t):
            pass

        class T(tqdm_auto):
            """
            Fake class
            """
            @property
            def total(self):
                """
                Returning None is important
                """
                return None
       

# Generated at 2022-06-12 14:30:47.228735
# Unit test for function product
def test_product():
    from copy import copy
    from os import remove
    from tempfile import mkstemp
    try:
        fd, tmp_file = mkstemp(prefix="tqdm_")  # file descriptor, path
        with open(tmp_file, 'w') as f:
            for i in product(range(100), range(100), tqdm_class=tqdm_auto,
                             desc="CUSTOM_DESC_PRODUCT", leave=False):
                f.write(str(i) + '\n')
        with open(tmp_file, 'r') as f:
            lines = f.readlines()
        assert len(lines) == 100 ** 2
    finally:
        remove(tmp_file)

# Generated at 2022-06-12 14:30:55.732255
# Unit test for function product
def test_product():
    for i in product(range(10), range(10, 20)):
        assert i == (i[0], i[1])
        assert i[0] < 10
        assert i[1] >= 10
    for i in product(range(10), range(10, 20), tqdm_class=None):
        assert i == (i[0], i[1])
        assert i[0] < 10
        assert i[1] >= 10
    assert list(product([], [1], [2])) == []
    assert list(product('x', [1, 2])) == list(zip('x', [1, 2]))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:31:01.389668
# Unit test for function product
def test_product():
    """
    Unit test for function `product`
    """
    from ..utils import numpy
    from .pandas import pandas_filter_kwargs

    for iterables in ([0, 1], [0, 1, 2], [0, 1, 2], [0, 1, 2], [0, 1, 2]):
        r = product(*iterables, desc="test", ascii=True, **pandas_filter_kwargs(numpy.random.randint(20, size=(5000, 3))))
        assert len(list(r)) == numpy.product(list(map(len, iterables)))

# Generated at 2022-06-12 14:31:06.142302
# Unit test for function product
def test_product():
    """
    Ensure that `product` function works as expected.
    """
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def capture():
        old = sys.stdout
        capture_out = io.StringIO()
        sys.stdout = capture_out
        yield capture_out
        sys.stdout = old

    with capture() as captured, tqdm.auto.tqdm(disable=True) as t:
        t.write("Hello")
    assert captured.getvalue() == "Hello\n"

    with capture() as captured, tqdm.auto.tqdm(disable=False) as t:
        t.write("Hello")
    assert captured.getvalue() == ""

# Generated at 2022-06-12 14:31:15.402324
# Unit test for function product
def test_product():
    import pytest
    from ..utils import FormatCustomText

    with pytest.raises(TypeError):
        list(product([2, 3], "ab"))
    with pytest.raises(TypeError):
        list(product(['foo', 'bar']))
    assert len(list(product([2, 3], [4, 5]))) == 8
    assert len(list(product([2, 3], [4, 5], [6, 7]))) == 16
    assert (list(product([0], [1, 2], [3, 4, 5])) ==
            [(0, 1, 3), (0, 1, 4), (0, 1, 5), (0, 2, 3), (0, 2, 4), (0, 2, 5)])

# Generated at 2022-06-12 14:31:19.565730
# Unit test for function product
def test_product():
    from distutils.version import LooseVersion
    from .external_versions import pypy_version

    if LooseVersion(pypy_version) >= LooseVersion("2.0"):  # pragma: no cover
        # bug:  https://bitbucket.org/pypy/pypy/issues/1937/
        pass
    else:
        # Unit test
        import numpy as np
        shape = np.array([[0, 2, 3], [2, 3, 3]])
        ix = 0
        for i in product(*shape):
            np.testing.assert_equal(i, shape[:, ix])
            ix += 1
        assert ix == 27

# Generated at 2022-06-12 14:31:26.226488
# Unit test for function product
def test_product():
    from .tests import TestCase

    class TestProduct(TestCase):
        def test(self):
            from .utils import FormatStopwatch
            from time import sleep

            for fmt in ["%(n)d/%(total)d", "%(n)d"]:
                with FormatStopwatch(format=fmt) as s:
                    seq = [(i, j) for i in product(range(3), tqdm_class=self.tqdm)
                           for j in product(range(3), tqdm_class=self.tqdm)]
                    assert len(seq) == 27

    test = TestProduct().test

    # Direct
    with TestProduct(tqdm_class=tqdm_auto) as t:
        test(t)

    # From root namespace (ignores virtualenv)
    tqdm_auto

# Generated at 2022-06-12 14:31:35.648115
# Unit test for function product
def test_product():
    import numpy as np
    e = []
    for j in product(range(10), range(10), range(10),
                     range(10), range(10), range(10)):
        e.append(j)
    assert len(e) == 10 ** 6
    e = []
    for j in product(range(10), range(10)):
        e.append(j)
    assert len(e) == 100
    t = np.array(e).T
    assert np.allclose(t[0], range(10))
    assert np.allclose(t[1], np.array([i // 10 for i in range(100)]))

# Generated at 2022-06-12 14:31:40.230437
# Unit test for function product
def test_product():
    """ Unit test for `tqdm.itertools.product` """
    assert list(product(list(range(3)), list(range(3)), tqdm_class=tqdm_auto)) \
        == list(itertools.product(list(range(3)), list(range(3))))
    assert len(list(product(list(range(3)), list(range(3)), tqdm_class=tqdm_auto))) \
        == 9

# Generated at 2022-06-12 14:32:05.763130
# Unit test for function product
def test_product():
    try:
        from numpy import prod, ndarray
    except ImportError:
        return

    # Test total (without postfix)
    t = tqdm_auto(leave=False)
    for i, _ in enumerate(product(t, range(10), range(10))):
        pass
    assert i == 81
    assert len(t.format_dict["desc"]) == 0

    # Test nested product
    t = tqdm_auto(leave=False)
    for i, _ in enumerate(product(t, product(range(10), range(10)))):
        pass
    assert i == 81
    assert len(t.format_dict["desc"]) == 0

    # Test total (with postfix)
    t = tqdm_auto(leave=False, ascii=False)

# Generated at 2022-06-12 14:32:12.613629
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    from ..utils import FormatCustomText
    test_string = 'Test sample'

    with tqdm_auto(total=6, desc=test_string, leave=False,
                   ascii=True, file=sys.stdout,
                   unit_scale=False, unit="", bar_format=FormatCustomText(test_string)) as t:
        list(product(['a', 'b', 'c'], repeat=2))
        t.write('Test string')
        t.write('Test string')


# Generated at 2022-06-12 14:32:21.028853
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from functools import partial
    from operator import add
    # examples with total
    assert (list(product([1, 2, 3])) ==
            list(itertools.product([1, 2, 3])))
    assert (list(product([1, 2, 3], repeat=2)) ==
            list(itertools.product([1, 2, 3], repeat=2)))
    # examples without total
    assert (list(product(iter(partial(add, 1)))) ==
            list(itertools.product(iter(partial(add, 1)))))
    assert (list(product(iter(partial(add, 1)), repeat=2)) ==
            list(itertools.product(iter(partial(add, 1)), repeat=2)))
    # example with progress

# Generated at 2022-06-12 14:32:29.425704
# Unit test for function product
def test_product():
    from ..tests import _test_iter
    from numpy.random import random
    from numpy import product as numproduct
    for a in range(5):
        for b in range(5):
            for c in range(5):
                # Test with product of (range, range, range)
                def f():
                    for i in product(range(a), range(b), range(c)):
                        yield i[0] + i[1] + i[2]
                yield (_test_iter, f, sum(range(a + b + c)))
                # Test with product of (random, random, random)
                def f():
                    for i in product(random(a), random(b), random(c)):
                        yield i[0] * i[1] * i[2]

# Generated at 2022-06-12 14:32:36.294218
# Unit test for function product
def test_product():
    """Unit test for function ``product``."""
    class MockClass(object):
        """Mock class for ``product`` unit test."""

        def __init__(self):
            self.n = 0

        def update(self):
            self.n += 1

    x = list(range(10))
    y = list(range(5))
    z = list(range(5))

    # Test with ``total=None``
    mock_obj = MockClass()
    for _ in product(x, tqdm_class=mock_obj):
        pass
    assert mock_obj.n == len(x)

    # Test with ``total`` value
    mock_obj = MockClass()
    for _ in product(x, y, z, tqdm_class=mock_obj):
        pass
    assert mock_obj

# Generated at 2022-06-12 14:32:45.321534
# Unit test for function product
def test_product():
    # test the case where tqdm correctly estimates the size of the iterator
    i = itertools.product(range(3), range(3), range(3))
    i = product(*i, tqdm_class = tqdm_auto)
    res = list(i)
    assert len(res) == 27

    # test the case where tqdm fails to estimate the size of the iterator
    class FailLen:
        """Failing length"""
        def __len__(self):
            """Return length"""
            raise TypeError("Faillen error")

    i = itertools.product(FailLen(), FailLen(), FailLen())
    i = product(*i, tqdm_class = tqdm_auto)
    res = list(i)
    assert len(res) == 0  # fails silently

# Generated at 2022-06-12 14:32:51.840498
# Unit test for function product
def test_product():
    from ..utils import frozen_set

    prod = product(*[range(1, 3) for _ in range(3)], tqdm_class=None)

    assert list(prod) == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                          (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
    assert list(prod) == []


# Generated at 2022-06-12 14:32:55.744900
# Unit test for function product
def test_product():
    for i in range(3):
        for j in range(3):
            for k in range(3):
                assert (i, j, k) == next(product(range(3), range(3), range(3)))
    assert (3 * 3 * 3) == len(list(product(range(3), range(3), range(3))))
    assert (1 * 2 * 3) == len(list(product(range(1, 4), repeated=3)))

# Generated at 2022-06-12 14:33:04.718445
# Unit test for function product
def test_product():
    try:
        itertools.product([0, 1], [1, 2, 3], [4, 5])
        itertools.tee  # needs Python >= 2.7.13 or >= 3.5.3
    except Exception:
        return
    from ..utils import FormatCustomText
    from .tqdm_gui import tqdm

    a = [[1, 2], [3, 4]]

    with tqdm(postfix=FormatCustomText("c/s", "custom")) as t:
        for i in product(a[0], a[1], tqdm_class=t.__class__):
            assert i
            t.set_postfix_str("{} / {}".format(i, i))
            t.update()


# Generated at 2022-06-12 14:33:09.038861
# Unit test for function product
def test_product():
    """ Unit tests for function product """
    from . import _test_itertools_mixin

    _test_itertools_mixin._test_itertools_function(
        itertools.product, tqdm_func=product)
    for i in product([1, 2, 3], [1, 2, 3], [1, 2, 3]):
        assert True

# Generated at 2022-06-12 14:33:56.280407
# Unit test for function product
def test_product():
    import sys
    import os
    import tempfile
    import subprocess as sp
    import shutil

    def run_test(f, *args, **kwargs):
        # get baseline
        res1 = f(*args, **kwargs)

        # run test
        try:
            old = sys.stdout
            sys.stdout = open(os.devnull, 'w')
            res2 = list(f(*args, **dict(kwargs, tqdm_class=tqdm_auto)))
            sys.stdout.close()
        finally:
            sys.stdout = old

        # compare results
        assert res1 == res2

    # run test

# Generated at 2022-06-12 14:33:59.705741
# Unit test for function product
def test_product():
    from .base import _test_positionals
    _test_positionals(product, itertools.product)

    from .base import _test_total
    _test_total(product, itertools.product)

    from .base import _test_leave
    _test_leave(product, itertools.product)

    from .base import _test_smoothing
    _test_smoothing(product, itertools.product)

# Generated at 2022-06-12 14:34:08.121985
# Unit test for function product
def test_product():
    """
    Unit tests for function `product`.
    """
    from ..pandas import tqdm_pandas

    data = list(product(range(0, 4), range(0, 4), tqdm_class=tqdm_pandas))
    assert data == [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2),
                    (1, 3), (2, 0), (2, 1), (2, 2), (2, 3), (3, 0), (3, 1),
                    (3, 2), (3, 3)]

# Generated at 2022-06-12 14:34:17.699170
# Unit test for function product
def test_product():
    from .nested import indexed_grouper
    from .trange import trange

    list(product([1], tqdm_class=None))
    list(product(["a", "b"], ["c"], ["d", "e", "f"]))
    list(product(trange(100), leave=True))
    list(product(range(0, 100), repeat=0))
    list(product(["a", "b"], ["c"], ["d", "e", "f"]))
    list(product(["a", "b"], ["c"], ["d", "e", "f"]))
    list(product(["a", "b"], ["c"], ["d", "e", "f"]))
    list(product(["a", "b"], ["c"], ["d", "e", "f"]))

# Generated at 2022-06-12 14:34:25.761681
# Unit test for function product
def test_product():
    from ._utils import FakeTqdmFile
    with FakeTqdmFile() as f:
        for _ in product(range(2), range(3), range(4),
                         tqdm_class=tqdm_auto, file=f):
            pass
        # NOTE: total=24, unit_scale=True,
        # NOTE: leave=False, miniters=1

# Generated at 2022-06-12 14:34:29.723741
# Unit test for function product
def test_product():
    from .tests_tqdm import pretest_posttest
    from .tests_tqdm import StringIO

    pretest_posttest(
        inp=[
            (3,),
            (3, 2)
            ],
        func=lambda x, **kwargs: list(product(*x, **kwargs)),
        total=[
            3,
            6],
        file=StringIO(),
        desc=lambda x: '\n'.join(map(str, x)))

# Generated at 2022-06-12 14:34:36.527667
# Unit test for function product
def test_product():
    """Unit test for function product."""
    from numpy.random import randint
    sizes = randint(1, 11,  # Randomly generate test samples
                    size=randint(1, 5))
    try:
        # tqdm.tqdm is imported only to test the auto-detection of tqdm
        import tqdm
        _tqdm = tqdm.tqdm
    except ImportError:
        _tqdm = tqdm_auto

    for size in sizes:
        iters = tuple(randint(1, 11, size=size) for _ in range(size))
        prods = product(*iters, tqdm_class=_tqdm)
        for p, p_ref in zip(prods, itertools.product(*iters)):
            assert p == p_ref

# Generated at 2022-06-12 14:34:37.318318
# Unit test for function product
def test_product():
    list(product('ab', range(3)))

# Generated at 2022-06-12 14:34:45.754808
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import random
    p = product([1, 2, 3], [4, 5, 6], tqdm_class=None)
    for x, y in zip(p, itertools.product([1, 2, 3], [4, 5, 6])):
        assert x == y

    random.seed(0)
    p = product([1, 2, 3], [4, 5, 6], tqdm_class=tqdm_auto)
    for x, y in zip(p, itertools.product([1, 2, 3], [4, 5, 6])):
        assert x == y

    random.seed(0)

# Generated at 2022-06-12 14:34:53.549220
# Unit test for function product
def test_product():
    '''Unit test for tqdm(itertools.product())'''
    from .tests import pretest_posttest_empty, closing, nested

    @closing
    def test_product(tqdm_cls):
        """Test that `tqdm(itertools.product(...))` works"""
        pretest_posttest_empty(tqdm_cls, product, (range(5),))
    test_product()

    @nested
    def test_product(nested, tqdm_cls):
        """Test that `tqdm(itertools.product(...))` works"""
        pretest_posttest_empty(tqdm_cls, product, (range(5),))
    test_product()