

# Generated at 2022-06-12 14:27:05.614851
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    from .iter_ipython import test_iter_examples
    test_iter_examples(
        product, iterables=["a", "bc", "de"], total=12, show_results=True)


# Alias
cartesian = product

# Generated at 2022-06-12 14:27:09.974670
# Unit test for function product
def test_product():
    with tqdm_auto(total=10000) as t:
        for i in product(range(100), tqdm=t):
            pass
    # Nested
    with tqdm_auto(total=10000) as t:
        for i in product(range(100), tqdm=t):
            pass

# Generated at 2022-06-12 14:27:14.061960
# Unit test for function product
def test_product():
    """
    Simple test for `tqdm.product`.
    """
    from tqdm import tqdm
    s = 0
    for i in tqdm(product('ABC', repeat=2)):
        s += sum(i)
    assert s == 165, s

# Generated at 2022-06-12 14:27:20.936785
# Unit test for function product
def test_product():
    from .tqdm import TqdmTypeError
    for kwargs in [dict(), dict(tqdm_class=lambda x: x)]:
        for iterables in [
                (range(1, 10),),
                (range(1, 3), range(10, 20))]:
            out1 = list(itertools.product(*iterables))
            out2 = list(product(*iterables, **kwargs))
            assert out1 == out2, "{0} != {1}".format(out1, out2)
            assert (isinstance(out2[-1], tuple) and
                    all(isinstance(i, int) for i in out2[-1]))

    # Test wrong input
    iterables = (None, 'abc', 123)

# Generated at 2022-06-12 14:27:25.159126
# Unit test for function product
def test_product():
    """
    Unit test `product` function.
    """
    from ..__init__ import tqdm

    assert list(product([1, 2, 3], ["a", "b"])) == \
        list(itertools.product([1, 2, 3], ["a", "b"]))

    assert list(product([1, 2, 3], ["a", "b"], tqdm_class=tqdm)) == \
        list(itertools.product([1, 2, 3], ["a", "b"]))

# Generated at 2022-06-12 14:27:35.232621
# Unit test for function product
def test_product():
    import sys
    import io
    import numpy as np
    from tqdm.utils import _term_move_up

    out = io.BytesIO()
    sys.stdout = out
    p1 = product(np.arange(5), tqdm_class=tqdm_auto)
    assert len(p1) == 5
    p2 = product(np.arange(5), np.arange(5), tqdm_class=tqdm_auto)
    assert len(p2) == 25
    val = out.getvalue()
    off = val.find(b"100%")
    assert off > 0
    # Move up one line to get the second progress bar
    _term_move_up()
    assert val[:off] == _term_move_up() + _term_move_up()

# Generated at 2022-06-12 14:27:42.747281
# Unit test for function product
def test_product():
    try:
        #> py3
        from itertools import zip_longest
    except ImportError:
        #> py2
        from itertools import izip_longest as zip_longest

    for l in (1, 10, 100):
        for r in (1, 10, 100):
            for v in (None, -1, 42, 42.5, "foo", [], {}, range):
                left = (v for _ in range(l))
                right = (v for _ in range(r))
                _product = list(itertools.product(left, right))
                tproduct = list(tqdm.product(left, right))

                # Check total (if known)
                total = getattr(tproduct, "total", None)

# Generated at 2022-06-12 14:27:53.150472
# Unit test for function product
def test_product():
    from .tests import TestCase  # NOQA
    # Preferance should be given to arguments over stdin
    for a, b, c in product([1, 2], [3, 4], ["A", "B"],
                           tqdm_class=TestCase.tqdm_class):
        TestCase.add(a, b, c)
    TestCase.check()
    TestCase.clear()
    for a, b, c in product([1, 2], [3, 4], ["A", "B"],
                           tqdm_class=TestCase.tqdm_class, total=8):
        TestCase.add(a, b, c)
    TestCase.check()


if __name__ == "__main__":
    from .tests import main  # NOQA

# Generated at 2022-06-12 14:28:01.664035
# Unit test for function product
def test_product():
    """
    Test function product().
    """
    import sys
    import os
    import warnings
    from contextlib import contextmanager
    from ..pandas import tqdm_pandas

    # Nose does not support function yielded from
    if 'nose' in sys.modules:
        raise nose.SkipTest

    @contextmanager
    def captured_output():
        new_out, new_err = os.pipe()
        old_out, old_err = sys.stdout.fileno(), sys.stderr.fileno()

# Generated at 2022-06-12 14:28:02.657917
# Unit test for function product
def test_product():
    from .tests import test_product
    test_product()

# Generated at 2022-06-12 14:28:08.813839
# Unit test for function product
def test_product():
    """Test to ensure product=product"""
    assert set(itertools.product([1, 2], [3, 4])) == set(product([1, 2], [3, 4]))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:28:16.383413
# Unit test for function product
def test_product():
    """Test ``itertools.product`` wrapper."""
    import io
    import sys
    import re

    def monkeypatch(func, replacement):
        """Replace a function, and return the function that was replaced."""
        orig_func = getattr(itertools, func)
        setattr(itertools, func, replacement)
        return orig_func

    # Hide itertools.product to test only tqdm wrapper
    itertools_product = monkeypatch("product", None)

    def product(*iterables, **tqdm_kwargs):
        """itertools.product wrapper"""
        return itertools_product(*iterables, **tqdm_kwargs)

    # Test cases

# Generated at 2022-06-12 14:28:26.283174
# Unit test for function product
def test_product():
    """
    Unit test for function `tqdm.itertools.product`.
    """
    import sys
    import os
    import inspect
    from .utils import _range, format_sizeof

    if '_test_itertools_product' in os.environ:
        from .gui import tqdm_notebook  # requires ipython > 3
        tqdm = tqdm_notebook
    else:
        from .std import tqdm

    def get_curframe():
        """Return the frame object for the caller's stack frame."""
        try:
            raise Exception
        except:
            return sys.exc_info()[2].tb_frame.f_back


# Generated at 2022-06-12 14:28:29.744768
# Unit test for function product
def test_product():
    from ..std import next
    assert next(product(range(10), range(10))) == (0, 0)
    assert next(product(range(10), repeat=10)) == tuple(0 for _ in range(10))
    assert next(product(range(10), repeat=2)) == (0, 0)
    assert next(product(range(10), range(10))) == (0, 0)

# Generated at 2022-06-12 14:28:39.075329
# Unit test for function product
def test_product():
    import sys
    import copy
    from ._utils import _random_data, FakeTqdmFile, closing

    # Test on integers
    it1 = [1, 2, 3]
    it2 = ['a', 'b']
    assert list(product(it1, it2)) == [
        (1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')
    ]

    # Test on generator
    it = (x for x in range(10))
    assert list(product(it)) == [()]

    # Test on single argument
    it = range(10)
    assert list(product(it)) == [()]

    # Test with tqdm and tqdm_gui

# Generated at 2022-06-12 14:28:45.543109
# Unit test for function product
def test_product():
    from .tests_tqdm import pretest_posttest
    from itertools import product as itertools_product
    for kwargs in [dict(),
                   dict(tqdm_class=lambda iterable, **kwargs: iterable)]:
        for total in [None, 10, 100]:
            for a in [range(10)] + ['abcde', 'abcdefghijklmnopqrstuvwxyz']:
                a = list(a)
                for b in [range(10)] + ['abcde', 'abcdefghijklmnopqrstuvwxyz']:
                    b = list(b)
                    for c in [range(10)] + ['abcde', 'abcdefghijklmnopqrstuvwxyz']:
                        c = list(c)

# Generated at 2022-06-12 14:28:55.745503
# Unit test for function product
def test_product():
    assert list(product([10, 20], [5, 10], [1.0, 2.0], tqdm_class=None)) == [
        (10, 5, 1.0), (10, 5, 2.0), (10, 10, 1.0), (10, 10, 2.0),
        (20, 5, 1.0), (20, 5, 2.0), (20, 10, 1.0), (20, 10, 2.0)
    ]
    assert list(product({'a': 10, 'b': 20}, [1, 2], tqdm_class=None)) == [
        ('a', 1), ('a', 2), ('b', 1), ('b', 2)
    ]

# Generated at 2022-06-12 14:29:04.477718
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import sys
    import io
    import random
    import pytest
    from .miscs import _range

    try:
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()
        random.seed(1)
        itertools.product(*[range(0, random.randint(1, 5))
                            for i in _range(random.randint(1, 5))])
        random.seed(1)
        gen_product = product(*[range(0, random.randint(1, 5))
                                for i in _range(random.randint(1, 5))])
        sys.stderr = old_stderr
    except:
        sys.stderr = old_stderr
        raise

# Generated at 2022-06-12 14:29:06.483981
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for a in product(["a", "b", "c"], repeat=3,
                     tqdm_class=tqdm_auto.tqdm_gui):
        pass

# Generated at 2022-06-12 14:29:15.006003
# Unit test for function product
def test_product():
    """
    Unit test for `product`
    """
    import numpy as np
    i = 0
    for ii in product(range(10), range(10), range(10)):
        assert all(np.array(ii) == np.unravel_index(i, (10, 10, 10)))
        i += 1
    assert i == 1000
    i = 0
    for ii in product(xrange(10), xrange(10), xrange(10)):
        assert all(np.array(ii) == np.unravel_index(i, (10, 10, 10)))
        i += 1
    assert i == 1000

# Generated at 2022-06-12 14:29:28.210666
# Unit test for function product
def test_product():
    """
    Unit test for :func:`product
    """
    assert list(product([1], [2], [3])) == [(1, 2, 3)]
    a = list(product([1, 2], [3, 4]))
    assert (1, 3) in a
    assert (1, 4) in a
    assert (2, 3) in a
    assert (2, 4) in a
    import sys
    if sys.version_info >= (3, ):
        assert (1, 3) in a
        assert (1, 4) in a
        assert (2, 3) in a
        assert (2, 4) in a

# Generated at 2022-06-12 14:29:34.798092
# Unit test for function product
def test_product():
    """Test itertools.product"""
    from random import randrange
    valid_list = [[randrange(1, 50) for _ in range(50)] for _ in range(10)]

    for inp in valid_list:
        valid = set(itertools.product(*inp))
        tst_set = set(product(*inp, tqdm_class=tqdm_auto))
        assert tst_set == valid, "itertools.product is not the same " \
                                 "as tqdm.itertools.product"

# Generated at 2022-06-12 14:29:40.235293
# Unit test for function product
def test_product():
    "Test for function product"
    import numpy as np
    from ..tests import mock_args
    from ..auto import tqdm
    with mock_args():
        kwargs = dict(tqdm_class=tqdm)

        assert (
            list(product(xrange(2), xrange(5), xrange(3), **kwargs)) ==
            list(itertools.product(xrange(2), xrange(5), xrange(3)))
        )
        assert (
            list(product([1, 1, 1], "ab", xrange(5), **kwargs)) ==
            list(itertools.product([1, 1, 1], "ab", xrange(5)))
        )

# Generated at 2022-06-12 14:29:44.396853
# Unit test for function product
def test_product():
    import numpy as np
    a = np.ones(10)
    b = np.ones(10)
    c = np.ones(10)
    for i, (x, y, z) in enumerate(product(a, b, c, tqdm_class=tqdm_auto)):
        assert i == (x * y * z) - 1

# Generated at 2022-06-12 14:29:53.304620
# Unit test for function product
def test_product():
    """
    Doctest for ``itertools.product``.

    >>> from itertools_tqdm import product
    >>> list(product([1, 2], repeat=1))
    [1, 2]
    >>> list(product([1, 2], repeat=2))
    [(1, 1), (1, 2), (2, 1), (2, 2)]
    >>> list(product(["a", "b"], [1, 2], [3, 4]))
    [('a', 1, 3), ('a', 1, 4), ('a', 2, 3), ('a', 2, 4), ('b', 1, 3), ('b', 1, 4), ('b', 2, 3), ('b', 2, 4)]
    """
from itertools import product
from tqdm import tqdm # For testing

# Generated at 2022-06-12 14:30:01.985082
# Unit test for function product
def test_product():
    """Test function product"""
    # Test with `tqdm.auto`
    assert list(product('ABCD', repeat=2)) == list(itertools.product('ABCD', repeat=2))
    assert list(product('ABCD', repeat=3)) == list(itertools.product('ABCD', repeat=3))
    assert list(product(range(2), repeat=2)) == list(itertools.product(range(2), repeat=2))
    assert list(product(range(3), repeat=3)) == list(itertools.product(range(3), repeat=3))
    # Test with `tqdm`
    from tqdm import trange

# Generated at 2022-06-12 14:30:09.131380
# Unit test for function product
def test_product():
    """test function product"""
    # check that nested loops work
    a, b, c = [range(1, 4), range(1, 4), range(1, 4)]
    assert list(product(a)) == [(i,) for i in a]
    assert list(product(a, b)) == [(i, j) for i in a for j in b]
    assert list(product(a, b, c)) == [(i, j, k) for i in a for j in b for k in c]
    # check that total is properly calculated
    assert len(list(product(a, b, c))) == 9
    # check that empty iterables are properly handled
    assert list(product(a, b, [])) == []

# Generated at 2022-06-12 14:30:11.379296
# Unit test for function product
def test_product():
    for i in product(range(4), range(4)):
        pass
    assert i == (3, 3)


# Generated at 2022-06-12 14:30:16.355447
# Unit test for function product
def test_product():
    # Test with array-like iterables
    list1 = [0, 1, 2]
    list2 = [10, 20, 30]
    list3 = [100, 200]

    # Test with scalar iterables
    list4 = 2
    list5 = 1

    for data in product(list1, list2, list3):
        pass

    for data in product(list1, list2, list3, tqdm_class=tqdm_auto):
        pass

    for data in product(list1, list2, list3, tqdm_class=tqdm_auto):
        pass

    for data in product(list1, list2, list4, list5):
        pass


# Generated at 2022-06-12 14:30:22.515086
# Unit test for function product
def test_product():
    from tqdm import trange
    from .itertools import product
    from .tqdm_pandas import tqdm_pandas
    from .tqdm_gui import tqdm_gui
    from numpy import product as npproduct
    test_elements = list(range(6))
    for tqdm in [trange, tqdm_gui, tqdm_pandas]:
        assert npproduct(test_elements) == sum(
            i for i in product(test_elements, tqdm_class=tqdm))

# Generated at 2022-06-12 14:30:39.869982
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal

    for iterable0 in [list(range(i)) for i in range(1, 3)]:
        for iterable1 in [list(range(i)) for i in range(1, 3)]:
            for iterable2 in [list(range(i)) for i in range(1, 3)]:
                products = list(itertools.product(iterable0, iterable1,
                                                  iterable2))
                products_tqdm = list(product(iterable0, iterable1, iterable2))
                assert_equal(products, products_tqdm)

# Generated at 2022-06-12 14:30:47.491392
# Unit test for function product
def test_product():
    """Test `tqdm.itertools.product`."""
    from ..pandas import tqdm_pandas; _ = tqdm_pandas
    from ..gui import tqdm; _ = tqdm
    from ..cli import tqdm; _ = tqdm
    from ..auto import tqdm; _ = tqdm


# Generated at 2022-06-12 14:30:56.907858
# Unit test for function product
def test_product():
    from numpy.random import random
    from os import devnull
    from sys import stderr

    lens = [0, 1, 2]
    for i in lens:
        for j in lens:
            for k in lens:
                iterables = random((i, 2, 3)).tolist(),\
                            random((j, 2, 3)).tolist(),\
                            random((k, 2, 3)).tolist()
                a = list(product(*iterables, tqdm_class=tqdm_auto,
                                 file=devnull))
                b = list(itertools.product(*iterables))
                assert a == b

    # check error if not iterable

# Generated at 2022-06-12 14:31:03.647502
# Unit test for function product
def test_product():
    import os
    import sys
    import tempfile


# Generated at 2022-06-12 14:31:13.610803
# Unit test for function product
def test_product():
    from .utils import _range
    for i in product(_range(0), _range(1), _range(2), _range(3)):
        assert 0 <= i[0] < 1
        assert 0 <= i[1] < 2
        assert 0 <= i[2] < 3
        assert 0 <= i[3] < 4
    total = 1
    for i in (0, 1, 2, 3):
        total *= i
    assert total == 24
    assert list(product(_range(0), _range(0))) == []
    assert list(product(_range(0, 5), repeat=4)) == list(itertools.product(
        _range(0, 5), repeat=4))

    # Avoid `len(..)` calls
    assert list(product(x for x in range(0))) == []

# Generated at 2022-06-12 14:31:21.015038
# Unit test for function product
def test_product():
    from .utils import _range, FormatWrapBase
    from numpy import all

    V = 100
    r0 = _range(V)
    r1 = list(range(V))

    res = list(product(r0, r1))
    assert len(res) == V * V

    res = list(product(r0, repeat=V))
    assert len(res) == V ** V

    res = list(product(r0, r1, tqdm_class=FormatWrapBase))
    assert len(res) == V * V

    res = list(product(r0, repeat=V, tqdm_class=FormatWrapBase))
    assert len(res) == V ** V

    # Test for numpy ndarray input
    from numpy import arange
    r0 = arange(V)


# Generated at 2022-06-12 14:31:27.314631
# Unit test for function product
def test_product():
    """Test function product"""
    # This test is insufficient because it only covers a single case
    from ..utils import format_sizeof
    from .utils import format_bytes
    globals_in = globals()
    locals_in = locals()
    address_in = id(globals()) + id(locals())
    import gc
    for _ in range(4):
        gc.collect()
    test_string = "0123456789"
    a = list(range(8))
    b = list(test_string)
    c = list(test_string)
    guide = list(zip(a, b, c))
    t = product(a, b, c, tqdm_class=tqdm_auto)
    assert next(t) == guide[0]

# Generated at 2022-06-12 14:31:36.968323
# Unit test for function product
def test_product():
    """
    Unit test for function :func:`itertools.product`.
    """
    import sys
    import os

    from .. import tqdm
    from ..utils import _term_move_up

    # Test total
    with tqdm(total=9, file=sys.stdout) as t:
        for i in product([1, 2, 3], repeat=2):
            t.update()
    assert t.total == 9

    # Test dynamic total
    with tqdm(total=None, file=sys.stdout) as t:
        for _ in product([1, 2, 3], repeat=2):
            t.update()
    assert t.total == 9

    # Test nested

# Generated at 2022-06-12 14:31:39.492761
# Unit test for function product
def test_product():
    """
    Unit tests for `product`

    Notes
    -----
    Uses pytest
    """
    import pytest
    with pytest.raises(TypeError):
        for _ in product([], tqdm_class=None):
            pass

# Generated at 2022-06-12 14:31:47.309274
# Unit test for function product
def test_product():
    """Test function product"""
    ilist = [range(5), range(5), range(5)]
    iprod = list(product(*ilist))
    assert len(iprod) == 125
    assert iprod[0] == (0, 0, 0)
    assert iprod[-1] == (4, 4, 4)
    assert list(product(*ilist, total=10)) == ilist
    ilist = [xrange(5), xrange(5), xrange(5)]
    iprod = list(product(*ilist))
    assert len(iprod) == 125
    assert iprod[0] == (0, 0, 0)
    assert iprod[-1] == (4, 4, 4)

# Generated at 2022-06-12 14:32:04.304232
# Unit test for function product
def test_product():
    """
    Simple function test.
    """
    from contextlib import redirect_stderr
    import io
    import sys
    import loguru

    loguru.logger.disable("tqdm")

    with io.StringIO() as buf, redirect_stderr(buf):
        for _ in product("ABC", "DEF", tqdm_class=tqdm_auto):
            pass
        # sys.stderr.flush()
        assert buf.getvalue() == ("18it [00:00, ?it/s]\n")

        from tqdm.auto import tqdm
        for _ in tqdm_auto("ABC", desc="desc", leave=False):
            pass
        # sys.stderr.flush()

# Generated at 2022-06-12 14:32:11.371928
# Unit test for function product
def test_product():
    """
    Simple unit test for function product.
    """
    from os import remove
    try:
        remove("product")
    except OSError:
        pass

    with open("product", "w") as f:
        for _ in product("abc", "123", tqdm_class=tqdm_auto, file=f):
            pass

    with open("product") as f:
        s = f.read()
    assert 'abc123' in s
    assert 'cba321' in s

    from ..main import tqdm
    try:
        import numpy as np
    except ImportError:
        return
    for _ in tqdm(product([1, 2], np.arange(10))):
        pass


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:32:20.233678
# Unit test for function product
def test_product():
    from numpy.random import randint
    try:
        from numpy.testing import assert_array_equal
    except ImportError:
        assert_array_equal = None
    try:
        from pandas.util.testing import assert_series_equal
    except ImportError:
        assert_series_equal = None

    from ..auto import tqdm
    from ..std import get_shape

    assert_array_equal(
        list(product(
            range(2),
            tqdm(range(3), desc="first range"),
            tqdm(range(4), desc="second range")
        )),
        list(itertools.product(range(2), range(3), range(4)))
    )

# Generated at 2022-06-12 14:32:28.709789
# Unit test for function product
def test_product():
    """ Test product() """
    # Test that the normal itertools.product is equivalent to the wrapped
    from itertools import product as itertools_product
    assert [i for i in product(range(2),
                               range(3))] == \
        [i for i in itertools_product(range(2), range(3))]
    # Test that it works with a string
    assert [i for i in product("ab",
                               "cd")] == \
        [i for i in itertools_product("ab", "cd")]
    # Test that it works with tuple arguments
    assert [i for i in product((1, 2),
                               (2, 3))] == \
        [i for i in itertools_product((1, 2), (2, 3))]

# Generated at 2022-06-12 14:32:35.917259
# Unit test for function product
def test_product():
    """Test product unit"""
    import random
    import math
    random.seed(0)
    assert list(product(range(100), range(100))) == list(
        itertools.product(range(100), range(100)))
    assert list(product(range(100), range(100), tqdm_class=None)) == list(
        itertools.product(range(100), range(100)))
    assert len(list(product(range(100), range(100)))) == 100 * 100
    assert len(list(product(range(100), range(100), tqdm_class=None))) == 100 * 100
    assert len(list(product(range(100), range(100), ascii=True,
                            tqdm_class=None))) == 100 * 100

# Generated at 2022-06-12 14:32:42.687832
# Unit test for function product
def test_product():
    iterables = [range(3), range(2)]
    _product = list(product(*iterables))
    assert _product == [(0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1)]

    iterables = [range(3), range(2)]
    _product = list(product(*iterables, tqdm_class=None))
    assert _product == [(0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1)]

# Generated at 2022-06-12 14:32:47.589995
# Unit test for function product
def test_product():
    """Unit test for function product."""
    from numpy.testing import assert_equal
    assert_equal(
        list(product(range(3), range(3), tqdm_class=tqdm_auto, desc="product")),
        list(itertools.product(range(3), range(3))))

# Generated at 2022-06-12 14:32:53.267544
# Unit test for function product
def test_product():
    from collections import Counter
    from six.moves import range
    from .main import tqdm
    # Base test
    assert list(product(range(5), repeat=2)) == list(itertools.product(range(5), repeat=2))
    assert list(product(range(5), range(5), repeat=2)) == list(itertools.product(range(5), range(5), repeat=2))
    assert list(product(range(5), range(5), range(5), repeat=2)) == list(itertools.product(range(5), range(5), range(5), repeat=2))
    # Test dynamic changing of tqdm `total`

# Generated at 2022-06-12 14:33:01.968591
# Unit test for function product
def test_product():
    import numpy as np
    import pytest
    from io import StringIO

    PROD_TEST_1 = (
        np.array(list(product(range(2), range(2), range(2)))),
        np.array([(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0),
                 (1, 0, 1), (1, 1, 0), (1, 1, 1)])
    )

# Generated at 2022-06-12 14:33:10.391802
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import freeze_support
    from ..utils import _range, FormatCustomText
    from .. import trange
    
    with freeze_support():
        # check that all iterables are processed
        with trange(10 ** 6, file=FormatCustomText(
                prefix="product(range(10), repeat=6): ")) as t:
            for i in product(_range(10), repeat=6):
                t.update()
        assert t.n == 10 ** 6

        # check keyword arguments
        with trange(10, desc="product(range(10), repeat=3)",
                    file=FormatCustomText(prefix="prefix")) as t:
            for i in product(_range(10), repeat=3, tqdm_class=t.__class__):
                t.update()

# Generated at 2022-06-12 14:33:32.775768
# Unit test for function product
def test_product():
    import numpy as np
    import sys

    ITERABLES = [np.arange(10).tolist(), np.arange(10).tolist()]
    with tqdm_auto(total=10**2, file=sys.stdout) as t:
        for _ in product(*ITERABLES, tqdm_class=tqdm_auto):
            t.update()

# Generated at 2022-06-12 14:33:34.927461
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product("AB", "CD")) == [("A", "C"), ("A", "D"), ("B", "C"), ("B", "D")]

# Generated at 2022-06-12 14:33:42.605641
# Unit test for function product
def test_product():
    import sys
    import numpy as np
    from ..std import numpy as np_std

    ranges = [np.linspace(0, 1, 10).tolist(),
              np.linspace(10, 20, 10).tolist(),
              np.linspace(100, 200, 10).tolist()]
    for i in product(*ranges, total=None):
        pass
    for i in product(*ranges, total=1000):
        pass
    for i in product(*ranges, total=None, mininterval=0.1, desc='prod'):
        pass
    for i in product(*ranges, total=1000, mininterval=0.1, desc='prod'):
        pass

# Generated at 2022-06-12 14:33:50.696462
# Unit test for function product
def test_product():
    import itertools as it
    from collections import Counter
    from .tests_tqdm import with_setup, pretest, posttest, _range

    with pretest(it.product, total=2520):
        r = product(_range(1, 11), _range(10, 0, -1),
                    tqdm_class=tqdm_auto,
                    desc='Test product')
    assert Counter(r) == Counter(
        it.product(_range(1, 11), _range(10, 0, -1)))
    with posttest(it.product) as r:
        product(_range(1, 11), _range(10, 0, -1),
                tqdm_class=tqdm_auto,
                desc='Test product')

# Generated at 2022-06-12 14:33:57.841222
# Unit test for function product
def test_product():
    import os
    import sys
    from .utils import closing

    n = 8
    for cls in [tqdm_auto, tqdm_auto._tqdm_notebook_impl]:
        out = []
        for _ in product(range(n), range(n), tqdm_class=cls):
            out.append(1)
            for _ in range(4):
                _ = (2 ** 32) ** .5  # slow down iterations
        assert n ** 2 == len(out)

    n = 64
    for cls in [tqdm_auto, tqdm_auto._tqdm_notebook_impl]:
        out = []
        for _ in product(range(n), range(n), tqdm_class=cls):
            out.append(1)
        assert n ** 2 == len

# Generated at 2022-06-12 14:34:03.211852
# Unit test for function product
def test_product():
    from .utils import closing, FakeTqdmFile, StringIO

    # Smoke test
    for _ in product(range(2), range(2)):
        pass

    # Test successive yield
    first = True
    for i in product(range(3), range(5)):
        if first:
            assert i == (0, 0)
        else:
            assert i == (1, 0)
        first = not first

    with closing(StringIO()) as our_file:
        with tqdm_auto(ncols=43, file=our_file) as t:
            for i in product(t, range(1000)):
                pass
            assert our_file.getvalue() == ""  # Nothing printed before closing


# Generated at 2022-06-12 14:34:13.113816
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from random import randint
    from sys import modules

    # Smoke test #1
    assert_equal(
        list(product([0, 1], [2, 3], [4, 5])),
        [(0, 2, 4), (0, 2, 5), (0, 3, 4), (0, 3, 5), (1, 2, 4), (1, 2, 5),
         (1, 3, 4), (1, 3, 5)])

    # Smoke test #2
    assert_equal(
        list(product([0, 1], repeat=2)),
        [(0, 0), (0, 1), (1, 0), (1, 1)])

    # Unit test #1
    mock_tqdm = modules["test_tqdm"]

# Generated at 2022-06-12 14:34:17.425461
# Unit test for function product
def test_product():
    """Test for itertools.product wrapper."""
    from .tests.test_itertools import test_if_function_equivalent

    test_if_function_equivalent(itertools.product, product,
                                iterable_list=list(range(3)))

# Generated at 2022-06-12 14:34:25.467457
# Unit test for function product
def test_product():
    """ Unit tests for function product """
    from numpy import allclose, array_equal
    from ..tqdm import tqdm
    from .tests_tqdm import pretest_posttest

    @pretest_posttest
    def test_product_a():
        """ Test product """
        x = list(tqdm.product(range(4), repeat=2))
        assert x == [(0, 0), (0, 1), (0, 2), (0, 3),
                     (1, 0), (1, 1), (1, 2), (1, 3),
                     (2, 0), (2, 1), (2, 2), (2, 3),
                     (3, 0), (3, 1), (3, 2), (3, 3)]
        return True


# Generated at 2022-06-12 14:34:29.723322
# Unit test for function product
def test_product():
    import tqdm
    import random
    iterables = [[random.random() for _ in range(10000)] for _ in range(10)]
    res = [i for i in product(*iterables)]
    res2 = [i for i in tqdm.tqdm(itertools.product(*iterables))]
    assert res == res2
    assert len(res) == len(res2) == len(iterables[0]) ** len(iterables)


test_product.test_product = True  # for pytest

# Generated at 2022-06-12 14:35:12.387538
# Unit test for function product
def test_product():
    import numpy as np
    from ..auto import tqdm

    for t in [tqdm_auto, tqdm]:
        for a, b in product(range(4), range(4), tqdm_class=t):
            pass
        for a, b in product(range(4), range(4), tqdm_class=t, total=16):
            pass
        for a, b in product(range(0), range(4), tqdm_class=t):
            pass
        try:
            for a, b in product(range(4), np.arange(4), tqdm_class=t):
                pass
        except TypeError:
            pass
        else:
            assert False, "Do not allow non-iterable arguments"

# Generated at 2022-06-12 14:35:15.370869
# Unit test for function product
def test_product():
    iproduct = product([1, 2, 3, 4], range(1, 3), tqdm_class=None)
    oproduct = itertools.product([1, 2, 3, 4], range(1, 3))
    list(iproduct) == list(oproduct)

# Generated at 2022-06-12 14:35:20.131329
# Unit test for function product
def test_product():
    from .std import tqdm

    # Without total
    for _ in product('ABCD', repeat=2):
        pass

    # With total
    for _ in product(range(1000), repeat=2, tqdm_class=tqdm):
        pass

    # Test error
    s = 'ABCD'
    try:
        for _ in product(s, repeat=2, tqdm_class=tqdm):
            s.append('E')
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-12 14:35:25.711250
# Unit test for function product
def test_product():
    import itertools
    list1 = iter(list(range(10)))
    list2 = iter(list(range(10)))
    list3 = iter(list(range(10)))
    list4 = iter(list(range(10)))
    list5 = iter(list(range(10)))

    for i in product(list1, list2, list3, list4, list5,
                     tqdm_class=tqdm_auto, total=10 * 10 * 10 * 10 * 10):
        pass

# Generated at 2022-06-12 14:35:28.489044
# Unit test for function product
def test_product():
    for n in product(range(3), range(3), range(3),
                     tqdm_class=None):
        assert n
    for n in product(range(10), range(5), range(2),
                     tqdm=None):
        assert n

# Generated at 2022-06-12 14:35:37.053403
# Unit test for function product
def test_product():
    from ..utils import FormatMixin
    import numpy as np
    class TqdmTypeError(TypeError, FormatMixin):
        pass


# Generated at 2022-06-12 14:35:43.472267
# Unit test for function product
def test_product():
    """Test for function product"""
    from .tests_tqdm import pretest_posttest

    def test_product_1(tqdm_class=tqdm_auto):
        list(product(*list(map(list, map(range, [3, 4, 5]))),
                     tqdm_class=tqdm_class))

    def test_product_2(tqdm_class=tqdm_auto):
        list(product(*list(map(dict, map(range, [3, 4, 5]))),
                     tqdm_class=tqdm_class))


# Generated at 2022-06-12 14:35:51.319727
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    try:  # Python 2
        from cStringIO import StringIO
    except ImportError:  # Python 3
        from io import StringIO
    from sys import stdout
    from .bar import Bar
    from .tqdm import trange, tqdm

    for iterable in (xrange(100), list('abcdefghij')):
        for kwargs in (
                {}, {"total": None}, {"total": 10}, {"total": None, "miniters": 10},
                {"total": 10, "miniters": 10}):
            p = product(iterable, **kwargs)
            with StringIO() as s:
                with Bar(file=s, **kwargs) as b:
                    list(p)

# Generated at 2022-06-12 14:35:53.951220
# Unit test for function product
def test_product():
    from ..nested import nested
    for i in nested(range(3), tqdm_class=tqdm_auto, total=8):
        assert i == list(product(*i, tqdm_class=tqdm_auto))

# Generated at 2022-06-12 14:35:55.771132
# Unit test for function product
def test_product():
    from .test_itertools import test_product as test_itertools_product
    test_itertools_product(tqdm_method=product)