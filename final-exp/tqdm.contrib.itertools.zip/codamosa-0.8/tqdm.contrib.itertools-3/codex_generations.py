

# Generated at 2022-06-12 14:27:05.381304
# Unit test for function product
def test_product():
    from .utils import TestBlock
    for i, j in product(range(10), TestBlock()):
        pass
    for i, j in product(range(10), TestBlock(total=None)):
        pass

# Generated at 2022-06-12 14:27:13.183131
# Unit test for function product
def test_product():
    from random import randint
    from itertools import product as i_product
    from numpy.testing import assert_equal

    with tqdm_auto(total=5 * 5 * 5 * 5) as t:
        for x in product(range(5), range(5), range(5), range(5)):
            assert_equal(x, next(i_product(range(5), range(5), range(5),
                                           range(5))))
            t.update()

        t.close()


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:27:14.567094
# Unit test for function product
def test_product():
    from ..tests import test_product
    test_product(product)

# Generated at 2022-06-12 14:27:21.233987
# Unit test for function product
def test_product():
    '''
    Test for function product

    Return
    ------
    True if the test passes else False
    '''

    import itertools
    import numpy as np
    from .utils import format_sizeof

    # Declare variables
    tqdm_class = tqdm_auto
    iterables = [range(5), range(5)]

    # time the function
    tqdm_class.clear()
    iterables = [range(5), range(5)]
    with tqdm_class(total=10) as t:
        for i in product(*iterables):
            t.update()
    time_product = t.average
    print('product took {:.5f}s.\n{}'.format(time_product, t))
    tqdm_class.clear()

    # time itertools


# Generated at 2022-06-12 14:27:25.983233
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range as range, pretest

    def check_product(**kwargs):
        for i in range(7):
            for j in range(5):
                for k in range(11):
                    assert (i, j, k) == next(product(xrange(i), xrange(j),
                                                     xrange(k), **kwargs))

    with_setup(pretest)
    check_product()

    with_setup(pretest)
    check_product(tqdm_class=tqdm_auto)

# Generated at 2022-06-12 14:27:35.939420
# Unit test for function product
def test_product():
    """
    Test the tqdm.itertools.product() wrapper.
    """
    tqdm_kwargs = {'ncols': 200}
    for a, b in product('abcd', range(100), tqdm_class=tqdm_auto,
                        ascii=True, miniters=1, mininterval=0,
                        maxinterval=0, **tqdm_kwargs):
        pass
    for a, b in product('abcd', range(100), tqdm_class=tqdm_auto,
                        ascii=True, miniters=1, mininterval=0,
                        maxinterval=0, **tqdm_kwargs):
        pass

# Generated at 2022-06-12 14:27:41.003448
# Unit test for function product
def test_product():
    import itertools as it
    for X in range(4):
        for Y in range(4):
            for Z in range(4):
                I = [i for i in product(range(X), range(Y), range(Z))]
                J = [j for j in it.product(range(X), range(Y), range(Z))]
                assert I == J
                assert I == [i for i in product(range(X), range(Y), range(Z),
                                                total=X * Y * Z)]

# Generated at 2022-06-12 14:27:43.685265
# Unit test for function product
def test_product():
    a = [1, 2, 3]
    b = [10, 20]
    result = product(a, b)
    assert sum(1 for _ in result) == 6
    result = product(a, b, tqdm_class=None)
    assert sum(1 for _ in result) == 6

# Generated at 2022-06-12 14:27:48.628702
# Unit test for function product
def test_product():
    from .tests import _test_iterable_over_iterable
    _test_iterable_over_iterable(product, [[2, 3]], 6)
    _test_iterable_over_iterable(product, [[2, 3], [4, 5]], 8)


if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-12 14:27:58.394375
# Unit test for function product
def test_product():
    """Test for function product"""
    import tqdm
    assert list(tqdm.tqdm.tqdm(product(['a', 'b'],
                                       repeat=2), total=4)) == \
           list(product(['a', 'b'], repeat=2))
    assert list(tqdm.tqdm.tqdm(product(['a', 'b'],
                                       repeat=2), total=4, ascii=True)) == \
           list(product(['a', 'b'], repeat=2))
    assert list(tqdm.tqdm.tqdm(product(['a', 'b'],
                                       repeat=2), total=4, miniters=2)) == \
           list(product(['a', 'b'], repeat=2))

# Generated at 2022-06-12 14:28:10.134208
# Unit test for function product
def test_product():
    from .main import main_test
    from .tests import eq_, no_duplicates, no_tqdm_set_attr
    with main_test(UnitTest, __file__, exit=False) as test:
        # Test normal usage
        eq_(list(product(range(3), [1, 2])))
        no_duplicates(
            product(range(3), [1, 2], [5, 6, 7]))
        no_duplicates(
            product(range(3), [1], [5, 6, 7]))
        no_duplicates(
            product(range(3), [1, 2], [5, 6]))
        test.display("Test normal usage OK")

        # Test tqdm kwargs

# Generated at 2022-06-12 14:28:17.553969
# Unit test for function product
def test_product():
    import random
    from ..utils import FormatCustomText

    lst1 = list(range(100))
    lst2 = list(range(100, 200))
    random.shuffle(lst1)
    random.shuffle(lst2)

    p = product(lst1, lst2)
    try:
        assert len(list(p)) == sum(range(1, 201))
    except AssertionError:
        raise AssertionError("itertools.product failed")


# Generated at 2022-06-12 14:28:27.383018
# Unit test for function product
def test_product():
    """Test case for function `tqdm.product`."""

    import numpy as np

    # Simulate a list of small and large lists
    N = 100
    M = 1000
    b = range(N)
    B = range(M)
    a = []
    A = []
    p = 0.1
    for i in range(N):
        if np.random.rand() < p:
            a.append(b)
            A.append(B)
        else:
            a.append(b[:i if i else 1])
            A.append(B[:i if i else 1])

    # Test all possible values of `total`

# Generated at 2022-06-12 14:28:33.882991
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import numpy as np
    from time import time
    for n in [10, 20, 50]:
        size = format_sizeof(product(range(n), repeat=n))
        print (u'itertools.product []x{0} ≈ {1:.1f} {} ({2:.2f} s)'.format(
            n, size[0], size[1], time() - t0))
        size = format_sizeof(np.array(list(product(range(n), repeat=n))))
        print (u'np.array([list(itertools.product())]) ≈ {0:.1f} {} ({1:.2f} s)'.format(
            size[0], size[1], time() - t0))

# Generated at 2022-06-12 14:28:38.479464
# Unit test for function product
def test_product():
    """
    Unit tests for function product.
    """
    from ..tqdm import tqdm
    for i in product(range(4), range(4), tqdm_class=tqdm):
        pass
    for i in product(range(4), range(4), total=16, tqdm_class=tqdm):
        pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:28:45.345312
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], repeat=2)) == [
        (1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
    assert list(product([1, 2, 3], [4, 5])) == [
        (1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]

# Generated at 2022-06-12 14:28:50.140120
# Unit test for function product
def test_product():
    with tqdm_auto(total=10**20) as t:
        for _ in product(range(10), range(10), tqdm_class=tqdm_auto):
            t.update()
        assert t.total == 10**2
        assert t.n == 10**2

# Generated at 2022-06-12 14:29:00.026653
# Unit test for function product
def test_product():
    import pytest
    from pytest import approx
    iterable = range(10), range(2), range(1, 5)
    tlist = [item for item in product(*iterable)]
    assert len(tlist) == approx(400)
    iterable = [list(range(10)), list(range(2)), list(range(1, 5))]
    iterable = [iter(it) for it in iterable]
    tlist = [item for item in product(*iterable)]
    assert len(tlist) == approx(400)
    tlist = [item for item in product(*iterable)]
    assert len(tlist) == approx(400)
    with pytest.raises(TypeError):
        iterable = [None] * 3
        iterable = [iter(it) for it in iterable]
        tlist

# Generated at 2022-06-12 14:29:06.519409
# Unit test for function product
def test_product():
    from .tests import TestCase, FakeTqdm
    from ..pandas import PandasDict
    expected = [
        tuple(i for i in range(j))
        for j in range(1, 7)
    ]
    for i in product(range(1), range(2), range(3), range(4),
                     range(5), range(6)):
        assert i == expected.pop(0)
    assert expected == []

    expected = [
        tuple(i for i in range(j))
        for j in range(1, 7)
    ]
    for i in product(range(1), range(2), range(3), range(4),
                     range(5), range(6), tqdm_class=tqdm_auto):
        assert i == expected.pop(0)
    assert expected == []

# Generated at 2022-06-12 14:29:15.403751
# Unit test for function product
def test_product():
    from sys import version_info
    for i, c in enumerate(product(range(1), repeat=10)):
        assert c == (0,) * 10
        if i == 10:
            break
    assert i == 10
    with tqdm_auto(unit="", file=None if version_info < (3,) else "devnull") as t:
        for i, c in enumerate(product(t, repeat=2)):
            assert ((c[0].n, c[0].total) ==
                    (c[1].n, c[1].total) ==
                    (i, i + 1))
            if i == 10:
                break
    assert i == 10

# Generated at 2022-06-12 14:29:29.150611
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy.testing import assert_array_equal
    n = 100000
    for tqdm in [tqdm_auto, lambda x: x]:
        for a in [range, lambda n: randint(0, 10, size=n)]:
            for b in [range, lambda n: randint(0, 10, size=n)]:
                assert_array_equal(
                    list(zip(a(n), b(n))),
                    list(tqdm.product(a(n), b(n))))

# Generated at 2022-06-12 14:29:37.204489
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product` behavior.
    """
    from ..std import StringIO
    from ..contrib.concurrent import process_map
    from ..utils import format_sizeof

    old_stdout, old_stderr = sys.stderr, sys.stdout
    sys.stdout = StringIO()  # capture output
    sys.stderr = StringIO()  # capture output

    lst = list(product(range(4), repeat=3, tqdm_class=tqdm_auto))  # check list(product()) works
    assert lst == list(itertools.product(range(4), repeat=3))
    print(format_sizeof(lst), file=sys.stderr)


# Generated at 2022-06-12 14:29:45.012958
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import TestTqdm
    from .utils import IS_PYPY

    with TestTqdm(
            leave=False, smoothing=0, mininterval=0, miniters=1
        ) as t:
        assert np.allclose(
            sum(float(x) for x in t.__iter__(
                product(
                    np.random.rand(3, 3),
                    np.random.rand(3, 3),
                    tqdm_class=TestTqdm
                ))),
            19.06117923265737)


# Generated at 2022-06-12 14:29:54.040845
# Unit test for function product
def test_product():
    from .utils import closing, format_sizeof
    from .utils import FakeTqdmFile

    for total_size in [0, 1, 12, 4096]:
        with closing(FakeTqdmFile(
                total_size=total_size, default_ncols=40)) as f:
            for i in product(range(10), range(100),
                             tqdm_class=tqdm_auto, file=f):
                pass
            f.seek(0)
            stdout = f.read()

        assert ("itertools.product" in stdout)
        assert ("10  100" in stdout)
        assert ("/{0:.1f} MB"
                "".format(format_sizeof(10 * 100)) in stdout)
        assert (str(10 * 100) in stdout)
       

# Generated at 2022-06-12 14:30:02.642193
# Unit test for function product
def test_product():
    from .utils import FormatWrapBase
    from .tqdm_gui import tqdm

    for tqdm_cls in (tqdm,
                     FormatWrapBase):
        for a in product([1, 2, 3], tqdm_class=tqdm_cls):
            assert a == (1, 1), a
        for a in product([1, 2, 3], [4, 5, 6], tqdm_class=tqdm_cls):
            assert a == (1, 4), a
        for a in product([1, 2, 3], [4, 5, 6], [7], tqdm_class=tqdm_cls):
            assert a == (1, 4, 7), a

# Generated at 2022-06-12 14:30:11.386348
# Unit test for function product
def test_product():
    from pytest import raises

    with raises(TypeError):
        list(product())

    A = [1, 2, 3]
    B = ['a', 'b', 'c']
    C = [999, 888, 777]
    for z in product(A, B, C):
        assert z[0] in A and z[1] in B and z[2] in C
    for z in product(A, B, C, tqdm_class=lambda x: x):
        assert z[0] in A and z[1] in B and z[2] in C

    import tqdm as tqdm_base

# Generated at 2022-06-12 14:30:14.272377
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    with tqdm_auto(total=5*5*5) as t:
        assert len(list(product(
            range(5),
            range(5),
            range(5),
            tqdm_class=tqdm_auto
            ))) == 5*5*5
        t.close()

# Generated at 2022-06-12 14:30:20.647639
# Unit test for function product
def test_product():
    """
    Test to optimise function product
    """
    prod = product([(3, 6), (2, 5), (7, 8)], total=24, leave=False)
    assert list(prod) == [(3, 2, 7),
                          (3, 2, 8),
                          (3, 5, 7),
                          (3, 5, 8),
                          (6, 2, 7),
                          (6, 2, 8),
                          (6, 5, 7),
                          (6, 5, 8)]

test_product()

# Generated at 2022-06-12 14:30:25.961912
# Unit test for function product
def test_product():
    from ..std import islice
    from .utils import RawPipe
    for i in islice(product(prod_list, prod_list, prod_list), 11):
        pass
    for i in islice(product(prod_list, prod_list, prod_list,
                            unit='prod',
                            tqdm_class=RawPipe), 11):
        pass

prod_list = [1, 2, 3, 4]

# Generated at 2022-06-12 14:30:28.590896
# Unit test for function product
def test_product():
    from tqdm import trange
    from tqdm import tqdm_gui
    for cls in (trange, tqdm_gui):
        for x in product(['a', 'b', 'c'], repeat=2, tqdm_class=cls):
            assert x


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:30:40.088848
# Unit test for function product
def test_product():
    from ._utils import _test_iterable
    _test_iterable(product((range(3), range(3)), (range(3), range(3))))

# Generated at 2022-06-12 14:30:46.723250
# Unit test for function product
def test_product():
    """Test product"""
    from .utils import closing, b

    with closing(StringIO()) as our_file:
        for _ in product('ABCD', tqdm=(None, our_file)):
            pass
        assert b("A B C D E F G H I J K L M N O P") in our_file.getvalue()

    with closing(StringIO()) as our_file:
        for _ in product('ABCD', tqdm=tqdm_gui, file=our_file):
            pass
        assert b("A B C D E F G H I J K L M N O P") in our_file.getvalue()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:30:56.180075
# Unit test for function product
def test_product():
    from ..tqdm import main
    import os
    try:
        with main.tqdm(desc='foo', ascii=True, miniters=1, mininterval=20,
                       leave=True) as t:
            for _ in product(range(5), range(5), tqdm_class=main.tqdm):
                pass
                t.update()
    except TypeError:
        pass
    else:
        raise Exception("Should not have been able to use tqdm as iterator")

# Generated at 2022-06-12 14:31:03.190516
# Unit test for function product
def test_product():
    """ Unit test for `product` function """
    from ..utils import format_sizeof

    try:  # Python 2
        from itertools import izip as zip
    except ImportError:  # Python 3
        pass

    try:  # Python 2
        iteritems = lambda d: d.iteritems()
    except AttributeError:  # Python 3
        iteritems = lambda d: iter(d.items())

    def test_product_gen(iterables, t=None):
        for obj in product(*iterables):
            if t is not None:
                t.update()
            yield obj

    def test_product_size(iterables, **kwargs):
        with tqdm_auto(**kwargs) as t:
            prodx = test_product_gen(iterables, t=t)

# Generated at 2022-06-12 14:31:10.052138
# Unit test for function product
def test_product():
    from .utils import _test_iterable
    assert _test_iterable(iterable=product(range(100), range(100))) == 99 ** 2
    assert _test_iterable(iterable=product(range(100), range(100),
                                           range(100))) == 99 ** 3
    assert _test_iterable(iterable=product(range(100))) == 99
    assert _test_iterable(iterable=product(range(100), ascii_letters)) == 99 * 52

# Generated at 2022-06-12 14:31:17.802386
# Unit test for function product
def test_product():
    """Test product func."""
    from ..utils import format_sizeof
    assert list(product(range(10), repeat=10)) == [tuple(range(10))]
    assert list(product(range(3), repeat=2)) == [(0, 0), (1, 0), (2, 0),
                                                 (0, 1), (1, 1), (2, 1),
                                                 (0, 2), (1, 2), (2, 2)]

# Generated at 2022-06-12 14:31:24.732609
# Unit test for function product
def test_product():
    from ._version import __version__

    # Unit test
    import sys
    import platform
    import pytest
    from collections import Counter
    from sys import version_info as py_version_info

    (major1, minor1, micro1, releaselevel1, serial1) = py_version_info
    py_version = "%s.%s.%s-%s%s" % (
        major1, minor1, micro1, releaselevel1, serial1)
    tqdm_version = __version__

    try:  # Python 3 (see #215)
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO

    class FakeTTY(object):
        def __init__(self, name):
            self.name = name
            self.buffer = []


# Generated at 2022-06-12 14:31:27.646118
# Unit test for function product
def test_product():
    # Unit test for function product
    a = list(product(
        range(10), range(10), range(10), tqdm_class=tqdm_auto))
    b = list(itertools.product(
        range(10), range(10), range(10)))
    assert a == b

# Generated at 2022-06-12 14:31:33.970378
# Unit test for function product
def test_product():
    """
    Basic test function
    """
    from ..tests.common import with_setup_args

    @with_setup_args(None)
    def test(r):
        r = []
        for i in product(range(4), range(4), tqdm_class=None, leave=False):
            r.append(i)
        assert len(r) == 16
        assert r[0] == (0, 0)
        assert r[-1] == (3, 3)

# Generated at 2022-06-12 14:31:42.513284
# Unit test for function product
def test_product():
    """
    Unit test for `product`.
    """
    import sys
    import io
    import itertools

    with io.StringIO() as our_file, \
            io.StringIO() as their_file, \
            redirect_stdout(our_file):

        for _ in tqdm_auto(product(range(2), repeat=3)):
            pass
        our_stdout = our_file.getvalue()

    with redirect_stdout(their_file):
        for _ in itertools.product(range(2), repeat=3):
            pass
        their_stdout = their_file.getvalue()

    assert our_stdout == their_stdout


if hasattr(itertools, 'product'):
    # If itertools is not imported, do not override it!
    tqdm

# Generated at 2022-06-12 14:32:06.231926
# Unit test for function product
def test_product():
    """
    Test if the product function works.
    """
    import numpy as np
    from ..utils import reverse_enumerate

    shuffle_test_data = np.random.randint(0, 255, size=(1000, 100), dtype=np.uint8)

    for i in range(shuffle_test_data.shape[0]):
        np.random.shuffle(shuffle_test_data[i])
        for j in reverse_enumerate(shuffle_test_data[i]):
            if j:
                for k in product(range(j)):
                    assert k == tuple(range(j))
                assert k == (j - 1,) * j

# Generated at 2022-06-12 14:32:12.848053
# Unit test for function product
def test_product():
    """Test the correctness of `product`."""
    from ..tests.py26compat import unittest

    class TestProduct(unittest.TestCase):
        def test_product(self):
            """Test the correctness of `product`."""
            try:
                import numpy as np
                from numpy.testing import assert_array_equal
            except ImportError:
                return  # skip
            from collections import OrderedDict
            a = OrderedDict([("a", [1, 2, 3]), ("b", [-1, -2, -3])])
            for method in (lambda: list(product(*a.values())),
                           lambda: np.array(list(product(*a.values()))))[:1]:
                res1 = method()
                res2 = list(map(tuple, method()))
               

# Generated at 2022-06-12 14:32:15.796834
# Unit test for function product
def test_product():
    for _ in product([[], [1, 2, 3], ["a", "b", "c"]], [1, 2], ["a", "b"], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:32:22.261682
# Unit test for function product
def test_product():
    from ..auto import trange
    for n in range(3):
        # loop over all possible iterables
        for iterables in [
                [1, 2, 3],
                [1, 2, 3, 4, 5, 6],
                [1, 2, 3, 4, 5, 6, 7, 8, 9],
        ]:
            assert list(product(
                *[iterables] * n, tqdm_class=trange)) == list(itertools.product(
                    *[iterables] * n))
            assert list(product(
                *[iter(iterables)] * n, tqdm_class=trange)) == list(itertools.product(
                    *[iterables] * n))

# Generated at 2022-06-12 14:32:27.494740
# Unit test for function product
def test_product():
    # Smoke test
    i = product([1, 2], [3, 4], tqdm_class=tqdm_auto)
    assert next(i) == (1, 3)
    assert next(i) == (1, 4)
    assert next(i) == (2, 3)
    assert next(i) == (2, 4)
    # Test total
    i = product([1, 2], [3, 4], tqdm_class=tqdm_auto)
    assert i.total == 4

# Generated at 2022-06-12 14:32:35.036130
# Unit test for function product
def test_product():
    """Test for parallel implementation of ``itertools.product``"""
    from ..utils import FormatCustomTextExtension
    import numpy.random as random

    class PytestTqdm(tqdm_auto):
        def format_meter(self, n, total, elapsed):
            self.custom_text = "custom text"
            return FormatCustomTextExtension.format_meter(
                self, n, total, elapsed)


# Generated at 2022-06-12 14:32:44.024713
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # Default
    p = product("ABCD", "xy")
    assert [x for x in p] == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                              ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

    # Total
    p = product("ABCD", "xy")
    assert [x for x in p] == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                              ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

    # Total None
    p = product("ABCD", [1, 2, 3, 4])

# Generated at 2022-06-12 14:32:48.146812
# Unit test for function product
def test_product():
    @test_product.register(tqdm_auto)
    def _(tqdm):
        for _ in tqdm(product(range(10), range(20))):
            pass
        for _ in tqdm(product(range(10), range(20)), total=10 * 20):
            pass
    test_product()

# Generated at 2022-06-12 14:32:53.064708
# Unit test for function product
def test_product():
    from ..tests.test_tqdm import with_setup, _range
    from numpy.testing import assert_equal

    @with_setup(pretest=True, posttest=True)
    def inner_test_product():
        try:
            import numpy as np
        except ImportError:
            raise SkipTest
        assert_equal(list(product([1, 2, 3, 4], [5, 6, 7])),
                     np.array([(1, 5), (1, 6), (1, 7),
                               (2, 5), (2, 6), (2, 7),
                               (3, 5), (3, 6), (3, 7),
                               (4, 5), (4, 6), (4, 7)]))
    inner_test_product()


# Generated at 2022-06-12 14:33:01.847427
# Unit test for function product
def test_product():
    r = product(range(3), range(3), range(3), tqdm_class=tqdm_auto)

# Generated at 2022-06-12 14:33:43.638045
# Unit test for function product
def test_product():
    """Runs `itertools.product` on a tuple of numbers, 0-9."""
    assert product(range(10), range(10), range(10), tqdm_class=tqdm_auto)



# Generated at 2022-06-12 14:33:48.404126
# Unit test for function product
def test_product():
    _input = [range(5), range(5), range(5), range(5)]
    total = 1
    for v in _input:
        total *= len(v)
    retval = list(product(*_input))
    assert total == len(retval)
    retval = list(product(*_input, tqdm_class=tqdm_auto))
    assert total == len(retval)

# Generated at 2022-06-12 14:33:51.058681
# Unit test for function product
def test_product():
    """Test for tqdm.itertools.product"""
    from .gui import tqdm
    for i in tqdm.product(range(3), range(3), range(3)):
        pass

# Generated at 2022-06-12 14:33:58.071795
# Unit test for function product
def test_product():
    """Test function ``product()``."""
    from ..utils import BATCH_SIZE, FormatCustomText, FormatCustomPercentage

    try:
        import numpy as np
    except ImportError:
        np = None

    with tqdm_auto(total=24 * 2 * 2 * 2 * 2, initial=0) as t:
        for _ in product([0, 1],
                         [2, 3],
                         [4, 5],
                         [6, 7, 8],
                         [9, 10],
                         [11, 12],
                         [13, 14, 15],
                         [16, 17],
                         [18, 19],
                         [20, 21],
                         [22, 23],
                         [24, 25],
                         [26, 27, 28],
                         tqdm=t):
            pass

# Generated at 2022-06-12 14:34:02.654582
# Unit test for function product
def test_product():
    assert list(product(range(2), repeat=2)) == list(itertools.product(range(2), repeat=2))
    assert list(product(range(2), repeat=2, tqdm_class=None)) == list(itertools.product(range(2), repeat=2))
    assert list(product(range(2), repeat=2, tqdm_class=tqdm_auto)) == list(itertools.product(range(2), repeat=2))
    assert list(product(range(2), repeat=2, tqdm_class=tqdm_auto, postfix="done")) == list(itertools.product(range(2), repeat=2))

# Generated at 2022-06-12 14:34:08.019976
# Unit test for function product
def test_product():
    """Test to ensure that the product function works"""
    value = 0
    for i in product(range(10), range(100), range(1000), tqdm_class=None):
        value += 1
    assert value == 10 * 100 * 1000

# Generated at 2022-06-12 14:34:17.548228
# Unit test for function product
def test_product():
    """Test for product"""
    from numpy.testing import assert_equal, assert_array_equal

    from itertools import product
    from numpy import arange
    from numpy.random import random, randint
    from tqdm import tqdm
    from .utils import FormatCustom, DataIO, discretize

    def _test_product(iterables, **kwargs):
        for i, o in zip(product(*iterables, **kwargs),
                        tqdm.tqdm_product(*iterables, **kwargs)):
            assert_array_equal(i, o)

    _test_product((list(range(10)) for _ in range(10)))
    _test_product((list(range(10)) for _ in range(10)), tqdm_class=tqdm)

# Generated at 2022-06-12 14:34:19.314276
# Unit test for function product
def test_product():
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]

# Generated at 2022-06-12 14:34:27.135276
# Unit test for function product
def test_product():
    from tqdm import tqdm_gui as tqdm

    it = product([1, 2, 3], [4, 5, 6], tqdm_class=tqdm)
    assert list(it) == [
        (1, 4), (1, 5), (1, 6),
        (2, 4), (2, 5), (2, 6),
        (3, 4), (3, 5), (3, 6),
    ]

    it = product([1, 2, 3], [4, 5, 6], [7, 8], tqdm_class=tqdm)

# Generated at 2022-06-12 14:34:30.370245
# Unit test for function product
def test_product():
    """Test function `product`"""
    import random
    from .monitor import tqdm

    iterables = [range(random.randint(10, 100)) for _ in range(random.randint(3, 5))]
    for i in product(*iterables,
                     total=0,
                     desc="Testing",
                     leave=False,
                     tqdm_class=tqdm):
        pass

# Generated at 2022-06-12 14:35:21.899038
# Unit test for function product
def test_product():
    # just tests that it runs without erroring
    from ..utils import format_sizeof
    from ..utils import format_interval
    import sys
    import time
    import numpy as np

    N = 10**17.5
    x = np.arange(N).reshape((-1, 3))

    t = time.time()
    l = list(product(x, x, x, x, x, x,
                     tqdm_class=tqdm_auto,
                     ascii=True,
                     disable=False,
                     mininterval=0.5,
                     miniters=1,
                     postfix=['a', {'b': 1}]))
    t1 = time.time()

    y = np.array(l)
    s = y.shape
    t2 = time.time()


# Generated at 2022-06-12 14:35:23.158033
# Unit test for function product
def test_product():
    """Unit test for function product"""
    list(product('ABCD', 'xy'))

# Generated at 2022-06-12 14:35:31.036460
# Unit test for function product
def test_product():
    if tqdm_auto.tqdm_gui(ascii=True).gui or \
            tqdm_auto.tqdm_gui().gui:
        # since `tqdm` is meant to work inside tqdm,
        # only test its full GUI mode
        import warnings
        warnings.filterwarnings(
            'ignore', r"TqdmDeprecationWarning.*r'TqdmExperimentalWarning'")
        import tqdm.testing
        tqdm.testing.main(verbose=False)
    else:
        import unittest
        with unittest.mock.patch('sys.stdout'):
            import tqdm.tests
            suite = tqdm.tests.TqdmTestSuite()
            unittest.TextTestRunner().run(suite)

# Generated at 2022-06-12 14:35:36.231070
# Unit test for function product
def test_product():
    from collections import Counter
    with tqdm_auto(total=None) as t:
        counter = Counter(product(range(10), range(10)))
        assert len(counter) == 100
        assert counter[(9, 9)] == 1
        assert counter[(0, 0)] == 1
        assert counter[(0, 1)] == 1
        assert counter[(1, 0)] == 1
        assert set(counter.elements()) == set(range(10))

# Generated at 2022-06-12 14:35:40.679783
# Unit test for function product
def test_product():
    from .examples import product_example  # NOQA
    from .fixture_data import data_tqdm, data_tqdm_write
    for d in data_tqdm.values():
        with d.get_io():
            for atoms in product('ABC', repeat=2):
                pass

    for d in data_tqdm_write.values():
        with d.get_io():
            for atoms in product('ABC', repeat=2):
                pass

# Generated at 2022-06-12 14:35:42.954698
# Unit test for function product
def test_product():
    """Test for itertools.product"""
    input_ = "abcde", "1234"
    output = itertools.product(*input_)
    output_ = list(product(*input_, tqdm_class=None))
    assert list(output) == output_



# Generated at 2022-06-12 14:35:47.948332
# Unit test for function product
def test_product():
    # list products
    list(product(["a", "b"], "c"))
    list(product(["a", "b"], ["c", "d"]))
    list(product(["a", "b"], ["c", "d"], ["e", "f"]))
    # infinite case
    assert list(product("ab", repeat=3)) == ["aaa", "aab",
                                             "aba", "abb",
                                             "baa", "bab",
                                             "bba", "bbb"]

# Generated at 2022-06-12 14:35:54.386520
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    # Test that it works the same as `itertools.product`
    for i in list(product([1, 2], [3, 4])):
        assert i in [(1, 3), (1, 4), (2, 3), (2, 4)]
    # Test that it works when itertools.product raises an exception
    try:
        iter([1]) * iter([2])
    except TypeError:
        for i in list(product([1], [2])):
            assert i in [(1, 2)]
    # Test that it works when itertools.product does not rais

# Generated at 2022-06-12 14:36:01.598366
# Unit test for function product
def test_product():
    r = [i for i in product([1, 2, 3], ['a', 'b'])]
    assert r == [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]
    r = [i for i in product([1, 2, 3], ['a', 'b'], tqdm_class=None)]
    assert r == [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]

# Generated at 2022-06-12 14:36:05.223188
# Unit test for function product
def test_product():
    """Test `product`."""
    with tqdm_auto(total=27) as t:
        assert list(t.update(i) or i for i in product(range(3), range(3),
                                                       range(3))) \
            == list(itertools.product(range(3), range(3), range(3)))