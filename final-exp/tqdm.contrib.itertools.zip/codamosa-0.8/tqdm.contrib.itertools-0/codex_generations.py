

# Generated at 2022-06-12 14:27:06.692092
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from pytest import raises, approx
    from random import randrange
    gen = product(range(1, 5), range(6, 10))
    assert next(gen) == (1, 6)
    assert next(gen) == (1, 7)
    assert list(product(range(20), range(20), range(20))) == [
        (i, j, k) for i in range(20) for j in range(20) for k in range(20)]

    # test iterator protocol

# Generated at 2022-06-12 14:27:16.545608
# Unit test for function product
def test_product():
    """ Test function product to make sure it works """
    from itertools import product

    assert tuple(product([1, 2, 3], [4, 5])) == tuple(product([1, 2, 3], [4, 5]))
    assert tuple(product([1, 2, 3], [4, 5])) == (
        (1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5))
    assert tuple(product([1, 2, 3], repeat=2)) == (
        (1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3))

# Generated at 2022-06-12 14:27:20.911487
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    a = list(product([1, 2, 3], [4, 5, 6]))
    assert_equal(a, [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6),
                     (3, 4), (3, 5), (3, 6)])

# Generated at 2022-06-12 14:27:27.317448
# Unit test for function product
def test_product():
    """
    Test function: tqdm.wrappers.product(*iterables).
    """
    from numpy.linalg import norm
    all_sums = []  # sums of the outputs
    for k in range(10):
        # 10 rounds of testing with random inputs
        rands = [_ for _ in range(k)]  # random.randint(1, 10, k)
        for i in rands:
            if i:
                d = [i for _ in range(i)]
            else:
                d = [i]
            all_sums.append(sum(d))
        # check that the sum is correct
        assert sum(
            list(product(*(range(_) for _ in rands),
                          tqdm_class=tqdm_auto))) == sum(all_sums)
        #

# Generated at 2022-06-12 14:27:36.935511
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from nose.tools import assert_equal
    from ..utils import __TESTMODE__
    __TESTMODE__ = True
    try:
        from ..utils import FormatCustomText
    finally:
        __TESTMODE__ = False
    import sys
    from io import StringIO
    out = StringIO()
    sys.stdout = out
    for _ in product(range(10), range(5), tqdm_class=FormatCustomText,
                     desc="Test"):
        pass
    sys.stdout = sys.__stdout__
    assert_equal(out.getvalue(),
                 "Test: 100%|##########| 50/50 [00:00<?, ?it/s]\n")
    out = StringIO()
    sys.stdout = out

# Generated at 2022-06-12 14:27:43.288809
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import numpy as np

    test_range = np.arange(10000)
    for n_tests in (1, 2, 3, 4, 5):
        # Setup test
        n_perms = 0
        for i in range(n_tests):
            n_perms += np.math.factorial(len(test_range)) ** n_tests
        test_range_permutations = itertools.product(test_range,
                                                    repeat=n_tests)
        test_range_permutations_tqdm = tqdm_auto(test_range_permutations,
                                                 total=n_perms,
                                                 ascii=True)

        # Test tqdm_auto.product works as expected
        results_tqdm = []

# Generated at 2022-06-12 14:27:53.749064
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import random
    from tqdm._utils import _term_move_up
    for total in [None, 10, 1000]:
        for j in range(3):
            iterables = []
            for i in range(j + 1):
                iterables.append(range(random.randint(1, 3 * (i + 1))))
            results = list(product(*iterables, total=total,
                                   smoothing=0))
            assert not tqdm_auto.monitor_interval
            assert tqdm_auto.unit == 'it'
            if total is None:
                assert tqdm_auto.total == len(results)
            else:
                assert tqdm_auto.total == total

# Generated at 2022-06-12 14:28:02.032355
# Unit test for function product
def test_product():
    # Test no argument
    gen = product(tqdm_class=None)

    assert next(gen) == ()

    # Test 1 argument
    gen = product([1, 2, 3], tqdm_class=None)

    assert next(gen) == (1,)
    assert next(gen) == (2,)
    assert next(gen) == (3,)
    try:
        next(gen)
        assert False
    except StopIteration:
        pass

    # Test 2 arguments
    gen = product([1, 2, 3], [4, 5], tqdm_class=None)

    assert next(gen) == (1, 4)
    assert next(gen) == (1, 5)
    assert next(gen) == (2, 4)
    assert next(gen) == (2, 5)

# Generated at 2022-06-12 14:28:05.819633
# Unit test for function product
def test_product():
    """Unit test for function `tqdm.itertools.product`."""
    from .tests_tqdm import pretest_posttest_demo
    with pretest_posttest_demo():
        for i, j in product("ABC", "12"):
            print(' ', end='')

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:28:10.819243
# Unit test for function product
def test_product():
    data = [
        list(map(int, range(1, 21))), list(map(int, range(1, 4))),
        list(map(int, range(1, 11))), list(range(1, 3))]

    total = 1
    for i in map(len, data):
        total *= i

    for i, j in zip(product(*data), itertools.product(*data)):
        assert i == j

# Generated at 2022-06-12 14:28:19.190828
# Unit test for function product
def test_product():
    """
    Unit test for function `itertools_chain`.
    """
    import numpy
    a = range(2)
    b = range(2)
    res = numpy.array(list(product(a, b)))
    cmp = numpy.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    numpy.testing.assert_array_equal(res, cmp)
    try:
        from IPython.display import clear_output
    except ImportError:
        pass
    else:
        clear_output()
        print("\x1b[1m\x1b[32mAll tests passed\x1b[0m")

# Generated at 2022-06-12 14:28:26.602911
# Unit test for function product
def test_product():
    from collections import namedtuple
    Point = namedtuple("Point", ["x", "y"])
    p = Product(tqdm=tqdm, iterables=[(Point(x, y) for x in range(5)), ("a", "b")])
    assert [i for i in p] == [(0, 'a'), (0, 'b'), (1, 'a'), (1, 'b'),
                              (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b'),
                              (4, 'a'), (4, 'b')]

# Generated at 2022-06-12 14:28:27.828274
# Unit test for function product
def test_product():
    """Test for product."""
    from .tests import test_product as f_tests
    f_tests()

# Generated at 2022-06-12 14:28:34.245284
# Unit test for function product
def test_product():
    from .gzip_ import gzip
    q = product(range(5), range(5), range(5), range(5),
                range(5), range(5), range(5), range(5),
                range(5), range(5), range(5), range(5),
                range(5), range(5), range(5), range(5),
                tqdm_class=tqdm_auto)
    w = gzip(itertools.product(range(5), range(5), range(5), range(5),
                               range(5), range(5), range(5), range(5),
                               range(5), range(5), range(5), range(5),
                               range(5), range(5), range(5), range(5)))
    for _ in q:
        pass

# Generated at 2022-06-12 14:28:37.044267
# Unit test for function product
def test_product():
    """Unit test for product"""
    assert product(range(2), range(2))
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))

# Generated at 2022-06-12 14:28:44.321147
# Unit test for function product
def test_product():
    try:
        from importlib import reload  # Python 3.4+
    except ImportError:
        try:
            from imp import reload
        except ImportError:
            pass
    reload(tqdm_auto)
    tqdm_auto.tqdm = _test_tqdm
    # Test basic
    assert [i for i in product(range(10))] == list(itertools.product(range(10)))
    # Test multi-args
    assert ([i for i in product(range(1, 5), range(3), ['a', 'b'])] ==
            list(itertools.product(range(1, 5), range(3), ['a', 'b'])))
    # Test kwargs

# Generated at 2022-06-12 14:28:49.484256
# Unit test for function product
def test_product():
    """Test for function product"""
    list(itertools.islice(product(range(10), repeat=2), 5)) == list(product(range(10), repeat=2))[:5]
    from random import shuffle
    r = range(100)
    for _ in range(100):
        shuffle(r)
        list(itertools.islice(product(r, repeat=2), 5)) == list(product(r, repeat=2))[:5]
    for _ in range(100):
        shuffle(r)
        list(itertools.islice(product(r, r), 5)) == list(product(r, r))[:5]

# Generated at 2022-06-12 14:28:59.618250
# Unit test for function product
def test_product():
    # Test 1
    assert (['a', '++', '0'], ['a', '++', '1'], ['a', '++', '2'],
            ['a', '++', '3'], ['b', '++', '0'], ['b', '++', '1'],
            ['b', '++', '2'], ['b', '++', '3']) == tuple(product(
                ('a', 'b'), ('+-', '-+'), '0123', tqdm_class=None))
    # Test 2

# Generated at 2022-06-12 14:29:03.961373
# Unit test for function product
def test_product():
    """Test function `product`."""
    import numpy as np
    product_test = True
    lst = [range(100), range(100), range(100), range(100), range(100),
           range(100)]
    for e, _ in zip(product(*lst), itertools.product(*lst)):
        if e != _:
            product_test = False
    return product_test


if __name__ == '__main__':
    print(test_product())

# Generated at 2022-06-12 14:29:12.282877
# Unit test for function product
def test_product():
    """Test function product with fast iterables"""
    import numpy as np
    from ..utils import Unique
    with Unique() as u:
        assert np.all(list(product(list(u))) == list(itertools.product(list(u))))
        assert np.all(list(product(list(u), range(u.total))) ==
                      list(itertools.product(list(u), range(u.total))))

    # Test fast iterables
    for i in range(-1, 3):
        for j in range(-1, 2):
            try:
                assert np.all(list(product(range(i), range(j))) ==
                              list(itertools.product(range(i), range(j))))
            except (ValueError, TypeError):
                continue  # No test for slow iterables



# Generated at 2022-06-12 14:29:20.725518
# Unit test for function product
def test_product():
    from ..version import __version__
    import sys
    import re
    import random
    import itertools

    if sys.version_info.major == 2:
        range = xrange

    def test(iterables, total):
        assert "product" not in list(locals().keys())
        with tqdm(**tqdm_args(len(iterables) == 1)) as pbar:
            for i in itertools.product(*iterables):
                if total is not None:
                    pbar.update()
                assert "product" not in list(locals().keys())
        assert "product" not in list(locals().keys())

    test([range(30)], 30 ** 1)
    test([range(20), range(20, 30)], 20 * 10)

# Generated at 2022-06-12 14:29:29.544568
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_equal
    assert_equal(list(product([1, 2, 3], [4, 5], [6, 7])),
                 list(itertools.product([1, 2, 3], [4, 5], [6, 7])))
    assert_equal(list(product([11, 21, 31], [41, 51])),
                 list(itertools.product([11, 21, 31], [41, 51])))
    assert_equal(list(product([11, 21, 31])), list(itertools.product([11, 21, 31])))
    assert_equal(list(product([])), list(itertools.product([])))

# Generated at 2022-06-12 14:29:33.236125
# Unit test for function product
def test_product():
    from ..std import inspect
    iterables = [['ABC', 'DEF'], ['123', '456']]
    res = inspect.getgeneratorstate(product(*iterables, tqdm_class=tqdm_auto))
    assert (res == inspect.GEN_CREATED)

# Generated at 2022-06-12 14:29:37.588987
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..utils import format_sizeof
    from ..tests import TestCase, closing
    from .utils import format_timesofar

    class TestProduct(TestCase):
        def setUp(self):
            import numpy as np
            from random import randint
            self.n1 = randint(2, 10)
            self.n2 = randint(2, 10)
            self.n3 = randint(2, 10)
            self.a = list(range(self.n1))
            np.random.seed(42)
            self.b = np.random.randint(1, 1000, (self.n2, self.n3))

        def test_product_module(self):
            from itertools import product as itertools_product

# Generated at 2022-06-12 14:29:45.350147
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ._tqdm import trange
    from ._utils import FormatCustomText

    it = product(
        trange(5),
        trange(5),
        tqdm_class=FormatCustomText,
        miniters=1,
        mininterval=0,
        disable=False,
    )
    assert next(it) == (0, 0)
    assert next(it) == (0, 1)
    assert next(it) == (0, 2)
    assert next(it) == (0, 3)
    assert next(it) == (0, 4)
    assert next(it) == (1, 0)
    assert next(it) == (1, 1)
    assert next(it) == (1, 2)
    assert next(it)

# Generated at 2022-06-12 14:29:48.186800
# Unit test for function product
def test_product():
    from ..tqdm import tqdm
    for i in tqdm.tqdm_pandas(tqdm.tqdm(range(500000))):
        pass

# Generated at 2022-06-12 14:29:50.971510
# Unit test for function product
def test_product():
    for a in product([1, 2], ['a', 'b', 'c'], range(3), tqdm_class=tqdm_auto):
        pass


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:29:57.616302
# Unit test for function product
def test_product():
    """Test function `product`."""
    import sys

    with open("test_product", 'w') as f:
        for i in product('ABC', 'xy', tqdm_class=tqdm_auto, file=f):
            sys.stdout.write('.')
            sys.stdout.flush()
    with open("test_product", 'r') as f:
        lines = f.readlines()
        assert len(lines) == 13
        for line in lines:
            assert all(i in line for i in ['Axy', '   ', '100%'])
    import os
    os.remove("test_product")

# Generated at 2022-06-12 14:30:03.623487
# Unit test for function product
def test_product():
    """
    Simple check that product behaves the same as builtin product.
    """
    iter1 = [1, 2]
    iter2 = ['a', 'b']
    iter3 = [1, 2, 3]
    assert list(itertools.product(iter1, iter2, iter3)) == \
        list(product(iter1, iter2, iter3))
    #assert list(itertools.product(iter1, iter2, iter3)) == \
    #    list(tqdm(iter1, iter2, iter3))

# Generated at 2022-06-12 14:30:12.262323
# Unit test for function product
def test_product():
    from .utils import FormatMixin

    class TestProduct(FormatMixin):
        @classmethod
        def setup_class(cls):
            super(TestProduct, cls).setup_class()
            cls.iterable = product('ABCD', 'xy', tqdm_class=tqdm_auto)
            cls.expected_values = [('A', 'x'), ('A', 'y'),
                                   ('B', 'x'), ('B', 'y'),
                                   ('C', 'x'), ('C', 'y'),
                                   ('D', 'x'), ('D', 'y')]
            cls.iteration = 0

        def test_iterable(self):
            assert next(self.iterable) == self.expected_values[self.iteration]
            self.iteration += 1


# Generated at 2022-06-12 14:30:22.684062
# Unit test for function product
def test_product():
    # Dummy product function
    def prod(x, y):
        return x * y
    a = list(range(10))
    b = list(range(10))
    assert list(product(a, b, tqdm_class=lambda x: x)) == list(itertools.product(a, b))
    assert list(product(a, b, tqdm_class=tqdm_auto)) == list(itertools.product(a, b))
    assert sum(product(a, b, tqdm_class=lambda x: x, desc="Test product",
                       leave=True)) == sum(itertools.product(a, b))

# Generated at 2022-06-12 14:30:28.943977
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..std import next
    # Demonstrate that `product` can be used as `itertools.product`
    assert (next(product([1, 2, 3], [4, 5, 6])) ==
            next(itertools.product([1, 2, 3], [4, 5, 6])))
    # ... but with a tqdm progress bar
    for _ in tqdm_auto([1, 2, 3], nested=True):
        for _ in tqdm_auto(product([1, 2, 3], [4, 5, 6])):
            pass


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:30:32.021969
# Unit test for function product
def test_product():
    """Unit test for function product"""
    with tqdm_auto(total=3*2*2) as t:
        for _ in product(range(1, 4), range(1, 3), range(1, 3)):
            t.update()
    assert t.n == t.total

# Generated at 2022-06-12 14:30:36.357678
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy import prod

    it1 = (randint(0, 10, size=10),)
    it2 = (randint(0, 10, size=10),) * 2
    it3 = (randint(0, 10, size=10),) * 3
    for iterables in (it1, it2, it3):
        t1 = list(product(*iterables))
        t2 = list(itertools.product(*iterables))
        assert t1 == t2
        assert sum(1 for i in product(*iterables)) == prod(map(len, iterables))

# Generated at 2022-06-12 14:30:42.956232
# Unit test for function product
def test_product():
    func_name = 'pyprind.prog_class.product'
    test_input_data = [
        [[1, 2, 3], [4, 5, 6], [7, 8, 9]],
        [['a', 'b'], ['c', 'd'], ['e', 'f']],
        [['a', 'b'], ['c', 'd'], ['e', 'f', 'g']],
        [range(10), range(10), range(10)],
        [range(100), range(100), range(100)]
    ]
    for data in test_input_data:
        iterable = itertools.product(*data)
        total = 1
        for i in range(len(data)):
            total *= len(data[i])

# Generated at 2022-06-12 14:30:52.519745
# Unit test for function product
def test_product():
    """
    Unit tests for `tqdm.itertools.product`
    """
    from numpy.testing import assert_equal  # pylint: disable=no-name-in-module

    assert_equal(list(product([], [])), [])
    assert_equal(list(product([1], [])), [])
    assert_equal(list(product([], [1])), [])
    assert_equal(list(product([1], [2])), [(1, 2)])
    assert_equal(list(product([1], [2], [3])), [(1, 2, 3)])
    assert_equal(list(product([1, 2], [3, 4])), [(1, 3), (1, 4), (2, 3), (2, 4)])

# Generated at 2022-06-12 14:30:58.746744
# Unit test for function product
def test_product():
    """Test `tqdm.itertools` product function"""
    # Test short args
    with tqdm_auto(total=8, ncols=None) as t:
        for _ in product(range(2), range(2), range(2)):
            t.update()
            pass
    assert t.n == 8
    # Test long args
    for i in product(range(10), range(10), tqdm_class=tqdm_auto, ncols=None):
        pass
    assert i[-1] == (9, 9)

# Generated at 2022-06-12 14:31:04.878629
# Unit test for function product
def test_product():  # pragma: no cover
    "Test function `product`"
    from nose.tools import assert_equal
    from operator import concat

    prod = product(range(4), range(4), tqdm_class=tqdm_auto)
    prod_err = list(product(range(4), "abcd", tqdm_class=tqdm_auto))
    prod_nested = list(product(range(4), "abcd", tqdm_class=tqdm_auto))
    assert_equal(prod_err, list(itertools.product(range(4), "abcd")))
    assert_equal(prod_nested, list(itertools.product(range(4), "abcd")))

# Generated at 2022-06-12 14:31:10.973418
# Unit test for function product
def test_product():
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = ['x', 'y', 'z']
    res_prod = list(itertools.product(a, b, c))
    res_tqprod = list(tqdm.tqdm.product(a, b, c))
    assert res_prod == res_tqprod

# Generated at 2022-06-12 14:31:18.599745
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    import numpy as np
    from tqdm import tqdm

    x = list(product(['a', 'b'],
                     tqdm_class=tqdm, total=3))
    # Assert length and type:
    assert len(x) == 3
    assert type(x) == list

    # Assert list elements are correct:
    assert set(x) == set(
        [('a', 0), ('a', 1), ('b', 0), ('b', 1), ('b', 2)])

    x = list(product(range(2), range(2),
                     tqdm_class=tqdm, total=4))
    # Assert length and type:
    assert len(x) == 4
    assert type

# Generated at 2022-06-12 14:31:28.262972
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np
    with tqdm_auto(total=100, desc="test") as t:
        for _ in product(range(100), range(100)):
            t.update()
        assert t.n == 100
        for _ in product(range(100), range(100.1, 100.2)):
            t.update()
        assert t.n == 200
        for _ in product(range(0, 100, 2), range(100)):
            t.update()
        assert t.n == 300
        for _ in product(range(0, 100, np.float32(2)), range(100)):
            t.update()
        assert t.n == 400

# Generated at 2022-06-12 14:31:37.683120
# Unit test for function product
def test_product():
    from .tests import BaseTest
    from itertools import product
    from numpy.random import randint

    class TestProduct(BaseTest):
        def test_usual(self):
            l = list(range(10))
            p = product(l, repeat=2)
            assert sum(1 for _ in product(l, repeat=2)) == len(l)**2
            self.assert_nested_list_equal(list(p),
                                          [[i, j] for i in l
                                           for j in l])

            # test keyword args
            p = tqdm_product(l, repeat=2, ascii=True)
            assert sum(1 for _ in tqdm_product(l, repeat=2, ascii=True)) == len(l)**2
            self.assert_nested_

# Generated at 2022-06-12 14:31:46.056291
# Unit test for function product
def test_product():
    from ..auto import tqdm
    from ..utils import _range

    def identity(x):
        return x
    assert list(product(['a', 'b', 'c'], matrix=[range(5), [0, 0, 0, 0, 0]])) == \
        list(itertools.product(['a', 'b', 'c'], matrix=[range(5), [0, 0, 0, 0, 0]]))
    assert list(product(range(2), range(2), range(2), range(2),
                        range(2), range(2), range(2), range(2))) == \
        list(product(range(2), range(2), range(2), range(2),
                     range(2), range(2), range(2), range(2), tqdm_class=tqdm))
    assert list

# Generated at 2022-06-12 14:31:49.343283
# Unit test for function product
def test_product():
    with tqdm_auto(total=4*3) as t:
        for i in product(range(4), range(3)):
            t.update()
    with tqdm_auto(total=4*3) as t:
        for i in itertools.product(range(4), range(3)):
            t.update()

# Generated at 2022-06-12 14:31:56.944291
# Unit test for function product
def test_product():
    import random
    random.seed(0)
    def sum_list(list_):
        return sum(list_)

    def f(x):
        return x * x

    def dot_product(x, y):
        return sum(i[0] * i[1] for i in zip(x, y))

    def matrix_product(A, B):
        return [
            [dot_product(row, col) for col in zip(*B)]
            for row in A
        ]

    for _ in product(range(2), repeat=4, tqdm_class=tqdm_auto):
        pass
    for _ in product(range(5)):
        pass


# Generated at 2022-06-12 14:31:57.678045
# Unit test for function product
def test_product():
    for i in product(range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:32:03.405816
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np

    for i in product([1, 2, 3], ['a', 'b'], [None, 'c'], tqdm_class=lambda x: x):
        assert i == (1, 'a', None)
        break  # test one iteration

    for i in product([1, 2, 3], ['a', 'b'], [None, 'c']):
        break  # test one iteration

    for i in product(np.array([1, 2, 3]), ['a', 'b'], [None, 'c']):
        break  # test one iteration

    for i in product(np.array([1, 2, 3]), ['a', 'b'], [None, 'c']):
        assert i == (1, 'a', None)
       

# Generated at 2022-06-12 14:32:10.949770
# Unit test for function product
def test_product():
    pd = product(range(3), range(3), range(3), tqdm_class=tqdm_auto)

# Generated at 2022-06-12 14:32:20.199725
# Unit test for function product
def test_product():
    from .util import _range
    from .unittest import TestCase

    class productTest(TestCase):
        """Test for `itertools.product`"""
        def assert_prod(self, result):
            """Check `itertools.product` result"""
            expected = list(itertools.product(*self.args, **self.kwargs))
            self.assertEqual(list(result), expected)


# Generated at 2022-06-12 14:32:26.285448
# Unit test for function product
def test_product():
    import tqdm
    iterables = [[1, 2], ['ab', 'cd'], [10, 20]]
    res = list(product(*iterables, tqdm_class=tqdm.tqdm)())
    assert res == [(1, 'ab', 10), (1, 'ab', 20),
                   (1, 'cd', 10), (1, 'cd', 20),
                   (2, 'ab', 10), (2, 'ab', 20),
                   (2, 'cd', 10), (2, 'cd', 20)]

# Generated at 2022-06-12 14:32:37.110323
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_equal
    output = []

# Generated at 2022-06-12 14:32:41.317133
# Unit test for function product
def test_product():
    import numpy as np

    a = np.random.randint(0, 3, 5)
    b = np.random.randint(0, 3, 5)

    assert list(product(a, b)) == list(itertools.product(a, b))

# Generated at 2022-06-12 14:32:48.246050
# Unit test for function product
def test_product():
    import numpy as np
    for tqdm_cls in [tqdm_auto] if tqdm_auto is not None else [None]:
        for i in product(range(100),  range(100),
                         range(100),  range(100),
                         range(100),  range(100),
                         range(100),  range(100),
                         range(100),  range(100),
                         tqdm_class=tqdm_cls):
            pass
        tqdm_cls.close()


# Generated at 2022-06-12 14:32:53.152827
# Unit test for function product
def test_product():
    import sys
    from ..utils import _range

    lst = list(product(_range(3), _range(3), _range(3)))

# Generated at 2022-06-12 14:32:57.571427
# Unit test for function product
def test_product():
    """
    Test function against itertools.product()
    """
    try:
        from numpy import product
    except ImportError:
        return
    from numpy.testing import assert_equal
    for i in [1, 2, 3, 2, 0, 1, 2]:
        prange = range(i)
        p = product(prange, repeat=i)
        assert_equal(list(p), list(product(prange, repeat=i)))

# Generated at 2022-06-12 14:33:06.072000
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product` wrapper.
    """
    import gc
    from ..utils import format_sizeof
    # Only run this test with memory-consuming ranges
    assert format_sizeof(1) != '1 bytes'
    with tqdm_auto(unit='B', unit_scale=True, miniters=1,
                   smoothing=0, leave=True) as t:
        for i in product(range(1, 1000000), range(1, 1000000),
                         tqdm_class=tqdm_auto, miniters=1,
                         postfix={'mem': format_sizeof(gc.mem_free())},
                         smoothing=0, leave=True):
            pass

# Generated at 2022-06-12 14:33:13.312262
# Unit test for function product
def test_product():  # pragma: no cover
    from .tests import pretest_posttest
    from .nested import nested_tqdm
    from .utils import BetterCounter

    with nested_tqdm(*range(4), total=4 ** 4, miniters=1,
                     tqdm_class=BetterCounter) as t:
        for i in product(*t):
            pass
    assert t.n == 4 ** 4

    with nested_tqdm(*range(4), total=None, miniters=1,
                     tqdm_class=BetterCounter) as t:
        for i in product(*t, total=None):
            pass
    assert t.n is None


# Generated at 2022-06-12 14:33:20.060044
# Unit test for function product
def test_product():
    import numpy as np
    a = np.asarray([1, 2, 3, 4])
    b = range(5)

    # Standard product
    res = []
    for i in product(a, b):
        res.append(i)
    assert(len(res) == 20)
    assert(isinstance(res[0], tuple))

    # Product with wrapper
    res = []
    for i in product(a, b, tqdm_class=tqdm_auto):
        res.append(i)
    assert(len(res) == 20)
    assert(isinstance(res[0], tuple))

# Generated at 2022-06-12 14:33:26.239385
# Unit test for function product
def test_product():
    import logging
    logger = logging.getLogger('tqdm')
    logger.propagate = False
    logger.addHandler(logging.NullHandler())
    # logger.setLevel(logging.INFO)

    import sys
    import tempfile
    with tempfile.TemporaryFile() as f:
        old_stdout = sys.stdout
        try:
            sys.stdout = f
            for ii in product('abcd', 'efg', 'hij',
                              tqdm_class=tqdm_auto,
                              file=sys.stdout,
                              mininterval=0.5):
                pass
            f.seek(0)
            assert f.read().count(b'\n') == 15
        finally:
            sys.stdout = old_stdout

# Generated at 2022-06-12 14:33:34.549142
# Unit test for function product
def test_product():
    from tqdm import tqdm
    from nose.tools import assert_equal
    for I in (tqdm.tqdm, tqdm.tqdm_notebook, tqdm.trange,
              tqdm.tqdm_pandas, tqdm.tqdm_gui, tqdm.tnrange):
        with I(ascii=True, desc="test") as pbar:
            assert_equal(
                list(product(["a", "b"], range(1000), tqdm_class=I)),
                list(itertools.product(["a", "b"], range(1000))))
            assert_equal(pbar.n, 1000)
            pbar.close()

# Generated at 2022-06-12 14:33:57.483731
# Unit test for function product
def test_product():
    from .tests import TestCase

    with TestCase() as t:
        a = product(*[range(10)] * 3, total=1000)
        b = []
        for _ in a:
            b.append(1)
        assert sum(b) == 1000
        assert a.total == 1000

        itr = product(*[tqdm_auto(range(10))] * 3, total=1000)
        a = tqdm_auto(itr, leave=False)
        b = []
        for _ in a:
            b.append(1)
        assert a.total == 1000


# Generated at 2022-06-12 14:34:02.854261
# Unit test for function product
def test_product():
    from .tqdm_pandas import tqdm_pandas as pdtqdm
    from .tqdm_pandas import tqdm_pandas_autonotebook
    from .tqdm_pandas import tqdm_pandas_notebook
    from .tqdm_pandas import tqdm_pandas_gui
    from .tqdm_pandas import tqdm_pandas_async
    tqdm = tqdm_auto
    products = []

# Generated at 2022-06-12 14:34:12.762835
# Unit test for function product
def test_product():
    from .main import tqdm
    assert next(product(range(10), tqdm_class=tqdm, ascii=True, desc='1st loop')) == (0, 0)
    assert next(product(range(10), tqdm_class=tqdm, ascii=True, desc='2nd loop')) == (0, 1)
    assert next(product(range(10), tqdm_class=tqdm, ascii=True, desc='3rd loop')) == (0, 2)
    assert next(product(range(10), tqdm_class=tqdm, ascii=True, desc='4th loop')) == (0, 3)

# Generated at 2022-06-12 14:34:19.555261
# Unit test for function product
def test_product():
    for n in range(4):
        l = range(n)
        p = product(*(l for _ in range(n)))
        # we don't really care about the assertions as long as they don't
        # raise an exception
        assert list(p) == list(itertools.product(*(l for _ in range(n))))
        p = product(*(l for _ in range(n)), tqdm_class=tqdm_auto)
        assert list(p) == list(itertools.product(*(l for _ in range(n))))

# Generated at 2022-06-12 14:34:27.353062
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    from collections import namedtuple
    from nose.tools import assert_equal
    Point = namedtuple('Point', 'x y')
    p = list(product(range(100), range(100), tqdm_class=tqdm_auto))
    assert_equal(p, list(itertools.product(range(100), range(100))))
    p = list(product(range(100), range(100), tqdm_class=tqdm_auto,
                     desc='Test'))
    assert_equal(p, list(itertools.product(range(100), range(100))))
    p = Point(*list(product(range(100), range(100), tqdm_class=tqdm_auto)))

# Generated at 2022-06-12 14:34:30.568732
# Unit test for function product
def test_product():  # pragma: no cover
    import numpy as np
    # This should work
    list(product(range(10), range(10)))
    # This should not raise
    list(product(np.arange(10), np.arange(10)))

# Generated at 2022-06-12 14:34:37.381230
# Unit test for function product
def test_product():
    """Test suite for product"""
    from ..utils import format_sizeof

    tqdm.wrapattr(itertools, "product")(range, range)
    assert format_sizeof(itertools.product(range, range)) == "2.0KiB"

    tqdm.wrapattr(itertools, "product")(range, range, range)
    assert format_sizeof(itertools.product(range, range, range)) == "8.0KiB"

# Simple sanity tests
if __name__ == "__main__":
    from . import _test as testmain
    #import itertools as IT
    #import operator as OP
    #from .. import main
    #main(itertools.chain)
    #main(itertools.chain.from_iterable)
    #main(

# Generated at 2022-06-12 14:34:45.606483
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    assert_equal(
        list(product(range(3), repeat=3,
                     tqdm_class=tqdm_auto)),
        list(enumerate(itertools.product(range(3), repeat=3))))
    assert_equal(
        list(product(range(6), repeat=6,
                     tqdm_class=tqdm_auto)),
        list(enumerate(itertools.product(range(6), repeat=6))))
    assert_equal(
        list(product(range(6), repeat=6, tqdm_class=tqdm_auto,
                     ascii=True, desc="test")),
        list(enumerate(itertools.product(range(6), repeat=6))))

# Generated at 2022-06-12 14:34:46.540298
# Unit test for function product
def test_product():
    from .tests import product_test
    product_test(product)

# Generated at 2022-06-12 14:34:48.848702
# Unit test for function product
def test_product():
    """ Unit test for function product """
    output_totals = []
    list(product(range(3), range(3), tqdm_class=lambda x: (yield i) or i + 1,
                 postfix={"total": lambda x: x}))
    assert output_totals == [9]

# Generated at 2022-06-12 14:35:34.440433
# Unit test for function product
def test_product():
    """
    Test that tqdm.product is equivalent to itertools.product.
    """
    import numpy as np
    from numpy.testing import assert_equal
    from numpy.random import randint
    rnd = randint(0, 10, size=1000).tolist()

    equals = lambda a, b: assert_equal(list(a), list(b), list(a))
    for eg in [map, zip, lambda: product(rnd, rnd), lambda: itertools.product(rnd, rnd)]:
        equals(product(rnd, rnd), eg())
        equals(product(range(10), repeat=3), itertools.product(range(10), repeat=3))

# Generated at 2022-06-12 14:35:41.520783
# Unit test for function product
def test_product():
    import numpy as np
    from .gui import tqdm

    with tqdm(total=None) as t:
        for i in itertools.product(range(5), repeat=5):
            t.update()
    assert (t.n, t.total) == (3125, 3125)

    with tqdm(total=3) as t:
        for i in product(range(5), repeat=5):
            t.update()
    assert (t.n, t.total) == (3125, 3125)

    with tqdm(total=3) as t:
        for i in product(np.arange(5), repeat=5):
            t.update()
    assert (t.n, t.total) == (3125, 3125)

# Generated at 2022-06-12 14:35:44.467117
# Unit test for function product
def test_product():
    from .main import tqdm_notebook
    tqdm_notebook(product, "ABC", "DEF")
    assert tqdm_notebook(product, [1, 2, 3], [1, 2, 3]).__length_hint__() == 9

# Generated at 2022-06-12 14:35:52.225600
# Unit test for function product
def test_product():  # pragma: no cover
    from ..utils import format_sizeof
    from ..tests._utils import _print_run_time

    def size_info():
        """
        Print array sizes for memory profiling
        """
        for i, (name, arr) in enumerate(zip(["comb"], [comb])):
            yield (i, name, format_sizeof(arr.nbytes))
    tqdm_kwargs = {'disable': None}

    _print_run_time(
        'comb = list(product(range(3), repeat=2))',
        'print(comb)',
        tqdm_kwargs=tqdm_kwargs,
        additional_functions=[size_info])


if __name__ == "__main__":  # pragma: no cover
    import pytest
    pytest.main

# Generated at 2022-06-12 14:36:01.093447
# Unit test for function product
def test_product():
    from six.moves import xrange
    from .utils import format_sizeof
    import pickle
    from .utils import StringIO

    def sparse_product(k, m, n, tqdm_cls=tqdm_auto):
        """
        Cartesian product of k lists of the form [0, .., m-1] x [0, .., n-1]
        """
        return product(
            *([xrange(m)] * k),
            *([xrange(n)] * k),
            tqdm_class=tqdm_cls)


# Generated at 2022-06-12 14:36:08.588027
# Unit test for function product
def test_product():
    """
    Unit tests for itertools.product.
    """
    try:
        import pytest
        import numpy as np
        pytest.importorskip("numpy")
    except ImportError:
        raise SkipTest("numpy not found")

    from ..utils import _range

    total_cases = 100
    iterations = 1000
    range_min = 1
    range_max = 10

    for _ in _range(total_cases):
        # Generate random iterables and their cartesian product
        rng = np.random.RandomState(total_cases)
        iterables = [_range(rng.randint(range_min, range_max))
                     for _ in _range(rng.randint(range_min, range_max))]

# Generated at 2022-06-12 14:36:14.714857
# Unit test for function product
def test_product():
    """Test for `itertools.product`"""
    from nose.tools import assert_equal
    for i in product("ab", "c", "de", tqdm_class=type(""), total=9):
        assert_equal(len(i), 3)
        break
    try:
        next(product("ab", "c", "de", tqdm_class=type("")))
    except StopIteration:
        # OK
        pass
    else:
        assert_equal("not an Exception", "raised!")


# For nosetests
if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:36:22.145150
# Unit test for function product
def test_product():
    """
    Test the `itertools.product` equivalent
    """
    # Test product(range(2), range(2))
    assert list(product(range(2), range(2))) == [
        (0, 0), (0, 1), (1, 0), (1, 1)]
    # Test product(range(2), range(2), tqdm_class=tqdm.tqdm_class)
    assert list(product(range(2), range(2), tqdm_class=tqdm_auto)) == [
        (0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-12 14:36:25.492108
# Unit test for function product
def test_product():
    iterables = [["0", "1"], ["0", "1"], ["0", "1"]]
    assert set(product(*iterables)) == set(itertools.product(*iterables))
    iterables = ["0", "1"]
    assert set(product(*iterables)) == set(itertools.product(*iterables))

# Generated at 2022-06-12 14:36:31.396779
# Unit test for function product
def test_product():
    import numpy as np
    n = 10000
    a = np.ones(n)
    b = np.ones(n)
    c = np.ones(n)
    for i, j, k in product(a, b, c, tqdm_class=tqdm_auto, leave=False):
        assert i == 1.0
    for i, j, k in itertools.product(a, b, c):
        assert i == 1.0
    for i in product([], [], [], tqdm_class=tqdm_auto):
        assert False
    assert list(product([1], [1], [1], tqdm_class=tqdm_auto))[0] == (1, 1, 1)