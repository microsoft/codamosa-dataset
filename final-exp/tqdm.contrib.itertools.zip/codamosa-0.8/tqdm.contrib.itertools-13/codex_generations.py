

# Generated at 2022-06-12 14:27:06.410809
# Unit test for function product
def test_product():
    from numpy import product as nprod
    from product import product
    for i in range(2, 7):
        for j in range(2, 7):
            assert sum(product(range(i), range(j))) == nprod([i, j]) - i - j

# Generated at 2022-06-12 14:27:14.970357
# Unit test for function product
def test_product():
    with tqdm_auto(unit='i') as t:
        for i in product(range(10), range(10), tqdm_class=tqdm_auto, total=100):
            pass
        for i in product(range(10), range(10), tqdm_class=tqdm_auto, total=1):
            pass
    with tqdm_auto(unit='i') as t:
        try:
            for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                             total=1000):
                pass
        except ValueError:
            pass
        else:
            raise ValueError("ValueError not raised")

# Generated at 2022-06-12 14:27:23.347811
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ._utils import _test_iterator
    from ._utils import format_sizeof
    it = product(range(8), range(5), range(3), range(100), range(10000), tqdm=tqdm_auto)
    pickle = _test_iterator(it)
    assert list(it) == list(product(range(8), range(5), range(3), range(100), range(10000)))
    _test_iterator(pickle, pickle=True)
    del it, pickle

    # Testing maxsize
    it = product(range(8), tqdm=tqdm_auto)
    assert next(it).__sizeof__() < 100  # ~58 bytes on Py3

# Generated at 2022-06-12 14:27:29.149938
# Unit test for function product
def test_product():
    """Test that the output of product equals the expected value (power set)"""
    test_list = [1, 2, 3, 4]
    powerset = [(1, 2, 3, 4), (1, 2, 3), (1, 2, 4), (1, 2), (1, 3, 4), (1, 3),
                (1, 4), (1,), (2, 3, 4), (2, 3), (2, 4), (2,), (3, 4), (3,),
                (4,), ()]
    for i, j in zip(product(test_list, repeat=4), powerset):
        assert i == j

# Generated at 2022-06-12 14:27:35.397310
# Unit test for function product
def test_product():
    import numpy as np
    from .trange import trange
    from .tqdm import tqdm
    for t in [tqdm, trange]:
        for p in product(range(3), range(3), tqdm_class=t):
            # Add a small pause to slow down the update speed
            np.random.randint(1e7)
            pass

# Main function
if __name__ == "__main__":
    test_product()

# Generated at 2022-06-12 14:27:42.395176
# Unit test for function product
def test_product():
    from ..tests import _test_iterable_content

    with tqdm_auto() as t:
        for i in product(range(6), range(6), range(6), range(6),
                         tqdm_class=t.__class__,
                         disable=False, unit='i',
                         unit_scale=True, unit_divisor=10e3,
                         total=60**4, dynamic_ncols=True,
                         ascii=True, mininterval=0.001, miniters=2,
                         desc='test', leave=True,
                         postfix={'int': 1, 'float': 1.0}):
            assert len(i) == 4
    _test_iterable_content(t)

# Generated at 2022-06-12 14:27:52.906616
# Unit test for function product
def test_product():
    """Test"""
    import sys

    if sys.version_info < (2, 7):
        return
    import numpy as np
    from ..auto import tqdm

    def prd(x, y, z):
        return x * y * z

    def prod(x, y, z):
        return product(x, y, z)

    for (x, y, z) in product(range(4), range(4), range(4)):
        assert prd(x, y, z) == prod(x, y, z)
    for (x, y, z) in product(range(4), range(4), range(4)):
        assert prd(x, y, z) == prod(x, y, z)
    z = range(100)
    z = [range(1000)] * 10
    r

# Generated at 2022-06-12 14:27:56.241008
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for i in product(range(10), range(50), range(100)):
        pass
    for i in product(range(10), range(50), range(100), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:28:01.389392
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from nose.tools import assert_equal
    import sys
    if sys.version_info.major == 2:
        import StringIO
    else:
        from io import StringIO
    test_stream = StringIO()

    total = 0
    for _ in tqdm_product(['a', 'b'], [1, 2], [3, 4]):
        total += 1

    assert_equal(total, 8)

# Generated at 2022-06-12 14:28:05.692983
# Unit test for function product
def test_product():
    """Test function product."""
    total = 0
    for _ in product(range(10), "abcd", "ef", tqdm_class=None):
        total += 1
    assert total == 10 * 4 * 2

    total = 0
    for _ in product(range(10), "abcd"):
        total += 1
    assert total == 10 * 4

# Generated at 2022-06-12 14:28:11.499825
# Unit test for function product
def test_product():
    a = tqdm_auto(product([1, 2], repeat=3))
    b = tqdm_auto(product([1, 2], [1, 2], [1, 2]))
    assert set(a) == set(b) == {1, 2, 3, 4, 5, 6, 7, 8}

# Generated at 2022-06-12 14:28:14.497914
# Unit test for function product
def test_product():
    """Test product"""
    N1 = 4
    N2 = 3
    N3 = 2
    for p in product(range(N1), range(N2), range(N3), tqdm_class=None):
        assert p == (p[0], p[1], p[2])

# Generated at 2022-06-12 14:28:24.394849
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import ClosingContextTestCase
    with ClosingContextTestCase(lambda: None) as t:
        # Test output order
        assert tuple(product('ABCD', 'xy')) == (('A', 'x'), ('A', 'y'),
                                                ('B', 'x'), ('B', 'y'),
                                                ('C', 'x'), ('C', 'y'),
                                                ('D', 'x'), ('D', 'y'))

# Generated at 2022-06-12 14:28:31.364522
# Unit test for function product
def test_product():
    # Test for integer multiplication
    i = -1
    for t in product((0, 1), repeat=4):
        i += 1
        assert i == int(''.join(map(str, t)), 2)

    # Test for Cartesian product
    assert list(product(range(3), 'ABC')) == list(product('ABC', range(3))) == [
        (0, 'A'),
        (0, 'B'),
        (0, 'C'),
        (1, 'A'),
        (1, 'B'),
        (1, 'C'),
        (2, 'A'),
        (2, 'B'),
        (2, 'C'),
    ]

# Generated at 2022-06-12 14:28:37.728605
# Unit test for function product
def test_product():
    it = product([1, 2, 3], tqdm_class=tqdm_auto)
    assert len(list(it)) == 3**1
    it = product([1, 2, 3], [4, 5], tqdm_class=tqdm_auto)
    assert len(list(it)) == 3**1 * 2**1
    it = product([1, 2, 3], [4, 5], [6, 7], tqdm_class=tqdm_auto)
    assert len(list(it)) == 3**1 * 2**1 * 2**1

# Generated at 2022-06-12 14:28:42.473295
# Unit test for function product
def test_product():
    from itertools import product
    from numpy.testing import assert_array_equal

    for A in ["", "ab", "abc"]:
        for B in ["", "efg"]:
            for C in ["", "h", "i"]:
                def _prod(*args):
                    return ["".join(p) for p in product(*args) if p]

                assert_array_equal(_prod(A, B, C), list(product(A, B, C)))

# Generated at 2022-06-12 14:28:43.886534
# Unit test for function product
def test_product():
    for i in product(range(100)):
        pass

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:28:46.327914
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tqdm import tqdm
    (x, y), total = list(product(range(100), range(100))), 10000
    for xy in tqdm(product(range(100), range(100)), total=total):
        assert xy == (next(x), next(y))

# Generated at 2022-06-12 14:28:57.700951
# Unit test for function product
def test_product():
    import operator as op
    import sys
    from .utils import format_sizeof
    from .utils import _range

    try:
        from collections import Counter
    except ImportError:  # python2.6
        class Counter(dict):
            def __init__(self):
                self.update = self.__setitem__
                self.__len__ = self.__contains__ = lambda s, *a: True
            def most_common(self, n=None):
                return sorted(self.items(), key=lambda kv: kv[1])


# Generated at 2022-06-12 14:29:01.021067
# Unit test for function product
def test_product():
    assert (
        "".join(product("AB", range(3), tqdm_class=tqdm_auto.tqdm))
        == "0A0B1A0B2A0B0A1B1A1B2A1B0A2B1A2B2A2B")


test_product()

# Generated at 2022-06-12 14:29:10.043224
# Unit test for function product
def test_product():
    from .tests import dumb_apply_mock, test_nested
    from itertools import product as itertools_product

    iterables = [range(7), range(5)]
    with tqdm_auto(
            iterable=product(*iterables,
                             tqdm_class=dumb_apply_mock), leave=False) as nt:
        for _ in nt:
            pass

    assert nt.total == 7 * 5
    test_nested(nt, total=nt.total,
                desc='itertools.product(range(7), range(5))')

    assert list(nt) == list(itertools_product(*iterables))

# Generated at 2022-06-12 14:29:18.933007
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np
    from .utils import SimpleNamespace as SN
    from .tests import pretest_posttest_private_tqdm, _range

    class my_tqdm(tqdm_auto):
        def __init__(self, *args, **kwargs):
            super(my_tqdm, self).__init__(*args, **kwargs)
            self.custom_value = 42

    @pretest_posttest_private_tqdm(True, tqdm_class=my_tqdm)
    def _test_product(autorange, tqdm_class):
        assert isinstance(tqdm_class, type)
        assert issubclass(tqdm_class, my_tqdm)

        L = np.array

# Generated at 2022-06-12 14:29:24.962589
# Unit test for function product
def test_product():

    from ..pandas import trange

    # Simple example
    x = product('ABC', range(2))
    assert list(x) == [('A', 0), ('A', 1), ('B', 0), ('B', 1), ('C', 0), ('C', 1)]

    # Test trange output
    x = product('ABC', trange(3))
    assert list(x) == [('A', 0), ('A', 1), ('A', 2), ('B', 0), ('B', 1), ('B', 2), ('C', 0), ('C', 1), ('C', 2)]

# Generated at 2022-06-12 14:29:27.657133
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy.random

    for i in product("abc", range(4), numpy.random.rand(5),
                     tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:29:36.452294
# Unit test for function product
def test_product():
    """Test for function product"""
    n = 100000
    for _ in product(range(n), tqdm_class=tqdm_auto):
        pass
    for _ in product(range(n), range(n), tqdm_class=tqdm_auto):
        pass
    for _ in product(range(n), range(n), range(n), tqdm_class=tqdm_auto):
        pass
    for _ in product(range(n), range(n), range(n), range(n),
                     tqdm_class=tqdm_auto):
        pass

    for _ in product(range(n), range(n), range(n), range(n),
                     range(n), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-12 14:29:38.842651
# Unit test for function product
def test_product():
    from .itertools_test import tests
    from .tests import _test_it
    _test_it(itertools, product, tests['itertools.product'],
             name='product')

# Generated at 2022-06-12 14:29:47.266483
# Unit test for function product
def test_product():
    """
    Simple unit tests for wrapped_product
    """
    import numpy as np
    # Test that wrapped_product is the same as itertools.product
    rng = np.random.RandomState(42)
    for i in range(2, 5):
        for j in range(10 ** i):
            lst = []
            for k in range(i):
                arr = rng.randint(0, 10, j).tolist()
                lst.append(arr)
            wrapped_result = list(product(*lst, tqdm_class=None))
            itertools_result = list(itertools.product(*lst))
            assert wrapped_result == itertools_result
    # Test that it works without TQDM
    wrapped_result = list(product([1, 2, 3]))


# Generated at 2022-06-12 14:29:55.935361
# Unit test for function product
def test_product():
    from ..utils import precision_wrapper, BiMultiMapping
    from io import StringIO
    from sys import stdout, stderr
    total = 10
    # For Python 2
    import sys
    if sys.version_info[0] < 3:
        buffer = StringIO()
    else:
        buffer = StringIO(newline='')

    with precision_wrapper(digits=4):
        for (i, j), _ in zip(product(range(total), range(total),
                                     tqdm_class=tqdm_auto, file=buffer),
                             range(total * total)):
            pass
    assert (_ for _ in range(total**2)), ('product', total**2, buffer)

    # Same test but with different file

# Generated at 2022-06-12 14:30:04.333701
# Unit test for function product
def test_product():
    """Test the product() wrapper"""
    import numpy as np
    from ..utils import format_sizeof

    for i in range(1, 4):
        for j in range(1, 4):
            for k in range(1, 4):
                for t in (tqdm, tqdm_gui, tqdm_notebook):
                    assert (
                        sum(1 for _ in product(range(i), range(j), range(k),
                                               tqdm_class=t)) ==
                        i * j * k)
                    # All tqdm versions output "100%|##########| 27/27 [00:00<?, ?it/s]"
                    # on Python 3.5 64-bit (Windows 10)

    # Test non-iterable args

# Generated at 2022-06-12 14:30:12.793387
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import gc
    from random import randrange

    # Test that all items are yielded
    L = [list(range(3)), list(range(3)), list(range(3))]
    L_cmp = list(itertools.product(*L))
    for _ in range(3):
        assert list(product(*L)) == L_cmp
        for l in L:
            l.pop()
    assert list(product(*L)) == []
    # Test that the correct number of items is yielded
    for _ in range(3):
        assert len(list(product(*L))) == 0
        assert len(list(product(*L, total=42))) == 0
        for l in L:
            l.append(None)

# Generated at 2022-06-12 14:30:20.178154
# Unit test for function product
def test_product():
    """
    Unit testing for product function.
    """
    for i in product(range(10), total=100):
        pass
    assert i == (9, 9)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-12 14:30:23.738955
# Unit test for function product
def test_product():
    """Unit test for function product"""
    _ = list(product('ABCD', 'xy', tqdm_class=tqdm_auto))
    _ = list(product(range(10), repeat=3, tqdm_class=tqdm_auto))

# Generated at 2022-06-12 14:30:26.475014
# Unit test for function product
def test_product():
    """Test for product function"""
    for x in product([1, 2, 3], [4, 5], [6, 7], tqdm_class=tqdm_auto):
        assert len(x) == 3
        assert isinstance(x, tuple)
        break

# Generated at 2022-06-12 14:30:29.906955
# Unit test for function product
def test_product():
    """Test function `product`."""
    s = set()
    for i in product("abc", [1, 2, 3]):
        s.add(i)
    assert s == set([('a', 1), ('a', 2), ('a', 3),
                     ('b', 1), ('b', 2), ('b', 3),
                     ('c', 1), ('c', 2), ('c', 3)])

# Generated at 2022-06-12 14:30:30.992470
# Unit test for function product
def test_product():
    for i in product(range(2), range(4), range(2)):
        pass

# Generated at 2022-06-12 14:30:38.039263
# Unit test for function product
def test_product():
    """
    Unit test of function `product`.

    Returns
    -------
    None.
    """
    import numpy as np
    a = np.arange(3)
    b = np.arange(3)
    c = np.arange(3)
    res = list(product(a, b, c))
    assert res == [(i, j, k) for i, j, k in zip(a, b, c)]
    assert list(product(a, b, c, total=9)) == [(i, j, k) for i, j, k in zip(a, b, c)]
    # no error with infinite iterable
    assert next(product(range(1000), range(1000))) is not None
    # error raised if total not provided

# Generated at 2022-06-12 14:30:40.839590
# Unit test for function product
def test_product():
    """
    Example for `tqdm(itertools.product)`
    """
    from .gui import tqdm
    for _ in tqdm(itertools.product(range(1000), repeat=2)):
        pass

# Generated at 2022-06-12 14:30:43.190839
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert list(product([1, 2, 3], [4, 5])) == [
        (1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]

# Generated at 2022-06-12 14:30:48.452794
# Unit test for function product
def test_product():
    from ..std import NextRange
    for _ in product(range(100), range(100)):
        pass

    for _ in product(range(100), range(100)):
        pass

    for _ in product(range(100), NextRange(100)):
        pass

    for _ in product(NextRange(100), range(100)):
        pass

    for _ in product(NextRange(100), NextRange(100)):
        pass

# Generated at 2022-06-12 14:30:51.836620
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import pytest

    def check_product(tqdm, **kwargs):
        a = list(range(2))
        b = list(range(2))
        list(tqdm.tqdm(product(a, b, tqdm_class=tqdm), **kwargs))

    with pytest.raises(ValueError):
        check_product(tqdm_auto, total=10)
    check_product(tqdm_auto, total=7)

# Generated at 2022-06-12 14:31:03.683556
# Unit test for function product
def test_product():
    int_1 = range(1000)
    int_2 = range(1000)

    product_1 = itertools.product(int_1, int_2)
    product_2 = tqdm.product(int_1, int_2)

    for item_1, item_2 in zip(product_1, product_2):
        assert item_1 == item_2

# Generated at 2022-06-12 14:31:12.531923
# Unit test for function product
def test_product():
    """
    test simple product
    """
    from ..utils import format_sizeof
    import os
    total = os.stat(__file__).st_size
    for _ in product([1, 2], [3, 4], [5, 6]):
        total -= 1
    assert total == 0
    # test short form
    for _ in product([1, 2], [3, 4], [5, 6], tqdm_class=None):
        total -= 1
    assert total == 0
    # test format_sizeof
    for _ in product([1, 2], total=format_sizeof(__file__)):
        total -= 1
    assert total == 0

# Generated at 2022-06-12 14:31:15.331409
# Unit test for function product
def test_product():
    """
    Extra unit tests for `itertools.product`.
    """
    with tqdm_auto(leave=True) as t:
        for _ in product(["a", "b"], range(5)):
            t.update()
    assert t.n == 10

# Generated at 2022-06-12 14:31:19.904232
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import numpy
    n, m = 3, 5
    # Default case, no `total` argument
    assert list(product(range(n), range(m))) == list(
        itertools.product(range(n), range(m)))
    assert list(product(numpy.arange(n), numpy.arange(m))) == list(
        product(range(n), range(m)))
    # With `total` argument
    assert list(product(range(n), range(m), total=n*m)) == list(
        itertools.product(range(n), range(m)))

# Generated at 2022-06-12 14:31:25.403943
# Unit test for function product
def test_product():
    """Simple self-contained test for `product` function"""
    from ..tests import FakeTqdmExperimentalDirective
    from .utils import BaseTestCase

    class Product(BaseTestCase):
        def testProduct(self):
            for seq1 in ([], [1, 2], [1, 2, 3]):
                for seq2 in ([], [3, 4], [3, 4, 5]):
                    self.assertAlmostEqual(
                        list(product(seq1, seq2, tqdm_class=FakeTqdmExperimentalDirective)),
                        list(itertools.product(seq1, seq2)))

    return Product



# Generated at 2022-06-12 14:31:27.858305
# Unit test for function product
def test_product():
    f = product(range(100), range(100), range(100),
                tqdm_class=tqdm_auto,
                desc="Unit test for tqdm.itertools.product")
    for _ in f:
        pass

# Generated at 2022-06-12 14:31:37.479033
# Unit test for function product
def test_product():  # pragma: no cover
    from ..utils import _range, format_sizeof
    from ..tests._utils import TestCase, IS_IPY, IS_PYPY, IS_WINDOWS

    class TestProduct(TestCase):
        def test_simple_basic(self):
            total = 0
            for i in product(range(10), range(10)):
                # print(i)  # uncomment for test coverage
                total += 1
            self.assertEqual(total, 100)

        def test_simple_basic_with_kwargs(self):
            if not IS_PYPY and (not IS_WINDOWS or IS_IPY):
                total = 0

# Generated at 2022-06-12 14:31:40.504590
# Unit test for function product
def test_product():
    iterables = range(100), range(100)
    with tqdm_auto(desc="test_product") as t:
        for _ in product(*iterables, total=100 * 100, tqdm_class=tqdm_auto):
            pass
    assert t.n == 100 * 100

# Generated at 2022-06-12 14:31:44.375199
# Unit test for function product
def test_product():
    """Test for product()"""
    from io import BytesIO

    s = BytesIO()
    for i in product(range(10), range(10),
                     tqdm_class=tqdm_auto,
                     file=s):
        assert len(i) == 2
    assert s.getvalue()

# Generated at 2022-06-12 14:31:52.375243
# Unit test for function product
def test_product():
    from .._utils import SimpleNamespace
    import sys
    out = sys.stdout
    sys.stdout = None
    try:
        iterable = (list(range(10)), [-1] + list(range(10)), list(range(10)))
        p = product(*iterable, tqdm_class=SimpleNamespace, ascii=True)
        assert next(p) == (0, -1, 0)
        next(p)
        p.set_description("h")
        p.set_postfix(dict(o=3), refresh=False)
        next(p)
        p.close()
        p.set_description("")
        p.set_postfix(dict(), refresh=False)
        next(p)
    finally:
        sys.stdout = out

# Generated at 2022-06-12 14:32:19.963269
# Unit test for function product
def test_product():
    from .tests import close_open_files
    from .utils import format_sizeof
    import time
    with tqdm_auto(unit="bits") as t:
        for i in product("ABC", "123", bar_format="{l_bar}{bar}|"):
            t.update(16)
    assert t.total == 16 * 3, \
        "total != 16 * 3: {0} != 48".format(t.total)
    assert t.n == 16 * 3, \
        "n != 16 * 3: {0} != 48".format(t.n)

# Generated at 2022-06-12 14:32:26.358757
# Unit test for function product
def test_product():
    try:
        len([])
    except TypeError:  # Python 3.5 support
        assert list(product(range(10), repeat=3)) == \
            list(itertools.product(range(10), repeat=3))
    else:
        assert list(product(range(10), repeat=3)) == \
            list(itertools.product(range(10), repeat=3))
        assert list(product(range(10), repeat=3, tqdm_class=None)) == \
            list(itertools.product(range(10), repeat=3))

# Generated at 2022-06-12 14:32:28.582235
# Unit test for function product
def test_product():
    x = list(product(range(10), range(15, 20), tqdm_class=tqdm_auto))
    assert x == itertools.product(range(10), range(15, 20))

# Generated at 2022-06-12 14:32:35.794531
# Unit test for function product
def test_product():
    for i in product(range(3), range(3), range(3)):
        assert i == (0, 0, 0)
        break
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        assert i == (0, 0, 0)
        break
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto,
                     leave=True):
        assert i == (0, 0, 0)
        break
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto,
                     disable=True):
        assert i == (0, 0, 0)
        break

# Generated at 2022-06-12 14:32:44.823915
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # no tqdm arguments
    str_list = []
    for l1 in product('ab', 'cd'):
        str_list.append(l1)
    assert str_list == [('a', 'c'), ('a', 'd'), ('b', 'c'), ('b', 'd')]

    # tqdm_class argument
    tqdm_class = tqdm_auto.tqdm
    str_list = []
    for l1 in product('ab', 'cd', tqdm_class=tqdm_class):
        str_list.append(l1)
    assert str_list == [('a', 'c'), ('a', 'd'), ('b', 'c'), ('b', 'd')]

    # total argument
    tqdm_class = tqdm

# Generated at 2022-06-12 14:32:50.935815
# Unit test for function product
def test_product():
    from .utils import StringIO
    from .tqdm import trange
    from .tqdm_gui import tqdm_gui
    from random import shuffle
    for cls in [tqdm, trange, tqdm_gui]:
        for j in range(10):
            for i in cls(product([0, 1], repeat=j, tqdm_class=cls)):
                assert len(i) == j
    for j in range(10):
        for i in product([0, 1], repeat=j, tqdm_class=None):
            assert len(i) == j
    # Fix bug #203, #204
    old_stdout = sys.stdout
    sys.stdout = StringIO()

# Generated at 2022-06-12 14:32:52.040790
# Unit test for function product
def test_product():
    "Tests that product(range(4), range(4)) has 16 elements"
    return len(list(product(range(4), repeat=2)))

# Generated at 2022-06-12 14:32:58.097037
# Unit test for function product
def test_product():
    """
    Test function `product`

    # Returns
        None
    """
    def naturals():
        n = 0
        while True:
            n += 1
            yield n

    product(naturals(), repeat=5)
    product(naturals(), repeat=5, tqdm_class=tqdm_auto)
    product(naturals(), repeat=5, tqdm_class=tqdm_auto, desc='Unicode 🐍',
            ascii=True)
    product(naturals(), repeat=5, tqdm_class=tqdm_auto, desc='Unicode 🐍',
            ascii=False)

# Generated at 2022-06-12 14:33:07.263404
# Unit test for function product
def test_product():
    """Test function ``product``."""
    assert list(product([1, 2], repeat=0)) == [(None,)]
    assert list(product([1, 2], repeat=1)) == [(1,), (2,)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product([])) == []
    assert list(product([])) == []
    assert list(product([2, 3], [4, 5, 6])) == [(2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]

# Generated at 2022-06-12 14:33:14.065446
# Unit test for function product
def test_product():
    from ..testing import _test_iter
    from ..testing import _test_iter_raise_on_break
    return _test_iter(product(range(10), range(10)), prod=100) + \
        _test_iter_raise_on_break(product(range(10), range(10)))


if __name__ == "__main__":
    import sys
    test_cases = [
        # fmt: off
        test_product,
        # fmt: on
    ]
    failed, tests = 0, []
    for t in test_cases:
        try:
            tests.append(t())
        except Exception as e:
            print("FAILED: %s raised %r" % (t.__name__, e))
            failed += 1
    try:
        import nose
    except ImportError:
        print

# Generated at 2022-06-12 14:34:10.085172
# Unit test for function product
def test_product():
    n = 3 * 2 * 4 * 2
    x = range(n)
    y = product([1, 2, 4], [1, 2, 4], [1, 2, 4], [1, 2, 4])
    assert list(y) == x

# Generated at 2022-06-12 14:34:16.697934
# Unit test for function product
def test_product():
    for i, _ in zip(range(6), itertools.product("123", "ab")):
        assert i == 0
    for i, _ in zip(range(6), product("123", "ab")):
        assert i == 0
    for i, _ in zip(range(6), itertools.product("123", "ab")):
        assert i == 0
    for i, _ in zip(range(6), product("123", "ab")):
        assert i == 0

# Generated at 2022-06-12 14:34:18.223374
# Unit test for function product
def test_product():
    from .tests import _test_iterator
    return _test_iterator(product,
                          itertools.product)

# Generated at 2022-06-12 14:34:20.208332
# Unit test for function product
def test_product():
    "Test product wrapper"
    from random import randint
    from itertools import islice
    from .tests_tqdm import with_unit_option

 

# Generated at 2022-06-12 14:34:24.840192
# Unit test for function product
def test_product():
    from ..utils import decoretools as dt
    l = list(product(range(3), ["a", "b", "c"], tqdm_class=dt.DummyTqdm))
    assert l == [(0, 'a'), (0, 'b'), (0, 'c'), (1, 'a'), (1, 'b'), (1, 'c'),
                 (2, 'a'), (2, 'b'), (2, 'c')]

# Generated at 2022-06-12 14:34:27.152161
# Unit test for function product
def test_product():
    from .stats import stats
    list(product(range(1000), range(100), tqdm_class=tqdm_auto))
    stats()

# Generated at 2022-06-12 14:34:35.016496
# Unit test for function product
def test_product():
    from .utils import closing, format_sizeof
    from .pandas import tqdm_pandas
    from .std import tqdm_std
    from .gui import tqdm_gui
    try:
        from .notebook import tqdm_notebook
    except:
        tqdm_notebook = None

    class SumUp(object):
        """Collects the sum of elements in the stream"""
        def __init__(self):
            self.val = 0
        def update(self, x):
            self.val += sum(x)
        def __str__(self):
            return str(self.val)

    def test(tqdm_class):
        """Functional test for tqdm.product (tqdm_class is e.g. tqdm)"""

# Generated at 2022-06-12 14:34:42.950164
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    from ..std import tqdm

    # Test if function can be initialized on its own
    gen = product(range(20))
    assert next(gen) == (0,)

    # Test if it can be called with keyword argument
    gen = product(range(20), tqdm_class=tqdm)
    assert next(gen) == (0,)

    # Test if tqdm works as expected
    gen = product(range(20), range(20), tqdm_class=tqdm)
    assert sum(1 for _ in gen) == 20**2

    # Test if tqdm can be used with multiple iterators
    gen = product(range(20), range(20), tqdm_class=tqdm)

# Generated at 2022-06-12 14:34:48.044571
# Unit test for function product
def test_product():
    """Test `tqdm.itertools.product`"""
    iterables = [[0, 1], [2, 3]]
    res = [i for i in product(*iterables)]
    assert res == [(0, 2), (0, 3), (1, 2), (1, 3)]

    kwargs = {"tqdm_class": tqdm_auto}
    res = [i for i in product(*iterables, **kwargs)]
    assert res == [(0, 2), (0, 3), (1, 2), (1, 3)]

# Generated at 2022-06-12 14:34:55.447067
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests import TestCaseNotUnit, pretest_posttest

    @pretest_posttest
    def test(test):
        test.assertTrue(hasattr(test, "tqdm_class"))
        test.assertTrue(test.tqdm_class is not tqdm_auto)
        test.assertEqual(
            list(product("AB", "12", tqdm_class=test.tqdm_class)),
            list(itertools.product("AB", "12")))

    with TestCaseNotUnit(tqdm_class=tqdm_auto) as test:
        test.test = test
        test()

# Generated at 2022-06-12 14:35:36.906181
# Unit test for function product
def test_product():
    try:
        iterables = [range(5)] * 3
        with product(*iterables, miniters=1, mininterval=0.1) as _:
            pass
    except Exception:
        raise AssertionError("Not a valid iterator")

# Generated at 2022-06-12 14:35:43.387395
# Unit test for function product
def test_product():
    from .tqdm import trange
    from .utils import FormatCustomText

    i, j, k = range(10), range(10), range(10)
    count = 10

# Generated at 2022-06-12 14:35:49.300574
# Unit test for function product
def test_product():
    """
    Test for `product`
    """
    # pylint: disable=W0612
    a = [1, 2, 3, 4]
    b = [1, 2, 3, 4]
    t = tqdm(
        product(a, b, tqdm_class=tqdm),
        total=len(a) * len(b) * len(a),
        desc="test_product",
        leave=False,
        ascii=True)
    for i, j in t:
        assert i == j, (i, j)

# Generated at 2022-06-12 14:35:52.445642
# Unit test for function product
def test_product():
    """
    Todo:

    - Actually make sure it produces the right product
    - Actually test the progress bar
    """
    import itertools
    assert product([1, 2], [3, 4], [5, 6]
                  ) == itertools.product([1, 2], [3, 4], [5, 6])

# Generated at 2022-06-12 14:36:00.059356
# Unit test for function product
def test_product():
    from .utils import closing
    iterables = [[1, 2], [3, 4, 5]]
    with closing(product(*iterables, total=5)) as pbar:
        assert len(list(pbar)) == len(list(itertools.product(*iterables)))
    # list/tuple doesn't work if no total
    with closing(product(range(4))) as pbar:
        assert len(list(pbar)) == len(list(itertools.product(range(4))))
    with closing(product(*iterables, desc="foobar")) as pbar:
        assert len(list(pbar)) == len(list(itertools.product(*iterables)))

# Generated at 2022-06-12 14:36:06.527968
# Unit test for function product
def test_product():
    import numpy as np
    assert list(product(['a', 'b'], [1, 2])) == [('a', 1), ('a', 2), ('b', 1), ('b', 2)]
    assert list(product([1, 2, 3], repeat=2)) == [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    assert np.sum(list(product([1, 2, 3], repeat=2))) == 36

# Generated at 2022-06-12 14:36:10.181276
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..tests import _test_iterable
    for total in [0, None, 1, 2]:
        for i in _test_iterable(product(range(3), range(3), total=total)):
            pass
        for i in _test_iterable(
                product(range(x), repeat=2, total=total) for x in range(3)):
            pass

# Generated at 2022-06-12 14:36:14.970335
# Unit test for function product
def test_product():
    """
    Note that this test is a bit faster than others because it
    doesn't involve sleep and it's faster to iterate over a range
    than over any other generator
    """
    with tqdm_auto(range(100), leave=False) as t1:
        for _ in t1:
            pass

    with tqdm_auto(range(100), leave=False) as t2:
        for _ in t1 & t2:
            pass

# Generated at 2022-06-12 14:36:23.868757
# Unit test for function product
def test_product():
    import numpy as np
    import re
    import sys
    from ..utils import FormatCustomText

    class MyCounter(FormatCustomText):
        prefix = "custom"
        total = 0
        n = 0

        def __init__(self, *args, **kwargs):
            kwargs["mininterval"] = 0.01
            super(MyCounter, self).__init__(*args, **kwargs)

        def format_meter(self, n, total, elapsed):
            # NOTE: use `total` when available, which sometimes is not known
            self.n = n
            if total is not None:
                assert self.total == 0
                self.total = total
            if total is None:
                assert self.total > 0
            return FormatCustomText.format_meter(self, n, self.total, elapsed)

       

# Generated at 2022-06-12 14:36:25.524692
# Unit test for function product
def test_product():
    from .tests import tests
    return tests.test_product(__file__)

if __name__ == "__main__":
    test_product()