

# Generated at 2022-06-24 09:48:59.379253
# Unit test for function product
def test_product():
    def flatten(l):
        return sum(map(flatten, l), []) if isinstance(l, list) else [l]

    assert list(product([1], [2], [3])), [1, 2, 3]
    assert list(product([1, 2], [3, 4])) == [1, 3, 1, 4, 2, 3, 2, 4]
    assert list(product([1, 2], [3, 4], [5, 6])) == [1, 3, 5, 1, 3, 6,
                                                     1, 4, 5, 1, 4, 6,
                                                     2, 3, 5, 2, 3, 6,
                                                     2, 4, 5, 2, 4, 6]

# Generated at 2022-06-24 09:49:01.706593
# Unit test for function product
def test_product():
    from numpy.testing import assert_almost_equal

    res = product(range(7), range(6), range(5),
                  tqdm_class=tqdm_auto, desc="product")
    res = list(res)
    assert_almost_equal(len(res), 7 * 6 * 5)

# Generated at 2022-06-24 09:49:05.467950
# Unit test for function product
def test_product():
    """Test function product"""
    assert list(product([1, 2], [3, 4], tqdm_class=None)) == \
        list(itertools.product([1, 2], [3, 4]))
    assert list(product([1, 2], tqdm_class=None)) == \
        list(itertools.product([1, 2]))
    assert list(product([1, 2], [], tqdm_class=None)) == \
        list(itertools.product([1, 2], []))

# Generated at 2022-06-24 09:49:09.262219
# Unit test for function product
def test_product():
    import numpy as np
    from ..std import numpy as np_tqdm

    with np_tqdm(total=163) as t:
        for i, j in product(np.arange(2), np.arange(5), np.arange(21)):
            t.update()
    assert t.n == 163

# Generated at 2022-06-24 09:49:19.968319
# Unit test for function product
def test_product():
    from .tests import TestCase

    with TestCase() as testcase:
        for i in product(range(2), tqdm_class=testcase.MockTqdm):
            assert i == (1, 0)
        for i in product(range(0, 5), range(0, 5), tqdm_class=testcase.MockTqdm):
            pass

# Generated at 2022-06-24 09:49:23.061378
# Unit test for function product
def test_product():
    """Test product"""
    import numpy as np

    a = np.arange(100000)
    b = np.arange(100000)
    prod = product(a, b)
    next(prod)
    assert prod.n == 1

# Generated at 2022-06-24 09:49:34.026303
# Unit test for function product
def test_product():
    """Test that the function `product` matches `itertools.product`"""
    import tqdm
    # Ensure that exception is raised
    it = product([], [])
    try:
        next(it)
        assert False, 'product_ is not returning an empty iterator'
    except StopIteration:
        pass

    for iterable in ([1, 2], [1], [], [1, 2, 3]):
        it_prod = product(iterable)
        it_prod_tqdm = product(iterable)
        assert list(it_prod) == list(it_prod_tqdm)
        it_prod_tqdm = product(iterable,
                               tqdm_class=tqdm.tqdm)

# Generated at 2022-06-24 09:49:45.161161
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Test with tqdm as nested iterators
    assert (
        "".join(str(i) for i in tqdm.product(tqdm(range(2)), tqdm(range(2))))
        == "0123"
    )
    # Test with tqdm as a single iterator
    assert "".join(str(i) for i in tqdm.product(range(2), range(2))) == "0123"
    # Test total kwarg
    assert "".join(
        str(i) for i in tqdm.product(range(2), range(2), tqdm_class=tqdm.tqdm)
    ) == "0123"
    # Test without total

# Generated at 2022-06-24 09:49:49.448027
# Unit test for function product
def test_product():
    iterables = [range(100), range(100)]
    for i in product(*iterables):
        assert i[0] < 100 and i[1] < 100
    for i, j in zip(product(*iterables),
                    itertools.product(*iterables)):
        assert i == j

# Generated at 2022-06-24 09:49:58.598640
# Unit test for function product
def test_product():
    """
    Product function unit test.
    """
    from numpy.testing import assert_equal
    from .utils import FormatWrapIter
    import tqdm

    for t in [tqdm.tqdm, tqdm.trange, tqdm.tqdm_gui,
              tqdm.tqdm_notebook, tqdm.tnrange,
              tqdm.trange]:
        a = [0, 1]
        b = ['A', 'B', 'C']
        list(t(product(a, repeat=2)))
        list(t(product(a, b)))
        list(t(product(a, b, ['F'])))
        list(t(product(a, b, ['F'], ['G'])))

# Generated at 2022-06-24 09:50:04.482493
# Unit test for function product
def test_product():
    from .tests.common import SimpleCalc

    it = product(range(10), range(10))
    expected = [tuple([i, j]) for i in range(10) for j in range(10)]
    assert (list(it) == expected)

    it = product(range(10), range(10), tqdm_class=SimpleCalc)
    assert (list(it) == expected)

# Generated at 2022-06-24 09:50:13.016130
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from unittest import TestCase
    from tests_tqdm import with_setup, pretest, posttest, _range

    class TqdmItertoolsTests(TestCase):
        """
        Tests for `tqdm.itertools.product`.
        """

        def test_simple(self):
            """
            Test that the iterator wrapper works
            """
            @with_setup(pretest, posttest)
            def inner():
                it = product(_range(100), _range(100), _range(100))
                self.assertEqual(
                    sum(1 for _ in it), sum(1 for _ in product(
                        _range(100), _range(100), _range(100))))


# Generated at 2022-06-24 09:50:16.663463
# Unit test for function product
def test_product():
    """Test for function product"""
    for i in product(range(4), range(4), tqdm_class=None):
        pass
    for i in product(range(4), range(4)):
        pass

# Generated at 2022-06-24 09:50:23.529063
# Unit test for function product
def test_product():
    """Test that itertools.product behaves like tqdm.product"""
    a = [1, 2, 3]
    b = ['a', 'b', 'c']

    it = product(a, b, tqdm_class=lambda a: a)
    str(it)
    result = list(it)
    assert result == list(itertools.product(a, b))

    it = product(a, b, tqdm_class=tqdm_auto)
    str(it)
    result = list(it)
    assert result == list(itertools.product(a, b))

# Generated at 2022-06-24 09:50:28.480323
# Unit test for function product
def test_product():
    r = product(['a', 'b', 'c'], [1, 2], tqdm_class=tqdm_auto)
    assert type(r) is type(itertools.product(['a', 'b', 'c'], [1, 2]))
    assert list(r) == [('a', 1), ('a', 2), ('b', 1), ('b', 2), ('c', 1), ('c', 2)]

# Generated at 2022-06-24 09:50:38.031084
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from tqdm.utils import _term_move_up

    def product(a, b, c):
        return itertools.product(a, b, c)

    # Test initial total
    with tqdm_auto(total=None) as t:
        assert t.total == None
        assert t.desc == "itertools.product(A, B, C)"
        for _ in product(range(10), range(10), range(10)):
            t.update()
    # Test progress
    with tqdm_auto(total=None, leave=False) as t:
        assert 0 < t.total < 1000
        for _ in product(range(10), range(10), range(10)):
            t.update()
    # Test leave

# Generated at 2022-06-24 09:50:46.399676
# Unit test for function product
def test_product():
    """Test for product()"""
    from ..utils import FormatCustomText
    ITERS = (range(3), range(3), range(3))
    MSI = 0
    FCT = FormatCustomText(desc="_test_desc", total=10)
    with tqdm_auto(**FCT) as t:
        for i in product(*ITERS, tqdm_class=tqdm_auto,
                         **FCT.kwargs):
            assert i[0] == i[1] == i[2]
            assert t.__len__() == i[0]
            if MSI > 0:
                assert t.smoothing == MSI
            MSI += 1

# Generated at 2022-06-24 09:50:56.675682
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..std import StringIO
    from ..utils import _range

    # if no total, it is None
    with tqdm_auto(unit="B", unit_scale=True, miniters=1,
                   file=StringIO()) as t:
        for xi in product(_range(100), _range(100), _range(100)):
            pass
    assert (t.total is None)

    # total is computed
    with tqdm_auto(unit="B", unit_scale=True, miniters=1,
                   file=StringIO()) as t:
        for xi in product(_range(100), _range(100), _range(100),
                          total=None):
            pass
    assert (t.total == 1e6)

    # iterates correctly
    l

# Generated at 2022-06-24 09:50:59.788562
# Unit test for function product
def test_product():
    prod = product(list(range(10)), list(range(10)), tqdm_class=lambda *x: None)
    for i in range(100):
        assert next(prod) == (i // 10, i % 10)

# Generated at 2022-06-24 09:51:08.818407
# Unit test for function product
def test_product():
    try:
        import numpy as np
    except ImportError:
        return None
    import time
    import itertools

    def product_test(a, tqdm_class):
        np.random.seed(1)
        res = []
        for x in tqdm_class(product(a, a, a, a, a, a, a, a, a, tqdm_class=tqdm_class)):
            res.append(x)
        return res

    def product_test_native():
        return list(itertools.product([1, 2, 3, 4], repeat=10))

    assert all([x == y for x, y in zip(
        product_test(range(10), tqdm_class=tqdm_auto),
        product_test_native())])
    # Also test

# Generated at 2022-06-24 09:51:11.135013
# Unit test for function product
def test_product():
    """
    Coverage test.
    """
    from ..utils import StringIO

    list(product(range(3), range(3), range(3),
                 tqdm=StringIO))

# Generated at 2022-06-24 09:51:17.793107
# Unit test for function product
def test_product():
    """Unit test for product"""
    import pytest
    from tqdm import tqdm
    from tqdm._utils import _range

    # Empty iterable
    assert list(product(range(0))) == []

    # Simple x2
    assert list(product(range(3))) == \
        [(0,), (1,), (2,)]

    # Simple x3
    assert list(product(range(2), range(2))) == \
        [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Simple x4
    assert list(product(range(1), range(2), range(2))) == \
        [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1)]

    # Empty inner iterator

# Generated at 2022-06-24 09:51:27.459670
# Unit test for function product
def test_product():
    try:
        import nose
        import nose.tools as nt
    except ImportError:
        return None
    # Simple test for unit conversion
    with nt.assert_raises(TypeError):
        for _ in product(range(3), range(2), range(4), tqdm_class=tqdm_auto):
            pass
    with nt.assert_raises(TypeError):
        for _ in product([], [], tqdm_class=tqdm_auto):
            pass
    # Check product() with no iterables:
    # 'itertools.product()' with no arguments returns an empty iterator
    with nt.assert_raises(StopIteration):
        next(product())

    # Test multiple arguments, including empty iterables.
    p = product([0, 1], [2], [])


# Generated at 2022-06-24 09:51:30.429057
# Unit test for function product
def test_product():
    assert list(product(range(3), repeat=3, tqdm_class=None)) == \
        list(itertools.product(range(3), repeat=3))

# Generated at 2022-06-24 09:51:40.464191
# Unit test for function product
def test_product():
    import numpy as np
    assert np.array_equiv(
        list(product(range(3), range(3), range(3),
                     tqdm_class=tqdm_auto,
                     total=3 ** 3)),
        list(itertools.product(range(3), range(3), range(3))))
    assert np.array_equiv(
        list(product(range(3), range(3), range(3),
                     tqdm_class=tqdm_auto)),
        list(itertools.product(range(3), range(3), range(3))))

# Generated at 2022-06-24 09:51:46.394594
# Unit test for function product
def test_product():
    from numpy import product as np_product
    from numpy import reshape as np_reshape
    from numpy import arange as np_range

    for N in range(4):
        for M in range(4):
            for K in range(4):
                a = np_range(N * M * K)
                a = np_reshape(a, (N, M, K))
                b = list(product(a, tqdm_class=tqdm_auto))
                assert np_product(a) == np_product(b)


del absolute_import, itertools  # cleanup namespace

# Generated at 2022-06-24 09:51:49.325909
# Unit test for function product
def test_product():
    assert list(product(range(5), range(5))) == [(x, y) for x in range(5) for y in range(5)]

# Generated at 2022-06-24 09:51:59.483710
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from .tests_tqdm import closing, func_name, range
    from .std_wrapper import StringIO

    with closing(StringIO()) as our_file:
        for _ in product(['a', 'b', 'c', 'd'], repeat=2,
                         file=our_file, miniters=1, mininterval=0.1,
                         tqdm_class=tqdm_auto):
            pass
        assert (our_file.getvalue() ==
                func_name(tqdm_auto, total=16) +
                func_name(tqdm_auto, total=16, leave=True))

    # Empty iterator

# Generated at 2022-06-24 09:52:05.681950
# Unit test for function product
def test_product():
    """Unit test for function `itertools.product`"""
    from numpy.random import randint
    total = 0
    for _ in product(range(10), range(1, 1000)):
        total += 1
    assert (total == 10 * 999)


# Needs multiprocessing for test

# Generated at 2022-06-24 09:52:11.534114
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # No total
    for x in product(range(1e4)):
        assert isinstance(x, int)
    # Specified total
    for x in product(range(1e4), total=1e4):
        assert isinstance(x, int)
    # Specified total and tqdm_class
    for x in product(range(1e4), total=1e4, tqdm_class=tqdm_auto):
        assert isinstance(x, int)

# Generated at 2022-06-24 09:52:20.797731
# Unit test for function product
def test_product():
    """ Unit test for function product. """
    test_list = ['abc', [1, 2, 3], [5, 6, 7]]
    test_list_ans = (('abc', 1, 5), ('abc', 1, 6), ('abc', 1, 7),
                     ('abc', 2, 5), ('abc', 2, 6), ('abc', 2, 7),
                     ('abc', 3, 5), ('abc', 3, 6), ('abc', 3, 7))
    for t in product(*test_list, total=9, disable=False):
        assert t in test_list_ans
    for t in product(*test_list, total=8, disable=False):
        assert t in test_list_ans
    for t in product(*test_list, total=7, disable=False):
        assert t in test_list_ans

# Generated at 2022-06-24 09:52:24.595313
# Unit test for function product
def test_product():
    for i in product(range(4), range(4), range(4),
                     tqdm_class=tqdm_auto,
                     leave=False,
                     disable=False,
                     ncols=80):
        assert i[0] < 4
        assert i[1] < 4
        assert i[2] < 4

# Generated at 2022-06-24 09:52:32.501377
# Unit test for function product
def test_product():
    import numpy as np
    import math
    assert 0 not in product(range(2), [1])

    len(list(product(range(1000), [None])))
    len(list(product(range(1000), [None], total=None)))
    len(list(product(range(1000), [None], total=1000)))
    len(list(product(range(1000), [None], total=1000.0)))
    len(list(product(range(1000), [None], total=math.inf)))
    len(list(product(range(1000), [None], total=np.inf)))


# Generated at 2022-06-24 09:52:41.886999
# Unit test for function product
def test_product():
    """Unit test for function product."""
    from .utils import _range
    from .tqdm import tqdm

    # Testing with a list of iterables
    for i in product(range(3), range(4), range(5)):
        pass

    a = tqdm(product(range(3), range(4), range(5)))
    assert len(list(a)) == 3 * 4 * 5
    assert a.n == 3 * 4 * 5

    a = tqdm(product(range(3), range(4), range(5), tqdm_class=tqdm))
    assert len(list(a)) == 3 * 4 * 5
    assert a.n == 3 * 4 * 5

    # Testing with an iterator
    a = tqdm(_range(3), _range(4), _range(5))


# Generated at 2022-06-24 09:52:49.698388
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    def product_gen(**tqdm_kwargs):
        for i in product(range(10), [None] * 11, "abcd",
                         tqdm_class=tqdm_auto, **tqdm_kwargs):
            yield i
    for i in range(10000):
        gen = product_gen(miniters=i)
        a = 0
        while hasattr(gen, "__next__"):
            try:
                next(gen)
            except StopIteration:
                break
            else:
                a += 1
    assert a >= 10 * 11 * 4 * 10000

# Generated at 2022-06-24 09:52:56.841577
# Unit test for function product
def test_product():
    import numpy as np
    import time
    from ..utils import format_sizeof

    def test():
        np.random.seed(10)
        n = 3
        m = 4
        for i in product(range(n), range(m)):
            time.sleep(0.01 * np.random.random())

    print("Unit test for function product:")
    print("  1G array:", format_sizeof(np.arange(1e9)))
    print("  3x4 grid:", format_sizeof(np.arange(n * m)))
    time.sleep(0.05)
    print("\n")
    test()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:53:07.051308
# Unit test for function product
def test_product():
    """ Unit tests of the `product` function. """
    from ..utils import FormatCustomText
    from .example_iterable import ExampleIterable
    from .tests_utils import check_meta

    # Empty
    for x in product():
        assert False, "this should never be run"

# Generated at 2022-06-24 09:53:13.782223
# Unit test for function product
def test_product():
    import sys
    if sys.version_info < (3,):
        from StringIO import StringIO
    else:
        from io import StringIO
    for _ in product('AB', 'cd', tqdm_class=tqdm_auto,
                     bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]",
                     file=StringIO()):
        pass

# Generated at 2022-06-24 09:53:19.668192
# Unit test for function product
def test_product():
    with tqdm_auto(total=10 ** 4) as t:
        for _ in product(range(10), tqdm_class=tqdm_auto):
            pass
    with tqdm_auto(total=12) as t:
        for _ in product(range(3), range(4), tqdm_class=tqdm_auto):
            pass

# Generated at 2022-06-24 09:53:27.748355
# Unit test for function product
def test_product():
    from time import sleep
    for m in product('ABC', repeat=2, tqdm_class=tqdm_auto):
        sleep(0.05)


if __name__ == '__main__':
    """
    Example of use:
    import tqdm.itertools
    for i in tqdm.itertools.product(*[range(10)] * 8):
    pass
    """
    import tqdm.itertools
    with tqdm.itertools.product(*[range(10)] * 8) as t:
        for i in t:
            pass

# Generated at 2022-06-24 09:53:35.889261
# Unit test for function product
def test_product():
    from math import factorial as fact
    import sys
    import doctest
    import numpy as np

    verbose = True
    # do not use class-scope variables
    verbose = False
    kwargs = dict(total=None, tqdm_class=tqdm_auto,
                  desc="Test product")
    print("NumPy (last col) vs tqdm (last col):")
    print("")
    # test_list = [1, 2, 3]
    # test_list = [1, 2, 3, 4, 5]
    # test_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    test_list = [1, 2, 3, 4, 5, 6]
    test_list2 = [7, 8, 9]

# Generated at 2022-06-24 09:53:46.237258
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import time
    try:
        import numpy as np
    except ImportError:
        return None
    # test iterables
    a = np.arange(3.)
    b = [1, 2.]
    c = [3]
    d = ['a', 'b']
    # test yields
    a_yields = np.array([[0., 1., 2.], [0., 1., 0.], [0., 1., 3.]])
    b_yields = np.array([[1., 1., 1.], [2., 2., 2.], [1., 1., 3.]])
    c_yields = np.array([[3., 3., 3.], [3., 3., 1.], [3., 3., 2.]])
    d_

# Generated at 2022-06-24 09:53:54.644648
# Unit test for function product
def test_product():
    from ._utils import TestCase, _range

    class TestProduct(TestCase):
        def test_exception(self):
            from numpy import prod
            from itertools import product
            from tqdm.autonotebook import tqdm

            for i in product(_range(2), _range(2), _range(2)):
                pass
            self.assertEqual(i, (1, 1, 1))

            for i in product(*(_range(2),) * 15):
                pass
            self.assertEqual(i, (1,) * 15)

            for i in product(_range(2), ['a', 'b'], [1, 2]):
                pass
            self.assertEqual(i, (1, 'b', 2))


# Generated at 2022-06-24 09:54:04.293583
# Unit test for function product
def test_product():
    assert list(product(*[[10, 20, 30], [4, 5], [8, 9]], desc="Test")) == [(10, 4, 8), (10, 4, 9), (10, 5, 8), (10, 5, 9), (20, 4, 8), (20, 4, 9), (20, 5, 8), (20, 5, 9), (30, 4, 8), (30, 4, 9), (30, 5, 8), (30, 5, 9)]

# Generated at 2022-06-24 09:54:15.130683
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import random
    import sys
    import time

    #import tqdm
    from ..auto import tqdm

    with tqdm(total=10, file=sys.stderr, ncols=45, ascii=True) as pbar:
        for i in product(range(10000), range(10000),
                         tqdm_kwargs=dict(disable=False, total=10)):
            pbar.update()
            time.sleep(0.000001 * random.random() * (10 - pbar.n))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:54:21.655351
# Unit test for function product
def test_product():
    """ Unit test for function product """
    assert list(product(range(3), ["a", "b", "c"])) == \
        [(0, 'a'), (0, 'b'), (0, 'c'), (1, 'a'), (1, 'b'), (1, 'c'),
         (2, 'a'), (2, 'b'), (2, 'c')]

    assert list(product([], ["a", "b", "c"])) == []
    assert list(product([1], ["a", "b", "c"])) == \
        [(1, 'a'), (1, 'b'), (1, 'c')]

# Generated at 2022-06-24 09:54:28.577641
# Unit test for function product
def test_product():
    import random
    import string
    import time

    def gen_iter():
        l = random.randint(1, 7)
        iterables = [
            range(random.randint(1, 11))
            for _ in range(l)
        ]
        yield iterables

    for iterables in gen_iter():
        for tqdm_cls in [tqdm_auto, tqdm_stdout_override]:
            a = []
            b = []
            for _ in product(*iterables, tqdm_class=tqdm_cls):
                a.append(_)
            for _ in itertools.product(*iterables):
                b.append(_)
            assert a == b

# Generated at 2022-06-24 09:54:34.216559
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    for i in product('AB', [1, 2], tqdm_class=tqdm_auto):
        pass
    for i in product('ABCDE', [1, 2, 3], tqdm_class=tqdm_auto):
        pass
    for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:54:44.130596
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import EmptyClass
    from numpy import prod
    from numpy.testing import assert_array_equal

    from .tests_tqdm import pretest_posttest, closing

    def _prod(it):
        """
        List the product of an iterable of iterables
        """
        return [i for i in product(*it)]

    class _prod_klass(EmptyClass):
        """
        List the product of an iterable of iterables
        """
        def __init__(self, it):
            self.it = it

        def __iter__(self):
            return product(*self.it)

    def _product(*iterables):
        """
        List the product of an iterable of iterables
        """

# Generated at 2022-06-24 09:54:54.783923
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import (assert_equal,
                               assert_almost_equal,
                               assert_allclose,
                               assert_array_equal,
                               assert_array_less)

    from .tests_tqdm import with_unit_option, with_unit_options, pretest_posttest_print

    with_unit_option(unit='iB', unit_scale=True)
    with with_unit_options(unit='iB', unit_scale=False):
        with with_unit_options(unit='iB', unit_scale=True):
            # Test: itertools.product
            assert_equal(list(product(())), [()])
            assert_equal(list(product([0])), [(0,)])

# Generated at 2022-06-24 09:55:03.371636
# Unit test for function product
def test_product():
    from .version import __version__
    from .utils import _range

    for i in product(_range(100), _range(100)):
        pass

    # test total
    for i in product(_range(100), _range(100), _range(100)):
        pass

    # test desc
    for i in product(_range(100), _range(100), desc="xyz"):
        pass

    # test total=0
    for _ in product(_range(100), _range(100), total=0):
        raise Exception("You should not have gotten here!")

    # test tqdm_class
    for i in product(_range(100), _range(100),
                     tqdm_class=tqdm_auto):
        pass

    # test nested tqdm_class

# Generated at 2022-06-24 09:55:12.408033
# Unit test for function product
def test_product():
    """Test for function product"""
    from .tests import closing, nested_tqdm
    # Check that the number of iterations is correct
    with closing(nested_tqdm(total=8, desc="a")) as t:
        for _ in product(tqdm_class=t.__class__, iterables=[range(2), range(4)]):
            pass
    # Check that the progress bar works as expected
    with closing(nested_tqdm(total=8, desc="a")) as t:
        for i, j in product(tqdm_class=t.__class__, iterables=[range(2), range(4)]):
            assert 0 <= i < 2
            assert 0 <= j < 4

# Generated at 2022-06-24 09:55:24.569460
# Unit test for function product
def test_product():
    from random import randint
    from sys import version_info as sys_version_info
    from tqdm.autonotebook import tqdm
    from .tests_tqdm import pretest_posttest_pass, closing

    def prod(range_, *iterables, **kwargs):
        """itertools.product() equivalent with a progressbar"""
        return product(range_, *iterables, **kwargs, tqdm_class=tqdm)

    # Simple tests
    with closing(tqdm(total=1)) as t:
        assert len(list(product([0], [1], tqdm=t))) == 1
        assert len(list(product([0], ['a'], tqdm=t))) == 1
        t.update()

# Generated at 2022-06-24 09:55:27.332940
# Unit test for function product
def test_product():
    import numpy as np
    for i in product(np.arange(10), np.arange(10)):
        pass
    for i in product(np.arange(10), np.arange(10), tqdm_class=None):
        pass

# Generated at 2022-06-24 09:55:33.680207
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.random import randint

    for i in product(range(10)):
        assert i == 0

    for i in product(range(10), range(10)):
        assert i == (0, 0)

    for i in product(randint(2, size=10), range(10)):
        assert i == (0, 0)

# Generated at 2022-06-24 09:55:44.793270
# Unit test for function product
def test_product():
    """
    Test function `product`.
    """
    import numpy as np
    from ..utils import format_sizeof

    assert np.all(list(product([])) == [()])
    assert np.all(list(product([1])) == [(1,)])
    assert np.all(list(product([1, 2])) == [(1, 2), (1, 2)])
    assert np.all(list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)])

# Generated at 2022-06-24 09:55:50.404679
# Unit test for function product
def test_product():
    """Test function product"""
    import numpy as np
    np.random.seed(1)
    for i in product(
        [np.random.random((10, 10)) for _ in range(4)],
        iterable=1,
        tqdm_class=tqdm_auto,
    ):
        pass

# Generated at 2022-06-24 09:55:55.393977
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..utils import format_sizeof
    from ..std import BytesIO
    import sys

    def test(x, y, z, tqdm_class=tqdm_auto, total=None):
        o = BytesIO()
        t = tqdm_class(total=total, file=o, positional_args=False)

# Generated at 2022-06-24 09:55:59.563820
# Unit test for function product
def test_product():
    from .tests import TestCase

    with TestCase():
        assert list(product(range(2), range(2), range(2), range(2),
                            tqdm_class=tqdm_auto, disable=True)) \
            == [i for i in itertools.product(range(2), range(2), range(2),
                                             range(2))]

# Generated at 2022-06-24 09:56:05.369986
# Unit test for function product
def test_product():
    "Test the product() wrapper"
    from ..tqdm import trange

    assert list(product(trange(10), trange(10))) == list(itertools.product(
        trange(10), trange(10)))


if __name__ == "__main__":
    from ..tqdm import tqdm

    for _ in product(tqdm(range(3)), repeat=3):
        pass

# Generated at 2022-06-24 09:56:12.948826
# Unit test for function product
def test_product():
    from ._utils import _range
    from ._utils import _raise

    func = product

    # Test tqdm_class
    class Tqdm(tqdm_auto):
        def __init__(self, **kwargs):
            kwargs.setdefault('disable', True)
            super(Tqdm, self).__init__(**kwargs)

    assert list(func([1], [2], [3], tqdm_class=Tqdm, total=3)) == [(1, 2, 3)]
    assert list(func([1], [2], [3], tqdm_class=Tqdm, total=2)) == [(1, 2, 3)]
    assert list(func([1], [2], [3], tqdm_class=Tqdm)) == [(1, 2, 3)]

    # No total


# Generated at 2022-06-24 09:56:17.636829
# Unit test for function product
def test_product():
    '''Unit test for function product'''
    from nose.tools import assert_equal
    from itertools import product as std_product

    for a in [[1, 2, 3], ['a', 'b'], []]:
        for b in [[4, 5], ['c', 'd'], []]:
            for c in [[], ['e'], [6, 7]]:
                assert_equal(list(product(a, b, c)),
                             list(std_product(a, b, c)))

# Generated at 2022-06-24 09:56:23.508133
# Unit test for function product
def test_product():
    list_ = [1, 2, 3]
    product_ = product(list_, tqdm_class=tqdm_auto.tqdm_gui)
    for i in product_:
        pass

# Generated at 2022-06-24 09:56:27.134424
# Unit test for function product
def test_product():
    """Unit test for function 'product'."""
    with tqdm_auto(unit='t', desc='test_product') as t:
        # Start
        for i in product(range(10), range(5), range(3), unit='t',
                         desc='test_product'):
            t.update()

# Generated at 2022-06-24 09:56:36.276589
# Unit test for function product
def test_product():
    from .common import closing, SimpleTextIOWrapper

    for iterable in (list, range):
        for total in (None, 10, 20):
            for desc in (None, "desc", "desc with spaces"):
                for initial in (None, 0):
                    for ncols in (None, 80):
                        with closing(SimpleTextIOWrapper()) as s:
                            p = product(iterable(range(total)),
                                        desc=desc, initial=initial)
                            for _ in p:
                                pass
                            s.seek(0)
                            pbar = s.read()[:-1]
                            if total is None:
                                assert not pbar.endswith("%")
                            else:
                                assert pbar.endswith("%")

# Generated at 2022-06-24 09:56:44.494658
# Unit test for function product
def test_product():
    from .utils import FormatMixin
    from .tqdm_pandas import tqdm_pandas

    class TqdmTest(FormatMixin, tqdm_auto):
        pass

    with TqdmTest(unit="it", dynamic_ncols=True) as t:
        for x in product([0, 1],
                         [1, 2],
                         [2, 3],
                         [3, 4],
                         tqdm_class=tqdm_pandas):
            t.update(1)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:56:53.746173
# Unit test for function product
def test_product():
    from .utils import format_sizeof

    # Non-memory-intensive
    for i in product(range(3), range(4), range(5)):
        assert len(i) == 3
    for i in product(range(3), range(4), range(5), tqdm_class=tqdm_auto):
        assert len(i) == 3

    # Memory-intensive
    import random
    import tempfile

    random.seed(0)
    with tempfile.NamedTemporaryFile() as f:
        for i in product(range(3), range(3), tqdm_class=tqdm_auto,
                         total=9, unit_scale=True):
            f.write(("%d\n" % i).encode("ascii"))
        f.flush()
        size = format_sizeof

# Generated at 2022-06-24 09:56:58.747226
# Unit test for function product
def test_product():
    """import tqdm; from tqdm.itertools import product; list(product('ABC', 'ghi'))"""
    with tqdm_auto.tqdm(['ABC', 'ghi']) as t:
        for i in itertools.product('ABC', 'ghi'):
            assert i
            t.update()

# Generated at 2022-06-24 09:57:05.627322
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    try:
        from _test_itertools import test_product
        test_product()
    except ImportError:
        from nose.tools import assert_equal
        from numpy.random import random
        from .utils import format_sizeof
        from .utils import format_interval
        # tests
        a = range(2)
        b = range(3)
        c = range(4)

        assert_equal(
            list(product(a, b, c)),
            list(itertools.product(a, b, c)))
        assert_equal(
            list(product(a, b, c, tqdm_class=None)),
            list(itertools.product(a, b, c)))

# Generated at 2022-06-24 09:57:07.333876
# Unit test for function product
def test_product():
    for x in product(range(3), range(3), tqdm_class=None):
        assert x == (0, 0)
        break

# Generated at 2022-06-24 09:57:10.253344
# Unit test for function product
def test_product():
    assert list(product(range(10), range(10))) == \
        list(itertools.product(range(10), range(10)))

# Generated at 2022-06-24 09:57:20.381310
# Unit test for function product

# Generated at 2022-06-24 09:57:29.303061
# Unit test for function product
def test_product():
    import numpy
    numpy.random.seed(42)

    expected_result = []
    for i in range(5):
        inner_list = []
        for j in range(5):
            inner_list.append(i*5 + j)
        expected_result.append(tuple(inner_list))

    result = []
    for i in product(range(5), range(5), range(5), range(5), range(5), tqdm_class=None):
        result.append(i)

    numpy.testing.assert_array_equal(result, expected_result)

# Generated at 2022-06-24 09:57:34.521690
# Unit test for function product
def test_product():
    for i in product(range(100), repeat=100, tqdm_class=tqdm_auto):
        pass


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:57:42.610900
# Unit test for function product
def test_product():
    iterables = [[1, 2, 3], [1, 2, 3], [1, 2, 3]]
    tqdm_kwargs = dict(tqdm_class=tqdm_auto)
    assert set(product(*iterables, **tqdm_kwargs)) == \
           set(itertools.product(*iterables))

    iterables = [[1, 2, 3], "abcd", ['a', 2, 3.0]]
    assert list(product(*iterables, **tqdm_kwargs)) == \
           list(itertools.product(*iterables))

if __name__ == "__main__":
    from nose import runmodule
    runmodule()

# Generated at 2022-06-24 09:57:52.159490
# Unit test for function product
def test_product():
    """
    .. code-block:: python

        params = [range(3)] * 3
        for prod in tqdm.product(*params):
            pass

        # ``params`` can be any iterable object
        # so``tqdm`` can control the range of len()
        from itertools import product
        import string

        params = [string.ascii_uppercase[:5]] * 5
        for prod in tqdm(product(*params)):
            pass
    """
    for prod in product(range(3), repeat=3):
        pass

    from itertools import product
    import string

    for prod in product(*[string.ascii_uppercase[:5]] * 5):
        pass

# Generated at 2022-06-24 09:57:58.118444
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np
    assert list(product([1, 2, 3], repeat=2)) == list(itertools.product([1, 2, 3], repeat=2))
    assert list(product(range(10))) == list(itertools.product(range(10)))
    assert list(product(range(10), range(10))) == list(itertools.product(range(10), range(10)))
    assert list(product(range(10), range(10), range(10))) == list(itertools.product(range(10), range(10), range(10)))

# Generated at 2022-06-24 09:58:07.042566
# Unit test for function product
def test_product():
    """
    Unit test for function product.

    It must NOT produce any line in the progress bar.
    """
    list(product(range(0), range(0)))
    list(product(range(1), range(1)))
    list(product(range(3), range(3)))
    list(product(range(3), range(3), tqdm_class=tqdm_auto.tqdm_gui))
    list(product(range(3), range(3), tqdm_class=tqdm_auto.tqdm_notebook))
    list(product(range(3), range(3), tqdm_class=tqdm_auto.tqdm_pandas))

# Generated at 2022-06-24 09:58:11.130461
# Unit test for function product
def test_product():
    """Test product"""
    list_of_lists = [[1, 2, 3, 4], [5, 6, 7], [8, 9], [10]]
    assert list(product(list_of_lists)) == list(itertools.product(*list_of_lists))

# Generated at 2022-06-24 09:58:18.167484
# Unit test for function product
def test_product():
    from random import randrange
    from textwrap import dedent
    from itertools import chain
    for x in [0, 1, 2, 3, 10, 10**4]:
        for y in [0, 1, 2, 3, 10, 10**4]:
            for z in [0, 1, 2, 3, 10, 10**4]:
                a = list(tqdm.tqdm.product(range(x), range(y), range(z)))
                b = list(tqdm.tqdm.product(range(x), range(y), range(z),
                                           total=1))
                c = list(tqdm.tqdm.product(range(x), range(y), range(z),
                                           total=x * y * z))

# Generated at 2022-06-24 09:58:24.437949
# Unit test for function product
def test_product():
    """
    Unit test for function product

    It checks that the output of :func:`itertools.product` is the one of
    :func:`itertools.product`
    """
    for i in product([1], ['a', 'b', 'c'], range(2)):
        assert i in list(itertools.product([1], ['a', 'b', 'c'], range(2)))

# Generated at 2022-06-24 09:58:34.015200
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # Define the class to be tested & control class
    class TestTqdm(tqdm_auto):
        def __init__(self, *args, **kwargs):
            self.cnt = 0
            self.smoothing = 0
            self.leave = False
            self.desc = None
            self.miniters = self.mininterval = 0
            self.maxinterval = 10 ** 6
            self.update_to(0)

        def update(self, *args, **kwargs):
            super(TestTqdm, self).update(*args, **kwargs)
            self.cnt += 1

        def update_to(self, n):
            self.n = n

    TClass = TestTqdm
    # Test non-optional args:

# Generated at 2022-06-24 09:58:40.006311
# Unit test for function product
def test_product():
    from numpy.random import randint
    N = randint(2, 4)
    M = randint(5, 10)
    res1 = set()
    res2 = set()
    res3 = set()
    for x in product('abc', repeat=N):
        res1.add(x)
    x = list(product('abc', repeat=N, tqdm_class=lambda x: None))
    for x in x:
        res2.add(x)
    for x in product('abc', repeat=M):
        res3.add(x)
    assert set(x) == set(product('abc', repeat=N))
    assert res1 == res2
    assert res3 >= res1

# Generated at 2022-06-24 09:58:45.349376
# Unit test for function product
def test_product():
    """Unit test for product"""
    from numpy import arange
    from numpy.testing import assert_almost_equal
    from .utils import SimpleProgress
    iterations = []
    for a in product(arange(10), arange(10), tqdm_class=SimpleProgress):
        iterations.append(a)

    expected_results = [(i, j) for i in range(10) for j in range(10)]
    assert_almost_equal(iterations, expected_results)

# Generated at 2022-06-24 09:58:54.694371
# Unit test for function product
def test_product():
    """Tests `tqdm.product` with `tqdm.auto.tqdm` by default."""
    try:
        from itertools import izip as zip
        range = xrange
    except ImportError:
        try:
            from itertools import zip_longest as zip
        except ImportError:
            pass
    res = list(zip(range(3), range(3, 6), range(6, 9)))
    assert list(product(range(3), range(3, 6), range(6, 9))) == res
    assert list(product(range(3), range(3, 6), range(6, 9), tqdm_class=None)) == res