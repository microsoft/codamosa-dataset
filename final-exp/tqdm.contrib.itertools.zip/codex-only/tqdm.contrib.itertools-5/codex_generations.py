

# Generated at 2022-06-24 09:48:58.064632
# Unit test for function product
def test_product():
    try:
        from numpy import prod
        from . import tqdm
    except ImportError:
        return
    for i in tqdm.product(range(10), range(10)):
        pass
    assert tqdm.format_sizeof(i) == "0 KiB"
    assert i == (9, 9)
    i = tqdm.product(range(10), range(10))
    assert tqdm.format_sizeof(i)
    assert next(i) == (0, 0)
    assert tqdm.format_sizeof(i) == "88 B"
    assert i.n == 1
    assert not i.sp(1)
    assert i.sp(2)
    assert i.sp(3)
    assert i.sp(2)
    assert i.sp(3)


# Generated at 2022-06-24 09:49:07.144305
# Unit test for function product
def test_product():
    """
    Unit tests for tqdm.itertools.
    """
    from ._utils import RandomArtificialError, RandomSleepIter
    from tqdm.test import TestCase

    ds = RandomSleepIter()
    p = list(product(ds, ds))
    assert len(p) == len(ds) ** 2

    class SleepExc(RandomArtificialError, RandomSleepIter):
        pass

    ds = SleepExc()
    p = list(product(ds, ds, tqdm_class=tqdm_auto))
    assert len(p) <= len(ds) ** 2

    class SleepExc(RandomArtificialError, RandomSleepIter):
        pass

    ds = SleepExc()
    p = list(product(ds, ds, tqdm_class=tqdm_auto))
    assert len

# Generated at 2022-06-24 09:49:11.887400
# Unit test for function product
def test_product():
    """Test the `tqdm.product` function"""
    a = [1, 2]
    b = [1, 2]
    c = []
    assert list(product(a, b)) == list(itertools.product(a, b))
    assert list(product(a, b, tqdm=lambda x: x)) == list(itertools.product(a, b))
    assert list(product(a, b, tqdm_class=tqdm_auto)) == list(itertools.product(a, b))
    assert list(product(a, c)) == list(itertools.product(a, c))
    assert list(product(a, c, tqdm=lambda x: x)) == list(itertools.product(a, c))

# Generated at 2022-06-24 09:49:22.444203
# Unit test for function product
def test_product():
    from random import random
    from time import sleep

    try:
        from numpy import product
    except ImportError:
        def product(iterable):
            n = 1
            for i in iterable:
                n *= i
            return n

    vals = [random() for i in range(10)]
    len_vals = [len(vals) for i in range(10)]

    it = product(vals, len_vals)
    assert sum(it) == product(vals) * product(len_vals)

    it = product(vals, len_vals)
    assert sum(it) == product(vals) * product(len_vals)

    for _ in tqdm_auto(it):
        sleep(0.01)

    it = product(vals, len_vals)

# Generated at 2022-06-24 09:49:24.728157
# Unit test for function product
def test_product():
    product(*(range(i) for i in range(2, 5)), tqdm_class=tqdm_auto)()


__all__.append('izip')



# Generated at 2022-06-24 09:49:27.529516
# Unit test for function product
def test_product():
    """Unit test for function product"""
    rounds = 2000
    for _ in product(range(rounds), range(rounds),
                     tqdm_class=tqdm_auto, desc="test_product"):
        pass

# Generated at 2022-06-24 09:49:32.124941
# Unit test for function product
def test_product():
    from .tests import test_product
    from .tests import closed as resource_closed
    with resource_closed("sys.stdout"):  # unittest.mock.patch() doesn't work
        test_product(itertools.product, product)

# Generated at 2022-06-24 09:49:37.910914
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatMixin

    class Progress(FormatMixin):
        def __init__(self):
            self.values = []

        def display(self, value, bar_style):
            self.values.append(value)

    p = Progress()
    total = 0
    for i in product(range(10), range(10), range(10), range(10), tqdm_class=p):
        assert i == tuple(map(lambda x: x, i))
        total += 1

    assert total == 10000
    return

# Generated at 2022-06-24 09:49:44.974431
# Unit test for function product
def test_product():
    import numpy as np
    import tqdm.auto
    assert list(map(np.mean,
                    tqdm.auto.product(np.arange(3),
                                      np.arange(3),
                                      np.arange(3),
                                      tqdm_class=tqdm.auto.tqdm))) == [
                                          4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0, 4.0,
                                          4.0
                                      ]

# Generated at 2022-06-24 09:49:53.898849
# Unit test for function product
def test_product():
    """
    Equivalent of `itertools.product`.

    Parameters
    ----------
    tqdm_class  : [default: tqdm.auto.tqdm].
    """
    mylst1 = list(range(10))
    mylst2 = list(range(11))
    res = itertools.product(mylst1, mylst2)
    for i in res:
        i = 0
    res1 = list(product(mylst1, mylst2))
    for i in res1:
        i = 0
    res1 = list(product(mylst1, mylst2, tqdm_class=None))
    for i in res1:
        i = 0

# Generated at 2022-06-24 09:49:58.990810
# Unit test for function product
def test_product():
    "Unit test for function product"
    r = product(range(10), range(10))
    assert list(r) == list(itertools.product(range(10), range(10)))

    r = product(range(10), range(10), tqdm_class=False)
    assert list(r) == list(itertools.product(range(10), range(10)))


if __name__ == "__main__":  # pragma: no cover
    test_product()

# Generated at 2022-06-24 09:50:06.455348
# Unit test for function product
def test_product():
    """Test function product"""
    test_items = ['abc', 'def']
    length_test_items = [1, 2, 3]
    test_items_final = ['abc', 'def', 'ghi', 'jkl', 'mno', 'pqr']
    for _ in product(test_items, length_test_items):
        pass
    for i, _ in enumerate(product(test_items, length_test_items,
                                  total=len(test_items) * len(length_test_items))):
        assert i == test_items_final[i]

# Generated at 2022-06-24 09:50:12.431122
# Unit test for function product
def test_product():
    a = range(1000000)
    b = range(10)
    p = product(a)
    res = [x + 1 for x in a]
    assert [x for x in p] == res
    p = product(a, b)
    res = list(itertools.product(a, b))
    assert len(res) == len(a) * len(b)
    assert [x for x in p] == res
    p = product(a, b, tqdm_class=None)
    assert [x for x in p] == res

# Generated at 2022-06-24 09:50:22.842911
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    from . import tqdm
    assert list(tqdm.product(range(10), range(10))) == list(itertools.product(range(10), range(10)))
    assert list(tqdm.product(range(10), range(10))) == list(tqdm.product(range(10), range(10), tqdm_class=tqdm.tqdm))
    assert list(tqdm.product(range(10), range(10))) == list(tqdm.product(range(10), range(10), tqdm_class=tqdm.tqdm))

# Generated at 2022-06-24 09:50:25.656290
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    with tqdm_auto(total=6) as t:
        for i in product(range(2), range(3)):
            assert len(i) == 2
            t.update()

# Generated at 2022-06-24 09:50:26.829415
# Unit test for function product
def test_product():
    for a in product('123', 'ab', tqdm_class=tqdm_auto):
        assert a[0] in '123'
        assert a[1] in 'ab'

# Generated at 2022-06-24 09:50:33.661338
# Unit test for function product
def test_product():
    """Test function `product`."""
    # All combinations of 2 lists
    assert list(product('ABC', 'DEF')) == [('A', 'D'), ('A', 'E'), ('A', 'F'),
                                           ('B', 'D'), ('B', 'E'), ('B', 'F'),
                                           ('C', 'D'), ('C', 'E'), ('C', 'F')]
    # All combinations of 2 strings
    assert list(product('ABC', 'DEF')) == [('A', 'D'), ('A', 'E'), ('A', 'F'),
                                           ('B', 'D'), ('B', 'E'), ('B', 'F'),
                                           ('C', 'D'), ('C', 'E'), ('C', 'F')]
    # All combinations of a string and 4 lists

# Generated at 2022-06-24 09:50:44.717340
# Unit test for function product
def test_product():
    import sys
    import numpy as np
    from io import BytesIO as OuterBytesIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = OuterBytesIO(), OuterBytesIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-24 09:50:50.233475
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    from ..std import next
    from itertools import count, chain, repeat, cycle

    class TestException(Exception):
        pass

    with tqdm_auto(total=5) as t:
        for _ in product(range(5), start=t.n):
            # avoid iteration to let progress bar reach 100%
            break

    with tqdm_auto(total=5) as t:
        for _ in product(range(5), start=t.n):
            # avoid iteration to let progress bar reach 100%
            break

    with tqdm_auto(total=5) as t:
        for _ in t.product(range(5)):
            # avoid iteration to let progress bar reach 100%
            break


# Generated at 2022-06-24 09:51:00.194974
# Unit test for function product
def test_product():
    """Test that product() returns the same result as itertools.product()"""
    import itertools
    import numpy as np
    import numpy.testing as npt
    import time

    np.random.seed(123456)

    def decode(x):
        if isinstance(x, bytes):
            return x.decode("utf-8")
        return x

    def check(x, y):
        npt.assert_array_equal(np.array(list(map(decode, x))), y)
        return 0

    def run(list_):
        print("")

        def dotproduct(list_):
            return check(product(*list_),
                         itertools.product(*list_))

        print(dotproduct(list_))


# Generated at 2022-06-24 09:51:09.271832
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .utils import UnknownLength
    from .formatters import format_interval
    from .pandas import trange
    items = [
        range(5),
        range(5, 10),
        range(10, 20, 3)
    ]
    n = 1
    for i in items:
        n *= len(i)
    assert UnknownLength not in (n, )
    with trange(n) as t:
        t.set_description("itertools.product({})".format(
            ", ".join(map(str, map(len, items)))))
        for it in product(*items):
            if t.n == 0:
                assert it == (0, 5, 10)

# Generated at 2022-06-24 09:51:13.056544
# Unit test for function product
def test_product():
    product('abc', range(4))
    product('abc', range(4), tqdm_class=tqdm_auto.tqdm)
    product('abc', range(4), tqdm_class=tqdm_auto.tqdm, leave=False)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:51:21.498694
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tqdm import trange
    from .utils import format_sizeof
    import sys
    import time


# Generated at 2022-06-24 09:51:30.519586
# Unit test for function product
def test_product():
    import operator
    import functools
    import numpy as np
    #from .numpy_example import numpy_example

    from .std_example import std_example
    from .tqdm_wget import tqdm_wget
    from .tqdm_gui import tqdm_gui
    #from .tqdm_notebook import tqdm_notebook
    #from .tqdm_pandas import tqdm_pandas
    #from .tqdm_std_out import tqdm_std_out
    from .tgrange_example import tgrange_example
    from .trange_example import trange_example

    from .main_bin import main_bin
    from .main_frozen import main_frozen
    from .main_lock import main_lock

# Generated at 2022-06-24 09:51:40.556930
# Unit test for function product
def test_product():
    """
    Unit test fo function `product`.
    """
    import sys
    import itertools
    import tqdm

    def _product(*args, **kwargs):
        T = kwargs.pop('T', tqdm.tqdm)
        it = tqdm.product(*args, **kwargs)
        if not tqdm.get_lock().locks:
            it = T(it)
        ins, outs = itertools.tee(it)
        ret = list(ins)
        assert len(ret) == len(list(outs))
        return ret

    ret = _product(range(5), repeat=2)
    assert ret == [(x, y) for x in range(5) for y in range(5)]

    ret = _product(range(3), repeat=3)
    assert ret

# Generated at 2022-06-24 09:51:47.190327
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..tqdm_gui import tqdm
    assert list(product([1, 2], [3, 4], tqdm_class=tqdm,
                        desc="test", leave=True, miniters=1, mininterval=1)) \
        == list(itertools.product([1, 2], [3, 4]))
    for l1, l2 in itertools.product([[1, 2], [3, 4, 5]], [[3, 4], [5, 6]]):
        assert list(product(l1, l2, tqdm_class=tqdm)) == list(itertools.product(l1, l2))

# Generated at 2022-06-24 09:51:50.575959
# Unit test for function product
def test_product():
    import numpy as np
    irr = np.random.rand(15, 15)
    laps = 0
    for i in product(irr, irr):
        laps += 1
    assert laps == 15*15*15*15

# Generated at 2022-06-24 09:51:55.038039
# Unit test for function product
def test_product():
    """Test product function with both one and two lists"""
    from tqdm import tqdm

    list_comprehension_sum = sum([sum(i) for i in
                                  tqdm(itertools.product([1, 2], [3, 4]))])
    function_sum = sum(sum(i)
                       for i in tqdm.product([1, 2], [3, 4]))
    assert list_comprehension_sum == function_sum

    # Check single list
    list_comprehension_sum1 = sum([sum(i) for i in
                                   tqdm(itertools.product([1, 2, 3]))])
    function_sum1 = sum(sum(i)
                        for i in tqdm.product([1, 2, 3]))
    assert list_com

# Generated at 2022-06-24 09:52:03.324258
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range

    with_setup(setup=tqdm_auto.setup, teardown=tqdm_auto.teardown)
    with tqdm_auto.set_lock(_range):
        assert list(product(_range(10))) == list(itertools.product(_range(10)))
        assert list(product(_range(10), _range(20))) == \
            list(itertools.product(_range(10), _range(20)))

    with_setup(setup=tqdm_auto.setup, teardown=tqdm_auto.teardown)

# Generated at 2022-06-24 09:52:11.709911
# Unit test for function product
def test_product():
    """
    Unit test.
    """
    import numpy as np
    try:
        from numpy.testing import assert_array_equal
    except ImportError:
        assert_array_equal = np.testing.assert_array_equal

    lst = list('abc')
    ref = np.array(list(itertools.product(*[lst for _ in range(4)])))
    for k in [1, 2, 3, 4]:
        obs = np.array(list(product(*[lst for _ in range(k)])))
        assert_array_equal(obs, ref)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:52:20.833484
# Unit test for function product
def test_product():
    import subprocess
    import sys
    import os
    inp = list(range(100))
    expected = sum(i[0] * i[1] for i in itertools.product(inp, inp))
    n = sys.executable
    if sys.version_info[0] < 3:
        n = os.path.join(os.path.dirname(n), 'python3')

# Generated at 2022-06-24 09:52:25.484700
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ._utils import _range

    for _ in product(_range(4), _range(4), _range(4)):
        pass

if __name__ == '__main__':  # pragma: no cover
    from ._utils import process_test_cases, run_module_doctests
    process_test_cases(__file__, globals())
    run_module_doctests(__file__)

# Generated at 2022-06-24 09:52:30.389580
# Unit test for function product
def test_product():
    l1 = [1, 2]
    l2 = [3, 4, 5]
    l3 = [6, 7, 8, 9]
    ip = itertools.product(l1, l2, l3)
    assert list(product(l1, l2, l3)) == list(ip)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:52:38.677121
# Unit test for function product
def test_product():
    from ..utils import _range
    it = product(
        [1, 2, 3], [3, 4],
        tqdm_class=tqdm_auto, desc="product-test")
    assert list(it) == [(1, 3), (1, 4), (2, 3), (2, 4), (3, 3), (3, 4)]
    it = product(_range(0, 10), _range(0, 10),
                 tqdm_class=tqdm_auto, desc="product-test")
    assert list(it) == list(itertools.product(_range(0, 10), _range(0, 10)))

# Generated at 2022-06-24 09:52:42.293436
# Unit test for function product
def test_product():
    try:
        from nose.tools import assert_equal as _assert_equal
    except ImportError:
        return
    _assert_equal(
        list(product(range(5), repeat=2, tqdm_class=tqdm_auto)),
        list(itertools.product(range(5), repeat=2)))

# Generated at 2022-06-24 09:52:51.464021
# Unit test for function product
def test_product():
    """Test products of lists"""
    assert list(product([1, 2, 3], [1])) == [(1, 1), (2, 1), (3, 1)]
    assert list(product([1, 2, 3], [1, 2, 3])) == [(1, 1), (1, 2), (1, 3),
                                                   (2, 1), (2, 2), (2, 3),
                                                   (3, 1), (3, 2), (3, 3)]

# Generated at 2022-06-24 09:53:05.441474
# Unit test for function product
def test_product():
    from ..std import numpy as np
    from ..utils import format_sizeof
    from .trange import trange
    from .tqdm_gui import tqdm_gui
    from .tqdm_pandas import tqdm_pandas
    import sys

    for t in [tqdm_auto]:
        for iterables in [
                (range(100), range(1000)),
                (np.arange(100), np.arange(100))
        ]:
            product(iterables, tqdm_class=t)
            assert t.write.__self__.n == sum(map(len, iterables))


# Generated at 2022-06-24 09:53:12.498557
# Unit test for function product
def test_product():
    import numpy as np

    def _test_product(*iterables):
        np.testing.assert_array_equal(
            list(itertools.product(*iterables)),
            list(product(*iterables, tqdm_class=tqdm_auto)))

    _test_product(["a", "b", "c"])
    _test_product([[0, 1], [0, 1]])
    _test_product([[0, 1], [0, 1], [0, 1]])
    _test_product([[0, 1], [0, 1], [0, 1], [0, 1]])
    _test_product([[0, 1], [0, 1], [0, 1], [0, 1], [0, 1]])



# Generated at 2022-06-24 09:53:16.928028
# Unit test for function product
def test_product():
    try:
        import pytest
        from ..tqdm import trange
        assert product(range(10), range(10), range(10),
                       tqdm_class=trange)
    except ImportError:
        pass

# Generated at 2022-06-24 09:53:21.240505
# Unit test for function product
def test_product():
    from .tests import closing, closing, closing

    with closing(lambda: product('ABCD', 'xy', total=8)) as fobj:
        assert sum(1 for _ in fobj) == 8

    with closing(lambda: product('ABCD', 'xy', ascii=True, total=8)) as fobj:
        assert sum(1 for _ in fobj) == 8

# Generated at 2022-06-24 09:53:29.908626
# Unit test for function product
def test_product():
    # Test with list
    assert list(product(range(5), range(5))) == list(itertools.product(range(5), range(5)))
    assert list(product(range(5), range(5), tqdm_class=tqdm_auto)) == list(itertools.product(range(5), range(5)))
    assert list(product(range(5), range(5), tqdm_class=tqdm_auto, total=20)) == list(itertools.product(range(5), range(5)))


test_product()

# Generated at 2022-06-24 09:53:39.481971
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Check single list
    expected = [(1,), (2,), (3,)]
    assert list(product([1, 2, 3])) == expected
    # Check single tuple
    assert list(product((1, 2, 3))) == expected
    # Check multiple args
    expected = [
        (1, 'a'), (2, 'a'), (3, 'a'),
        (1, 'b'), (2, 'b'), (3, 'b'),
        (1, 'c'), (2, 'c'), (3, 'c')
    ]
    assert list(product([1, 2, 3], ('a', 'b', 'c'))) == expected
    # Check empty lists
    assert list(product([])) == []
    assert list(product([], [])) == []
    assert list

# Generated at 2022-06-24 09:53:41.141026
# Unit test for function product
def test_product():
    from .tests import test_product as ttp
    return ttp.test_product(product)

# Generated at 2022-06-24 09:53:48.839862
# Unit test for function product
def test_product():
    from numpy import random
    from ..utils import format_interval
    from .std import tqdm
    import time

    def timeit(func, *args, **kwargs):
        """
        Time function execution and return result.

        Parameters
        ----------
        func  : function
            Function to time.
        """
        start_time = time.time()
        func(*args, **kwargs)
        return time.time() - start_time

    elapsed = timeit(product, random.randn(100000),
                     random.randn(100000), tqdm_class=tqdm)
    assert (format_interval(elapsed) < '2s')



# Generated at 2022-06-24 09:53:57.263033
# Unit test for function product
def test_product():
    def check(i):
        """Test that both lists are the same"""
        a = [i for i in product(range(i), range(i), range(i),
                                tqdm_class=tqdm_auto)]
        b = [i for i in itertools.product(range(i), range(i), range(i))]

        assert a == b

    for i in range(5):
        check(i)

# Generated at 2022-06-24 09:54:04.990832
# Unit test for function product
def test_product():
    import pytest
    with pytest.raises(ValueError):
        # nargs < 1
        with tqdm_auto(total=1) as t:
            for _ in product([]):
                t.update()
    with pytest.raises(ValueError):
        # nargs > 1
        with tqdm_auto(total=1) as t:
            for _ in product(range(2), range(2), range(2)):
                t.update()
    with tqdm_auto(total=4) as t:
        for _ in product(range(2), range(2)):
            t.update()
    # no len

# Generated at 2022-06-24 09:54:16.630865
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import _range

    for iterables in [
            [[]],
            [[1], [2]],
            [[1], [2, 3]],
            [[1, 2, 3], _range(10)],
            _range(10),
            [_range(10), _range(10)]]:
        # print(iterables)
        assert list(itertools.product(*iterables)) == \
            list(product(*iterables, tqdm_class=None))
        assert list(itertools.product(*iterables)) == \
            list(product(*iterables, tqdm_class=tqdm_auto))

    def test_total(iterables, total):
        return len(list(product(*iterables, tqdm_class=None))) == total
    assert not test

# Generated at 2022-06-24 09:54:18.356746
# Unit test for function product
def test_product():
    for i in product("abcde", repeat=3, tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:54:20.812131
# Unit test for function product
def test_product():
    list(tqdm.product(["1", "2", "3"], ["a", "b"], ["x", "y", "z"],
                      tqdm=tqdm))

# Generated at 2022-06-24 09:54:28.794009
# Unit test for function product
def test_product():
    # Equivalent to
    # `itertools.product("abcd", "1234")`, but with tqdm progress
    try:
        import __builtin__ as builtins
    except ImportError:  # pragma: no cover
        import builtins
    iterable = product("abcd", "1234", tqdm_class=tqdm_auto)
    # `itertools.product` is lazy, so this test is also lazy
    builtins_zip = iter(builtins.zip)
    for i in iterable:
        assert i == next(builtins_zip)
    try:
        next(iterable)
    except StopIteration:
        pass
    else:
        builtins_next = iter(builtins.next)
        for i in iterable:
            assert i == next(builtins_next)

# Generated at 2022-06-24 09:54:30.499120
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    list(product(range(2), range(2)))

# Generated at 2022-06-24 09:54:40.622130
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_equal, assert_allclose

    np.random.seed(0)

    tqdm_kwargs = dict(
        tqdm_class=tqdm_auto,
        desc="product",
        unit="integers")


# Generated at 2022-06-24 09:54:48.901178
# Unit test for function product
def test_product():
    import numpy as np
    from tqdm.contrib.test import closing, _range
    with closing(tqdm_auto(_range(0))) as pbar:
        assert not np.any(list(product(pbar, [3, 2, 1])))
    with closing(tqdm_auto(_range(0))) as pbar:
        assert np.all(list(product(pbar, [3, 2, 1])) ==
                      [(0, 3), (0, 2), (0, 1)])

# Generated at 2022-06-24 09:54:59.708821
# Unit test for function product
def test_product():
    try:
        from nose.plugins.attrib import attr
    except ImportError:
        def attr(*args, **kwargs):
            if not kwargs.get('skip', False):
                def dec(func):
                    return func
                return dec
    @attr(speed='slow')
    def test_product_1():
        """`product`: simple"""
        a = range(0, 5)
        b = range(10, 15)
        assert list(product(a, b)) == list(itertools.product(a, b))
        assert list(product(a, b, tqdm_class=tqdm_auto.tqdm)) == list(itertools.product(a, b))

# Generated at 2022-06-24 09:55:01.846225
# Unit test for function product
def test_product():
    with tqdm_auto(total=2 * 3 * 4) as t:
        for i in product(['a', 'b'], range(2), range(4), tqdm_class=tqdm_auto):
            t.update()

# Generated at 2022-06-24 09:55:12.554855
# Unit test for function product
def test_product():
    """
    Unit test for function tqdm.utils.itertools.product
    """
    assert list(product(range(2), range(2), tqdm_class=None)) == list(
        itertools.product(range(2), range(2)))
    assert list(product(range(2), range(2), tqdm_class=tqdm_auto)) == list(
        itertools.product(range(2), range(2)))
    assert list(product(range(2), range(2), tqdm_class=tqdm_auto.tqdm)) == list(
        itertools.product(range(2), range(2)))

# Generated at 2022-06-24 09:55:22.390465
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys

    iterables = [
        range(2), [1, 3, 5],
        "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"]
    outstr = "".join(map(str, itertools.product(*iterables)))
    ourstr = "".join(map(str, product(*iterables, desc="testing:",
                                      unit="uints", total=None, file=sys.stdout)))
    assert (outstr == ourstr)

# Generated at 2022-06-24 09:55:30.508482
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy.random import randint
    from numpy import arange, array

    def test_eq_product(ar1, ar2):
        iterables = tuple(tuple(a) for a in ar1)
        its = product(*iterables)
        for it1, it2 in zip(its, ar2.ravel()):
            assert array(it1) == it2

    test_eq_product([
        arange(4),
        arange(3)
    ], arange(4 * 3).reshape(4, 3))

    test_eq_product([
        arange(1),
        arange(3),
        arange(3)
    ], arange(1 * 3 * 3).reshape(1, 3, 3))

    test_eq_

# Generated at 2022-06-24 09:55:34.768307
# Unit test for function product
def test_product():
    """Test for tqdm.itertools.product"""
    from numpy import product

    # Test iterator length
    assert sum(1 for _ in product(range(3), repeat=3)) == 27
    assert sum(1 for _ in product(range(3), repeat=0)) == 1
    assert sum(1 for _ in product([], repeat=3)) == 0

# Generated at 2022-06-24 09:55:41.411500
# Unit test for function product
def test_product():
    """Test for function product"""
    from ..utils import format_sizeof
    from ..tests import sigm, tqdm
    from . import trange
    from .trange import trange

    test_list = list(range(2))
    for i in trange(10000000, dynamic_ncols=True, leave=False):
        test_product = list(product(test_list))
    assert test_product == [(0,), (1,)]

    test_list = list(range(5))
    for i in trange(1000000, dynamic_ncols=True, leave=False):
        test_product = list(product(test_list))

# Generated at 2022-06-24 09:55:51.865431
# Unit test for function product
def test_product():
    # Test list of list product
    a = [[1, 2, 3],
         ["a", "b"]]

    ap = product(a)
    assert (tuple(ap) ==
            ((1, 'a'),
             (1, 'b'),
             (2, 'a'),
             (2, 'b'),
             (3, 'a'),
             (3, 'b')))

    # Test list of list product
    a = [[1, 2, 3],
         ["a", "b"]]

    ap = product(a)
    assert (tuple(ap) ==
            ((1, 'a'),
             (1, 'b'),
             (2, 'a'),
             (2, 'b'),
             (3, 'a'),
             (3, 'b')))

    # Test list of str product
   

# Generated at 2022-06-24 09:56:00.758766
# Unit test for function product
def test_product():
    """
    Unit test for function `tqdm.itertools.product`.
    """
    from random import random
    from operator import mul

    # Itertools.product
    with tqdm_auto() as t:
        for _ in itertools.product(range(1), range(10), range(100)):
            t.update()

    # Tqdm.itertools.product
    with tqdm_auto() as t:
        for _ in tqdm.itertools.product(range(1), range(10), range(100)):
            t.update()

    # Evenly spaced ranges
    with tqdm_auto() as t:
        for _ in tqdm.itertools.product(range(1), range(10), range(100)):
            t.update()

# Generated at 2022-06-24 09:56:05.810417
# Unit test for function product
def test_product():
    from numpy import prod
    l = (9000, 900000000000001, 900000000000002)
    for i, item in enumerate(product(*l, tqdm_class=None)):
        assert item == (i % l[0], (i // l[0]) % l[1], (i // l[0]) // l[1])
    assert i == prod(l) - 1

# Generated at 2022-06-24 09:56:07.724694
# Unit test for function product
def test_product():
    """Test for function product"""
    for i in product([1, 2, 3], ['a', 'b', 'c'], tqdm_class=tqdm_auto) :
        pass

# Generated at 2022-06-24 09:56:15.582738
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    seq1 = ['a', 'b']
    seq2 = ['c', 'd']
    seq3 = ['e', 'f']

    ans = ['ace', 'acf', 'ade', 'adf', 'bce', 'bcf', 'bde', 'bdf']
    prod = product(seq1, seq2, seq3)
    lst = list(prod)
    assert lst == ans

    prod = product(seq1, seq2, seq3, tqdm_class=None)
    lst = list(prod)
    assert lst == ans

# Generated at 2022-06-24 09:56:18.423168
# Unit test for function product
def test_product():
    from .tests import _test_iterator
    _test_iterator(product, lambda: list(itertools.product(range(2), repeat=2)))

if __name__ == '__main__':
    assert test_product()

# Generated at 2022-06-24 09:56:27.190555
# Unit test for function product
def test_product():
    from pytest import raises

    x = product([1, 2, 3], [4, 5, 6], [7, 8, 9])
    assert next(x) == (1, 4, 7)
    assert next(x) == (1, 4, 8)
    assert next(x) == (1, 4, 9)
    assert next(x) == (1, 5, 7)
    assert next(x) == (1, 5, 8)
    assert next(x) == (1, 5, 9)
    assert next(x) == (1, 6, 7)
    assert next(x) == (1, 6, 8)
    assert next(x) == (1, 6, 9)

    with raises(StopIteration):
        next(x)

# Generated at 2022-06-24 09:56:30.834103
# Unit test for function product
def test_product():
    """
    Unit test.
    """
    import itertools
    import numpy as np
    a = range(1, 7)
    b = np.arange(6).reshape(2, 3)
    for i, j in tqdm.product(a, b, ascii=True):
        pass

# Generated at 2022-06-24 09:56:40.301471
# Unit test for function product
def test_product():
    """
    Examples
    --------
    >>> from tqdm.itertools import product
    >>> import tqdm
    >>> list(product(range(3), range(3), tqdm=tqdm))
    [0, 0]
    [0, 1]
    [0, 2]
    [1, 0]
    [1, 1]
    [1, 2]
    [2, 0]
    [2, 1]
    [2, 2]
    """
    import sys
    import time
    import tqdm

    sys.stderr.write(repr(list(tqdm.itertools.product(
        range(3), range(3), tqdm=tqdm.tqdm))))

# Generated at 2022-06-24 09:56:48.406656
# Unit test for function product
def test_product():
    try:
        from .main import tqdm
    except ImportError:
        from tqdm import tqdm
    from nose.tools import raises
    from itertools import product

    class StopIterationError(Exception):
        """Stopping an iterator"""

    @raises(StopIterationError)
    def test_normal(tqdm_cls=None):
        """Test slow, normal iterator"""

# Generated at 2022-06-24 09:56:53.892689
# Unit test for function product
def test_product():
    """Test function product."""
    try:
        iter_ = product([1, 2, 3], ["i", "j", "k"], total=9, leave=True)
        list(iter_)
    except Exception as e:
        raise RuntimeError("Test `product` failed with error {}".format(e))
    else:
        print("Test `product` passed successfully")


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:56:58.548730
# Unit test for function product
def test_product():
    """
    Unit tests for function `product`.
    """
    from .tqdm_gui import tqdm

    list(product(range(100),
                 ["string {}".format(i) for i in range(10)],
                 ["a", "b", "c"],
                 tqdm_class=tqdm))

# Generated at 2022-06-24 09:57:05.379274
# Unit test for function product
def test_product():
    import sys
    l = list(product(range(n) for n in [3, 1, 4]))
    assert l == [(0, 0, 0), (0, 0, 1), (0, 0, 2), (0, 0, 3)], l


# Generated at 2022-06-24 09:57:11.323796
# Unit test for function product
def test_product():
    import sys
    import six
    import random
    try:
        from nose.tools import assert_equal
    except ImportError:
        pass
    else:
        assert_equal(list(product(range(2), repeat=2)), list(itertools.product(range(2), repeat=2)))
        assert_equal(list(product(range(3), repeat=3)), list(itertools.product(range(3), repeat=3)))
        assert_equal(list(product(range(4), repeat=4)), list(itertools.product(range(4), repeat=4)))
        assert_equal(list(product(range(5), repeat=5)), list(itertools.product(range(5), repeat=5)))

# Generated at 2022-06-24 09:57:20.967052
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    # Hyper-parameters
    n_run = 10
    n_iter = 100

    # Test case:
    # Test with `tqdm` default version
    from ..auto import tqdm as tqdm_auto
    for i in product(range(n_run), ["a", "b"], tqdm_kwargs={"tqdm_class": tqdm_auto}):
        assert len(i) == 3

    # Test with `tqdm` manual version
    for i in product(range(n_run), ["a", "b"], tqdm_kwargs={"tqdm_class": tqdm_auto, "total": 2 * n_run}):
        assert len(i) == 3

# Generated at 2022-06-24 09:57:25.223004
# Unit test for function product
def test_product():
    for it in product(range(4), range(3), range(2), tqdm_class=tqdm_auto):
        pass
    for it in product(range(4), range(3), range(2)):
        pass

# Generated at 2022-06-24 09:57:29.221036
# Unit test for function product
def test_product():
    """Unit test for function product"""
    it = product("ABCD", "xy", tqdm_class=tqdm_auto)
    try:
        assert list(it) == list(itertools.product("ABCD", "xy"))
    except AssertionError:
        raise

# Generated at 2022-06-24 09:57:38.712369
# Unit test for function product
def test_product():
    for i in product(range(10), range(10), (1, 2)):
        assert sum(i) == 10
    for i in product([1, 2], ['a', 'b', 'c'], [0.1, 0.01]):
        assert sum(i) == 3.11
    for i in product(range(10), range(10), total=None):
        assert sum(i) == 10

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:57:48.895377
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import random
    import copy
    import shutil
    import tqdm
    from .tests_tqdm import PretendTqdmFile

    # Test 1: Test iterator with a total
    with tqdm.tqdm(total=2 * 3 * 4 * 5) as t:
        assert len(list(tqdm.itertools.product(range(2),
                                               range(3),
                                               range(4),
                                               range(5)))) == 120
        for i in tqdm.itertools.product(range(2),
                                        range(3),
                                        range(4),
                                        range(5)):
            assert len(i) == 4
            t.update()

# Generated at 2022-06-24 09:57:58.447339
# Unit test for function product
def test_product():
    """Test that product is indeed an equivalent of itertools.product"""
    import numpy as np

    np.random.seed(0)
    # Test that tqdm.product is equivalent to itertools.product
    for a in [list(range(10)), list(range(10)), list(range(10)), list(range(10))]:
        assert(sum(1 for _ in product(*a)) == 10**4)
        assert(sum(1 for _ in product(*a, ascii=True)) == 10**4)
        try:
            from matplotlib import pyplot as plt
            assert(sum(1 for _ in product(*a, ascii=False)) == 10**4)
        except ImportError:
            pass

# Generated at 2022-06-24 09:58:05.736350
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.testing import assert_equal, assert_
    from numpy import all
    for X in [range, range]:
        for Y in [range, range]:
            for Z in [range, range]:
                a = list(itertools.product(X(2), Y(3), Z(4)))
                b = list(product(X(2), Y(3), Z(4)))
                assert_equal(a, b)
                assert_(all(hasattr(i, "n") for i in b))

# Generated at 2022-06-24 09:58:14.708027
# Unit test for function product
def test_product():
    import random
    import string
    import sys
    import itertools

    random.seed(1)
    test = random.randint(1, 10)
    if len(sys.argv) > 1:
        test = int(sys.argv[1])
    for i in range(test):
        for j in range(test):
            for k in range(test):
                li1, li2, li3 = range(i), range(j), range(k)
                for _ in itertools.product(li1, li2, li3):
                    pass
                for _ in product(li1, li2, li3):
                    pass
        print(i)

    def my_sum(*args):
        return sum(args)


# Generated at 2022-06-24 09:58:24.277225
# Unit test for function product
def test_product():
    import numpy as np
    list1 = np.arange(10)
    list2 = np.arange(10)
    list_res = list1 * 10 + list2
    for c, x in enumerate(product(list1, list2)):
        assert x == (list1[c // len(list2)], list2[c % len(list2)])
    for c, x in enumerate(product(list1, list2, tqdm_class=None)):
        assert x == (list1[c // len(list2)], list2[c % len(list2)])

# Generated at 2022-06-24 09:58:33.933276
# Unit test for function product
def test_product():
    from ..utils import _range

    # Testing when total can be determined
    for n in _range(1, 3):
        for m in _range(1, 3):
            for tqdm_cls in (tqdm_auto, None):
                l = list(product(iterable=_range(n),
                                 iterable2=_range(m),
                                 tqdm_class=tqdm_cls))
                assert len(l) == n * m
                assert l[-1] == (n - 1, m - 1)
                dupes = set()
                for i in _range(n):
                    for j in _range(m):
                        dupes.add((i, j))
                assert len(dupes) == n * m

    # Testing when total cannot be determined

# Generated at 2022-06-24 09:58:40.684956
# Unit test for function product
def test_product():
    """Test product."""
    first = [1, 2, 3]
    second = ['a', 'b', 'c']
    third = [('d', 'e', 'f'), ('g', 'h', 'i'), ('j', 'k', 'l')]
    for i in product(first, second, third, total=len(first) * len(second) *
                     len(third)):
        pass
    # Test partial=True
    for i in product(first, second, total=len(first) * len(second)):
        pass
    # Test flatten
    for i in product(first, second, flatten=True):
        pass
    # Test nested lists
    for i in product([first, second, third], total=len(first) * len(second) *
                     len(third)):
        pass
   

# Generated at 2022-06-24 09:58:45.946483
# Unit test for function product
def test_product():
    import numpy as np

    a = range(3)
    b = 'abc'
    res = product(a, b)
    tqdm_res = list(tqdm(res))
    try:
        assert np.allclose(tqdm_res, list(itertools.product(a, b)))
    except AssertionError:
        print('tqdm_res:', tqdm_res)
        print('itertools.product(a, b):', list(itertools.product(a, b)))
        raise

# Generated at 2022-06-24 09:58:50.174906
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_allclose
    from .utils import _range

    assert_allclose(list(product(_range(3), _range(3))),
                    np.array(list(itertools.product(_range(3), _range(3)))))