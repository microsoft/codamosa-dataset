

# Generated at 2022-06-24 09:48:58.927097
# Unit test for function product
def test_product():
    from ..utils import SimpleNamespace
    from ._utils import FakeTqdmFile

    for tqdm_cls in [tqdm_auto, SimpleNamespace(write=tqdm_auto)]:
        for total in [None, 0, 4]:
            out = list(product([1, 2], [3], tqdm_class=tqdm_cls, total=total))
            assert out == [(1, 3), (2, 3)]

        f = FakeTqdmFile()
        for total in [None, 0, 4]:
            out = list(product([1, 2], [3], tqdm_class=tqdm_cls, total=total,
                               file=f))
            assert out == [(1, 3), (2, 3)]
            assert "6it" in f.getvalue()

# Generated at 2022-06-24 09:49:03.247605
# Unit test for function product
def test_product():
    from random import randint
    from pytest import raises
    from numpy import product
    from ..utils import _range

    for i in _range(10):
        n = randint(2, 10)
        r = [randint(1, 5) for _ in _range(n)]
        assert product(r) == product(r, tqdm_class=None)
        assert product(r) == product(r, tqdm_class=tqdm_auto)
        assert product(r, tqdm_class=tqdm_auto) == product(r, tqdm_class=None)



# Generated at 2022-06-24 09:49:07.426237
# Unit test for function product
def test_product():
    """
    Simple test case for `product`.
    """
    import pickle
    from io import BytesIO
    from gunzip_iter import gunzip_iter

    # Run product()
    gen = product(range(10), range(10), tqdm_class=tqdm_auto)
    # Check that the generator works
    assert next(gen) == (0, 0)
    assert next(gen) == (0, 1)
    assert next(gen) == (0, 2)
    # Save the generator
    file = BytesIO()
    pickle.dump(gen, file)
    file.flush()

    # Uncompress without holding everything in memory
    pickle_iter = gunzip_iter(file, tqdm_class=tqdm_auto)
    # Load the generator

# Generated at 2022-06-24 09:49:10.947505
# Unit test for function product
def test_product():
    assert list(product(range(10), range(3))) == list(itertools.product(range(10), range(3)))
    assert list(product([b'tqdm'], range(3))) == list(itertools.product([b'tqdm'], range(3)))

# Generated at 2022-06-24 09:49:21.609171
# Unit test for function product
def test_product():
    """
    Unit test for tqdm.itertools.product
    """
    from time import sleep
    from numpy.random import random
    from .utils import truncate_float
    from .std import tqdm
    tot = 0
    for i in tqdm.itertools.product(range(4), range(4)):
        tot += 1
        sleep(0.01 * random())
    assert tot == 16
    tot = 0
    for i in tqdm.itertools.product(range(15), repeat=3):
        tot += 1
        sleep(0.01 * random())
    assert tot == 3375
    tot = 0

# Generated at 2022-06-24 09:49:24.468331
# Unit test for function product
def test_product():
    from nose.tools import eq_
    iterables = [list(range(i)) for i in range(1, 4)]
    eq_([i for i in product(*iterables)],
        [i for i in itertools.product(*iterables)])

# Generated at 2022-06-24 09:49:26.894912
# Unit test for function product
def test_product():
    for i in product(range(5), ['a', 'b', 'c'], tqdm_class=tqdm_auto):
        assert i == (i[0], i[1])

# Generated at 2022-06-24 09:49:37.147703
# Unit test for function product
def test_product():
    import re
    from .tests_tqdm import pretest_posttest
    from .tests_tqdm import closing

    @closing(tqdm_auto(leave=False))
    def inner_prod() -> None:
        """Test inner product"""
        for _ in range(20):
            yield
    @closing(tqdm_auto(leave=False))
    def outer_prod() -> None:
        """Test outer product"""
        for _ in zip(*[inner_prod() for _ in range(10)]):
            yield

    @pretest_posttest
    def test_product_1(total, **kwargs):
        """Test inner product"""
        for _ in product(range(total), **kwargs, tqdm_class=tqdm_auto):
            pass


# Generated at 2022-06-24 09:49:47.549641
# Unit test for function product
def test_product():
    """
    Unit test for function `product`
    """
    from ..utils import format_sizeof
    from ._utils import FormatCustomText

    t = range(9)
    r = list(product(t, t, t, t, t, t, t, t, t))
    assert len(r) == 9**9

    r = list(product(t, t, t, t, t, t, t, t, t, tqdm_class=FormatCustomText))
    assert len(r) == 9**9

    r = list(product(t, t, t, t, t, t, t, t, t, tqdm_class=FormatCustomText))
    assert len(r) == 9**9


# Generated at 2022-06-24 09:49:50.399932
# Unit test for function product
def test_product():
    from ..contrib.utils import adict
    p = adict(a=0, b=0, c=0)
    for i in product('abc', 'def', tqdm_class=tqdm_auto, total=12):
        p[i[0]] += 1
    assert p == {'a': 4, 'b': 4, 'c': 4}

# Generated at 2022-06-24 09:49:52.813030
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    for i in product(range(4), range(4)):
        pass

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:49:58.989925
# Unit test for function product
def test_product():
    assert list(product(range(3))) == [0, 1, 2] == list(range(3))
    assert list(product(range(3), range(3))) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (2, 0), (2, 1), (2, 2)]
    assert list(product(range(3), repeat=2)) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-24 09:50:08.859130
# Unit test for function product
def test_product():
    """Unit test for product"""
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))
    assert list(product(range(3), range(3))) == list(product(range(3), range(3), tqdm_class=tqdm_auto))
    assert list(product(range(3), range(3))) == list(product(range(3), range(3), tqdm_class=tqdm_auto, total=9))
    assert list(product(range(3), range(3))) == list(product(range(3), range(3), tqdm_class=tqdm_auto, total=10))

# Generated at 2022-06-24 09:50:10.644476
# Unit test for function product
def test_product():
    assert product([1, 2, 3], [4, 5]) == \
        list(itertools.product([1, 2, 3], [4, 5]))

# Generated at 2022-06-24 09:50:15.329809
# Unit test for function product
def test_product():
    """Test function product"""
    a = [1, 2, 3]
    b = ["a", "b"]
    c = ["x", "y", "z"]
    print(list(product(a, b, c)))
    print(list(product(a, b, c, tqdm_class=None)))

# Generated at 2022-06-24 09:50:24.258547
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    # pylint: disable=protected-access
    from random import randint, shuffle
    from .utils import format_sizeof
    from .std import b


# Generated at 2022-06-24 09:50:26.298484
# Unit test for function product
def test_product():
    for i, _ in enumerate(product('ABC', 'XY', tqdm_class=None)):
        assert i == 0

# Generated at 2022-06-24 09:50:33.345522
# Unit test for function product
def test_product():
    # Imports required for unit testing this function
    from ..utils import FormatCustomTextExt
    from ..pandas import tqdm_pandas
    from collections import Counter
    from itertools import count
    from random import shuffle, randint
    import pandas as pd

    print('### Test product')

    # test basic product
    assert list(product(range(3), range(3))) == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-24 09:50:38.371665
# Unit test for function product
def test_product():
    from .tqdm import trange

    def test_func():
        for _ in trange(5, desc="Outer", leave=False):
            for _ in trange(8, desc="Inner", leave=True):
                for _ in trange(3, leave=False):
                    pass
            for _ in trange(7, desc="Inner", leave=False):
                for _ in trange(3, leave=False):
                    pass
    test_func()

# Generated at 2022-06-24 09:50:46.954794
# Unit test for function product
def test_product():
    """Test the function `itertools.product` using tqdm.auto."""
    assert list(product([1, 2, 3], [4], [5, 6])) == list(
        itertools.product([1, 2, 3], [4], [5, 6]))
    assert list(product([1, 2, 3], [4])) == list(itertools.product([1, 2, 3], [4]))
    assert list(product([1, 2, 3])) == list(itertools.product([1, 2, 3]))
    assert list(product(["ABC", "DEF", "GHI"])) == list(itertools.product(["ABC", "DEF", "GHI"]))

# Generated at 2022-06-24 09:50:51.061618
# Unit test for function product
def test_product():
    with tqdm_auto(total=2 * 3 * 3) as t:
        for i, j, k in product(range(2), range(3), range(3)):
            assert (0 <= i <= 1) and (0 <= j <= 2) and (0 <= k <= 2)
            t.update()

# Generated at 2022-06-24 09:51:00.060848
# Unit test for function product
def test_product():
    from os import linesep
    iterables = [list(range(1000))] * 4
    from .utils import _range_
    with tqdm_auto(iterables, desc="test_product", unit="B") as t:
        p = product(*t)
        while True:
            try:
                i = next(p)
            except StopIteration:
                break
            t.update()
    # Test that postfix gets created properly in nested bars
    bar_str = t.__str__()
    assert bar_str == "test_product: |", bar_str
    assert len(_range_(bar_str, "B")) == 10
    assert len(_range_(bar_str, "B/s")) == 8

# Generated at 2022-06-24 09:51:08.409611
# Unit test for function product
def test_product():
    """ Unit test for function product """
    import copy
    import _tqdm
    from ._tqdm_gui import tqdm_gui
    from ._tqdm import tqdm
    from ._main import TMonitor
    from ._tqdm_gui import _range
    from ._utils import _min_interval

    with _tqdm.external_write_mode():
        with tqdm(leave=True) as t:
            t.write("\r")
        with tqdm(leave=True) as t:
            t.write("\r" * t.term_width)
        with tqdm(leave=True) as t:
            t.write("\r" * (t.term_width + 1))

# Generated at 2022-06-24 09:51:16.127279
# Unit test for function product
def test_product():
    from pytest import raises
    from numpy import prod
    from random import randint, shuffle
    from tqdm import trange

    for tqdm_class in [trange, tqdm_auto, tqdm_gui.tqdm]:
        # 3 by 3, 2 by 2, 2 by 1 empty product
        assert (
            list(product([[1, 2, 3]], [[11, 12]], [], tqdm_class=tqdm_class)) ==
            []
        )
        # 3 by 2 by 1 product
        assert (
            list(product([[1, 2, 3]], tqdm_class=tqdm_class)) ==
            [[1], [2], [3]]
        )
        # 3 by 2 by 1 product

# Generated at 2022-06-24 09:51:21.000527
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import sys
    import io
    import mock

    from ..utils import format_sizeof
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    out = StringIO()
    m = mock.Mock()
    with mock.patch("sys.stdout", out):
        iterable = product(m, tqdm_class=tqdm_auto,
                           desc="TEST", unit="it",
                           leave=False, ascii=True,
                           ncols=100, mininterval=0.1,
                           maxinterval=10.0, miniters=5,
                           postfix={"foo": "bar"})

# Generated at 2022-06-24 09:51:30.112604
# Unit test for function product
def test_product():
    from .utils import FormatCustomText
    from .monitor import TMonitor
    from .contrib import IPUtils

    with TMonitor(interval=0, leave=True):
        for i in IPUtils.product(range(1, 6), range(5, 10)):
            pass

    t = formatCustomText()
    for i in IPUtils.product(range(1, 6), range(5, 10)):
        t.update()
        pass
    assert t.n == 24

    with TMonitor(interval=0, leave=True):
        for i in IPUtils.product(range(1, 6), range(5, 10), tqdm_class=FormatCustomText):
            pass


# See https://github.com/tqdm/tqdm/pull/640

# Generated at 2022-06-24 09:51:40.164349
# Unit test for function product
def test_product():
    """
    Test for `product()`.
    """
    from . import trange
    from .utils import format_bytesize, format_time

    from .pandas import tqdm_pandas
    from .gui import tqdm_notebook
    from .std import tqdm

    for tqdm_cls in trange, tqdm, tqdm_pandas, tqdm_notebook:
        for i in tqdm_cls(product(range(10)), unit='times'):
            assert isinstance(i, tuple)
            assert len(i) == 2
            assert i[0] < 10 and i[1] < 10


# Generated at 2022-06-24 09:51:46.616900
# Unit test for function product
def test_product():
    """Test that product behaves like itertools.product"""
    # test when no total given
    ret1 = product(range(5), range(10), repeat=2, tqdm_class=None)
    ret2 = itertools.product(range(5), range(10), repeat=2)
    assert list(ret1) == list(ret2)

    # test when total given
    ret1 = product(range(5), range(10), repeat=2, total=100, tqdm_class=None)
    ret2 = itertools.product(range(5), range(10), repeat=2)
    assert list(ret1) == list(ret2)

# Generated at 2022-06-24 09:51:57.858973
# Unit test for function product
def test_product():
    """Unit test for product"""
    from ._utils import _range

    assert len(list(product(_range(6)))) == 6 ** 1
    assert len(list(product(_range(6), _range(6)))) == 6 ** 2
    assert len(list(product(_range(6), _range(6), _range(6)))) == 6 ** 3
    assert len(list(product(_range(6), _range(6), _range(6), _range(6)))) == 6 ** 4
    assert len(list(product(_range(6), _range(6), _range(6), _range(6),
                            _range(6)))) == 6 ** 5


if __name__ == "__main__":
    from ._utils import _tee_data
    for item in product(_tee_data(3)):
        pass

# Generated at 2022-06-24 09:52:04.111249
# Unit test for function product
def test_product():
    import pytest
    import numpy as np

    iterables = ([1, 2], [3, 4])
    expected = np.array([[1, 2], [3, 4]]).T
    result = np.array(list(product(*iterables)))
    assert result.shape == expected.shape
    assert np.all(result == expected)
    result = np.array(list(tqdm_auto(product(*iterables))))
    assert result.shape == expected.shape
    assert np.all(result == expected)

    with pytest.raises(TypeError):
        list(tqdm_auto(product(range(10), range(10), tqdm_class=int)))

# Generated at 2022-06-24 09:52:08.556853
# Unit test for function product
def test_product():
    # Unit tests
    from numpy.testing import assert_array_equal
    a = [1, 2, 3]
    b = [4, 5, 6]
    p = product(a, b)
    assert_array_equal(list(p), list(itertools.product(a, b)))

# Generated at 2022-06-24 09:52:15.138189
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..utils import FormatCustomText as __
    from ..utils import StringIO

    with StringIO() as our_file:
        for i in product(range(3), ['a', 'b', 'c'], tqdm_class=tqdm_auto,
                         file=our_file, desc=__('Testing product:'),
                         miniters=1, mininterval=0.05):
            pass

    assert(our_file.getvalue().rstrip() == __(
        u'Testing product:  0%|          | 0/9 [00:00<?, ?it/s]', 'utf8'))

# Generated at 2022-06-24 09:52:22.888947
# Unit test for function product
def test_product():
    """Unit test for function `tqdm.itertools.product`"""
    from numpy.random import randint
    # Random number of iterations
    total = randint(1, 1000)
    # Random number of iterables (1 to 4)
    iterables = tuple(range(randint(1, 5)) for _ in range(randint(1, 4)))

    for iterable in iterables:
        assert len(list(itertools.product(iterable))) == len(iterable)

# Generated at 2022-06-24 09:52:25.618992
# Unit test for function product
def test_product():
    iterables = [range(5), range(5), range(5)]

    assert list(itertools.product(*iterables)) == list(product(*iterables))

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:52:36.009442
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from numpy.random import randint
    from .tqdm import trange, tqdm

    total = 0
    for i in product(range(5), ['abc', 'de'], 'xy'):
        total += 1
        assert len(i) == 3
    assert total == 5 * 2 * 2

    # Test tqdm_class kwarg
    total = 0
    for i in product(range(5), ['abc', 'de'], 'xy', tqdm_class=trange):
        total += 1
        assert len(i) == 3
    assert total == 5 * 2 * 2

    def gen():
        for i in range(20):
            yield randint(0, 10, size=3)
    total = 0

# Generated at 2022-06-24 09:52:44.374913
# Unit test for function product
def test_product():
    """
    Test product().

    :return: (bool) True, if successful.
    """
    from .std import ncols
    from .utils import format_sizeof as fmt_size
    import sys
    iterables = [list(range(10)), range(10), range(10), range(10), range(10)]
    lst = list(product(*iterables))
    assert (len(lst) == sum(map(len, iterables)))
    assert (sum(product([1, 2], repeat=2)) == 6)
    assert (product([1, 2]) == [1, 2])
    assert (product([1, 2], [3, 4]) == [(1, 3), (1, 4), (2, 3), (2, 4)])
    # Test progressbar printing

# Generated at 2022-06-24 09:52:47.848878
# Unit test for function product
def test_product():
    assert (all(x == y
                for x, y in zip(tqdm_auto.product(range(3), 'ABC',
                                                  tqdm_class=tqdm_auto),
                                itertools.product(range(3), 'ABC'))))

# Generated at 2022-06-24 09:52:56.106905
# Unit test for function product
def test_product():
    from .tests import TestCase

    class Test(TestCase):
        def test_product(self):
            t = list(product(range(100), repeat=100))
            self.assertTrue(len(t) == 100 ** 100)

        def test_2args(self):
            t = list(product(range(100), range(10)))
            self.assertTrue(len(t) == 100 * 10)

    Test().run()

# Generated at 2022-06-24 09:53:07.016335
# Unit test for function product
def test_product():
    from ._deprecated import trange, tqdm_notebook, tnrange

    for tqdm in [tqdm_auto, trange, tqdm_notebook, tnrange]:
        with tqdm(product(range(5), range(5, 8)), leave=False) as t:
            assert t.total == 15
            for _ in t:
                pass
        with tqdm(product(range(5), range(5)), leave=False) as t:
            assert t.total == 25
            for _ in t:
                pass
        with tqdm(product(range(5), range(5), range(5)), leave=False) as t:
            assert t.total == 125
            for _ in t:
                pass

# Generated at 2022-06-24 09:53:15.792550
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], [4, 5], [7], tqdm_class=tqdm_auto)) == \
        list(itertools.product([1, 2, 3], [4, 5], [7]))
    assert list(product(
        ['abc', 'def', 'ghi'], [1, 2], ['a', 'b'], tqdm_class=tqdm_auto)) == \
        list(itertools.product(
            ['abc', 'def', 'ghi'], [1, 2], ['a', 'b']))

# Generated at 2022-06-24 09:53:18.785070
# Unit test for function product
def test_product():
    """Test for function product"""
    # Unit test for tqdm(...)
    from ..gui import tqdm

    for i in range(3):
        for j in tqdm(product(range(1000), range(1000), range(100))):
            pass

    # Unit test for tqdm.write(...)
    from .utils import WRITER
    with tqdm(total=10, file=WRITER) as t:
        for _ in product(range(10), range(10), range(10)):
            t.write('a')

# Generated at 2022-06-24 09:53:25.069157
# Unit test for function product
def test_product():
    """Test for function product"""
    # call product with two lists and verify that values are produced as expected
    expected_list = [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]
    actual_list = product([1, 2, 3], ['a', 'b'])
    assert list(actual_list) == expected_list

    # call product with the same list three times and verify that values are produced as expected
    expected_list = [(1, 1, 1), (1, 1, 2), (1, 2, 1), (1, 2, 2), (2, 1, 1), (2, 1, 2), (2, 2, 1), (2, 2, 2)]

# Generated at 2022-06-24 09:53:33.259731
# Unit test for function product
def test_product():
    L1 = range(2)
    L2 = range(3)

    assert list(product(L1, L2)) == [
        (0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2)]
    assert list(product(L1, L2, [])) == []
    assert list(product(L1, L2, [1])) == [(0, 0, 1), (0, 1, 1), (0, 2, 1), (1, 0, 1), (1, 1, 1), (1, 2, 1)]

# Generated at 2022-06-24 09:53:44.241976
# Unit test for function product
def test_product():
    from ..auto import tqdm

    # Test all combinations of kwargs
    for tqdm_class in (tqdm, tqdm_auto):
        for ascii in (True, False):
            for bar_format in ("{l_bar}", "{bar}"):
                for unit_scale in (True, False, None):
                    for unit in ("foos", "bars"):
                        # Test regular
                        assert sum(product([1, 2, 3], repeat=2, tqdm_class=tqdm_class,
                                           bar_format=bar_format, unit_scale=unit_scale,
                                           unit=unit, ascii=ascii)) == 9
                        # Test empty iterable
                        assert len(list(product([], tqdm_class=tqdm_class))) == 0


# Generated at 2022-06-24 09:53:51.634837
# Unit test for function product
def test_product():
    """
    Test for `tqdm.tqdm.product`.
    """
    from .tests_tqdm import with_setup
    from .tests_tqdm import pretest_posttest, posttest

    import numpy as np

    @with_setup(pretest_posttest)
    def test_basic():
        "basic"
        with tqdm_auto(unit="p") as t:
            for i in product(range(2), repeat=3):
                t.update(1)
        assert t.n == 8

    @with_setup(pretest_posttest)
    def test_subit():
        "subit"

# Generated at 2022-06-24 09:54:03.179969
# Unit test for function product
def test_product():
    """Test for function `product`"""
    from .tests2 import _test_iterable
    # Test 1: simple product
    _test_iterable(itertools.product([1, 2], [4, 5]),
                   product([1, 2], [4, 5]),
                   list(itertools.product([1, 2], [4, 5])))
    # Test 2: tqdm_class / tqdm_kwargs
    _test_iterable(itertools.product([1, 2], [4, 5]),
                   product([1, 2], [4, 5], tqdm_class=tqdm_auto),
                   list(itertools.product([1, 2], [4, 5])))
    # Test 3: total

# Generated at 2022-06-24 09:54:14.338958
# Unit test for function product
def test_product():
    """Test function _product"""
    assert list(product('ABCD', 'xy')) == [
        ('A', 'x'), ('A', 'y'),
        ('B', 'x'), ('B', 'y'),
        ('C', 'x'), ('C', 'y'),
        ('D', 'x'), ('D', 'y')]
    assert list(product(range(2), repeat=3)) == [
        (0, 0, 0), (0, 0, 1),
        (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1),
        (1, 1, 0), (1, 1, 1)]



# Generated at 2022-06-24 09:54:21.164580
# Unit test for function product
def test_product():
    import numpy as np
    assert list(product(range(3), repeat=3)) == list(itertools.product(range(3), repeat=3))
    assert list(product(range(3), repeat=3, tqdm_class=lambda x: x, total=None)) == list(itertools.product(range(3), repeat=3))
    assert list(product(range(3), repeat=3, total=None, tqdm_class=lambda x: x)) == list(itertools.product(range(3), repeat=3))
    assert list(product(range(10), repeat=8, total=None)) == list(itertools.product(range(10), repeat=8))

# Generated at 2022-06-24 09:54:24.885236
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    assert_equal(list(product("ABC", "123")), list(itertools.product("ABC", "123")))
    assert_equal(list(product("ABC", "123", "abc")), list(itertools.product("ABC", "123", "abc")))

# Generated at 2022-06-24 09:54:36.299375
# Unit test for function product
def test_product():  # pragma: no cover
    from ..utils import __interactive__
    if not __interactive__:  # pragma: no cover
        from nose.tools import assert_equals
    from itertools import count, repeat, cycle
    from time import sleep

    it = [(range(3), ['a', 'b', 'c', 'd'])]
    for _ in tqdm_auto(product(*it), total=len(list(product(*it)))):
        pass
    it = [(cycle(range(3)), repeat('a', 4))]
    for _ in tqdm_auto(product(*it),
                        total=len(list(product(*it))),
                        smoothing=0):
        sleep(0.01)
    it = [(count(1), ['a', 'b', 'c', 'd'])]
   

# Generated at 2022-06-24 09:54:39.653982
# Unit test for function product
def test_product():
    reference = [(1, 2), (1, 3), (1, 4), (2, 2), (2, 3), (2, 4)]
    result = [i for i in product(range(1, 3), range(2, 5))]
    assert reference == result

# Generated at 2022-06-24 09:54:48.057887
# Unit test for function product
def test_product():
    import numpy

    def product_with_tqdm(*iterables, **tqdm_kwargs):
        product_iterator = product(*iterables, **tqdm_kwargs)
        return list(product_iterator)

    func = product_with_tqdm
    assert func(range(0, 3), range(0, 3)) == []
    assert func(range(0, 3), range(0, 3), tqdm_class=None) == []

    assert func(range(1, 3), range(1, 3)) == [(1, 1), (1, 2), (2, 1), (2, 2)]

# Generated at 2022-06-24 09:54:55.098996
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import format_sizeof
    N = 512
    M = 4096
    L = 64
    arrays = [np.random.normal(size=N) for _ in range(M)]
    for _ in product(*arrays, total=M*N):
        pass
    assert format_sizeof(M * N * L) == format_sizeof(product(*arrays))

# Generated at 2022-06-24 09:55:03.570795
# Unit test for function product
def test_product():
    from random import randint
    from .misc import IS_PYPY
    # Don't test on PyPy:
    #  - PyPy3.3-v5.5.0-alpha-724-g0b78f7908 is unstable
    #    (and actually even segfaults on this test)
    #  - PyPy2.7-v7.1.1 crashes with:
    #      OverflowError: cannot convert float infinity to integer
    if IS_PYPY:
        return
    # Create list of data
    a = []
    for _ in range(1000):
        a.append(randint(0, 100))
    # Test
    from .utils import TestingIO as StringIO
    from . import _utils

# Generated at 2022-06-24 09:55:15.183112
# Unit test for function product
def test_product():
    """Run test for function product."""
    from .tqdm import trange
    from .utils import writetext
    from .utils import readtext
    from .utils import RemovalPyCache
    from .utils import _range

    with trange(5) as t:
        for i in product(t, _range(3)):
            t.set_postfix(i=i)
            t.update()

    for i in trange(3, desc='a'):
        for j in trange(3, leave=False, desc='b'):
            for k in trange(3, leave=False, desc='c'):
                pass

    # with trange(5) as t:
    #     for i in product(t, t, t):
    #         t.update()

    # with trange(10, desc

# Generated at 2022-06-24 09:55:28.381054
# Unit test for function product
def test_product():
    it = product('ABCD', 'xy', tqdm_class=lambda x: x)
    assert list(it) == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]
    it = product('ABCD', 'xy', '10', tqdm_class=lambda x: x)

# Generated at 2022-06-24 09:55:32.502066
# Unit test for function product
def test_product():
    """Test function product"""
    from random import randint
    for length in (10, None):
        with tqdm_auto(total=length) as t:
            for _ in products(range(length), repeat=randint(1, 10)):
                t.update()

# Generated at 2022-06-24 09:55:39.949469
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..utils import FormatCustomText
    N = 3
    try:
        from numpy import prod
    except ImportError:
        from operator import mul
        from functools import reduce
        prod = lambda l: reduce(mul, l, 1)
    for comb in product(range(N), range(N), range(N),
                        tqdm_class=FormatCustomText,
                        desc="Iteration"):
        assert len(comb) == 3
        assert comb[0] < N
        assert comb[1] < N
        assert comb[2] < N
        assert comb[0] + comb[1] + comb[2] < 3 * N
    # Test tqdm_kwargs
    total = prod([N] * 3)
    assert total == 27

# Generated at 2022-06-24 09:55:48.361658
# Unit test for function product
def test_product():
    """Test function `product`."""
    p = product(range(3), "123", ["ABC", "DEF"],
                tqdm_class=tqdm_auto,  # use default tqdm
                desc="Testing product")

# Generated at 2022-06-24 09:55:57.914066
# Unit test for function product
def test_product():
    import sys
    import nose

    stdout = stdout_patch = None
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

# Generated at 2022-06-24 09:55:59.722941
# Unit test for function product
def test_product():
    from ..tests._utils import _test_total_wrapper
    _test_total_wrapper(product(range(3), range(4)), 12)

# Generated at 2022-06-24 09:56:02.051466
# Unit test for function product
def test_product():
    for _ in product(range(0), range(3), range(4), range(0), range(10),
                     tqdm_class=tqdm_auto, leave=True):
        pass

# Generated at 2022-06-24 09:56:10.363098
# Unit test for function product
def test_product():
    """Test function `product`."""
    from ..utils import format_sizeof
    a = list(list(range(i)) for i in range(2, 5))
    for total in [None, 1, 1e4]:
        for desc in [None, '', '  ']:
            with tqdm_auto(a, total=total,
                           miniters=0, mininterval=0.1,
                           smoothing=0, desc=desc) as t:
                assert t.total == None
                assert t.miniters == 0
                assert t.mininterval == 0.1
                assert t.smoothing == 0
                assert t.desc == desc
                for _ in t:
                    t.update()
                cnt = 0

# Generated at 2022-06-24 09:56:19.059498
# Unit test for function product
def test_product():
    import sys
    import tempfile
    from numpy import prod
    from tqdm import trange

    with tempfile.TemporaryFile('w+') as f:
        sys.stderr = f

        assert list(product([])) == []
        assert list(product([1])) == [[1]]
        assert list(product([1, 2])) == [[1, 2]]

# Generated at 2022-06-24 09:56:23.073225
# Unit test for function product
def test_product():
    l = [[1, 2, 3], [4, 5], [6, 7, 8]]
    idx = 0
    for i in product(*l):
        assert i == (1, 4, 6)
        idx += 1
        if idx == 10:
            break

# Generated at 2022-06-24 09:56:27.619913
# Unit test for function product
def test_product():
    """Unit test for function product."""
    from numpy.random import randint
    for n_inner in range(4):
        for n_outer in range(4):
            for n_iter in range(4):
                outer = [randint(0, 10, size=(n_inner, n_iter))
                         for _ in range(n_outer)]
                yield (n_inner, n_outer, n_iter), outer

# Generated at 2022-06-24 09:56:36.795130
# Unit test for function product
def test_product():
    from .._utils import _range

    def test_product_generator(gen, *ranges, **kwargs):
        """Helper function to test `product` generators"""
        tot = 1
        for r in ranges:
            tot *= len(r)
        assert hasattr(gen, "update")
        assert gen.total == tot

        values = []
        for i in gen:
            assert i not in values
            values.append(i)
        assert sorted(values) == sorted(itertools.product(*ranges))


# Generated at 2022-06-24 09:56:45.950045
# Unit test for function product
def test_product():
    from .itertoolsp import product as itertoolsp_product
    from .tests_tqdm import FakeTqdmType
    from .tests import pretest_posttest

    for i in range(1, 4):
        iterables = [range(j) for j in range(i)]
        pretest_posttest(
            product,
            itertoolsp_product,
            False,
            tqdm_class=FakeTqdmType,
            iterables=iterables)
        pretest_posttest(
            product,
            itertoolsp_product,
            True,
            tqdm_class=FakeTqdmType,
            iterables=iterables)

# Generated at 2022-06-24 09:56:54.910284
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import math
    import random
    from ..utils import chunk_len

    sum_chunks = 0
    with tqdm_auto(total=20) as pbar:
        for chunk in product(range(50), range(30), tqdm=pbar):
            sum_chunks += len(chunk)
            pbar.update(chunk_len(chunk))
    assert sum_chunks == math.fsum(range(50)) * math.fsum(range(30))

    l = random.randint(1, 20)
    sum_chunks = 0
    with tqdm_auto(total=l) as pbar:
        for chunk in product((l,), tqdm=pbar):
            sum_chunks += len(chunk)
            pbar.update

# Generated at 2022-06-24 09:57:06.527184
# Unit test for function product
def test_product():
    import sys
    import random
    import types

    random.seed(6)
    # Iterable of Iterables
    iterable = [range(random.randint(1, 10)) for i in range(random.randint(1, 5))]

    # Num iterations
    num = 1
    for i in iterable:
        num *= len(i)

    for tqdm_class in [tqdm_auto, types.FunctionType(tqdm_auto.__code__, tqdm_auto.__globals__)]:
        i = 0
        for y in product(*iterable, tqdm_class=tqdm_class, file=sys.stdout):
            i += 1
        assert i == num

        i = 0

# Generated at 2022-06-24 09:57:12.694260
# Unit test for function product
def test_product():
    """Test function product"""
    try:
        import numpy as np
    except ImportError:
        pass
    else:
        np.random.seed(0)
        iterables = [np.arange(0, 3),
                     np.random.randint(0, 10, size=4),
                     np.arange(0, 9)]
        for p in product(*iterables):
            pass


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:57:21.705152
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range

    @with_setup(None, lambda: None)
    def inner(n):
        # Check iterator
        # sm = sum(i**2 for i in utils.product(range(n), repeat=2))
        sm = sum(i[0] ** 2 + i[1] ** 2 for i in product(_range(n), repeat=2))
        # sm2 = sum(i[0] ** 2 + i[1] ** 2 + i[2] ** 2 for i in
        #          tqdm_utils.product(_range(n), repeat=3))
        assert sm == n * (n + 1) * (2 * n + 1) / 6, sm

    for n in [1, 2, 4, 16]:
        inner(n)

# Generated at 2022-06-24 09:57:32.066928
# Unit test for function product
def test_product():
    """Test for the ``product`` function."""
    from ..utils import FormatCustomTextExtension, IdentityFormatCustomText
    seq = range(8)
    assert tuple(product(seq, seq, seq)) == tuple(
        itertools.product(seq, seq, seq))
    assert tuple(product(seq, seq, seq, tqdm_class=tqdm_auto)) == tuple(
        itertools.product(seq, seq, seq))
    assert tuple(product(seq, seq, seq, tqdm_class=FormatCustomTextExtension)) == tuple(
        itertools.product(seq, seq, seq))
    assert tuple(product(seq, seq, seq, tqdm_class=IdentityFormatCustomText)) == tuple(
        itertools.product(seq, seq, seq))

# Generated at 2022-06-24 09:57:42.474812
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    import numpy as np
    from ..utils import format_sizeof
    results = []
    # it = product(np.arange(9), np.arange(9))
    it = product(range(9), range(9))
    for i in it:
        results.append(i)
    assert len(results) == 81
    for i in product(range(9), range(9)):
        assert i in results
    for i in product(range(9), range(9), tqdm_class=tqdm_auto, unit='things'):
        assert i in results
    for i in product(range(9), range(9), tqdm_class=tqdm_auto, leave=False):
        assert i in results

# Generated at 2022-06-24 09:57:47.198785
# Unit test for function product
def test_product():
    """
    Test function `product`
    """
    assert list(product(range(3), range(3), range(3), range(3),
                        tqdm_class=tqdm_auto)) \
        == list(itertools.product(range(3), range(3), range(3), range(3)))

# Generated at 2022-06-24 09:57:54.972480
# Unit test for function product
def test_product():
    from sys import stdout
    from .utils import FormatCustomiser

    format_str = "Custom bar format: [{l_bar}{bar}{r_bar}] {n_fmt}/{total_fmt} [{rate_fmt}{postfix}]"
    format_dict = {"l_bar": "", "r_bar": " ", "n_fmt": "3s", "total_fmt": "3s", "rate_fmt": "6s"}

    fc = FormatCustomiser(format_str, format_dict)
    with tqdm_auto(
            product("ABCD", "1234", "xy", "a"),
            desc="description", unit="it", file=stdout,
            format_customiser=fc,
            leave=False) as t:
        for _ in t:
            pass

# Generated at 2022-06-24 09:57:58.864102
# Unit test for function product
def test_product():
    """
    Unit test for function product.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    from ..auto import trange

    for i in trange(10, leave=False):
        for j in product(range(10), range(0, 100, 10),
                         iterable=trange):
            pass

# Generated at 2022-06-24 09:58:08.987021
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    assert list(product([0, 1], repeat=0)) == [()]
    assert list(product([0, 1], repeat=1)) == [(0,), (1,)]
    assert list(product([0, 1], repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product([0, 1], repeat=3)) == [
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)
    ]

# Generated at 2022-06-24 09:58:13.078208
# Unit test for function product
def test_product():
    """Test function `product`

    Unit test for function `product` using `tqdm.tqdm`.
    """
    from ..tests import _test_product_eq

    _test_product_eq(tqdm_auto)
    _test_product_eq(tqdm_auto, desc="test")

# Generated at 2022-06-24 09:58:23.503446
# Unit test for function product
def test_product():
    from ._utils import format_sizeof
    import multiprocessing
    import numpy as np
    import os

    try:
        from PIL import Image
    except ImportError:
        try:
            import Image
        except ImportError:
            Image = None

    def mock_iter(n):
        for i in range(n):
            yield i

    def mock_iter_len(n):
        for i in range(n):
            yield i, i

    def mock_iter_pipe_with_len(n, pipe):
        for i in range(n):
            yield i
            pipe.send(i)

    def mock_iter_pipe_no_len(n, pipe):
        for i in range(n):
            yield i
            pipe.send(None)


# Generated at 2022-06-24 09:58:33.111695
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np

    # test with no _progbar
    for a, b, c in product(np.arange(3), np.arange(3),
                           tqdm_class=lambda x: x):
        pass

    # test with _progbar
    for a, b, c in product(np.arange(3), np.arange(3),
                           tqdm_class=lambda x: x,
                           _progbar=True):
        pass

    # test with total
    for a, b, c in product(np.arange(3), np.arange(3),
                           tqdm_class=lambda x: x):
        pass

    # test with total and _progbar

# Generated at 2022-06-24 09:58:39.873554
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    from .itertools import product as tqdm_product
    from .utils import BaseTestCase

    class productTest(BaseTestCase):
        def test_product(self):
            for args in [
                ([1],),
                ([1, 2],),
                ([1, 2, 3], [3, 4], [4, 5]),
                ([1, 2], [3, 4], [5, 6, 7]),
            ]:
                assert_equal(list(product(*args)), list(tqdm_product(*args)))

# Generated at 2022-06-24 09:58:44.786059
# Unit test for function product
def test_product():
    import numpy as np
    assert np.allclose(
        np.array([p for p in product(range(1, 4), range(1, 4), range(1, 4))]),
        np.array([
            [i, j, k]
            for i in range(1, 4)
            for j in range(1, 4)
            for k in range(1, 4)
        ])
    )

# Generated at 2022-06-24 09:58:55.963070
# Unit test for function product
def test_product():
    from .tests import TestCase
    from ..tests.common import closing
    from .utils import format_sizeof

    with closing(TestCase()) as tc:
        tc.assert_equal(
            list(product(range(5), repeat=2)),
            list(product(range(5), range(5))))
        tc.assert_equal(
            list(product([1], repeat=5)),
            [[1] * 5])
        tc.assert_equal(
            list(product(range(5), repeat=0)),
            [()])
        tc.assert_equal(
            list(product(range(5), repeat=10)),
            [(i,) * 10 for i in range(5)])