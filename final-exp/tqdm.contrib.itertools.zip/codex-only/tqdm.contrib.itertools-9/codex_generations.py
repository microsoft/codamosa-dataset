

# Generated at 2022-06-24 09:48:48.866620
# Unit test for function product
def test_product():
    """
    Simple unit test for itertools.product.
    """
    from .. import trange
    from .utils import TotalSpy
    # pylint: disable=redefined-outer-name
    assert list(product(range(10))) == list(itertools.product(range(10)))
    assert list(product(range(10), range(10))) == \
        list(itertools.product(range(10), range(10)))

    assert list(product(range(10), range(10), tqdm_class=trange.tqdm)) == \
        list(itertools.product(range(10), range(10)))

# Generated at 2022-06-24 09:48:57.547727
# Unit test for function product
def test_product():
    """
    Unit test for function `product`
    """
    import sys
    import os
    import random
    from functools import partial

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio    # free up some memory
            sys.stdout = self._stdout

    class MyTQDM(tqdm_auto):
        @property
        def lines(self):
            """
            Number of lines printed in one epoch (one iteration of
            internal loop).
            """
            return 1


# Generated at 2022-06-24 09:49:06.752050
# Unit test for function product
def test_product():
    """Unit test for function `product`

    Test that totals are properly computed (without progress bars) and that
    tqdm.total is set.
    """
    from ..__main__ import tqdm_main
    from .testsets import lrange
    iterables = [lrange(3), 'xyz', lrange(4), lrange(5)]
    for iterable in lrange(4):  # check that tqdm.total is set
        for i, _ in enumerate(tqdm_main(product(iterables[iterable]))):
            assert i+1 == tqdm_main.total
        assert i+1 == tqdm_main.total
        assert i+1 == tqdm_main.n

    assert tqdm_main.total == 3*3*3*3

    # Test totals without progress

# Generated at 2022-06-24 09:49:10.485779
# Unit test for function product
def test_product():
    from tqdm import tqdm
    l = list(product(
        range(10),
        'dsa',
        tqdm_class=tqdm,
        desc="testing mutation",
        leave=False))
    assert len(l) == 30
    assert l[0] == (0, 'd')
    assert l[-1] == (9, 'a')

# Generated at 2022-06-24 09:49:14.083146
# Unit test for function product
def test_product():
    """Test function `product`"""
    test_range = list(range(100))
    assert sum(product(test_range, test_range, tqdm_class=tqdm_auto)) == 3297500

# Generated at 2022-06-24 09:49:23.754379
# Unit test for function product
def test_product():
    from ..std import MockTqdmType
    from ..testing import closing

    # Test total
    with closing(MockTqdmType(total=10)) as t:
        for _ in product(range(4), range(4), tqdm_class=MockTqdmType):
            pass
    assert t.n == 10

    # Test product
    l = list(product(range(3), repeat=3))

# Generated at 2022-06-24 09:49:34.342067
# Unit test for function product
def test_product():
    import numpy as np
    # TODO: numpy.prod(axis=None) returns an array,
    # but should it be a scalar?
    # try:
    #     total = np.prod([len(('A', 'B')), len(('C', 'D'))])
    #     assert (total == 4)
    # except:
    #     pass
    total = 4
    for i, _ in enumerate(product(('A', 'B'), ('C', 'D'), tqdm_class=tqdm_auto)):
        assert (i < total)
    assert (i == total - 1)


from .__common import tqdm as tqdm_common
from .iterables import *
from .dummy import *
from .decorators import *

# Generated at 2022-06-24 09:49:45.205710
# Unit test for function product
def test_product():
    """Unit test for `tqdm.itertools.product`"""
    from tqdm import tqdm_gui
    import pytest

    def prod(*args):
        "Product of list of lists"
        p = 1
        for a in args:
            p *= len(a)
        return p

    for i in range(2):
        if i:
            from tqdm import trange
        else:
            from tqdm.auto import tqdm as trange
        for j in range(3):
            p = trange(2 + j, desc='test', mininterval=0.)
            if i:
                with p:
                    for _ in product(*(['ab', 'cd', 'efg'][:j]
                                       if j else ['ab'])):
                        pass

# Generated at 2022-06-24 09:49:50.625143
# Unit test for function product
def test_product():
    import pytest
    from .tqdm_gui import tqdm

    assert '0.8' in tqdm.__version__

    from .utils import FormatStrenthTestIO
    with FormatStrenthTestIO() as fstio:
        for _ in product(range(100), range(200), range(300)):
            pass
        assert fstio.unsupported_formats == []

# Generated at 2022-06-24 09:49:59.903132
# Unit test for function product
def test_product():
    "Test if function product works as expected"
    from six.moves import range
    from ..utils import FormatCustomText
    from ..std import _range
    import sys

    def _get_raises_msg(e):
        return (FormatCustomText(
            "ERROR: stderr from {module}:\n{traceback}",
            module=__name__, traceback=e.args[0]) + '\n')


# Generated at 2022-06-24 09:50:10.367457
# Unit test for function product
def test_product():
    from ..utils import freeze_support

    def test_list_equal(list_a, list_b):
        assert len(list_a) == len(list_b)
        for el_a, el_b in zip(list_a, list_b):
            assert el_a == el_b

    def unit_test(iter1, iter2):
        target = list(itertools.product(iter1, iter2))
        test = list(product(iter1, iter2, desc='product', miniters=1))
        test_list_equal(target, test)

    freeze_support()  # handle import errors in frozen environments

    unit_test(range(10), [chr(97 + i) for i in range(10)])
    unit_test(range(10), range(10))

# Generated at 2022-06-24 09:50:20.338732
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..pandas import tqdm
    test_dict = {'a': [1, 2], 'b': [3, 4, 5]}
    assert set(
        product(test_dict['a'], test_dict['b'], tqdm_class=tqdm)) == set(
            itertools.product(test_dict['a'], test_dict['b']))

    test_dict = {
        'a': [1, 2, 3],
        'b': [1, 2, 3, 4],
        'c': [1, 2, 3, 4, 5],
    }

# Generated at 2022-06-24 09:50:28.945275
# Unit test for function product
def test_product():
    x = product(range(10), range(10))
    assert isinstance(x, type(product(range(10))))
    assert sum(1 for _ in x) == 100
    assert sum(1 for _ in x) == 100

    x = product(range(10), range(10), tqdm_class=tqdm_auto)
    assert isinstance(x, type(product(range(10))))
    assert sum(1 for _ in x) == 100
    assert sum(1 for _ in x) == 100

    x = product(range(10), range(10), tqdm_class=tqdm_auto)
    assert isinstance(x, type(product(range(10))))
    assert sum(1 for _ in x) == 100
    assert sum(1 for _ in x) == 100


# Generated at 2022-06-24 09:50:38.472083
# Unit test for function product
def test_product():
    from random import getrandbits
    from .utils import FormatMixin

    class tqdm(FormatMixin, tqdm_auto, object):
        """
        Fake class for testing
        """
        @property
        def n(self):
            """Return current iteration"""
            return self.last_print_n

    for nbits in range(10):
        a = [getrandbits(nbits) for _ in range(10)]
        b = [getrandbits(nbits) for _ in range(10)]
        c = [getrandbits(nbits) for _ in range(10)]
        with tqdm(unit="it") as t:
            for i, j, k in product(a, b, c, tqdm_class=tqdm):
                assert i in a and j in b and k in c
               

# Generated at 2022-06-24 09:50:48.378067
# Unit test for function product
def test_product():
    import sys
    import io
    import unittest

    class TestTqdm(unittest.TestCase):
        def check_tqdm(self, iterable, desc, total=None, leave=False,
                       iterable_len=None, **kwargs):
            """
            Tests tqdm progressbar and correctness of iteration.
            """
            if iterable_len is None:
                try:
                    iterable_len = len(iterable)
                except:
                    iterable_len = None

            with tqdm_auto(iterable,
                           desc=desc,
                           total=total,
                           leave=leave,
                           **kwargs) as t:
                if total in [0, None]:
                    self.assertIs(next(t), iterable_len)

# Generated at 2022-06-24 09:50:56.210064
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`
    """
    # Test basic functionality
    L = range(3); S = 'abc'
    assert current_tqdm().write(list(product(L, S))) == 'Product: 6 iterables |'
    assert current_tqdm().write(list(product(L))) == 'Product: 1 iterable |'
    assert current_tqdm().write(list(product(S))) == 'Product: 1 iterable |'

# Generated at 2022-06-24 09:51:04.837439
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from ..std import StringIO
    import sys
    # Construct test data
    data = [list(range(x)) for x in [2, 3, 5]]
    # Redirect stdout to a buffer
    sys.stdout = StringIO()
    for ele in product(*data):
        print(ele)
    sys.stdout.seek(0)
    # Read from buffer
    lines = sys.stdout.readlines()
    # Restore console
    sys.stdout = sys.__stdout__
    # Assertions
    assert len(lines) == sum(map(len, data))

# Generated at 2022-06-24 09:51:09.839867
# Unit test for function product
def test_product():
    """Unit test for function product"""
    x = product(range(1000), repeat=2, tqdm_class=None)
    assert len(list(x)) == 1000**2
    x = product(range(1000), repeat=2, tqdm_class=tqdm_auto)
    assert len(list(x)) == 1000**2

# Generated at 2022-06-24 09:51:12.909522
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    it = product(range(2), range(2), range(2),
                 range(2), range(2), tqdm_class=tqdm_auto)
    assert sum(1 for _ in it) == 64

# Generated at 2022-06-24 09:51:19.724881
# Unit test for function product
def test_product():
    import numpy as np
    # 6 products of 2 elements
    products = list(product(range(3), range(3)))
    assert products == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0),
                        (2, 1), (2, 2)]
    np_array = np.array(products)
    assert np.all(np_array.sum(axis=1) == np.array([0, 1, 2, 1, 2, 3, 2, 3, 4]))
    assert len(tuple(product(range(3)))) == 3

# Generated at 2022-06-24 09:51:25.526001
# Unit test for function product
def test_product():
    import faker
    from faker.providers import address
    fake = faker.Faker()
    fake.add_provider(address)
    fake_iter = (fake.city() for _ in range(10))

    assert list(product(fake_iter)) == list(itertools.product(fake_iter))


if __name__ == "__main__":
    from pytest import main  # type: ignore
    main([__file__])

# Generated at 2022-06-24 09:51:29.197042
# Unit test for function product
def test_product():
    """
    A little unit test for the ``product`` function.
    """
    res = product(range(3), ['a', 'b'], tqdm_class=tqdm_auto)
    out = list(res)
    assert out == list(itertools.product(range(3), ['a', 'b']))

# Generated at 2022-06-24 09:51:31.384576
# Unit test for function product
def test_product():
    assert list(product('ABCD', 'xy', tqdm_class=None)) == list(itertools.product('ABCD', 'xy'))

# Generated at 2022-06-24 09:51:36.381114
# Unit test for function product
def test_product():
    from ..tests import TestCase, closing

    with closing(TestCase()) as TC:
        list(product(range(2), range(2), tqdm_class=tqdm_auto)) == list(itertools.product(range(2), range(2)))
        TC.assertTrue(TC.tqdm.write.called)

# Generated at 2022-06-24 09:51:41.422174
# Unit test for function product
def test_product():
    """ Unit test for function product"""
    import numpy as np
    s = np.random.rand(10, 3)

    def func(a, b, c):
        return a**2 + b + c

    res = []
    for i, j, k in product(s[:, 0], s[:, 1], s[:, 2]):
        res.append(func(i, j, k))
    res = np.array(res)
    assert (res == np.apply_along_axis(func, 1, s)).all()

# Generated at 2022-06-24 09:51:44.313316
# Unit test for function product
def test_product():
    total = 0
    for i in product(range(3), range(3), range(3)):
        total += 1
        assert total == sum(i) + 1


test_product()

# Generated at 2022-06-24 09:51:46.708279
# Unit test for function product
def test_product():
    s = 'abc'
    for i in product(s, repeat=2, tqdm_class=lambda x: x):
        pass
    assert (i == ('c', 'c'))



# Generated at 2022-06-24 09:51:53.369248
# Unit test for function product
def test_product():
    """
    Unit test of `itertools.product`
    """
    assert (list(product(xrange(1000), xrange(1000))) ==
            list(itertools.product(xrange(1000), xrange(1000))))
    assert (list(product(xrange(1000), xrange(1000), tqdm_class=None)) ==
            list(itertools.product(xrange(1000), xrange(1000))))

# Generated at 2022-06-24 09:52:02.499000
# Unit test for function product
def test_product():
    """Unit test for function product"""

# Generated at 2022-06-24 09:52:12.491116
# Unit test for function product
def test_product():
    from .testit import testit
    from .compatibility import IS_WIN

    # Assert `total` in `product`
    assert testit(lambda: list(product(list(range(500)),
                                       tqdm_class=tqdm_auto))) == \
        [[0, 0], [0, 1], [0, 2], [0, 3], [0, 4], [1, 0], [1, 1], [1, 2],
         [1, 3], [1, 4], [2, 0], [2, 1], [2, 2], [2, 3], [2, 4], [3, 0],
         [3, 1], [3, 2], [3, 3], [3, 4], [4, 0], [4, 1], [4, 2], [4, 3],
         [4, 4]]


# Generated at 2022-06-24 09:52:16.494954
# Unit test for function product
def test_product():
    import numpy as np
    lens = np.random.randint(1, 10, size=5)
    iterables = [list(range(i)) for i in lens]

    count = 0
    for _ in product(*iterables):
        count += 1
    assert count == int(np.prod(lens))

# Generated at 2022-06-24 09:52:20.793845
# Unit test for function product
def test_product():
    for i in product(range(4), range(4), tqdm_class=tqdm_auto):
        pass
    for i in product(range(4), range(4), range(4), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:52:29.255577
# Unit test for function product
def test_product():
    """
    Unit testing for `product`.
    """
    import random
    import string
    list_1 = 'abcdefg'
    list_2 = 'hijklmn'

    list_1_1 = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    list_2_1 = ['h', 'i', 'j', 'k', 'l', 'm', 'n']
    list_3_1 = ['a', 'b', 'c', 'h', 'i', 'j', 'k', 'l', 'm']
    list_4_1 = ['a', 'h', 'ae', 'hi', 'af', 'hj', 'ag', 'hk', 'a', 'hi']

    list_1_2 = random.sample(string.ascii_letters, 7)

# Generated at 2022-06-24 09:52:39.441984
# Unit test for function product
def test_product():
    """Test for function product"""
    class Foo:
        def __init__(self):
            self.foo = list(range(10))

        def __len__(self):
            return len(self.foo)

        def __getitem__(self, i):
            return self.foo[i]

    assert (list(range(3)) == list(tqdm_auto.product(range(3))))
    assert (list(range(3)) == list(tqdm_auto.product(Foo())))
    for i in tqdm_auto.product(range(10)):
        assert (i <= 10)
    assert (len(list(tqdm_auto.product(range(10), range(5), range(3)))) == 10 * 5 * 3)

# Generated at 2022-06-24 09:52:42.401905
# Unit test for function product
def test_product():
    """Test function product"""
    from ..utils import FormatStopSizeStop
    with FormatStopSizeStop():
        list(product([1, 2, 3], ['a', 'b', 'c'], tqdm_class=tqdm_auto))

# Generated at 2022-06-24 09:52:51.463776
# Unit test for function product
def test_product():
    """Test for function product"""
    # skip if there's no tqdm
    try:
        import tqdm
    except ImportError:
        return
    # test case 1: no `total` kwargs
    try:
        iterable = (range(5), 'ab')
        mapper = product(*iterable)
        assert mapper.total == None
        assert len(list(mapper)) == len(list(itertools.product(*iterable)))
    except Exception:
        _ = None
    # test case 2: with `total` kwargs
    try:
        iterable = product(range(5), 'ab', tqdm_class=tqdm.tqdm, total=15)
        assert len(list(iterable)) == 15
    except Exception:
        _ = None
    # test case 3

# Generated at 2022-06-24 09:53:02.337737
# Unit test for function product
def test_product():
    L = [range(1000), range(1000), range(10)]
    total_len = 1000 * 1000 * 10
    assert sum(1 for _ in product(*L, tqdm_class=tqdm_auto, leave=False)) == \
        total_len
    assert sum(1 for _ in product(*L, tqdm_class=tqdm_auto, total=total_len,
                                  leave=False)) == total_len


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 09:53:08.887665
# Unit test for function product
def test_product():
    """
    >>> list_ = list(product(range(3), range(3), tqdm_class=tqdm))
    100%|██████████| 9/9 [00:00<00:00, 120219.22it/s]
    >>> list_
    [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]
    """
    pass


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 09:53:16.238301
# Unit test for function product
def test_product():
    "Unit test of `itertools.product` wrapper"
    import io
    import sys
    import os
    import random
    from contextlib import closing
    from itertools import permutations
    from .._utils import _range
    with closing(io.BytesIO()) as our_file, \
            closing(io.BytesIO()) as spy_file:
        def seek(offset):
            "Helper to seek stdout to a known byte offset"
            our_file.seek(offset)
            spy_file.seek(offset)

        for test_case in range(5):
            stdout = sys.stdout

# Generated at 2022-06-24 09:53:24.094198
# Unit test for function product
def test_product():
    product(range(10), range(5))
    product(range(10), range(5), tqdm_class=tqdm_auto)
    product(range(10), range(5), tqdm_class=tqdm_auto, desc="testing")
    product(range(10), range(5), tqdm_class=tqdm_auto, miniters=2)
    product(range(10), range(5), tqdm_class=tqdm_auto, maxinterval=1)
    product(range(10), range(5), tqdm_class=tqdm_auto, mininterval=1)
    product(range(10), range(5), tqdm_class=tqdm_auto, mininterval=1, maxinterval=1)

# Generated at 2022-06-24 09:53:29.419095
# Unit test for function product
def test_product():
    for i, j in product(range(10), repeat=2):
        assert i in range(10) and j in range(10)
    for i, j, k in product(range(10), range(20), range(30)):
        assert i in range(10) and j in range(20) and k in range(30)

# Generated at 2022-06-24 09:53:38.968956
# Unit test for function product
def test_product():
    """Test unit for `product` method"""
    import sys
    from ..utils import __version__
    m = min(len(__version__), 3)
    if not sys.version_info[:m] >= (3, 3, 0):
        raise SkipTest("Test requires Python >= (3, 3, 0), current is {}".format(
            sys.version_info))
    from ..compat import range
    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-24 09:53:45.616231
# Unit test for function product
def test_product():
    assert list(
        product('abc', 'xy', tqdm=tqdm_auto, ascii=True, total=None)) == list(
            itertools.product('abc', 'xy'))
    assert list(
        product('abc', 'xy',
                tqdm_class=tqdm_auto,
                ascii=True,
                total=None)) == list(
                    itertools.product('abc', 'xy'))

# Generated at 2022-06-24 09:53:52.261600
# Unit test for function product
def test_product():
    """Test function `product`."""
    import math
    import sys
    import time
    import random
    # Test 1
    t1 = time.time()
    for _, i in enumerate(product("ABCDEFG", repeat=2)):
        pass
    t2 = time.time()
    assert _ == (7 ** 2) - 1
    print("test 1 (no total) passed in", t2 - t1)
    # Test 2
    t1 = time.time()
    for _, i in enumerate(product("ABCDEFG", repeat=2, total=7 ** 2)):
        pass
    t2 = time.time()
    assert _ == (7 ** 2) - 1
    print("test 2 (with total) passed in", t2 - t1)
    # Test 3

# Generated at 2022-06-24 09:53:58.879453
# Unit test for function product
def test_product():
    it = product('AB', 'cd')
    assert next(it) == ('A', 'c')
    assert next(it) == ('A', 'd')
    assert next(it) == ('B', 'c')
    assert next(it) == ('B', 'd')
    try:
        next(it)
        assert False, "StopIteration expected but not raised"
    except StopIteration:
        pass

# Generated at 2022-06-24 09:54:02.527249
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    for i in product([1, 2, 3], [4]):  # Test with tqdm=False
        assert i == (1, 4) or i == (2, 4) or i == (3, 4)


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:54:07.003618
# Unit test for function product
def test_product():
    """Simple unit test for function `product`"""
    from numpy.testing import assert_array_equal
    for iterables in [
            (range(4), range(4)),
            (['a', 'b', 'c'], [1, 2]),
            (['a', 'b', 'c'], [1, 2], [1, 2])
    ]:
        assert_array_equal(list(itertools.product(*iterables)),
                           list(product(*iterables)))

# Generated at 2022-06-24 09:54:16.880070
# Unit test for function product
def test_product():
    from ..utils import FormatWrapBytes
    from .utils import format_sizeof
    import numpy as np
    import sys
    import warnings

    _, total = product(range(4),  # 1
                       range(1, 101),  # 100
                       range(2, 3),  # 1
                       range(4, 7),  # 3
                       tqdm_class=tqdm_auto,
                       total=False
                       )  # (1 * 100 * 1 * 3) = 300
    assert total == 300

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=UserWarning)
        assert 500 == sum(1 for _ in product(range(3),
                                            range(2),
                                            tqdm=lambda x: x,
                                            total=False))

    # Test with manual

# Generated at 2022-06-24 09:54:22.693391
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from tqdm import trange
    for n in trange(100):
        for m in trange(100):
            for k in trange(100):
                I = list(range(n))
                J = list(range(m))
                K = list(range(k))
                ip = product(I, J, K)
                assert_equal(list(ip), list(itertools.product(I, J, K)))

# Generated at 2022-06-24 09:54:26.987552
# Unit test for function product
def test_product():
    """
    Unit test to check that the dummy wrapper works
    """
    assert [i for i in product([1, 2, 3], [4, 5, 6])] == [
        (1, 4), (1, 5), (1, 6),
        (2, 4), (2, 5), (2, 6),
        (3, 4), (3, 5), (3, 6)
    ]

# Generated at 2022-06-24 09:54:35.068686
# Unit test for function product
def test_product():
    """Test that the wrapper runs at least"""
    import numpy as np
    # list(product(range(10), range(10), range(10)))
    assert (False not in np.array([i == j for i, j in
                                   zip(product(range(10), range(10),
                                               range(10)),
                                       itertools.product(range(10),
                                                         range(10),
                                                         range(10)))]))


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 09:54:41.389473
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    from .common import closing, TemporaryFile

    with closing(TemporaryFile()) as f:
        t_total = 0
        for t in product(range(10),
                         range(10),
                         tqdm_class=tqdm_auto,
                         file=f):
            t_total += 1
        f.seek(0)
        assert "100it" in f.read().decode("utf-8")
        assert t_total == 100



# Generated at 2022-06-24 09:54:47.653729
# Unit test for function product
def test_product():
    from itertools import product as iproduct
    for iterables in ([[0, 1], [0, 1], [0, 1]],
                      ["abc", "def"],
                      [0.0, 1.0]):
        assert list(product(*iterables)) == list(iproduct(*iterables))
        assert list(product(*iterables, total=0)) == list(iproduct(*iterables))
        assert list(product(*iterables, total=-1)) == list(iproduct(*iterables))
        assert list(product(*iterables, total=None)) == list(iproduct(*iterables))

# Generated at 2022-06-24 09:54:57.318817
# Unit test for function product
def test_product():
    from numpy.random import random
    check_conv = lambda x, y: int(x*10**y)
    rnd = lambda: check_conv(*random() + (2,)) / 10.**2
    iterations = rnd()
    iterables = [rnd() for _ in range(rnd())]

    test_outputs = []
    for x in product(*iterables, total=iterations):
        test_outputs.append(x)

    ref_outputs = []
    for x in itertools.product(*iterables):
        ref_outputs.append(x)

    assert test_outputs == ref_outputs

# Generated at 2022-06-24 09:54:58.614657
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    pass

# Generated at 2022-06-24 09:55:05.024853
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..contrib.concurrency import thread_map

    def func(arg):
        """
        Dummy function
        """
        return arg

    assert list(product(range(4), repeat=2)) == list(itertools.product(range(4), repeat=2))
    assert list(product(range(4), repeat=2, tqdm_class=None)) == list(itertools.product(range(4), repeat=2))
    assert list(product(range(4), repeat=2, tqdm_class=tqdm_auto)) == list(itertools.product(range(4), repeat=2))

# Generated at 2022-06-24 09:55:11.695258
# Unit test for function product
def test_product():
    """
    Test function product
    """
    from ..utils import format_sizeof
    import random

    random.seed(0)
    ranges = [
        list(range(random.randint(1, 10000)))
        for i in range(random.randint(1, 50))
    ]
    z = 0
    for i in product(*ranges):
        z += 1
    assert z == reduce(lambda x, y: len(x) * len(y), ranges, 1)

# Generated at 2022-06-24 09:55:24.539575
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    assert list(product(range(10), repeat=3)) == list(itertools.product(
        range(10), repeat=3))
    assert list(product(range(10), repeat=3, tqdm_class=None)) == list(
        itertools.product(range(10), repeat=3))
    # Test for issue #309
    assert list(product([1], [2], tqdm_class=None)) == [(1, 2)]
    # Test for issue #578

# Generated at 2022-06-24 09:55:31.345671
# Unit test for function product
def test_product():
    """Test for product"""
    from ..utils import FormatCustomText

    class TqdmBarFormatCustomText(FormatCustomText):
        def update_to(self, b):
            self.n = b.n
            self.total = b.total

    for n in range(4):
        for total in [10 ** 3, float('inf')]:
            with TqdmBarFormatCustomText(total=total) as bar:
                it = product(range(n), tqdm_class=TqdmBarFormatCustomText,
                             total=total)
                assert next(it) == (0,)
                bar.write("test")
                assert next(it) == (1,)
                bar.write("test1")

# Generated at 2022-06-24 09:55:36.886035
# Unit test for function product
def test_product():
    """
    Basic unit tests for `tqdm.tqdm.product`.
    """
    from warnings import catch_warnings
    from itertools import product

    with catch_warnings(record=True):
        assert list(product(
            'abc', 'de', range(3), tqdm=tqdm_auto)) == list(product(
                'abc', 'de', range(3)))


# Test decorator
if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:55:42.466497
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing

    with closing(TestCase) as case:
        for i in product(range(4), range(4), range(4)):
            assert i[0] < 4 and i[1] < 4 and i[2] < 4
        case.assertEqual(case.sp.n, 4**3)
        case.assertEqual(case.sp.smoothed, 1.0)
        case.assertEqual(case.sp.avg, 1.0)
        case.assertEqual(case.sp.l_avg_time, case.sp.r_avg_time)
        assert case.sp.l_avg_time > 0
        assert case.sp.r_avg_time > 0

# Generated at 2022-06-24 09:55:49.798430
# Unit test for function product
def test_product():
    """validate function `product`"""
    from ..utils import format_sizeof
    for i, _ in enumerate(product('0123456789', '0123456789', tqdm_class=None), 1):
        pass
    assert i == 10**2
    assert format_sizeof(i) == "10"

    seq = range(10)
    i = 0
    for _ in product(seq, seq, tqdm_class=None):
        i += 1
    assert i == 10 ** 2
    assert format_sizeof(i) == "10"

    seq = list(range(100))
    i = 0
    for _ in product(seq, tqdm_class=None):
        i += 1
    assert i == 100
    assert format_sizeof(i) == "100"


# Generated at 2022-06-24 09:55:56.283698
# Unit test for function product
def test_product():
    """
    Test function product
    """
    assert list(product([], range(3))) == []
    assert list(product([], range(3), range(3))) == []
    assert list(product(range(2), range(3))) == [
        (0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2)
    ]
    assert list(product(range(4), repeat=4)) == list(
        itertools.product(range(4), repeat=4))

# Generated at 2022-06-24 09:56:04.033487
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .loop import tqdm_pandas
    from .utils import FormatCustomTextTest

    # Test that the unit test itself is working
    list(product('ABC', [1, 2])) == [('A', 1), ('A', 2), ('B', 1), ('B', 2), ('C', 1), ('C', 2)]

    # Test that 'total' is working
    with tqdm_auto(total=0) as t:
        with tqdm_auto(total=5) as t:
            assert t.total == 5
            t.update()  # to silence pyflakes unused variable warning

# Generated at 2022-06-24 09:56:09.542139
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    s = list('ABCD')
    p = list(product(s, repeat=2))
    assert p[0] == ('A', 'A')
    assert p[-1] == ('D', 'D')
    p = list(product(s, repeat=3))
    assert p[0] == ('A', 'A', 'A')
    assert p[-1] == ('D', 'D', 'D')
    assert len(p) == 64
    p = list(product([0, 1, 2], [0, 1, 2]))
    assert p == [(0, 0), (0, 1), (0, 2),
                 (1, 0), (1, 1), (1, 2),
                 (2, 0), (2, 1), (2, 2)]


# Generated at 2022-06-24 09:56:15.349784
# Unit test for function product
def test_product():
    for i, _ in zip(product('ABC', 'xy'), itertools.product('ABC', 'xy')):
        assert i == _, "product('ABC', 'xy') failed"
    # returncode
    assert 0 == main_func(['product', 'ABC', 'xy'])
    assert 1 == main_func(['product'])
    assert 1 == main_func(['product', 'ABC', 'xy', '-x', '1'])



# Generated at 2022-06-24 09:56:24.505794
# Unit test for function product
def test_product():
    import sys
    import nose.tools as nt
    import numpy as np
    from .utils import closing, report
    from .. import tqdm_notebook as tn
    from .tests_tqdm import pretest_posttest

    @pretest_posttest
    def test_product_mock():
        total = 50 * 10 * 2 * 5 * 2 * 2 * 100 * 5
        with closing(tn.tqdm_notebook(leave=False)) as t:
            for i in product(
                    range(50), range(10), (".", ","),
                    (str, float), (1, 2), [0, 1, 2],
                    range(100), tuple(range(5))):
                t.update()

    @pretest_posttest
    def test_product_mock1():
        total = 50

# Generated at 2022-06-24 09:56:29.369888
# Unit test for function product
def test_product():
    rng = range(10)
    assert list(product(rng, rng)) == list(itertools.product(rng, rng))
    assert list(product(rng, rng, tqdm=lambda x: x)) == list(itertools.product(rng, rng))
    assert list(product(rng, rng, unit="tup")) == list(itertools.product(rng, rng))

# Generated at 2022-06-24 09:56:32.708928
# Unit test for function product
def test_product():
    for _ in product('ABC', 'x', tqdm_class=tqdm_auto):
        pass
    for _ in product(range(5), range(10), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:56:43.338230
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from tqdm._utils import _term_move_up

    with tqdm_auto(total=8) as t:
        for (a, b, c) in product(range(2), range(2), range(2)):
            t.update()

    with tqdm_auto(unit='p') as t:
        for (a, b, c) in product(range(2), range(2), range(2)):
            t.update()

    with tqdm_auto(unit='p', file=open(os.devnull, 'w')) as t:
        for (a, b, c) in product(range(2), range(2), range(2)):
            t.update()
            assert _term_move_up() in t.file.write('')

# Generated at 2022-06-24 09:56:47.274797
# Unit test for function product
def test_product():
    """Test of product"""
    import sys
    import time
    with tqdm_auto(total=10, file=sys.stdout, unit_scale=True) as t:
        for i in product(range(10), range(10), tqdm_class=tqdm_auto):
            time.sleep(0.1)

# Generated at 2022-06-24 09:56:49.464812
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    product_range = range(10)

# Generated at 2022-06-24 09:56:56.949172
# Unit test for function product
def test_product():
    """Test function `product`."""
    L1 = [1, 2]
    L2 = ["a", "b"]
    L3 = [["i0", "i1"], ["j0"]]
    for item in product(L1, L2, L3):
        assert len(item) == 3
        assert item[0] == 1 or item[0] == 2
        assert item[1] == "a" or item[1] == "b"
        assert item[2] == ["i0", "i1"] or item[2] == ["j0"]

    for item in product(L1, L2, L3):
        assert len(item) == 3
        assert item[0] == 1 or item[0] == 2
        assert item[1] == "a" or item[1] == "b"
       

# Generated at 2022-06-24 09:56:59.311594
# Unit test for function product
def test_product():
    from . import _test_given_example
    _test_given_example('itertools.product',
                        product,
                        itertools.product)

# Generated at 2022-06-24 09:57:01.614392
# Unit test for function product
def test_product():
    for i in product('ABCD', 'xy'):
        assert i == ('A', 'x')
        break
    for i in product(range(2), repeat=3):
        assert i == (0, 0, 0)
        break

# Generated at 2022-06-24 09:57:11.792549
# Unit test for function product
def test_product():
    """Test function both with and without tqdm"""
    for tqdm_class in (tqdm_auto, None):
        it = product(range(2), repeat=2, tqdm_class=tqdm_class,
                     desc="test") if tqdm_class else itertools.product(
                         range(2), repeat=2)
        assert list(it) == [(0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-24 09:57:21.001210
# Unit test for function product
def test_product():
    """
    Test function to check if all the expected products
    are generated.
    """
    assert list(product('ABCD', 'xy')) == [
        ('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
        ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]
    assert list(product(range(2), repeat=3)) == [
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:57:31.859469
# Unit test for function product
def test_product():
    from .tqdm_test_cases import StringIO
    from .tests_tqdm import TestCaseMixin

    # Test cases
    for it in range(2, 10):
        for nt in range(10):
            for enum in range(5):
                for desc in ['', ' ', None]:
                    for total in [None, 0, 10, 1000]:
                        with tqdm_auto(total=total, desc=desc) as t:
                            for _ in product(range(it), enumerate(range(nt)),
                                             **vars()):
                                pass
                            assert t.display_total_create > 0

    class ProductTests(TestCaseMixin):
        """
        Test cases for `product`.
        """
        # NOTE: make sure `total` is never too small to trigger broadcasting
        # and

# Generated at 2022-06-24 09:57:42.376911
# Unit test for function product
def test_product():
    """Test function product"""

# Generated at 2022-06-24 09:57:53.180152
# Unit test for function product
def test_product():
    from operator import mul
    from functools import reduce
    from numpy.random import random
    from numpy import allclose
    from .utils import FormatWrapBase

    # no total
    for n in range(2, 10):
        for s in range(1, 10):
            for tqdm_cls in [tqdm_auto]:  # , FormatWrapBase]:
                total = max(s, reduce(mul, range(1, n), 1))
                l = [(random(s),) for _ in range(n)]
                with tqdm_cls(**{"total": total, "ascii": True}) as t:
                    l_ = list(product(*l))
                    assert len(l_) == total
                l = [(range(s),) for _ in range(n)]

# Generated at 2022-06-24 09:58:01.199159
# Unit test for function product
def test_product():
    ''' Tests the product function '''
    x, y, z = 'x', 'y', 'z'
    s = 'product(range(5), repeat=2)'
    assert list(product(range(5), repeat=2)) == list(itertools.product(range(5), repeat=2))
    assert list(product(range(5), repeat=2)) == [(i, j) for i in range(5) for j in range(5)]
    assert list(product(x, y)) == list(itertools.product(x, y)) == [('x', 'y')]
    assert list(product(x, y, repeat=3)) == list(itertools.product(x, y, repeat=3)) == [('x', 'y', 'x', 'y', 'x', 'y')]

# Generated at 2022-06-24 09:58:07.529280
# Unit test for function product
def test_product():
    '''Unit test for function `product`'''
    test_data = [
        (list('ab'), list('cd'), list('ef'), 'ac'),
        (list('ab'), list('cd'), list('ef'), 'dc'),
        (list('ab'), list('cd'), list('ef'), 'ed')]
    for a, b, c, d in test_data:
        for i, j, k in product(a, b, c):
            if i + j + k != d:
                return False
    return True

# Generated at 2022-06-24 09:58:11.290152
# Unit test for function product
def test_product():
    r = product(range(1), range(1), tqdm_class=tqdm_auto)
    assert sum(1 for _ in r) == 1

if __name__ == "__main__":
    import nose2
    nose2.main()

# Generated at 2022-06-24 09:58:18.208472
# Unit test for function product
def test_product():
    from ..tqdm import trange
    from numpy.random import randint
    from numpy import prod

    n = 3
    pbar = trange(n, desc='product', leave=True)
    for i in product(range(n), range(n), range(n), tqdm=pbar):
        pass
    assert pbar.n == 3 * 3 * 3

    n = 10
    pbar = trange(n, desc='product', leave=True)
    for i in product(range(n), range(n), range(n), tqdm=pbar):
        pass
    assert pbar.n == n * n * n

    n = 5
    pbar = trange(n, desc='product', leave=True)

# Generated at 2022-06-24 09:58:29.167920
# Unit test for function product

# Generated at 2022-06-24 09:58:40.763255
# Unit test for function product
def test_product():
    from .pandas import DataFrame
    for i in product(['1', '2', '3'],
                     ['a', 'b', 'c'],
                     [False, True]):
        assert i
    for i in product(['1', '2', '3'],
                     ['a', 'b', 'c'],
                     [False, True],
                     total=0):
        assert i
    assert DataFrame.from_dict(dict(product(zip("abcdefg", range(7)),
                                            zip("abcdefg", range(7))))) \
        .equals(DataFrame.from_dict(dict(itertools.product(zip("abcdefg",
                                                               range(7)),
                                                            zip("abcdefg",
                                                                range(7))))))

# Generated at 2022-06-24 09:58:48.697450
# Unit test for function product
def test_product():
    from ..utils import Stream
    from ..std import format_interval
    from .utils import TotalSpacing

    def unq(x):
        """
        Removes duplicates from list x while preserving order
        """
        seen = set()
        return [i for i in x if i not in seen and not seen.add(i)]

    x = list(range(5))
    y = list(map(list, product(x, x, x)))