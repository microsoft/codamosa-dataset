

# Generated at 2022-06-24 09:48:51.516082
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from itertools import product as itproduct
    from tqdm.test import with_setup, pretest, posttest

    @with_setup(pretest, posttest)
    def base_test():
        """Base test for function product"""
        assert hasattr(product, '__wrapped__')
        assert not hasattr(itproduct, '__wrapped__')

        assert list(product(range(3), repeat=2)) == list(itproduct(
            range(3), repeat=2))
        assert list(product(range(3), repeat=3)) == list(itproduct(
            range(3), repeat=3))
        assert list(product(range(5), repeat=5)) == list(itproduct(
            range(5), repeat=5))

# Generated at 2022-06-24 09:48:59.297305
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range, FakeTQDM
    maxint = getattr(__builtins__, 'maxint', getattr(__builtins__, 'maxsize'))
    iterables = [[10**i for i in _range(5)], [5**i for i in _range(5)]]

    with FakeTQDM() as t:
        list(product(*iterables, desc="test", tqdm_class=t))
        assert t.n == sum(len(i) for i in iterables)
        assert t.total == t.n
        assert t.last_print_n == t.n
        assert t.desc == "test"


# Generated at 2022-06-24 09:49:03.595115
# Unit test for function product
def test_product():
    from .tests import TestCase, closing
    class Test(TestCase):
        def test_product(self):
            with closing(self.tqdm_cls(
                    total=1, leave=False, ncols=10,
                    desc='test_product', disable=False)) as pbar:
                pbar.set_description('p')
                for i in product(range(10), range(10)):
                    pbar.update()
    with Test('utf-8') as bar:
        bar.test_product()
    with Test('latin') as bar:
        bar.test_product()

# Generated at 2022-06-24 09:49:11.590485
# Unit test for function product
def test_product():
    import sys
    from ..utils import format_sizeof
    from ..std import FormatBase as fm
    from . import trange

    for tqdm_class in [tqdm_auto, trange]:
        for n in [1e1, 1e2, 1e3, 1e4, 1e5]:
            with tqdm_class(total=n, file=sys.stdout,
                            bar_format=fm._DEFAULT_BAR_FORMAT) as t:
                for i in product(range(n), range(n), tqdm=tqdm_class):
                    pass
        print("product OK.")

        t = tqdm_class(total=1, file=sys.stdout,
                       bar_format=fm._DEFAULT_BAR_FORMAT)

# Generated at 2022-06-24 09:49:18.770918
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .._utils import _range
    for total in [None, 1, 10, 100]:
        for i in product(_range(10), _range(10), _range(10), tqdm_class=tqdm, total=total):
            print(i)
    for total in [None, 1, 10, 100]:
        for i in product(_range(10), repeat=3, tqdm_class=tqdm, total=total):
            print(i)

# Generated at 2022-06-24 09:49:23.022028
# Unit test for function product
def test_product():
    from ..tqdm import trange
    for x in product(trange(7), trange(5), trange(3), tqdm_class=trange):
        pass
    for x in product('ABC', '12'):
        pass
    for x in product(range(5), repeat=3):
        pass

# Generated at 2022-06-24 09:49:33.967553
# Unit test for function product
def test_product():
    """Test the itertools.product wrapper"""
    from .tests_tqdm import with_setup, _range

    @with_setup(pretest=lambda: None, posttest=lambda: None)
    def wrapper():
        """Test the product wrapper"""
        assert list(itertools.product(*[list(range(i)) for i in range(2, 5)])) ==\
            list(product(*[list(range(i)) for i in range(2, 5)]))
        for cls in _range(tqdm_auto):
            assert list(itertools.product(*[list(range(i)) for i in range(2, 5)])) ==\
                list(product(*[list(range(i)) for i in range(2, 5)],
                             tqdm_class=cls))

# Generated at 2022-06-24 09:49:37.826524
# Unit test for function product
def test_product():
    assert list(product(range(2), range(2), tqdm_class=tqdm_auto.tqdm)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-24 09:49:48.256224
# Unit test for function product
def test_product():
    """
    Test for function `tqdm.itertools.product`
    """
    from .utils import SimpleProgressBar
    from .tests_tqdm import _test_nested_desc, _test_iter

    # Test that no exception is raised
    list(product(*([1, 2, 3], [4, 5, 6], [7, 8, 9])))
    list(product(*([1, 2, 3], [4, 5, 6], [7, 8, 9])))
    list(product(*([1, 2, 3], [4, 5, 6], [7, 8, 9])))
    list(product(*([1, 2, 3], [4, 5, 6], [7, 8, 9])))

# Generated at 2022-06-24 09:49:56.523197
# Unit test for function product
def test_product():
    """
    Unit test for function product.

    Returns
    -------
    True if all tests passed.
    """
    from .utils import FormatWrap

    def fancy_product(l, r, tqdm_class=tqdm_auto, **kwargs):
        return product(l, r, tqdm_class=tqdm_class, **kwargs)

    def plain_product(l, r, tqdm_class=tqdm_auto, **kwargs):
        return itertools.product(l, r)

    left = range(10)
    right = range(10, 20)
    assert list(fancy_product(left, right)) == list(plain_product(left, right))

    with tqdm_auto() as t:
        fp = FormatWrap(t, fancy_product)


# Generated at 2022-06-24 09:50:01.396842
# Unit test for function product
def test_product():
    from .tqdm import trange
    from .utils import FormatCustomText
    with trange(10, leave=True) as t:
        assert list(product(t, 'abc')) == list(itertools.product(t, 'abc'))

    with trange(10, leave=True) as t:
        assert list(product(t, 'abc', bar_format=FormatCustomText('|{bar}|'))) == list(itertools.product(t, 'abc'))

# Generated at 2022-06-24 09:50:11.545713
# Unit test for function product
def test_product():
    from ..utils import Str
    from .main import tqdm
    from .utils import FormatCustomTextTest
    import io
    import sys


# Generated at 2022-06-24 09:50:16.948146
# Unit test for function product
def test_product():
    """Unit test for function product"""
    kwargs = {"tqdm_class": None}
    for i in product(range(5), range(5), **kwargs):
        assert i is not None
    for i in product(range(5), range(5), tqdm_class=tqdm_auto):
        assert i is not None

# Generated at 2022-06-24 09:50:25.783060
# Unit test for function product
def test_product():
    from math import sqrt
    l = list(product(range(10), repeat=2))
    assert len(l) == 100
    assert l[0] == (0, 0)

    def _map(x):
        yield int(sqrt(x * x + x * x))
        yield x * x

    l = list(product(range(5), range(5), map=_map))
    assert len(l) == 25
    assert l[0] == (2, 0)

    l = list(product(range(5), range(5), repeat=2, map=_map))
    assert len(l) == 625
    assert l[0] == (0, 2, 0, 2)

    l = list(product(range(5), repeat=2, map=_map))
    assert len(l) == 25


# Generated at 2022-06-24 09:50:32.451135
# Unit test for function product
def test_product():
    """
    Test tqdm.itertools.product.
    """
    from nose.tools import assert_equal
    assert_equal(list(product(range(10), range(10))),
                 list(itertools.product(range(10), range(10))))
    assert_equal(list(product(range(10), range(10), tqdm_class=None)),
                 list(itertools.product(range(10), range(10))))



# Generated at 2022-06-24 09:50:35.965295
# Unit test for function product
def test_product():
    prods = []
    for _ in tqdm_auto.product(range(4), range(4)):
        prods.append(_)
    assert len(prods) == 16
    assert prods[4] == (1, 1)


# Generated at 2022-06-24 09:50:43.332392
# Unit test for function product
def test_product():
    print("Simple `product` test:", end=' ')
    assert list(product(range(5), repeat=3)) == list(itertools.product(
        range(5), repeat=3))
    assert not list(product(range(5), repeat=3,
                            tqdm_class=False)) == list(itertools.product(
                                range(5), repeat=3))
    print("OK")

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:50:53.213669
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.testing import assert_equal
    from ..utils import FormatBase

    product_list = []
    for i in product('ABCD', 'xy'):
        product_list.append(i)

    assert_equal(product_list, [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'),
                                ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')])

    product_list = []
    for i in product(['A', 'B', 'C', 'D'], ['x', 'y']):
        product_list.append(i)
    

# Generated at 2022-06-24 09:51:02.678218
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    try:
        from nose import tools as nt
    except ImportError:
        import warnings
        warnings.warn(
            'Package `nose` not found; thus all tests skipped.',
            category=ImportWarning)
        return

    # Case 1: basic usage
    prd = product('AB', range(3), tqdm_class=tqdm_auto)
    res = [p for p in prd]
    nt.assert_equal(res, [('A', 0), ('A', 1), ('A', 2),
                          ('B', 0), ('B', 1), ('B', 2)])

    # Case 2: with hook
    hook_list = []
    prd = product('AB', range(3), tqdm_class=tqdm_auto)

# Generated at 2022-06-24 09:51:03.726687
# Unit test for function product
def test_product():
    from .tqdm_test_examples import product_test
    product_test()

# Generated at 2022-06-24 09:51:11.135504
# Unit test for function product
def test_product():
    """unit test for function product"""
    from numpy.testing import assert_equal
    from itertools import product
    from .tqdm import trange

    for A in range(11):
        for B in range(11):
            for C in range(11):
                for D in range(11):
                    assert_equal(
                        list(product(range(A), range(B), range(C), range(D))),
                        list(product(range(A), range(B), range(C), range(D),
                                     tqdm_class=trange)))

# Generated at 2022-06-24 09:51:14.123461
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`
    """
    from ..utils import _range
    list(product(1, 4, 2, _range(1000000), tqdm_class=tqdm_auto))

# Generated at 2022-06-24 09:51:21.945028
# Unit test for function product
def test_product():
    from .utils import TotalMonitor
    from . import trange
    from .utils import FormatCustomText, format_interval
    from .._utils import format_meter
    import sys
    import time

    for tqdm_cls in [tqdm_auto, trange]:
        with tqdm_cls(product('abcd', 'xyz', '123', '123'),
                      dynamic_ncols=True,
                      smoothing=0.5,
                      total=len('abcd') * len('xyz') * len('123') ** 2) as t:
            for n, _ in enumerate(t, 1):
                time.sleep(0.01)

# Generated at 2022-06-24 09:51:28.737367
# Unit test for function product
def test_product():
    "Ensure `tqdm.itertools.product` works correctly"
    from ..utils import SimpleNamespace
    # Empty iterator
    assert list(product()) == [()]
    # Single iterator
    res = product(range(3))
    assert isinstance(res, SimpleNamespace)
    assert list(res) == [(i,) for i in range(3)]
    # Multiple iterators
    res = list(product(range(3), range(3)))
    assert res == [(i, j) for i in range(3) for j in range(3)]

# Generated at 2022-06-24 09:51:39.075758
# Unit test for function product
def test_product():
    #pylint: disable=invalid-name
    from ..utils import FormatCustomText
    import numpy
    # Test 1
    # ======
    n = numpy.arange(6).reshape(2, 3)
    for i in product(n, n):
        assert i == (n[0], n[1])
    for i in product(n, n):
        assert i == (n[0], n[1])

    # Test 2
    # ======
    def test_format(x, format_dict=None):
        return FormatCustomText("%s:%s" % x).format_dict(format_dict)
    n = numpy.arange(6).reshape(2, 3)

# Generated at 2022-06-24 09:51:44.888450
# Unit test for function product
def test_product():
    '''
    Test that `tqdm.itertools.product` behaves the same as `itertools.product`.
    '''
    a = [1, 2, 3, 4]
    b = ['a', 'b']
    c = ['A', 'B', 'C']
    abc_list = list(itertools.product(a, b, c))
    p_abc_list = list(product(a, b, c))
    assert (set(abc_list) == set(p_abc_list))
    abc_list.sort()
    p_abc_list.sort()
    assert (abc_list == p_abc_list)

    # Test empty list
    assert (list(product()) == list(itertools.product()))

    # Test nested

# Generated at 2022-06-24 09:51:48.859815
# Unit test for function product
def test_product():
    assert product([1, 2, 3], [4, 5, 6], [7, 8, 9], tqdm_class=None) == list(itertools.product([1, 2, 3], [4, 5, 6], [7, 8, 9]))

# Generated at 2022-06-24 09:51:54.662789
# Unit test for function product
def test_product():
    """Test for function `product`."""
    a = ['a', 'b', 'c']
    b = ['d', 'e']
    pb = product(a, b)
    assert not any(pb)
    assert [x for x in product(a, b)] == \
        [('a', 'd'), ('a', 'e'), ('b', 'd'), ('b', 'e'), ('c', 'd'), ('c', 'e')]

# Generated at 2022-06-24 09:51:59.086432
# Unit test for function product
def test_product():
    from random import randint
    from time import sleep

    for i in product(list(range(6)), repeat=6, tqdm_class=tqdm_auto,
                     desc="test_product", leave=False):
        sleep(0.01)

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:52:02.101646
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for _ in product(['a', 'b', 'c'], repeat=3):
        continue

if __name__ == '__main__':
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 09:52:07.987920
# Unit test for function product
def test_product():
    """
    Ensure we can iterate over all permutations of 1-9
    """
    n = 9
    vals = list(range(n))

    count = 0
    for i in product(vals, vals, vals, vals, vals, vals, vals, vals, vals):
        count += 1
    assert count == n**9

# Generated at 2022-06-24 09:52:16.028097
# Unit test for function product
def test_product():
    from os import devnull
    from random import random
    from sys import stderr, stdout
    from time import sleep
    from inspect import cleandoc

    # Test callbacks
    class FunctionCallback():
        def __init__(self):
            self.n_updates = 0

        def __call__(self, *args, **kwargs):
            self.n_updates += 1

    fn_cb = FunctionCallback()
    p = product(range(10), range(100), range(100),
                tqdm_class=tqdm_auto,
                tqdm_kwargs={"on_update": fn_cb})
    # 1000 iterations are performed
    for _ in p:
        pass
    assert fn_cb.n_updates == 1000

    # Test total

# Generated at 2022-06-24 09:52:25.415059
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    try:
        from inspect import signature
    except ImportError:
        try:
            from funcsigs import signature
        except ImportError:
            raise ImportError("Missing package: either "
                              "`funcsigs` or `inspect`")
    from tqdm.tests import TestsNoBar, PretendNonKwargsTqdm
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # python 2
    from six import PY3

    def _test_fake(tqdm_cls=None):
        """Test fake"""

# Generated at 2022-06-24 09:52:35.789385
# Unit test for function product
def test_product():
    """
    Unit test for the `tqdm.itertools.product()` function.
    """
    from ._utils import StringIO
    from ._tqdm import tqdm
    import sys
    with StringIO() as our_file:
        # Test basic functionality
        for i in product(list(range(100)), list(range(100)),
                         tqdm_class=tqdm, file=our_file):
            pass
        # Test with nested loops
        our_file.seek(0)
        with tqdm(total=10000, file=our_file) as t:
            for i in product(list(range(100)), list(range(100)),
                             tqdm_class=t.__class__, file=our_file):
                pass
        # Test with nested loops
        our_file.seek

# Generated at 2022-06-24 09:52:40.012256
# Unit test for function product
def test_product():
    from .tqdm import _range
    from .utils import _term_move_up

    for A, B, C in product([1, 2], [3, 4, 5], [6, 7, 8, 9]):
        _term_move_up()
        assert A * B * C, "{} * {} * {}".format(A, B, C)

# Generated at 2022-06-24 09:52:48.055963
# Unit test for function product
def test_product():
    """Unit test for function product."""
    import sys
    with tqdm_auto(unit_scale=True, miniters=1, mininterval=0.1,
                   file=sys.stderr, ascii=True) as t:
        res = list(product('ABCD', range(2), tqdm_class=t.__class__))
        assert (res == [(x, y, z) for x in 'ABCD' for y in range(2) for z in 'ABCD'])
        t.close()


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:52:50.317404
# Unit test for function product
def test_product():
    assert list(product(range(3), range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1)]

# Generated at 2022-06-24 09:52:57.859479
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import random

    N = 100
    M = 10000000
    iterables = [range(N) for _ in range(3)]
    prod = product(*iterables, desc=test_product.__name__)
    for e in prod:
        pass
    assert prod.n == N ** 3
    for e in product(*iterables, desc=test_product.__name__,
                     total=prod.n):
        pass
    assert prod.n == N ** 3

    iterables = (range(_) for _ in range(4))
    for e in product(*iterables, desc=test_product.__name__, total=None):
        pass
    assert prod.n == sum(range(4))

    import collections
    iterables = [range(N) for _ in range(3)]

# Generated at 2022-06-24 09:53:00.841417
# Unit test for function product
def test_product():
    from random import randint, seed
    seed(1)
    for _data in product(range(randint(1, 10)), range(randint(1, 10))):
        pass

# Generated at 2022-06-24 09:53:09.285368
# Unit test for function product
def test_product():
    """Test that the wrapper works correctly"""
    result = list(product(range(2), range(3), range(10)))
    # 2 * 3 * 10 = 60
    assert len(result) == 60
    # Test that the sub-iterators' steps are accounted for
    result2 = list(product(range(2), range(3), range(10),
                           tqdm_class=tqdm_auto.tqdm_gui))
    assert len(result2) == 60
    # Test that the sub-iterators' steps are accounted for
    result3 = list(product(range(2), range(3), range(10),
                           tqdm_class=tqdm_auto.trange))
    assert len(result3) == 60

# Generated at 2022-06-24 09:53:17.946025
# Unit test for function product
def test_product():
    """Run module docstring as a unit test."""
    # pylint: disable=missing-docstring
    l = range(int(1e6))
    with tqdm_auto(total=len(l) ** 2) as t:
        for _ in product(l, l):
            t.update()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:53:21.057254
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .utils import closing

    with closing(TestCase()) as tc:
        for i, j in product(*[list(range(3)), list(range(3))], tqdm_class=tc):
            assert i * j == i + j

# Generated at 2022-06-24 09:53:32.770718
# Unit test for function product
def test_product():
    from .utils import _range
    from .nested import nested_tqdm
    from .std import tqdm as tqdm_std
    for _tqdm in (tqdm_auto, tqdm_std):
        for t in (tqdm_auto, tqdm_std):
            with nested_tqdm(tqdm_class=t) as t0:
                with nested_tqdm(**t0.defaults) as t1:
                    with nested_tqdm(**t1.defaults) as t2:
                        with _tqdm(tqdm_class=t,
                                   **t0.defaults) as t3:
                            t4 = _tqdm(tqdm_class=t,
                                       **t1.defaults)

# Generated at 2022-06-24 09:53:36.776809
# Unit test for function product
def test_product():
    with tqdm_auto(disable=True) as t:
        i = product(range(100), range(100), tqdm_class=t.__class__)
        assert len(list(i)) == 10000
        assert t.total == 10000

# Generated at 2022-06-24 09:53:46.715379
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tests import buf, closing, FakeTqdmFile, UnicodeIO

    # Test alternate tqdm class
    class TqdmTypeError(Exception):
        pass

    def tqdm_raises(*args, **kwargs):
        raise TqdmTypeError

    iterables = [[1, 2, 3],
                 range(10),
                 'abc']
    for iterable in iterables:
        for tqdm_class in [tqdm_auto, tqdm_raises]:
            with closing(UnicodeIO()) as our_file:
                tn = tqdm_class(iterable, file=our_file)
                list(tn)
            assert our_file.getvalue() == ''

    # Test multi-iterable (https://github.

# Generated at 2022-06-24 09:53:50.972953
# Unit test for function product
def test_product():
    """Unit test for product"""
    from random import randint
    x1 = list(range(randint(2, 5)))
    x2 = list(range(randint(2, 5)))
    x3 = lis

# Generated at 2022-06-24 09:53:58.352194
# Unit test for function product
def test_product():
    """Unit tests for the product() function."""
    assert list(product([[1, 2, 3], [4, 5, 6]], repeat=2)) == \
        [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6),
         (3, 4), (3, 5), (3, 6), (1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6),
         (3, 4), (3, 5), (3, 6)]

# Generated at 2022-06-24 09:54:06.111927
# Unit test for function product
def test_product():
    from .gui import tqdm
    from .utils import FormatCustomText

    for n in product(range(3), range(1, 5)):
        pass

    for n in product(range(3), range(5), tqdm=tqdm):
        pass

    for n in product(range(3), range(5), tqdm_class=tqdm):
        pass

    for n in product(range(3), range(5), tqdm_class=tqdm, ascii=True):
        pass

    for n in product(range(3), range(5), tqdm_class=FormatCustomText(tqdm)):
        pass

    for n in product(range(3), range(1, 5), tqdm=tqdm_auto):
        pass


# Generated at 2022-06-24 09:54:16.426458
# Unit test for function product
def test_product():
    """
    Unit test for function product

    Expected results
    ---------------
    >>> from .utils import _range
    >>> product([], _range(0)) == []
    True
    >>> product([], _range(2)) == []
    True
    >>> product(_range(0), []) == []
    True
    >>> product(_range(0), _range(2)) == []
    True
    >>> product(_range(3), _range(2))
    [(0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1)]
    >>> product(_range(3), _range(2)) == list(itertools.product(_range(3), _range(2)))
    True
    """

if __name__ == '__main__':
    from .utils import _range


# Generated at 2022-06-24 09:54:21.801879
# Unit test for function product
def test_product():
    """
    Test for function `product`.
    """
    assert sorted(product([1, 2], [3, 4], [5, 6], tqdm_class=None)) == \
        sorted([(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6),
                (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)])

# Generated at 2022-06-24 09:54:29.387279
# Unit test for function product
def test_product():
    from . import tqdm
    from .tests import pretest_posttest
    from itertools import product as product_itertools

    list1 = list(range(20))
    list2 = list(range(50))
    list3 = list(range(10))

    @pretest_posttest
    def test_pretest_posttest():
        assert list(product(list1, list2)) == list(product_itertools(list1, list2))

    
    @pretest_posttest
    def test_pretest_posttest_total():
        assert list(product(list1, list2, list3, tqdm=tqdm)) == list(product_itertools(list1, list2, list3))

    
    test_pretest_posttest()
    test_pretest_posttest_

# Generated at 2022-06-24 09:54:32.423122
# Unit test for function product
def test_product():
    """Test that `product` does not get stuck in an infinite loop."""
    for _ in product(range(1), range(1), tqdm_class=tqdm_auto):
        break

# Generated at 2022-06-24 09:54:35.588391
# Unit test for function product
def test_product():
    assert list(product([1, 2], [1, 2], [1, 2], tqdm_class=tqdm_auto)) == list(itertools.product([1, 2], [1, 2], [1, 2]))


# Generated at 2022-06-24 09:54:39.043674
# Unit test for function product
def test_product():
    i, j, k = 1, 4, 3
    iterables = [range(i), range(j), range(k)]
    iterator = product(*iterables)
    for count, _ in enumerate(iterator):
        assert len(iterator) == i * j * k

# Generated at 2022-06-24 09:54:46.018888
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    input_iterables = [range(100000), range(100)]
    output = ''
    mem = 0
    for i in product(*input_iterables, show_mem_usage=True, tqdm_class=tqdm_auto, leave=True):
        output = i
        mem += format_sizeof(i)
    assert output == (999999, 99)
    assert sum(1 for _ in product(*input_iterables)) == len(input_iterables[0]) * len(input_iterables[1])
# -

# Generated at 2022-06-24 09:54:47.892323
# Unit test for function product
def test_product():
    """
    Todo: Add testing.
    """

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:54:56.854174
# Unit test for function product
def test_product():
    N = 10
    from numpy.testing import assert_equal
    from numpy.random import randint

    for k in range(1, N):
        for n in range(1, N):
            for repeat in range(1, N):
                for tqdm_class in (None, tqdm_auto):
                    a = randint(0, 10, n)
                    assert_equal(list(product(a, repeat=repeat,
                                              tqdm_class=tqdm_class)),
                                 list(itertools.product(a, repeat=repeat)))

# Generated at 2022-06-24 09:55:03.659954
# Unit test for function product
def test_product():
    """
    Test for function `product`.
    """
    from random import random
    from .tqdm import tqdm, trange

    assert list(product(range(5), range(5))) == list(itertools.product(range(5), range(5)))
    assert list(product(range(5), range(5))) == list(tqdm(itertools.product(range(5), range(5))))
    assert list(product(range(5), range(5))) == list(tqdm(itertools.product(range(5), range(5)), total=25))
    with tqdm(total=25) as t:
        for _ in product(range(5), range(5)):
            t.update()

# Generated at 2022-06-24 09:55:12.090173
# Unit test for function product
def test_product():
    import numpy as np
    all_arr = np.array(list(itertools.product(*[[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3]])))
    # print (all_arr)
    all_arr_tqdm = np.array(list(product(*[[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3]])))
    # print (all_arr_tqdm)
    assert np.all(all_arr == all_arr_tqdm)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:55:24.539704
# Unit test for function product
def test_product():
    '''
    Test the function product
    '''
    # Normal case
    it_test = product(range(15), tqdm_class=tqdm_auto)
    assert sum(it_test) == 105

    # Normal case
    it_test = product(range(15), tqdm_class=tqdm_auto)
    assert sum(it_test) == 105

    # Empty case
    it_test = product([], tqdm_class=tqdm_auto)
    assert sum(it_test) == 0

    # With initializable iterator
    it_test = iter(product(range(15), tqdm_class=tqdm_auto))
    assert sum(it_test) == 105

    # With tqdm_class

# Generated at 2022-06-24 09:55:34.531066
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    try:
        from itertools import product as itertools_product
    except ImportError:
        return
    except Exception:
        raise

    for i in range(1, 5):
        for j in range(1, 5):
            for k in range(1, 5):
                for t_cls in (tqdm_auto, tqdm_auto.tqdm, tqdm_auto.trange,
                              bool):
                    with tqdm_auto.tqdm(_range=0) as t:
                        t.disable = bool(t_cls is bool)

# Generated at 2022-06-24 09:55:41.268158
# Unit test for function product
def test_product():
    from .tests import common
    from .tests.common import iterations
    from .tests.common import FakeTqdmFile

    common.create_io(tqdm_module)
    # Test case 1
    assert list(itertools.product([1, 2, 3], repeat=2)) == list(tqdm_module(
        itertools.product([1, 2, 3], repeat=2)))
    common.clean_io()

    # Test case 2
    iterations = 0
    with tqdm_module(ascii=True) as pbar:
        for _ in itertools.product([1, 2, 3], repeat=2):
            pbar.update()
            iterations += 1
    assert iterations == 9

    # Test case 3

# Generated at 2022-06-24 09:55:51.335287
# Unit test for function product
def test_product():
    from .testsandbox import RandomArg, RandomArgList
    from .testsandbox import closing_disabled

    for cls in [tqdm_auto, tqdm_auto.tqdm, tqdm_auto.trange]:
        with closing_disabled() as c:
            try:
                c.check_grammar()
            except AttributeError:
                c.disable_closing()
            for obj in [RandomArg(), RandomArgList()]:
                assert c.refuse_total(cls, obj)
                assert not c.refuse_total(cls, *obj)
                with c.disabled(cls):
                    assert set(
                        product(*obj, tqdm_class=cls)) == set(
                            itertools.product(*obj))

# Generated at 2022-06-24 09:55:56.021338
# Unit test for function product
def test_product():
    for i in product(range(2), range(2), range(2), tqdm_class=tqdm_auto):
        pass
    for i in product(tqdm_class=tqdm_auto):
        pass
    for i in product(range(2), range(2), range(2), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:56:06.505152
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .tests import closing
    from io import BytesIO

    def test_bar(bar, expected_set, expected_total):
        assert isinstance(bar, tqdm_auto)
        assert isinstance(bar.bar_format, str)
        assert isinstance(bar.n, int)
        assert isinstance(bar.total, int)
        assert bar.total == expected_total
        assert bar.n == 0
        assert bar.last_print_n == 0
        assert bar.last_print_t == None
        assert isinstance(bar.dynamic_ncols, bool)
        assert isinstance(bar.leave, bool)
        assert isinstance(bar.miniters, int)
        assert isinstance(bar.smoothing, float)

# Generated at 2022-06-24 09:56:10.618755
# Unit test for function product
def test_product():
    from ..utils import FormatWrapper
    list(product(range(10), FormatWrapper(lambda x: [x, x])))
    list(product(range(10), FormatWrapper(lambda x: [x, x])))
    list(product(range(10), FormatWrapper(lambda x: [x, x])))
    list(product(range(10), FormatWrapper(lambda x: [x, x]), tqdm_class=None))

# Generated at 2022-06-24 09:56:19.212918
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import random
    import time
    for _ in range(5):
        a = list(range(random.randint(1, 10)))
        b = list(range(random.randint(1, 10)))
        a_b = list(product(a, b))
        assert(a_b == [(i, j) for i in a for j in b])
        t = time.time()
        a_b = list(product(a))
        t = time.time() - t
        assert(a_b == [(i, ) for i in a])
        print("Iterations: {:g}, Total: {:s}, {:.3g} s".format(
            len(a_b), format_sizeof(len(a_b)), t))



# Generated at 2022-06-24 09:56:25.095220
# Unit test for function product
def test_product():
    with tqdm_auto(total=4) as t:
        for i in product(xrange(2), xrange(2)):
            t.update()

# Generated at 2022-06-24 09:56:29.251663
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .utils import _range

    with TestCase(bar_format='') as tc:
        list(product(_range(10)))
        list(product(_range(10), tqdm_class=tqdm_auto))
        list(product(_range(10), tqdm_class=tc.tqdm))

# Generated at 2022-06-24 09:56:33.890160
# Unit test for function product
def test_product():
    """ A test for the product function of the itertools package. """
    import itertools
    from ..utils import format_sizeof
    from ..main import tqdm

    for x in tqdm(itertools.product([3, 4], [5, 6])):
        pass

# Test all itertools

# Generated at 2022-06-24 09:56:40.732108
# Unit test for function product
def test_product():
    from ..tests.test_tqdm import with_unit_option, PretendRc

    for u in [False, True]:
        with with_unit_option(u, "n/s"):
            res = list(product(range(5), range(5)))
        assert res == list(itertools.product(range(5), range(5)))

        with with_unit_option(u, "n/s"):
            res = list(product(range(5), range(5), range(5)))
        assert res == list(itertools.product(range(5), range(5), range(5)))

# Generated at 2022-06-24 09:56:49.508708
# Unit test for function product
def test_product():
    from .tests.test_tqdm import sayhello
    import sys

    # Check with no optional parameters
    for i in product(range(5), repeat=2):
        sayhello("iterator")
    # Check with given optional parameters
    for i in product(range(5), repeat=2, tqdm_class=tqdm_auto):
        sayhello("iterator")
    # Check with keyword arguments
    for i in product(range(5), repeat=2, tqdm_class=tqdm_auto, file=sys.stdout):
        sayhello("iterator")
    # Check without keyword arguments

# Generated at 2022-06-24 09:56:56.982602
# Unit test for function product
def test_product():
    import sys

    class TqdmArgs(object):
        def __init__(self, *args, **kwargs):
            self.miniters = kwargs.pop("miniters", None)
            self.desc = kwargs.pop("desc", '')
            self.leave = kwargs.pop("leave", False)
            self.disable = kwargs.pop("disable", None)
            self.iterable = tqdm_auto(*args, **kwargs)
            self.it = iter(self.iterable)

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.it)

        next = __next__

    def mylen(i):
        return i


# Generated at 2022-06-24 09:57:07.274561
# Unit test for function product
def test_product():
    from .tests import comparisons
    from .tests import common
    from .tests import write
    def test_one_iterable():
        assert list(product(range(5))) == comparisons.list_of_range(5)

    def test_two_iterables():
        assert list(product(range(5), range(5))) == comparisons.list_of_range(
            5, 2)

    def test_three_iterables():
        assert list(product(range(5), range(5), range(5))) == comparisons.list_of_range(
            5, 3)

    def test_four_iterables():
        assert list(product(range(5), range(5), range(5), range(5))) == comparisons.list_of_range(
            5, 4)


# Generated at 2022-06-24 09:57:12.045596
# Unit test for function product
def test_product():
    from ..auto import tqdm
    from .utils import _range
    # case 0: just to test if it raises no errors
    list(product(_range(1), tqdm=tqdm))
    # case 1: test actual total
    total = 10
    for tick in range(total):
        assert tick in product(range(total), tqdm=tqdm)

# Generated at 2022-06-24 09:57:14.445554
# Unit test for function product
def test_product():
    list_ = list(product(range(10), range(20), range(20)))
    assert len(list_) == 20 * 20 * 10

# Generated at 2022-06-24 09:57:19.851961
# Unit test for function product
def test_product():
    a = [1, 2, 3]
    b = ['a', 'b', 'c']
    c = product(a, b)
    # print(c)
    assert list(c) == [(1, 'a'), (1, 'b'), (1, 'c'),
                       (2, 'a'), (2, 'b'), (2, 'c'),
                       (3, 'a'), (3, 'b'), (3, 'c')]

# Generated at 2022-06-24 09:57:29.855633
# Unit test for function product
def test_product():
    from itertools import product as iproduct
    for i in iproduct(*[range(2)] * 3):
        assert i == next(product(*[range(2)] * 3))
    for i in iproduct(*[range(2)] * 3):
        assert i == next(product(*[range(2)] * 3, total=8))
    assert list(product(range(2), range(2))) == list(iproduct(range(2),
                                                              range(2)))
    assert list(product(range(2), range(2), range(2))) == list(iproduct(range(2),
                                                                       range(2),
                                                                       range(2)))

# Generated at 2022-06-24 09:57:39.983214
# Unit test for function product
def test_product():
    """Test function `product`."""
    # 1
    list_ = []
    for i in product([1, 2, 3], ["a", "b", "c"]):
        list_.append(i)
    aeq(list_, [(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b'), (2, 'c'),
                (3, 'a'), (3, 'b'), (3, 'c')])
    # 2
    list_ = []
    for i in product([1, 2, 3], ["a", "b", "c"]):
        list_.append(i)
        i[0] = 5

# Generated at 2022-06-24 09:57:43.388772
# Unit test for function product
def test_product():
    from ..std import testit
    assert testit(product, [], [], tqdm_class=tqdm_auto) == [()]
    assert testit(product, [1, 2], [10, 20], tqdm_class=tqdm_auto) == [
        (1, 10),
        (1, 20),
        (2, 10),
        (2, 20),
    ]

# Generated at 2022-06-24 09:57:53.800830
# Unit test for function product
def test_product():
    """Run `product` function unit tests"""
    from .utils import _test_iterator, SimpleNamespace

    ns = SimpleNamespace()
    ns.tqdm_class = tqdm_auto
    ns.iterables = map(reversed, [range(1, 6), range(1, 3)])
    ns.total = 5 * 2

# Generated at 2022-06-24 09:58:00.347977
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    import gc
    try:
        import numpy as np
        iterables = [np.arange(2) for _ in range(10)]
        # test if np.array can be used
        # remote dep: pip install --user six
        import six
        if six.PY3:
            iterator = product(*iterables)
        else:
            iterator = product(*[np.asarray(i) for i in iterables])
        for _ in range(5):
            next(iterator)
    finally:
        gc.collect()  # to avoid memory leaks due to test suite design

# Generated at 2022-06-24 09:58:10.560310
# Unit test for function product
def test_product():
    import sys
    if sys.version_info[0] >= 3:
        tqdm_kwargs = {"total": 9}

# Generated at 2022-06-24 09:58:14.641017
# Unit test for function product
def test_product():
    from ..std import numpy as np
    np.random.seed(42)
    for _ in product(np.arange(10), (1, 2), np.random.randint(0, 100, 10),
                     ('a', 'b', 'c', 'd', 'e'), ['foo', 'bar', 'baz'],
                     tqdm_class=tqdm_auto):
        pass



# Generated at 2022-06-24 09:58:19.693656
# Unit test for function product
def test_product():
    """
    Simple recursive test.
    """
    assert list(product(range(3), range(3), tqdm_class=tqdm_auto)) == list(itertools.product(range(3), range(3)))


if __name__ == "__main__":
    from tests_tqdm import _test_wrap
    _test_wrap(__file__, test_product)

# Generated at 2022-06-24 09:58:28.419866
# Unit test for function product
def test_product():
    """
    Unit tests for `product`.
    """
    from .tests import pretest_posttest_decorator
    from .utils import format_sizeof, format_interval

    from random import random
    from timeit import default_timer as timer
    from ..auto import tqdm, trange
    from ..utils import _range

    @pretest_posttest_decorator
    def unit_product_tests():
        assert (
            list(product([], repeat=3)) ==
            list(itertools.product([], repeat=3)) ==
            [()]
        )
        assert (
            list(product((), repeat=3)) ==
            list(itertools.product((), repeat=3)) ==
            [()]
        )

# Generated at 2022-06-24 09:58:30.471321
# Unit test for function product
def test_product():
    for i in product(range(3), range(2), tqdm_class=None):
        pass
    assert i == (2, 1)



# Generated at 2022-06-24 09:58:41.456393
# Unit test for function product
def test_product():
    from nose.tools import assert_equal


# Generated at 2022-06-24 09:58:45.946187
# Unit test for function product
def test_product():
    from ..pandas import tqdm_pandas
    import pandas as pd

    df = pd.DataFrame({"foo": list(range(32))})

    assert df.foo.tolist() == \
        [i for i in product(df.itertuples(index=False), tqdm_class=tqdm_pandas)]


if __name__ == '__main__':
    import nose
    nose.runmodule()