

# Generated at 2022-06-24 09:48:53.197688
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .utils import FormatWidget
    from .trange import trange
    from .tqdm_gui import tqdm_gui
    from .tqdm import tqdm

    def check(total, leave, tqdm_cls):
        # Caller must provide tqdm_cls
        with tqdm_cls(total, leave=leave, miniters=total, mininterval=0,
                      ascii=True, file=None) as t:
            # Check length
            assert len(t) == total
            # Check __enter__
            assert isinstance(t, tqdm_cls)
            # Check iteration
            for _ in t:
                pass
            # Check __exit__
            assert isinstance(t, tqdm_cls)
            #

# Generated at 2022-06-24 09:48:55.871824
# Unit test for function product
def test_product():
    l = list(product(['a', 'b', 'c'], repeat=2))
    assert l == [('a', 'a'), ('b', 'a'), ('c', 'a'),
                 ('a', 'b'), ('ba', 'b'), ('c', 'b'),
                 ('a', 'c'), ('b', 'c'), ('c', 'c')]

# Generated at 2022-06-24 09:49:05.680050
# Unit test for function product
def test_product():
    """Test the function `~tqdm.itertools.product`."""
    from ..utils import _range

    assert list(product(_range(10), _range(10))) == list(_range(10) * 10)

    assert list(product(_range(10), _range(10), tqdm_class=None)) == list(_range(10) * 10)

    assert list(product(tqdm_class=None, *(_range(10),) * 3)) == list(_range(10) * 10)

    def short_iterable():
        for i in _range(5):
            yield i

    assert list(product(short_iterable(), _range(10))) == list(
        map(tuple, zip(short_iterable(), _range(10))))


# Generated at 2022-06-24 09:49:07.983591
# Unit test for function product
def test_product():
    """
    Unit tests for product wrapper.
    """
    from ...tests import TestCase
    with TestCase():
        [i for i in product(range(5), range(5))]

# Generated at 2022-06-24 09:49:12.751239
# Unit test for function product
def test_product():
    from .utils import _range

    assert list(product(_range(2), 'ab', tqdm_class=None)) == \
        list(itertools.product(_range(2), 'ab'))
    assert list(product(_range(3), _range(3), tqdm_class=None)) == \
        list(itertools.product(_range(3), _range(3)))

    # Test to raise
    try:
        list(product(_range(3), _range(3), total=5))
        assert False, "Should raise"
    except RuntimeError:
        pass

# Generated at 2022-06-24 09:49:23.183169
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range, pretest
    import sys

    @with_setup(pretest)
    def unit():
        """
        Unit test for `tqdm(itertools.product(...))`.

        """
        # No crash
        list(tqdm_auto(product("AB", "12"),
                       desc="test_product", file=sys.stdout))

        with tqdm_auto(product("AB", "12", "CD", "EF"),
                       desc="test_product", file=sys.stdout) as t:
            for _ in t:
                pass

        # Check correct total iterations
        assert t.n == len("AB") * len("12") * len("CD") * len("EF")


# Generated at 2022-06-24 09:49:34.141628
# Unit test for function product
def test_product():
    # Only one iterable
    assert list(product(range(10))) == [(i,) for i in range(10)]
    # Two iterables
    assert list(product(range(2), range(3))) == [
        (i, j) for i in range(2) for j in range(3)]
    # Three iterables with repeat
    assert list(product(range(2), repeat=3)) == [
        (i, i, i) for i in range(2)]
    # Iterator as input
    assert list(product(x for x in range(2))) == [
        (i,) for i in range(2)]

    def f(x):
        for i in range(x):
            yield i

    assert list(product(f(2))) == [(i,) for i in range(2)]

# Generated at 2022-06-24 09:49:45.207615
# Unit test for function product
def test_product():
    from .tests import nose_run_module
    # TODO: implement tests for product()
    tqdm_args = ['unit_scale', 'disable', 'mininterval', 'miniters']

    def check_tqdm_args(opts):
        for k, v in opts.items():
            if k not in tqdm_args or v not in [True, False]:
                raise ValueError(
                    "Invalid tqdm kwarg %s" % k,
                    "Allowed are: %s" % tqdm_args)


# Generated at 2022-06-24 09:49:54.733360
# Unit test for function product
def test_product():
    from numpy.random import randint
    import numpy as np
    from .utils import FormatBytes
    from .utils import chunk
    from .utils import bytes
    from .utils import trange

    it = product(range(0, 21, 2), repeat=2)
    assert isinstance(it, tqdm_auto)
    assert list(it) == [(x, y) for x in range(0, 21, 2) for y in range(0, 21, 2)]

    it = product(sorted(['ha', 'he', 'hi']), repeat=2)
    assert isinstance(it, tqdm_auto)

# Generated at 2022-06-24 09:49:58.598107
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    from ..pandas import tqdm_pandas
    for tqdm_class in [tqdm_auto, tqdm_pandas]:
        for x in product('ABCD', 'xy', tqdm_class=tqdm_class):
            None

# Generated at 2022-06-24 09:50:00.342879
# Unit test for function product
def test_product():
    for i in product(range(20), range(20), tqdm_class=tqdm_auto):
        assert i



# Generated at 2022-06-24 09:50:10.841834
# Unit test for function product
def test_product():
    from .utils import SimpleNamespace as NS
    from .utils import closing, ignored

    # usage
    with ignored(StopIteration):
        for i in product("12345", "12", tqdm_class=tqdm_auto):
            break

    # output
    with closing(NS(iter=0)) as o:
        for i in product("1234", "1234", tqdm_class=tqdm_auto.__tqdm_cls__,
                         file=o):
            o.iter += 1
    assert o.iter == 16

    # with or without total

# Generated at 2022-06-24 09:50:14.546674
# Unit test for function product
def test_product():
    assert list(product(range(3))) == [(i,) for i in range(3)]


if __name__ == '__main__':
    from pytest import main
    main(['-x', '--pdb', __file__])

# Generated at 2022-06-24 09:50:23.815029
# Unit test for function product
def test_product():
    """Test product"""
    from numpy.testing import assert_allclose
    # Test scalars
    assert_allclose(list(product(1, 2)), [(1, 2)])
    assert_allclose(list(product(1, 2, 1)), [(1, 2, 1)])
    # Test lists
    assert_allclose(list(product([1, 2], [3, 4])), [(1, 3), (1, 4), (2, 3), (2, 4)])
    # Test arrays
    assert_allclose(list(product(range(3), [3, 4])), [(0, 3), (0, 4), (1, 3), (1, 4), (2, 3), (2, 4)])
    # Test classes

# Generated at 2022-06-24 09:50:31.825603
# Unit test for function product
def test_product():
    try:
        import numpy
    except:
        return
    from ..std import tqdm, trange
    from .tests import pretest_posttest_demo
    with pretest_posttest_demo():
        list(tqdm(product(numpy.arange(10), tqdm(numpy.arange(20))), total=200))
        list(tqdm(product(numpy.arange(10), numpy.arange(20)), total=200))
        list(product(numpy.arange(10), numpy.arange(20)))
        with trange(6) as t:
            for n in numpy.arange(6):
                t.set_description("n=%i" % n)

# Generated at 2022-06-24 09:50:33.618431
# Unit test for function product
def test_product():
    # Test default no tqdm
    for _ in product(range(3), repeat=3):
        pass
    # Test fake tqdm
    for _ in product(range(3), repeat=3, tqdm_class=None):
        pass
    # Test real tqdm

# Generated at 2022-06-24 09:50:40.318239
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    def product_wrapper(*iterables, **kwargs):
        """
        Wrapper around `itertool.product` to unit test `product`
        """
        iterable = list(product(*iterables, **kwargs))
        iterable2 = list(itertools.product(*iterables))
        assert (iterable == iterable2)
    from .utils import setup_tests, teardown_tests
    setup_tests()

    product_wrapper(range(3), range(3), range(3), range(3), tqdm_class=None)
    product_wrapper(range(3), range(3), range(3), range(3))

    teardown_tests()

# Generated at 2022-06-24 09:50:45.228483
# Unit test for function product
def test_product():
    from ..main import _range
    for i in product(_range(5), _range(5)):
        pass
    for i in product(_range(5), 'abc'):
        pass
    for i in product(_range(5), 8):
        pass
    for i in product(_range(5), _range(5), _range(5), _range(5), _range(5)):
        pass

# Generated at 2022-06-24 09:50:48.538314
# Unit test for function product
def test_product():
    # This is already tested by the standard `itertools` unit-tests
    # Just verify that the wrapper "works"
    len1, len2 = 10, 20
    for _ in product(range(len1), range(len2)):
        pass

# Generated at 2022-06-24 09:50:56.012496
# Unit test for function product
def test_product():
    from os import urandom
    for t in range(1000):
        for i in product(range(t), repeat=t):
            assert len(i) == t, (t, i)
            for j in range(t):
                assert i[j] < t, (t, i, j)
        for i in product([urandom(1) for _ in range(t)], repeat=t):
            assert len(i) == t, (t, i)
            for j in range(t):
                assert len(i[j]) == 1, (t, i, j)

# Generated at 2022-06-24 09:51:04.736990
# Unit test for function product
def test_product():
    # Test 1
    iterables1 = [["a", "b", "c"], ["d"], ["e", "f"]]
    prodlst = [i for i in product(*iterables1)]
    target1 = [("a", "d", "e"), ("b", "d", "e"), ("c", "d", "e"), ("a", "d", "f"), ("b", "d", "f"), ("c", "d", "f")]
    assert prodlst == target1, "product() function failed test 1"
    # Test 2
    iterables2 = [["a", "b", "c"], [], ["e", "f"]]
    prodlst = [i for i in product(*iterables2)]
    target2 = []
    assert prodlst == target2, "product() function failed test 2"
   

# Generated at 2022-06-24 09:51:13.271953
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product` (same expected output as `itertools.product`)
    """
    a = iter(['a', 'b', 'c'])
    b = iter(['d', 'e', 'f'])
    ab = [list(i) for i in product(a, b)]
    exp = [list(i) for i in itertools.product(a, b)]
    assert (ab == exp)

    # Test no crashing on non-iterable (gh-1379)
    try:
        list(product(None, repeat=2))
    except Exception:
        raise AssertionError("Should not crash on non-iterable")

# Generated at 2022-06-24 09:51:21.498023
# Unit test for function product
def test_product():
    from .utils import FixedLenBufferIO
    from .gui import tnrange
    from .std import tqdm
    from .std import trange

    for t in (tqdm, tnrange, trange):
        for limit in (None, 1000):
            with t(unit="B", leave=True) as t:
                for i in product(range(1000), repeat=2, tqdm_class=t,
                                 leave=True, unit="B", miniters=1, mininterval=0.001, ascii=True, maxinterval=1,
                                 maxinterval=1, mininterval=0.001):
                    pass
                assert t.unit == "B"
                assert sum(1 for _ in product(range(10), repeat=2)) == 100

# Generated at 2022-06-24 09:51:30.520984
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    from ._utils import PY2
    if not PY2:
        # Ensure ranges behave correctly on other (e.g. Python 2) versions
        assert [x for x in product([10, 20], range(2))] == [
            (10, 0), (10, 1), (20, 0), (20, 1)]

    assert [x for x in product([10, 20], range(2))] == [
        (10, 0), (10, 1), (20, 0), (20, 1)]

    assert [x for x in product([10, 20], range(2), tqdm_class=tqdm)] == [
        (10, 0), (10, 1), (20, 0), (20, 1)]


# Generated at 2022-06-24 09:51:32.736633
# Unit test for function product
def test_product():
    from .tests import TestCase
    with TestCase():
        from .tests import TestProduct
        list(product(TestProduct()))

# Generated at 2022-06-24 09:51:41.024844
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import sys

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    stream = StringIO()
    sys.stdout = stream
    stream.seek(0)
    for _ in product(range(3), range(4), range(5)):
        pass
    sys.stdout = sys.__stdout__
    # stream.seek(0)
    # print(stream.read())
    assert stream.getvalue() == ' 60%|██████    | 6/10 [00:00<00:00, 45.00it/s]\n'

# Generated at 2022-06-24 09:51:51.200614
# Unit test for function product
def test_product():
    from . import trange
    from .std import Timer, DataSize

    # minitest
    with Timer("a x b x c"):
        l = [a*b*c for a, b, c in product(range(2), range(2), range(2))]
    print("result:", l)

    # minitest
    print("\nBenchmarking 3x3x3 ...")
    with Timer("3 x 3 x 3"):
        list(product(range(3), range(3), range(3)))
    print("\nBenchmarking 3x5x7 ...")
    with Timer("3 x 5 x 7"):
        list(product(range(3), trange(5), trange(7)))

    # minitest

# Generated at 2022-06-24 09:52:01.414447
# Unit test for function product
def test_product():
    assert list(product(['a', 'b'], [1, 2], [True, False], tqdm_class=tqdm_auto)) == \
        list(itertools.product(['a', 'b'], [1, 2], [True, False]))
    assert list(product('ab', tqdm_class=tqdm_auto)) == list(itertools.product('ab'))
    assert list(product([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], tqdm_class=tqdm_auto)) == \
        list(itertools.product([1], [2], [3], [4], [5], [6], [7], [8], [9], [10]))

# Generated at 2022-06-24 09:52:08.556869
# Unit test for function product
def test_product():
    import numpy as np
    a = np.arange(1, 11)
    b = np.arange(1, 11)
    c = np.arange(1, 11)
    assert sum(1 for _ in product(a, b, c)) == 1000
    assert sum(1 for _ in product(a, b, c, disable=False)) == 1000
    assert sum(1 for _ in product(a, b, c, disable=True)) == 1000

# Generated at 2022-06-24 09:52:16.487909
# Unit test for function product
def test_product():
    """
    Tests the function product
    """
    # Test case 1
    # Basic usage
    test_case = 'Basic usage'
    with tqdm_auto() as t:
        iterables = ([1, 2], [3, 4])
    result = list(product(*iterables, total=4, tqdm_class=t))
    assert result == [(1, 3), (1, 4), (2, 3), (2, 4)], result
    # Test case 2
    # Basic usage
    test_case = 'Basic usage'
    with tqdm_auto() as t:
        iterables = ([1, 2, 3], [4, 5, 6])
    result = list(product(*iterables, total=9, tqdm_class=t))

# Generated at 2022-06-24 09:52:20.798634
# Unit test for function product
def test_product():
    """
    Unit test for ``tqdm.itertools.product``
    """
    from math import factorial
    product_iter = product(range(10))
    itertools_iter = itertools.product(range(10))
    assert sum(1 for _ in product_iter) == factorial(10)
    assert [x for x in product_iter] == list(itertools_iter)

# Generated at 2022-06-24 09:52:29.022375
# Unit test for function product
def test_product():
    """Test main function"""
    # quiet
    list(tqdm.product(range(10), [1, 2], ['a', 'b', 'c'], file=open(os.devnull, 'w')))

    # verbose
    list(tqdm.product(range(10), [1, 2], ['a', 'b', 'c']))

    # dynamic_ncols
    with tqdm(total=12, dynamic_ncols=True, desc="foo",
              bar_format="{desc}: {n_fmt}/{total_fmt} [{elapsed}<{remaining}]") as t:
        for _ in tqdm.product(range(10), range(10), range(10)):
            t.update()

# Generated at 2022-06-24 09:52:39.245215
# Unit test for function product
def test_product():
    """
    Randomly test whether `product` works as
    its `itertools` counterpart.
    """
    try:
        from random import randint
        import numpy
    except (ImportError, SystemError):
        # Python fuzz test only works on Linux/Mac
        return

# Generated at 2022-06-24 09:52:43.877138
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, pretest, posttest, _range

    @with_setup(pretest, posttest)
    def wrapper():
        list(product(
            _range(10), _range(100), tqdm_class=tqdm_auto))
        list(product(
            _range(10), _range(100), tqdm_class=tqdm_auto))

    wrapper()

# Generated at 2022-06-24 09:52:52.542358
# Unit test for function product
def test_product():
    from pytest import approx
    from numpy.testing import assert_almost_equal
    from math import factorial
    from itertools import permutations, product, combinations
    from numpy import array, arange

    # Basic
    assert list(product([1, 2], [3, 4])) == [
        (1, 3), (1, 4), (2, 3), (2, 4)]
    assert list(product(
        [[1, 2], [3, 4]], [5, 6])) == [
            ([1, 2], 5), ([1, 2], 6), ([3, 4], 5), ([3, 4], 6)]

# Generated at 2022-06-24 09:53:03.522397
# Unit test for function product
def test_product():
    import random
    import sys
    random.seed(42)
    total = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    len_ = int(sys.argv[2]) if len(sys.argv) > 2 else 200
    # Unit test for function product

# Generated at 2022-06-24 09:53:11.468769
# Unit test for function product
def test_product():
    """Test function product"""
    result = product([1,2,3],['a','b'],tqdm_class=tqdm_auto)
    assert next(result) == (1, 'a')
    result = list(result)
    assert len(result) == 5
    assert (2, 'b') in result

# Generated at 2022-06-24 09:53:21.957031
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import numpy as np

    for tqdm_class in [tqdm_auto, None]:
        for a in product(range(100), tqdm_class=tqdm_class):
            pass
        assert a == (99, 99)

        for a in product(range(100), range(100), tqdm_class=tqdm_class):
            pass
        assert a == (99, 99)

        for a in product(range(100), [10], tqdm_class=tqdm_class):
            pass
        assert a == (99, 10)

        p = product([1, None, 3], tqdm_class=tqdm_class)
        assert np.isnan(p.n)
        for a in p:
            pass


# Generated at 2022-06-24 09:53:33.285611
# Unit test for function product
def test_product():
    """
    Unit test for function product()

    Returns
    -------
    True if test passed, raises AssertionError if failed.
    """
    from ._utils import format_sizeof
    import numpy as np

    # for high dims (>3) and small `total` size, there are very few update
    # calls, so set `miniters=1` to get somewhat sensible results
    d = 3
    total = int(1e2)
    miniters = 1
    iterables = tuple([np.random.rand(int(total**(1./d))) for _ in range(d)])
    # test normal
    raw = list(itertools.product(*iterables))
    wrapped = list(product(*iterables, total=total, miniters=miniters))
    assert raw == wrapped
    # test with exceptions

# Generated at 2022-06-24 09:53:35.263818
# Unit test for function product
def test_product():
    product([1, 2], ['a'], tqdm_class=tqdm_auto, desc='product')

# Generated at 2022-06-24 09:53:38.574417
# Unit test for function product
def test_product():
    for i in product((1, 2, 3), repeat=4):
        assert len(i) == 4
    assert sum(1 for _ in product((1, 2, 3), repeat=4)) == 3 ** 4

# Generated at 2022-06-24 09:53:44.199857
# Unit test for function product
def test_product():
    """Test whether product is outputting the right stuff"""
    a = [1, 2, 3]
    b = ['a', 'b', 'c', 'd']
    assert list(itertools.product(a, b)) == list(product(a, b))

    assert list(itertools.product(a, b, repeat=3)) == list(product(a, b, repeat=3))

# Generated at 2022-06-24 09:53:51.610649
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, StringIO, closing
    from .gui import tqdm
    from .utils import _range

    @with_setup(PY3=False)
    def universal_setup():
        return StringIO(), tqdm(_range(4), mininterval=0, file=s)

    @with_setup(PY3=True)
    def universal_setup():
        return StringIO(), tqdm(_range(4), mininterval=0, file=s)

    def check(s, t):
        t.close()
        assert t.n == 4
        assert t.dynamic_miniters
        assert s.getvalue()[:4].count('\r') == 3

    for _ in _range(5):
        s, t = universal_setup()

# Generated at 2022-06-24 09:54:03.179273
# Unit test for function product
def test_product():
    from .tests import closing, closing_iterator

    class A(object):
        def __len__(self):
            return 2

    class B(object):
        def __len__(self):
            return 2

        def __iter__(self):
            for i in range(2):
                yield i

    # Test progress bar
    with closing(tqdm_auto(total=6, unit='it',
                           leave=False)) as pbar:
        for _ in product(*[A(), B()],
                         tqdm_class=pbar.__class__,
                         tqdm_kwargs=vars(pbar)):
            pass
        assert pbar.total == 6

    # Test autodetect

# Generated at 2022-06-24 09:54:15.549126
# Unit test for function product
def test_product():
    from .utils import _range
    from .tests_tqdm import with_setup, pretest, posttest, _check_ctrl_c_behaviour
    from .tests_tqdm import _random_ratelim_params
    from .tqdm_pandas import tqdm_pandas
    import numpy as np
    import pandas as pd

    def test_product_input(n):
        with tqdm_auto(total=n) as t:
            for _ in product(_range(n)):
                t.update()

    @with_setup(pretest, posttest)
    def test_product_wrap():
        for n in _range(5):
            test_product_input(n)
            _check_ctrl_c_behaviour(test_product_input, n)


# Generated at 2022-06-24 09:54:25.090003
# Unit test for function product
def test_product():
    import numpy as np
    if tqdm_auto.tqdm.__name__.lower() == 'tqdm':
        # NOTE: some versions of tqdm_auto.tqdm are buggy and raise errors
        # when used in `with` statements
        assert list(product(range(3), range(3), range(3), tqdm_class=tqdm_auto)) \
            == list(itertools.product(range(3), range(3), range(3)))
        assert list(product(range(100), tqdm_class=tqdm_auto)) \
            == list(itertools.product(range(100)))
        assert list(product([], tqdm_class=tqdm_auto)) \
            == list(itertools.product([]))

# Generated at 2022-06-24 09:54:30.191261
# Unit test for function product
def test_product():
    """Unit test for `itertools.tqdm_product`"""
    assert (len(list(product(range(2), repeat=2))) == 4)
    assert (len(list(product(range(2), repeat=2, ascii=True))) == 4)

# Generated at 2022-06-24 09:54:40.394638
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Test with total=None (input is empty list)
    with tqdm_auto(total=None) as t:
        assert list(product([], [], tqdm_class=t.__class__)) == []
        assert t.total is None

    # Test with total=None (input is generator)
    with tqdm_auto(total=None) as t:
        l = []
        for _ in product(range(3), range(3), tqdm_class=t.__class__):
            l.append(_)
        assert l == [(0, 0), (0, 1), (0, 2),
                     (1, 0), (1, 1), (1, 2),
                     (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-24 09:54:44.865163
# Unit test for function product
def test_product():
    """Test function product."""
    assert dict(product(
        [['a', 'b'], [1, 2, 3]], tqdm_class=None)) == \
        {('a', 1): None, ('a', 2): None, ('a', 3): None,
         ('b', 1): None, ('b', 2): None, ('b', 3): None}

# Generated at 2022-06-24 09:54:55.508711
# Unit test for function product
def test_product():
    from random import random
    from time import sleep
    from .utils import FormatCustomTextExtension

    N_ITER = 10
    ITERABLES = [range(10)] * N_ITER
    ERR = 1e-6

    # Test A: generator interface
    tot_size = 1
    for i in range(N_ITER):
        tot_size *= 10

    pbar = tqdm_auto(total=tot_size, miniters=tot_size, mininterval=0.5,
                     file=None)
    assert pbar.total == tot_size

    for i in product(*ITERABLES, tqdm_class=tqdm_auto):
        pbar.update()
        sleep(0.0001 * random())
        assert pbar.n == i[0] + 1


# Generated at 2022-06-24 09:55:03.869522
# Unit test for function product
def test_product():
    from io import StringIO
    from sys import stdout
    from .utils import _range

    f = StringIO()
    it = product(_range(5), _range(10), _range(5), tqdm_class=tqdm_auto,
                 file=f)
    assert sum(1 for _ in it) == 5 * 10 * 5
    output = f.getvalue()
    assert len(output) > 30

    # Should be able to use `for ... in ...` with tqdm_auto
    it = product(_range(5), _range(10), _range(5), file=stdout)
    total = 0
    for _ in it:
        total += 1
    assert total == 5 * 10 * 5

    # Should be able to use `for ... in ...` with progressbar

# Generated at 2022-06-24 09:55:09.816254
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import ExceptionPookFixture

    with ExceptionPookFixture(KeyboardInterrupt):
        from tqdm import tqdm
        from .utils import closing
        with closing(tqdm(product(np.arange(100), np.arange(10)))
                     ) as pbar:
            for _ in pbar:
                if pbar.n > 100:
                    break
                pass
            pass

# Generated at 2022-06-24 09:55:18.988000
# Unit test for function product
def test_product():
    """
    Unit tests for function product.
    """
    def assert_product(f, iterables, result):
        assert list(f(*iterables)) == result

    assert_product(product, [], [()])
    assert_product(product, [range(3)], [
        (0,), (1,), (2,)
    ])
    assert_product(product, [range(3), range(3)], [
        (0, 0), (0, 1), (0, 2),
        (1, 0), (1, 1), (1, 2),
        (2, 0), (2, 1), (2, 2),
    ])

# Generated at 2022-06-24 09:55:24.569237
# Unit test for function product
def test_product():
    try:
        assert len(list(product(*[range(10)] * 3, bar_format="{l_bar}{bar}|",
                        tqdm_class=tqdm_auto))) == 1000
    except tqdm_auto.TqdmTypeError:
        tqdm_auto.disable_tqdm()
        assert len(list(product(*[range(10)] * 3, bar_format="{l_bar}{bar}|",
                        tqdm_class=tqdm_auto))) == 1000


# Example for function product

# Generated at 2022-06-24 09:55:31.687378
# Unit test for function product
def test_product():
    import random
    import string
    """Equivalent of `itertools.product`"""
    with tqdm_auto(total=1) as t:
        for i in product(range(2), string.ascii_lowercase,
                         range(5), string.ascii_uppercase,
                         range(10), string.digits):
            t.update()
            random.shuffle(i)
            assert all(map(lambda x: x in (2, 26, 5, 26, 10, 10), map(len, i)))

# Generated at 2022-06-24 09:55:38.885100
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from .download import get_file

    # Ensure that size is correct
    fpath = get_file("sw.txt", "https://www.gutenberg.org/files/84/84-0.txt")
    with open(fpath, 'r', encoding='utf8') as f:
        data = f.read().split()
    assert format_sizeof(len(data)) == "7.8 KiB"
    assert format_sizeof(len(list(product(data, repeat=2)))) == "9.1 MiB"
    assert format_sizeof(len(list(product(data, repeat=3)))) == "7.4 GiB"

# Generated at 2022-06-24 09:55:47.841711
# Unit test for function product
def test_product():
    import tempfile
    import os
    from ..utils import _range

    def test_product(*test_args):
        return list(product(*test_args, tqdm_class=tqdm_auto,
                            leave=False))

    assert test_product([1, 2, 3]) == [(1,), (2, ), (3, )]
    assert test_product([1, 2, 3], [4, 5]) == [(1, 4), (1, 5),
                                               (2, 4), (2, 5),
                                               (3, 4), (3, 5)]


# Generated at 2022-06-24 09:55:56.876878
# Unit test for function product
def test_product():
    """
    test_product()

    Simple unit test to check if product(X, Y, Z) equals
    itertools.product(X, Y, Z)
    """
    itertools_ret = []
    tqdm_ret = []

    X = [1, 2, 3, 4]
    Y = [5, 6, 7, 8]
    Z = [9, 10, 11, 12]

    itertools_ret = list(itertools.product(X, Y, Z))
    for t in product(X, Y, Z):
        tqdm_ret.append(t)

    assert (itertools_ret == tqdm_ret)



# Generated at 2022-06-24 09:56:07.479443
# Unit test for function product
def test_product():
    """
    Test function product
    """
    for i in product([1, 2, 3]):
        pass
    t = tqdm_auto(total=9)
    for i in product([1, 2, 3], t=t):
        pass
    t.close()
    for i in product(range(100)):
        pass
    t = tqdm_auto(total=100)
    for i in product(range(100), t=t):
        pass
    t.close()

    assert list(product([1, 2])) == [(1,), (2,)]
    assert list(product([1, 2, 3])) == [(1,), (2,), (3,)]

# Generated at 2022-06-24 09:56:14.486860
# Unit test for function product
def test_product():
    from itertools import count

    def check_it(a, b, c):
        return sum(x * y * z for x, y, z in product(a, b, c))

    assert check_it(range(10), range(10), range(10)) == 3628800
    assert check_it(count(5), range(5), range(5)) == 37500
    assert check_it(range(5), count(5), range(5)) == 37500
    assert check_it(range(5), range(5), count(5)) == 37500

# Generated at 2022-06-24 09:56:17.088503
# Unit test for function product
def test_product():
    for i in product(range(3), range(3), range(3), range(3), tqdm_class=tqdm_auto):
        assert i == (0,0,0,0)
        break

# Generated at 2022-06-24 09:56:27.532987
# Unit test for function product
def test_product():
    """
    Simple unit test for function product.
    """
    import pytest
    from pytest import approx
    from .utils import closing
    from . import trange

    with closing(trange(0)) as pbar:
        pb = pbar
        assert list(product(pb, range(3))) == \
            list(itertools.product(range(0), range(3)))
    with closing(trange((1, 2, 3))) as pbar:
        pb = pbar
        assert list(product(pb, range(3))) == \
            list(itertools.product((1, 2, 3), range(3)))
    with closing(trange((1, 2, 3))) as pbar:
        pb = pbar

# Generated at 2022-06-24 09:56:36.077868
# Unit test for function product
def test_product():
    from .utils import FormatMixin
    from .std import tqdm_stdout
    from .gui import tqdm_gui

    class TestProduct(FormatMixin):
        title = "TestProduct"

        def _format_eta(self):
            return "ETA {elapsed}s".format(elapsed=self.last_print_n)

    with tqdm_stdout(tqdm_class=TestProduct) as t1:
        for _ in product(range(10), range(5)):
            t1.n += 1

    with tqdm_gui(tqdm_class=TestProduct) as t2:
        for _ in product(range(10), range(5)):
            t2.n += 1

# Generated at 2022-06-24 09:56:44.867015
# Unit test for function product
def test_product():
    """Test for function product"""
    from ._utils import _range
    from ._utils import _ensure_string_type
    from ._utils import _test_iterable_equal
    from ._utils import _pbar_rate_limit

    def test_product(a, b, **kwargs):
        """Test for function product"""
        return _test_iterable_equal(
            product(a, b, **kwargs),
            itertools.product(a, b),
            kwargs.get("unit"))

    assert test_product(_range(3), _range(3))
    assert test_product(_range(3), _range(3), total=9)
    assert test_product(_range(3), _range(3), desc="test")
    assert test_product(["e", "f", "g"], [])

# Generated at 2022-06-24 09:56:54.069330
# Unit test for function product
def test_product():
    """Test code for function itertools.product()"""
    import copy
    import numpy as np
    from nose.tools import assert_equal

    # Test if tqdm wrapper works as expected (without tqdm options)
    try:
        assert_equal(list(product(range(10), range(10), range(10),
                                  tqdm_class=None)),
                     list(itertools.product(range(10), range(10), range(10))))
    except Exception:
        raise

    # Test if tqdm wrapper works as expected (with tqdm options)

# Generated at 2022-06-24 09:56:57.641912
# Unit test for function product
def test_product():
    """Test of `tqdm.itertools.product` unit test"""
    from ...tests.test_itertools import product_test
    product_test(product, tqdm_class=tqdm_auto)

# Generated at 2022-06-24 09:57:06.193415
# Unit test for function product
def test_product():
    """
    Tests for the `product` function.
    """
    import numpy as np
    from numpy.testing import assert_array_equal

    with tqdm_auto(leave=False,
                   desc=__file__,
                   disable=None) as t:
        prod = product(range(2), range(2), range(2), tqdm_class=t.__class__)
        assert_array_equal(
            np.array(list(prod)),
            np.array(list(itertools.product(range(2), range(2), range(2)))))
        t.update()

# Generated at 2022-06-24 09:57:09.267567
# Unit test for function product
def test_product():
    """Unit test for function product"""
    with tqdm_auto(unit="it", leave=False, disable=None) as t:
        assert len(list(product(t, range(9),
                                [1, 2, 3],
                                {"a": 1, "b": 2, "c": 3}))) == 9 * 3 * 3

# Generated at 2022-06-24 09:57:15.758442
# Unit test for function product
def test_product():
    from .tests import compare_iters

# Generated at 2022-06-24 09:57:23.428927
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range
    from .utils import format_sizeof
    from itertools import product
    from sys import getsizeof

    total = 0
    def setup():
        global total
        # WARNING: VERY slow (1-2min)!
        l = list(range(15))
        total = sum(map(len, product(l, repeat=6)))
        total = format_sizeof(total)
    with_setup(setup)

    @with_setup(setup=setup)
    def test():
        l = list(product(_range(15), repeat=6))
        assert (format_sizeof(getsizeof(l)) == total)


# Generated at 2022-06-24 09:57:33.073001
# Unit test for function product
def test_product():
    from random import random

    def rand_list(size, rand_max=20):
        return [int(round(size * random())) for _ in range(size)]

    for i in range(1, 5):
        for j in range(1, 5):
            for k in range(1, 5):
                if i < j < k:
                    li = rand_list(i)
                    lj = rand_list(j, rand_max=3)
                    lk = rand_list(k, rand_max=2)
                    lst = list(product(li, lj, lk))
                    assert len(lst) == i * j * k
                    break
            else:
                continue
            break
        else:
            continue
        break

# Generated at 2022-06-24 09:57:37.176198
# Unit test for function product
def test_product():
    with tqdm_auto(desc="test_product") as t:
        for a, b in product([1, 2], [3, 4]):
            assert a * b < 10
            t.update()

# Generated at 2022-06-24 09:57:43.972089
# Unit test for function product
def test_product():
    import random
    from .tests.py26 import captured_stdout
    from .utils import format_interval
    from . import trange

    random.seed(1)
    t0 = 0
    for _ in trange(100, desc='Testing trange'):
        i = random.randint(0, 1000)
        with captured_stdout() as io:
            for _ in trange(i, desc='Testing trange', file=io.write):
                pass
        t1 = io.get_lines()[-1]
        assert format_interval(t1) == format_interval(i)

        with captured_stdout() as io:
            for _ in trange(i, desc='Testing trange', leave=True, file=io.write):
                pass

# Generated at 2022-06-24 09:57:51.899767
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import FormatCustomText
    import gc
    lst = ["ab", "cde"]
    for i in range(4):
        gc.collect()
        tqdm_prod = list(product(lst, desc="Product Loop", bar_format=FormatCustomText('{l_bar}{bar}|')))
        assert tqdm_prod == [('ab', 'cde'), ('ab', 'cde'), ('ab', 'cde'), ('ab', 'cde')]
        import sys
        if sys.version_info[:2] >= (3, 0):
            assert "\rProduct Loop:   0%|          | 0/4 [00:00<?, ?" in tqdm_prod.out.getvalue()

# Generated at 2022-06-24 09:57:59.162556
# Unit test for function product
def test_product():
    """Test the ``product()`` function."""
    vals = [
        "ab",
        "123"
    ]
    list_vals = list(product(*vals))
    assert list_vals == [("a", "1"), ("a", "2"), ("a", "3"),
                         ("b", "1"), ("b", "2"), ("b", "3")]
    list_vals = list(product(*vals,
                             tqdm_class=tqdm_auto))
    assert list_vals == [("a", "1"), ("a", "2"), ("a", "3"),
                         ("b", "1"), ("b", "2"), ("b", "3")]

# Generated at 2022-06-24 09:58:09.234155
# Unit test for function product
def test_product():
    import numpy
    try:
        # Use numpy.product if available
        numpy_prod = numpy.prod
    except AttributeError:
        numpy_prod = numpy.multiply.reduce

    assert len(list(product([[1]]))) == 1
    assert len(list(product([[1, 2], [1, 2]]))) == 4
    assert len(list(product([[1, 2], [1, 2, 3]]))) == 6

    assert numpy_prod(list(product([[1], [2], [3]]))) == 6
    assert numpy_prod(list(product([[1, 2], [3, 4]]))) == 24
    assert numpy_prod(list(product([[1, 2, 3], [4, 5, 6]]))) == 216

# Generated at 2022-06-24 09:58:17.241075
# Unit test for function product
def test_product():
    from .tests import SimpleTest
    from .utils import SlowTest

    with SimpleTest():
        for i in product([1, 2, 3], ['a', 'b'], total=6):
            pass
        for i in product(['a', 'b'], total=2):
            pass
        for i in product(['a', 'b', 'c'], total=3):
            pass
        for i in product(['a', 'b', 'c', 'd'], total=4):
            pass
        for i in product(['a', 'b', 'c', 'd', 'e'], total=5):
            pass
        for i in product(['a', 'b', 'c', 'd', 'e', 'f'], total=6):
            pass

# Generated at 2022-06-24 09:58:22.939323
# Unit test for function product
def test_product():
    from ..main import trange
    for i in product(range(2), range(3), range(4)):
        pass
    for i in product(range(4), range(3), range(2), tqdm_class=trange):
        pass
    for i in product(range(1, 4), range(1, 3), range(1, 2)):
        pass
    for i in product(range(1, 3), range(1, 4), range(1, 2)):
        pass

# Generated at 2022-06-24 09:58:29.627144
# Unit test for function product
def test_product():
    """Test tqdm.utils.itertools.product"""
    assert list(product(range(0, 4), range(4, 0, -1))) == [
        (0, 4), (0, 3), (0, 2), (0, 1), (1, 4), (1, 3), (1, 2), (1, 1),
        (2, 4), (2, 3), (2, 2), (2, 1), (3, 4), (3, 3), (3, 2), (3, 1)]

# Generated at 2022-06-24 09:58:40.763669
# Unit test for function product
def test_product():
    """ Unit test for function product """
    l = [2, 3]
    out = [i for i in product(l, tqdm_class=tqdm_auto, leave=True)]
    assert len(out) == 6
    out = [i for i in product(l, tqdm_class=tqdm_auto, disable=True)]
    assert len(out) == 6
    out = [i for i in product(l, tqdm_class=tqdm_auto,
                              dynamic_ncols=True, leave=True)]
    assert len(out) == 6
    out = [i for i in product(l, tqdm_class=tqdm_auto,
                              dynamic_ncols=True, disable=True)]
    assert len(out) == 6

# Generated at 2022-06-24 09:58:42.916265
# Unit test for function product
def test_product():
    for i in product([range(4), range(4), range(4), range(4), range(4)],
            tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:58:44.543232
# Unit test for function product
def test_product():
    list(product(range(10), range(10), tqdm_class=tqdm_auto))

if __name__ == "__main__":
    test_product()