

# Generated at 2022-06-24 09:48:50.706490
# Unit test for function product
def test_product():
    for _ in product(range(10), range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, desc="Hello"):
        pass

# Generated at 2022-06-24 09:48:54.470468
# Unit test for function product
def test_product():
    """
    Simple check equivalent to

        >>> from tqdm import tqdm
        >>> list(tqdm(itertools.product("ABC", "123"), total=9))
    """
    list(product("ABC", "123", tqdm_class=tqdm_auto.tqdm))

# Generated at 2022-06-24 09:49:01.007473
# Unit test for function product
def test_product():  # pragma: no cover
    """Tests for product"""
    import sys
    import tempfile
    import unittest
    with tempfile.TemporaryFile("w+") as fh:
        def myprint(s, end=""):
            """Wrapper around print() to save result to file-like object"""
            # print("myprint():", repr(s))
            fh.write(s + end)
        sys.stdout.flush()
        orig_print, sys.stdout.write = sys.stdout.write, myprint
        # must be done before global tqdm import (as tqdm may load tensorflow
        # which will NOT send stderr to `fh` but to the screen!
        global tqdm, tqdm_gui, tqdm_notebook
        import tqdm

# Generated at 2022-06-24 09:49:06.330570
# Unit test for function product
def test_product():
    from .tests_wrap import expected_wrapper_map
    from .tests import test_itertools
    from .tests_wrap import wrapped_test_decorator

    @wrapped_test_decorator(expected_wrapper_map)
    def basic_test(tqdm_cls):
        for _ in product(range(10),
                         range(10),
                         range(10),
                         tqdm_class=tqdm_cls):
            pass

        for _ in product([], range(10), tqdm_class=tqdm_cls):
            pass

    def test_with_initial_total_arg():
        for _ in product(range(10), total=100, tqdm_class=tqdm_auto):
            pass

    test_with_initial_total_arg()
    test_it

# Generated at 2022-06-24 09:49:13.049404
# Unit test for function product
def test_product():
    import random
    import time


# Generated at 2022-06-24 09:49:23.302696
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert (sum(1 for _ in product(range(1), range(1))) ==
            sum(1 for _ in product(range(1), range(1), tqdm_class=None)))
    assert (sum(1 for _ in product(range(1), range(5))) ==
            sum(1 for _ in product(range(1), range(5), tqdm_class=None)))
    assert (sum(1 for _ in product(range(5), range(5))) ==
            sum(1 for _ in product(range(5), range(5), tqdm_class=None)))
    assert (sum(1 for _ in product(range(5), range(1))) ==
            sum(1 for _ in product(range(5), range(1), tqdm_class=None)))

# Generated at 2022-06-24 09:49:34.224606
# Unit test for function product
def test_product():
    """
    Equivalent of `itertools.product`
    """
    from ..utils import format_sizeof
    from .utils import closing, format_interval
    import time
    import sys
    r = range(5)
    total = 1
    for i in list(map(len, (r, r, r, r))):
        total *= i
    assert total == 625

    def nocall(*args, **kwargs):
        pass

    with closing(product(r, r, r, r, r, tqdm=nocall)) as pr:
        assert len(pr) == 625

        # test disable
        pr.disable()
        # test iteration
        n = 0
        start_t = time.time()
        for _ in pr:
            n += 1

# Generated at 2022-06-24 09:49:37.962407
# Unit test for function product
def test_product():
    for n, d in zip(range(10), product(range(10), range(10), range(10), range(10), tqdm_class=tqdm_auto)):
        assert n == d[0]

# Generated at 2022-06-24 09:49:48.390849
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from tqdm import tqdm as tqdm_std
    from tqdm.contrib.test_python.utils import _range

    # Check on product
    assert (list(product(_range(3), repeat=3)) ==
            list(itertools.product(_range(3), repeat=3)))
    assert (list(product(_range(3), repeat=3, tqdm_class=tqdm_std)) ==
            list(itertools.product(_range(3), repeat=3)))
    assert (list(product(_range(3), repeat=3, tqdm_class=tqdm_std,
                          leave=False)) ==
            list(itertools.product(_range(3), repeat=3)))

# Generated at 2022-06-24 09:49:55.686971
# Unit test for function product
def test_product():
    from .tests_tqdm import with_bar, pretest_posttest
    from .tests_tqdm import with_close
    from .tests_tqdm import tmp_file

    for i in [range(10), range(1000)]:
        assert with_bar(i, product, *([range(i), range(i), range(i)]))

    for i in [zip(range(10), range(1000))]:
        with_close(i, product, *(range(i), range(i), range(i)))

    # Test `with open()` works
    with tmp_file() as tmp:
        product(*([range(10)] * 10), file=tmp)

# Generated at 2022-06-24 09:49:59.569915
# Unit test for function product
def test_product():
    # Test values
    func_ref = product(range(10), range(5, 10), tqdm_class=tqdm_auto)
    ref_list = list(itertools.product(range(10), range(5, 10)))
    assert func_ref == ref_list

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:50:09.908890
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import numpy as np

    ret = list(product(
        range(2),
        range(2),
        tqdm_class=tqdm_auto,
        dynamic_ncols=True
    ))

    assert ret == list(itertools.product(range(2), range(2)))

    ret = list(product(
        range(2),
        range(2),
        tqdm_class=tqdm_auto,
        dynamic_ncols=True
    ))

    assert ret == list(itertools.product(range(2), range(2)))


# Generated at 2022-06-24 09:50:19.753763
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from numpy.random import randint
    np, pbar = tqdm_auto.pbar, tqdm_auto

    # Test that it works with an empty product
    for _ in product():
        assert 0, "Empty lists should not produce anything"

    for _ in product(range(10)):
        assert 0, "Single-item products should not produce anything"

    for _ in product(range(2), range(2), range(2), range(2),
                     tqdm_class=tqdm_auto.trange):
        assert 0, "Single-item products should not produce anything"


# Generated at 2022-06-24 09:50:28.402290
# Unit test for function product
def test_product():
    import random
    import string
    res = product(*(string.ascii_lowercase for i in range(6)), tqdm_class=lambda x: x)
    res_list = list(res)
    assert len(res_list) == 26 ** 6
    for l in res_list:
        assert len(l) == 6
        for c in l:
            assert c in string.ascii_lowercase
    for i in range(10):
        res = product(*[list(range(i)) for k in range(i)], tqdm_class=lambda x: x)
        res_list = list(res)
        assert len(res_list) == i ** i

# Generated at 2022-06-24 09:50:31.158139
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    with tqdm_auto(total=9, unit="tests") as t:
        for i, j in product(range(3), range(3)):
            t.update()
            assert i >= 0
            assert j >= 0

# Generated at 2022-06-24 09:50:39.786872
# Unit test for function product
def test_product():
    import numpy
    from ..utils import format_sizeof
    from six.moves import zip
    from time import sleep

    def test_a(*args, **kwargs):
        try:  # python2/3 compat
            assert(list(itertools.product(*args)) == list(product(*args, **kwargs)))
        except AssertionError:  # numpy arrays fail without iteration
            assert(list(itertools.product(*map(list, args))) == list(product(*args, **kwargs)))

    try:
        import scipy
        test_a(numpy.mgrid[:3, :2])
    except ImportError:
        pass
    test_a(numpy.arange(1000))
    test_a(numpy.arange(10000).reshape(100, 100))
    test_

# Generated at 2022-06-24 09:50:41.464151
# Unit test for function product
def test_product():
    list(product((1, 2), (3, 4), tqdm=tqdm_auto))

# Generated at 2022-06-24 09:50:50.861621
# Unit test for function product
def test_product():
    from . import _test_equality
    from ..tests import common
    from ..tests._deprecate import deprecated_func_testing
    # Test the old product wrapper with tqdm_deprecated.
    with common.Python25AssertRaisesRegex(AttributeError):
        deprecated_func_testing(itertools.product, product)
    # Test the old product wrapper with deprecated.
    with common.Python25AssertRaisesRegex(AttributeError):
        deprecated_func_testing(itertools.product, product)
    # Test the new product wrapper with tqdm_deprecated.
    common.assert_equal(itertools.product, product)
    # Test the new product wrapper with deprecated.
    common.assert_equal(itertools.product, product)
    # Test the new product wrapper with tqdm_deprecated & deprecated

# Generated at 2022-06-24 09:51:00.919465
# Unit test for function product
def test_product():
    from .test_tqdm_gui import FakeTqdmFile
    from six import next
    from sys import getfilesystemencoding
    from unicodedata import normalize
    import gc

    # Only used for tests
    if __name__ == "__main__":
        raise RuntimeError(
            "``import tqdm.tests`` should only be done from pytest")

    # Test unicode support
    non_ascii = "±πéá"
    if getfilesystemencoding() != "ASCII":
        non_ascii = normalize("NFC", non_ascii)

    with FakeTqdmFile(encoding=None) as f:
        # Test zero iteration edge case
        for _ in product([], [], [], tqdm_class=tqdm_auto):
            raise RuntimeError

# Generated at 2022-06-24 09:51:10.232419
# Unit test for function product
def test_product():
    """Test function product"""
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    assert list(product(range(2), repeat=2)) == [(0, 0), (1, 0), (0, 1), (1, 1)]
    assert list(product(range(2), range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-24 09:51:15.129276
# Unit test for function product
def test_product():
    list_1 = [1, 2, 3]
    list_2 = ['a', 'b', 'c']
    # Test case 1: Assert total length
    length = 0
    for i, j in product(list_1, list_2):
        length += 1
    assert len(list(product(list_1, list_2))) == length
    # Test case 2: Assert total == None
    assert product({0, 1}, {}).total == None

# Generated at 2022-06-24 09:51:18.626840
# Unit test for function product
def test_product():
    for r in product('abcd', repeat=2, tqdm_class=tqdm_auto):
        assert len(r) == 2
        assert r[0] in 'abcd'
        assert r[1] in 'abcd'


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:51:27.900543
# Unit test for function product
def test_product():
    import sys

    from .utils import StringIO, closing

    with closing(StringIO()) as our_file, closing(StringIO()) as true_file:
        with tqdm_auto(file=our_file) as t:
            for _ in product('ACGT', 'ACGT', tqdm_class=tqdm_auto):
                pass

        with tqdm_auto(file=true_file) as t:
            for _ in itertools.product('ACGT', 'ACGT'):
                t.update()

        assert our_file.getvalue() == true_file.getvalue()

    t = tqdm_auto(total=1000)

# Generated at 2022-06-24 09:51:36.523935
# Unit test for function product
def test_product():
    from ..tqdm_pandas import trange
    for total in [None, 50000]:
        for t in [itertools.product, trange.wraps(product)]:
            for i in t(range(10), tqdm_class=trange, total=total):
                pass
    for t in [itertools.product, trange.wraps(product)]:
        for i in t(range(10), tqdm_class=trange, total=None):
            pass
    for i in itertools.product(range(10), tqdm_class=trange, total=None):
        pass

# Generated at 2022-06-24 09:51:43.943181
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    for i in product(range(4), repeat=2, tqdm_class=None):
        pass
    for i in product(range(4), repeat=2, tqdm_class=tqdm_auto):
        pass
    for i in product(range(4), repeat=2, tqdm_class=lambda **kwargs: tqdm_auto()):
        pass
    for i in product(range(2), repeat=2, tqdm_class=lambda **kwargs: tqdm_auto(**kwargs)):
        pass
    for _ in range(100):
        assert_equal(len(list(product(range(32), repeat=12, Total=None, tqdm_class=None))), 32768**12)

# Generated at 2022-06-24 09:51:54.134973
# Unit test for function product
def test_product():
    """
    Unit tests for `product`
    """
    import warnings
    import functools

    # Ignore ResourceWarnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res1 = [i for i in product(range(3), repeat=3, ascii=True,
                                   tqdm_class=tqdm_auto)]
        res2 = [i for i in itertools.product(range(3), repeat=3)]
        assert res1 == res2

    # Test with yield from
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        def triple(iterable):
            for i in iterable:
                yield i
            for i in iterable:
                yield i
            for i in iterable:
                yield i

# Generated at 2022-06-24 09:51:57.767821
# Unit test for function product
def test_product():
    import numpy as np
    for a, b in product(range(4), range(4), tqdm_class=tqdm_auto):
        assert (a, b) == np.unravel_index(a * 4 + b, (4, 4))

# Generated at 2022-06-24 09:52:03.635973
# Unit test for function product
def test_product():
    assert list(product(range(3), range(5))) == [
        (0, 0), (0, 1), (0, 2), (0, 3), (0, 4), 
        (1, 0), (1, 1), (1, 2), (1, 3), (1, 4), 
        (2, 0), (2, 1), (2, 2), (2, 3), (2, 4)]
    assert list(product(range(3), range(5), tqdm_class=None)) == \
        list(product(range(3), range(5), tqdm_class=tqdm_auto))

# Generated at 2022-06-24 09:52:10.024398
# Unit test for function product
def test_product():
    """Unit test for function product"""
    result = list(product("ABC", repeat=2, ascii=True, miniters=1,
                          total=1, tqdm_class=tqdm_auto))
    assert result == [("A", "A"), ("A", "B"), ("A", "C"),
                      ("B", "A"), ("B", "B"), ("B", "C"),
                      ("C", "A"), ("C", "B"), ("C", "C")]

# Generated at 2022-06-24 09:52:14.807852
# Unit test for function product
def test_product():
    with tqdm_auto(total=10) as t:
        for i in product([0, 2], [4, 8], tqdm_class=t.__class__):
            pass

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:52:22.648590
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from .tests_old import _test_iterable
    from .tests_old import _test_iterable_empty_sequence
    from .tests_old import _test_iterable_exception
    from .tests_old import _test_iterable_nested
    from .tests_old import _test_iterable_nested_empty_sequence
    from .tests_old import _test_iterable_nested_exception
    from .tests_old import _test_long_repeat
    from .tests_old import _test_new_total
    assert _test_iterable(product)
    assert _test_iterable_empty_sequence(product)
    assert _test_iterable_exception(product)
    assert _test_iterable_nested(product)
    assert _test

# Generated at 2022-06-24 09:52:24.254243
# Unit test for function product
def test_product():
    from .main_test import tqdm_test_module
    tqdm_test_module(globals())

# Generated at 2022-06-24 09:52:34.411505
# Unit test for function product
def test_product():
    from ..tqdm_pandas import tqdm_pandas
    from ..defaults import DEFAULTS


# Generated at 2022-06-24 09:52:38.307691
# Unit test for function product
def test_product():
    """
    >>> list(product(["A", "B", "C"], ["D", "E"]))
    [('A', 'D'), ('A', 'E'), ('B', 'D'), ('B', 'E'), ('C', 'D'), ('C', 'E')]
    """
    pass

# Generated at 2022-06-24 09:52:45.767410
# Unit test for function product
def test_product():
    """Test function `product`."""
    try:
        import numpy as np
    except ImportError:
        return
    for n in [0, 1, 2, 4, 8, 16]:
        for mode in ["sequential", "random", "identity"]:
            # Generate a matrix to iterate with chunks
            X = np.random.random((n, n))
            if mode == "sequential":
                idx = np.arange(n)
            elif mode == "random":
                idx = np.random.permutation(n)
            elif mode == "identity":
                idx = np.arange(n)
                idx_i = np.random.permutation(n)
                idx_j = np.random.permutation(n)

# Generated at 2022-06-24 09:52:51.173580
# Unit test for function product
def test_product():
    """Test for product format"""
    from sys import version_info as py_version_info

# Generated at 2022-06-24 09:53:05.439241
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # pylint: disable=redefined-outer-name
    from ..tests import closing, closing_iter
    from ..utils import format_sizeof

    try:
        from contextlib import ExitStack
    except ImportError:
        from contextlib2 import ExitStack

    from construction.iterable import OuterProduct
    from construction.combinatorics import prod
    from ..nested import NestedDict

    with ExitStack() as stack:
        a = stack.enter_context(closing_iter(range(4)))
        b = stack.enter_context(closing_iter(range(4)))
        c = stack.enter_context(closing_iter(range(4)))
        d = stack.enter_context(closing(OuterProduct(a, b, c)))
        t

# Generated at 2022-06-24 09:53:12.690274
# Unit test for function product
def test_product():
    """
    Test that `product` gives the same output as `itertools.product`

    Fails if the output is different or if an exception is raised.
    """
    import numpy as np
    assert(list(product([1, 2, 3], repeat=2)) ==
           list(itertools.product([1, 2, 3], repeat=2)))
    assert(list(product([1, 2, 3], repeat=2, tqdm_class=tqdm_auto)) ==
           list(itertools.product([1, 2, 3], repeat=2)))
    assert(list(product([1, 2, 3], repeat=2, tqdm_class=tqdm_auto,
                        disable=True)) ==
           list(itertools.product([1, 2, 3], repeat=2)))

# Generated at 2022-06-24 09:53:19.114448
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    x = list(range(5))
    y = list(range(5, 10))
    z = list(range(10, 15))
    for xyz in product(x, y, z):
        pass # Will only get here if no errors
    for xyz in product(x, y, z, disable=True):
        pass # Will only get here if no errors

# Generated at 2022-06-24 09:53:25.899906
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..std import StringIO
    tqdm_test = StringIO()
    for _ in product("abc", range(3), tqdm_class=tqdm_auto,
                     file=tqdm_test, mininterval=0):
        pass
    output = 'a  b\nc  0\nd  1\ne  2\n'
    assert tqdm_test.getvalue() == output

# Generated at 2022-06-24 09:53:35.047306
# Unit test for function product
def test_product():
    for i in product((1, 2, 3), (4, 5), (6,)):
        assert len(i) == 3
    for i in product((1, 2, 3), repeat=3):
        assert len(i) == 3
    for i in product('abc', repeat=3):
        assert len(i) == 3
    assert list(product('abc', repeat=1)) == list('abc')
    assert len(list(product('abc', repeat=1))) == 3
    assert list(product('abcd', repeat=2)) == [
        a + b for a in 'abcd' for b in 'abcd']

# Generated at 2022-06-24 09:53:45.744107
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import pytest
    from distutils.version import LooseVersion
    from ..pandas import trange

    with trange(2) as t:
        for _ in itertools.product(range(2), range(2)):
            t.update()
    assert t.n == 4

    with trange(3) as t:
        for _ in product(range(2), range(2), range(2)):
            t.update()
    assert t.n == 8

    # test total
    with trange(3) as t:
        for _ in product(range(2), range(2), range(2)):
            t.update(1)
    assert t.n == 3


# Generated at 2022-06-24 09:53:50.247226
# Unit test for function product
def test_product():
    assert list(product(range(3), range(3), range(3))) == list(itertools.product(range(3), range(3), range(3)))

# Generated at 2022-06-24 09:54:01.507950
# Unit test for function product

# Generated at 2022-06-24 09:54:10.302611
# Unit test for function product
def test_product():
    a = lambda x: x
    try:
        b = tqdm_auto(**{"leave": True})
    except Exception:
        b = None
    try:
        c = tqdm_auto(**{"leave": False})
    except Exception:
        c = None
    list_of_lists = [[1, 2], ['a', 'b', 'c'], [3, 4, 5, 6]]
    for cls in [a, b, c]:
        if cls is None:
            continue

# Generated at 2022-06-24 09:54:16.246380
# Unit test for function product
def test_product():
    """
    Test `itertools.product` wrapper.
    """
    iterables = [[1, 2], [3, 4], [5, 6]]
    expected = [[1, 3, 5], [1, 3, 6],
                [1, 4, 5], [1, 4, 6],
                [2, 3, 5], [2, 3, 6],
                [2, 4, 5], [2, 4, 6]]
    p = product(*iterables)
    assert list(p) == expected

if __name__ == '__main__':
    import pytest  # noqa: E402
    pytest.main(['-rx', '--pdb', __file__])

# Generated at 2022-06-24 09:54:25.407020
# Unit test for function product
def test_product():
    """Test case for product"""
    from tqdm._tqdm import trange
    from ..utils import format_sizeof

    def count(iterator):
        c = 0
        for _ in iterator:
            c += 1
        return c

    assert product('AB', '12') == product('AB', '12')
    assert count(product('AB', '12')) == 2 * 2
    assert count(product('ABC', '12', 'XYZ')) == 3 * 2 * 3
    assert count(product(range(3))) == 3
    assert count(product(range(3), range(3))) == 3 * 3
    assert count(product(range(3), repeat=3)) == 3 * 3 * 3
    assert count(product([1], repeat=10)) == 1 ** 10

# Generated at 2022-06-24 09:54:34.937330
# Unit test for function product
def test_product():
    """
    Tests that the itertools.product wrapper is functioning correctly.

    Parameters
    ----------
    None

    Returns
    -------
    True is returned if the wrapper is functioning correctly

    Raises
    ------
    AssertionError is raised if the wrapper is not functioning correctly
    """
    RANGE = 10
    reference = list(itertools.product(range(RANGE), range(RANGE)))
    check = list(product(range(RANGE), range(RANGE), tqdm_class=tqdm_auto))
    assert (reference == check)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:54:40.282427
# Unit test for function product
def test_product():
    """Unit test"""
    from ..tqdm import tqdm
    for i in tqdm.product([1, 2, 3], total=3):
        pass
    assert i == (3, 3)
    i_ = None
    for i in tqdm.product([1, 2, 3], total=3):
        i_ = i
    assert i == (3, 3)
    assert i_ == (2, 3)

# Generated at 2022-06-24 09:54:48.607405
# Unit test for function product
def test_product():  # pragma: no cover
    from ..utils import FormatCustomText as fct
    try:
        from itertools import product
    except ImportError:
        pass
    else:
        for x, y in zip(product('ABC', 'xyz'), tqdm.product('ABC', 'xyz')):
            assert x == y
            assert list(x) == list(y)

        for x, y in zip(product('ABC'), tqdm.product('ABC')):
            assert x == y
            assert list(x) == list(y)

        from tqdm.contrib.tests.utils import use_unicode_stdout

# Generated at 2022-06-24 09:54:59.545124
# Unit test for function product
def test_product():
    try:
        __IPYTHON__
    except NameError:
        ipy_mode = False
    else:
        ipy_mode = True

    from ..utils import FormatCustomTextExt
    if ipy_mode:  # pragma: nocover
        for i in tqdm_notebook(product(['A', 'B'], repeat=2, tqdm_class=FormatCustomTextExt)):
            pass

# Generated at 2022-06-24 09:55:04.906426
# Unit test for function product
def test_product():
    import sys
    sys.stderr.write('Testing function product ...')
    from .loop import progressbar, progressbar_deps
    from .pandas import pandas_deps, pandas_deps_within_range
    for tqdm_class in [None] + progressbar_deps:
        for start, stop in pandas_deps + pandas_deps_within_range:
            for chunk in product(range(start, stop),
                                 tqdm_class=tqdm_class):
                pass
    sys.stderr.write(' done\n')

# Generated at 2022-06-24 09:55:09.238835
# Unit test for function product
def test_product():
    for i, j in product(range(5), ['a', 'b']):
        assert i in range(5)
        assert j in ['a', 'b']


if __name__ == "__main__":
    from ._version import __version__
    print(__version__)
    test_product()

# Generated at 2022-06-24 09:55:18.756956
# Unit test for function product
def test_product():
    import numpy as np
    from .utils import TestTqdmExecution
    from .tests_tqdm import pretest_posttest_run
    for kwargs in TestTqdmExecution.bar_desc_total_kwargs:
        for i in range(1, 4):
            for j in range(10, 13):
                for k in range(100, 103):
                    for ii in range(i):
                        for jj in range(j):
                            for kk in range(k):
                                a = []
                                p = product(
                                    range(i),
                                    range(j),
                                    range(k),
                                    **kwargs)
                                for v in p:
                                    a.append(v)
                                print(a)

# Generated at 2022-06-24 09:55:25.552547
# Unit test for function product
def test_product():
    """Test function itertools_product"""
    list_test1 = [1, 2, 3]
    list_test2 = [4, 5]
    import os
    try:
        from .itertools_test_cases import test_cases
    except (ImportError, SystemError):
        import sys
        sys.path.append(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))))
        from .itertools_test_cases import test_cases
    for t in test_cases(product(list_test1, list_test2, tqdm_class=None)):
        pass

# Generated at 2022-06-24 09:55:30.451195
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from itertools import islice

    def check(total, i):
        assert i == total - 1

    for k in range(4):
        l = range(k)
        for i in product(*([l] * k), tqdm_class=tqdm_auto):
            check(k**k, i[-1])

    for k in range(4):
        l = range(k)
        g = product(*([l] * k), tqdm_class=tqdm_auto)
        assert hasattr(g, 'n')
        assert hasattr(g, 'total')
        assert hasattr(g, 'desc')
        assert hasattr(g, 'smoothing')
        assert hasattr(g, 'dynamic_ncols')
        assert hasattr

# Generated at 2022-06-24 09:55:38.605682
# Unit test for function product
def test_product():
    from ..tests import test_itertools_fast

    product(*test_itertools_fast.ITERATORS, total=test_itertools_fast.PRODUCT_TOTAL,
            smoothing=test_itertools_fast.SMOOTHING)
    product(*test_itertools_fast.ITERATORS, total=test_itertools_fast.PRODUCT_TOTAL,
            smoothing=test_itertools_fast.SMOOTHING, ascii=test_itertools_fast.ASCII)

# Generated at 2022-06-24 09:55:47.677700
# Unit test for function product
def test_product():
    """Test function `product`"""
    from .tests_tqdm import pretest_posttest

    with pretest_posttest() as (p, _):
        # Test manual total, same length
        for kwargs in [{}, {'total': 10000}]:
            for l in (1, 100):
                p(product, range(10), range(10), range(10),
                  range(10), tqdm_class=tqdm_auto, **kwargs)
                p(product, range(l), range(l), range(l),
                  range(l), tqdm_class=tqdm_auto, **kwargs)
                p(product, range(l), range(l), range(l),
                  range(l), tqdm_class=tqdm_auto, **kwargs)

        # Test manual

# Generated at 2022-06-24 09:55:53.140969
# Unit test for function product
def test_product():
    """
    Unit Test function to test the function product
    """
    try:
        from numpy.testing import assert_equal
    except:
        from nose.tools import assert_equal

    from ..utils import FormatCustomText
    from ..utils import format_sizeof

    iterable = list(range(20, 60, 10))
    for _ in product(iterable, iterable):
        pass

    # Test custom text formatting
    class MyClass():
        def __len__(self):
            return 60

        def __repr__(self):
            return "MyClass"

    iterable = MyClass()
    format_sizeof_str = format_sizeof(len(iterable), "", 1)

    # Test custom class

# Generated at 2022-06-24 09:55:57.710880
# Unit test for function product
def test_product():
    from itertools import product as itertools_product
    for a, b in (range(4), range(10), range(20), range(100)):
        gen = product(range(a), range(b), total=a * b)
        gen2 = itertools_product(range(a), range(b))
        assert list(gen) == list(gen2)

# Generated at 2022-06-24 09:56:05.017912
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy import sum as np_sum, array as np_array
    from tqdm import tqdm

    # Test 1: no positional args
    assert list(product(tqdm=tqdm)) == [()]

    # Test 2: single positional arg
    assert list(product([1, 2], tqdm=tqdm)) == [(1,), (2,)]

    # Test 3: multiple positional args
    a = list(range(3))
    b = list('abc')
    c = list('XY')

# Generated at 2022-06-24 09:56:16.701707
# Unit test for function product
def test_product():
    import sys
    import os
    import unittest
    import numpy as np
    from ..utils import _range

    class Tests(unittest.TestCase):
        "Test product function"

        def test_product_list(self):
            """
            Check that the same result is obtained with list
            """
            A = np.arange(3)
            B = np.arange(3)

            for I in product(A, B):
                for J in itertools.product(A, B):
                    np.testing.assert_array_equal(I, J)

        def test_product_range(self):
            """
            Check that the same result is obtained with range
            """

# Generated at 2022-06-24 09:56:25.907287
# Unit test for function product
def test_product():
    """ Test `tqdm.itertools.product` """
    from ..tests import pretest_posttest
    test = pretest_posttest()
    assert test(product, range(0), None) == []
    assert test(product, range(3), range(3), None) == list(itertools.product(
        range(3), range(3)))

    total_length = 0
    for _ in product([1, 2, 3], [4, 5, 6]):
        total_length += 1
    assert total_length == len([1, 2, 3]) * len([4, 5, 6])

    import sys
    try:
        from contextlib import redirect_stdout
    except ImportError:
        from contextlib import _redirect_stdout as redirect_stdout

# Generated at 2022-06-24 09:56:31.455113
# Unit test for function product
def test_product():
    from sys import stderr
    from ..utils import format_interval
    from ..tqdm_gui import trange

    # Check that product is equal to built-in
    with trange(3, file=stderr) as t:
        assert t.total == 3
        count = 3 * 3 * 3 * 3 * 3 * 3 * 3 * 3 * 3

# Generated at 2022-06-24 09:56:32.803514
# Unit test for function product
def test_product():
    from .test_examples import test_examples
    test_examples(product, "product")

# Generated at 2022-06-24 09:56:43.449594
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..utils import format_sizeof
    A = list(range(50)) + [None]
    B = list(range(50)) + [None]
    C = list(range(30))
    D = list(range(20)) + [None]


# Generated at 2022-06-24 09:56:52.789697
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .utils import FormatCustom

    # Test basic functionality
    expected = [('a', 'b'), ('a', 'c'), ('b', 'b'), ('b', 'c')]
    for i, j in enumerate(product('ab', 'bc')):
        assert j == expected[i]

    # Test with desc
    expected = [('a', 'b'), ('a', 'c'), ('b', 'b'), ('b', 'c')]
    for i, j in enumerate(product('ab', 'bc', desc="test_product")):
        assert j == expected[i]

    # Test with tqdm_class
    expected = [('a', 'b'), ('a', 'c'), ('b', 'b'), ('b', 'c')]

# Generated at 2022-06-24 09:57:04.252478
# Unit test for function product
def test_product():
    """
    Unit tests for product
    """
    import pytest

    # Cannot iterate over the product of int
    with pytest.raises(TypeError):
        assert sum(product(1)) == 0

    # Comparing with count()
    assert sum(product(range(0, 5))) == sum(range(0, 5))

    # Comparing with count()
    assert list(product(range(0, 5), repeat=2)) == list(itertools.product(range(0, 5), repeat=2))

    # Checking total
    assert sum(product(range(0, 5), range(0, 5), range(0, 5), tqdm_class=tqdm_auto)) == \
        sum(itertools.product(range(0, 5), range(0, 5), range(0, 5)))

# Generated at 2022-06-24 09:57:06.526604
# Unit test for function product
def test_product():
    """Test function product"""
    io = product([3, 2, 1], [1, 2, 3], [1, 2, 3], tqdm_class=tqdm_auto)
    for j in io:
        pass

# Generated at 2022-06-24 09:57:11.139295
# Unit test for function product
def test_product():
    """Unit tests for `itertools.product`"""
    assert list(product(['a', 'b', 'c'], [1, 2, 3])) == \
        [('a', 1), ('a', 2), ('a', 3), ('b', 1), ('b', 2), ('b', 3),
         ('c', 1), ('c', 2), ('c', 3)]

# Generated at 2022-06-24 09:57:20.895741
# Unit test for function product
def test_product():
    from collections import Counter
    from .generate_tests import CheckAux, R
    with CheckAux(loop=100, count=100, leave=False, miniters=1) as ca:
        for i, j in product(range(10), R(0, 10), tqdm_class=ca):
            pass
        ca.assert_lock()
        assert ca.lock.count == 100
        # test nested instances
        ca.print_lock()
        c = Counter()
        for i, j in product(range(10), R(0, 10), R(0, 10), tqdm_class=ca):
            c[(i, j)] += 1
        ca.assert_lock()
        assert ca.lock.count == 1000
        # presence of nested instances
        assert ca.lock.descs
        assert ca.lock

# Generated at 2022-06-24 09:57:25.138970
# Unit test for function product
def test_product():
    from .tests import _range
    for a, b, c in product(_range(2), _range(2), _range(2)):
        pass
    assert a == b == c == 1


__all__ = ['setsum']



# Generated at 2022-06-24 09:57:30.895689
# Unit test for function product
def test_product():
    import random
    iterables_list = [[random.random() for i in range(random.randint(1, 100))]
                      for j in range(random.randint(1, 10))]
    result = list(product(*iterables_list))
    for i in range(len(result)):
        assert result[i] == itertools.product(*iterables_list)[i]

# Generated at 2022-06-24 09:57:33.829132
# Unit test for function product
def test_product():
    assert list(product(range(5), repeat=2)) == \
        [(x, y) for x in range(5) for y in range(5)]

# Generated at 2022-06-24 09:57:42.999909
# Unit test for function product
def test_product():
    import numpy as np
    from .gui import tqdm
    a = np.array([1, 2, 3])
    b = np.array(range(10))
    c = np.array([1])
    d = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
                  18, 19, 20])
    test_results = [(1, 8, 13),
                    (1, 18, 23),
                    (2, 8, 13),
                    (2, 18, 23),
                    (3, 8, 13),
                    (3, 18, 23)]
    test = product(a, b, d, tqdm=tqdm)

# Generated at 2022-06-24 09:57:53.687193
# Unit test for function product
def test_product():
    """Test function `product`."""
    # Test number of iterations
    list_results = list(product(range(10), range(10)))
    assert len(list_results) == 100
    # Test content of results:
    for i, j in zip(list_results, list(itertools.product(range(10), range(10)))):
        assert i == j
    # Test dynamic display:
    results = product(range(10), range(10), tqdm_class=tqdm_auto, miniters=1)
    for i in range(10):
        next(results)
    # Test `total` argument:
    results = product(range(10), range(10), tqdm_auto, total=10)
    for i in range(10):
        next(results)

# Generated at 2022-06-24 09:58:01.560607
# Unit test for function product
def test_product():
    """Test suite for function product"""
    from ..utils import TestingIO

    with TestingIO(tqdm_class=object) as (out, err):
        assert list(product([1])) == [(1, )]

# Generated at 2022-06-24 09:58:11.761496
# Unit test for function product
def test_product():
    """
    Unit test for function product

    Note:
        When run from the command line, you can use the `--bench` flag
        (e.g. ``python tqdm/std.py --bench``) for a (very) unscientific
        benchmark.
    """
    from .tqdm_gui import tgrange, trange
    from .tqdm import trange
    from .std import product
    from .utils import _term_move_up
    from .utils import format_sizeof
    import os
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Benchmark

# Generated at 2022-06-24 09:58:18.500478
# Unit test for function product
def test_product():
    from .utils import States

    # A: list of lists
    A = [list(range(3)), list(range(3)), list(range(3))]
    # B: generator of generators
    B = (range(3) for _ in range(3))

    # testing that both methods give the same results
    A_result = [i for i in tqdm.product(*A)]
    assert A_result == list(itertools.product(*A))
    B_result = [i for i in tqdm.product(*B, tqdm_cls=tqdm.trange)]
    assert B_result == list(itertools.product(*B))

    # testing that the results are correct
    assert len(A_result) == 27
    assert A_result[0] == (0, 0, 0)

# Generated at 2022-06-24 09:58:29.490866
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy import product as nprod
    from numpy import array


# Generated at 2022-06-24 09:58:37.164462
# Unit test for function product
def test_product():
    import io

    with io.StringIO() as buf:
        for _ in product(range(5), "abcd", tqdm_class=tqdm_auto, file=buf):
            pass
        # Ensure no crash (no exception raised)
        pass
    assert len(buf.getvalue()) > 0

# Generated at 2022-06-24 09:58:48.399208
# Unit test for function product
def test_product():
    """Test for `product`."""
    from .tests_wip import setup_tests, test_values, teardown_tests
    import sys

    setup_tests()

    # basic test for tqdm
    for n, kwargs in test_values:
        out = list(product(range(n), **kwargs))
    try:
        if sys.version_info[0] == 2:
            assert out == [(i, j) for i in range(n) for j in range(n)]
        else:
            assert out == list(itertools.product(range(n), repeat=2))
    except AssertionError:
        print(out, list(itertools.product(range(n), repeat=2)))
        raise

    # custom tqdm class