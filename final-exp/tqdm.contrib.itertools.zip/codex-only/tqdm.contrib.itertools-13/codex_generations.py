

# Generated at 2022-06-24 09:48:53.070524
# Unit test for function product
def test_product():
    from ..__main__ import _test_arg_strings
    # Uncomment for unit test
    # _test_arg_strings("function", "itertools.product", "product")
    # Test with a generator
    assert list(product("ABC", "xy")) == \
        list(itertools.product("ABC", "xy"))

    # Test with a list
    assert list(product("ABC", ["x", "y"]))

# Generated at 2022-06-24 09:48:57.993940
# Unit test for function product
def test_product():
    # Test normal behaviour
    total = 1
    for i in range(1, 4):
        total *= i
        assert len(list(product(range(i), range(i), tqdm_class=None))) == total

    # Test total override
    total = 1
    for i in range(1, 4):
        total *= i
        assert len(list(product(range(i), range(i), tqdm_class=None, total=10000))) == 10000

# Generated at 2022-06-24 09:49:03.344765
# Unit test for function product
def test_product():
    """Test for itertools.product equivalence"""
    from .tests_tqdm import pretest_posttest

    def func(a, b):
        """
        :param a: list
        :param b: int
        """
        total = 0
        a = product(a, range(b), tqdm_class=tqdm_auto)
        for _ in a:
            total += 1
        return total

    return pretest_posttest(func, itertools.product)

# Generated at 2022-06-24 09:49:06.878313
# Unit test for function product
def test_product():
    """
    Test for function product.
    """
    from ..tqdm_gui import tqdm
    from ..__init__ import _range
    from numpy import prod
    from random import sample

    total = sample(list(_range(1, 10)), 1)[0]
    d = sample(list(_range(1, 100)), total)
    assert sum(1 for _ in product(*[d]*2)) == prod(d)
    assert sum(1 for _ in product(*[d]*total)) == prod(d)**total
    assert sum(1 for _ in tqdm(product(*[d]*total))) == prod(d)**total



# Generated at 2022-06-24 09:49:11.710135
# Unit test for function product
def test_product():
    from pandas import DataFrame

    from pandas.util.testing import assert_frame_equal

    tqdm_kwargs = {"mininterval": 0.1}

    itl = [[1, 2, 3], [4, 5, 6]]
    exp = [(1, 4), (1, 5), (1, 6), (2, 4), (2, 5), (2, 6), (3, 4), (3, 5), (3, 6)]

    i = itertools.product(*itl)
    assert list(i) == exp

    i = product(*itl)
    assert list(i) == exp

    i = product(*itl, **tqdm_kwargs)
    out = list(i)
    assert out == exp

    # https://github.com/tqdm/tqdm/issues/516

# Generated at 2022-06-24 09:49:22.281415
# Unit test for function product
def test_product():
    # pylint: disable=E1101
    import sys
    import tqdm
    import numpy as np

    it = tqdm.product(range(1000), range(1000), tqdm_class=tqdm.tqdm_gui)
    np.testing.assert_array_equal(
        [i for i in it],
        np.array(sorted(_ for _ in itertools.product(range(1000), range(1000)))),
        'product(range(1000), range(1000))')

    it = tqdm.product(np.arange(1000), np.arange(1000), tqdm_class=tqdm.tqdm_gui)

# Generated at 2022-06-24 09:49:29.874944
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    with tqdm_auto(total=0) as t:
        t.set_description("product")
        assert (list(product(range(5), repeat=2))
                == list(itertools.product(range(5), repeat=2)))

        assert (list(product(range(5), repeat=1))
                == list(itertools.product(range(5), repeat=1)))

        assert (list(product(range(5), repeat=0))
                == list(itertools.product(range(5), repeat=0)))

# Generated at 2022-06-24 09:49:38.758375
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import gc

    iter_ = [
        ["a", "b", "c"],
        ["d", "e"],
        ["f"]
    ]
    expected = [
        ('a', 'd', 'f'),
        ('a', 'e', 'f'),
        ('b', 'd', 'f'),
        ('b', 'e', 'f'),
        ('c', 'd', 'f'),
        ('c', 'e', 'f')
    ]

    # Test default behaviour
    gc.disable()
    for i, j in zip(product(*iter_), expected):
        assert i == j
    gc.enable()

    # Test the default mininterval

# Generated at 2022-06-24 09:49:45.117054
# Unit test for function product
def test_product():
    T = [3, 2, 1]
    assert ([i for i in product(T)] ==
            [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
             (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1),
             (2, 0, 0), (2, 0, 1), (2, 1, 0), (2, 1, 1)])

# Generated at 2022-06-24 09:49:54.660839
# Unit test for function product
def test_product():
    """
    Test that itertools.product returns the same but faster than nested loops.
    """
    import collections

    # Test that nested loop is equivalent to itertools.product
    seqs = [
        list(range(5)),
        list(map(str, range(5))),
        list(map(str, range(5))),
    ]
    prod_expected = itertools.product(*seqs)
    prod_nested = _product_nested(seqs)
    assert collections.Counter(prod_expected) == collections.Counter(prod_nested)

    # Test that itertools.product is faster than nested loop
    # (on my machine, it is about 40 times faster)
    import timeit
    from ..utils import format_sizeof


# Generated at 2022-06-24 09:50:02.367221
# Unit test for function product
def test_product():
    """[Internal]  Unit test for the `tqdm.itertools` module"""
    from .tests import pretest_posttest, unittest

    # Functional tests
    pretest_posttest()
    for tqdm_class in [tqdm_auto, unittest]:
        with tqdm_class(total=1, leave=False, unit="unit") as t:
            assert all(i == j for i, j in zip(
                t.__iter__(),
                product(range(5), range(5), tqdm_class=tqdm_class)))
            t.update_to(1)

# Generated at 2022-06-24 09:50:12.399514
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    import numpy as np
    from ..utils import format_sizeof

    # prevent nested tqdm
    a = range(int(1e4))
    b = range(int(1e4))
    c = range(int(1e4))
    res = product(a, b, c, tqdm_class=None)

    # Test data
    i = 0
    for i, _ in enumerate(res):
        pass
    assert i + 1 == int(1e4 ** 3)

    # Test total
    res = product(a, b, c, tqdm_class=tqdm_auto)
    i = 0
    for i, _ in enumerate(res):
        pass
    assert i + 1 == int(1e4 ** 3)



# Generated at 2022-06-24 09:50:22.801224
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product('ABCD', repeat=2)) == [('A', 'A'), ('A', 'B'), ('A', 'C'), ('A', 'D'),
                                               ('B', 'A'), ('B', 'B'), ('B', 'C'), ('B', 'D'),
                                               ('C', 'A'), ('C', 'B'), ('C', 'C'), ('C', 'D'),
                                               ('D', 'A'), ('D', 'B'), ('D', 'C'), ('D', 'D')]

    assert list(product('ABCD', repeat=2, tqdm_class=False)) == list(product('ABCD', repeat=2))

    try:
        from tqdm import tqdm
    except:
        return


# Generated at 2022-06-24 09:50:23.975607
# Unit test for function product
def test_product():
    from .tests import test_product as tp
    tp(product)

# Generated at 2022-06-24 09:50:31.942314
# Unit test for function product
def test_product():
    """Product does not have a type signature, so this test serves to explain
    what the function does.

    Examples
    --------
    >>> from tqdm.contrib import product
    >>> from tqdm._utils import _term_move_up
    >>> list(product(['a', 'b'], ['c', 'd'], tqdm_class=None))
    [('a', 'c'), ('a', 'd'), ('b', 'c'), ('b', 'd')]
    >>> list(product([['a', 'b'], ['c', 'd']], repeat=2))
    [['a', 'b'], ['a', 'd'], ['c', 'b'], ['c', 'd']]
    """
    from . import trange
    from .utils import format_interval
    from .utils import SimpleNamespace

# Generated at 2022-06-24 09:50:35.481172
# Unit test for function product
def test_product():
    from random import randint
    n = randint(1, 10)
    m = randint(1, 10)
    k = randint(1, 10)
    for i, j, k in product(range(n), range(m), range(k)):
        pass

# Generated at 2022-06-24 09:50:46.198556
# Unit test for function product
def test_product():
    from ._utils import _range

    for tqdm_cls in [tqdm_auto, None]:
        a = list(product(range(4), repeat=4, tqdm_class=tqdm_cls))
        assert a == list(itertools.product(range(4), repeat=4))

        b = list(product(range(2), repeat=3, tqdm_class=tqdm_cls))
        assert b == list(itertools.product(range(2), repeat=3))

        with tqdm_auto(total=None) as t:
            assert list(product(_range(2), tqdm_class=tqdm_cls)) == [
                (0, 0), (0, 1), (1, 0), (1, 1)]
            assert t.total == 4



# Generated at 2022-06-24 09:50:54.054291
# Unit test for function product
def test_product():
    from ._tqdm_test.tests_tqdm import Diff
    from ._tqdm_test.utils import ClosingContextBase

    class ProductClosingContext(ClosingContextBase):
        def closing_context(self, *args, **tqdm_kwargs):
            return product(*args, **tqdm_kwargs)

    with ProductClosingContext() as ctx:
        assert ctx.diff(Diff(2, 3, 0), [2, 3, 4], [5, 6]) == \
            [10, 12, 15, 12, 14, 18, 15, 18, 24]
test_product()

# Generated at 2022-06-24 09:51:03.297354
# Unit test for function product
def test_product():
    "Test for product"
    from .sigs import signature
    assert signature(product) == signature(itertools.product)
    assert list(product([1, 2])) == [(1,), (2,)]
    assert list(product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    assert list(product([1, 2], "ab")) == [('1', 'a'), ('1', 'b'),
                                           ('2', 'a'), ('2', 'b')]
    tqdm_product = product([1, 2], "ab", tqdm_class=tqdm_auto)
    assert next(tqdm_product) == ('1', 'a')
    assert next(tqdm_product) == ('1', 'b')
   

# Generated at 2022-06-24 09:51:06.994453
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Verify the total product of the set {1,2,3} with itself 4 times
    # is 81
    assert len(list(product(range(1, 4), repeat=4))) == 81

# Generated at 2022-06-24 09:51:15.233289
# Unit test for function product
def test_product():
    # Test total
    import io
    import sys
    fake_stderr = io.BytesIO()
    sys.stderr = fake_stderr
    _ = list(product(range(10), [1,2], tqdm_class=tqdm_auto.tqdm))
    assert not fake_stderr.getvalue()
    sys.stderr = sys.__stderr__
    # Test output
    assert list(product([0, 1])) == list(itertools.product([0, 1]))
    assert list(product([0, 1], [2, 3])) == list(itertools.product([0, 1], [2, 3]))

# Generated at 2022-06-24 09:51:17.125373
# Unit test for function product
def test_product():
    from .tests import test_product as _test_product
    return _test_product(tqdm_class=tqdm_auto)

# Generated at 2022-06-24 09:51:27.312626
# Unit test for function product
def test_product():
    from ..tests import common
    from ..utils import format_sizeof
    test_input = list(range(100))
    common.test_sequence(test_input, itertools.product,
                         lambda t: list(product(t, total=0)))
    common.test_sequence(test_input, itertools.product,
                         lambda t: list(product(t, total=(len(t) * len(t)))))

    for total in (0, 100):
        expected = list(itertools.product(test_input, test_input))
        assert len(expected) == (len(test_input) * len(test_input))
        test_input_mem_size = format_sizeof(test_input, 'B')
        # Test manual `total`

# Generated at 2022-06-24 09:51:38.044917
# Unit test for function product
def test_product():
    a = list(product([1, 2, 3, 4], repeat=3))

# Generated at 2022-06-24 09:51:42.256389
# Unit test for function product
def test_product():
    assert len(list(product([1, 2, 3], [1, 2, 3]))) == 9
    assert list(product([1, 2, 3], [1, 2, 3])) == [(1, 1), (1, 2), (1, 3),
                                                   (2, 1), (2, 2), (2, 3),
                                                   (3, 1), (3, 2), (3, 3)]

# Generated at 2022-06-24 09:51:51.466942
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # Suppress resource warnings
    if hasattr(tqdm_auto, 'logger'):
        tqdm_auto.logger.disabled = True
    with tqdm_auto(total=1) as t:
        pass  # Required as long as no error is above

    from .tests import RandomArguments, TestCase

    class ProductTest(TestCase):
        """
        Test for `itertools.product`.
        """

        def test_product_integration(self):
            iterables = [[1, 2],[3, 4, 5],[6, 7]]
            i = 0
            for _ in product(*iterables):
                i += 1
            self.assertEqual(i, itertools.product(*iterables).__sizeof__())


# Generated at 2022-06-24 09:52:01.647069
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    def check(tqdm_func):
        assert list(tqdm_func(range(3), range(5), range(7))) == list(
            product(range(3), range(5), range(7)))
        assert list(tqdm_func(range(1), range(1), range(1))) == list(
            product(range(1), range(1), range(1)))
        assert list(tqdm_func(range(1000))) == list(product(range(1000)))

# Generated at 2022-06-24 09:52:09.344652
# Unit test for function product
def test_product():
    from ..tests.test_tqdm import tqdm
    try:
        range = xrange
    except NameError:
        pass
    from ..tests.test_itertools import test_product

    l = [range(10 ** a, 10 ** (a + 1)) for a in range(3)]
    for _, a, b in zip(range(3), product(*l, tqdm_class=tqdm),
                       test_product(*l)):
        assert (a == b)

# Generated at 2022-06-24 09:52:19.459311
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from numpy import product as np_product
    from random import randint
    # Test on ranges
    x = product(range(5), repeat=2, tqdm_class=tqdm_auto)
    x = list(x)
    L = [i for i in range(5)]
    assert len(x) == 25
    assert x == [(i, j) for i in L for j in L]
    # Test on non-ranges
    x = product(list(range(5)), repeat=2, tqdm_class=tqdm_auto)
    x = list(x)
    L = [i for i in range(5)]
    assert len(x) == 25
    assert x == [(i, j) for i in L for j in L]
   

# Generated at 2022-06-24 09:52:25.721976
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    from sys import version_info
    from pytest import raises

    from .utils import closing, IS_PYPY
    from .tqdm import tqdm

    for x in product(range(4), range(4), range(4),
                     tqdm_class=tqdm,
                     disable=IS_PYPY or (version_info.major == 3 and
                                         version_info.minor == 2)):
        assert x <= (3, 3, 3)

    with closing(tqdm(total=64, leave=False)) as t:
        for x in product(range(4), range(4), range(4), tqdm_class=t):
            assert x <= (3, 3, 3)

    assert t.n == 64

# Generated at 2022-06-24 09:52:28.963529
# Unit test for function product
def test_product():
    """
    Test for function `product`.
    """
    list(product(range(100), range(100), tqdm_class=tqdm_auto))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:52:39.167274
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.std.itertools.product`.
    """
    from ..std import product as tprod
    from itertools import product as iprod
    assert list(tprod(xrange(10), repeat=3)) == list(iprod(xrange(10), repeat=3))
    assert list(tprod(xrange(10))) == list(iprod(xrange(10)))
    assert not list(tprod(xrange(10), total=0, postfix={'foo': 'bar'}))
    from .. import trange
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]

# Generated at 2022-06-24 09:52:46.357468
# Unit test for function product
def test_product():
    from ..utils import FormatBytes
    from .prange import range
    from .nested import nested
    from . import trange
    from .utils import FormatCustomText
    from .desc import desc
    # test input validation
    try:
        for _ in product(range(4), range(5), tqdm_class=None):
            pass
        assert False, "tqdm_class==None should raise a TypeError"
    except TypeError:
        pass
    # test total=None
    try:
        for _ in product(None, None):
            raise Exception
    except TypeError:
        pass
    # test output
    assert list(product(range(2), repeat=2)) == [
        (0, 0),
        (0, 1),
        (1, 0),
        (1, 1),
    ]


# Generated at 2022-06-24 09:52:48.205584
# Unit test for function product
def test_product():
    # For _product()
    for i in product('ABCD', repeat=2):
        print(i)
    print('-' * 10)
    for i in product('ABCD', 'xy'):
        print(i)

# Generated at 2022-06-24 09:52:55.986192
# Unit test for function product
def test_product():
    """
    test_product
    """
    # pylint: disable=unused-variable
    import itertools as it

    assert list(product([1, 2, 3])) == list(it.product([1, 2, 3]))
    assert list(product([1, 2, 3], [4, 5])) == list(it.product([1, 2, 3], [4, 5]))

    from .utils import closing, EmptyContext  # pylint: disable=redefined-outer-name
    from ..utils import EmptyException

    with closing(EmptyContext(EmptyException)) as (__, ctx):
        try:
            for _ in ctx:
                for _ in product([1, 2, 3]):
                    assert False
            assert False
        except EmptyException:
            pass

# Generated at 2022-06-24 09:53:05.356491
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, pretest
    with_setup(pretest)


# Generated at 2022-06-24 09:53:08.320458
# Unit test for function product
def test_product():
    assert list(product(range(5), range(5))) == [(x,y) for x in range(5)
                                                            for y in range(5)]

# Generated at 2022-06-24 09:53:10.025813
# Unit test for function product
def test_product():
    with tqdm_auto(total=2*3*5) as t:
        for _ in product(2, 3, 5):
            t.update()

# Generated at 2022-06-24 09:53:15.574244
# Unit test for function product
def test_product():
    """
    Test function product.
    """
    lst = list(product([1, 2, 3], [4, 5, 6], repeat=2))
    assert lst == list(itertools.product([1, 2, 3], [4, 5, 6], repeat=2))

# Generated at 2022-06-24 09:53:21.961516
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    vals = list(product(range(3), range(3)))
    assert vals == [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]
    vals = list(product([], range(3)))
    assert vals == []
    vals = list(product(range(3), []))
    assert vals == []

# Generated at 2022-06-24 09:53:33.286970
# Unit test for function product
def test_product():
    """Test function `product`"""
    num_runs = 1000
    import numpy as np
    np.random.seed(0)
    for i in product(range(num_runs), tqdm_class=tqdm_auto):
        assert i == 0
    for i in product(range(num_runs), tqdm_class=tqdm_auto, total=num_runs):
        assert i == 0
    assert len(list(product(range(10), range(num_runs)))) == num_runs
    assert len(list(product(range(10), range(num_runs - 1), range(num_runs - 2)))) == (num_runs - 2) * num_runs * 10

# Generated at 2022-06-24 09:53:42.547838
# Unit test for function product
def test_product():
    """
    Test for ``product`` and ``.n``
    """
    from ..utils import n_samples_powerlaw

    def func():
        for _ in product(range(1), range(1), range(100)):
            pass

    for tqdm_class_ in [tqdm_auto, tqdm]:
        for s in n_samples_powerlaw(1, 2000, 3,
                                    max_exp=10):
            func.n_samples = [s]
            d = tqdm_class_(func)
            func()
            assert d.n == s

# Benchmark for function product

# Generated at 2022-06-24 09:53:50.457670
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import FormatCustomText
    from ..std import unicode as u
    from ..std import unittest

    # Test basic function
    with tqdm_auto(
            total=7, leave=False,
            unit_scale=True, unit="B",
            desc=u("\u0394"),
            miniters=1, mininterval=0, smoothing=0) as bar:
        for t in product(range(7), bar=bar):
            bar.update()
        assert bar.n == 7

    # Test non-tqdm output
    assert list(product([0, 1], [0, 1], [0, 1])) == list(
        itertools.product([0, 1], [0, 1], [0, 1]))

   

# Generated at 2022-06-24 09:54:01.540391
# Unit test for function product
def test_product():
    import numpy as np
    from scipy.sparse import coo_matrix

    arr = [np.arange(i) for i in (1, 2, 3, 4)]
    prod = product(*arr)
    prod_arr = list(prod)
    assert prod_arr == list(itertools.product(*arr))
    assert prod.total == len(prod_arr)
    assert prod.n != 1  # n=1 breaks the tqdm.__enter__() logic
    assert prod.dynamic_ncols()  # check that autodetection works

    # check sparsity autodetection in nested iterables
    arr_o = np.array([0, 1, 1, 1, 0], dtype=object)

# Generated at 2022-06-24 09:54:10.345458
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # pylint: disable=protected-access
    import sys
    import re
    import os
    import textwrap
    import doctest

    def _get_tqdm_titles(t, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}"):
        """
        Helper function to get the list of titles of all bars in `t`.
        """
        # pylint: disable=protected-access
        return [re.sub("[\r\n].*", "", bar.format_dict["desc"]) for bar in t._instances]

    def _get_tqdm_bar(t):
        """
        Helper function to get the first bar of `t`.
        """
        # pylint: disable=protected-

# Generated at 2022-06-24 09:54:16.966947
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import pandas as pd
    import tqdm
    import numpy as np
    from ..utils import format_sizeof


# Generated at 2022-06-24 09:54:26.048238
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # In all the following examples, product(A,B) is equivalent to:
    # ((x,y) for x in A for y in B).

    from .utils import GzipFile
    try:
        from itertools import permutations
    except ImportError:
        pass

    result = []
    for i in product('ABC', repeat=2):
        result.append(i)
    assert result == [('A', 'A'),('A', 'B'),('A', 'C'),
                      ('B', 'A'),('B', 'B'),('B', 'C'),
                      ('C', 'A'),('C', 'B'),('C', 'C')]

    result = []
    for i in product('ABC', 'xy'):
        result.append(i)

# Generated at 2022-06-24 09:54:30.948493
# Unit test for function product
def test_product():
    p = product(list(range(5)), list(range(5)), list(range(5)),
                tqdm_class=None)
    assert list(p) == list(itertools.product(
        list(range(5)), list(range(5)), list(range(5))))

# Generated at 2022-06-24 09:54:40.659731
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert list(product([1, 2, 3], ['a', 'b'])) == [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]
    assert list(product([1, 2, 3], ['a', 'b'], total=3)) == [(1, 'a'), (1, 'b'), (2, 'a')]
    assert list(product([1, 2, 3], ['a', 'b'], tqdm_class=tqdm_auto.tqdm_gui)) == [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]

# Generated at 2022-06-24 09:54:44.499898
# Unit test for function product
def test_product():
    """Test to make sure that range is evaluated lazily (see #65)"""

    @product
    def foo():
        return range(5)

    foo.update(5)
    foo.close()

    # Make sure tqdm.update() works even with manual iteration
    for i in foo:
        pass

# Generated at 2022-06-24 09:54:47.433655
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], repeat=3)) == list(
        itertools.product([1, 2, 3], repeat=3))


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:54:49.704071
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np
    assert np.all(
        list(product(range(5), [0, 1])) ==
        list(itertools.product(range(5), [0, 1])))

# Generated at 2022-06-24 09:55:00.677119
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import format_sizeof
    from six.moves import xrange
    try:
        from numpy import arange
    except ImportError:
        arange = xrange
    size = 2**10
    try:
        product(arange(size), total=size, tqdm_class=tqdm_auto)
        product(arange(size, 0, -1), total=size, tqdm_class=tqdm_auto)
        assert (True)
    except Exception:
        print('product() test failed!')

# Generated at 2022-06-24 09:55:06.671475
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText, format_sizeof
    for _ in product([1, 2],
                     ['a', 'b', 'c'],
                     bar_format=FormatCustomText(**dict(
                         item_show="{desc}",
                         desc="{per_second}{postfix}".format(
                             per_second="{per_second:7.1f}",
                             postfix="/s{desc}")))):
        pass


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:55:17.817268
# Unit test for function product
def test_product():
    """
    Tests function `itertools.product`.
    """
    res = product(range(2), range(2), range(2))
    assert next(res) == (0, 0, 0)
    assert next(res) == (0, 0, 1)
    assert next(res) == (0, 1, 0)
    assert next(res) == (0, 1, 1)
    assert next(res) == (1, 0, 0)
    assert next(res) == (1, 0, 1)
    assert next(res) == (1, 1, 0)
    assert next(res) == (1, 1, 1)

    res = product(range(2), range(2), range(2), tqdm_class=tqdm_auto)
    assert next(res) == (0, 0, 0)

# Generated at 2022-06-24 09:55:24.766270
# Unit test for function product
def test_product():
    """
    test_product()
    """
    from ..nested import tqdm
    # Unit test for function product
    for X, Y, i in product(tqdm([1, 2, 3]), tqdm(["a", "b", "c"]),
                           tqdm(["A", "B", "C", "D"], leave=False)):
        pass
    for X, Y, i in product(tqdm([1, 2, 3], leave=False),
                           tqdm(["a", "b", "c"], leave=False),
                           tqdm(["A", "B", "C", "D"], leave=False)):
        pass

# Generated at 2022-06-24 09:55:27.892455
# Unit test for function product
def test_product():
    """Test product iterator"""
    def _():
        for _ in product(*[[0, 2, 5], [2, 3], [3, 5]]):
            pass
    _()
    def _():
        for _ in product(*[[0, 2, 5], [2, 3], [3, 5]],
                         tqdm_class=tqdm_auto):
            pass
    _()

# Generated at 2022-06-24 09:55:36.924094
# Unit test for function product
def test_product():
    """
    Unit test for product().
    """
    from ..utils import SafeExitStack
    from ..tests import closing, closing_to_thread
    from .._tqdm_gui import _version_warning
    with closing(SafeExitStack()) as stack:
        i = stack.enter_context(_version_warning(None))
        with closing_to_thread(i, stack):
            # Test key argument 'tqdm_class'
            from tqdm.auto import tqdm
            assert len(list(product(range(5), repeat=2, tqdm_class=tqdm))) \
                == 5**2


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:55:40.475770
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..tests.test_utils import tqdm_test
    tqdm_test(product(range(10), range(10), range(10), tqdm_class=tqdm_auto))

# Generated at 2022-06-24 09:55:48.579623
# Unit test for function product
def test_product():
    from .utils import TestReporter
    import random
    import string
    from .utils import Decimal

    def _():
        for _ in product([1, 2, 3, 4],
                         ['a', 'b', 'c', 'd'],
                         ['#' + random.choice(string.digits)
                          for _ in range(4)],
                         tqdm_class=TestReporter):
            pass

    class TestProduct(TestReporter):
        def __init__(self, *args, **kwargs):
            kwargs['leave'] = kwargs.get('leave', False)
            self.i = 0
            self.total = Decimal(24)
            super(TestProduct, self).__init__(*args, **kwargs)


# Generated at 2022-06-24 09:55:57.953499
# Unit test for function product
def test_product():
    from . import __file__ as loc
    import os
    import sys
    print('\n** Testing {} **'.format(os.path.basename(__file__)),
          file=sys.stderr)
    A = range(15)
    B = range(20)
    C = range(18)
    p = product(A, B, C, tqdm_class=tqdm_auto)
    next(p)
    p.n = 0
    for a in A:
        for b in B:
            for c in C:
                assert (a, b, c) == next(p)
    try:
        next(p)
    except StopIteration:
        print("\033[92m* Pass\033[0m", file=sys.stderr)

# Generated at 2022-06-24 09:56:05.184362
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    from pyprind.prog_class import Prog
    from pyprind.prog_class import ProgPercent
    from pyprind.prog_class import ProgBar
    from pyprind.prog_class import ProgPercentage
    from pyprind.prog_class import ProgLog
    from pyprind.prog_class import ProgNotebook
    from pyprind.prog_class import ProgUpdate
    from pyprind.prog_class import ProgIter


# Generated at 2022-06-24 09:56:11.504128
# Unit test for function product
def test_product():
    from .tests import test_utils
    assert(test_utils.eval_iter_subset([(1, 2, 3), ('a', 'b', 'c')],
                                       [1, 'a'],
                                       list(product([1, 2, 3], ['a', 'b', 'c']))))

# Generated at 2022-06-24 09:56:20.976079
# Unit test for function product
def test_product():
    """Test function product()"""
    from ..utils import _range
    assert list(product(['a', 'b'])) == list(itertools.product(['a', 'b']))
    assert list(product(['a', 'b'], repeat=2)) == \
        list(itertools.product(['a', 'b'], repeat=2))
    assert list(product(_range(3), _range(4), _range(5))) == \
        list(itertools.product(_range(3), _range(4), _range(5)))
    from ..contrib.concurrent import thread_map
    assert list(product(thread_map(_range, [10, 20, 30]))) == \
        list(itertools.product(_range(10), _range(20), _range(30)))



# Generated at 2022-06-24 09:56:27.332840
# Unit test for function product
def test_product():
    from numpy.random import randint
    for iterables in [
            range(4),
            [randint(10, 30, 10),
             randint(20, 50, 10),
             randint(30, 80, 10)]]:
        try:
            p = product(*iterables, total=None)
        except TypeError as e:
            assert "total" not in str(e)
            p = product(*iterables)
        res = []
        for i in p:
            res.append(i)
        assert list(itertools.product(*iterables)) == res

# Generated at 2022-06-24 09:56:36.517761
# Unit test for function product
def test_product():
    import numpy as np
    for r in range(4):
        for i in product(*[range(10)] * r):
            pass
        for i in product(*[range(100)] * r):
            pass
        for i in product(*[range(1000)] * r):
            pass
        for i in product(*[range(10)] * r, tqdm_class=tqdm_auto):
            pass
        for i in product(*[range(100)] * r, tqdm_class=tqdm_auto):
            pass
        for i in product(*[range(1000)] * r, tqdm_class=tqdm_auto):
            pass
        for i in product(*[np.arange(10)] * r, tqdm_class=tqdm_auto):
            pass

# Generated at 2022-06-24 09:56:46.777015
# Unit test for function product
def test_product():
    try:
        from nose.tools import assert_equal as _assert_equal
    except ImportError:
        from .utils import assert_equal as _assert_equal
    from .utils import MockIO, StringIO

    def _test(iterable, expect, total=None, **tqdm_kwargs):
        expect = list(expect)
        niter = 0
        with MockIO(StringIO()) as mock:
            with tqdm_kwargs.pop("tqdm_class", tqdm_auto)(
                                iterable, total=total, **tqdm_kwargs) as t:
                for i in t:
                    niter += 1
                    _assert_equal(i, expect.pop(0))

# Generated at 2022-06-24 09:56:54.541041
# Unit test for function product
def test_product():
    from .utils import _range

    assert list(product([1, 2], _range(3))) == list(itertools.product([1, 2], _range(3)))


# To allow `from itertools import *` without side-effects (test_product)
itertools_ls = locals().keys()
for _it in dir(itertools):
    if _it.startswith('_') or _it in itertools_ls:
        continue
    locals()[_it] = getattr(itertools, _it)
del itertools
del tqdm_auto
del tqdm_kwargs
del itertools_ls
del _it

# Generated at 2022-06-24 09:57:05.958253
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`.
    """
    try:
        import numpy
    except ImportError:
        return None
    from numpy.random import randint
    from numpy.testing import assert_equal
    from ..std import itertools as it

    tqdm_it = product(range(5), range(6), range(7),
                      tqdm_class=tqdm_auto)
    assert_equal(list(it.product(range(5), range(6), range(7))),
                 list(tqdm_it))
    X = randint(0, 9, (100, 100))
    assert_equal(list(it.product(*X)),
                 list(product(*X, tqdm_class=tqdm_auto)))

# Generated at 2022-06-24 09:57:11.778207
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import re
    import tempfile
    from ..utils import _range

    with tempfile.TemporaryFile("w+") as tmp:
        with tqdm_auto(range(3)) as t:
            for i in product(range(3), range(3), tqdm_class=tqdm_auto):
                assert i == (t.n, 0, 0)
                tmp.write("{0}\n".format(i))

        with tqdm_auto(range(3)) as t:
            for i in _range(3) | tqdm_auto | product(range(3), range(3)):
                assert i == (t.n, 0, 0)
                tmp.write("{0}\n".format(i))


# Generated at 2022-06-24 09:57:16.074839
# Unit test for function product
def test_product():
    """Tests whether product is correct."""
    x = []
    for i in product("ABC", [1, 2]):
        x.append(i)
    assert x == [("A", 1), ("A", 2), ("B", 1), ("B", 2), ("C", 1), ("C", 2)]

# Generated at 2022-06-24 09:57:20.360395
# Unit test for function product
def test_product():
    """
    Tests `itertools.product` wrapper.
    """
    import sys

    class MockTqdmFile(object):
        """
        Mock file-like object that will write to `fp_write` instead of a
        file.
        """
        encoding = "utf-8"

        def __init__(self, fp_write):
            self.fp_write = fp_write

        def write(self, x):
            self.fp_write(x)

    expected_output = "2it [00:00, ?it/s]"

    f = sys.stderr if sys.version_info[0] >= 3 else sys.stderr

# Generated at 2022-06-24 09:57:31.544892
# Unit test for function product
def test_product():
    """
    Unit test for function product

    Note: the docstring above is used as the test.
    """
    import numpy as np
    assert list(product(range(5), [], range(3, 4))) == []
    assert list(product(range(1), [], range(3, 4))) == []
    assert list(product('ABC', 'xy')) == list(itertools.product('ABC', 'xy'))
    assert list(product('ABC', 'xy', repeat=2)) == \
        list(itertools.product('ABC', 'xy', repeat=2))
    assert list(product(range(10), repeat=3)) == \
        list(itertools.product(range(10), repeat=3))

# Generated at 2022-06-24 09:57:40.991142
# Unit test for function product
def test_product():
    """Test that itertools.product is wrapped properly"""
    assert list(product('ABC', '12', tqdm_class=tqdm_auto)) == \
        list(itertools.product('ABC', '12'))
    assert list(product('ABC', '12', tqdm_class=tqdm_auto, total=3)) == \
        list(itertools.product('ABC', '12'))
    # Test total override
    assert list(product('ABCDE', repeat=2,
                        tqdm_class=tqdm_auto, total=12)) == \
        list(itertools.product('ABCDE', repeat=2))

# Generated at 2022-06-24 09:57:51.877677
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from .tests_tqdm import with_setup, StringIO

    try:
        from collections import OrderedDict
    except ImportError:
        from .tests_tqdm import OrderedDict

    @with_setup(pretest=lambda: None, posttest=lambda: None)
    def test(exp, **kwargs):
        out = StringIO()
        for _ in product("ABC", "AB", tqdm_class=lambda iterable: iterable,
                         file=out, **kwargs):
            pass
        out = out.getvalue().replace('\n', ' ')
        assert out.startswith("["), out
        assert out.strip().endswith("]"), out

# Generated at 2022-06-24 09:57:57.153626
# Unit test for function product
def test_product():
    """
    Test that product yields the right result
    """
    assert list(product(['a', 'b'], [1, 2])) == \
        list(itertools.product(['a', 'b'], [1, 2]))
    assert list(product(['a', 'b'], [1, 2], tqdm_class=None)) == \
        list(itertools.product(['a', 'b'], [1, 2]))

# Generated at 2022-06-24 09:58:03.847983
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from ..tests import get_macro_test_tqdm

    macrotest = get_macro_test_tqdm(product)

    for cls in macrotest:
        for t in (range, iter):
            with cls(total=5) as pbar:
                assert pbar.total == 5
                for i in product(t(3), t(5), t(7), tqdm_class=cls,
                                 ascii=True, bar_format="{l_bar}"):
                    pbar.update()
                    assert pbar.n == pbar.last_print_n
                    assert pbar.n == i[0] * i[1] * i[2]
                assert pbar.n == 105
                assert pbar.n == pbar.last_

# Generated at 2022-06-24 09:58:07.447038
# Unit test for function product
def test_product():
    assert list(product(range(10),
                        range(10, 15),
                        bar_format=None,
                        tqdm_class=tqdm_auto)) == list(itertools.product(range(10), range(10, 15)))

# Generated at 2022-06-24 09:58:12.144903
# Unit test for function product
def test_product():
    import numpy as np
    assert np.allclose(
        np.array([i for i in product(
            range(10), range(10), range(10), tqdm_class=None)]),
        np.array([i for i in itertools.product(range(10), range(10),
                                               range(10))]))

# Generated at 2022-06-24 09:58:18.716047
# Unit test for function product
def test_product():
    """Test: test_product"""
    import sys
    import time
    from .utils import closing
    from .tqdm_gui import tqdm
    from .tqdm import trange

    for t in [trange, tqdm]:
        with closing(t(total=5)) as pbar:
            for i in product('abcd', 'xyz', '0123', tqdm=t):
                time.sleep(0.01)
                pbar.update()

    # Test with generator

# Generated at 2022-06-24 09:58:27.459168
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from six.moves import range

    assert list(product(range(3), range(3), range(3))) == \
        list(itertools.product(range(3), range(3), range(3)))
    assert list(zip(product(range(3), range(3), range(3)),
                    itertools.product(range(3), range(3), range(3)))) == \
        list(zip(product(range(3), range(3), range(3)),
                 itertools.product(range(3), range(3), range(3))))

# Generated at 2022-06-24 09:58:36.295845
# Unit test for function product
def test_product():
    '''
    unit test for `product`
    '''
    from ..utils import format_sizeof
    from ..tests import TEST_ITERABLES

    for iterable1 in TEST_ITERABLES.values():
        for iterable2 in TEST_ITERABLES.values():
            for iterable3 in TEST_ITERABLES.values():
                for iterable4 in TEST_ITERABLES.values():
                    for iterable5 in TEST_ITERABLES.values():
                        t = list(product(iterable1, iterable2, iterable3,
                                         iterable4, iterable5))
                        assert len(t) == len(list(itertools.product(
                            iterable1, iterable2, iterable3, iterable4,
                            iterable5)))
                        assert format_sizeof

# Generated at 2022-06-24 09:58:39.110533
# Unit test for function product
def test_product():
    from ..tests import test_itertools, test_unit
    list(product(range(10), tqdm_class=test_itertools.TqdmClass))
    list(product(range(10), tqdm_class=test_unit.DummyTqdmFile))

# Generated at 2022-06-24 09:58:42.254732
# Unit test for function product
def test_product():
    """
    Tests function `product`
    """
    s = '1234567890'
    t = 'abcdefghij'
    for _ in product(s, t):
        pass

# Generated at 2022-06-24 09:58:48.351265
# Unit test for function product
def test_product():
    q = []
    x = product(range(5), range(5), tqdm_class=tqdm_auto, ascii=True)
    for i in x:
        q.append(i)

    assert q[0] == (0, 0)
    assert q[-1] == (4, 4)

    q = []
    x = product(range(5), range(5), tqdm_class=tqdm_auto, ascii=False)
    for i in x:
        q.append(i)

    assert q[0] == (0, 0)
    assert q[-1] == (4, 4)