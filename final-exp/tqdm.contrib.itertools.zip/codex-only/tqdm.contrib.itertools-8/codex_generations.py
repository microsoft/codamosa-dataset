

# Generated at 2022-06-24 09:48:50.306451
# Unit test for function product
def test_product():
    '''
    Check that iterating over itertools.product and tqdm.product
    is identical
    '''
    for i in itertools.product(range(3), range(3)):
        pass
    for i in product(range(3), range(3)):
        pass

# Generated at 2022-06-24 09:48:58.578790
# Unit test for function product
def test_product():
    import sys
    if sys.version_info < (3, 0):
        from io import BytesIO as IOBase
    else:
        from io import StringIO as IOBase

    from ..auto import tqdm_gui
    from ..utils import _range

    for kwargs in [dict(),
                   dict(tqdm_class=tqdm_gui),
                   dict(tqdm_class=tqdm_gui, mininterval=0)]:
        for t in ['', '\r', 'foo']:
            for out in (sys.stderr, IOBase()):
                with tqdm_gui(**kwargs) as tq:
                    string = tq.write(t)
                try:
                    string = string.decode('utf-8')
                except AttributeError:
                    pass

# Generated at 2022-06-24 09:48:59.649492
# Unit test for function product
def test_product():
    for _ in product(range(4), repeat=4, tqdm_class=None):
        pass

# Generated at 2022-06-24 09:49:05.153514
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from .utils import BaseTestUpdater
    # numpy dtype not tested in itertools.product unit tests
    class TestUpdater(BaseTestUpdater):
        def ncols(self):
            return len(self.nms)
        def __init__(self, *args, **kwargs):
            super(TestUpdater, self).__init__(*args, **kwargs)
            self.nms = []
        def desc(self, nm):
            self.nms.append(nm)
        def postprocess(self, out):
            return out, self.nms

# Generated at 2022-06-24 09:49:11.320979
# Unit test for function product
def test_product():
    from numpy import array
    from numpy.testing import assert_array_equal
    from .utils import FakeTqdmFile

    with FakeTqdmFile() as f:
        list(product(range(2), range(5), range(10), tqdm_class=tqdm_auto,
                     file=f))
    f.seek(0)
    assert "50it" in f.readline()

    a = product([2], [5], [10])
    b = array(list(a))
    assert_array_equal(b, array(list(itertools.product([2], [5], [10]))))

# Generated at 2022-06-24 09:49:21.608659
# Unit test for function product
def test_product():
    from tqdm import tqdm
    from numpy.testing import assert_allclose

    values = list(product(range(5), range(5),
                          tqdm_class=tqdm,
                          desc=''))
    assert_allclose(values, list(itertools.product(range(5), range(5))))

    values = list(product(range(6), repeat=2,
                          tqdm_class=tqdm))
    assert_allclose(values, list(itertools.product(range(6), repeat=2)))

    values = list(product(range(6), repeat=3,
                          tqdm_class=tqdm))
    assert_allclose(values, list(itertools.product(range(6), repeat=3)))

# Generated at 2022-06-24 09:49:32.387236
# Unit test for function product
def test_product():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    # Reference itertools product implementation
    def product_itertools(iterables, tqdm_class=tqdm_auto, **tqdm_kwargs):
        kwargs = tqdm_kwargs.copy()
        try:
            lens = list(map(len, iterables))
        except TypeError:
            total = None
        else:
            total = 1
            for i in lens:
                total *= i
            kwargs.setdefault("total", total)
        with tqdm_class(**kwargs) as t:
            for i in itertools.product(*iterables):
                yield i
                t.update()

    # Test to ensure consistent behaviour with itertools
    assert list

# Generated at 2022-06-24 09:49:37.009335
# Unit test for function product
def test_product():
    from pytest import approx
    from . import trange

    for t in map(trange, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 100], ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10']):
        for i in product(t, [5, 6, 7, 8, 9]):
            assert i == approx(i)

# Generated at 2022-06-24 09:49:42.079586
# Unit test for function product
def test_product():
    """
    Test for `itertools.product` wrapper
    """
    from .tqdm_examples import example_itertools

    for kwarg in [dict(), dict(tqdm_class=tqdm_auto)]:
        assert (list(product(*example_itertools, **kwarg))
                == list(itertools.product(*example_itertools)))

# Generated at 2022-06-24 09:49:51.818643
# Unit test for function product
def test_product():
    from .._tqdm import tqdm, trange, TqdmTypeError

    with trange(10) as t:
        assert len(list(t)) == 10

    with trange(10, desc='desc', leave=True) as t:
        assert list(t) == list(range(10))

    with trange(10, total=15, desc='desc', leave=True) as t:
        assert t.total == 15
        assert list(t) == list(range(10))

    with tqdm(10) as t:
        assert len(list(t)) == 10


# Generated at 2022-06-24 09:50:00.422126
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import format_sizeof
    from .utils import format_interval
    from . import trange

    N = 500
    M = 20000

    x = np.random.random(N)
    y = np.random.random(M)

    f = product(x, y)
    if hasattr(f, "__len__"):
        assert len(f) == N * M
    assert len(list(f)) == N * M

    # Test dynamic total
    f = product(x, y)
    f.__len__ = None  # remove __len__
    assert len(list(f)) == N * M

    # Test that wrapping a generator that is already wrapped works
    f = product(x, y, tqdm_class=trange)

# Generated at 2022-06-24 09:50:09.518419
# Unit test for function product
def test_product():
    """
    Example usage:
    --------------
    >>> test_product()
    100%|██████████| 6/6 [00:00<00:00, ?it/s]
    True

    See Also
    --------
    itertools.product : Base iterator.
    """
    tqdm_kwargs = dict(
        tqdm_class=tqdm_auto,
        leave=False)
    iterables = list('ABC'), range(3), "abcd"
    l1 = set(product(*iterables, **tqdm_kwargs))
    l2 = set(itertools.product(*iterables))
    return l1 == l2

# Generated at 2022-06-24 09:50:19.230571
# Unit test for function product
def test_product():
    "Test products of iterables"
    from nose.tools import eq_ as eq, assert_raises

    assert_raises(TypeError, lambda: list(product()))
    assert_raises(TypeError, lambda: list(product(1)))
    assert_raises(TypeError, lambda: list(product(1, 2, tqdm_class=None)))
    eq(list(product(['a', 'b'], repeat=1)),
       list(product('ab', repeat=1)))
    eq(list(product(['a', 'b'], repeat=0)), [])
    eq(list(product(['a', 'b'], repeat=2)),
       list(product('ab', repeat=2)))

# Generated at 2022-06-24 09:50:27.930216
# Unit test for function product
def test_product():
    from random import seed, shuffle
    from ..utils import format_sizeof
    from . import trange
    pbar = trange(0, 0, desc="test_product")
    pbar.update(0)
    for i in product(
        range(3),
        ['a', 'b', 'c'],
        ["d", 'e', 'f'],
        tqdm_class=pbar.__class__,
        leave=False
    ):
        print(i)
    pbar.update(1)


# Generated at 2022-06-24 09:50:37.827287
# Unit test for function product
def test_product():
    from ._utils import _range
    from ._utils import format_sizeof
    from ._tqdm_gui import tqdm
    from ._tqdm import trange
    from ._tqdm import _version
    from ._tqdm_gui import version
    from ._tqdm import tqdm_pandas
    from ._tqdm import main as tqdm_main
    from ._tqdm import tgrange
    from ._tqdm import TqdmExtensionWarning
    from ._tqdm import TqdmExperimentalWarning
    from ._tqdm import tqdm_notebook
    from ._tqdm import TqdmDeprecationWarning
    from ._pandas_tqdm import tqdm_pandas
    from ._monitor import TMonitor
    from ._main import main


# Generated at 2022-06-24 09:50:47.926015
# Unit test for function product
def test_product():
    from .utils import in_examples_dir

    assert in_examples_dir()

    from .test_tqdm_gui import test_cls
    from .tqdm_gui import tqdm

    for _ in test_cls(lambda: product(iterable=range(10), tqdm_class=tqdm)):
        pass
    for _ in test_cls(lambda: product(
            *([range(100), range(100), range(100), range(100), range(100),
               range(100), range(100), range(100), range(100), range(100)] +
              [range(100) for i in range(100)]),
            tqdm_class=tqdm)):
        pass

# Generated at 2022-06-24 09:50:50.941674
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    x = list(product(range(10)))
    y = [x for x in product(range(10), tqdm_class=tqdm_auto.tqdm)]

# Generated at 2022-06-24 09:51:00.651066
# Unit test for function product
def test_product():
    """Test for function product."""
    from .utils import TestTQDM
    from .itertools_examples import examples
    from .itertools_examples import DummyClass
    for exp in examples:
        with TestTQDM(**exp.get("kwargs", {})) as t:
            for obj in product(*exp["inputs"], **exp.get("kwargs", {})):
                t.update()
                pass
        with TestTQDM(**exp.get("kwargs", {})) as t:
            for obj in product(*exp["inputs"],
                               tqdm_class=DummyClass,
                               **exp.get("kwargs", {})):
                t.update()
                pass
        assert t.n == exp["loop"]

# Generated at 2022-06-24 09:51:01.933213
# Unit test for function product
def test_product():
    from .tests import product_test
    product_test(product)

# Generated at 2022-06-24 09:51:08.818210
# Unit test for function product
def test_product():
    from .main import _range

    for tqdm in [tqdm_auto]:
        for i, j in product(_range(100), _range(100),
                            total=10000,
                            tqdm_class=tqdm):
            assert i * 100 + j < 10000

    for tqdm in [tqdm_auto]:
        for i, j in product(_range(100), _range(100),
                            total=None,
                            tqdm_class=tqdm):
            assert i * 100 + j < 10000


# Generated at 2022-06-24 09:51:17.334398
# Unit test for function product
def test_product():
    """
    Test function `tqdm.itertools.product`
    """
    iterables = [range(100), range(100), range(100), range(100)]
    # Test no tqdm_class
    p = product(*iterables)
    assert next(p) == (0, 0, 0, 0)
    assert len(list(p)) == 100 ** 4 - 1
    # Test with tqdm
    from ..std import tqdm
    p = product(*iterables, tqdm_class=tqdm)
    assert next(p) == (0, 0, 0, 0)
    assert len(list(p)) == 100 ** 4 - 1
    # Test with default class
    p = product(*iterables)
    assert next(p) == (0, 0, 0, 0)

# Generated at 2022-06-24 09:51:42.438993
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..std import list_std
    for a in list_std([range(10), range(10)]):
        assert a == (0, 0)
        break
    else:
        raise AssertionError()
    for a in list_std([range(10), range(10)]):
        assert a == (9, 9)
        break
    else:
        raise AssertionError()
    try:
        for a in product(range(10), range(10), tqdm_class=None):
            raise AssertionError()
    except TypeError:
        pass
    for a in product(range(10), range(10), tqdm_class=tqdm_auto):
        assert a == (0, 0)
        break
    else:
        raise Ass

# Generated at 2022-06-24 09:51:49.075749
# Unit test for function product
def test_product():
    from .itertools import _range
    from .numpy import array
    from .dataframe import DataFrame

    # 1. Test iteration by itertools.product
    with_itertools = list(itertools.product(
        _range(3),
        _range(3),
    ))
    with_tqdm = list(product(
        _range(3),
        _range(3),
    ))
    assert with_itertools == with_tqdm

    # 2. Test iteration with progress bars
    with_tqdm = list(product(
        _range(3),
        _range(3),
    ))
    assert with_itertools == with_tqdm

    # 3. Test with multi-variables

# Generated at 2022-06-24 09:51:59.368721
# Unit test for function product
def test_product():
    from .tests import TestCase, closing

    with closing(TestCase()) as t:
        for a in product('ABCD', 'xy', tqdm_class=t.cls):
            t.assertTrue(a in (('A', 'x'), ('A', 'y'), ('B', 'x'), ('B',
                               'y'), ('C', 'x'), ('C', 'y'), ('D', 'x'),
                               ('D', 'y')))
        t.assertEqual(len(t.values), 8)


# Generated at 2022-06-24 09:52:05.707331
# Unit test for function product
def test_product():
    from .utils import FormatMixin
    from .utils import StringIO

    class TqdmTypeError(FormatMixin, TypeError):
        pass

    class Test(object):
        """
        Test class that checks iterations are executed and the progressbar
        is updated.
        """
        def __init__(self, iterable):
            self.iterable = iterable

        def __enter__(self, *args, **kwargs):
            self.iter_count = 0
            self.prgbar_updt_count = 0
            return self

        def __exit__(self, *args, **kwargs):
            pass

        def __iter__(self):
            for value in self.iterable:
                self.iter_count += 1
                yield value

        def update(self, n=1):
            self.prgbar

# Generated at 2022-06-24 09:52:10.708417
# Unit test for function product
def test_product():
    from . import trange, TMonitor

    iterables = [range(i) for i in range(1, 5)]
    with trange(10, monitor=TMonitor()) as t:
        for _ in product(*iterables, tqdm_class=t.__class__):
            pass
    assert t.total == 5 * 6 * 7 * 8
    assert t.n == t.total

# Generated at 2022-06-24 09:52:20.754245
# Unit test for function product
def test_product():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_stdout():
        old = sys.stdout
        capturer = io.StringIO()
        sys.stdout = capturer
        yield capturer
        sys.stdout = old

    with capture_stdout() as output:
        for _ in product(range(5), bar_format="{postfix[0]},{postfix[1]}"):
            pass

    assert output.getvalue() == "[0/5,0/5,]\n[0/5,1/5,]\n[0/5,2/5,]\n[0/5,3/5,]\n[0/5,4/5,]\n"
    " ".join(output.getvalue()) + "\n"

# Generated at 2022-06-24 09:52:25.238953
# Unit test for function product
def test_product():
    """
    Test function product
    """
    iterables = [['abc', 'def'], [2, 3, 4], [1, 2, 3, 4]]
    res_list = list(product(*iterables, tqdm_class=None))

    assert(res_list == list(itertools.product(*iterables)))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:52:35.786122
# Unit test for function product
def test_product():
    import random
    import sys

    import pytest

    from ..utils import FormatCustomTextExt, FormatCustomTextTotal
    from ..utils import FormatSIBase
    from ..utils import FormatStd
    from ..utils import format_sizeof

    for n in range(20):
        for i in product(range(10), repeat=n):
            pass


# Generated at 2022-06-24 09:52:38.993778
# Unit test for function product
def test_product():
    """
    Check if success > 0
    """
    from tqdm import tqdm
    print(list(product(range(10), repeat=3)))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:52:46.333249
# Unit test for function product
def test_product():
    """Test product"""
    import numpy as np
    from ..utils import format_sizeof

    size_of_int = np.array([], dtype=np.int8).itemsize * 8
    int_max = 2 ** (size_of_int - 1) - 1
    int_min = -int_max - 1

    # TODO: define a more systematic test of the dynamic range

    for rng in [3, 7, int_max / 2, int_max - 6, int_min / 2, int_min + 7]:
        for n in range(6):
            for i in product(range(rng), repeat=n):
                assert len(i) == n
                assert min(i) >= 0
                assert max(i) < rng
                # TODO: check contents

    # Test empty iter:

# Generated at 2022-06-24 09:52:48.291020
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], [4, 5, 6])) == \
        [i for i in itertools.product([1, 2, 3], [4, 5, 6])]

# Generated at 2022-06-24 09:52:56.434047
# Unit test for function product
def test_product():
    import sys
    from random import randint
    for _ in product(range(1), range(1), range(1)):
        pass
    for _ in product(range(int(sys.float_info.max)), ("", "a", "b")):
        pass
    for _ in product(range(randint(1, 9)), range(randint(1, 9))):
        pass
    for _ in product(range(randint(1, 9)), range(randint(1, 9)),
                     range(randint(1, 9))):
        pass
    for _ in product(range(randint(1, 9)), range(randint(1, 9)),
                     range(randint(1, 9)), range(randint(1, 9))):
        pass


# Generated at 2022-06-24 09:53:03.337463
# Unit test for function product
def test_product():
    from .utils import closing_disabled
    list(product([1, 2], repeat=4))
    list(product([1, 2], repeat=4, tqdm_class=closing_disabled))

# Generated at 2022-06-24 09:53:14.026100
# Unit test for function product
def test_product():
    from ._utils import closing, test_closed
    from ._tqdm_test_cls import T
    with closing(T()) as t:
        assert t.disable == 0
        assert test_closed(type(t), t)

        it = product(range(10), range(10), tqdm_class=T)
        assert isinstance(it, T)
        assert test_closed(T, it)

        assert list(it) == list(itertools.product(range(10), range(10)))
        assert t.disable == 1

        assert it.disable == 1
        assert list(it) == []

# Generated at 2022-06-24 09:53:23.536479
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    try:
        import numpy as np
    except ImportError:  # pragma: no cover
        return
    a = list(range(3))
    b = np.array(list("abc"))
    c = np.zeros(10)
    d = [np.nan]

# Generated at 2022-06-24 09:53:34.160823
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Bit messy, but testing everything that can go wrong:
    # - get_instances
    # - total
    # - no term_size
    # - no total
    # - wrap
    # - list

# Generated at 2022-06-24 09:53:44.955524
# Unit test for function product
def test_product():
    # pure python
    assert list(product("ABCD", "xy")) == [x + y for x in "ABCD" for y in "xy"]

    # Pure python iterable
    assert list(product("ABCD", repeat=2)) == list(product("ABCD", "ABCD"))

    # Empty iterables
    assert list(product("ABCD", [])) == []
    assert list(product("", "xy")) == []
    assert list(product("", repeat=2)) == []
    assert list(product("", repeat=0)) == []

    # One iterable
    assert list(product("ABCD")) == list("ABCD")

    # Repeated iterable
    assert list(product("ABCD", repeat=3)) == list(product("ABCD", "ABCD", "ABCD"))

# Generated at 2022-06-24 09:53:46.556913
# Unit test for function product
def test_product():
    with tqdm_auto(total=10) as t:
        for _ in product(range(5), range(5), tqdm_class=tqdm_auto):
            pass

# Generated at 2022-06-24 09:53:50.906935
# Unit test for function product
def test_product():
    with tqdm_auto(total=26) as t:
        for i in product('ABC', 'abcdefghi', tqdm_class=None):
            t.update()


# Generated at 2022-06-24 09:53:59.453572
# Unit test for function product
def test_product():
    import numpy as np
    assert sorted(product(range(10), repeat=2)) == \
        list(zip(*np.meshgrid(range(10), range(10))))


# Test for function tqdm_notebook
if __name__ == '__main__':
    from .utils import TestTqdmInternal as TestTqdm

    with TestTqdm(dynamic_ncols=True, disable=False) as clock:
        list(product(range(10), repeat=2))
        list(product(range(100), repeat=2))

# Generated at 2022-06-24 09:54:05.730903
# Unit test for function product
def test_product():
    """
    Unit tests for function product().
    """
    from .tests_tqdm import with_setup, pretest, posttest, _range
    import sys
    pretest()
    old_stderr, sys.stderr = sys.stderr, sys.stdout
    try:
        with_setup(lambda: None, lambda: None)(
            lambda: [
                all(i == (i - 1) * 3 + 1 for i in
                    product(list(_range(3)), list(_range(3)), list(_range(3)))),
            ])()
    finally:
        posttest(old_stderr)

# Generated at 2022-06-24 09:54:11.682240
# Unit test for function product
def test_product():
    for i in product(range(3), range(3), tqdm_class=None):
        pass
    for i in product(range(3), ['a', 'b'], tqdm_class=None):
        pass


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:54:16.386256
# Unit test for function product
def test_product():
    """Test function `product`"""
    with tqdm_auto(total=150) as t:
        for i in product(range(1, 3), range(1, 5), range(1, 9), tqdm_class=tqdm_auto):
            assert i[0] in [1, 2]
            assert i[1] in [1, 2, 3, 4]
            assert i[2] in [1, 2, 3, 4, 5, 6, 7, 8]
            assert i[3] in [1, 2, 3, 4, 5, 6, 7, 8]
            t.update()

# Generated at 2022-06-24 09:54:19.446765
# Unit test for function product
def test_product():
    iterables = [range(10), range(10), range(10)]
    assert sum(1 for _ in product(*iterables)) == len(iterables[0]) * len(iterables[1]) * len(iterables[2])

# Generated at 2022-06-24 09:54:27.898695
# Unit test for function product
def test_product():
    ret = [x for x in product(*[list(range(i)) for i in range(1, 6)])]

# Generated at 2022-06-24 09:54:32.971176
# Unit test for function product
def test_product():
    """Test function `product`"""
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        data = list(product(range(3), range(3), tqdm_class=tqdm_auto))
        assert (list(pd.DataFrame(data, columns=["a", "b"]).sum())
                == [9, 9])

# Generated at 2022-06-24 09:54:35.374443
# Unit test for function product
def test_product():
    """ Test for function product """
    from random import randint
    for _ in product([randint(0, 1) for _ in range(5)]):
        pass

# Generated at 2022-06-24 09:54:42.385197
# Unit test for function product
def test_product():

    # check nested for loop with time control
    for _ in product(range(3), range(3), tqdm_class=tqdm_auto, unit_scale=True):
        pass
    # check nested for loop with different unit_scale
    for _ in product(range(3), range(3), tqdm_class=tqdm_auto, unit_scale=2):
        pass
    # check nested for loop with normal iterator
    for _ in product(range(3), range(3)):
        pass
    # check simple iterator
    for _ in product(range(3)):
        pass

# Generated at 2022-06-24 09:54:48.830080
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from ..std import StdOutCapture
    for tqdm_class in (tqdm_auto, FormatCustomText, StdOutCapture):
        with tqdm_class(
                miniters=1, mininterval=0.01,
                total=None, leave=None) as t:
            for i in product(
                    [1, 2, 3, 4],
                    range(3),
                    ["a", "b", "c"],
                    bar_format='{l_bar}{bar}|',
                    tqdm_class=tqdm_class):
                t.update()
                assert t.position != 0
                assert t.dynamic_mess == "l_bar", t.dynamic_mess


from .. import tqdm
tqdm.pandas = tq

# Generated at 2022-06-24 09:54:55.093468
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product([1, 2, 3], [6, 5], [7])) == [
        (1, 6, 7),
        (2, 6, 7),
        (3, 6, 7),
        (1, 5, 7),
        (2, 5, 7),
        (3, 5, 7),
    ]

# Generated at 2022-06-24 09:55:03.537691
# Unit test for function product
def test_product():
    from .utils import format_sizeof
    from .tests import test_product as _test_product
    import sys

    # Unit tests
    _test_product()

    # data size tests
    a, b, c = list(map(range, [10] * 3))
    for p in product(*[a, b], tqdm_class=tqdm_auto, total=2e6, miniters=1,
                     mininterval=0.01, leave=False, maxinterval=1,
                     ascii=False, ncols=100, unit_scale=True, unit="B",
                     dynamic_ncols=True, bar_format="{l_bar}{bar}|"):
        pass

    def mega_product(*args):
        """
        Returns a mega-sized product
        """
        return product

# Generated at 2022-06-24 09:55:06.392450
# Unit test for function product
def test_product():
    """
    Unit test for tqdm.product.
    """
    from .std import TestTqdmExternalWrite

    with TestTqdmExternalWrite() as t:
        t.write("tqdm.product:", end="")
        for i in product(range(100), range(10), tqdm=t, leave=False):
            pass

# Generated at 2022-06-24 09:55:17.710345
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import os
    import re
    import subprocess
    import time
    import numpy as np

    def remove_temp_file(fn):
        try:
            os.remove(fn)
        except:
            pass

    if sys.version_info[0] > 2:  # python 3
        from io import StringIO
    else:  # python 2
        from StringIO import StringIO

    # Testing function `product` with monitor

    # TEST 1: test `product` with `monitor` and `total`.

# Generated at 2022-06-24 09:55:24.477357
# Unit test for function product
def test_product():  # pragma: no cover
    import sys
    import random
    # Avoid calendar and locale output differences
    if sys.version_info <= (3, 2):
        random.seed(1)
    assert list(product('ABCD', 'xy', tqdm_class=tqdm_auto)) == [
        ('A', 'x'), ('A', 'y'),
        ('B', 'x'), ('B', 'y'),
        ('C', 'x'), ('C', 'y'),
        ('D', 'x'), ('D', 'y')]

# Generated at 2022-06-24 09:55:30.557391
# Unit test for function product
def test_product():
    import numpy as np
    a = np.random.randint(1, 10, 100)
    b = np.random.randint(1, 100, 100)
    n = len(a)

    from tqdm import tqdm
    assert (len(list(tqdm(itertools.product(a, b))))
            == len(list(product(a, b, tqdm_class=tqdm))))

    from tqdm import trange
    assert (len(list(trange(n * n)))
            == len(list(product(a, b, tqdm_class=trange))))

# ALL BELOW ARE DEPRECATED


# Generated at 2022-06-24 09:55:38.705602
# Unit test for function product
def test_product():
    from nose.tools import assert_equal
    for iterables, opts in [
            (((1, 2), (3, 4)), {"total": 4}),
            ((["a", "b"], ["c"]), {"total": 2}),
            ((iter(["d", "e", "f"]), iter(["g", "h"])), {"total": 6})]:
        assert_equal(list(product(*iterables)), list(itertools.product(*iterables)))
        assert_equal(list(product(*iterables, **opts)), list(itertools.product(*iterables)))
        assert_equal(list(product(*iterables[::-1], **opts)), list(itertools.product(*iterables[::-1])))
        iterables_c = [l[:] for l in iterables]

# Generated at 2022-06-24 09:55:47.732785
# Unit test for function product
def test_product():
    """Test for function product"""
    from random import randint
    from time import sleep
    from numpy import product

    iterables = [range(randint(2, 10)) for _ in range(randint(1, 5))]
    ref = product(*iterables)

    for _ in range(3):
        t = list(product(*iterables))
        assert t == ref

        t = list(product(*iterables, total=1))
        assert t == ref

        t = list(product(*iterables, total=1, leave=False))
        assert t == ref

        t = list(product(*iterables, leave=False))
        assert t == ref

    for _ in range(3):
        t = list(product(*iterables, total=len(list(ref))))
        assert t == ref


# Generated at 2022-06-24 09:55:53.557673
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..auto import tqdm

    t = tqdm(product(range(30), range(40), range(40),
                     unit_scale=True, mininterval=0.01),
             total=30 * 40 * 40, file=open(os.devnull, "w"))
    for _ in t:
        pass


# Generated at 2022-06-24 09:56:02.086288
# Unit test for function product
def test_product():
    # Test without args
    assert list(product()) == [()]
    assert list(product([()])) == [()]
    assert list(product([], [])) == []
    assert list(product([])) == []

# Generated at 2022-06-24 09:56:10.396316
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    result = set()
    for i in product([1, 2, 3], repeat=3, tqdm_class=None):
        result.add(i)

# Generated at 2022-06-24 09:56:17.904313
# Unit test for function product
def test_product():
    from .tests import closing, closing_last
    from ..std import next

    with closing(tqdm_auto(total=5)) as t:
        for _ in product(tqdm_auto(range(5), leave=None), [1], [1, 2], [1, 2, 3]):
            t.update()

    with closing_last(tqdm_auto()) as t:
        for _ in product([1], [1, 2], [1, 2, 3], tqdm_auto(range(5), leave=None)):
            t.update()

    with closing(tqdm_auto(total=6)) as t:
        for _ in product(range(3), range(2), [1, 2]):
            t.update()


# Generated at 2022-06-24 09:56:27.577749
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from ._utils import FakeTqdmFile
    from ..utils import FormatCustomText
    from .auto import tqdm

    for n in [10, 100, 1000, 1000]:
        with tqdm(unit="it", ascii=True, file=FakeTqdmFile()) as t:
            res = list(product(range(n), range(n), range(n), range(n),
                               tqdm_class=t.__class__))
        a = str(t).split("it/s")[0].strip()
        assert_equal(a, "10000/10000")


# Generated at 2022-06-24 09:56:33.453387
# Unit test for function product
def test_product():
    res = list(product([1, 2, 3], ['a', 'b', 'c'], tqdm_class=None))
    exp = [(1, 'a'),
           (1, 'b'),
           (1, 'c'),
           (2, 'a'),
           (2, 'b'),
           (2, 'c'),
           (3, 'a'),
           (3, 'b'),
           (3, 'c')]
    assert res == exp

# Generated at 2022-06-24 09:56:42.276605
# Unit test for function product
def test_product():
    import pytest
    from ..utils import number_range, formatted_timer
    from ..std import time

    t = formatted_timer()
    assert list(product('ABCD', 'xy', tqdm_class=tqdm_auto)) == list(itertools.product('ABCD', 'xy'))
    assert list(product(number_range(), number_range(2, 5))) == list(itertools.product(number_range(),
                                                                                          number_range(2, 5)))
    assert t.secs < 0.1
    with pytest.raises(AssertionError):
        list(product(number_range(), number_range(2, 5)))

    t = formatted_timer()
    l = list(product(number_range(), tqdm_class=tqdm_auto))
    assert t

# Generated at 2022-06-24 09:56:51.576976
# Unit test for function product
def test_product():
    """
    Test function `product`
    """
    from .test_tqdm import _open_file, pretest_posttest

    with _open_file() as (f, fname):
        for _ in range(0, 3):
            for _ in product('ABC', '123', tqdm_class=tqdm_auto,
                             file=f):
                pass
        f.close()
        with open(fname) as f2:
            lines = f2.readlines()

# Generated at 2022-06-24 09:56:53.108798
# Unit test for function product
def test_product():
    it = product(range(10000), "abcd", fd=1)
    next(it)
    it.close()

# Generated at 2022-06-24 09:56:54.446435
# Unit test for function product
def test_product():
    for i in product([1, 2, 3], (4, 5), ["hi", "yo"]):
        pass



# Generated at 2022-06-24 09:57:06.128017
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from ..std import numpy as np
    iterables = [range(10), range(10)]
    total = 100
    for i, j in tqdm(product(*iterables)):
        assert i * 10 + j == j * 10 + i
    # nested lists
    iterables = [[range(5)], range(10)]
    total = 50
    for i, j in tqdm(product(*iterables)):
        assert i * 10 + j == j * 10 + i
    # numpy arrays
    np.random.seed(0)
    iterables = [np.random.rand(5) for _ in range(2)]
    total = 5
    for i, j in tqdm(product(*iterables)):
        assert np.all(i == j[::-1])


# Generated at 2022-06-24 09:57:11.896757
# Unit test for function product
def test_product():
    """Test function product"""
    import sys
    from ..utils import StringIO
    from ..auto import trange

    test_ranges = []
    test_ranges.append(range(0))
    test_ranges.append(range(10))
    test_ranges.append(range(2, 3))
    test_ranges.append(range(1, 10, 2))
    test_ranges.append(range(10, 1, -1))

    output = StringIO()

# Generated at 2022-06-24 09:57:21.347868
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import tqdm

    # Basic test
    assert list(product(range(2), range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    # Test with tqdm
    assert list(
        product(range(2), range(2), tqdm_class=tqdm.tqdm)) == [
            (0, 0), (0, 1), (1, 0), (1, 1)]
    # Test with total=None
    assert list(product(range(2), tqdm_class=tqdm.tqdm)) == [
        (), (0,), (1,)]
    # Test with total=None + unit

# Generated at 2022-06-24 09:57:31.897518
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal, assert_raises
    from sys import version_info
    if version_info[0] == 3:
        # Test for Python 3
        import functools
        from io import StringIO
        from os import devnull
        from unittest import mock

        # With `itertools.product`
        fake = StringIO()
        with mock.patch('sys.stdout', fake):
            list(itertools.product('123', 'abc'))

# Generated at 2022-06-24 09:57:42.400850
# Unit test for function product
def test_product():
    """Test if product works correctly"""
    # Test without total
    func = lambda *i: product(*i, tqdm_class=tqdm_auto)
    assert list(func(range(3))) == list(itertools.product(*[range(3)]))
    assert list(func(range(3), range(3))) == list(itertools.product(*[range(3), range(3)]))
    assert list(func(range(3), range(2), range(4))) == list(itertools.product(*[range(3), range(2), range(4)]))
    # Test with total
    func = lambda *i: product(*i, tqdm_class=tqdm_auto)
    assert list(func(range(3))) == list(itertools.product(*[range(3)]))

# Generated at 2022-06-24 09:57:53.221764
# Unit test for function product
def test_product():
    import sys
    import io

    # If no redirect necessary
    if sys.stdout.isatty():
        list(product(range(3), repeat=3))
    else:
        # Unit test without tqdm output (redirect stdout)
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()  # capture output


# Generated at 2022-06-24 09:58:00.932426
# Unit test for function product
def test_product():
    """ Test the `product` wrapper """
    try:
        from numpy import array, logspace
    except ImportError:
        return
    for t in [list, array]:
        for num in [10, logspace(1, 2)]:
            for iter_len in [3, 10, 20]:
                for tqdm_cls in [tqdm_auto, tqdm_auto.tqdm,
                                 tqdm_auto.tqdm_gui, tqdm_auto.tqdm_notebook]:
                    res1 = product([num] * iter_len, tqdm_class=tqdm_cls)
                    res2 = itertools.product([num] * iter_len)
                    assert t(res1) == t(res2)

# Generated at 2022-06-24 09:58:10.474799
# Unit test for function product
def test_product():
    # Create test iterable
    test_iterable = [[1, 2], [3, 4], [5, 6]]
    # Create tqdm instance
    t = tqdm_auto(test_iterable, total=8, leave=False)
    # Create expected list
    expected_output = [
        (1, 3, 5),
        (1, 3, 6),
        (1, 4, 5),
        (1, 4, 6),
        (2, 3, 5),
        (2, 3, 6),
        (2, 4, 5),
        (2, 4, 6)]
    output = [i for i in product(*test_iterable, total=8, leave=False)]
    assert expected_output == output

# Generated at 2022-06-24 09:58:16.611234
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    from common import SimpleTqdm
    assert list(product(range(3), range(2), tqdm_class=SimpleTqdm)) == list(
        itertools.product(range(3), range(2)))
    assert list(product(range(3), tqdm_class=SimpleTqdm)) == list(
        itertools.product(range(3)))

# Generated at 2022-06-24 09:58:20.553384
# Unit test for function product
def test_product():
    from .tqdm import tqdm
    for i in tqdm.product(list(range(1000)), list(range(1000))):
        # Dummy loop
        pass
    for i in tqdm.product(list(range(1000)), list(range(1000))):
        # Dummy loop
        pass

# Generated at 2022-06-24 09:58:31.248711
# Unit test for function product
def test_product():
    from random import randint as ri
    from time import sleep as sleep
    from numpy.random import rand, randint
    from numpy import array
    from itertools import product as iproduct
    from nose.tools import raises, nottest, assert_is_instance, assert_raises
    import sys

    if sys.version_info < (2, 7):
        assert_raises = raises(Exception)


# Generated at 2022-06-24 09:58:38.891312
# Unit test for function product
def test_product():
    import numpy
    import random
    random.seed(123)
    numpy.random.seed(123)
    tqdms = [tqdm_auto, tqdm_auto(total=None), tqdm_auto(total=10)]
    # Small range
    for tqdm_ in tqdms:
        res = []
        for i in product(range(10), tqdm_class=tqdm_):
            res.append(i)
        assert(numpy.all(numpy.array(res) == numpy.array(list(itertools.product(range(10))))))
        # Empty range
        res = []
        for i in product(range(0), tqdm_class=tqdm_):
            res.append(i)

# Generated at 2022-06-24 09:58:47.021210
# Unit test for function product
def test_product():
    from ..utils import ncols
    from ..pandas import pandas
    from ..std import std
    from .trange import trange

    inputs = [
        [1, 2, 3, 4],
        ['a', 'b', 'c'],
        ['#', '$', '%'],
        range(100)
    ]
    outputs = set()
    for i in product(*inputs, desc="test product"):
        outputs.add(i)
    assert len(outputs) == len(inputs[0]) * len(inputs[1]) * len(
        inputs[2]) * len(inputs[3])

    with trange(2, 3, 4) as t:
        assert t.total == 2 * 3 * 4

    assert ncols(0) == 0