

# Generated at 2022-06-24 09:48:58.030681
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..tqdm_pandas import tqdm_pandas
    from pandas import DataFrame, Series

    with tqdm_pandas(total=2*2*2*2) as t:
        I = 'abcdefghijklmnopqrstuvwxyz'
        for _ in itertools.product(I, I, I, I):
            if not t.n:
                assert t.total == 2*2*2*2
            t.update(1)
    t = tqdm_pandas()
    with DataFrame(t.pandas_obj(DataFrame(range(2*2*2*2)))) as t:
        I = 'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-24 09:49:07.105404
# Unit test for function product
def test_product():
    """ Test function `product`."""
    import numpy as np
    # Test using itertools.product
    # (tqdm should not be used except in this test!)
    import itertools
    a = range(100)
    b = range(100)
    c = range(100)
    for i in product(a, b, c):
        pass
    for i in itertools.product(a, b, c):
        pass
    # Compare the results
    assert i == tqdm_auto.tqdm.is_last_iteration()
    assert len(a) == len(b) == len(c) == len(i)
    # Test using numpy.broadcast
    a = np.arange(100)
    b = a.reshape(-1, 1)
    c = a.resh

# Generated at 2022-06-24 09:49:11.828470
# Unit test for function product
def test_product():
    """Test for `itertools.product`."""
    try:
        from nose import SkipTest
        raise SkipTest
    except ImportError:
        pass
    from ..gui import tqdm
    from ..utils import format_sizeof
    from .itertools import trange
    from .iterable import FakeTqdmFile
    from .pandas import tqdm_pandas

    for t in [tqdm, tqdm_pandas]:
        for i in t(product(range(0, 3), range(0, 3), range(0, 3))):
            pass
    assert i == (2, 2, 2)


# Generated at 2022-06-24 09:49:21.349064
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    try:
        import numpy as np
    except ImportError:
        np = None
    assert list(itertools.product(range(3), range(3))) == \
        list(product(range(3), range(3)))
    assert list(itertools.product(range(3), range(3))) == \
        list(product(range(3), range(3), tqdm_class=None))
    if np is not None:
        assert list(itertools.product(np.array([1, 2]), np.array([3, 4]))) == \
            list(product(np.array([1, 2]), np.array([3, 4])))

# Generated at 2022-06-24 09:49:23.225213
# Unit test for function product
def test_product():
    """Test for function product"""
    for a in product(range(10000), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:49:34.182130
# Unit test for function product
def test_product():
    test_product.counter = 0
    for _ in tqdm_auto.product(range(10), repeat=1):
        test_product.counter += 1
    assert test_product.counter == 10
    test_product.counter = 0
    for _ in tqdm_auto.product(range(10), repeat=2):
        test_product.counter += 1
    assert test_product.counter == 100
    test_product.counter = 0
    for _ in tqdm_auto.product(range(10), repeat=3):
        test_product.counter += 1
    assert test_product.counter == 1000

    # Unit test for total kwargs
    test_product.counter = 0
    for _ in tqdm_auto.product(range(10), range(10), total=100):
        test_product.counter += 1

# Generated at 2022-06-24 09:49:38.678424
# Unit test for function product
def test_product():
    list(product([1, 2, 3], [1, 2, 3], ["a", "b", "c"],
                 tqdm_class=tqdm_auto.tqdm, total=27))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:49:47.600514
# Unit test for function product
def test_product():
    """Tests itertools.product"""
    from numpy.random import randint
    from numpy.testing import assert_equal

    it = product([1, 2, 3], [4, 5, 6])
    assert_equal(list(it),
                 [(1, 4), (1, 5), (1, 6),
                  (2, 4), (2, 5), (2, 6),
                  (3, 4), (3, 5), (3, 6)])

    it = product(randint(100, size=100), randint(100, size=100))
    assert_equal(sum(it.__len__() for _ in range(10)), 100 * 100 * 10)

# Generated at 2022-06-24 09:49:56.134097
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for i_, j_ in product(['a', 'b'], [1, 2]):
        assert (i_, j_) in [('a', 1), ('a', 2), ('b', 1), ('b', 2)]
    I = list(product(['a', 'b'], [1, 2]))
    assert I == [('a', 1), ('a', 2), ('b', 1), ('b', 2)]
    I = list(product(['a', 'b'], [1, 2], ['X', 'Y']))

# Generated at 2022-06-24 09:49:59.719326
# Unit test for function product
def test_product():
    for i in product('12345', repeat=4):
        pass
    for i in product('123', repeat=4, tqdm_class=lambda i: i):
        pass
    def foo():  # nested
        for i in product('123', repeat=4):
            pass
    foo()

# Generated at 2022-06-24 09:50:10.123171
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    import io
    import re
    import inspect
    import unittest
    from unittest.mock import patch

    if hasattr(inspect, 'signature'):
        sig = inspect.signature(product)
        assert "total" in str(sig.parameters)
    else:
        from ..utils import signature
        sig = signature(product)
        assert "total" in str(sig)

    # Test itertools.product wrapper
    assert list(product([1, 2], [3], tqdm_class=tqdm_auto)) == [(1, 3), (2, 3)]

# Generated at 2022-06-24 09:50:12.500359
# Unit test for function product
def test_product():
    import numpy as np
    assert np.all(
        np.array(list(product(range(10), repeat=2, tqdm_class=None)))
        == np.arange(10)[:, np.newaxis] ** 2)

# Generated at 2022-06-24 09:50:16.540201
# Unit test for function product
def test_product():
    from .._tqdm_test_mixins import _test_iterable
    _test_iterable(product([list(range(10)), (3, 5), [1, 2]], total=5))

# Generated at 2022-06-24 09:50:24.377508
# Unit test for function product
def test_product():
    from .utils import FixedFakeTqdmFile

    iterables = ([1, 2], ["a", "b"], ["x", "y"])
    for i in range(4):
        with FixedFakeTqdmFile(leave=True) as f:
            kwargs = {"file": f, "entire_counter": i >= 1,
                      "dynamic_ncols": i >= 2, "ascii": i >= 3}
            res = list(product(*iterables, **kwargs))
        assert res == list(itertools.product(*iterables))

        if i % 2:
            assert "\r" in f.get_value()
        else:
            assert "\r" not in f.get_value()

# Generated at 2022-06-24 09:50:32.223858
# Unit test for function product
def test_product():
    """Test the function product()."""
    try:
        from nose import tools as nt
    except:
        raise ImportError("Please install nose for unit testing")

    from nose.tools import (assert_equal, assert_is_instance,
                            assert_in, assert_not_in)

    from .utils import closing

    with closing(StringIO()) as our_file:
        with closing(tqdm(total=6, file=our_file)) as pbar:
            for (i, j) in product([1, 2, 3], tqdm_class=tqdm):
                assert_is_instance(i, int)
                assert_is_instance(j, int)
                pbar.update()
                assert_not_in("/ 6", our_file.getvalue())


# Generated at 2022-06-24 09:50:39.648653
# Unit test for function product
def test_product():
    from .tests import TestCase

    class TestProduct(TestCase):

        def test_empty(self):
            for n in product():
                self.fail()

        def test_with_length(self):
            for n in product(list(range(10))):
                self.assertEqual(len(n), 1)

        def test_without_length(self):
            for n in product(range(10)):  # generator
                self.assertEqual(len(n), 1)

        def test_multiply_length(self):
            for n in product(range(2), list(range(10))):
                self.assertEqual(len(n), 2)

    test = TestProduct()
    test.run()

# Generated at 2022-06-24 09:50:42.795103
# Unit test for function product
def test_product():
    """
    # test function product
    """
    import numpy
    expected = numpy.prod(range(1, 11))
    computed = 0
    for i in product(range(1, 11)):
        computed += 1
    assert expected == computed

# Generated at 2022-06-24 09:50:47.153276
# Unit test for function product
def test_product():
    """Test function `product`."""
    iterable = product('ABCD', 'xy', tqdm_class=None)
    assert list(iterable) == [('A', 'x'), ('A', 'y'), ('B', 'x'), ('B', 'y'), ('C', 'x'), ('C', 'y'), ('D', 'x'), ('D', 'y')]

# Generated at 2022-06-24 09:50:57.488532
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import cStringIO
    import six

    # Test tqdm(total=None)
    out = cStringIO.StringIO()
    t = tqdm_auto(product([], [], tqdm_class=tqdm_auto),
                  file=out, total=None)
    for _ in t:
        pass
    t.close()
    out = six.ensure_str(out.getvalue())
    assert '| 0/0 [00:00<' in out

    # Test tqdm(total=N)
    out = cStringIO.StringIO()
    t = tqdm_auto(product(range(3), [1], tqdm_class=tqdm_auto),
                  file=out, total=3)

# Generated at 2022-06-24 09:51:05.000956
# Unit test for function product
def test_product():
    """Test for product."""

    def product_nocount():
        return list(
            product(range(10), range(10), range(10), tqdm_class=tqdm_auto))

    def product_count():
        return list(
            product(range(10), range(10), range(10), total=1000,
                    tqdm_class=tqdm_auto))

    def product_upd():
        return list(
            product(range(10), range(100), range(10), total=1000,
                    tqdm_class=tqdm_auto))

    assert product_nocount() == product_count()
    assert product_nocount() == product_upd()

# Generated at 2022-06-24 09:51:14.222088
# Unit test for function product
def test_product():
    import numpy as np
    import time
    try:
        import lzma as comp
    except ImportError:
        import zlib as comp

    for fn in [
            product,
            tqdm_auto(itertools.product).__wrapped__,
            tqdm_auto(zip, total=1)]:
        # Test basic case
        L = [range(10), range(10), range(10)]
        assert sum(1 for _ in fn(L)) == 1000
        # Test verbosity
        with tqdm(total=1000) as t:
            for _ in fn(L, tqdm=t):
                pass
        # Test with log-like
        with tqdm(1000) as t:
            for _ in fn(L, tqdm=t):
                pass
        # Test non-

# Generated at 2022-06-24 09:51:20.517135
# Unit test for function product
def test_product():
    """Basic unit test for function product"""
    iter = product(['a', 'b'], repeat=3)
    res = [' '.join(i) for i in iter]
    assert res == ['a a a', 'a a b', 'a b a', 'a b b',
                   'b a a', 'b a b', 'b b a', 'b b b']


# NOTES:
#
# * product is a generator, therefore we can't use its length
#   to specify total.
# * loop.close() (where loop is the loop in function product)
#   does not close the iterables.

# Generated at 2022-06-24 09:51:29.722895
# Unit test for function product
def test_product():
    """Unit test for function :func:`product`"""
    import sys
    import io
    # Test case 1
    testlist = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    cap = io.StringIO()
    sys.stdout = cap
    l = list(product(testlist, testlist))
    sys.stdout = sys.__stdout__

# Generated at 2022-06-24 09:51:35.295301
# Unit test for function product
def test_product():
    """Test itertools.product wrapper"""
    assert list(product(range(8),
                        range(8))) == list(itertools.product(range(8),
                                                            range(8)))
    assert list(product(range(8),
                        range(8),
                        tqdm_class=None)) == list(itertools.product(range(8),
                                                                    range(8)))

# Generated at 2022-06-24 09:51:40.555381
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    import numpy as np

    try:
        from nose import SkipTest
        raise SkipTest("Requires numpy & nose")
    except ImportError:
        pass

    try:
        import pandas as pd

        has_andas = True
    except ImportError:
        has_andas = False

    def _test_values(iterables, total):
        """Internal test function"""
        # Prepare lists
        tot = 1
        iterables_ = list(map(lambda x: list(x), iterables))
        for i in iterables_:
            tot *= len(i)
        assert total == tot

        # Test numpy ndarray
        arrays = []

# Generated at 2022-06-24 09:51:44.572867
# Unit test for function product
def test_product():
    with tqdm_auto(total=10) as t:
        for i in product(range(10), range(10)):
            t.update()
    with tqdm_auto(total=10) as t:
        for i in product(range(10), range(10), tqdm_class=tqdm_auto):
            t.update()

test_product()

# Generated at 2022-06-24 09:51:50.364887
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import pytest

    list_2_2 = [["a", "b"], ["c", "d"]]
    list_2_2_2 = [["a", "b"], ["c", "d"], ["e", "f"]]

    def check(kwargs):
        tqdm_class = kwargs.pop("tqdm_class", tqdm_auto)
        with tqdm_class(**kwargs) as t:
            for _ in t:
                assert t.n == 0
                for i in product(*list_2_2, **kwargs):
                    assert t.n == 1
                    for j in product(*list_2_2_2, **kwargs):
                        assert t.n == 3

# Generated at 2022-06-24 09:51:52.913673
# Unit test for function product
def test_product():
    """
    Unit test for product
    """
    from ..utils import _range
    i = 0
    for x in product(_range(3), _range(3), _range(3), tqdm_class=None):
        assert x == (i % 3, i % 3, i % 3)
        i += 1

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:51:54.662328
# Unit test for function product
def test_product():
    for _ in product("AB", "123", "abcd", tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:51:57.530508
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    result = []
    for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                     postfix=False, disable=False):
        result.append(i)



# Generated at 2022-06-24 09:52:04.135996
# Unit test for function product
def test_product():
    """Simple unit test of product()."""
    from itertools import product as itproduct

    iterables = [range(i, i + 4) for i in range(1, 7)]
    ret = list(product(*iterables, desc="product", unit=" items"))
    assert ret == itproduct(*iterables)

    iterables = [range(3), range(3)]
    ret = list(product(*iterables, desc="product", unit=" items",
                       total=9))
    assert ret == itproduct(*iterables)

    ret = list(product(*iterables, desc="product", unit=" items"))
    assert ret == itproduct(*iterables)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:52:06.812604
# Unit test for function product
def test_product():
    from .tests import pretest_product
    pretest_product()
    from .tests import test_product
    test_product()

# Generated at 2022-06-24 09:52:15.138145
# Unit test for function product
def test_product():
    """Test function."""
    from .test_common import closing, StringIO, offset
    from .utils import _range

    # Test basic functionality
    with closing(StringIO()) as our_file:
        for _ in product(*((_range(1000),) * 3),
                         tqdm_class=tqdm_auto, file=our_file):
            pass
        assert len(our_file.getvalue().split(
            "\n")) == 100  # Check for multiple lines

    # Test total=None
    with closing(StringIO()) as our_file:
        for _ in product(
                *((_range(1000),) * 3),
                tqdm_class=tqdm_auto, file=our_file):
            pass
        assert len(our_file.getvalue().split(
            "\n")) == 100 

# Generated at 2022-06-24 09:52:18.014766
# Unit test for function product
def test_product():
    iterables = [['a', 'b'], [1, 2]]
    res = [i for i in product(*iterables, tqdm_class=None)]
    assert res == list(itertools.product(*iterables))

# Generated at 2022-06-24 09:52:24.781457
# Unit test for function product
def test_product():
    """
    Unit test for product(...)
    """
    from .tqdm_gui import tqdm
    from .utils import FormatCustomTextTest

    for cls in [tqdm_auto, tqdm]:
        for n, i in enumerate(product(range(3), range(3), range(3),
                                      tqdm_class=cls)):
            pass
        assert n == 27

        for n, i in enumerate(product(range(5), range(5), tqdm_class=cls)):
            pass
        assert n == 25

        with FormatCustomTextTest(cls) as t:
            for n, i in enumerate(product(range(5), range(5), tqdm=t)):
                pass
        assert n == 25
        assert t.n == 25

# Generated at 2022-06-24 09:52:35.151152
# Unit test for function product
def test_product():
    inputs = [list([1, 2, 3]), list([4, 5, 6, 7]), list([8, 9])]

    # Test terminal case
    for inp in inputs:
        for product in itertools.product(*inp):
            assert len(product) == len(inp)

    # Test generator case
    for inp in inputs:
        for product in product(*inp):
            assert len(product) == len(inp)

    # Test tqdm_class option
    from tqdm import tqdm
    for inp in inputs:
        for product in product(*inp, tqdm_class=tqdm):
            assert len(product) == len(inp)

    # Test total option

# Generated at 2022-06-24 09:52:43.777482
# Unit test for function product
def test_product():
    from numpy import product as nprod
    from .helpers import closing, closing_to_result

    def identity(x):
        return x

    # Test <itertools.chain> iterator
    assert nprod(list(itertools.chain.from_iterable(range(i)
                                                    for i in range(1, 6)))) == \
        closing_to_result(product,
                          itertools.chain.from_iterable(range(i)
                                                        for i in range(1, 6)),
                          total=0, postfix={"nprod": identity})


# Generated at 2022-06-24 09:52:52.338715
# Unit test for function product
def test_product():
    for i in product(range(2), range(2), range(2), range(2)):
        assert i in ((0, 0, 0, 0), (0, 0, 0, 1), (0, 0, 1, 0), (0, 0, 1, 1),
                     (0, 1, 0, 0), (0, 1, 0, 1), (0, 1, 1, 0), (0, 1, 1, 1),
                     (1, 0, 0, 0), (1, 0, 0, 1), (1, 0, 1, 0), (1, 0, 1, 1),
                     (1, 1, 0, 0), (1, 1, 0, 1), (1, 1, 1, 0), (1, 1, 1, 1))
        tqdm_test_interruption()

    tot = 0

# Generated at 2022-06-24 09:53:05.463127
# Unit test for function product
def test_product():
    """
    Test product().
    """
    try:
        import numpy as np
    except ImportError:
        return
    n = 10
    # Direct output comparison
    assert np.array_equal(
        list(product(range(n), range(n))),
        np.array(list(itertools.product(range(n), range(n)))))
    # Compare with length comparison
    assert np.array_equal(
        list(product(range(n), range(n), tqdm_class=None)),
        np.array(list(product(range(n), range(n)))))
    assert np.array_equal(
        list(product(range(n), range(n), tqdm_class=None)),
        np.array(list(itertools.product(range(n), range(n)))))

# Generated at 2022-06-24 09:53:12.712730
# Unit test for function product
def test_product():
    from .tests import TestCase
    import numpy as np
    from tqdm.contrib import DummyTqdmFile

    with TestCase():
        # Test basic functionality
        with DummyTqdmFile() as f:
            for _ in product([1, 2], [3, 4], [5, 6], tqdm_class=tqdm_auto,
                             file=f, miniters=0):
                pass
        assert f.write.call_count > 0

        # Test 0D array support
        with DummyTqdmFile() as f:
            for _ in product(np.random.rand(4),
                             np.random.rand(2), tqdm_class=tqdm_auto,
                             file=f, miniters=0):
                pass
        assert f.write.call

# Generated at 2022-06-24 09:53:20.391102
# Unit test for function product
def test_product():
    # import itertools first because of (broba)#215
    import itertools as it

    for a in [list('abc'), list('def'), list('ghi')]:
        for b in [list('jkl'), list('mno'), list('pqr')]:
            for c in [list('stu'), list('vwx'), list('yz ')]:
                list_a = list(it.product(a, b, c))
                list_b = list(product(a, b, c))
                assert list_a == list_b

# Generated at 2022-06-24 09:53:32.156243
# Unit test for function product
def test_product():
    """ Test tqdm's itertools """
    from nose.tools import assert_equal
    from collections import Counter

    with tqdm_auto("itertools.product") as t:
        it = product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, miniters=10)
        for _ in it:
            pass

    assert_equal(t.n, 1000)

    # is there a faster way to do this?
    with tqdm_auto("itertools.product",
                   disable=None) as t:
        it = product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto, miniters=10)
        for _ in it:
            pass


# Generated at 2022-06-24 09:53:42.734967
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import identity
    from numpy.testing import assert_equal

    iterables = [
        (1, 2, 3),
        (None, None, None),
        range(5),
        'abcde'
    ]
    p = product(*iterables)
    assert_equal(len(list(p)), len(iterables[0]) * len(iterables[1]) * len(iterables[2]) * len(iterables[3]))
    q = product(*iterables, tqdm_class=identity)
    assert_equal(len(list(q)), len(iterables[0]) * len(iterables[1]) * len(iterables[2]) * len(iterables[3]))

# Generated at 2022-06-24 09:53:44.684387
# Unit test for function product
def test_product():
    t = tqdm_auto(product(range(10), range(20)))
    assert t.total == 200
    assert next(t) == (0, 0)
    t.update(42)
    assert t.n == 42

# Generated at 2022-06-24 09:53:47.833512
# Unit test for function product
def test_product():
    """
    Unit test for itertools.product.
    """
    assert list(zip(product(range(10), range(2)), itertools.product(range(10), range(2)))) == \
        list(zip(range(20), range(20)))

# Generated at 2022-06-24 09:53:52.059798
# Unit test for function product
def test_product():
    for i in product(range(4), range(4)):
        print(i)

# Generated at 2022-06-24 09:53:54.979353
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for i in product("ABCD", repeat=2):
        pass

# Generated at 2022-06-24 09:54:04.453717
# Unit test for function product
def test_product():
    """
    Test function product
    """
    from ..tests import common
    n = 100
    a1 = range(n)
    a2 = range(n)
    it = product(a1, a2)
    assert next(it) == (0, 0)
    from ..utils import format_sizeof
    assert format_sizeof(it, "auto") == format_sizeof(
        list(itertools.product(a1, a2)), "auto")

    # Test total

# Generated at 2022-06-24 09:54:15.432739
# Unit test for function product
def test_product():
    ret = [i for i in product(*[[1, 2], [3, 4]], tqdm_class=None)]
    ret2 = [(1, 3), (1, 4), (2, 3), (2, 4)]
    assert ret == ret2

# Generated at 2022-06-24 09:54:21.820308
# Unit test for function product
def test_product():
    import sys

    # Multiprocessing is not supported (see Issue #379)
    if 'multiprocessing' in sys.modules:
        del sys.modules['multiprocessing']

    from collections import Mapping, Iterable
    from itertools import product as itertools_product

    try:
        from numpy import product as numpy_product
    except ImportError:
        numpy_product = None


# Generated at 2022-06-24 09:54:24.048768
# Unit test for function product
def test_product():
    """
    Unit test for function `product`
    """
    import numpy as np
    np.testing.assert_array_equal(
        list(product(xrange(5), repeat=5)),
        np.array(list(itertools.product(xrange(5), repeat=5))))

# Generated at 2022-06-24 09:54:25.874528
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    L = [2, 3, 5, 7]
    for k in product(range(100000000), L):
        pass
    for k in product(L, repeat=4):
        pass

# Generated at 2022-06-24 09:54:36.813089
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # Check no empty args
    assert list(product()) == []
    # Check 1 arg
    assert list(product([1])) == [1]
    # Check 2 args
    assert list(product([1, 2])) == [1, 2]
    assert list(product([1], [2])) == [(1, 2)]
    assert list(product(range(2), range(2))) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    # Check 3 arguments

# Generated at 2022-06-24 09:54:42.682815
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tests import closing, closing_pbar
    from .utils import __GEN_EXAMPLE_ITERABLES

    iterables = __GEN_EXAMPLE_ITERABLES()
    total = 0
    for _ in iterables:
        total += 1
    with closing(product(*iterables)) as pbar:
        assert pbar.total == total
    with closing_pbar(product(*iterables)) as pbar:
        assert pbar.total == total

# Generated at 2022-06-24 09:54:45.970544
# Unit test for function product
def test_product():
    import numpy as np
    res = list(product(range(10), "abcd"))
    assert len(res) == 40
    assert isinstance(res[0], tuple)

    res = list(product(np.arange(10), np.arange(10)))
    assert len(res) == 100
    assert isinstance(res[0], tuple)

# Generated at 2022-06-24 09:54:55.366969
# Unit test for function product
def test_product():
    try:
        with tqdm_auto() as t:
            for i in product(range(20), range(20), range(20),
                             tqdm_class=tqdm_auto, total=800000):
                pass
        assert t.total == 80000
        assert t.n == 80000
    except TypeError:
        pass
    with tqdm_auto() as t:
        for i in product(range(20)):
            pass
    assert t.total == 20
    assert t.n == 20

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:55:02.030392
# Unit test for function product
def test_product():
    def generate(n):
        for i in range(n):
            yield i
        raise StopIteration

    assert list(product(generate(5))) == [(i,) for i in range(5)]
    assert list(product(generate(5), repeat=2)) == [(i, j)
                                                    for i in range(5)
                                                    for j in range(5)]

    assert list(product(generate(2), generate(3))) == [(0, 0), (0, 1), (0, 2),
                                                       (1, 0), (1, 1), (1, 2)]

# Generated at 2022-06-24 09:55:12.657237
# Unit test for function product
def test_product():  # pragma: no cover
    from .std import product as tqdm_product


# Generated at 2022-06-24 09:55:20.065281
# Unit test for function product
def test_product():
    from io import StringIO
    from sys import stdout

    with StringIO() as strf:
        stdout, tqdm_auto.write = strf, strf.write

        for _ in product(range(100), range(100), range(100),
                         desc='Test', leave=False,
                         tqdm_class=tqdm_auto):
            pass

        # Need to set stdout back to stdout
        stdout = stdout
        s = strf.getvalue()
        assert '\r' not in s


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:55:29.358139
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm

    for i in product(range(3), range(3), tqdm=tqdm):
        pass
    assert i == (2, 2)


try:
    import numpy as np
    from numpy import ndindex
except ImportError:
    pass
else:
    __all__ += ['ndindex']

    def ndindex(*shape, **tqdm_kwargs):
        """
        Equivalent of `numpy.ndindex`, but `tqdm`-compatible.

        Parameters
        ----------
        tqdm_class  : [default: tqdm.auto.tqdm].
        """
        kwargs = tqdm_kwargs.copy()

# Generated at 2022-06-24 09:55:33.049644
# Unit test for function product
def test_product():
    """Test product"""
    from ._utils import _range
    from ._termui_testing import _do_test_write
    from .trange import trange
    values = [1, 2, 3]
    total = 1
    for i in list(map(len, values)):
        total *= i
    with trange(total) as t:
        for i in product(*values):
            assert i in list(itertools.product(*values))
            t.update()

# Generated at 2022-06-24 09:55:34.833551
# Unit test for function product
def test_product():
    for i, _ in enumerate(tqdm.tqdm_product((['a', 'b'], ['c', 'd'], ['e', 'f']))):
        pass
    assert i == 8


# Generated at 2022-06-24 09:55:42.221871
# Unit test for function product
def test_product():
    import numpy as np
    x = np.array(list(product([1, 2], [3, 4])))
    x.sort()
    assert np.array_equal(x, np.arange(1, 9).reshape(4, 2))

    x = np.array(list(product([1, 2, 3], [4, 5, 6])))
    x.sort()
    assert np.array_equal(x, np.arange(1, 37).reshape(18, 2))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:55:52.905772
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..tqdm import trange
    from .tests_tqdm import with_setup, pretest, posttest, _range


# Generated at 2022-06-24 09:56:01.660183
# Unit test for function product
def test_product():
    # Test instantiation
    with tqdm_auto(unit='word') as n:
        n.update(3)
        n.close()

    with tqdm_auto(unit='word', unit_scale=1) as n:
        n.update(3)
        n.close()

    with tqdm_auto(unit_scale=10) as n:
        n.update(3)
        n.close()

    with tqdm_auto(unit_scale=0.1) as n:
        n.update(3)
        n.close()

    with tqdm_auto(unit='s') as n:
        for i in range(3):
            n.update()

    with tqdm_auto(unit='s') as n:
        for i in range(10):
            n.update()

# Generated at 2022-06-24 09:56:10.091468
# Unit test for function product
def test_product():
    from . import _test_iters

    func = product
    err_type = TypeError
    t_args = ([1, 2], ['a', 'b'])
    t_kwargs = {}
    t_expected_result = [
        (1, 'a'),
        (1, 'b'),
        (2, 'a'),
        (2, 'b'),
    ]
    _test_iters(func, t_args, t_kwargs, t_expected_result, err_type)

    t_args = ([1, 2], ['a', 'b'], ['A', 'B'])
    t_kwargs = {}

# Generated at 2022-06-24 09:56:18.989578
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    import itertools
    import tqdm
    it = tqdm.product(range(3))
    assert next(it) == (0,)
    assert next(it) == (1,)
    assert next(it) == (2,)
    it = tqdm.product(range(3), range(3))
    assert next(it) == (0, 0)
    assert next(it) == (0, 1)
    assert next(it) == (0, 2)
    assert next(it) == (1, 0)
    it = tqdm.product(range(3), range(3), range(3))
    assert next(it) == (0, 0, 0)
    assert next(it) == (0, 0, 1)


# Generated at 2022-06-24 09:56:22.539411
# Unit test for function product
def test_product():
    for _ in product(["a", "b"], [1, 2], tqdm_class=None):
        pass

# Generated at 2022-06-24 09:56:31.064776
# Unit test for function product
def test_product():
    try:
        from numpy.testing import assert_equal
    except ImportError:
        return True  # No testing possible
    from ..utils import format_sizeof

    assert_equal(list(product(range(3), repeat=2, tqdm_class=None)),
                 list(itertools.product(range(3), repeat=2)))

    with tqdm_auto(total=3) as t:
        def tqdm(total, *args, **kwargs):
            assert kwargs.pop("leave", False)
            return t
        assert_equal(list(
            product(range(3), repeat=2, tqdm_class=tqdm)),
                     list(itertools.product(range(3), repeat=2)))
    assert_equal(t.n, 3)

# Generated at 2022-06-24 09:56:38.909483
# Unit test for function product
def test_product():
    import numpy as np
    from operator import mul
    from functools import reduce
    from ..tests.common import Random

    def prod(iterable):
        return reduce(mul, iterable, 1)

    r = Random(0)
    for i in range(5):
        ranges = r.randint(1, 5, size=r.randint(1, 3))
        prods = []
        for _ in tqdm(list(product(*[range(r) for r in ranges]))):
            prods.append(prod(_))

        assert set(prod(ranges) == prods)

# Generated at 2022-06-24 09:56:47.668162
# Unit test for function product
def test_product():
    from .tests import TestCase

    try:
        from random import randint
        from itertools import product
        from collections import Counter
    except ImportError:
        return

    for _ in TestCase().iter_failures():
        gen_a = (randint(0, 5) for _ in range(10))
        gen_b = (randint(0, 5) for _ in range(10))
        gen_c = (randint(0, 5) for _ in range(10))
        list_a = list(gen_a)
        list_b = list(gen_b)
        list_c = list(gen_c)
        expected = list(product(list_a, list_b, list_c))
        l = set()

# Generated at 2022-06-24 09:56:54.138254
# Unit test for function product
def test_product():
    import numpy as np

    for i in product(range(5), range(5)):
        pass
    assert i == (4, 4)

    for i in product(range(5), range(5), tqdm_class=None):
        pass
    assert i == (4, 4)

    assert len(list(product(range(5), range(5)))) == 25


# Generated at 2022-06-24 09:57:05.855313
# Unit test for function product
def test_product():
    import pytest
    from numpy.random import randint
    from ..utils import format_sizeof as sizeof

    def check_product(a, b, c):
        ref = list(itertools.product(a, b, c))
        out = list(product(a, b, c))
        assert ref == out
        out = list(product(a, b, c, tqdm_class=lambda x: x))
        assert ref == out
        out = list(product(a, b, c, tqdm_class=tqdm_auto, leave=False))
        assert ref == out

    # Simple cases
    check_product([1, 2, 3], [4, 5, 6], [7, 8, 9])

    # Non-trivial size

# Generated at 2022-06-24 09:57:07.938954
# Unit test for function product
def test_product():
    for i in product(range(6), ['a', 'b', 'c']):
        assert (i)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:57:13.674642
# Unit test for function product
def test_product():
    import numpy as np
    from ..tqdm import trange
    from ..utils import format_interval

    for t in trange(1, 14, desc='1-14', leave=True):
        for p in product(range(0, t + 1), repeat=3):
            pass
        for t1 in trange(1, 22, desc='1-22', leave=True):
            for p in product(range(0, t1 + 1), repeat=t):
                pass

# Generated at 2022-06-24 09:57:15.882659
# Unit test for function product
def test_product():
    from .tests import test_product as tp
    tp()

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:57:21.283522
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from nose.tools import assert_equal
    from ..compat import range
    assert_equal(len(list(product(range(10)))), 10)
    assert_equal(len(list(product([[0]]))), 1)
    assert_equal(len(list(product(range(10), range(10)))), 100)
    assert_equal(len(list(product(range(10), range(10), range(10)))), 1000)

# Generated at 2022-06-24 09:57:28.687996
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests import closing, in_closing
    from tqdm import trange
    from itertools import product

    list(product(range(4), range(4)))
    for tqdm_class in [tqdm_auto, trange]:
        it = product(range(4), range(4), tqdm_class=tqdm_class)
        with closing(it):
            assert not in_closing(it)
            list(it)

# Generated at 2022-06-24 09:57:38.509521
# Unit test for function product
def test_product():
    """Unit test for function `product`"""
    try:
        import numpy as np
    except ImportError:
        yield skip("numpy needed for this test")
    yield lambda: assert_equal(np.prod(np.array([3, 4, 5])),
                               np.sum(map(len, product(range(3),
                                                      range(4),
                                                      range(5)))))



# Generated at 2022-06-24 09:57:48.707457
# Unit test for function product
def test_product():
    """Unit test for product"""
    import random
    with tqdm_auto(total=10 * 5 * 5 * 5 * 5) as t:
        for i in product(range(10), 'abcd', 'ABCD', '12345', tqdm_class=t.__class__):
            assert type(i) == tuple
            assert len(i) == 4
            assert type(i[0]) == int
            assert type(i[1]) == str
            assert type(i[2]) == str
            assert type(i[3]) == str
            t.update()
    with tqdm_auto(total=10 * 5 * 5) as t:
        for i in product(range(10), 'abcd', 'ABCD', tqdm_class=t.__class__):
            assert type(i) == tuple


# Generated at 2022-06-24 09:57:55.144539
# Unit test for function product
def test_product():
    """Test function `product`"""
    import numpy as np
    from .tqdm_test_utils import RandomIterable

    iterables = list(map(RandomIterable, [10, 15, 20]))
    res = list(product(*iterables))
    expected = list(itertools.product(*iterables))

    for (r1, r2) in zip(res, expected):
        assert r1 == r2
    assert len(res) == np.prod(map(len, iterables))

# Generated at 2022-06-24 09:58:02.562529
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import TestCase, TestsBar

    class TqdmTest(TestCase):

        def test_product(self):
            for kwargs in TestsBar.generate_kwargs(ncols=True):
                for iter in (
                    ([1, 2], ['a', 'b']),
                    (range(10), ['a', 'b']),
                    ([1, 2], range(10), range(10)),
                ):
                    with self.subTest(**kwargs):
                        out = next(product(*iter, **kwargs))
                        self.assertIsInstance(out, tuple)
                        self.assertEqual(len(iter), len(out))
                        res = (next(iter[0]),) if len(iter) == 1 else iter


# Generated at 2022-06-24 09:58:12.712124
# Unit test for function product
def test_product():
    """Unit Test"""
    from ..auto import tqdm

    def test_product_gen():
        for _ in tqdm.product(range(5), range(5), range(5)):
            pass

    def test_product_gen_tqdm():
        for _ in tqdm.product(range(5), range(5), range(5), tqdm_class=tqdm):
            pass

    test_product_gen()
    test_product_gen_tqdm()
    for _ in tqdm.product("ABC", total=6):
        pass
    for _ in tqdm.product("ABC", total=3):
        pass
    try:
        for _ in tqdm.product("ABC", range(3)):
            pass
    except TypeError:
        pass

# Generated at 2022-06-24 09:58:22.896100
# Unit test for function product
def test_product():  # pragma: no cover
    from .status import StatusPrinter, format_sizeof
    from .utils import FormatCustomText

    it = product(range(10), range(20), range(30),
                 tqdm_class=tqdm_auto,
                 leave=False,
                 ascii=True,
                 bar_format=FormatCustomText(
                     '{l_bar}{bar}{r_bar}',
                     dict(
                         l_bar='{desc}: {percentage:3.0f}%|',
                         r_bar='| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, '
                               '{rate_fmt}{postfix}]')))
    while it.n < it.total:
        it.set_description("Done")
        next(it)


# Generated at 2022-06-24 09:58:30.646819
# Unit test for function product
def test_product():
    from .tests import setup_tests, teardown_tests
    setup_tests()

    from .tests import size, closing, closing_iter

    try:
        len(list(product(closing(range(i)) for i in range(3))))
    except RuntimeError:
        pass
    else:
        assert False, "RuntimeError should have been raised"

    assert len(list(product(closing_iter(range(i)) for i in range(3)))) == 0

# Generated at 2022-06-24 09:58:39.542608
# Unit test for function product
def test_product():
    for k1 in range(1, 6):
        for k2 in range(1, 6):
            for k3 in range(1, 6):
                x = list(range(k1))
                y = list(range(k2))
                z = list(range(k3))
                p = product(x, y, z, tqdm_class=tqdm_auto)
                assert list(p) == list(itertools.product(x, y, z))

# Generated at 2022-06-24 09:58:47.143041
# Unit test for function product
def test_product():
    """
    Unit testing for `tqdm.tqdm_itertools.product`.
    """
    from .. import trange
    from ..tqdm_gui import tqdm

    def g(M, N, **kwargs):
        return trange(M * N, file=None, **kwargs)

    def g2(M, N, **kwargs):
        return tqdm.trange(M * N, file=None, **kwargs)

    for t in [trange, g, g2]:
        # Test against itertools.product
        out1 = list(itertools.product('abcd', repeat=2))
        out2 = list(product('abcd', repeat=2, tqdm_class=t))
        assert out1 == out2

        # Test against itertools.product (

# Generated at 2022-06-24 09:58:51.698073
# Unit test for function product
def test_product():
    with tqdm_auto(total=0) as t:
        testlist = list(product('abcd', '123'))