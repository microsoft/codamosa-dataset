

# Generated at 2022-06-24 09:49:01.359071
# Unit test for function product
def test_product():
    import pytest
    with pytest.raises(TypeError):
        list(product(range(3), 4))
    assert list(product(range(3), range(4))) == \
        [(0, 0), (0, 1), (0, 2), (0, 3), (1, 0), (1, 1), (1, 2), (1, 3),
         (2, 0), (2, 1), (2, 2), (2, 3)]

# Generated at 2022-06-24 09:49:03.464039
# Unit test for function product
def test_product():
    s = "abcd"
    p = list(product(s, repeat=3))
    assert p == list(itertools.product(s, repeat=3))

# Generated at 2022-06-24 09:49:11.502040
# Unit test for function product
def test_product():
    """Test function"""
    from numpy import prod
    assert sum(1 for _ in product(range(2), range(3))) == prod([2, 3])
    assert prod([2, 3]) == 6
    assert sum(1 for _ in product(range(2), range(3))) == prod([2, 3])
    assert prod([2, 3]) == 6
    assert sum(1 for _ in product(range(2), range(3), range(2))) == \
        prod([2, 3, 2])
    assert prod([2, 3, 2]) == 12
    assert sum(1 for _ in product(range(2), range(3), range(2))) == \
        prod([2, 3, 2])
    assert prod([2, 3, 2]) == 12

# Generated at 2022-06-24 09:49:22.114613
# Unit test for function product
def test_product():
    """Test tqdm(itertools.product())"""
    from ..main import trange
    from ..utils import format_interval
    from ..tests import pretest_posttest  # NOQA
    # Test 1
    with trange(10, desc='test') as t:
        for (i, j, k) in product(t, (1, 2, 3), 'abc'):
            assert i == j * len('abc') + list('abc').index(k)
    # Test 2
    with trange(12, 5) as t:
        for i in product(range(0, 5), tqdm_class=type(t)):
            if i[0] == 0:
                t.set_description('Loop')
            elif i[0] == 4:
                t.set_description('Completed')
   

# Generated at 2022-06-24 09:49:28.464629
# Unit test for function product
def test_product():
    from ..utils import FormatWrapBase

    class FakeTqdm(FormatWrapBase):
        def __init__(self, n):
            self._n = n

        def __iter__(self):
            for i in range(self._n):
                yield i

        def update(self, n=1):
            pass

    result = list(product(range(10), range(10), tqdm_class=FakeTqdm))
    assert result == list(itertools.product(range(10), range(10)))

# Generated at 2022-06-24 09:49:37.941350
# Unit test for function product
def test_product():
    # Test that tqdm wraps product correctly
    import numpy as np
    a = ['a', 'b', 'c']
    b = ['d', 'e', 'f']
    for (x, y), i in zip(itertools.product(a, b), tqdm_auto(itertools.count())):
        assert x + y == ''.join(('a', 'd')) + chr(ord('d') + i)
    # Test that tqdm wraps product with original number of elements
    a = np.arange(5)
    b = np.arange(5)
    l = len(list(itertools.product(a, b)))

# Generated at 2022-06-24 09:49:48.350195
# Unit test for function product
def test_product():
    """
    Testing function product.
    """
    from tqdm import tqdm
    from tqdm.contrib import product as tqdm_product

    def foo(a, b, c):
        """
        Does nothing
        """
        return a + b + c

    a = [0, 1]
    b = [2, 3]
    c = [4, 5, 6]
    for _ in zip(product(a, b, c), tqdm_product(a, b, c), tqdm(product(a, b, c))):
        pass

    for _ in zip(product(a, b, c, tqdm_class=tqdm), tqdm_product(a, b, c),
                 tqdm(product(a, b, c))):
        pass


# Generated at 2022-06-24 09:49:55.145514
# Unit test for function product
def test_product():
    import inspect
    import os
    import sys

    # Make sure tqdm's functional tests can be run in a subprocess
    # (see https://github.com/tqdm/tqdm/issues/481)
    __location__ = os.path.join(os.getcwd(), os.path.dirname(inspect.getfile(inspect.currentframe())))
    sys.path.append(os.path.join(__location__, ".."))
    from .tests_tqdm import pretest_posttest

    pretest_posttest(product, (range(10), range(10), range(10)))

# Generated at 2022-06-24 09:49:58.057432
# Unit test for function product
def test_product():
    for _ in product([1, 2], ["a", "b", "c"]):
        pass
    for _ in product(["a", "b", "c"], [1, 2], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:50:01.173833
# Unit test for function product
def test_product():
    import numpy as np
    from ..auto import tqdm as tqdm_auto

    for n1, n2 in product([10, 1], [10, 1],
                          tqdm_class=tqdm_auto,
                          leave=False):
        np.random.rand(n1, n2)

# Generated at 2022-06-24 09:50:11.437648
# Unit test for function product
def test_product():
    assert list(product(range(3), 'xyz', ['a', 'b'])) ==\
        [(0, 'x', 'a'), (0, 'x', 'b'), (0, 'y', 'a'), (0, 'y', 'b'),
         (0, 'z', 'a'), (0, 'z', 'b'), (1, 'x', 'a'), (1, 'x', 'b'),
         (1, 'y', 'a'), (1, 'y', 'b'), (1, 'z', 'a'), (1, 'z', 'b'),
         (2, 'x', 'a'), (2, 'x', 'b'), (2, 'y', 'a'), (2, 'y', 'b'),
         (2, 'z', 'a'), (2, 'z', 'b')]

# Generated at 2022-06-24 09:50:21.802782
# Unit test for function product
def test_product():
    """Unit test for `product` with builtin `zip`.
    """
    from ..utils import FormatMeter
    from ..utils import StatusPrinter
    from ..utils import ProcessMonitor
    from ..utils import Timer

    def test_func(i, j, k=0):
        return i, j, k

    with FormatMeter(1, 0, 2, 5) as f:
        with StatusPrinter(0, 4, 1, 0, f) as s:
            with ProcessMonitor(s) as p:
                with Timer(s, p) as t:
                    for i in product(list(range(5)),
                                     list(range(10)),
                                     total=5*10,
                                     desc="test description",
                                     leave=False):
                        assert i[0] < 5

# Generated at 2022-06-24 09:50:27.769837
# Unit test for function product
def test_product():
    iterables = [range(2), [2.0], ['a', 'b']]
    assert (list(product(*iterables)) ==
            list(itertools.product(*iterables)))
    assert (list(product(*iterables, tqdm_class=None)) ==
            list(itertools.product(*iterables)))
    assert (list(product(*iterables, total=len(iterables))) ==
            list(itertools.product(*iterables)))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:50:33.266230
# Unit test for function product
def test_product():
    """
    Unit test for function `product`
    """
    from os import pardir
    from os.path import abspath, dirname, join
    test_dir = join(dirname(abspath(__file__)), pardir, pardir)
    if not abspath(test_dir) == abspath(abspath(join(__file__, pardir))):
        raise RuntimeError("Do not run unit test from subfolder")
    import sys

    sys.path.append(test_dir)
    from tests.test_tqdm import test_script

    test_script(test_dir, "test_tqdm_itertools.py")

# Generated at 2022-06-24 09:50:39.809617
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys

    class _tqdm(tqdm_auto):
        # fake tqdm.write()
        def write(self, s, file=None, end="\n", nolock=False):
            return sys.stdout.write(s) or None

    assert 'ABCDEF' == ''.join(
        _tqdm(product('ABCD', 'ef'), desc='test', unit='it')
    )
    assert 'ABCDEF' == ''.join(
        _tqdm(product('AB', 'C', 'D', 'ef'), desc='test', unit='it')
    )

# Generated at 2022-06-24 09:50:46.478041
# Unit test for function product
def test_product():
    from .tests_tqdm import with_setup, _range
    with_setup(tqdm_auto)(lambda: product(range(1000)))
    with_setup(tqdm_auto)(lambda: product(range(500), range(500)))
    with_setup(tqdm_auto)(lambda: product(range(500), repeat=2))

    with_setup(tqdm_auto, leave=True)(lambda: list(product(range(10), repeat=5)))
    with_setup(tqdm_auto, leave=True)(lambda: list(product(_range(), repeat=5)))

# Generated at 2022-06-24 09:50:56.766487
# Unit test for function product
def test_product():
    g = product(range(3), range(3), range(3), tqdm_class=tqdm_auto)

# Generated at 2022-06-24 09:51:05.262004
# Unit test for function product
def test_product():
    """Test various parameters to `tqdm.itertools.product`"""
    from ..utils import format_sizeof  # Avoid circular dependencies
    assert len(list()) == 0
    iter1, iter2 = range(10), range(10)
    total = 100
    test_str = """00%|                                                          | 0/100 [00:00<?, ?it/s]"""
    assert len(
        str(tqdm_auto(product(iter1, iter2, total=total)))) == len(test_str)
    assert len(
        str(tqdm_auto(product(iter1, iter2, total=total), desc="prod1"))) == len(
            test_str)

# Generated at 2022-06-24 09:51:11.497604
# Unit test for function product
def test_product():
    """Test function"""
    iterators = [range(1), range(1), range(1)]
    ret = product(*iterators)
    assert next(ret) == (0, 0, 0)
    import sys
    if sys.version_info[0] < 3:
        # range is not an iterable in Py2
        iterators = [xrange(1), xrange(1), xrange(1)]
    assert list(product(*iterators)) == [(0, 0, 0)]

# Generated at 2022-06-24 09:51:18.004701
# Unit test for function product
def test_product():
    from .utils import TerminalLineWatcher
    from itertools import chain, product as true_product

    def simple_gen():
        yield from iter(range(5))

    def gen():
        for i in range(5):
            yield from range(5 - i)

    for ascii in (True, False):
        for total in (None, 5):
            for ncols in (0, 1):
                with TerminalLineWatcher('nl', 'ncols') as tw:
                    tw.stop()
                    tw.start()
                    list(product(range(5), total=total, ascii=ascii,
                                 ncols=ncols))

                with TerminalLineWatcher('nl', 'ncols') as tw:
                    tw.stop()
                    tw.start()

# Generated at 2022-06-24 09:51:27.534164
# Unit test for function product
def test_product():
    from ..utils import format_sizeof

    # Tests:
    # default
    # ensure `total` is correct
    # ensure correct values are returned
    # ensure no error if `total=None`
    # ensure no error if `total` is positive

    def get_product_values(iterables_sizes):
        return [format_sizeof(p) for p in product(*[range(s) for s in
                                                    iterables_sizes])]

    assert get_product_values([1, 1, 1]) == ['0 B', '0 B', '0 B']
    assert get_product_values([1, 1, 2]) == ['0 B', '0 B', '1 B']

# Generated at 2022-06-24 09:51:38.135202
# Unit test for function product
def test_product():
    import sys
    import numpy
    from ..auto import tqdm

    # itertools.product
    assert list(product(['a', 'b'], repeat=3)) == \
        [('a', 'a', 'a'), ('a', 'a', 'b'), ('a', 'b', 'a'),
         ('a', 'b', 'b'), ('b', 'a', 'a'), ('b', 'a', 'b'),
         ('b', 'b', 'a'), ('b', 'b', 'b')]

# Generated at 2022-06-24 09:51:42.673934
# Unit test for function product
def test_product():
    import sys
    with tqdm_auto(unit_scale=True, ascii=True,
                   mininterval=0., miniters=1,
                   file=sys.stderr) as pbar:
        str_product = product(range(4), repeat=4, tqdm_class=pbar)
        for i in str_product:
            pass

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:51:51.656770
# Unit test for function product
def test_product():
    """
    Test `tqdm.tqdm_itertools.product` format.
    """
    from ..tqdm_gui import tqdm
    with tqdm(total=3) as t:
        assert t.miniters == 1
        assert list(t) == []
    with tqdm(total=3) as t:
        assert t.miniters == 1
        assert list(t) == []
        assert not t.disable
    with tqdm(total=3) as t:
        assert t.miniters == 1
        assert list(t) == []
        assert not t.disable
        t.close()
    with tqdm(total=3) as t:
        assert t.miniters == 1
        assert list(t) == []

# Generated at 2022-06-24 09:52:01.877002
# Unit test for function product
def test_product():
    """Test function product"""
    import numpy as np

    for i in range(10):
        for j in range(10):
            for k in range(10):
                for l in range(10):
                    assert next(product(range(i),
                                        range(j),
                                        range(k),
                                        range(l))) == (0, 0, 0, 0)
                    assert next(product(range(i), range(j),
                                        range(k), range(l))) == (0, 0, 0, 1)
                    assert next(product(range(i), range(j),
                                        range(k), range(l))) == (0, 0, 0, 2)
                    assert next(product(range(i), range(j),
                                        range(k), range(l))) == (0, 0, 0, 3)

# Generated at 2022-06-24 09:52:09.712658
# Unit test for function product
def test_product():
    from tqdm import trange
    from random import randrange
    for _ in trange(10):
        for i in range(3, randrange(4, 8)):
            assert list(product(*[range(randrange(3, 8))] * i)) == list(itertools.product(*[range(randrange(3, 8))] * i))
    assert list(product(*(range(i) for i in range(1, 6)))) == list(itertools.product(*(range(i) for i in range(1, 6))))

# Generated at 2022-06-24 09:52:19.877711
# Unit test for function product
def test_product():
    from ..utils import _range
    from itertools import product as it_product

    def test_product_with_len():
        for l in [1, 2, 4, 100]:
            for f in [_range, list]:
                for m in [1, 2, 4]:
                    for k in [0, 1, 2]:
                        for j in [1, 2, 3, 4]:
                            iterables = [f(l)] * j

# Generated at 2022-06-24 09:52:25.783493
# Unit test for function product
def test_product():
    it = product('ABCD', 'xy', tqdm_class=tqdm_auto)
    assert tuple(it) == tuple(itertools.product('ABCD', 'xy'))
    assert tuple(product('ABCD', 'xy', tqdm_class=tqdm_auto)) == \
        tuple(itertools.product('ABCD', 'xy'))
    assert tuple(product('ABCD', 'xy', tqdm_class=tqdm_auto)) == \
        tuple(product('ABCD', 'xy', tqdm_class=tqdm_auto))

# Generated at 2022-06-24 09:52:36.137989
# Unit test for function product
def test_product():
    """Test for coverage"""
    from .tests import _test_iterable_wraps
    from .tests import nose, with_setup, ok_, eq_, is_not_

    _test_iterable_wraps(lambda: product(range(30)), total=None,
                         desc="product(range(30))")
    _test_iterable_wraps(lambda: product(range(30), tqdm_class=tqdm_auto),
                         total=None, desc="product(range(30))",
                         tqdm_class=tqdm_auto)

    _test_iterable_wraps(lambda: product(range(30), range(20)),
                         total=600,
                         desc="product(range(30), range(20))")


# Generated at 2022-06-24 09:52:44.454785
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    with tqdm_auto(total=1) as t:
        assert t.total == 1
        for i in product(range(10), range(10)):
            assert i[0] < 10 and i[1] < 10
            t.update()
    with tqdm_auto(leave=False) as t:
        assert t.total is None
        for i in product(range(10), range(10)):
            assert i[0] < 10 and i[1] < 10
            t.update()
    with tqdm_auto(total=10) as t:
        assert t.total == 10
        for i in product(range(10)):
            assert i[0] < 10
            t.update()

# Generated at 2022-06-24 09:52:52.910435
# Unit test for function product
def test_product():
    """
    Unit test of function `product`.
    """
    import numpy as np
    from .utils import comparison


# Generated at 2022-06-24 09:53:00.126955
# Unit test for function product
def test_product():
    """Unit test for function `tqdm.itertools.product`"""
    # The function must only add a progress bar
    assert list(product('ABCD', 'xy')) == list(itertools.product('ABCD', 'xy'))
    assert list(product('ABCD', 'xy', tqdm_class=None)) == \
        list(itertools.product('ABCD', 'xy'))
    # Test iterations number
    with tqdm_auto(total=None) as t:
        assert list(product('ABCD', 'xy', tqdm_class=tqdm_auto,
                            total=None, miniters=1)) == \
            list(itertools.product('ABCD', 'xy'))

# Generated at 2022-06-24 09:53:02.134357
# Unit test for function product
def test_product():
    import doctest
    return doctest.testmod()


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:53:10.549060
# Unit test for function product
def test_product():
    from .tests import TestCase
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as f:
        for i in product([0, 1], tqdm_class=tqdm_auto, file=f):
            pass
        f.seek(0)
        lines = f.readlines()

    lines = [l.decode().strip() for l in lines]
    del lines[:3]  # Header
    del lines[-3:]  # Footer
    assert lines == ["0/2", "1/2"]

    with NamedTemporaryFile() as f:
        for i in product([0, 1], tqdm_class=tqdm_auto, file=f):
            pass
        f.seek(0)
        lines = f.readlines()


# Generated at 2022-06-24 09:53:21.853315
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import format_sizeof
    from .utils import FormatMixin
    from .monitor import new_tqdm

    class TestProduct(FormatMixin, object):
        def __init__(self):
            import numpy as np
            self.n = 10
            self.shape = (self.n, self.n)

        def test_product_identity(self):
            # Check that product == implicit loop
            # and that product uses max memory available
            a = np.zeros(self.shape)
            b = np.zeros(self.shape)
            c = np.zeros(self.shape)
            arr = np.zeros(self.shape)

# Generated at 2022-06-24 09:53:33.184751
# Unit test for function product
def test_product():
    """Test function product"""
    import numpy as np
    from ..utils import FormatMixin

    class MockTqdm(FormatMixin):
        def __init__(self, **kwargs):
            self.n = 0
            for k, v in kwargs.items():
                setattr(self, k, v)

        def __iter__(self):
            return self

        def __next__(self):
            self.n += 1
            if self.n <= self.total:
                return self
            raise StopIteration

        next = __next__  # Python 2 compatibility

        def format_meter(self, n, total, elapsed):
            return self.format_sizeof(n)

        def update(self, n=1):
            raise NotImplementedError("Not needed for this test function")


# Generated at 2022-06-24 09:53:44.158150
# Unit test for function product
def test_product():
    from .tests import TestCase
    from collections import Counter

    for tqdm_class in (tqdm_auto,):  # TODO: Test for tqdm when #1067 fixed
        with TestCase(tqdm_class=tqdm_class):
            for t in product(range(2), range(3), range(4), tqdm_class=tqdm_class):
                pass
            with TestCase(tqdm_class=tqdm_class):
                for t in product([2], range(3), tqdm_class=tqdm_class):
                    pass
            with TestCase(tqdm_class=tqdm_class):
                for t in product(range(3), [3], tqdm_class=tqdm_class):
                    pass

# Generated at 2022-06-24 09:53:47.687564
# Unit test for function product
def test_product():
    import numpy as np
    np.random.seed(0)
    iter = product(range(100), range(100), tqdm_class=tqdm_auto)
    counter = 0
    while next(iter):
        counter += 1
    assert (counter == 100 ** 2)


# Generated at 2022-06-24 09:53:55.955046
# Unit test for function product
def test_product():
    "Test for function product"
    with tqdm_auto(total=4) as pbar:
        for x in product('ABCD', repeat=2, tqdm_class=pbar.__class__):
            pass

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:54:03.986283
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    from .utils import format_interval, format_meter

    result = []
    for product_ in [product, itertools.product]:
        with product_(range(3), range(3), range(3),
                      tqdm_class=tqdm_auto,
                      unit="it", unit_scale=False,
                      total=27) as td:
            result.append(list(td))
    assert(result[0] == result[1])

    def square(x):
        """Calculate x^2"""
        return x * x

    result = []

# Generated at 2022-06-24 09:54:16.202394
# Unit test for function product
def test_product():
    """Test for product() function."""
    from .gui import tqdm
    from .utils import FormatCustomText

    # Exercise the `total` parameter
    for total in [None, 1, 100]:
        with tqdm(total=total) as pbar:
            assert pbar.total == total
            for _ in product(['a', 'b', 'c'], repeat=4, tqdm_class=tqdm,
                             total=total):
                pbar.update()
    # Check that the `product` function works as a context manager
    with product(['a', 'b', 'c'], repeat=2, tqdm_class=tqdm) as pbar:
        for _ in pbar:
            pass
    # Check that the `product` function works with an ascii/unicode bar

# Generated at 2022-06-24 09:54:21.571204
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from tqdm.utils import _range as range

    iterable = product(range(i) for i in range(1, 10))
    assert len(list(filter(lambda x: sum(x) == 10, iterable))) == 1
    iterable = product([1, 2, 3], repeat=3)
    assert len(list(filter(lambda x: sum(x) == 10, iterable))) == 55

# Generated at 2022-06-24 09:54:26.157232
# Unit test for function product
def test_product():
    from ..utils import FormatWarn

    for T in [None, 1, 10]:
        for i in product(range(3), range(3), tqdm_class=tqdm_auto,
                         desc="0", total=T):
            with FormatWarn(hide_input=True):
                assert 0 <= sum(i) <= 3

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:54:31.499444
# Unit test for function product
def test_product():
    """ Test for the product() function """
    with tqdm_auto(total=4) as t:
        for i in product(range(2), range(2), tqdm_class=tqdm_auto):
            pass
    assert t.n == 4
    assert t.total == 4

# Generated at 2022-06-24 09:54:41.294003
# Unit test for function product
def test_product():
    import random

# Generated at 2022-06-24 09:54:47.935325
# Unit test for function product
def test_product():
    """
    Unit test for `product`
    """
    from ._version import get_versions
    __version__ = get_versions()['version']
    del get_versions

    import numpy as np

# Generated at 2022-06-24 09:54:54.961400
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    from .tqdm import tqdm
    from .._tqdm import _range

    kwargs = dict(total=5, desc="Total", ascii=True)
    for prod in (product, tqdm.itertools.product):  # noqa: F811
        L = []

# Generated at 2022-06-24 09:55:02.665585
# Unit test for function product
def test_product():
    """
    Unit-test for `product`.
    """
    from .tests_tqdm import with_setup, PretendMock, StringIO

    with with_setup(PretendMock(dict(write=None)).__enter__,
                    PretendMock(dict(write=None)).__exit__):
        for i in product(range(10), tqdm_class=tqdm_auto):
            pass

    with with_setup(tqdm_auto.__enter__, tqdm_auto.__exit__):
        s = StringIO()
        for i in product(range(10), tqdm_class=tqdm_auto.write(file=s)):
            pass

# Generated at 2022-06-24 09:55:12.693336
# Unit test for function product
def test_product():
    from .tests import TestCase, __version__

    class TestProduct(TestCase):

        def test_product(self):
            with tqdm_auto(total=0) as t:
                with self.assertRaises(TypeError):
                    for i in product(tqdm_class=tqdm_auto):
                        pass
            with tqdm_auto(total=0) as t:
                for i in product([1], [1], tqdm_class=tqdm_auto):
                    pass
                self.assertEqual(t.total, 1)
            with tqdm_auto(total=0) as t:
                for i in product([1, 2], [1], tqdm_class=tqdm_auto):
                    pass
                self.assertEqual(t.total, 2)

# Generated at 2022-06-24 09:55:21.125834
# Unit test for function product
def test_product():
    from pkg_resources import resource_filename
    from .. import TqdmTypeError
    from numpy.testing import assert_raises
    # 1
    assert_raises(
        TqdmTypeError,
        product, [1, 2], tqdm_class=None)
    # 2
    assert_raises(
        TqdmTypeError,
        product, [1, 2], tqdm_class=int)
    # 3
    assert_raises(
        TqdmTypeError,
        product, [1, 2], tqdm_class=resource_filename(__name__, "__init__.py"))
    # 4
    import sys
    assert_raises(
        TqdmTypeError,
        product, [1, 2], tqdm_class=sys.stdout)

# Generated at 2022-06-24 09:55:28.911635
# Unit test for function product
def test_product():
    import sys
    iter_1 = [1, 2, 3]
    iter_2 = ['A', 'B', 'C']
    result = product(iter_1, iter_2, tqdm_class=tqdm_auto)
    exp_result = [(1, 'A'), (1, 'B'), (1, 'C'), (2, 'A'), (2, 'B'), (2, 'C'),
                  (3, 'A'), (3, 'B'), (3, 'C')]
    assert result == exp_result, 'itertools.product wrapper failed'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:55:37.854300
# Unit test for function product
def test_product():
    """
    Unit test for function product().
    """
    import nose
    assert list(product(range(3), range(3), range(3))) == list(itertools.product(range(3), range(3), range(3)))
    assert list(product(range(5), range(4), range(2))) == list(itertools.product(range(5), range(4), range(2)))
    assert list(product(range(3), range(3), range(3), tqdm_class=None)) == list(itertools.product(range(3), range(3), range(3)))
    assert list(product(range(5), range(4), range(2), tqdm_class=None)) == list(itertools.product(range(5), range(4), range(2)))

# Generated at 2022-06-24 09:55:47.268342
# Unit test for function product

# Generated at 2022-06-24 09:55:55.144868
# Unit test for function product
def test_product():
    with tqdm_auto(total=10 * 2 * 3 * 2) as t:
        for i in product((1, 2), (3, 4), tqdm_class=tqdm_auto):
            pass
        assert t.total == 10
        for i in product(range(10), tqdm_kwargs={"total": 10}):
            pass
        assert t.total == 10
        for i in product(range(10), tqdm_class=tqdm_auto):
            pass
        assert t.total is None

# Generated at 2022-06-24 09:56:03.231295
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .utils import FunnyTqdmTypeError
    # Dummy class for testing
    class DummyTqdmClass(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def update(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def close(self):
            return

    # In any case, iterables must be preserved
    iterables = [[1, 2], [2, 3, 4], [5, 6]]
    res = list(product(*iterables, tqdm_class=DummyTqdmClass))

# Generated at 2022-06-24 09:56:13.884419
# Unit test for function product
def test_product():
    """Unit test for tqdm.itertools"""
    assert list(product([1, 2], repeat=3)) == list(itertools.product([1, 2], repeat=3))

    assert list(product([1, 2], repeat=3, tqdm_class=None)) == list(itertools.product([1, 2], repeat=3))

    assert list(product([1, 2], repeat=3, tqdm_class=tqdm_auto)) == list(itertools.product([1, 2], repeat=3))

# Generated at 2022-06-24 09:56:23.030008
# Unit test for function product
def test_product():
    """
    Example of `itertools.product`:
        >>> pool = ['1', '2', '3']
        >>> p = product(pool, pool, tqdm_class=tqdm.tqdm_notebook, total=9)
        >>> for i in p:
        ...     print(i)
        ('1', '1', '1')
        ('1', '1', '2')
        ('1', '1', '3')
        ('1', '2', '1')
        ('1', '2', '2')
        ('1', '2', '3')
        ('1', '3', '1')
        ('1', '3', '2')
        ('1', '3', '3')
    """
    from ..std import tqdm, trange

# Generated at 2022-06-24 09:56:31.857075
# Unit test for function product
def test_product():
    """
    Unit test of `tqdm.itertools.product`.
    """
    from ..utils import nocolour
    from ._utils import DiscreteTimer

    # First test: work as expected
    # NB: using nocolour() as we really need to catch the exact output
    with DiscreteTimer(unit="s", leave=True):
        with tqdm_auto(product(range(5),  range(6),
                               range(7),  range(8),
                               range(9),  range(10),
                               range(11), range(12),
                               range(13), range(14))) as t:
            for i in t:
                pass
    res = nocolour(t.__dict__["_instant_dynamic_msg"])

# Generated at 2022-06-24 09:56:34.896466
# Unit test for function product
def test_product():
    """
    Unit test.
    """
    from .gui import tqdm
    for _ in tqdm.product([1, 2], ['a', 'b'], tqdm_class=tqdm):
        pass

# Generated at 2022-06-24 09:56:43.636326
# Unit test for function product
def test_product():
    """Unit test"""
    from ..utils import FormatMixin
    from . import trange

    fmt = FormatMixin()

    # Test the product wrapper
    assert list(product('ABC', '12', tqdm_class=tqdm_auto)) == \
        list(itertools.product('ABC', '12'))
    assert list(product('ABC', '12', tqdm_class=trange)) == \
        list(itertools.product('ABC', '12'))

    # Test the iterator
    it = product(range(3), range(3), range(1000000), tqdm_class=tqdm_auto)
    assert next(it) == (0, 0, 0)
    assert next(it) == (0, 0, 1)
    assert next(it) == (0, 1, 0)

# Generated at 2022-06-24 09:56:52.989774
# Unit test for function product
def test_product():
    from .compatibility import StringIO
    import sys
    import unittest
    from itertools import product

    from .tests_tqdm import discretize_size, SlowTestCase, closing, tqdm

    class ProductTest(SlowTestCase):

        def test_product(self):
            """Test product"""
            with closing(StringIO()) as our_file:
                # Test special case: no iterables
                list(tqdm([]))
                list(tqdm(iter([])))
                # Test special case: 1 iterable
                list(tqdm(range(3)))
                # Regular test

# Generated at 2022-06-24 09:56:55.219319
# Unit test for function product
def test_product():
    with tqdm_auto(unit="i", desc="product", miniters=1) as t:
        for i, j in product(range(10), range(3)):
            t.update()

# Generated at 2022-06-24 09:57:04.014613
# Unit test for function product
def test_product():
    from .tests import TestCase

    with TestCase(unit="i") as t:
        for i in product(range(4), tqdm_class=t.cls):
            pass
        for i in product(range(4), tqdm_class=t.cls, desc="desc"):
            pass
        for i in product(range(4), range(5), tqdm_class=t.cls, ascii=True,
                         unit_scale=True, total=20):
            pass

# Generated at 2022-06-24 09:57:14.706363
# Unit test for function product
def test_product():
    """
    Test for function `product`.
    """
    from tqdm.contrib.test import utils

    def go(l):
        """
        Test product(l)
        """
        utils.TestWrapper(itertools.product(l)).test()

    def test_iterator():
        """
        Test `itertools.product` itself
        """
        assert list(itertools.product([])) == [(None,)]
        assert list(itertools.product([1, 2, 3])) == \
            [(1,), (2,), (3,)]

# Generated at 2022-06-24 09:57:22.910108
# Unit test for function product
def test_product():
    from ..tests import IN_CI_PYPY
    from ..utils import FormatCustomText
    from .utils import closing
    from .trange import trange
    from .std import tqdm
    from .std import tnrange
    from .std import trange
    from .std import tqdm_pandas
    from .std import tnrange_pandas
    from .std import trange_pandas
    from .gui import tqdm_gui
    from .gui import tnrange_gui
    from .gui import trange_gui
    from .gui import tgrange
    from .gui import tqdm_gui
    from .gui import tnrange_gui
    from .gui import trange_gui
    from .gui import tgrange
    from .gui import tqdm_notebook

# Generated at 2022-06-24 09:57:28.860056
# Unit test for function product
def test_product():
    "Test product with empty iterable and with counting"
    total = 0
    for _ in product([1, 2, 3], tqdm_class=tqdm_auto):
        total += 1
    assert total == 6

    # tqdm_class=None
    total = 0
    for _ in product([1, 2, 3], tqdm_class=None):
        total += 1
    assert total == 6

# Generated at 2022-06-24 09:57:41.031827
# Unit test for function product
def test_product():
    from ..auto import trange
    from .utils import _range

    # First, test with lists as inputs
    for t in [tqdm_auto, trange]:
        for n in _range(10):
            for m in _range(10):
                assert list(t.product(range(n), range(m))) == list(itertools.product(range(n), range(m)))
    # Then, test with iterators (can only be done with `trange`)
    for n in _range(10):
        for m in _range(10):
            assert list(trange.product(range(n), range(m))) == list(itertools.product(range(n), range(m)))

# Generated at 2022-06-24 09:57:45.345626
# Unit test for function product
def test_product():
    """Simple unit test for tqdm.itertools.product"""
    from nose.plugins.skip import SkipTest
    raise SkipTest("TODO")


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:57:49.229988
# Unit test for function product
def test_product():
    """Test the tqdm `product` function"""
    out = list(product(range(10), range(10)))
    assert len(out) == 100
    out = list(product(range(10), range(10), tqdm_class=None))
    assert len(out) == 100
    out = list(product(range(10), range(10)))
    assert len(out) == 100

# Generated at 2022-06-24 09:57:53.559279
# Unit test for function product
def test_product():
    """Test function product with 1+ iterables."""
    product_iter = product(range(5), range(5), range(5),
                           tqdm_class=tqdm_auto, unit_scale=True,
                           desc="product 1")
    total = 0
    for i, j, k in product_iter:
        assert i + j + k == total
        total += 1
    assert total == 125

# Generated at 2022-06-24 09:58:01.474153
# Unit test for function product
def test_product():  # pragma: no cover
    from .main import main
    from .utils import format_sizeof

    a = [1, 2]
    b = ['a', 'b']
    c = ["123", "456", "789"]
    d = range(1000)
    for i in product(a, b, c, d):
        pass
    print("Product:")
    print("  total =", format_sizeof(sum(len(i) for i in [a, b, c, d])))
    print("  result =", format_sizeof(sum(len(i) for i in [a, b, c, d])))
    for i in product(a, b, c, d, tqdm_class=main):
        pass
    print("Product (main):")

# Generated at 2022-06-24 09:58:11.681684
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    from .tests import _IS_PYPY
    from .tests import closing
    from .tests import FakeTqdmFile

    def basic(it):
        for i in it:
            pass

    if _IS_PYPY:
        it = product((1, 2), (3, 4),
                     tqdm_class=tqdm_auto)
    else:
        with closing(FakeTqdmFile()) as f:
            it = product((1, 2), (3, 4),
                         tqdm_class=tqdm_auto, file=f)
        assert "itertools.product" in f.getvalue()


# Generated at 2022-06-24 09:58:18.452967
# Unit test for function product

# Generated at 2022-06-24 09:58:21.246804
# Unit test for function product
def test_product():
    """Test for function product."""
    from ..main import tqdm
    list(tqdm(product(range(4), range(4), tqdm_class=tqdm)))

# Generated at 2022-06-24 09:58:31.718100
# Unit test for function product
def test_product():
    """
    Simple unit test for function `product`.
    """
    from tqdm._utils import _term_move_up
    from ._utils import TestCase
    assert tuple(product(range(10))) == tuple(itertools.product(range(10)))
    assert tuple(product(range(10), repeat=2)) == \
        tuple(itertools.product(range(10), repeat=2))
    assert tuple(product(range(10), repeat=3)) == \
        tuple(itertools.product(range(10), repeat=3))

    class Tqdm(TestCase):
        def __call__(self, *args, **kwargs):
            """
            Wraps tqdm call.
            """
            self.tqdm(*args, **kwargs)

    tqdm = Tqdm()
   

# Generated at 2022-06-24 09:58:45.590826
# Unit test for function product
def test_product():
    try:
        from collections import Iterator
    except ImportError:
        Iterator = object
    from .tests_tqdm import closing, pretest

    ######################################
    # Test for class iterators
    class TestGen(Iterator):
        """ TestGenerator """
        def __init__(self, it, last=False):
            self.last = last
            self.it = it

        def __iter__(self):
            return self

        def __next__(self):
            return self.it.__next__()

        def next(self):
            return self.__next__()

    ######################################
    # Test for function iterators

    def test_gen():
        """ TestGenerator """
        it = iter(range(5))
        for i in range(5):
            yield next(it)

   

# Generated at 2022-06-24 09:58:56.029290
# Unit test for function product
def test_product():
    """Unit test for function product"""
    # Setup
    try:
        itertools.product
    except AttributeError:
        # Skip if `itertools` package is not present
        return

    # Test with all types of tqdm arguments
    for n in range(3):
        for positional in ["", "itertools"]:
            if n and positional:
                continue  # Skip useless combinations
            if positional:
                kwargs = {}
                args = (positional, 1, 2, 3)
            else:
                kwargs = {"desc": "Test-Product"}
                args = (1, 2, 3)

            for unit in ["", "iterations", "iters"]:
                if n and unit:
                    continue  # Skip useless combinations

                kwargs["unit"] = unit