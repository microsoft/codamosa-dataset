

# Generated at 2022-06-24 09:48:55.660562
# Unit test for function product
def test_product():
    from .tests import TestCase

    assert (list(product(range(10), range(10), range(10), tqdm_class=TestCase))
            == list(itertools.product(range(10), range(10), range(10))))
    assert (set(product(range(10), range(10)))
            == set(itertools.product(range(10), range(10))))

# Generated at 2022-06-24 09:49:05.523373
# Unit test for function product
def test_product():
    """ Test """
    import numpy as np
    from ..pandas import pandas

    # Test simple product
    with pandas(total=12, miniters=1, mininterval=1, unit="int") as pbar:
        for i in product(range(1, 4), range(1, 4), range(1, 4)):
            assert i == np.array([1, 1, 1])
            pbar.update()
        assert pbar.n == 12
        assert pbar.n == pbar.total
        assert pbar.n == pbar.smoothed_n

    # Test iterable length handling

# Generated at 2022-06-24 09:49:12.725705
# Unit test for function product
def test_product():
    from .tests import T, t2
    from os import getpid
    from .utils import FormatCustomTextTest, format_dict
    from .auto import trange, tqdm

    ##################################################
    # Tests
    ##################################################
    with T("3x3"):
        with T("'int' bars"):
            for i in product(range(3), range(3), range(3)):
                pass

        with T("'float' bars"):
            for i in product(range(3), range(3), range(3),
                             tqdm_class=tqdm):
                pass

        with T("'int' bars"):
            for i in product(range(3), range(1, 3), range(2, 5)):
                pass


# Generated at 2022-06-24 09:49:23.143893
# Unit test for function product
def test_product():
    from random import randint
    from time import sleep
    from .utils import FormatCustomText

    max_sleep = 0.06
    for n_iters in [2, 3, 5, 10]:
        for n_args in [1, 2, 5, 10]:
            for n_iters_per_arg in [1, 2, 5, 10]:
                for ascii in [True, False]:
                    flat_it = [randint(0, 100) for _ in range(n_iters)]
                    arg_it = (
                        [flat_it[i:i + n_iters_per_arg]
                         for i in range(0, n_iters, n_iters_per_arg)] *
                        n_args)
                    expected = list(itertools.product(*arg_it))
                    tqdm_

# Generated at 2022-06-24 09:49:24.364858
# Unit test for function product
def test_product():
    from .tqdm import trange
    for i in trange(10):
        for j in product(range(3), range(3)):  # NOQA
            pass

# Generated at 2022-06-24 09:49:35.241199
# Unit test for function product
def test_product():
    from .utils import FormatMixin
    from .tests import pretest_posttest_monkeypatch

# Generated at 2022-06-24 09:49:39.423279
# Unit test for function product
def test_product():
    """
    Test for function `product`.
    """
    for i, _ in enumerate(
            product(range(10), range(10), tqdm_class=tqdm_auto)):
        assert i == i
    assert i == 99

# Generated at 2022-06-24 09:49:49.876604
# Unit test for function product
def test_product():
    # test that they are the same, regardless of bar position
    with tqdm_auto(product([], [], ascii=True),
                   ascii=True) as a:
        with tqdm_auto(product([], []),
                       ascii=True) as b:
            assert list(a) == list(b)
    # test all the arguments of product
    with tqdm_auto(product('ABC', 'xy', 'z'),
                   ascii=True, leave=False) as a:
        assert list(a) == ['Az', 'Bz', 'Cz', 'Ax', 'Bx', 'Cx', 'Ay', 'By', 'Cy']


# Generated at 2022-06-24 09:49:54.018235
# Unit test for function product
def test_product():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    from tests_tqdm import pretest_posttest_monkeypatch

    with pretest_posttest_monkeypatch():
        list(tqdm_gui(product('ABCD', 'xy'), total=9))

# Generated at 2022-06-24 09:49:58.141158
# Unit test for function product
def test_product():
    """Test function product"""
    from pytest import approx

    with tqdm_auto(total=120) as t:
        for i in product(range(10), range(10), range(10), tqdm_class=tqdm_auto):
            assert i == (i[0], i[1], i[2])
            assert len(i) == 3
            t.update()

# Generated at 2022-06-24 09:50:04.030566
# Unit test for function product
def test_product():
    from .tests import TestCase, closing

    with closing(TestCase()) as t:
        with t.assertRaises(TypeError):
            for _ in t.tqdm(product(range(3), 'ABCD'), total=None):
                pass
        for _ in t.tqdm(product(range(3), 'ABCD'), total=12):
            pass
        for _ in t.tqdm(product(range(3), 'ABCD'), total=12,
                        miniters=12, mininterval=0, smoothing=False):
            pass
        for _ in t.tqdm(product(range(3), 'ABCD'), total=None,
                        mininterval=0, smoothing=False):
            pass

# Generated at 2022-06-24 09:50:12.716998
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from ..std import product as tqdm_product
    from ..pandas import tqdm_pandas
    import pandas as pd
    import unittest
    import io

    class Tests(unittest.TestCase):
        def test_product(self):
            with tqdm_pandas(tqdm_product(
                    range(10), range(100)
                ), file=io.StringIO()
            ) as t:
                t.get_lock().readline()

                t.update(1)
                t.update(2)
                self.assertEqual(t.n, 3)
                self.assertEqual(t.total, 1000)

# Generated at 2022-06-24 09:50:19.543025
# Unit test for function product
def test_product():
    """
    Invokes `product()` for testing purposes.
    """
    from time import sleep
    from .tests import pretest_posttest

    def add(a, b):
        sleep(0.01)
        return a + b


# Generated at 2022-06-24 09:50:26.589935
# Unit test for function product
def test_product():
    """
    Test suite for itertools.product.
    """
    with tqdm_auto(total=10 * 9 * 2 * 5 * 2 * 36 * 9 * 5 * 2) as t:
        for i in product(range(10), range(9), range(2),
                         range(5), range(2),
                         "abcdefghijklmnopqrstuvwxyz",
                         "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                         range(9), range(5), range(2)):
            assert isinstance(i, tuple)
            assert len(i) == 10
            t.update()

# Generated at 2022-06-24 09:50:37.500237
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    from .main import tqdm
    from .tqdm_pandas import tqdm_pandas

    with tqdm.configuration.gui():
        try:
            list(product(range(10), tqdm_class=tqdm.std))
        except Exception:
            pass
    try:
        list(product(range(10), tqdm_class=tqdm.std))
    except Exception:
        pass

    try:
        import pandas
    except ImportError:
        pass
    else:
        from .tqdm_pandas import tqdm_pandas

# Generated at 2022-06-24 09:50:47.220634
# Unit test for function product
def test_product():
    import sys
    import numpy as np
    from ..utils import _range
    from ..auto import tqdm_notebook as tqdm

    # Without tqdm
    it = product(_range(1, 20), _range(1, 20))

    res = list(it)
    assert res == list(itertools.product(_range(1, 20), _range(1, 20)))
    print(len(res))

    # With tqdm
    it = product(_range(1, 20), _range(1, 20), tqdm_class=tqdm)

    res = list(it)
    assert res == list(itertools.product(_range(1, 20), _range(1, 20)))
    print(len(res))

    # With tqdm and total=False

# Generated at 2022-06-24 09:50:48.721538
# Unit test for function product
def test_product():
    with tqdm_auto(iterable=product([1, 2], "ab", total=None)) as t:
        for i in range(6):
            t.update()

# Generated at 2022-06-24 09:50:58.793109
# Unit test for function product
def test_product():
    from ..utils import format_sizeof

    from itertools import product
    from .utils import FormatSizeofTest

    f = FormatSizeofTest()
    test_tqdm = tqdm_auto(product(f.numbers, repeat=32))
    for v in test_tqdm:
        assert v == (12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
                     12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
                     12, 12, 12, 12)
    assert test_tqdm.n == format_sizeof(f.numbers) ** 32

if __name__ == "__main__":
    try:
        test_product()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 09:51:06.549496
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    print("Testing", format_sizeof(product))
    from .tqdm_test_cases import \
        tnrange, trange, tqdm, tqdm_gui, tgrange, tqdm_notebook

# Generated at 2022-06-24 09:51:08.678926
# Unit test for function product
def test_product():
    """Test function product"""
    assert list(product("ABCDEF", repeat=2)) == list(
        itertools.product("ABCDEF", repeat=2))

# Generated at 2022-06-24 09:51:10.684092
# Unit test for function product
def test_product():
    for i in product(range(6), ['a', 'b', 'c'], [":D", ":/"]):
        pass

# Generated at 2022-06-24 09:51:19.204187
# Unit test for function product
def test_product():
    from ._tqdm_test_case import _TestCase
    from ..utils import FormatCustomText, UnknownLength

    for iterable in ((),
                     (1, 2, 3),
                     (i for i in range(10)),
                     range(10)):
        for iterable2 in ((),
                          (1, 2, 3),
                          (i for i in range(10)),
                          range(10)):
            with _TestCase() as tc:
                tc.assertEqual(
                    list(product(iterable, iterable2, tqdm_class=tc.Mock())),
                    list(itertools.product(iterable, iterable2)))


# Generated at 2022-06-24 09:51:28.558694
# Unit test for function product
def test_product():
    '''Test for the product wrapper'''
    outer = [1, 2, 3]
    inner = ['a', 'b', 'c']
    assert list(product(outer, inner)) == [
        (1, 'a'), (1, 'b'), (1, 'c'),
        (2, 'a'), (2, 'b'), (2, 'c'),
        (3, 'a'), (3, 'b'), (3, 'c')
    ]

    outer = [1, 2, 3]
    inner = ['a', 'b', 'c']

# Generated at 2022-06-24 09:51:38.865825
# Unit test for function product
def test_product():
    assert list(product(range(5))) == [
        (0,), (1,), (2,), (3,), (4,)]
    assert list(product(range(2), range(2))) == [
        (0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(2), range(2), range(2))) == [
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-24 09:51:46.463133
# Unit test for function product
def test_product():
    import sys
    assert list(product([1, 2, 3], ['a', 'b'], tqdm_class=tqdm_auto)) == [
        (1, 'a'), (1, 'b'), (2, 'a'), (2, 'b'), (3, 'a'), (3, 'b')]
    assert list(product(['a', 'b'], tqdm_class=tqdm_auto)) == [('a',), ('b',)]
    assert list(product([0], repeat=3, tqdm_class=tqdm_auto)) == [(0, 0, 0)]
    assert list(product([0, 1], repeat=2, tqdm_class=tqdm_auto)) == [
        (0, 0), (0, 1), (1, 0), (1, 1)]

# Generated at 2022-06-24 09:51:51.573026
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import unittest
    import io
    import sys
    from .utils import closing

    class Tests(unittest.TestCase):
        def test_basic(self):
            with closing(io.StringIO()) as our_file, closing(
                    io.StringIO()) as true_file:
                with tqdm_auto(file=our_file) as t:
                    for _ in product(range(3), range(3), range(3),
                                     tqdm_class=tqdm_auto, file=true_file):
                        pass
                our_lines = our_file.getvalue().split("\n")
                true_lines = true_file.getvalue().split("\n")
                # Check bar output
                self.assertIn('|', true_lines[0])
               

# Generated at 2022-06-24 09:52:01.766627
# Unit test for function product
def test_product():
    from ..utils import _range_of_progressbar
    from .tests_tqdm_wget import test_wget

    for class_ in ['tqdm', 'trange', 'tqdm_notebook']:
        for nested in [False, True]:
            # Don't use trange
            if nested and class_ == 'trange':
                continue

            for total in (None, 10):  # , 0)):
                for leave in (True, False):
                    for dynamic_ncols in (True, False):
                        fd = test_wget()
                        if nested:
                            with tqdm_auto(total=10, file=fd,
                                           nested=True) as pbar:
                                # r=range(10)
                                r = _range_of_progressbar(10)
                               

# Generated at 2022-06-24 09:52:11.650221
# Unit test for function product
def test_product():
    # Test for correct result
    assert list(product('AB', '12')) == [('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]

    # Test for tqdm_class
    assert list(product('AB', '12', tqdm_class=None)) == [('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]

    # Test for total
    with tqdm_auto(total=4) as t:
        assert list(product('AB', '12', tqdm_class=tqdm_auto, total=100)) == [('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]

# Generated at 2022-06-24 09:52:15.664869
# Unit test for function product
def test_product():
    """
    Unit test for itertools.product().
    """
    for i in range(10):
        for j in range(5):
            for k in range(3):
                assert (i, j, k) == next(product(range(i), range(j), range(k)))

# Generated at 2022-06-24 09:52:23.260592
# Unit test for function product
def test_product():
    """Run unit tests for function product."""
    from .tests import TqdmTestCase
    from .tests.utils import in_place
    import sys
    if sys.version_info[0] == 2:
        return  # Skip for Python 2
    with TqdmTestCase() as tc:
        assert tc.tqdm(product(range(i), repeat=2), desc='units') == \
            list(itertools.product(range(i), repeat=2))
        assert in_place(
            tc.tqdm(), testimport=None, quiet=True, tqdm_class=None,
            tqdm_kwargs={"unit": "test"},
            iterable=list(product(range(i), repeat=2))) == \
            list(itertools.product(range(i), repeat=2))


# Generated at 2022-06-24 09:52:28.486725
# Unit test for function product
def test_product():
    """
    Unit test fonction product.
    """
    from .tests import TestCase
    from ..utils import format_sizeof

    class TestProduct(TestCase):
        def test_product(self):
            pbars = [tqdm_auto(range(10)),
                     tqdm_auto(['a', 'b'])]
            self.assertEqual(len(list(product(*pbars))), 20)

# Generated at 2022-06-24 09:52:34.025338
# Unit test for function product
def test_product():
    import sys
    a = [1, 2, 3, 4, 5]

    try:
        from itertools import izip_longest as zip_longest
        itertools_zip_longest = True
    except ImportError:
        from itertools import zip_longest
        itertools_zip_longest = False

    try:
        list(tqdm_auto.itertools.product(a, repeat=2))
    except TypeError:
        assert itertools_zip_longest
    else:
        assert not itertools_zip_longest

    with tqdm_auto.tqdm(product(a, repeat=2), dynamic_ncols=True) as g:
        assert g.total == len(a)**2
        assert next(g) == (1, 1)


# Generated at 2022-06-24 09:52:43.075877
# Unit test for function product
def test_product():
    from nose.tools import assert_equals
    from numpy.random import permutation

    lst = range(10)
    ans = sum(1 for _ in product(lst))
    assert_equals(ans, 10)

    ans = sum(1 for _ in product(lst, lst))
    assert_equals(ans, 100)

    ans = sum(1 for _ in product(lst, lst, lst))
    assert_equals(ans, 1000)

    # permutation is just a nice iterator, not a list
    ans = sum(1 for _ in product(permutation(lst)))
    assert_equals(ans, 10)

    ans = sum(1 for _ in product(permutation(lst), lst))
    assert_equals(ans, 100)


# Generated at 2022-06-24 09:52:51.702123
# Unit test for function product
def test_product():
    """
    Unit test of tqdm.itertools.product(...)

    Returns
    -------
    success: bool
        True if tests passed
    """
    # Check list products
    assert (set(product([], ["a"])) ==
            set([()]))
    assert (set(product(["a"], [])) ==
            set([()]))
    assert (set(product(["a"], ["b"])) ==
            set([("a", "b")]))
    assert (set(product(["a", "b"], ["c"])) ==
            set([("a", "c"), ("b", "c")]))

# Generated at 2022-06-24 09:53:05.437601
# Unit test for function product
def test_product():
    with tqdm_auto(total=0) as t:
        assert list(product(range(2), repeat=2)) == [(x, y) for x in range(2)
                                                     for y in range(2)]
        assert list(product(range(2), tqdm_class=t.__class__)) == [0, 1]
        assert list(product(range(2), "ab", tqdm_class=t.__class__)) == \
            [(0, 'a'), (0, 'b'), (1, 'a'), (1, 'b')]


if __name__ == "__main__":
    from .common_tests import (_TestCase, TestCase, get_entries,
                               get_entries_slow, check_leave)
    from .test_tqdm import pretest_posttest

# Generated at 2022-06-24 09:53:15.202473
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText

    test_iterables = (range(10), range(10), range(10))
    test_total = 1
    for i in test_iterables:
        test_total *= len(i)

    def test_result(iterable, *args, **kwargs):
        for i in iterable:
            pass
    test_kwargs = dict(
        desc="test_product", total=test_total,
        bar_format=FormatCustomText("Processing: {l_bar}"),
        ncols=100, ascii=False, disable=False, smoothing=None)
    test_kwargs['leave'] = True
    import tqdm
    # test_result(product(*test_iterables, **test_kwargs), **test_kwargs)

# Generated at 2022-06-24 09:53:23.895199
# Unit test for function product
def test_product():
    """
    Unit test for function product()
    """
    import numpy as np
    from ..utils import eval_tqdm_kwargs
    from ..std import tqdm_std
    list1 = [1, 2, 3]
    list2 = [4, 5, 6]
    list3 = [7, 8, 9]
    list4 = ['a', 'b', 'c']
    list5 = ['d', 'e', 'f']

    # test default tqdm
    res = []
    for x in product(list1, list2, list3, list4, list5):
        res.append(x)
    assert res == list(itertools.product(list1, list2, list3, list4, list5))

    # test std tqdm
    tqdm_kwargs = eval_

# Generated at 2022-06-24 09:53:28.117863
# Unit test for function product
def test_product():
    import numpy

    n = numpy.arange(3)
    n2 = numpy.arange(3)
    pbar = product(n, n2)
    for (i, j) in pbar:
        assert((i, j) in zip(n, n2))

# Generated at 2022-06-24 09:53:35.966246
# Unit test for function product
def test_product():
    from ._utils import closing, FakeTQDM
    for tqdm_class in [tqdm_auto, FakeTQDM]:
        assert list(product([1, 2, 3], [4, 5, 6], tqdm_class=tqdm_class)) \
            == [(1, 4), (1, 5), (1, 6),
                (2, 4), (2, 5), (2, 6),
                (3, 4), (3, 5), (3, 6)]

# Generated at 2022-06-24 09:53:46.317070
# Unit test for function product
def test_product():
    """Unit test for function `tqdm_itertools.product`."""
    from .tests_tqdm import lrange
    from . import trange
    from .utils import format_sizeof
    from time import sleep

    for n, k, l in product(lrange(6), lrange(4), lrange(5)):
        sleep(0.01)

    for n, k, l in product(lrange(6), lrange(4), lrange(5),
                           tqdm_class=trange):
        sleep(0.01)

    for n, k, l in product(lrange(6), lrange(4), lrange(5),
                           tqdm_class=trange, dynamic_ncols=True):
        sleep(0.01)


# Generated at 2022-06-24 09:53:54.645048
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests import get_null_tqdm

# Generated at 2022-06-24 09:53:56.322658
# Unit test for function product
def test_product():
    return len(list(product([1, 2, 3], [4, 5, 6], tqdm_class=None)))

# Generated at 2022-06-24 09:54:04.099410
# Unit test for function product
def test_product():
    from .itertools import product
    from .tests_tqdm_class import _range_iter, _NoLenIterable

    # Test basic product
    assert list(product(
        range(3),
        _range_iter(3),
        _range_iter(3),
        _range_iter(3),
    )) == [(i, j, k, l) for i in range(3) for j in range(3) for k in range(3)
                                                         for l in range(3)]

# Generated at 2022-06-24 09:54:16.353757
# Unit test for function product
def test_product():  # pragma: no cover
    from random import randrange
    from .tests_tqdm import with_setup, _range

    try:
        from collections.abc import Iterator
    except ImportError:
        from collections import Iterator
    from .utils import FormatSmartIter

    for sz in _range(1, 9):
        for reps in _range(1, sz):
            lst = [_range(1, sz)] * reps
            lst2 = lst[:]

            @with_setup(teardown=lambda: lst2.clear())
            def core(lst=lst, lst2=lst2, sz=sz):
                g1 = itertools.product(*lst)
                g2 = product(*lst2)

# Generated at 2022-06-24 09:54:25.484404
# Unit test for function product
def test_product():
    import random
    import io
    import sys
    from ..utils import format_sizeof
    from ..utils import format_interval
    from ..utils import format_meter

    def tsize(size):
        return format_sizeof(size, suffix="B")

    def tinterval(t):
        return format_interval(t, unit='s')

    def tmeter(n, total, elapsed):
        return format_meter(n, total, elapsed, unit='B', ncols=None)

    # Example using stram (stdout):

# Generated at 2022-06-24 09:54:36.467554
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    from multiprocessing import freeze_support, Pool
    import os

    freeze_support()
    i = 0
    for res in product(range(100), repeat=2, total=1000):
        # print(res)
        i += 1
    assert i == 1000

    pool = Pool()

    _ = [i for i in pool.imap_unordered(
        lambda x: x,
        product(
            range(100), repeat=2,
            tqdm_class=tqdm_auto,
            tqdm_kwargs={
                'total': 1000000,
                'miniters': 100000,
                'file': open(os.devnull, 'w')}),
        chunksize=10000)]

if __name__ == "__main__":
    test_

# Generated at 2022-06-24 09:54:41.133161
# Unit test for function product
def test_product():
    from .ssl import assert_same_bar
    it = product('ABCD', 'xy', tqdm_class=tqdm_auto)
    assert_same_bar(it, 'ABCD', 'xy')

    it = product('ABCD', 'xy', tqdm_class=tqdm_auto, total=8)
    assert_same_bar(it, 'ABCD', 'xy')

# Generated at 2022-06-24 09:54:45.178139
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from tqdm import tqdm
    from tqdm._tqdm import _range, TMonitor
    with TMonitor(leave=True):
        for a, b in product(_range(1000), _range(1000), tqdm_class=tqdm):
            pass

# Generated at 2022-06-24 09:54:51.895157
# Unit test for function product

# Generated at 2022-06-24 09:55:03.135891
# Unit test for function product
def test_product():
    """Test that `itertools.product` is wrapped properly"""
    import sys
    from ..std import mock
    with mock.patch.object(sys, 'stderr', new_callable=list) as stderr:
        list(product(range(2)))
    assert '2it [00:00, ?it/s]' in stderr[0]
    with mock.patch.object(sys, 'stderr', new_callable=list) as stderr:
        list(product(range(3)))
    assert '6it [00:00, ?it/s]' in stderr[0]
    with mock.patch.object(sys, 'stderr', new_callable=list) as stderr:
        list(product(range(2), range(2), range(2)))

# Generated at 2022-06-24 09:55:05.684350
# Unit test for function product
def test_product():
    from .base import _range

    for p in map(tuple, product(_range(10), _range(5))):
        assert sum(p) <= 14


if __name__ == "__main__":
    pass

# Generated at 2022-06-24 09:55:12.934483
# Unit test for function product
def test_product():
    """ Unit test for function product """
    from .tests import closing
    # XXX: test with **total**
    assert sum(1 for _ in product(['a', 'b', 'c'], repeat=2)) == 9

    # test with closing
    assert sum(1 for _ in closing(product(['a', 'b', 'c'], repeat=2))) == 9
    assert sum(1 for _ in closing(product(['a', 'b', 'c'], repeat=2),
                                  leave=False)) == 9
test_product()

# Generated at 2022-06-24 09:55:22.208504
# Unit test for function product
def test_product():
    """
        Unit test for function product
        :return:
    """
    import numpy as np
    it = product(range(3000),range(4000))
    a = np.array([i for i in it])
    assert np.array_equal(a[0], [0,0])
    assert np.array_equal(a[-1], [2999,3999])
    assert a.shape == (3000*4000,2)
    

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:55:30.508351
# Unit test for function product
def test_product():
    a = ['a', 'b']
    b = [1, 2, 3]
    c = ['x', 'y', 'z']
    for _ in product(a, b, c):
        pass

    for _ in product(a, b, c, tqdm_class=lambda **kwargs: None):
        pass

    try:
        product(a, tqdm_class=lambda **kwargs: None)
    except AttributeError:
        pass


# Generated at 2022-06-24 09:55:38.673247
# Unit test for function product
def test_product():
    from copy import copy
    from itertools import product as it_product
    from random import randint, choice
    g1 = [[[randint(-100, 100) for _ in range(randint(1, 3))]
           for _ in range(randint(1, 4))]
          for _ in range(randint(5, 10))]
    g2 = [[randint(-100, 100) for _ in range(randint(1, 3))]
          for _ in range(randint(5, 10))]
    g3 = [randint(-100, 100) for _ in range(randint(5, 10))]

# Generated at 2022-06-24 09:55:45.562324
# Unit test for function product
def test_product():
    """
    Test function `product`.
    """
    from ._count import tqdm
    it = tqdm.product(['a', 'b'], repeat=3)
    assert list(it) == [('a', 'a', 'a'), ('a', 'a', 'b'),
                        ('a', 'b', 'a'), ('a', 'b', 'b'),
                        ('b', 'a', 'a'), ('b', 'a', 'b'),
                        ('b', 'b', 'a'), ('b', 'b', 'b')]

# Generated at 2022-06-24 09:55:49.444838
# Unit test for function product
def test_product():
    from .main_classes import TqdmTypeError

    with TqdmTypeError():
        for _ in product(object()):
            pass

# Generated at 2022-06-24 09:55:58.594347
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.

    Run with::

        python -m tqdm.itertools
    """
    from ._utils import _range, format_sizeof, is_notebook

    if not is_notebook():
        # disable colour bar due to issue with range(0)
        it = product(range(10), range(20), range(100), tqdm_class=tqdm_auto)
        assert sum(1 for _ in it) == 10 * 20 * 100
        it = product(range(0))
        assert sum(1 for _ in it) == 0

    for i in _range(20):
        for j in _range(i):
            for k in _range(j):
                size = i * j * k

# Generated at 2022-06-24 09:56:08.132545
# Unit test for function product
def test_product():
    """
    Test function `product`
    """
    assert list(product([1], [2, 3])) == [(1, 2), (1, 3)]
    assert list(product([1, 2, 3], [4, 5, 6])) == [
        (1, 4),
        (1, 5),
        (1, 6),
        (2, 4),
        (2, 5),
        (2, 6),
        (3, 4),
        (3, 5),
        (3, 6),
    ]

# Generated at 2022-06-24 09:56:17.666728
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    for i in product(range(10),
                     range(10),
                     range(10),
                     range(10),
                     range(10),
                     range(10)):
        pass
    for i in product(range(10),
                     range(10),
                     range(10),
                     range(10),
                     range(10),
                     range(10),
                     tqdm_class=tqdm_auto):
        pass
    for i in tqdm_auto(itertools.product(range(10),
                                         range(10),
                                         range(10),
                                         range(10),
                                         range(10),
                                         range(10))):
        pass

# Generated at 2022-06-24 09:56:21.335308
# Unit test for function product
def test_product():
    """Unittest of product"""
    import numpy as np
    assert np.array_equal(
        list(product(range(10), range(10))),
        list(itertools.product(range(10), range(10))))

# Generated at 2022-06-24 09:56:24.732054
# Unit test for function product
def test_product():
    """Test `itertools.product` wrapper."""
    from ..tests import _test_iterable
    return _test_iterable('product')
if __name__ == '__main__':
    from ..tests import _test_iterable
    _test_iterable('product')

# Generated at 2022-06-24 09:56:28.926478
# Unit test for function product
def test_product():
    from random import randint
    for size in [0, 1, 16, 32, 1024]:
        ref = [randint(1, 10) for _ in range(size)]
        with tqdm_auto(unit_scale=True, unit='values', leave=False) as t:
            assert list(ref) == list(product(ref, tqdm_class=t))

# Generated at 2022-06-24 09:56:31.682815
# Unit test for function product
def test_product():
    t = tqdm_auto(product(range(10), range(10)), total=100)
    assert next(t) == (0, 0)
    assert t.n == 1
    assert t.total == 100

# Generated at 2022-06-24 09:56:35.371069
# Unit test for function product
def test_product():
    """Tests for `product`"""
    total = 0
    for i in product(range(3), range(3), range(3), tqdm_class=tqdm_auto):
        assert len(i) == 3
        total += 1
    assert total == 27

# Generated at 2022-06-24 09:56:45.917868
# Unit test for function product
def test_product():
    import sys
    from ..std import chunks
    from test_tqdm import with_setup

    @with_setup(pretest=lambda: None, posttest=lambda: None)
    def wrapper():
        total_list = [
            [list(chunks(range(100), 10))],
            [list(chunks(range(100), 10)), list(chunks(range(10), 1))],
            [list(chunks(range(100), 10)), list(chunks(range(10), 2))],
        ]
        for iterables in total_list:
            for i in product(*iterables):
                pass
            # check that unit has NOT been set
            assert sys.gettotalrefcount() > 0

        # Check total
        for iterables in total_list:
            for i in product(*iterables):
                pass


# Generated at 2022-06-24 09:56:51.915939
# Unit test for function product
def test_product():
    li = [(1, 2), (3, 4), (5, 6)]
    expected_result = [(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6), (2, 3, 5),
                       (2, 3, 6), (2, 4, 5), (2, 4, 6)]
    assert list(product(*li)) == expected_result
    assert list(product(*li, tqdm_class=None)) == expected_result

# Generated at 2022-06-24 09:56:55.668535
# Unit test for function product
def test_product():
    """
    Test function :func:`tqdm.itertools.product`
    """
    from .tests import _test_iters, _test_exception
    _test_iters(itertools.product, 'itertools.product', tqdm_wrap=product)
    _test_exception(itertools.product, 'itertools.product', tqdm_wrap=product)

# Generated at 2022-06-24 09:57:00.725751
# Unit test for function product
def test_product():
    """Test module `product`."""
    from numpy import allclose
    iterables = [range(3), range(3, 6)]
    res = list(product(*iterables))
    exp = [0, 1, 2, 3, 4, 5]
    assert allclose(res, exp)

# Generated at 2022-06-24 09:57:03.086427
# Unit test for function product
def test_product():
    assert tuple(product("a", "b")) == (("a", "b"),)
    assert tuple(product("ab", "12")) == (("a", "1"), ("a", "2"), ("b", "1"), ("b", "2"))

# Generated at 2022-06-24 09:57:09.909497
# Unit test for function product
def test_product():
    assert(list(product([], repeat=2)) == [])
    assert(list(product([1], repeat=2)) == [(1,1)])
    assert(len(list(product(range(10), repeat=5))) == 100000)

# Generated at 2022-06-24 09:57:17.164581
# Unit test for function product
def test_product():
    import sys
    from ..utils import format_sizeof

    test_it = product(*[range(i, i + 3) for i in range(100000)])
    try:
        for _ in test_it:
            pass
        assert (False)  # pragma: no cover
    except MemoryError:
        assert (True)
    assert (test_it.total == 100000000000)
    assert (format_sizeof(test_it.total) == "9.1 GB")

# Generated at 2022-06-24 09:57:25.405786
# Unit test for function product
def test_product():
    import numpy as np
    from ..utils import io

    with io.capture_output() as captured:
        for _ in product(range(10), range(10)):
            pass
    assert captured.getvalue() == ""

    with io.capture_output() as captured:
        for _ in product(range(10), range(10), tqdm_class=tqdm_auto):
            pass
    assert captured.getvalue() != ""

    with io.capture_output() as captured:
        for _ in product(range(10), range(10), tqdm_class=None):
            pass
    assert captured.getvalue() == ""

    # Simple test that repeats same products
    # (necessary due to internal caching of `itertools`)

# Generated at 2022-06-24 09:57:29.057423
# Unit test for function product
def test_product():
    from sys import stderr
    from time import sleep
    for t in [tqdm_auto, tqdm]:
        for i in t(product(range(10000), repeat=2), file=stderr):
            sleep(0.01)

# Generated at 2022-06-24 09:57:41.831541
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    from .utils import RandomIT
    from .tests import pretest_posttest
    a = list(range(10))
    for k, _total, kwargs in pretest_posttest(tqdm, product, a, a, **test_kwargs):
        assert k._total == _total
        assert k.miniters == 1
        assert k.leave == True

    a = list(range(10))
    for k, _total, kwargs in pretest_posttest(tqdm, product, a, a, **test_kwargs):
        assert k._total == _total

    a = RandomIT(10)

# Generated at 2022-06-24 09:57:52.775442
# Unit test for function product
def test_product():
    """ Tests `product()` function """
    from ..utils import format_sizeof
    from ._tqdm_gui import tqdm_notebook

    # Basic
    iterables = [list(range(100)), list(range(10))]
    res = product(
        *iterables,
        desc='itertools', ascii=False, miniters=1, mininterval=0.01,
        maxinterval=0.1, smoothing=0, dynamic_ncols=False, position=0,
        leave=True, file=None, ncols=None,
        bar_format=None, initial=0, total=None, postfix=None,
        unit_scale=False, unit='it', gui=False, nrows=None)

# Generated at 2022-06-24 09:57:58.209181
# Unit test for function product
def test_product():
    """Test product"""
    from ..__init__ import tqdm
    assert list(tqdm.product([1, 2], ['a', 'b'])) == [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b')]
    assert list(tqdm.product([1, 2], ['a', 'b'], tqdm_class=None)) == [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b')]

# Generated at 2022-06-24 09:58:08.167168
# Unit test for function product
def test_product():
    from .tests import _test_clean_exit, _test_out_to_in, _test_err_to_out
    from textwrap import dedent
    from sys import executable
    _test_clean_exit(dedent(r"""
    from tqdm import tqdm_notebook, tqdm_gui
    [i for i in tqdm_gui.product(range(10), tqdm_notebook(range(10)))]
    """))
    _test_out_to_in(dedent(r"""
    from tqdm import tqdm
    print([i for i in tqdm.product(range(10), range(10))])
    """), limit=15)

# Generated at 2022-06-24 09:58:10.892579
# Unit test for function product
def test_product():
    """ Test wrapping itertools.product """
    import sys
    from .tests import test_product
    test_product(sys.modules[__name__])

# Generated at 2022-06-24 09:58:17.933381
# Unit test for function product
def test_product():
    from .tests import PretendNonGenerator
    iterables = [range(3)] * 3
    res = list(product(*iterables, tqdm_class=PretendNonGenerator))
    assert res == list(itertools.product(*iterables))
    if tqdm_auto.gui is False:
        # Mock the kwarg passed to PretendNonGenerator
        from unittest.mock import patch
        with patch("tqdm.tqdm.tqdm") as mock:
            product(*iterables)
            mock.assert_called_with(*iterables, total=27,
                                    desc='product', leave=False)
    else:
        # Mock the kwarg passed to PretendNonGenerator
        from unittest.mock import patch

# Generated at 2022-06-24 09:58:27.116851
# Unit test for function product
def test_product():
    import numpy as np

    from .tqdm_gui import tqdm
    from .utils import format_sizeof

    verbose = 1
    if verbose >= 2:
        def listofstr(t):
            if not isinstance(t, (tuple, list)):
                raise TypeError
            t = list(map(lambda x: str(x), t))
            return "[" + ", ".join(t) + "]"

        def sizeof(iterable):
            try:
                return format_sizeof(sum(map(sys.getsizeof, iterable)))
            except TypeError as e:
                return "?"
    else:
        sizeof = listofstr = lambda x: "?"

    from ..utils import _term_move_up
    from io import TextIOWrapper

# Generated at 2022-06-24 09:58:32.414481
# Unit test for function product
def test_product():

    assert tuple(product(range(10), range(10), tqdm_class=lambda x: x)) == tuple(
        itertools.product(range(10), range(10)))

    assert tuple(product(range(10), range(10), bar_format="{l_bar}",
                                            tqdm_class=lambda x: x)) == tuple(
        itertools.product(range(10), range(10)))
    return

# Generated at 2022-06-24 09:58:41.445608
# Unit test for function product
def test_product():
    for a in product([1, 2], [3, 4]):
        assert True
    for a in product([1, 2], [3, 4], tqdm_class=None):
        assert True
    for a in product([1, 2], [3, 4], tqdm_class=tqdm_auto):
        assert True

# Generated at 2022-06-24 09:58:44.997447
# Unit test for function product
def test_product():
    import random
    random.seed(1)
    sample = lambda: [random.randint(0, 100) for _ in range(10)]
    for _ in product(sample(), sample(), sample()):
        pass


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:58:50.097521
# Unit test for function product
def test_product():
    assert list(product([1, 2, 3], repeat=2)) == \
        list(itertools.product([1, 2, 3], repeat=2))
    assert list(product([1, 2, 3])) == \
        list(itertools.product([1, 2, 3]))

# Generated at 2022-06-24 09:58:57.939945
# Unit test for function product
def test_product():  # pragma: no cover
    from ..std import product
    i = product([1, 2], [3, 4], [5, 6])
    l = [0]
    for j in i:
        l[0] += 1
        # print(j)
    assert l[0] == len(list(itertools.product([1, 2], [3, 4], [5, 6])))

    i = product([1, 2], [3, 4], [5, 6], total=2)
    l = [0]
    for j in i:
        l[0] += 1
        # print(j)
    assert l[0] == 2


if __name__ == '__main__':  # pragma: no cover
    test_product()