

# Generated at 2022-06-24 09:48:55.429884
# Unit test for function product
def test_product():
    """Test for function product"""
    assert list(map(list, product('abc', range(3)))) == [
        ['a', 0], ['a', 1], ['a', 2],
        ['b', 0], ['b', 1], ['b', 2],
        ['c', 0], ['c', 1], ['c', 2]]
    assert list(product(range(2), repeat=3)) == [
        (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
        (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
    assert list(map(list, product("ab"))) == [
        ['a'], ['b']]

# Generated at 2022-06-24 09:49:00.620512
# Unit test for function product
def test_product():
    """
    Test the `tqdm.wrappers.product` function
    """
    list_in = [range(10), range(10)]
    list_out1 = list(product(*list_in))
    list_out2 = list(itertools.product(*list_in))
    assert list_out1 == list_out2

# Generated at 2022-06-24 09:49:05.326350
# Unit test for function product
def test_product():
    # Smoke test
    list(product([1, 2], ["a", "b"]))
    list(product([1, 2], ["a", "b"], tqdm_class=tqdm_auto))


if __name__ == "__main__":  # pragma: no cover
    from .main import _test_functions
    _test_functions(globals(), verbose=False)

# Generated at 2022-06-24 09:49:10.458913
# Unit test for function product
def test_product():
    def f(a, b, c):
        from time import sleep
        sleep(0.1)

    try:
        from tqdm import tqdm
        for i in tqdm(product('ABC', repeat=3), unit='B', smoothing=0.1,
                      bar_format="{l_bar}{bar}|"):
            f(*i)
    except Exception:  # pragma: no cover
        pass
    else:
        raise Exception("Raise an exception if not iterating over product()")

# Generated at 2022-06-24 09:49:20.968069
# Unit test for function product
def test_product():
    ''' Test function _product using itertools.product. '''
    import numpy as np
    np.random.seed(12345)
    num_iterables = np.random.randint(2, 5)
    iterables = []
    expectedResult = None
    for iterable_n in range(num_iterables):
        iterable = [0, 1]
        iterables.append(iterable)
        if expectedResult is None:
            expectedResult = list(itertools.product(iterable))
        else:
            expectedResult = [x + (y,) for x in expectedResult
                              for y in itertools.product(iterable)]

    kwargs = {}
    result = product(*iterables, **kwargs)
    assert result == expectedResult
    assert result.total == len(result)

# Generated at 2022-06-24 09:49:31.880854
# Unit test for function product
def test_product():
    from .tests import util
    from .tests.common import StringIOWrapper
    import sys
    import os

    for l in product("1234", repeat=4):
        assert isinstance(l, tuple)
        assert all(len(i) == 1 for i in l)
        assert all(i in "1234" for i in l)

    ncols = [None, 80, 5]
    for ncol in ncols:
        if ncol is None:
            stdout = sys.stdout.fileno()
        else:
            stdout = StringIOWrapper()
        fd = os.dup(stdout)

# Generated at 2022-06-24 09:49:36.709843
# Unit test for function product
def test_product():
    import sys
    for i, res in enumerate(tqdm(product([1, 2, 3], repeat=2), desc='product')):
        if i == 10:
            # len([1, 2, 3] ** 2) == 27
            assert len(list(res)) == 3
            # len([1, 2, 3] ** 3) == 27
            assert len(list(res)) == 3
            sys.stderr.write('PASS\n')

# Generated at 2022-06-24 09:49:47.059470
# Unit test for function product
def test_product():
    """
    Simple tests for tqdm.itertools.product
    """
    from ..auto import trange

    assert list(product(range(3), range(3))) == [
        (0, 0), (0, 1), (0, 2),
        (1, 0), (1, 1), (1, 2),
        (2, 0), (2, 1), (2, 2)
    ]
    assert list(product(range(3), range(3), tqdm_class=trange)) == [
        (0, 0), (0, 1), (0, 2),
        (1, 0), (1, 1), (1, 2),
        (2, 0), (2, 1), (2, 2)
    ]

# Generated at 2022-06-24 09:49:48.489404
# Unit test for function product
def test_product():
    from ..utils import FormatWrapBase, format_sizeof
    list(product(range(100), tqdm_class=FormatWrapBase, ascii=True,
                 unit=format_sizeof, unit_scale=True, total=100 * 100))

# Generated at 2022-06-24 09:49:56.650005
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import numpy as np
    with tqdm_auto(total=4) as bar:
        for _ in product(range(2), *map(np.array, (range(1), range(2)))):
            bar.update()

        assert bar.total == 4
        assert bar.n == 4
        assert bar.last_print_n == 4
        assert bar.last_print_refresh_time

        for _ in product(range(4), *map(np.array, (range(1), range(2)))):
            bar.update()

        assert bar.total == 4
        assert bar.n == 8
        assert bar.last_print_n == 4
        assert bar.last_print_refresh_time


# Generated at 2022-06-24 09:50:03.664501
# Unit test for function product
def test_product():
    from numpy.random import shuffle
    from itertools import repeat
    from ..std import numpy as np
    from ..utils import _range

    for tqdm_class in (tqdm_auto,):
        shuffle(list(range(10)))  # 1st shuffle is MUCH slower
        for iterable1 in ([], [0], list(range(10)), repeat(0, 10)):
            for iterable2 in ([], [0], list(range(10)), repeat(0, 10), list(
                    range(10))):
                for max_count in _range(len(iterable1) + len(iterable2) + 2):
                    a = list(product(iterable1, iterable2,
                                    tqdm_class=tqdm_class, total=max_count))

# Generated at 2022-06-24 09:50:05.612945
# Unit test for function product
def test_product():
    for i in product(range(5), tqdm_class=tqdm_auto):
        assert i[0] < 5
    for i in product(range(5), range(5), tqdm_class=tqdm_auto):
        assert i[0] < 5 and i[1] < 5

# Generated at 2022-06-24 09:50:14.839382
# Unit test for function product
def test_product():
    import random
    import math
    import nose

    with tqdm_auto(total=1) as t:
        # test range(2)
        total = 1
        for i in range(2):
            total *= i
            t.update()

        # test produced list is correct
        nose.tools.eq_(
            list(product(range(2), repeat=2)),
            [(0, 0), (0, 1), (1, 0), (1, 1)])

        # test produced list is correct
        nose.tools.eq_(
            list(product(range(2), range(2))),
            [(0, 0), (0, 1), (1, 0), (1, 1)])

        # test len(product(range(2), range(3))) == 2*3

# Generated at 2022-06-24 09:50:24.016830
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import numpy as np
    from .._utils import _range

    # Test without total
    try:
        iter_ = ([0, 2, 3])
        gen = product(iter_)
        next(gen)
        assert(next(gen) == (0, 2, 3))
        try:
            next(gen)
        except StopIteration:
            pass
        else:
            raise AssertionError

    except Exception as e:
        sys.stderr.write("Error: %s\n" % str(e))
        raise e

    # Test with total

# Generated at 2022-06-24 09:50:31.972589
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from tempfile import TemporaryFile
    from .utils import _range

    from sys import version_info
    PY3 = version_info[0] == 3

    with TemporaryFile(mode='w+b') as f:
        for _ in _range(start=1, times=3):
            for _ in _range(start=2, times=4):
                pass
            for _ in _range(start=5, times=6):
                pass
        f.seek(0)
        if PY3:
            f.seek(0)

# Generated at 2022-06-24 09:50:36.005454
# Unit test for function product
def test_product():
    from .tests import tests
    import numpy as np
    from ..utils import FormatCustomText

    np.random.seed(42)
    s = [range(0, i) for i in tests]
    r = list(itertools.product(*s))
    rr = list(product(*s, tqdm_class=tqdm_auto,
                      total=len(r), postfix=FormatCustomText('postfix')))
    t = 'product([range(0, i) for i in tests])'
    assert r == rr, \
        "For {}, got {} and expected {}".format(t, rr, r)

# Generated at 2022-06-24 09:50:41.972318
# Unit test for function product
def test_product():
    """ Unit test for function `product` """
    from .._utils import NoDaemonPool

# Generated at 2022-06-24 09:50:44.033647
# Unit test for function product
def test_product():
    from test_generator import check_generator
    check_generator(product([], [], [], ['a', 'b']))

# Generated at 2022-06-24 09:50:47.032412
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy
    i = product(numpy.arange(100), numpy.arange(100))
    assert sum(i) == 99 * 99 * 99

    i = product(numpy.arange(100) * 100, numpy.arange(100),
                tqdm=lambda x: x)
    assert sum(i) == 99 * 99 * 99

# Generated at 2022-06-24 09:50:57.441892
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import re, os
    import shutil
    from ..tqdm import tqdm
    from ..utils import format_sizeof

    # Test that the length of itertools.product() is computed correctly
    with tqdm(total=3*3*3) as t:
        for _ in product(range(3), range(3), range(3)):
            t.update()

    # Test that it works with non-iterable products (empty)
    with tqdm(total=1) as t:
        for _ in product(0, range(3), range(3)):
            t.update()

    # Test that it works with non-iterable products (non-empty)

# Generated at 2022-06-24 09:51:05.229085
# Unit test for function product
def test_product():
    """Test for `product`"""
    res = list(product(range(2), range(2)))
    assert res == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product([], range(2))) == []
    assert list(product([1])) == [(1,)]
    assert list(product([1], [2])) == [(1, 2)]
    assert list(product([1], [2], [3])) == [(1, 2, 3)]
    assert list(product([1, 2], [3, 4])) == [(1, 3), (1, 4), (2, 3), (2, 4)]


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:51:10.187314
# Unit test for function product
def test_product():
    assert set(product([1, 2], ["a", "b", "c"], tqdm_class=tqdm_auto)) == set([(1, "a"), (1, "b"),
                                                                              (1, "c"), (2, "a"),
                                                                              (2, "b"), (2, "c")])

# Generated at 2022-06-24 09:51:15.136132
# Unit test for function product
def test_product():
    import random
    import string
    import sys
    for x in [50, 100, 1000, 5000]:
        for y in [50, 100, 1000, 5000]:
            for z in [50, 100, 1000, 5000]:
                result = list(product(range(x), range(y), range(z)))
                assert len(result) == x*y*z, "product result is wrong length"
                assert result[-1] == (x-1, y-1, z-1), "product result is wrong"

# Generated at 2022-06-24 09:51:17.655195
# Unit test for function product
def test_product():
    """
    Unit test `product`
    """
    assert sum(product(range(100))) == sum(itertools.product(range(100)))


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:51:27.155092
# Unit test for function product
def test_product():
    from numpy import prod

    from .tqdm_gui import tqdm

    for N in [1, 2, 5, 10, 50, 100, 500]:

        for nprod in [1, 2, 5, 10, 50, 100]:

            # Make sure myprod == numpy.prod
            myprod = 1
            for _ in product(range(N), range(N), range(N),
                             range(N), range(N), range(N),
                             range(N), range(N), range(N),
                             tqdm=tqdm,
                             # Leave a few more kwargs here ...
                             total=nprod):
                myprod *= _[0]

            assert prod(range(N)) == myprod

# Generated at 2022-06-24 09:51:31.919291
# Unit test for function product
def test_product():
    # since its a simple wrapper, we just need to make sure that it is
    # being called
    def tqdm_mock(*args, **kwargs):
        return args[0]

    assert list(product("ab", tqdm_class=tqdm_mock)) == [("a",), ("b",)]

# Generated at 2022-06-24 09:51:41.639764
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product('ABCD', 'xy')) == [('A', 'x'), ('A', 'y'),
                                           ('B', 'x'), ('B', 'y'),
                                           ('C', 'x'), ('C', 'y'),
                                           ('D', 'x'), ('D', 'y')]

# Generated at 2022-06-24 09:51:51.392039
# Unit test for function product
def test_product():
    from .test_itertools import TestItertools
    from .deprecate import TestCase
    from .utils import closing_disabled
    with closing_disabled():
        with TestCase.disable_gc():
            for tqdm_cls, nrows in [(tqdm_auto, 3)]:
                with TestItertools(tqdm_class=tqdm_cls) as t:
                    t.assertEqual(
                        t.str_join(product(t.letters, t.integers)),
                        ['a1', 'a2', 'a3', 'b1', 'b2', 'b3',
                         'c1', 'c2', 'c3'])

# Generated at 2022-06-24 09:51:55.488691
# Unit test for function product
def test_product():
    from random import randrange

    for size in (1, 2, 5, 10):
        for i in product(*[[randrange(10) for _ in range(size)] for _ in range(5)]):
            pass

# Generated at 2022-06-24 09:51:59.561827
# Unit test for function product
def test_product():
    for i in product([1, 2, 3], [4, 5, 6], [7, 8], [9, 10],
                     tqdm_class=tqdm_auto):
        assert i[0] * i[1] * i[2] * i[3] == i[0] + i[1] + i[2] + i[3]

# Generated at 2022-06-24 09:52:10.758196
# Unit test for function product
def test_product():
    """
    Test for product.
    """
    assert list(product((), (), tqdm_class=None)) == []
    assert list(product((1,), (), tqdm_class=None)) == []
    assert list(product((), (1,), tqdm_class=None)) == []
    assert list(product((), (), 1, tqdm_class=None)) == []
    assert list(product((1,), (1,), tqdm_class=None)) == [(1, 1)]

    # Test default tqdm
    assert list(product((1, 2), (3, 4))) == [(1, 3), (1, 4), (2, 3), (2, 4)]
    assert list(product(range(1, 2), range(1, 2))) == [(0, 0)]

# Generated at 2022-06-24 09:52:17.239556
# Unit test for function product
def test_product():
    from . import trange
    for n_iter in [10**i for i in trange(4, desc="n_iter")]:
        for n_ranges in [10**i for i in trange(4, desc="n_ranges")]:
            assert sum(1 for _ in product(
                *(range(n_iter) for _ in range(n_ranges)))) == n_iter ** n_ranges

# Generated at 2022-06-24 09:52:22.708449
# Unit test for function product
def test_product():
    a = [1, 2, 3]
    b = [5, 6]
    c = [9, 10]
    d = [a, b, c]

    prod = list(product(*d))
    prod_total = sum(1 for _ in prod)

    prod2 = list(itertools.product(*d))
    prod2_total = sum(1 for _ in prod2)

    assert prod_total == prod2_total
    assert prod_total == len(prod)
    assert prod_total == len(prod2)

    assert prod == prod2

# Generated at 2022-06-24 09:52:30.465213
# Unit test for function product
def test_product():
    from .utils import FormatTqdmDeprecationWarning
    import warnings
    from .utils import _range

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=FormatTqdmDeprecationWarning)
        assert list(product(_range(4), _range(4), _range(4),
                            tqdm_class=tqdm_auto)) == list(itertools.product(_range(4), _range(4), _range(4)))
        assert list(product(_range(3), _range(3), _range(3),
                            tqdm_class=tqdm_auto)) == list(itertools.product(_range(3), _range(3), _range(3)))
        assert list(product(_range(3))) == list(itertools.product(_range(3)))

# Generated at 2022-06-24 09:52:40.499513
# Unit test for function product
def test_product():
    """
    Test cases for product.

    Parameters
    ----------
    tqdm : [default: tqdm.tqdm].
    """
    from .utils import InvisibleTqdmFile
    with InvisibleTqdmFile() as inf:
        for _ in product([1, 2, 3], tqdm_class=tqdm, file=inf):
            pass
        assert inf.n == 9
        for _ in product([1, 2, 3], tqdm_class=tqdm, file=inf,
                         total=9):
            pass
        assert inf.n == 18

    from .utils import TqdmTypeError
    with TqdmTypeError():
        for _ in product([1, 2, 3], tqdm_class=tqdm, file=5):
            pass

# Generated at 2022-06-24 09:52:46.930876
# Unit test for function product
def test_product():
    """
    Unit test for product.
    """
    # check infinite iterator
    with tqdm_auto() as t:
        n = 0
        for _ in product([1]):
            n += 1
            if n == 20:
                break
        assert t.n == 20
        assert t.total is None

    # check finite iterator
    with tqdm_auto() as t:
        for _ in product([1], [1], [1]):
            pass
        assert t.n == 1
        assert t.total == 1

    # check finite iterator (with len)
    with tqdm_auto() as t:
        for _ in product(range(2), range(2), range(2)):
            pass
        assert t.n == 8
        assert t.total == 8

# Generated at 2022-06-24 09:52:51.916111
# Unit test for function product
def test_product():
    from ..std import next, iter
    from ..utils import format_sizeof
    import numpy as np
    from .tests_tqdm import discretize, FakeTqdmFile, closing, closing_wrap
    from .._tqdm_gui import tqdm_notebook
    from os import devnull
    import sys
    import random
    import time

    seed = 0
    random.seed(seed)
    np.random.seed(seed)

    total = 10**6
    vrange = list(range(total))

    class RandIters():
        def __init__(self, max_size=10**3, max_time=0.5):
            self.max_size = max_size
            self.max_time = max_time
        def __iter__(self):
            return self

# Generated at 2022-06-24 09:53:00.252037
# Unit test for function product
def test_product():
    """Test function product"""
    orig = list(itertools.product(*[[0, 1], [0, 1]]))
    assert list(product(*[[0, 1], [0, 1]])) == orig
    assert list(product(*[[0, 1], [0, 1]], tqdm_class=tqdm_auto)) == orig

# Generated at 2022-06-24 09:53:07.254056
# Unit test for function product
def test_product():
    from .tests import TestCase
    from .utils import closing

    with closing(TestCase()) as tc:
        for i in product(tc._range(3), tc._range(3)):
            continue
        for i in product(tc._range(1, 3), tc._range(1, 3)):
            continue
        for i in product([1, 2], [1, 2]):
            continue
        for i in product():
            break
    with closing(TestCase()) as tc:
        for i in product(tc._range(3), tc._range(3), tqdm_class=tqdm_auto):
            continue
        for i in product(tc._range(1, 3), tc._range(1, 3),
                         tqdm_class=tqdm_auto):
            continue

# Generated at 2022-06-24 09:53:11.890925
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    # Test with simple generator
    assert list(product("ABC", repeat=2)) == list(itertools.product("ABC", repeat=2))
    # Test with iterator
    assert list(product(iter("ABC"), repeat=2)) == list(itertorts.produce("ABC", repeat=2))

if __name__ == "__main__":
    """
    Unit tests.
    """
    test_product()

# Generated at 2022-06-24 09:53:22.156960
# Unit test for function product
def test_product():
    """
    Test for function `product`
    """
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    assert list(product(range(3), range(3))) == [(0, 0), (0, 1), (0, 2),
                                                 (1, 0), (1, 1), (1, 2),
                                                 (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-24 09:53:28.639235
# Unit test for function product
def test_product():
    """
    Test that range(x) is equivalent to xrange(x) (Python 2 only).
    """
    try:
        range = xrange
    except NameError:
        pass

    sequence = range(1, 5)
    results = product(*[sequence, sequence, sequence])
    assert all(i == j for i, j in zip(
        results, itertools.product(*[sequence, sequence, sequence])))



# Generated at 2022-06-24 09:53:36.114571
# Unit test for function product
def test_product():
    import pytest
    from itertools import product
    from .utils import closing

    with closing(tqdm_auto(total=7*5*6)) as t:
        for _ in product(range(7), range(5), range(6)):
            t.update()
        assert t.n == t.total

    with closing(tqdm_auto(total=7*5*6)) as t:
        for _ in product([1, 2, 3, 4, 5], [6, 7, 8, 9, 10]):
            t.update()
        assert t.n == t.total

    with closing(tqdm_auto(total=5)) as t:
        for _ in product(range(5), repeat=5):
            t.update()
        assert t.n == t.total


# Generated at 2022-06-24 09:53:46.436584
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    from .tests_tqdm import with_setup, pretest, posttest, _range
    import sys

    @with_setup(pretest, posttest)
    def test():
        """Test function `product`."""
        # no total because infinite
        assert list(product(_range(3), _range(3))) == [(0, 0), (0, 1), (0, 2),
                                                       (1, 0), (1, 1), (1, 2),
                                                       (2, 0), (2, 1), (2, 2)]

# Generated at 2022-06-24 09:53:54.688360
# Unit test for function product
def test_product():
    import numpy as np
    try:
        from nose.tools import assert_equal, assert_not_equal
    except ImportError:
        from numpy.testing import assert_equal, assert_not_equal

    for x in product(range(5), [1, 2], ['a', 'b'], tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:54:04.317245
# Unit test for function product
def test_product():
    from .utils import closing, truncate_float
    from random import random
    from operator import mul

    for i in range(3):
        for n in [0, 1, 2, 3, 5]:
            with closing(list(product(range(n), range(n), tqdm_class=tqdm_auto, desc="product({})"
                                                                 .format(n)))) as L:
                assert len(L) == n**2

    # Check that total is working (#215)
    # (might fail on Py2 with some deprecation warnings)
    with closing(list(product(range(3), range(3), tqdm_class=tqdm_auto, total=9))) as L:
        assert len(L) == 9

    # Check support of reduce in case of an empty iterable

# Generated at 2022-06-24 09:54:16.354986
# Unit test for function product
def test_product():
    """Test for function :func:`product`"""
    # Unit test for function product
    from .tests_tqdm import pretest_posttest, _range, closing

    with closing(tqdm_auto()) as t:
        for _ in t.wrap_tqdm(product(range(3), _range(4), _range(1000), tqdm=t)):
            pass
        assert t.n == 3 * 4 * 1000
        t.n = 0
        for _ in t.wrap_tqdm(product(range(3), _range(4), _range(1000), tqdm=t)):
            t.total = 1000
            break
        with pretest_posttest(t) as (pre, post):
            pass
        assert pre == (0, 1000)
        assert post == (1000, 1000)



# Generated at 2022-06-24 09:54:25.485069
# Unit test for function product
def test_product():
    from .tests import BaseTestMixin, closing
    import sys

    class Tests(BaseTestMixin):
        def test_product_basic(self):
            with closing(self.StringIO()) as our_file:
                list(product("ABC", our_file=our_file))
                self.assertIn("itertools", our_file.getvalue())

                with closing(self.StringIO()) as our_file:
                    list(product("ABC", our_file=our_file, tqdm_class=tqdm_auto))
                    self.assertIn("itertools", our_file.getvalue())

        def test_product_total(self):
            with closing(self.StringIO()) as our_file:
                list(product("ABC", "ABC", total=5, our_file=our_file))

# Generated at 2022-06-24 09:54:30.297806
# Unit test for function product
def test_product():
    """Runs unit tests on the product function"""
    iterable_list = [range(10), range(10), range(10), range(10),
                     range(10), range(10), range(10)]
    for i in product(*iterable_list, total=-1):
        pass

# Generated at 2022-06-24 09:54:31.700226
# Unit test for function product
def test_product():
    from .tests import test_product
    test_product(product)

# Generated at 2022-06-24 09:54:41.422489
# Unit test for function product
def test_product():
    # Test basic function
    for p in product(range(10), repeat=3):
        pass
    for p in product(range(10), repeat=3, total=5):
        pass
    for p in product(range(10), repeat=3, miniters=5):
        pass
    for p in product(range(10), repeat=3, mininterval=0.5):
        pass
    for p in product(range(10), repeat=3, total=5, miniters=5):
        pass
    for p in product(range(10), range(10), range(10),
                     total=5, miniters=5):
        pass
    # Test partial
    p = product(range(10), range(10), range(10), total=5)
    next(p)
    next(p)
    next

# Generated at 2022-06-24 09:54:43.838037
# Unit test for function product
def test_product():
    """Test for product"""
    for _ in product(['a', 'b', 'c'], [1, 2]):
        pass
    for _ in product(['a', 'b', 'c'], repeat=2):
        pass

# Generated at 2022-06-24 09:54:48.021357
# Unit test for function product
def test_product():
    from numpy import product
    import random
    number_of_tests = 10
    results = []
    for _ in tqdm_auto(range(number_of_tests)):
        args = [list(range(random.randint(1, 10))) for i in range(random.randint(1, 5))]
        results.append(product(*args) == list(product(*args)))
    assert all(results)

# Generated at 2022-06-24 09:54:59.461190
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy.testing import assert_equal, TestCase
    import numpy as np
    import copy

    class Test(TestCase):
        def test_product(self):
            total = 0
            t = tqdm_auto(range(10), total=None)
            for i in product(range(10), range(10), tqdm_class=t,
                             desc="nested product"):
                total += 1
                pass
            assert_equal(total, 10 ** 2)
            assert_equal(t.n, 10)
            assert_equal(t.total, 10 ** 2)
            assert_equal(t.desc, "nested product")

            total = 0
            t = tqdm_auto(total=10)

# Generated at 2022-06-24 09:55:03.570711
# Unit test for function product
def test_product():
    """ Unit test for function `tqdm.product`. """
    assert list(product(range(2), range(2), tqdm_class=tqdm_auto)) == [
        (0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(2), tqdm_class=tqdm_auto)) == [(0,), (1,)]

# Generated at 2022-06-24 09:55:09.400013
# Unit test for function product
def test_product():
    """
    Test that iteration over the same list using two for loops is equal
    to itertools.product.
    """
    # set up
    a = range(3)
    b = range(2)
    ab = list(product(a, b))

    # test
    assert len(ab) == 6
    for i in range(3):
        for j in range(2):
            assert ab[i*2 + j] == (i, j)

# Generated at 2022-06-24 09:55:18.817897
# Unit test for function product
def test_product():
    import sys
    import pytest

    a = list(range(10))
    b = list(range(10, 40, 2))
    c = list(range(30, 50))

    # Simple test
    assert list(product(a, b, c)) == [(i, j, k) for i in a for j in b for k in c]
    assert list(product(a, b, c, repeat=2)) == \
        [(i, j, k, i, j, k) for i in a for j in b for k in c]
    assert list(product(a, b, c, repeat=3)) == \
        [(i, j, k, i, j, k, i, j, k) for i in a for j in b for k in c]

# Generated at 2022-06-24 09:55:26.514939
# Unit test for function product
def test_product():
    from .util import _range

    assert list(product(_range(10), repeat=3)) == list(
        itertools.product(_range(10), repeat=3))
    assert list(product([], [], [], _range(10))) == list(
        itertools.product([], [], [], _range(10)))
    assert list(product(_range(10), _range(10))) == list(
        itertools.product(_range(10), _range(10)))
    assert list(product(_range(10), _range(10), _range(10))) == list(
        itertools.product(_range(10), _range(10), _range(10)))
    assert list(product(_range(0), _range(10))) == list(
        itertools.product(_range(0), _range(10)))

# Generated at 2022-06-24 09:55:36.848091
# Unit test for function product
def test_product():
    from sys import version_info as v
    from subprocess import Popen
    from time import sleep

    if not v[0] == 2:  # noqa
        raise unittest.SkipTest("python2 only")

    from .tests_tqdm import pretest_posttest

    def run_test(cls, ncols, **kargs):
        it = product(xrange(10), tqdm_class=cls, **kargs)
        for _ in it:
            pass

    for ncols in [80, 40]:
        with pretest_posttest(lambda: Popen('stty cols {}'.format(ncols),
                                            shell=True).wait()) as p:
            assert (p.returncode == 0)

            # test normal function

# Generated at 2022-06-24 09:55:42.622561
# Unit test for function product
def test_product():
    """Test function product"""
    from pytest import raises
    from .._utils import FormatCustomText
    vals = [4, 4, 4]
    for total in [None, 12, 12, 12]:
        for a in vals:
            for b in vals:
                for c in vals:
                    # Test product
                    prod = product([a], [b], [c])
                    assert [i for i in prod] == [(a, b, c)]
                    # Test product with total
                    prod = product([a], [b], [c], total=total)
                    assert [i for i in prod] == [(a, b, c)]
                    # Test product with desc
                    prod = product([a], [b], [c], desc="test")
                    assert [i for i in prod] == [(a, b, c)]
    #

# Generated at 2022-06-24 09:55:49.888803
# Unit test for function product
def test_product():
    try:
        import pytest
    except ImportError:
        print("pytest required for unit testing")
        return
    # with total inverse_period
    with pytest.raises(AttributeError):
        for i in product([1, 2, 3], tqdm_class=tqdm_auto, mininterval=0.1,
                         total=1.1):
            pass
    # without total inverse_period
    with pytest.raises(AttributeError):
        for i in product([1, 2, 3], tqdm_class=tqdm_auto, mininterval=0.1,
                         total=1.1):
            pass
    # without total inverse_period

# Generated at 2022-06-24 09:55:56.533125
# Unit test for function product
def test_product():
    """
    Unit test for `product`.
    """
    import sys
    import io
    from ..utils import format_sizeof
    res = []

    # Dummy classes
    class DummyClass():
        def __init__(self, l):
            self.l = l

        def __len__(self):
            return len(self.l)

        def __iter__(self):
            return iter(self.l)

    class DummyNoLenClass():
        def __init__(self, n):
            self.n = n

        def __iter__(self):
            for i in range(self.n):
                yield i

    try:
        import numpy as np
    except ImportError:
        np = None

# Generated at 2022-06-24 09:56:01.110778
# Unit test for function product
def test_product():
    "Unit test for function `product`"
    from .misc import _deprecate_new_kwargs
    assert product('ABCD', 'xy', tqdm_class=_deprecate_new_kwargs) == itertools.product('ABCD', 'xy')

# Generated at 2022-06-24 09:56:05.147685
# Unit test for function product
def test_product():
    import numpy as np
    for i, j in product(range(2), range(5), range(3),
                        tqdm_class=tqdm_auto,
                        desc="Test product"):
        assert np.all(np.array([i] * 5 * 3) == j)

# Generated at 2022-06-24 09:56:10.037484
# Unit test for function product
def test_product():
    """ Unit test for function product. """
    assert list(product([1, 2, 3], [4, 5, 6])) == list(itertools.product([1, 2, 3], [4, 5, 6]))

# Generated at 2022-06-24 09:56:18.955839
# Unit test for function product
def test_product():
    """Unit test for module `utils.itertools`"""
    try:
        from nose.tools import assert_equal
    except:
        raise RuntimeError("nose not found")

    assert_equal(list(itertools.product([1, 2], repeat=3)),
                 list(product([1, 2], repeat=3)))

    assert_equal(list(itertools.product([1, 2], repeat=3)),
                 list(product([1, 2], repeat=3,
                              tqdm_class=tqdm_auto)))

    assert_equal(list(itertools.product([1, 2], [1, 2])),
                 list(product([1, 2], [1, 2])))


# Generated at 2022-06-24 09:56:26.614256
# Unit test for function product
def test_product():
    l = list(range(5))
    pl = list(product(l, repeat=2, tqdm_class=None))
    assert len(pl) == len(l) ** 2
    assert set(pl) == set((i, j) for i in l for j in l)

    pl = list(product(l, repeat=2))
    assert len(pl) == len(l) ** 2
    assert set(pl) == set((i, j) for i in l for j in l)

    pl = list(product(l, repeat=2, desc="testing2"))
    assert len(pl) == len(l) ** 2
    assert set(pl) == set((i, j) for i in l for j in l)

# Generated at 2022-06-24 09:56:35.719153
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import collections
    import sys

    def products_equal(products1, products2):
        """
        Assume products1, products2 are lists (not tuples) of lists
        of the same length.
        """
        if (len(products1) != len(products2)):
            return False
        for i, prod in enumerate(products1):
            if (len(prod) != len(products2[i])):
                return False
            for j, comp in enumerate(prod):
                if (comp != products2[i][j]):
                    return False
        return True


# Generated at 2022-06-24 09:56:42.514948
# Unit test for function product
def test_product():
    from itertools import product as itertools_product
    from numpy.random import randint
    from numpy import product as np_product
    from .std import nprint
    nprint("itertools.product()", time=False)
    nprint("tqdm.product()", time=False)
    nprint("numpy.product()", time=False)
    for size in [10, 100, 1000]:
        arr = randint(0, 10, size)
        assert list(itertools_product(arr)) == list(product(arr)) == list(np_product(*arr))

# Generated at 2022-06-24 09:56:51.830507
# Unit test for function product
def test_product():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class Test_product(unittest.TestCase):
        def test_product(self):
            from itertools import izip
            from .utils import LinearTest

            a = ['a', 'b', 'c', 'd']
            b = [4, 3, 2, 1]
            for _a, _b in izip(product(a, b), itertools.product(a, b)):
                self.assertEqual(_a, _b)

            class Product(LinearTest):
                def setup(self):
                    self.s = 0

                def teardown(self):
                    self.assertEqual(self.s, 24)

                def body(self, bar):
                    self.s

# Generated at 2022-06-24 09:57:03.649527
# Unit test for function product
def test_product():
    from math import fsum
    from collections import Counter

    n = 1000

    def check(i, elms):
        assert (i == len(elms))
        assert (i == sum(elms))
        assert (i == fsum(elms))
        assert (i == min(elms))
        assert (i == max(elms))
        assert (i == len(set(elms)))  # Check distinct
        assert (Counter(elms) ==
                Counter([int(x) for x in format(i, 'b')]))

    def check_product(iterables, nb_elmts):
        # Check number of elements
        i = sum(1 for _ in itertools.product(*iterables))
        assert (i == nb_elmts)

        # Check individual elements

# Generated at 2022-06-24 09:57:14.682409
# Unit test for function product
def test_product():
    from .tests import CovariantList, MeasureKnownIterable

    a = range(3)
    b = range(2)
    c = CovariantList(range(4))

    assert list(itertools.product(a, b)) == \
        list(product(a, b))
    assert list(itertools.product(a, b, c)) == \
        list(product(a, b, c))

    a = MeasureKnownIterable(range(3))
    b = MeasureKnownIterable(range(2))
    c = MeasureKnownIterable(CovariantList(range(4)))
    for it in [a, b, c]:
        it.reset()


# Generated at 2022-06-24 09:57:22.885459
# Unit test for function product
def test_product():
    """Test for `product`"""
    # Test for simple addition
    from .collections import cnums
    from .utils import format_sizeof
    from random import randint

    def test_gens(i, n):
        yield map(str, range(i, i + n))
        yield range(i, i + n)  # test range()
        yield range(i, i + n, n)  # test range(step)
        yield (cnum(i + j) for j in range(n))  # test generator
        yield list(range(i, i + n))  # test list

# Generated at 2022-06-24 09:57:32.767741
# Unit test for function product
def test_product():

    def myproduct(*iterables):
        r = iterables[0]
        for it in iterables[1:]:
            r = [a + b for b in it for a in r]
        return r

    assert myproduct(['a', 'b', 'c']) == product(['a', 'b', 'c'],
                                                tqdm_class=None)
    assert myproduct(['a', 'b', 'c'], ['1', '2']) == list(
        product(['a', 'b', 'c'], ['1', '2'], tqdm_class=None))

# Generated at 2022-06-24 09:57:38.519939
# Unit test for function product
def test_product():
    """Test function `product`"""
    import sys
    import time
    from ..utils import format_sizeof

    trials = [0]
    def trial(it):
        trials[0] += 1

        assert format_sizeof(sum(map(sys.getsizeof, it))) > 0
        assert list(it)
        time.sleep(0.01)
        assert trials[0] == 1
        return trials[0]


# Generated at 2022-06-24 09:57:48.745115
# Unit test for function product
def test_product():
    from .tqdm import trange
    rng = range(5)
    for i, j in product(rng, trange=trange):
        pass
    for i, j in product(rng, range(3), trange=trange):
        pass
    for i, j in product(rng, range(3), range(4), trange=trange):
        pass
    for i, j in product(rng, range(3), range(4), range(2), trange=trange):
        pass
    for i, j in product(rng, range(3), range(4), range(2), range(7),
                        trange=trange):
        pass
    for i, j in product(rng, repeat=5, trange=trange):
        pass

# Generated at 2022-06-24 09:57:53.953707
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ..utils import format_sizeof
    for j in product(xrange(10), repeat=2, tqdm_class=tqdm_auto):
        pass
    for j in product(xrange(10), repeat=3, tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:58:01.757055
# Unit test for function product
def test_product():
    """
    Run the `tqdm.itertools.product()` function unit test.
    """
    import nose.tools as nt
    ret = list(product(range(3),
                       iter(tqdm_auto(range(3))),
                       range(3, 6)))

# Generated at 2022-06-24 09:58:02.972477
# Unit test for function product
def test_product():
    for _ in product(range(100), range(100), range(100)):
        pass

# Generated at 2022-06-24 09:58:09.193840
# Unit test for function product
def test_product():
    try:
        from nose.tools import assert_equals
    except ImportError:
        raise ImportError("Test requires nose.tools")

    it = product("abc", repeat=3)
    assert_equals(list(it), list(itertools.product("abc", repeat=3)))
    it = product("abc", repeat=3, tqdm_class=tqdm_auto)
    assert_equals(list(it), list(itertools.product("abc", repeat=3)))

# Generated at 2022-06-24 09:58:17.240743
# Unit test for function product
def test_product():
    """Tests `tqdm.itertools.product`"""
    from ..utils import _term_move_up
    assert (list(product(range(3), range(2), tqdm_class=None)) ==
            list(itertools.product(range(3), range(2))))
    it = product(range(3), range(2), tqdm_class=None)
    assert (next(it), next(it)) == ((0, 0), (0, 1))
    with tqdm_auto(total=1, desc="testing product") as t:
        list(product(range(3), range(2), tqdm_class=tqdm_auto))
        assert t.n == 6

    # Test dynamic updates

# Generated at 2022-06-24 09:58:26.552955
# Unit test for function product
def test_product():  # pragma: no cover
    from ..utils import FormatCustomText
    for t in FormatCustomText, lambda i: "":
        for k in MyIterable, range:
            for h in tqdm_auto, tqdm_gui, tqdm_notebook:
                # Test default
                assert sum(product(range(i), tqdm_class=h, desc=t(i))) == (
                    i - 1) * i

                # Test normal use
                assert sum(product(range(i), tqdm_class=h, desc=t(i),
                                   bar_format="{l_bar}{bar}{r_bar}")) == \
                    (i - 1) * i

                # Test total

# Generated at 2022-06-24 09:58:31.924817
# Unit test for function product
def test_product():
    """
    Tests product function.
    """
    from ..auto import tqdm
    from ..std import time
    with tqdm(product(['a', 'b'], ['c', 'd'], ['e', 'f']),
              desc='test') as pbar:
        for i in pbar:
            time.sleep(0.1)

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:58:38.558947
# Unit test for function product
def test_product():
    for i, _ in enumerate(product(range(10))):
        assert i == _

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:58:45.072783
# Unit test for function product
def test_product():
    from ..tests.bad_format import format_interactive
    from .tests import pretest_posttest_pass, pretest_posttest_fail

    @pretest_posttest_pass
    def test_product_examples():
        """
        >>> import sys
        >>> list(product([1, 2, 3]))
        1
        2
        3
        >>> total = 0
        >>> format_interactive()
        >>> for i, j in product(range(5), range(5)):
        ...     total += i * j
        ...     sys.stdout.write('{}\r'.format(total))
        >>> total
        100
        >>> for i, j, k in product(range(5), range(5), range(5)):
        ...     pass
        """


# Generated at 2022-06-24 09:58:52.413871
# Unit test for function product
def test_product():
    """Test function product"""
    from .. import trange

    assert list(product(['a', 'b'], [1, 2, 3])) == \
        [(a, b) for a in ['a', 'b'] for b in [1, 2, 3]]

    r = product(range(10), range(10), tqdm_class=trange)
    assert not next(r).pos
    assert list(r) == [(i, j) for i in range(10) for j in range(10)]