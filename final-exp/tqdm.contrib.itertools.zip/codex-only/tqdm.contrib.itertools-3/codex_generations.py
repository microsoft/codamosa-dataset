

# Generated at 2022-06-24 09:48:58.065936
# Unit test for function product
def test_product():
    try:
        import numpy as np
    except ImportError:
        raise SkipTest
    a = np.arange(30)
    res1, res2 = [], []
    for x, y, z in tqdm.product(a, a, a):
        res1.append((x, y, z))
        if np.sum(res1) > 10:
            break
    for x, y, z in tqdm.product(a, a, a, tqdm=None):
        res2.append((x, y, z))
        if np.sum(res2) > 10:
            break
    assert res1 == res2

# Generated at 2022-06-24 09:49:00.829362
# Unit test for function product
def test_product():
    """ Test for function product """
    count = 0
    for _ in product(xrange(100), xrange(100), xrange(100)):
        count += 1
    assert count == 1e6

# Generated at 2022-06-24 09:49:05.386094
# Unit test for function product
def test_product():
    from .._utils import SimpleTextIOWrapper
    from ..utils import _environ_cols_wrapper
    try:
        import cStringIO as stringIO
    except ImportError:
        import io as stringIO

    # Test 1: iteration without total
    it = product(range(10))
    with SimpleTextIOWrapper(stringIO.StringIO()) as f:
        t = tqdm(it, file=f)
        for _ in t:
            pass
        assert t.desc == '0it [00:00, ?it/s]'

    # Test 2: iteration with total
    it = product(range(10), range(10))
    with SimpleTextIOWrapper(stringIO.StringIO()) as f:
        t = tqdm(it, file=f)

# Generated at 2022-06-24 09:49:12.648560
# Unit test for function product
def test_product():
    p = list(product([1, 2, 3], ["a", "b", "c"], tqdm_class=tqdm_auto))
    assert len(p) == 3 * 3
    assert p[0] == (1, "a")
    assert p[-1] == (3, "c")

    p = list(product([1, 2, 3], ["a", "b", "c"], tqdm_class=tqdm_auto))
    assert len(p) == 3 * 3
    assert p[0] == (1, "a")
    assert p[-1] == (3, "c")

    p = list(product([1, 2, 3], tqdm_class=tqdm_auto))
    assert len(p) == 3
    assert p[0] == 1

# Generated at 2022-06-24 09:49:23.062205
# Unit test for function product
def test_product():
    """Test function product"""
    # Test without total
    assert list(product(range(10))) == list(itertools.product(range(10)))
    assert list(product(range(2), range(10))) == list(
        itertools.product(range(2), range(10)))
    assert list(product(range(2), range(3), range(10))) == list(
        itertools.product(range(2), range(3), range(10)))
    # Test with non-homogeneous iterables
    assert list(product(range(2), range(10), 'abc')) == list(
        itertools.product(range(2), range(10), 'abc'))
    # Test with total: len(iterable_1)*len(iterable_2)

# Generated at 2022-06-24 09:49:33.259026
# Unit test for function product
def test_product():
    import sys
    lists = [[1, 2, 3] * 100, [10, 20, 30, 40] * 75]
    for i, _ in enumerate(product(*lists, ascii=True, mininterval=0)):
        pass
    assert i == len(lists[0]) * len(lists[1]) - 1
    assert tqdm_auto.write.call_count == i + 1
    tqdm_auto.write.reset_mock()
    for i, _ in enumerate(product(*lists, ascii=True, file=sys.stdout)):
        pass
    assert i == len(lists[0]) * len(lists[1]) - 1
    assert tqdm_auto.write.call_count == 0

# Generated at 2022-06-24 09:49:40.027305
# Unit test for function product
def test_product():
    import numpy as np

    def s():
        for i in product('ABC', '123', tqdm=tqdm_auto, leave=False):
            yield i
        for i in product(range(10), repeat=2, tqdm=tqdm_auto, leave=False):
            yield i
        for i in product(range(10), range(10), tqdm=tqdm_auto, leave=False):
            yield i

    g = s()
    a = np.array([i for i in g])

# Generated at 2022-06-24 09:49:42.632338
# Unit test for function product
def test_product():
    """Test product() function"""
    for char in product("abc", [1, 2, 3], range(5)):
        print(char)

# Generated at 2022-06-24 09:49:46.269344
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    with tqdm_auto(total=10, mininterval=0.05) as t:
        for i in product(range(10), range(10), tqdm_class=t.__class__):
            pass

# Generated at 2022-06-24 09:49:49.867271
# Unit test for function product
def test_product():
    from .base import UnitTestBase
    from .base import TypeTestBase
    from .base import UnicodeTestBase
    from .base import Py34TestBase

    class _TestProduct(UnitTestBase):
        def __init__(self, *args, **kwargs):
            super(_TestProduct, self).__init__()
            self.iterables = args
            self.tqdm_kwargs = kwargs

        def __next__(self):
            return next(product(*self.iterables, **self.tqdm_kwargs))

    class TestProduct(_TestProduct):
        def __init__(self, iterables):
            super(TestProduct, self).__init__(*iterables)


# Generated at 2022-06-24 09:49:57.452541
# Unit test for function product
def test_product():
    """Test function product()."""
    from .tests_tqdm import StringIO
    from .tests_tqdm import with_setup
    from .tests_tqdm import pretest

    @with_setup(pretest)
    def inner_test():
        """Test function product()."""
        out = StringIO()
        list(product(["a", "b"], [1, 2], ["c", "d", "e"], file=out))
        assert out.getvalue() == "0it [00:00, ?it/s]\n" \
                                 "12it [00:00, 516.11it/s]\n"

    inner_test()

# Generated at 2022-06-24 09:50:03.571737
# Unit test for function product
def test_product():
    """
    Unit test for `fastproduct`.
    """
    # pylint: disable=protected-access
    assert sum(1 for _ in product([1, 2, 3], [1, 2, 3])) == 9
    t = product([1, 2, 3], [1, 2, 3])
    assert hasattr(t, '_instances')
    assert t._instances[0]._total == 9
    t = product([1, 2, 3], [1, 2, 3], tqdm_class=tqdm_auto, ascii=True)
    assert hasattr(t, '_instances')
    assert t._instances[0]._total == 9
    assert tqdm_auto._instances

# Generated at 2022-06-24 09:50:10.277863
# Unit test for function product
def test_product():
    import pytest
    for i in product(
            range(3),
            ['a', 'b'],
            tqdm_class=None,
            desc="foobar"):
        pass
    for i in product(
            range(3),
            ['a', 'b'],
            tqdm_class=None,
            desc="foobar",
            total=6):
        pass

    def outer_product(iterables):
        return list(itertools.product(*iterables))

    def inner_product(iterables):
        return list(product(*iterables, total=None))

    def total_product(iterables):
        return list(product(*iterables, total=6))


# Generated at 2022-06-24 09:50:12.964355
# Unit test for function product
def test_product():
    from ..auto import trange
    # Test the itertools.product equivalents:
    assert list(product(['a', 'b'], trange)) == \
        list(itertools.product(['a', 'b'], trange))

# Generated at 2022-06-24 09:50:21.675629
# Unit test for function product
def test_product():
    assert list(product(["a"], ["b"], tqdm_class=None)) == \
        list(itertools.product(["a"], ["b"]))
    assert list(product(["a"], ["b"], tqdm_class=tqdm_auto)) == \
        list(itertools.product(["a"], ["b"]))
    tqdm_test = lambda **kwargs: kwargs.get("total", None)
    assert list(product(["a"], ["b"], tqdm_class=tqdm_test)) is None
    assert list(product(["a"], ["b"], tqdm_class=tqdm_test, total=0)) == 0

# Generated at 2022-06-24 09:50:30.064739
# Unit test for function product
def test_product():
    from .utils import FormatCustom
    import numpy.random as rd
    import pandas as pd

    rd.seed(1)
    list_of_lists = [range(10), range(3), range(1, 4)]

    def prod_list(list_of_lists):
        for i in itertools.product(*list_of_lists):
            yield i

    all_prod = prod_list(list_of_lists)
    all_prod_pbar = prod_list(list_of_lists)

    for i in product(list_of_lists):
        assert i == next(all_prod)

    for p in itertools.product(list_of_lists):
        assert p == next(all_prod)

    for p in product(*list_of_lists):
        assert p

# Generated at 2022-06-24 09:50:39.471884
# Unit test for function product
def test_product():
    from numpy.linalg import norm

    # Product of two lists of random vectors
    vecs = [[-0.211, 0.501, -0.744], [-0.990, -0.663, -0.822], [0.150, 0.340, 0.906], [-0.944, 0.735, -0.494], [0.839, -0.916, -0.474], [0.933, -0.092, -0.347]]
    prod = product(vecs, vecs)
    prod_sum = [0.0, 0.0, 0.0]
    for v1, v2 in prod:
        prod_sum = list(map(sum, zip(prod_sum, [a * b for a, b in zip(v1, v2)])))

# Generated at 2022-06-24 09:50:49.004647
# Unit test for function product
def test_product():
    from .utils import _range
    i = product([1], range(10), tqdm_class=tqdm_auto, miniters=1)
    assert sum(len(j) for j in i) == 10
    assert sum(i) == 45
    i = product(range(10), tqdm_class=tqdm_auto, miniters=1)
    assert sum(i) == tqdm_auto.format_interval(45)
    i = product(range(10), tqdm_class=tqdm_auto, miniters=1)
    assert len(list(i)) == 10
    i = product(range(10), range(10), tqdm_class=tqdm_auto, miniters=1)
    assert sum(i) == tqdm_auto.format_inter

# Generated at 2022-06-24 09:50:57.661912
# Unit test for function product
def test_product():
    for i in itertools.product('ABC', '12'):
        pass
    for i in product('ABC', '12'):
        pass
    for i in product(range(3), range(2), tqdm_class=tqdm_auto, total=12):
        pass
    for i in product(range(3), total=3, tqdm_class=tqdm_auto):
        pass
    for i in product(range(3), range(2), total=12, tqdm_class=tqdm_auto):
        pass
    for i in product(range(3), total=12, tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:51:01.493797
# Unit test for function product
def test_product():
    """Test for `tqdm.itertools.product`"""
    from .tests import pretest_posttest
    t = pretest_posttest(product)
    for i in t:
        for j in i:
            for k in j:
                pass
    assert t.n == 27

# Generated at 2022-06-24 09:51:07.391413
# Unit test for function product
def test_product():
    """Test `tqdm.itertools.product`."""
    from ..utils import _range
    with tqdm_auto(total=8) as t:
        for _ in product(_range(2), _range(2), _range(2), tqdm_class=tqdm_auto):
            t.update()


try:
    from . import trange
except ImportError:
    from ..std.itertools import trange

__all__ += ['trange', 'tqdm']

# Generated at 2022-06-24 09:51:09.799115
# Unit test for function product
def test_product():
    """Test for product"""
    for i in product(range(10), range(10), range(10),
                     tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:51:16.986783
# Unit test for function product
def test_product():
    from .tests import closing, ncols_test
    from time import sleep
    # Test auto
    with closing(ncols_test()) as ncols:
        for n in ncols, ncols - 10, ncols + 1:
            for total_width in None, ncols / 1.5:
                for desc in None, "A", ''.join("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
                    total = None if total_width is None else 100

# Generated at 2022-06-24 09:51:27.273436
# Unit test for function product
def test_product():
    import numpy as np
    total = 0
    for i in product(*[range(10), range(10), range(10), range(10),
                       range(10)],
                   tqdm_class=tqdm_auto, unit="a", desc="pre"):
        total += 1
    assert total == 10000, total

    total = 0
    for i in product(*[range(10), range(10), range(10), range(10),
                       range(10)],
                   tqdm_class=tqdm_auto, disable=True, unit="a", desc="pre"):
        total += 1
    assert total == 10000, total

    total = 0

# Generated at 2022-06-24 09:51:33.128264
# Unit test for function product
def test_product():
    assert list(product((1,), [1, 2], tqdm_class=None)) == [(1, 1), (1, 2)]
    assert list(product((1, 2), [1, 2], tqdm_class=None)) == [(1, 1), (1, 2),
                                                              (2, 1), (2, 2)]
    assert list(product([1, 2], (1, 2), tqdm_class=None)) == [(1, 1), (1, 2),
                                                              (2, 1), (2, 2)]

# Generated at 2022-06-24 09:51:42.256668
# Unit test for function product
def test_product():
    for iterable1 in (["a", "b"], [1, 2], ["a", "b", "c"], [1, 2, 3],
                      ["a", "b", "c", "d"], [1, 2, 3, 4],
                      ["a", "b", "c", "d", "e"], [1, 2, 3, 4, 5],
                      ["a", "b", "c", "d", "e", "f"], [1, 2, 3, 4, 5, 6],
                      ["a", "b", "c", "d", "e", "f", "g"],
                      [1, 2, 3, 4, 5, 6, 7]):
        assert list(product(*([iterable1]*2))) == list(itertools.product(iterable1, iterable1))

# Generated at 2022-06-24 09:51:44.467382
# Unit test for function product
def test_product():
    """Test for product function (itertools)"""
    for i in product(range(10), range(10), range(10)):
        pass

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:51:49.911117
# Unit test for function product
def test_product():
    from ..tests import _test_iterable
    from ..utils import _supports_unicode
    _test_iterable(product(range(3), range(3), tqdm_class=tqdm_auto))

    if _supports_unicode():
        _test_iterable(product(map(chr, range(130, 150)), repeat=2,
                              tqdm_class=tqdm_auto))

# Generated at 2022-06-24 09:52:00.080457
# Unit test for function product
def test_product():
    """Test function product"""
    test_iterator = product(range(3), tqdm_class=tqdm_auto)
    assert isinstance(test_iterator, tqdm_auto)
    assert list(test_iterator) == list(itertools.product(range(3)))

    test_iterator = product(range(3), tqdm_class=tqdm_auto)
    assert isinstance(test_iterator, tqdm_auto)
    assert list(test_iterator) == list(itertools.product(range(3)))
    test_iterator.close()

    test_iterator = product(range(3), tqdm_class=tqdm_auto)
    assert isinstance(test_iterator, tqdm_auto)

# Generated at 2022-06-24 09:52:07.377902
# Unit test for function product
def test_product():
    """Unit test for function product"""
    assert list(product([1, 2, 3], repeat=3)) \
        == list(itertools.product([1, 2, 3], repeat=3))
    assert list(product([1, 2, 3], [1, 2, 3], [1, 2, 3])) \
        == list(itertools.product([1, 2, 3], [1, 2, 3], [1, 2, 3]))

# Generated at 2022-06-24 09:52:15.511402
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert [i for i in product(range(3), repeat=2)] == \
        list(itertools.product(range(3), repeat=2))

    assert [i for i in product('ABC', 'xy')] == \
        list(itertools.product('ABC', 'xy'))

    assert [i for i in product(range(3), repeat=2, tqdm_class=None)] == \
        list(itertools.product(range(3), repeat=2))

    assert [i for i in product(range(3), repeat=2, tqdm_class=tqdm_auto)] == \
        list(itertools.product(range(3), repeat=2))


# Test from the documentation

# Generated at 2022-06-24 09:52:21.935160
# Unit test for function product
def test_product():
    from ..utils import format_sizeof

    for i in product(
            (1, 2, 3, 4, 5), ('a', 'b', 'c'), ('!', '@', '#', '%', '?'),
            tqdm_class=tqdm_auto, desc="Product example", unit="B",
            disable=False):
        assert i
    from ..utils import _range
    for i in product(
            (_range(5), _range(0xffff), _range(10**5)),
            tqdm_class=tqdm_auto, desc="_range example", unit="B"):
        assert i

# Generated at 2022-06-24 09:52:26.821997
# Unit test for function product
def test_product():
    """
    Unit test for the function "product".
    """
    assert list(product(range(3), range(3))) == list(itertools.product(range(3), range(3)))
    assert list(product(range(3), range(3), tqdm_class=tqdm_auto)) == \
        list(itertools.product(range(3), range(3)))

if __name__ == '__main__':
    test_product()  # pragma: no cover

# Generated at 2022-06-24 09:52:35.017444
# Unit test for function product
def test_product():
    """Test that the nested tqdm decorator works"""
    try:
        import numpy as np
    except ImportError:
        np = None
    if np is not None:
        a = np.arange(1000).reshape(100, 10).tolist()
        b = np.arange(1000, 2000).reshape(100, 10).tolist()
        aa = list(product(a, b))
        bb = [(x, y) for x, y in zip(a, b)]
        assert aa == bb


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:52:40.298004
# Unit test for function product
def test_product():
    """
    Run "python -m tqdm.utils.itertools_test",
    or "python tests/utils/itertools_test.py"
    """
    from ..tests import tests as tmod
    return tmod.test_product(tqdm=tqdm_auto)


if __name__ == "__main__":
    from ..tests import tests as tmod
    tmod.run_module_suite()

# Generated at 2022-06-24 09:52:41.886590
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for i in product(range(5), range(5)):
        pass

# Generated at 2022-06-24 09:52:51.422241
# Unit test for function product
def test_product():
    """
    Unit test for function ``product``.
    """
    import numpy as np
    from .utils import FormatWrapIter
    seq = [FormatWrapIter([1, 2, 3]),
           FormatWrapIter('ABC'),
           FormatWrapIter([1.0, -1.0])]

    assert list(itertools.product(*seq)) == list(product(*seq))
    assert list(itertools.product(*seq)) == list(product(*seq, tqdm_class=None))

    assert list(itertools.product(*seq)) == list(product(*seq, tqdm_class=tqdm_auto))
    assert np.allclose([0, 0, 0], [0, 0, 0])

if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:53:05.437725
# Unit test for function product
def test_product():
    """
    Test for the string representation of `tqdm.itertools.product`
    """
    from .._utils import _range
    from .._tqdm_gui import _version_warning
    _version_warning("tqdm.itertools", "tqdm_gui")

    # Verify ranges
    assert list(tqdm_gui.itertools.product(['a', 'b'], _range(2))) == \
        list(itertools.product(['a', 'b'], _range(2)))
    assert list(tqdm_gui.itertools.product(['a', 'b'], _range(2),
                                           tqdm_class=None)) == \
        list(itertools.product(['a', 'b'], _range(2)))

# Generated at 2022-06-24 09:53:07.861840
# Unit test for function product
def test_product():
    """Unit test for product."""
    # pylint: disable=unused-variable
    from .tests import TestCase

    with TestCase():
        for i in product(range(10), range(5)):
            pass

# Generated at 2022-06-24 09:53:13.233026
# Unit test for function product
def test_product():
    """Test for `product`."""
    for i, _ in zip(product(range(10), range(3)), range(30)):
        assert i == _
    for i, _ in zip(product(range(5), range(5), range(5)), range(125)):
        assert i == _

# Generated at 2022-06-24 09:53:22.961929
# Unit test for function product
def test_product():
    from .utils import TotalCounter
    iter1 = range(3)
    iter2 = range(3)
    iter3 = range(3)
    kwargs = dict(miniters=1, mininterval=0.01)

    # First test
    total = TotalCounter()
    for i in product(iter1, iter2, **kwargs):
        total.val += 1
    assert total.val == 9

    total = TotalCounter()
    for i in product(iter1, iter2, tqdm_class=None):
        total.val += 1
    assert total.val == 9

    # Second test
    total = TotalCounter()
    for i in product(iter1, iter2, iter3, **kwargs):
        total.val += 1
    assert total.val == 27

    total = TotalCounter()
   

# Generated at 2022-06-24 09:53:28.638477
# Unit test for function product
def test_product():
    iterables = [list(range(10)), list(range(100))]
    with tqdm_auto(total=len(range(10)) * len(range(100))) as t:
        assert list(product(iterables[0], iterables[1], tqdm_class=tqdm_auto)) == list(itertools.product(iterables[0], iterables[1]))

# Generated at 2022-06-24 09:53:33.610596
# Unit test for function product
def test_product():
    # Generator of the expected output
    def expected():
        for x in "ab":
            for y in "ef":
                for z in "ghi":
                    yield (x, y, z)

    # Use the product function
    for a in product(*"ab", *"ef", *"ghi"):
        e = next(expected())
        assert a == e

# Generated at 2022-06-24 09:53:43.825452
# Unit test for function product
def test_product():
    """ Unit test for function product """
    from .._utils import _range
    from . import trange
    for iterables, tqdm_kwargs, islice in [
            (list(_range(10)), {}, slice(None)),
            (list(_range(10)), {}, slice(5, 10)),
            ([[_range(10), _range(2)], ["foo"]], {}, slice(10, 20)),
            ([[_range(10), _range(10)]], {}, slice(5))]:
        for _ in trange(list(zip(*product(*iterables, **tqdm_kwargs))) ==
                        list(zip(*itertools.product(*iterables))[islice]),
                        desc="Unit test", leave=False):
            pass

# Generated at 2022-06-24 09:53:51.374605
# Unit test for function product
def test_product():
    # Test simple use cases
    assert list(product(range(7), repeat=0)) == [()]
    assert list(product(range(2), repeat=1)) == [(0,), (1,)]
    assert list(product(range(3), repeat=2)) == [
        (0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]
    assert list(product(range(3), range(2), repeat=1)) == [
        (0,), (1,), (2,), (0,), (1,), (2,), (0,), (1,), (2,)]
    # Test that total is ignored under manual mode

# Generated at 2022-06-24 09:54:03.060709
# Unit test for function product
def test_product():
    """Unit test for itertools.product"""
    from itertools import product as itertools_product
    from nose.tools import assert_equal

    assert_equal(
        list(product(range(2), repeat=2)),
        list(itertools_product(range(2), repeat=2)))


# Generated at 2022-06-24 09:54:09.564913
# Unit test for function product
def test_product():
    for i, j in zip(
            product(["a", "b", "c"], ["d", "e"], ["f", "g"]),
            itertools.product(["a", "b", "c"], ["d", "e"], ["f", "g"])):
        assert i == j

# Generated at 2022-06-24 09:54:14.111710
# Unit test for function product
def test_product():
    a = list(range(4))
    b = range(3)
    c = list('abc')
    assert sum(1 for _ in product(a, b, c)) == len(a) * len(b) * len(c)


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:54:23.758767
# Unit test for function product
def test_product():
    from numpy.testing import assert_equal
    from six.moves import zip as izip

    # Test no ncols
    a = [1, 2, 3, 4, 5]
    b = [1, 2, 3]
    c = [1, 2]
    for (i, j, k), (ii, jj, kk) in izip(itertools.product(a, b, c),
                                        product(a, b, c)):
        assert_equal((i, j, k), (ii, jj, kk))

    # Test with ncols
    a = [1, 2, 3, 4, 5]
    b = [1, 2, 3]
    c = [1, 2]

# Generated at 2022-06-24 09:54:30.720135
# Unit test for function product
def test_product():
    """Test that product is equivalent to itertools.product"""
    import operator
    import pytest
    from numpy.random import randint
    from contextlib import contextmanager

    @contextmanager
    def fixed_randint(n):
        """Context manager to fix random integer for unit tests"""
        with pytest.warns(None) as record:
            yield randint(n)
        assert not record

    # Compute the same number of loops
    with fixed_randint(2**16) as n:
        itertools_prod = list(itertools.product(range(n), repeat=2))

    with fixed_randint(2**16) as n:
        tqdm_prod = list(product(range(n), repeat=2))


# Generated at 2022-06-24 09:54:39.732531
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import random
    import string
    import sys
    try:
        random = random.SystemRandom()
        using_sysrandom = True
    except NotImplementedError:
        using_sysrandom = False

    for _ in product('abcd', '1234', 'xyz', tqdm_class=tqdm_auto):
        print(_)
    for _ in product(string.ascii_letters[:26], string.digits):
        print(_)
    for _ in product(range(10), repeat=3):
        print(_)
    for _ in product(*([iter(range(10))] * 3)):
        print(_)

    # Shuffle randomly but reproducibly using SystemRandom
    T = 20
    r_seed = 42

# Generated at 2022-06-24 09:54:46.746461
# Unit test for function product
def test_product():
    import numpy as np
    from numpy.testing import assert_equal
    from tqdm.auto import trange
    try:
        import cupy as cp
    except ImportError:  # pragma: no cover
        pass
    else:
        cp.set_allocator(None)
        cp.cuda.Device(0).use()
        cp.get_default_memory_pool().free_all_blocks()

    def _check(l, it_range=None, tqdm_class=trange, total=None):
        it = product(*l, tqdm_class=tqdm_class)
        if it_range is not None:
            it = tqdm_class(it, total=total)
        x = list(it)
        y = list(itertools.product(*l))

# Generated at 2022-06-24 09:54:58.632672
# Unit test for function product
def test_product():
    from .tests import closing, closing_bool
    from .tests import range as _range
    import sys

    # Check total
    with closing(tqdm_auto(product([1, 2, 3], ["a", "b"]))):
        pass

    # Check iterable
    assert closing_bool(tqdm_auto(product([1, 2, 3], ["a", "b"])))
    assert closing_bool(tqdm_auto(product([1], ["a", "b"])))
    assert closing_bool(tqdm_auto(product("ABCD", "xy")))

    # Check closing
    with closing(tqdm_auto(product("ABCD", "xy", tqdm_class=tqdm_auto))) as t:
        assert t.disable is False  # simulate closing
        t.close()

# Generated at 2022-06-24 09:55:01.115889
# Unit test for function product
def test_product():
    """ Tests product function """
    expect_output = [0, 1, 2, 3, 4, 5]
    actual_output = [i for i in product(range(3), range(2), total=6)]
    assert expect_output == actual_output

# Generated at 2022-06-24 09:55:04.459776
# Unit test for function product
def test_product():
    """
    Unit tests for function product.
    """
    for i in product([1, 2], ["bob", "dob"], desc="outer", nested=True,
                     ascii=True, miniters=1):
        print(i)

# Generated at 2022-06-24 09:55:16.276873
# Unit test for function product
def test_product():
    from ..tqdm_pandas.tqdm_pandas import tqdm_pandas

    def test_eq_product(i):
        return i

    def test_eq_product_tqdm_pd(i):
        return i

    i = 0
    for j, k in zip(product([1], [2], [3], tqdm_class=tqdm_pandas),
                    tqdm_pandas([1], [2], [3]).product(test_eq_product_tqdm_pd)):
        assert j[0] == k[0][0] and j[1] == k[0][1] and j[2] == k[0][2]
        i += 1
    assert i == 6  # 6 == 1 * 2 * 3

# Generated at 2022-06-24 09:55:19.120576
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .tests import closing, in_test
    with closing(in_test()) as (_, fout):
        for i in product(range(3), ["a", "b", "c"], total=9):
            fout.write(str(i) + '\n')

# Generated at 2022-06-24 09:55:24.900402
# Unit test for function product
def test_product():
    # Corner case of step=0 (infinite loop)
    for i in tqdm_auto.product(range(4), range(4), step=0):
        pass
    # Simple test
    list(tqdm_auto.product(range(4), range(4)))
    # Verbose test
    list(tqdm_auto.product(range(4), range(4),
                           tqdm_class=tqdm_auto.tqdm,
                           desc='Test product'))

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:55:30.100184
# Unit test for function product
def test_product():
    import numpy as np
    import warnings
    warnings.filterwarnings("error")
    try:
        with tqdm_auto(total=None) as t:
            for i in tqdm_auto.product(range(10), range(10), range(10)):
                t.update()
    except UserWarning:
        pass
    with np.errstate(invalid='ignore'):
        for i in product(range(10), range(10), range(10)):
            pass
        for i in product(range(10), range(10), range(10)):
            break
        for i in product(range(10), range(10), range(10), total=None):
            pass
        for i in product(range(10), range(10), range(10), total=None):
            break

# Generated at 2022-06-24 09:55:38.339261
# Unit test for function product
def test_product():
    """
    Test if product module works as desired.
    """
    def check_every_input(total, *args):
        """
        Check if `total` is right, and the output matches given `args`.
        """
        assert total == sum([1 for _ in product(*args)])
        assert sum([1 for _ in product(*args)]) == sum([1 for _ in itertools.product(*args)])
        assert len(list(product(*args))) == len(list(itertools.product(*args)))

    def check_every_value(total, *args):
        """
        Check if `total` is right, and the output matches given `args`.
        """
        for i in product(*args):
            assert i in itertools.product(*args)


# Generated at 2022-06-24 09:55:45.901266
# Unit test for function product
def test_product():
    """Unit test for function `product`."""
    with tqdm_auto(total=10) as t:
        assert (list(product(range(10), range(10), tqdm_class=tqdm_auto)) ==
                list(itertools.product(range(10), range(10))))
    with tqdm_auto(total=100) as t:
        assert (list(product(range(10), range(10), range(10), tqdm_class=tqdm_auto)) ==
                list(itertools.product(range(10), range(10), range(10))))

# Generated at 2022-06-24 09:55:57.128790
# Unit test for function product
def test_product():
    from io import StringIO
    import re
    from contextlib import redirect_stdout

    # Unit test for hiding monitor
    with redirect_stdout(StringIO()) as f:
        for _ in product(range(100)):
            pass
        assert re.search(r'100/100', f.getvalue()) is None

    # Unit test for auto monitor
    with redirect_stdout(StringIO()) as f:
        for _ in product(range(100), tqdm=tqdm_auto):
            pass
        assert re.search(r' 100%|\r100/100', f.getvalue()) is not None

    # Unit test for manual monitor
    with redirect_stdout(StringIO()) as f:
        for _ in product(range(100), tqdm=tqdm_auto, disable=False):
            pass

# Generated at 2022-06-24 09:56:07.618543
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    assert len(list(itertools.product([], repeat=2))) == 0
    assert list(itertools.product([1], repeat=2)) == [(1, 1)]
    assert list(itertools.product([1, 2], repeat=2)) == [(1, 1), (1, 2), (2, 1), (2, 2)]
    for x, y in itertools.product([1, 2, 3], [4, 5]):
        assert not (
            (x == 1 and y == 4)
            or
            (x == 2 and y == 4)
            or
            (x == 2 and y == 5)
            or
            (x == 3 and y == 4)
            or
            (x == 3 and y == 5)
        )

# Generated at 2022-06-24 09:56:17.284160
# Unit test for function product
def test_product():
    from numpy import prod
    import os

    # Test 1: single product
    for i in product('abcd', repeat=3):
        assert isinstance(i, tuple) and len(i) == 3
    assert i == ('d', 'd', 'd')

    # Test 2: product x product
    res = []
    for i, j in product(product('abcd', repeat=2), repeat=2):
        assert isinstance(i, tuple) and len(i) == 2
        assert isinstance(j, tuple) and len(j) == 2
        res.append((i, j))
    assert i == ('d', 'd')
    assert j == ('d', 'd')

# Generated at 2022-06-24 09:56:23.495387
# Unit test for function product
def test_product():
    """ Unit tests for function `product` """
    assert list(product(range(1, 11), range(1, 11))) == \
        list(itertools.product(range(1, 11), range(1, 11)))

# Generated at 2022-06-24 09:56:28.702671
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    import random
    import string

    random.seed(0)
    tqdm_kwargs = dict(
        leave=False,
        bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} "
                   "[{elapsed}<{remaining}, {rate_fmt}{postfix}]",
    )

    def rands(n):
        return "".join(random.choice(string.ascii_letters) for _ in range(n))

    print(format_sizeof(rands(0)))

    # Test no total, no desc
    print("Testing no total, no desc")
    for x in product(rands(i) for i in range(10)):
        pass

    # Test total, no desc

# Generated at 2022-06-24 09:56:33.621873
# Unit test for function product
def test_product():
    """
    Test for constant `tqdm.tqdm.product()` output.
    """
    from ..tests_tqdm import pretest_posttest_private_dummy
    return pretest_posttest_private_dummy(product, iterables=[[1], [2, 3], [4, 5]],
                                          testsize=3,
                                          desc="product")

# Generated at 2022-06-24 09:56:42.396395
# Unit test for function product
def test_product():
    from numpy.random import randint
    from numpy import allclose
    from time import sleep
    for i in range(4):
        for j in range(4):
            for k in range(4):
                for l in range(4):
                    a = randint(100000)
                    b = randint(100000)
                    c = randint(100000)
                    d = randint(100000)
                    A = randint(100000)
                    B = randint(100000)
                    C = randint(100000)
                    D = randint(100000)
                    sum1 = 0.0
                    sum2 = 0.0

# Generated at 2022-06-24 09:56:45.577987
# Unit test for function product
def test_product():
    import numpy
    a = numpy.arange(12).reshape(3, 4)
    assert (
        [i for i in product(a, range(5))] ==
        list(itertools.product(a, range(5)))
    )

# Generated at 2022-06-24 09:56:50.197510
# Unit test for function product
def test_product():
    try:
        from collections.abc import Iterator
    except ImportError:
        from collections import Iterator

    assert(isinstance(product(range(10), tqdm_class=tqdm_auto), Iterator))
    assert(len(list(product(range(10), tqdm_class=tqdm_auto))) == 10)

    assert(isinstance(product(range(10), range(10), tqdm_class=tqdm_auto),
                        Iterator))
    assert(len(list(product(range(10), range(10), tqdm_class=tqdm_auto))) ==
           100)

# Generated at 2022-06-24 09:56:55.461446
# Unit test for function product
def test_product():
    import sys
    ip = product(range(10), range(10), range(10), tqdm_class=tqdm_auto)
    assert next(ip) == (0, 0, 0)
    ip = product(range(10), range(10), range(10), tqdm_class=tqdm_auto)
    ip = product(range(10), range(10), range(10), tqdm_class=tqdm_auto, file=None)
    assert next(ip) == (0, 0, 0)
    ip = product(range(10), range(10), range(10), tqdm_class=tqdm_auto)
    ip = product(range(10), range(10), range(10), tqdm_class=tqdm_auto, file=sys.stdout)

# Generated at 2022-06-24 09:57:02.719016
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..auto import tqdm

    with tqdm(total=None) as t:
        assert sum(1 for _ in product(
            range(1000), range(1000), range(1000),
            tqdm_class=t.__class__)) == 1e6


# vim: set sw=4 ts=4 sts=4 expandtab filetype=python

# Generated at 2022-06-24 09:57:09.094597
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText as fc
    import sys

    def str_list(list_):
        return list(map(str, list_))

    pbar = tqdm_auto(product(_range(2), _range(3), _range(4)))
    result_str = [str_list(x) for x in pbar]
    assert result_str == [fc(i) + fc(j) + fc(k)
                          for i in _range(2)
                          for j in _range(3)
                          for k in _range(4)]
    assert pbar.pos == 0
    assert pbar.n == 24

# Generated at 2022-06-24 09:57:11.675887
# Unit test for function product
def test_product():
    for i in product(range(3), repeat=3, desc='Repeated product',
                     bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}',
                     smoothing=0):
        pass

# Generated at 2022-06-24 09:57:21.176124
# Unit test for function product
def test_product():
    from ..utils import _range
    from ..tests import _test_closed
    from sys import version_info

    assert list(product(_range(3))) == list(itertools.product(_range(3)))
    assert list(product(_range(3), _range(2), _range(2))) == list(
        itertools.product(_range(3), _range(2), _range(2)))

    class TqdmTypeError(Exception):
        pass

    class TqdmTypeErrorDisabled(tqdm_auto):
        def format_meter(self, *args, **kwargs):
            raise TqdmTypeError

    assert_raises(TqdmTypeError, list, TqdmTypeErrorDisabled(
        product(_range(2), _range(2))))

# Generated at 2022-06-24 09:57:31.292249
# Unit test for function product
def test_product():
    """Unit test for `itertools.product`."""
    import random
    import string
    import sys
    out = product(string.ascii_letters, repeat=3)
    assert out.__class__.__name__ == 'product'
    assert next(out) == ('a', 'a', 'a')
    # Deliberately do not use timeit for test
    for _ in range(5):
        seq = [random.choice(string.ascii_letters) for _ in range(5)]
        print(repr(seq), end="", file=sys.stderr)
        result = ''.join(out for out in product(seq))
        assert result == "".join(reversed(sorted(result)))

# Generated at 2022-06-24 09:57:42.167338
# Unit test for function product
def test_product():
    import numpy as np

    n = 3
    m = 4
    k = 5
    expected = np.empty((n * m * k))
    expected[0] = 0
    expected[1] = 0
    expected[2] = 1
    expected[3] = 0
    expected[4] = 1
    expected[5] = 1
    expected[6] = 0
    expected[7] = 2
    expected[8] = 1
    expected[9] = 2
    expected[10] = 0
    expected[11] = 3
    expected[12] = 1
    expected[13] = 3
    expected[14] = 0
    expected[15] = 0
    expected[16] = 1
    expected[17] = 0
    expected[18] = 1
    expected[19] = 1

# Generated at 2022-06-24 09:57:44.334105
# Unit test for function product
def test_product():
    from .tests import test_product
    test_product(product)

# Generated at 2022-06-24 09:57:53.800739
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy import allclose
    with tqdm_auto(total=20, leave=True, miniters=1) as t:
        list_ = []
        for i, j in product(range(10), range(2)):
            list_.append(i)
            t.update()
    assert len(list_) == 20, len(list_)
    assert allclose(sorted(list_),
                    [0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
                     7, 7, 8, 8, 9, 9]), sorted(list_)


if __name__ == "__main__":
    from pytest import main
    main([__file__])

# Generated at 2022-06-24 09:58:01.648222
# Unit test for function product
def test_product():
    """Test `product`"""
    import warnings
    warnings.filterwarnings("ignore",
                            message='Passing a `total`',
                            category=RuntimeWarning,
                            module='tqdm')

    m = product([1, 2, 3], repeat=2, tqdm_class=tqdm_auto)

# Generated at 2022-06-24 09:58:11.211095
# Unit test for function product
def test_product():
    """Test all functions above."""
    from random import randint
    import sys

    if sys.version_info < (3, 0):
        range = xrange

    for n in range(3):
        it = product(*[range(n) for _ in range(n)], tqdm_class=tqdm_auto)
        count = 0
        for _ in it:
            count += 1
        assert count == n ** n

    for n in range(3):
        it = product(*[range(n) for _ in range(n)], total=randint(0, 10),
                     tqdm_class=tqdm_auto)
        count = 0
        for _ in it:
            count += 1
        assert count == n ** n

# Generated at 2022-06-24 09:58:15.435797
# Unit test for function product
def test_product():
    """Test function for product"""
    # Test for correct output
    correct = [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(2), range(2))) == correct
    # Test total
    with tqdm_auto(total=10) as t:
        assert list(product(range(2), range(2), tqdm_class=tqdm_auto)) == correct

# Generated at 2022-06-24 09:58:18.500097
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from .tqdm_test_cases import loop_test

    def test_generator():
        for i in product(range(4), range(4), range(4),
                         tqdm_class=tqdm_auto,
                         disable=None):
            yield i

    loop_test(test_generator)

# Generated at 2022-06-24 09:58:27.556767
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    iterables_a = ['ABCD', range(4)]
    iterables_b = ['abcd', range(4)]

    r = list(product(*iterables_a, **{'tqdm_class': tqdm_auto}))
    assert r == [(x, y) for x in 'ABCD' for y in range(4)]

    r = list(product(*iterables_a, **{'tqdm_class': tqdm_auto, 'total': 0}))
    assert r == [(x, y) for x in 'ABCD' for y in range(4)]

    r = list(product(*iterables_a, **{'tqdm_class': tqdm_auto, 'total': 100}))

# Generated at 2022-06-24 09:58:36.362754
# Unit test for function product
def test_product():
    from os import linesep
    from io import StringIO
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class Tests(unittest.TestCase):
        """Tests"""
        def test_product(self):
            """test_product"""
            # See https://github.com/tqdm/tqdm/issues/484
            for i in product(range(10), range(10), tqdm_class=tqdm_auto,
                             leave=False):
                pass

            for i in product(range(10), tqdm_class=tqdm_auto, leave=False):
                pass


# Generated at 2022-06-24 09:58:46.076150
# Unit test for function product
def test_product():
    from .tests.common import BasicTestSuite
    from .tests.common import randomstr

    class ProductTest(BasicTestSuite):
        def test_fb(self):
            a = [1, 2, 3, 4, 5]
            b = 'abcde'
            r = ""
            for i, j in product(a, b):
                r += str(i) + str(j)
            self.assertEqual(r, '1a2b3c4d5e')

        def test_fbr(self):
            a = [1, 2, 3, 4, 5]
            b = 'abcde'
            r = ""
            for i, j in product(a, b, tqdm_class=self.tqdm_class):
                r += str(i) + str(j)

# Generated at 2022-06-24 09:58:49.107392
# Unit test for function product
def test_product():
    equiv = list(product(*[xrange(10)] * 10))
    assert len(equiv) == 1000000000
    assert len(list(product(*[xrange(10000)] * 10))) == 10000000000000000

# Generated at 2022-06-24 09:58:57.826420
# Unit test for function product
def test_product():
    """Test function product."""
    # pylint: disable=missing-docstring, protected-access
    # removing private attributes