

# Generated at 2022-06-24 09:48:47.845299
# Unit test for function product
def test_product():
    """Unit tests to determine if product is working"""
    #TODO

# Generated at 2022-06-24 09:48:48.762092
# Unit test for function product
def test_product():
    # TODO
    pass

# Generated at 2022-06-24 09:48:57.431466
# Unit test for function product
def test_product():
    from operator import mul
    from functools import reduce
    from itertools import izip, count

    class Foo(object):
        def __len__(self):
            return 0

    total_runs = 0
    fail_runs = 0
    *A, = range(2), Foo(), range(3), Foo(), range(5), Foo()
    # check against equivalent length using `izip`
    for i in product(*A, tqdm_class=tqdm_auto, ascii=True, total=None):
        total_runs += 1
        if len(i) != sum(1 for _ in izip(*A)):
            fail_runs += 1
    assert fail_runs == 0

    # check against equivalent length using `izip`
    total_runs = 0
    fail_runs = 0

# Generated at 2022-06-24 09:49:01.725910
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests import get_first_n
    with tqdm_auto(total=10) as t:
        assert get_first_n(t, product(range(10), range(10)), 10) == (
            0, 0, 1, 0, 2, 0, 3, 0, 4, 0)

# Generated at 2022-06-24 09:49:06.415806
# Unit test for function product
def test_product():
    """Test function product"""
    # noinspection PyPep8Naming
    def gen_a(i):
        for j in range(i):
            yield j

    # noinspection PyPep8Naming
    def gen_b(i):
        for j in range(i):
            yield j

    res = list(product(gen_a(25), gen_b(8)))
    assert len(res) == 25 * 8, "std test failed"

    # noinspection PyPep8Naming
    def gen_c(i):
        for j in range(i):
            yield j

    # noinspection PyPep8Naming
    def gen_d(i):
        for j in range(i):
            yield j

    res = list(product(gen_c(5), gen_d(5)))

# Generated at 2022-06-24 09:49:12.938961
# Unit test for function product
def test_product():
    from .trange import trange
    from .tgrange import tgrange
    for iterator in [trange, tgrange]:
        assert sum(product(range(3), range(3),
                           tqdm_class=iterator)) == 36

if __name__ == "__main__":
    from ._version import get_versions

    print((
        "tqdm  {v} ({vv})\n"
        "Python {pyv} on {plat}\n"
    ).format(
        v=get_versions()['version'],
        vv=get_versions()['full-revisionid'],
        pyv=get_versions()['python-version'],
        plat=get_versions()['sys-version'],
    ))
    test_product()

# Generated at 2022-06-24 09:49:15.419411
# Unit test for function product
def test_product():
    """Test for product"""
    for i, j in product(range(3), range(3)):
        pass

# Generated at 2022-06-24 09:49:16.948393
# Unit test for function product
def test_product():
    list(product(range(10), range(10)))



# Generated at 2022-06-24 09:49:22.322155
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`.
    """
    from ..utils import _range, FormatWarn
    from ..tests import pretest_posttest_close

    with pretest_posttest_close(lambda: None) as func:
        with func(lambda: None):
            # noinspection PyTypeChecker
            list(FormatWarn(product(_range(100)))) \
                == list(product(_range(100)))



# Generated at 2022-06-24 09:49:33.178519
# Unit test for function product
def test_product():
    """Unit test for product()"""
    # Test simple use-case
    with tqdm_auto(total=10) as t:
        for i in product(range(5), range(4), tqdm_class=tqdm_auto,
                         total=10):
            pass
        assert sum(1 for i in product(range(5), range(4))) == 20

    # Test empty iterable
    for i in product():
        pass

    # Test generator use-case
    with tqdm_auto(total=10) as t:
        for i in product(range(5), range(4), tqdm_class=tqdm_auto,
                         total=10):
            pass
        assert sum(1 for i in product(range(5), range(4))) == 20
    # Test use with non-generator iterable

# Generated at 2022-06-24 09:49:37.346062
# Unit test for function product
def test_product():
    """
    Unit test for function `product`.
    """
    import tqdm

    def gen_data():
        for _ in tqdm.tqdm(range(10000)):
            yield None

    for i, _ in enumerate(product(gen_data(), gen_data(),
                                  tqdm_class=tqdm.tqdm, total=2)):
        assert i == 0

# Generated at 2022-06-24 09:49:43.659609
# Unit test for function product
def test_product():
    """Test function product"""
    import sys
    if sys.version_info[0] >= 3:
        s = 'abcde'
        actual = set(product(s, repeat=3))
        # Don't use assertSetEqual due to Python < 3.2
        expected = set(itertools.product(s, repeat=3))
        assert actual == expected

if __name__ == '__main__':
    from ..main import _main
    _main(__file__)

# Generated at 2022-06-24 09:49:49.780253
# Unit test for function product
def test_product():
    """
    Simple test for the product() wrapper
    """
    from nose.tools import assert_equals
    from numpy.random import randint
    from numpy import prod
    for i in range(3):
        for j in range(3):
            for k in range(3):
                assert_equals(sum(1 for _ in product(range(i),
                                                     range(j),
                                                     range(k))),
                              prod([i, j, k]))

# Generated at 2022-06-24 09:49:56.335046
# Unit test for function product
def test_product():
    with tqdm_auto(total=5, desc="product") as t1:
        for i in product(range(3),
                         range(3),
                         total=5,
                         desc="product",
                         unit="it",
                         leave=True,
                         disable=False):
            assert t1.total == 5
            assert t1.desc == "product"
            assert t1.unit == "it"
            assert t1.leave
            assert not t1.disable
            t1.update()

    assert t1.n == 5
    assert t1.total == 5

    assert t1.last_print_n == t1.n

# Generated at 2022-06-24 09:50:03.478049
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from .tests_tqdm import with_setup  # NOQA, analysis:ignore
    with_setup(setup=None, teardown=None)

# Generated at 2022-06-24 09:50:05.822455
# Unit test for function product
def test_product():
    """Unit test for `itertools.product`"""
    list(tqdm.tqdm_product(range(10), range(10)))

# Generated at 2022-06-24 09:50:13.867856
# Unit test for function product
def test_product():
    """
    Test-case for function product
    """
    import contextlib
    # Test case 1: no total, __len__() not implemented:
    total1 = -1
    for i in product([0, 1, 2], tqdm_class=contextlib.suppress(stop=True)):
        total1 += 1
        assert total1 == sum(i)
    # Test case 2: no total, __len__() implemented:
    total2 = -1
    for i in product([0, 1], [2, 3, 4], [5, 6, 7, 8], tqdm_class=contextlib.suppress(stop=True)):
        total2 += 1
        assert total2 == sum(i)
    # Test case 3: total, __len__() not implemented:
    total3 = -1

# Generated at 2022-06-24 09:50:19.229575
# Unit test for function product
def test_product():
    """Test function `product`."""
    import nose.tools as nt

    with nt.assert_raises(TypeError):
        iter(product(xrange(3), xrange(3, 6)))

    iter(product(xrange(3), xrange(3, 6), tqdm_class=tqdm_auto))


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:50:23.814041
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    iterables = [[1, 2], ['a', 'b', 'c'], [u"p", u"q"]]
    # Compute full list
    expected_list = list(itertools.product(*iterables))
    # Compute list using product
    prod_list = list(product(desc="product", *iterables))
    assert expected_list == prod_list

# Generated at 2022-06-24 09:50:31.824174
# Unit test for function product
def test_product():
    from numpy import prod
    from numpy.random import random
    n = 10
    for n_iter in [1, 5, 10, 100]:
        for n_dim in range(1, n):  # including 0
            for mult in [1, 10, 100, 1000]:
                for disable in [False, True]:
                    iterables = [range(m) for m in random.randint(
                        1, n, size=n_dim) * mult]
                    total = prod([len(it) for it in iterables])
                    # First without tqdm
                    gen = product(*iterables, tqdm_class=None)
                    assert not hasattr(gen, "n")
                    assert not hasattr(gen, "total")
                    assert not hasattr(gen, "disable")
                    assert len(list(gen)) == total


# Generated at 2022-06-24 09:50:39.882757
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import sys
    import numpy as np

    from ..utils import format_sizeof
    from ..__main__ import main as tqdm_main

    def run_test(iterable, total=None, tqdm_class=tqdm_auto,
                 unit_scale=None, leave=False, desc=None,
                 dynamic_ncols=False, unit_divisor=1024, ascii=None,
                 mininterval=0, **kwargs):
        res = []

# Generated at 2022-06-24 09:50:48.929690
# Unit test for function product
def test_product():
    """Test function product"""
    a = list(product(range(2), range(2), range(2)))
    assert a == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                 (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
    a = list(product(range(2), range(2), range(2), tqdm_class=tqdm_auto))
    assert a == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                 (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-24 09:50:55.315253
# Unit test for function product
def test_product():
    for i in product(['a', 'b', 'c'], repeat=3, tqdm_class=None):
        pass
    assert i == ('c', 'c', 'c')
    gen = product(['a', 'b', 'c'], repeat=3)
    assert next(gen) == ('a', 'a', 'a')
    gen.close()


#Backward-compatibility
tqdm_product = product
tqdm_itertools = product

# Generated at 2022-06-24 09:51:04.253576
# Unit test for function product
def test_product():
    assert list(product(range(4))) == list(itertools.product(range(4)))
    assert list(product(range(4), repeat=3)) == \
        list(itertools.product(range(4), repeat=3))
    assert list(product({1, 2})) == list(itertools.product({1, 2}))
    assert list(product({1, 2})) == list(itertools.product({1, 2}))
    assert list(product({1, 2}, "ab")) == list(itertools.product({1, 2}, "ab"))
    assert list(product({1, 2}, repeat=2)) == \
        list(itertools.product({1, 2}, repeat=2))

# Generated at 2022-06-24 09:51:09.180414
# Unit test for function product
def test_product():
    total = 1
    for i in map(len, [range(10), range(20)]):
        total *= i
    with tqdm_auto(total=total) as t:
        for i in product(range(10), range(20)):
            assert i[0] < 10
            assert i[1] < 20
            t.update()

# Generated at 2022-06-24 09:51:16.616710
# Unit test for function product
def test_product():
    from ..utils import format_sizeof
    iterables = [[1, 2], ['a', 'b'], ['A', 'B'],
                 ['aa', 'bb', 'cc'], ['AA', 'BB', 'CC'],
                 ['aaa', 'bbb', 'ccc']]

# Generated at 2022-06-24 09:51:20.339244
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ._utils import TestingIO  # pylint: disable=import-error
    with TestingIO():
        list(product(range(5), range(5)))

# Generated at 2022-06-24 09:51:29.562022
# Unit test for function product
def test_product():
    """Tests that `tqdm.itertools.product` yields the same results as `itertools.product`."""
    # Basic tests
    assert (set(product([1, 2, 3], repeat=2)) ==
            set(itertools.product([1, 2, 3], repeat=2)))
    assert (set(product([1, 2, 3], repeat=0)) ==
            set(itertools.product([1, 2, 3], repeat=0)))
    assert (set(product([1, 2, 3], repeat=-1)) ==
            set(itertools.product([1, 2, 3], repeat=-1)))

    # Custom tests

# Generated at 2022-06-24 09:51:31.384525
# Unit test for function product
def test_product():
    for i in product("hello", "world", tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:51:41.321653
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from operator import mul, itemgetter
    import random
    import sys
    from .utils import _range

    iterables = [
        _range(3),
        _range(4),
        _range(2),
        "abcd"
    ]
    for i in product(*iterables):
        assert i in itertools.product(*iterables)

    p = product(itertools.repeat(1), itertools.repeat(2), repeat=10)
    assert next(p) == tuple([1] * 10)
    assert next(p) == tuple([2] * 10)
    assert next(p) == tuple([1] * 10)
    assert next(p) == tuple([2] * 10)
    with pytest.raises(StopIteration):
        next(p)

# Generated at 2022-06-24 09:51:48.250047
# Unit test for function product
def test_product():
    from itertools import product as it_product
    from numpy import product as np_product
    from numpy import prod as np_prod
    from numpy import array as np_array
    from numpy import float64 as np_float64
    from ..utils import FormatCustomTextFloat as FormatCustomText

    tqdm_auto_inst = tqdm_auto(range(10), '', leave=False)
    tqdm_auto_inst_format = tqdm_auto(range(10),
                                      '', leave=False,
                                      format=FormatCustomText())
    tqdm_auto_inst_bar_format = tqdm_auto(range(10),
                                          '', leave=False,
                                          bar_format=FormatCustomText())


# Generated at 2022-06-24 09:51:49.517327
# Unit test for function product
def test_product():
    for _ in product((4, 5, 6), repeat=3,tqdm_class=None):
        pass

# Generated at 2022-06-24 09:51:59.680166
# Unit test for function product
def test_product():
    """
    Ensure that the products are identical with and without `tqdm`.

    Note
    ----
    The only way to make sure that the tqdm iterators behave exactly the same
    as the non-tqdm iterator, is to evaluate it completely.
    """
    from collections import Counter

    for tqdm_class in (tqdm_auto, None):
        if tqdm_class is None:
            tqdm_func = lambda x: x
        else:
            tqdm_func = lambda x: tqdm_class(x, leave=True)

        it1 = itertools.product(range(100), tqdm_func(range(1000)))
        it2 = tqdm_func(product(range(100), range(1000)))

        assert Counter(it1) == Counter(it2)



# Generated at 2022-06-24 09:52:03.148815
# Unit test for function product
def test_product():
    from .utils import closing
    from .utils import TemporaryFile
    from .utils import FakeTqdmFile

    with closing(TemporaryFile()) as f:
        for _ in product(range(1000), range(1000),
                         tqdm_class=tqdm_auto,
                         file=FakeTqdmFile(f)):
            pass

# Generated at 2022-06-24 09:52:08.169797
# Unit test for function product
def test_product():
    with product("ABC", "123") as p:
        assert list(p) == [("A", "1"), ("A", "2"), ("A", "3"),
                           ("B", "1"), ("B", "2"), ("B", "3"),
                           ("C", "1"), ("C", "2"), ("C", "3")]

# Generated at 2022-06-24 09:52:16.174891
# Unit test for function product
def test_product():
    """
    Unit tests for itertools.product.
    """
    assert list(itertools.product('ABCD', 'xy')) == \
        list(product('ABCD', 'xy'))

    assert list(itertools.product(range(2), repeat=4)) == \
        list(product(range(2), repeat=4))

    assert product(
        [1, 2, 3], repeat=2, tqdm_class=tqdm_auto).n == 9

    assert product(
        [1, 2, 3], repeat=2, tqdm_class=tqdm_auto).last_print_n == 9

    assert product(
        [1, 2, 3], repeat=2, tqdm_class=tqdm_auto).total == 9


# Generated at 2022-06-24 09:52:21.899782
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for _ in product(range(2), range(2), range(2), range(2),
                     tqdm_class=tqdm_auto):
        pass
    assert _ == (1, 1, 1, 1)


if __name__ == "__main__":  # pragma: no cover
    kwargs = {}
    kwargs['total'] = 100
    for i in product(range(1), range(1), range(1), range(1),
                     tqdm_class=tqdm_auto, **kwargs):
        pass

# Generated at 2022-06-24 09:52:23.062234
# Unit test for function product
def test_product():
    for i in product(range(4), range(4), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:52:27.594173
# Unit test for function product
def test_product():
    from .tests_tqdm import pretest_posttest

    # Test input == generator
    @pretest_posttest
    def f():
        for i in product(range(3), range(3), range(3)):
            yield i
    list(f())

    # Test input == list
    @pretest_posttest
    def f():
        for i in product([0, 1, 2], [0, 1, 2], [0, 1, 2]):
            yield i
    list(f())

    # Test total=None
    @pretest_posttest
    def f():
        for i in product([], [], []):
            yield i
    list(f())

# Generated at 2022-06-24 09:52:30.637273
# Unit test for function product
def test_product():
    # trivial
    for i in range(100):
        for j in range(100):
            for a, b in product(range(i), range(j)):
                assert a < i and b < j


# Generated at 2022-06-24 09:52:40.791893
# Unit test for function product
def test_product():
    """
    Unit test for function product.

    Tests the function against itertools.product.
    """
    import numpy as np

    i = list(range(10))
    j = list(range(100))
    k = list(range(1000))

    for it in [product(i), product(i, j), product(i, j, k)]:
        for x in it:
            pass
        assert x == (9, 99, 999)

    it = product(i, j, k, tqdm_class=None)
    for x in it:
        pass
    assert x == (9, 99, 999)

    it1 = product(i, j, tqdm_class=None)
    for _ in it1:
        pass
    assert _ == (9, 99)


# Generated at 2022-06-24 09:52:51.340279
# Unit test for function product
def test_product():
    """ Unit test for function `tqdm.itertools.product` """
    from .tests import TestCase, _range

    for tqdm_cls in [tqdm_auto]:
        with TestCase(tqdm_cls) as tc:
            for iterable in tc.iterables:
                for x in tqdm_cls.itertools.product(iterable):
                    tc.assertTrue(*x)
            for iterable in tc.iterables:
                for x in tqdm_cls.itertools.product(*iterable):
                    tc.assertTrue(*x)
            for iterable in tc.iterables:
                for x in tqdm_cls.itertools.product(_range(3)):
                    tc.assertTrue(*x)

# Generated at 2022-06-24 09:52:59.930429
# Unit test for function product
def test_product():
    """Test for `tqdm.std.itertools.product`"""
    from nose.tools import assert_equal

    assert_equal(len(list(product([1, 2], [3, 4]))), 4)
    assert_equal(len(list(product(range(10), repeat=4))), 10000)

# Generated at 2022-06-24 09:53:06.059782
# Unit test for function product
def test_product():
    from io import StringIO
    import sys
    from .utils import format_sizeof

    results = []
    for i in product(range(3), repeat=3, tqdm_class=tqdm_auto):
        results.append(i)
    assert len(results) == 27

    # unit test (for size and time)
    # NOTE: apparently Jupyter displays "size" in human-readable format
    # and pytest does not: https://github.com/tqdm/tqdm/issues/582
    buf = StringIO()
    sys.stdout = buf
    for i in product(range(30000), repeat=3, tqdm_class=tqdm_auto):
        pass
    sys.stdout = sys.__stdout__
    assert ' | ' in buf.getvalue()

# Generated at 2022-06-24 09:53:15.437586
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np
    from ..utils import format_sizeof

    for i, (A, B) in enumerate(product(range(100), range(100))):
        if (A * B != i):
            raise AssertionError(A, B, i)
        if (A + B != i % 200):
            raise AssertionError(A, B, i)

    for i, (A, B) in enumerate(product(range(100), range(100))):
        if (A * B != i):
            raise AssertionError(A, B, i)
        if (A + B != i % 200):
            raise AssertionError(A, B, i)


# Generated at 2022-06-24 09:53:19.201747
# Unit test for function product
def test_product():
    from operator import mul

    iprod = 1
    for i in range(1, 10000):
        iprod *= i
    assert sum(i for i in product(range(1, 10000))) == iprod

# Generated at 2022-06-24 09:53:30.372465
# Unit test for function product
def test_product():
    from numpy import product as np
    from numpy.random import randint
    for N, M, O in product(range(10), repeat=3):
        with tqdm_auto(total=N) as t1:
            assert product(range(n) for n in (N, M, O)) == np(N, M, O)
            assert total(t1) == np(N, M, O)
        with tqdm_auto(total=N) as t1:
            assert list(product(range(n) for n in (N, M, O))) == list(
                itertools.product(range(N), range(M), range(O)))
            assert total(t1) == np(N, M, O)

# Generated at 2022-06-24 09:53:34.626728
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy.random import random
    a = random((50, 10))
    b = random((30, 10))
    c = random((70, 10))
    true_z = sum(itertools.product(((a, b, c),)))
    z = sum(product(a, b, c))
    assert z == true_z

# Generated at 2022-06-24 09:53:45.359978
# Unit test for function product
def test_product():
    from random import random
    from string import ascii_letters
    from ..utils import format_sizeof
    l = [int(random() * 10**i) for i in range(7)]
    s = [ascii_letters[int(random() * 52)] for i in range(7)]
    res = list(product(l, repeat=3))
    assert res == list(itertools.product(l, repeat=3))
    res = list(product(s, repeat=3))
    assert res == list(itertools.product(s, repeat=3))
    res = list(product(l, repeat=3, tqdm_class=tqdm_auto))
    assert res == list(itertools.product(l, repeat=3))

# Generated at 2022-06-24 09:53:54.096311
# Unit test for function product
def test_product():
    from pytest import approx
    p = product([1, 2, 3], [4, 7, 8], [5, 9, 0], [6, 10, 11],
                tqdm_class=tqdm_auto, desc="My Product", leave=False)
    vals = list(p)

# Generated at 2022-06-24 09:53:59.069413
# Unit test for function product
def test_product():
    """Simple unit test for function product"""
    from numpy.random import randint

    for i in product(range(4), range(4), range(4), tqdm_class=tqdm_auto):
        pass
    for i in product(randint(1, 3, 216), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:54:06.740036
# Unit test for function product
def test_product():
    import operator
    from tqdm import trange

    def _test(desc, a, b, *iterables):
        print(desc)
        p = product(*iterables, total=50)
        assert list(p) == list(itertools.product(*iterables))
        print('OK')

    for i in trange(10):
        _test('size', i, i, range(i), range(i))
        _test('size', i, i, range(i), range(i), range(i), range(i), range(i),
              range(i))

# Generated at 2022-06-24 09:54:16.881097
# Unit test for function product
def test_product():
    import sys
    # Testing basic function
    assert list(product("AB", "12", tqdm_class=None)) == [
        ('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]
    # Testing with tqdm_class=None
    assert list(product("AB", "12", tqdm_class=None)) == [
        ('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]
    # Testing with tqdm_class=tqdm
    assert list(product("AB", "12")) == [('A', '1'), ('A', '2'), ('B', '1'), ('B', '2')]
    # Testing with tqdm_class=tqdm and args

# Generated at 2022-06-24 09:54:25.974544
# Unit test for function product
def test_product():
    prod = product(range(3), range(3), range(3), tqdm_class=None)

# Generated at 2022-06-24 09:54:32.872613
# Unit test for function product
def test_product():
    from .tests import test

    # Closed by hand
    def check_product():
        _ = list(itertools.product(range(10), repeat=2))
        _ = list(product(range(10), repeat=2))
        for i in product(range(10), repeat=2):
            pass
        for i in product(range(10), range(10), repeat=2):
            pass

    test(check_product)

# Generated at 2022-06-24 09:54:40.277041
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for const in range(1, 5):
        for i in product(list(range(const)),
                         [3.4, 5],
                         list(range(const))):
            assert i == (int(i[0]), float(i[1]), int(i[2]))

    for i in product([1], [2], [3]):
        assert i == (1, 2, 3)
        break

    for i in product([1], [2], [3]):
        assert i == (1, 2, 3)
        break

# Generated at 2022-06-24 09:54:45.679461
# Unit test for function product
def test_product():
    # Unit test for function product
    l = list(product([1, 2], repeat=2))
    assert len(l) == 4
    assert l[0][0] == 1 and l[0][1] == 1
    assert l[1][0] == 1 and l[1][1] == 2
    assert l[2][0] == 2 and l[2][1] == 1
    assert l[3][0] == 2 and l[3][1] == 2

# Generated at 2022-06-24 09:54:49.420499
# Unit test for function product
def test_product():
    from .tests import TestCase
    with TestCase() as tc:
        for i in product(range(4), range(4), tqdm_class=tc.tqdm):
            pass
        tc.assertEqual(tc.total, 16, "Invalid total value.")

# Generated at 2022-06-24 09:55:00.191629
# Unit test for function product
def test_product():
    assert sum(1 for _ in product(*[[1, 2, 3]])) == 3**1

    assert sum(1 for _ in product(*[[1, 2, 3], [1, 2, 3]])) == 3**2

    assert sum(1 for _ in product(*[[1, 2, 3], [1, 2, 3], [1, 2, 3]])) \
        == 3**3


# Generated at 2022-06-24 09:55:10.218773
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import nose
    from random import randint
    from ..utils import format_sizeof

    def checker(a, b):
        """
        Check that the outputs of itertools.product and tqdm.itertools.product
        are equivalent for lists `a` and `b`.
        """
        nose.tools.eq_(list(itertools.product(a, b)),
                       list(tqdm.itertools.product(a, b)),
                       'itertools.product and tqdm.itertools.product are ' 'different!')

    class Integer():
        """
        Class for returning a random integer as a generator
        """

# Generated at 2022-06-24 09:55:22.493671
# Unit test for function product
def test_product():
    from random import randrange
    from sys import maxsize
    from itertools import product, islice

    for i in range(0, 5):
        l1 = [randrange(1, maxsize) for _ in range(i)]
        l2 = [randrange(1, maxsize) for _ in range(i + 1)]
        assert tuple(islice(product(l1, l2), maxsize)) == \
            tuple(islice(product(l1, l2, tqdm_class=None), maxsize))
        l3 = [randrange(1, maxsize) for _ in range(i + 2)]

# Generated at 2022-06-24 09:55:24.399252
# Unit test for function product
def test_product():
    import tqdm
    N = 7
    assert sum(1 for _ in tqdm.product(range(N), repeat=2)) == N**2
    assert sum(1 for _ in tqdm.product(range(N), repeat=N)) == N**N

# Generated at 2022-06-24 09:55:31.300184
# Unit test for function product
def test_product():
    from ..std import list
    iterables = [[1, 2], [11, 22, 33], [], [44, 55]]
    len_exp = [2, 3, 0, 2]
    j = 0
    for i in range(len(iterables)):
        for _ in product(iterables[i]):
            j += 1
        assert j == len_exp[i]
        j = 0
    assert list(product([1, 2, 3], [4, 5])) == [(1, 4), (1, 5), (2, 4), (2, 5), (3, 4), (3, 5)]

# Generated at 2022-06-24 09:55:35.904261
# Unit test for function product
def test_product():
    """
    Test the function product through its `total` argument.
    """
    # test passing `total`
    for i in product(range(4), range(3), tqdm_class=tqdm_auto, total=12):
        pass
    # test not passing `total`
    for i in product(range(4), range(3), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:55:39.063389
# Unit test for function product
def test_product():
    for i in product(
        ['a', 'b', 'c'], [1, 2], tqdm_class=tqdm_auto,
        desc="test_product"
    ):
        print(i)

# Generated at 2022-06-24 09:55:40.558525
# Unit test for function product
def test_product():
    result = list(product(range(10), repeat=5))
    assert len(result) == 100000
    assert result[-1] == (9, 9, 9, 9, 9)

# Generated at 2022-06-24 09:55:48.625432
# Unit test for function product
def test_product():
    """
    Test `tqdm.itertools.product`.
    """
    from ..utils import AllLengths, colour_text
    iterables = [
        AllLengths(3, [0, 1]),
        AllLengths(5, (x * x for x in range(2, 5))),
        AllLengths(7, ('.' * x for x in [1, 2, 2, 3, 2, 1, 2]))]
    with AllLengths(11):
        for _, x in product(*iterables):
            pass
    assert sum(len(x) for x in iterables) > 10
    for _ in range(2):
        for _, x in product(*iterables, tqdm_class=tqdm_auto):
            pass


# Generated at 2022-06-24 09:55:57.992484
# Unit test for function product
def test_product():
    """
    Unit test for `tqdm.itertools.product`.
    """
    from collections import Counter
    from .testing import _TestDataCount

    # Check sanity
    for args in ((), 0, [], [[]]):
        assert list(product(args)) == []

    # Check sum product
    for args in (([1], ), ([1, 2], ), ([1, 2, 3], ), ([1, 2], [3, 4])):
        assert sum(1 for _ in product(*args)) == \
            reduce(lambda x, y: x*y, map(len, args))

    # Check values:

# Generated at 2022-06-24 09:56:01.058056
# Unit test for function product
def test_product():
    import random
    random.seed(42)
    for n in [0, 1, 1000, 10000]:
        L = list(range(n))
        if not L:
            L = []
        assert list(itertools.product(L)) == list(product(L))

# Generated at 2022-06-24 09:56:04.847072
# Unit test for function product
def test_product():
    for p in product(range(4), range(10), range(2)):
        pass
    for p in product(range(4), range(10), range(2), tqdm_class=tqdm_auto):
        pass

# Generated at 2022-06-24 09:56:16.662339
# Unit test for function product
def test_product():
    """Test for `product` (using above wrapper)."""
    results = [i ** 2 for i in tqdm.tmap(product, [range(10)] * 5)]
    assert results == list(itertools.product(*[range(10)] * 5))
    results = [i ** 2 for i in tqdm.tmap(product, [range(10)], [range(10)])]
    assert results == list(itertools.product(*[range(10), range(10)]))
    results = [i ** 2 for i in tqdm.tmap(product,
                                         [range(8)] * 5,
                                         tqdm_class=tqdm.tqdm_notebook)]
    assert results == list(itertools.product(*[range(8)] * 5))



# Generated at 2022-06-24 09:56:27.532745
# Unit test for function product
def test_product():

    from .utils import format_sizeof
    from .utils import testing

    # pylint: disable=undefined-variable
    class A(object):

        def __len__(self):
            return 1

        def __iter__(self):
            for i in range(3):
                yield i

    class B(object):

        def __len__(self):
            return 2

        def __iter__(self):
            for i in range(2):
                yield i

    # pylint: enable=undefined-variable

    try:
        import numpy as np
    except ImportError:
        np = None

    # No crash on unknown argument
    try:
        product([1], tqdm_class=tqdm_auto, unknown=None)
    except TypeError:
        pass  # expected

# Generated at 2022-06-24 09:56:33.793683
# Unit test for function product
def test_product():
    """Tests `itertools.product`"""
    ret = True
    for i in product(range(7), repeat=4):
        assert (i[0] < 7 and i[1] < 7 and i[2] < 7 and i[3] < 7), \
            "problem in itertools.product"
    for j in range(7):
        for i in product(range(j), repeat=4):
            ret = False
    assert ret, "problem in itertools.product"

# Generated at 2022-06-24 09:56:42.556072
# Unit test for function product
def test_product():
    assert list(product([1], [2])) == [(1,2)]
    assert list(product([1, 2], [3, 4])) == [(1,3), (1,4), (2,3), (2,4)]
    assert list(product([1, 2], [3, 4], [5, 6])) == [(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6), (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)]

# Generated at 2022-06-24 09:56:51.875135
# Unit test for function product
def test_product():
    """Unit test for product"""
    assert list(product("AB", "12")) == [("A", "1"), ("A", "2"), ("B", "1"), ("B", "2")]
    assert list(product("AB", repeat=2)) == [("A", "A"), ("A", "B"), ("B", "A"), ("B", "B")]

# Generated at 2022-06-24 09:57:03.649796
# Unit test for function product
def test_product():
    from .tests import TestCase, closing

    with closing(TestCase()) as t:
        # Test that product works
        t.assertEqual(
            list(product([1, 2, 3], repeat=2)),
            [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)])

        # Test that tqdm works
        p = product([1, 2, 3], repeat=2, tqdm_class=t.cls)
        t.assertEqual(t.len(t), len(list(p)) - 1)
        t.assertIn("itertools.product", t.out)

        # Test bar_format
        t.out = ""

# Generated at 2022-06-24 09:57:14.682171
# Unit test for function product
def test_product():
    """
    Unit test of function itertools.product, using tqdm.product.
    """
    import numpy

    numpy.random.seed(123)
    a = [numpy.random.rand(100) for i in range(10)]
    aa = []
    for i in itertools.product(*a):
        aa.append(i)
    b = [numpy.random.rand(100) for i in range(10)]
    bb = []
    for i in product(*b):
        bb.append(i)
    assert numpy.all(aa == bb)
    aa = []
    for i in itertools.product(a):
        aa.append(i)
    bb = []
    for i in product(b):
        bb.append(i)

# Generated at 2022-06-24 09:57:21.734584
# Unit test for function product
def test_product():
    for i in product(range(10), range(10), tqdm_class=tqdm_auto, ascii=True):
        pass
    for i in product(range(100), range(100), tqdm_class=tqdm_auto, ascii=True):
        pass
    for i in product(list(range(100)), list(range(100)),
                     tqdm_class=tqdm_auto, ascii=True):
        pass
    c = product(range(10), range(10), tqdm_class=tqdm_auto, ascii=True)
    c.__length_hint__()

# Generated at 2022-06-24 09:57:32.066881
# Unit test for function product
def test_product():
    """
    Test :func:`tqdm.utils.product`

    """
    from ..tqdm_gui import tqdm
    from .term_move import hidden_cursor

    with hidden_cursor():

        assert list(product(["a", "b", "c"], repeat=2)) == \
            [("a", "a"), ("a", "b"), ("a", "c"),
             ("b", "a"), ("b", "b"), ("b", "c"),
             ("c", "a"), ("c", "b"), ("c", "c")]


# Generated at 2022-06-24 09:57:42.218310
# Unit test for function product
def test_product():
    """
    Unit test for function `tqdm.itertools.product`.
    """
    from .gui import tqdm_notebook

    for n in [None, 1, 2]:
        for t in [None, 1, 2]:
            for i in [0, 1]:
                for j in [0, 1]:
                    for p in [False, True]:
                        if i == 1 and n is None:
                            continue  # n not defined when i == 1
                        if j == 1 and t is None:
                            continue  # t not defined when j == 1
                        if j == 1 and not p:
                            continue  # t defined but p == False
                        total = None if (n is None) else (n ** i)

# Generated at 2022-06-24 09:57:52.159484
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    if tqdm_auto is None:
        raise unittest.SkipTest("Skipping test")
    import numpy as np
    if np.array([1]).any():
        return  # Test Suite in python 2.6 does not mock any()
    assert list(product("abc", tqdm_class=tqdm_auto)) == [
        ("a",), ("b",), ("c",)]
    assert list(product("abc", "de", tqdm_class=tqdm_auto)) == [
        ("a", "d"), ("a", "e"), ("b", "d"), ("b", "e"), ("c", "d"), ("c", "e")]

# Generated at 2022-06-24 09:58:00.459818
# Unit test for function product
def test_product():
    """Test product"""
    from ._deprecations import PY36_OR_GREATER

    expected = [
        (1, 'a'), (1, 'b'), (1, 'c'),
        (2, 'a'), (2, 'b'), (2, 'c'),
        (3, 'a'), (3, 'b'), (3, 'c')]
    actual = list(product([1, 2, 3], 'abc', tqdm_class=tqdm_auto))
    assert expected == actual

    expected = [
        (1, 'a'), (1, 'b'), (1, 'c'),
        (2, 'a'), (2, 'b'), (2, 'c'),
        (3, 'a'), (3, 'b'), (3, 'c')]

# Generated at 2022-06-24 09:58:10.388420
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from numpy import product as nprod
    from numpy import all
    from numpy.random import randint
    kwargs = {"miniters": 1, "leave": True}
    # Test 1
    out = list(product(*(iter(range(r)) for r in randint(2, 11, 4))))
    assert all(nprod(out, 0) == nprod(xrange(max(randint(2, 11, 4))), 0))
    # Test 2
    out = list(product(*(xrange(randint(1000)) for _ in xrange(4)),
                        **kwargs))
    assert all(nprod(out, 0) == nprod(xrange(max(randint(1000))), 0))

# Generated at 2022-06-24 09:58:20.553280
# Unit test for function product
def test_product():
    from random import randrange
    from itertools import product as it_product
    from .utils import IN_IPYNB, _range

    # Test many iterators
    for l in _range(2, 20):
        iterables = [range(randrange(1, 20)) for _ in _range(l)]
        products = tuple(product(*iterables))
        assert products == it_product(*iterables)
        for prod in products:
            assert len(prod) == len(iterables)

    # Test with tqdm_class
    from ..std import tqdm
    assert tuple(product(tqdm_class=tqdm, iterable=range(100))) == \
        tuple(it_product(range(100)))

    # Test with total
    assert tuple(product(iterable=range(100), total=100))

# Generated at 2022-06-24 09:58:31.247724
# Unit test for function product
def test_product():
    """Test for `product`"""
    from .pandas import DataFrame
    from .iterable import _range
    from .numpy import array

    total = 0
    for _ in product(_range(10), _range(4)):
        total += 1
    assert total == 40

    # Test for pandas.DataFrame
    df = DataFrame(index=['a', 'b', 'c'], columns=['d', 'e', 'f'])
    total = 0
    for _ in product(df):
        total += 1
    assert total == len(df)

    # Test for numpy.array
    arr = array([['a', 'b'], ['c', 'd']])
    total = 0
    for _ in product(arr):
        total += 1
    assert total == 4

    # Test for None


# Generated at 2022-06-24 09:58:38.894733
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from ._utils import closing_bar, mock
    from ._utils import nullcontext as nullcontext_patch

    with nullcontext_patch() as nullcontext:
        with mock.patch('tqdm.std.itertools', new=itertools) as m:
            with mock.patch('tqdm.std.tqdm',
                            new=closing_bar) as n:
                # no error should occur
                with product([1, 2], [3, 4]) as p:
                    for i in p:
                        pass

        # should not raise exception even
        # if not iterable

# Generated at 2022-06-24 09:58:45.674002
# Unit test for function product
def test_product():
    """Test that product uses tqdm_class properly."""
    result = repr(list(product(range(3), tqdm_class=tqdm_auto)))
    expected = repr(list(product(range(3))))
    assert result == expected

if __name__ == '__main__':
    from subprocess import call
    from os import path
    src = path.dirname(path.abspath(__file__))
    call('echo "from . import ' + __name__ + '" | python ' + path.join(src, 'itertools.py'), shell=True)

# Generated at 2022-06-24 09:58:56.033305
# Unit test for function product
def test_product():
    """Test `product` function."""
    x = (2, 3, 2)
    res = sum(1 for _ in product(*x))
    assert res == 12, res

    x = range(10)
    res = sum(1 for _ in product(*x))
    assert res == 3628800, res

    x = [[0, 1], ["a", "b"]]
    res = list(product(*x))
    assert res == [(0, 'a'), (0, 'b'), (1, 'a'), (1, 'b')], res

    x = [{0, 1}, {"a", "b"}]
    res = list(product(*x))
    assert len(res) == 4, res

    x = range(1, 26)