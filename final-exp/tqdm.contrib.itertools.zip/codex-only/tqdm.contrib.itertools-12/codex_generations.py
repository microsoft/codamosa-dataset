

# Generated at 2022-06-24 09:48:57.691927
# Unit test for function product
def test_product():
    # Define the iterates
    all_iterables = [
        range(1000),
        range(10),
        range(100),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(10),
        range(1000)
    ]

    # Make the product (using explicit tqdm class)
    my_product = product(*all_iterables, tqdm_class=tqdm_auto)
    my_product_list = [i for i in my_product]

    # Make the

# Generated at 2022-06-24 09:49:06.871355
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import os
    import sys
    import math
    from ..utils import _range

    # Set defaults of tqdm_notebook function
    tqdm_kwargs = {}

# Generated at 2022-06-24 09:49:16.752957
# Unit test for function product
def test_product():
    """
    Test for `product()` wrapping `itertools.product()`.
    """
    from pyprind.prog_bar import ProgBar

    assert list(product(range(2), repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]
    assert list(product(range(2), repeat=3)) == [(0, 0, 0), (0, 0, 1),
                                                 (0, 1, 0), (0, 1, 1),
                                                 (1, 0, 0), (1, 0, 1),
                                                 (1, 1, 0), (1, 1, 1)]

# Generated at 2022-06-24 09:49:20.927080
# Unit test for function product
def test_product():
    assert list(product([1, 2], [3, 4])) == list(itertools.product([1, 2], [3, 4]))
    assert list(product([1, 2], [3, 4], tqdm_class=None)) == list(itertools.product([1, 2], [3, 4]))



# Generated at 2022-06-24 09:49:28.935725
# Unit test for function product
def test_product():
    import nose.tools as nt
    l = list(range(1, 10))
    l2 = [x + 10 for x in l]
    # assert all([x == y for x, y in product(l, l2)])  # probably not
    nt.assert_equal(list(product(l, l2)),
                    [x for x in itertools.product(l, l2)])
    l3 = [x + 100 for x in l]
    nt.assert_equal(list(product(l, l2, l3)),
                    [x for x in itertools.product(l, l2, l3)])

# Generated at 2022-06-24 09:49:33.921218
# Unit test for function product
def test_product():
    from .utils import FormatMixinTest
    lists = [[1, 2, 3], [1., 2., 3.]]
    g = product(*lists)
    assert isinstance(g, FormatMixinTest)
    assert len(list(g)) == len(lists[0]) * len(lists[1])

# Generated at 2022-06-24 09:49:40.385742
# Unit test for function product
def test_product():
    # Test case where no progress bar is required
    assert tuple(product(range(5), range(5), range(5), range(5),
                         range(5), range(5), use_tqdm=False)) == \
           tuple(itertools.product(range(5), range(5), range(5),
                                   range(5), range(5), range(5)))!= \
           tuple(product(range(5), range(5), range(5), range(5),
                         range(5), range(5)))
    # Test case where progress bar is required

# Generated at 2022-06-24 09:49:50.791774
# Unit test for function product
def test_product():
    import sys
    from numpy.random import randint
    from numpy import all, array_equal
    from .. import trange

    for n in range(1, 5):
        for m in range(1, 5):
            t = trange(n, desc="prod", leave=True, bar_format="{desc}: {percentage:3.0f}%|{bar}|")
            t = trange(m, desc="prod", leave=True, bar_format="{desc}: {percentage:3.0f}%|{bar}|", total=n*m)
            A = randint(0, 10, (n, m))
            B = randint(0, 10, (n, m))

# Generated at 2022-06-24 09:50:00.005306
# Unit test for function product
def test_product():
    import numpy as np
    from ..collections import DummyTqdmFile
    N = 10
    with DummyTqdmFile(1) as f:
        for i in product(range(N), range(N), range(N), tqdm_class=DummyTqdmFile):
            assert i == (i[0], i[1], i[2])
    with DummyTqdmFile(1) as f:
        for i in product(range(N), range(N), range(N), tqdm_class=DummyTqdmFile):
            assert i == (i[0], i[1], i[2])

# Generated at 2022-06-24 09:50:10.500046
# Unit test for function product
def test_product():
    """
    Test tqdm.product
    """
    # Basic test
    assert sum(product(range(0), range(5))) == 0
    assert sum(product(range(5), range(0))) == 0
    assert list(product([0, 1], repeat=2)) == [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Smoke test
    assert sum(
        product(range(i ** 2), range(i ** 2 + 1), repeat=2,
                tqdm_class=tqdm_auto)) == sum(tqdm_auto(itertools.product(
                    range(i ** 2), range(i ** 2 + 1), repeat=2)))

    # Test total

# Generated at 2022-06-24 09:50:14.931732
# Unit test for function product
def test_product():
    assert list(product(range(5), range(5))) == list(itertools.product(range(5), range(5)))
    assert list(product(range(5), range(5), tqdm_class=lambda: None)) == list(itertools.product(range(5), range(5)))

# Generated at 2022-06-24 09:50:19.666435
# Unit test for function product
def test_product():
    x = list(product([1, 2], [3, 4], tqdm_class=tqdm_auto))
    assert x == [(1, 3), (1, 4), (2, 3), (2, 4)]

    x = list(product([1, 2], tqdm_class=tqdm_auto))
    assert x == [(1,), (2,)]

# Generated at 2022-06-24 09:50:26.715438
# Unit test for function product
def test_product():
    """
    Unit test for product
    """
    # Same as itertools.product
    all_expected = list(itertools.product([0, 1], [0, 1], [0, 1]))
    all_result = list(product([0, 1], [0, 1], [0, 1]))
    assert all_expected == all_result

    # Specify tqdm_class
    class MyTqdm(tqdm_auto):
        pass
    all_result = list(product([0, 1], [0, 1], [0, 1], tqdm_class=MyTqdm))
    assert all_expected == all_result

# Generated at 2022-06-24 09:50:30.401616
# Unit test for function product
def test_product():
    """Unit test for function product"""
    for i in product(tqdm_class=tqdm_auto, iterables=[range(4), range(4)],
                     leave=False):
        pass

# Generated at 2022-06-24 09:50:39.681058
# Unit test for function product
def test_product():
    """ Unit test for `itertools.product` wrapper """
    from ._utils_test import ensure_posix_behavior
    ensure_posix_behavior()

    from . import trange
    from .utils import format_sizeof

    def _prd(n, m, trange=trange, format_sizeof=format_sizeof):
        """
        Equivalent of `product` with `trange`
        """
        return list(product(trange(n), trange(m)))

    # Test that we have covered all the iterables types
    assert list(product(range(3))) == [(0,), (1,), (2,)]
    assert list(product(range(3), repeat=1)) == [(0,), (1,), (2,)]

# Generated at 2022-06-24 09:50:46.996039
# Unit test for function product
def test_product():
    """
    Unit test for `itertools.product`.
    """
    import sys
    import tempfile
    import io

    with tempfile.TemporaryFile('w+t') as tf:
        sys.stdout = tf
        with tqdm_auto(unit='B', unit_scale=True, miniters=1,
                       mininterval=0.1, file=io.StringIO()) as t:
            for i in product(range(10), repeat=2):
                pass
        sys.stdout = sys.__stdout__
        tf.seek(0)
        assert '100it' in tf.read()

# Generated at 2022-06-24 09:50:57.358060
# Unit test for function product
def test_product():
    from math import factorial
    from ..utils import FormatCustomText, FormatCustomTextFloat
    from .trange import trange

    list_list = [range(4), range(4), range(4)]

# Generated at 2022-06-24 09:51:02.554196
# Unit test for function product
def test_product():
    """Test function product"""
    f = list(product([1, 2, 3], ['a', 'b', 'c'], tqdm_class=tqdm_auto))
    assert f == [(1, 'a'), (1, 'b'), (1, 'c'),
                 (2, 'a'), (2, 'b'), (2, 'c'),
                 (3, 'a'), (3, 'b'), (3, 'c')]

# Generated at 2022-06-24 09:51:12.081670
# Unit test for function product
def test_product():
    """
    Test tqdm.itertools.product
    """
    from ..utils import FormatCustomText, FormatCustomTextTest, AtomicCounter
    counter = AtomicCounter()
    def func(x):
        """
        custom func to test itertools.product
        """
        counter.increment()
        return x

    print('Testing tqdm.itertools.product')
    with tqdm_auto(leave=False) as t:
        assert t.total is None
        result = list(product(tqdm_auto(range(1)), func, range(10),
                              tqdm_class=FormatCustomText))
        result2 = list(product(tqdm_auto(range(1), leave=False), func,
                               range(10), tqdm_class=FormatCustomText))
    assert result2

# Generated at 2022-06-24 09:51:20.517428
# Unit test for function product
def test_product():
    """Test product on a simple example."""
    from ..utils import FormatCustomText
    from ..std import StringIO
    from .._version import __version__

    f = StringIO()
    for i in product(range(4), range(4), tqdm_class=FormatCustomText,
                     file=f):
        pass

    assert ("FormatCustomText(0/64, bar_format='{desc}{percentage:3.0f}%"
            "|{bar}| {n_fmt}/{total_fmt}"
            " [{elapsed}<{remaining}, {rate_fmt}{postfix}]'): 100%|"
            "█████████| 64/64 [00:00<00:00, 988.79it/s]\n" in f.getvalue())



# Generated at 2022-06-24 09:51:29.753630
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import numpy as np
    from inspect import isgeneratorfunction

    # Check function type and arguments
    assert isgeneratorfunction(product)
    try:
        product(1, 2, 3)
    except TypeError:
        pass
    else:
        raise AssertionError("function 'product' does not check input type")
    for i in [0, 1, 2]:
        try:
            product(*list(range(3)) * i)
        except TypeError:
            pass
        else:
            raise AssertionError("function 'product' does not check number of arguments")
    for i in [0, 1, 2]:
        try:
            product() * i
        except TypeError:
            pass

# Generated at 2022-06-24 09:51:39.827186
# Unit test for function product
def test_product():
    """
    Defines a unit test for `product`.
    """
    import numpy
    from ..auto import tqdm as tqdm_auto
    tqdm_auto.DEFAULT_UNIT = "laps"

# Generated at 2022-06-24 09:51:47.310816
# Unit test for function product
def test_product():
    """Unit test for function product"""
    import sys
    import gc
    try:
        from .tests_tqdm import pretest_posttest
    except (ImportError, SyntaxError):
        import doctest
        doctest.testmod()
    else:
        for i in range(1, 10):
            for j in range(1, 10):
                for k in range(1, 10):
                    for l in range(1, 10):
                        for m in range(0, 3):
                            for n in range(0, 3):
                                for o in range(0, 3):
                                    for p in range(0, 3):
                                        for q in range(0, 3):
                                            print("\n####### Run number #######")

# Generated at 2022-06-24 09:51:57.980513
# Unit test for function product
def test_product():
    import numpy as np
    from sys import version_info as python_version
    from ..utils import _range_tuple

    for tqdm_cls in [tqdm_auto, tqdm_auto.tqdm]:
        assert list(product(['a', 'b'], [1, 2], tqdm_class=tqdm_cls)) == \
            list(itertools.product(['a', 'b'], [1, 2]))

        assert list(product(['a', 'b'], [1, 2], tqdm_class=tqdm_cls,
                            desc='prod')) == \
            list(itertools.product(['a', 'b'], [1, 2]))

        # check custom tqdm kwargs

# Generated at 2022-06-24 09:52:04.907749
# Unit test for function product
def test_product():
    ip = product(range(10), range(20), range(30),
                 tqdm_class=None)
    assert list(ip) == list(itertools.product(range(10), range(20), range(30)))
    ip = product(range(10), range(20), range(30),
                 tqdm_class=tqdm_auto, total=None)
    assert list(ip) == list(itertools.product(range(10), range(20), range(30)))
    ip = product(range(10), range(20), range(30),
                 tqdm_class=tqdm_auto, total=None)
    assert list(ip) == list(itertools.product(range(10), range(20), range(30)))

# Generated at 2022-06-24 09:52:13.913411
# Unit test for function product
def test_product():
    """Unit test for function product."""
    from nose.tools import assert_equal

    def assert_len_and_sum(iterable, length, sum):
        """Assert len and sum of iterable."""
        assert_equal(len(iterable), length)
        assert_equal(sum(iterable), sum)

    assert_len_and_sum(list(product(range(10))), 10, 45)
    assert_len_and_sum(list(product(range(2), range(2))), 4, 6)
    assert_len_and_sum(list(product(range(1, 5), range(4))), 12, 50)
    assert_len_and_sum(
        list(product(range(1, 5), range(2), range(3))), 24, 108)
    assert_len_and_sum

# Generated at 2022-06-24 09:52:16.202282
# Unit test for function product
def test_product():
    for i in product(list(range(4)), list(range(4)),
                     tqdm_class=tqdm_auto):
        pass
test_product()

# Generated at 2022-06-24 09:52:25.584929
# Unit test for function product
def test_product():
    from ._utils import _test_env_tqdm  # NOQA

    from .tqdm import trange
    from .std import tqdm

    @tqdm_auto
    def product(*iterables):
        """
        Equivalent of `itertools.product`.
        """
        for i in itertools.product(*iterables):
            yield i

    with _test_env_tqdm() as (_, cls):
        if cls is tqdm:
            cls = trange
        assert list(product(range(2), range(3), range(4))) == \
            list(itertools.product(range(2), range(3), range(4)))

# Generated at 2022-06-24 09:52:35.967808
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import sys
    import subprocess

    name = 'tqdm_tests.tests.test_itertools'
    try:
        import_cmd = [sys.executable, '-c',
                      'import tqdm_tests.tests.test_itertools'
                      ' as tqdm_tests_tests_test_itertools']
        subprocess.check_output(import_cmd)
    except subprocess.CalledProcessError as e:
        out = e.output
    else:
        out = name + ' imported successfully'


# Generated at 2022-06-24 09:52:42.474797
# Unit test for function product
def test_product():
    """For more details, see https://github.com/tqdm/tqdm/pull/386"""
    from ..main import tqdm
    assert tuple(tqdm(product([1], [2], [3]))) == ((1, 2, 3),)
    assert tuple(tqdm(product([1], [2], [3], [4]))) == ((1, 2, 3, 4),)
    assert tuple(tqdm(product([1], [2], [3], [4], [5]))) == ((1, 2, 3, 4, 5),)

# Generated at 2022-06-24 09:52:43.743287
# Unit test for function product
def test_product():
    """Test for product()"""
    for _ in product(range(4), repeat=4):
        pass

# Generated at 2022-06-24 09:52:51.701966
# Unit test for function product
def test_product():
    from ..utils import FormatWrapper, _range
    from ..std import _zip
    from random import randint
    a = b = []
    for i in _range(int(1e2)):
        a.append(randint(-10, 10))
        b.append(randint(-10, 10))
    with FormatWrapper():
        # NOTE: itertools.product is NOT a generator
        # NOTE: The total should automatically be the appropriate product
        #       of the lengths of the input iterables (not the sum of the
        #       lengths)
        for (x, y), (i, j) in _zip(product(a, b, total=None),
                                   _zip(a, b)):
            assert x == i
            assert y == j

# Generated at 2022-06-24 09:53:05.438439
# Unit test for function product
def test_product():
    """ Unit test for function product """
    list_, n = [], 0
    for i in product('abc', 'xyz', 'pqr'):
        list_.append(''.join(i))
        n += 1
    assert (list_ == ['axp', 'axq', 'axr',
                      'ayp', 'ayq', 'ayr',
                      'azp', 'azq', 'azr',
                      'bxp', 'bxq', 'bxr',
                      'byp', 'byq', 'byr',
                      'bzp', 'bzq', 'bzr',
                      'cxp', 'cxq', 'cxr',
                      'cyp', 'cyq', 'cyr',
                      'czp', 'czq', 'czr'])
    assert n == 27


# Generated at 2022-06-24 09:53:10.453189
# Unit test for function product
def test_product():
    from .tests import comparison

    # Test that the number of iterations is correct
    with tqdm_auto(total=10) as t:
        for _ in product(range(10), tqdm=t):
            pass
    for n in range(1, 10):
        with tqdm_auto(total=n * 10) as t:
            for _ in product(range(n), range(10), tqdm=t):
                pass

    # Final test
    comparison()

# Generated at 2022-06-24 09:53:21.853133
# Unit test for function product
def test_product():
    """Example of usage"""
    from .utils import FormatCustomText
    from time import sleep

    # generate some data
    l2 = [0, 1, 2, 3]
    l1 = [0, 1]
    l3 = [0, 1]
    l4 = [0, 1, 2]
    data = product(l1, l2, l3, l4, tqdm_class=FormatCustomText)  # tqdm()

    fmt_str = "{l1:d} {l2:d} {l3:d} {l4:d}"
    out = [fmt_str.format(**dict(zip(["l1", "l2", "l3", "l4"], i)))
           for i in product(l1, l2, l3, l4)]

    i = 0

# Generated at 2022-06-24 09:53:26.746826
# Unit test for function product
def test_product():
    """Test `tqdm(itertools.product)`"""
    from .tqdm import tqdm
    with tqdm(product(range(10), range(10), range(10),
                      tqdm_class=tqdm)) as (iterator):
        for _ in iterator:
            pass

# Generated at 2022-06-24 09:53:35.425130
# Unit test for function product
def test_product():
    from .itertools import product
    from .utils import TestingIO
    import sys
    import time

    for i in product(range(3), range(4), range(5), tqdm_class=tqdm_auto):
        time.sleep(0.01)
    try:
        del i
    except NameError:
        pass
    else:
        assert (False), "product should be an iterator"

    with TestingIO(initial_len=37) as f:
        sys.stdout = f
        for i in product(range(1), range(2), range(3), range(0),
                         tqdm_class=tqdm_auto):
            pass
        sys.stdout = sys.__stdout__
    assert ('0it [00:00, ?it/s]' in f.output)

# Generated at 2022-06-24 09:53:45.991572
# Unit test for function product
def test_product():
    assert list(product('ABCD', repeat=2)) ==\
        [('A', 'A'), ('A', 'B'), ('A', 'C'), ('A', 'D'),
         ('B', 'A'), ('B', 'B'), ('B', 'C'), ('B', 'D'),
         ('C', 'A'), ('C', 'B'), ('C', 'C'), ('C', 'D'),
         ('D', 'A'), ('D', 'B'), ('D', 'C'), ('D', 'D')]
    assert list(product('ABCD', 'xy')) ==\
        [('A', 'x'), ('A', 'y'),
         ('B', 'x'), ('B', 'y'),
         ('C', 'x'), ('C', 'y'),
         ('D', 'x'), ('D', 'y')]
    assert list

# Generated at 2022-06-24 09:53:54.620521
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    from ..auto import tqdm
    from ..utils import format_sizeof
    # list
    with tqdm(lst) as t_lst:
        for i in product(t_lst, repeat=2):
            assert i[0] in lst and i[1] in lst
            t_lst.set_description(",".join(map(str, i)))
    # list of tuples
    with tqdm(lst_of_tups) as t_lst:
        for i in product(*t_lst):
            assert all(j in tups for j in i)
            t_lst.set_description(",".join(map(str, i)))
    # generator

# Generated at 2022-06-24 09:54:04.293145
# Unit test for function product
def test_product():
    from .tqdm_gui import tqdm
    from .utils import UnicodeIO
    from .tests import pretest_posttest

    def test_product_output(tqdm_cls):
        for iterables in [['ab', 'cd', 'ef'], range(30), range(1, 5)]:
            with tqdm_cls(iterables, total=1) as pbar:
                assert pbar.total == 1
                for _ in pbar:
                    pass
            with tqdm_cls(iterables, file=UnicodeIO()) as pbar:
                assert pbar.total == 1
                for chars in pbar:
                    pass
            with tqdm_cls(iterables) as pbar:
                assert pbar.total is None
                for chars in pbar:
                    pass

   

# Generated at 2022-06-24 09:54:16.353214
# Unit test for function product
def test_product():
    """Test function product"""
    from .tests_tqdm import disc_tqdm
    from collections import defaultdict
    from numpy.random import RandomState
    from math import factorial

    n_samples, n_iter = 1, 1000

    for prng in (RandomState(8), None):
        for k in range(3):
            rng = RandomState(k) if prng is None else prng
            sizes = rng.randint(1, 11, size=k)
            iters = [rng.randint(0, 10, size=size) for size in sizes]

            # check all pairs appear
            pairs = defaultdict(int)
            for _ in range(n_samples):
                for pair in product(*iters, tqdm_class=disc_tqdm):
                    pairs[pair]

# Generated at 2022-06-24 09:54:24.509207
# Unit test for function product
def test_product():
    import numpy as np

    def prod(i, j):
        return i * j

    i = np.arange(1, 6)
    j = np.arange(11, 16)

    res = [prod(i, j) for i, j in product(i, j)]
    ground_truth = [prod(*ij) for ij in itertools.product(i, j)]
    assert res == ground_truth

    res = [prod(i, j) for i, j in product(i, j, tqdm_class=None)]
    ground_truth = [prod(*ij) for ij in itertools.product(i, j)]
    assert res == ground_truth

# Generated at 2022-06-24 09:54:30.582114
# Unit test for function product
def test_product():
    seq = [1, 2, 3, 4]

    number_of_products = 1
    for i in seq:
        number_of_products *= i

    products = product(seq, seq)
    products_count = 0
    for _ in products:
        products_count += 1

    assert number_of_products == products_count

    number_of_products = 1
    seq = [1, 2, 3, 4]
    for i in seq:
        number_of_products *= i

    products = product(seq, seq)
    products_count = 0
    for _ in tqdm_auto(products):
        products_count += 1

    assert number_of_products == products_count

# Generated at 2022-06-24 09:54:33.990334
# Unit test for function product
def test_product():
    try:
        iter(itertools)
    except TypeError:
        return
    x = list(itertools.product('ABCD', 'xy'))
    x_ = list(product('ABCD', 'xy'))
    assert x == x_

# Generated at 2022-06-24 09:54:44.130705
# Unit test for function product
def test_product():
    """Test that tqdm product is equivalent to itertools product"""
    from numpy.random import randint
    from numpy.testing import assert_array_equal
    from .utils import format_sizeof
    for shape in [(10, 10), (5, 5, 5), (4, 4)]:
        for itype in [list, tuple, zip]:
            n = len(shape)
            iters = [itype(randint(0, 2, s)) for s in shape]
            assert_array_equal(
                list(itertools.product(*iters)), list(product(*iters)))
            assert_array_equal(
                list(itertools.product(*iters)), list(product(*iters)))

# Generated at 2022-06-24 09:54:54.783230
# Unit test for function product
def test_product():
    from ..utils import FormatCustomText
    from .common import closing
    from .pandas import trange as pd_trange

    fct = FormatCustomText()

    with closing(pd_trange(4, desc=fct)) as t:
        for i in product(range(4), range(4), tqdm_class=t.__class__,
                         desc=fct, leave=False):
            assert (i[0] >= 0) and (i[0] < 4)
            assert (i[1] >= 0) and (i[1] < 4)
            fct.update(i)
            t.update()


# Generated at 2022-06-24 09:54:57.317647
# Unit test for function product
def test_product():
    """
    Unit test for product
    """
    assert list(product(range(5), repeat=3)) == list(itertools.product(range(5), repeat=3))

# Generated at 2022-06-24 09:55:03.871063
# Unit test for function product
def test_product():
    """Unit test for `tqdm.itertools.product`"""
    from numpy import product as npprod
    from numpy import random
    import time
    # list(itertools.product(['a','b','c'], range(3))) ==
    # [('a', 0), ('a', 1), ('a', 2), ('b', 0), ('b', 1), ('b', 2), ('c', 0),
    #  ('c', 1), ('c', 2)]
    # Note: must use %r instead of %s to avoid Unicode conversion
    exp = [('a', 0), ('a', 1), ('a', 2), ('b', 0), ('b', 1), ('b', 2),
           ('c', 0), ('c', 1), ('c', 2)]

# Generated at 2022-06-24 09:55:15.740057
# Unit test for function product
def test_product():
    import numpy as np
    # Test single iterable
    assert(tuple(product(range(2))) == (0, 1))
    # Test multiple iterables
    assert(tuple(product(range(2), range(2))) == ((0, 0), (0, 1), (1, 0),
                                                  (1, 1)))
    # Test nested iterables
    assert(tuple(product(range(2), range(2), range(2))) == ((0, 0, 0), (0, 0,
                                                           1), (0, 1, 0),
                                                          (0, 1, 1), (1, 0, 0),
                                                          (1, 0, 1), (1, 1, 0),
                                                          (1, 1, 1)))
    # Test non-iterable as input

# Generated at 2022-06-24 09:55:28.911423
# Unit test for function product
def test_product():
    from .tests import DryTest
    s = "abcde"
    # Test 1
    sum_ = 0
    for i in product(range(len(s) + 1), repeat=2):
        sum_ += 1
        assert (i[0] >= 0) and (i[0] <= len(s))
        assert (i[1] >= 0) and (i[1] <= len(s))
    assert sum_ == (len(s) + 1) ** 2
    # Test 2
    sum_ = 0
    for i in product(range(len(s) + 1), repeat=2, tqdm_class=DryTest):
        sum_ += 1
        assert (i[0] >= 0) and (i[0] <= len(s))

# Generated at 2022-06-24 09:55:34.862313
# Unit test for function product
def test_product():
    """
    Unit test for function product.
    """
    import operator
    import sys

    # Python 2 is deprecated and not supported
    if sys.version_info[0] < 3:
        raise RuntimeError("Please use Python 3")

    a = range(3)
    assert list(product(a, a, a)) == \
        list(itertools.product(a, a, a))
    assert list(product(a, a, a, a)) == \
        list(itertools.product(a, a, a, a))
    assert list(product(a)) == \
        list(itertools.product(a))
    assert list(product('abc', 'def')) == \
        list(itertools.product('abc', 'def'))


# Generated at 2022-06-24 09:55:45.066231
# Unit test for function product
def test_product():
    from .utils import TestCase

    class TestProduct(TestCase):
        def test_product(self):
            def prod(*iterables):
                r = 1
                for i in iterables:
                    r *= len(i)
                return r

            for i in (product(range(10))):
                if i != (0,):
                    break
            self.ae(len(list(i)), 10)
            for i in (product(range(10), range(10))):
                if i != (0, 0):
                    break
            self.ae(len(list(i)), 100)
            x = [1, 2, 3]
            y = [4, 5, 6, 7]
            z = [8, 9, 10]

# Generated at 2022-06-24 09:55:49.994781
# Unit test for function product
def test_product():
    """Tests for function product."""
    # TODO: Test unit test
    assert product(range(10), ["foo", "bar"])  # noqa: F841


if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:55:55.627113
# Unit test for function product
def test_product():
    import io
    import sys
    import tempfile
    import itertools

    with tempfile.TemporaryFile() as f:
        r = list(product(range(3), range(3), tqdm_class=tqdm))
        assert r == itertools.product(range(3), range(3))
        r = list(product(f, repeat=2, tqdm_class=tqdm))
        assert r == []

    # Test file-like progress bar with no total
    with io.StringIO() as s:
        for x in tqdm(range(20), file=s):
            pass
        s.seek(0)
        captured = s.read()
        assert u"  0%|          | 0/20 [00:00<?, ?it/s]" in captured

# Generated at 2022-06-24 09:56:06.176186
# Unit test for function product
def test_product():
    for this in product(range(i) for i in [4, 5]):
        assert len(this) == 2
    for i, this in enumerate(product(range(i) for i in [4, 5])):
        assert len(this) == 2
        assert i < 20
    assert i == 19

# Generated at 2022-06-24 09:56:11.026161
# Unit test for function product
def test_product():
    """
    Simple unit test for `tqdm.itertools.product`.
    """
    from itertools import product
    from numpy.random import rand
    n = 100000
    with tqdm_auto(total=n) as t:
        for _ in product(range(n), range(n), range(n), range(n), range(n),
                         range(n), range(n), range(n)):
            t.update()

if __name__ == "__main__":
    test_product()

# Generated at 2022-06-24 09:56:17.303083
# Unit test for function product
def test_product():
    from .utils import StringIO
    # TEST 1
    with StringIO() as our_file:
        for _ in product(["a", "b", "c"], repeat=3,
                         ascii=True, file=our_file):
            pass
        our_txt = our_file.getvalue()

    test_txt = """\
0%|          | 0/27 [00:00<?, ?it/s]
100%|██████████| 27/27 [00:00<00:00,  7.76it/s]
"""
    assert test_txt == our_txt


if __name__ == '__main__':
    test_product()

# Generated at 2022-06-24 09:56:26.860153
# Unit test for function product
def test_product():
    from numpy import prod
    from random import randint
    from time import sleep

    with tqdm_auto(unit="test") as t:
        prod_tqdm = list(product([100, 20, 30], [1, 2, 3], [1, 2]))
    assert prod([100, 20, 30]) == len(prod_tqdm)
    with tqdm_auto(unit="test") as t:
        prod_tqdm = list(product(
            [100, 20, 30], [[1, 2, 3], [1, 2, 3], [1, 2, 3]]))
    assert prod([100, 20, 30, 3]) == len(prod_tqdm)

# Generated at 2022-06-24 09:56:35.998484
# Unit test for function product
def test_product():
    """
    Test for function `product`
    """
    from tqdm import tqdm
    for _ in tqdm(product(range(100), ["a", "b"]),
                  ascii=True):
        pass
    # Smoke tests
    for _ in tqdm(product(range(100), ["a", "b"]),
                  desc="unit test", dynamic_ncols=True):
        pass
    for _ in tqdm(product(range(100), ["a", "b"]),
                  unit="obs", dynamic_ncols=True):
        pass
    for _ in tqdm(product(range(100), ["a", "b"]),
                  unit_scale=True, dynamic_ncols=True):
        pass

# Generated at 2022-06-24 09:56:46.383434
# Unit test for function product
def test_product():
    from .tqdm_test_cases import tqdm_gears
    for i in range(2, 6):
        for j in range(3, 6):
            for c in tqdm_gears:
                tqdm_class = c

                with tqdm_class(total=i * j, miniters=1) as t:
                    res_gen = product(range(i), range(j), tqdm_class=tqdm_class)
                    res_list = list(res_gen)
                    assert len(res_list) == i * j
                    for (_, _, val) in res_list:
                        t.update(val=val)


if __name__ == "__main__":
    from ._utils import _test_module_docstrings

# Generated at 2022-06-24 09:56:51.702287
# Unit test for function product
def test_product():
    from .tqdm_test_cases import TestTqdmIter
    from .tests_tqdm import pretest_posttest

    @pretest_posttest
    def product_test(desc, iterables, **kwargs):
        return list(product(*iterables, **kwargs))

    t = TestTqdmIter()
    t.test_iter(product_test)
    t.report()

# Generated at 2022-06-24 09:56:54.373994
# Unit test for function product
def test_product():
    from . import _test_environment
    test_it = product(range(10), range(10), tqdm_class=_test_environment.tqdm)
    assert sum(1 for _ in test_it) == 10*10

# Generated at 2022-06-24 09:57:04.833484
# Unit test for function product
def test_product():
    import numpy as np
    iterables = [np.array(range(10))] * 4
    it = product(*iterables, ascii=True)
    res = set(it)
    assert len(res) == 10000
    assert set(res) == set(itertools.product(*iterables))

    iterables = [iter(range(10))] * 4
    it = product(*iterables, ascii=True)
    res = list(it)
    assert len(res) == 10000
    assert set(res) == set(itertools.product(*iterables))


if __name__ == "__main__":  # pragma: no cover
    test_product()

# Generated at 2022-06-24 09:57:10.944509
# Unit test for function product
def test_product():
    """Test for function product"""
    with tqdm_auto(total=36) as t:
        for i in product(range(6), range(6), range(6)):
            assert len(i) == 3
            assert 0 <= i[0] < 6
            assert 0 <= i[1] < 6
            assert 0 <= i[2] < 6
            t.update()
    with tqdm_auto(total=0) as t:
        for i in product():
            assert len(i) == 0
            t.update()
    with tqdm_auto(total=1) as t:
        for i in product(range(1)):
            assert len(i) == 1
            assert i[0] == 0
            t.update()

# Generated at 2022-06-24 09:57:20.785786
# Unit test for function product
def test_product():
    # Test total is set correctly
    range_itr = range(3, 5)
    product_itr = product(range_itr)
    assert hasattr(product_itr, 'total')
    assert product_itr.total == 2
    # Test iteration
    product_itr = product(range_itr)
    assert next(product_itr) == (3, )
    assert next(product_itr) == (4, )
    # Test total is not set if iterable cannot be mapped to len()
    product_itr = product([1, 2], (True, False))
    assert product_itr.total is None
    # Test that total is set by the object itself with tqdm_class=tqdm
    from ..tqdm import tqdm
    from six.moves import range

# Generated at 2022-06-24 09:57:24.651686
# Unit test for function product
def test_product():
    with tqdm_auto(total=6, leave=False) as t:
        for i in product(range(2), range(3), tqdm_class=tqdm_auto):
            t.update()

# Generated at 2022-06-24 09:57:31.206954
# Unit test for function product
def test_product():
    assert list(product([1, 2], repeat=1)) == list(product([1, 2]))
    assert list(product([1, 2], repeat=2)) == list(product([1, 2], [1, 2]))
    assert list(product([1, 2], repeat=3)) == list(product([1, 2], [1, 2], [1, 2]))
    assert list(product([1, 2], repeat=0)) == [()]

# Generated at 2022-06-24 09:57:42.140386
# Unit test for function product
def test_product():
    from . import _test_it
    from . import _test_example

    test_iter = _test_example.test_iter
    num = _test_example.num

    _test_it(tqdm(test_iter,  leave=False))
    _test_it(tqdm(product(test_iter, repeat=3)))
    _test_it(tqdm(product(test_iter, repeat=3), total=num ** 3))
    _test_it(tqdm(product(test_iter, repeat=3), miniters=num ** 3 // 3))
    _test_it(tqdm(product(test_iter, repeat=3), miniters=num ** 3 // 3),
          total=num ** 3, leave=False)

# Generated at 2022-06-24 09:57:53.016425
# Unit test for function product
def test_product():
    """
    Simple unit test for function product.
    """
    import numpy as np
    s = 0
    for _ in product(range(4), repeat=2, tqdm_class=tqdm_auto):
        s += 1
    assert s == 16
    s = 0
    for _ in product(range(4), repeat=2):
        s += 1
    assert s == 16
    for _ in product(range(5), range(5), tqdm_class=tqdm_auto):
        s += 1
    assert s == 25
    for _ in product(range(5), range(5)):
        s += 1
    assert s == 25
    s = 0
    for _ in product(range(100), repeat=2, tqdm_class=tqdm_auto):
        s += 1
   

# Generated at 2022-06-24 09:58:01.032946
# Unit test for function product
def test_product():
    """Unit test for function product"""
    from random import choice
    from string import ascii_letters
    from ..std import iden
    MAX_STR_LEN = 10

    assert product(range(2), range(2), range(2),
                   tqdm_class=lambda **kwargs: iden(8)) == [
                       (0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1),
                       (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1),
                   ]

# Generated at 2022-06-24 09:58:11.357605
# Unit test for function product
def test_product():
    for i in product(range(1000)):
        pass
    for i in product("abc", "def"):
        pass
    for i in product("abc", "def", "ghi"):
        pass
    for i in product("abc", "def", "ghi", "jkl"):
        pass
    for i in product("abc", "def", "ghi", "jkl", "mno"):
        pass
    for i in product("abc", "def", "ghi", "jkl", "mno", "pqr"):
        pass
    for i in product("abc", "def", "ghi", "jkl", "mno", "pqr", "stu"):
        pass

# Generated at 2022-06-24 09:58:15.572881
# Unit test for function product
def test_product():
    """Test for function product"""
    res1 = list(product([1, 2, 3], ['a', 'b', 'c']))
    res2 = [(1, 'a'), (1, 'b'), (1, 'c'),
            (2, 'a'), (2, 'b'), (2, 'c'),
            (3, 'a'), (3, 'b'), (3, 'c')]
    assert res1 == res2

# Generated at 2022-06-24 09:58:25.005752
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    # Test with no iterables
    assert tuple(product(tqdm_class=None)) == ((),)

    # Test with regular iterables
    assert tuple(product(['spam', 'ham'], [1, 2, 3], tqdm_class=None)) == \
        (('spam', 1), ('spam', 2), ('spam', 3),
         ('ham', 1), ('ham', 2), ('ham', 3))

    # Test with iterables that have no length
    assert tuple(product('spam', range(1), tqdm_class=None)) == \
        (('s', 0), ('p', 0), ('a', 0), ('m', 0))

    # Test with tqdm

# Generated at 2022-06-24 09:58:34.483773
# Unit test for function product
def test_product():
    """Test function ``product"""
    from ..tests._utils import _random_data, closing, inspect
    # import sys; sys.path.append(".")
    l = 10
    iterables = tuple(map(_random_data, range(10)))
    # Test basic kwargs
    with closing(tqdm_auto(total=l)) as t:
        for i in product(*iterables):
            t.update()
    assert t.n == l
    # Test auto total kwargs
    with closing(tqdm_auto()) as t:
        for i in product(*iterables,
                         tqdm_class=tqdm_auto,
                         total=None):
            pass
    assert t.n == 1
    # Test auto total kwargs without total

# Generated at 2022-06-24 09:58:42.179955
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    import sys
    import re
    if sys.version_info >= (3,0):
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    from ..tests.common import closing
    from .utils import format_sizeof

    with closing(StringIO()) as our_file:
        with tqdm(total=25) as t:
            our_file.write('a')
            t.update()  # +1

    with closing(StringIO()) as our_file:
        it = product('ab', repeat=2)
        with tqdm(it, total=4) as t:
            for _ in t:
                # Each iteration, `our_file` will be written twice
                our_file.write('a')
                our_

# Generated at 2022-06-24 09:58:49.059062
# Unit test for function product
def test_product():
    """Test for product"""
    import sys
    my_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-24 09:58:57.802012
# Unit test for function product
def test_product():
    """
    Unit test for function product
    """
    from .fake_tqdm import FakeTqdm

    list1 = [1, 2, 3]
    list2 = [4, 5, 6]
    list3 = [7, 8, 9]
    list4 = [10, 11]
    output = []
    product(list1, list2, list3, list4, tqdm_class=FakeTqdm)
    assert output == list1 * list2 * list3 * list4
    output = []
    product(list1, list2, list3, list4, tqdm_class=FakeTqdm)
    assert output == list1 * list2 * list3 * list4
    output = []