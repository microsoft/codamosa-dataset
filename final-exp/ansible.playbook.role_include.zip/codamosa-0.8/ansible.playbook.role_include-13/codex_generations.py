

# Generated at 2022-06-11 10:49:58.486791
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.player import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # Test load and get_block_list methods of class IncludeRole
    class TestIncludeRole_load(unittest2.TestCase):
        def test_IncludeRole_load(self):
            role = Role.load("ansible.posix", Play(), PlayContext())
            task = Task.load(dict(action=dict(module='test', args='test')), role, loader=None, variable_manager=None, use_handlers=None)

# Generated at 2022-06-11 10:50:09.333551
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager=variable_manager, host_list=[])
    p = PlayContext(remote_addr='127.0.0.1', remote_user='test', password='test', become_pass='test')
    variable_manager.set_inventory

# Generated at 2022-06-11 10:50:17.779376
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    loader, variable_manager, _ = C.ZMQ_COMPATIBLE_INTERFACES.get(C.DEFAULT_ZMQ_BACKEND, (None, None, None))
    variable_manager = VariableManager()

    # Without name and without role
    data = [ '- include_role: {}' ]
    ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
    assert ir is None

    # Without name and with role
    data = [ '- include_role: role=test_role_name' ]
    ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
    assert ir is not None
    assert ir._role_name == 'test_role_name'

    # With name and without role

# Generated at 2022-06-11 10:50:28.715448
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # set up data
    my_data = {'name': 'test_name',
               'apply': {'when': 'test_when'},
               'allow_duplicates': False,
               'public': True,
               'vars_from': 'test_vars_from',
               'defaults_from': 'test_defaults_from',
               'handlers_from': 'test_handlers_from',
               'rolespec_validate': False,
               'tags': ['test_tag1', 'test_tag2']}

    # set up temp block
    my_block = Block.load(data=dict(hosts='all', tasks=[]), play=None)
    my_block._parent = None

    # set up temp role

# Generated at 2022-06-11 10:50:38.129136
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print("get_block_list")
    # setUp
    task_include = IncludeRole(task_include="task_include")
    task_include._role_name = "../../tests/test_data/roles/test_include/"
    task_include._block = Block()
    task_include._block.vars = dict(a="b")

    #Execute
    blocks, handlers = task_include.get_block_list()

    #Validate
    assert type(blocks[0]) is Block
    assert blocks[0].name == "Test task in test_include"
    assert type(handlers[0]) is Block
    assert handlers[0].name == "task_1"

# Generated at 2022-06-11 10:50:49.652965
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    fake_loader = DictDataLoader({})
    fake_playbook_vars = dict(
        foo='foo',
        bar='bar',
        baz='baz',
        svc_user='my_user',
    )
    fake_variable_manager = VariableManager()
    fake_variable_manager._extra_vars = fake_playbook_vars
    action = 'include_role'
    data = dict(name='foo')
    my_task = IncludeRole.load(data=data, block=None, role=None, task_include=None, variable_manager=fake_variable_manager, loader=fake_loader)
    assert my_task.name == 'foo'
    assert my_task._parent_role

# Generated at 2022-06-11 10:51:00.522167
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.display('Testing %s' % test_IncludeRole_get_include_params.__name__)

    # Create include_role
    block = Block.load(dict(
        name='my_block',
        #tasks=[{'debug': 'msg="Hello from a test"'}],
        tasks=[['debug', 'msg="Hello from a test"']],
    ), play=None)
    role = Role()
    ir = IncludeRole(block, role)
    my_param = 'foo'
    ir.vars = {my_param: 'bar'}

    # Create parent role
    parent_role_name = 'my_parent_role'
    parent_role_path = 'my_parent_role_path'
    parent_role = Role()
    parent_role._role_name = parent_role_name


# Generated at 2022-06-11 10:51:01.322961
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    pass

# Generated at 2022-06-11 10:51:13.132223
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import unittest
    import ansible.playbook.include_role

    class TestIncludeRole_load(unittest.TestCase):
        mock_loader = 'mock_loader'
        mock_variable_manager = 'mock_variable_manager'
        mock_block = 'mock_block'
        mock_role = 'mock_role'
        mock_task_include = 'mock_task_include'

# Generated at 2022-06-11 10:51:23.275286
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Play, Playbook, Task, Role
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleParserError
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-11 10:51:42.863180
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.block import Block

    class TestPlay(object):
        def __init__(self):
            self.roles = []
            self.handlers = []

    class TestRole(object):
        def __init__(self, name):
            self.name = name

        def get_handler_blocks(self, play):
            return ['test_handler']

        def compile(self, play, dep_chain):
            return [Block(self.name, [])]

    class TestVariableManager(object):
        def get_vars(self, play=None, task=None):
            return {'test_var': 'test_val'}

    class TestLoader(object):
        def __init__(self):
            self._templates = {}

        def contains(self, path):
            return False

       

# Generated at 2022-06-11 10:51:52.427560
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel


# Generated at 2022-06-11 10:51:53.839396
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-11 10:52:04.909117
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=[])


# Generated at 2022-06-11 10:52:16.021420
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    if PY3:
        import io as StringIO
    else:
        import StringIO
    ir = IncludeRole()
    ir.vars = {'a': 'A', 'b': 'B'}
    ir._from_files = {'tasks': 'task_file', 'handlers': 'handler_file', 'vars': 'vars_file', 'defaults': 'defaults_file'}
    ir._parent_role = Role()
    ir._parent_role.get_name = lambda: 'role_name'
    ir._parent_role.get_role_

# Generated at 2022-06-11 10:52:29.015638
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    lu = dict(
        block=dict(
            name='test-block',
            parent=None,
            role=None
        ),
        data=dict(
            name='test-name',
            role='test-role',
            tasks_from='test-file'
        ),
        variable_manager=None,
        loader=None
    )

    # test lack of required parameter 'name'
    data = lu['data'].copy()
    data.pop('name')
    ir = IncludeRole.load(data, **lu)

    # test invalid options
    data = lu['data'].copy()
    data.update(dict(
        apply=dict(),
        public=True,
        allow_duplicates=False,
        rolespec_validate=False,
        invalid_option='test'
    ))

# Generated at 2022-06-11 10:52:38.771813
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    loader = DictDataLoader({})

    # Test an include role with name tag, and with include_tasks and tasks_from
    data = dict(
        include_role=dict(
            name="my_role",
            include_tasks=True,
            include_vars=True,
            include_handlers=True,
            include_defaults=True,
            tasks_from="the_main.yml",
            defaults_from="the_defaults.yml",
            vars_from="the_vars.yml",
            handlers_from="the_handlers.yml",
        )
    )
    ir = IncludeRole.load(data)
    assert ir._from_files['tasks'] == "the_main.yml"

# Generated at 2022-06-11 10:52:48.687030
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    import tempfile
    import textwrap
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager._extra_vars = {'inventory_dir': 'tests/unit/inventory',
                                    'inventory_file': 'hosts.yml',
                                    'playbook_dir': './tests/unit',
                                    'playbook_file': 'test_playbook.yml'}
    # Option _rolespec

# Generated at 2022-06-11 10:52:59.520555
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    class MockOptions:
        verbosity = C.DEFAULT_VERBOSITY
        private_key_file = None

    class MockPassword:
        connection = 'password'
        def get_password(self, host, user, connect_kwargs):
            return 'pass'
        def run(self):
            pass

    class MockPlayContext:
        def __init__(self):
            self.variable_manager = VariableManager()
            self.password = MockPassword()

    #

# Generated at 2022-06-11 10:53:08.786801
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role

    # prerequisites
    def fake_get_role_params():
        return dict(
            role_name = 'test_role_name',
            role_path = '/test/role/path',
        )

    def fake_get_name():
        return 'my_name'

    # setup object to be tested
    r = Role()
    r._metadata = dict(
        role_name = 'role_name_from_metadata',
        role_path = '/role/path/from/metadata',
    )
    r.get_role_params = fake_get_role_params
    r.get_name = fake_get_name
    r._parent_role = None
    ir = IncludeRole()

# Generated at 2022-06-11 10:53:26.018447
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    role_include = IncludeRole(block=block, role=role)
    result = role_include.get_name()
    assert (result == "include_role : <unknown>")


# Generated at 2022-06-11 10:53:34.609573
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test basic success
    myir = IncludeRole.load(dict(name='some_name'))
    assert myir.name == 'some_name'
    assert myir.rolespec_validate is True
    assert myir.allow_duplicates is True
    assert myir.public is False

    # test failure for invalid option
    try:
        myir = IncludeRole.load(dict(bad_option='some_name', name='some_name'))
        exception_raised = False
    except AnsibleParserError:
        exception_raised = True
    assert exception_raised is True

    # test failure for invalid values
    try:
        myir = IncludeRole.load(dict(name='some_name', rolespec_validate='true'))
        exception_raised = False
    except AnsibleParserError:
        exception

# Generated at 2022-06-11 10:53:41.169319
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()

    # name is not set
    ir = IncludeRole()

    ir.action = 'action'
    ir._role_name = 'role_name'

    result = ir.get_name()
    assert result == 'action : role_name'

    # name is set
    ir = IncludeRole()

    ir.name = 'name'

    result = ir.get_name()
    assert result == 'name'



# Generated at 2022-06-11 10:53:52.298834
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a Play and PlayContext
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = loader.load_from_file('./test/ansible_hosts')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext

# Generated at 2022-06-11 10:53:59.718547
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    import os
    import pprint
    import shutil
    import sys
    import tempfile

    curr_dir = os.path.dir

# Generated at 2022-06-11 10:54:11.915173
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()
    # Initialize loader, inventory, variable_manager for next parameters.
    loader = DataLoader()
    variable_manager = VariableManager()
    # Create play and set

# Generated at 2022-06-11 10:54:21.467720
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    d = dict(
        name = 'my_role',
        action = 'include_role',
        args = dict(name='my_role', static=True, apply=dict(a=1,b=2))
    )
    context = dict()
    context['role'] = RoleDefinition()
    context['play'] = Play().load(dict(hosts=['localhost']))
    context['loader'] = DataLoader()
    context['variable_manager'] = VariableManager()
    klass = IncludeRole.load(d, **context)

# Generated at 2022-06-11 10:54:32.208787
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    task_include = TaskInclude(block=block)
    task_include._parent_role = TaskInclude()
    task_include._parent_role._role_params = {'ansible_version': '2.9.0', 'galaxy_info': {'author': 'Rajesh', 'min_ansible_version': '2.7'}}
    v = task_include.get_include_params()
    expected_v = {'ansible_parent_role_names': [None], 'ansible_parent_role_paths': [None], 'ansible_version': '2.9.0', 'galaxy_info': {'author': 'Rajesh', 'min_ansible_version': '2.7'}}
    assert v == expected_v

# Generated at 2022-06-11 10:54:40.009455
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition

    data = dict(
        name = 'test_IncludeRole_load',
        tasks = 'main.yml',
        defaults = 'defaults/main.yml',
        vars = 'vars/main.yml',
        meta = 'meta/main.yml'
    )

    rd = RoleDefinition.load(data, load_from_file=False)
    rd.sanity_check(is_handler=False)

    ir = IncludeRole.load(data, role=rd)
    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-11 10:54:49.116493
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 10:55:12.078675
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader, JsonParser
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    file_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    sys.path.insert(0, file_root + '/molecule/default/plays')


# Generated at 2022-06-11 10:55:12.686149
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    return "TBD"

# Generated at 2022-06-11 10:55:22.488793
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.include import RoleInclude

    # one of the best test is this if we include a role from galaxy:
    # https://github.com/ansible/galaxy/blob/master/clients/ansible-galaxy/test_data/test_1/test_role/tasks/main.yml
    import tempfile, os
    tmp_dir = tempfile.mkdtemp()
    tmp_file_name = 'tasks/main.yml'
    tmp_file_path = os.path.join(tmp_dir, tmp_file_name)
    with open(tmp_file_path, 'w') as f:
        f.write('\n- debug: msg="A task"\n')



# Generated at 2022-06-11 10:55:32.082183
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    def _loader(path):
        class MockLoader(object):
            def load_from_file(self, path):
                from collections import namedtuple
                return namedtuple('Obj', ['name', 'data'])(path, {})
        return MockLoader()

    def _variable_manager(play=None, host=None, task=None):
        class MockVariableManager(object):
            def get_vars(self, play=None, host=None, task=None):
                return {}
        return MockVariableManager()

    obj = dict(
        __ansible_module__ = 'include_role',
        name = 'foo'
    )
    ir = IncludeRole.load(data=obj, block=None, role=None, task_include=None, variable_manager=_variable_manager(), loader=_loader('.'))
   

# Generated at 2022-06-11 10:55:42.108221
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'fake_os'
    variable_manager.set_play_context(play_context)

    task = Task()
    task.action = 'include_role'
    args = {'name': 'test_role', 'apply': 'yes'}

# Generated at 2022-06-11 10:55:52.263439
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    def run_test_case(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        ir = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
        return ir

    # Test Bad Params
    data = {"none_of_the_above": 3}
    with pytest.raises(AnsibleParserError):
        run_test_case(data)

    # Test Bad Params 2
    data = {"name": "fake_role"}
    with pytest.raises(AnsibleParserError):
        run_test_case(data)

    # Test Bad Params 3
    data = {"role": "fake_role"}

# Generated at 2022-06-11 10:56:01.267043
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    i = IncludeRole()
    i._parent = RoleDefinition()
    ctx = PlayContext()
    ctx._vars_per_block = []
    ctx._vars_per_block = [{'a': 1, 'b': 2}]
    i._parent._play = ctx
    i.load({'name': 'test', 'private': True, 'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-11 10:56:12.441813
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    r = RoleDefinition()
    r._role_path = '/home/node/ansible-role'
    import os
    r._metadata = RoleMetadata()
    r._metadata.allow_duplicates = True
    r.vars = {}
    r.tasks = None
    r.tasks_from = '../../tasks/main.yml'
    r._dependencies = []
    r._parents = []

    i = IncludeRole()
    i._role_name = 'ansible-role'
    i.vars = {}

    ir

# Generated at 2022-06-11 10:56:20.456257
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    #
    # This test verifies that load() handles various invalid combinations
    # of arguments.
    #
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def test_IncludeRole_load_helper(arguments, data, expect_failure=True, action='include_role'):

        # The following code is copied from the constructor for IncludeRole
        # in order to replicate its state when calling load().
        data['__ansible_action__'] = action
        block = Block.load(data, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=loader)
        ir = IncludeRole(block=block)


# Generated at 2022-06-11 10:56:30.407740
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C


# Generated at 2022-06-11 10:56:59.637386
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:57:06.299924
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # test with a name
    ir = IncludeRole(role=None, task_include=None)
    ir._role_name = "test_role_name"
    assert ir.get_name() == "include_role : test_role_name", "IncludeRole get_name not working"
    # test with no name
    ir_no_name = IncludeRole(role=None, task_include=None)
    ir_no_name._role_name = None
    assert ir_no_name.get_name() == "include_role : None", "IncludeRole get_name not working"


# Generated at 2022-06-11 10:57:15.024887
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import ansible.playbook 
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    t = Task()
    b = Block()
    p = ansible.playbook.Play()
    p._included_file = "/root/test.yml"
    p._basedir = "/root"
    b._play = p
    b._parent = p
    t._parent = b
    b._role = None
    t._role = None
    ri = IncludeRole()
    ri._parent = t
    ri.name = "test123"
    assert ri.get_name() == "test123 : "


# Generated at 2022-06-11 10:57:25.313855
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    import os
    pb = Playbook.load(os.path.join('test/units/module_utils/', 'include_role-test.yml'), variable_manager=None, loader=None)
    assert isinstance(pb, Playbook)
    play = pb.get_plays()[0]
    assert isinstance(play, Play)
    assert len(play.get_roles()) == 1
    role_definition = play.get_roles()[0]

# Generated at 2022-06-11 10:57:34.238247
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import tempfile
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    # Create a temporary directory
    t = tempfile.mkdtemp()

    # Create a simple test playbook
    base_playbook = '''
    ---
    - hosts: localhost
      gather_facts: false
      tasks:
        - name: Include
          include_role: name=test_role
          vars:
            include_role_vars: include_role

    '''
    playbook_filename = os.path.join(t, 'test_playbook_role_include.yml')
    with open(playbook_filename, 'w') as f:
        f.write(base_playbook)

# Generated at 2022-06-11 10:57:45.575465
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader
    import ansible.constants as C

    class MockVariableManager(object):
        def __init__(self, play):
            self.play = play
        def get_vars(self, play, task):
            return self.play.vars

    class MockLoader(object):
        @staticmethod
        def file_exists(file_name):
            return False


# Generated at 2022-06-11 10:57:55.337315
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    import ansible.constants as C
    import ansible.plugins.action
    import ansible.plugins.cache.fact_cache
    import ansible.plugins.connection
    import ansible.plugins.lookup
    import ansible.plugins.strategy
    import ansible.plugins.strategy.linear
    import ansible.plugins.strategy.free
    import ansible

# Generated at 2022-06-11 10:58:05.548557
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    yaml_data = """
    - hosts: localhost
      tasks:
        - name: bad args
          include_role:
            name: geerlingguy.simple-test-role
            mytestargs: yes
    """

    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.playbook.play import Play

        loader = DataLoader()
        play = Play.load(yaml_data, loader=loader)
        play._variable_manager = VariableManager()
    except AnsibleParserError as e:
        assert "Invalid options for include_role: mytestargs" in e.message

# Generated at 2022-06-11 10:58:14.773332
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Testing:
      IncludeRole._get_block_list()
    """

    # Test 1:
    #   Test that empty role list is handled correctly;
    #   expecting ansible error

    # test setup
    block = Block.load(dict(name='test_block', tasks = []), play=None)
    role = Role.load(dict(name='test_role', tasks = []), play=None)
    task_include = IncludeRole.load(dict(name='test_include_role', role='test_role'), block=block, role=role)

    # test
    blocks, handlers = task_include.get_block_list()

    # test validation
    assert blocks == [], "blocks should be an empty list"

    # Test 2:
    #   Test that empty role list is handled correctly;
    #   expecting

# Generated at 2022-06-11 10:58:25.247716
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    data = {
        'include_role': {
            'name': 'example1',
        },
        'include_tasks': {
            'name': 'example2',
        },
    }
    try:
        ir = IncludeRole.load(data['include_role'])
        assert ir._role_name == 'example1'
        assert ir._role_path is None
        assert not ir.public
    except AnsibleParserError:
        assert False

    # test bad args
    try:
        data['include_role']['foobar'] = ''
        ir = IncludeRole.load(data['include_role'])
        assert False
    except AnsibleParserError:
        assert True

    # test 'public' option

# Generated at 2022-06-11 10:59:38.184436
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    import json

    # initialize needed objects
    variable_manager = VariableManager()
    loader = DataLoader()

    # parsing our yaml file into a json object
    data = loader.load_from