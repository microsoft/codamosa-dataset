

# Generated at 2022-06-11 10:49:59.924174
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    _mod_action_plugin.py - Unit test for method load of class IncludeRole
    """
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import action_loader

    # create a role and modify its definition
    role = Role()
    role.definition = RoleDefinition()
    role.definition.name = 'role_name'
    role.definition.path = 'role_path'
    role.definition.vars_files = None
    role.definition._task_blocks = None
    role.definition._handlers_blocks = None

    loader = action_loader._create_action_loader()
    task_include = action_loader.get('include_role', class_only=True)
    task_include.loader = loader
    ir

# Generated at 2022-06-11 10:50:10.966567
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.module_utils.six import iteritems
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import os
    import yaml


# Generated at 2022-06-11 10:50:16.214244
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    include_role = IncludeRole(block, role="test_role")
    assert include_role.get_name() == "include_role : test_role"

    include_role = IncludeRole(block, role="test_role", name="test_name")
    assert include_role.get_name() == "test_name"

# Generated at 2022-06-11 10:50:27.465077
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='./tests/units/support/hosts')


# Generated at 2022-06-11 10:50:38.127518
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    yml = '''
- hosts: localhost
  vars:
    # foo: bar
    # toto: titi
  tasks:
    - name: include role
      include_role:
        name: foo
        apply:
          tags:
            - bar
        vars:
          baz: qux
'''
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.metadata import MetadataParser
    import ansible.constants as C
    import ansible.playbook.play
    import ansible.playbook.playbook
    import ansible.utils.context_objects
    import ansible.vars.manager
    import ansible.vars.hostvars

    import sys
    if sys.version_info[0] < 3:
        from io import Bytes

# Generated at 2022-06-11 10:50:38.669117
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:50:39.238832
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:50:51.097061
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    IncludeRole._load:
     - Allow_duplicates.
     - Public.
     - Rolespec_validate.
     - Bad options.
     - Multiple args.
     - Different args.
     - 'From' type args.
    """

    include_role_obj = IncludeRole()

    ################################################################################
    # Allow_duplicates.

    data = dict(
        name='role_name',
        allow_duplicates=True,
    )
    actual = include_role_obj._load(data)
    assert actual.allow_duplicates
    assert actual.inline_task

    ################################################################################
    # Public.

    data = dict(
        name='role_name',
        public=True,
    )

# Generated at 2022-06-11 10:51:01.757051
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    variable_manager = DummyVarsPlugin()
    loader = DummyLoader()

    play_ds = dict(
        name="abc",
        hosts="all",
        gather_facts="no",
        roles=[]
    )

    my_play = Play().load(play_ds, variable_manager=variable_manager, loader=loader)
    my_play._tqm._unreachable_hosts = dict()


    display.verbosity = 3


# Generated at 2022-06-11 10:51:13.449578
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.plugins.loader import collection_loader

    loader = collection_loader
    variable_manager = VariableManager()
    play_context = PlayContext(loader=loader, variable_manager=variable_manager, options=dict(tags=['test']))
    play_context._set_options()
    # test load function in class IncludeRole
    # test normal case
    data = {
        u'name': 'test',
        u'vars': {
            u'var1': 'value1'
        }
    }
    task = IncludeRole.load(data, block=None, role=None, task_include=None, loader=loader, variable_manager=variable_manager)
    assert task is not None

# Generated at 2022-06-11 10:51:32.809164
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    v = VariableManager()
    loader = DataLoader()
    play = Play.load({}, variable_manager=v, loader=loader)
    inventory = InventoryManager([loader.load_from_file('./test/units/lib/ansible_test_inventory')])
    include_role = IncludeRole.load({"name": "test-role"}, block=Block(), role=Role(), task_include=TaskInclude())
    include_role.post_validate(play=play, variable_manager=v, loader=loader)

# Generated at 2022-06-11 10:51:33.638431
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:51:45.637701
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    class MockLoader(object):
        pass

    loader = MockLoader() #MockLoader(searchpath=['./roles'])
    variable_manager = VariableManager()

    dirname = './roles'
    name = 'role_a'
    play_name = 'test'
    role_path = dirname + '/' + name
    playbook_path = 'test.yaml'


# Generated at 2022-06-11 10:51:54.191541
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = {
        'args': {
            'name': 'geerlingguy.apache',
            'apply': {
                'when': "{{ ansible_os_family == 'Debian' }}"
            }
        },
        'block': {},
    }
    loader = DataLoader()
    variable_manager = VariableManager()
    task_include = TaskInclude()
    task_include.vars = {}

    # success
    role = Role()
    role.metadata = RoleMetadata()
    role.metadata.dependencies = []

# Generated at 2022-06-11 10:52:05.321640
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block([])
    task1 = IncludeRole(block)
    task2 = IncludeRole(block)

    block.block  = [task1, task2]

    # Change _parent_role of task1
    task1._parent_role = "test_value1"

    # BUG-FIX-10/22/2019
    # The method get_block_list() did not call the method get_include_params()
    # to retrieve the params for the play variable manager.
    # The variable manager was None and thus the test was failing.
    # Hence, calling the method get_include_params() before calling the method
    # get_block_list().
    params = task1.get_include_params()

    # Call the method get_block_list

# Generated at 2022-06-11 10:52:16.277575
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import filter_loader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # create objects of all the classes required for test case
    role = Role()

# Generated at 2022-06-11 10:52:29.265793
# Unit test for method get_name of class IncludeRole

# Generated at 2022-06-11 10:52:38.938006
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Initialize
    block_data = {}
    block = Block(block_data)
    role = {}
    task_include = {}
    variable_manager = {}
    loader = {}

    # action is not implemented

    # action is implemented
    action = 'include_role'
    task_include['action'] = action
    role['_role_path'] = '/home/ansible/roles/role1'
    task_include['vars'] = {'var1': 'value1'}
    play = {}
    play['roles'] = [role]
    task_include['name'] = 'role1'
    role['tasks'] = []
    role['handlers'] = []
    role['vars'] = {'var2': 'value2'}

    # For now the test passed

# Generated at 2022-06-11 10:52:46.588969
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role

    # For instance creation
    data = {'args': {'role': 'test'}}
    block = Block()
    role = Role()

    # For use with load method
    variable_manager = None
    loader = None

    r_instance = IncludeRole().load(data, block, role, variable_manager, loader)
    assert r_instance.action == 'include_role'
    assert r_instance._role_name == 'test'


# Generated at 2022-06-11 10:52:57.455202
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.connection = 'local'

    def load_data(data):
        '''
        Function to test a `data` dict, common to all tests
        '''
        ir = IncludeRole.load(data=data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)

        blocks = ir.get_block_list

# Generated at 2022-06-11 10:53:24.741848
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from units.mock.loader import DictDataLoader

    # Create a mock object for the host(target)
    host = Mock()
    host.get_name.return_value = 'test_host'

    # Create a mock object for the play
    play = Mock()
    play.hosts = [host]

    # Create a mock object for the role
    role = Mock()
    role.get_name.return_value = 'role1'
    role.get_path.return_value = '/test/role'


    # Create a mock object for the variable_manager
    variable_manager = Mock()
    variable_manager.get_vars.return_value = {'var1': 'test1'}

    # Create a mock object for the loader

# Generated at 2022-06-11 10:53:33.689954
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar
    from ansible.module_utils._text import to_text
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Load role
    role_name = 'test_role'
    myplay = Mock()
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create an IncludeRole object
    ir = IncludeRole()
    ir._role_name = role_name

    # PATCH other methods of class IncludeRole
    ir._get_role_path = Mock()
    ir._get_role_path.return_value = '/tmp/ansible_test_role/'
    ir.build_parent_block = Mock()
    ir.build_parent

# Generated at 2022-06-11 10:53:44.414302
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Create a mock of method load of class Block
    def dummy_load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None, collection_list=None):
        return Block().load_data(data)

    # Create a mock of method compile of class Role
    def dummy_compile(self, play=None, dep_chain=None):
        return [Block()]

    # Create a mock of method get_handler_blocks of class Role
    def dummy_get_handler_blocks(self, play=None):
        return [Block()]

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    block = Block()
    role = RoleDefinition()
    task_include = TaskInclude()


# Generated at 2022-06-11 10:53:55.049663
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole.load({'name': 'nfs'}, task_include='tasks/main.yml')
    assert ir.name is None
    assert ir.action == 'tasks/main.yml'
    assert ir._role_name == 'nfs'
    assert ir.statically_loaded is False
    assert ir.args == {'name': 'nfs'}
    assert ir.allow_duplicates is True
    assert ir._from_files == {}
    assert isinstance(ir, IncludeRole)

    ir = IncludeRole.load({'name': 'nfs', 'public': True, 'allow_duplicates': False, 'apply': {'tags': 'test_tags'},
                           'vars_from': 'vars/main.yml'}, task_include='tasks/main.yml')

# Generated at 2022-06-11 10:54:02.382884
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block.load(dict(role=dict(name='test-role'), tasks=[dict(debug=dict(var='a'))]))
    block._play = block
    role = Role()
    role._play = role
    ir = IncludeRole(block=block, role=role)
    ir._role_name = 'test-role'
    ret_blocks, ret_handlers = ir.get_block_list()
    assert ret_blocks[0]['block'][0]['task'][0]['debug']['var'] == 'a'

# Generated at 2022-06-11 10:54:13.866769
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class FakeOptions(object):
        verbosity = 0
        connection = 'local'
        module_path = 'library'
        forks = 1
        check = False
        become = False
        become_method = 'sudo'
        become_user = 'root'
        remote_user = 'root'
        listhosts = None
        subprocess_errors = False
        inventory = None
        extra_vars = [('name', 'pong'), ('role_name', 'pong')]
        private_key_file = None
        host_key_checking = False

# Generated at 2022-06-11 10:54:22.718337
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook

    # TODO: fill in
    data = """
- hosts: localhost
  gather_facts: no

  tasks:
    - include_role:
        name: a_role
"""
    pb = ansible.playbook.PlayBook(
        playbook=data,
        callbacks=None,
        runner_callbacks=None,
        stats=None,
    )
    play = pb.get_plays()[0]
    block_list, handler_list = play.compile()

    assert len(handler_list) == 0
    assert len(block_list) == 1
    assert isinstance(block_list[0], ansible.playbook.block.Block)
    assert len(block_list[0].block) == 1

# Generated at 2022-06-11 10:54:33.899391
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys
    #sys.path.append('./lib/')
    #import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role.definition
    import ansible.playbook.task
    from ansible.vars.unsafe_proxy import convert_unsafe_to_safe_and_convert_kv

    #create object of class Play
    play_test1 = ansible.playbook.play.Play(dict(
        name = "test_play",
        hosts = 'all',
        gather_facts = 'no',
        roles = ['test_role1']
    ))

    #create object of class Role

# Generated at 2022-06-11 10:54:44.086488
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    try:
        from .mock import patch, Mock
    except ImportError:
        from mock import patch, Mock

    from ansible.playbook.play_context import PlayContext

    block = Mock()
    block.vars = dict()
    role = Mock()
    role._role_path = "base.role"
    role._role_name = "base.role"
    role.get_role_params.return_value = dict()
    task_include = None
    role_name = "test_role"
    play = Mock()

    # setup the test object
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir._role_name = role_name
    ir.collections = []

    # make sure it fails without a loader since we use template
    ir.get_block

# Generated at 2022-06-11 10:54:51.435165
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test get_block_list method of class IncludeRole
    """
    from unittest.mock import MagicMock

    """
    mock class RoleInclude
    """
    class Mock_RoleInclude:
        @staticmethod
        def load(role_name, play, variable_manager, loader, collection_list):
            if role_name == RoleInclude.load_invalid_role:
                raise AnsibleParserError('Invalid role found')
            return Mock_RoleInclude()

        def compilation_success(self):
            if self.compilation_exception:
                return False
            return True

        def compile(self, dep_chain=[]):
            if self.compilation_exception:
                raise self.compilation_exception

            return self.blocks


# Generated at 2022-06-11 10:55:42.207522
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    play_context = dict(become=False,
                        become_user='test',
                        connection='test',
                        check_mode=True,
                        diff=False,
                        env=dict(PATH='/usr/local/bin:/usr/bin:/bin'),
                        forks=10,
                        inventory=None,
                        module_path=None,
                        password='test',
                        private_key_file=None,
                        scp_extra_args=None,
                        sftp_extra_args=None,
                        ssh_common_args=None,
                        ssh_extra_args=None,
                        force_handlers=True,
                        start_at_task=None,
                        roles_path=None,
                        subset=None,
                        tags=None,
                        timeout=200,
                        user='test')
    include_role = IncludeRole

# Generated at 2022-06-11 10:55:52.356696
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
  """Test load method of class IncludeRole"""
  task_include = None
  block = Block()
  role = Role()
  block.role = role
  data = {u'_ansible_no_log': False,
          u'block': {u'role': u''},
          u'connection': u'local',
          u'delegate_to': u'',
          u'ignore_errors': False,
          u'name': u'',
          u'private': True,
          u'public': False,
          u'role': u'galaxy_role',
          u'include': u'include_role'}
  variable_manager = None
  loader = None

# Generated at 2022-06-11 10:55:52.729422
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:56:02.271444
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task = IncludeRole(block, role)
    data = {'name': 'test', 'apply': {'ignore_unreachable': True},
            'tasks': 'test.yml', 'handlers': 'test.yml',
            'vars': 'test.yml', 'tags': ['test']}
    task.load(data, variable_manager=None, loader=None)
    assert task._name == 'test'
    #assert task._action == 'include_role'
    assert task._tasks_from == 'test.yml'
    assert task._handlers_from == 'test.yml'
    assert task._vars_from == 'test.yml'
    assert task._tags == ['test']
    assert task._run_once == False

# Generated at 2022-06-11 10:56:07.624632
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole()
    # name is needed, or use role as alias
    assert ir.load({'role':'test_role'})
    assert ir.load({'name':'test_role'})
    try:
        ir.load({'nope':'test_role'})
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-11 10:56:17.541114
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    class MockRole(Role):
        def __init__(self, name=None, path=None, data=None, metadata=None, loader=None, collection_list=None):
            self._role_name = name
            self._role_path = path
            self._metadata = metadata
            self.collection_list = collection_list

        def compile(self, *args, **kwargs):
            return self._data

    class MockPlay(object):
        def __init__(self):
            self.handlers = []
            self.roles = []
            self.vars = dict()
            self.default_vars = dict()

    class MockBlock:
        def __init__(self, name=None, parent=None, vars=None, collections=None):
            self.vars = vars

# Generated at 2022-06-11 10:56:26.307249
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Parameters
    data = "include_role: name=role_name tasks_from=task_file vars_from=vars_file allow_duplicates=yes rolespec_validate=no"
    role = None
    variable_manager = None
    loader = None
    task_include = "include_role"
    # Expected
    expected = "role_name"
    block = None
    # Result
    include_role = IncludeRole.load(data, block, role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    result = include_role._role_name
    # Assertions
    assert isinstance(include_role, IncludeRole)
    assert result == expected


# Generated at 2022-06-11 10:56:36.803128
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    display.verbosity = 3
    options = lambda x: None
    options.verbosity = 3

    # create a play with a simple include_role
    play_source = dict(
        name="play_name",
        hosts="hosts",
        gather_facts="no",
        roles=[
            dict(name="role_name",
                 include_role=dict(name="include_role_name",
                                   tasks_from="tasks/main.yml"))
        ]
    )
    loader = DictDataLoader({
        "tasks/main.yml": """
        - name: task_name
          debug:
            msg: task_msg
        """,
    })
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:56:42.115573
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    Block.load = lambda *args, **kwargs: Block()
    Role.load = lambda *args, **kwargs: Role()
    task = IncludeRole.load({'include_role': {'name': 'foo'}}, block=Block(), role=Role())
    assert task.get_name() == 'include_role : foo'


# Generated at 2022-06-11 10:56:46.772062
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    myir = IncludeRole()
    myir._parent_role = None
    myir._parent = None
    myir.statically_loaded = False
    myir.action = C.ACTION_INCLUDE_ROLE

    # build test roles
    role_data = {}
    role_data['name'] = 'test_role'
    role_data['path'] = '/etc/ansible/test_role'
    role_data['defaults'] = {}
    role_data['vars'] = {}
    role_data['tasks'] = []
    role_data['handlers'] = []
   

# Generated at 2022-06-11 10:58:04.557728
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # The data was generated using the following playbook.
    '''
    - hosts: localhost
      connection: local
      gather_facts: no
      tasks:
        - include_role:
            name: include_role_test
            apply:
              x: y
              z: 42
            public: True
            allow_duplicates: False
            rolespec_validate: False
            tasks_from: include_role_test/tasks/main.yml
            vars_from: include_role_test/vars/main.yml
            defaults_from: include_role_test/defaults/main.yml
            handlers_from: include_role_test/handlers/main.yml
    '''
    # Generated JSON below. Note that this is not a valid YAML file, it is
    # missing the

# Generated at 2022-06-11 10:58:05.337568
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:58:14.563373
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Test IncludeRole.get_block_list()
    '''

    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    # Create a Play to use in these tests
    play = Play.load(dict(
        name = "IncludeRole UnitTest",
        hosts = 'all',
        gather_facts = 'no',
        roles = [
        ],
    ), variable_manager=VariableManager())

    # Create a block to use in these tests

# Generated at 2022-06-11 10:58:24.972027
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import role

    import ansible.utils.vars as ans_vars

    tests = {}
    tests['1'] = {}
    tests['1']['bs'] = """
- hosts:   'localhost'
  vars:
    v1:      'a'
  vars_files:
    - the_file
  roles:
    - { role: 'a_role', tasks_from: 'some_file' }
"""

# Generated at 2022-06-11 10:58:34.681817
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test invalid options in include_role
    with pytest.raises(AnsibleParserError) as exec_info:
        data = dict(task='include_role', name='my_name', invalid_key='invalid')
        IncludeRole.load(data)
    assert 'Invalid options for include_role: invalid_key' in str(exec_info)

    # Test invalid options in import_role
    with pytest.raises(AnsibleParserError) as exec_info:
        data = dict(task='import_role', name='my_name', invalid_key='invalid')
        IncludeRole.load(data)
    assert 'Invalid options for import_role: invalid_key' in str(exec_info)

    # Test invalid options in include_role

# Generated at 2022-06-11 10:58:43.988759
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    import stat
    import tempfile
    import unittest

    current_dir = os.path.dirname(__file__)
    action_plugin_path = os.path.join(current_dir, '../../action_plugins')
    lookup_plugin_path = os.path.join(current_dir, '../../lookup_plugins')

    def setup_rolespec():
        '''Get an absolute path for the test rolespec'''

        fd, rolespec = tempfile.mkstemp()
        # mkstemp creates a read-only file, so make it writable
        os.chmod(rolespec, stat.S_IWUSR)

# Generated at 2022-06-11 10:58:52.303708
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.task import Task

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.base import PlaybookBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.utils.vars import combine_vars

    import json
    import os
    import tempfile

    # Setup variables
    role_path = "/opt/ansible/roles/test"

# Generated at 2022-06-11 10:58:52.959370
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert False

# Generated at 2022-06-11 10:59:02.774933
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def _create_IncludeRole(data="""
      - include_role:
          name: test_role
          apply:
            tests:
              - test1: 1
              - test2"""):
        block = Block()
        block._play = Mock()
        block._play.handlers = []
        block._play.roles = []
        role = Mock()
        role._role_path = "test_role"
        role._metadata = Mock()
        role._metadata.allow_duplicates = True
        loader = Mock()
        variable_manager = Mock()
        return IncludeRole.load(data, block=block, role=role, loader=loader, variable_manager=variable_manager)

    # ATTENTION: In order to use fixtures a pytest.mark.usefixtures has to be set in the test file
    # This is

# Generated at 2022-06-11 10:59:03.323746
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    obj = IncludeRole()