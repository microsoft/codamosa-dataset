

# Generated at 2022-06-11 10:49:51.226317
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:49:52.673450
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    result = IncludeRole.get_block_list()
    assert False

# Generated at 2022-06-11 10:50:03.280334
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import os
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    display_class_name = 'ansible.module_utils.basic.AnsibleModule, '
    class_name = 'AnsibleModule'
    # Create a temp directory to save the file and change the current directory
    # to the temp dir
    fake_file_name = 'fake_include_role.yml'
    os.mkdir('fake_role')
    os.chdir('fake_role')
    # Create a fake file with wrong indentation
    fake_file = open(fake_file_name, 'w')
    fake_file.write('---\n')
    fake_file.write('- include_role:\n')
    fake_file.write('     name: FOO')

# Generated at 2022-06-11 10:50:13.829111
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # setup
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    import os
    import tempfile
    import json
    import ansible.parsing.dataloader

    # setup files and directories
    temp_dir = tempfile.mkdtemp()
    role_dir = os.path.join(temp_dir, 'testdir')
    os.makedirs(role_dir)
    meta_file = os.path.join(role_dir, 'meta')
    tasks_file = os.path.join(role_dir, 'tasks', 'main.yml')
    handler_file = os.path.join(role_dir, 'handlers', 'main.yml')

# Generated at 2022-06-11 10:50:24.722340
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.verbosity = 2

    # --
    # Unit test for method load of class IncludeRole
    # --

    log = logging.getLogger('ansible.inventory')

    log.debug('')
    log.debug('UNIT TEST OUTPUT: test_IncludeRole_load()')

    # --

    # Make this a method of class IncludeRole
    #test_block = Block.load({"name": "name1", "block": "main", "parent": None, "role": None, "loop": "item_name", "loop_control": "loop_control_name", "when": "cond_name", "rescue": [], "always": [], "tags": [], "register": "result_name"}, play=None, variable_manager=variable_manager, loader=loader)

    # Mock
    mock_variable_manager

# Generated at 2022-06-11 10:50:35.882573
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # python 2.6 needed this import, but it breaks 2.7
    #from ansible.plugins.loader import add_all_plugin_dirs
    #add_all_plugin_dirs()

    data = dict(
        name='myname',
        role='myrole',
        tasks_from='mytasks',
        vars_from='myvars',
        defaults_from='mydefaults',
        handlers_from='myhandlers',
        public=True,
        allow_duplicates=True,
    )

    variable_

# Generated at 2022-06-11 10:50:47.265697
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    class DummyPlay(object):

        def __init__(self):
            self.roles = []

    class DummyVariableManager(object):

        def __init__(self):
            self.vars = {}

        def set_nonpersistent_facts(self, facts):
            pass

    # Create a dummy loader
    class DummyLoader(object):

        class CachedFile:
            def __init__(self, data):
                self.data = data

            def get_data(self):
                return self.data

        def __init__(self, file_data=None):
            self.file_data = file_data or {}

        def get_basedir(self, path):
            return '/fake_path'

        def path_dwim(self, basedir, given):
            return given


# Generated at 2022-06-11 10:50:58.162245
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import collections_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    # init objects
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()

    # init templar
    templar = Templar(loader=DataLoader(), variables=variable_manager.get_vars(play=None, task=None))

    # init fake role
    r = Role()
    r._role_

# Generated at 2022-06-11 10:51:06.189745
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    v = dict()
    role = Role()
    role._role_path = "path/to/role"
    role._metadata = Role()
    role._metadata.name = "role_name"
    role._metadata.version = "1.0"
    role._metadata.description = "role_description"
    ire = IncludeRole()
    ire._parent_role = role
    ire._role_name = 'dummy_role'
    v = ire.get_include_params()
    assert v["ansible_parent_role_names"] == ["role_name"], "Failed to get role name"
    assert v["ansible_parent_role_paths"] == ["path/to/role"], "Failed to get role path"

# Generated at 2022-06-11 10:51:08.016525
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # TODO: add unit test for IncludeRole.

    assert True

# Generated at 2022-06-11 10:51:26.330101
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create the arguments
    # args_list will be used to generate args dict with dict(args_list)
    args_list = {'name': 'foo', 'tasks_from': 'bar/tasks.yaml'}
    # action is used to create obj.action
    action = "include_role"
    # block is used to create obj.block
    block = Block()

    # Create obj from role
    obj = IncludeRole.load(data=args_list, block=block)
    # Assert obj has the given action
    assert action == obj.action
    # Assert obj has the given block
    assert block == obj.block
    # Assert obj has the given role
    assert "foo" == obj._role_name
    # Assert obj has the given role
    assert "bar/tasks" == obj._from_

# Generated at 2022-06-11 10:51:38.383236
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Make blocks and stuff
    loader = DictDataLoader({
        ".": DataSource({
            "main.yml": DataSource({
              "data": """
              - include_role:
                  name: include_role_tasks
                  tasks_from: tasks/main.yml
                  vars_from: vars/main.yml
                  apply:
                    tags: include_role_tasks
                  public: True
              """,
        })
      })
    })
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [],
        tasks = []
    ), loader=loader, variable_manager=variable_manager)


# Generated at 2022-06-11 10:51:49.663746
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    import unittest
    import tempfile
    import shutil

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import iteritems
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.plugins import action_loader


# Generated at 2022-06-11 10:52:01.685354
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import tempfile
    import shutil

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader, connection_loader, cache_loader, strategy_loader, vars_loader, lookup_loader, filter_loader, test_loader, terminal_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    base_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


# Generated at 2022-06-11 10:52:13.688756
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Mock objects
    block = Block()
    role = Role()
    task_include = TaskInclude()

    data_loader = DataLoader()
    inventory = InventoryManager('localhost,')
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)

    # Create test data
    data = AnsibleMapping()

# Generated at 2022-06-11 10:52:25.968268
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Check that - import_playbook: works
    assert IncludeRole.load({u'import_playbook': u'smtp.yml'})

    # Check that - include: works
    assert IncludeRole.load({u'include': u'smtp.yml'})

    # Check that - include_tasks: works
    assert IncludeRole.load({u'include_tasks': u'smtp.yml', u'name': 'test include_tasks'})

    # Check that - include_role: works
    assert IncludeRole.load({u'include_role': u'smtp.yml', u'name': 'test include_role'})

    # Check that - include_role: has valid options

# Generated at 2022-06-11 10:52:36.357813
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.collections import CollectionLoader

    loader = CollectionLoader()
    loader.set_basedir('docs/collections/test/test_namespace/')
    collection = loader.load('test_namespace.test_collection')
    p = Play.load({
        'name': 'test',
        'hosts': 'all',
        'roles': [RoleDefinition(collection.get_role('include_role')[0].get_role_path())],
        'tasks': [
            {'include_role': {'name': 'include_role'}},
        ],
    })

    include_role_task = p.tasks[0]
    blocks, handlers = include_role_task.get_

# Generated at 2022-06-11 10:52:43.727960
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # basic test of arg validation
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(dict(name='dummy', option='bad'), task_include=dict(action='incl_role'))

    # test that apply is not allowed in any action but include_role
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(dict(name='dummy', apply=dict()), task_include=dict(action='import_role'))

    # test that invalid from_args are not allowed

# Generated at 2022-06-11 10:52:44.802361
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass



# Generated at 2022-06-11 10:52:55.503631
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition, ROLE_TYPES
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    # Test setup
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    rolespec_validate = True


# Generated at 2022-06-11 10:53:20.483748
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(
        block=Block(),
        role=Role(),
        task_include=IncludeRole(
            block=Block(),
            role=Role(),
            task_include=IncludeRole(
                block=Block(),
                role=Role()
            )
        )
    )
    name = ir.get_name()

    assert(name is not None)
    assert(name != '')

# Generated at 2022-06-11 10:53:30.401674
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # FIXME: don't import like this
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader, module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class FauxLoader(object):

        def get_basedir(self, *args, **kwargs):
            return '/some/path'

        def path_dwim(self, *args, **kwargs):
            return '/some/path/defaults/main.yml'

        def get_collections(self):
            return []

        def load_plugin_filters(self):
            filters = {
                'foo': {'filter': 'bar'}
            }

            return filters


# Generated at 2022-06-11 10:53:37.116992
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
    variable_manager = inventory.get_variable_manager()
    play_context = PlayContext()


# Generated at 2022-06-11 10:53:48.330816
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''Unit test for method load of class IncludeRole'''

    data = dict(
        name='my-role',
        tasks_from='my-role_tasks.yml',
        handlers_from='my-role_handlers.yml',
        vars_from='my-role_vars.yml',
        defaults_from='my-role_defaults.yml',
        public=True,
        apply=dict(
            min_version=2,
        )
    )

    ir = IncludeRole.load(data)

    assert ir.statically_loaded == True
    assert ir._role_name == 'my-role'

# Generated at 2022-06-11 10:53:57.711127
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class _meta:
        def __init__(self):
            self.allow_duplicates = False
    class _role:
        def __init__(self):
            self._role_params = { 'role_params': 'expected' }
            self.get_name = lambda: 'role_name'
            self._role_path = 'role_path'
            self._metadata = _meta()
    class _block:
        def __init__(self):
            pass
    ir = IncludeRole(block=_block())
    ir._parent_role = _role()

    # Test case with parent role defined
    v = ir.get_include_params()

# Generated at 2022-06-11 10:54:09.872995
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.executor.task_queue_manager
    def _set_loader(self, task):
        self._loader, self._variable_manager = task.get_loader_and_vars()

    block = ansible.playbook.block.Block()
    ir = IncludeRole(block)
    ir._role_name = 'test_IncludeRole_role'
    ir._parent = Block()
    ir._parent.apply = dict()
    ir._parent.apply['delegate_to'] = 'vagrant'
    ir._parent.apply['serial'] = 1
    ir._parent.apply['run_once'] = True
    ir._parent.apply['when'] = dict()
    ir._parent.apply['when']['test_IncludeRole_run_once'] = 'success'
   

# Generated at 2022-06-11 10:54:14.263953
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(block=Block(), role=Role())
    ir.name = "one/two/three/four"
    ir._role_name = "one/two/three/four"
    assert ir.get_name() == "one/two/three/four : one/two/three/four"



# Generated at 2022-06-11 10:54:22.945050
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    def _createVariableManager(loader, inventory):
        variable_manager = VariableManager()
        variable_manager.extra_vars = {'hostvars': {'fake_host': {}}}
        variable_manager.set_inventory(inventory)
        return variable_manager

    def _createLoader():
        options = dict()
        options['verbosity'] = 3
        loader = DataLoader()
        return loader


# Generated at 2022-06-11 10:54:34.088815
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    role = Role.load('/path/to/roles/a/rolename',
                     'rolename',
                     {'tasks': ['tasks/main.yml']},
                     '/path/to/roles/a')
    ir = IncludeRole.load({'name': 'rolename'}, role)

    assert ir._role_name == 'rolename'
    assert ir._role_path == '/path/to/roles/a/rolename'
    assert ir._parent_role == role

    assert ir.args == {'name': 'rolename'}
    assert ir._from_files == {}

    ir = IncludeRole.load({'someoption': 'somevalue'}, role)
    assert ir.args == {'someoption': 'somevalue'}
    assert ir._role_name is None
    assert ir._role_

# Generated at 2022-06-11 10:54:44.268406
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    import mock
    import tempfile
    import shutil
    import os

    params = dict(
        tasks_from='tasks_file',
        vars_file='vars_file'
    )


# Generated at 2022-06-11 10:55:52.847054
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.errors import AnsibleParserError

    ir = IncludeRole()
    ir._role_name = 'test_role'

    # Failing role file name
    ir.set_loader(role_loader)
    ir._parent_role = Role()
    ir._parent_role._role_path = 'tests/lib/ansible/playbook/__init__.py'
    ir._parent_role._role_name = 'test_include_role'
    ir._parent_role._metadata = None
    ir._parent_role.get_vars = lambda: {'ansible_parent_role_paths': [ir._parent_role._role_path]}
    ir._parent_role.get_role_params

# Generated at 2022-06-11 10:55:55.235288
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Create fake data for the test
    data = dict(name="my_role")

    # Create the test object
    obj = IncludeRole()

    # Test the method
    obj._load(data=data)

# Generated at 2022-06-11 10:55:55.815758
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:56:05.069298
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = '''
    - import_role:
        name: sample_role
    '''
    task = IncludeRole.load(data)
    assert task.action == 'import_role'
    assert task.name is None
    assert task._role_name == 'sample_role'
    assert task.args.get('name') == 'sample_role'
    assert task._from_files == {}
    assert task._parent_role is None
    assert task._role_path is None
    assert task.statically_loaded is False
    assert task.allow_duplicates is True
    assert task.public is False
    assert task.rolespec_validate is True


# Generated at 2022-06-11 10:56:05.695622
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:56:12.536503
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole().get_name() == ": "
    assert IncludeRole(role=Role()).get_name() == ": "
    assert IncludeRole(role=Role(), name="role_name").get_name() == "role_name : "
    assert IncludeRole(task_include=TaskInclude()).get_name() == ": "
    assert IncludeRole(task_include=TaskInclude(), name="role_name").get_name() == "role_name : "



# Generated at 2022-06-11 10:56:22.281693
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.parsing.dataloader

    try:
        from ansible.parsing.vault import VaultLib

        vault_lib_totp = VaultLib(password=None, vault_password_file=None,
                                  vault_ids=None, vault_method=None,
                                  vault_version=None,
                                  vault_identity_list=None,
                                  format='yaml',
                                  loader=ansible.parsing.dataloader.DataLoader(),
                                  )
    except ImportError:
        vault_lib_totp = None

    import ansible.parsing.vault
    ansible.parsing.vault.vault_lib_totp = vault_lib_totp

    import ansible.playbook
    import ansible.executor


# Generated at 2022-06-11 10:56:32.466732
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    options = PlayContext()
    roles = [dict(name='Foo', include_role=dict(name='Bar'))]
    path = 'test_IncludeRole_load.yml'

    results = IncludeRole.process_include_results(roles, path, loader)

    assert results[0].get_name() == "include_role : Bar"
    assert results[0]._role_name == "Bar"
    assert results[0]._from_files == {'tasks': None, 'vars': None, 'handlers': None, 'defaults': None}

# Generated at 2022-06-11 10:56:42.430695
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    block = Block()
    role = Role()

    class FakePlay:
        pass

    myplay = FakePlay()
    myplay.handlers = []

    vars_manager = VariableManager()

    class TestIncludeRole(IncludeRole):

        def __init__(self):
            self.args = dict(
                name=AnsibleUnicode("apache-hosting"),
                tasks_from=AnsibleUnicode("tasks"),
                vars_from=AnsibleUnicode("vars.yml")
            )
            self.collections = []

            #

# Generated at 2022-06-11 10:56:43.013399
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:58:09.706196
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class MockIncludeRole(IncludeRole):
        def load_data(self, data):
            return self

    data = dict(
        name="Ansible.apache",
        apply={
            "tags": ['apache']
        }
    )

    play = dict(
        ansible_version=dict(
            _text='2.0.0.2'
        )
    )
    block = Block.load(data, play=play)
    role = Role()
    role._role_path = "Tests/support/roles/Ansible.apache"

    ir = MockIncludeRole.load(data, block, role)

    assert ir.name == 'Ansible.apache'
    assert isinstance(ir.apply, dict)
    assert ir.apply['tags'] == ['apache']

    assert ir._parent

# Generated at 2022-06-11 10:58:19.417237
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    loader_mock = mock.MagicMock()
    variable_manager_mock = mock.MagicMock()
    block_mock = Block(role=mock.MagicMock())
    ir = IncludeRole.load(data={'name': 'common', 'apply': {'tags': ['common']}}, 
                          block=block_mock, 
                          variable_manager=variable_manager_mock, 
                          loader=loader_mock)
    assert ir._apply_includes == None
    assert ir._allow_duplicates == True
    assert ir._error_on_undefined_vars == True
    assert ir._freeze_variables == False
    assert ir._loop == None
    assert ir._loop_args == None
    assert ir._loop_control == None

# Generated at 2022-06-11 10:58:29.668518
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.sentinel import Sentinel

    class ResultCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(ResultCallback, self).__init__(*args, **kwargs)
            self.result = []


# Generated at 2022-06-11 10:58:39.615782
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Unit test for method load of class IncludeRole
    """

    import ansible.playbook.play_context
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.module_utils.six
    import ansible.parsing.dataloader
    import ansible.playbook.role
    import ansible.playbook.task_include

    # Create a play_context
    play_context = ansible.playbook.play_context.PlayContext()

    # Create a loader
    loader = ansible.parsing.dataloader.DataLoader()

    # Create a variable_manager
    variable_manager = ansible.vars.manager.VariableManager()

    # Create a block
    block = ansible.playbook.block.Block()
    block._parent = None

# Generated at 2022-06-11 10:58:44.632516
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    IncludeRole: Check get_block_list method
    """

    from ansible.playbook import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    import ansible.constants as C

    # The class under test
    i = IncludeRole()

    # A basic task with a registered handler
    t1 = Task()
    t1._block = Block(parent_block=None, role=None, task_include=None, use_handlers=False, play=None)
    t1._name = "basic"
    t1._handler = True

    # A handler to be registered
    t2 = Task()
    t2

# Generated at 2022-06-11 10:58:50.821657
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(name='common', tasks_from='tasks/main.yml', apply=dict(ignore_errors=True))
    variable_manager = None
    loader = None
    block = Block()
    role = Role()
    task_include = None

    ir = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert ir._from_files['tasks'] == 'main.yml'
    assert ir.apply == dict(ignore_errors=True)

# Generated at 2022-06-11 10:59:00.174326
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO:
    # The tests for IncludeRole.get_block_list() only cover
    # the calls that changed after the method was moved to class
    # IncludeRole. The rest should be ported from the previous
    # location of the method (tasks/include.py:IncludeTask.get_block_list()).
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import inventory_loader

# Generated at 2022-06-11 10:59:09.989331
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    task = IncludeRole()
    task._parent = block
    block._parent = block

    role_path = 'path_to_role'
    tasks_from = 'path_to_tasks'
    vars_from = 'path_to_vars'
    defaults_from = 'path_to_defaults'
    handlers_from = 'path_to_handlers'
    apply_args = {'items': [1, 2]}
    allow_duplicates = False
    public = True
    rolespec_validate = False
    name = 'role_name'


# Generated at 2022-06-11 10:59:18.813502
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ''' Test IncludeRole.load method '''
    logger = logging.getLogger('role_include')
    display.verbosity = 3
    display.debug("\nTesting IncludeRole.load")

    # Test data with valid values and struct in expected format
    test_data = dict(
        name='myrole',
        tasks_from='mytasks.yml',
        vars_from='myvars.yml',
        defaults_from='mydefaults.yml',
        handlers_from='myhandlers.yml',
        apply=dict(
            test_key1='test_value1',
            test_key2='test_value2',
        )
    )

    def test_data_1(self):
        ir = IncludeRole()
        ir.load_data(test_data)
        assert_true

# Generated at 2022-06-11 10:59:27.680720
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    import os
    import json

    json_file = os.path.join(os.path.dirname(__file__), '../../', 'test/units/parsing/data/playbook_include_role.json')