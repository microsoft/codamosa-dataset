

# Generated at 2022-06-11 10:49:56.633038
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    include_role:
        name: myrole
    '''
    data = dict(
        __ansible_action__=dict(
            name='include_role',
            args=dict(name='myrole'),
        )
    )

    role = Role()
    role._role_path = '/my/roles/path'

    include = IncludeRole.load(data, role=role)
    assert include._role_name == 'myrole'
    assert include._parent_role == role
    assert include._role_path is None
    assert include.statically_loaded

# Generated at 2022-06-11 10:50:01.889517
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test for the case when role is dynamic
    gr = IncludeRole(role=Role(),role_name='test_role')
    gr.get_block_list()

    # test for the case when role is static
    gr = IncludeRole(role=Role(),role_name='test_role')
    gr.statically_loaded = True
    gr.get_block_list()

# Generated at 2022-06-11 10:50:02.584308
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
	pass

# Generated at 2022-06-11 10:50:08.394934
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    args = {}
    args['name'] = 'test'
    ir = IncludeRole()
    ir.load({'args': args}, block=Block(), task_include=None) # Block is a dummy parameter. It should not be used in get_name()

    assert(ir.get_name() == "include_role : test")
    assert(ir.get_name() != "include_role : test1")

# Generated at 2022-06-11 10:50:17.270168
# Unit test for method get_include_params of class IncludeRole

# Generated at 2022-06-11 10:50:25.025259
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir._role_name = "foo"
    ir.action = "bar"

    assert ir.get_name() == "[foo] bar"


# Generated at 2022-06-11 10:50:28.921860
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor


    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'extra_var_1': 'extra_var_value_1',
                                   'extra_var_2': 'extra_var_value_2'}

    inventory_manager = InventoryManager(loader, variable_manager, loader.get_basedir())


# Generated at 2022-06-11 10:50:29.558061
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:50:36.585667
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    block = Block()
    role = Role()
    task_include = None
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    include_role.vars = dict(role_name='test_role_name')
    name = include_role.get_name()
    assert name == 'test_role_name : test_role_name'


# Generated at 2022-06-11 10:50:48.092957
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_data = {
        "name": "test_role"
    }
    manager = Block.load(data=test_data, variable_manager=None, loader=None)
    my_blocks = manager.get_block_list()
    assert my_blocks == None
    test_data = {
        "name": None,
        "role": "test_role"
    }
    manager = Block.load(data=test_data, variable_manager=None, loader=None)
    my_blocks = manager.get_block_list(play = None)
    assert my_blocks == None
    test_data = {
        "name": "test_role"
    }
    manager = Block.load(data=test_data, variable_manager=None, loader=None)
    my_blocks = manager.get_block_list

# Generated at 2022-06-11 10:51:02.031610
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block(parent_block=None)
    task = TaskInclude(block=block)
    role = Role()
    role._role_params = {'role_param': 'The value of role_param'}
    include_role = IncludeRole(block=block, role=role, task_include=task)
    include_params = include_role.get_include_params()
    assert include_params['role_param'] == 'The value of role_param'

# Generated at 2022-06-11 10:51:13.750344
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    r = Role().load({})
    assert r.get_include_params() == {}

    r = Role().load({'defaults': {'foo': 'bar'}, 'vars': {'baz': 'quux'}, 'dependencies': {'one': {}}})
    assert r.get_include_params() == {'foo': 'bar', 'baz': 'quux'}

    r2 = Role().load(data={'dependencies': {'one': {}}})
    r.add_child_role(r2)
    assert r.get_include_params() == {'foo': 'bar', 'baz': 'quux'}

    r3 = Role().load(data={'defaults': {'bar': 'baz'}, 'vars': {'quux': 'baz'}})
    r

# Generated at 2022-06-11 10:51:23.690003
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import json
    import sys
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    data = {
        "name": "test-role",
    }
    loader = DataLoader()
    variable_manager=VariableManager()
    variable_manager.extra_vars = {
        "hosts": "testhost",
    }

    ivm = InventoryManager(loader=loader, variable_manager=variable_manager, sources="testhost")
    variable_manager.set_inventory(ivm)


# Generated at 2022-06-11 10:51:34.341315
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test a normal use case
    data = {'name': 'test_role'}
    block = Block()
    role = Role()
    try:
        ir = IncludeRole.load(data, block, role)
    except Exception as e:
        raise AssertionError('Could not create IncludeRole: %s' % e)

    assert ir._role_name == 'test_role'

    # Test a reversed use case
    data = {'role': 'test_role'}
    try:
        ir = IncludeRole.load(data, block, role)
    except Exception as e:
        raise AssertionError('Could not create IncludeRole: %s' % e)

    assert ir._role_name == 'test_role'

    # Test with a bad parameter
    data = {'blah': 'test_role'}


# Generated at 2022-06-11 10:51:40.494436
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name = 'name1',
    )

    block = Block(role=None, task_include=None, use_handlers=False, always_run=False, loop=None)
    role = Role()
    ir = IncludeRole.load(data, block = block, role = role)
    ir.validate()
    print(ir)

# Generated at 2022-06-11 10:51:46.066868
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    role_name = 'my_role'
    module_name = 'include_role'
    block = Block()
    ir = IncludeRole(block, None, task_include=None)
    ir._role_name = role_name

    generated_name = ir.get_name()

    assert generated_name == "%s : %s" % (module_name, role_name)

# Generated at 2022-06-11 10:51:54.428487
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.plugins.loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    # Loading inventory file
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[ 'tests/unit/inventory_vars.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create PlaybookExecutor object
    pbex = Play

# Generated at 2022-06-11 10:52:05.600856
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'include_role': {
            'name': 'foobar',
        }
    }
    include = IncludeRole.load(data)
    assert include.args['name'] == 'foobar'
    assert include._role_name == 'foobar'

    data = {
        'include_role': {
            'role': 'foobar',
        }
    }
    include = IncludeRole.load(data)
    assert 'name' not in include.args
    assert include.args['role'] == 'foobar'
    assert include._role_name == 'foobar'

    data = {
        'include_role': {
            'name': 'foobar',
            'unknown': 'value',
        }
    }
    include = IncludeRole.load(data)

# Generated at 2022-06-11 10:52:16.454849
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # init data
    data = {
            'include_role':{'name':"role1"}
            }
    block = Block.load(data, play=None)
    role = Role()
    role.name = "role1"

    # init test obj
    ir = IncludeRole(block, role)
    # set attr
    ir._role_name = "role1"
    ir.statically_loaded = False
    ir.public = False
    ir.rolespec_validate = False
    ir._role_path = "/tmp/.ansible/roles/role1/meta_my_role.yml"


# Generated at 2022-06-11 10:52:29.516551
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # NOTE: this is a poor unit test, as it actually runs get_block_list.
    #       it should probably stub out the load and compile methods of
    #       Role and RoleInclude to test them more independently
    import ansible.plugins.loader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task

    import os
    import tempfile
    import shutil
    import yaml
    import sys

    # TODO:
    #   - should we test different combinations of include_tasks,
    #     include_v

# Generated at 2022-06-11 10:52:44.160477
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role(name='role_name')
    role._metadata.allow_duplicates = True
    ir = IncludeRole(block, role)
    ir.vars = dict(
        task_name = dict(
            var1 = 'value1'
        )
    )
    ir._from_files = dict(
        tasks = 'tasks',
        vars = 'vars',
        defaults = 'defaults',
        handlers = 'handlers'
    )
    ir._parent_role = None
    ir._role_name = "role1"
    loader = None
    play = None
    variable_manager = None

    ir.rolespec_validate = False

# Generated at 2022-06-11 10:52:54.859014
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    # we create a mock of the TaskInclude class, for the unit test
    class TaskInclude(object):
        def __init__(self, *args, **kwargs):
            self.module_args = kwargs['module_args']
            self.action = 'include_role'

        def get_name(self):
            return self.module_args.get('name')

    data = {
        "name": "test_name_000",
        "role": "test_role_000",
        "private": False,
        "allow_duplicates": True
    }


# Generated at 2022-06-11 10:53:05.221941
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    This is a test case to verify that the method IncludeRole.get_block_list() successfully
    retrieve a list of tasks from a role.
    This test case works with a simple role named test_role that is composed of a single task.
    Since IncludeRole inherits from TaskInclude, its constructor needs some parameter to
    be defined, although they are not used within the method.
    """
    from ansible.errors import AnsibleParserError
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    # Create a IncludeRole instance
    block = Block()
    role = Role()
    test_include = IncludeRole(block, role)

    # Set the path to the test role

# Generated at 2022-06-11 10:53:05.561156
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:53:09.837761
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class FakeRole(Role):
        def __init__(self, blocks, name=None, handlers=None):
            super(FakeRole, self).__init__(name=name, collection_list=[])
            self._blocks_bag = blocks
            self._handlers_bag = handlers
    
        def get_handler_blocks(self):
            return self._handlers_bag
    
        def compile(self):
            return self._blocks_bag

    # Tests the case when the block has no rolespec_validate
    def test_get_block_list_default():
        block = IncludeRole(Block(parent_block=None, role=FakeRole([])))

        block_list, _ = block.get_block_

# Generated at 2022-06-11 10:53:12.382439
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    ir = IncludeRole()
    ir.name = "testName"

    assert ir.get_name() == "testName"

    ir.name = None
    ir.action = "testAction"
    ir._role_name = "testRoleName"

    assert ir.get_name() == "testAction : testRoleName"

# Generated at 2022-06-11 10:53:14.467880
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """ Test class IncludeRole load method """
    data = {}
    assert IncludeRole.load(data=data, block=None, role=None, task_include=None, variable_manager=None, loader=None)


# Generated at 2022-06-11 10:53:20.076553
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    include_role = IncludeRole(block=block, role='role1')
    include_role.args['name'] = 'role1'
    play = 'play'
    variable_manager = 'variable_manager'
    loader = 'loader'
    blocks, handlers = include_role.get_block_list(play=play, variable_manager=variable_manager, loader=loader)
    assert blocks is not None
    assert handlers is not None

# Generated at 2022-06-11 10:53:29.967584
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = None
    variable_manager = VariableManager()
    block_list = None
    play_context = PlayContext()

    data = dict(
        name='test_role',
        task_include=dict(
            name='test_include',
            include='test_include',
        ),
        block=dict(
            tasks=dict(
                name='test_task',
                shell='echo "hello"'
            )
        )
    )

    ir = IncludeRole.load(data=data, variable_manager=variable_manager, loader=loader)
    assert ir.name == 'test_role'
    assert block_list == None

    play = Play().load

# Generated at 2022-06-11 10:53:36.865383
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    block = Block()
    role = Role()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(roledefs=dict(foo=dict(index=1, ignore_errors=True), other=dict(index=2)))
    loader = None
    include_role = IncludeRole(block=block, role=role)

    # required
    data = dict(name='foo', loop='{{roledefs.foo}}', index=1)
    task = include_role.load(data, block, role, loader=loader, variable_manager=variable_manager)
    assert task._role_name == 'foo' and task.index == 1

# Generated at 2022-06-11 10:53:59.544031
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    ######################################################################################################################
    #
    # Setup
    #
    ######################################################################################################################
    # ######################################################################################################################
    # Setup for block test
    # ######################################################################################################################

    # Role

# Generated at 2022-06-11 10:54:11.776338
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook = Playbook.load('test_playbook.yaml', variable_manager=variable_manager, loader=loader, inventory=inventory)

    myblock = Block()
    data = {'include_role': {'name': 'test'}}
    ir = IncludeRole.load(data=data, block=myblock, variable_manager=variable_manager, loader=loader)

    blocks

# Generated at 2022-06-11 10:54:21.432351
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    class MockPlay(object):
        def __init__(self):
            self.handlers = []
            self.roles = []

    class MockRole(object):
        def __init__(self):
            self._metadata = None
            self._role_path = "foo/roles/bar"

    class MockBlock(Block):
        def __init__(self):
            self._attributes = None


# Generated at 2022-06-11 10:54:27.940934
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    block = Block()
    role = "my_role"
    task_include = "my_task"
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    assert type(include_role) == IncludeRole
    # TODO
    # Add tests for method get_block_list of class IncludeRole

# Generated at 2022-06-11 10:54:38.343802
# Unit test for method load of class IncludeRole

# Generated at 2022-06-11 10:54:47.778970
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import pytest
    from mock import Mock, PropertyMock

    # Simulate a block and a role
    block = Mock(spec=Block)
    type(block)._parent = PropertyMock(return_value=Mock(name="parent role"))
    role = Mock(name="parent role", spec=Role)


# Generated at 2022-06-11 10:54:57.621168
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import os
    import ansible.utils.plugin_docs as docs

    loader, inventory, variable_manager = docs._setup_loader()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    inventory._hosts = {'127.0.0.1': {
        'host_name': 'localhost',
        'connection': 'local',
        'vars': {'test_hostvar': 'test_hostvalue'},
        'groups': ['test_group1', 'test_group2']
    }}
    inventory._groups = {'test_group1': {'vars': {'test_group1var': 'test_group1value'}},
                         'test_group2': {'vars': {'test_group2var': 'test_group2value'}}}

    role_

# Generated at 2022-06-11 10:55:07.527464
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task

    yaml_data = """
    - name: Foo
      include_role:
        name: bar
        apply:
          tags:
            - baz
          block:
            - meta:
                tags:
                  - baz
            - fail:
                msg: "This won't be run"
              tags:
                - not_baz
              block:
                - fail:
                    msg: "This won't be run"
    """

    role_name = "bar"
    role_path = "/some/path/foo/roles/" + role_name


# Generated at 2022-06-11 10:55:10.965049
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'name'
    assert ir.get_name() == 'name'
    ir.name = None
    ir._role_name = 'hello, world!'
    assert ir.get_name() == 'include_role : hello, world!'

# Generated at 2022-06-11 10:55:15.719797
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    role = Role()
    block = Block(role=role)
    include = IncludeRole(block=block, role=role)
    ret = include.get_block_list(play=None, variable_manager=None, loader=None)
    assert ret == ((), ())

# Generated at 2022-06-11 10:55:54.506800
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import os
    import sys
    import shutil
    import tempfile
    import yaml
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.errors import AnsibleError

    display = Display()
    vars_manager = VariableManager()
    loader = DataLoader()


    # create a temporary directory
    tmpdir = tempfile

# Generated at 2022-06-11 10:56:04.842448
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class Y(object):
        pass
    x = Y()
    x.tasks = [{'name': 'Test', 'hosts': '{{ host }}', 'action': 'ping', 'rolespec': 'include role'}]
    x._role_name = 'MyRole'
    x.vars = {'host': 'xyz'}
    x._from_files = {'tasks': 'tasks/main.yaml'}
    x._parent_role = Y()
    x._parent_role._role_path = '~/roles/MyRole'
    x._role_name = 'MyRole'
    blocks, handlers = x.get_block_list()
    assert blocks[0].module == 'ping'
    assert blocks[0].module_args == 'xyz'

# Generated at 2022-06-11 10:56:15.592358
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    lst1 = ['name', 'role', 'vars_from']
    lst2 = ['tasks_from', 'defaults_from', 'handlers_from']
    lst3 = ['apply', 'allow_duplicates', 'public', 'rolespec_validate']

    for lst in [lst1, lst2, lst3]:
        for opt in lst:
            print(opt)

            data1 = {opt: 'foo'}
            data2 = {opt: 42}
            data3 = {opt: [1, 2, 3]}
            data4 = {opt: {'a': 1, 'b': 2}}

            ir = IncludeRole()

            if lst in (lst1, lst3):
                assert ir.load(data1)

# Generated at 2022-06-11 10:56:20.071328
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.name = 'test_name'
    ir._role_name = 'role1'
    assert ir.get_name() == 'test_name'
    ir.name = None
    assert ir.get_name() == 'include_role : role1'
    ir.action = 'include_tasks'
    assert ir.get_name() == 'include_tasks : role1'


# Generated at 2022-06-11 10:56:30.017847
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create a dummy Block
    block = Block()

    # Create a dummy IncludeRole
    include_role = IncludeRole()

    # Call the get_block_list method
    # Note that this call fails with an error as the _role_name is not set
    # To link a task to an actual role you need to specify a name
    # This is what is done in the role loader (which is called later in the process)
    try:
        include_role.get_block_list(play=None, variable_manager=None, loader=None)
    except AnsibleParserError as e:
        assert str(e) == "'name' is a required field for - include_role:"
    else:
        raise Exception("Unit test for IncludeRole().get_block_list() should have failed as name was not set")



# Generated at 2022-06-11 10:56:40.481776
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.definition import RoleIncludeDef
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    host = Host(name="localhost")
    inventory.add_host(host)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    context = PlayContext()

    # Test for IncludeRole
    block = Block()

# Generated at 2022-06-11 10:56:49.865120
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    MockedTask = type('MockedTask', (object,), {
        'get_name': lambda: 'dummy name',
    })

    MockedParentRole = type('MockParentRole', (object,), {
        '_parent_role': None,
        'get_role_params': lambda: {},
        'get_name': lambda: 'dummy parent role name',
        '_role_path': 'dummy parent role path',
    })

    MockedRoleInclude = type('MockedRoleInclude', (object,), {
        'load': lambda s, n, p, vm, l, cl: MockedParentRole(),
    })


# Generated at 2022-06-11 10:56:59.716032
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """ IncludeRole: load - error cases """
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader

    # no name given
    args = dict(role='test.role')
    loader = DataLoader()
    hostvars = dict()
    variable_manager = None #TODO
    try:
        RoleInclude.load(args, loader=loader, variable_manager=variable_manager)
        assert False, 'Expected AnsibleParserError'
    except AnsibleParserError as e:
        assert isinstance(e.obj, dict)
        assert 'role' in e.obj
        assert e.obj['role'] == 'test.role'

    # no role given
    args = dict(name='test.role')
    loader = DataLoader()
    hostvars

# Generated at 2022-06-11 10:57:07.055780
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {u'include_role': {u'name': u'Terraform', u'private': u'false', u'allow_duplicates': u'false', u'apply': {}, u'tasks_from': u'uninstall.yml', u'rolespec_validate': u'false', u'vars_from': u'vars.yml', u'handlers_from': u'uninstall.yml', u'defaults_from': u'defaults.yml', u'public': u'false'}}
    ir = IncludeRole.load(data, variable_manager=None, loader=None)
    assert ir.args['name'] == u'Terraform'

# Generated at 2022-06-11 10:57:17.643441
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import ansible.playbook
    import ansible.playbook.role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping

    # Set up test environment for testing methods of class IncludeRole

# Generated at 2022-06-11 10:58:28.390901
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    play.post_validate(variable_manager=variable_manager)

    data = None
    block = None
    role = None
    task_include = None

    data = dict(
         name="test"
    )


# Generated at 2022-06-11 10:58:38.651797
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader, module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import os
    import shutil
    os.makedirs('./vars')
    shutil.copyfile('../../test/vars/main.yml', './vars/main.yml')
    task = IncludeRole()
    task._role_name = 'test_role'
    task._role_path = './vars/main.yml'
    play_context = PlayContext()
    module_loader.add_directory('./plugins/modules')
    module_loader.add_directory

# Generated at 2022-06-11 10:58:39.614278
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # TODO: setup debug and check output
    pass

# Generated at 2022-06-11 10:58:46.697619
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    my_loader = DataLoader()
    my_inventory = Inventory(loader=my_loader, variable_manager=VariableManager(), host_list=['localhost'])

# Generated at 2022-06-11 10:58:50.861757
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude

    # Initialize class IncludeRole
    include_role = IncludeRole(role=RoleDefinition())

    block_list = include_role.get_block_list()
    assert block_list == []



# Generated at 2022-06-11 10:59:00.174960
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # import modules needed to construct fake objects
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import ansible.template as template
    template.Template._config_class = None
    from ansible.playbook.role.definition import RoleDefinition

    # construct fake objects
    play = Play().load(dict(
        name='fakeplay',
        hosts='foo',
        roles=['bar'],
        vars={}
        ))
    block = Block.load(
        dict(
            tasks=[]
            )
        )
    role = RoleDefinition(
        name='fake_role',
        play=play
        )

    # construct real object
    obj = IncludeRole(block=block, role=role)

    # assign attributes
    obj._role_name = 'test_role'

# Generated at 2022-06-11 10:59:05.028699
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()

    myplay = None
    variable_manager = None
    loader = None

    ir.rolespec_validate = False
    ir._role_name = "test.role"

    ir.allow_duplicates = True
    ir.get_block_list(play=myplay, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:59:14.372641
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.tests.unit.test_playbook import test_playbook

    # set workaround so we can use a template
    C.DEFAULT_HASH_BEHAVIOUR = 'merge'

    # test no name or role error
    block = Block()
    role = Role()
    task_include = IncludeRole(block, role)

    data = dict(tasks='main.yml')
    ir = IncludeRole.load(data, block=block, role=role, task_include=task_include)

    assert(ir._role_name is None)

    # test role arg
    data = dict(role='some_role')
    ir = IncludeRole.load(data, block=block, role=role, task_include=task_include)

    assert(ir._role_name == 'some_role')



# Generated at 2022-06-11 10:59:23.330731
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.playbook.block import Block

    # Create an IncludeRole object
    data = AnsibleUnicode('role_name')
    block = Block()
    role = Role()
    role._role_path = 'role_path'
    task_include = None
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir._from_files = {"from_files": "from_files"}

    # Create a Play object
    play_context = PlayContext()
    variable_manager = VariableManager

# Generated at 2022-06-11 10:59:23.944340
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass