

# Generated at 2022-06-11 10:49:58.940091
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    task = dict(action='include_role', name='test')
    block = Block(TaskInclude.load(task, None, None, None, None))
    role = RoleDefinition.load(dict(name='test_role', tasks=task), None, None)
    ir = IncludeRole(block=block, role=role)
    loader = DataLoader()
    var_manager = VariableManager()
    play = Play().load(dict(name='play1', hosts=['localhost'], roles=[role]), loader=loader, variable_manager=var_manager)
    blocks, handlers = ir.get_block_

# Generated at 2022-06-11 10:50:09.775287
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    cls = IncludeRole

    # action is set to include, include is set to none
    ir = cls()
    ir.action = 'include'
    ir.include = None
    assert ir.get_name() == 'include : UNSET'

    # action is set to include
    ir = cls()
    ir.action = 'include'
    ir.include = 'test'
    assert ir.get_name() == 'include : test'

    # action is set to include_tasks
    ir = cls()
    ir.action = 'include_tasks'
    ir.include = 'test'
    assert ir.get_name() == 'include_tasks : test'

    # action is set to import_task
    ir = cls()
    ir.action = 'import_tasks'

# Generated at 2022-06-11 10:50:18.007029
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    play_ctx = PlayContext()
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir._role_name = "geerlingguy.git"
    blocks, handlers = ir.get_block_list()
    assert len(handlers) >= 1
    assert len(blocks) >= 1

    # The tests below need a copy of the correct data structures
    # in order to be able to test correctly.
    # The data structures are not in the repository,
    # so we have to build them skeleton from the tests below.
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-11 10:50:28.964018
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Validate that IncludeRole.load() raises an AnsibleParserError if:
    - a required option is missed
    - an unnecessary option is passed
    - an option has a wrong type
    - a mandatory option is missing
    - an option is not a string
    """
    import ansible.playbook.play_context
    import ansible.utils.vars
    from ansible.parsing.dataloader import DataLoader

    context = ansible.playbook.play_context.PlayContext()
    variable_manager = ansible.utils.vars.VariableManager()
    loader = DataLoader()

    data = dict(
        name="test_role",
        apply=dict(),
        public=False
    )


# Generated at 2022-06-11 10:50:39.187122
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play

    role_file = '/usr/share/ansible/roles/common/tasks/main.yml'
    block = Block()
    role = Role()
    role_path = '/usr/share/ansible/roles/common'
    role._role_path = role_path

    loader = None
    variable_manager = None

    task_include = IncludeRole(block=block, role=role)

    playbook_dir = '/tmp'


# Generated at 2022-06-11 10:50:48.902403
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    include_role = IncludeRole()
    data = dict(action=None, name=None, tasks_from=None, vars_from=None, defaults_from=None, handlers_from=None, register=None, ignore_errors=None, tags=None, when=None, file=None, tags_from_file=None, args=None, role=None, always_run=None, resc_from=None)

    role_loaded = include_role.load(data=data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert role_loaded is None, "IncludeRole load method doesn't work as expected"

# Generated at 2022-06-11 10:50:59.882549
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()

    # Test 1
    ir._role_path = None
    ir._parent_role = None
    assert ir.get_include_params() == {}

    # Test 2
    ir._role_path = './'
    ir._parent_role = None
    assert ir.get_include_params() == {}

    # Test 3
    ir._role_path = './'
    class mock_role(object):
        def __init__(self):
            self._role_path = 'test_role1'
            self.get_role_params = lambda : {'vars': {'var1': 'val1'}}
            self.get_name = lambda : 'role1'
    ir._parent_role = mock_role()

# Generated at 2022-06-11 10:51:09.516448
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """Unit test - IncludeRole - load method"""

    import ansible.playbook.role.meta

    # test load without role
    r = IncludeRole(role=None)
    d = dict(
        name="test",
    )
    r.load(d)
    assert r.name == "test"

    # test load with role
    r = IncludeRole(role=ansible.playbook.role.meta.Role())
    d = dict(
        name="test",
    )
    r.load(d)
    assert r.name == "test"
    assert r._tasks == []
    assert r.tags == []

# Generated at 2022-06-11 10:51:20.558769
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()

    # Actual values
    # --------------------------------------
    # IncludeRole(block=None, role=None, task_include=None)
    # load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):

    role_name = "some_role"
    args = { 'name' : role_name }

    # new_me = super(IncludeRole, self).copy(exclude_parent=exclude_parent, exclude_tasks=exclude_tasks)
    # return new_me

    # setattr(ir, option, ir.args.get(option))
    # ir.action = "_role_include"
    # ir.name = "Role Include some_role"
    # ir.args = args
    # ir._role_name = role_name

# Generated at 2022-06-11 10:51:27.765051
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    role1_yml = """
    - debug:
        msg: "Hello"
    """
    task1_yml = """
    - hosts: localhost
      gather_facts: no
      tasks:
      - include_role:
          name: role1
    """
    role1 = Role()
    role1.load_from_file('role1', role1_yml)
    task1 = IncludeRole()
    task1.load_from_file('task1', task1_yml)
    blocks = task1.get_block_list()
    assert blocks == [[{
        'tasks': [
            {
                'name': 'debug',
                'action': 'debug',
                'args': {
                    'msg': 'Hello'
                }
            }
        ]
    }]]

    task2_

# Generated at 2022-06-11 10:51:51.779945
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.verbosity = 3
    data = dict(
        name='test',
        role='test'
    )
    result = IncludeRole.load(data)
    assert result.get_name() == 'test : test'

# Generated at 2022-06-11 10:52:02.767937
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import unittest
    import os
    import json
    from ansible.playbook.play_context import PlayContext

    class TestIncludeRoleLoad(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test1(self):
            play_context = PlayContext()
            play_context.CONFIG_DEFAULT_SECTION = 'defaults'
            play_context.basedir = "/ansible-test/playbooks"
            play_context.vars = {}
            play_context.vars['home'] = os.environ['HOME']
            play_context.vars['ansible_connection'] = "local"
            play_context.vars['ansible_python_interpreter'] = sys.executable

# Generated at 2022-06-11 10:52:14.609088
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    options = dict(connection='local', forks=1, become=None, become_method=None, become_user=None, check=False, diff=False)

    display = Display()
    loader = DataLoader()
    passwords = dict()

    inventory = InventoryManager(loader=loader, sources=['localhost,127.0.0.1,all=True'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook = Play()
    variable_manager._options = options
    variable_

# Generated at 2022-06-11 10:52:21.945500
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    argument_spec = {'list':False}
    data = {
        'name': 'test role',
        'list': ['a', 'b'],
    }
    blk = Block()
    rl = Role()
    ti = IncludeRole()

    result = IncludeRole.load(argument_spec,data,blk,rl,ti)

    assert result._from_files == {}
    assert result.rolespec_validate == True


# Generated at 2022-06-11 10:52:33.513981
# Unit test for method load of class IncludeRole

# Generated at 2022-06-11 10:52:34.206111
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:52:42.474449
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)


# Generated at 2022-06-11 10:52:46.307457
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole.load(dict(action='include_role', role='mock_role', name='my include_role'), role=None)

    actual = ir.get_name()
    assert actual == 'my include_role : mock_role'


# Generated at 2022-06-11 10:52:57.208728
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Arrange
    data = dict()
    data['name'] = "role name"
    data['tasks_from'] = "mytasksfile.yml"
    data['vars_from'] = "myvars.yml"
    data['defaults_from'] = "mydefaults.yml"
    data['handlers_from'] = "handlerstask.yml"
    data['allow_duplicates'] = False
    data['public'] = True
    data['apply'] = {'newthing': 'newvalue'}
    data['rolespec_validate'] = False

    # Act
    ir1 = IncludeRole.load(data)
    ir2 = IncludeRole.load(data, block=None, role=None, task_include=None)

    # Assert

# Generated at 2022-06-11 10:53:07.024685
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible.executor.process.worker import WorkerProcess
    from ansible import context
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import Playbook

# Generated at 2022-06-11 10:53:31.927118
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Imports needed for this test
    import jinja2
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    if PY3:
        unicode = str

    # Set up things needed by get_block_list
    play = Play.load({}, variable_manager=VariableManager(), loader=None)
    templar = Templar(loader=None, variables={})
    ir = IncludeRole()
    ir._from_files = {'tasks': 'test_tasks_from'}
    ir._parent_role = None
    ir._role_name = 'test_role'
    ir._allow_duplicates = True

    # Define mock implementations of needed objects
   

# Generated at 2022-06-11 10:53:38.206943
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    def test_case(name, expected_result):
        ir = IncludeRole(role=None, block=None)
        ir.name = name
        ir.action = 'include_role'
        ir._role_name = 'foobar'
        assert ir.get_name() == expected_result

    # without name
    test_case(
        None,
        'include_role : foobar'
    )
    # with name
    test_case(
        'some_name',
        'some_name'
    )

# Generated at 2022-06-11 10:53:49.274924
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    #import json
    #import os

    # Load the default test data
    #data = json.load(open(os.path.join(os.path.dirname(__file__), 'loader_unittest.json')))

    # Create the fake inventory
    inv = Inventory()
    inv.add_group('fake_group')
    inv.add_host('fake_host', 'fake_group')

    # Create the fake play
    play_context = PlayContext()

# Generated at 2022-06-11 10:53:58.226131
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    TEST_ROLE_PATH = "/tmp/test"
    TEST_INVENTORY_PATH = "/tmp/test_inventory.yaml"


# Generated at 2022-06-11 10:54:04.671122
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = role = Role()
    role.name = "role_name"
    role.get_role_params()
    block = Block()
    ir = IncludeRole(role=role)
    ir.action = "include_role"
    ir._role_name = "role_name"
    assert ir.get_name() == "include_role : role_name"

# Generated at 2022-06-11 10:54:12.671736
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Validates that the IncludeRole.load class method works as expected
    """

    # Make some test data
    data = dict(
        name='test_role',
        vars=dict(x=1),
    )

    # Try creating an IncludeRole object from the data
    include = IncludeRole.load(data)

    # Verify the object is as expected
    assert isinstance(include, IncludeRole)
    assert include.name == 'test_role'
    assert isinstance(include.vars, dict)
    assert include.vars['x'] == 1



# Generated at 2022-06-11 10:54:21.998147
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    myloader = DictDataLoader({'a.yml': """
- name: a
  hosts: all
  roles:
    - b
"""})

    myplay = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        roles = ['a'],
    ), loader=myloader, variable_manager=VariableManager())

    myplay.post_validate(templar=None)
    myplay.handle_loader_errors()

    task = myplay.get_tasks()[0]
    include_role = task._block._resolve_task_include(task._task_include, loader=myloader, variable_manager=myplay._variable_manager)
    assert include_role._from_files['tasks'] == 'main.yml'


# Generated at 2022-06-11 10:54:33.205776
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'name': 'role_name',
        'apply': {
            'tags': ['always']
        },
        'private': False,
        'allow_duplicates': False,
        'rolespec_validate': False
    }

    data_copy = data.copy()
    include_role = IncludeRole.load(data_copy)
    assert include_role.name == 'role_name' and \
        include_role.apply == data['apply'] and \
        include_role.private == data['private'] and \
        include_role.allow_duplicates == data['allow_duplicates'] and \
        include_role.rolespec_validate == data['rolespec_validate']

    data_wrong = data.copy()

# Generated at 2022-06-11 10:54:43.289453
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Unit test for method load of class IncludeRole
    '''
    # Testing with include_role
    ir = IncludeRole.load({'include_role': {'name': 'sysctl'}}, variable_manager='', loader='')
    assert ir._role_name == 'sysctl'
    ir = IncludeRole.load({'include_role': {'role': 'sysctl'}}, variable_manager='', loader='')
    assert ir._role_name == 'sysctl'
    ir = IncludeRole.load({'include_role': {'name': 'sysctl', 'public': True}}, variable_manager='', loader='')
    assert ir._role_name == 'sysctl'
    assert ir._public == True

# Generated at 2022-06-11 10:54:48.422533
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    If a role includes a role with - include_role: ...
    We expect IncludeRole.load() to return an instance of IncludeRole
    containing the info to find and execute the included role
    """
    assert IncludeRole.load(data={'include_role': {'name': 'myrole'}})
    assert IncludeRole.load(data={'include_role': {'role': 'myrole'}})


# Generated at 2022-06-11 10:55:27.717589
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # variables
    block = Block()
    role = "role"
    loader = AnsibleCollectionLoader()

    # run test
    test_obj = IncludeRole(block, role)
    test_obj._role_name = 'foo'
    test_obj._parent_role = RoleMetadata()
    test_obj._parent_role._role_path = 'foo'
    test_obj._parent_role._collection_paths = ['foo']
    
    # create a basic task with a name
    task_1 = Task()
    task_1._role = 'foo'
    task_1._role

# Generated at 2022-06-11 10:55:35.528008
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import role_loader
    import ansible.constants as C
    import os

    class FakePlay(object):
        def __init__(self):
            self.handlers = []
            self.roles = []

    class FakeIncludeRole(object):
        def __init__(self):
            self.args = {}

# Generated at 2022-06-11 10:55:46.000247
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    def _t(file, name):
        return '%s:%d:%s' % (file, name, name)

    h = Host(name='testhost')
    g = Group(name='testgroup')
    g.add_host(h)
    p = Play()
    p._hosts_cache = [h]
    p._groups = [g]
    l = DataLoader()

    # method load test
    file = _t

# Generated at 2022-06-11 10:55:55.117324
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.playbook
    import ansible.playbook.role.definition

    playbook = ansible.playbook.PlayBook(loader=None, variable_manager=None, options=None)
    data = dict(
        include_role='name',
    )
    block = ansible.playbook.Block()

    role = ansible.playbook.role.definition.RoleDefinition()
    role._role_name = 'test'
    role._role_path = 'path'

    include_role = IncludeRole.load(data, block, role)

    assert not include_role.task_include
    assert include_role.action == 'include_role'
    assert include_role.block is block
    assert include_role._role_name == data.get('include_role')
    assert include_role._role_path == role._role

# Generated at 2022-06-11 10:55:58.369030
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()
    ir.name = 'A'
    ir._role_name = 'B'
    ir._from_files = {'A': 'C'}
    assert ir.get_block_list() == ([], [])


# Generated at 2022-06-11 10:56:10.156118
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Invalid options test
    i_data = {}
    try:
        ir = IncludeRole.load(data=i_data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    except AnsibleParserError as ape:
        assert ape.message == '\'name\' is a required field for include_role.'
    else:
        raise AssertionError('Test failed: expected AnsibleParserError not raised')

    # Invalid apply field test
    i_data = {}
    i_data['name'] = 'test_role'
    i_data['apply'] = 'test'

# Generated at 2022-06-11 10:56:19.189933
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    ####################################################################################################################
    # test setup
    ####################################################################################################################

    class MockRole(object):

        def __init__(self, name, loader, variable_manager=None):
            self._role_name = name
            self._role_params = {'role_name': name}
            self._role_path = '%s/%s' % ('/my/role/path', name)
            self._loader = loader
            self._variable_manager = variable_manager

        def get_handler_blocks(self, play=None):
            return []

        def compile(self, play=None, dep_chain=None):
            return [Block(parent=self, play=play)]

        def get_role_params(self):
            return self._role_params

        def get_name(self):
            return self._

# Generated at 2022-06-11 10:56:22.260150
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block_list = ir.get_block_list(play=myplay, variable_manager=vm, loader=loader)
    print("block.get_block_list: %s" % str(block_list))


# Generated at 2022-06-11 10:56:32.465948
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Generate dict data
    data = dict()
    data['action'] = 'include_role'
    data['name'] = 'common'
    data['apply'] = dict()
    data['allow_duplicates'] = True
    data['public'] = False
    data['rolespec_validate'] = True
    data['tasks_from'] = 'tasks.yml'
    data['vars_from'] = 'vars.yml'
    data['defaults_from'] = 'defaults.yml'
    data['handlers_from'] = 'handlers.yml'

    # Show data after construction
    display.display("data = %s" % (data))

    ir = IncludeRole.load(data)
    display.display("ir = %s" % (ir))

    # Test get_block

# Generated at 2022-06-11 10:56:42.430693
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import os
    import json
    import tempfile
    import shutil

    my_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(my_dir)
    data = {
        'block': None,
        'hosts': 'all',
        'name': 'Test Role',
        'roles': {},
        'tasks': []
    }
    role_include = {
        'block': None,
        'hosts': 'all',
        'name': 'do_something',
        'role': 'foobar'
    }
    play_context = Play

# Generated at 2022-06-11 10:57:54.657261
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude

    play_context = PlayContext()
    play = Play().load(dict(
        name = 'foobar',
        hosts = 'all',
        gather_facts = 'no',
        roles = [ include_role_task ]
    ), variable_manager=None, loader=None)

    ir = IncludeRole(block=None, role=None, task_include=include_role_task).load(include_role_task, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:58:01.115831
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    include_role:
      name: foo
      # apply:
      #   tags: foo
    '''
    data = dict(
        _raw_params='name=foo',
        role='foo',
        tags=[]
    )
    obj = IncludeRole.load(data, block=Block(), role=None)
    assert obj._role_name == 'foo'
    assert obj._role_path is None
    assert not obj._from_files
    assert obj._parent_role is None


# Generated at 2022-06-11 10:58:01.706756
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert True

# Generated at 2022-06-11 10:58:11.307603
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play as Play
    import ansible.playbook.role.meta as RoleMetadata
    import ansible.template
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.utils.vars as ans_vars
    import ansible.parsing.yaml.objects as ans_yaml_objs

    play_context = ansible.playbook.play_context.PlayContext()
    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()

# Generated at 2022-06-11 10:58:20.802759
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create a block object
    block = Block.load(dict(block=dict(), role=dict(name='role_name')))
    # Create an IncludeRole object
    ir = IncludeRole(block)
    # Name of task is 'role'
    assert ir.action == 'role'
    name = ir.get_name()
    # Name is role : role_name
    assert name == "role : role_name"
    # Create another IncludeRole object
    ir2 = IncludeRole(block, name='role_name')
    # Name of task is 'role_name'
    assert ir2.action == 'role_name'
    name2 = ir2.get_name()
    # Name is role_name
    assert name2 == "role_name"


# Generated at 2022-06-11 10:58:21.447295
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:58:31.531239
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.role import ROLE_CACHE
    from ansible.module_utils.common.collections import ImmutableDict


    class FakeVarsManager:
        def get_vars(self, play, task):
            return ImmutableDict(self.vars)

    C._ACTION_INCLUDE_ROLE = {}

    # Creation of a fake Role object
    fake_role = Role()
    fake_role.name = 'test_role'
    fake_role._role_path = '/tmp/test_role'

    # Add role object to the role cache
    ROLE_CACHE['test_role'] = fake_role

    # Creation of a fake block object
    block = Block()

    # Creation of a fake variable manager
    var_manager = FakeVarsManager()

    # Creation

# Generated at 2022-06-11 10:58:41.443934
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    display.verbosity = 3
    log_capture_string = ""
    display.verbose = lambda x: log_capture_string.__add__(x)

    loader = DictDataLoader(dict())

    # Make a mock PlayContext
    play_context = PlayContext()
    play_context._play = Mock()
    play_context._play.handlers = []
    play_context._play.roles = []

    # Make a mock VariableManager
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()

    # make an empty role

# Generated at 2022-06-11 10:58:47.550916
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test loading an action with a valid number of args
    # single arg
    ir_test = IncludeRole.load(
        dict(
             include='/path/to/role1/tasks/main.yml',
        ),
    )
    assert ir_test.include == '/path/to/role1/tasks/main.yml'
    assert ir_test.args == dict()
    assert not ir_test.statically_loaded

    # list of args
    ir_test = IncludeRole.load(
        dict(
             include=['/path/to/role2/tasks/main.yml', '/path/to/role2/tasks/other.yml'],
        ),
    )

# Generated at 2022-06-11 10:58:56.492756
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 3

    def get_tasks(role_name):
        ds = dict(
            name=role_name,
            tasks=[
                dict(action=dict(module='debug', args=dict(msg="test 1"))),
                dict(action=dict(module='debug', args=dict(msg="test 2"))),
            ]
        )
        loader = DataLoader()
        role = Role.load(ds, play=play)
        play.roles.append(role)

        ir = IncludeRole(role=role)
        ir.vars = dict()
        ir.args = dict(name=role.get_name())
        ir._role_name = role.get_name()