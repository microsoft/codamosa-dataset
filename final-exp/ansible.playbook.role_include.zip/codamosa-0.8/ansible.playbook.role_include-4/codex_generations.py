

# Generated at 2022-06-11 10:49:48.286583
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert False, "This method needs a unit test"


# Generated at 2022-06-11 10:49:58.940561
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["[i1]\nlocalhost\n", "[i2]\nlocalhost\n"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:50:09.775097
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    loader = None
    variable_manager = None
    role = Role()
    block = Block()
    task_include = None

    # Test success
    data = dict(
        name="role_name"
    )
    ir = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert ir._parent_role == role
    assert ir._role_name == "role_name"
    assert ir._from_files == {}
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True

    # Test 'role' alias to 'name'


# Generated at 2022-06-11 10:50:18.007679
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # setup
    data = dict(
        name="role1",
        apply=dict(
            rules=dict(
                exclusions=7
            )
        )
    )
    variable_manager = None
    loader = None
    block = Block()
    task_include = None
    # test
    ir = IncludeRole.load(data, block=block, variable_manager=variable_manager, loader=loader, task_include=task_include)
    # asserts
    assert str(ir) == "role1 : role1"
    assert ir.get_allow_duplicates() == True
    assert ir.get_rolespec_validate() == True
    assert ir.get_public() == False
    assert ir._role_name == "role1"
    assert ir._from_files == {}
    assert ir._parent_role

# Generated at 2022-06-11 10:50:29.014705
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    action_loader.add_directory('./test/unit/lib/ansible/modules/action')

# Generated at 2022-06-11 10:50:31.995045
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    i = dict(
        name='role_name',
        tasks_from='file_name_1',
    )

    print(IncludeRole.load(i))

# Generated at 2022-06-11 10:50:40.668923
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    myplay = Play.load({
        'name': 'testincluderole',
        'hosts': 'all',
        'roles': [
            {'name': 'testincluderole',
            'tasks': [
                {'include_role': {
                    'name': 'testrole'
                }}
            ]}
        ]
    }, loader=None)
    assert len(myplay._entries) == 1
    assert type(myplay._entries[0]) == Role, 'Role not created'
    assert type(myplay._entries[0].get_tasks()[0]) == IncludeRole, 'IncludeRole not created'

    myplay_error

# Generated at 2022-06-11 10:50:52.268902
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display = Display()
    display.verbosity = 4

    load = IncludeRole.load
    load_data = IncludeRole.load_data

    # avoid actually loading these
    IncludeRole.load = load_data

    # playbook
    block = Block()
    block.block = [TaskInclude]

# Generated at 2022-06-11 10:51:02.509606
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Setup
    action = "random"
    block = [ { 'args': [] } ]
    data = {
        'action': 'random',
        'block': block,
        'args': { 'role': 'somerole' }
    }

    # Setup - Mocks
    class MockIncludeRole(object):
        def __init__(self, block, role, task_include):
            self.action = action
            self.args = { 'role': 'somerole' }
            self.block = block

    # Unit under test
    actual = IncludeRole.load(data, block=block, role=MockIncludeRole)

    # Assertions
    assert actual.args['role'] == 'somerole'
    assert actual.action == action
    assert actual.block == block


# Generated at 2022-06-11 10:51:14.289969
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext

    # load an action plugin to test
    action_plugins = action_loader.all(class_only=True)['include_role']
    action_plugin = action_plugins[0]
    dynamic_action = 'include_role'
    action_plugin_name = action_plugin.__class__.__name__

    # create a task to test
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play_context = PlayContext()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-11 10:51:30.014529
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    class FakeVariableManager():
        def get_vars(self, play=None, task=None):
            return dict()

    class FakeTask():
        def __init__(self, action=None):
            self.action = action

        def set_loader(self, loader):
            self.loader = loader

        def copy(self, exclude_parent=False, exclude_tasks=False):
            return FakeTask(self.action)

        def update_block_vars(self, block):
            pass

    class FakeLoader():
        pass

    class FakeParentRole():
        def __init__(self):
            self._parents = []
            self._metadata = FakeParentRoleMetadata()

        def _get_parent_attr(self, attr):
            return None

        def get_role_params(self):
            return dict()

# Generated at 2022-06-11 10:51:31.126145
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass



# Generated at 2022-06-11 10:51:43.802469
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = Role()
    block = Block()
    obj = IncludeRole(block, role)
    obj._role_name = 'role_name'
    obj.action = 'action_name'
    obj.name = None
    name = obj.get_name()
    assert name == "action_name : role_name"
    obj.name = 'task_name'
    name = obj.get_name()
    assert name == "task_name"
    block = Block()
    obj = IncludeRole(block, None)
    obj._role_name = 'role_name'
    obj.action = 'action_name'
    obj.name = None
    name = obj.get_name()
    assert name == "action_name : role_name"
    obj.name = 'task_name'
    name = obj.get_

# Generated at 2022-06-11 10:51:53.092321
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import (
        become_loader,
        connection_loader,
        shell_loader,
    )

    display.verbosity = 3

    shell_loader.add_directory('./lib')
    connection_loader.add_directory('./lib')
    become_loader.add_directory('./lib')

    play_context = PlayContext()

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='./tests/unittests/support/sample_inventory.yaml')

    ir = IncludeRole()
    ir.args = {
        'name': './tests/unittests/support/test_role'
    }


# Generated at 2022-06-11 10:51:58.324515
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar

    class DummyRole(RoleInclude):

        def __init__(self):
            pass

        def get_vars(self):
            return ['vars']

        def load(self):
            return ['loads']

    class DummyRole2(RoleInclude):
        def __init__(self):
            pass

        def compile(self):
            return ['Handlers'], ['Handler_Blocks']

    def test_var_manager(play, task):
        return {}


# Generated at 2022-06-11 10:52:09.876405
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.task import Task

    # Check if role_path is updated with role loaded
    block = Block()
    role = Role()
    task_include = Task()

    block._role = role
    task_include._role = role

    data_role_updated = dict(
        name='test_role',
        role='test_name',
    )

    ir = IncludeRole(block, role, task_include=task_include).load_data(data_role_updated)
    assert ir._role_path is None

    ir.get_block_list()
    assert ir._role_path is not None

    # Check if role_name is updated with role loaded
    block = Block()
    role = Role()
    task_include = Task()

    block._role = role
    task_include._role = role



# Generated at 2022-06-11 10:52:18.657969
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role = Role()
    role._metadata = {'name': 'role_name'}
    role._role_path = '/role_path'
    role.name = 'role_name'
    role._parents = []
    ir = IncludeRole(block, role)
    assert ir.get_include_params() == {'ansible_current_role_names': ['role_name']}

    block = Block()
    role = Role()
    role._metadata = {'name': 'role_name'}
    role._role_path = '/role_path'
    role.name = 'role_name'
    role._parents = []
    role_parent = Role()
    role_parent._metadata = {'name': 'role_parent'}
    role_parent.name = 'role_parent'
    role

# Generated at 2022-06-11 10:52:31.557673
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import RESERVED_VARS

    loader = "AnsibleLoader"
    variable_manager = VariableManager()

    hostvars = dict([(y, AnsibleUnicode(u'hostvars_{}'.format(y))) for y in RESERVED_VARS])

    variables = dict(
        role_params=dict([(y, AnsibleUnicode(u'role_params_{}'.format(y))) for y in RESERVED_VARS])
    )
    variable_manager._vars = variables

    context

# Generated at 2022-06-11 10:52:40.649720
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # import needed to run unit test
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    # define a PlayContext to initialize in unit test
    play_context = PlayContext()

    # define a base Play to initialize in unit test
    play = Play().load({
        'name'      : "Ansible Play",
        'hosts'     : "all",
        'gather_facts' : "no",
    }, variable_manager=VariableManager(), loader=None)

    # define a base Block to initialize in unit test
    block = Block()

    # define the variables that will be initialized in the unit test
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = None


# Generated at 2022-06-11 10:52:51.130689
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import tempfile
    import shutil

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import load_extra_vars
    from ansible.executor.playbook_executor import PlaybookExecutor

    # setup a temporary directory to use as a playbook dir
    pb_dir = tempfile.mkdtemp()
    assert pb_dir is not None

    # create a mock playbook file in the temporary dir
    playbook_path = pb_

# Generated at 2022-06-11 10:53:07.273042
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block()
    role = Role()
    task_include = 'null'
    data = dict(name='my_role')

    IncludeRole.load(data, block, role, task_include)

    include_role = IncludeRole(block, role, task_include)

    include_role.vars = dict(role_name='my_role')

    include_role.loader = DataLoader()
    include_role.variable_manager = VariableManager()

    assert include_role.get_block_list()

# Generated at 2022-06-11 10:53:11.869930
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    include_role is a task, thus we use TaskInclude's attributes
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    # Setup block
    block = Block()

    # Setup play for injecting into attribute _play of block
    play_ds =  dict(
            name = "Ansible Play TEST",
            hosts = 'localhost',
            gather_facts = 'no',
            roles = [],
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{playbook_dir}}')))
            ]
        )

# Generated at 2022-06-11 10:53:16.268813
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ''' unit test for method load of class IncludeRole '''

    ir = IncludeRole()
    ir_loaded = ir.load(dict(include_role=dict(name="test_role")), variable_manager={}, loader={})
    assert isinstance(ir_loaded, IncludeRole)
    assert ir_loaded._role_name == "test_role"

    ir_loaded = ir.load(dict(include=dict(name="test_role")), variable_manager={}, loader={})
    assert isinstance(ir_loaded, IncludeRole)
    assert ir_loaded._role_name == "test_role"


# Generated at 2022-06-11 10:53:26.347066
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class MockTemplar:
        def template(self, d):
            return d

    class MockBlock:
        def __init__(self):
            self.vars = dict()
            self.collections = dict()

    class MockVariableManager:
        def get_vars(self):
            return dict()

    class MockPlay:
        def __init__(self):
            self.handlers = list()
            self.roles = list()

    class MockRole:
        def __init__(self):
            self.name = "test_role"
            self._metadata = MockBlock()
            self._parents = list()
            for i in range(3):
                self._parents.insert(i, MockBlock())
            self.get_handler_blocks = lambda play: list()

# Generated at 2022-06-11 10:53:34.820108
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-11 10:53:45.823042
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host, Group

    def test_includes(data, expected_role_name, expected_from_files, expected_statically_loaded, expected_apply_attrs):
        variable_manager = VariableManager()
        variable_manager.extra_vars = {}
        loader = None
        new_play = Play().load({'name': 'ir_test',
                                'hosts': 'all',
                                'gather_facts': 'no',
                                'roles': []},
                               variable_manager=variable_manager, loader=loader)
        ri = IncludeRole.load(data, play=new_play, variable_manager=variable_manager, loader=loader)
        assert ri._role_name

# Generated at 2022-06-11 10:53:55.383992
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins import module_loader
    import ansible.parsing.dataloader

    loader = ansible.parsing.dataloader.DataLoader()
    test_data = {'block': None, 'name': 'foo', 'role': 'foobar', 'apply': {'tags': ['hello', 'world']}, 'allow_duplicates': True, 'public': True}
    ir = IncludeRole.load(data=test_data, block=None, role=None, task_include=None, variable_manager=None, loader=loader)

    assert ir.name == 'foo'
    assert ir.role == 'foobar'
    assert ir.allow_duplicates == True
    assert ir.public == True

# Generated at 2022-06-11 10:53:58.792239
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    ir = IncludeRole(block=block, role=role)
    # defined
    ir.name = 'foobar'
    assert ir.get_name() == 'foobar'

    # not defined
    ir.name = None
    ir.role = 'foobar'
    assert ir.get_name() == 'include_role : foobar'

# Generated at 2022-06-11 10:54:10.905830
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # init data
    data = dict(
        name="foo",
        tasks_from="./main.yml",
        handlers_from="../handlers.yml",
        vars_from="../vars.yml",
        defaults_from="../defaults.yml",
        apply="dict(always_run=True)",
        allow_duplicates=False,
        public=True,
        rolespec_validate=False
    )

    # init block, role, task_include
    block = Block(None, None)
    role = Role()
    task_include = TaskInclude()

    # init variable_manager
    variable_manager = "variable_manager"
    loader = "loader"

    # set _action

# Generated at 2022-06-11 10:54:20.845897
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Run unit tests for method get_block_list of class IncludeRole
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_text
    import ansible.constants as C
    import os
    import tempfile


# Generated at 2022-06-11 10:54:46.498741
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    ir = IncludeRole()


# Generated at 2022-06-11 10:54:47.141408
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole._get_name() == 'ROLE'

# Generated at 2022-06-11 10:54:56.712078
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    b = Block()
    b.args = {'some': 'value'}
    b.vars = {}
    t = Task()
    t.action = 'include_role'
    p = Play()
    p.become = True
    p.become_user = 'root'
    p.vars = {}
    pm = PlayContext(play=p)
    t._play_context = pm
    t._parent = b
    assert isinstance(t, Block)
    assert isinstance(t, Task)
    assert isinstance(t, IncludeRole)
    assert isinstance(t._parent, Block)

# Generated at 2022-06-11 10:55:06.307424
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    data = {'name': 'world', 'tasks_from': './world.yml', 'defaults_from': '/world_defaults', 'handlers_from': '../handlers.yml', 'apply': {'a': 1, 'b': 2}, 'public': False, 'allow_duplicates': True}

    actual = IncludeRole.load(data)

    assert actual._role_name == 'world'
    assert actual._from_files == {'tasks': 'world.yml', 'defaults': 'world_defaults', 'handlers': 'handlers.yml'}
    assert actual.apply == {'a': 1, 'b': 2}
    assert actual.public == False
    assert actual.allow_duplicates == True


# Generated at 2022-06-11 10:55:08.992459
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    r = RoleDefinition()
    t = Task()
    b = Block()
    b._parent = r
    t._parent = b
    ir = IncludeRole(block=b, role=r, task_include=t)
    ir._role_path = '1/2/3'
    assert ir._role_path == '1/2/3'
    ir.get_include_params()

# Generated at 2022-06-11 10:55:18.505759
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import io

    loader = DataLoader()
    my_loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    play_context = PlayContext(become_method='sudo', become_user='root', become_flags=['-H'])

    file = io.StringIO("""
- include_role:
    name: apache
    apply:
      port: "{{ http_port }}"
""")
    file.name = '/tmp/testfile'

   

# Generated at 2022-06-11 10:55:28.262350
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import role_loader

    ir = IncludeRole()

    # No name or role provided
    bad_data = dict(include="test")
    try:
        ir.load(bad_data)
        assert False, "Should not accept no name or role arg"
    except AnsibleParserError:
        pass

    # No name provided, but role provided
    bad_data = dict(role="test", unknown="test")

# Generated at 2022-06-11 10:55:35.807410
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import sys
    import os
    import yaml

    this_path, this_file = os.path.split(__file__)
    data = yaml.load(open(this_path + '/role_include_test.yml'))
    data = data['tasks'][0].get('include_role', {})

    test_object = IncludeRole.load(data)
    assert isinstance(test_object, IncludeRole)
    assert isinstance(test_object._from_files, dict)
    assert len(test_object.args) == 2
    assert test_object.name == 'include_role_test_name'
    assert test_object.action == 'include_role'
    assert test_object.allow_duplicates is True
    assert test_object.public is False
    assert test_object._role_name

# Generated at 2022-06-11 10:55:36.387479
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:55:37.850884
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: write unit tests for IncludeRole._load
    pass

# Generated at 2022-06-11 10:56:18.246487
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Mock Block for test
    class MockBlock():
        def __init__(self, name, children=[]):
            self._uuid = 'uuid'
            self.block = Block(name, children=children)
            self.children = children
            self.dep_chain = []
            self._parents = []
            self._dep_parents = []
            self._final_when = []
            self._paused_when = []
            self._always_precede = []
            self._always_follow = []
            self.action = 'action'
            self.name = 'name'
            self.tags = []
            self.when = []
            self.register = []
            self.loop = []
            self.vars_prompt = []
            self.vars_files = []
            self.notify = []


# Generated at 2022-06-11 10:56:27.746741
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # initialize plugin loader
    add_all_plugin_dirs()

    # create dummy include
    test_ir = IncludeRole()
    test_ir.statically_loaded = False
    test_ir.args['name'] = AnsibleVault

# Generated at 2022-06-11 10:56:38.531503
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    display.verbosity = 4

    #### 1
    ir = IncludeRole()
    ir.args = {'name': 'role_name'}
    assert (ir.get_name() == 'role_name')
    #### 2
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = {'role': 'role_name'}
    assert (ir.get_name() == 'include_role : role_name')
    #### 3
    ir = IncludeRole()
    ir.name = 'task_name'
    ir._role_name = 'role_name'
    assert (ir.get_name() == 'task_name')
    #### 4
    ir = IncludeRole()
    ir.name = 'task_name'
    ir.action = 'include_role'
    ir

# Generated at 2022-06-11 10:56:47.656420
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    host_vars = {'role_name':'role_name',
                 'role_path':'role_path',
                 'ansible_parent_role_names':[],
                 'ansible_parent_role_paths':[]}

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating.vars_plugins.yaml import VarsModule

    data_loader = DataLoader()
    #data_loader.set_vault_secrets(dict(vault_list=[]))

    play_context = PlayContext()


# Generated at 2022-06-11 10:56:54.426262
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    with open('/etc/ansible/roles/test_role/meta/main.yml') as f:
        meta_data = f.read()
    with open('/etc/ansible/roles/test_role/tasks/main.yml') as f:
        tasks = f.read()
    meta_data = yaml.load(meta_data)
    tasks = yaml.load(tasks)
    ir = IncludeRole.load(meta_data)
    #ir.get_block_list()
    return

# Generated at 2022-06-11 10:57:03.983568
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    #        include_role:
    #          name: role_name
    #          tasks_from: role_name/tasks/main.yml
    #          vars_from: role_name/vars/main.yml

    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-11 10:57:13.712514
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os.path

    C.DEFAULT_ROLES_PATH = '../test/'
    t = IncludeRole(dict(name="hello_world"))
    t._role_name = "hello_world"

    (blocks, handlers) = t.get_block_list()

    assert len(blocks) == 1
    assert len(blocks[0]._entries) == 3
    assert blocks[0]._entries[1].action == "fail"
    assert blocks[0]._entries[1]._attributes.args['msg'] == "Doing fail on purpose"

    assert len(handlers) == 1
    assert len(handlers[0]._entries) == 1
    assert handlers[0]._entries[0].action == 'debug'

# Generated at 2022-06-11 10:57:23.882750
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import os.path
    import sys

    # copy test root relative to current directory
    test_dir = os.path.dirname(__file__)
    test_dir = os.path.relpath(test_dir)
    root_dir = os.path.join(test_dir,'../..')
    root_dir = os.path.abspath(root_dir)
    ansible_playbook_root = os.path.join(root_dir, 'lib/ansible/playbook')
    tmp_dir = os.path.join(test_dir, '..', 'temp')

    # copy test root to temp
    print("Copying '%s' to '%s'" % (root_dir, tmp_dir))
    import shutil
    shutil.copytree(root_dir, tmp_dir)

# Generated at 2022-06-11 10:57:25.470615
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole().get_name() == 'tasks: <None>'

# Generated at 2022-06-11 10:57:34.320022
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data_str = '''\
- include_role:
    name: ansible-testing.python_3_8
    apply:
        tags:
            - pytest
        ignore_errors: yes
        when: ansible_python_version == "3.8"
    vars:
        python_virtualenv_dir: '{{project_dir}}/venv'
    vars_files:
        - '{{project_dir}}/group_vars/all'
    tags:
        - python
    allow_duplicates: no
    rolespec_validate: no
- include_role:
    name: ansible-testing.ansible
    public: yes
    vars_files:
        - '{{project_dir}}/group_vars/all'
'''

# Generated at 2022-06-11 10:58:41.104415
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block(play=None)
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    variable_manager = None
    loader = None
    blocks = ir.get_block_list(play=None, variable_manager=variable_manager, loader=loader)
    assert(blocks is not None)

# Generated at 2022-06-11 10:58:43.002102
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    block_list = IncludeRole.load({'name': 'Test'}).get_block_list()
    assert block_list is None

# Generated at 2022-06-11 10:58:51.311770
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.task as task
    import ansible.playbook.task_include as task_include
    import ansible.playbook.block as block
    import ansible.playbook.play as play

    # config
    block_name = "name"
    role_name = "name"
    role_path = "path"

    # create parent block
    b = block.Block(block_name, [], [])
    b._role = role_name

    # create parent play
    p = play.Play()

    # prepare data for constructor
    data = {}
    data['include'] = role_path
    data['args'] = {}
    data['action'] = "include_role"
    data['_role_path'] = role_path
    data['block'] = b

# Generated at 2022-06-11 10:59:00.889444
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """Load an IncludeRole with the specified args"""

# Generated at 2022-06-11 10:59:10.365331
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # '- include_role: name="my_role"'
    args = ["name=my_role"]
    data = "include_role:" + "".join(args)
    t = IncludeRole.load(data)
    assert t.get_name() == "include_role : my_role"
    assert t.args == {"name": "my_role"}

    # '- include_role: role="my_role"'
    args = ["role=my_role"]
    data = "include_role:" + "".join(args)
    t = IncludeRole.load(data)
    assert t.get_name() == "include_role : my_role"

# Generated at 2022-06-11 10:59:19.205401
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    data = dict(
        role='role1',
        tags=['a', 'b', 'c'],
        any_errors_fatal=True
    )
    block=Block()
    inventory=InventoryManager(C.DEFAULT_HOST_LIST)
    variable_manager=VariableManager(inventory)
    play_context=PlayContext()
    ir = IncludeRole.load(data, block=block, variable_manager=variable_manager, loader=None)
    assert ir._role_name == 'role1'

# Generated at 2022-06-11 10:59:28.218255
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class MockRole(Role):
        def __init__(self, *args, **kwargs):
            pass

    role = MockRole()
    include_role = IncludeRole()
    assert include_role.get_name() == 'include_role : None'
    include_role = IncludeRole(role=role)
    assert include_role.get_name() == 'include_role : None'

    def test_get_role_params():
        assert include_role.get_include_params() == {'ansible_role_name': 'None', 'ansible_role_path': None}

    def test_get_block_list():
        class MockPlaybook:
            pass

        class MockBlock:
            def __init__(self):
                self._parent = None


# Generated at 2022-06-11 10:59:38.569765
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test with the correct data with the correct task_include
    block = Block()
    role = Role()
    task_include = [
        {
            "name": "test",
            "role": "test",
            "tasks_from": "/etc/ansible/roles/test/tasks/main.yml",
            "vars_from": "/etc/ansible/roles/test/vars/main.yml",
            "defaults_from": "/etc/ansible/roles/test/defaults/main.yml",
            "handlers_from": "/etc/ansible/roles/test/handlers/main.yml"
        }
    ]
    variable_manager = None
    loader = None