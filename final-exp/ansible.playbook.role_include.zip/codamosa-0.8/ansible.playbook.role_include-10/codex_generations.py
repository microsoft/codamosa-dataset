

# Generated at 2022-06-11 10:49:48.678341
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # The test fails if IncludeRole.get_block_list throw an exception
    pass

# Generated at 2022-06-11 10:49:59.235826
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import IncludeRole
    from ansible.playbook.persistent_dict import PersistentDict
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

# Generated at 2022-06-11 10:50:09.996783
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print("\n************************ test_IncludeRole_get_block_list **************************")

    from ansible.playbook.play import Play
    p = Play().load({
        'name': 'test_play',
        'hosts': 'localhost',
        'roles': []
    }, variable_manager=None, loader=None)

    ir = IncludeRole.load(data={'name': 'test_role'})
    ir._parent = p
    ir._parent_role = Role().load({'name': 'test_role1'}, variable_manager=None, loader=None)
    ir._parent_role._role_path = 'roles/test_role1/'
    ir._role_name = 'test_role_name'

    variable_manager=None
    loader=None
    result = ir.get_block

# Generated at 2022-06-11 10:50:18.093693
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:50:29.013707
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    class MockBlock(Block):
        pass

    class MockDataLoader(DataLoader):
        pass

    class MockIncludeRole(IncludeRole):
        def __init__(self):
            super(MockIncludeRole, self).__init__(block=MockBlock())

    def test():

        loader = MockDataLoader()
        variable_manager = None

        myplay = PlayContext()
        myplay.ROLE_CACHE = {}  # force start with clean cache

        # test that we get a block list
        ir = MockIncludeRole()
        ir._role_name = 'test1'

# Generated at 2022-06-11 10:50:39.218330
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.role
    class FakeParentBlock:
        def __init__(self):
            self.role = FakeParentRole()
    class FakeParentRole:
        def __init__(self):
            self._parents = []
            self._metadata = ansible.playbook.role.RoleMetadata()
            self._metadata.collections = []
        def get_name(self):
            return "TestParent"

    class FakeBlock(Block):
        def __init__(self):
            super(FakeBlock, self).__init__()
            self.role = FakeRole()
    class FakeRole:
        def __init__(self):
            self._metadata = ansible.playbook.role.RoleMetadata()
            self._metadata.collections = []


# Generated at 2022-06-11 10:50:51.103472
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # include_role can use name or role, but not both
    data = dict(role=4, name='foo')
    ir = IncludeRole(block=dict(), role=None, task_include=None).load_data(data, variable_manager=None, loader=None)
    assert ir._role_name == 4
    assert ir._role_path == None

    data = dict(role='foo', name='bar')
    ir = IncludeRole(block=dict(), role=None, task_include=None).load_data(data, variable_manager=None, loader=None)
    assert ir._role_name == 'bar'
    assert ir._role_path == None

    # include_role cannot combine options

# Generated at 2022-06-11 10:50:54.474941
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir._role_name = 'test_role'
    assert ir.get_name() == "include_role : test_role"

# Generated at 2022-06-11 10:50:57.613109
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Load from dictionary
    from_dict = IncludeRole.load(data={'name': 'role1'})
    assert from_dict and from_dict._role_name == 'role1'


# Generated at 2022-06-11 10:50:58.731633
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # TODO / FIXME
    pass

# Generated at 2022-06-11 10:51:18.563897
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create the loader object
    loader = DataLoader()

    # Create the inventory object
    inventory = InventoryManager(loader=loader, sources=[])

    # Create the variable manager object
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create the play object
    play = Play().load({
        'hosts': 'all',
        'tasks': [
            {
                'include_role': {'name': 'foo'}
            }
        ]
    }, variable_manager=variable_manager, loader=loader)

    # Get the first task in play
    task = play.get

# Generated at 2022-06-11 10:51:26.628020
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager

    # Creating fake role and play
    role = Role()
    role.name = 'fake_role'
    role.fake_path = 'fake_role_path'

    play = Play()
    play.name = 'fake_play'

    # Creating fake include_role with fake role
    include_role = IncludeRole()
    include_role.action = 'fake_action'
    include_role._parent_role = role
    include_role._role_name = 'fake_role_name'
    include_role._role_path = 'fake_role_path'

    # Invoking get_block_list method
    vars = VariableManager()
    blocks, handlers = include_role.get

# Generated at 2022-06-11 10:51:38.698570
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
  role_name = 'foo'
  role_path = '/path/to/foo'
  ir = IncludeRole()
  ir._role_name = role_name
  ir._role_path = role_path
  ir._parent_role = type('', (), {
    '_role_path': role_path,
    'get_role_params': lambda self: { 'a_role_param': 1 },
    'get_name': lambda self: role_name
  })()

  assert ir.get_include_params() == {
    'a_role_param': 1,
    'ansible_parent_role_names': [role_name],
    'ansible_parent_role_paths': [role_path]
  }


# Generated at 2022-06-11 10:51:40.000396
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-11 10:51:50.799290
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: make this a real unit test, not a functional test

    display.verbosity = 3

    curr_dir = os.path.dirname(__file__)

    datadir = os.path.join(curr_dir, 'include_role_test_data')

    test1 = os.path.join(datadir, 'test1.yml')
    data1 = open(test1).read()

    pb = Playbook.load(data1, variable_manager=variable_manager, loader=loader)

    hosts = pb.get_hosts()
    play = pb.get_play(hosts[0])

    ansible_vars = play._variable_manager.get_vars(loader=loader, play=play)
    play._variable_manager.set_inventory(inventory)
    play

# Generated at 2022-06-11 10:52:01.871788
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager

    # can't use 'self' in static method
    my_self = IncludeRole()
    my_self.vars = {}
    for r in ['role1', 'role2']:
        my_self.vars[r] = {}
    my_self._role_name = 'default'
    # create a role object
    my_role = Role()

    # create a parent block object
    my_block = Block()

    # create a task object
    my_task = IncludeRole()
    my_task.vars = {}
    my_task.name = 'host2'
    # create a task_include object
    my_task_include = TaskInclude()
    my_task_include.vars = {}
    my_

# Generated at 2022-06-11 10:52:02.494741
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert True

# Generated at 2022-06-11 10:52:14.394741
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    raw_role_data = {
        'name': 'test_role',
        'file': 'test_role/meta/main.yaml',
        '_role_path': '/tmp/test_role_path'
    }
    raw_task_data = {
        'name': 'test_task',
        'file': 'test_role/tasks/main.yaml',
        '_task_include': 'include_role',
    }

    role = Role().load(raw_role_data)
    task = IncludeRole().load(raw_task_data, role=role)


# Generated at 2022-06-11 10:52:26.767031
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # No Name
    data = {"action": "include_role",
            "args": {
                "rolespec_validate": False
            }
           }
    loader = None
    variable_manager = None
    task = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    assert task is not None
    assert task._role_name == data["args"]["rolespec_validate"]

    # Name
    data = {"action": "include_role",
            "args": {
                "name": "Name",
                "rolespec_validate": False
            }
           }
    loader = None
    variable_manager = None

# Generated at 2022-06-11 10:52:37.120207
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.utils.display import Display
    display = Display()
    options = dict(
        tags=dict(
            type='list',
            elements='string',
        ),
        rolespec_validate=dict(
            type='bool',
            default=True,
        ),
        collections=dict(
            type='list',
            elements='string',
        )
    )
    def load_data(self, data, variable_manager=None, loader=None):
        self.args = data['args']
        return self
    IncludeRole.load_data = load_data
    inc_role = IncludeRole()

# Generated at 2022-06-11 10:53:13.241037
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test for the correct function of IncludeRole Class which is under the name of get_block_list.
    # The first input test is default and the second is when there is a new play. The third input is default
    # but with a new variable_manager. The fourth is default with a new loader. The fifth is with new play,
    # variable_manager and loader.
    # if the returns list of blocks and handlers are the same as they were expected, it is successful.
    # the first test is successful.
    test1 = IncludeRole()
    test1._role_name = "test_role_1"
    test1._parent_role = Role()
    test1._parent_role._role_path = "test_role_path_1"
    test1_result1,test1_result2 = test1.get_block_list()

# Generated at 2022-06-11 10:53:14.191229
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:53:24.285486
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    # Create a block for use in testing
    class TestBlock(Block):

        def __init__(self, role=None, task_include=None, parent_block=None, always_run=False, tags=None):
            super(TestBlock, self).__init__(
                role=role,
                task_include=task_include,
                parent_block=parent_block,
                always_run=always_run,
                tags=tags
            )

        def get_vars(self):
            return dict()

        def filter_tagged_tasks(self, play_context):
            return []

        def filter_ungrouped_tasks(self, play_context):
            return []



# Generated at 2022-06-11 10:53:33.399599
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys
    import os
    sys.path.insert(0, os.path.abspath('../../'))
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-11 10:53:44.113037
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    dummy_loader = DummyLoader()
    dummy_variable_manager = VariableManager()
    dummy_play_context = PlayContext()
    dummy_play = Play().load({'name': 'ansible-role-include-task-plugin'},
        variable_manager=dummy_variable_manager, loader=dummy_loader)

    # Test IncludeRole._load()
    dummy_name = "test-role"
    dummy_block = Block()
    dummy_role = Role()

# Generated at 2022-06-11 10:53:51.277368
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    # Setup arguments to call the load method of class IncludeRole
    test_dict = {
        "apply": {},
        "role": "test_role",
    }
    block = Block()
    role = Role()

    # Call the load method of class IncludeRole
    result = IncludeRole.load(data=test_dict, block=block, role=role)
    # Check the result of the load method of class IncludeRole
    result.get_block_list()

# Generated at 2022-06-11 10:53:59.260787
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    test_IncludeRole_get_block_list: Tests behavior of IncludeRole.get_block_list
    '''
    import ansible.playbook
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.utils.shlex

    class MockParentRole(ansible.playbook.role.Role):
        def get_role_params(self):
            return {
                'ansible_parent_role_paths': [
                    'path1',
                    'path2',
                ],
                'ansible_parent_role_names': [
                    'name1',
                    'name2',
                ],
            }

    class MockTaskData(object):
        def __init__(self):
            self.vars = {}


# Generated at 2022-06-11 10:54:11.476733
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    play = Play().load({
        u'name': u'foobar',
        u'hosts': u'all',
        u'gather_facts': u'no',
        u'roles': [
            {'name': 'role-included', 'version': 'v0.0.1'},
            {'name': 'role-included', 'version': 'v0.0.2'}
        ]
    }, variable_manager=None, loader=None)

    play_context = PlayContext()

    block = Block()

# Generated at 2022-06-11 10:54:21.181133
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    role1 = "test_role1"
    role2 = "test_role2"
    block1 = Block().load(
        dict(
            tasks=[
                dict(action=dict(module="setup")),
                dict(action=dict(module="assert", args=dict(that=["item.msg == 'Hello Ansible'"])))
            ]
        ),
        task_include=dict(static=True, args=dict(name=role1))
    )
    block2 = Block().load(
        dict(
            tasks=[
                dict(action=dict(module="debug", args=dict(msg="Hello Ansible")))
            ]
        ),
        task_include=dict(static=True, args=dict(name=role2))
    )

# Generated at 2022-06-11 10:54:32.468356
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    from ansible.playbook.tests.unit.test_play import get_play
    from ansible.playbook.tests.unit.test_block import get_block

    p = get_play(None)
    r = Role()
    t = Task()

    ir = IncludeRole(t)

    assert ir.get_name() == 'meta'

    p.load({'name': 'foo'})

    ir.name = 'bar'
    assert ir.get_name() == 'bar'

    r.load({'name': 'baz'})
    ir._parent_role = r
    ir.name = None

# Generated at 2022-06-11 10:55:02.638870
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-11 10:55:12.117676
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, module_loader
    import ansible.constants as C
    import os
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.vault import mock_open_decrypted_file
    from units.compat import unittest

    C.HOST_KEY_CHECKING = False
    C.DEFAULT_DEBUG = True

    # creation of a Play()
    play = Play

# Generated at 2022-06-11 10:55:16.496557
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='foo.yml',
        tasks='main'
    )
    ir = IncludeRole.load(data)
    assert ir.name == data['name']
    assert ir.get_name() == "%s : %s" % (ir.action, data['name'])
    assert ir.tasks == ['main']
    assert ir.task_name == 'main'

    data = dict(
        name='foo.yml',
        public=True
    )
    ir = IncludeRole.load(data)
    assert ir.name == data['name']
    assert ir.get_name() == "%s : %s" % (ir.action, data['name'])
    assert ir._public is True
    assert ir.public is True


# Generated at 2022-06-11 10:55:25.926848
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='test',
        tasks_from='file.yml',
        vars_from='file.yml',
        defaults_from='file.yml',
        handlers_from='file.yml',
        apply={},
        public=True,
        allow_duplicates=False,
        rolespec_validate=False
    )
    ir = IncludeRole()
    ir.load_data(data)
    assert ir.name == 'test'
    assert ir.tasks_from == 'file.yml'
    assert ir.vars_from == 'file.yml'
    assert ir.defaults_from == 'file.yml'
    assert ir.handlers_from == 'file.yml'
    assert ir.public == True

# Generated at 2022-06-11 10:55:34.630674
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import sys
    import os
    import tempfile

    # Missing 'name' or 'role'
    broken_data = dict(
        action="include_role",
        )
    try:
        IncludeRole.load(broken_data, None, None, None)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("IncludeRole.load: invalid data %s" % broken_data)

    good_data = dict(
        action="include_role",
        name="foo",
        )
    IncludeRole.load(good_data, None, None, None)

    # Invalid options
    broken_data = dict(
        action="include_role",
        name="foo",
        barz="boz",
        )

# Generated at 2022-06-11 10:55:39.258916
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = 'some_role'
    assert ir.get_name() == 'include_role : some_role'

    ir = IncludeRole()
    ir._role_name = 'some_role'
    ir.name = 'Test Include'
    assert ir.get_name() == 'Test Include'



# Generated at 2022-06-11 10:55:48.900299
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file('./test/unit/inventory'))
    play_context = PlayContext()

    ir = IncludeRole.load({'action': 'include_role', 'name': 'myrole', 'apply': {'tags': 'tag'}})

    print('______')
    print(ir)
    # ir.get_block_list(variable_manager=variable_manager, loader=loader)
    print('______')

# Generated at 2022-06-11 10:55:56.710397
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import os
    import sys
    import tempfile
    import textwrap

    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a role
    role_name = 'x'
    os.mkdir(os.path.join(tmpdir, 'roles', role_name, 'tasks'))

# Generated at 2022-06-11 10:56:04.844346
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayClass
    play = Play().load({
        "name": "Ansible Play",
        "hosts": "all",
        "roles": [
            "role1",
            "role2",
        ],
    })
    play = PlayClass().load(play, variable_manager=None, loader=None)
    role = Role()
    ir = IncludeRole(play=play, role=role, task_include=None)
    assert ir.get_name() == 'include_role : '

# Generated at 2022-06-11 10:56:15.591524
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Unit test for method get_block_list of class IncludeRole
    '''
    class MyRole():
        def __init__(self):
            self.name = "test"
            self._role_path = "tests/data/roles/test"
            self._parents = []
            self._metadata = {}

        def get_handler_blocks(self, play):
            return []

        def compile(self, play, dep_chain):
            return []

        def get_role_params(self):
            return {'test': 'get_role_params'}

        def get_name(self):
            return self.name

    class MyBlock():
        pass

    class MyPlay():
        def __init__(self):
            self.roles = []
            self.handlers = []


# Generated at 2022-06-11 10:57:26.458968
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import copy
    import os
    import sys
    import unittest
    from mock import MagicMock
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.playbook.task import Task
    from ansible.template import Templar

    class TestIncludeRole(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()

# Generated at 2022-06-11 10:57:35.250206
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.task import Task

    data = {}
    block = None
    role = None
    task_include = Task()
    variable_manager = None
    loader = None

    # Test with bad argument
    data = {'name': 'myrole', 'badarg': 'badargvalue'}
    try:
        ir = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('IncludeRole.load with bad argument did not raise AnsibleParserError')

    # Test with bad from argument
    data = {'name': 'myrole', 'badarg_from': 'badargvalue'}

# Generated at 2022-06-11 10:57:46.641534
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    ROLE_LIB = "/etc/ansible/roles"
    PLAY_CTXT = PlayContext()
    VARS = dict()
    LOADER = "loader"
    BLOCK = "block"
    ROLE = "role"

    # Declaring the following block as a string for testing purposes
    BLOCK_LIST = """- block:
  - name: Include task1
    debug:
      msg: task1
- block:
  - name: Include task2
    debug:
      msg: task2"""

    BLOCK_SPLIT = BLOCK_LIST.split('\n')
    BLOCK_LIST_RESULT = []
    BLOCK_TASK_LIST = []
    BLOCK_TASK_LIST_RESULT = []

    # Pars

# Generated at 2022-06-11 10:57:56.175627
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block1 = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = {}
    loader = {}
    data = {'tasks': [{'include_tasks': 'tasks/passwd.yml'},
                      {'include_tasks': 'tasks/group.yml'}]}
    ir = IncludeRole.load(data, block=block1, role=role, task_include=task_include,
                          variable_manager=variable_manager, loader=loader)
    assert len(ir._from_files) == 0
    assert ir._role_name is None
    assert ir.public is False
    assert ir.rolespec_validate is True


# Generated at 2022-06-11 10:58:06.490815
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import unittest
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class IncludeRoleTester(unittest.TestCase):

        def setUp(self):
            self.role_name = 'test_role'
            self.block = Block()
            self.task = Task()
            self.task._parent = self.block
            self.task.apply_when = [UnsafeProxy(True)]
            self.task.action = 'include_role'


# Generated at 2022-06-11 10:58:07.079400
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:58:09.025281
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = "Test Role"
    assert ir.get_name() == "Test Role"


# Generated at 2022-06-11 10:58:18.740357
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Setup test class
    data = {"role": "../role_dir/role_name"}
    ir = IncludeRole(task_include=IncludeRole())

    # Test function
    result = ir.load(data, loader=None, variable_manager=None)
    assert result._role_name == "../role_dir/role_name"
    assert result._role_path == None
    assert result.statically_loaded == True

    data = {"role": "../role_dir/role_name", "apply": {"vars": {"var1": "value1"}}}
    ir = IncludeRole(task_include=IncludeRole())

    # Test function
    result = ir.load(data, loader=None, variable_manager=None)
    assert result._role_name == "../role_dir/role_name"
    assert result._

# Generated at 2022-06-11 10:58:23.999880
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest

    tk = get_task_manager(args={'action': 'include_role', 'name': 'testing'})
    task = IncludeRole.load(tk.args, block=Block(parent_block=None, role=None, task_include=None), role=None, task_include=None)
    assert task.name == 'testing'
    assert task.vars == {}
    assert task.args == {}

    with pytest.raises(AnsibleParserError) as execinfo:
        tk = get_task_manager(args={'action': 'include_role'})
        task = IncludeRole.load(tk.args, block=Block(parent_block=None, role=None, task_include=None), role=None, task_include=None)

# Generated at 2022-06-11 10:58:28.886764
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task_include = IncludeRole({}, Block(), None)
    task_include.action = 'foo'
    task_include._role_name = 'test_role'

    assert task_include.get_name() == 'foo : test_role'

    task_include.name = 'test_name'
    assert task_include.get_name() == 'test_name'
