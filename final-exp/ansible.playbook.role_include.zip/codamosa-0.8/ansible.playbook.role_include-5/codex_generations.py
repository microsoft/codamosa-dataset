

# Generated at 2022-06-11 10:49:50.231080
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.templating.jinja2.variable import AnsibleVariable

    # Create dummy AnsibleVariable for use in tests
    av = AnsibleVariable()
    av.post_validate({}, None)
    av._templar = Templar(loader=None, variables={})

    # Create dummy Role for use in tests
    r = Role()
    r._role_path = "~/role"
    r.vars = {"a": 1, "b": "two", "c": 3.0}

# Generated at 2022-06-11 10:49:54.823055
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.name = 'foo'
    assert ir.get_name() == "include_role : foo"
    ir.name = None
    ir._role_name = 'foo'
    assert ir.get_name() == "include_role : foo"


# Generated at 2022-06-11 10:49:55.606699
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:50:06.308148
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    action = '- my_action: run_some_role'

    # missing 'name'
    data = {'args': {'foo': 'bar'}}
    display.verbosity = 3
    with raises(AnsibleParserError) as excinfo:
        IncludeRole.load(data, action=action)
    assert "name" in str(excinfo.value)
    display.verbosity = 0

    # missing 'role'
    data = {'args': {'foo': 'bar'}}
    with raises(AnsibleParserError) as excinfo:
        IncludeRole.load(data)
    assert "name" in str(excinfo.value)

    # test option 'public'
    data = {'args': {'name': 'foo', 'public': True}}

# Generated at 2022-06-11 10:50:06.935116
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    pass

# Generated at 2022-06-11 10:50:16.520413
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    my_playbook = {}
    my_loader = {}
    my_var_manager = {}
    my_var_manager['_vars'] = {}

    # Initialize an IncludeRole object
    my_block = Block()
    my_role = Role()
    my_IncludeRole = IncludeRole(block=my_block, role=my_role)
    my_IncludeRole._parent_role = my_role

    # Set the role params of the role in the IncludeRole object
    my_role._role_params = {'foo':'bar'}

    # Test the method get_include_params
    assert my_IncludeRole.get_include_params() == my_role._role_params
    assert my_IncludeRole.get_include_params() == {'foo':'bar'}

# Generated at 2022-06-11 10:50:27.685516
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    dataloader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:50:32.857148
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        action = 'include_role',
        name = 'some_role'
    )
    ir = IncludeRole.load(data, loader=None, variable_manager=None, task_include=None)
    assert ir.action == 'include_role'
    assert ir.name == 'some_role'


# Generated at 2022-06-11 10:50:40.966767
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.module_utils.facts.system.distribution import Distribution

    class PlaySpec:
        def __init__(self, name, roles_path=None, collection_paths=None):
            self.name = name
            self.hosts = 'localhost'
            self.roles_path = roles_path
            self.collection_paths = collection_paths


# Generated at 2022-06-11 10:50:52.678772
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # setup play context
    playbook_path = "/Users/zhang/ansible/examples/ansible-lint/roles/nxos/tasks/network_lint.yml"
    vars = {}
    extra_vars = {}
    inventory = Inventory([])
    play = Play()
    play_context = PlayContext(play=play, extra_vars=extra_vars)

    # setup Include

# Generated at 2022-06-11 10:51:06.226087
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    #Create an object IncludeRole
    template = '''
    - include_role:
        name: test_name
        tasks_from: tasks/main.yml
        vars_from: vars/main.yml
        defaults_from: defaults/main.yml
        handlers_from: handlers/main.yml
        apply:
          tags:
            - test
        public: True
        allow_duplicates: True
        rolespec_validate: True
    '''
    block = Block.load(None, None, None, task_include=None, role=None, role_include=None, task=None, data=template)
    role = Role()
    task_include = TaskInclude()
    obj = IncludeRole(block=block, role=role, task_include=task_include)

    #Check the value

# Generated at 2022-06-11 10:51:17.449253
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """ """
    # Duplicating some code from __init__ to avoid breaking it
    class RO(object):
        def __init__(self):
            self.name = 'RO'
    ro = RO()
    data =  { 'include_role': { 'name' : 'test_name', 'role' : 'test_role' } }
    _task = IncludeRole.load(data, role=ro)
    assert _task.get_name() == 'RO : test_name' 
    data =  { 'include_role': { 'role' : 'test_role' } }
    _task = IncludeRole.load(data, role=ro)
    assert _task.get_name() == 'include_role : test_role' 


# Generated at 2022-06-11 10:51:26.081196
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # prepare
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()

    block = Block(parent_block=None)
    role = Role()
    task_include = None
    data = {'name': 'apache'}
    ir_obj = IncludeRole(block, role, task_include).load_data(data, variable_manager=variable_manager, loader=loader)
    ir_obj.vars = {'name': 'apache'}

    ir_obj._role_name = 'apache'
    ir_obj._role_path = '.'


# Generated at 2022-06-11 10:51:29.372570
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(role='test').get_name() == 'test : None'
    assert IncludeRole(role='test', name='test_name').get_name() == 'test_name : test'

# Generated at 2022-06-11 10:51:39.809396
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Make a copy of the class and create a temporary instance.
    import copy
    import ansible.playbook.task
    TASK_CLASS = copy.deepcopy(ansible.playbook.task.Task)
    t = TASK_CLASS()

    # Create a temporary instance of Role.
    from ansible.playbook.role import Role
    r = Role()

    # Create a temporary instance of IncludeRole and call load.
    from ansible.parsing.mod_args import ModuleArgsParser
    i = IncludeRole(role=r)
    i.load(data=ModuleArgsParser().parse_args(args=""), variable_manager='', loader='')

# Generated at 2022-06-11 10:51:50.681375
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create TaskInclude object
    task_include_obj = TaskInclude()

    # Create parent object
    parent_obj = Block()
    # Create play object
    play_obj = Block()
    # Set Block object in parent object
    parent_obj._parent = play_obj

    # Set Block object in TaskInclude object
    task_include_obj._parent = parent_obj

    # Assigning action to task
    task_include_obj.action = "include_role"

    # Assigning args to task
    task_include_obj.args = dict(name="sudheer_role")

    # Assigning vars to task
    task_include_obj.vars = dict(name="sudheer")

    # Create IncludeRole object
    include_role_obj = IncludeRole()
    # Assigning Block object in Include

# Generated at 2022-06-11 10:51:51.439741
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:52:02.442118
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    module_utils_path = 'ansible.module_utils.basic'
    data = {'action': 'include_role',
            'args': {
                'name': 'some_role',
                'apply': {'foo':'bar'}
            }}

    include_role = IncludeRole.load(data)
    assert include_role is not None
    assert include_role.action == 'include_role'
    assert include_role.module_utils == module_utils_path
    assert include_role.allow_duplicates is True
    assert include_role.public is False
    assert include_role.rolespec_validate is True
    assert include_role._from_files == {}
    assert include_role._parent_role is None
    assert include_role._role_name == 'some_role'


# Generated at 2022-06-11 10:52:14.397922
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    yaml_data = """
    - include_role:
        name: common
    """
    ir = IncludeRole()
    result = ir.load(data=yaml_data, variable_manager=None, loader=None)

    assert result is not None
    assert result.args is not None
    assert len(result.args.keys()) > 0
    assert result.action == 'include_role'
    assert result.name == 'include_role common'
    assert result._parent is None
    assert result._role_name == 'common'
    assert result._role_path is None
    assert result._from_files == {}
    assert result._parent_role is None
    assert result._

# Generated at 2022-06-11 10:52:20.599085
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print("\nTesting get_name method of class IncludeRole\n")
    task = IncludeRole()
    task._role_name = "ansible-role-test"
    print("Testing value ansible-role-test")
    print("Result: " + str(task.get_name()))
    print("Expected result: ansible-role-test : ansible-role-test")


# Generated at 2022-06-11 10:52:37.376337
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    class TestIncludeRole(IncludeRole):
        def __init__(self, data, block=None, role=None, task_include=None):
            self.data = data
            super(TestIncludeRole, self).__init__(block=block, role=role, task_include=task_include)

        def load_data(self, data, variable_manager=None, loader=None):
            pass

    class TestBlock(Block):
        def __init__(self):
            super(TestBlock, self).__init__(
                role=TestRole(
                    file_name='test_file',
                    parent_role=None
                ),
                task_include=TestIncludeRole(data=dict(name='test_role', apply=dict(serial=1)))
            )


# Generated at 2022-06-11 10:52:38.076426
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # TODO
    pass

# Generated at 2022-06-11 10:52:47.401524
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as constants
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play, Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Setup a testing playbook
    pb = Playbook()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(remote_user='root', become=True)

    play = Play

# Generated at 2022-06-11 10:52:58.275310
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Define test function

    def _test_get_block_list(action, args, expected_block_list, expected_handlers):
        assert_msg = 'Unexpected blocks returned'
        loader = DictDataLoader({})
        block = Block(loader=loader)
        role = Role(loader=loader)
        role._role_path = 'the_role_path'
        role._role_name = 'the_role_name'
        role._metadata.allow_duplicates = True
        role.set_loader(loader)
        include_role = IncludeRole(block, role)
        include_role.statically_loaded = True
        include_role.args = args
        include_role.action = action
        block_list, handlers = include_role.get_block_list()
        has_error = False

# Generated at 2022-06-11 10:53:07.876193
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Code to setup test case
    import sys
    import os.path
    import ansible.playbook
    import ansible.playbook.task_include
    import importlib

    importlib.reload(ansible.playbook.task_include)
    importlib.reload(ansible.playbook)

    block = ansible.playbook.Block()
    role = ansible.playbook.Role()
    task_include = ansible.playbook.task_include.TaskInclude()
    ir = ansible.playbook.task_include.IncludeRole(block=block, role=role, task_include=task_include)

    blocks = ir.get_block_list(play=None, variable_manager=None, loader=None)

    # Code to test
    # assert function_name(input) == expected

# Generated at 2022-06-11 10:53:12.403124
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    test_block = Block.load(
        dict(
            name="test",
            tasks=[
                dict(include_role=dict(
                    name='foo'
                )),
            ]
        ),
        play=None,
        variable_manager=VariableManager(),
        loader=AnsibleCollectionLoader(),
    )

    test_include = test_block.block_args.get('tasks')[0]
    assert isinstance(test_include, IncludeRole)

    pc = PlayContext()

# Generated at 2022-06-11 10:53:14.467528
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = None
    ir.action = 'TESTING'
    ir._role_name = 'test my name'
    assert ir.get_name() == ('TESTING : test my name')

# Generated at 2022-06-11 10:53:15.598653
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    raise NotImplementedError

# Generated at 2022-06-11 10:53:25.612733
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test when block is None
    data = {'list': [{'key1': 'value1', 'key2': 'value2'}]}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    assert IncludeRole.load(data, block, role, task_include, variable_manager, loader)

    # Test when rolespec_validate is False
    data = {'list': [{'key1': 'value1', 'key2': 'value2'}]}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    assert IncludeRole.load(data, block, role, task_include, variable_manager, loader)

    # Test when block is an object of Block
    block = Block()


# Generated at 2022-06-11 10:53:34.320695
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader

    role_loader._collection_paths = [
        'test/sanity/code/roles/collections/ansible_collections/test_namespace/test_collection1/ansible_collections/test_namespace/test_collection1/roles/test_role1',
        'test/sanity/code/roles/collections/ansible_collections/test_namespace/test_collection1/roles/test_role2'
    ]
    role_loader._fallback_paths = [
        'test/sanity/code/roles/'
    ]


# Generated at 2022-06-11 10:54:07.830141
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    yaml_data = '''
    - include_role:
        name: foobar
        apply:
          tags:
            - foo
        public: True
        allow_duplicates: False
        rolespec_validate: False
    '''
    from collections import namedtuple
    Block = namedtuple('Block', ['vars'])
    Role = namedtuple('Role', ['vars'])
    class Play:
        def __init__(self, vars):
            self.vars = vars
    class PlayContext:
        def __init__(self, defs):
            self.CONFIG_DEFAULTS = defs
    x = IncludeRole.load(yaml_data, Block(dict()), Role(dict()), loader=None, variable_manager=None)

# Generated at 2022-06-11 10:54:18.589730
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    action = 'include_role'
    data = {
        'foo': 'bar',
        'one': 1,
        'name': 'test_name',
        'apply': {
            'foo': 'test_foo',
            'two': 2,
            'three': 3,
        },
        'handlers_from': 'test_handlers_from',
        'defaults_from': 'test_defaults_from',
        'vars_from': 'test_vars_from',
        'tasks_from': 'test_tasks_from',
        'public': True,
        'allow_duplicates': False,
        'rolespec_validate': False,
    }
    display.verbosity = 3
    # Test with good values

# Generated at 2022-06-11 10:54:22.146476
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    data = dict()

    include_role = IncludeRole.load(data, block, role, task_include, loader)

    assert include_role.block == block
    assert include_role.action == 'include_role'

# Generated at 2022-06-11 10:54:33.352667
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    import sys
    import yaml
    sys.path.append(os.path.join(os.path.dirname(__file__), '../test'))
    from unittest_data import data
    def run_test(obj_type, data, expected_result=None, **kwargs):
        if obj_type=='IncludeRole':
            from ansible.playbook.task_include import TaskInclude
            from ansible.playbook.role import Role
            from ansible.playbook.play import Play
            ti=TaskInclude()
            role=Role()
            ri=RoleInclude()
            play=Play().load(data=dict(vars=dict(somevar='somevalue')))
            play.roles=[role]

# Generated at 2022-06-11 10:54:43.423849
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    inc_role = IncludeRole()
    data = {'include_role': {'name': 'foo'}}
    inc_role = inc_role.load(data)
    assert inc_role['name'] == 'foo'
    assert inc_role['role'] == 'foo'
    assert inc_role.args == {'name': 'foo', 'role': 'foo'}

    inc_role = IncludeRole()
    data = {'include_role': {'role': 'bar'}}
    inc_role = inc_role.load(data)
    assert inc_role['name'] == 'bar'
    assert inc

# Generated at 2022-06-11 10:54:51.181540
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import sys
    import json
    import yaml

    temp1 = '''
    - {include_role: role1, public: true}
    '''

    temp2 = '''
    - {include_role: role1, apply: {a: 1}}
    '''

    temp3 = '''
    - {include_role: role1, tasks_from: 1}
    '''

    temp4 = '''
    - {include_role: role1, vars_from: 1}
    '''

    temp5 = '''
    - {include_role: role1, handlers_from: 1}
    '''

    temp6 = '''
    - {include_role: role1, unknown_key: 1}
    '''


# Generated at 2022-06-11 10:54:51.745479
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:55:01.905538
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    import copy
    import random
    import shutil
    from ansible.module_utils._text import to_bytes
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-11 10:55:11.525042
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    def get_hosts(hosts_str):
        hosts_str = hosts_str or ''
        host_list = hosts_str.split(',')

        hosts = []
        for host in host_list:
            hosts.append(host.strip())

        return hosts

    def get_host_patterns(hosts_str):
        hosts_str = hosts_str or ''
        host_list = hosts_str.split(',')

        host_patterns = []
        for host in host_list:
            host_patterns.append(host.strip())

        return host_patterns


# Generated at 2022-06-11 10:55:12.764022
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test load
    raise NotImplementedError


# Generated at 2022-06-11 10:55:40.681105
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import yaml
    from ansible.utils.display import Display

    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-11 10:55:50.950844
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''Unit test for method load of class IncludeRole.'''
    class FakePlay:
        def __init__(self):
            self.handlers = []
            self.roles = []
    class FakeRole:
        def __init__(self, name=None, path=None):
            self._metadata = type('FakeMeta', (object,), {'allow_duplicates': True})
            self._role_name = name
            self._role_path = path
            self._parents = []
        def get_handler_blocks(self, play=None):
            return [type('FakeBlock', (object,), {'_parent': self})]
        def compile(self, play=None, dep_chain=None):
            return [type('FakeBlock', (object,), {'_parent': self})]

# Generated at 2022-06-11 10:55:57.791895
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play
    import ansible.playbook.role
    from ansible.playbook.play import Play
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role_include import RoleInclude

    class FakeVariableManager:
        def get_vars(self, play=None, task=None):
            return {}

    class FakeLoader:
        def get_basedir(self):
            return '/home/ansible/my_playbook/'

    class FakePlay:
        def __init__(self):
            self.roles = []
            self.handlers = []

    class FakeRoleInclude:
        def __init__(self):
            self.vars = {}

        def get_role_params(self):
            return {}


# Generated at 2022-06-11 10:56:09.402197
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import get_all_plugin_loaders

    test_plugin_loader = get_all_plugin_loaders()[0]._find_plugin(
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'test', 'unit', 'test_plugins'))


# Generated at 2022-06-11 10:56:18.774730
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    class MockPlaybook():
        def __init__(self, vars):
            self.vars = vars
            self.loader = None
            self.roles = []
            self.handlers = []

    class MockRole():
        def __init__(self):
            self.name = 'mock-role'
            self._role_path = '/mock/role/path'
            self._metadata = MockMetadata()

    class MockRoleInclude():
        def __init__(self):
            self.vars = {
                'test-var': 'test-value',
            }

    class MockBlock(Block):
        pass

    class MockMetadata():
        def __init__(self):
            self.allow_duplicates = False

    sv = C.DEFAULT_SANDBOX_ROLE_VARS

# Generated at 2022-06-11 10:56:25.278947
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block(None, [])
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)

    ir._role_name = 'a'
    myplay = {}
    variable_manager = {}
    loader = {}

    block_list, handlers = ir.get_block_list(play=myplay, variable_manager=variable_manager, loader=loader)
    assert len(block_list) == 0
    assert len(handlers) == 0

# Generated at 2022-06-11 10:56:35.348700
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager('IncludeRole.load')
    results = tqm.load_callbacks()
    myplay = tqm._play
    play_loader = myplay._loader
    play_variable_manager = tqm.variable_manager

    # set role_path to some folder containing a role
    myplay.role_path = ['tests/lib/roles']
    # "role_name" should be a dir in the above folder
    data = {
        'name': 'role_name',
        'role': 'role_name',
        'tags': ['all', 'my_role']
    }

    # pylint: disable=E1123
    # this is being tested in the following lines:
    role_include = Include

# Generated at 2022-06-11 10:56:44.796445
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os
    import shutil
    import tempfile

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    print(tmpdir)
    # create a file in the temp directory
    test_playbook_file = tmpdir + "/test_playbook.yaml"
    test_playbook_content = C.DEFAULT_ROLES_PATH + "/test_role_tasks/main.yaml"

    # clean up the temp directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-11 10:56:54.591030
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    file_name = "/path/to/file.yml"
    role_name = "role_name"
    data = {"include_role": role_name, "_ansible_verbosity": 4}
    from ansible.playbook import Playbook
    myplay = Playbook.load(file_name, loader=None, variable_manager=None, database=None)
    ir = IncludeRole.load(data, role=None, task_include=None)
    assert ir._role_name == role_name
    assert ir.statically_loaded is False
    assert ir._role_path is None
    assert ir.allow_duplicates is True
    assert ir.public is False
    ir.get_block_list(play=myplay, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:56:55.673940
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    assert None, 'Unit test has not been implemented'

# Generated at 2022-06-11 10:57:29.374941
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:57:34.739581
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    test_hosts = ['localhost']
    test_loader_name = 'test_loader_file'
    test_loader_path = '/tmp/'
    test_loader_content = '[all]\nlocalhost'
    test_loader_full_path = test_loader_path + test_loader_name

    with open(test_loader_full_path, 'w') as loader_file:
        loader_file.write(test_loader_content)

    inventory = InventoryManager(loader=loader, sources=test_loader_name)

# Generated at 2022-06-11 10:57:46.166523
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    import ansible.constants as C
    import ansible.plugins.loader as plugin_loader
    import ansible.utils.collection_loader as collection_loader

    class MockPlay:
        def __init__(self):
            self._ds = {}
            self._variable_manager = None

    class MockVariableManager:
        def get_vars(self, play=None, task=None):
            if task is not None:
                return task.vars
            return {}


# Generated at 2022-06-11 10:57:55.779075
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole(None, None)
    data = dict(name="test_role")
    include_role.load(data)
    assert "test_role" == include_role.name
    data = dict(role="test_role", allow_duplicates=True)
    include_role.load(data)
    assert True == include_role.allow_duplicates
    data = dict(role="test_role", public=True)
    include_role.load(data)
    assert True == include_role.public
    data = dict(role="test_role", rolespec_validate=False)
    include_role.load(data)
    assert False == include_role.rolespec_validate
    data = dict(role="test_role", tasks_from="main.yml")
    include_role

# Generated at 2022-06-11 10:58:06.063449
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude

    ansible_play_context = PlayContext()
    ansible_play_context.become = False
    mock_play = Play().load({
        'name': 'test',
        'connection': 'local',
        'hosts': 'all',
        'gather_facts': 'no',
        'roles': ['test']
    }, variable_manager=None, loader=None)
    mock_role_include = RoleInclude.load('test', play=mock_play, variable_manager=None, loader=None, collection_list=None)
    # set attributes of role include instance
    mock_role_include._metadata = 'test'
    mock

# Generated at 2022-06-11 10:58:15.237206
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.constants as C
    import ansible.inventory

    ansible.constants.DEFAULT_LOCALHOST_WARNING = False
    inventory = ansible.inventory.Inventory(host_list=[])
    vars_files=["test_data/vars_files/vars_file"]
    vars_manager = ansible.vars.VarsManager(loader=C.DEFAULT_LOADER, inventory=inventory, variables=dict())
    vars_manager.extra_vars = dict(foo="bar")
    vars_manager.options_vars = dict()
    vars_manager.set_vars_files(vars_files)
    vars_manager._vars_files = vars_files

# Generated at 2022-06-11 10:58:25.692361
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import loader

    p = PlayContext()
    fake_loader = loader.DictDataLoader(dict(
        dict(
            dict(
                dict(
                    path='/dev/null',
                    content="""
                    - name: "include_role test"
                      hosts: localhost
                      gather_facts: no
                      roles:
                        - role_include
                    """,
                )
            )
        )
    ))

    # playbook parser needs a fake display
    class FakeDisplay:
        verbosity = 3

        def display(self, msg, *args, **kwargs):
            return

    display = FakeDisplay()

    b = Block()
    r = Role()
    r._role_path = '/dev/null'
    r._

# Generated at 2022-06-11 10:58:26.999504
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: write unit tests for the load method
    pass



# Generated at 2022-06-11 10:58:35.248226
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    action = 'include_role'
    loader = None
    variable_manager = None
    block = None
    role = None
    include_role = None
    playbooks_path = '/etc/ansible/playbooks'
    data = {
        'name': 'sample',
        'role': 'sample'
    }
    include_role = IncludeRole.load(data, block=block, role=role, task_include=include_role, variable_manager=variable_manager, loader=loader)
    name = 'sample'
    assert include_role._role_name == name
    block_list, handlers = include_role.get_block_list()
    assert block_list is not None

# Generated at 2022-06-11 10:58:44.405635
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    def run_test(ir, count, handler_count):
        blocks, handlers = ir.get_block_list(play=myplay, variable_manager=var_mgr, loader=loader)
        assert len(blocks) == count
        assert len(handlers) == handler_count

    # Create some test data