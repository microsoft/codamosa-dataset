

# Generated at 2022-06-11 10:49:44.976508
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert False, "test_IncludeRole_get_block_list() not implemented"


# Generated at 2022-06-11 10:49:55.542463
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    # define a couple of test classes

    class MyBlock(Block):
        name = 'TEST'


# Generated at 2022-06-11 10:50:06.263022
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(include_role=dict(name="foo")), dict(role=dict(name="bar"))],
    )
    play = Play.load(play_source, variable_manager=None, loader=None)

    assert len(play.get_roles()) == 2

    # Validate include_role
    ir0_task = play.get_tasks()[0]
    assert isinstance(ir0_task, IncludeRole)

# Generated at 2022-06-11 10:50:10.814755
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole()
    task.name = "name"
    task._role_name = "role_name"
    assert task.get_name() == "name : role_name"
    task.name = None
    assert task.get_name() == "include_role : role_name"

# Generated at 2022-06-11 10:50:21.970529
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # IMPORTANT: this test does not run in CI, as we need the dummy role (see path below)
    # to do a full test, run: `git clean -dfx && python -m pytest unit/test_include.py -s -vv`
    import ansible.plugins.loader
    ansible.plugins.loader.add_directory("./../../")
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.action as action_plugins
    import ansible.plugins.tasks as task_plugins
    import ansible.plugins.callback as callback_plugins
    from ansible import context
    from ansible.playbook.helpers import load_list_of_tasks

    from ansible.playbook.role.definition import RoleDefinition, DEFAULT_ROLES_PATH

# Generated at 2022-06-11 10:50:33.304250
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test if method get_block_list of class IncludeRole
    """
    class ParentRole():
        def __init__(self, name, namespace):
            self.name = name
            self.namespace = namespace

        def get_namespace(self):
            """
            Get namespace of role
            """
            return self.namespace

    global display
    display = Display()

    class Play():
        def __init__(self):
            self.handlers = []
            self.roles = []

    class RoleInclude():
        def __init__(self, name, namespace):
            self.name = name
            self.namespace = namespace

        def get_name(self):
            """
            Get namespace of role
            """
            return self.name


# Generated at 2022-06-11 10:50:41.178853
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'name': 'x'}
    role = Role()
    role.get_role_params = lambda: {'ansible_role_name': 'y'}
    task = IncludeRole(block, role, task_include)
    assert task.get_include_params() == {'ansible_role_name': 'y'}

    role = Role()
    role.get_role_params = lambda: {'ansible_role_name': 'y'}
    role._role_path = 'role_path'
    task = IncludeRole(block, role, task_include)

# Generated at 2022-06-11 10:50:52.835026
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook import Role
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import load as task_include_load
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    name = 'test_name'
    empty_data = {'name': name}
    invalid_role_data = {'name': name, 'role': 'invalid_role'}

    variable_manager = None
    loader = None

    # test with empty 'name' param
    data = empty_data.copy()
    data['name'] = None

# Generated at 2022-06-11 10:51:02.899499
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest
    from ansible.utils.display import Display
    from ansible.playbook.task import Task

    display = Display()
    block = Block()

    task = Task()
    task.action = 'include_role'
    task._role_name = 'role_name'
    task._role_path = 'role_path'
    task._parent_role = 'parent_role'
    task._from_files = {"tasks": "new_task_name.yml"}

    data = {'name': 'role_name', 'tasks_from': 'task_file', 'apply': {'do_something': True}}
    my_role = IncludeRole.load(data, task)

    assert my_role.name == 'role_name'

# Generated at 2022-06-11 10:51:14.853132
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.task

    play_context = PlayContext()

    play = ansible.playbook.play.Play()
    play._included_filenames = {'/tmp/roles/test/tasks/main.yml'}
    play._variable_manager = dict()
    play._loader = dict()
    play._loader.set_basedir( '/tmp/ansible_test' )

    task = ansible.playbook.task.Task()
    task.action = 'include_role'
    task._parent = play
    task.args = dict(
        name='test'
    )
    task._role_name = 'test'
    task._role_path = 'test'

    # First

# Generated at 2022-06-11 10:51:28.147517
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.plugins.callback import CallbackBase

    def test_cb_init(*args, **kwargs):
        return CallbackBase(*args, **kwargs)
    callback = test_cb_init()

    class TestBlock(Block):

        def __init__(self):
            super(TestBlock, self).__init__()
            self.action = 'test'

    loader = DataLoader()
    roles_path = './tests/unit_tests/vars/roles/'

# Generated at 2022-06-11 10:51:36.047788
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import unittest
    import sys
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.play_context import PlayContext

    class TestIncludeRole_load(unittest.TestCase):
        def test_load(self):
            pass
    suite = unittest.TestLoader().loadTestsFromModule(TestIncludeRole_load())
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-11 10:51:46.669559
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from .yaml import YAML
    yaml_loader = YAML(typ='unsafe')
    yaml_loader.set_document(yaml_loader._construct_sequence(['include_role', {'name': 'Apache', 'tasks_from': 'main.yml'}]))
    yaml_loader._load_prelude()
    ir_task = yaml_loader._load_tasks()[0]
    ir = IncludeRole.load(ir_task)
    assert ir.get_name() == 'include_role : Apache'
    assert ir._role_name == 'Apache'
    assert ir._from_files['tasks'] == 'main.yml'



# Generated at 2022-06-11 10:51:54.714326
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # From test/units/module_utils/test_utils.py
    from ansible.module_utils.six import PY3
    import ast
    import os
    import sys
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    # Instantiate object IncludeRole
    # =================================================================================
    # ATTRIBUTES
    block=None
    role=None
    task_include=None
    variable_manager=None
    loader=None
    ir = IncludeRole(block, role, task_include=task_include)
    
    # test '_allow_duplicates' attribute
    assert ir._allow_du

# Generated at 2022-06-11 10:52:05.866934
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import os
    import random
    import shutil
    import tempfile
    import textwrap
    import unittest

    import ansible.errors as ans_errors
    import ansible.module_utils.six.moves.configparser as configparser

    import ansible.module_utils.six as six
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    from ansible.playbook.role import Role

# Generated at 2022-06-11 10:52:09.381707
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: Add test cases
    #       RoleInclude.load()
    #       Role.load()
    #       Role.compile()
    #       Role.get_handler_blocks()
    pass

# Generated at 2022-06-11 10:52:18.435789
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor import playbook_executor

    loader = None
    variable_manager = VariableManager()
    inventory = None
    variable_manager.extra_vars = {}
    variable_manager.set_inventory(inventory)
    variable_manager.set_loader(loader)
    variable_manager.set_options_vars(None)
    variable_manager.extra_vars = {u'role_name': u'fibonacci-ansible-role'}

    deployment_play = {u'hosts': u'localhost', u'name': u'Playbook1', u'roles': []}
    role_name = u'fibonacci-ansible-role'
    play_path = u

# Generated at 2022-06-11 10:52:31.319366
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    import ansible.playbook.play
    import ansible.inventory.host
    import ansible.utils.template

    #
    # Objects creation
    #
    name = "test_name"
    data = {"name" : name}

    variable_manager = ansible.utils.template.VariableManager()
    host = ansible.inventory.host.Host(name="test_host")

    pb = ansible.playbook.play.Play()
    pb._variable_manager = variable_manager
    pb._hosts = [host, ]

    block = ansible.playbook.block.Block()
    block._play = pb

    r = Role()
    r._play = pb

    #


# Generated at 2022-06-11 10:52:35.551086
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class TestIncludeRole(IncludeRole):
        def __init__(self):
            pass

    test_case = TestIncludeRole()
    test_case.action = 'include_role'
    test_case._role_name = 'test_role'
    assert test_case.get_name() == 'include_role : test_role'

# Generated at 2022-06-11 10:52:43.307177
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # 1. include_role
    # 1.1 (no parameter)
    include_role_task = IncludeRole(None, None)
    include_role_task._role_name = 'test.role'
    include_role_task._parent = Block()
    include_role_task._parent._play = 'play'
    actual_result = include_role_task.get_block_list()
    expected_result = ([], [])
    assert actual_result == expected_result
    # 1.2 (with parameter)
    variables = {'vars': {'var1': 'value1'}}
    include_role_task.vars = variables['vars']
    include_role_task._parent.vars = variables
    actual_result = include_role_task.get_block_list()

# Generated at 2022-06-11 10:53:05.775783
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    block = Block()
    role = RoleDefinition.load(dict(name='role_name', path='/fake/path'))

    block.append(IncludeRole(role=role, task_include=dict(name='test_include', static=True)))
    block.append(IncludeRole(role=role, task_include=dict(name='test_include', static=False)))


# Generated at 2022-06-11 10:53:11.305881
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play, Playbook
    from ansible.vars import VariableManager

    vm = VariableManager()
    playbook = Playbook()
    play = Play.load(dict(name="foo"), playbook, vm)
    ir = IncludeRole.load(dict(role="test-role"), play, vm, playbook)
    play.block.blocklist.append(ir)
    play.post_validate()
    blocks, handlers = ir.get_block_list(play=play)
    assert len(blocks) == 1
    assert type(blocks[0]) == Block
    assert type(handlers[0]) == Block

# Generated at 2022-06-11 10:53:11.986239
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    raise NotImplementedError()


# Generated at 2022-06-11 10:53:17.383393
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pprint
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # ansible.utils.display.Display.verbosity = 5
    yaml_data = """
- include_role: 
    name: my_role
    allow_duplicates: True
    apply:
        ignore_errors: True
    vars:
        var1: value1
"""
    mock_loader = DataLoader()

# Generated at 2022-06-11 10:53:27.444468
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class Task1(Block):
        _block_type = 'block'
        _updatable_fields = ('action',)

    class ParentRole(Role):
        pass

    def task_loader(x):
        return Task1()

    def role_loader(x):
        return ParentRole()

    l = dict(
        role_loader=role_loader,
        task_loader=task_loader,
    )

    class TaskInclude1(TaskInclude):
        def __init__(self, loader=l):
            super(TaskInclude1, self).__init__(loader=loader)

    block = Task1()
    role = ParentRole()


# Generated at 2022-06-11 10:53:30.873499
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.module_utils.basic
    import ansible.variables

    yaml_data = {'include_role': 'some_role'}
    block = None
    role = None
    task_include = None
    variable_manager = ansible.variables.VariableManager()
    loader = ansible.module_utils.basic.AnsibleModuleLoader(None, None)

    expected_result = 'some_role'

    actual_result = IncludeRole.load(yaml_data, block, role, task_include, variable_manager, loader)._role_name

    assert actual_result == expected_result, "Actual result should be " + expected_result + \
                                             ", but it was " + actual_result

# Generated at 2022-06-11 10:53:33.446169
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role_name = "testRole"
    action = "include_role"
    expected = "include_role : testRole"
    include = IncludeRole()
    include._role_name = role_name
    include.action = action
    assert include.get_name() == expected



# Generated at 2022-06-11 10:53:44.161902
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import vars_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    role = Role()
    rolepath = "../../../test/integration/targets/vcenter_group_by/"
    role.name = "group_by"
    role.path = rolepath

    display.verbosity = 4
    loader = DataLoader()
    templar = Templar(loader=loader)

    block = Block(role=role)

    var_manager = VariableManager()
    var_manager.extra_vars = {'foo': 43}

    play_context = PlayContext()
    play_context.check_mode = True
    play

# Generated at 2022-06-11 10:53:45.319490
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-11 10:53:55.671588
# Unit test for method load of class IncludeRole

# Generated at 2022-06-11 10:54:29.687016
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader

    play = Play().load(dict(
        name="Ansible Play",
        hosts=['localhost'],
        gather_facts='no',
        tasks=[
            dict(action=dict(
                __ansible_module__='include_role',
                name='common',
                vars=dict(state='present'))
            ),
        ]
    ), variable_manager=VariableManager(), loader=Loader())

    tqm = None
    callback = callba

# Generated at 2022-06-11 10:54:39.905464
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    block = Block([])
    role = Role()
    role._role_path = "/path/to/role"
    role._role_name = "myrole"
    role._metadata = dict()
    role._metadata.allow_duplicates = True
    role._metadata.compiled_by = 1
    role._metadata.compiled_with = "2.9"
    role._metadata.created_by = "3.0"
    role._metadata.galaxy_info = "4"
    role._

# Generated at 2022-06-11 10:54:49.045042
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import group_loader, lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.module_utils.six import iteritems

    # Prepare data which would be loaded by constructor
    data = dict(
        include='common',
        name='test_role'
    )
    include_data = dict(
        include='common',
        name='test_role'
    )

    # Prepare other objects
    variable_manager = VariableManager
    loader = group_loader
    display = Display()

# Generated at 2022-06-11 10:54:50.904381
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Call method
    #ir.get_block_list()

    # No exception raised

    assert True

# Generated at 2022-06-11 10:55:00.847930
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.persistent_cache import PersistentCache
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import string_types
    import yaml

    loader = DataLoader()
    variable_manager = VariableManager()
    template = Templar(loader=loader, variable_manager=variable_manager)
    play_context = PlayContext()


# Generated at 2022-06-11 10:55:02.004443
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test the loading of IncludeRole.load
    pass

# Generated at 2022-06-11 10:55:11.643508
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    role = RoleDefinition.load(dict(
        name="foobar",
        tasks=[dict(name="blah")]
    ))
    role._role_path = "/path/to/role"
    role._parents = []

    task = TaskInclude.load(dict(
        name="task_x",
        include_role=dict(name="foobar")
    ))

    include_role = IncludeRole(role=role, task_include=task)
    variable_manager = VariableManager()
    vars_dict = variable_

# Generated at 2022-06-11 10:55:21.443207
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test with arguments missing
    data = {'include_role': {'name': 'foo'}}
    ir = IncludeRole.load(data)
    assert ir._role_name == 'foo'
    assert ir._from_files == {}

    # Test with arguments missing
    data = {'include_role': {'role': 'foo'}}
    ir = IncludeRole.load(data)
    assert ir._role_name == 'foo'
    assert ir._from_files == {}

    # Test with plain arguments
    data = {'include_role': {'role': 'foo', 'tasks_from': 'bar', 'vars_from': 'spam', 'defaults_from': 'ham', 'handlers_from': 'eggs'}}
    ir = IncludeRole.load(data)

# Generated at 2022-06-11 10:55:31.015502
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    data_loader = DataLoader()
    inventory = InventoryManager(loader=data_loader, sources=[])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[dict(
            role='foobar',
            tasks=[dict(
                include_role=dict(
                    name='foo'
                )
            )],
        )],
    )

# Generated at 2022-06-11 10:55:41.293495
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # No task_include object passed in
    assert IncludeRole.load(dict(name="role2", tasks_from="main.yml", vars_from="vars/main.yml",
                                 defaults_from="defaults/main.yml", handlers_from="handlers/main.yml"))

    # No task_include object passed in
    # No 'name' nor 'role' passed in
    try:
        IncludeRole.load(dict())
    except AnsibleParserError as e:
        assert e.message == "'name' is a required field for include_role."

    # name is needed, or use role as alias
    # 'name' is passed in with a value

# Generated at 2022-06-11 10:56:41.029639
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # pylint: disable=redefined-outer-name,too-many-branches
    import os

    from ansible_collections.collection_name.roles.role_name import defaults, meta, README, tasks, vars

    loader, inventory, variable_manager = Support.mock_loader()
    play, block = Support.mock_play(variable_manager=variable_manager, loader=loader)

    # Mocks
    inventory.groups = [ "foo" ]
    role_dir = os.path.dirname(__file__)
    role_vars_dir = os.path.join(role_dir, 'vars')
    role_defaults_dir = os.path.join(role_dir, 'defaults')

# Generated at 2022-06-11 10:56:50.409063
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleCollectionLoader()
    paths = 'ansible.builtin collection:devel.basic'
    collections = loader.list_collections(paths)
    display.vvvv('collections: %s' % collections)

    blocks, handlers = IncludeRole.load(
        data=dict(name='apb',
                  apply=dict(tags=['foo', 'bar']),
                  collections=paths),
        loader=loader,
        variable_manager=VariableManager(),
    ).get_block_list()

    display.vvvv('blocks: %s' % blocks)
    display

# Generated at 2022-06-11 10:56:53.262643
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole(block=None, role=None, task_include=None)
    assert ir.load(data=None) is None
    assert ir.load_data(data=None) is None


# Generated at 2022-06-11 10:57:02.892177
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # set up objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='127.0.0.1,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:57:12.250209
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    import os
    import sys
    # Make sure we use modules from this checkout
    # We need to do this because we want to run unit tests
    # before an install has happened
    ansible_base = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(1, ansible_base)
    sys.path.insert(1, os.path.join(ansible_base, 'lib'))

    # Define arguments
    args = {'name': 'test', 'role': 'test'}


# Generated at 2022-06-11 10:57:22.544060
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    loader = DataLoader()
    variable_manager = VariableManager()
    block = Block()
    task_include = TaskInclude()
    role = Role()

    # Tests:
    #
    # - extra parameter
    # - all options, but with misspelled allow_duplicates
    # - create an IncludeRole
    # - pass an extra parameter to the action
    # - pass an invalid parameter to the action
    # - pass wrong variable type for apply parameter
    # - pass wrong variable type for `public` parameter
    args = dict(name="test")
    data = dict(
        action="include_role",
        args=args,
        apply=dict(
           create_on_missing=[]
        )
    )
    test_args = args.copy()
    test_args["public"] = "test"

# Generated at 2022-06-11 10:57:26.762798
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    actual = IncludeRole(role='roleA').get_name()
    expected = 'include_role : roleA'
    assert actual == expected
    actual = IncludeRole(name='roleB').get_name()
    expected = 'include_role : roleB'
    assert actual == expected


# Generated at 2022-06-11 10:57:35.695956
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print("*******************************")
    print("Testing IncludeRole.get_block_list")

    # test_1
    block1 = Block()
    task_include1 = TaskInclude()
    task_include1.name = "test"
    task_include1.action = "test"
    task_include1.tasks = []

    print("block1 = ", block1)
    print("task_include1 = ", task_include1)

    role1 = Role()
    role1._role_path = "."
    role1._metadata = {}
    role1.compile(play=None, dep_chain=[])
    role1.validate()
    role1.finalize()

    include_role1 = IncludeRole(block=block1, role=role1, task_include=task_include1)
    include_role

# Generated at 2022-06-11 10:57:47.113743
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 10:57:53.977980
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class FakeRole(object):
        _parent = None
        _role_path = None
        action = 'include_role'
        name = None
        args = {'name': 'test', 'role': 'test'}

    ir = IncludeRole(role=FakeRole())
    assert ir.get_name() == 'test : test'

    ir.args['name'] = None
    assert ir.get_name() == 'include_role : test'

    ir.name = 'test'
    assert ir.get_name() == 'test'

