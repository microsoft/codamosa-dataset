

# Generated at 2022-06-11 10:49:52.624904
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Data (dict, block, role, task_include, variable_manager and loader are default)
    data = dict(
        name='test_name',
        role='test_role'
    )
    ir = IncludeRole.load(data)
    # Assertion
    assert ir._role_name == 'test_name'


# Generated at 2022-06-11 10:50:03.231042
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.role.meta
    import ansible.playbook.role.include
    import ansible.playbook.role.definition
    p = ansible.playbook.play.Play()
    m = ansible.playbook.role.meta.RoleMeta()
    r = ansible.playbook.role.Role(name='foobar1', role_path='./tests/support/role_include2')
    r2 = ansible.playbook.role.definition.RoleDefinition()
    ri = ansible.playbook.role.include.RoleInclude(role=r, role_name='foobar2', role_path='./tests/support/role_include1')


# Generated at 2022-06-11 10:50:13.830179
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.collections.loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()
    role_name = 'test_include_role'

    display.settings['collection_auto_deps'] = True
    play_context = PlayContext()
    ir = IncludeRole(role_name=role_name)
    ir._allow_duplicates = True
    ir._public = False
    ir._rolespec_validate = False
    ir.vars = {}
    ir.apply = {}
    # create play

# Generated at 2022-06-11 10:50:24.721270
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import tempfile

    # make a temporary directory to create our test files
    t = tempfile.mkdtemp()
    x = tempfile.mkdtemp()

    # The data structure to pass to IncludeRole's constructor
    args = {'name': 'some-name'}

    def clean_up():
        import shutil
        try:
            shutil.rmtree(t)
            shutil.rmtree(x)
        except Exception:
            pass

    # create a role
    role_dir = os.path.join(t, 'some-name')
    os.mkdir(role_dir)
    task_dir = os.path.join(role_dir, 'tasks')
    os.mkdir(task_dir)

# Generated at 2022-06-11 10:50:35.931368
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    This test helps to test that method get_block_list of class IncludeRole
    is working as designed.
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a mock class for a block
    class Block:
        def __init__(self):
            self.collections = []
            self.handlers = []
            self.tasks = []
            self.vars = {}
            self.role= None
            self.root_block = self
            self.parents = []
            self.child_block_list= []
            self.statically_loaded = False
            self.vars_files = []
            self.apply_implicit_include_role = False
            self.no_log = []

# Generated at 2022-06-11 10:50:47.315760
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # no options
    assert IncludeRole.load({'include_role': ''}).args == {}
    assert IncludeRole.load({'include_tasks': ''}).args == {}

    # role
    assert IncludeRole.load({'include_role': {'name': 'foo'}}).args == {'name': 'foo'}

    # role, apply
    assert IncludeRole.load({'include_role': {'name': 'foo', 'apply': {'b': 'bbb'}}}).args == {'name': 'foo', 'apply': {'b': 'bbb'}}

    # role, apply, public

# Generated at 2022-06-11 10:50:58.261410
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    myplay = Play().load({
        'name': 'test',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {
                'include_role': {
                    'name': 'foo.bar',
                    'apply': {
                        'to_all': True,
                        'tags': ['x', 'y']
                    }
                }
            }
        ]
    }, variable_manager=VariableManager(), loader=DataLoader())


# Generated at 2022-06-11 10:51:06.200138
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.vars.unsafe_proxy
    import ansible.vars.manager
    import ansible.template.template

    class VarsModule:
        def __init__(self):
            self.vars = {'id': '1', 'flag': 'myflag'}

        def get_vars(self, *args, **kwargs):
            return self.vars

    class TestIncludeRole(IncludeRole):
        def __init__(self):
            self.vars = VarsModule()
            self.args = {'name': 'mytestinclude', 'apply': {'flag': 'myflag'}}
            self._parent_role = None
            self._role_name = 'mytestinclude'


# Generated at 2022-06-11 10:51:07.039191
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:51:19.029085
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import ansible.errors
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # load role
    role_name = 'test-role'
    role_path = '../test-role/'
    variables = dict()
    loader = None
    play = Play().load(dict(name="test-play", hosts=['127.0.0.1']), loader=loader, variable_manager=variable_manager)
    variable_manager = None
    rolespec = {role_name: role_path}

    ri = RoleInclude.load(role_name, play, variable_manager, loader, rolespec)
    ri.vars = variables

    # build block
    block = Block()
    block

# Generated at 2022-06-11 10:51:38.137544
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from units.mock.loader import DictDataLoader

    data = dict(
        name="foobar.yml",
        host_name="foobar.example.com",
        play=dict(
            name="foobar",
            roles=[dict(
                name="foobar",
                tasks=[]
            )]
        )
    )

    # Instantiate variables manager, loader and templar
    variable_manager = VariableManager()
    loader = DictDataLoader(data)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    # Build the role
    role = Role.load(data['play']['roles'][0], variable_manager=variable_manager, loader=loader)

    # Build the block
    block = Block()
    block._role = role
    block._

# Generated at 2022-06-11 10:51:49.513787
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 10:51:51.156303
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:52:02.151408
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-11 10:52:14.128467
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from units.mock.loader import DictDataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_host("127.0.0.1")
    play_context = PlayContext()
    play_context.variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:52:26.436627
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test for correct action options
    assert IncludeRole.load({'include_role': {'name': 'role1'}}).name == 'include_role : role1'
    assert IncludeRole.load({'import_role': {'name': 'role1'}}).name == 'import_role : role1'

    # Test for missing role name
    try:
        IncludeRole.load({'include_role': {}})
    except AnsibleParserError as e:
        assert 'Expected a string but got' in e.message
    else:
        assert False, 'AnsibleParserError not raised'

    # Test for incorrect action options

# Generated at 2022-06-11 10:52:36.852407
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Unit test for method load of class IncludeRole
    '''

    # test IncludeRole load with valid inputs
    valid_in = dict(
        action='include_role',
        name='rolespec.name',
        apply={},
        allow_duplicates=True,
        public=False,
        rolespec_validate=True,
        tasks_from='tasks/main.yml',
        vars_from='vars/main.yml',
        defaults_from='defaults/main.yml',
        handlers_from='handlers/main.yml'
    )

    # test IncludeRole load with invalid inputs

# Generated at 2022-06-11 10:52:41.235866
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(name='somerole')
    block = Block()
    role = Role()
    task_include = None
    variable_manager = None
    loader = None
    ir = IncludeRole.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert ir.args == data


# Generated at 2022-06-11 10:52:48.827477
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test case: RoleInclude without name
    block = Block()
    role = Role()
    ir1 = IncludeRole(block=block, role=role)
    ir1._role_name = 'test-role'
    assert ir1.get_name() == 'import_role : test-role'

    # Test case: RoleInclude with name
    ir2 = IncludeRole(block=block, role=role)
    ir2.name = 'test-name'
    ir2._role_name = 'test-role'
    assert ir2.get_name() == 'test-name'

# Generated at 2022-06-11 10:52:49.464221
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:53:11.278620
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # pylint: disable=unused-variable

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    role_def = "../../../test/support/roles/test-role/tasks/main.yml"

    block = Block()
    block._play = None
    block._role = None
    block._parent = None
    block._task_blocks = []
    block._apply_priorities = {}
    block._block: []
    block._next_block = []

    role = RoleDefinition()
    role._role_path = "../../../test/support/roles/test-role"
    role._metadata = None
    role.compile()

    pc = PlayContext()
    role.set

# Generated at 2022-06-11 10:53:11.929341
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass
#

# Generated at 2022-06-11 10:53:17.348338
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test loading an include role with minimal params (include role is really just a role)
    task = dict(action='include_role', name='foo')
    result = IncludeRole.load(task)
    assert result._role_name == 'foo'

    # test loading an include role with allow_duplicates False
    task = dict(action='include_role', name='foo', allow_duplicates=False)
    result = IncludeRole.load(task)
    assert result._role_name == 'foo'
    assert result._allow_duplicates is False

    # test loading an include role with rolespec_validate False
    task = dict(action='include_role', name='foo', rolespec_validate=False)
    result = IncludeRole.load(task)
    assert result._role_name == 'foo'
    assert result._

# Generated at 2022-06-11 10:53:22.197391
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    result = {}
    my_arg_names = frozenset({})
    assert my_arg_names.difference(IncludeRole.VALID_ARGS) == result
    assert my_arg_names.intersection(IncludeRole.FROM_ARGS) == result
    assert my_arg_names.intersection(IncludeRole.OTHER_ARGS) == result


# Generated at 2022-06-11 10:53:31.175964
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    p = Play().load({'name': 'myplay', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager={}, loader=loader)
    add_all_plugin_dirs()
    ir = IncludeRole.load(data={"role": "test"}, block=Block(play=p), variable_manager={}, loader=loader)

    assert ir._role_name == "test"
    assert 'name' in ir.args
    assert ir.args['name'] == "test"


# Generated at 2022-06-11 10:53:40.467390
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.errors import AnsibleError
    from ansible.mock import Mock
    from ansible.utils import plugin_docs
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    import ansible.constants as C

    # setup
    options_mock = Mock()
    options_mock.roles_path = plugin_docs.find_files(C.DEFAULT_ROLES_PATH, 'roles')
    options_mock.defer_facts = False

    loader_mock = Mock()
    loader_m

# Generated at 2022-06-11 10:53:51.643018
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from units.mock.loader import DictDataLoader

    log = []

    class MockPlay:
        def __init__(self):
            self.name = "mockplay"
            self.roles = []
            self.handlers = []

    class MockVariableManager:
        def __init__(self):
            self.play = MockPlay()
            self.vars = {}

    class MockRoleInclude:
        def __init__(self):
            self.vars = {}
            self.roles_paths = ['/roles']

        def load(self, name, play, variable_manager, loader, collection_list):
            log.append("RoleInclude.load(%s)" % name)
            self.name = name

            return self


# Generated at 2022-06-11 10:53:59.404352
# Unit test for method get_include_params of class IncludeRole

# Generated at 2022-06-11 10:54:05.444597
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test without name parameter
    ir = IncludeRole()
    ir._role_name = "foo"
    assert ir.get_name() == "include_role:foo"

    # Test with name parameter
    ir1 = IncludeRole()
    ir1.name = "bar"
    assert ir1.get_name() == "bar"


# Generated at 2022-06-11 10:54:16.241747
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Verify IncludeRole.load is able to handle the following arguments: name, role, allow_duplicates, public and rolespec_validate
    """
    result = IncludeRole.load({'name': 'foo'})
    assert result._role_name == 'foo'
    assert result.allow_duplicates == True
    assert result.public == False
    assert result.rolespec_validate == True
    # Check additional arguments
    result = IncludeRole.load({'name': 'foo', 'role': 'bar', 'allow_duplicates': False, 'public': True, 'rolespec_validate': False})
    assert result._role_name == 'foo'
    assert result.allow_duplicates == False
    assert result.public == True
    assert result.rolespec_validate == False


# Unit test

# Generated at 2022-06-11 10:55:20.009149
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """ Unit test for method get_name of class IncludeRole
    """

    def fake_get_name(self):
        return 'fake_get_name'

    # Create a new instance of class IncludeRole
    ir = IncludeRole()
    # Replace the method get_name of class IncludeRole with 
    # a new method (fake_get_name)    
    ir.get_name = fake_get_name

    # Execute the method get_name of class IncludeRole
    result = ir.get_name()

    # Asserts to verify the result
    assert result == 'fake_get_name', 'Not the expected value'

# Generated at 2022-06-11 10:55:29.730360
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # Test load without block or role.
    IncludeRole.load({'name': 'test_role'}, block=None, role=None)

    # Test load with block and role but without a name or role.
    try:
        IncludeRole.load({}, block=Block(), role=Role())
        raise AssertionError('IncludeRole load should raise error when missing name or role entry.')

    except AnsibleParserError as e:
        assert 'name' in str(e), 'IncludeRole load should throw error when missing name or role entry: ' + str(e)

    # Test load with block and role but with missing 'name'.
   

# Generated at 2022-06-11 10:55:36.595715
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils._text import to_text

    def _normalize_2space(v):
        return v.replace(u'\xa0', u' ').replace(u'\x0a', u'\n')

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-11 10:55:47.239353
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.helpers import load_list_of_blocks

    play = Play().load({
        'name': 'test play',
        'hosts': 'localhost',
        'roles': [ 'test_role' ]
    }, variable_manager=None, loader=False)
    role = RoleDefinition.load({
        'name': 'test role'
    }, play=play, variable_manager=None, loader=False)

# Generated at 2022-06-11 10:55:55.899165
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(include_role=dict(name='test'))),
        ]
    ), variable_manager=VariableManager(), loader=action_loader)

    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-11 10:56:07.084848
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import shutil
    import tempfile
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    tmp_dir = tempfile.mkdtemp()
    host_list = 'localhost'
    base_vars = """
    a_var: "value"
    """
    data_loader = DataLoader()

    # The following code was copied from test_playbook_directory_loader.py
    main_role_base_

# Generated at 2022-06-11 10:56:17.128081
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor import playbook_executor


    inventory = InventoryManager(loader=DataLoader(), variable_manager=VariableManager(), sources='localhost')
    variable_manager = VariableManager()
    loader = DataLoader()

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(include='/home/dev/ansible-playbooks/role.yml'))
        ]
    )

# Generated at 2022-06-11 10:56:26.520782
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class FakeLoader(object):
        pass
    class FakeVariableManager(object):
        pass
    class FakePlay(object):
        pass
    class FakeRole(object):
        pass
    class FakeBlock(Block):
        pass
    class FakeRoleInclude(object):
        pass
    class FakeTemplar(Templar):
        def template(self, data, depth=0, convert_bare=True, fail_on_undefined=True, filter_fatal=True, overrides=None):
            return data
    class DummyIncludeRole(IncludeRole):
        def get_role_spec(self, role, role_with_colon=True):
            return "test"
    loader = FakeLoader()
    variable_manager = FakeVariableManager()
    play = FakePlay()
    block = FakeBlock()
    role

# Generated at 2022-06-11 10:56:37.018940
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from units.mock.loader import DictDataLoader
    import os

    pwd = os.path.dirname(os.path.realpath(__file__))


# Generated at 2022-06-11 10:56:42.316449
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    play = Play()
    task = Task()
    task._role = Role()
    ir = IncludeRole()
    ir._task_include = TasksInclude()
    ir._parent = task
    play.handlers = [Handler()]
    ir.get_block_list(play=play, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:57:51.950785
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Set up the play

# Generated at 2022-06-11 10:57:59.280710
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    example_valid_data = dict(
        name='name of role',
        tasks_from='mytasks.yml',
        vars_from='myvars.yml',
        handlers_from='myhandlers.yml',
        apply=dict(
            tags=['foo'],
            when='bar is baz'
            ),
        public=True,
        allow_duplicates=False,
        rolespec_validate=True,
        )

    my_include_role = IncludeRole.load(example_valid_data)
    assert(my_include_role.args['name'] == 'name of role')
    assert(my_include_role.tasks_from == 'mytasks.yml')
    assert(my_include_role.vars_from == 'myvars.yml')
   

# Generated at 2022-06-11 10:58:09.244713
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_play = Play().load({
        'hosts': 'all',
        'tasks': [
            {'include_role': {
                'name': 'ntp',
                'apply': {
                    'name': 'test',
                    'tags': ['test_tag']
                }
            }}
        ]
    })

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader())
    include_role = my_play.get_tasks()[0]

    # set default role path

# Generated at 2022-06-11 10:58:13.090945
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block1 = Block()
    block1._role_name = 'Test Role'
    task = IncludeRole()
    task._parent = block1
    task.action = 'include_role'
    task._role_name = 'Test Role'
    assert task.get_name() == 'include_role : Test Role'

# Generated at 2022-06-11 10:58:23.275565
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from units.mock.loader import DictDataLoader

    display = Display()
    loader = DictDataLoader({})
    variable_manager = VariableManager()

    data1 = {"include_role": {"name": "test.role",
                              "apply": "no",
                              "vars_from": "test.yml",
                              "allow_duplicates": True,
                              "rolespec_validate": True,
                              "apply_on_error": "yes",
                              "import_role": "yes",
                              "import_playbook": "yes",
                              "tag": "tag1"
                              }
             }
    result1 = IncludeRole.load(data1, loader=loader, variable_manager=variable_manager)

    assert result1._role_name == "test.role"


# Generated at 2022-06-11 10:58:33.318923
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.plugins.loader as loader_pkg

    my_block = Block(play=None)
    my_block._play = None
    my_loader = None
    my_vm = None

    my_ir = IncludeRole(block=my_block, role=None)
    my_ir._parent = None
    my_ir._parent_role = None
    my_ir.action = 'include_role'
    my_ir._role_name = 'my_role_name'
    my_ir._role_path = 'my_role_path'
    my_ir.statically_loaded = True
    my_ir.collections = []

    my_ir2 = IncludeRole(block=my_block, role=None)
    my_ir2.action = 'include_role'
    my_ir2.statically_

# Generated at 2022-06-11 10:58:42.855446
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    import ansible.constants as C
    C.DEFAULT_DEBUG_MSG_FORMAT = '%(name)s: %(message)s'

    C.DEFAULT_DEBUG = "verbose"

    display.verbosity = 3
    display.debug = True

    # Add plugin directories

# Generated at 2022-06-11 10:58:51.133768
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    # Define a task of type IncludeRole
    class TaskExample(IncludeRole):
        _allow_duplicates = True
        _public = False
        _rolespec_validate = True

        def __init__(self, block=None, role=None, task_include=None):
            super(TaskExample, self).__init__(block, role, task_include)
            self.action = 'include_role'
            self._from_files = {}
            self._parent_role = role
            self._role_name = None
            self._role_path = None

    class ParentBlock(Block):
        _role = None
        _dep_chain = []

        def __init__(self):
            super(ParentBlock, self).__init__()

       

# Generated at 2022-06-11 10:58:51.639104
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
     pass

# Generated at 2022-06-11 10:59:01.610147
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test when include_role is set
    data = {'include_role': {
            'name': 'test'
    },
            '__ansible_module__': 'include_role'
    }
    display.display = lambda x: x
    includerole = IncludeRole.load(data, None, None, None, None, None)
    assert includerole.get_name() == "include_role : test"
    # Test when role is set
    data = {'include_role': {
        'role': 'test'
    },
        '__ansible_module__': 'include_role'
    }
    display.display = lambda x: x
    includerole = IncludeRole.load(data, None, None, None, None, None)