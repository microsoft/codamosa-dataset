

# Generated at 2022-06-11 10:49:50.180774
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import os, shutil
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # copied from test_playbooks
    class Options(object):
        tags = {'foo'}
        listtags = False
        listtasks = False
        listhosts = False
        syntax = False
        connection = 'ssh'
        module_path = None
        forks = 100
        remote_user = 'vagrant'
        remote_port = None
        private_key_file = ['/home/zoran/.ssh/id_rsa']

# Generated at 2022-06-11 10:49:52.823916
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.task_include import TaskInclude
    include_role = IncludeRole()

    assert include_role.get_block_list() == ([],[])

# Generated at 2022-06-11 10:50:03.556554
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play

    from ansible.playbook import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='./test/inventory_hosts')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 10:50:14.035909
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.collections.ansible.builtin import AnsibleBuiltin as Builtin

    collection = Builtin()

    parent_role = Role.load('test/roles/test1', collection=collection)

    t1 = IncludeRole()
    t1._role_name = 'test'
    t1._parent_role = parent_role
    t1._role_path = ''

    # This is needed to avoid errors in get_block_list
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

# Generated at 2022-06-11 10:50:24.925787
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.task import Task

    t = Task()
    t.action = 'include_role'
    t.args = {'name': 'foo', 'public': True}
    ir = IncludeRole.load(t.args, task_include=t)
    assert ir.allow_duplicates is True
    assert ir.public is True
    assert ir._role_name == 'foo'
    assert ir._role_path is None
    assert ir._from_files == {}

    t = Task()
    t.action = 'include_role'

# Generated at 2022-06-11 10:50:36.066850
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext

    class Test_Role(Role):
        def __init__(self):
            super(Test_Role, self).__init__()

    class Test_AnsObj(AnsibleBaseYAMLObject):
        def __init__(self):
            super(Test_AnsObj, self).__init__()

    class Test_PlayContext(PlayContext):
        def __init__(self):
            super(Test_PlayContext, self).__init__()

    class Test_AnsInclRole(TaskInclude):
        def __init__(self):
            super(Test_AnsInclRole, self).__init__

# Generated at 2022-06-11 10:50:47.467221
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    some_task = Task()
    some_task.action = "I am a task"

    test_ir = IncludeRole()
    test_ir.role = some_task
    test_ir.action = "I am an include role"

    test_ir._role_name = "I am a role name"

    test_ir._parent = Block()
    test_ir._parent.apply = None
    test_ir._parent.tags = []
    test_ir._parent.deps = []

    test_ir._parent._play = None

    assert type(test_ir.get_block_list()) == tuple
    assert len(test_ir.get_block_list()[0]) == 1
    assert test_ir.get_block

# Generated at 2022-06-11 10:50:54.691111
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Testing for "name" parameter set to a string with arbitrary value
    block_test_1 = Block()
    i1 = IncludeRole(block=block_test_1)
    i1.name = 'My name'
    assert i1.get_name() == 'My name'
    # Testing for "name" parameter not set
    block_test_2 = Block()
    i2 = IncludeRole(block=block_test_2)
    assert i2.get_name() == 'include_role'


# Generated at 2022-06-11 10:51:04.171430
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.required_property import RequiredProperty
    from ansible.playbook.role import Role
    from ansible.utils.display import Display

    display = Display()
    play = Play.load(dict(
        name = "test",
        hosts = 'all',
        gather_facts = 'no',
        roles = [dict(
            name = "test",
            tasks = [dict(
                include_role = dict(
                    name = "test"
                )
            )]
        )]
    ))

    role = Role()
    role_name = "test"
    play.load()
    play.post_validate(play_context=play._play_context, split_vars=play.get_variable_manager())
    play._update_dependencies

# Generated at 2022-06-11 10:51:16.566488
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    loader = DictDataLoader({})
    play_context = PlayContext()

    def assertRaisesAnsibleParserError(expect_err_msg, data):
        if isinstance(data, IncludeRole):
            try:
                data.validate()
            except AnsibleParserError as e:
                assert str(e) == expect_err_msg
            else:
                assert False, 'Expected AnsibleParserError not found'
        else:
            try:
                IncludeRole.load(data, None, None, None, None, loader)
            except AnsibleParserError as e:
                assert str(e) == expect_err_msg
            else:
                assert False, 'Expected AnsibleParserError not found'

    # define parent_role
    parent_role = Role({}, [], 'parent_role', loader)

   

# Generated at 2022-06-11 10:51:24.127867
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._task_include = {'name': 'myRole', 'role': 'myRole'}
    assert ir.get_name() == 'myRole : myRole'

# Generated at 2022-06-11 10:51:34.853624
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import vars_loader

    fake_loader = vars_loader.VarsModule()
    fake_loader.set_fact('parent_role_var', 'parent_role_value')
    fake_loader.set_fact('role_var', 'role_value')
    fake_loader.set_fact('task_var', 'task_value')

    fake_play = Play({'name':'Fake Play'})
    fake_play.set_loader(fake_loader)
    fake_play.set_variable_manager()

    parent_role_name = 'parent_role'
    parent_role = Role().load({'name': parent_role_name}, parent_role=None, play=fake_play)

# Generated at 2022-06-11 10:51:46.906103
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''
    Check if get_include_params returns the correct results
    '''
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    import ansible.constants as C


# Generated at 2022-06-11 10:51:53.791243
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    yaml_data = """
- hosts: localhost
  tasks:
  - include_role:
      name: common
      vars:
        foo: bar
    """
    p = Play().load(yaml_data, variable_manager=VariableManager(), loader=DataLoader())
    t = p.get_tasks()[0]

    assert t._role_name == 'common'
    assert t.vars == dict(foo='bar')

# Generated at 2022-06-11 10:52:04.909161
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: Complete testing which will include testing all possible loader
    # options as well as testing with a pb that uses the correct loader.
    # Currently this test just checks that the method doesn't explode.
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, lookup_loader
    import ansible

# Generated at 2022-06-11 10:52:15.983463
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'name': 'foobar'}
    try:
        IncludeRole.load(data)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('IncludeRole.load with bad args did not raise AnsibleParserError')

    data = {'role': 'foobar'}
    IncludeRole.load(data)

    data = {'role': 'foobar', 'public': False}
    IncludeRole.load(data)

    data = {'name': 'foobar', 'public': False}
    IncludeRole.load(data)

    data = {'role': 'foobar', 'public': False, 'apply': {}, 'allow_duplicates': True, 'rolespec_validate': False}
    IncludeRole.load(data)


# Generated at 2022-06-11 10:52:28.946842
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-11 10:52:34.636289
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # without name
    block = Block()
    task = IncludeRole(block=block)
    task._role_name = 'testRole'
    assert task.get_name() == 'include_role : testRole'

    # with name
    task = IncludeRole(block=block)
    task._role_name = 'testRole'
    task.name = 'testInclude'
    assert task.get_name() == 'testInclude'

# Generated at 2022-06-11 10:52:42.759652
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import yaml

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_variable': 'test_value'}
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            'test_role'
        ]
    )

# Generated at 2022-06-11 10:52:43.495593
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:53:04.917078
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import os
    import sys
    ROLE_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'test_data', 'roles', 'test_role_included')
    ROLE_DEF_PATH = os.path.join(ROLE_PATH, 'meta')
    sys.path.append(ROLE_DEF_PATH)
    try:
        import meta
    except ImportError:
        raise AssertionError("Cannot import role definition meta from %s" % ROLE_DEF_PATH)
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

# Generated at 2022-06-11 10:53:07.190004
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    
    expect = "include_role : name"
    actual = IncludeRole.load({'include_role':'name'}).get_name()
    assert(expect == actual)

# Generated at 2022-06-11 10:53:13.711738
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    data = {'include_role': {'name': 'test'}}
    variable_manager = Mock()
    loader = Mock()
    ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
    assert ir.name == 'test'

    data = {'include_role': {'name': 'test2', 'allow_duplicates': False}}
    variable_manager = Mock()
    loader = Mock()
    ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
    assert not ir.allow_duplicates

    data = {'include_role': {'name': 'test3', 'rolespec_validate': False}}
    variable_manager = Mock()
    loader = Mock()

# Generated at 2022-06-11 10:53:23.752362
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Create IncludeRole object
    # Note: the constructor for class Block will be called automatically
    include_role = IncludeRole(action='include_role', args=dict(name='some_role'), block=Block(parent=None))

    # Set up the mock.
    # Note: Vars dict is only needed for the called method to run without errors
    play_mock = Mock(spec=Play, roles=[], handlers=[])
    play_mock.vars = dict()
    variable_manager_mock = Mock()
    loader_mock = Mock()

    # Run the function under test
    blocks, handlers = include_role.get_block_list(play=play_mock, variable_manager=variable_manager_mock, loader=loader_mock)

    # Check the calls

# Generated at 2022-06-11 10:53:32.980568
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.verbosity = 3
    display.color = True
    display.columns = 80
    display.debug = True

    # noqa - AnsibleParserError: Found illegal option 'foo' in include_role
    try:
        x = IncludeRole.load(data = {'action':'include_role', 'foo': 'bar'})
    except AnsibleParserError as e:
        print(('exception {0}'.format(e)))

    # noqa - AnsibleParserError: this is a required field for 'include_role'
    try:
        x = IncludeRole.load(data = {'action':'include_role'})
    except AnsibleParserError as e:
        print(('exception {0}'.format(e)))

    # noqa - AnsibleParserError: 'name' is a required field for 'include

# Generated at 2022-06-11 10:53:36.738096
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(role=Role(), task_include=TaskInclude(name='foo')).get_name() == 'foo'
    assert IncludeRole(role=Role(), task_include=TaskInclude(name=None)).get_name() == 'include_role : '

# Generated at 2022-06-11 10:53:42.951222
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # mock an object of class Role to use as attribute _parent_role
    mock_role = MockRole()

    # mock an object of class Block to use as attribute _block
    mock_block = MockBlock()

    # Test method of IncludeRole in case of having a valid _parent_role and a valid _block attribute
    ir = IncludeRole(role= mock_role, block = mock_block)
    assert isinstance(ir.get_block_list(), tuple)

# Generated at 2022-06-11 10:53:53.904163
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    mock_data = {
        'name': 'testname',
        'options': {
            'tasks': 'testtasks',
            'files': 'testfiles',
            'handlers': 'testhandlers',
            'vars': 'testvars',
            'defaults': 'testdefaults',
        },
        'block': 'mock_block',
        'role': 'mock_role',

    }
    mock_variable_manager = 'mock_variable_manager'
    mock_loader = 'mock_loader'

    # Run the tested method and check it's behavior

# Generated at 2022-06-11 10:53:54.258120
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    pass

# Generated at 2022-06-11 10:54:04.559954
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-11 10:54:36.139772
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 10:54:42.423280
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # describe an initial IncludeRole object
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # data from the playbook
    data = {'include_role': {'name': 'myRole'}}

    # run the load method
    res = IncludeRole.load(data, block, role, task_include, variable_manager, loader)

    # verify result
    assert res._role_name == 'myRole'

# Generated at 2022-06-11 10:54:50.664146
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.constants as C

    v = VariableManager()
    v.extra_vars = {'a': 'alpha', 'b': 'beta'}
    l = DataLoader()
    t = Templar(loader=l, variables=v)

# Generated at 2022-06-11 10:55:00.506524
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # inputs
    action = 'include_role'
    role_name = 'testrole'
    loader_mock = object()
    block = object()
    play = object()
    collection_list = object()
    variable_manager = object()

    # mocks
    block_mock = Block()
    block_mock.vars = dict()
    block_mock.collections = dict()
    role_mock = Role()
    role_mock.vars = dict()
    role_mock.collections = dict()
    role_mock_load = lambda role_name, play, parent_role=None, from_files=dict(), from_include=None, validate=None: role_mock
    role_mock._parents = dict()
    role_mock._role_path = object()
    role

# Generated at 2022-06-11 10:55:10.510006
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.parsing.yaml.dumper import AnsibleDumper

    # check loading of IncludeRole with `- import_role: ...` syntax
    role_name = 'include_role_test_1'
    role_path = './non_existent_role1'
    args = {'name': role_name, 'role': role_path, 'allow_duplicates': True}
    data = AnsibleDumper.dump({'import_role': args})
    my_ir = IncludeRole.load(data, variable_manager={})

    assert my_ir.get_name() == "%s : %s" % (my_ir.action, role_name)
    assert my_ir._role_name == role_name
    assert my_ir._role_path is None
    assert my_ir._allow_duplicates

# Generated at 2022-06-11 10:55:14.644203
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    ``load`` is a method of ``IncludeRole`` which is used to parse an included
    role. Data contains the parsed data of the included role.

    In the following function, we are testing the validity of the following
    parameters:

        * ``my_arg_names``
        * ``bad_opts``

    """
    block = Block()
    include_role_obj = IncludeRole(block)
    assert isinstance(include_role_obj, IncludeRole)

    data = {'block': block, 'role': 'role'}
    actual_result = include_role_obj.load(data)
    assert actual_result is not None

# Generated at 2022-06-11 10:55:24.209415
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    This test case is to cover the get_name method of the include role
    This assumes the role include is being tested as part of a play as
    it is a task include that is not intended to be ran by itself.
    First we create a play that is associated with the role include
    and we then create a role include and add it the the play
    The role include has a name and a role but when get_name is called
    it uses the task include (action) of the role include as the name
    if the name is none
    """
    from ansible.playbook import Play
    from ansible.playbook.includedfile import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role


# Generated at 2022-06-11 10:55:32.042609
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.utils.display
    import ansible.module_utils.six

    task_include = IncludeRole(None, None)
    task_include.name = 'TESTTASK'

    result = task_include.get_name()
    assert result == 'TESTTASK'

    task_include.name = None
    task_include.action = 'TESTACTION'

    task_include._role_name = 'FOOBAR'
    result = task_include.get_name()
    assert result == "TESTACTION : FOOBAR"

# Generated at 2022-06-11 10:55:42.058229
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)

    include_role.action = 'include_role'
    include_role.args = {}

    assert include_role.get_name() == 'include_role : '

    include_role.name = 'name1'
    include_role.args = {'role': 'role1'}
    include_role.action = 'include_role'

    assert include_role.get_name() == 'name1 : role1'

    include_role.name = 'name2'
    include_role.args = {'role': 'role2'}
    include_role.action = 'include_role'


# Generated at 2022-06-11 10:55:48.044834
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    r = RoleDefinition()
    r.name = 'foo'
    b = Block()
    b.role = r
    data = {'role': 'bar'}
    task = IncludeRole.load(data, b)
    assert isinstance(task, IncludeRole)
    assert task._role_name == 'bar'

# Generated at 2022-06-11 10:56:40.732976
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # noinspection PyUnresolvedReferences
    import ansible.constants
    ansible.constants.DEFAULT_ROLES_PATH = 'foo'

    # Make sure an exception is raised when required parameter 'role' is not provided
    test_data = dict(
        _hosts='localhost',
        _raw_params='fake_host',
        _task_fields=dict(
            action='fake_action',
        )
    )
    try:
        IncludeRole.load(test_data, task_include=TaskInclude())
    except AnsibleParserError as err:
        assert isinstance(err, AnsibleParserError)
    else:
        assert False

    # Make sure an exception is raised if an invalid option is provided

# Generated at 2022-06-11 10:56:50.151417
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    from ansible.module_utils._text import to_text, to_bytes
    from units.mock.loader import DictDataLoader

    kwargs = dict(
        block=dict(),
        name="test",
        args=dict(),
        tasks=[],
    )

    dummy_loader = DictDataLoader({
        'test/meta/main.yml': """
dependencies: []
""",
        'test/tasks/test.yml': """
- debug:
    msg: Test
""",
        'test/handlers/test.yml': """
- debug:
    msg: Test
""",
    })

    dummy_context = PlayContext()
    dummy_context._vars_

# Generated at 2022-06-11 10:56:59.967537
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Create a json with all attributes
    data = {
        'name': 'role1',
        'tasks': [
            {'include_role': {'name': 'role2'}},
            {'include_role': {'name': 'role3'}},
        ],
    }

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Create a parent playbook for the include role
    play = Play.load({
        'name': 'test',
        'hosts': 'all',
        'roles': [
            data
        ],
    })

    # Create the first block (it will be used as parent)
    parent_block = Block()
    parent_block._attributes = data
    parent_block._play

# Generated at 2022-06-11 10:57:08.693897
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins.loader import play_role_include_loader
    from ansible.plugins.loader import RoleIncludeLoader
    from ansible.playbook.role.definition import RoleDefinition

    collection = RoleDefinition()
    collection.action = '- include_role:'
    collection.name = 'test_role'
    collection.args = {'name': 'test_role'}
    collection.tasks = []
    collection.handlers = []
    collection.default_vars = {}
    collection.default_tasks = []
    collection.vars = {}
    collection.dep_chain = []
    collection.block = Block()

    name = 'test'
    role = role_loader(name)
    role.add_parent(role)
    role.add_child(role)
    collection.add_child(role)

# Generated at 2022-06-11 10:57:19.397792
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from_file_name = 'rolespec_validate_extra_vars.yml'
    from_file_path = '/Users/kweiss/ansible-playbooks/playbooks2_test/role_test/'
    from_file_path_name = '{}{}'.format(from_file_path, from_file_name)
    extra_vars = load_extra_vars(loader=DataLoader(), options=dict(extra_vars=from_file_path_name))
   

# Generated at 2022-06-11 10:57:29.229373
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    #from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    #loader = DataLoader()
    #templar = Templar(loader=loader)

    playbook = PlaybookExecutor()
    loader, inventory, variable_manager = playbook._load_playbook_data()

# Generated at 2022-06-11 10:57:38.910636
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='apache',                                                                 # name is a required argument
        apply=dict(    # this is an optional argument
            a=17,
        ),
        rolespec_validate=True,  # this is an optional argument
        unittest_skip_this=True, # this is an invalid argument
    )
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    p = Play().load(dict(name='unittest'), loader=loader, variable_manager=VariableManager())
    r = RoleInclude()

# Generated at 2022-06-11 10:57:49.906980
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        # taken from library/include/main.yaml
        apply=dict(
            ignore_errors=True,
            tags=['mytag'],
        ),
        allow_duplicates=False,
        name='foo',
        public=True,
    )

    ir = IncludeRole.load(data)

    assert ir._parent == None
    assert ir._role == None
    assert ir._role_name == 'foo'
    assert ir._role_path == None
    assert ir.allow_duplicates == False
    assert ir.args == data
    assert ir.apply == dict(ignore_errors=True, tags=['mytag'])
    assert ir.collections == []
    assert ir.delegate_to == None
    assert ir.delegate_facts == None
    assert ir.loop == None

# Generated at 2022-06-11 10:57:50.511284
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:57:58.447943
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role

    mypath = os.path.dirname(__file__)  # relative path to this file
    dataloader = DataLoader()

    # load a valid include_role
    # this also tests the corner case with 'name: foo'
    task_data = dataloader.load_from_file(os.path.join(mypath, 'test_data/include_role-valid-1.yml'))
    ir = IncludeRole.load(task_data, loader=dataloader, role=Role())
    assert ir._role_name == 'test-role'
    assert ir._from_files['tasks'] == 'tasks.yml'