

# Generated at 2022-06-11 10:49:58.538255
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''Unit test for method load of class IncludeRole'''

    # Test load with no data
    ir = IncludeRole.load({}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # Test load with invalid data
    try:
        ir = IncludeRole.load({'foo': 'bar'}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
        assert False
    except AnsibleParserError as e:
        pass
    try:
        ir = IncludeRole.load({'role': 'bar'}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
        assert False
    except AnsibleParserError as e:
        pass

    # Test load with valid data
    ir = Include

# Generated at 2022-06-11 10:50:09.376358
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    t = Templar(loader=None, variables={})
    data = dict(
        name="newrole"
    )
    p = PlayContext()
    t.set_available_variables(p.serialize())
    ir = IncludeRole.load(data)
    ir.validate_attributes(t)
    assert ir.name == "newrole", "fail: %s" % ir
    assert ir.rolespec_validate == True, "fail: %s" % ir
    ir.post_validate(None, None)

    data = dict(
        name="newrole",
        role="newrole"
    )
    p = PlayContext()
    t.set_available_variables(p.serialize())


# Generated at 2022-06-11 10:50:13.407435
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert IncludeRole.load(
        dict(name='example_role'),
        block=dict(name=''),
        role=dict(),
        task_include=dict(),
        variable_manager=dict(),
        loader=dict()
    ) is not None


# Generated at 2022-06-11 10:50:24.367311
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.vars.manager import VariableManager

    args_data = dict(
        name='foo',
        tasks_from='tasks/main.yml',
        vars_from='vars/main.yml',
        handlers_from='handlers/main.yml',
        defaults_from='defaults/main.yml',
        private=True
    )

    # Keyword arguments
    ir = IncludeRole.load(args_data)
    assert ir.action == 'include_role'
    assert ir._role_name == 'foo'
    assert ir.statically_loaded == False

# Generated at 2022-06-11 10:50:35.530961
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    C.DEFAULT_HOST_LIST = 'localhost'
    C.DEFAULT_HOST_PATTERN = 'all'
    C.DEFAULT_MODULE_NAME = 'copy'
    C.DEFAULT_MODULE_PATH = '/usr/share/ansible'
    C.DEFAULT_FORKS = 5
    C.DEFAULT_REMOTE_PORT = 22
    C.DEFAULT_MODULE_LANG = 'C'
    C.DEFAULT_TIMEOUT = 10
    C.DEFAULT_POLL_INTERVAL = 15


# Generated at 2022-06-11 10:50:36.572785
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO
    pass

# Generated at 2022-06-11 10:50:37.107463
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:50:48.708598
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    role = Role(name='test')

    block = Block.load(dict(
        tasks=dict(
            main=dict(
                action=dict(
                    module='debug',
                    args=dict(
                        msg='Hello world'
                    )
                )
            )
        )
    ))
    block._role = role
    block._play = role._parent

    ir = IncludeRole(block, role)
    ir._from_files = dict(
        tasks=dict(
            main=dict(
                action=dict(
                    module='debug',
                    args=dict(
                        msg='Hello world'
                    )
                )
            )
        )
    )
    ir._role_name = 'test'
    ir._role_path = '/some/path'


# Generated at 2022-06-11 10:50:59.682227
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from pprint import pprint
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    display.verbosity = 3

    loader = DataLoader()
    inventory = loader.load_from_file("../inventory.json")

    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:51:11.489297
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    yaml_block_list = '''
'''

    test_block_list = [
        {'name': 'test task 1'},
        {'name': 'test task 2'}
    ]

    yaml_blocks_list = '''
'''

    test_blocks_list = [
        {'name': 'test handler'}
    ]

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import collection_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class test_play:
        name = 'test play'

        def __init__(self):
            self.basedir = 'roles'
            self.roles = []
            self.handlers = []


# Generated at 2022-06-11 10:51:32.244486
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data_valid = {
        "include_role": {
            "name": "foo",
            "tasks_from": "some_tasks.yml",
            "vars_from": "some_vars.yml",
            "defaults_from": "some_defaults.yml",
            "handlers_from": "some_handlers.yml",
            "allow_duplicates": "true",
            "rolespec_validate": "false"
        }
    }


# Generated at 2022-06-11 10:51:44.861227
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='test_role',
        tasks_from='test_role/main.yml',
        vars_from='test_role/vars/main.yml',
        handlers_from='test_role/handlers/main.yml',
        public=True,
        allow_duplicates=False,
        rolespec_validate=False,
        apply=dict(
            ignore_errors=True
        )
    )
    ir = IncludeRole.load(data)
    assert ir.name == 'test_role'
    assert ir._role_name == 'test_role'
    assert not ir.tasks
    assert ir._from_files == dict(tasks='main.yml', vars='main.yml', handlers='main.yml')
    assert ir.public

# Generated at 2022-06-11 10:51:53.731395
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print('Test method get_name of class IncludeRole')

    # first, test with "name" as name variable
    data_in = {'tags': ['tag1'], 'name': 'foo', 'when': 'bar'}
    include_role = IncludeRole.load(data_in)
    data_out = include_role.get_name()
    if data_out == 'foo':
        print('Test1: PASS')
    else:
        print('Test1: FAIL')

    # second, test with "role" as name variable
    data_in = {'tags': ['tag1'], 'role': 'foo2', 'when': 'bar'}
    include_role = IncludeRole.load(data_in)
    data_out = include_role.get_name()

# Generated at 2022-06-11 10:52:00.591718
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='test',
        private=True,
        role='test_role',
        static=True,
        apply=dict(
            tags='test',
        ),
    )
    ir = IncludeRole.load(data)
    assert ir._name == data['name']
    assert ir._private
    assert ir._role_name == data['role']
    assert not ir._allow_duplicates
    assert ir._public
    assert ir._apply == data['apply']


# Generated at 2022-06-11 10:52:05.007042
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    b = Block(parent=None, role=None, task_include=None)
    r = Role(name="test_role")
    ir = IncludeRole(b, r)
    assert ir.get_name() == "include_role : test_role"


# Generated at 2022-06-11 10:52:09.873843
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    a = module_utils.basic.AnsibleModule()
    b = ansible.playbook.include.IncludeRole.load(data={
        'name': 'foo'
    }, block=Block(hosts=[], tasks=[]), variable_manager=a, loader=a)
    print(b)


# Generated at 2022-06-11 10:52:14.260665
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = 'test'
    assert ir.get_name() == 'include_role : test'
    ir.name = 'test_name'
    assert ir.get_name() == 'test_name'


# Generated at 2022-06-11 10:52:26.599374
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():


    import os
    import sys

    file_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, file_path + "/../../..")

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.blocks import Block

    # Load the inventory file
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/Users/bearlee/Workspace/ansible/samples/inventory.ini"])

    # Create inventory and pass to var manager
    variable_

# Generated at 2022-06-11 10:52:31.367986
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Unit test for method get_name of class IncludeRole
    """
    assert IncludeRole().get_name() == 'include_role : '
    assert IncludeRole(role=0).get_name() == 'include_role : '
    assert IncludeRole(role=object()).get_name() is None


# Generated at 2022-06-11 10:52:40.505224
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class FakeBlock:
        class FakePlay:
            def __init__(self, name=None, hosts=None, roles=None):
                self.name = name
                self.hosts = hosts
                self.roles = roles
                self.vars = {}
                self.tags = set()
                self.filters = {}
                self.defaults = {}

            def set_variable_manager(self, variable_manager):
                self.variable_manager = variable_manager

            def get_variable_manager(self):
                return self.variable_manager

        name = 'fake_play'
        hosts = 'fake_hosts'
        roles = 'fake_roles'
        play = FakePlay(name=name, hosts=hosts, roles=roles)
        _role = None
        _parent = None

# Generated at 2022-06-11 10:53:04.382984
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Set up and execute test for method load of class IncludeRole Class.
    """
    action = "include_role"
    data = {
        'include': action,
        'role': 'name',
        'tasks_from': 'tasks_from',
        'vars_from': 'vars_from',
        'defaults_from': 'defaults_from',
        'handlers_from': 'handlers_from',
        'apply': {'var1': 'val1', 'var2': 'val2'},
        'public': True,
        'allow_duplicates': False,
        'rolespec_validate': False
    }

    task_include = TaskInclude(block=Block.load(dict()), role=Role())
    role = Role(name='name', play=None)


# Generated at 2022-06-11 10:53:10.402178
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    parent = Block()
    parent._parent = Block()
    parent._role = Role()
    role = Role()
    inc = IncludeRole(block=parent, role=role)
    inc._from_files = {}
    inc._role_name = 'foo'
    # this makes the method call the one that returns the blocks
    def mock_load(name, play, variable_manager, loader, collection_list):
        return role
    RoleInclude.load = mock_load
    blocks, handlers = inc.get_block_list()
    # this is the result we expect
    assert blocks == [parent]
    assert handlers == []

# Generated at 2022-06-11 10:53:16.198415
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role import Role
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    collection_paths = AnsibleCollectionLoader().paths()
    loader = DataLoader()
    inventory = '''
    localhost    ansible_connection=local
    '''


# Generated at 2022-06-11 10:53:26.246511
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    i = IncludeRole(Block(play=None))
    assert i.load(dict(name='baz', tasks_from='foo', allow_duplicates=False, rolespec_validate=True))
    assert i.load(dict(name='baz', tasks_from='foo', apply=dict(ignore_errors=True), rolespec_validate=True))
    assert i.load(dict(name='baz', tasks_from='foo', public=True, rolespec_validate=True))
    assert i.load(dict(name='baz', tasks_from='foo', public=True, allow_duplicates=False, rolespec_validate=True))

# Generated at 2022-06-11 10:53:34.793456
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import unittest
    import ansible.plugins.loader as ds
    from ansible.module_utils.six import PY2

    class Dummy(object):
        def __init__(self):
            self._roles = []

    class DummyRole(object):
        # pylint: disable=too-many-arguments
        def __init__(self, name, path, vars, file_vars, metadata, collection_info):
            self._role_name = name
            self._role_path = path
            self._vars = vars
            self._file_vars = file_vars
            self._metadata = metadata
            self._collections = collection_info.collections

        def get_metadata(self, allow_duplicates=False):
            return self._metadata


# Generated at 2022-06-11 10:53:45.772677
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.display("Testing IncludeRole load method")
    import ansible.playbook
    import ansible.playbook.role
    import ansible.template
    import ansible.vars.manager
    import ansible.loader
    import tempfile

    def cleanup_changed_directory():
        if os.path.exists(new_tmpdir):
            os.removedirs(new_tmpdir)
    # cleanup_changed_directory()

    tmpdir = tempfile.mkdtemp()
    new_tmpdir = tmpdir + '/' + 'baz'
    os.makedirs(new_tmpdir)

    # Create a role
    role_name = 'foo'

# Generated at 2022-06-11 10:53:55.991090
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Unit test for method get_block_list of class IncludeRole.
    This method is tested in a separate class and not by the common
    module self_test.py since it is not a static function and
    requires to create a object of class IncludeRole.
    '''

    # initialize objects of type IncludeRole and Block
    ir = IncludeRole()
    b = Block()

    # Test method get_block_list() using data from tests/test_utils/test_module_utils_role_include.py
    # initialize parameters
    play = {
        'name': 'test_play',
        'gather_facts': True,
        'roles': [
        ],
        'tasks': [
        ],
    }

# Generated at 2022-06-11 10:54:07.528553
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ''' helper class to load a task and validate result '''
    class InputData:
        def __init__(self, task_action, args, task_block=None):
            self.task_action = task_action
            self.args = args
            self.task_block = task_block

    def test_IncludeRole_load_test(test, role):
        # convert input to dict
        data = {
            'tasks': [
                InputData(test['action'], test['args'], test.get('block', {}))
            ]
        }

        # unmarshall and validate
        assert isinstance(IncludeRole.load(data, role=role), IncludeRole)

    # role object
    role = Role()

    # test cases

# Generated at 2022-06-11 10:54:08.284620
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:54:18.902067
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import tempfile
    from collections import namedtuple

    #  IncludeRole.get_block_list depends on two other Ansible modules,
    #  ModuleUtils and LookupModule.
    #  Because of the way testinfra is setup, we can't import them from
    #  the ansible source code.
    #  To test IncludeRole.get_block_list, we will mock those two modules
    #  so that we can focus on testing IncludeRole.get_block_list.

    #  Mock ModuleLoader for testing IncludeRole.get_block_list.
    #  Params 'module_utils_loader' and 'module_loader' are used
    #  to mock LookupModule.

# Generated at 2022-06-11 10:54:52.131631
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()

    pb = Playbook().load('tasks/include_role.yml', variable_manager=variable_manager, loader=loader)

    pbex = PlaybookExecutor(playbooks=[pb], inventory=None, variable_manager=variable_manager, loader=loader,
                            options=None, passwords=None)

# Generated at 2022-06-11 10:54:59.428393
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        "name": "my_include_role",
        "role": "../my_role",
        "apply": {
            "tags": ["my_tag1", "my_tag2"],
            "when": "true",
        },
        "public": "true",
    }
    ir = IncludeRole.load(data)
    assert ir._role_name == "../my_role"
    assert ir.apply.tags == ["my_tag1", "my_tag2"]
    assert ir.apply.when == "true"
    assert ir.public == True

# Generated at 2022-06-11 10:55:09.522306
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """ The loader module can be tested by mocking a data structure and see if it can
    successfully load it back.
    """
    from ansible.playbook.role.include import IncludeRole

    data_param = """
     - include_role: '{{ foo }}'
       tasks_from: foo.yml
       vars_from: bar.yml
       apply:
         something: true
    """
    test_loader = DictDataLoader({})
    try:
        test_role = IncludeRole.load(data=data_param, variable_manager=DictDataManager(), loader=test_loader)
    except Exception:
        raise AnsibleParserError('Failed to test IncludeRole.load')

    # check the attrs of the IncludeRole
    assert test_role.action == 'include_role'

# Generated at 2022-06-11 10:55:19.088193
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    loader = Mock()
    loader.get_basedir = MagicMock(return_value='/path/to/task')

    play_context = Mock()
    play_context.connection = 'local'

    mock_play = Mock()
    mock_play.ROLE_CACHE = {}
    mock_play.ROLE_NAME_CACHE = {}
    mock_play.connection = 'local'

    mock_blk = Mock()
    mock_parent_role = Mock()
    mock_parent_role._role_cache_dir = '/path/to/role_cache'
    mock_parent_role._role_name = 'role_name'
    mock_parent_role._role_path = '/path/to/role'

# Generated at 2022-06-11 10:55:28.812885
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    block = Block()
    role = Role()

    data = {
        'name': 'bar',
        'role': 'foo',
        'public': True,
        'allow_duplicates': False
    }

    ir_1 = IncludeRole.load(data, block=block, role=role)
    assert ir_1._role_path is None
    assert ir_1._role_name == 'bar'
    assert ir_1._parent_role == role
    assert ir_1.private == True
    assert ir_1.action == 'include_role'
    assert ir_1.allow_duplicates == False
    assert ir_1.public == True

    data = {
        'name': 'bar',
        'role': 'foo',
        'allow_duplicates': False
    }


# Generated at 2022-06-11 10:55:36.105031
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-11 10:55:46.695250
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest

    from ansible.playbook.role.definition import RoleDefinition

    def _mock_get_role_definition(self, name):
        return None

    RoleDefinition._get_role_definition = _mock_get_role_definition

    data = dict(
        name='foo'
    )
    result = IncludeRole.load(data)

    assert result._role_name == 'foo'

    data = dict(
        name=dict(
            a=1
        )
    )
    with pytest.raises(AnsibleParserError) as err:
        result = IncludeRole.load(data)

    assert 'Expected a string for name but got' in str(err)

    data = dict(
        name='foo',
        apply=dict(
            a=1
        )
    )
   

# Generated at 2022-06-11 10:55:55.500745
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # nomenclature : O -> old, N -> new

    # parameter data
    data = {'tasks': 'tasks/main.yml', 'vars': 'vars/main.yml', 'handlers': 'handlers/main.yml', 'defaults': 'defaults/main.yml'}

    # parameter block
    block = Block(play=Play().load({}, variable_manager=VariableManager()), parent_role=None, role=None, task_include=None, use_handlers=False, always_run=False, any_errors_fatal=False, any_unreachable_fatal=False, no_log=False)

    # parameter role
    role = None

    # parameter task_include
    task_include = None

    # parameter variable_manager
    from ansible.vars import Variable

# Generated at 2022-06-11 10:56:06.382417
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    my_loader = DictDataLoader({})

    # Empty args
    args = {}
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(args)

    # Bad args
    args = {'blah_from': 'foo.yml'}
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(args)

    # Bad args
    args = {'allow_duplicates': 'foo'}
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(args)

    # Bad args
    args = {'rolespec_validate': 'foo'}
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(args)

    # Bad args

# Generated at 2022-06-11 10:56:07.262684
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:57:10.266007
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    data = {u'allow_duplicates': True,
            u'apply': {u'run_once': True},
            u'collections': [],
            u'hosts': u'localhost',
            u'name': u'prometheus',
            u'public': False,
            u'rolespec_validate': True,
            u'when': u'prometheus_install'}

    results = IncludeRole.load(data)
    assert results.name == u'prometheus'

# Generated at 2022-06-11 10:57:20.709652
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # create an inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])

    # create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a test Play

# Generated at 2022-06-11 10:57:30.295839
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    display.verbosity = 3
    loader = DataLoader()
    variable_manager = VariableManager()

    block = Block()
    role = Role()
    task_include = TaskInclude()
    task_include_role = IncludeRole(block, role, task_include)
    task_include_role._full_action = '- include_role: name=foo'
    task_include_role.name = 'include_role : foo'
    task_include_role.apply = {}
    task_include_role.rolespec_validate = True
    task_include_role.collections = []



# Generated at 2022-06-11 10:57:40.802385
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''verify that a IncludeRole object is properly constructed when
    given a valid task.
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))
    variable_manager.set_loader(loader)

    data = dict(
        name='test',
    )
    result = IncludeRole.load(data=data, variable_manager=variable_manager, loader=loader)

    assert result._role_name == 'test', "expected role name to be 'test'"
    assert result.module_args == {}, "expected no module args"

    data = dict

# Generated at 2022-06-11 10:57:51.117391
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    class VariableManager(object):
        def get_vars(self, play, task):
            return []
        def set_host_variable(self, host, varname, value):
            pass
    class Loader(object):
        def load_from_file(self, filename):
            if filename == 'tasks/main.yml':
                data = {
                    'tasks': [
                        {'action': 'setup'},
                    ]
                }
            else:
                data = {'n': 'v'}
            return data

# Generated at 2022-06-11 10:57:58.814964
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    with pytest.raises(AnsibleParserError):
        IncludeRole.load({})  # no name
    test_ib = IncludeRole.load({'name': 'test', 'role': 'test'}, block=Block([]))
    assert test_ib._role_name == 'test'
    # no bad_opt
    test_ib = IncludeRole.load({'name': 'test', 'role': 'test', 'bad_opt': True}, block=Block([]))
    assert test_ib._role_name == 'test'
    assert test_ib.args.get('bad_opt') is None
    # apply dict
    test_ib = IncludeRole.load({'name': 'test', 'role': 'test', 'apply': {}}, block=Block([]))
    assert test_ib.args.get('apply') == {}


# Generated at 2022-06-11 10:58:08.858044
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class FakeRole():
        def __init__(self):
            self._role_path = 'role_path'

    # test the global variables
    dummy_data = {'role': 'role_name'}
    variable_manager = 'variable_manager'
    loader='loader'

    # test the instance variables
    action = 'include_role'
    block = 'block'
    role = FakeRole()
    task_include = 'task_include'

    # create the instance for class IncludeRole
    include_role = IncludeRole(block, role, task_include=task_include)

    # assert the name filed
    assert include_role.get_name() == "include_role : role_name"

    # test the function load

# Generated at 2022-06-11 10:58:18.562099
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name = 'test',
        tasks_from = 'tasks/main.yml'
        )

    ir = IncludeRole.load(data)
    assert ir.name is None
    assert(ir.args == data)
    assert ir._role_name == 'test'
    assert ir._from_files == {'tasks': 'tasks/main.yml'}

    data = dict(
        name = 'test',
        tasks_from = 'main.yml'
        )

    ir = IncludeRole.load(data)
    assert ir.name is None
    assert(ir.args == data)
    assert ir._role_name == 'test'
    assert ir._from_files == {'tasks': 'main.yml'}


# Generated at 2022-06-11 10:58:23.808760
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = dict(
        name = AnsibleUnicode('test'),
        tasks_from = AnsibleUnicode('test.yml'),
        vars_from = AnsibleUnicode('test.yml'),
        handlers_from = AnsibleUnicode('test.yml'),
        defaults_from = AnsibleUnicode('test.yml'),
        apply = dict(when = AnsibleUnicode('yes')),
        public = True,
        allow_duplicates = True,
        rolespec_validate = True,
    )


# Generated at 2022-06-11 10:58:33.754056
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    IncludeRole: load
    """
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = None
    play_context = PlayContext()
    play_source = dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            roles = [
                dict(name = 'test1'),
                dict(name = 'test2')
            ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None