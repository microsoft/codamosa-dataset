

# Generated at 2022-06-11 10:49:56.776384
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'main_role_var': 'main_role_var'}
    variable_manager._inventory = InventoryManager(loader=loader, sources='localhost,')

    block = Block.load(dict(tasks=[]).copy(), play=None)

    role = Role()
    role._role_path = "main_role_path"
    role._metadata

# Generated at 2022-06-11 10:50:07.479915
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    # Test that include_role's load method raise error for
    # invalid options.
    data = dict(hosts="all", tasks=[{"include_role": "role_name", "bad_option": "bad_value"}])
    block = Block().load(data, [PlayContext()])
    ir = block.block[0]
    assert isinstance(ir, IncludeRole)

    try:
        ir.load(data, block, None, None, None, None)
        assert False, "Should have raised an exception"
    except AnsibleParserError as e:
        assert "Invalid options for include_role: bad_option" in str(e)

    # Test that include_role's load method raise error for
    # invalid 'when' value.

# Generated at 2022-06-11 10:50:16.757664
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test IncludeRole.get_include_params() without parent role
    ir1 = IncludeRole()
    expected_v1 = {}
    actual_v1 = ir1.get_include_params()
    assert sorted(expected_v1.keys()) == sorted(actual_v1.keys()), "Expected v1=%r but got v1=%r" % (expected_v1, actual_v1)

    # Test IncludeRole.get_include_params() with parent role
    ir2 = IncludeRole()
    ir2._parent_role = Role()
    ir2._parent_role.name = 'p_role_name'
    ir2._parent_role._role_path = 'p_role_path'

# Generated at 2022-06-11 10:50:24.975925
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = "name"
    assert ir.get_name() == "name"
    ir.name = None
    ir.args = {'role': "role"}
    assert ir.get_name() == "include_role : role", 'include_role : role'
    ir.action = "foo"
    assert ir.get_name() == "foo : role", 'foo : role'
    ir.action = "include_role"
    ir.args = {'name': "name"}
    assert ir.get_name() == "name", 'name'

# Generated at 2022-06-11 10:50:36.158045
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    variable_manager = None
    loader = None
    block = Block()
    role = Role()
    task_include = None
    # Test 1: args do not contain name or role
    data = "{'action': '- include_role: public: yes'}"
    try:
        include_role = IncludeRole.load(data, block, role=role, task_include=task_include, variable_manager=variable_manager, loader =loader)
    except AnsibleParserError:
        pass
    # Test 2: args contains public
    data = {'action' : '- include_role: name: foo'}
    try:
        include_role = IncludeRole.load(data, block, role=role, task_include=task_include, variable_manager=variable_manager, loader =loader)
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 10:50:39.691728
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(role = Role(name = "test_empty_role")).get_name() == "include_role : test_empty_role"
    assert IncludeRole(role = Role(name = "test_empty_role"), name = "Test name").get_name() == "Test name"

# Generated at 2022-06-11 10:50:44.477539
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    ir._role_name = 'include_role_name'
    assert ir.get_name() == "include_role : include_role_name"


# Generated at 2022-06-11 10:50:56.090599
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    # Set IncludeRole options
    name = "name"
    role_name = "role_name"
    tasks_from = "tasks_from"
    vars_from = "vars_from"
    defaults_from = "defaults_from"
    handlers_from = "handlers_from"
    apply = {"apply": ""}
    public = True
    allow_duplicates = True
    rolespec_validate = True

# Generated at 2022-06-11 10:51:05.126256
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    x = IncludeRole.load({'name': 'myrole'})
    assert x._role_name == 'myrole'

    y = IncludeRole.load({'role': 'myrole'})
    assert y._role_name == 'myrole'

    with pytest.raises(AnsibleParserError):
        # name is needed, or use role as alias
        a = IncludeRole.load({})

    with pytest.raises(AnsibleParserError):
        # name is needed, or use role as alias
        b = IncludeRole.load({'name': None})

    with pytest.raises(AnsibleParserError):
        # name is needed, or use role as alias
        c = IncludeRole.load({'role': None})


# Generated at 2022-06-11 10:51:14.191037
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class DataObj:

        def __init__(self, data):
            self._data = data

        def __getitem__(self, key):
            return self._data[key]

        def __getattr__(self, key):
            return self._data[key]

        def __str__(self):
            return "ObjStr"

        def __repr__(self):
            return "ObjRepr"

    data = DataObj({
        "include_role": {
            "name": "foobar"
        }
    })

    assert IncludeRole.load(data)

# Generated at 2022-06-11 10:51:37.555486
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.verbosity = 4
    display.debug("Test get_block_list()")
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    ###################################################################################################################
    #
    #   IncludeRole.get_block_list()
    #
    ###################################################################################################################
    # test 1:
    role_definition = RoleDefinition.load(dict(name='test_role_0'))
    playbook_include_role = IncludeRole.load(dict(name='test_role_0'))

# Generated at 2022-06-11 10:51:47.413384
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Ansible 2.9.0-2.9.2
    # ---
    # file: test.yml
    # ---
    # # tasks file for test.yml
    # - debug:
    #     msg: hello world
    # - include_role:
    #     name: foo
    #     allow_duplicates: false
    #     apply:
    #     - test.yml
    #     public: false
    #     rolespec_validate: true
    #     tasks_from: bar
    #     vars_from: bar
    #     defaults_from: bar
    #     handlers_from: bar
    raise NotImplementedError

# Generated at 2022-06-11 10:51:53.308830
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    p = PlayContext(variable_manager=None, loader=None)
    yaml_data = {"- include_role": {"name": "foo", "tasks_from": "bar"}}
    block = Block.load(yaml_data, play=p)
    t = block.block[0]
    assert t._role_name == "foo"
    assert t._from_files == {"tasks": "bar"}


# Generated at 2022-06-11 10:52:04.248819
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # "name" is a required field
    # missing name
    data = dict(
        action='include_role'
    )

    # load
    try:
        block = IncludeRole.load(data=data, role=None, task_include=None, variable_manager=None, loader=None)
    except AnsibleParserError as e:
        assert 'is a required field' in str(e)
    else:
        assert False, "missing name field passes IncludeRole.load()"

    # ---

    # "name" or "role" is a required field
    # missing name and role
    data = dict(
        action='include_role'
    )

    # load

# Generated at 2022-06-11 10:52:15.718117
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'name': 'role_name',
        'tasks_from': 'role_name/tasks/main.yml',
        'vars_from': 'role_name/vars/main.yml',
        'defaults_from': 'role_name/defaults/main.yml',
        'handlers_from': 'role_name/handlers/main.yml',
        'allow_duplicates': True,
        'public': True,
        'tag': ['tag1', 'tag2'],
        'apply': {
            'tags': 'tag3'
        }
    }

    # Test 1
    # Test with normal params
    test_obj = IncludeRole.load(data)
    assert test_obj.name == 'role_name'

# Generated at 2022-06-11 10:52:28.604034
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    
    # Test variables
    role = 'testRole'
    variable_manager = None
    loader = None
    file_name = 'test_file'
    rolespec_validate = True
    allow_duplicates = False
    public = False
    apply = dict(all=dict(a=1))

    # Test input
    data = dict(name=role,
                file=file_name,
                allow_duplicates=allow_duplicates,
                public=public,
                rolespec_validate=rolespec_validate,
                apply=apply)

    # Test output
    blocks = [Block()]
    handlers = [Block()]

    # Test object
    ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)

    # Test function call
    assert blocks == ir

# Generated at 2022-06-11 10:52:38.438385
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # setup objects required for execute
    test_block = Block()
    test_block.vars.update({
        'name': 'test_role',
        'a': '1',
        'b': '2',
        'c': '3',
        'd': '4',
        'e': '5',
        'f': '6',
        'g': '7',
        'h': '8',
        'i': '9',
        'j': '10',
        'k': '11',
        'l': '12',
        'm': '13',
        'n': '14',
        'o': '15',
    })

    # Run code to be tested
    ir = IncludeRole.load(data=test_block, block=test_block)

    # Make assertions

# Generated at 2022-06-11 10:52:48.163464
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    module = None
    block = Block()
    role = Role()
    task_include = None
    variable_manager = None
    loader = None

    # load without 'name'
    data = {'tasks': [], 'include_tasks': 'tasks/main.yml', 'vars': {}, 'include_vars': {}}
    try:
        IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    except Exception as e:
        assert 'is a required field for include_role' in str(e)

    # load without 'role'
    data = {'tasks': [], 'include_tasks': 'tasks/main.yml', 'vars': {}, 'include_vars': {}}

# Generated at 2022-06-11 10:52:48.789074
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:52:50.207471
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Unit test for method load of class IncludeRole
    '''

    return True

# Generated at 2022-06-11 10:53:04.117783
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:53:10.432308
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    action = 'include_role'
    args = {}
    items = [
        'vmware_guest',
        '/Users/test/test.yml',
        'test_role'
    ]

    for item in items:
        try:
            ir = IncludeRole(block=Block(), role=Role())
            ir.name = item
            name = ir.get_name()
            assert name == item
        except AssertionError:
            ir = IncludeRole(block=Block(), role=Role())
            ir.args['name'] = item
            name = ir.get_name()
            assert name == "%s : %s" % (action, item)

# Generated at 2022-06-11 10:53:16.221562
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook

    # Fixtures
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from units.compat.mock import patch, MagicMock, PropertyMock

    loader = DataLoader()
    variable_manager = VariableManager()

    # Mock get_block_list from role.Role
    block_list = [
        Block([
            Task.load({
                'action': {
                    'module': 'ping',
                }
            })
        ])
    ]
    role_mock = MagicMock()

# Generated at 2022-06-11 10:53:23.939145
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test IncludeRole.load with bad data
    data = dict(name='test', role='test')
    try:
        IncludeRole.load(data)
    except AnsibleParserError as e:
        assert 'is a required' in str(e)

    # test IncludeRole.load with good data
    data = dict(name='test', role='test', tasks='tasks/main.yml')
    IncludeRole.load(data)

    # test IncludeRole.load with extra subdirectories
    data = dict(name='test', tasks='tasks/main.yml')
    IncludeRole.load(data)

# Generated at 2022-06-11 10:53:33.134189
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ''' Test get_include_params method of class IncludeRole '''

    def _ir_get(instance):
        ''' return params of the include role instance that are uniquely added by get_include_params method '''
        ir_params = instance.get_include_params()
        for p in ('ansible_role_name', 'ansible_role_path',
                  'ansible_parent_role_names', 'ansible_parent_role_paths'):
            del ir_params[p]
        return ir_params

    # create parent role and populate ansible_parent_role_names and ansible_parent_role_paths
    parent_role = Role()
    parent_name = 'parent'
    parent_path = 'parent/path'
    parent_role._metadata.name = parent_name

# Generated at 2022-06-11 10:53:43.861363
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test when name and role are null
    ir = IncludeRole()
    ir.action = 'action'
    ir._role_name = None
    assert ir.get_name() == 'action : None'

    # Test when name is null and role is not null
    ir = IncludeRole()
    ir.action = 'action'
    ir._role_name = 'role'
    assert ir.get_name() == 'action : role'

    # Test when name is not null and role is null
    ir = IncludeRole()
    ir.action = 'action'
    ir.name = 'name'
    ir._role_name = None
    assert ir.get_name() == 'name'

    # Test when name is not null and role is not null
    ir = IncludeRole()
    ir.action = 'action'
    ir.name

# Generated at 2022-06-11 10:53:54.578646
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.task import Task
    
    # Instantiate a Play
    play_1 = Play()
    play_1._variable_manager = None
    play_1._loader = None

    # Instantiate a Role
    role_meta_1 = RoleMeta()
    role_meta_1.name = "role_1"
    role_1 = Role()
    role_1._metadata = role_meta_1
    role_1._role_path = "/path/to/role_1"
    role_1._tasks_block = Block()
    role_1._parent = play_1
    role

# Generated at 2022-06-11 10:53:56.621413
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    include_role._role_name = 'test'
    assert include_role.get_name() == 'meta : test'


# Generated at 2022-06-11 10:53:57.819279
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass
    #TODO(craig)

# Generated at 2022-06-11 10:54:09.926969
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from .test_loader import DictDataLoader
    from .test_helpers import LoaderModuleMock

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    # Mocks
    class Connection:
        def __init__(self, conn_loader, tmp_path="", allow_executable=False):
            self.loader = conn_loader
            self.tmp_path = tmp_path
            self.allow_executable = allow_executable
    class Task:
        def __init__(self, task_loader, tmp_path="", allow_executable=False):
            self.loader = task_loader
            self.tmp_path = tmp_path
            self.allow_executable = allow_executable

# Generated at 2022-06-11 10:54:59.897009
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.utils.addresses import parse_address
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # Setup
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({},variable_manager=variable_manager, loader=loader)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play))

    # Test
    role_path = 'roles/storage/rbd'
    name='storage-rbd-pvc'

# Generated at 2022-06-11 10:55:00.564928
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:55:10.508997
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook

    # Build task include
    data = {
        'include_role': {
            'name': 'my_role_name'
        }
    }
    task_inc = ansible.playbook.TaskInclude.load(data)

    # Build block
    data = {
        'block': {
            'key1': 'val1',
            'key2': 'val2'
        }
    }
    block = ansible.playbook.Block.load(data)

    # Build role
    data = {
        'include_role': {
            'name': 'my_parent_role_name'
        }
    }
    parent_role = ansible.playbook.Role.load(data)
    parent_role._parents = []

# Generated at 2022-06-11 10:55:20.055035
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role

    mock_loader = object()
    mock_variable_manager = object()
    mock_play = object()

    block = Block(play=mock_play)
    task = Task()
    task_include = TaskInclude()

    role = Role()
    role.tasks = [[task, task_include]]
    role.handlers = [task, task_include]
    role._role_path = "/roles/foo"

    # NOTE: templar is a private attribute of the class
    task_include._templar = "test_templar"
    # NOTE: _parent is a private attribute of the

# Generated at 2022-06-11 10:55:29.772396
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    mock_play = Mock()
    mock_play.ROLE_CACHE = {}
    mock_play.collections = set()
    mock_play.role_collections = {}

    mock_var_man = Mock()
    mock_loader = Mock()

    def def_mock_load(filename, *args, **kwargs):
        class MockRoleSpec:
            def __init__(self, **kwargs):
                self.tasks_path = kwargs.get('tasks_path')
        return MockRoleSpec(**kwargs)

    mock_loader.load_from_file.side_effect = lambda x, *args, **kwargs: def_mock_load(x, *args, **kwargs)


# Generated at 2022-06-11 10:55:34.853814
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert IncludeRole.load(dict(include_role='test1'), block=Block())
    assert IncludeRole.load(dict(include_tasks='test2'), block=Block())
    assert IncludeRole.load(dict(import_role='test3'), block=Block())
    assert IncludeRole.load(dict(include='test4'), block=Block())
    assert IncludeRole.load(dict(import_tasks='test5'), block=Block())

# Generated at 2022-06-11 10:55:44.912402
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host, Group
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play_context = PlayContext(remote_user='root', become=True)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(include_role=dict(name='example-role'))),
            ]
        )

# Generated at 2022-06-11 10:55:54.506872
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from types import MethodType
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    fake_loader = {}
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    fake_play_context = PlayContext(fake_variable_manager, fake_loader)
    fake_play = Play().load({}, variable_manager=fake_variable_manager, loader=fake_loader)
    fake_block = Block()

    ######################################################################
    # fake Role
    class Role:
        def __init__(self):
            self._metadata = {}
            self

# Generated at 2022-06-11 10:56:03.615269
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Runs tests on IncludeRole.load() to ensure that it returns the correct object
    type and accepts values of allowed types
    """
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    imp_loader = DataLoader()
    from ansible.vars import VariableManager
    variable_manager = VariableManager()

    t = Task()
    t.action = 'include_role'

    data = "test"

    ir = IncludeRole.load(data, block=t, task_include=None, variable_manager=variable_manager, loader=imp_loader)
    assert isinstance(ir, IncludeRole)


# ===========================

# Generated at 2022-06-11 10:56:14.602341
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    loader = None
    variable_manager = None
    play = None
    from collections import namedtuple
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    TaskInclude = namedtuple('TaskInclude', ['action', 'block', 'args', 'statically_loaded', 'vars'])

# Generated at 2022-06-11 10:57:19.268547
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.six import PY3

    if not PY3:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf8')

    # Load inventory
    inventory = InventoryManager()
    inventory.load_inventory(inventory)
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Load play context
    context = PlayContext()

    # Construct a task
    data = dict()
    data['name'] = 'test'
    data['action'] = 'include_role'
    data['args'] = {}
    data['args']['name'] = 'test'

    # Initialize

# Generated at 2022-06-11 10:57:29.105704
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.task import Task

    # Setup
    task_data = dict(name='task1', action="shell", args="echo 1")

    task = Task.load(task_data)

    block_data = dict(tasks=[task])

    parent_block = Block.load(block_data, play=None)

    include_role_data = dict(name="role.name", public=True)

    include_role = IncludeRole.load(include_role_data, block=parent_block, role=None, task_include=None)

    # Mocking Block.compile (it's private)
    def mock_compile(self, play=None, dep_chain=None):
        return [task]

    Block.compile=mock_compile

    # Mocking Role.compile (it's private)

# Generated at 2022-06-11 10:57:38.666680
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import ansible.utils.vars as vars_util

    display.verbosity = 3

    #
    #   Prepare unit test
    #
    some_include_role = IncludeRole(role=None)

    #
    #   Begin unit test
    #
    display.display("\n---\nPERFORM UNIT TEST: IncludeRole.get_block_list()")

    #
    #   Test case 1:
    #   Check that block list is empty when there is no play set
    #
    display.display("\n***\nTest case 1: Check that block list is empty when there is no play set")

# Generated at 2022-06-11 10:57:49.668868
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    test_block = Block()
    test_block._role = Role()

    test_task = IncludeRole(block=test_block)

    # test missing name
    test_data = {'include_role': None}
    try:
        test_task.load(data=test_data)
    except AnsibleParserError as e:
        assert e.message == "'name' is a required field for include_role."
    else:
        assert False

    test_data = {'include_role': {'name': 'my_role'}}
    r = test_task.load(data=test_data)
    assert isinstance(r, IncludeRole)
    assert r._allow_duplicates is True
    assert r._from_files == {}
    assert r._public is False

# Generated at 2022-06-11 10:57:57.954599
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
  """
  Run a simple unit test for class IncludeRole's get_block_list method
  """
  import os
  import sys
  import unittest
  from ansible.playbook.play import Play
  from ansible.inventory import Inventory
  from ansible.vars.manager import VariableManager
  from ansible.parsing.dataloader import DataLoader

  class TestIncludeRoleGetBlockList(unittest.TestCase):
    """
    Test the get_block_list method of class IncludeRole
    """

    def setUp(self):
      """
      Set up the unittest.
      """
      self.loader = DataLoader()
      self.inventory = Inventory(self.loader, {})
      self.variable_manager = VariableManager()


# Generated at 2022-06-11 10:58:08.125175
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    role_path = './tests/unit/roles/basic_role'
    loader = DictDataLoader({role_path: ''})
    variable_manager = VariableManager()
    # the play would be needed if load() is invoked while parsing a dynamic include
    play = Play.load({'name': 'test_play'}, loader=loader, variable_manager=variable_manager)

    block = Block()
    parent_role = Role.load(dict(name='foo', tasks={'meta': {'vars': {'foo_var': 'FooVAr'}}}),
                            variable_manager=variable_manager, loader=loader)
    variable_manager.set_nonpers

# Generated at 2022-06-11 10:58:15.488234
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # prep code
    loader = None
    variable_manager = None

    # make data
    data = dict(
        name='test',
    )

    # prep code
    block = Block()
    role = Role()
    task_include = None

    # run code to be tested
    result = IncludeRole.load(data, block, role, task_include, variable_manager, loader)

    # make expected
    expected = IncludeRole(block=block, role=role, task_include=task_include)
    expected.name = 'test'
    expected._role_name = 'test'

    # assert equal
    assert result == expected



# Generated at 2022-06-11 10:58:26.008972
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Testcase 1
    # When _role_name is not passed in IncludeRole
    from ansible.playbook import Playbook

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager

    from ansible.module_utils.six import string_types

    if not isinstance('_role_name', string_types):
        raise AnsibleParserError("'_role_name' is a required field for %s." % 'Role')

    # Testcase 2
    # When 'args' is not passed in IncludeRole

# Generated at 2022-06-11 10:58:35.700043
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display = Display()
    _loader = None
    _variable_manager = None
    _block = Block(parent_block=None, role=None, task_include=None, use_handlers=False, always_run=False, loop=None)
    _task_include = TaskInclude(task=None, block=_block, role=None, task_include=None)
    _include_role = IncludeRole(block=_block, role=None, task_include=_task_include)

    _include_role._role_name = 'includerole'

    _play = Play()

# Generated at 2022-06-11 10:58:42.050496
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block.load(dict(name='Test'), task_include=None, role=None, loader=None, variable_manager=None)
    import ansible.playbook.role.definition
    role = ansible.playbook.role.definition.RoleDefinition.load(dict(name='Test'))
    included_role = IncludeRole.load(dict(name='Test'), block, role)
    assert included_role
    task_list, handler_list = included_role.get_block_list()
    assert task_list