

# Generated at 2022-06-11 10:49:56.477047
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import strategy_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    import sys

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=('test/inventory/hosts', 'test/inventory/hosts'))
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:50:07.115668
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_role_name = 'TestRole1'
    test_role_tasks = [{'name': 'TestTask1', 'hosts': 'all'}]
    test_role_commands = [{'include': test_role_tasks}]
    test_role_data = {'name': test_role_name, 'tasks': test_role_commands}
    # build the role
    role = Role().load(test_role_data)

    test_blocks = [{'block': [
        {'rescue': []},
        {'always': []}]
    }]

    test_include_role_data = {'name': 'TestRole2', 'tasks_from': test_role_name}
    test_include_role = IncludeRole().load(test_include_role_data)

   

# Generated at 2022-06-11 10:50:16.583977
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    import ansible.utils.plugin_docs
    import ansible.constants as C

    data = {u'name': u'role_name'}
    loader = None
    play_context = PlayContext()
    variable_manager = None
    block = Block([])
    task_include = TaskInclude()
    task_include.action = C.INCLUDE_ROLE_NAME

    res = IncludeRole.load(data, block=block, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert res._role_name == u'role_name'

    task_include.action = C.INCLUDE_TASK_NAME


# Generated at 2022-06-11 10:50:17.284160
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:50:20.032332
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='test_IncludeRole_load',
        role='test_IncludeRole_load'
    )
    IncludeRole.load(data)
    # pass

# Generated at 2022-06-11 10:50:24.060455
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import unittest


    # TODO: implement test
    class TestIncludeRole(unittest.TestCase):

        def test_it(self):
            self.skipTest("Not implemented")

    unittest.main()

# Generated at 2022-06-11 10:50:27.158784
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = Role()
    ir = IncludeRole(role=role)
    ir._role_name = 'rolemock'
    assert ir.get_name() == 'role : rolemock'


# Generated at 2022-06-11 10:50:37.863462
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # normal
    data = dict(
        name="role_name",
        apply=dict(
            some_key="some_value",
        )
    )
    include_role = IncludeRole()
    include_role = include_role.load(data=data, variable_manager=VariableManager(), loader=None)
    assert include_role._role_name == data['name']
    assert include_role.some_key == data['apply']['some_key']

    # error case

# Generated at 2022-06-11 10:50:49.404578
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.parsing.mod_args import ModuleArgsParser

    # test bare with only a name
    data = dict(
        name='test_role',
    )
    ir = IncludeRole.load(data=data)
    assert isinstance(ir, IncludeRole)
    assert ir.name == 'test_role'
    assert ir._role_name == 'test_role'
    assert not ir._from_files

    # test all options

# Generated at 2022-06-11 10:51:00.345033
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext

    v = dict(
        ansible_play_hosts=['host1'],
        ansible_play_batch_size=5,
        ansible_play_hosts_all=['host1'],
        ansible_version={
            u'full': u'2.9.1',
            u'last_release_version': u'2.9.1',
            u'network_debug': False,
            u'sha': u'2e1e8868f885aa98f54e11a0d854e1917c9f7dac',
            u'version': u'2.9'
        },
        ansible_python_interpreter='/usr/bin/python',
        ansible_check_mode=False,
    )

# Generated at 2022-06-11 10:51:19.517435
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    import ansible.utils.vars as vars_mod
    import ansible.vars.manager
    import ansible.inventory.host
    import ansible.parsing.yaml.objects
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task

    task_vars = dict()
    play_context = PlayContext()

    # Create a host to use as inventory
    new_host = ansible.inventory.host.Host(name="myhost")
    new_host.vars = dict(ansible_connection="local")

    # Create inventory to use
    inventory = ansible.inventory.Inventory(host_list=[new_host])

    # Create variable manager to use

# Generated at 2022-06-11 10:51:27.217847
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


    ##########################################################################
    # Variables
    ##########################################################################

# Generated at 2022-06-11 10:51:34.538856
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # normal testing is done in integration tests
    # this is just to make sure the new attributes are setup correctly
    import ansible.playbook
    data = dict(
        apply=dict(a=1),
        name='test',
    )
    ir = IncludeRole.load(data=data)
    assert ir._apply == dict(a=1)
    assert ir._role_name == 'test'
    assert isinstance(ir, ansible.playbook.Base)

# Generated at 2022-06-11 10:51:46.116656
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class MockRole(Role):

        def __init__(self):
            super(MockRole, self).__init__()

    ir = IncludeRole()
    ir._role_name = 'name'
    assert ir.get_name() == 'include_role : name'
    ir._role_name = None
    assert ir.get_name() == 'include_role'
    ir._role_name = 'name'
    ir._parent_role = MockRole()
    ir._parent_role.name = 'parent name'
    assert ir.get_name() == 'parent name : name'
    ir._parent_role.name = None
    ir._parent_role._role_path = 'parent/path'
    assert ir.get_name() == 'parent/path : name'

# Generated at 2022-06-11 10:51:51.925679
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block_obj = Block()
    role_obj = Role()
    task_include_obj = TaskInclude()
    include_role_params = {'role': 'myrole'}
    include_role_obj = IncludeRole(block=block_obj, role=role_obj, task_include=task_include_obj).load_data(include_role_params)
    assert include_role_obj.get_include_params() == include_role_params


# Generated at 2022-06-11 10:52:02.917419
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.utils.vars import combine_vars

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play import Play

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            'test',
        ],
        tasks = [
            dict(
                action= 'include_role',
                name = 'test',
                args = dict(
                    tasks_from = 'main.yml',
                ),
            ),
        ],
    )

    inventory = InventoryManager(loader=None, sources=['localhost,'])

# Generated at 2022-06-11 10:52:14.651851
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Initializing test class objects
    test_module = IncludeRole()
    # Initializing dict data object for test case
    dict_data = dict (
                name = dict(type='str'),
                tasks_from = dict(type='str'),
                vars_from = dict(type='str'),
                defaults_from = dict(type='str'),
                handlers_from = dict(type='str'),
                apply = dict(type='dict'),
                public = dict(type='bool'),
                allow_duplicates = dict(type='bool'),
                rolespec_validate = dict(type='bool'),
                )

    # Validating the test case
    with pytest.raises(AnsibleParserError) as excinfo:
        test_module.load(dict_data)

    assert 'name' in str(excinfo.value)


# Generated at 2022-06-11 10:52:26.712623
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    data = dict(name='test_role')
    include_role = IncludeRole(block, role, task_include)

    include_role.load(data, block, role, task_include, variable_manager, loader)

    # check _from_files
    ir_from_files = include_role._from_files
    assert 'tasks' in ir_from_files
    assert 'handlers' in ir_from_files
    assert 'vars' in ir_from_files
    assert 'defaults' in ir_from_files

    # check _role_name
    assert include_role._role_name == 'test_role'


# Generated at 2022-06-11 10:52:37.072401
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # case 1: not parent role
    task = IncludeRole()
    params = task.get_include_params()
    assert 'ansible_parent_role_paths' not in params
    assert 'ansible_parent_role_names' not in params

    # case 2: parent role
    task._parent_role = Role()
    task._parent_role._role_name = "myrole"
    task._parent_role._role_path = "/tmp/myrole"
    params = task.get_include_params()
    assert 'ansible_parent_role_paths' in params
    assert 'ansible_parent_role_names' in params
    assert len(params['ansible_parent_role_paths']) == 1
    assert len(params['ansible_parent_role_names']) == 1

# Generated at 2022-06-11 10:52:44.026365
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.role

    class fake_vars(object):
        def get_vars(self, *args, **kwargs):
            return dict()

    class fake_playbook(object):
        def __init__(self):
            self.handlers = []
            self.roles = []

    class fake_loader(object):
        def __init__(self):
            self.foo = 'bar'

        def load_from_file(self, *args, **kwargs):
            return dict(foo='bar')

    class fake_role(Role):
        def __init__(self, role_name, role_path, parent_role=None):
            self._metadata = ansible.playbook.role.RoleMetadata(self)
            self._role_name = role_name
            self._role_

# Generated at 2022-06-11 10:53:07.313385
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-11 10:53:11.907560
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    path = './test/ansible/module_utils/ansible_test/_data/playbooks/include_role/playbook_include.yaml'
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    context = PlayContext()
    context._stdout_callback = display.display
    loader = DataLoader()
    passwords = dict(vault_pass='secret')

# Generated at 2022-06-11 10:53:17.327305
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Tests don't support mixed case, so we need to use lowercase characters
    # to test this method.
    #
    # The contents of the role 'test' are:
    #
    # - hosts: localhost
    #   connection: local
    #   gather_facts: false
    #   roles:
    #   - include_role:
    #     name: test
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.constants as C

    # add top level role dir and role via command line args
    C.config.set_config_attr('DEFAULT_ROLES_PATH', 'my_roles')

# Generated at 2022-06-11 10:53:27.454304
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """ Unit test for method get_block_list of class IncludeRole """
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    import ansible.constants as C
    import tempfile
    import shutil


# Generated at 2022-06-11 10:53:35.557269
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import tempfile
    import ansible.playbook.play_context
    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader, action_loader

    role = Role()
    role._role_path = '/home/user/test_role'

    # Build block to provide as argument of IncludeRole
    block = Block()
    block._play = Play()
    block._role = role

    task_include = TaskInclude()
    task_include._play = Play()
    task_include._role = role

    include_role = IncludeRole(block, role, task_include)
    include_role._role_name = 'test_role'

    ansible.playbook.play_context.CLIARGS = {}
    current_loader = ansible.plugins.loader.action_loader


# Generated at 2022-06-11 10:53:46.730259
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.plugins.loader as plugin_loader
    import os
    import unittest

    class FakeOptions:
        def __init__(self, verbose=False):
            self.verbose = verbose
            self.connection = 'local'

    def fake_get_config_data(self, play_context, path, vault_password=None, convert_data=False, expand_vars=False, runner_data=None):
        return None, None

    class FakePluginLoader(plugin_loader.PluginLoader):
        def __init__(self, class_name, package, config, subdir, aliases=None):
            if class_name is not None:
                self.package = package
                self.aliases = aliases
                self.base_class = 'ansible.plugins.loader.%s' % class_name

# Generated at 2022-06-11 10:53:56.682949
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from unittest import TestCase
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    import os

    class TestIncludeRole(TestCase):

        def setUp(self):

            block = Block()
            role = Role()
            task_include = TaskInclude()

            role_include = IncludeRole(block, role, task_include)
            role_include._role_name = 'RoleName'

            self.role_include = role_include

        def test_get_block_list_success(self):

            # Mock PlayContext and create templar
            variable_manager = VariableManager()
            variable_manager._

# Generated at 2022-06-11 10:54:07.880675
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Unit test for method get_block_list of class IncludeRole
    :return:
    """

    # Valid inputs
    block = Block()
    role = Role()
    task_include = TaskInclude()
    play = Play()

    # Invalid inputs
    # block = None
    role = None
    task_include = None
    play = None

    # Test function call
    include_role_obj = IncludeRole(block, role, task_include)
    include_role_obj.get_block_list(play)

    # Expected Output
    # blocks = []
    # handlers = []
    # play.roles = [<Role name="role1">]
    # play.handlers = [<Handler name="handler1">]



# Generated at 2022-06-11 10:54:18.633615
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys
    import types

    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task

    block = Block(
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        role_params={},
        static_vars={},
        unscale_vars={},
        task_vars={},
        play_context={},
        play=None,
    )
    block.vars = {
        'item': {
            'key': 'value',
            'key2': 1,
        },
    }
    block.collections = {'collections': True}
   

# Generated at 2022-06-11 10:54:28.489136
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Unit test for method load of class IncludeRole
    '''

    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # set up
    data = dict(
        include_role=dict(
            name='myrole',
            tasks_from='./tasks/main.yml',
            vars_from='./vars/main.yml',
            defaults_from='./defaults/main.yml',
            handlers_from='./handlers/main.yml',
            apply=dict(
                meta=dict(
                    foo='bar',
                ),
                tags='mytag',
                when='mywhen',
                allow_duplicates=False,
            )
        )
    )
    role = Role()
    role._role_

# Generated at 2022-06-11 10:55:06.224182
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    for opt in IncludeRole.VALID_ARGS:
        ir = IncludeRole()
        data = dict(foo='bar', bam='boom', name='some.role')
        data[opt] = 'some.value'
        ir.load(data=data, variable_manager=None, loader=None)
        assert 'name' in ir.args, 'name not present in %s' % ir.args

    # from files
    ir = IncludeRole()
    data = dict(foo='bar', bam='boom', name='some.role', tasks_from='/my/tasks/main.yml')
    ir.load(data=data, variable_manager=None, loader=None)
    assert 'name' in ir.args, 'name not present in %s' % ir.args
    assert 'tasks' in ir._

# Generated at 2022-06-11 10:55:15.671603
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import ansible.constants as C

    # We need a role that has a 'tasks' directory with a main.yml file.
    # For testing purposes, we'll just pass in that path and use that as a test.
    # The first two args below are just dummy args to Playbook().
    pb = Playbook.load([], [], [], loader=C.DEFAULT_LOADER)

    # We need to create a block and a role since we need to pass those as args to IncludeRole.load().
    # We need to create a block so that we can create a task, which gets passed as an arg to IncludeRole.load().
    # We need a task so that we can have a 'name

# Generated at 2022-06-11 10:55:16.315880
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:55:25.639904
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # To ease testing, create a fake *_callback variable
    import ansible.utils.plugin_docs as plugin_docs

    plugin_docs.Callbacks = {}
    plugin_docs.ACTION_CALLBACK_PLUGINS = {}
    plugin_docs.CACHE_MODULES = {}
    plugin_docs.STRATEGY_CALLBACK_PLUGINS = {}
    plugin_docs.TERM_MODULES = {}
    plugin_docs.NETCONF_MODULES = {}
    plugin_docs.DEFAULT_CACHE_PLUGIN = None
    plugin_docs.EVERY

# Generated at 2022-06-11 10:55:27.760505
# Unit test for method load of class IncludeRole

# Generated at 2022-06-11 10:55:30.397586
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task_include = IncludeRole()
    task_include.name = "name of task"
    task_include._role_name = "name of role"
    assert task_include.get_name() == "name of task : name of role"

    task_include.name = None
    assert task_include.get_name() == "include_role : name of role"

# Generated at 2022-06-11 10:55:36.861590
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext

    ir = IncludeRole()
    ir._parent_role = Role()
    ir._parent_role._role_params = dict(
        ansible_parent_role_names=['parent_role_name'],
        ansible_parent_role_paths=['top_role_path', 'parent_role_path']
    )
    ir._parent_role.name = 'child_role_name'
    ir._parent_role._role_path = 'child_role_path'

    include_params = ir.get_include_params()

    assert len(include_params) == 2
    assert include_params['ansible_parent_role_names'] == ['parent_role_name', 'child_role_name']

# Generated at 2022-06-11 10:55:46.281526
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''Unit Test for method load of class IncludeRole'''

    blk = Block()
    data = dict(apply=dict(a_f=dict(a=11, b=22)))
    ir = IncludeRole.load(data, block=blk)
    #print(ir._from_files)
    #print(ir._parent_role)
    #print('#' * 40)
    #print(ir._role_name)
    #print(ir._role_path)
    #print(ir._task_include.path)
    assert ir._role_name is None
    assert ir._role_path is None

if __name__ == "__main__":
    test_IncludeRole_load()

# Generated at 2022-06-11 10:55:55.317334
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.test.unit.test_ansible_playbook_test as apt
    # import ansible.playbook.test.unit.test_ansible_playbook_objects as apo
    # import ansible.playbook.play_context
    # import ansible.playbook.task_include
    # import ansible.playbook.role.role
    # import ansible.playbook.role.include
    # import ansible.playbook.role.definition
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.meta import RoleMetadata
    import ansible.plugins
    import os

    ri = None

    mock_vars = {}
    mock_loader = apt.MockFileLoader({})

# Generated at 2022-06-11 10:56:06.044458
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    fake_loader = None
    fake_variable_manager = None
    fake_play = FakePlay()

    #===========================
    # No role name specified
    #===========================

    # Create an IncludeRole object
    include_role = IncludeRole(block=None, role=None, task_include=None)

    # Call get_block_list:
    try:
        blocks, handlers = include_role.get_block_list(
            play=fake_play,
            variable_manager=fake_variable_manager,
            loader=fake_loader)
        # Should have raised an exception
        assert False, 'Should have been an exception'
    except Exception as e:
        # Expected error message
        expected_error_msg = "'name' is a required field for include_role."

        # Check that the exception message is as expected
       

# Generated at 2022-06-11 10:57:49.215663
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class MockPlaybook(object):
        def __init__(self):
            self.handler_list = []
            self.roles = []

    class MockRole(object):
        def __init__(self):
            self._handlers_loaded = []
            self._tasks_loaded = []
            self.handlers = []
            self.tasks = []

    class MockBlock(object):
        def __init__(self):
            self.name = "block_name"

    class MockVariableManager(object):
        def get_vars(self, play, task):
            return {}

    class MockLoader(object):
        def get_basedir(self, host, task, **kwargs):
            return None

    class MockTemplar(object):
        def template(self, data):
            return {}


# Generated at 2022-06-11 10:57:57.692163
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.plugin_docs import get_docstring
    from ansible.parsing.dataloader import DataLoader

    class InfraIncludeRole():
        def __init__(self, block=None, role=None, task_include=None):
            self.block = block
            self.role = role
            self.task_include = task_include


# Generated at 2022-06-11 10:58:07.866647
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ...common.unit.mock import mock_loader
    from ...common.unit.mock import mock_plugins
    from ...common.unit.mock import patch

    loader = mock_loader()
    plugins = mock_plugins(loader=loader)
    play = []
    path = 'path'
    role = Role()
    role._role_name = "role"
    role._role_path = path

    # test with a dict argument
    data = dict(
        name="role_name",
        _role_name="role_name",
        _role_path="role_path",
    )
    with patch.dict(plugins, {'action': 'action'}):
        include_role = IncludeRole(role=role)
        include_role.load(data, role=role)
        assert include_role._from_files

# Generated at 2022-06-11 10:58:10.471191
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # create IncludeRole object
    # create variables
    # create loader
    # create variable manager
    # create play
    # call get_block_list(include_block, play, variable_manager, loader)
    pass

# Generated at 2022-06-11 10:58:20.346439
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class MyMockOptions(object):
        verbosity = 0
        inventory = None
        listhosts = None
        subset = None
        module_paths = None
        extra_vars = []
        ask_vault_pass = None
        vault_password_files = []
        new_vault_password_file = None
        output_file = None
        default_vars = None
        connection = 'local'
        timeout = 10
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None

# Generated at 2022-06-11 10:58:25.153154
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        include_role=dict(
            name="some_role"
        )
    )
    block = Block()
    role = Role()
    ir = IncludeRole.load(data, block=block, role=role)
    assert ir._role_name == "some_role"
    assert ir.vars == {}



# Generated at 2022-06-11 10:58:34.857752
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block().load({'tasks':[]}, None, None)
    include_role = IncludeRole(block=block)
    display.vvv("========== test IncludeRole_get_block_list ==========")
    _available_variables = {
        'ansible_version': {
            'git_commit': '83578b2',
        },
        'ansible_config': {
            'DEFAULT_ROLES_PATH': '/etc/ansible/roles',
            'ROLES_PATH': '/etc/ansible/roles',
        },
    }

# Generated at 2022-06-11 10:58:38.524297
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole().get_name() == 'include_role'
    assert IncludeRole(role='foo').get_name() == 'include_role: foo'
    assert IncludeRole(role='foo', name='bar').get_name() == 'bar'

# Generated at 2022-06-11 10:58:39.125106
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:58:46.432732
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'var1': 'ansible'}
    inventory = InventoryManager(loader=loader, sources=[u'source1'])
    variable_manager.set_inventory(inventory)

    # Test the load() function
    res = IncludeRole.load({'include_role': {'name': 'nonexisting'}}, loader=loader, variable_manager=variable_manager)
    assert(res is None)
