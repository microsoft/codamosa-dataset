

# Generated at 2022-06-11 10:49:59.629602
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    display.verbosity = 3

    block = Block()
    role = Role()
    task = TaskInclude()

    assert hasattr(IncludeRole, '_allow_duplicates')
    assert hasattr(IncludeRole, '_public')
    assert hasattr(IncludeRole, '_rolespec_validate')

    # Test 'name' required
    data = dict(
        block=block,
        role=role,
        task_include=task,
    )
    with pytest.raises(AnsibleParserError):
        ir = IncludeRole.load(data, **data)

    # Test invalid option

# Generated at 2022-06-11 10:50:10.664492
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

    play_source = dict(
        name="Ansible Play",
        hosts='webservers',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args='msg="{{role_name}} is the name of the role"'), register='debug_result'),
        ]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)

    block1 = Block

# Generated at 2022-06-11 10:50:13.994069
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    l = IncludeRole()
    with pytest.raises(AnsibleParserError) as execinfo:
        l.get_block_list(None, None, None)
    assert 'is a required field' in str(execinfo.value)

# Generated at 2022-06-11 10:50:15.609079
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    results = {}
    results['include_params'] = IncludeRole().get_include_params()
    return results

# Generated at 2022-06-11 10:50:26.805991
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import sys
    if sys.version_info[0] > 2:
        unicode = str
    from ansible.playbook.play import Play

    ir = IncludeRole()
    ir.name = "name_of_task"
    ir._role_name = "name_of_role"

    template = Unicode(ir.get_name())
    assert template == "name_of_task : name_of_role"

    ir.name = None

    template = Unicode(ir.get_name())
    assert template == "include_role : name_of_role"

    ir.name = "name_of_task"
    ir._role_name = None

    template = Unicode(ir.get_name())
    assert template == "name_of_task : None"

    ir.name = None


# Generated at 2022-06-11 10:50:37.627463
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.block import Block

    # instantiate objects for method load of class IncludeRole
    # kwargs = {'test': 'test data'}
    # obj = IncludeRole(**kwargs)
    dataloader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=dataloader, sources=[])

# Generated at 2022-06-11 10:50:49.156307
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    ########################################################################################
    # Example

    include_example = dict(
        name='Nginx'
    )

    var_manager = None
    loader = None
    play, role, task_include = None, None, None

    ########################################################################################

    # error checking

    #######
    # 1. without name
    data = dict()
    irl = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert irl._role_name is None
    assert irl.args['name'] is None
    #######
    # 2. with name
    data = dict(include_example)
    irl = IncludeRole

# Generated at 2022-06-11 10:50:56.341328
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.role.main import Role
    from ansible.playbook.role_include import RoleInclude

    data = dict(
        name="my-role",
        apply=dict(
            a=1,
            b=2,
        ),
    )

    r = Role()
    ir = IncludeRole.load(data, role=r)

    assert ir._role_name == "my-role"
    assert ir.apply == dict(a=1, b=2)



# Generated at 2022-06-11 10:51:05.244921
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    import ansible.utils.vars as utils_vars
    import ansible.playbook.play as play
    import ansible.playbook.block as block
    import ansible.playbook.file_based_object as file_based_object
    utils_vars.AnsibleVarsModule.set_default_aggregate_vars_type('yaml')
    display.verbosity = 3

    # Test 1: Test with all arguments

# Generated at 2022-06-11 10:51:17.403320
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play

    # test case 1
    InRole = IncludeRole(
        role=Role(
            name="test",
            tasks=[],
            handlers=[],
            vars={},
            default_vars={},
            meta={}),
        from_files={'tasks': 'main.yml', 'handlers': 'handlers/main.yml'},
        _parent=Block([], [], [], [], []),
    )
    # test case 2

# Generated at 2022-06-11 10:51:37.726974
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import pytest

    fake_loader = DataLoader()

    yaml_data = dict()

# Generated at 2022-06-11 10:51:49.162720
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # set up the object
    loader = DictDataLoader({
        "test_role": dict(
            default_vars=dict(
                one=1, two=2, three=3, four=4, five=5,
            ),
            tasks=dict(
                main=dict(
                    block=dict(
                        block=dict(
                            tasks=dict(
                                main=dict(
                                    debug=dict(msg="Hello world!"),
                                )
                            )
                        )
                    )
                )
            )
        )
    })
    variable_manager = VariableManager()

    # the attributes of the object
    block = Block()
    role = Role()
    task_include = TaskInclude()

    # the args to load

# Generated at 2022-06-11 10:51:55.759590
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    block = Block()
    role = Role()
    task_include = None
    data = dict(
        name='name',
        apply=dict(),
        allow_duplicates=True,
        handlers_from='handlers_from',
        tasks_from='tasks_from',
        vars_from='vars_from',
        when='when'
    )
    myobj = IncludeRole.load(data=data, block=block, role=role, task_include=task_include)
    assert myobj.name == 'name'
    assert myobj.action == 'include_role'
    assert myobj.allow_duplicates == True

# Generated at 2022-06-11 10:52:07.091314
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # first, a simple passing test
    data = dict(
        name="test",
        apply=dict(
            a=1,
            b=2
        )
    )
    ir = IncludeRole.load(data, block=Block(), role=None, task_include=None)
    assert ir._from_files == {}
    assert ir._parent_role is None
    assert ir._role_name == "test"
    assert ir._role_path is None
    assert ir.allow_duplicates == True
    assert ir.public == False
    assert ir.rolespec_validate == True

    assert ir.args == {'apply': {'a': 1, 'b': 2}, 'name': 'test'}

    # now, a simple failing test

# Generated at 2022-06-11 10:52:17.365035
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.inventory.host import Host   # WORKAROUND
    data = dict(
        name="rolename",
        tasks_from="../../main.yml"
    )
    data_result = IncludeRole.load(data)

    assert data_result.statically_loaded
    assert data_result._allow_duplicates
    assert not data_result._public
    assert data_result._rolespec_validate
    assert data_result._from_files == {"tasks": "../../main.yml"}
    assert data_result._role_name == "rolename"
    assert data_result._role_path is None
    assert isinstance(data_result._role, Role)
    assert data_result._role_context == {}
    assert data_result._loader is None

# Generated at 2022-06-11 10:52:30.566722
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook import Play
    from ansible.playbook import Playbook
    from ansible.playbook.role import Role
    from collections import namedtuple
    import json

    pb = Playbook.load('test/playbooks/include_role.yml', variable_manager={'env': 'dev'})
    play = pb.get_plays()[0]
    task_data = json.loads(play.serialize())['tasks'][0]
    task = IncludeRole.load(task_data, play=play, variable_manager={'env': 'dev'}, loader=pb._loader)
    assert task._role_name.startswith('test_include_role_')
    assert task._parent_role.get_name() == 'test_role_inclusion'

# Generated at 2022-06-11 10:52:39.914065
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    Display().verbosity = 4
    block = Block()
    role = Role()
    role.name = 'role'
    task_include = TaskInclude()
    task_include.action = 'action'
    task_include.__dict__['_role_name'] = 'role_name'
    x = IncludeRole(block, role, task_include)
    assert x.get_name() == 'role_name'
    task_include.name = 'name'
    x = IncludeRole(block, role, task_include)
    assert x.get_name() == 'name'
    x = IncludeRole(block, role, task_include)
    assert x.get_name() == 'name'
    task_include.name = None
    x = IncludeRole(block, role, task_include)
    assert x.get_name

# Generated at 2022-06-11 10:52:50.116987
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role import Role
    from ansible.plugins.loader import role_loader
    from units.mock.loader import DictDataLoader

    role_data = dict(
        name="test_role",
        include_role=dict(
            name="include_role_test",
            tasks_from="tasks/main.yml"
        )
    )

# Generated at 2022-06-11 10:52:59.375076
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.definition import RoleDefinition

    # setup
    r = RoleDefinition.load({'name': 'test_role'})
    ir = IncludeRole.load({'name': 'test_include'}, block=r)
    r.add_child_block(ir)
    # run
    v = ir.get_include_params()
    # assert
    assert v['ansible_role_name'] == 'test_role'
    assert v['ansible_role_names'] == ['test_role']
    assert v['ansible_parent_role_names'] == ['test_role']
    assert v['ansible_parent_role_paths'] == [None]

# Generated at 2022-06-11 10:53:08.718343
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    yaml_data = """
    - name: test_IncludeRole_load
      hosts: all
      vars:
        role_name: myrole
      tasks:
      - name: include role test
        include_role:
          name: "{{ role_name }}"
          tasks_from: main.yml
        tags:
          - always
    """

    loader, inventory, variable_manager = ansible_runner.get_runner_context(yaml_data)
    p = Play().load(yaml_data, variable_manager=variable_manager, loader=loader)
    tqm = None
    block_list = p.compile()

# Generated at 2022-06-11 10:53:27.357182
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # This test is only run if execute ansible-test includes.
    # ansible-test includes --python 3
    class MyRole(object):
        def __init__(self):
            self._role_path = 'myrole_path'
            self.vars = {'role_var': 'role_var_value'}

        def get_name(self):
            return 'my_role_name'

        def get_role_params(self):
            return {}

    class MyParentRole(object):
        def __init__(self):
            self._name = 'my_role_name'
            self._role_path = 'myparentrole_path'
            self.vars = {'parent_role_var': 'parent_role_var_value'}


# Generated at 2022-06-11 10:53:35.476270
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test_IncludeRole_get_block_list_with_unavailable_block
    try:
        block = Block(parent_block=None)
        role = {'name': 'myRole'}
        task_include = {'action': 'include_role'}
        include_role = IncludeRole(block=block, role=role, task_include=task_include)
        block_list = include_role.get_block_list()
    except Exception as ex:
        assert(ex.args[0] == 'The requested role myRole was not found.')

    # test_IncludeRole_get_block_list_with_unavailable_play

# Generated at 2022-06-11 10:53:46.623080
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class ParentRole():
        def __init__(self, collection_name, collection_version):
            self.collection_name = collection_name
            self.collection_version = collection_version

    # Test  case 1
    # name not defined, role defined
    # Expected result: "%s : %s" % (self.action, self._role_name)
    ir = IncludeRole()
    ir.action = "action1"
    ir.args = {'role': "role"}
    ir._role_name = "role"
    assert ir.get_name() == "action1 : role"

    # Test  case 2
    # name defined, role defined
    # Expected result: "%s : %s" % (self.action, self._role_name)
    ir = IncludeRole()
    ir.action = "action1"

# Generated at 2022-06-11 10:53:56.611553
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class FixedDict(dict):
        def add_block(self, blk):
            self.update({blk.block: blk})
    class FakeDisplay(Display):
        def __init__(self):
            self.log = False
            self.verbosity = 0
            self.deprecations = []
            self.warnings = []
    class FakeRole(Role):
        def __init__(self, name):
            self._role_path = name
            self._metadata = RoleMetadata()
            self._metadata._role_name = name
            self._metadata._remote_module_version = ansible_version
            self._metadata._basedir = os.path.dirname(name)
    class FakeVariableManager:
        def get_vars(self, *args, **kwargs):
            return {}

# Generated at 2022-06-11 10:54:08.278979
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    Unit test for method get_include_params of class IncludeRole
    """
    include_role = IncludeRole()
    include_role._parent_role = ansible.playbook.role.Role()
    include_role._parent_role.name = 'test_role_name'
    include_role._parent_role._role_path = 'test_role_path'
    assert 'ansible_parent_role_names' in include_role.get_include_params()
    assert 'ansible_parent_role_paths' in include_role.get_include_params()
    assert 'test_role_name' in include_role.get_include_params()['ansible_parent_role_names']

# Generated at 2022-06-11 10:54:18.859456
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # 1: Success: load a simple include_role
    data = dict(name='role1', tasks_from='tasks_filename', vars_from='vars_filename',
                defaults_from='defaults_filename', handlers_from='handlers_filename',
                apply=dict(ignore_errors=True), allow_duplicates=False, rolespec_validate=False)
    ir1 = IncludeRole.load(data)
    assert isinstance(ir1, IncludeRole)
    assert ir1.name == 'role1'
    assert ir1._role_name == 'role1'
    assert ir1.apply == dict(ignore_errors=True)
    assert ir1.allow_duplicates is False
    assert ir1.rolespec_validate is False

# Generated at 2022-06-11 10:54:29.025276
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    task_include = TaskInclude()
    task_include.action = 'name'
    role = Role()
    role.get_name = lambda: 'myrole'
    role._role_path = '/path/to/myrole'

    args = dict(
        name='myincludedrole',
        tasks_from='role/tasks/main.yml',
        vars_from='role/vars/main.yml',
        defaults_from='role/defaults/main.yml',
        handlers_from='role/handlers/main.yml',
        apply=dict(
            tags=['some', 'tags'],
        ),
        public=True,
        allow_duplicates=False,
        rolespec_validate=False,
    )

# Generated at 2022-06-11 10:54:39.292762
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.loader import role_loader
    role_loader.add_directory('./lib/ansible/roles')

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    inv_data = """
        myhost ansible_host=xx.xx.xx.xx
        [group1]
        myhost
        [group2]
        myhost
    """

# Generated at 2022-06-11 10:54:48.573619
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils.facts import FactCollector

    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # create test play
    play_data = b"""
        - hosts: localhost
          gather_facts: no
          roles:
              - {role: test_collections.sub_role1,
                 tasks_from: "tasks/main.yml",
                 vars_from: "vars/main.yml",
                 handlers_from: "handlers/main.yml" }
    """
    loader = AnsibleLoader(play_data, FileInputLoader('<string>'))
    play_data = loader

# Generated at 2022-06-11 10:54:58.543364
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    # create playbook instance

# Generated at 2022-06-11 10:55:16.940719
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader

    # Empty data structure
    data = dict()

    # Non-defined params
    params = dict()

    # Test code
    t = IncludeRole()
    result = t.load(data, block=Block(), role=Role(), task_include=None,
                    variable_manager=VariableManager(), loader=DictDataLoader())

    # Assertions
    assert isinstance(result, IncludeRole)
    assert result.action == 'include_role'
    assert result.args == params
    assert result.block == None
    assert result.block_id == 1
    assert result.always_run == False
    assert result.any_errors_fatal == None

# Generated at 2022-06-11 10:55:23.084494
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    r = Role()
    r._role_path = 'some/path'
    r.name = 'SomeRole'
    i = IncludeRole()
    i.vars = dict(a=1)
    i._parent_role = r
    assert i.get_include_params() == dict(a=1, ansible_role_name='SomeRole', ansible_role_path='some/path', ansible_parent_role_names=['SomeRole'], ansible_parent_role_paths=['some/path'])

# Generated at 2022-06-11 10:55:32.563635
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Unitialized global objects are not accessible within the scope of this
    function, so we need to explicitly define it (to make sure they are
    available).
    '''
    global_objects= {
        'play': None,
        'variable_manager':None,
        'loader': None
    }


# Generated at 2022-06-11 10:55:42.606775
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.utils.vars as ans_vars
    from ansible.template import Templar
    from ansible.playbook.block import Block
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-11 10:55:52.642361
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import tempfile
    # Create a mock role to be included
    included_role_name = 'included_role'
    included_role_path = tempfile.mkdtemp()

    included_role_vars_path = included_role_path + '/vars'
    os.mkdir(included_role_vars_path)

    included_role_meta_path = included_role_path + '/meta'
    os.mkdir(included_role_meta_path)

    included_role_files_path = included_role_path + '/files'
    os.mk

# Generated at 2022-06-11 10:56:02.096624
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    global display

    # Static load of an include_role and test that the task_data has the right
    # format so that it can be used to instantiate an IncludeRole object
    module_loader = None
    variable_manager = None
    loader = None
    block = None
    inv_data = None
    play_context = None
    # Set a path to a role to be used as the test role
    role_path = '../../../test/integration/targets/include_role'
    data = dict(
        include_role=dict(
            name=role_path
        )
    )

    # Create an IncludeRole object and get the blocks it contains
    ir = IncludeRole.load(data, block=block, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    blocks,

# Generated at 2022-06-11 10:56:13.332549
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook import playbooks

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)
    block = Block()
    display.verbosity = 3

# Generated at 2022-06-11 10:56:20.903837
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    role = Role._load_role_data(dict(
        foo='bar',
        files=['baz'],
        handler_to_load='/tmp/test',
        include='test/test.yml',
        pre_tasks='pre_test.yml',
        role_path='roles/test',
        templates='template/test.j2',
        vars='vars/test.yml',
        post_tasks='post_test.yml',
        tasks='tasks/test.yml'
    ))
    test_case_1 = {'name':'include_role', 'role':'test/test.yml'}
    include_role = IncludeRole(block=None, role=role, task_include=None)
    include_role.load(test_case_1)
    test

# Generated at 2022-06-11 10:56:27.408348
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    data = '''
    - include_role:
        name: name
        apply:
          handlers:
            - action1
            - action2
        vars:
          var1: value1
          var2: value2
    '''
    IncludeRole.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:56:38.178237
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:57:06.786015
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ansible_playbook_inject_entry(object, '_current_task', None)
    #import pdb;pdb.set_trace()

# Generated at 2022-06-11 10:57:17.302961
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.constants as C

    class TestTaskInclude(TaskInclude):
        def __init__(self):
            self.tasks = []

        def load_data(self, data):
            self.data = data
            return self

    data = {
        'include': './role2'
    }

    ti = TaskInclude.load(data, TaskInclude().load_data(data))
    assert ti.use_handlers_only == False
    assert ti.apply_role is None
    assert ti._play is None
    assert ti._role is None
    assert ti._task_include is None
    assert ti.action == 'include'
    assert ti.args == {'include': './role2'}
    assert ti.collections is None
    assert ti.name is None
    assert ti.owner

# Generated at 2022-06-11 10:57:27.313566
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''IncludeRole_load()'''

    # set up mock objects
    class TestIncludeRole(IncludeRole):
        '''Mock object of class IncludeRole'''
        def __init__(self, role, tasks_from=None, vars_from=None, defaults_from=None, handlers_from=None):
            '''constructor for mock object'''
            super(TestIncludeRole, self).__init__(role=role, tasks_from=tasks_from, vars_from=vars_from, defaults_from=defaults_from, handlers_from=handlers_from)

    class TestParentRole(object):
        '''Mock object for role dependency'''
        def get_role_params(self):
            '''mock for get_role_params'''

# Generated at 2022-06-11 10:57:36.282179
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 10:57:47.647569
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    loader = MockLoader()
    mytest = IncludeRole(role='mytest', loaders=[loader])
    mytest.vars = {'mytest_var': True}
    mytest._from_files = {'tasks': 'main.yml'}
    mytest.rolespec_validate = False

    blocks, handlers = mytest.get_block_list(variable_manager=MockVariableManager())

    assert blocks[0].name == 'task 1', "task name '%s' is not 'task 1'" % blocks[0].name
    assert blocks[1].name == 'task 2', "task name '%s' is not 'task 2'" % blocks[1].name

    # tests for variable inheritance
    assert blocks[0].vars['mytest_var'] is True, "mytest_var should be True"
   

# Generated at 2022-06-11 10:57:56.773268
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ''' test_IncludeRole_get_include_params() - Unit test to validate IncludeRole.get_include_params() meets expectations
    '''

    # Create a basic IncludeRole object with a mocked parent role
    class MockBasicRole(object):
        def __init__(self):
            self._metadata = {'namespace': None, 'name': 'MyRoleName', 'path': '/path/to/my/role'}
        def get_role_params(self):
            return {'ansible_role_namespace': self._metadata['namespace'], 'ansible_role_name': self._metadata['name'], 'ansible_role_path': self._metadata['path']}
        def get_name(self):
            return self._metadata['name']
    mock_basic_role = MockBasicRole()
    mock_basic_

# Generated at 2022-06-11 10:58:06.902454
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Setup
    import os

    # Ansible 2.9
    class MockAnsible2_9:
        def __init__(self):
            self.variable_manager = None
        def getattr(self, name):
            if name == 'display':
                return Display()
    class MockPluginLoader2_9:
        def __init__(self, ansible):
            self.ansible = ansible
            self.collections = []
        @staticmethod
        def load_plugin(plugin_type, name, namespace, class_only=False, class_name=None, mod_only=False):
            pass
        def find_collection_plugins(self, arg):
            pass
    class MockVariableManager2_9:
        def __init__(self):
            self.vars = {}

# Generated at 2022-06-11 10:58:16.038928
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    import ansible.plugins.loader as plugin_loader
    from ansible.vars.manager import VariableManager

    # Arrange
    data = dict(name='test')
    block = Block()
    role = Role()
    task_include = 'test'
    variable_manager = VariableManager()
    loader = plugin_loader.PluginLoader()

    # Act
    ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)

    # Assert
    assert ir.ignore_errors is False
    assert ir.args == data
    assert ir.when == ''
    assert ir.action == 'test'
    assert ir.always_run is False

# Generated at 2022-06-11 10:58:26.561991
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class MockRole(object):
        @staticmethod
        def get_name():
            return 'test'
        @staticmethod
        def get_role_params():
            return {'ansible_role_test1': 1, 'ansible_role_test2': 2}
    inc_role = IncludeRole(role=MockRole)

    # Test without parent role
    assert inc_role.get_include_params() == {'ansible_role_name': 'test'}

    # Test with parent role
    class MockParentRole(object):
        @staticmethod
        def get_name():
            return 'parent_role'
        @staticmethod
        def get_role_params():
            return {'ansible_role_parent1': 1, 'ansible_role_parent2': 2}
    inc_role._parent_role

# Generated at 2022-06-11 10:58:36.414697
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """ This takes a directory name, loads a test yaml file, and
    verifies the expected data structure.  If we have time
    we can make this into a pytest, or something similar
    """

    debug = False
    if debug:
        display.verbosity = 2

    # test1.yml
    # Verify that the block list contains two tasks: one that is
    # created by task include and one that is created by a block
    # in the test_block.yaml file in the given directory
    #dirname = 'test-include-role-directory'
    dirname = 'test-include-role-directory-no-task-include-task'
    test_file = 'test1.yml'

    # Modified from test_task_include.py:
    #   Load a task include yaml file and verify that the block list

# Generated at 2022-06-11 10:59:20.040418
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:59:20.604236
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:59:29.520944
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:59:40.004497
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test IncludeRole.get_block_list()
    """
    import ansible.playbook
    import ansible.inventory
    import ansible.vars

    inventory = ansible.inventory.Inventory(ansible.constants.DEFAULT_HOST_LIST)
    variable_manager = ansible.vars.VariableManager(inventory=inventory)
    loader = ansible.parsing.dataloader.DataLoader()

    action = "include_role"
    name = "role"
    args = {'role': name}
    parent = ansible.playbook.Play()
    role = ansible.playbook.Role()
    task = IncludeRole(block=None, role=role, task_include=None).load(dict(action=action, args=args), None, role, None, variable_manager, loader)