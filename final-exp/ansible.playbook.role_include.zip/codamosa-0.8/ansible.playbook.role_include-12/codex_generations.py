

# Generated at 2022-06-11 10:49:56.426774
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Returns role and main block under the role block.
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.compat.tests import unittest

    class TestIncludeRole(unittest.TestCase):

        def setUp(self):
            self.variable_manager = VariableManager()
            self.loader = DataLoader()
            self.options = {'__play_context': PlayContext()}

            # compile data

# Generated at 2022-06-11 10:50:07.071626
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Unit test for method get_block_list of class IncludeRole

    :return:
    """
    from ansible.playbook.role.definition import RoleDefinition
    #from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    mock_play = None
    mock_block = Block.load(data={'block': [{'foo': 'bar'}, {'baz': 'bax'}]}, play=mock_play)
    mock_role = RoleDefinition.load(data={'name': 'role01', 'tasks': [{'foo': 'bar'}, {'baz': 'bax'}]})
    # mock_task = TaskInclude

# Generated at 2022-06-11 10:50:16.580648
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    def test_assert(expected, actual):
        assert sorted(expected) == sorted(actual)

    def init_block(block_path, task_type='task', task_action='debug', task_args=None):
        if task_args is None:
            task_args = {}

        if task_type == 'block':
            task_args['block'] = []
            task_args['rescue'] = []
            task_args['always'] = []


# Generated at 2022-06-11 10:50:18.571046
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Unit test for method get_block_list of class IncludeRole
    :return:
    '''
    pass

# Generated at 2022-06-11 10:50:29.448614
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import __main__
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    if PY3:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'

    setattr(__main__, '__file__', '/test_IncludeRole_load.py')
    setattr(__main__, '__name__', '__main__')

    block = Block()
    task_include = TaskInclude()

# Generated at 2022-06-11 10:50:39.452876
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test for error on invalid options
    try:
        RoleInclude.load({'role': 'alice', 'bogus': 'value'})
        assert False, "Exception should have been raised on invalid options"
    except AnsibleParserError as e:
        assert "Invalid options" in e.message

    # Test base attributes and defaults
    ri = RoleInclude.load({'role': 'alice'})
    assert ri.name == 'alice'
    assert ri.allow_duplicates is True
    assert ri.public is False
    assert ri.rolespec_validate is True
    assert ri.apply == {}

    # Test custom attributes

# Generated at 2022-06-11 10:50:47.991107
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.task_include import TaskIncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    block = Block()
    task = TaskIncludeRole(block=block)

    try:
        task.get_block_list()
    except Exception as e:
        raise AssertionError("IncludeRole should not require play to be passed in")
    else:
        pass

# Generated at 2022-06-11 10:50:58.928382
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    def _create_mock_object(d):
        class Mock(object):
            pass
        m = Mock()
        for k, v in d.items():
            setattr(m, k, v)
        return m
    from ansible.playbook.role.definition import RoleDefinition
    Q = RoleDefinition()
    Q.name = 'a_role'
    Q.role_path = 'path/to/a_role'
    Q.parents = ()
    Q.dependencies = ()
    Q.metadata = _create_mock_object({'allow_duplicates': True})
    Q.play = _create_mock_

# Generated at 2022-06-11 10:51:06.445385
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    templar = ansible.template.Templar(loader=loader, variables=variable_manager.get_vars())

    data = dict(
        name='some-role',
        tasks='some-tasks.yml',
        handlers='some-handlers.yml',
        defaults='some-defaults.yml',
        vars='some-vars.yml',
        apply='x',
        public=True,
        allow_duplicates=False,
        rolespec_validate=False
    )


# Generated at 2022-06-11 10:51:07.194356
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:51:23.581244
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor import  module_common
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager()

    # Create a play_context
    play_context =  PlayContext()

    # Set the play_context variables and options
    play_context.network_os = 'junos'
    play_context.remote_addr = '10.0.0.1'
    play_context.remote_user = 'admin'

    # Create a task_include object
    task_include = TaskInclude()

   

# Generated at 2022-06-11 10:51:34.240634
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    import tempfile
    import shutil
    import json

    lib_path = os.path.join(os.path.dirname(__file__), '..', '..')
    sys.path.insert(0, lib_path)
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    # Create temp dir
    tmpdir = tempfile.mkdtemp()

    # Create temp role in temp dir
    temp_role_path = os.path.join(tmpdir, 'test_role')
    os.mkdir(temp_role_path)

    # Create temp task vars file

# Generated at 2022-06-11 10:51:36.712865
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import doctest
    results = doctest.testmod(IncludeRole)
    if results.failed:
        exit(1)

# Generated at 2022-06-11 10:51:44.119489
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    my_include_role = IncludeRole()
    my_include_role.name = 'foo'
    assert my_include_role.get_name() == 'foo'

    my_include_role.name = None
    my_include_role._role_name = 'bar'
    my_include_role.action = 'baz'
    assert my_include_role.get_name() == 'baz : bar'


# Generated at 2022-06-11 10:51:53.278645
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:51:59.841653
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    t_i = TaskInclude()
    r = Role()
    r_i = RoleInclude()
    for opt in IncludeRole.VALID_ARGS:
        ro = IncludeRole()
        ro.load(opt, block=t_i, role=r)
        print(ro)

# Generated at 2022-06-11 10:52:11.861175
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def get_deepcopy(arg):
        return deepcopy(arg)
    # set up test objects
    o1 = dict(name='hello')
    o2 = dict(name='hello', allow_duplicates=False)
    o3 = dict(name='hello', handlers_from='hi')
    o4 = dict(name='hello', apply=dict(a=1))
    # test the load method
    assert IncludeRole(task_include=TaskInclude()).load(get_deepcopy(o1))
    assert IncludeRole(task_include=TaskInclude()).load(get_deepcopy(o2))
    assert IncludeRole(task_include=TaskInclude()).load(get_deepcopy(o3))
    assert IncludeRole(task_include=TaskInclude()).load(get_deepcopy(o4))

# Generated at 2022-06-11 10:52:19.432748
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory')
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'yes',
        tasks = [
            dict(action=dict(
                module='debug',
                args=dict(
                    msg='Hello world!'
                )
            ))
        ]
    ), variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-11 10:52:31.979198
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.utils.display import Display
    Display.verbosity = True
    import ansible.playbook
    import ansible.template
    import ansible.vars


# Generated at 2022-06-11 10:52:36.914485
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Initialize test data
    data = {
        'apply': {
            'ignore_errors': True
        },
        'allow_duplicates': True,
        'public': True,
        'rolespec_validate': True
    }

    # Instantiate
    ir = IncludeRole()

    # Call load
    ir.load(data)

    # Verify attributes
    assert ir.apply == {'ignore_errors': True}
    assert ir.allow_duplicates == True
    assert ir.public == True
    assert ir.rolespec_validate == True

    # Verify type(s)
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, Block)

# Generated at 2022-06-11 10:52:59.682781
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    # Issue number:  72249
    # testcase_file location:  /home/jbj/ansible/test/units/test_playbook_tasks_include.py
    # testcase_Function name:  test_IncludeRole_load
    # testcase_linenumber:  149
    @patch('ansible.playbook.block.Block.load')
    @patch('ansible.playbook.task_include.TaskInclude.load')
    """

# Generated at 2022-06-11 10:53:08.917758
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    pb = Playbook.load(loader=loader, variable_manager=VariableManager(), paths='test/playbooks/hash_include_role.yml')
    assert pb.get_handler_blocks()[0]._role_name == 'my_role'
    assert pb.get_handler_blocks()[0]._from_files['tasks'] == 'tasks.yml'
    assert pb.get_handler_blocks()[0]._from_files['vars'] == 'vars.yml'

# Generated at 2022-06-11 10:53:14.989605
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    data = { u'name': u'foo.bar',
             u'apply': {u'a': u'b'},
             u'rolespec_validate': u'no',
             u'public': u'yes',
             u'allow_duplicates': u'no' }

    ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
   

# Generated at 2022-06-11 10:53:24.942010
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role

    # Define some vars to play with
    my_name = 'my_name'
    my_role = ansible.playbook.role.Role()
    my_role._metadata = ansible.playbook.role.RoleMetadata()
    my_role._metadata.name = my_name
    my_play = ansible.playbook.play.Play().load({})
    my_play.name = 'some_play'
    my_play._tqm = 'some_tqm'
    my_play._variable_manager = VariableManager()
    my_play._variable_manager

# Generated at 2022-06-11 10:53:33.867680
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create a role with no parent role
    role_no_parent = Role()

    # Create a role with a parent role and a parent role with it's own parent role
    role_with_parent_parent = Role()
    role_with_parent_parent.name = 'role_with_parent_parent'
    role_with_parent_parent._role_path = '/path/to/role_with_parent_parent'

    role_with_parent = Role()
    role_with_parent.name = 'role_with_parent'
    role_with_parent._role_path = '/path/to/role_with_parent'
    role_with_parent.add_parent(role_with_parent_parent)

    # Create include role with no parent role
    include_role_no_parent = IncludeRole()
    include_role_no

# Generated at 2022-06-11 10:53:44.661423
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes
    import ansible.constants as C

    loader = DictDataLoader({
        'some_role.yml': to_bytes("""
        - include_tasks: tasks/main.yml
        """),
        'tasks/main.yml': to_bytes("""
        - debug:
            msg: "hi"
        """)
    })

    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    pb = Playbook()

# Generated at 2022-06-11 10:53:55.176545
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # role_name is a required value for IncludeRole
    data = dict(
        name="foo",
        include=["role1", "role2"]
    )
    p = Play().load(data, variable_manager=None, loader=None)
    pb = PlaybookExecutor(playbooks=[])
    pb._tqm._inventory = pb._inventory = pb.loader.inventory = 'localhost,'
    p._tqm = pb._tqm
    t = p.get_tasks()[1]  # 0 contains setup/

# Generated at 2022-06-11 10:54:06.716560
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins import action_loader

    # Create an action
    action = action_loader.get('include_role', class_only=True)()

    # Create a block
    block = Block()
    block.role = None
    block.parent = None

    # Create a templar
    templar = Templar(loader=None, variables={})

    # Create a task
    include_role = IncludeRole(block, role=None, task_include=action)

    # Create a task with data
    data = {'action': 'include_role', 'args': {'name': 'my_role', 'apply': {'tags': ['my_tag']}}}
    include_role = include_role.load(data=data, block=None, role=None, task_include=action)

    # Test the data
    assert include

# Generated at 2022-06-11 10:54:17.460702
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Arrange
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = dict(name='test_load_name', tasks_from='test_load_tasks_from', vars_from='test_load_vars_from',
                defaults_from='test_load_defaults_from', handlers_from='test_load_handlers_from', apply=dict(a=1, b=2),
                public=True, allow_duplicates=True, rolespec_validate=True)

# Generated at 2022-06-11 10:54:18.168355
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:54:50.520106
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext()

# Generated at 2022-06-11 10:54:51.434548
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-11 10:55:01.551597
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # no should have been
    ir = IncludeRole.load(data=dict(name='foo', apply=dict(a='b')), variable_manager=None, loader=None)
    assert ir.name == 'foo'

    # should have been
    ir = IncludeRole.load(data=dict(role='foo', apply=dict(a='b')), variable_manager=None, loader=None)
    assert ir.name == 'foo'
    assert ir.apply == {'a': 'b'}

    # not string
    with pytest.raises(AnsibleParserError):
        ir = IncludeRole.load(data=dict(name=dict(role='foo', apply=dict(a='b'))), variable_manager=None, loader=None)
        assert ir.name == 'foo'

# Generated at 2022-06-11 10:55:05.095897
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # arrange
    ir = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude())
    # act
    result = ir.get_name()
    # assert
    assert result is not None or result != ''

# Generated at 2022-06-11 10:55:11.840096
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    block_list_obtained = IncludeRole.load(data={"role": "test-include"}, loader=TestIncludeRoleLoader()).get_block_list()[0]._blocks
    # Blocks are created as RoleInclude() results. The blocks are list of Block.
    block_list_expected = [Block(block=block_list_obtained[0], role=Role(name="test-include", loader=TestIncludeRoleLoader(), collection_list=[]))]
    for block in block_list_expected:
        assert block in block_list_obtained


# Generated at 2022-06-11 10:55:21.683153
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObject
    from ansible.playbook.task import Task

    class object_from_role(object):
        def __init__(self, role):
            self.role = role

    class roleconf_from_role(object):
        def __init__(self, role):
            self.role = role

    class Role(Task):
        def __init__(self, data, play=None, parent_role=None):
            self._data = data
            self._name = self._metadata.get('name', 'ROLE_NAME')
            self._role_path = 'ROLES_PATH'
            self._metadata = {'name': 'ROLE_NAME', 'collections': ["collections"]}
            self._parent_role = parent

# Generated at 2022-06-11 10:55:22.242768
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-11 10:55:31.810652
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import tempfile
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    content = '''
    - include_role:
        name: test_roles.test_role1
        tasks_from: test_tasks
    '''
    tmpdir = tempfile.mkdtemp(dir=C.DEFAULT_LOCAL_TMP)
    tmpdir_b = to_bytes(tmpdir)


# Generated at 2022-06-11 10:55:34.734084
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    i = IncludeRole()
    i._role_name = 'my_role'
    i.action = 'include_role'
    assert i.get_name() == 'include_role : my_role'



# Generated at 2022-06-11 10:55:35.335002
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:57:07.779854
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-11 10:57:18.454876
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # All required imports
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # Initialize a Play instance
    play_context = dict(
        remote_addr='127.0.0.1',
        password=dict(),
        become_method='',
        become_user='',
        become_pass='',
        become_exe='',
        become_flags='',
        become_info=dict()
    )
    loader = None
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:57:28.453567
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    import json

    display.verbosity = 3

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 10:57:37.509520
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars import VariableManager

    class TestModule(object):
        def test_load(self):
            data = dict(include="role", include_role_name="test", include_tasks="test.yml")
            variable_manager = VariableManager()
            r = IncludeRole(block=None, role=None, task_include=None)
            r2 = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=None)
            s =  "%s" % r2

# Generated at 2022-06-11 10:57:49.019899
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.required_component import RoleRequirementComponent
    from ansible.playbook.role.scope import RoleScope

    loader = DictDataLoader({})

    role_name = 'myrole'
    role_path = '/my/path/'
    myplay = DummyPlay()
    variable_manager = DummyVariableManager()
    variable_manager.set_nonpersistent_facts(dict(ansible_current_user='ansible'))
    variable_manager.extra_vars = {'foo': 'bar'}

    # test basic load


# Generated at 2022-06-11 10:57:57.572705
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test 1
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'role_name': 'test_role', 'foo': 'bar'}
    variable_manager.options_vars = {'role_name': 'test_role', 'foo': 'bar'}
    play = Play.load({
        'name': 'test play',
        'hosts': 'test_host',
        'vars': {
            'test_var': 'test_value',
        },
    }, loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-11 10:57:58.244774
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-11 10:58:08.338861
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # make a fake role to include
    role = Role()
    role._role_name = 'fake_role'
    role_path = '/path/to/a/fake_role'
    role._role_path = role_path
    # create play object
    play = Play()
    ir = IncludeRole(role=role, task_include={'tasks': 'tasks'}, block=Block())
    # test data
    data = dict(name='fake_role', tasks_from='tasks', apply=dict(serial=2))
    role_deps = dict(roles=dict(foobar=dict(apply=dict(serial=1))))
    # with no variable_manager, loader or role_deps
    ir.load(data)
    assert ir._role_name == 'fake_role'
    assert ir._role_path

# Generated at 2022-06-11 10:58:17.971936
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    role_obj = Role()
    templar = Templar(loader=None, variables=dict(a='hello', b='world'))

    # All valid arguments (includes base, default)
    ri_args = {'name': 'test', 'role': 'test', 'tasks_from': 'file', 'vars_from': 'file', 'defaults_from': 'file', 'handlers_from': 'file', 'apply': {'a':'hello'}}
    role_include = IncludeRole.load(ri_args, role_obj)

    assert role_include.args == ri_args
    assert role_include.name == 'test'
    assert role_include._role_name == 'test'
    assert role_include

# Generated at 2022-06-11 10:58:27.958940
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    import ansible.template.template as template
    from ansible.parsing.vault import VaultLib

    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    # Create a fake play for our parent block
    play_context = PlayContext()
    pc = StringIO()