

# Generated at 2022-06-21 01:24:44.662672
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Valid include_role but name is not supplied
    data = dict(
        include_role=dict(
            role=u'role.common',
            tasks_from=u'tasks/main.yml',
            vars_from=u'vars/main.yml',
            defaults_from=u'defaults/main.yml',
            handlers_from=u'handlers/main.yml',
            apply=dict(
                ignore_errors=False),
            public=True,
            allow_duplicates=False,
            rolespec_validate=True)
    )

    # name of include_role is required
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data=data)

    # valid include_role where name is supplied

# Generated at 2022-06-21 01:24:56.321207
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    my_loader = MockLoader({'../../roles/foo': '{"name": "foo", "otherkey": "othervalue"}'})
    my_loader.paths = ['/some/path/to/roles']
    my_role = Role.load('foo', my_loader)

    # test constructor via superclass
    ir = IncludeRole(role=my_role, task_include=RoleInclude(role_name='foo', loader=my_loader))
    assert ir._parent_role == my_role
    assert ir._role_name == 'foo'
    assert ir.vars == {'otherkey': 'othervalue'}
    assert ir._from_files == {}

    # test constructor with explicit kwargs

# Generated at 2022-06-21 01:25:07.982448
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    data = dict(name='foo')
    play_context = PlayContext(play=Play().load(
        dict(
            name='foobar',
            hosts='all',
            gather_facts='no',
            roles=[dict(name='foo', tasks=[data])]
        )
    ))
    variable_manager = VariableManager()
    if not hasattr(Templar, '_available_variables'):
        Templar._available_variables = {}
    templar = Templar(loader=None, variables=variable_manager.get_vars(loader=None, play=Play().load(data, variable_manager=variable_manager)))


# Generated at 2022-06-21 01:25:11.145933
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    task_include_obj = TaskInclude("- include_role: name=myrole", role=None)
    include_role_obj = IncludeRole(block=None, role=None, task_include=task_include_obj)
    include_role_obj.statically_loaded = False
    new_obj = include_role_obj.copy(exclude_tasks=True)
    assert new_obj.statically_loaded == False

# Generated at 2022-06-21 01:25:16.465262
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Construct Block and Role instances
    block = Block()
    role = Role()

    # Construct IncludeRole instance
    include_role = IncludeRole(block=block, role=role)

    # TODO:
    #   I don't understand the purpose of this method, so I can't implement this unit test

# Generated at 2022-06-21 01:25:25.163089
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}
    variable_manager._options_vars['roles_path'] = ["./test/unit/lib/ansible/roles"]

    name = "test_role"
    names = [name, "test_role2"]
    role_list = []

# Generated at 2022-06-21 01:25:35.036331
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    import datetime
    import json
    import os
    import time

    from ansible.errors import AnsibleParserError
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    from ansible.vars.manager import VariableManager

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from units.mock.vault_helper import VaultHelper

    display = Display()

    # Temporary disabled because it is causing CI failures
    # RoleInclude, Role and Play are tested in other tests
    # def test

# Generated at 2022-06-21 01:25:43.786117
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test for get_name without name nor role
    ir = IncludeRole()
    assert ir.get_name() == "include_role :"

    # Test for get_name with name
    ir = IncludeRole()
    ir.args['name'] = "test_name"
    assert ir.get_name() == "include_role : test_name"

    # Test for get_name with role
    ir = IncludeRole()
    ir.args['role'] = "test_role"
    assert ir.get_name() == "include_role : test_role"



# Generated at 2022-06-21 01:25:44.673979
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    pass

# Generated at 2022-06-21 01:25:48.413945
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert hasattr(IncludeRole, '__init__')
    assert callable(IncludeRole.__init__)

    # ensure no errors are raised when creating a IncludeRole object
    IncludeRole()

    # ensure no errors are raised when creating a IncludeRole object with the following args
    IncludeRole(block = Block())


# Generated at 2022-06-21 01:26:02.940870
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    blk = Block()
    obj = IncludeRole(blk, Role())
    assert(isinstance(obj, TaskInclude))

# unit tests
from ansible.module_utils.six import iteritems
from ansible.module_utils._text import to_bytes
from units.mock.loader import DictDataLoader


# Generated at 2022-06-21 01:26:15.486985
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create task
    role_block = Block()
    role_block.vars.update({"x": "y"})

    role = Role()
    role._role_name = "test_role"

    base_task = IncludeRole(block=role_block, role=role)

    # Create data
    data = {
        "name": "my_role"
    }

    # Define mock functions
    def mock_RoleInclude_load(self, *args, **kwargs):
        return self

    def mock_Role_load(self, *args, **kwargs):
        return self

    # Run test

# Generated at 2022-06-21 01:26:16.209046
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-21 01:26:23.492777
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """Tests IncludeRole.get_name()
    """

    # IncludeRole.get_name()
    ir = IncludeRole()

    # name is set
    ir.name = 'foo'
    expected = 'foo'
    actual = ir.get_name()
    assert actual == expected

    # name is not set
    ir.name = ''
    ir._role_name = 'bar'
    expected = 'include_role : bar'
    actual = ir.get_name()
    assert actual == expected


# Generated at 2022-06-21 01:26:36.053190
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block(parent_block=None)
    role = Role()
    task_include = TaskInclude()
    data = {'name':'role1', 'apply':{'cmd':'ls'}, 'public':True, 'allow_duplicates':False, 'rolespec_validate':True}
    variable_manager = None
    loader = None
    ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert ir.action == 'include_role'
    assert ir.name == data['name']
    assert ir._role_name == data['name']
    assert ir.vars == {}
    assert ir.args == data
    assert ir.block == block
    assert ir._role_path is None
    assert ir._parent_role == role
    assert ir._task_

# Generated at 2022-06-21 01:26:38.313873
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = "test"
    assert ir.get_name() == "test : "
    ir._role_name = "test_name"
    assert ir.get_name() == "test : test_name"


# Generated at 2022-06-21 01:26:45.533151
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Testing class Block

# Generated at 2022-06-21 01:26:57.703765
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    var_manager = VariableManager()

    # Test: no parent role
    ir = IncludeRole(block=Block(), role=None)
    assert ir.get_include_params() == {
        'ansible_play_hosts': [],
        'ansible_playbook_python': 'python',
        'role_name': None,
        'role_path': None,
    }

    # Test: with parent role (not directly used, just to check get_role_params calls)
    parent_role = Role()
    ir = IncludeRole(block=Block(), role=parent_role)

# Generated at 2022-06-21 01:26:59.011428
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    i = IncludeRole()
    i._role_name = 'test'
    i._parent_role = 'test_parent_role'
    result = i.get_block_list()
    assert result

# Generated at 2022-06-21 01:27:00.294647
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    results = IncludeRole()
    assert results != None


# Generated at 2022-06-21 01:27:26.338022
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager

    class FakeRole(Role):
        def get_role_params(self):
            return {
                "role_var": "role_val"
            }

        def get_name(self):
            return "role_name"

    loader = DictDataLoader({
        "boo": "a=1\nb=2\n",
        "vars": "var1=a\nvar2=b\n",
    })
    var_manager = VariableManager()
    var_manager._fact_cache = {"var1": "val1", "var2": "val2"}


# Generated at 2022-06-21 01:27:35.094753
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = "fake_loader"

    playbook_path = "/path/to/playbook"
    file_name = "/path/to/include_role.yml"

# Generated at 2022-06-21 01:27:39.125807
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    v = IncludeRole(task_include=None, block=Block(), role=Role(name='my_parent_role')).get_include_params()
    assert v['ansible_parent_role_names'] == ['my_parent_role']

# Generated at 2022-06-21 01:27:50.209715
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import os
    import sys
    import json

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.six import string_types
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.requiremenets import RoleRequirement

# Generated at 2022-06-21 01:27:52.017746
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass


# Generated at 2022-06-21 01:28:03.688843
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    tmp_data = {
        'block': Block(parent_block=None, role=None, task_include=None),
        'role': None,
        'task_include': None,
        'action': 'include_role',
        'static': 'True',
        '_role_name': 'test_role',
        '_role_path': '/var/roles/test_role',
        '_from_files': {'tasks': 'test.yml'}
    }
    include_role = IncludeRole(**tmp_data)
    new_me = include_role.copy()

    assert new_me.statically_loaded is True
    assert new_me._role_name == 'test_role'
    assert new_me._role_path == '/var/roles/test_role'
    assert new_me

# Generated at 2022-06-21 01:28:09.440640
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    #
    # Setup
    #
    #   Setup a very simple role and a simple play.
    #
    role_dirname = "test_dirname"
    role_filename = "test_IncludeRole_get_block_list"
    role_name = "test"

    role_path = role_dirname + "/" + role_filename + "/" + role_name

    for path in [role_dirname, role_dirname + "/" + role_filename]:
        if not os.path.exists(path):
            os.makedirs(path)

    with open(role_path + "/meta/main.yml", "w") as f:
        pass


# Generated at 2022-06-21 01:28:17.825432
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test loading of a simple name
    data = {}
    data['name'] = 'fake-role-1'
    data['tasks'] = 'fake_role_1_tasks.yml'
    data['handlers'] = 'fake_role_1_handlers.yml'
    data['vars'] = 'fake_role_1_vars.yml'
    data['defaults'] = 'fake_role_1_defaults.yml'

    ir = IncludeRole.load(data)
    assert ir._role_name == 'fake-role-1'
    assert ir._from_files['tasks'] == 'fake_role_1_tasks.yml'
    assert ir._from_files['handlers'] == 'fake_role_1_handlers.yml'

# Generated at 2022-06-21 01:28:20.629520
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    IncludeRole()


# Generated at 2022-06-21 01:28:25.442961
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    args_from_dict = dict(name='jumpserver', role='jumpserver')
    ir = IncludeRole.load(args_from_dict)
    assert ir.get_name() == "include_role : jumpserver"

# Generated at 2022-06-21 01:28:44.497446
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    a = IncludeRole()
    a.statically_loaded = True
    a._from_files = {'tasks': 'roles/a/tasks/main.yml'}
    a._role_name = 'a'
    a._role_path = 'a'
    a.dependencies = [Block.load(dict(
        block=dict(
            tasks=[dict(name='a', action='a')],
        )
    ))]
    b = a.copy()
    assert a.statically_loaded == b.statically_loaded
    assert a._from_files == b._from_files
    assert a._role_name == b._role_name
    assert a._role_path == b._role_path
    assert a.dependencies == b.dependencies

# Generated at 2022-06-21 01:28:54.981415
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import io
    import pytest
    from ansible.playbook.play_context import PlayContext

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    context = PlayContext()
    variable_manager = None
    loader = DictDataLoader({})

    fake_data = dict(
        name='mysql',
    )

    mock_loader = DictDataLoader({
        '/etc/ansible/roles/mysql/meta/main.yml': io.StringIO(
            "galaxy_info:\n"
            "  description: MySQL\n"
        )
    })

    fake_display = DummyDisplay()


# Generated at 2022-06-21 01:29:03.537926
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    testme = IncludeRole()
    testme._parent_role = None
    assert testme.get_include_params() == {}
    testme._parent_role = Block()
    testme._parent_role.get_role_params = lambda: {'a':1}
    testme._parent_role.get_name = lambda: 'main.yml'
    testme._parent_role._role_path = '~/roles/role1'
    assert testme.get_include_params() == {
        'a': 1,
        'ansible_parent_role_names': ['main.yml'],
        'ansible_parent_role_paths': ['~/roles/role1']
    }

# Generated at 2022-06-21 01:29:10.540325
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.role import Role

    display = Display()
    play = Role()
    variables = dict(name='test', role='role1')
    data = dict(name='role1')

    role = IncludeRole.load(data, play=play, variable_manager=variables)
    assert role._role_name == 'role1'

# Generated at 2022-06-21 01:29:15.665580
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    task_include = TaskInclude()
    block = Block()
    role = Role()
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    assert(include_role == include_role.copy())

# Generated at 2022-06-21 01:29:25.536419
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    loader = MockLoader()
    variable_manager = MockVariableManager()

    data = dict(
        name='foo',
        include=dict(
            tasks='included-tasks.yml',
            vars='included-vars.yml',
            handlers='included-handlers.yml',
            defaults='included-defaults.yml',
            apply=dict(
                tags='tag1'
            ),
            allow_duplicates=True,
            public=True
        ),
        vars={'key': 'value'})

    ir = IncludeRole.load(data, task_include=MockTaskInclude())
    blocks, _ = ir.get_block_list(play=MockPlay(), variable_manager=variable_manager, loader=loader)

    assert 1 == len(blocks)

    assert True

# Generated at 2022-06-21 01:29:26.435303
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(role=None)
    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-21 01:29:35.611027
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # needed to setup the default settings
    context = PlayContext()
    variable_manager = None
    loader = None

# Generated at 2022-06-21 01:29:43.654301
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    # VALID
    # Test 1 : name is 'test_name' and role is 'test_role'
    role = IncludeRole(block=block, role='test_role')
    role.name = 'test_name'
    assert role.get_name() == 'test_name : test_role'
    # Test 2 : name is None and role is 'test_role'
    role = IncludeRole(block=block, role='test_role')
    role.name = None
    assert role.get_name() == 'include_role : test_role'
    # Test 3 : name is 'test_name' and role is None
    role = IncludeRole(block=block, role=None)
    role.name = 'test_name'
    assert role.get_name() == 'test_name : None'


# Generated at 2022-06-21 01:29:47.546610
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    data = dict()
    data['name'] = "testname"
    data['role'] = "testrole"
    ir = IncludeRole.load(data)
    assert ir.get_name() == "testname : testrole"

    ir = IncludeRole.load(data, role="role1")
    assert ir.get_name() == "testname : role1"

    ir = IncludeRole.load(data, role="role1")
    ir.name = "name1"
    assert ir.get_name() == "name1 : role1"

# Generated at 2022-06-21 01:30:24.065303
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: Replace this with a dynamic constructor using data defined in a YAML file or something.

    block = Block()
    task_include = TaskInclude(block=block)
    include_role = IncludeRole(block=block, task_include=task_include)

    assert include_role.get_name() == '- include_role : '
    assert include_role.tasks_from is None
    assert include_role.vars_from is None
    assert include_role.defaults_from is None
    assert include_role.handlers_from is None
    assert include_role.allow_duplicates is True
    assert include_role.public is False
    assert include_role.rolespec_validate is True

    block = Block()
    task_include = TaskInclude(block=block)
    include_role

# Generated at 2022-06-21 01:30:32.568212
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import ansible.playbook.play_context
    import ansible.playbook.role.definition
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.playbook.task

    blocks = [Block(
        role=RoleDefinition(),
        task_includes=[
            TaskInclude(
                block=Block()
            ),
            IncludeRole(
                block=Block()
            ),
        ])]

    play_context = ansible.playbook.play_context.PlayContext()
    play_context.network_os = "network_os"


# Generated at 2022-06-21 01:30:42.932785
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    parent_role = Role()
    parent_role._role_name = 'foo'
    parent_role._role_path = '/bar'

    child = IncludeRole(role=parent_role)
    child.vars = dict(a=1)
    child._parent_role = parent_role

    expected = dict(
        a=1,
        ansible_parent_role_names=['foo'],
        ansible_parent_role_paths=['/bar'],
    )

    parent_role.vars = dict(b=2)
    parent_role._metadata = dict(c=3)
    parent_role._role_params = dict(d=4)

    expected.update(dict(
        b=2,
        c=3,
        d=4,
    ))

    assert child.get_include

# Generated at 2022-06-21 01:30:46.017517
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole().load_data({'include_role': {'name': 'foo', 'tasks_from': 'main.yml'}})

    assert isinstance(ir, IncludeRole)
    assert ir._role_name == 'foo'
    assert ir._from_files['tasks'] == 'main.yml'

# Generated at 2022-06-21 01:30:47.481596
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # FIXME: Mock required
    pass

# Generated at 2022-06-21 01:30:54.069278
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # ansible-playbook --syntax-check test-playbook.yml
    data = dict(include_role=dict(name="test"))
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole.load(data=data, block=block, role=role, task_include=task_include)

    assert include_role.args.get('name') == "test"


# Generated at 2022-06-21 01:31:00.109280
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole(block=None, role=None, task_include=None)

    include_role.name = "test1"
    include_role.action = "action1"
    include_role._role_name = "test2"

    assert include_role.get_name() == "test1"

    include_role.name = None
    assert include_role.get_name() == "action1 : test2"

    include_role.name = ""
    assert include_role.get_name() == "action1 : test2"

# Generated at 2022-06-21 01:31:07.814339
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # create an empty play and an empty block
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    play = Play()
    block = Block()
    block.vars = dict()
    # create a variable manager
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    loader = None
    # create a TaskInclude instance with the play, the block, and the variable manager
    from ansible.playbook.task_include import TaskInclude
    ti = TaskInclude()
    ti._play = play
    ti._block = block
    ti._variable_manager = variable_manager
    ti._loader = loader
    # create an IncludeRole instance with the play, the block, and the task include
    ir = IncludeRole()
    ir._parent = block


# Generated at 2022-06-21 01:31:13.101230
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create a sample play
    play = Play()
    # Create a sample role
    role = Role()

    # Create a sample block
    block = Block()

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude

    # Create dummy task_include
    task_include = TaskInclude()

    # Create dummy RoleDefinition
    role_definition = RoleDefinition.load(dict(name='dummy_role', task_paths=['tasks']), role=role, play=play)

    # Create a sample IncludeRole
    include_role = IncludeRole(block, role, task_include)

    # Set role name
    include_role._role_name = 'dummy_role'

    # Set _from_files

# Generated at 2022-06-21 01:31:17.369880
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role_name = 'some_role'
    ir = IncludeRole()
    ir._role_name = role_name

    assert ir.get_name() == "{} : {}".format(ir.action, role_name)

# Generated at 2022-06-21 01:32:23.415799
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Setup
    block1 = Block(["task1", "task2", "task3"], 5, "parent1")
    block2 = Block(["task1", "task2", "task3"], 5, "parent2")
    role1 = Role(name="role1")
    role2 = Role(name="role2")
    ir1 = IncludeRole(block=block1, role=role1)
    ir2 = IncludeRole(block=block2, role=role2)
    ir1.action = "testaction1"
    ir1.dirty = False
    ir1.any_errors_fatal = True
    ir1.any_errors_fatal_configured = True
    ir1.always_run = False
    ir1.always_run_configured = True

# Generated at 2022-06-21 01:32:26.232290
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    include_role = IncludeRole(block=block, role=role)
    include_role._role_name = "role_name"
    include_role.action = "include"
    assert include_role.get_name() == "include : role_name"

# Generated at 2022-06-21 01:32:31.455775
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.role import Role
    t = IncludeRole()
    t._role_name = 'test_role'
    t._parent_role = Role()
    t._parent_role._role_name = 'parent_role'
    assert t.get_name() == 'include_role : test_role'
    t.name = 'test'
    assert t.get_name() == 'test : test_role'

# Generated at 2022-06-21 01:32:42.508910
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    import ansible.constants as C

    # Create TaskInclude instance
    role = Role()
    task = Task()
    task.name = 'testTask'
    task.action = 'testAction'
    role.tasks.append(task)
    task_include = task._block._parent
    task_include._role = role
    task_include._role_name = 'testRole'

    # Test execution
    actual = IncludeRole.load(data=task_include, role=role)
    actual._parent_role = task_include._role
    actual._task_include = task_include._task_include
    actual._role_name = task_include._role_name
    actual._role_path = task_include._role_

# Generated at 2022-06-21 01:32:53.729112
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test valid args
    include_role = IncludeRole()

    data = {'name': 'valid_role1'}
    include_role.load(data)
    assert include_role._role_name == 'valid_role1'

    data = {'role': 'valid_role2'}
    include_role.load(data)
    assert include_role._role_name == 'valid_role2'

    data = {'name': 'valid_role3', 'role': 'valid_role3'}
    include_role.load(data)
    assert include_role._role_name == 'valid_role3'

    data = {'apply': 'var', 'public': True, 'allow_duplicates': False, 'rolespec_validate': False}
    include_role.load(data)
    assert include_

# Generated at 2022-06-21 01:33:05.011788
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    my_role = Role()
    my_role_include = RoleInclude()
    my_task_include = TaskInclude()

    #no name no role
    result = IncludeRole.load('roles: [programmer]', my_task_include, my_role, my_role_include)
    assert isinstance(result, IncludeRole)
    assert result.name is None
    assert result.role is None

    #name no role
    result = IncludeRole.load({'include_role': {'name': 'kikos'}}, my_task_include, my_role, my_role_include)

# Generated at 2022-06-21 01:33:14.530691
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ''' AnsibleRoleInclude._get_block_list '''

    import os
    import sys
    import yaml

    #
    # load env
    #

    # load env vars used by ansible.constants (for testing)
    # setup logging format
    #   using default format specified in ansible/constants
    CONST_LOG_FORMAT = C.DEFAULT_LOG_FORMAT_STRING
    CONST_LOG_DATE_FMT = C.DEFAULT_LOG_DATE_FORMAT

    #
    # define test data
    #

    # test data for method get_block_list of class IncludeRole

# Generated at 2022-06-21 01:33:24.948376
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    raw_data = {
        'name': 'my-role',
        'public': True,
        'tasks_from': 'the-tasks',
        'vars_from': 'the-vars',
        'defaults_from': 'the-defaults',
    }

    ir = IncludeRole.load(raw_data)

    assert isinstance(ir, IncludeRole)
    assert isinstance(ir.block, Block)
    assert isinstance(ir._role_name, string_types)
    assert ir._role_name == 'my-role'
    assert ir._public is True
    assert ir._from_files == {'tasks': 'the-tasks', 'vars': 'the-vars', 'defaults': 'the-defaults'}



# Generated at 2022-06-21 01:33:31.300458
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    include_role.action = "include_role"
    include_role.name = "common_tasks"
    assert include_role.get_name() == "include_role : common_tasks"

    include_role.action = "import_role"
    include_role.name = None
    include_role._role_name = "common_tasks"
    assert include_role.get_name() == "import_role : common_tasks"

# Generated at 2022-06-21 01:33:42.883797
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash

    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # play is needed for get_include_params to work