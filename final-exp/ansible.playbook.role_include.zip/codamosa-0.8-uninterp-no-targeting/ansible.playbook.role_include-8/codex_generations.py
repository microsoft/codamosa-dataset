

# Generated at 2022-06-21 01:24:27.121911
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = IncludeRole("role_name")
    assert role.name == "role_name"

    role = IncludeRole()
    assert role.name == "include_role"

# Generated at 2022-06-21 01:24:36.054901
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.module_utils.six import PY3
    if PY3:
        from imp import reload
    import ansible.module_utils.common.json_utils as json

    test1_from_args = {
        'name': 'foo',
        'tasks_from': './somefile.yml',
        'vars_from': './somefile.yml',
        'handlers_from': './somefile.yml',
        'defaults_from': './somefile.yml',
        'apply': {
            'a': 'b'
        }
    }
    # test1_from_args is private. Use accessor

# Generated at 2022-06-21 01:24:47.525466
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class Play():
        class Role():
            def __init__(self):
                self.get_vars = lambda: {}

        def __init__(self, vars):
            self.roles = []
            self.role = Play.Role()
            self.vars = vars
            self.basedir = '.'

        def _get_variable_manager(self):
            try:
                self.variable_manager.extra_vars.update(self.vars)
            except:
                self.variable_manager = VariableManager(loader=None, play=self)
                self.variable_manager.extra_vars.update(self.vars)
            return self.variable_

# Generated at 2022-06-21 01:24:50.782987
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Tests that the get_name() function returns the correct value
    task = IncludeRole({'name': 'role_name'})
    assert task.get_name() == 'include_role : role_name'


# Generated at 2022-06-21 01:24:59.165021
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    # Arrange
    from ansible.playbook.tests.unit.loader_mock import BaseLoaderMock
    loader = BaseLoaderMock()
    data = {
        'role': 'testrole'
    }
    # in order to get the include_role to work we need to have the role
    # definition available in the role directory
    loader.exists_mock['testrole'] = True

    # Act
    obj = IncludeRole.load(data, loader=loader)

    assert obj._role_name == 'testrole'
    assert obj._role_path == 'testrole'

# Generated at 2022-06-21 01:25:11.511534
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Create the block and set its attributes
    blk = Block()
    blk.defined_tags = ['tag1', 'tag2']
    blk.apply = [{'name': 'key1', 'value': 'value1'}]
    blk.post_validate = 'https://www.ansible.com'
    blk.always_run = True

    # Create the role and set its attributes
    rl = Role()
    rl.name = "role_name"
    rl.passwords = {'key3': 'value3'}
    rl.become_pass = "become_pass"

    # Create the task and set its attributes
    includerole = IncludeRole()
    includerole.action = 'IncludeRole'
    includerole.name = "name"
    includerole

# Generated at 2022-06-21 01:25:20.301666
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block1 = Block('block1')
    block1.parent = None

    loader=DataLoader()
    variable_manager=VariableManager()

    data = dict(
        name='test_role',
        tasks_from='test_role'
    )
    ir = IncludeRole(block=block1, role=None)
    ir = ir.load(data=data, variable_manager=variable_manager, loader=loader)
    assert isinstance(ir, IncludeRole)

    return ir

# Generated at 2022-06-21 01:25:23.233258
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # pass values to constructor, 
    i = IncludeRole(block=None, role=None, task_include=None)
    # check values of variables.
    assert i._role_name == None
    assert i._role_path == None

# Generated at 2022-06-21 01:25:33.952134
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    from ansible.playbook.role import ROLE_CACHE
    from ansible.playbook.role.include import RoleInclude

    # Reset the cache
    ROLE_CACHE = {}

    # Output from the importer from a role of the official Ansible Galaxy

# Generated at 2022-06-21 01:25:34.615443
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-21 01:25:46.978181
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Parameters
    block = None
    role = {'name': 'test', '_role_path': 'test'}
    task_include = None

    # Create the object and get include params
    include_role = IncludeRole(block, role, task_include)
    expected_params = {'ansible_role_name': 'test', 'ansible_role_path': 'test'}
    params = include_role.get_include_params()

    assert params == expected_params

# Generated at 2022-06-21 01:25:50.075799
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    x = IncludeRole()
    x.statically_loaded = True
    x._from_files = { "abc": "def" }
    y = x.copy()
    assert y.statically_loaded == True
    assert y._from_files == { "abc": "def" }

# Generated at 2022-06-21 01:25:54.460644
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = {
        'block': Block(play=None),
        'role': 'include_role',
    }
    ir = IncludeRole(**data)
    assert ir._parent_role == None
    assert ir._role_name == None
    assert ir._role_path == None
    assert ir.block == data.get('block')
    assert ir.role == data.get('role')

# Generated at 2022-06-21 01:26:05.493582
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext


    results = dict(
        changed=False,
        failed=False,
        skipped=False,
        ignored=False,
    )

    context = PlayContext()
    context._options = dict(
        connection='local',
        module_path=None,
        forks=10,
        become=False,
        become_method=None,
        become_user=None,
        become_ask_pass=False,
        check=False,
        diff=False,
        syntax=False,
        sudoable=False,
        conditions=[],
        start_at_task=None,
    )
    context._vars = dict()
    context._play = None
    context._play_context = context
    context._task = None
    context._original_task = None

# Generated at 2022-06-21 01:26:17.645164
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    x = IncludeRole()
    x.name = 'foo'
    x.args = {'a':1}
    x._parent = 2
    x.statically_loaded = True
    x._from_files = {'a':'b'}
    x._parent_role = 3
    x._role_name = 'bar'
    x._role_path = 'baz'

    y = x.copy()
    assert y.name == 'foo'
    assert y.args == {'a':1}
    assert y._parent == 2
    assert y.statically_loaded == True
    assert y._from_files == {'a':'b'}
    assert y._parent_role == 3
    assert y._role_name == 'bar'
    assert y._role_path == 'baz'

    z = x

# Generated at 2022-06-21 01:26:22.557462
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = "geerlingguy.java"
    # Generate expected output
    expected_output = "geerlingguy.java : geerlingguy.java"
    # Compare method output with expected output
    assert ir.get_name() == expected_output

# Generated at 2022-06-21 01:26:28.836997
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = {'name': 'test', 'tasks': 'tasks/main.yml'}

    loader = None
    variable_manager = None
    ansible_vars = {}

    t = IncludeRole.load(data, loader=loader, variable_manager=variable_manager, ansible_vars=ansible_vars)

    print(t.name)
    print(t._from_files)

    assert t.name == 'test'
    assert t._from_files['tasks'] == 'tasks/main.yml'

if __name__ == "__main__":
    test_IncludeRole()

# Generated at 2022-06-21 01:26:32.411213
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    IncludeRole(block=block, role=role, task_include=task_include)

# Generated at 2022-06-21 01:26:33.077746
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-21 01:26:43.237524
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    from ansible.template import Templar

    # initializing some test data
    class DataManager:
        def __init__(self):
            self.data = None

    data_manager = DataManager()
    data_manager.data = {'name': 'test_IncludeRole_copy', 'role': 'sample_role'}

    block = Block()
    role = Role()
    task_include = TaskInclude()

    # creating instance

# Generated at 2022-06-21 01:27:00.127266
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    instance = IncludeRole()
    assert isinstance(instance, IncludeRole)
    assert isinstance(instance, TaskInclude)
    assert isinstance(instance, Block)

# Generated at 2022-06-21 01:27:09.353737
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.include import RoleInclude
    role_include = RoleInclude()
    role_include.name="role1"
    role_include.collections=[]
    include_role = IncludeRole(role=role_include)
    include_role._from_files={'role1': 'role1/tasks/main.yaml', 'role2': 'someother.yaml'}
    include_role._parent_role = role_include
    include_role._role_name = 'role1'
    include_role._role_path = '/myhome/myuser/myplaybooks/roles/role1'
    include_role.statically_loaded = True
    include_role.action = 'include_role'

    assert(include_role.name == 'role1')

# Generated at 2022-06-21 01:27:15.278447
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    assert include_role.get_name() == ""

    include_role.name = "test"
    assert include_role.get_name() == "test"

    include_role.name = None
    include_role.action = "action"
    include_role._role_name = "role_name"
    assert include_role.get_name() == "action : role_name"


# Generated at 2022-06-21 01:27:18.244916
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    This is a test class for constructor of IncludeRole class
    """
    ir = IncludeRole(block=Block(), role=Role())
    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-21 01:27:21.697039
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    actual_name = "test_TaskInclude_get_name"
    ir = IncludeRole()
    ir.name = actual_name
    assert ir.get_name() == "include_role: " + actual_name


# Generated at 2022-06-21 01:27:31.393329
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test with invalid data
    data = {}
    ir = IncludeRole()
    try:
        ir.load(data=data)
    except AnsibleParserError as e:
        assert "name is a required field for include_role" in str(e)

    data = {"role": "foo"}
    ir = IncludeRole()
    ir.load(data=data)

    data = {"name": "foo"}
    ir = IncludeRole()
    ir.load(data=data)

    # Test with valid data
    data = {"role": "foo", "allow_duplicates": True}
    ir = IncludeRole()
    ir.load(data=data)
    assert ir._role_name == "foo"
    assert ir.allow_duplicates is True


# Generated at 2022-06-21 01:27:34.828251
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    context = dict()
    role = Role()
    ir = IncludeRole(role=role)
    assert type(ir) is IncludeRole
    assert ir._parent_role == role

# Generated at 2022-06-21 01:27:44.080124
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play_context
    def mock_block_list(self, **kwargs):
        return Block(play=kwargs['play'])
    _old_block_list = ansible.playbook.play_context.IncludeRole.get_block_list
    ansible.playbook.play_context.IncludeRole.get_block_list = mock_block_list
    c = ansible.playbook.play_context.IncludeRole()
    assert isinstance(c.get_block_list(), Block)
    ansible.playbook.play_context.IncludeRole.get_block_list = _old_block_list

# Generated at 2022-06-21 01:27:54.975478
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ir = IncludeRole()

    res = ir.get_include_params()
    assert 'ansible_parent_role_names' in res
    assert 'ansible_parent_role_paths' in res
    assert 'ansible_parent_role_name' in res
    assert 'ansible_parent_role_path' in res

    #
    # test for ansible_parent_role_name
    #

    # with _parent_role
    ir = IncludeRole()
    ir._parent_role = Block()
    ir._parent_role.get_name = lambda: 'Ansible_parent_role_name'
    res = ir.get_include_params()

# Generated at 2022-06-21 01:27:57.104871
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole().get_name() is None
    assert IncludeRole(name="foo").get_name() == "foo"
    assert IncludeRole(name="foo", role="bar").get_name() == "foo"

# Generated at 2022-06-21 01:28:30.487030
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()

    options = {
        'name': 'testrole',
    }

    task_include = IncludeRole(block, role)
    task_include.load_data(options, variable_manager=None, loader=None)

    assert task_include.get_name() == 'testrole'


# Generated at 2022-06-21 01:28:43.257090
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import role_loader, action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleParserError
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.template import Templar

# Generated at 2022-06-21 01:28:54.544089
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.playbook_include import PlaybookInclude

    class ParentBlock(Block):
        pass

    class ParentRole(Role):
        pass

    parent_role = ParentRole(name='parent_role')
    parent_block = ParentBlock(block=['parent_block'], role=parent_role)
    playbook_include = PlaybookInclude(from_name='playbook_include')

    include_role = IncludeRole(block=parent_block, role=parent_role, task_include=playbook_include)
    include_role.statically_loaded = False
    include_role._from_files = {'tasks': 'from_tasks_file'}
    include_role._parent_role = parent_role
    include_role._role_name = 'role_name'
    include_role._role_

# Generated at 2022-06-21 01:29:02.420597
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Test :meth:`ansible.playbook.role.include.IncludeRole.get_name`
    """
    ir = IncludeRole()
    ir.name = "name1"
    assert ir.get_name() == "name1"
    ir.name = None
    ir._role_name = "name2"
    assert ir.get_name() == "include_role : name2"
    ir.action = "include_role2"
    assert ir.get_name() == "include_role2 : name2"

# Generated at 2022-06-21 01:29:08.932716
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_obj = IncludeRole()
    test_obj.action = 'role'
    test_obj._role_name = 'test_role_name'
    expected_result = 'Role : test_role_name'
    actual_result = test_obj.get_name()
    assert actual_result == expected_result

# Generated at 2022-06-21 01:29:16.395108
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    test_action = 'test_action'
    test_block = Block()
    test_role = Role()
    test_task_include = TaskInclude()
    test_include_role = IncludeRole(test_block, test_role, test_task_include)
    assert test_include_role._block == test_block
    assert test_include_role._role == test_role
    assert test_include_role._task_include == test_task_include
    assert test_include_role._metadata == test_task_include._metadata
    assert not test_include_role._parent
    assert test_include_role._role_type == 'include_role'
    assert test_include_role._dep_chain == []
    assert test_include_role._role_path == None
    assert not test_include_role._statically_loaded


# Generated at 2022-06-21 01:29:22.961754
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    assert not IncludeRole.load(dict(name=''), block=Block(), role=RoleDefinition())
    assert not IncludeRole.load(dict(name=None), block=Block(), role=RoleDefinition())
    assert not IncludeRole.load(dict(name='role1'), block=Block(), role=RoleDefinition())
    assert not IncludeRole.load(dict(role='role1'), block=Block(), role=RoleDefinition())
    play_context = PlayContext()
    play_context.setup_cache()
    play_context.vars = dict()

# Generated at 2022-06-21 01:29:27.248946
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(role=None)
    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir._rolespec_validate == True

# Generated at 2022-06-21 01:29:35.972165
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook

    opts = {'remote_user': 'root', 'verbosity': 0}
    pb_loader = DictDataLoader({})
    pb_inventory = Inventory(loader=pb_loader, variable_manager=VariableManager())
    pb_variable_manager = VariableManager(loader=pb_loader, inventory=pb_inventory)

    # Setup the playbook object
    playbook = Playbook()
    playbook.loader = pb_loader
    playbook.set_variable_manager(pb_variable_manager)

    pc = PlayContext()
    pc.remote_user = 'root'
    pc.verbosity = 0

   

# Generated at 2022-06-21 01:29:44.194037
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = {'name': 'apache'}

    c = ir.copy()
    c.args = {'name': 'apache', 'tasks_from': 'httpd.yml'}

    assert c.action == 'include_role'
    assert c._role_name == 'apache'
    assert c.args.get('tasks_from') == 'httpd.yml'
    assert c._from_files.get('tasks') == 'httpd.yml'
    assert c.statically_loaded == False

    try:
        c.args = {'name': 'apache', 'tasks_from': 4}
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-21 01:30:44.880945
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    tasks = [{"include_role": {"name": "foobar"}}, {"include_role": {"name": "foobar2"}}]
    name = "tasks_bar.yml"
    block = Block.load(tasks, role=Role(), task_include=TaskInclude(name=name))
    ir = IncludeRole.load(tasks[0], block=block, role=Role())

    ir.statically_loaded = True
    ir._from_files = {'tasks': 'tasks_bar.yml'}
    ir._parent_role = Role()
    ir._role_name = "foobar"
    ir._role_path = "foobar_path"

    new_ir = ir.copy()

    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from

# Generated at 2022-06-21 01:30:56.851526
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    display = Display()
    inv_mgr = InventoryManager(loader=loader, sources=["localhost"])
    variable_mgr = VariableManager(loader=loader, inventory=inv_mgr)

    play_context = PlayContext(play=Play.load(dict(
        name = "test",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [],
        vars = {}
    ), variable_manager=variable_mgr, loader=loader))


# Generated at 2022-06-21 01:31:04.499067
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ast
    import json
    import yaml

    def _load_role(text):
        ds = yaml.safe_load(text)
        assert isinstance(ds, dict)
        assert len(ds) == 1
        if isinstance(ds, dict):
            d = ds['tasks']
        else:
            d = ds
        assert isinstance(d, list)
        assert len(d) == 1
        assert isinstance(d[0], dict)
        assert len(d[0]) == 1
        k, v = d[0].items()[0]
        assert k == 'include_role'
        assert isinstance(v, dict)
        return v


# Generated at 2022-06-21 01:31:10.878341
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    yaml_data = '''
    - name: test
      hosts: all
      tasks:
        - include_role:
            name: testrole
    '''
    loader = DataLoader()
    play = Play().load(yaml_data, variable_manager=VariableManager(), loader=loader)
    task=play.get_tasks()[0]
    tmp_task=task.copy()
    assert tmp_task.name == task.name
    assert tmp_task.action == task.action
    assert tmp_task.block == task.block
    assert tmp_task.loop == task.loop
    assert tmp_task.role == task.role
    assert tmp_task._parent == task._parent
    assert tmp_task.statically_loaded == task.statically_loaded

# Generated at 2022-06-21 01:31:20.508813
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # init
    ir = IncludeRole()
    ir.statically_loaded = True

    ir._from_files = {
        'task': 'file1.yml',
        'vars': 'file2.yaml',
        'defaults': 'file3.yaml',
        'handlers': 'file4.yaml'
    }

    # call copy
    new_me = ir.copy()

    # assert
    assert new_me.statically_loaded is True
    assert new_me._from_files == ir._from_files



# Generated at 2022-06-21 01:31:30.703197
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    play_context = dict(play=dict(become='yes'))
    role_name = {'name': 'role_name'}
    role_no_name = dict()

    ir_name = IncludeRole.load(role_name, play_context=play_context)
    name = 'role_name'
    assert ir_name.get_name() == name

    ir_no_name = IncludeRole.load(role_no_name, play_context=play_context)
    name = 'role : '
    assert ir_no_name.get_name() == name

# Generated at 2022-06-21 01:31:43.251552
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Validates class IncludeRole load method for expected outcomes.
    """
    import pytest

    class MockRole(object):
        """
        A mock object to represent a Role.
        """
        def __init__(self, name):
            self.name = name

        def get_role_params(self):
            return {'ansible_role_names': [self.name]}

        def get_name(self):
            return self.name
    #
    # Arrange
    #
    # Create a Mock Role which can be used to test the IncludeRole object.
    mock_role = MockRole('mock_role_name')

    #
    # Act
    #
    # Create an IncludeRole object, passing in load a yaml statement to
    # create the object as well as the mock Role.

# Generated at 2022-06-21 01:31:53.363653
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    roledef = RoleDefinition()
    roledef.name = 'foobar'
    roledef.task_blocks = [('tasks', [])]
    roledef.handler_blocks = [('handlers', [])]
    role = roledef.load()
    role_path = '10192811'
    role._role_path = role_path

# Generated at 2022-06-21 01:32:03.522762
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    data = dict(
        name='foo',
        role='bar',
    )
    templar = Templar(loader=None)
    loader = None
    variable_manager = None
    bl = Block()
    task_include = IncludeRole.load(data, block=bl, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    new_task = task_include.copy()
    new_task.post_validate(templar=templar)
    assert new_task is not task_include
    assert new_task.name == task_include.name
    assert new_task.role == task_include.role
    assert new_task.statically_loaded == task_include.statically_loaded
    assert new_task._from_files == task_include._from_files
   

# Generated at 2022-06-21 01:32:14.790569
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.yaml import objects
    from ansible.plugins.loader import include_role_loader
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = include_role_loader  # Using include_role_loader as role_loader class also uses load method
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    variable_manager.options_vars = {'role_opts_var': 'role_opts_value'}
    inventory = InventoryManager(loader=action_loader)
    play_context = PlayContext()
    play = objects.Play.load