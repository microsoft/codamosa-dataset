

# Generated at 2022-06-21 01:24:39.259178
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Create a dummy play to use
    play_ds = dict(
        name="Test Play",
        hosts='localhost',
        gather_facts='no',
        roles='TestRole'
    )
    play = Play().load(play_ds, variable_manager=None, loader=None)

    # Create a dummy role to use
    role_ds = dict(
        name="TestRole",
        tasks=[
            dict(action=dict(module='setup', args=dict()))
        ]
    )
    role = Role().load(role_ds, play=play, variable_manager=None, loader=None)

    # Create a

# Generated at 2022-06-21 01:24:52.043010
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    b = Block()
    r = Role()
    i = IncludeRole(b, r)
    i._role_name = 'foo'
    j = i.copy()
    assert j._from_files == {}
    assert j._parent_role is None
    assert j._role_name == 'foo'
    assert j._role_path is None
    i._from_files = {'a': 'b'}
    i._role_name = 'bar'
    j = i.copy()
    assert j._from_files == {'a': 'b'}
    assert j._role_name == 'bar'
    i._parent_role = r
    j = i.copy()
    assert j._parent_role is not r # should be a copy of r
    assert i._parent_role is r

# Generated at 2022-06-21 01:24:59.955801
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    role = Role.load(dict(name="test"))
    block = Block(parent_block=role)
    task = Task(block=block)
    include_role = IncludeRole(block=block, task_include=task)

    assert include_role.action == 'include_role'
    assert include_role.statically_loaded == False
    assert include_role._from_files == {}
    assert include_role._parent_role == role
    assert include_role._role_name == None
    assert include_role._role_path == None

# Generated at 2022-06-21 01:25:02.226331
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir._allow_duplicates is True
    assert ir._public is False

# Generated at 2022-06-21 01:25:14.267147
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # play_context
    play_context = PlayContext()

    # 1st play
    play1 = Play().load(
        dict(
            name = "test_play",
            hosts = "localhost",
            gather_facts = "no",
            tasks = [
                dict(
                    name = "test task1",
                    shell= "/bin/echo hello",
                    when = "False",
                ),
                dict(
                    name = "test task2",
                    shell= "/bin/echo world",
                )
            ]
        )
    )
    play1.post_validate(play_context=play_context)

    # 2nd play

# Generated at 2022-06-21 01:25:20.852308
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    r = Role()
    b = Block()
    b.role = r
    t = IncludeRole(block=b)

    assert t is not None

# Generated at 2022-06-21 01:25:25.051636
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ex_block = Block()
    ex_role = None
    ex_task = IncludeRole(block=ex_block, role=ex_role)
    ex_task._action = 'include_role'
    ex_task._role_name = 'testrole'
    result = ex_task.get_name()
    assert "testrole" in result
    assert result == 'include_role : testrole'


# Generated at 2022-06-21 01:25:34.975436
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_host': "127.0.0.1"}
    variable_manager.options_vars = {'test_host': "127.0.0.1"}
    inventory = [{'hostname': 'localhost'}]
    play_context = PlayContext(loader=loader, variable_manager=variable_manager, inventory=inventory)
    myblock = Block()
    myblock.parent = myblock
    myrole = Role()

    # test with no name or role

# Generated at 2022-06-21 01:25:46.063684
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # the minimal structure we need for a role
    data = {
        'tasks': [{'debug': 'msg=test_block'}],
        'handlers': [{'include': {'name': 'check_handler'}}],
    }
    # create a fake role

# Generated at 2022-06-21 01:25:46.629681
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert False

# Generated at 2022-06-21 01:26:04.591816
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Set arguments for the object IncludeRole
    include_file_args = {
        'role': 'collections.community.network.arista.eos_interfaces',
        'config': {
            'instance': {
                'name': 'eth0'
            },
            'state': 'up'
        }
    }
    # Create object IncludeRole
    include_file = IncludeRole().load_data(include_file_args)
    # Check instance of the object IncludeRole
    assert isinstance(include_file, IncludeRole)
    # Check attributes of the object IncludeRole
    assert include_file.name == 'include_role'
    assert include_file.role == 'collections.community.network.arista.eos_interfaces'

# Generated at 2022-06-21 01:26:16.251274
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    ip = IncludeRole()
    v = {}
    assert v == ip.get_include_params()

    # build some random fake variables
    ip._parent_role = Role()
    ip._parent_role._role_params = {'test': 'test'}
    ip._parent_role._name = 'test-role'
    ip._parent_role._role_path = 'test-path'


    v = ip.get_include_params()
    assert v['ansible_parent_role_names'][0] == ip._parent_role._name
    assert v['ansible_parent_role_paths'][0] == ip._parent_role._role_path

    assert v['test'] == ip._parent_role._role_params['test']


# Generated at 2022-06-21 01:26:22.759984
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    assert include_role.get_name() == 'include_role : '
    include_role.name = "fantastic"
    assert include_role.get_name() == 'fantastic'

test_IncludeRole_get_name()




# Generated at 2022-06-21 01:26:28.728137
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role = IncludeRole()
    role._role_name = "test"
    role._from_files = {"test": "test"}
    role._parent_role = "test"
    role._role_path = "test"
    copy_role = role.copy(exclude_parent=True, exclude_tasks=True)
    assert copy_role._role_name == role._role_name
    assert copy_role._from_files == role._from_files
    assert copy_role._parent_role == None
    assert copy_role._role_path == role._role_path

# Generated at 2022-06-21 01:26:35.861221
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    my_block = Block()
    my_role = Role()

    my_include_role = IncludeRole(block=my_block, role=my_role)

    assert my_include_role._block == my_block
    assert my_include_role._role == my_role
    assert my_include_role._role_name == None
    assert my_include_role._from_files == {}


# Generated at 2022-06-21 01:26:44.404884
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # method load with bad arguments
    block = Block()
    role = Role()
    task_include = TaskInclude()
    data = {}
    variable_manager = VariableManager()
    loader = 'test_loader'
    try:
        IncludeRole.load(data, block, role, task_include, variable_manager, loader)
        assert False
    except AnsibleParserError:
        assert True

    # method load with good arguments
    data = {'name': 'test_role_name', 'vars': {'test_key': 'test_value'}}

# Generated at 2022-06-21 01:26:51.333718
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    This test checks the method get_name.
    """
    ir = IncludeRole()
    ir.action = "include_role"
    ir.name = "name_of_role"
    assert ir.get_name() == "name_of_role"
    del ir.name
    ir._role_name = "role_name"
    assert ir.get_name() == "include_role : role_name"


# Generated at 2022-06-21 01:27:02.265433
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Initialize the objects required
    ds = DataLoader()
    pm = PlayContext(C.DEFAULT_MODULE_NAME)
    vm = VariableManager(loader=ds)

    # Load a role with a single task
    included_role = IncludeRole.load({"role": "./include_role"})
    # Load a role which includes the above role
    including_role = Role.load({"role": "./including_role"}, play=None)
    # Create a block from the including role
    including_role_block = Block.load({"block": including_role, "_hostvars": {}})

# Generated at 2022-06-21 01:27:03.421542
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir

# Generated at 2022-06-21 01:27:09.810730
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    #takes initialization of Block object and only use the constructor of IncludeRole class
    block = Block()
    ir = IncludeRole(block=block)
    #takes initialization of Block object and initialization of Role object and use the constructor of IncludeRole class
    block = Block()
    r = Role()
    ir = IncludeRole(block=block, role=r)
    #takes initialization of Block object and initialization of TaskInclude object and use the constructor of IncludeRole class
    block = Block()
    ti = TaskInclude()
    ir = IncludeRole(block=block, task_include=ti)

# Generated at 2022-06-21 01:27:24.817413
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    result = IncludeRole()
    #print(result)
    assert isinstance(result, IncludeRole)
    #print(result.get_name())
    assert result.get_name() == "include_role : None"
    #print(result.get_block_list())
    assert isinstance(result.get_block_list(), tuple)

# Generated at 2022-06-21 01:27:31.593011
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    role_meta = dict(
        name='role_name',
        file_name='role_file_name',
        default_vars='role_default_vars',
        dependencies='role_dependencies',
        vars_files='role_vars_files',
        tasks_filtered='role_tasks_filtered',
        handlers_filtered='role_handlers_filtered',
        meta='role_meta',
        _role_path='role_role_path',
        _role_name='role_role_name',
    )
    block_meta = dict(
        name='block_name',
        parent='block_parent',
        role='block_role',
        loop='block_loop',
        loop_control='block_loop_control',
        _line_number='block_line_number'
    )

# Generated at 2022-06-21 01:27:42.534474
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ''' test_IncludeRole_copy is a unittest for the method copy of class IncludeRole
        :returns: returns nothing
    '''
    # initialization of class Block
    block = Block()
    # initialization of class Role
    role = Role(name='role_name',
                default_vars=dict(),
                metadata=dict(),
                private_role_vars=False)
    # initialization of class IncludeRole
    include_role = IncludeRole(block=block, role=role)
    # initialization of class Block
    exclude_parent = Block()
    task_include_exclude = IncludeRole.copy(include_role, exclude_parent)
    # testing result
    assert task_include_exclude.statically_loaded == False

# Generated at 2022-06-21 01:27:47.060134
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()
    v = ir.get_include_params()
    assert v is not None
    assert len(v) == 3
    assert 'ansible_role_name' in v
    assert 'ansible_role_path' in v
    assert 'ansible_role_names' in v


# Generated at 2022-06-21 01:27:49.500299
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    temp_task_include = TaskInclude()
    temp_task_include.action = 'include_role'
    temp_task_include.name = 'Test'
    ir = IncludeRole(role = Role(), task_include = temp_task_include)
    ir._role_name = 'Test role'
    assert ir.get_name() == 'Test : Test role'


# Generated at 2022-06-21 01:27:49.877738
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:27:50.747546
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:27:56.981178
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    role = IncludeRole()
    assert role._task_include is None
    assert role._role is None
    assert role._block is None
    assert role._allow_duplicates is True
    assert role._public is False
    assert role._rolespec_validate is True


# Generated at 2022-06-21 01:27:57.839634
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:28:06.223831
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import role_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    ansible_loader = role_loader

    # Load the role
    ri = RoleInclude()
    ri._role_name = 'test'

# Generated at 2022-06-21 01:28:30.442556
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """test class IncludeRole: test_IncludeRole_copy()"""
    from ansible.playbook.block import Block
    block = Block()
    from ansible.playbook.task import Task
    task = Task()
    from ansible.playbook.role import Role
    role = Role()
    include = IncludeRole(block=block, role=role, task_include=task)
    import ansible.playbook.task_include
    assert isinstance(include.copy(), ansible.playbook.task_include.TaskInclude)

# Generated at 2022-06-21 01:28:38.296708
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    assert 'copy' in dir(IncludeRole)
    my_block = Block()
    my_role = Role()
    my_include = IncludeRole(block=my_block, role=my_role)
    my_copy = my_include.copy()
    assert my_copy._block is my_block
    assert my_copy._parent_role is my_role


# Generated at 2022-06-21 01:28:46.307872
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # GIVEN
    display = Display()
    templar = Templar(loader=None, variables={})

    data, args = dict(name='test_role', apply=dict(), tags=['foo'], tasks=[]), {}
    args.update(dict(BASE={}))

    include_role = IncludeRole.load(data, variable_manager=None, loader=None)
    include_role.name = 'test_role'

    # WHEN
    name = include_role.get_name()

    # THEN
    assert name == "test_role : test_role", 'IncludeRole.get_name should return test_role : test_role'


# Generated at 2022-06-21 01:28:57.037395
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    mock_play = dict(name="play")
    parent_role = "parent_role"
    allow_duplicates = True
    public = False
    validate = True
    role_name = "role_name"
    role_path = "role_path"

    include_role = IncludeRole()

    include_role._parent = mock_play
    include_role._parent_role = parent_role
    include_role._allow_duplicates = allow_duplicates
    include_role._public = public
    include_role._rolespec_validate = validate
    include_role._role_name = role_name
    include_role._role_path = role_path

    new_me = include_role.copy()

    assert(new_me._parent == mock_play)

# Generated at 2022-06-21 01:29:05.214345
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role_include import RoleInclude

    mock_role = RoleInclude()
    mock_role.name = 'TestRole'
    mock_role._role_path = '/fake_path'
    mock_role.vars = {'test_var': 'test_value'}
    mock_role.collections = 'collections.ansible.org,community.general'

    mock_include = IncludeRole(role=mock_role)
    mock_include.vars = {'test_include_var': 'test_include_value'}


# Generated at 2022-06-21 01:29:15.309438
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    This function tests the function ``load`` of class ``IncludeRole``.
    """
    # Test case 1:
    #  data: dictionary with no 'name' or 'role' key.
    #  expected result: raise AnsibleParserError.
    data = {'action': 'include_role'}

    # run test
    try:
        IncludeRole.load(data)
    except AnsibleParserError as e:
        assert "name is a required field" in str(e)
    except Exception as e:
        raise RuntimeError("Test case 1 of function `load` of class `IncludeRole` FAILED")

    # Test case 2:
    #  data: dictionary with 'name' as an integer.
    #  expected result: raise AnsibleParserError.

# Generated at 2022-06-21 01:29:25.398654
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    block = Block()
    block.vars = dict(milk='milk', cheese='cheese')

    ir = IncludeRole(block=block)
    ir.name = 'master'
    ir.vars = dict(cheese='cheddar')
    ir.collection_name = 'master-collection'

    p_ir = IncludeRole(block=block)
    p_ir.name = 'parent'
    p_ir.collection_name = 'parent-collection'

    p2_ir = IncludeRole(block=block)
    p2_ir.name = 'elder'
    p2_ir.collection_name = 'elder-collection'

    ir._parent_role = p_ir
    p_ir._parent_role = p2_ir


# Generated at 2022-06-21 01:29:29.831184
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """IncludeRole - get_name method
    Return:
        Return name of task
    """
    from ansible.playbook.play import Play

    # Initialize IncludeRole() instance
    ir = IncludeRole()

    # Call method get_name()
    name = ir.get_name()

    # Assert: compare expected vars
    exp_name = "include_role : "
    assert exp_name == name


# Generated at 2022-06-21 01:29:41.856746
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    
    # Instantiate include role
    ir = IncludeRole()
    ir._role_name = "some_role"
    
    # Instantiate blocks
    b1 = Block()
    b2 = Block()
    blocks = [b1, b2]
    
    # Instantiate play
    p = Play()
    
    # Instantiate parent role
    r = Role()
    
    # Instantiate role
    ri = RoleInclude()
    ri.vars = dict()
    
    # Initialize variables
    available_variables = dict()
    from_files = dict()
    handlers = [b1, b2]
    
    # Mocked functions
    def mock_load(role_name, play, variable_manager, loader, collection_list):
        return ri

# Generated at 2022-06-21 01:29:47.871981
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # method get_block_list of class IncludeRole
    
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    play = Play()
    
    ##########
    # Test 1 #
    ##########
    print("Test1: Include a role used in the playbook through ansible-galaxy but with un-defined collection in the rolespec.")
    
    include_role_dict = dict()
    include_role_dict['include_role'] = dict()

# Generated at 2022-06-21 01:30:24.697355
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    class MockRoleInclude(object):
        def __init__(self, vars):
            self.vars = vars

    class MockRole(object):
        def __init__(self, blocks, handlers):
            self.blocks = blocks
            self.handlers = handlers
        def get_handler_blocks(self):
            return self.handlers
        def compile(self):
            return self.blocks

    class MockPlay(object):
        def __init__(self):
            self.handlers = []
            self.roles = []

    class MockBlock(object):
        def __init__(self, tasks):
            self.tasks = tasks
        def set_parent(self, block):
            self.parent = block
            for task in self.tasks:
                task.set_parent(block)


# Generated at 2022-06-21 01:30:29.834362
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude(block, role)
    o = IncludeRole(block, role, task_include)
    args = {"name": "foo", "somevar": "somevalue"}
    o.load_data(args)
    assert o.name == 'foo', repr(o.name)
    assert o.statically_loaded is False, repr(o.statically_loaded)

# Generated at 2022-06-21 01:30:35.595485
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._load_name = 'name'
    ir._role_name = 'role'
    ir.action = 'action'
    assert ir.get_name() == 'name'
    ir.name = ''
    assert ir.get_name() == 'role'
    ir = IncludeRole()
    ir.action = 'action'
    assert ir.get_name() == 'action : '
    ir = IncludeRole()
    ir.action = 'action'
    ir._role_name = ''
    assert ir.get_name() == 'action : '


# Generated at 2022-06-21 01:30:37.884980
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole._get_name() == None

# Generated at 2022-06-21 01:30:45.610056
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # setup mock role
    role = Role()
    role._role_name = "mock_role"
    role._role_path = "./mock_role"
    role.get_role_params = lambda: {'foo': "bar"}

    # setup mock block
    mock_block = Block()
    mock_block._parent = role

    # create instance of IncludeRole
    test_instance = IncludeRole(mock_block)

    # assert that get_include_params returns some parameters including role params
    assert test_instance.get_include_params() == {'foo': 'bar', 'ansible_parent_role_names': ['mock_role'], 'ansible_parent_role_paths': ['./mock_role']}

# Generated at 2022-06-21 01:30:47.792227
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    #TODO: Need to write test case once the IncludeRole class is rearranged
    return

# Generated at 2022-06-21 01:30:58.509605
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block.load('- hosts: all\n  gather_facts: True\n  roles:\n    - role: fake')
    role_a = Role.load(data={'name': 'fake', 'collections':['fake_col']}, play=block._play, dep_chain=[])
    role_b = Role.load(data={'name': 'fake_b', 'collections':['fake_b']}, play=block._play, dep_chain=[role_a])
    role_b._role_path = "roles/fake_b"
    role_c = Role.load(data={'name': 'fake_c', 'collections':['fake_c']}, play=block._play, dep_chain=[role_b])
    role_c._role_path = "roles/fake_c"
    role_d

# Generated at 2022-06-21 01:31:01.137668
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole()
    task.__setattr__('_role_name', 'test')
    assert task.get_name() == 'include_role : test'

# Generated at 2022-06-21 01:31:08.807915
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Test
    ir_1 = IncludeRole()
    ir_1.statically_loaded = True
    ir_1._allow_duplicates = True
    ir_1._from_files = {
        'tasks': 'tasks/main.yml',
        'vars': 'vars/main.yml',
        'defaults': 'defaults/main.yml',
        'handlers': 'handlers/main.yml',
        'meta': 'meta/main.yml',
        'library': None,
        'module_utils': None
    }
    ir_1._rolespec_validate = False
    ir_1._parent_role = Role()
    ir_1._role_name = 'my-role'
    ir_1._role_path = '/my-role/path'

   

# Generated at 2022-06-21 01:31:22.083593
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create a test object with no initialisation
    testObj = IncludeRole()

    # Check if property name is empty
    if testObj.name is not None:
        raise AssertionError('Property name is not empty')

    # Set the value for name
    testObj._name = 'test_role'
    # Check if the property name is updated with the new value
    if testObj.name != 'test_role':
        raise AssertionError('Property name value is not updated')

    # Check if the value of the method get_name is updated
    if testObj.get_name() != 'test_role : None':
        raise AssertionError('Get_name method value is not updated')

    # Set the value for _role_name
    testObj._role_name = 'test_role_name'
    # Check if the value of

# Generated at 2022-06-21 01:32:02.258006
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # can't use a regular Role as parent/grandparent, so we have to mock it
    class MockRole(object):
        def __init__(self):
            self._parents = []
            self._metadata = None
            self._role_path = '/test/role/path'
            self.get_role_params = lambda: {'test_role_param': True}
    class MockBlock(Block):
        def __init__(self):
            self._role = None
            self.vars = {}
            self.collections = []
    class MockTaskInclude(object):
        def __init__(self):
            self.args = {}
            self.static_import = False
            self.action = 'include_role'
            self.dependent_role = None
    # more mocking to avoid loading real files

# Generated at 2022-06-21 01:32:06.611030
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    IncludeRole(block=block, role=role, task_include=task_include)

# Generated at 2022-06-21 01:32:16.598544
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()

    role = Role()
    role.name = "foobar"
    role.path = 'foobar'

    task_include = TaskInclude()
    task_include.name = "foobar"
    task_include.static = True

    data = {'role': 'foobar', 'static': True}

    include_role = IncludeRole(block, role, task_include=task_include).load_data(data, variable_manager=None, loader=None)

    new_me = include_role.copy(exclude_parent=False, exclude_tasks=False)

    assert new_me.name == include_role.name
    assert new_me._parent == include_role._parent
    assert new_me._role_name == include_role._role_name

# Generated at 2022-06-21 01:32:24.298490
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    play_ds = dict(
        name="foobar",
        hosts='all',
        vars={},
        roles=[]
    )
    play = Play().load(play_ds, variable_manager=None, loader=None)
    role_ds = dict()
    role = Role().load(role_ds, play, variable_manager=None, loader=None)
    block_ds = dict(
        name="foobar",
        vars={},
        tasks=[]
    )
    block = Block().load(block_ds)

    ir = IncludeRole()

    # Here we test when the name of the task is not set
    ir._role_name = None

# Generated at 2022-06-21 01:32:28.472668
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    include_Role = IncludeRole()
    assert (include_Role.action == 'include_role')


# Generated at 2022-06-21 01:32:41.168908
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play

    r_m_d = RoleMetadata()
    r_m_d.name = 'my_role_name'

    # Create an include and a parent task
    include = TaskInclude()
    include._ds = {'name': 'include_something'}
    include._parent = Task()

    include.statically_loaded = True
    include._from_files = {}
    include._parent_role = RoleDefinition()


# Generated at 2022-06-21 01:32:50.218114
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    yaml_data = '''- include_role:
        name: foo'''
    task = Task.load(yaml_data)
    assert isinstance(task, IncludeRole)
    assert task.name == "foo"

    task = IncludeRole(Block(parent_block=None))
    assert task.name == "include_role"
    assert task.args == {'name': None}

# Generated at 2022-06-21 01:33:02.443407
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create a block
    block = Block()
    block._parent = block
    # create a role
    role = None
    # create a task_include
    task_include = None
    # create an IncludeRole object with the block, role and task_include created before
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    # set its properties
    ir._role_name = 'test_role'
    ir.name = 'test_role_name'
    ir.action = 'test_action'
    ir._parent = block
    ir.args = {'name': 'test_role'}
    ir._play = None
    ir.statically_loaded = True
    ir.public = False
    ir.allow_duplicates = True
    ir.rolespec_validate = True

# Generated at 2022-06-21 01:33:12.239571
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Input values
    name = 'role_name'
    args = {'name': name}
    block = Block([])
    role = Role()

    # Invoke constructor
    obj = IncludeRole(block, role)
    obj.load_data(args)

    # Assertion
    assert obj.action == 'include_role'
    assert obj._name == name
    assert obj._role_name == name
    assert obj._block == block
    assert obj._parent_role == role
    assert obj._parent == block
    assert obj._loader == None
    assert obj._from_files == {}
    assert obj._role_path == None

# Generated at 2022-06-21 01:33:21.857007
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block0 = Block()
    role0 = Role()
    task0 = IncludeRole(block=block0, role=role0)
    expected = {'ansible_parent_role_names': ['role0'],
                'role_name': None}
    actual = task0.get_include_params()
    assert actual == expected or (actual['ansible_parent_role_paths'].endswith('role0') and
                                  actual['ansible_parent_role_names'] == ['role0']),\
        "Expected: %r\nActual: %r" % (expected, actual)
    return True