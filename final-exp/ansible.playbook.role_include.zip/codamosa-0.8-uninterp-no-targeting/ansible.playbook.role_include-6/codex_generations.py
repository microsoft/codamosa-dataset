

# Generated at 2022-06-21 01:24:37.353922
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block(parent_block=None, role=None, task_include=None, always_run=False)
    ir = IncludeRole(block=block)
    ir_copy = ir.copy()
    assert(ir_copy and isinstance(ir_copy, Block)) 
    assert(ir_copy.parent and isinstance(ir_copy.parent, Block))
    assert(not ir_copy.task_include)
    assert(not ir_copy.role)
    assert(isinstance(ir_copy.args, dict))
    assert(ir_copy.always_run == ir.always_run)
    assert(ir_copy.parent.parent == ir.parent.parent)
    assert(ir_copy.parent.role == ir.parent.role)

# Generated at 2022-06-21 01:24:42.314583
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    name = "ntp"
    role_name = "roles/ntp"
    include_role = IncludeRole(name=name, role_name=role_name)
    assert include_role.get_name() == "%s : %s" % (include_role.action, role_name)

# Generated at 2022-06-21 01:24:54.799617
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create a fake include role
    ir = IncludeRole()
    ir._parent = None
    # Create a fake role
    role = Role()
    role.name = "role_name"
    role._role_path = "role_path"
    role._metadata = None
    # Create a fake variable manager
    variable_manager = None
    loader = None
    # Test with a real playbook
    play = Play.load(dict(name="play", hosts=['localhost'], gather_facts='no',
                          roles=[dict(role_name="role_name")],
                          tasks=[dict(action="include_role", args=dict(name="role_name"))]))
    # Run the method get_block_list of class IncludeRole

# Generated at 2022-06-21 01:25:02.308670
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    myloader = [{'name': 'myhost', 'hostname': 'myhost.example.com', 'other': {'key': 'value'}}]
    myvars = {'key1': 'value1', 'key2': 'value2'}
    myplay = {'hosts': ['all'], 'tasks': [{'include_role': {'name': 'fakerole', 'tasks_from': 'main.yml'}}]}

# Generated at 2022-06-21 01:25:13.916043
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Test the copy method of class IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    t = Task()
    ti = TaskInclude(task=t, name='foobar.yml')

    ir = IncludeRole(task_include=ti)
    ir._role_name = 'foobar'
    ir._parent_role = 'baz'
    ir._from_files = {'tasks': 'foo.yml', 'handlers': 'bar.yml'}

    ir_copy = ir.copy()
    assert ir_copy._role_name == 'foobar'
    assert ir_copy._parent_role == 'baz'
    assert not ir_copy._from_files == {}

# Generated at 2022-06-21 01:25:23.903433
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    #
    # for metadata
    #
    meta_data = {}
    def load_meta_file(name):
        return meta_data

    #
    # for bound_vars
    #
    variable_manager = lambda : None
    variable_manager.get_vars = lambda : { 'bound_var' : 'bound_value' }

    #
    # for loader
    #
    loader = lambda : None

    #
    # for parent role
    #
    role = lambda : None
    role._role_path = '/path1'

    #
    # for parent task
    #
    task = lambda : None
    task.action = 'import_role'
    task.get_include_params = lambda : { 'parent_task_var' : 'parent_task_value' }
    task._role = role


# Generated at 2022-06-21 01:25:34.278768
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    r1 = Role()
    r2 = Role()
    r2._parents = [r1]
    r1._children = [r2]
    i = IncludeRole()
    i._parent_role = r1
    copy = i.copy()
    assert copy._parent_role == i._parent_role
    assert copy._from_files == i._from_files
    assert copy._role_name == i._role_name
    assert copy._role_path == i._role_path
    assert copy.statically_loaded == i.statically_loaded
    assert copy.block == i.block
    assert copy.action == i.action
    assert copy.loop == i.loop
    assert copy.name == i.name
    assert copy.register == i.register
    assert copy.until == i.until
    assert copy.retries

# Generated at 2022-06-21 01:25:36.841253
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    t = IncludeRole()
    t._role_name = 'role_name'
    assert t.get_name() == "include_role : role_name"

# Generated at 2022-06-21 01:25:47.129299
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    class MyVars(object):
        def __init__(self):
            self.vars = { "foo": "bar" }

    class MyBlock(Block):
        def __init__(self, role):
            self._role = role

    class MyRole(Role):
        def __init__(self, name, metadata):
            self._metadata = metadata
            self._name = name

    # create test objects
    vars_object = MyVars()
    role_object = MyRole(name="foo", metadata={ "name": "foo", "src": "foo" })
    block_object = MyBlock(role_object)

    # invoke IncludeRole constructor
    ir = IncludeRole(role=role_object, block=block_object)
    ir.vars = vars_object.vars

    # test for the object's

# Generated at 2022-06-21 01:25:49.699962
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role()
    include_role = IncludeRole(block, role)
    variables = {}
    include_role.get_block_list(variables)

# Generated at 2022-06-21 01:26:17.846688
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from tasks import Tasks
    from plays import Play
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.vault import get_vault_secrets
    import ansible.constants as C
    import os
    import copy

    v = VariableManager()
    v.extra_vars = {'testvar': 'test'}
    v.options_vars = {'testoption': 'test'}
    v.ansible_version = {'full': C.__version__}
    v.ansible_facts_modified = True
    v.ansible_facts = {'ansible_facts_modified': True}


# Generated at 2022-06-21 01:26:27.838909
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    #Create dummy class : PlayContext
    class DummyPlayContext():
        def __init__(self, inventory, variable_manager, loader, options, passwords, run_once):
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.passwords = passwords
            self.run_once = run_once

    #Create dummy class : TaskQueueManager
    class DummyTaskQueueManager():
        def __init__(self, inventory, variable_manager, loader, settings, stdout_callback=None, run_tree=False, options=None, passwords=None, forks=None):
            self.inventory = inventory

# Generated at 2022-06-21 01:26:40.406455
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.errors import AnsibleError
    from ansible.modules.system import ping
    from unit_tests.mock.loader import DictDataLoader
    from unit_tests.mock.path import mock_unfrackpath_noop, mock_unfrackpath_success


# Generated at 2022-06-21 01:26:44.394957
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'name': 'myrole', 'public': 'yes'}
    ri = IncludeRole.load(data)
    assert ri.public == True
    assert ri._role_name == 'myrole'
    assert ri._role_path == None


# Generated at 2022-06-21 01:26:56.231827
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    block = Block()
    role = Role()

    include_role = IncludeRole(block, role)
    assert include_role._parent == block
    assert include_role._task_include is None
    assert include_role._role == role

    include_role = IncludeRole(role=role, task_include=block)
    assert include_role._parent == block
    assert include_role._task_include == block
    assert include_role._role == role

    include_role = IncludeRole(role=role, block=block)
    assert include_role._parent == block
    assert include_role._task_include is None
    assert include_role._role == role

    include_role = IncludeRole(block=block, task_include=role)
    assert include_role._parent == block
    assert include_role._task_include == role
   

# Generated at 2022-06-21 01:27:06.544341
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # pylint: disable=too-many-locals
    display.verbosity = 3

    my_play = Play().load({'name': 'Test Play'}, variable_manager=None, loader=None)
    my_block = Block().load({'name': 'Test Block', 'parent': my_play}, variable_manager=None, loader=None)

    my_role = Role().load({'name': 'Test Role'}, variable_manager=None, loader=None)
    # fake the role name
    my_role.name = "test-role"

    my_task = IncludeRole().load

# Generated at 2022-06-21 01:27:06.991951
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-21 01:27:13.419565
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play import Play
    from ansible.template import Templar

    test_play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [ 'test_role' ],
    ))

    include = IncludeRole.load(dict(
        name = "test_role",
    ), play=test_play)

    new_include = include.copy()

    assert include.name == new_include.name
    assert include._block.name == new_include._block.name
    assert include.action == new_include.action
    assert include.loop == new_include.loop
    assert include.delegate_to == new_include.delegate_to
    assert include.when == new_include.when
    assert include.tags

# Generated at 2022-06-21 01:27:24.817766
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-21 01:27:27.773647
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    IR = IncludeRole.load({'role': 'myrole'}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert(IR._role_name == 'myrole')

# Generated at 2022-06-21 01:27:52.936707
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    include_role = IncludeRole({}, role=object())
    include_role._name = 'task'
    include_role._role_name = 'role_name'
    include_role.statically_loaded = True
    include_role.loop = 'loop'
    include_role._from_files = {'tasks': 'tasks'}
    include_role._role_path = '/role_path'
    include_role.tags = ['tags']
    include_role.when = 'when'

    include_role_copy = include_role.copy()

    assert include_role_copy.action == 'include_role'
    assert include_role_copy._name == 'task'
    assert include_role_copy._role_name == 'role_name'
    assert include_role_copy.statically_loaded
    assert include_

# Generated at 2022-06-21 01:28:04.101430
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-21 01:28:09.694098
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.block import Block

    class MockLoader:
        pass

    class MockVarManager:
        pass

    block = Block()
    block.role = 'test'
    block.vars = {'first': 'first'}
    block.dep_chain = []

    block_2 = Block()
    block_2.role = 'test_2'
    block_2.vars = {'block_2_first': 'block_2_first'}
    block_2.dep_chain = []

    block.dep_chain.append(block_2)

    include_role = IncludeRole()
    include_role.name = 'name'
    include_role.action = 'action'
    include_role._parent_role = block
    include_role._role_name = 'role_name'

   

# Generated at 2022-06-21 01:28:16.815778
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role

    role = Role(name='test_name')
    role._metadata = {'name': 'role_name'}
    role._role_path = '/role/path'

    include_role = IncludeRole(role=role)

    expected = {'ansible_role_names': ['test_name'], 'ansible_role_paths': ['/role/path'], 'ansible_parent_role_names': ['role_name'], 'ansible_parent_role_paths': ['/role/path']}
    ret = include_role.get_include_params()
    assert ret == expected

# Generated at 2022-06-21 01:28:25.803629
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    test_name = 'test_name'
    test_role_name = 'test_role_name'
    test_role_path = 'test_role_path'

    task_include = TaskInclude(name=test_name)
    role = Role()
    block = Block()
    include_role = IncludeRole(block=block, role=role, task_include=task_include)

    assert test_name == include_role.get_name()
    include_role._role_name = test_role_name
    include_role._role_path = test_role_path
    assert test_role_name == include_role._role_name
    assert test_role_path == include_role._role_path

# Generated at 2022-06-21 01:28:30.312527
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Mock the role object
    role = 'my_role'

    # Use the IncludeRole.get_block_list
    block = IncludeRole.get_block_list(role)
    assert block is not None

# Generated at 2022-06-21 01:28:40.449472
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test loading of IncludeRole
    assert IncludeRole.load(dict(name='foo'))
    assert IncludeRole.load(dict(role='foo'))

    # test loading dynaimc
    assert IncludeRole.load(dict(name='foo'), block=Block())

    # test bad args
    from ansible.module_utils.six import PY3
    if PY3:
        import pytest
        with pytest.raises(AnsibleParserError):
            assert IncludeRole.load(dict(foo='bar'))

# Generated at 2022-06-21 01:28:54.996345
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="/etc/ansible/hosts")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbooks = ['/etc/ansible/playbook.yml']
    action_loader._add_directory(C.action_loader, 'actions')

# Generated at 2022-06-21 01:29:03.537787
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.plugins.loader import dynamic_plugin_getters
    from ansible.plugins.loader import get_plugin_loader
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager

    # change base directory for unit test purpose
    C.DEFAULT_ROLES_PATH = '../../roles'

    # load plugins
    dynamic_plugin_getters.add('lookup', 'ansible.parsing.vault_lookup_plugin')
    dynamic_plugin_getters.add('filter', 'ansible.parsing.filter_plugin')

# Generated at 2022-06-21 01:29:14.707891
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """Role - Method ``copy``.
    """
    # test function of method copy of class IncludeRole

    display.display(display.Traceback())

    # create a IncludeRole object
    blk = Block()
    blk.role = "ROLE_NAME"
    blk.task = "TASK_NAME"
    ir = IncludeRole(blk)

    new_ir = ir.copy()
    assert new_ir.__class__.__name__ == 'IncludeRole'

    # set variable to the object 'new_ir'
    new_ir.vars = dict(KEY_NAME='KEY_VALUE')
    assert new_ir.vars['KEY_NAME'] == 'KEY_VALUE'

    # get variable from the object 'new_ir'
    result_vars = new_ir.get_vars()

# Generated at 2022-06-21 01:29:58.873655
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir1 = IncludeRole(block, role, task_include)
    ir1.private = 'private'

    ir1.statically_loaded = True
    ir1._from_files = {'tasks': 'tasks.yml'}
    ir1._parent_role = role
    ir1._role_name = 'test_name'
    ir1._role_path = 'test_path'

    ir2 = ir1.copy(exclude_parent=True, exclude_tasks=True)

    assert ir1.name == ir2.name
    assert ir1.block == ir2.block
    assert ir1.args == ir2.args
    assert ir1.action == ir2.action
    assert ir1.action == ir

# Generated at 2022-06-21 01:30:05.718219
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play = Play().load({'name': 'foo', 'hosts': 'all'})
    play_context = PlayContext()

    parent_role = Role().load({'name': 'child_role', 'tasks': []})
    parent_role._role_path = '/path/to/child_role'
    parent_role_params = parent_role.get_role_params()

    include_role = IncludeRole()
    include_role.action = 'include_role'
    include_role._role_name = 'foo_role'

# Generated at 2022-06-21 01:30:11.168249
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_ir = IncludeRole()
    # Check bad args
    test_data = dict(name="test_role")
    test_data['bad_args'] = 'bad_value'
    result_ir = IncludeRole.load(test_data, block=Block())
    assert result_ir.args == test_data
    # Check good args
    test_data = dict(name="test_role")
    test_data['apply'] = 'bad_value'
    result_ir = IncludeRole.load(test_data)
    assert result_ir.args == test_data
    test_data = dict(name="test_role")
    test_data['public'] = 'bad_value'
    result_ir = IncludeRole.load(test_data)
    assert result_ir.args == test_data

# Generated at 2022-06-21 01:30:21.550016
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    print("Test case: test_IncludeRole_copy")
    # Make a mock IncludeRole
    mock_from_files = {"tasks": "main.yaml", "handlers": "hello.yaml"}
    mock_role_name = "mock_role"
    mock_role_path = "mock_path" 
    mock_parent_role = "mock_parent"
    mock_statically_loaded = False
    mock_allow_duplicates = True
    mock_rolespec_validate = False
    mock_args = {"tasks_from": "main.yaml", "handlers_from": "hello.yaml"}
    mock_action = "mock_action"
    mock_name = "mock_name"
    mock_c_list = "mock_c_list"
    mock

# Generated at 2022-06-21 01:30:28.604375
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    task_block = Block.load(dict(name='test block', tasks=[
      dict(action='test_section_include', name='test section include', include_role=dict(name='test_include_role')),
      dict(action='test_section_include', name='test section include', include_tasks=dict(name='test_role_tasks'))
    ]))

    loader = None
    variable_manager = None
    play = None

    # test case 1
    task = task_block.block.pop()
    task_include = task._task_include
    task_include._role = None
    task_include._parent_role = None
    res = task_include.get_include_params()
    assert isinstance(res, dict)

    # test case 2
    task = task_block.block.pop()


# Generated at 2022-06-21 01:30:33.216929
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    # TaskInclude
    i = TaskInclude()
    # IncludeRole
    ir = IncludeRole()

    # ensure IncludeRole.__init__() went fine
    assert isinstance(ir, TaskInclude)
    assert isinstance(ir, Block)
    assert not isinstance(ir, IncludeRole)

    # test IncludeRole.copy() and TaskInclude.copy()
    assert ir.copy() is not ir
    assert i.copy() is not i

# Generated at 2022-06-21 01:30:38.483630
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    a = IncludeRole()
    b = a.copy()
    assert a.statically_loaded == b.statically_loaded
    assert a._from_files == b._from_files
    assert a._parent_role == b._parent_role
    assert a._role_name == b._role_name
    assert a._role_path == b._role_path

# Generated at 2022-06-21 01:30:46.461978
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # This method of the class is tested here
    from ansible.playbook import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude

    import ansible.constants as C
    import os

    # We create a new class to overload the method load of the class RoleInclude
    # with a method that return itself in order to test correctly this method here

# Generated at 2022-06-21 01:30:57.465227
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os

    # Test 1: Invalid role name.
    role = IncludeRole()
    role._role_name = 'non_existing_ansible_role'
    try:
        role.get_block_list()
        raise AssertionError("Should not reach here")
    except IOError as e:
        if 'No such file or directory' not in str(e):
            raise AssertionError("Unexpected exception: " + str(e))

    # Test 2: Invalid role name, which is a directory but not ansible role.
    role = IncludeRole()
    role._role_name = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-21 01:31:05.723766
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # 1.
    # Test that 'handlers_from' and 'tasks_from' are in the 'from_files' dictionary
    # when they have values.

    # 'handlers_from' and 'tasks_from' should be in 'from_files' dictionary
    role_data = {
        'name': 'include_role',
        'include_role': {
            'name': 'my-role',
            'handlers_from': 'my-handlers',
            'tasks_from': 'my-tasks',
            'vars_from': 'my-vars'
        }
    }
    expect_from_files = {
        'handler': 'my-handlers',
        'tasks': 'my-tasks'
    }

    role = IncludeRole.load(role_data)
    blocks,

# Generated at 2022-06-21 01:32:20.962160
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    role = Role()
    include_role = IncludeRole(role=role)
    assert include_role.action == 'include_role'
    assert include_role.name == 'AnsibleIncludeRole'
    assert include_role._parent_role == role
    assert include_role._from_files == {}
    assert include_role.allow_duplicates
    assert not include_role.public
    assert include_role.rolespec_validate

# Generated at 2022-06-21 01:32:31.918081
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = dict(
        all=dict(
            children=dict(
                ungrouped=dict(
                    hosts=dict(
                        localhost=dict(
                            ansible_connection='local',
                            ansible_host='127.0.0.1',
                            ansible_user='test'
                        )
                    )
                )
            )
        )
    )

    variable_manager._extra_vars = dict()
    variable_manager.set_inventory(inventory)

    src_role = dict(name='test_role', path='test_role')

# Generated at 2022-06-21 01:32:40.214592
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    variables = {'foo': 'bar'}
    variable_manager = VariableManager()
    variable_manager.extra_vars = variables
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost']))
    r = include_role(name='myrole', variables=variables)
    i = IncludeRole.load(r, variable_manager=variable_manager)


# Generated at 2022-06-21 01:32:52.769865
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    import sys
    # ansible_dir is the path to the directory where Ansible is installed
    ansible_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    sys.path.insert(0, ansible_dir)
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    display = Display()
    loader = DataLoader()
    play_context = PlayContext()
    variable_manager = VariableManager()
    action = 'include_role'
    data = dict(name='myrole', tasks_from='tasks.yml')
    block = Block()
    task_include = TaskIn

# Generated at 2022-06-21 01:33:04.473003
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    obj1 = IncludeRole(role=None, from_files={u'vars': u'vars/main.yml', u'handlers': u'handlers/main.yml', u'tasks': u'main.yml'})
    obj1.action = u'include_role'
    obj1._parent = None
    obj1.allow_duplicates = True
    obj1.always_run = False
    obj1.any_errors_fatal = False
    obj1.args = {u'skip_tags': [u'dontrun'], u'name': u'foobar'}
    obj1.async_val = 0
    obj1.async_seconds = 0
    obj1.block = None
    obj1.collections = []
    obj1.conditional = None
    obj1.de

# Generated at 2022-06-21 01:33:14.398315
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Instantiate a new field attribute with "age" as the field name
    my_field_attribute = FieldAttribute("age")
    # Instantiate a new field attribute with "age" as the field name
    my_field_attribute2 = FieldAttribute("age")
    # Instantiate a new field attribute with "age" as the field name
    my_field_attribute3 = FieldAttribute("age")

    # Instantiate a new IncludeRole object, that does not inherits of TaskInclude
    my_IncludeRole = IncludeRole()

    # Instantiate two new Role objects
    my_Role = Role()
    my_Role2 = Role()

    my_Role._metadata = my_field_attribute
    my_Role._metadata.name = "name"
    my_Role._metadata.collection = "collection"
    my_Role._metadata.allow_dupl

# Generated at 2022-06-21 01:33:24.421141
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    ds = DataLoader()
    variable_manager = VariableManager()

    play_context.variable_manager = variable_manager
    variable_manager.set_play_context(play_context)

    role = Role()

    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = {'name': 'foo'}
    ir.post_validate(ds, variable_manager)
    (blocks, handlers) = ir.get_block_list(play=None, variable_manager=variable_manager, loader=ds)
    assert blocks == []
    assert handlers == []

# Generated at 2022-06-21 01:33:31.238891
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir.private is True
    assert ir.statically_loaded is False
    assert ir.args == {}
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True
    assert ir._from_files == {}
    assert ir._parent_role is None
    assert ir._role_name is None
    assert ir._role_path is None



# Generated at 2022-06-21 01:33:42.867277
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    #If main function
    if __name__ == '__main__':
        data_a = [
            "name",
            "role",
            "options_hash",
            "metadict",
            "tags",
            "when",
            "dep_chain",
            "statically_loaded"
        ]
        data_b = [
            "name",
            "role",
            "options_hash",
            "metadict",
            "collections",
            "tags",
            "when",
            "dep_chain",
            "statically_loaded"
        ]
        # Create object class Include_Role and check whether the variables are empty
        obj = IncludeRole()
        if vars(obj) == {}:
            print("\n The Include_Role object is empty!\n")

        #Test case for load

# Generated at 2022-06-21 01:33:52.510269
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role

    play = Play().load({
        'name': 'test play',
        'hosts': 'local',
    }, variable_manager=None, loader=None)

    play_context = PlayContext()
