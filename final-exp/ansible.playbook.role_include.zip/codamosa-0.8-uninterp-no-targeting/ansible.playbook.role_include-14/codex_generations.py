

# Generated at 2022-06-21 01:24:37.989771
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """returning the expected dict"""
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.playbook.role.definition
    import ansible.playbook.block
    import ansible.template.template
    myblock = ansible.playbook.block.Block()
    myparent_role = ansible.playbook.role.definition.RoleDefinition()
    myparent_role._role_path='/var/folders/xw/yw36k38j1k17fvnry6h9bhsr0000gn/T/tmpVLcCG0/test/parent_role'

# Generated at 2022-06-21 01:24:40.973949
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir,Block)
    assert isinstance(ir,TaskInclude)
    assert isinstance(ir,IncludeRole)

# Generated at 2022-06-21 01:24:44.940364
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    Block.load(dict(
        name = 'Test',
        hosts = 'all',
        tasks = [
            dict(
                include_role='some.role'
            )
        ]
    ))

# Generated at 2022-06-21 01:24:56.572367
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.role.meta import RoleMetadata

    p = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'roles': [
            {
                'name': 'first',
                'include_role': {
                    'name': 'first',
                    'apply': {
                        'ignore_errors': True,
                    },
                },
            },
            {
                'name': 'second',
                'include_role': {
                    'name': 'second',
                    'apply': {
                        'ignore_errors': True,
                    },
                },
            },
        ]
    }, variable_manager=None, loader=None)
    p._tasks

# Generated at 2022-06-21 01:25:03.155410
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.tasks_from = "tasks/main.yml"
    ir.vars_from = "defaults/main.yml"
    ir.defaults_from = "defaults/main.yml"
    ir.handlers_from = "handlers/main.yml"
    ir.allow_duplicates = True
    ir.public = True
    ir.rolespec_validate = False
    ir._role_name = "my_role"
    block = Block()
    block.name = "my_block"
    ir._parent = block
    # The following values will not be reassigned
    ir._parent_role = "parent_role"
    ir._role_path = "path/to/role"
    ir.collections = "collection_name"
    ir

# Generated at 2022-06-21 01:25:11.068018
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    assert include_role._allow_duplicates == True
    assert include_role._from_files == {}
    assert include_role._parent_role == role
    assert include_role._public == False
    assert include_role._role_name == None
    assert include_role._role_path == None
    assert include_role._rolespec_validate == True

# Generated at 2022-06-21 01:25:22.027337
# Unit test for method get_include_params of class IncludeRole

# Generated at 2022-06-21 01:25:33.080207
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    ir = IncludeRole()
    ir.name = "test_include_role"
    ir.action = "include_role"
    ir._role_name = "test_role"
    myplay = Play().load({})
    myblock = Block(myplay)
    ir._parent = myblock
    assert ir.get_name() == "test_include_role"

    ir = IncludeRole()
    ir.name = ""
    ir.action = "include_role"
    ir._role_name = "test_role"
    myplay = Play().load({})
    myblock = Block(myplay)
    ir._parent = myblock
    assert ir.get_name() == "include_role : test_role"

# Generated at 2022-06-21 01:25:37.747342
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    ir = IncludeRole()
    ir.name = False
    ir.action = 'include_role'
    ir._role_name = 'role_name'

    name = ir.get_name()

    assert name == 'include_role : role_name'


# Generated at 2022-06-21 01:25:47.639109
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # play 1 (role1) -> play 2 (role2) -> play 3
    # plays 1 and 2 are included in 3, so play 3 should inherit variables from
    # both roles 1, 2 and self.

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources='localhost,')
    variable

# Generated at 2022-06-21 01:26:04.935031
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    new_ir = IncludeRole(None, None, None)
    assert new_ir.copy is IncludeRole.copy
    new_ir.statically_loaded = True
    new_ir._from_files = {'tasks': 'a'}
    new_ir._parent_role = 'Role'
    new_ir._role_name = 'test'
    new_ir._role_path = 'test'

    new_ir_copy = new_ir.copy()

    for attr in ('statically_loaded', '_from_files', '_parent_role', '_role_name', '_role_path'):
        assert getattr(new_ir, attr) == getattr(new_ir_copy, attr)

    assert new_ir_copy.exclude_parent == False
    assert new_ir_copy.ex

# Generated at 2022-06-21 01:26:17.043535
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import become_loader, action_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=['localhost'])

    # create a play to instantiate the task
    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-21 01:26:27.282486
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole.load({'include_role': {'name': 'test_role'}})
    ir.play_context.update({'tags': ['a']})
    ir.name = 'test_name'
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'
    ir._parent_role = {'a': 'b'}
    ir._from_files = {'tasks': 'tasks', 'vars': 'vars'}

    ir1 = ir.copy()
    assert ir.name == ir1.name
    assert ir._role_name == ir1._role_name
    assert ir._role_path == ir1._role_path
    assert ir.play_context == ir1.play_context
    assert ir._parent_role == ir

# Generated at 2022-06-21 01:26:34.205647
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role()
    task_include = "test_task_include"
    include_role = IncludeRole(block, role, task_include=task_include)

    try:
        include_role.get_block_list()
        assert False
    except Exception:
        assert True
    except:
        assert False
    else:
        assert False

# Generated at 2022-06-21 01:26:39.595969
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    display = Display()
    display.verbosity = 3

    ds = dict(
        action="include_role",
        name="my_role"
    )
    ir = IncludeRole.load(ds)
    assert ir._role_name == 'my_role'
    assert ir._from_files == {}
    assert ir.allow_duplicates is True
    assert ir.public is False
    assert ir.rolespec_validate is True
    assert ir.apply == {}


# Generated at 2022-06-21 01:26:46.043453
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader


    loader = DataLoader()
    p = PlayContext()
    tqm = TaskQueueManager(loader=loader, inventory='/etc/ansible/hosts', variable_manager=None)
    i = IncludeRole.load(dict(task='include_role', name='role', public=True, allow_duplicates=False, rolespec_validate=False), role=None, task_include=None, tqm=tqm, loader=loader)
    assert i.action == 'include_role'
    assert i.name == 'role'
    assert i._public == True

# Generated at 2022-06-21 01:26:47.987533
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    i = IncludeRole()
    assert isinstance(i.get_include_params(), dict)

# Generated at 2022-06-21 01:26:59.652325
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)

    # create a parent role with a single include_role

# Generated at 2022-06-21 01:27:08.915698
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test 1: role already present in the play
    # Setup
    import ansible.playbook.play_context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    yaml_text = """
- hosts: localhost
  roles:
    - some_role
  tasks:
    - include_role:
        name: some_role
      tags:
        - include_role
"""
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader

# Generated at 2022-06-21 01:27:14.306588
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Arrange
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.name = 'ansible_role'
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'tasks', 'handlers': 'handlers', 'vars': 'vars', 'defaults': 'defaults'}
    ir._parent_role = 'role'
    ir._role_name = '_role_name'
    ir._role_path = '_role_path'
    ir.task = ("tasks", True, 'role', 'block', 2, 'include_role', 0)

    # Act
    new_me = ir.copy(exclude_parent=False, exclude_tasks=False)

    # Assert
    assert new_me.__class__.__name__

# Generated at 2022-06-21 01:27:30.604135
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # If there is no name or role, raise AnsibleParserError
    data = dict(action = 'include_role', args = dict(tasks_from = 'tasks/main.yml'))
    block = Block(parent_block=None, role=None, task_include=None, use_handlers=False, defaults=dict())
    role=None
    task_include=None
    variable_manager=None
    loader=None
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    try:
        ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    except Exception as e:
        assert type(e) == AnsibleParserError
        assert str(e) == "'name' is a required field for include_role."

    #

# Generated at 2022-06-21 01:27:42.073158
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar

    # (1) Test get_include_params() when neither parent_role nor _parent is set

    ir = IncludeRole()

# Generated at 2022-06-21 01:27:51.137568
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = dict(
        name='common',
        vars=dict(foo='bar', bar='baz')
    )
    ir = IncludeRole.load(data)
    ir._valid_names = frozenset(['name', 'rolespec_validate'])
    ir._valid_attrs = frozenset(['name', 'rolespec_validate'])
    assert ir.name == 'common'
    assert ir.rolespec_validate is True
    assert ir.args == dict(name='common')
    assert ir.vars == dict(foo='bar', bar='baz')
    assert ir.action == 'include_role'


# Generated at 2022-06-21 01:28:03.427280
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

    # Test IncludeRole.VALID_ARGS
    assert IncludeRole.VALID_ARGS == frozenset(['rolespec_validate', 'vars_from', 'tasks_from', 'name', 'role', 'defaults_from', 'apply', 'handlers_from', 'public', 'allow_duplicates'])

    # Test _role_name field gets name-argument
    result = IncludeRole.load(dict(name="test_name", role="test_role"), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:28:08.914144
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    action='test'
    name='test_name'
    role='test_role'

    block=Block()
    role_obj=Role()
    task_include=TaskInclude()

    assert IncludeRole(block,role_obj,task_include).get_name()=="tasks : test"
    assert IncludeRole(block,role_obj,task_include,action=action,name=name).get_name()=="test : test_name"
    assert IncludeRole(block,role_obj,task_include,role=role).get_name()=="test : test_role"
    assert IncludeRole(block,role_obj,task_include,action=action,role=role).get_name()=="test : test_role"

# Generated at 2022-06-21 01:28:12.447528
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.verbosity = 3
    block = Block()
    role = Role()
    include_role = IncludeRole(block, role)
    assert include_role.get_name() == "include_role : "

# Generated at 2022-06-21 01:28:21.970783
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest

    def _fake_load_role(self, role_path):
        self._role_path = role_path

    Role._load_role = _fake_load_role

    # without valid data
    with pytest.raises(AnsibleParserError) as err:
        IncludeRole.load(data=None, block='block', role='role', task_include='task_include', variable_manager='variable_manager', loader='loader')


# Generated at 2022-06-21 01:28:34.280739
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class MockRole:
        def __init__(self, _metadata):
            self._metadata = _metadata
            self._role_path = 'some_path'
            self.collections = []

    class MockBlock:
        def __init__(self, _parent):
            self._parent = _parent
            self.collections = []


    ir = IncludeRole()
    ir._role_name = 'name_of_role'
    role = MockRole({})
    role.compile = lambda *args, **kwargs: [MockBlock(None)]
    ir._parent_role = role
    ir._play = {
        'roles': []
    }
    ir._from_files = {}

    block_list, handlers = ir.get_block_list()
    assert len(block_list) == 1
    assert block

# Generated at 2022-06-21 01:28:45.503903
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    def print_dict(input_dict):
        for k in input_dict:
            v = input_dict[k]
            print(k, v)

    from ansible.playbook.role import Role
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.roles import parse_roles_spec
    from ansible.utils.path import unfrackpath
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    role_metadata = RoleMetadata()
    role_metadata.name = 'test_role'
    role_metadata._role_path = unfrackpath("test1")
    role_metadata.role_spec = parse_roles_spec('test_role', path_type='role')


# Generated at 2022-06-21 01:28:55.345896
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    import yaml

    if not os.path.exists('test.yml'):
        print('test.yml file not found')
        print('Use: python -m test.units.test_IncludeRole')
        sys.exit(1)

    with open('test.yml', 'r') as f:
        data = f.read()

    login_task = yaml.safe_load(data)
    print(login_task)
    print(login_task['tasks'][0]['include_role'])
    ir = IncludeRole.load(login_task['tasks'][0]['include_role'])
    print(ir)
    blocks, handlers = ir.get_block_list()
    print(blocks)
    print(handlers)

# Generated at 2022-06-21 01:29:14.425259
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import fragment_loader

    # Setup
    rd = RoleDefinition('bar', 'roles/bar', 'roles/bar/vars/main.yml', 'roles/bar/tasks/main.yml', 'roles/bar/meta/main.yml')
    play_context_variable_manager = VariableManager()
    loader = fragment_loader

# Generated at 2022-06-21 01:29:17.671384
# Unit test for method get_name of class IncludeRole

# Generated at 2022-06-21 01:29:26.096545
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    r = Role()
    r.name = "a_role"
    r._role_path = "../a_role"
    t = IncludeRole()
    t.statically_loaded = True
    t._parent_role = r
    t._role_name = "b_role"
    t._role_path = "../b_role"
    t._from_files = {'tasks': 'main.yml'}
    assert t.args['name'] == 'b_role'
    assert t.statically_loaded is True
    assert t._parent_role.name == 'a_role'
    assert t._parent_role._role_path == '../a_role'
    assert t._role_name == 'b_role'
    assert t._role_path == '../b_role'
    assert t._from

# Generated at 2022-06-21 01:29:36.003966
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
  compare_result = IncludeRole(block=None, role=None, task_include=None)
  compare_result.args = {
      'name': 'controller',
      'apply': {
          'tags': 'all'
      },
      'public': True
  }

  role_data = {
      'include_role': 'controller',
      'apply': {
          'tags': 'all'
      },
      'public': True
  }

  result = IncludeRole.load(data=role_data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

  assert result.args == compare_result.args


# Generated at 2022-06-21 01:29:44.226543
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """ Test_IncludeRole_get_block_list - test method get_block_list of class IncludeRole.
    """
    from ansible.playbook import Play
    import ansible.module_utils.six as six

    myblock = Block()
    myblock.vars = {"var1": "a", "var2": "b"}

    try:
        my_result = IncludeRole().get_block_list()
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    my_result = IncludeRole(block=myblock).get_block_list()
    assert isinstance(my_result, tuple)
    assert my_result[0] == []
    assert my_result[1] == []

    my_Play = Play()

# Generated at 2022-06-21 01:29:55.015284
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    try:
        from ansible.playbook.play_context import PlayContext
        from ansible.vars.manager import VariableManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.playbook.play import Play
    except ImportError:
        print("collection lib is too old?")
        return

    class FakeRole(Role):
        @staticmethod
        def load(role_include, play=None, variable_manager=None, loader=None):
            return Role(loader=loader)

    ir = IncludeRole()
    ir._role_name = "fake_role"
    ir.args = dict(name=ir._role_name)
    ir._parent_role = FakeRole(loader=DataLoader())

# Generated at 2022-06-21 01:29:55.969642
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    pass

# Generated at 2022-06-21 01:30:00.296318
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    display = Display()
    display.verbosity = 3
    block = Block()
    parent_role = Role()
    task_include = TaskInclude()
    data = {'block': block,
            'role': parent_role,
            'task_include': task_include}
    instance = IncludeRole(**data)
    instance.copy()

# Generated at 2022-06-21 01:30:12.667070
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host, Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    import ansible.constants as C

    # create play
    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VarsModule()
    variable_manager._fact

# Generated at 2022-06-21 01:30:16.469875
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = IncludeRole()
    role.name = "test"
    assert role.get_name() == "test"
    role.action = "include_role"
    role._role_name = "role"
    assert role.get_name() == "include_role : role"

# Generated at 2022-06-21 01:30:38.239169
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ##############################
    # role is required
    data = dict(
        include_role=dict(),
    )
    # noinspection PyBroadException
    try:
        IncludeRole.load(data)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert e.message == "'role' is a required field for include_role."

    ##############################
    # when include_role is dynamic, name and statically_loaded are not allowed
    data = dict(
        include_role=dict(
            role="myrole",
            name="myname",
            statically_loaded=True,
        ),
        when="1==1",
    )
    # noinspection PyBroadException
    try:
        IncludeRole.load(data)
    except Exception as e:
        assert isinstance

# Generated at 2022-06-21 01:30:46.329081
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    from ansible.vars import VariableManager
    from ansible.module_utils.six import StringIO

    display = Display()
    loader = role_loader
    variable_manager = VariableManager()

    correct_role_vars = dict(a=1, b=2, c=3)
    loader.set_basedir(path=u"some_path")
    loader.set_basedir(path=u"another_path")
    loader.path_exists(u"some_path")
    loader.path_exists(u"another_path")
    loader.set_variable_manager(variable_manager=variable_manager)

# Generated at 2022-06-21 01:30:57.425339
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys

    import six
    from ansible.module_utils.common.dicts import merge_hash
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Template
    from ansible.template.template import AnsibleTemplate
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.errors import AnsibleParserError


# Generated at 2022-06-21 01:31:02.548646
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(block=None, role=None, task_include=None).get_name() == "include_role : None"
    assert IncludeRole(block=Block.load(data={'name': 'test'}, parent_block=None), role=None, task_include=None).get_name() == "test"
    assert IncludeRole(block=Block.load(data={'name': 'test'}, parent_block=None), role=None, task_include=None).get_name() == "test"

# Generated at 2022-06-21 01:31:09.189497
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = False
    ir._from_files = {'foo':'bar'}
    parent_role = Role()
    ir._parent_role = parent_role
    ir._role_name = 'test_role'
    ir._role_path = '/path/to/role'
    new_ir = ir.copy()
    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from_files == ir._from_files
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_name == ir._role_name
    assert new_ir._role_path == ir._role_path

# Generated at 2022-06-21 01:31:21.434158
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = {}
    data['name'] = 'test'
    blk = Block()
    rl = Role(dict(name='test'))
    tsk = TaskInclude(block=blk, role=rl, task_include=None)
    variable_manager = VariableManager()
    loader = DataLoader()
    instance = IncludeRole.load(
        data=data,
        block=blk,
        role=rl,
        task_include=tsk,
        variable_manager=variable_manager,
        loader=loader
    )
    assert instance.name == 'test'

# Generated at 2022-06-21 01:31:33.063699
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Create the object
    task = IncludeRole()
    # Set the value for name
    task.name = "name"
    # Set the value for metadata
    task.action = "action"
    # Set the value for loop
    task.loop = { "a": "b" }
    # Set the value for with_items
    task.with_items = []
    # Set the value for with_fileglob
    task.with_fileglob = "with_fileglob"
    # Set the value for with_items
    task.with_first_found = []
    # Set the value for when
    task.when = "when"
    # Set the value for async_poll_interval
    task.async_val = 5
    # Set the value for async_seconds
    task.async_seconds = 5
   

# Generated at 2022-06-21 01:31:43.951204
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role_name = 'role_name'
    action = 'action'
    args = {'args': 'args'}
    tasks = []
    vars = {'vars': 'vars'}
    block = Block(role_name=role_name, task_include=action, args=args, tasks=tasks)
    role = Role(name=role_name)
    task_include = 'task_include'
    test_include_role = IncludeRole(block=block, role=role, task_include=task_include)
    test_include_role.vars = vars

    new_include_role = test_include_role.copy()
    assert new_include_role._parent_role == role
    assert new_include_role._parent_role == role
    assert new_include_role._role_name == role

# Generated at 2022-06-21 01:31:53.648990
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test for class type assertions
    assert isinstance(IncludeRole.BASE, tuple), "'BASE' variable should be of type tuple."
    assert isinstance(IncludeRole.FROM_ARGS, tuple), "'FROM_ARGS' variable should be of type tuple."
    assert isinstance(IncludeRole.OTHER_ARGS, tuple), "'OTHER_ARGS' variable should be of type tuple."
    assert isinstance(IncludeRole.VALID_ARGS, tuple), "'VALID_ARGS' variable should be of type tuple."

    # test for load method to raise exception when name or role is not provided
    data = dict(action='- include_role')
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data, block=Block())

    data = dict(action='- import_role')


# Generated at 2022-06-21 01:32:03.593706
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,  host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()


# Generated at 2022-06-21 01:32:35.309406
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    role.name = "/path/to/role"
    task_include = TaskInclude()
    task_include.name = "/path/to/task"

    # test empty data
    try:
        ir = IncludeRole.load(data = dict(), block = block, role = None, task_include=task_include)
        assert False
    except AnsibleParserError as e:
        pass

    # test empty role
    try:
        ir = IncludeRole.load(data = dict(name = ""), block = block, role = role, task_include=None)
        assert False
    except AnsibleParserError as e:
        pass

    # test empty name

# Generated at 2022-06-21 01:32:42.584518
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.block import Block

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    r = Role()
    r.get_name = lambda : 'myrole'
    r.get_path = lambda : '/home/user/workspace/test-project/roles/myrole'
    ir = IncludeRole()

    ir._parent_role = r

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources='')
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)
    play

# Generated at 2022-06-21 01:32:53.727626
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create IncludeRole
    include_role = IncludeRole(
        block=None,
        role=None,
        task_include=None,
    )
    include_role.name = 'name'
    include_role._role_name = 'role_name'
    include_role.action = 'include_role'
    include_role.tags = 'test'
    include_role.when = 'test'
    include_role._ignore_errors = True

    # Create an include role and add it to parent role
    parent_role = Role()
    parent_role.name = 'parent_role'
    parent_role._role_path = '/path/to/parent_role'
    parent_role._metadata.dependencies = ['dependency_role']

    # Test
    include_role._parent_role = parent_role
    result

# Generated at 2022-06-21 01:33:05.010365
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Common fixtures
    host = "hostname"
    block = Block()
    role = Role()
    task_include = TaskInclude(block=block, role=role)
    # Role name is required and missing
    data = {'action': 'include_role'}
    try:
        IncludeRole.load(data=data, block=block, role=role, task_include=task_include)
    except AnsibleParserError as e:
        assert "name' is a required field for include_role" in str(e)
    # Role name is required and missing (alias)
    data = {'action': 'include_role', 'name': 'mysql_database'}

# Generated at 2022-06-21 01:33:14.529070
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    import sys
    import os
    import imp

    file_name, file_ext = os.path.splitext(__file__)
    data_file = file_name + ".dat"

    with open(data_file, 'rb') as my_data_file:
        data = my_data_file.read()

    # Create a dictionary for a role as load_data needs a dictionary as an input.
    data = eval(data)

    # Create an object of class IncludeRole.
    ir = IncludeRole(block=None, role=None)
    ir1 = ir.load_data(data)

    assert ir1._task_include.action == 'include_role'
    assert ir1._role_name == 'meta'
    assert ir1.args['name'] == 'meta'

# Generated at 2022-06-21 01:33:24.450173
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    This test checks the behaviour of the AnsibleTask.copy method.
    It checks the copy of IncludeRole objects
    """

    # Creation of the base object
    include_role = IncludeRole()
    include_role.name = 'name'
    include_role.tasks = [{'name': 'task1'}]
    include_role.handlers = [{'name': 'handler1'}]
    include_role.tags = ['tag1']
    include_role.ignore_errors = 'yes'
    include_role.always_run = 'yes'
    include_role.register = 'result'
    include_role.delegate_to = 'localhost'
    include_role.become = 'yes'
    include_role.become_method = 'su'

# Generated at 2022-06-21 01:33:33.219801
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()

    # test no parent_role
    assert ir.get_include_params() == {'role_names': [],
                                       'role_paths': [],
                                       'role_params': [],
                                       'parent_role_names': [],
                                       'parent_role_paths': []}

    # test parent_role
    ir._parent_role = 'A'
    assert ir.get_include_params() == {'role_names': [],
                                       'role_paths': [],
                                       'role_params': [],
                                       'ansible_parent_role_names': ['A'],
                                       'ansible_parent_role_paths': [None]}
    ir._parent_role._role_path = 'B'
    assert ir.get_include_params()

# Generated at 2022-06-21 01:33:42.582232
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.static_load = True
    ir.args = {}
    ir._from_files = {}
    ir._parent_role = 'simple'
    ir._role_name = 'simple'
    ir._role_path = '/home/ansible/simple'
    new_me = ir.copy()
    assert ir.static_load == new_me.static_load
    assert ir.args == new_me.args
    assert ir._from_files == new_me._from_files
    assert ir._parent_role == new_me._parent_role
    assert ir._role_path == new_me._role_path


# Generated at 2022-06-21 01:33:53.417675
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ###################################
    #
    # Test basic class construction
    #
    ###################################

    # Test without a passed in block and Role
    def test_no_parent():
        try:
            IncludeRole()
        except SystemExit:
            print('Caught SystemExit exception')
        except:
            pass
        else:
            raise RuntimeError('IncludeRole failed to throw exception when block is not passed in')

    test_no_parent()

    # Test with a passed in Block, but no Role
    block = Block()
    block.statically_loaded = False

    def test_no_parent_role():
        try:
            IncludeRole(block)
        except SystemExit:
            print('Caught SystemExit exception')
        except:
            pass

# Generated at 2022-06-21 01:33:58.291402
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role.definition
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.constants as C
    import ansible.template

    # test data
    data = {'alias': 'SomeAlias', 'tasks': 'tasks/main.yml', 'handlers': 'handlers/main.yml', 'vars': {'test': 'TEST'}, 'defaults': {'test2': 'TEST2'}}

    # initialize vars