

# Generated at 2022-06-21 01:24:30.281278
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-21 01:24:32.888078
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    x = IncludeRole(block, role, task_include)
    assert isinstance(x, IncludeRole)



# Generated at 2022-06-21 01:24:38.715855
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook import Play

    pb = Play().load({
        "hosts": "all",
        "tasks": [
            {
                'name': 'test',
                'include_role': {
                    'name': 'test',
                    'tasks_from': 'tasks/main.yml'
                }
            }
        ]
    })
    assert len(pb.tasks) == 1
    assert isinstance(pb.tasks[0], IncludeRole)
    copy_task = pb.tasks[0].copy()
    assert isinstance(copy_task, IncludeRole)

# Generated at 2022-06-21 01:24:43.767786
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    role_name = "my_role"

    ir = IncludeRole(block=Block(), role=None, task_include=None)
    ir._role_name = role_name

    assert ir.get_name() == 'include_role : %s' % role_name

# Generated at 2022-06-21 01:24:55.597899
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import role_load
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    host_list = InventoryManager(loader=loader, sources='localhost,').get_hosts()
    variable_manager = VariableManager(loader=loader, host_list=host_list)
    roledata = dict(name="test_role",
                    hosts=dict(localhost=dict()),
                    tasks=dict(main=dict(include_role=dict(name="test_role_include"))))
    role = role_load(roledata, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:25:01.505290
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create a mock role
    mock_role = type(str('Role'), (object,), {'get_role_params': lambda x: {"role_param": "mocked"}})

    # Create a mock role include
    role_include = IncludeRole(None, mock_role)

    known_params = {"role_param": "mocked"}
    known_params['ansible_parent_role_names'] = []
    known_params['ansible_parent_role_paths'] = []

    include_params = role_include.get_include_params()

    assert include_params == known_params

# Generated at 2022-06-21 01:25:13.563729
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from units.mock.loader import DictDataLoader

    data = dict(
        name='foo',
        tasks='tasks/main.yml',
        handlers='handlers/main.yml',
        vars='vars/main.yml',
        default_vars='vars/main.yml',
        meta='meta/main.yml',
        files='files',
        templates='templates',
        tests='tests',
        dependencies=[],
        ignore_files=[],
        defaults={},
        allow_duplicates=True,
        public=False,
        validate=True,
    )

    # Create a new role instance
    role_instance = Role.load(data=data,
                              role_name='myrole',
                              loader=DictDataLoader({}))
    # Create a new

# Generated at 2022-06-21 01:25:17.202675
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    o = IncludeRole(None, None, None)
    o._role_name = "role.name"
    assert o.get_name() == "include_role : role.name"


# Generated at 2022-06-21 01:25:25.605479
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    instance = IncludeRole(block=None, role=None, task_include=None)
    instance.statically_loaded = False
    instance._from_files = {'defaults': 'test'}
    instance.rolespec_validate = False
    instance._parent_role = None
    instance._role_name = 'my-role'
    instance._role_path = 'my/role/path'
    exclude_parent = True
    exclude_tasks = False
    new_me = instance.copy(exclude_parent, exclude_tasks)
    assert instance.statically_loaded == new_me.statically_loaded
    assert instance._from_files == new_me._from_files
    assert instance._parent_role == new_me._parent_role
    assert instance._role_name == new_me._role_path




# Generated at 2022-06-21 01:25:31.328946
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role_include = IncludeRole()
    role_include.name = 'Test1'
    assert role_include.get_name() == 'Test1'
    role_include.name = None
    role_include.action = 'include_role'
    role_include._role_name = 'Test2'
    assert role_include.get_name() == 'include_role : Test2'


# Generated at 2022-06-21 01:25:50.146092
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    # Create a mock of Play object
    play1 = Play()
    play1._ds = dict(
        name='fake_play_name',
        connection='fake_play_connection',
        remote_user='fake_play_remote_user',
        become='fake_play_become',
        become_method='fake_play_become_method',
        become_user='fake_play_become_user',
        gather_facts='fake_play_gather_facts',
        no_log='fake_play_no_log')

    # Create a mock of VariableManager object
   

# Generated at 2022-06-21 01:25:54.505267
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    role_name = 'role_name'
    ir = IncludeRole(block, role, task_include)
    ir._role_name = role_name
    ir.name = 'include_role'
    assert ir.get_name() == "include_role : role_name"


# Generated at 2022-06-21 01:26:01.000120
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
  data = dict(
    name = 'test',
    )
  action = 'include_role'
  block = Block()
  role = Role()
  task_include = TaskInclude()
  variable_manager = object()
  loader = object()
  ir = IncludeRole(block, role, task_include=task_include)
  ir.load_data(data, variable_manager=variable_manager, loader=loader)
  assert ir.get_name() == 'test : test'

# Generated at 2022-06-21 01:26:09.022343
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = {'connection': 'local', 'module_path': '', 'forks': 1, 'become': None, 'become_method': None, 'become_user': None, 'check': False, 'diff': False}
    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager

# Generated at 2022-06-21 01:26:21.082941
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader)
    play_context = PlayContext()
    play_context.become = None
    play_context.become_method = None
    play_context.become_user = None
    play_context.check_mode = False
    inventory.set_play_context(play_context=play_context)
    host = inventory.get_host('localhost')
    role = Role.load(dict(name='test'), loader=loader, play=None, inventory=inventory)
    block = Block(dummy_validate=True)
    block.block  # pylint: disable=attribute-defined

# Generated at 2022-06-21 01:26:28.698725
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(block=None, role=None, task_include=None)
    assert hasattr(ir, '_allow_duplicates') == True
    assert hasattr(ir, '_public') == True
    assert hasattr(ir, '_rolespec_validate') == True
    assert hasattr(ir, '_from_files') == True
    assert hasattr(ir, '_parent_role') == True
    assert hasattr(ir, '_role_name') == True
    assert hasattr(ir, '_role_path') == True
    assert hasattr(ir, 'ACTION') == True
    assert hasattr(ir, 'DEFAULT_ATTRIBUTE_WARNING') == True



# Generated at 2022-06-21 01:26:35.789395
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    r = Role()
    r._role_path = '/path/to/role'
    ir = IncludeRole(role=r)
    assert ir.copy()._role_path == '/path/to/role'
    assert ir.copy(exclude_parent=True)._role_path == None
    assert ir.copy(exclude_tasks=True)._role_path == '/path/to/role'

# Generated at 2022-06-21 01:26:43.936376
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''Unit test for method get_block_list of class IncludeRole'''

    block = Block(None)
    role = Role()
    task_include = TaskInclude()

    test_obj = IncludeRole(block=None, role=role, task_include=task_include)
    test_obj._role_name = "role1"
    test_obj._parent_role = role
    task_include.action = "include_role"
    task_include.args = {"name": "name1"}

    # test for first return value
    assert test_obj.get_block_list()[0] is not None

    # test for second return value
    assert test_obj.get_block_list()[1] is not None



# Generated at 2022-06-21 01:26:55.566819
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Scenario 1:
    # Use case: The IncludeRole object is initialized with _parent_role set to None.
    # Expected result: The method get_include_params returns {}.
    test1_include_role = IncludeRole()
    params1 = test1_include_role.get_include_params()
    assert params1 == {}

    # Scenario 2:
    # Use case: The IncludeRole object is initialized with _parent_role not set to None.
    #           The method get_role_params of class Role returns {}.
    # Expected result: The method get_include_params returns the role parameters.
    test2_role = Role()
    test2_include_role = IncludeRole(_parent_role = test2_role)
    params2 = test2_include_role.get_include_params()
    assert params2

# Generated at 2022-06-21 01:27:06.064267
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.collection.collection_include import CollectionInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.constants import DEFAULT_ROLES_PATH
    from ansible.utils.display import Display
    from ansible.module_utils.six import string_types
    from ansible.template import Templar

    loader = None
    variable_manager = None
    display = Display()

    # = Setting up to fake the a RoleInclude =
    # =======================================
    # = Creating a fake RoleDefinition object =
    # =========================================

# Generated at 2022-06-21 01:27:28.574011
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    block = Block()
    role = Role()

    print("Testing IncludeRole with no parent role")
    ir = IncludeRole(block, role)
    ir._role_name = "foo"
    fake_play = object()
    fake_variable_manager = object()
    fake_loader = object()
    assert ir.get_block_list(play=fake_play, variable_manager=fake_variable_manager, loader=fake_loader) == ([], [])

    print("Testing IncludeRole with parent role")
    ri = object()
    actual_role = object()
    myplay = object()
    dep_chain = object()

    class RoleInclude:

        def __init__(self, role_name):
            self.role_name = role_name

        def load(self):
            return self


# Generated at 2022-06-21 01:27:33.279510
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    role._role_path = 'test'
    include_role = IncludeRole(block=block, role=role)
    assert include_role._parent == block
    assert include_role._parent_role == role
    assert include_role._role_path == 'test'

if __name__ == '__main__':
    test_IncludeRole()

# Generated at 2022-06-21 01:27:41.972725
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    def fail_copy(ir):
        # Create "copy" of IncludeRole object
        new_ir = ir.copy()

        # Fail if the "copy" object is not the same as the original object
        if new_ir is not ir:
            raise AssertionError('IncludeRole copy should return same object if both arguments are default')

    block = Block(play=None, parent=None)

    ir = IncludeRole(block=block)
    fail_copy(ir)

    ir = IncludeRole(block=block, role=Role())
    fail_copy(ir)

# Generated at 2022-06-21 01:27:51.062484
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Test with parent role
    include_role = IncludeRole()
    include_role._parent_role = Role()
    include_role._parent_role.name = 'test_parent'
    include_role._parent_role._role_path = '/path/to/test_parent'
    result = include_role.get_include_params()
    assert result['ansible_parent_role_names'] == ['test_parent']
    assert result['ansible_parent_role_paths'] == ['/path/to/test_parent']

    # Test without parent role
    include_role = IncludeRole()
    result = include_role.get_include_params()
    assert result == {}

# Generated at 2022-06-21 01:28:03.382028
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # create a block
    block = Block()
    block.block  = [ dict(action=dict(module='shell', args='ifconfig')) ]

    # create a role
    role = Role()
    role._role_name = 'test_role'
    role._role_params = dict(foo=1)
    role.get_vars()
    role.get_mapped_vars()
    role._task_blocks = [block]
    role._handler_blocks = [block]

    # create a option for the include_role
    task_include = dict(include='test_include_role.yml')

    # create an instance of IncludeRole class
    ir = IncludeRole(block, role, task_include=task_include)
    ir._allow_duplicates = 'True'
    ir._public = 'False'

# Generated at 2022-06-21 01:28:05.399023
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert IncludeRole().get_include_params() == {}


# Generated at 2022-06-21 01:28:15.996469
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    my_include_role = IncludeRole()
    assert isinstance(my_include_role, IncludeRole)
    assert isinstance(my_include_role, TaskInclude)
    assert isinstance(my_include_role, Block)
    assert my_include_role.action not in C._ACTION_INCLUDE_ROLE
    assert my_include_role.apply is False
    assert my_include_role.private is False
    assert my_include_role.statically_loaded is True
    assert my_include_role.args == {}
    assert my_include_role._from_files == {}
    assert my_include_role._parent_role is None
    assert my_include_role._role_name is None
    assert my_include_role._role_path is None

    ir = IncludeRole(action='include_role')


# Generated at 2022-06-21 01:28:23.376352
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Verify that get_include_params returns a dict of the expected format.
    # The role_params fixture is generated by test_role_params.py.
    role_params = {
        'role_name': 'test-role',
        'role_path': './roles/test-role',
        'role_uuid': '7f2e0d67-6f62-4e9b-80d7-22b1a017c1c3',
        'ansible_role_names': ['test-role'],
        'ansible_role_paths': ['./roles/test-role'],
    }
    # Create an IncludeRole object.
    include_role = IncludeRole()
    # Call get_include_params on it.
    include_role_params = include_role.get_include_params

# Generated at 2022-06-21 01:28:35.008582
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    block1 = Block()

    assert block1.serialize() == {'block': []}

    block1.args.load({'name': 'test_block'})
    assert block1.serialize() == {'block': [], 'name': 'test_block'}

    block1.parent = block1
    assert block1.serialize() == {'block': [], 'name': 'test_block'}

    block1.parent = block1
    block1.include = []
    assert block1.serialize() == {'block': [], 'name': 'test_block'}

    block1.parent = block1
    block1.include = []
    block1.loop.load({'items': []})
    assert block1.serialize() == {'block': [], 'name': 'test_block'}

   

# Generated at 2022-06-21 01:28:37.530025
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    role_path = '/path/to/ansible/roles'
    role = Role.load(role_path)
    ir = IncludeRole(role=role)
    assert ir._allow_duplicates
    assert not ir._public
    assert ir._rolespec_validate

# Generated at 2022-06-21 01:29:13.103954
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext

    task = IncludeRole()
    assert task.action == 'include_role'
    assert task.statically_loaded is False
    assert task.args == {}
    assert task.block is None
    assert task.delegate_to is None
    assert task.loop is None
    assert task._parent is None
    assert task.register == ''
    assert task.tags == []
    assert task.when is None
    assert task.any_errors_fatal is False
    assert task.always_run == False
    assert task.become is None
    assert task.become_user is None
    assert task.become_method is None
    assert task.become_flags == ''
    assert task.check_mode is None
    assert task.connection is None

# Generated at 2022-06-21 01:29:19.083042
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude())
    ir._role_name = 'name_role'
    result = ir.get_name()
    assert result == "name role : name_role"


# Generated at 2022-06-21 01:29:26.008239
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole(None, None, None)
    ir.name = "foo_name"
    ir.role = "foo_role"
    ir.tags = ["foo tags"]
    ir.always_run = True
    ir.static = True
    ir.block = Block()

    new_ir = ir.copy()

    assert ir.name == new_ir.name
    assert ir.role == new_ir.role
    assert ir.tags == new_ir.tags
    assert ir.always_run == new_ir.always_run
    assert ir.static == new_ir.static
    assert ir.block == new_ir.block
    assert ir.block is not new_ir.block

# Generated at 2022-06-21 01:29:38.013327
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from io import StringIO, BytesIO
    from ansible.plugins.loader import add_all_plugin_dirs, find_plugin
    add_all_plugin_dirs()
    vars_manager = VariableManager()
    ir = IncludeRole.load(dict(name='test_role'), role=None, task_include=None, variable_manager=vars_manager, loader=None)
    include_params = ir.get_include_params()
    assert include_params == dict()


# Generated at 2022-06-21 01:29:45.627993
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Test method get_block_list of class IncludeRole
    '''
    class MyBlock:
        def __init__(self):
            self._attributes = dict()
            self._roles = dict()
            self._dep_chain = []

        def __setattr__(self, name, value):
            if name.startswith('_'):
                self.__dict__[name] = value
            else:
                self._attributes[name] = value

        def __getattr__(self, name):
            if name.startswith('_'):
                try:
                    return self.__dict__[name]
                except:
                    raise AttributeError
            else:
                if name in self._attributes:
                    return self._attributes[name]
                raise AttributeError


# Generated at 2022-06-21 01:29:58.488249
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    test_role_name = 'test_role_name'
    test_args = {'key1':'value1', 'key2':'value2', 'key3':'value3'}
    test_block = Block()
    test_role = Role()
    test_obj = IncludeRole(test_block, test_role)

    test_obj._role_name = test_role_name
    test_obj.args = test_args

    test_obj2 = test_obj.copy(exclude_parent=True)

    # exclude_parent = True
    assert test_obj2._parent_role == None
    assert test_obj2._role_name == test_role_name
    assert test_obj2.args == test_args
    assert test_obj2.statically_loaded == test_obj.statically_loaded
   

# Generated at 2022-06-21 01:30:00.613929
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._action = 'include_role'
    ir._role_name = 'some_role'
    assert ir.get_name() == 'include_role : some_role'

# Generated at 2022-06-21 01:30:12.989085
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    my_ia = IncludeRole()
    src_ia = IncludeRole()
    src_ia.statically_loaded = True
    src_ia._from_files = {'apply':'rolespec.yml'}
    src_ia._parent_role = 'role1'
    src_ia._role_name = 'role2'
    src_ia._role_path = 'file_path'
    dest_ia = my_ia.copy(exclude_parent=False, exclude_tasks=False)
    assert dest_ia.statically_loaded == src_ia.statically_loaded
    assert dest_ia._from_files == src_ia._from_files
    assert dest_ia._parent_role == src_ia._parent_role
    assert dest_ia._role_name == src_ia._role_name
    assert dest

# Generated at 2022-06-21 01:30:14.256138
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: need to implement
    pass

# Generated at 2022-06-21 01:30:24.140254
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Arrangement
    display.verbosity = 3
    display.verbose("running test_IncludeRole_get_block_list")
    block = Block()
    role = Role()
    role.name = 'testrole1'
    role.vars = dict(arg=dict(default='default_value'))
    module_util = loader.get_module_utils('_text')

# Generated at 2022-06-21 01:31:11.973563
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test
    assert True
    # TODO

# Generated at 2022-06-21 01:31:21.881687
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.verbosity = 2
    # Test when name is None and role exists
    ir = IncludeRole(block=None, role=None, task_include=None)
    ir._role_name = 'unit-test-role'
    assert ir.get_name() == 'TASK : unit-test-role'
    # Test when name and role exist
    ir = IncludeRole(block=None, role=None, task_include=None)
    ir.name = 'test-name'
    ir._role_name = 'unit-test-role'
    assert ir.get_name() == 'test-name'


# Generated at 2022-06-21 01:31:23.901102
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: add a test here
    assert False

# Generated at 2022-06-21 01:31:28.110687
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    module_name = 'include_role'

    # If you want to run the test, change the perform_test to True
    perform_test = False
    if perform_test is False:
        return
    display.verbosity = 4
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # init the args for the Role class
    pb = __import__('ansible.playbook.__init__')
    role_path = '../tests/integration/targets/include-role'
    role_name = 'include_role_test'

    # init the args

# Generated at 2022-06-21 01:31:35.314150
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import copy

    c1 = copy.deepcopy(C)
    c2 = copy.deepcopy(C)

    c1.DEFAULT_HANDLERS_PATH = ['/home/me/ansible/playbooks/handlers']
    c2.DEFAULT_HANDLERS_PATH = ['/tmp/playbooks/handlers']

    c1.DEFAULT_TASK_PATH = ['/home/me/ansible/playbooks/tasks']
    c2.DEFAULT_TASK_PATH = ['/tmp/playbooks/tasks']

    c1.DEFAULT_VARS_PATH = ['/home/me/ansible/playbooks/vars']
    c2.DEFAULT_VARS_PATH = ['/tmp/playbooks/vars']

    from ansible.playbook.block import Block


# Generated at 2022-06-21 01:31:44.751038
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # test that the IncludeRole.get_name() method returns the name of the task
    # or a composite of the action and role name for tasks where there is no name

    # define some basic task data
    role_name = 'test_role_name'
    test_data = {'name': 'this is a name', 'role': role_name, 'include_role': {}}

    # create the block and role objects required by the IncludeRole constructor
    block = Block()
    role = Role()
    # create the IncludeRole object, passing the block and role objects to the constructor
    ir = IncludeRole(block=block, role=role)
    # load the IncludeRole object with the data
    ir.load_data(test_data)

    # verify that we get the expected output
    expected = 'this is a name'
    actual = ir.get

# Generated at 2022-06-21 01:31:53.953622
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.rolevars import RoleVars
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:31:59.664248
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole()
    task.name = 'TestTask'
    task._role_name = 'TestRole'
    assert task.get_name() == 'TestTask : TestRole'
    task.name = None
    assert task.get_name() == 'include_role : TestRole'


# Generated at 2022-06-21 01:32:12.388950
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import ast
    import inspect
    import os

    def load_role_path(obj, name):
        for f in os.listdir(obj.args['role']):
            if os.path.splitext(f)[0] == name:
                return os.path.join(obj.args['role'], f)

    def _static_var_test(test_method_name, test_method_params, test_method, test_method_class, test_method_expect, test_method_side_effects):
        test_method_side_effects = test_method_side_effects or []

        # save original context
        origin_context = locals().copy()

        # build context
        context = dict(origin_context)

# Generated at 2022-06-21 01:32:22.899692
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test with one key
    assert IncludeRole.load({'apply': {'foo': 1, 'bar': '2'}, 'name': 'foo'}, block=None,
                            role=None, task_include=None, variable_manager=None, loader=None).apply == {'foo': 1,
                                                                                                         'bar': '2'}
    assert IncludeRole.load({'allow_duplicates': False, 'name': 'foo'}, block=None,
                            role=None, task_include=None, variable_manager=None, loader=None).allow_duplicates == False
    assert IncludeRole.load({'public': True, 'name': 'foo'}, block=None,
                            role=None, task_include=None, variable_manager=None, loader=None).public == True
    assert IncludeRole