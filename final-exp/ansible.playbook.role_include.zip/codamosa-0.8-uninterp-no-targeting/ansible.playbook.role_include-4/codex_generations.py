

# Generated at 2022-06-21 01:24:40.071906
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.task_include import TaskInclude

    role1 = Role()
    role1._role_name = 'role1'
    role1._role_path = '/path/to/role1'

    task1 = TaskInclude()
    task1.action = 'include_role'
    task1._parent = role1
    task1._parent_role = role1
    task1._role_name = 'role2'
    task1._role_path = '/path/to/role2'


# Generated at 2022-06-21 01:24:40.701081
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:24:44.244906
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    task = IncludeRole()
    task.args = {'name': 'my-role'}
    _xit = task.get_block_list()



# Generated at 2022-06-21 01:24:55.927853
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.task_include import TaskInclude
    a = IncludeRole(block=None, role=None)
    a.statically_loaded = True
    a._from_files = {}
    a._parent_role = None
    a._role_name = 'test'
    a._role_path = '/path/to/role'
    a.post_validate(templar=None, shared_loader_obj=None)
    b = a.copy(exclude_parent=False, exclude_tasks=False)
    assert a.statically_loaded == b.statically_loaded
    assert a._from_files == b._from_files
    assert a._parent_role == b._parent_role
    assert a._role_name == b._role_name
    assert a._role_path == b._role

# Generated at 2022-06-21 01:25:00.836533
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # noinspection PyUnusedLocal
    block1 = Block()
    # noinspection PyUnusedLocal
    block2 = Block()
    # noinspection PyUnusedLocal
    role1 = Role()
    # noinspection PyUnusedLocal
    task_include = TaskInclude()

    assert IncludeRole(block1, role1, task_include) is not None


# Generated at 2022-06-21 01:25:11.658387
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ''' Test for method IncludeRole.get_include_params() '''

    new_me = IncludeRole()

    role_name = 'role_name'
    role_path = 'role_path'

    new_me._parent_role = MockRole()

    new_me._parent_role.get_name.return_value = role_name
    new_me._parent_role._role_path = role_path

    ansible_return = new_me.get_include_params()

    assert ansible_return['ansible_parent_role_names'][0] == role_name
    assert ansible_return['ansible_parent_role_paths'][0] == role_path



# Generated at 2022-06-21 01:25:13.564447
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert(isinstance(ir, IncludeRole))

# Generated at 2022-06-21 01:25:23.653808
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.definition import RoleDefinition

    pb1 = RoleDefinition()
    pb1._role_path = '/some/path'
    pb1._role_name = 'some_role_name'

    ir1 = IncludeRole(role=pb1)
    assert 'ansible_parent_role_names' not in ir1.get_include_params()
    assert 'ansible_parent_role_paths' not in ir1.get_include_params()

    pb2 = RoleDefinition()
    pb2._role_path = '/some/other/path'
    pb2._role_name = 'some_other_role_name'

    ir2 = IncludeRole(role=pb2)
    ir2._parent_role = pb1

    result = ir2.get_include_params

# Generated at 2022-06-21 01:25:34.033928
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Define data
    data1 = {
        'include_role': 'name=some_role',
        'allow_duplicates': True
        }
    data2 = {
        'import_role': 'name=some_role',
        'allow_duplicates': False
        }
    data3 = {
        'include_role': 'name=some_role',
        'apply': {'block':{'name':'this_block', 'tasks':['this_task']}},
        'allow_duplicates': True
        }
    data4 = {
        'include_role': 'name=some_role',
        'apply': {'block':{'name':'this_block', 'tasks':['this_task']}, 'public':True},
        'allow_duplicates': True
        }

# Generated at 2022-06-21 01:25:45.386275
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # ---------------
    # from __future__ import (absolute_import, division, print_function)
    data = {'name': 'role_name'}
    include_role = IncludeRole(block=None, role=None, task_include=None)
    include_role.action = 'include_role'
    include_role2 = IncludeRole.load(data=data, block=None, role=None, task_include=include_role, variable_manager=None, loader=None)
    assert include_role2
    assert include_role2.allow_duplicates
    assert not include_role2.public

    # ---------------
    # if not isinstance(apply_attrs, dict):
    #     raise AnsibleParserError('Expected a dict for apply but got %s instead' % type(apply_attrs), obj=data)

# Generated at 2022-06-21 01:26:05.192467
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = "test_role"
    assert ir.get_name() == "include_role : test_role"

# Generated at 2022-06-21 01:26:17.296873
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader
    import os

    class Options(object):
        verbosity = 4
        extra_vars = {}
        inventory = 'tests/test_included_role/inventory'


    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=Options().inventory)

# Generated at 2022-06-21 01:26:27.459937
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import load_plugin_paths

    import ansible.playbook
    ansible.playbook._load_playbook_plugins(load_plugin_paths())

    class FakePlay(object):
        pass

    loader = DictDataLoader(dict())
    role = DummyRole(metadata=RoleMetadata(), play=FakePlay(), loader=loader)
    block = Block(parent_block=role).load({'block': []}, None, None)
    task_include = IncludeRole(block=block, role=role, task_include={'name': 'foo', 'checked': False})

    # Should return blocks and handlers
   

# Generated at 2022-06-21 01:26:40.200419
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    def _assert_msg(got_msg, want_msg):
        print("got_msg:[{msg}]".format(msg=got_msg))
        print("want_msg:[{msg}]".format(msg=want_msg))
        assert(want_msg in got_msg)

    # load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    #   :param data: parsed include_role/tasks_from/vars_from/handlers_from data
    #   :param block: Block to use for loading
    #   :param role: Role to use as parent for loading
    #   :param task_include: data used for task includes
    #   :param variable_manager: variable manager to

# Generated at 2022-06-21 01:26:44.819598
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'name': 'include_role', 'args': {'name': 'docker', 'allow_duplicates': True, 'public': True, 'tasks_from': 'somefile'}}

    include_role = IncludeRole.load(data)

    assert include_role.name == 'include_role'
    assert include_role._role_name == 'docker'
    assert include_role._allow_duplicates == True
    assert include_role._public == True
    assert include_role._from_files == {'tasks': 'somefile'}

# Generated at 2022-06-21 01:26:49.667343
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Constructor of superclass
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()
    print(task_include.__dict__)

    # Constructor of subclass
    include_role = IncludeRole(task_include)
    print(include_role.__dict__)

# Generated at 2022-06-21 01:26:56.345864
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_task = IncludeRole(
        block=Block(),
        role=Role(),
        task_include=TaskInclude(block=Block())
    )
    test_task.name = 'Test task'
    test_task._role_name = 'Test role'
    assert test_task.get_name() == 'Test task'
    test_task.name = None
    assert test_task.get_name() == '- include_role: Test role'

# Generated at 2022-06-21 01:27:01.192208
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Test: Empty object
    x = IncludeRole()
    y = x.copy()
    assert x.__dict__ == y.__dict__

    # Test: Non empty object
    x = IncludeRole(Block([]), Role(), TaskInclude('foo'))
    y = x.copy()
    assert x.__dict__ == y.__dict__

# Generated at 2022-06-21 01:27:10.308355
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_inventory(loader.load_from_file('tests/inventory'))

    test_role = Role.load(dict(name='test_role',
        tasks=[dict(action='test_task')]
    ))
    assert isinstance(test_role, Role)

    block = Block()
    block.role = test_role


# Generated at 2022-06-21 01:27:11.342821
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: implement this
    pass

# Generated at 2022-06-21 01:27:31.358648
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test bad args
    fake_file = dict(
        action='include_role',
        args=dict(name='my_role'),
        bad_opt='bad_arg'
    )
    assert IncludeRole.load(fake_file)


# Generated at 2022-06-21 01:27:43.426476
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Create probe objects
    ir_probe_obj = IncludeRole()
    ir_probe_obj.statically_loaded = True
    ir_probe_obj._from_files = {'one': 'two', 3: 4}
    ir_probe_obj._parent_role = 'parent_role'
    ir_probe_obj._role_name = 'role_name'
    ir_probe_obj._role_path = 'role_path'

    # Test method
    new_obj = ir_probe_obj.copy(exclude_parent=True, exclude_tasks=True)

    # Assert test result
    assert type(new_obj) == IncludeRole
    assert new_obj.statically_loaded == ir_probe_obj.statically_loaded
    assert new_obj._from_files == ir_

# Generated at 2022-06-21 01:27:45.167015
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    imp = IncludeRole(block=block)
    assert imp._block == block

# Generated at 2022-06-21 01:27:51.725844
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole()

    assert ir._parent is None
    assert ir._role is None
    assert ir._task_include is None

    ir2 = IncludeRole(Block(), Role())

    assert ir2._parent is None
    assert ir2._role is not None
    assert ir2._task_include is None

    ir3 = IncludeRole(Block(), Role(), task_include=IncludeRole())

    assert ir3._parent is None
    assert ir3._role is not None
    assert ir3._task_include is not None

# Generated at 2022-06-21 01:28:03.585623
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task.meta import TaskMetadata

    # Create test objects
    # RoleDefinition object
    role_definition = RoleDefinition()
    role_definition._metadata = RoleMetadata()
    role_definition._metadata._role_paths = ['roles/test-role']

    # Role object
    role = Role()
    role._metadata = RoleMetadata()
    role._role_params = dict()
    role._role_params.setdefault('ansible_role_names', [])
    role._definitions = [role_definition]

    # IncludeRole object
    include_role = IncludeRole()
    include_role._parent = role
    include_role._parent_role = role


# Generated at 2022-06-21 01:28:04.603673
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert not IncludeRole().get_include_params()


# Generated at 2022-06-21 01:28:15.579695
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    role = Role()
    role._role_path = "/home"
    role.name = "role"
    role_include = IncludeRole(role=role)
    role_include._parent_role = role
    result = role_include.get_include_params()
    assert 'ansible_parent_role_names' in result
    assert len(result["ansible_parent_role_names"]) is 1
    assert result["ansible_parent_role_names"][0] == role.get_name()
    assert 'ansible_parent_role_paths' in result
    assert len(result["ansible_parent_role_paths"]) is 1
    assert result["ansible_parent_role_paths"][0] == role._role_path

    result = IncludeRole(role=None).get_include_params()


# Generated at 2022-06-21 01:28:23.216719
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play

    block = Block()
    role = Role()
    task_include = TaskInclude()

    actual_role_actual_blocks = [Block() for _ in range(4)]

    class RoleMock:

        def __init__(self):
            self._parents = []
            self._metadata = None
            self._role_path = "/abc"
            self.collections = ['123']

        def compile(self, play=None, dep_chain=None):
            return actual_role_actual_blocks

    class TaskIncludeMock:

        def __init__(self):
            self.vars = {'xyz': '987'}
            self.args = {'apply': {}}
            self.action = 'include_role'
            self.statically_loaded = False


# Generated at 2022-06-21 01:28:25.443882
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # TODO - implement test
    pass

# Generated at 2022-06-21 01:28:35.530679
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    block1 = Block(play=Play().load(
        dict(
            name = "include_role test play",
            hosts = 'all',
            gather_facts = 'no',
            roles = './test_roles/foo',
        ),
        variable_manager=None,
        loader=None
    ))

# Generated at 2022-06-21 01:29:15.959787
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    my_name = "my_name"
    my_role_path = "my_role_path"
    my_role_name = "my_role_name"
    my_include_role = IncludeRole()
    my_include_role._role_name = my_role_name
    my_include_role._role_path = my_role_path
    my_include_role.name = my_name
    my_parent_role = Role()
    my_parent_role._role_path = "/my_parent_path"
    my_parent_role._role_name = "my_parent_name"
    my_include_role._parent_role = my_parent_role
    my_result = my_include_role.get_include_params()
    assert my_result['ansible_include_role_name'] == my

# Generated at 2022-06-21 01:29:25.645319
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create fake Play
    pb = Play.load({}, variable_manager=VariableManager(), loader=DataLoader())

    # Create fake Role
    fake_role = RoleInclude.load('test-role-name', pb)
    fake_role.vars

# Generated at 2022-06-21 01:29:35.266011
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from .mock import MockLoader, MockDataLoader
    from ansible.vars.manager import VariableManager
    import yaml


# Generated at 2022-06-21 01:29:43.398658
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test with two tasks the Includerole class
    """
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role.args = {'tasks_from': 'test/tasks', 'name': 'Test'}
    include_role.vars = {'a':2}
    include_role._from_files = {'a':'b'}
    include_role._role_name = 'Test'
    include_role._role_path = 'Test'
    include_role.statically_loaded = False
    include_role.public = False
    include_role.allow_duplicates = True
    include_role.rolespec_validate = True

# Generated at 2022-06-21 01:29:54.227181
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    module = type('module', (object,), {'__name__': 'fake'})()
    module.__file__ = '/etc/ansible/test_IncludeRole_load.py'

# Generated at 2022-06-21 01:30:02.785624
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude

    task_include = TaskInclude()
    role_include = RoleInclude()
    role_include.statically_loaded = True

    task_include._loader = None
    task_include._variable_manager = None
    task_include._parent = None

    role_include._loader = None
    role_include._variable_manager = None
    role_include._parent = None

    play = Play().load({'name': 'test'}, loader=None, variable_manager=None)

# Generated at 2022-06-21 01:30:03.611220
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole

# Generated at 2022-06-21 01:30:11.572672
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    #for init
    task_block = Block(parent_block=None)
    parent_role = Role()
    task_include = TaskInclude()

    #for copy
    exclude_parent = False
    exclude_task = False

    myIncludeRole = IncludeRole(block=task_block, role=parent_role, task_include=task_include)
    new_IncludeRole = myIncludeRole.copy(exclude_parent, exclude_task)

    assert myIncludeRole == new_IncludeRole

# Generated at 2022-06-21 01:30:18.054297
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block=block, role=role, task_include=task_include)

    include_role._from_files['tasks'] = 'fake_tasks'
    include_role._from_files['vars'] = 'fake_vars'
    include_role._from_files['defaults'] = 'fake_defaults'
    include_role._from_files['handlers'] = 'fake_handlers'
    include_role._parent_role = "fake_parent_role"
    include_role._role_name = "fake_role_name"
    include_role._role_path = "fake_role_path"

    new_me = include_role.copy()

    assert new_me.statically_

# Generated at 2022-06-21 01:30:23.710689
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role_find_result = {}
    role_find_result['name'] = 'foo'

    my_role_include = IncludeRole(role_find_result)
    assert my_role_include.get_name() == 'foo : foo'

    role_find_result['name'] = 'bar'
    my_role_include = IncludeRole(role_find_result)
    assert my_role_include.get_name() == 'foo : bar'

# Generated at 2022-06-21 01:31:33.444666
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    assert True

# Generated at 2022-06-21 01:31:44.095100
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()
    assert ir.get_include_params() == {
        'ansible_current_role_name': '',
        'ansible_current_role_path': ''
    }

    ir2 = IncludeRole()
    ir2._parent_role = IncludeRole()
    ir2._parent_role._parent_role = IncludeRole()
    ir2._role_path = 'a/b/c'
    ir2._parent_role._role_name = 'a'
    ir2._parent_role._parent_role._role_name = 'b'
    v = ir2.get_include_params()
    assert v['ansible_parent_role_paths'] == [ir2._parent_role._parent_role._role_path, ir2._parent_role._role_path]

# Generated at 2022-06-21 01:31:51.420737
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    r = IncludeRole()
    r_1 = IncludeRole(block=Block(name='test_role_block'))
    assert r.__class__.__name__ == 'IncludeRole'
    assert r.block == None
    assert r.role == None
    assert r_1.__class__.__name__ == 'IncludeRole'
    assert r_1.block.__class__.__name__ == 'Block'
    assert r_1.block.name == 'test_role_block'

# Generated at 2022-06-21 01:32:03.054373
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import copy
    import os

    # Setup ansible.cfg to use test/units/lib/ansible_test_role/ as a role path
    role_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible_test_role')
    config = os.path.join(os.getcwd(), 'test', 'units', 'ansible.cfg')
    lines = [line.rstrip('\n') for line in open(config)]
    pattern = "^\[defaults\]$"
    new_contents = []
    role_line = 'roles_path = %s' % role_path
    for line in lines:
        new_contents.append(line)
        if re.search(pattern, line):
            new_

# Generated at 2022-06-21 01:32:05.329588
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    obj = IncludeRole()
    assert obj is not None


# Generated at 2022-06-21 01:32:10.678942
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    assert ir is not None
    assert block == ir.block
    assert role == ir.role
    assert task_include == ir.task_include

# Generated at 2022-06-21 01:32:20.560194
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # The test for method load of class IncludeRole is performed in
    # unit test test_IncludeRole.
    #
    # test_IncludeRole was implemented to test class IncludeRole.
    # test_IncludeRole is helper function that calls method load
    # of class IncludeRole.
    #
    # We decided to test method load of class IncludeRole by
    # calling it from the helper function test_IncludeRole
    # to ensure that we test method load of class IncludeRole
    # with the same parameters as it is tested in test_IncludeRole.

    pass



# Generated at 2022-06-21 01:32:31.803483
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()
    ir.name = "test_role"
    ir.vars = { "test_var": "test_var_value" }
    ir._from_files['tasks'] = 'test_role_main.yml'
    ir.rolespec_validate = True
    ir.collections = [ 'test_collection' ]
    block = Block()
    block.vars = { "block_var": "block_var_value" }
    block._parent = block
    block.collections = [ 'test_collection2' ]
    play = object()
    variable_manager = object()
    loader = object()

    blocks, handlers = ir.get_block_list(block, play, variable_manager, loader)
    assert len(blocks) == 1, 'resulting blocks should only have 1 block'

# Generated at 2022-06-21 01:32:37.162176
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    ir = IncludeRole(block, role)
    assert ir.__class__.__name__ == "IncludeRole"


if __name__ == '__main__':
    test_IncludeRole()

# Generated at 2022-06-21 01:32:43.874857
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # test get_include_params method
    from ansible import context
    from ansible.vars.manager import VariableManager
    from ansible.vars.tasks import TaskVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar
    ctx = PlayContext()
    ctx.sourced_vars = set()
    context._init_global_context(loader=DataLoader())