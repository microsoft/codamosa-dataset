

# Generated at 2022-06-21 01:24:39.408087
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    mock_loader = DictDataLoader({"/etc/ansible/roles/test_role/tasks/main.yml": "---\n- debug: msg=test_task\n"})

    display = Display()
    templar = Templar(loader=mock_loader, variables={})
    vars_manager = ansible.vars.Manager()

    fake_play_context = PlayContext()
    fake_play_context.CLIARGS = dict()

    test_instance = IncludeRole(role=None, task_include=None)
    test_instance

# Generated at 2022-06-21 01:24:44.225789
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    loader = None
    variable_manager = None
    task_vars = dict()
    ir = IncludeRole(block=Block(), role=None, task_include=None)
    ir._role_path = '/path/to/role'
    ir._parent_role = Role()
    ir._parent_role._role_params = dict(role="MyRole", role_name="MyRole", role_path="path/to/role", role_uuid="adb2aac0-6cff-4e9b-8bb7-0380d4b4c6f4")
    ir._parent_role._role_path = '/path/to/role'
    v = ir.get_include_params()

# Generated at 2022-06-21 01:24:55.929612
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    b = Block()
    r = Role()

    t = IncludeRole(block=b, role=r)
    t2 = t.copy()
    assert t2 == t
    assert object.__ne__(t2,t)

    t._allow_duplicates = False
    t._from_files = {'tasks': 'tasks_file_2'}
    t._role_name = 'role_name_2'
    t._role_path = 'role_path_2'
    t.apply = {'new_task': 'add_value'}
    t.public = True
    t.rolespec_validate = False

    t2 = t.copy()
    assert t2 == t
    assert object.__ne__(t2,t)
    assert t2._allow_duplicates == False

# Generated at 2022-06-21 01:25:07.065735
# Unit test for method get_name of class IncludeRole

# Generated at 2022-06-21 01:25:15.489808
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role.args = {'apples': 'mangos', 'bananas': 'oranges'}
    new_include_role = include_role.copy()
    assert isinstance(new_include_role, IncludeRole)
    assert new_include_role.args == {'apples': 'mangos', 'bananas': 'oranges'}


# Generated at 2022-06-21 01:25:19.940198
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class EmptyRole:
        def __init__(self):
            self.args = {}
            self.action = None
            self.tasks = []

    base_test = EmptyRole()
    base_test.action = 'include_role'
    base_test.args = {}



# Generated at 2022-06-21 01:25:27.041341
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play

    playbook_path = 'test/playbooks/IncludeRole_get_block_list_play.yaml'

    # Set up a play
    play = ansible.playbook.play.Play().load(playbook_path, variable_manager=None, loader=None)

    # Set up an IncludeRole object
    include_role_name = 'test_include_role'
    include_role_action = 'include_role'
    block = Block(parent=play, role=None, task_include=None, use_handlers=True)
    block.vars = {'role_name': include_role_name}
    block_tasks = ['test_task']
    block.block = block_tasks


# Generated at 2022-06-21 01:25:35.896728
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Arrange
    class MockRole(Role):
        def __init__(self):
            Role.__init__(self)
            self._metadata = MockRoleData()

        def get_role_params(self):
            return {'role_params': 'test_role_params'}

        def get_name(self):
            return 'test_name'

    class MockRoleData:
        def __init__(self):
            self._role_path = 'test_role_path'

    class MockPlay:
        def __init__(self, collections=None):
            self.collections = collections


# Generated at 2022-06-21 01:25:45.916777
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test load is successful with different combinations of mandatory and optional arguments
    task_include = IncludeRole()

    with pytest.raises(AnsibleParserError):
        # Test load fails without 'name' or 'role'
        task_include.load({"include":"role"}, block=Block().load("block", {"hosts":"all"}, task_include, None, None))

    task_include.load({"include":"role", "name":"role_name"}, block=Block().load("block", {"hosts":"all"}, task_include, None, None))
    task_include.load({"include":"role", "role":"role_name"}, block=Block().load("block", {"hosts":"all"}, task_include, None, None))



# Generated at 2022-06-21 01:25:55.536701
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.mod_args import ModuleArgsParser


    # create a test include_role
    block = Block()
    ir = IncludeRole(block, loader=loader)
    ir._role_name = "test-role"
    assert ir.get_name() == "include_role : test-role"

    # create a test include_role with name
    block = Block()
    ir = IncludeRole(block, loader=loader)
    ir._role_name = "test-role"

# Generated at 2022-06-21 01:26:15.587695
# Unit test for method get_include_params of class IncludeRole

# Generated at 2022-06-21 01:26:26.182386
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # This unit test is based on a regression test for issue:
    # https://github.com/ansible/ansible/issues/40642
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    def load_from_file(self, path):
        '''
        Read a file from the specified path and return the data contained within it.
        '''
        return path

    DataLoader.load_from_file = load_from_file

    play_context = {}

# Generated at 2022-06-21 01:26:38.755538
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.utils.display import Display

    display = Display()
    display.columns = 80
    display.verbosity = 4
    display.debug("foo")

    template = 'when: inventory_hostname == "localhost"'

    ir = IncludeRole()
    ir.load({'include_role': {'name': 'webserver', 'vars': {'foo': '{{bar}}' }, 'when': template}})
    ir.load({'include_role': {'name': 'webserver', 'apply': {'minimal': {'bar': 'baz'}}, 'when': template}})
    ir.load({'include_role': {'name': 'webserver', 'apply': [{'minimal': {'bar': 'baz'}}], 'when': template}})

# Generated at 2022-06-21 01:26:39.889998
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = 'example'
    assert ir.get_name().endswith(': example')


# Generated at 2022-06-21 01:26:50.503158
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Sample play for testing purposes
    play_data = dict(
        hosts='localhost',
        hosts_role1='localhost',
        hosts_role2='localhost',
        roles='test_role1',
        roles_role1='test_role2',
        roles_role2='test_role3',
        vars=dict(
            my_hosts='localhost',
            my_hosts_role1='localhost',
            my_hosts_role2='localhost',
            my_roles='test_role1',
            my_roles_role1='test_role2',
            my_roles_role2='test_role3',
        )
    )
    play = Mock()
    play.vars = play_data.get('vars')
    play.roles = []
    # Sample role 1 for testing purposes

# Generated at 2022-06-21 01:26:57.704485
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir.block is None
    assert ir.role is None
    assert ir.task_include is None
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True
    assert ir._from_files == {}
    assert ir._parent_role is None
    assert ir._role_name is None
    assert ir._role_path is None

# Generated at 2022-06-21 01:27:04.523753
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create object IncludeRole
    ir = IncludeRole()
    # Assign to attributes
    ir.action = 'action'
    ir._role_name = 'role_name'
    ir.name = 'name'
    # Verify expected name (role_name)
    assert ir.get_name() == "role_name"
    # Assign name to None
    ir.name = None
    # Verify expected name (action: role_name)
    assert ir.get_name() == "action: role_name"


# Generated at 2022-06-21 01:27:12.174022
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # init vars
    blocks = []

    # define some Block objects
    b1 = Block(None)
    b1.name = 'b1'
    blocks.append(b1)

    b2 = Block(None)
    b2.name = 'b2'
    blocks.append(b2)

    # define other vars (must be Instance of class)
    play = None
    variable_manager = None
    loader = None
    role = None
    collection_list = None

    # create instance of class
    ir = IncludeRole(block=None, role=role)

    # declare mock_object
    RoleInclude = RoleInclude = mock.Mock()

    # set return value of method `load` of object `RoleInclude`

# Generated at 2022-06-21 01:27:23.263586
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import unittest
    import os
    import sys
    import tempfile
    import shutil

    import ansible.constants
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar

    def debug_playbook_load(name, datas, variable_manager=None, loader=None):
        from ansible.parsing.mod_args import ModuleArgsParser
        from ansible.playbook.handler import Handler
        from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-21 01:27:32.149716
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.meta import RoleMetadata

    p = Play().load({
        'name': 'placeholder play',
        'hosts': 'all',
        'roles': [
            {
                'name': 'foo',
                'include_role': {
                    'role': 'foo',
                    'tasks_from': 'tasks/main.yml',
                }
            }
        ]
    })
    t = p.get_tasks()[0]
    assert isinstance(t, Task)
    assert t.action == 'include_role'
    assert isinstance(t._role, RoleMetadata)
    assert isinstance(t._parent, Block)
    assert t._role._role

# Generated at 2022-06-21 01:27:48.752429
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    print("Test copy method of class IncludeRole")
    parent_role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(parent_role, task_include)
    # set default values defined in class
    ir.apply = {}
    ir.allow_duplicates = True
    ir.public = False
    ir.rolespec_validate = True
    ir.statically_loaded = False

    # set class attributes
    ir._from_files = {
        "tasks": "main.yml",
        "vars": "vars/main.yml",
        "defaults": "defaults/main.yml",
        "handlers": "handlers/main.yml"
    }
    ir._parent_role = parent_role
    ir._role_name = "role_name"

# Generated at 2022-06-21 01:27:56.532525
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    class FakeBlock(object):
        pass

    my_path = 'examples/ansible-bender/roles/openshift'
    my_role_name = 'openshift'
    my_block_args = {'name': my_role_name}
    my_block = FakeBlock()

    my_loader = DataLoader()
    my_play_context = PlayContext()
    my_variable_manager = VariableManager()


# Generated at 2022-06-21 01:28:06.619074
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    name = "tests/fixtures/roles/valid_include_role/include_role.yaml"

    from ansible.plugins.loader import load_plugin
    block = load_plugin("include_role", Block.load(name, 'main'))
    result = block.get_block_list()
    assert result == ([], [])

    name = "tests/fixtures/roles/valid_include_role/tasks/main.yaml"

    block = load_plugin("include_role", Block.load(name, 'main'))
    result = block.get_block_list()
    assert result == ([], [])

# Generated at 2022-06-21 01:28:16.605405
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context = PlayContext()
    loader = DictDataLoader()
    play = Play().load(dict(
        name = "Ansible Play name",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            {
                'name': 'test',
                'include_role': {
                    'name': 'testrole',
                    'tasks_from': 'main.yml'
                }
            }
        ],
    ), loader=loader, variable_manager=VariableManager())
    tqm = None

# Generated at 2022-06-21 01:28:26.277608
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Patching the internal Ansible variables
    context = PlayContext()
    C.INVENTORY = InventoryManager(loader=DataLoader(), sources=[])
    C.VARIABLE_MANAGER = VariableManager(loader=DataLoader(), inventory=C.INVENTORY)

    host = C.INVENTORY.get_host('test')
    C.VARIABLE_MANAGER.set_host_variable(host=host, varname='test_var_1', value=1)

    # Fake role setup, with fake 'test_role' role
    C.DEFAULT_R

# Generated at 2022-06-21 01:28:27.757238
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    t = IncludeRole(None, None)
    assert t.get_name() == 'include_role : None'


# Generated at 2022-06-21 01:28:36.188825
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """ IncludeRole - constructor unit test """

    from ansible.playbook.play_context import PlayContext

    yaml_data = dict(
        name='test.yml',
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(
                module='shell',
                args='/usr/bin/true'
            ))
        ]
    )

    play_ds = dict(
        name="test play",
        hosts='all',
        gather_facts=False,
        roles=[],
        tasks=[
            dict(action=dict(
                include_role=dict(),
            ))
        ]
    )

    block = Block.load(play_ds['tasks'][0], play=None)
    role = Role()
    role.name = "test-role"

    #

# Generated at 2022-06-21 01:28:41.589790
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display = Display()

    class mock_role:
        def __init__(self):
            self.name = 'foo'
            self.role_path = 'role_path'

        def get_name(self):
            return self.name

        def get_role_params(self):
            return {'one': 1, 'two': 2}

        def get_default_vars(self):
            return {'three': 3}

    class mock_parent:
        def __init__(self, role):
            self._role = role

        def get_role_params(self):
            return self._role.get_role_params()

        def get_default_vars(self):
            return self._role.get_default_vars()

        def get_vars(self):
            return {'four': 4}



# Generated at 2022-06-21 01:28:51.788744
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.tasks import Task

    ir = IncludeRole()
    ir.action='include_role'
    ir._role_name='test_role'

    name = ir.get_name()
    assert name == "include_role : test_role"

    ir.name='Include_test'

    name = ir.get_name()
    assert name == "Include_test : test_role"

# Generated at 2022-06-21 01:29:03.231506
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole(action='include_role')
    ir.name='test_copy'
    ir.allow_duplicates=False
    ir._from_files={'tasks':'foo.yml', 'vars':'varfile.yml'}
    ir._parent_role='test_parent'
    ir._role_name='test_role'
    ir._role_path='/roles/test_role'
    new_ir = ir.copy()
    assert new_ir.action == 'include_role'
    assert new_ir.name == 'test_copy'
    assert new_ir.allow_duplicates == False
    assert new_ir._from_files == {'tasks':'foo.yml', 'vars':'varfile.yml'}
    assert new_ir._role_name

# Generated at 2022-06-21 01:29:26.645990
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    options = {'roles_path': ["tests/test_include_role/roles"], 'inventory': None}
    loader = None

    # load the play
    pb = Playbook.load("pb-includerole.yml", variable_manager=None, loader=loader)

    # pb.inventory = Inventory("test/test_include_role")
    pb.vars_prompt = dict()


# Generated at 2022-06-21 01:29:39.663393
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # test the get_include_params method of IncludeRole class
    # this is a super simple test with its main focus on code coverage
    from ansible import context
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    context.CLIARGS = ImmutableDict()

    block = Block()
    block._parent = Play.load({'name': 'test_play', 'hosts': 'all'}, loader=action_loader)
    role = Role()
    role._metadata = {'name': 'test_role_name'}
    role._role_path = 'test_role_path'
    task = Task()
    task.action = 'include_role'

# Generated at 2022-06-21 01:29:52.738247
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # create a dict data
    data = dict(
        foo='bar',
        name='myrole',
        tasks_from='file.yml',
        vars_from='file.yml',
        defaults_from='file.yml',
        handlers_from='file.yml',
        public=True,
        apply=dict(
            bar='baz'
        )
    )

    # create role block
    role = Block.load(dict(
        name="myrole",
    ), task_include=None)
    role._role_path = 'roles/foo'
    role_path = '/path/to/roles'

    # create loader
    class FakeLoader:
        class FakeFile:
            def __init__(self, name, data):
                self.name = name
                self.data = data

# Generated at 2022-06-21 01:30:01.034365
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
  class BlockLike(Block):
    _default_name = '/tmp/ansible-test/include_role'

    def __init__(self):
      self._play = 'playlike'
      self._parent = 'parentlike'

  class RoleLike:
    _role_path='/tmp/ansible-test/include_role'

    def __init__(self, name='rolelike'):
      self.get_name = lambda: name

  # Test for basic copy operation
  myblock = BlockLike()
  myrole = RoleLike()
  myinclude = IncludeRole(block=myblock, role=myrole)
  myinclude_copy = myinclude.copy()

  assert myinclude._parent == myinclude_copy._parent
  assert myinclude._role == myinclude_copy._role
  assert myinclude._play == myinclude_

# Generated at 2022-06-21 01:30:06.195027
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(block=Block(), role=Role()).get_name() == 'include_role : '
    assert IncludeRole(block=Block(), role=Role(), name='test').get_name() == 'test'

# Generated at 2022-06-21 01:30:07.149865
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:30:10.654127
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # init
    test_object = IncludeRole(task_include=None)

    # test
    params = test_object.get_include_params()
    assert params == {}

# end get_include_params tests



# Generated at 2022-06-21 01:30:17.412366
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # tests should verify correctness of the generated object
    # The code below will serve as an example of how to use the object.
    # You can cut and paste this code into a testcase and modify it.
    # Or you can put the code in a file and run it using pybot/jybot
    #
    # NOTE: the code assumes that the following variables have been defined:
    #    data - a dict representing a task as defined by
    #           ansible.utils.template.template_from_file
    #    block - an ansible.playbook.block.Block
    #    role - an ansible.playbook.role.Role

    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host

# Generated at 2022-06-21 01:30:26.476893
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole(role='parent')
    task._role_name = 'test_role'
    name = task.get_name()
    assert name == 'test_role : test_role'

    task = IncludeRole(role='parent')
    task.action = 'test_action'
    name = task.get_name()
    assert name == 'test_action : None'

    task = IncludeRole(role='parent')
    task.action = 'test_action'
    task._role_name = 'test_role'
    name = task.get_name()
    assert name == 'test_action : test_role'

    task = IncludeRole(role='parent')
    task.name = 'test_name'
    name = task.get_name()
    assert name == 'test_name : None'

    task = Include

# Generated at 2022-06-21 01:30:34.581555
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class ParentRole:
        def get_role_params(self):
            return {'ansible_foo': 'bar'}
        def get_name(self):
            return 'testrole_1'
    class Play:
        class Role:
            _role_path = '/path/to/roles'
    class Block:
        def __init__(self):
            role = 'testrole_1'
    class Role:
        def __init__(self):
            self.vars = {}
            self.include_role_tasks = []
            self._dep_chain = []
    it = IncludeRole()
    it._parent_role = ParentRole()
    it._parent = Block()
    it._parent_role._play = Play()
    it.collections = 'test_collections'
    r = Role()
   

# Generated at 2022-06-21 01:30:51.430917
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    pass

# Generated at 2022-06-21 01:30:58.624556
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class MockRole(object):
        def __init__(self, name):
            self.name = name

    def test_get_name():
        role = MockRole('example-role')
        block = Block(role=role, task_include=IncludeRole(role=role))
        assert block.task_include.get_name() == '- include_role : example-role', 'The method get_name of class IncludeRole returns "{}" instead of "{}"'.format(block.task_include.get_name(), '- include_role : example-role')

    test_get_name()

# Generated at 2022-06-21 01:31:06.741177
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext

    block = Block(play=Play())
    role = Role()
    task_include = TaskInclude()

    r = IncludeRole(block, role, task_include)

    playbook_name = 'playbook.yml'
    play = Play().load({}, loader=None, variable_manager=PlayContext(loader=None))
    block = Block(play=play, parent=None)
    role = Role.load('role', play=play, variable_manager=PlayContext(loader=None), loader=None)
    task_include = TaskInclude()

    r = IncludeRole(block, role, task_include)

    assert isinstance(r.get_name(), string_types)

# Generated at 2022-06-21 01:31:12.325455
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import pytest

# Generated at 2022-06-21 01:31:23.228139
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create an IncludeRole object to test
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = dict(name='my_role')
    ir._role_name = ir.args['name']
    ir._role_path = None
    ir._parent = Mock()
    # Mock the blocks needed to call get_block_list
    ir.vars = dict()
    ir.collections = {}
    play = Mock()
    variable_manager = Mock()
    loader = Mock()
    # Call the method to test
    blocks, handlers = ir.get_block_list(play=play, variable_manager=variable_manager, loader=loader)
    # Assert the result is correct
    assert blocks, handlers
    assert len(blocks) == 1
    # Check the parent of the created block
    assert blocks

# Generated at 2022-06-21 01:31:33.786480
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Create a nested role
    role1 = Role()
    role1.name = 'role1'
    role1.path = 'roles/role1'
    role1.tasks_path = 'roles/role1/tasks/main.yml'

    role2 = Role()
    role2.name = 'role2'
    role2.path = 'roles/role2'
    role2.tasks_path = 'roles/role2/tasks/main.yml'

    include = IncludeRole()
    include.roles = [role2]
    include.name = 'include-role'
    include.action = 'include_role'
    include._role_name = 'test-role'
    include._role_path = 'roles/test-role'
    include.task_include = TaskIn

# Generated at 2022-06-21 01:31:34.627550
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    pass

# Generated at 2022-06-21 01:31:44.520448
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    data = {
        "block": {
            "name": "test_block",
            "path": "/path/to/test_block",
            "parent": None,
            "role": None,
            "task_include": None,
            "block": None,
            "when": [],
            "rescue": []
        },
        "args": {
            "name": "test_role_name"
        },
        "action": "include_role",
        "delegate_to": False,
        "loop": None,
        "tags": "",
        "when": None,
        "until": None,
        "register": None,
        "ignore_errors": False,
        "notify": []
    }

    i = IncludeRole.load(data)

    # Copy i to new_i
    new

# Generated at 2022-06-21 01:31:53.860493
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import collection_loader

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.vars import VarsModule
    from ansible.utils.vars import combine_vars

    import tempfile
    import shutil
    import os
    import json
    import sys

    if sys.version_info < (3,):
        import yaml2
    else:
        import imp

# Generated at 2022-06-21 01:32:02.606499
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''Unit test for method load of class IncludeRole
       Role is required field and must be set, but if not
        then will use name as alias.
    '''
    data = dict(
        name='foobar',
        role='foo'
    )
    ir = IncludeRole()
    ir_new = IncludeRole.load(data)
    assert ir_new._role_name == ir._role_name == 'foobar'

    # role is required, but can be alias to name
    data.pop('role')
    ir_new = IncludeRole.load(data)
    assert ir_new._role_name == ir._role_name == 'foobar'
    data['name'] = None

    # will fail without name

# Generated at 2022-06-21 01:32:42.447176
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test the method get_block_list of the object IncludeRole.
    :return:
    """

    # The object task of the object IncludeRole
    # The object block of the object task
    # The object Block of the object block
    block = Block(parent_block=None, role=None, task_include=None, use_handlers=True)
    # The object role of the object IncludeRole
    role = Role()
    # The object task_include of the object IncludeRole
    task_include = TaskInclude()
    # The object IncludeRole
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    # include_role._role_name = include_role.args.get('name', include_role.args.get('role'))
    include_role._role_name

# Generated at 2022-06-21 01:32:53.698007
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook import Play

    play_obj = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'roles': [
            {'name': 'role1'},
            {'include_role': {'name': 'role2'}},
            {'include_role': {'name': 'role3', 'apply': {'exclude': 'this'}}},
        ]
    }, variable_manager=None, loader=None)

    role1 = play_obj.get_roles()[0]
    role2 = play_obj.get_roles()[1]._parent
    role3 = play_obj.get_roles()[2]._parent

    assert set([]) == set(role1.get_include_params())

# Generated at 2022-06-21 01:32:57.181572
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    pb = IncludeRole()
    assert pb.get_name() == "include_role : "

# Generated at 2022-06-21 01:33:06.023749
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude


# Generated at 2022-06-21 01:33:14.901895
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_id = '1'
    play_tasks = [
        {
            "include_role": {
                "name": "foo",
                "apply": {"configure": {"key": "value"}},
                "allow_duplicates": False,
                "public": False,
                "rolespec_validate": True}}]

# Generated at 2022-06-21 01:33:24.606241
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # dummy class to inherit from
    class role(object):
        pass

    class TaskInclude(object):
        pass

    class Block(object):
        pass

    class Loader(object):
        def get_basedir(self):
            return 'my/basedir'

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar

    def get_vars(self):
        return dict(
            a=1,
            b=2
        )

    class VariableManager(object):
        def get_vars(self):
            return get_vars(self)

    # load a RoleDefinition
    rd = RoleDefinition()
    rd._role_path = 'a/b/c'
    rd._metadata = dict(
        allow_duplicates = False
    )

# Generated at 2022-06-21 01:33:33.287832
# Unit test for method load of class IncludeRole

# Generated at 2022-06-21 01:33:43.378897
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test valid data
    data = {'name': 'my_role'}
    include_role = IncludeRole.load(data, task_include=Block())
    assert include_role._from_files == {'tasks': 'main.yml', 'vars': 'main.yml', 'defaults': 'main.yml', 'handlers': 'main.yml'}
    assert include_role._allow_duplicates is True
    assert include_role._public is False
    assert include_role._rolespec_validate is True
    assert include_role._role_name == 'my_role'

    # Test valid data with a role provided as an alias for 'name'
    data = {'role': 'my_role'}
    include_role = IncludeRole.load(data, task_include=Block())

# Generated at 2022-06-21 01:33:48.185941
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = 'task_include'
    ir = IncludeRole(block, role, task_include=task_include)
    assert ir._parent == block



# Generated at 2022-06-21 01:33:54.008835
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import os
    import tempfile
    import json

    # init temporary vault password file
    vault_password_file_fd, vault_password_file = tempfile.mkstemp()
    os.close(vault_password_file_fd)
    os.write(vault_password_file_fd, b"12345")

    # init a vault