

# Generated at 2022-06-21 01:24:35.979592
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import pytest
    from ansible.playbook.role import Role

    parent_role1 = Role()
    parent_role1._role_name = 'role1'
    parent_role1._role_path = '/role1'

    parent_role1._role_params = {
        'role_name': 'role1',
        'role_path': '/role1'
    }

    parent_role2 = Role()
    parent_role2._role_name = 'role2'
    parent_role2._role_path = '/role2'

    parent_role2._role_params = {
        'role_name': 'role2',
        'role_path': '/role2'
    }

    parent_role3 = Role()
    parent_role3._role_name = 'role3'
    parent_role3._

# Generated at 2022-06-21 01:24:41.689711
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext

    # default values
    ir = IncludeRole()
    assert ir.action == C.INCLUDE_ROLE_TASK_NAME
    assert ir.name is None
    assert ir.vars == dict()
    assert ir.when is None
    assert ir.block is None
    assert ir.loop is None
    assert ir._parent_role is None
    assert ir._role_name is None
    assert ir._role_path is None

    # assigned values
    ir = IncludeRole(name='test_name', block=Block(parent=Block()), vars=dict(test_var='test_value'), when="test_when", loop="test_loop", role=PlayContext())
    assert ir.action == C.INCLUDE_ROLE_TASK_NAME

# Generated at 2022-06-21 01:24:44.611853
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = "web"

    assert ir.get_name() == "include_role : web"

# Generated at 2022-06-21 01:24:52.404422
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role_name = 'role'
    role_path = '/path/to/role/'
    role = Role()
    role._role_name = role_name
    role._role_path = role_path
    include_role = IncludeRole(block=block, role=role)
    assert include_role.get_include_params() == {'ansible_parent_role_names': [role_name], 'ansible_parent_role_paths': [role_path]}


# Generated at 2022-06-21 01:25:01.237306
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.vars

    # play instance
    play_name = 'play_name'
    play = ansible.playbook.play.Play()
    play.name = play_name
    play.handlers = [ansible.playbook.handler.Handler() for i in range(0, 2)]
    play.roles = [ansible.playbook.role.Role() for i in range(0, 2)]

    # tasks
    task_math_name = 'test_task_math'
    test_task_math = ansible.playbook.task.Task()
    test_task_math.name = task_

# Generated at 2022-06-21 01:25:13.237988
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    A test to make sure IncludeRole correctly inherits parameters from its parent
    """
    d = dict()
    i = IncludeRole.load(d)
    # without a parent, no inheritance should happen
    assert i.get_include_params()['ansible_parent_role_names'] == []
    assert i.get_include_params()['ansible_parent_role_paths'] == []

    # make a dummy role to use as a parent
    r = Role.load(dict(name='parent', tasks=[]))
    r._role_path = 'fake_path'
    i = IncludeRole.load(d)
    i._parent = Block(parent_block=None)
    i._parent_role = r
    # now that we have a parent, we should see them in the params
    assert i.get_include_

# Generated at 2022-06-21 01:25:17.399832
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    Create a IncludeRole object with task_include, block and role.
    """
    include_role = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude())
    assert isinstance(include_role, IncludeRole)

# Generated at 2022-06-21 01:25:25.702544
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Setup
    ir = IncludeRole()

    # Exercise
    # Verify
    assert ir._parent_role is None
    assert ir.get_include_params() == {'ansible_role_name': '', 'ansible_role_path': ''}

    # Setup
    ir = IncludeRole()
    ir._parent_role = Role()
    ir._parent_role._name = 'name of role'
    ir._parent_role._role_path = '/path/to/role'

    # Exercise
    # Verify
    assert ir._parent_role is not None

# Generated at 2022-06-21 01:25:32.744181
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Test that IncludeRole.get_name() returns the name with the action 'include_role'
    """
    block_data = """
        - name: my-role
          include_role:
            name: my-role
    """
    block = Block.load(block_data, None, task_include=None)
    role = Role()
    role._role_name = "my-role"
    include_role = IncludeRole(block, role)
    assert include_role.get_name() == "include_role : my-role"

# Generated at 2022-06-21 01:25:44.549776
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    for testing get_name method of IncludeRole class
    """
    block1 = Block.load(dict(rescue=[]), task_include=None, role=None, loader=None, variable_manager=None)
    role1 = Role()
    task_include1 = TaskInclude()
    role2 = Role()
    task_include2 = TaskInclude()
    ir = IncludeRole(block=block1, role=role1, task_include=task_include1)
    assert ir.get_name() == " - include_role : "
    ir = IncludeRole(block=block1, role=role2, task_include=task_include2)
    ir._role_name = 'test'
    assert ir.get_name() == " - include_role : test"

# Generated at 2022-06-21 01:25:59.177158
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import unittest

    class AnsiblePlaybook(object):

        def __init__(self):
            self.roles = []

    class AnsibleRole(object):

        def __init__(self):
            self._role_path = '/path/to/role'

        def get_handler_blocks(self):
            return []

        def compile(self):
            return []

    role = AnsibleRole()
    include_role = IncludeRole(role=role)
    include_role._role_name = 'role'
    play = AnsiblePlaybook()
    assert len(include_role.get_block_list(play)) == 2

# Generated at 2022-06-21 01:26:05.974724
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test with only block
    bl = Block()
    ir = IncludeRole(block=bl)
    ans = ir.get_block_list()
    assert ans == ([], []), "Result of get_block_list for only block is wrong"

    # Test with block and role
    r = Role()
    ir = IncludeRole(block=bl, role=r)
    ans = ir.get_block_list()
    assert ans == ([], []), "Result of get_block_list for block and role is wrong"

# Generated at 2022-06-21 01:26:17.847165
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    '''
    test method copy of class IncludeRole
    '''
    ir = IncludeRole(block=Block(play=None), task_include=TaskInclude(Block(play=None)))

    ir.statically_loaded = True
    ir._from_files = {'tasks': 'tasks'}
    ir._parent_role = 'parent_role'
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'

    new_ir = ir.copy()
    assert isinstance(new_ir, IncludeRole)
    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from_files == ir._from_files
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_name == ir._role

# Generated at 2022-06-21 01:26:21.675109
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create a parent role
    parent_role = Role()
    parent_role._role_name = 'parent_role_name'
    parent_role._role_path = 'parent_role_path'
    parent_role._metadata = dict()
    parent_role._metadata['role_params'] = dict()
    parent_role._metadata['role_params']['role_name'] = parent_role._role_name
    parent_role._metadata['role_params']['role_path'] = parent_role._role_path
    parent_role.get_name = lambda: parent_role._role_name
    parent_role.get_role_params = lambda: parent_role._metadata['role_params']

    # Create an IncludeRole
    include_role = IncludeRole()
    include_role._role_name = 'role_name'

# Generated at 2022-06-21 01:26:29.565790
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.handler

    ansible.playbook.role._ROLE_CACHE = dict()
    ansible.playbook.task._ROLE_TASKS_CACHE = dict()
    ansible.playbook.role._ROLE_HANDLERS_CACHE = dict()

    # Create a play
    p = ansible.playbook.play.Play()
    p._ds = dict( name="test_play" )
    p._loader = ansible.parsing.dataloader.DataLoader()

    # Create a parent role
    r = ansible.playbook.role.Role

# Generated at 2022-06-21 01:26:33.136019
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Try with no parameters
    assert IncludeRole.load({}) is not None
    # Try with one parameter
    assert IncludeRole.load({'name': 'test'}) is not None


# Generated at 2022-06-21 01:26:34.210200
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-21 01:26:36.706908
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
  from ansible.playbook.task import Task
  task = Task()
  task._role = 'role.tasks'
  ir = IncludeRole(task)

# Generated at 2022-06-21 01:26:42.078856
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    this = IncludeRole()
    assert this.get_name() == 'include_role : None'

    this._role_name = 'foo'
    assert this.get_name() == 'include_role : foo'

    this = IncludeRole()
    this.name = 'namename'
    this._role_name = 'foo'
    assert this.get_name() == 'namename : foo'


# Generated at 2022-06-21 01:26:54.200600
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Setup Variables
    test_host = 'hostname'
    test_play = {'handler': 'handler', 'hosts': test_host, 'name': 'playname', 'tasks': []}
    test_variable_manager = '__test_variable_manager__'
    test_loader = '__test_loader__'

    # Create Source Block
    source_mock = '__mock_block__'
    test_block_name = 'task'
    test_block_action = 'include_role'
    test_block_args = {'name': 'test_role'}
    test_block = Block(source_mock, test_block_name, test_block_action, test_block_args, [])

    # Create Template
    test_template = '{{ test_role }}'
    test_template_

# Generated at 2022-06-21 01:27:10.076595
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import copy

    # Create original IncludeRole object
    ir = IncludeRole()

    # Set some of the attributes of the class IncludeRole
    ir.args = {'name': 'TestRole1',
               'private': True,
               'tasks_from': 'test_tasks.yml',
               'vars_from': 'test_vars.yml',
               'apply': dict(test=True),
               'allow_duplicates': False,
               'rolespec_validate': True}

    ir._allow_duplicates = False
    ir._public = True
    ir._rolespec_validate = True

    ir._role_name = 'TestRole1'
    ir._role_path = 'TestRole1_Path'


# Generated at 2022-06-21 01:27:13.956034
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role_name = 'name'
    ir = IncludeRole()
    ir._role_name = role_name
    ir.action = 'include_role'
    name = ir.get_name()
    assert name == '%s : %s' % (ir.action, role_name)

# Generated at 2022-06-21 01:27:17.890909
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    task_include = TaskInclude()
    role = Role(name='TestRole')
    ir = IncludeRole(block, role)
    assert ir.block == block and ir.role == role and ir._task_include == task_include

# Generated at 2022-06-21 01:27:21.737514
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = {'name': 'test'}
    ir = IncludeRole(task_include=True)
    ir = ir.load_data(data)
    assert len(ir.args) == 1
    assert ir.args['name'] == 'test'



# Generated at 2022-06-21 01:27:26.665526
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()

    ir._role_name = 'test_role'
    ir.name = 'test_include'

    assert ir.get_name() == 'test_include : test_role'

    ir.name = None

    assert ir.get_name() == 'include_role : test_role'

# Generated at 2022-06-21 01:27:30.778185
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task = IncludeRole(block=block, role=role)

    task.name = 'test task'
    task._role_name = 'test_role'

    assert task.get_name() == 'test task'

    task.name = None
    assert task.get_name() == 'include_role : test_role'

# Generated at 2022-06-21 01:27:42.371590
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Testing get_include_params where _parent_role is None, None is returned
    block = Block()
    ir = IncludeRole(block=block)
    assert ir.get_include_params() is None

    # Testing get_include_params where param 'ansible_parent_role_names' exists, the corresponding value is returned
    block = Block()
    ir = IncludeRole(block=block)
    ir._parent_role = object()
    ir._parent_role.get_role_params = lambda : {'ansible_parent_role_names': ['test']}
    assert ir.get_include_params()['ansible_parent_role_names'] == ['test']

    # Testing get_include_params where param 'ansible_parent_role_names' does not exist, the corresponding default value is returned
    block = Block()
   

# Generated at 2022-06-21 01:27:48.703521
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create object to test with
    ir = IncludeRole()

    # Set some properties
    ir._parent_role = 'role-object'

    # Call function under test
    ret = ir.get_include_params()

    # Assert
    assert ret == {'ansible_parent_role_names': ['role-object'], 'ansible_parent_role_paths': ['role-object']}

# Generated at 2022-06-21 01:27:56.499129
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.task import Task

    i = IncludeRole(block=Block())
    i.name = 'include_role_name'
    i.action = 'include_role_action'
    i._role_name = 'include_role_name'
    i._role_path= '/path/to/role/'
    i.tags = ["tag1", "tag1"]
    i.when = "when value"
    i.vars = {'key1': 'val1', 'key2': 'val2'}
    i.statically_loaded = True
    i._from_files = {'tasks': 'main.yaml', 'handlers': 'handlers/main.yaml', 'vars': 'vars/main.yaml', 'defaults': 'defaults/main.yaml'}
   

# Generated at 2022-06-21 01:28:09.184442
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    b = Block()
    my_role = Role()
    my_ti = IncludeRole(b, my_role)
    my_ti.name = 'my_name'
    my_ti.action = 'my_action'
    my_ti.statically_loaded = False
    my_ti._from_files = {'tasks': 'my_task'}
    my_ti._role_name = 'my_role_name'
    my_ti._role_path = 'my_role_path'

    my_copy = my_ti.copy()
    assert my_ti.name == my_copy.name, my_copy.name
    assert my_ti.action == my_copy.action, my_copy.action
    assert my_ti.statically_loaded == my_copy.statically_loaded, my_copy.st

# Generated at 2022-06-21 01:28:34.351707
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    In order to test IncludeRole class, we need to have a task,
    role and a play. We cannot pass the play, role and task to the
    IncludeRole class because the parameters of the load method
    needs to be tested.

    The load method takes three parameters

    # load(self, data, block=None, role=None, task_include=None, variable_manager=None, loader=None):

    In order to test load method without passing the parameters,
    we will create first a class TaskInclude and then we will
    finally create a class IncludeRole for testing the load method
    of the IncludeRole.

    The creation of the class TaskInclude is necessary to use the
    super function on the load function of the IncludeRole.

    """


    class TaskInclude(object):
        name = 'TaskInclude'


# Generated at 2022-06-21 01:28:38.550912
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    r = Role({})
    r.name = 'base'
    r._role_path = '/a/path/to/some/role'
    r.get_role_params = lambda: dict(a='a', b='b')
    i = IncludeRole({}, r)
    i.name = 'include'
    i.vars = dict(c='c', d='d')
    i._role_path = '/a/path/to/some/other/role'
    params = i.get_include_params()

# Generated at 2022-06-21 01:28:47.818712
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    loader, inventory, variable_manager = C.load_extra_vars(C.DEFAULT_LOAD_CALLBACK_PLUGIN, loader=None, inventory=None, variable_manager=None)

# Generated at 2022-06-21 01:28:52.147017
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole().get_name() == 'include_role : '
    assert IncludeRole(name='dummy').get_name() == 'dummy : '
    assert IncludeRole(name='dummy', role='role').get_name() == 'dummy'



# Generated at 2022-06-21 01:29:00.881620
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_vars = dict(a=1)
    test_block = Block(dict(vars=test_vars))
    test_task = IncludeRole(block=test_block)
    test_task.name = 'test_name'

    # Test with name
    assert test_task.get_name() == 'test_name'
    # Test without name
    test_task.name = None
    assert test_task.get_name() == 'include_role : None'


# Generated at 2022-06-21 01:29:13.544118
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    block = Block()
    role = RoleDefinition()
    role._parents = ['rp']
    role._role_path = 'rp'
    role._metadata = 'um'
    role_include = IncludeRole(block=block, role=role)

    task_include = TaskInclude(block=block)
    task_include.from_file = 'ff'
    task_include._from_file_args = 'ffa'
    task_include.args = 'a'
    task_include.vars = 'v'
    task_include.always_run = 'ar'
    task_include.register = 'r'
    task_include.ignore_errors = 'ie'

# Generated at 2022-06-21 01:29:25.210663
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    test_role = IncludeRole()

    assert test_role.BASE == ('name', 'role')
    assert test_role.FROM_ARGS == ('tasks_from', 'vars_from', 'defaults_from', 'handlers_from')
    assert test_role.OTHER_ARGS == ('apply', 'public', 'allow_duplicates', 'rolespec_validate')
    assert test_role.VALID_ARGS == ('tasks_from', 'vars_from', 'defaults_from', 'handlers_from', 'apply', 'public', 'allow_duplicates', 'name', 'role', 'rolespec_validate')
    assert test_role.collections == {}

# Generated at 2022-06-21 01:29:35.064405
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    import tempfile
    import shutil
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-21 01:29:43.199064
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test the case of no parent role
    ir = IncludeRole(block=None, role=None, task_include=None)
    v = ir.get_include_params()
    assert v == {}

    # Test the case of having a parent role
    parent_role = Role()
    role_path = '/home/carl/ansible/lib/ansible/roles/test_role'
    role_name = 'test_role'
    parent_role._role_path = role_path
    parent_role._role_name = role_name
    ir = IncludeRole(block=None, role=parent_role, task_include=None)
    v = ir.get_include_params()
    assert v['ansible_parent_role_names'][0] == role_name

# Generated at 2022-06-21 01:29:54.178788
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test 1 - role 'test_role' is valid
    #   - no specified vars 'arg1', 'arg2'
    #   - no specified tasks 'test_task', 'test_task'
    #   - no vars_from, defaults_from, or handlers_from specified
    #   - no apply specified
    #   - role_path and role name are '/<role_path>/test_role'
    #   - role statically loaded is True
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.variables.manager import VariableManager


    class CompileRole:
        def __init__(self, parent=None):
            self._parents = []

# Generated at 2022-06-21 01:30:26.393909
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole.load(dict(role='xyz', apply=dict(a=1)), block=Block(), role=Role(), task_include=TaskInclude())
    assert ir.public == False
    assert ir._role_name == 'xyz'
    assert ir._from_files['vars'] == 'main.yml'

    # include_role allow duplicates by default
    ir = IncludeRole.load(dict(role='xyz', allow_duplicates=False), block=Block(), role=Role(), task_include=TaskInclude())
    assert ir.public == False
    assert ir._role_name == 'xyz'
    assert ir.allow_duplicates == False

# Generated at 2022-06-21 01:30:30.616109
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    host = 'test'
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)
    ir._role_name = 'new_role'

    include_name = 'new_role : new_role'
    name = ir.get_name()
    assert include_name == name

# Generated at 2022-06-21 01:30:37.715077
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    loader = DummyLoader()
    play = mock.Mock()
    role = mock.Mock()
    parent = mock.Mock()
    parent.parent_block.name = 'parent'
    blocks = [parent, role]
    role._parent_role = parent
    role._parent = parent
    role._task_blocks = blocks
    role._load_role = mock.Mock(return_value=role)
    role._parent_role._dep_chain = ['dep1', 'dep2']
    play._handlers = ['handlers']
    variable_manager = mock.Mock()


# Generated at 2022-06-21 01:30:46.012839
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import combine_vars

    display = Display()

# Generated at 2022-06-21 01:30:57.386672
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    class ParentRole(Role):
        pass

    block = Block()
    parent_role = ParentRole(name='role1')
    include_role = IncludeRole(block, parent_role)
    include_role._role_path = 'role1'
    include_role.statically_loaded = True
    include_role._from_files = {'vars': 'vars/main.yml', 'tasks': 'tasks/main.yml'}
    include_role._allow_duplicates = False
    include_role._public = True

    new_include_role = include_role.copy(exclude_parent=True, exclude_tasks=True)

    assert new_include_role.action == 'include_role'
    assert new_include_role.block == block
    assert new_include_role.parent == None

# Generated at 2022-06-21 01:31:02.556005
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Ensure that the get_block_list method on an IncludeRole object works as expected
    '''

    block = Block()
    block._parent = None

    # Test without a parent role
    task = IncludeRole(block, role=None)

    # Test with a parent role
    role = Role()
    role._role_path = 'test_path'
    role._metadata = {'allow_duplicates': False}
    role._parents = []

    task = IncludeRole(block, role=role)



# Generated at 2022-06-21 01:31:06.109788
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Test get_name of IncludeRole
    """

    # IncludeRole object
    irr = IncludeRole()

    irr.name = 'test'

    # test
    name = irr.get_name()

    assert name is not None, "get_name should return something"


# Generated at 2022-06-21 01:31:07.940693
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True

# Generated at 2022-06-21 01:31:13.174862
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.module_utils.six import PY3

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    ir = dict(
        name='some_role',
        tasks_from='foo',
        vars_from='bar',
        handlers_from='baz',
        public=True,
        allow_duplicates=False
    )

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-21 01:31:25.410444
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play
    import ansible.playbook.task

    def _get_the_block_list(block_str, block_str_with_handlers):
        # mock a role
        role1 = ansible.playbook.role.Role()
        role1.name = 'role1'
        role1._role_path = 'role1'
        role1.blocks = [ansible.playbook.block.Block.load(block_str)]
        role1.handlers = [ansible.playbook.block.Block.load(block_str_with_handlers)]

        # mock a Play
        play = ansible.playbook.play.Play()

        # mock a task
        task = ansible.playbook.task.Task()
        task._role = role1
        task._parent = role1

# Generated at 2022-06-21 01:32:25.098969
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task_include
    import ansible.playbook.task

    from ansible.playbook.included_file import IncludedFile
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.mod_args import ModuleArgsParser

    args = dict(
        name='role-name',
        collections=[['namespace', 'collection']],
        tasks_from='tasks/main.yml',
        vars_from='vars/main.yml',
        handlers_from='handlers/main.yml',
    )

    block = ansible.playbook.block.Block()
    block.root_block = True
    play = ansible.playbook.play

# Generated at 2022-06-21 01:32:36.277191
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''Test get_include_params()'''
    ir = IncludeRole()
    v = ir.get_include_params()
    assert v['ansible_role_names'] == []
    assert v['ansible_role_paths'] == []
    assert 'ansible_parent_role_names' not in v
    assert 'ansible_parent_role_paths' not in v
    ir = IncludeRole(parent_role=Block())
    v = ir.get_include_params()
    assert v['ansible_role_names'] == []
    assert v['ansible_role_paths'] == []
    assert v['ansible_parent_role_names'] == []
    assert v['ansible_parent_role_paths'] == []

# Generated at 2022-06-21 01:32:43.193515
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import pytest
    # test for instance without parent_role
    ir = IncludeRole()
    include_params = ir.get_include_params()
    assert getattr(include_params, 'ansible_parent_role_names') == None
    assert getattr(include_params, 'ansible_parent_role_paths') == None
    # test for instance with parent_role
    class RoleObj:
        def get_role_params(self):
            return 'get_role_params'
        def get_name(self):
            return 'get_name'
        _role_path = '_role_path'
    class IncludeObj:
        _parent_role = RoleObj()
    ir = IncludeRole(task_include=IncludeObj())
    include_params = ir.get_include_params()

# Generated at 2022-06-21 01:32:53.903792
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inv_mgr)

    # valid
    data = dict(
        name="some_role",
        role=None,
        tasks_from="some_dir/some_file.yml"
    )
    ir = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    assert ir._role_name == "some_role"

# Generated at 2022-06-21 01:32:59.237371
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    data = dict(name="TestRole")
    block = Block()
    include_role = IncludeRole.load(data, block)
    assert include_role.get_name() == "include_role : TestRole"



# Generated at 2022-06-21 01:33:03.597631
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role_block = Block()
    role_block.name = 'test_name'
    include_role = IncludeRole(role_block)
    assert include_role.get_name() == 'name: test_name'

# Generated at 2022-06-21 01:33:14.134652
# Unit test for method load of class IncludeRole

# Generated at 2022-06-21 01:33:24.269660
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    play = Play().load(dict(name="myplay", hosts=["myhost"]), variable_manager=None, loader=None)
    role = Role().load(dict(name="myrole", hosts=["myhost"]), play=play)
    role.compile()
    ir = IncludeRole(block=None, role=role).load(dict(name="myincluderole"), variable_manager=None, loader=None)
    ir.compile()
    # assert that manually added properties are copied

    ir2 = ir.copy()
    assert ir2.action == ir.action
    assert ir2._allow_duplicates == ir._allow_duplicates
    assert ir2._public == ir._public
    assert ir2._from

# Generated at 2022-06-21 01:33:33.177240
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.required_context import RequiredContext
    from ansible.playbook.role.context import TaskContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    myplay = Play().load({'name': 'test_play',
                          'hosts': 'localhost',
                          'roles' : [
                            {'role': 'test_role1'},
                            {'role': 'test_role2'},
                            {'role': 'test_role3'},
                            ]}, variable_manager=None, loader=None)

    role1 = Role().load({'name': 'test_role1'}, play=myplay, variable_manager=None, loader=None)


# Generated at 2022-06-21 01:33:43.378790
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class MockPlay():
        class MockName(object):
            def __init__(self, name):
                self.name = name
        def __init__(self, name):
            self.name = self.MockName(name)

    class MockRole(object):
        class MockName(object):
            def __init__(self, name):
                self.name = name
        def __init__(self, name):
            self.name = self.MockName(name)

    display.verbosity = 3

    # Test 1
    ir = IncludeRole(task_include=Block())
    ir.action = 'include_role'
    ir.name = 'mytest'
    ir._role_name = 'mytest'
    assert(ir.get_name() == 'mytest : mytest')

    # Test 2
   