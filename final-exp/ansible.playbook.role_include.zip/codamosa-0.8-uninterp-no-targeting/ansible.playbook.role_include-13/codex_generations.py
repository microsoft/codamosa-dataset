

# Generated at 2022-06-21 01:24:38.832014
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    block = Block()
    block.action = 'meta'
    task = Task()
    task.action = 'meta'
    task._role = None
    task._block = block
    task_include = TaskInclude()
    task_include._task = task
    task_include._block = block
    task_include._play_context = PlayContext()
    task_include.role_name = 'some_role'
    task_include._parent = task
    task_include.vars = {"keyword":"value"}
    ir = IncludeRole(block, role=None, task_include=task_include)

# Generated at 2022-06-21 01:24:44.519301
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class args:
        name = 'foo'
    class Role:
        def __init__(self):
            self.name = None
    ir = IncludeRole()
    ir.name = None
    ir._parent = Role()
    assert ir.get_name() == '- include_role : foo'

# Generated at 2022-06-21 01:24:56.190309
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    # Create the role objects
    parent_role = Role()
    parent_role.name = 'parent_role'
    parent_role.vars = dict(var1 = 'parent_role var1',var2 = 'parent_role var2')
    parent_role.path = '/path/to/parent/role'
    parent_role._metadata = dict(metadata_parent_role = 'metadata_parent_role')
    parent_block = Block()
    parent_block.vars = dict(var3 = 'parent block var3')
    parent_role._task_blocks.append(parent_block)
    p_parent_role = Role()
    p_parent_role.name = 'parent parent role'
    p_parent_role._

# Generated at 2022-06-21 01:25:07.730519
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test load method with empty data
    data = {}
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    result = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert result is not None
    assert isinstance(result, IncludeRole)
    assert result.from_files == {}
    assert result.name is None
    assert result.parent_role == role
    assert result.role_name is None
    assert result.role_path is None
    assert result.args == {}

    # Test load method with simple attributes
    data = {"name": "my_role"}
    result = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert result is not None

# Generated at 2022-06-21 01:25:16.806043
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = NoVars()

    role_name = "test_role"
    role = Role.load(role_name, loader=loader, variable_manager=variable_manager)
    parent = Block([IncludeRole(role=role, loader=loader, variable_manager=variable_manager)])
    parent.post_validate()
    assert parent.get_children()[0].get_include_params()["ansible_role_name"] == role_name



# Generated at 2022-06-21 01:25:25.367353
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = dict(
        role='role_common',
        name='role_common'
    )
    block = Block()
    role = Role()

    ir = IncludeRole.load(data)
    assert ir.statically_loaded
    assert ir._allow_duplicates
    assert not ir._public
    assert ir._rolespec_validate
    assert ir._from_files == {}
    assert ir._parent_role is None
    assert ir._role_name == 'role_common'
    assert ir._role_path is None

    ir = IncludeRole.load(data, block=block, role=role)
    assert not ir.statically_loaded
    assert ir._allow_duplicates
    assert not ir._public
    assert ir._rolespec_validate
    assert ir._from_files == {}
    assert ir

# Generated at 2022-06-21 01:25:35.096911
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader, lookup_loader, module_loader

    display.verbosity = 3
    ir = IncludeRole()
    ir.action = 'include_role'
    ir._parent = Block()
    ir._parent._play = PlayContext()
    ir._parent._play.action_loader = action_loader
    ir._parent._play.lookup_loader = lookup_loader
    ir._parent._play.module_loader = module_loader
    ir.args = {'name': 'my_name', 'tags': ['my_tag'], 'when': 'my_when',
               'ignore_errors': False, 'register': 'my_result'}

    assert ir.get_name() == 'include_role : my_name'


# Generated at 2022-06-21 01:25:46.062457
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.block import Task
    tasks = [{u'include_role': {u'name': u'common', u'allow_duplicates': True},
              u'name': u'Include role common'},
             {u'meta': {u'role1': {u'foo': u'bar'}},
              u'name': u'Set foo to bar',
              u'vars': {u'foo': u'bar'},
              u'vars_files': [u'file1', u'file2']}]
    block = Block.load(tasks, parent_role=None, play=None, task_include=None, role=None, use_handlers=True,
                       loader=None, variable_manager=None)

# Generated at 2022-06-21 01:25:55.918911
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.executor.play_iterator import PlayIterator

    host = dict(name='localhost', port=2020)
    hostvars = dict()
    loader = None
    variable_manager = VariableManager(loader=loader, inventory=None)
    variable_manager.set_host_variables(host, hostvars)

    play_context = PlayContext()
    play_context.load.loader = loader
    play_context.connection = None

    # initialize a block to use as a parent
    block1 = Block()
    play_context.set_task_and_

# Generated at 2022-06-21 01:26:00.077983
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create IncludeRole object
    ir = IncludeRole()

    # Call method get_name() of class IncludeRole
    result = ir.get_name()

    # Check result of method get_name() of class IncludeRole
    assert result is None
    assert ir.name is None
    assert ir._role_name is None

# Generated at 2022-06-21 01:26:18.340493
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # include role has no allow_duplicates option
    assert 'allow_duplicates' not in IncludeRole.load({
        'role': 'web',
    })._attributes

    # allow_duplicates option is set with apply
    assert 'allow_duplicates' in IncludeRole.load({
        'role': 'web',
        'apply': {
            'allow_duplicates': False
        },
    })._attributes

    # allow_duplicates option is set with apply
    assert IncludeRole.load({
        'role': 'web',
        'apply': {
            'allow_duplicates': False
        },
    }).allow_duplicates is False

    # allow_duplicates is overriden by role

# Generated at 2022-06-21 01:26:28.136456
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class my_role:
        def __init__(self):
            self._metadata = []

    class my_play:
        def __init__(self):
            self.roles = []

    class my_block:
        def __init__(self):
            self._parent = None
            self.collections = []

        def build_parent_block(self):
            self = my_block()
            return self

    class my_player:
        def __init__(self):
            self.name = 'my_player'
            self.vars = {'my_player': 'my_player'}
            self._play = my_play()
            self._play.roles = [my_role()]
            self._parent_role = my_role()
            self._play._play = my_play()
            self._

# Generated at 2022-06-21 01:26:30.742476
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    name = ir.get_name()
    assert name == 'include_role :  : '

# Generated at 2022-06-21 01:26:34.535084
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = {'public': '1'}
    block = Block()
    role = Role()
    test_IncludeRole = IncludeRole(data, block, role)
    assert test_IncludeRole.public == "1"

# Generated at 2022-06-21 01:26:42.113809
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # make sure they can be created
    i = IncludeRole(None)
    i = IncludeRole(None, None, None)

    # make sure the internal vars work
    assert i._allow_duplicates == True
    assert i._from_files == {}
    assert i._parent_role == None
    i._parent_role = 'foo'
    assert i._parent_role == 'foo'
    assert i._public == False
    assert i._rolespec_validate == True
    assert i._role_name == None
    assert i._role_path == None

# Generated at 2022-06-21 01:26:44.737437
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = IncludeRole.load({'name': 'test'})
    assert role.get_name() == 'test'


# Generated at 2022-06-21 01:26:55.521636
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role = Role()
    role._role_path = '/path/to/role'
    role._role_name = 'a_role'
    include_role = IncludeRole()
    include_role._parent_role = role
    include_role._role_name = role._role_name
    include_role._role_path = role._role_path
    include_role.statically_loaded = False

    new_include_role = include_role.copy()

    assert new_include_role._parent_role is None
    assert new_include_role._role_name == role._role_name
    assert new_include_role._role_path == include_role._role_path
    assert new_include_role.statically_loaded is False

# Generated at 2022-06-21 01:27:06.019409
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    mytask = IncludeRole()
    mytask._role_name = 'test-role'
    mytask._parent_role = Role()
    mytask._parent_role._role_path = '/etc/ansible/test-role/'
    # Force parent attribute to None to test for this particular case
    mytask._parent._parent = None
    newtask = mytask.copy()
    assert newtask._role_name == 'test-role'
    assert newtask._parent_role._role_path == '/etc/ansible/test-role/'
    assert newtask._parent._parent is None
    # Assert new task is not an IncludeRole

# Generated at 2022-06-21 01:27:13.230395
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import ansible.constants as C

    data = dict(
        name='test_role',
        task_includes=[
            dict(
                role=dict(
                    name='test_role_name',
                    tasks_from='test_role_tasks_from',
                    vars_from='test_role_vars_from',
                    defaults_from='test_role_defaults_from',
                    handlers_from='test_role_handlers_from',
                    apply=dict(
                        static_var='test_role_apply',
                    ),
                ),
            ),
        ],
    )


# Generated at 2022-06-21 01:27:24.705675
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    display.verbosity = 3
    ds = dict(
        name='test_role',
        become='yes',
        become_user='root'
    )
    ir = IncludeRole.load(data=ds, variable_manager=None, loader=None)

    assert ir.get_name() == "include_role : test_role"
    assert ir.args['name'] == 'test_role'
    assert ir.name == "test_role"
    assert ir.action == 'include_role'
    assert ir.allow_duplicates == True
    assert ir.public == False
    assert ir.rolespec_validate == True
    assert ir.statically_loaded == False
    assert ir.become == True
    assert ir.become_user == 'root'

# Generated at 2022-06-21 01:27:48.370335
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    data = { "action": "include_role",
             "args": {"name": "foo", "tasks_from": "tests/test_action_include_role.yml",
                      "allow_duplicates": True, "apply": {"a": "b"}, "rolespec_validate": False} }
    x = IncludeRole.load(data)
    assert(x._role_name == 'foo')
    assert(x._from_files == {'tasks': 'tests/test_action_include_role.yml', 'vars': None, 'defaults': None, 'handlers': None})
    assert(x._allow_duplicates == True)
    assert(x._rolespec_validate == False)
    assert(x.vars == {"a": "b"})


# Generated at 2022-06-21 01:27:56.262250
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()

    ir = IncludeRole(block, role=None, task_include=None)

    block.from_yaml(['- import_role: name=test_role', '  tags:', '    - tags_from_import'], loader=None, variable_manager=None, parent_role=None)

    ir.task_include.block = block
    ir.task_include.role = None
    ir.task_include.args = {'name': 'test_role'}
    ir.task_include.action = 'import_role'

    play = None
    variable_manager = None
    loader = None

    ri = ir.get_block_list(play=play, variable_manager=variable_manager, loader=loader)

    #assert len(ri) == 2


# Generated at 2022-06-21 01:28:05.540389
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    import collections
    import copy
    import os
    import ansible.constants as C
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.plugins.loader import action_loader
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

# Generated at 2022-06-21 01:28:10.525143
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create a mocked role, with a mocked parent role
    class MockedRole:
        def __init__(self, name, path):
            self._name = name
            self._role_path = path
        def get_name(self):
            return self._name
        def get_role_params(self):
            return {"a_role_param" : "a_role_value"}
    class MockedParentRole:
        def __init__(self, name, path):
            self._name = name
            self._role_path = path
        def get_name(self):
            return self._name
        def get_role_params(self):
            return {"a_parent_role_param" : "a_parent_role_value"}

# Generated at 2022-06-21 01:28:14.849815
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(block=None, role=None, task_include=None)
    ir._role_name = "common"
    assert ir.get_name() == "include_role : common"


# Generated at 2022-06-21 01:28:23.425701
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    task_block = Block()
    role = Role()
    task_include = TaskInclude()

    include_role = IncludeRole(block=task_block, role=role, task_include=task_include)

    data = {
        'action': 'include_role',
        'args': {'name': 'common', 'role': 'common', 'tasks_from': 'test_tasks.yml',
                 'vars_from': 'test_vars.yml', 'defaults_from': 'test_defaults.yml',
                 'handlers_from': 'test_handlers.yml', 'public': True,
                 'allow_duplicates': False, 'rolespec_validate': True,
                 'apply': {'name': 'common'}}
    }

    actual_include_role = IncludeRole

# Generated at 2022-06-21 01:28:35.041505
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    i_r = IncludeRole.load({'name' : 'foo'})
    new_i_r = i_r.copy()
    assert new_i_r._from_files == {}
    assert new_i_r._parent_role is None
    assert new_i_r._role_name is None
    assert new_i_r._role_path is None
    assert new_i_r.allow_duplicates is True
    assert new_i_r.apply is {}
    assert new_i_r.args == {'name' : 'foo'}
    assert new_i_r.async_val == 0
    assert new_i_r.delegate_to == 'localhost'
    assert new_i_r.environment == {}
    assert new_i_r.first_available_file == None

# Generated at 2022-06-21 01:28:42.121943
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    r = Role()
    ib = Block()
    ib.block = [{'include_role': 'some_role'}]
    ir = IncludeRole(ib, r)
    assert(ir.name == 'include_role')
    assert(ir.action == 'include_role')
    assert(ir.args is not None)
    assert(ir.role is r)
    assert(ir._role_name == 'some_role')

# Generated at 2022-06-21 01:28:54.995706
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    task_include = IncludeRole()
    task_include._role_name = 'test'
    task_include._parent_role = {'_role_name': 'test_parent'}
    task_include._from_file = {'tasks': 'test_task', 'handlers': 'test_handler'}
    variable_manager = {}
    loader = {}
    blocks, handlers = task_include.get_block_list(variable_manager=variable_manager, loader=loader)
    assert len(blocks) == 1
    block = blocks[0]
    assert block.name == 'test'
    assert block._parent.name == 'test_parent'
    assert block._dep_chain[0] == {'_role_name': 'test_parent'}
    assert block._metadata.allow_duplicates

# Generated at 2022-06-21 01:29:04.573849
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Should construct a Block and set the default options and 
    # allow_duplicates, parent_role and role_name property to None
    ir = IncludeRole()
    assert isinstance(ir, Block) == True
    assert ir.action == 'include_role'
    assert ir.allow_duplicates == True
    assert ir.parent_role == None
    assert ir.role_name == None
    assert ir.static_load == False
    assert ir.statically_loaded == False
    assert ir.tags == set()
    assert ir.when == set()
    assert len(ir.post_validate_msg) == 0

    # Should construct a IncludeRole object and set the role_name property to 'my_role'
    ir = IncludeRole(role='my_role')
    assert isinstance(ir, Block) == True
   

# Generated at 2022-06-21 01:29:25.890923
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'name': 'foo',
        'role': 'generic',
        'bar': 'foo',
        'baz': 'foo',
        'unused': 'foo'
    }
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition()
    role.name = 'generic'

    ir = IncludeRole.load(data, role=role)
    # validate internal vars
    assert ir._role_name == 'foo'
    assert ir._from_files == {}
    assert ir._parent_role == role
    assert ir._role_path is None

    # make sure allowed options load
    for k in IncludeRole.VALID_ARGS:
        assert k in ir.args

# Generated at 2022-06-21 01:29:37.672801
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    
    display.verbosity = 0
    
    # define test data

# Generated at 2022-06-21 01:29:45.386921
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    '''
    Unit test for constructor of class IncludeRole
    :return: Nothing
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_source = dict(name="Test Play", hosts=["localhost"])
    my_block = Block(play=play_source)
    my_block.vars['a'] = 'A'
    my_block.vars.update(combine_vars(loader=loader, variable_manager=variable_manager, play=play_source))
    my_role = Role()
   

# Generated at 2022-06-21 01:29:55.014462
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = Role.load({'name': 'test_role', 'tasks': [{}]})
    block = Block.load(None, [], role=role, task_include=None)
    empty_include_role = IncludeRole(block=block, role=role)
    block.block  = [empty_include_role]
    role.compile()
    assert empty_include_role.get_name() == "include_role : "
    test.assert_raises(AnsibleParserError, empty_include_role.copy().copy().copy().copy().copy().copy().copy().copy().copy().copy().copy)

# Generated at 2022-06-21 01:30:03.694022
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Need to test the init method, this can only be done by checking
    # if the instance of the class is created and compare the result
    # with the expected result.
    ir = IncludeRole()
    # Assert if the object is instantiated properly.
    # test name of the class
    assert isinstance(ir, IncludeRole)
    # test name of the object
    assert ir == ir
    # test private attributes
    assert hasattr(ir, '_role_path')
    assert hasattr(ir, '_parent_role')
    assert hasattr(ir, '_role_name')
    assert hasattr(ir, '_allow_duplicates')
    assert hasattr(ir, '_public')
    assert hasattr(ir, '_rolespec_validate')
    assert hasattr(ir, '_from_files')

# Generated at 2022-06-21 01:30:09.663360
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C


# Generated at 2022-06-21 01:30:13.203899
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    block.vars = {'name': 'test_name', 'role': 'test_role'}
    role.vars = {}
    ir = IncludeRole(block, role)
    assert ir.get_name() == 'test_name : test_role'

# Generated at 2022-06-21 01:30:23.508142
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.vars.manager import VariableManager

    constructor_arguments = dict(
        data=dict(
            __ansible_role_name__='some_role_name',
            some_key='some_val',
            _role='the_role_being_included',
        ),
        loader=None,
        variable_manager=VariableManager(),
    )
    include_role = IncludeRole(**constructor_arguments)

    assert include_role._parent._play is None
    assert not isinstance(include_role._parent, Role)
    assert isinstance(include_role, IncludeRole)
   

# Generated at 2022-06-21 01:30:26.177797
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    try:
        my_task = IncludeRole(block=None, role=None, task_include=None)
    except Exception as e:
        assert False, "Failed to create IncludeRole object %s" % e

# Generated at 2022-06-21 01:30:27.031573
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass


# Generated at 2022-06-21 01:31:00.050102
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    display = Display()

    # Test the role is created with no arguments
    role = IncludeRole()
    assert type(role) == IncludeRole

    # test the role is created with arguments
    block = Block()
    role2 = IncludeRole(block)
    assert type(role2) == IncludeRole
    assert role2.block == block

    display.display(role2._valid_attrs)
    display.display(role2.args)

# Generated at 2022-06-21 01:31:04.244391
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.name = 'my-role'
    assert ir.get_name() == 'my-role'
    ir.name = None
    ir._role_name = 'your-role'
    assert ir.get_name() == 'include_role : your-role'

# Generated at 2022-06-21 01:31:05.472016
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass


# Generated at 2022-06-21 01:31:11.582756
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    copy_block = Block()
    copy_block.vars["var1"] = "value1"
    copy_block.vars["var2"] = "value2"
    copy_block.vars["foo"] = "bar"
    copy_block.vars["copy_var"] = "copy_value"
    copy_block.vars["copy_var2"] = "copy_value2"

    copy_task = Task()
    copy_task.vars["var1"] = "value1"
    copy_task.vars["var2"] = "value2"
    copy_task.vars["foo"] = "bar"
    copy_task.vars["copy_var"] = "copy_value"

# Generated at 2022-06-21 01:31:22.942997
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible import utils
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    ''' unit test for ansible.playbook.include.IncludeRole '''

    ########################################################################################
    # constructor: __init__(self, block=None, role=None, task_include=None)
    ########################################################################################
    # ''' AnsibleTaskInclude.task_include_obj'''
    # ''' Block.block_obj'''
    #
    # ''' AnsibleTaskInclude.task_include_obj'''
    # ''' Block.block_obj'''


    ########################################################################################
    # get_name()
    ########################################################################################
    # ''' return the name of the

# Generated at 2022-06-21 01:31:33.668750
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    
    ir = IncludeRole()
    ir.vars = {'key': 'value'}

    all_vars = []
    all_vars.append({'key': 'value1'})
    all_vars.append({'key': 'value2'})
    all_vars.append({'key': 'value3'})
    
    def new_get_vars(play=None, task=None):
        var_list = all_vars.pop()
        var_list.update(ir.vars)
        return var_list

    # Save previous method
    original_get_vars = VariableManager.get_vars

    # Monkey patch
    VariableManager.get_vars = new_get_vars
    ir.get_block_list()

    # Restore original method
    VariableManager.get

# Generated at 2022-06-21 01:31:44.180344
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    class MyBlock:
        pass

    ir = IncludeRole(MyBlock())
    assert isinstance(ir, TaskInclude)
    assert isinstance(ir, Block)
    assert ir._parent == MyBlock()
    assert ir._role is None
    assert ir._task_include is None
    assert ir._role_name is None
    assert ir._role_path is None
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate == True
    assert ir._from_files == {}

    #create parameters for __init__ method of class IncludedRole
    class MyBlock2:
        pass

    class MyRole:
        pass

    class MyIncludedRole:
        pass

    ir = IncludeRole(MyBlock2(), MyRole(), MyIncludedRole())

    assert isinstance

# Generated at 2022-06-21 01:31:52.317225
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    data = {'role': 'test', 'include': 'role'}
    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    src = "include_role"

    ir = IncludeRole.load(data, play=play_context, loader=DataLoader(), variable_manager=inventory.get_vars())
    assert ir.get_name() == src + " : test"

# Generated at 2022-06-21 01:32:03.394427
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    pb = PlaybookExecutor(loader=DataLoader(), variable_manager=VariableManager(), inventory=InventoryManager(loader=DataLoader()), options='{"force": {"deprecate": true}}')
    bl = Block()
    bl._play = pb._play
    bl.collections = []
    r = Role()
    r.collection

# Generated at 2022-06-21 01:32:10.085183
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert type(ir) == IncludeRole
    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir._rolespec_validate == True
    assert ir._from_files == {}
    assert ir._role_name == None
    assert ir._role_path == None


# Generated at 2022-06-21 01:33:42.669403
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.template import Templar


# Generated at 2022-06-21 01:33:52.487959
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from collections import namedtuple
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    RoleOptions = namedtuple('RoleOptions', Base.valid_attrs)
    RoleMetadata = namedtuple('RoleMetadata', RoleDefinition.valid_attrs)

    def fake_meta_load(self, *args, **kwargs):
        return RoleMetadata()

    RoleDefinition._metadata = property(fake_meta_load)


# Generated at 2022-06-21 01:33:57.210007
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # load test data
    loader = DataLoader()
    context = PlayContext(loader=loader, options=dict(connection='local'))
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:34:03.224482
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:34:11.837690
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """Unittest for IncludeRole.get_include_params()"""

    # Try to assert the behavior of a trivial scenario of parent_roles

    # Create a trivial parent_role
    parent_role = Role()
    parent_role.name = "parent_role"
    parent_role.path = "path/to/parent_role"

    role = Role()
    role.name = "role"
    role.path = "path/to/role"
    role._role_path = "path/to/role"
    role._parent_role = parent_role

    # Call method
    v = role.get_include_params()

    # Assertion about the expected value.
    assert v['ansible_parent_role_names'] == ['parent_role']

# Generated at 2022-06-21 01:34:22.320541
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.meta import RoleMeta
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    def test_setup():
        task = Task()
        task._parent = Block()
        task._role = Role()
        task._block = Block()
        task._role._role_path = "/foo/bar"
        task._role._metadata = RoleMeta()
        task._role._metadata.name = "my-role"
        task._role._parent = Role()
        task._role._parent._role_path = "/role"
        task