

# Generated at 2022-06-21 01:24:36.774298
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test_action_1 is a valid include_role directive
    test_action_1 = {
        'asdf': 'fdsa',
        'name': 'do_something',
        'public': 'true',
        'role': 'my_role',
        'rolespec_validate': 'false',
        'allow_duplicates': 'false',
        'apply': {
            'when': 'True'
        },
        'vars_from': 'some_file',
        'tasks_from': 'some_file',
        'handlers_from': 'some_file',
        'defaults_from': 'some_file'
    }
    # test_action_2 is a valid include_tasks directive

# Generated at 2022-06-21 01:24:40.793539
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = "a"
    ir._role_name = "b"
    result = ir.get_name()
    assert result == "b : a", 'Result of get_name method is not what is expected.'

# Test load method

# Generated at 2022-06-21 01:24:53.540349
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    import ansible.vars.manager
    import ansible.vars.loader

    block = Block()
    block.vars = {}
    context = PlayContext()
    context.vars = {}
    ansible.vars.manager.set_vars(context.vars)
    ansible.vars.manager.set_global_vars(context.global_vars)

    role = Role()
    role.vars = {}
    role._role_name = 'ansible'

    ir1 = IncludeRole(block, role)
    ir1.vars = {}
    ir1._parent_role = role
    ir1._from_files = {}
    ir1.action = 'include_role'
    ir1_params = ir1.get_include

# Generated at 2022-06-21 01:25:01.648515
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    def fake_get_vars(play=None, task=None):
        return {
            'a': 1,
            'b': 2,
            'c': 3,
            'd': 4,
            'e': 5,
            'f': 6,
            'g': 7,
            'h': 8,
            'i': 9,
            'j': 10,
        }

    class Fake_ParentRole(object):
        def __init__(self):
            self.vars = {}
            self.name = 'parent'
            self.get_role_params = lambda: {'a': 1, 'b': 2, 'c': 3}
            self._role_path = '/path/to/parent'
            self.statically_loaded = True
            self.actions = {}

# Generated at 2022-06-21 01:25:13.716831
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test setup
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import os
    import shutil
    import tempfile
    cwd = os.getcwd()
    tempdir = tempfile.mkdtemp(dir=cwd)
    os.chdir(tempdir)
    playbook_dir = tempdir

    def cleanup():
        os.chdir(cwd)
        shutil.rmtree(tempdir)

    # test body
    loader = None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_context = PlayContext()

    from ansible.playbook.play import Play

# Generated at 2022-06-21 01:25:23.774135
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.verbosity = 3

    class A(object):
        pass
    a = A()
    # setup variables
    v = dict(a=1, b=2, c=3)
    a.vars = v
    # setup parent role
    a.task = A()
    a.task._parent = A()
    a.task._parent.get_role_params = lambda: dict(ansible_role_names=['role1', 'role2'], ansible_role_paths=['/path1', '/path2'])
    # setup play
    a.task._play = A()
    a.task._play._role_params = {}
    # test
    a.task_include = TaskInclude()
    a.task.action = 'include_role'

# Generated at 2022-06-21 01:25:34.152091
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-21 01:25:37.067707
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    Ir = IncludeRole()
    assert Ir._allow_duplicates is True
    assert Ir._public is False
    assert Ir._rolespec_validate is True


# Generated at 2022-06-21 01:25:47.282175
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.role import Role
    from ansible.template import Templar

    options = dict(
        name='role',
        tasks=dict(
            name='task',
        ),
    )

    role = Role.load(options)
    role._parents = ['test']

    options = dict(
        name='test',
        role='test',
        public=True,
        rolespec_validate=True,
        allow_duplicates=True,
        tasks_from='test',
    )

    loader = mock.MagicMock()
    templar = Templar(loader=loader)
    include_role = IncludeRole.load(options, role=role, role_name='test')

    new_include_role = include_role.copy()

    assert include_role == new_include_role
    assert include

# Generated at 2022-06-21 01:25:56.279039
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole(None, None, None)
    task.name = None
    task.action = "action"
    task._role_name = None
    assert task.get_name() == "action : None"
    task.name = "name"
    task.action = "action"
    task._role_name = None
    assert task.get_name() == "name"
    task.name = None
    task.action = "action"
    task._role_name = "role_name"
    assert task.get_name() == "action : role_name"
    task.name = "name"
    task.action = "action"
    task._role_name = "role_name"
    assert task.get_name() == "name"

# Generated at 2022-06-21 01:26:07.644341
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    a = IncludeRole()
    assert a.action == C._ROLE_INCLUDE_ACTION, "IncludeRole action was %s instead of %s" % (a.action, C._ROLE_INCLUDE_ACTION)
    assert isinstance(a, TaskInclude)
    assert isinstance(a, Block)

# Generated at 2022-06-21 01:26:19.705228
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    task_vars = {
        'ansible_parent_role_names': [],
        'ansible_parent_role_paths': [],
    }

    # get_include_params
    ir = IncludeRole()

    # get_include_params without parent role
    assert ir.get_include_params() == task_vars

    # get_include_params with parent role
    parent_role_names = ['parent1', 'parent2']
    parent_role_paths = ['path/to/parent1', 'path/to/parent2']

    class DummyRole():
        def __init__(self, name, path):
            self.name = name
            self.path = path
        def get_name(self):
            return self.name

# Generated at 2022-06-21 01:26:28.728334
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.warning = mock.Mock()
    display.verbosity = 1
    ir = IncludeRole.load(dict(name='test_role', file='test_file', tasks_from='test_tasks_file'))
    assert ir._role_name == 'test_role'

    try:
        ir = IncludeRole.load(dict(role='test_role', unknown_key='unknown_value'))
        raise Exception('Invalid option of action raises no error')
    except AnsibleParserError as e:
        pass
    # Base case
    ir = IncludeRole.load(dict(name='test_role'))
    assert ir._role_name == 'test_role'
    # Process from parameter
    # Make sure to do the same thing for each kind of from

# Generated at 2022-06-21 01:26:41.064164
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    role = "test_role"
    path = "/path/to/role"

    playbook = dict(
        ansible_version=dict(
            full="test-1.2.3",
        ),
        hosts=dict(),
        roles=[role],
        collections=[],
    )

    # Test valid load
    data = dict(
        name=role,
        allow_duplicates=False,
        apply=dict(
            meta=dict(
                author="me",
            )
        ),
        rolespec_validate=False,
        tasks_from=path,
        vars_from=path,
    )


# Generated at 2022-06-21 01:26:52.501531
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class TestObj(object):
        def __init__(self, *args):
            self.args = args

        def __getattr__(self, name):
            return self.args[0]


# Generated at 2022-06-21 01:27:03.467952
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    role_metadata = dict(
        name='test',
        collection=None,
        file=None,
        platform='all',
        dependencies=[],
        private=False,
    )
    role_data = dict(
        metadata=role_metadata,
        default_vars=dict(test_role_default='default'),
        vars_files=[],
        vars_prompt=dict(),
        handlers=dict(),
        tasks=[],
        files=[],
        tests=[],
    )
    role = Role.load(role_data, None)
    include = dict(
        role='test'
    )
    include_data = dict(
        include='role',
        args=include,
        name=None,
        block=None
    )

# Generated at 2022-06-21 01:27:09.841563
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    def _get_name(name, role):
        class IncludeRoleMock(IncludeRole):
            def __init__(self, name, role):
                self.args = dict()
                if name:
                    self.args['name'] = name
                if role:
                    self.args['role'] = role
        return IncludeRoleMock(name, role).get_name()
    assert _get_name('test', None) == 'include_role : test'
    assert _get_name(None, 'role_name') == 'include_role : role_name'

# Generated at 2022-06-21 01:27:19.377510
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role = Role()
    include_role = IncludeRole(role=role)
    new_me = include_role.copy(exclude_parent=True, exclude_tasks=False)
    new_me._parent_role = include_role._parent_role

    assert(new_me.statically_loaded == include_role.statically_loaded)
    assert(new_me._from_files == include_role._from_files)
    assert(new_me._parent_role == include_role._parent_role)
    assert(new_me._role_name == include_role._role_name)
    assert(new_me._role_path == include_role._role_path)



# Generated at 2022-06-21 01:27:29.730881
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''
    Test IncludeRole.get_include_params.
    '''

    import ansible.playbook.role_include

    ir = IncludeRole()

    # initialize variables
    ir.vars = {'a': 'apple'}

    # initialize _parent_role
    parent_role = Role()
    parent_role.vars = {'b': 'banana'}
    parent_role._metadata = ansible.playbook.role_include.RoleInclude()
    parent_role._metadata.set_name('parent_role')
    parent_role._metadata.set_role_path('/directory/parent_role')    
    ir._parent_role = parent_role

    actual = ir.get_include_params()

# Generated at 2022-06-21 01:27:37.069370
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(block=Block(), role=None, task_include=None)
    ir.name = 'includerole_name'
    ir.action = 'action_name'
    ir._role_name = 'role_name'

    assert 'includerole_name : role_name' == ir.get_name()

    ir.name = None
    assert 'action_name : role_name' == ir.get_name()

    ir.name = ''
    assert 'action_name : role_name' == ir.get_name()


# Generated at 2022-06-21 01:27:59.067700
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Block
    block = Block()

    # Role
    role = Role()

    # TaskInclude
    task_include = TaskInclude()

    # IncludeRole
    ir = IncludeRole(block, role, task_include)
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, TaskInclude)

    return ir

# Generated at 2022-06-21 01:28:06.713105
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = False
    ir._from_files = {'tasks': 'tasks/main.yml', 'handlers': 'handlers/main.yml'}
    ir._parent_role = None
    ir._role_name = "test_role"
    ir._role_path = "/path/test/role/test_role"
    new_me = ir.copy()

    assert new_me.statically_loaded == False
    assert ir._from_files == {'tasks': 'tasks/main.yml', 'handlers': 'handlers/main.yml'}
    assert new_me._parent_role == None
    assert new_me._role_name == "test_role"

# Generated at 2022-06-21 01:28:16.636322
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = 1
    ir._from_files = {'key' : 'value'}
    ir._parent_role = 2
    ir._role_name = 3
    ir._role_path = 4
    ir.tasks = True
    ir.role = True
    ir.block = True
    ir.vars = True
    ir.loops = True
    ir.always_run = True
    ir.any_errors_fatal = True
    ir.post_validate_passed_vars = True
    ir.when = True
    ir.until = True
    ir.delegate_to = True
    ir.first_available_file = True
    ir.include_role = True
    ir.include = True
    ir.rescue = True
    ir.changed

# Generated at 2022-06-21 01:28:26.281684
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = {
        'name': 'test',
        'options': {
            'apply': {},
            'tags': [],
            'when': [],
            'block': [],
            'handlers': [],
            'vars': [],
            'include_tasks': [],
            'pre_tasks': [],
            'post_tasks': [],
        },
        '_original_block': [],
        '_role': None,
        '_parent': None,
        '_role_params': {},
    }
    include_role = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert include_role.name == 'test'
    assert include_role._role_name == 'test'
   

# Generated at 2022-06-21 01:28:35.818600
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    def set_role(ir, role):
        ir._parent_role = role
        ir._parent = role
        ir._role_path = role._role_path
        ir._role_name = role._role_name
    task = IncludeRole()
    role_1 = Role()
    role_1._metadata.name = 'test_role_1'
    role_1._role_path = './test_role_1'
    role_2 = Role()
    role_2._metadata.name = 'test_role_2'
    role_2._role_path = './test_role_2'
    set_role(task, role_1)

# Generated at 2022-06-21 01:28:40.610341
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task_include = IncludeRole()
    task_include._role_name = "apache"
    task_include.action = "include_role"
    assert task_include.get_name() == "include_role : apache"


# Generated at 2022-06-21 01:28:53.900585
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Arrange
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    data = '''
---
- hosts: localhost
  tasks:
    - include_role:
        name: test
        tasks_from: main.yml
'''
    play_source = dict(
        name="IncludeRole.test_get_block_list",
        hosts='localhost',
        gather_facts='no',
        tasks=[
        ],
    )

# Generated at 2022-06-21 01:29:02.665032
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_block = Block()
    test_role = Role()
    test_task_include = TaskInclude()
    task = IncludeRole(block=test_block, role=test_role, task_include=test_task_include)
    assert task.get_name() == ": "
    test_block.name = "TESTTASK"
    task.action = "- include_role"
    assert task.get_name() == "TESTTASK : "
    task._role_name = "TEST_ROLE"
    assert task.get_name() == "TESTTASK : TEST_ROLE"

# Generated at 2022-06-21 01:29:09.901201
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    i = IncludeRole()
    i._role_name = "test"
    i._from_files = {}
    i._parent_role = None
    try:
        i.get_block_list()
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError not raised"


# Generated at 2022-06-21 01:29:16.239937
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.role import Role
    from ansible.playbook.base import Base
    from ansible.parsing.yaml.loader import AnsibleLoader
    import json
    import yaml
    import os
    b = Base()
    yaml_data = """
- hosts: all
  roles:
    - role: stuff
      name: role1
      public: true
      rolespec_validate: False
      tasks_from: roles/tasks/main.yml
      vars_from: roles/vars/main.yml
      defaults_from: roles/defaults/main.yml
      handlers_from: roles/handlers/main.yml
      apply:
        tags:
          - foo
      allow_duplicates: no
"""

# Generated at 2022-06-21 01:29:46.004154
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from copy import deepcopy

    my_loader = DataLoader()
    my_loader.set_basedir(context.CLIARGS['basedir'])

    # Playbook with single role
    simple_playbook = Play()
    host = "localhost"
    simple_playbook.hosts = [host]
    simple_playbook.connection = 'local'

    simple

# Generated at 2022-06-21 01:29:57.710610
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    class ParentRole:
        def __init__(self):
            self._role_params = {'role_name': 'name', 'role_path': 'path'}
            self.name = 'name'
        def get_role_params(self):
            return self._role_params
        def get_name(self):
            return self.name

    block = Block()
    role = ParentRole()
    ir = IncludeRole(block, role)
    assert ir.get_include_params() == {
        'role_name': 'name',
        'role_path': 'path',
        'ansible_parent_role_names': ['name'],
        'ansible_parent_role_paths': ['path']
    }

# Generated at 2022-06-21 01:30:05.013798
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 01:30:09.323250
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    o = IncludeRole()
    assert o.get_name() == 'tasks: tasks'

    o = IncludeRole(role=Role())
    assert o.get_name() == 'tasks: tasks'

    o = IncludeRole(role=Role(name='Ansible'))
    assert o.get_name() == 'tasks: Ansible'

    o = IncludeRole(role=Role(name='Ansible'), name='ansible')
    assert o.get_name() == 'include_role: ansible'


# Generated at 2022-06-21 01:30:11.681884
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(None, None)
    ir.args = {'name': 'test_role'}
    expect = 'test_role'
    assert ir.get_name() == expect

# Generated at 2022-06-21 01:30:22.081649
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.file_include import FileInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:30:23.460265
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole('block', 'role') is not None

# Generated at 2022-06-21 01:30:26.991313
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole(block=Block(), role=Role())
    ir.statically_loaded = False
    assert ir.load(dict(name=dict(key1='value'), allow_duplicates=True, apply=dict(key2='value', key3='value')), role=Role()) == ir

# Generated at 2022-06-21 01:30:28.596965
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(block=None, role=None, task_include=None).get_name() == "include_role : "

# Generated at 2022-06-21 01:30:36.097469
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    block = Block(play=None, parent_block=None)
    role = Role()
    task_include = TaskInclude()
    role_include = RoleInclude()
    task = Task()

    include_role = IncludeRole()
    include_role.statically_loaded = True
    include_role._from_files = {'tasks': 'main.yml'}
    include_role._parent_role = role
    include_role._role_name = 'as_role'

# Generated at 2022-06-21 01:31:33.842672
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.config.manager import ensure_type
    from ansible.module_utils.six import string_types

    raw_data = dict(
        name='test_role',
        role='test_role_path',
        public=True,
        vars={'test_vars': 'test_value'},
        tasks_from='test_tasks_path',
    )
    # Initiate IncludeRole object
    include_role_object = IncludeRole.load(raw_data, task_include=TaskInclude())
    # Create copy of IncludeRole object
    copy_include_role_object = include_role_object.copy()
    # Check if copy_include_role_object has the same content as include_role_object
    assert copy_include_role_object.statically_loaded == include_role_object.statically_

# Generated at 2022-06-21 01:31:44.233784
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.allow_duplicates = True
    ir.public = True
    ir.rolespec_validate = True
    ir.name = 'my_role'
    ir.statically_loaded = True
    ir._from_files = {'tasks':'main.yml'}
    assert ir.name == 'my_role'
    assert ir.allow_duplicates is True
    assert ir.public is True
    assert ir.rolespec_validate is True
    assert ir.statically_loaded is True
    assert ir._from_files == {'tasks': 'main.yml'}
    ir_copy = ir.copy()
    assert isinstance(ir_copy, IncludeRole)
    assert ir_copy.name == 'my_role'
    assert ir_copy.allow

# Generated at 2022-06-21 01:31:54.931147
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    parent_role = Role.load(dict(name='parent-role'), play=None, variable_manager=None, loader=None)
    ir = IncludeRole.load(dict(name='child-role'), block=None, role=parent_role, task_include=None,
                          variable_manager=None, loader=None)
    ir.vars = dict(key1='value1')
    ir._from_files = dict(key1='value1')
    ir.statically_loaded = True
    ir._role_name = 'child-role'
    ir._role_path = 'child-role-path'
    ir.apply = dict(key1='value1')
    ir.allow_duplicates = False
    ir.public = True
    ir.rolespec_validate = False

    new_ir = ir.copy

# Generated at 2022-06-21 01:32:03.318462
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class FakeRole:
        def __init__(self):
            self._role_params = dict()

        def get_role_params(self):
            return self._role_params

        def get_name(self):
            return 'Parent_Role'

        @property
        def _role_path(self):
            return 'Parent_Path'

    role = FakeRole()
    role._role_params = {'k_0': 'v_0'}
    include_role = IncludeRole(role=role)
    assert include_role.get_include_params() == {'ansible_parent_role_names': ['Parent_Role'], 'ansible_parent_role_paths': ['Parent_Path'], 'k_0': 'v_0'}, "get_include_params of IncludeRole didn't work properly"

# Generated at 2022-06-21 01:32:14.676390
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ''' test_IncludeRole_copy

        Test that IncludeRole.copy() returns the same object
    '''
    # Arrange
    my_ir = IncludeRole()
    my_ir.name = 'my include'
    my_ir._role_name = 'my role'
    my_ir._from_files = {'tasks': 'tasks/main.yml'}
    my_ir._allow_duplicates = False
    my_ir._public = True
    my_ir.action = 'include_role'
    my_ir.statically_loaded = True
    my_ir.rolespec_validate = False


    # Act
    other_ir = my_ir.copy()

    # Assert
    assert my_ir.name == other_ir.name
    assert my_ir._role_name

# Generated at 2022-06-21 01:32:22.457070
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    i=IncludeRole()
    # configure object
    i.statically_loaded=True
    i._from_files={'han':'han.yml'}
    i._parent_role='King of Corellia'
    i._role_name='Solo'
    i._role_path='/path/to/solo.yml'
    # test copy
    new_me=i.copy()
    assert i.statically_loaded==new_me.statically_loaded
    assert i._from_files==new_me._from_files
    assert i._parent_role==new_me._parent_role
    assert i._role_name==new_me._role_name
    assert i._role_path==new_me._role_path
    # test copy with exclude_parent
    new_me=i.copy

# Generated at 2022-06-21 01:32:32.644021
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    Creates a simple role, include role and make sure it's
    detected statically loaded.
    """

    class MockTask:
        pass

    _task_vars = dict(
        ansible_version='2.9.9',
        ansible_python_interpreter='/usr/bin/python',
    )
    _task_args = dict(
        apply=dict(
            ignore_errors=True,
        ),
        name="mock-role",
    )
    _mock_task = MockTask()
    _mock_task.vars = _task_vars
    _mock_task.args = _task_args
    _mock_task.statically_loaded = True

    _mock_block = Block([_mock_task])
    _mock_block.parent_role

# Generated at 2022-06-21 01:32:40.411200
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    v = {'hostvars': dict(), 'omit': dict(), 'vars': dict(), 'run_once': [], 'role_names': [], 'rolenames': [], 'role_debug': False,
                'role_paths': [], 'name': 'test_include_role', 'tasks_from': 'a', 'vars_from': 'b', 'defaults_from': 'c',
                'handlers_from': 'd', 'apply': dict(), 'rolespec_validate': True, 'allow_duplicates': True, 'public': False, 'tags': list(),
                'when': list(), 'add_role': True, 'include_role': True, 'include_tasks': True, 'include_vars': True,
                'include_defaults': True, 'include_handlers': True}



# Generated at 2022-06-21 01:32:42.096083
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass


# Generated at 2022-06-21 01:32:53.527403
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    from ansible.compat.tests import unittest

    from ansible.playbook.play import Play

    from ansible.playbook.block import Block

    from ansible.playbook.task import Task

    from ansible.vars.manager import VariableManager

    from ansible.errors import AnsibleParserError

    from ansible.template import Templar

    from ansible.parsing.mod_args import ModuleArgsParser

    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import add_all_plugin_dirs

    from ansible.module_utils._text import to_bytes

    add_all_plugin_dirs()
