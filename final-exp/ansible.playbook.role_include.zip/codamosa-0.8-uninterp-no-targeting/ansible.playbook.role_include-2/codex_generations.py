

# Generated at 2022-06-21 01:24:39.206833
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test for list of strings, list of dicts and a dict
    test_data1 = dict(name="test1",tasks_from="test2/tasks/main.yml",apply=dict(print_args=True))
    test_data2 = dict(name="test2",public=True,apply={"print_args":True},tasks_from="test1/tasks/main.yml")
    test_data3 = dict(name="test3",public=True,apply={"print_args":True},tasks_from="test1/tasks/main.yml")

    incr = IncludeRole.load(data=test_data1)
    assert(incr._role_name == "test1")
    assert(incr._from_files["tasks"] == "main.yml")

# Generated at 2022-06-21 01:24:48.990229
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.display("test IncludeRole class")
    test_role_path = "test/test_role"
    test_role_name = "test_role"
    role = Role(name=test_role_name, path=test_role_path)
    block = Block(role=role)
    ir = IncludeRole(block=block, role=role)
    assert ir.get_include_params()['ansible_parent_role_paths'] == [test_role_path]
    assert ir.get_include_params()['ansible_parent_role_names'] == [test_role_name]

# Generated at 2022-06-21 01:24:57.793994
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Testing for the initialization of class IncludeRole and its parameters
    obj = IncludeRole(name='my_role', public=True, apply=dict(roles='my_role'))
    assert obj.name == 'my_role'
    assert obj.action == 'include_role'
    assert obj.statically_loaded
    assert obj.public
    assert obj.allow_duplicates
    assert obj.rolespec_validate
    assert obj._role_name == 'my_role'
    assert obj._from_files == {}
    assert obj._parent_role is None
    assert obj._role_path is None



# Generated at 2022-06-21 01:25:09.975064
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-21 01:25:21.339523
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    block = Block()
    role = Role()
    role._role_params = {'role1': 'role1name'}

    inventory = Inventory(loader=None, variable_manager=VariableManager(),
                          host_list=['localhost'])
    variable_manager = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-21 01:25:32.444685
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.template import Templar


# Generated at 2022-06-21 01:25:37.568410
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    task_block = Block()
    parent_role = Role()
    task_include = TaskInclude()
    _include_role = IncludeRole(task_block, parent_role, task_include)
    assert _include_role.task_include == task_include
    assert _include_role._parent == task_block

# Generated at 2022-06-21 01:25:47.580735
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role = Role()
    role._role_path = "role_path_1"
    role_params = {'name' : 'role_name_1', 'role' : 'role_attr_1'}
    role.get_role_params = lambda: role_params
    include_role = IncludeRole(block=block, role=role)
    include_role._parent_role = Role()
    include_role._parent_role._role_path = "role_path_0"
    include_role._parent_role.get_role_params = lambda: {'name' : 'role_name_0', 'role' : 'role_attr_0'}

    result_params = include_role.get_include_params()
    assert result_params['name'] == 'role_name_1'

# Generated at 2022-06-21 01:25:56.277708
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Setup test
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    blocks, handlers = ir.get_block_list()

    assert isinstance(blocks, list)
    assert len(blocks) == 0
    assert isinstance(handlers, list)
    assert len(handlers) == 0

    # test with a valid role
    ir._role_name = "test"
    blocks, handlers = ir.get_block_list()
    assert isinstance(blocks, list)
    assert len(blocks) > 0
    assert isinstance(handlers, list)
    assert len(handlers) > 0

# Generated at 2022-06-21 01:26:06.448680
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # import pdb; pdb.set_trace()
    root_block = Block()
    root_block.parent_role=None
    root_block.module_utils_path='./module_utils'
    root_block.role_path=''

    include_block = Block(parent_block=root_block)
    include_block.action='include_role'
    include_block.module_utils_path='./module_utils'
    include_block.role_path='./roles/'

    include_role = IncludeRole(block=include_block)
    include_role._rolespec_validate=False
    include_role._parent_role=root_block
    include_role._role_name='test_role'
    include_role._role_path='./roles/test_role'



# Generated at 2022-06-21 01:26:23.768391
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # code of test
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadatarole import RoleMetadata
    from ansible.playbook.block import Block
    data = {
        'name': "test_role",
        'task_list': Block(),
        'role_name': 'test_role',
        'metadata': RoleMetadata(),
        'definition': RoleDefinition(),
        'collections': []
    }
    block = Block()
    role = Role()
    test_obj = IncludeRole(block=block, role=role)
    result = test_obj.load(data)
    assert isinstance(result, IncludeRole)
    assert result._role_name == 'test_role'

# Generated at 2022-06-21 01:26:25.750364
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole(role='test-role')
    assert include_role.get_name() == 'include_role : test-role'

# Generated at 2022-06-21 01:26:38.594196
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.verbosity = 3
    data = {
        'action': 'include_role',
        'task': [{'__ansible_module__': 'include_role', '__ansible_arguments__': [{'name': 'TestRole', 'public': False, 'allow_duplicates': False, 'rolespec_validate': True}], '__ansible_modulename__': 'include_role'}],
        '__ansible_verbosity': 0,
        '__ansible_no_log': False,
        '__ansible_internal_modulename': 'include_role',
        '__ansible_version__': '2.0',
        '__ansible_internal_action': 'include_role',
        '__ansible_internal_disable_action_plugin_lookup': False
    }


# Generated at 2022-06-21 01:26:41.524564
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    task_include = TaskInclude()
    task_include.name = "include_tasks"

    block = Block()
    block.role = "include"

    role = Role()
    role.name = "role_name"
    role.get_name = lambda: "rolename"

    ir = IncludeRole(block, role, task_include)

    assert ir.get_name() == "include_role : rolename"

# Generated at 2022-06-21 01:26:53.483123
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    loader = None
    variable_manager = None

    # Given a variable_manager and a loader
    # When I create an instance of IncludeRole and I set up a role name and a role
    ir = IncludeRole(block=block)
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'

    # And I set the _parent_role attributes to a Role object
    ir._parent_role = Role()

    # And I set up a role_include attribute
    role_include = RoleInclude()

    # And I call the load method with a play, a variable_manager and a loader
    role_include.load(ir._role_name, play=None, variable_manager=variable_manager, loader=loader)

    # When I set the vars attribute with a dictionary
   

# Generated at 2022-06-21 01:27:04.215690
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ROLE_NAME = "test_role"
    ROLE_NAME_2 = "test_role2"
    ROLE_ARGS = dict(name=ROLE_NAME)
    ROLE_ARGS_2 = dict(name=ROLE_NAME_2)
    loader = DictDataLoader({
        ROLE_NAME: dict(
            meta=dict(
                dependencies=dict(
                    role=[]
                )
            )
        ),
        ROLE_NAME_2: dict(
            meta=dict(
                dependencies=dict(
                    role=[ROLE_NAME]
                )
            )
        )
    })

    my_ir = IncludeRole.load(
        dict(
            include_role=ROLE_ARGS
        ),
        loader=loader
    )
    my_ir_2 = IncludeRole

# Generated at 2022-06-21 01:27:09.892446
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Constructing class without any params
    ir = IncludeRole()
    assert ir._parent is None
    assert ir._action == 'include_role'
    assert ir._role_name is None
    assert ir._role_path is None

    role = Role()
    ir = IncludeRole(role)
    assert ir._parent is None
    assert ir._action == 'include_role'
    assert ir._parent_role == role
    assert ir._role_name is None
    assert ir._role_path is None


# Generated at 2022-06-21 01:27:20.620522
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    include_block = IncludeRole()
    include_block._parent = Block()
    include_block._parent._play = None
    include_block._parent._role = None
    include_block._role_name = "test_role"
    include_block.statically_loaded = True
    include_block._from_files = {"tasks":"test_task_file.yml"}
    include_block._role_path = "/test/test_file.yml"
    include_block._parent_role = Role()
    include_block._parent_role._role_path = "/test/test_file.yml"

    new_include_block = include_block.copy(False, True)
    print(new_include_block)
    assert new_include_block._from_files == include_block._from_files
    assert new_

# Generated at 2022-06-21 01:27:30.674983
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    data = dict(
        name="test.yml",
        apply=dict(
            block="main",
            tasks_from="tasks/main.yml"
        ),
        from_tasks="tasks/main.yml",
        from_vars="vars/main.yml",
        from_defaults="defaults/main.yml",
        from_handlers="handlers/main.yml",
        allow_duplicates=False
    )

    block = Block()
    block.args = data

    role = Role()

# Generated at 2022-06-21 01:27:42.171190
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import json

    # create the dummy play
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(host_list=['localhost']))

# Generated at 2022-06-21 01:28:04.670941
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    ir = IncludeRole()
    ir.action = "Foo"
    ir._role_name = "Bar"

    assert ir.get_name() == "Foo : Bar"

    ti = TaskInclude()
    ti.action = "Include"
    ti._role_name = "the Role"

    assert ti.get_name() == "Include : the Role"

    t = Task()
    t.action = "Use"
    t.args = { "name": "the Task" }


# Generated at 2022-06-21 01:28:10.052759
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import fragment_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager

    def _get_templar(loader, play_context):
        def _get_available_variables(loader=loader):
            # setup fake var manager, loader and templar
            fake_vars = {}
            fake_play = FakePlayContext()
            fake_variable_manager = VariableManager()
            fake_inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-21 01:28:17.473011
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    task_include = TaskInclude()
    task_include.name = "task include"
    task_include.args = {'name': 'my_role', 'role': 'my_role'}

    role = Role()
    role.name = "some_role_name"

    include_role = IncludeRole(block=block, role=role, task_include=task_include)

    include_role.action = '- include_role'
    assert include_role.get_name() == '- include_role : my_role'

    del include_role.name
    assert include_role.get_name() == '- include_role : my_role'



# Generated at 2022-06-21 01:28:26.855835
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    IncludeRole: load
    """
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, connection_loader, lookup_loader
    from ansible.errors import AnsibleParserError
    import os

    PATH = os.path.dirname(os.path.realpath(__file__))
    # for test_data_role_spec_validate_attribute.yml

# Generated at 2022-06-21 01:28:35.895364
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir._parent = Block()
    ir._parent._parent = Block()
    ir._parent._parent._parent = Block()
    ir._parent._parent._parent._parent = Block()
    ir._parent._role = Role()
    ir._parent._role.name = 'role A'
    ir._parent._role._role_path = '/path/to/role'
    ir._parent._role._metadata = {}
    ir._parent._role._metadata['allow_duplicates'] = True

    new_ir = ir.copy()
    assert new_ir._parent.name == 'role A'
    assert new_ir._parent._parent.name == 'role A'
    assert new_ir._parent._parent._parent.name == 'role A'
    assert new_ir._parent._parent._parent._parent.name

# Generated at 2022-06-21 01:28:38.041032
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Implement tests within module
    test_nested_role_params()


# Generated at 2022-06-21 01:28:47.607179
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block

    parent_playbook = Playbook.load('.', 'test_playbook.yml', variable_manager=VariableManager(), loader=DataLoader())

    display.verbosity = 3

# Generated at 2022-06-21 01:28:54.337634
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    v = IncludeRole.get_include_params(self)
    assert v.get('ansible_role_name') == self._role_name
    assert v.get('ansible_role_path') == self._role_path
    assert v.get('ansible_role_params') == self.vars
    assert v.get('ansible_role_collections') == self.collections
    assert v.get('ansible_parent_role_names') == []
    assert v.get('ansible_parent_role_paths') == []

# Generated at 2022-06-21 01:29:04.329552
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    import copy

    yaml_data = dict(
        name='test_include',
        clam=dict(
            apple='pie'
            ),
        apply=[],
        vars_from='vars.yml',
        defaults_from='defaults.yml',
        no_log=True,
        when=dict(
            a="b"
            ),
        tags=['foo', 'bar'],
        register='something',
        environment=dict(
            oink='moo'
            ),
        ignore_errors=True
        )

    ir = IncludeRole().load_data(yaml_data)

    assert ir.name == 'test_include'
    assert ir.apply == []
    assert ir._from_files['vars'] == 'vars.yml'

# Generated at 2022-06-21 01:29:05.171041
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:29:42.022871
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.block import Block

    block = Block()
    ir = IncludeRole(block, role_name="name", task_include='task_include')
    ir._from_dict = 'from_dict'
    ir.statically_loaded = 'statically_loaded'
    ir._parent_role = 'parent_role'
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'
    ir.tags = ['t1', 't2']
    ir.always_run = ['t3', 't4']
    ir.run_once = ['t5', 't6']
    ir.when = 'when'

    new_ir = ir.copy()
    assert ir._block == new_ir._block
    assert ir.task_include == new_ir.task_

# Generated at 2022-06-21 01:29:52.702313
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = True
    ir._from_files = {'tasks':'foo.yml'}
    ir._parent_role = 'parent_role'
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'
    new_ir = ir.copy()
    assert new_ir.statically_loaded == True
    assert new_ir._from_files == {'tasks':'foo.yml'}
    assert new_ir._parent_role == 'parent_role'
    assert new_ir._role_name == 'role_name'
    assert new_ir._role_path == 'role_path'

# Generated at 2022-06-21 01:30:02.314446
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.vars.manager

    # create a playbook, a role and a task
    play = ansible.playbook.play.Play.load(
        dict(
            name = "test_play",
            hosts = "localhost",
            roles = [ "role" ],
        )
    )
    block = ansible.playbook.block.Block.load(
        dict(
            name = "test_block",
            tasks = [ dict(
                name = "test_task",
                action = dict(
                    module = "test0",
                ),
            ) ],
        ),
        play = play,
    )
    role = ansible.playbook

# Generated at 2022-06-21 01:30:12.861215
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.deprecated("The IncludeRole_load test is deprecated and will be removed"
                       " in version 2.12. Use AWX tests instead.")
    import doctest
    from ansible.playbook.role.include import IncludeRole
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text

    display = Display()
    results = doctest.testmod(IncludeRole)
    display.display(to_text(results), color='blue')

    if results.failed == 0:
        display.display("Success on IncludeRole.load test!", color='green')
    else:
        display.display("%s failures on IncludeRole.load test!" % results.failed, color='red')

# Generated at 2022-06-21 01:30:17.305030
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(name='my_role', tasks_from='fake_tasks')
    ir = IncludeRole(Block())
    ir.load(data, loader=None, variable_manager=None)
    assert ir._from_files['tasks'] == 'fake_tasks'
    assert ir._role_name == 'my_role'


# Generated at 2022-06-21 01:30:25.764041
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block_obj = Block()
    role_obj = Role()
    task_obj = TaskInclude()
    obj = IncludeRole(block_obj, role_obj)
    assert obj.get_name() is None
    obj1 = IncludeRole(block_obj, role_obj, task_obj)
    assert obj1.get_name() is None
    obj1.set_loader(None)
    obj1.name = "my test"
    assert obj1.get_name() == "my test"
    obj1.name = None
    obj1.action = "include"
    obj1._role_name = "myrole"
    assert obj1.get_name() == "include : myrole"


# Generated at 2022-06-21 01:30:33.637782
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    def assert_equal(val1, val2):
        assert val1 == val2

    test_str = '---\n- include_role:\n    name: include_role.tasks\n'
    ir = IncludeRole.load(data=yaml.safe_load(test_str), loader=DictDataLoader())
    new_me = ir.copy()

    assert_equal(ir.statically_loaded, new_me.statically_loaded)
    assert_equal(ir._from_files, new_me._from_files)
    assert_equal(ir._parent_role, new_me._parent_role)
    assert_equal(ir._role_name, new_me._role_name)
    assert_equal(ir._role_path, new_me._role_path)

# Generated at 2022-06-21 01:30:43.835479
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    IncludeRole: Test the method get_include_params of class IncludeRole.
    """
    # setup
    block = Block('block', loader=None, play=None, variable_manager=None, parent_block=None, role=None)

    role = object()
    task_include = object()

    include_role = IncludeRole(block=block, role=role, task_include=task_include)

    # Make sure that the default values were assigned
    assert (include_role._from_files == {})
    assert (include_role._parent_role == role)
    assert (include_role._role_name == None)
    assert (include_role._role_path == None)

    # test
    include_params = include_role.get_include_params()

    # verify results

# Generated at 2022-06-21 01:30:52.590784
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    play = Play()
    role = Role._load(dict(name="test-role"), play=play, variable_manager=None, loader=None, collection_list=None)
    role._role_path = "role/path"
    ir = IncludeRole(role=role)
    assert ir.get_include_params() == {'ansible_parent_role_names': ['test-role'], 'ansible_parent_role_paths': ['role/path']}

# Generated at 2022-06-21 01:30:59.608850
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    TaskIncludeObj = TaskInclude(block=None, role=None, task_include=None)

    # Manually injecting values for variables used in method get_name of class IncludeRole
    TaskIncludeObj.action = "Include Role"
    TaskIncludeObj._role_name = "name_of_the_role"
    assert TaskIncludeObj.get_name() == "Include Role : name_of_the_role"

    TaskIncludeObj.action = "Include Role"
    TaskIncludeObj._role_name = None
    assert TaskIncludeObj.get_name() == None



# Generated at 2022-06-21 01:31:57.107978
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(role=None, task_include=None)
    ir._role_name = "test_role"
    assert ir.get_name() == "include_role: test_role"



# Generated at 2022-06-21 01:32:04.571781
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role.load(RoleInclude())
    task_include = TaskInclude()

    include_role = IncludeRole(block, role, task_include)

    # Test Case: Name is none and role is none
    include_role.name = None
    include_role._role_name = None
    assert include_role.get_name() == 'include_role : UNDEFINED'
    include_role.name = None
    include_role._role_name = 'role_name'
    assert include_role.get_name() == 'include_role : role_name'
    include_role.name = 'name'
    include_role._role_name = None
    assert include_role.get_name() == 'include_role : UNDEFINED'
    include_role.name = 'name'

# Generated at 2022-06-21 01:32:15.251529
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = combine_vars(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-21 01:32:22.906476
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    ir = IncludeRole()

    # Base class copy
    ir_copy = ir.copy(False, False)
    assert isinstance(ir_copy, Block)
    assert ir_copy == ir

    # New instance of IncludeRole
    ir_copy2 = ir.copy(False, False)
    assert isinstance(ir_copy2, IncludeRole)
    assert ir_copy2 == ir

    # Excluding parent
    ir_copy3 = ir.copy(True, True)
    assert ir_copy3._parent is None
    assert ir_copy3._tasks == []

    # Excluding tasks
    ir_copy4 = ir.copy(False, True)
    assert ir_copy4._tasks == []

    # Include_role custom parameters
    ir.statically_loaded = True
    ir._role_name = 'foo'


# Generated at 2022-06-21 01:32:32.842868
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
  from ansible.playbook.play_context import PlayContext
  from ansible.template import Templar
  from ansible.vars.manager import VariableManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.block import Block
  from ansible.playbook.role import Role
  from ansible.playbook.task import Task
  from ansible.playbook.play import Play
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.plugins.callback import CallbackBase
  import json
  import sys


# Generated at 2022-06-21 01:32:42.347236
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Set up a fake Block object
    block = Block()
    block._play = None
    block._role = None

    # Create a mock IncludeRole object
    include_role = IncludeRole(block)

    # Set the name, action and rolename attributes
    include_role.name = "My custom name"
    include_role.action = "My action"
    include_role._role_name = "my_rolespec"

    # Ensure we get the name we expect
    assert include_role.get_name() == "My custom name"

    # Clear the name and ensure we get a generated name
    include_role.name = None
    assert include_role.get_name() == "My action : my_rolespec"

# Generated at 2022-06-21 01:32:53.630394
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    test_play = dict(
        name = 'test_play', 
    )
    test_include = dict(
        name = 'test_include',
        role = 'test_role',
        vars = dict(
            var1 = 'var1_value',
        ),
    )
    test_parent_role = dict(
        name = 'test_parent_role',
        vars = dict(
            var2 = 'var2_value',
        ),
        defaults = dict(
            default1 = 'default1_value',
        ),
    )
    # Instantiate include and parent role
    include = IncludeRole(task_include=test_include).load_data(test_include, variable_manager=None, loader=None)

# Generated at 2022-06-21 01:33:04.973648
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    pb = Playbook.load(C.DATA_PATH + '/playbook/playbook_syntax.yml', variable_manager=None, loader=None)
    play = pb.get_plays()[0]
    host = play.get_dependency_tree().get_host('localhost')
    play.set_variable_manager(play._variable_manager)
    play.set_loader(play._loader)
    block = host.get_blocks()[0]
    context = PlayContext()
    context.become = block.vars.get('ansible_become', False)
    context.become_method = block.vars.get('ansible_become_method', 'sudo')
    context.bec

# Generated at 2022-06-21 01:33:14.533201
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    loader = None
    templar = None

    ds = {
        'block': None,
        'role': 'test_role',
        'tasks_from': 'subdir1/subdir2/tasks.yml',
        'vars_from': 'subdir1/subdir2/vars.yml',
        'defaults_from': 'subdir1/subdir2/defaults.yml',
        'handlers_from': 'subdir1/subdir2/handlers.yml',
        'apply': {'a': '1'},
        'public': False,
        'allow_duplicates': True,
        'rolespec_validate': True
    }
    # Test 1: Invalid action

# Generated at 2022-06-21 01:33:24.491933
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    display.verbosity = 3

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            roles = [
                dict(role='test1'),
                dict(role='test2')
            ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
