

# Generated at 2022-06-21 01:24:36.348734
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print("Test get_name")
    # Create an IncludeRole object
    ir = IncludeRole(block=None, role=None, task_include=None)
    ir._parent = Block()
    ir._role_name = None
    ir.action = 'include_role'
    print("Object:\n%s" % ir)
    # Execute the get_name method and verify
    name = ir.get_name()

# Generated at 2022-06-21 01:24:39.319742
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    result = IncludeRole.load({'role': 'role_name'}, block='block')
    assert result.get_name() == 'include_role : role_name'


# Generated at 2022-06-21 01:24:48.647800
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    IncludeRole: Testing method get_name

    Returns:
        string: name of the task

    pre-conditions:
        None

    post-conditions:
        IncludeRole.action = 'include_role'

    """
    my_block = Block()
    my_role = Role()
    my_object = IncludeRole(block=my_block, role=my_role)
    my_object.action = 'include_role'
    my_object._role_name = 'name'

    assert my_object.get_name() == 'include_role : name'

# Generated at 2022-06-21 01:24:57.195241
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_i = TaskInclude()
    ir = IncludeRole(block, role, task_include=task_i)

    ir._role_name = None
    assert ir.get_name() == "include_role : None", "Name has been correctly parsed"

    ir._role_name = 'test-role'
    assert ir.get_name() == "include_role : test-role", "Name has been correctly parsed"

    task_i.name = 'test-task'
    assert ir.get_name() == "test-task", "Name has been correctly parsed"

# Generated at 2022-06-21 01:25:08.959068
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Test that you can create an IncludeRole instance with just a role passed in
    def test_construct_with_role():
        role = Role()
        ir = IncludeRole(role=role)
        assert ir._parent_role == role
        assert ir._role_name == "Role_1"
        assert ir._role_path == "Role_1"
        assert not ir.statically_loaded
        assert ir._from_files == {}

    test_construct_with_role()

    # Test that you can create an IncludeRole instance with just a role passed in
    def test_construct_with_block_and_role():
        role = Role()
        block = Block()
        block._role = role
        ir = IncludeRole(block=block)
        assert ir._parent_role == role

# Generated at 2022-06-21 01:25:13.546844
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Construct class with defaults
    role = IncludeRole(None)

    # Ensure defaults were set
    assert role.action == 'include_role'
    assert role.name is None
    assert role.allow_duplicates is True
    assert role.block is None
    assert role.loop is None
    assert role.loop_control is None
    assert role.when is None
    assert role.register is None
    assert role.any_errors_fatal is False
    assert role.always_run is False
    assert role.delegate_to is None
    assert role.delegate_facts is None
    assert role.become is False
    assert role.become_user is None
    assert role.become_method is None
    assert role.tags is None
    assert role.run_once is False

# Generated at 2022-06-21 01:25:14.177377
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-21 01:25:24.041803
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader, action_loader
    from ansible.plugins.loader import module_loader, filter_loader
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    from ansible.playbook.play import Play

    dataloader = DataLoader()
    variable_manager = VariableManager()

    def fake_init_loader_module(module_name):
        if module_name == 'action':
            return action_loader
        if module_name == 'module':
            return module_loader
        if module_name == 'filter':
            return filter_loader
        if module_name == 'callback':
            return callback_loader


# Generated at 2022-06-21 01:25:29.489094
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(role='/Users/bobby/ansible/roles/foo')
    result = IncludeRole.load(data, role=None, task_include=None)
    assert result._task_include == None
    assert result._role_name == '/Users/bobby/ansible/roles/foo'
    assert result._role == None

# Generated at 2022-06-21 01:25:30.131443
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
	pass

# Generated at 2022-06-21 01:25:46.522574
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    def assert_select_attribs(self, expected_attribs, actual_attribs):
        for attrib_name, attrib_value in actual_attribs.items():
            if attrib_name in expected_attribs:
                assert attrib_value == expected_attribs[attrib_name]

    # test constructor without block argument
    ir = IncludeRole()

    # test constructor with Block object argument
    b = Block()
    ir = IncludeRole(block=b)

    # test constructor with block attribute
    ir = IncludeRole(block=b)

    # test get_name()
    ir = IncludeRole(role=Role())
    assert ir.get_name() == 'include_role : None'

    # test load()
    ti = TaskInclude()
    ti.action = 'include_role'

# Generated at 2022-06-21 01:25:47.296613
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:25:47.732570
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole()

# Generated at 2022-06-21 01:25:53.761532
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir.name = "file"
    assert ir.get_name() == "file"
    ir.name = None
    ir._role_name = "role"
    assert ir.get_name() == "include_role : role"

# Generated at 2022-06-21 01:26:04.904020
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    ir = IncludeRole()
    ir.statically_loaded = True
    ir._parent_role = "parent"
    ir._role_name = "role"
    ir._role_path = "role_path"
    ir._from_files = {"list_of_files"}
    ir.apply = True
    ir.public = False
    ir.rolespec_validate = True
    ir.allow_duplicates = False

    assert ir.copy().statically_loaded == ir.statically_loaded, "statically_loaded values are different"
    assert ir.copy()._parent_role == ir._parent_role, "_parent_role values are different"
    assert ir.copy()._role_name == ir._role_name, "_role_name values are different"
    assert ir.copy()._role_path == ir._role_

# Generated at 2022-06-21 01:26:17.005024
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible_collections.notstdlib.moveitallout.plugins.loader import get_basedir
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible_collections.notstdlib.moveitallout.plugins.lookup.pathlib import Path
    import json
    import sys
    plugin_path = ["/root/.ansible/collections/ansible_collections/notstdlib/moveitallout/plugins/lookup/pathlib"]
    sys.path.extend(plugin_path)

    # create play with tasks

# Generated at 2022-06-21 01:26:27.245553
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    class Inventory(object):
        def get_hosts(self, pattern=None):
            return ['host1']

    class Play(object):
        def __init__(self, name=None, play_hosts=None):
            self.name = name
            self.hosts = play_hosts or 'hosts'
            self.inventory = Inventory()
            self.basedir = 'test/test/test'

    play = Play(name='test_play', play_hosts='all')
    block = Block()

    ir = IncludeRole(block, play, loader=None)
    assert isinstance(ir, IncludeRole)

    ir.load({'name': 'zaphod'})
    assert ir.name == 'zaphod'
    assert ir.get_name() == 'zaphod'

# Generated at 2022-06-21 01:26:39.938252
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    test_str_name = 'name_test'
    test_str_role = 'role_test'
    test_block = Block()
    test_role = Role()
    test_role_include = RoleInclude()

    test_include_role = IncludeRole(test_str_name, test_str_role, test_block, test_role, test_role_include)
    assert test_include_role._name == test_str_name
    assert test_include_role._role == test_str_role
    assert test_include_role._block == test_block
    assert test_include_role._parent_role == test_role
    assert test_include_role._role_include == test_role_include
    assert test_include_role._loader == None
    assert test_include_role._play is None
    assert test_

# Generated at 2022-06-21 01:26:44.659497
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test'
    assert ir.get_name() == ir.name
    ir.name = None
    ir.action = 'include_role'
    ir._role_name = 'test_role_1'
    assert ir.get_name() == 'include_role : test_role_1'



# Generated at 2022-06-21 01:26:50.831740
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    r = Role(RoleDefinition('name', 'path'))
    t = IncludeRole()
    t._parent_role = r
    params = t.get_include_params()
    assert 'ansible_parent_role_names' in params
    assert 'ansible_parent_role_paths' in params

# Generated at 2022-06-21 01:27:11.110696
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert True
    run = IncludeRole()
    data = {'name': 'role1', 'action': 'include_role'}
    result = run.load(data, task_include=None)
    assert result._role_name == 'role1'
    assert result.name == 'role1 : role1'

    data = {'role': 'role2', 'action': 'include_role'}
    result = run.load(data, task_include=None)
    assert result._role_name == 'role2'
    assert result.name == 'role2 : role2'

    data = {'action': 'include_role'}
    try:
        result = run.load(data, task_include=None)
    except AnsibleParserError as ex:
        assert isinstance(ex, AnsibleParserError)

# Generated at 2022-06-21 01:27:21.657308
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''Unit test for method get_include_params of class IncludeRole
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    my_play = Play()
    my_play.vars = dict(my_var='my_val')
    my_play.context = PlayContext(my_play)

    ir = IncludeRole()
    ir._role_name = 'my_name'
    ir._parent_role = None
    ir._role_path = 'my_path'
    ir.statically_loaded = True
    ir._from_files = dict(tasks='my_tasks')
    ir.allow_duplicates = True
    ir.rolespec_validate = True
    ir.public

# Generated at 2022-06-21 01:27:30.529414
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.args = {'name': 'admin', 'role': 'admin'}
    ir._role_name = 'admin'
    assert ir.get_name() == 'include_role : admin'
    ir.args = {'name': 'admin', 'role': 'admin'}
    ir._role_name = 'admin'
    ir.name = 'admin'
    assert ir.get_name() == 'admin'
    ir.args = {'name': 'admin', 'role': 'admin'}
    ir._role_name = 'admin'
    ir.name = 'admin'
    ir.action = 'include'
    assert ir.get_name() == 'include : admin'

# Generated at 2022-06-21 01:27:39.074694
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    role = Role.load(path="tests/lib/ansible_test/_data/roles/role_with_role_parent_path/")
    ir = IncludeRole.load({"name": "role_with_role_parent_path"}, role=role)
    v = ir.get_include_params()
    assert v['ansible_parent_role_names'] == ['role_with_role_parent_path']
    assert v['ansible_parent_role_paths'] == ['tests/lib/ansible_test/_data/roles/role_with_role_parent_path']

# Generated at 2022-06-21 01:27:46.911219
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block.load(dict(
        tasks=[
            dict(
                include_role=dict(
                    name='bar'
                )
            )
        ]
    ))
    role = Role.load(dict(
        name='foo',
        dependencies=[],
        tasks=[
            dict(
                include_role=dict(
                    name='bar'
                )
            )
        ]
    ))

    include_role = IncludeRole(task_include=task_include, role=role)
    assert include_role.get_name() == 'include_role : bar'

# Generated at 2022-06-21 01:27:50.682876
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    sut = IncludeRole()
    sut.action = 'action_test'
    sut._role_name = 'role_name_test'
    assert sut.get_name() == 'role_name_test : action_test'

# Generated at 2022-06-21 01:28:03.275319
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Method get_block_list belongs to the class IncludeRole
    # That class is defined
    assert hasattr(IncludeRole, 'get_block_list'), "Class IncludeRole should have method 'get_block_list'"
    # Method get_block_list is public
    assert callable((getattr(IncludeRole, 'get_block_list'))), "Method 'get_block_list' of class IncludeRole should be public"
    # Method get_block_list has docstring
    assert (getattr(IncludeRole, 'get_block_list').__doc__ is not None), "Method 'get_block_list' of class IncludeRole should have docstring"
    # Method get_block_list takes four parameters

# Generated at 2022-06-21 01:28:14.870785
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    role = Role()
    role._role_path = '/some/path'
    role._role_name = 'foo'

    block = Block.load(
        dict(
            name = 'Test',
            block = [
                dict(
                    include_role = dict(
                        name = "bar"
                    )
                )
            ]
        )
    )

    play = Play()
    play._role = role
    play._loader = None
    play.roles = [role]
    play._variable_manager = None

    block._play = play
    block._role = role
    block._variable_manager = None
    block._loader = None

    ir = block._children

# Generated at 2022-06-21 01:28:23.940156
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=[tempfile.mkdtemp() + "/hosts"])
    context = PlayContext()

    ir = IncludeRole()
    ir.args = {"name": "test"}
    ir._parent_role = None
    ir._role_name = "test"
    ir._role_path = "test"

    assert ir.get_block_list() == ([], [])

# Generated at 2022-06-21 01:28:35.251795
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_cases = [
        {'name': 'include', 'action': 'dummy_action', '_role_name': 'my_role', 'expected': 'my_role : '},
        {'name': 'include', 'action': 'dummy_action', '_role_name': 'my_role', 'expected': 'my_role : '},
        {'name': 'include', 'action': 'dummy_action', '_role_name': 'my_role', 'expected': 'my_role : '},
        {'name': 'include', 'action': 'dummy_action', '_role_name': 'my_role', 'expected': 'my_role : '},
    ]


# Generated at 2022-06-21 01:28:52.676146
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Test load method of class IncludeRole

    # When ansible.cfg is not present in the same path as instance.
    raise NotImplementedError

    # When ansible.cfg is present in the same path as instance.
    raise NotImplementedError

# Generated at 2022-06-21 01:29:03.613467
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # Create a new Play
    pb = Play().load({
        'name': 'Test Play',
        'hosts': ['all'],
        'roles': [],
        'tasks': [
            {'name': 'Test Task'}]})
    # Create a new PlayContext
    pc = PlayContext(play=pb)
    # Create a new VariableManager (Dummy)
    vm = VariableManager(loader=DataLoader())
    # Create a new IncludeRole
    ir = IncludeRole(block=Block(), role=pb.get_roles()[0])
    # Test constructor of class IncludeRole


# Generated at 2022-06-21 01:29:14.737368
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.task import Task

    # Following dict will be converted to IncludeRole object
    d = dict(action='include_role', name="foobar", tasks_from="tasks_file", vars_from="vars_file",
             handlers_from="handler_file", defaults_from="defaults_file", apply={'tags': ['a', 'b']})

    ir = IncludeRole.load(d)
    ir_copy = ir.copy()

    # check if returned obj is same as input obj
    assert ir == ir_copy

    # check if copy method actually copy object or just return same object
    assert ir is not ir_copy

    # change name of original object and compare with copy
    ir.name = "barfoo"
    assert not ir == ir_copy

    # make copy as Task object and check if it is

# Generated at 2022-06-21 01:29:25.138384
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Calls to the method IncludeRole._get_include_params
    # GIVEN
    block = Block()
    role = Role()
    include_role = IncludeRole(block, role)

    # WHEN
    v = include_role.get_include_params()

    # THEN
    assert 'ansible_parent_role_names' in v
    assert 'ansible_parent_role_paths' in v
    assert 'ansible_role_name' in v
    assert 'ansible_role_path' in v
    assert 'ansible_play_hosts' in v
    assert 'ansible_play_batch' in v
    assert 'ansible_play_hosts_all' in v
    assert 'ansible_play_hosts_count' in v
    assert 'ansible_play_batch_count' in v

# Generated at 2022-06-21 01:29:35.032458
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from collections import namedtuple
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    current_play = Play()
    variable_manager = namedtuple('var', 'get_vars')
    loader = namedtuple('loader', 'get_basedir')
    def get_vars(play):
        return []
    variable_manager.get_vars = get_vars
    def get_basedir(loader):
        return '/'
    loader.get_basedir = get_basedir
    data = {
        'name': 'test',
        'action': 'include_role'
    }
    block = Block()

# Generated at 2022-06-21 01:29:43.164088
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_includerole import RoleIncluderole
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import role_loader


# Generated at 2022-06-21 01:29:55.015379
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    data = dict(
        name='role_name',
        tasks_from='tasks/main.yml',
        vars_from= 'vars/main.yml',
        rolespec_validate=False,
        public=True,
        apply=dict(
            ignore_errors=True,
            tags=['always'],
            force_handlers=True,
            serial=5,
        )
    )
    tr = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
    assert tr.name == 'role_name'
    assert tr.tasks_from == 'main.yml'
   

# Generated at 2022-06-21 01:30:03.694525
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader, connection_loader
    from ansible.plugins.loader import callback_loader, cache_loader
    from ansible.plugins.loader import cliconf_loader, db_loader
    from ansible.plugins.loader import doc_fragments_loader, httpapi_loader
    from ansible.plugins.loader import shell_loader, lookup_loader
    from ansible.plugins.loader import inventory_loader, vars_loader
    from ansible.plugins.loader import filter_loader, test_loader
    from ansible.plugins.loader import terminal_loader, strategy_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import Data

# Generated at 2022-06-21 01:30:04.330533
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    a = IncludeRole()
    assert a != None

# Generated at 2022-06-21 01:30:09.471979
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.module_name = "include_role"
    ir.name = 'test-name'
    ir._role_name = 'role1'
    res = ir.get_name()
    assert res == 'test-name : role1'

# Generated at 2022-06-21 01:30:39.379501
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test data
    data = dict(
        include='role_test',
        tasks_from='test/test_playbook/roles/test/tasks/main.yml'
    )
    # simulate play
    play = dict(
        roles=[],
        handlers=[],
    )
    # Classes to test
    # first fake class
    # second fake class
    class fake_varMgr:
        def __init__(self, loader = None):
            self.loader = loader
        def get_vars(self, task=None, play=None):
            return dict()

    class fake_loader:
        def get_basedir(self):
            return 'test/test_playbook/roles'

    # simulate variable and loader
    variable_manager = fake_varMgr(loader=fake_loader())
   

# Generated at 2022-06-21 01:30:47.016778
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import sys
    import os

    test_class_inst = IncludeRole()

    # Expected AnsibleParserError when dict is empty
    result = test_class_inst.load(data={}, variable_manager={}, loader={})
    assert result.action == 'include_role'
    assert result.args == {}
    assert result._parent_role == None
    assert result._role_name == None
    assert result._role_path == None

    test_dict = {'role': 'test_role'}
    test_class_inst2 = IncludeRole()
    result = test_class_inst2.load(data=test_dict, variable_manager={}, loader={})
    assert result.args == {'role': 'test_role'}
    assert result._parent_role == None

# Generated at 2022-06-21 01:30:57.924548
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # case1: invalid options
    block = Block(parent_block=None)
    block.role = Role()
    task_inc = TaskInclude.load(dict(action='include_role', name='my_role', invalid_arg=123), block, role=block.role)

# Generated at 2022-06-21 01:31:06.459461
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    datadir="./tests/integration/testdata/"
    variable_manager=VariableManager(loader=None)
    variable_manager._extra_vars = {
        'hostvars': {
            'host1': {'ansible_hostname': 'host1', 'ansible_ip_address': '10.0.0.1', 'ansible_network_os': 'ios'},
            'host2': {'ansible_hostname': 'host2', 'ansible_ip_address': '10.0.0.2', 'ansible_network_os': 'iosxr'},
        }
    }

    loader = DataLoader()
   

# Generated at 2022-06-21 01:31:12.065345
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    play_source = dict(
        name="Ansible Play", hosts='localhost', gather_facts='no',
        tasks=[dict(action=dict(include_role=dict(name="ansible.builtin.debug", public=True), args={})),
               dict(action=dict(include_role=dict(name="ansible.builtin.debug", public=True), args={}))]
    )

    inv_source = dict(localhost=dict(host_name="localhost"))

    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)
    inv = InventoryManager(loader=None, sources=[inv_source])


# Generated at 2022-06-21 01:31:17.809189
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role.name = "task_name"
    assert include_role.get_name() == "task_name"

# Generated at 2022-06-21 01:31:24.934622
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    ir = IncludeRole()
    # exclude_parent=False
    ir_1 = ir.copy()
    assert ir_1.parent is None
    # exclude_parent=True
    ir_2 = IncludeRole(Block(parent=ir)).copy(exclude_parent=True)
    assert ir_2.parent is None
    # exclude_tasks=False
    ir_3 = IncludeRole(Block(parent=ir), role=RoleDefinition()).copy()
    assert ir_3.tasks is not None
    # exclude_tasks=True
    ir_4 = IncludeRole(Block(parent=ir), role=RoleRequirement()).copy(exclude_tasks=True)
    assert ir_4

# Generated at 2022-06-21 01:31:31.523376
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # True Case
    ir = IncludeRole(None, None, None)
    ir._role_name = 'test_name'
    name = ir.get_name()
    assert name.find('test_name') != -1
    # False Case
    ir = IncludeRole(None, None, None)
    ir._role_name = None
    name = ir.get_name()
    assert name is not None


# Generated at 2022-06-21 01:31:43.489551
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    try:
        import yaml
    except ImportError:
        raise SkipTest("Failed to import yaml module")

    # test the copy method
    ir = IncludeRole(task_include=TaskInclude())
    ir._parent = Block()
    data = yaml.safe_load("""
    - name: my-role
      from_task: included-task
    """)
    ir.load_data(data)

    ir2 = ir.copy()
    assert ir2._parent == ir._parent
    assert ir2.action == ir.action
    assert ir2.name == ir.name
    assert ir2.register == ir.register
    assert ir2.loop == ir.loop
    assert ir2.delegate_to == ir.delegate_to
    assert ir2.loop_control == ir.loop_control
   

# Generated at 2022-06-21 01:31:44.283635
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    pass

# Generated at 2022-06-21 01:32:35.291976
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    #set up test variables
    role_name = 'test_role1'
    role_path = '/home/ansible/test_role_path'
    role_metadata = '{"name": "test_role1","version": "0.0.1", "dependencies": []}'
    test_vars = {'role_path': role_path}

    # create test objects
    block = Block()
    role = Role()
    role._role_name = role_name
    role._role_path = role_path
    role._metadata = role_metadata

    test_include_role = IncludeRole(block=block, role=role)

    # run method get_include_params of class IncludeRole
    result = test_include_role.get_include_params()

    # test result
    assert result == test_vars

# Generated at 2022-06-21 01:32:43.722435
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import role_loader

    task_include = IncludeRole.load(dict(name="httpd"), variable_manager=VariableManager(), loader=role_loader)
    task_include._role_path = "httpd"
    assert task_include.get_name() == "include_role : httpd"

    play_context = PlayContext()
    play_context.remote_addr = ""
    play_context.port = 0
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.module_name = "command"

# Generated at 2022-06-21 01:32:47.601538
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role = IncludeRole()
    params_returned = include_role.get_include_params()
    assert isinstance(params_returned, dict)



# Generated at 2022-06-21 01:32:50.849263
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    assert 'block' in include_role.__dict__
    assert 'role' in include_role.__dict__
    assert 'task_include' in include_role.__dict__

# Generated at 2022-06-21 01:32:56.149077
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(role='default.install').get_name() == "include_role : default.install"
    assert IncludeRole(role='default.install', name='Install').get_name() == "Install : default.install"



# Generated at 2022-06-21 01:33:05.719289
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    method IncludeRole.get_include_params should return a dictionary with keys:
    ansible_parent_role_names, ansible_parent_role_paths, role_name and role_path
    """
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role

    variable_manager = DummyVariableManager()
    loader = DummyLoader()

    b = Block()
    b._role = Role()

    pc = PlayContext()

# Generated at 2022-06-21 01:33:14.801530
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # The data needed to create a IncludeRole instance
    task_data = {
        '__ansible_module__': 'include_role',
        '__ansible_arguments__': ['name=some_role'],
    }

    # The role instance needs a parent, a block and a role.
    # The block and role need a playbook to get fully initialized, but this playbook is not used by the Include Role
    # instance.
    task_include = TaskInclude(block=Block(), role=Role())
    task = IncludeRole(task_include=task_include)
    assert(task.load(task_data) == task)


# Generated at 2022-06-21 01:33:24.582994
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    role = IncludeRole(block=None, role=None, task_include=None)
    d = dict(
        name='this_name',
        tasks_from='task_from_file',
        vars_from='vars_from_file',
        handlers_from='handlers_from_file',
        apply=dict(
            role_name='role_name',
            role_path='role_path',
        ),
        public=False,
        allow_duplicates=True,
        rolespec_validate=True,
    )
    role.load(d)
    print(role.get_name())
    print(role.get_block_list())
    print(role.copy())
    print(role.get_include_params())


if __name__ == '__main__':
    test_Include

# Generated at 2022-06-21 01:33:33.286226
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block(parent_block=None)
    role = Role()
    ir = IncludeRole(block, role)
    ir.name = 'test'
    ir._role_name = 'test2'
    ir._role_path = 'test3'
    ir._from_files = {'test4':'test4'}
    ir._private_parent_role = 'test5'
    ir.allow_duplicates = False
    ir._parent = role
    ir._parent_role = role
    ir._ds = 'test6'
    ir._loop = 'test7'
    ir._role_params = 'test8'
    ir._when = 'test9'
    ir._any_errors_fatal = False
    ir.always_run = True
    ir.async_val = 0

# Generated at 2022-06-21 01:33:33.815361
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert False, "get_block_list needs unit tests"