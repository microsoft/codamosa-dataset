

# Generated at 2022-06-21 01:24:48.941225
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.role import Role

    r1 = Role()
    r1._role_name = 'test01'
    r1._role_path = '/roles/test01'

    r2 = Role()
    r2._role_name = 'test02'
    r2._role_path = '/roles/test02'
    r2._parents = [ r1 ]

    r3 = Role()
    r3._role_name = 'test03'
    r3._role_path = '/roles/test03'
    r3._parents = [ r2 ]

    ir = IncludeRole()
    ir._parent_role = r3

    assert 'ansible_parent_role_names' not in ir.get_include_params()

# Generated at 2022-06-21 01:24:59.313815
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest
    from ansible.vars.manager import VariableManager
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import module_common
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import become_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    blocks = []
    play_context = {}
    new_stdin = module

# Generated at 2022-06-21 01:25:11.708548
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    This test code is not part of the main code and is not being executed
    """

    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import task_loader
    from ansible.plugins.loader import lookup_loader

    import ansible.constants as C
    from ansible.template import Templar

    from ansible.parsing.vault import VaultLib
    #from ansible.parsing.vault import VaultSecret
    from ansible.plugins.lookup import LookupBase

    import ansible.inventory.manager

# Generated at 2022-06-21 01:25:23.481615
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import role_loader
    from ansible.inventory.manager import InventoryManager

    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader

    display = Display()


# Generated at 2022-06-21 01:25:34.036155
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """Unit test for method 'get_block_list' of class 'IncludeRole'
        - test1: valid parameters, 2 roles to include,
                        check that the first role is included and check the second also
    """
    block = Block()
    role = Block()
    task_include = Block()

    include_role = IncludeRole(block=block, role=role, task_include=task_include)

    # test1
    tasks_1 = [{'name':'task_1_1', 'tags': 'include_role_1'}]
    handlers_1 = [{'name':'handler_1_1', 'tags': 'include_role_1'}]

    tasks_2 = [{'name':'task_2_1', 'tags': 'include_role_2'}]

# Generated at 2022-06-21 01:25:45.388072
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Test the case where _parent_role is None
    data = dict(collections=None, action="some_include", args=dict(name="some_role"), delegate_to=None, module=None)
    block = Block(play=Play().load(dict(), variable_manager=None, loader=None))
    role = Role()
    ir = IncludeRole.load(data, block, role, task_include=None, variable_manager=None, loader=None)
    assert ir.collections is None
    assert len(ir.get_include_params()) == 0

    # Test the case where _parent_role is not None
    parent_role = Role()
    parent_role.name = "some_parent_role"
    parent_

# Generated at 2022-06-21 01:25:55.096291
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    task = IncludeRole()
    task._parent_role = 'role_object'
    p_role = Role()
    p_role._role_path = 'role_dir/role_name'
    p_role.name = 'role_name'
    role_params = dict(
        role_name='role_name',
        role_path='role_dir/role_name',
        role_params=dict(
            ansible_parent_role_names=['role_name'],
            ansible_parent_role_paths=['role_dir/role_name']
        ))
    p_role.get_role_params = lambda: role_params
    task._parent_role = p_role
    res = task.get_include_params()
    assert isinstance(res, dict)
    assert set(res.keys())

# Generated at 2022-06-21 01:26:05.949033
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.playbook.play import Play

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:26:17.847274
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    import tempfile
    temp_path = tempfile.mkdtemp()
    sys.path.append(temp_path)
    os.chdir(temp_path)

    import pkgutil

    # Extracts the role default role provided as argument
    extract_role = lambda role_path: pkgutil.get_data('ansible.parsing', os.path.join(role_path, 'meta', 'main.yml')).decode()

    # Creates the main.yml file in the specified path
    def save_file(data, dest):
        with open(dest, 'w') as f:
            f.write(data)

    # Creates a role with a given name, adds the default role to it and saves the file in the specified path

# Generated at 2022-06-21 01:26:21.127984
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(block=Block(), role=Role())
    assert isinstance(ir, IncludeRole)
    assert ir.vars == {}
    assert ir.tags == set()

# Generated at 2022-06-21 01:26:41.184339
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''test for IncludeRole.get_block_list'''

    class Mock_Data(object):
        '''Mocking ansible data structure'''

        def __init__(self, data):
            self.data = data

    class Mock_Block(object):
        '''Mocking ansible data structure'''

        def __init__(self):
            pass

        def set_parent(self, parent):
            self.parent_block = parent

    class Mock_Play(object):
        '''Mocking ansible data structure'''

        def __init__(self):
            pass

        def _load_included_file(self, path, *args, **kwargs):
            return path

    blocks = [Mock_Block(), Mock_Block()]
    handlers = [Mock_Block(), Mock_Block()]
    mock

# Generated at 2022-06-21 01:26:52.973888
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import os
    import tempfile

    # Create temp file to read and write test data
    fd, temppath = tempfile.mkstemp()
    os.close(fd)

    # Create a temp role for test data
    rolepath = os.path.abspath(os.path.join(temppath, "..", "test_role"))
    os.makedirs(rolepath)
    main_path = os.path.join(rolepath, "tasks", "main.yml")

    # Create main task file
    with open(main_path, 'w') as main_file:
        main_file.write("""
        - debug:
            var: test_var
        """)


# Generated at 2022-06-21 01:27:03.754462
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    i_r = IncludeRole()
    i_r._main_block = Block()
    i_r.statically_loaded = True
    i_r._from_files = ['py']
    i_r._parent_role = Role()
    i_r._role_name = "t"
    i_r._role_path = "p"
    new_i_r = i_r.copy()
    assert new_i_r.statically_loaded == True
    assert i_r._from_files == new_i_r._from_files
    assert i_r._parent_role == new_i_r._parent_role
    assert i_r._role_name == new_i_r._role_name
    assert i_r._role_path == new_i_r._role_path


# Generated at 2022-06-21 01:27:11.109442
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    include_role = IncludeRole()
    include_role.statically_loaded = True
    include_role._from_files = {'tasks_from': 'main.yml'}
    include_role._role_name = 'my_role'
    include_role._role_path = 'roles/my_role'
    new_include_role = include_role.copy()
    assert new_include_role.statically_loaded == include_role.statically_loaded
    assert new_include_role._from_files == include_role._from_files
    assert new_include_role._role_name == include_role._role_name
    assert new_include_role._role_path == include_role._role_path

# Generated at 2022-06-21 01:27:21.656558
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import ansible.constants as C

    display = Display()
    options

# Generated at 2022-06-21 01:27:27.950009
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir.name == None
    assert ir.args == {}
    assert ir._role_name == None
    assert ir._from_files == {}
    assert ir._parent_role == None
    assert ir._role_path == None
    assert ir.apply == {}
    assert ir.allow_duplicates == True
    assert ir.public == False
    assert ir.rolespec_validate == True

# Generated at 2022-06-21 01:27:29.482959
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test if method get_block_list of class IncludeRole work well under normal
    # situation.
    pass

# Generated at 2022-06-21 01:27:40.095244
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.collections import CollectionLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.become = None
            self.become_method = None

# Generated at 2022-06-21 01:27:49.299339
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print('TESTING IncludeRole.get_name()')
    ir = IncludeRole(block=Block([]))
    ir.name = 'my_fake_name'
    ir.action = 'my_fake_action'
    ir._role_name = 'my_fake_role_name'
    assert ir.get_name() == "my_fake_name : my_fake_role_name"
    ir.name = None
    assert ir.get_name() == "my_fake_action : my_fake_role_name"

if __name__ == '__main__':
    test_IncludeRole_get_name()

# Generated at 2022-06-21 01:27:50.199329
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert False



# Generated at 2022-06-21 01:28:08.380071
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()

    assert isinstance(ir, IncludeRole)
    assert ir.action == "include_role"
    assert ir._role_name is None
    assert ir._parent_role is None
    assert ir._role_path is None


# Generated at 2022-06-21 01:28:17.443067
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from io import StringIO
    from ansible.playbook.task import Task

    # data
    data = {'include_role': {'name': 'test', 'tasks_from': 'file.yml'}}

    # loaders
    loader = DataLoader()

    # variable manager
    variable_manager = VariableManager()

    # inventory manager
    inventory = InventoryManager(loader=loader, sources='')

    # create play with single task

# Generated at 2022-06-21 01:28:24.662836
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()

    # test for default value of _allow_duplicate
    assert ir.allow_duplicates == ir._allow_duplicates.default

    # test for default value of _public
    assert ir.public == ir._public.default

    # test for default value of _rolespec_validate
    assert ir.rolespec_validate == ir._rolespec_validate.default

    # test for default value of _parent_role
    assert ir._parent_role == None


# Generated at 2022-06-21 01:28:35.395939
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    #Test load - name is needed, or use role as alias
    data = dict(name='role_name')
    obj = IncludeRole.load(data)
    assert obj._role_name == 'role_name'

    data = dict(role='role_name', other='value')
    obj = IncludeRole.load(data)
    assert obj._role_name == 'role_name'

    #Test load - build options for role includes
    data = dict(name='role_name', tasks_from='1.yaml')
    obj = IncludeRole.load(data)
    assert obj._from_files == {'tasks': '1.yaml'}

    data = dict(name='role_name', vars_from='1.yaml')
    obj = IncludeRole.load(data)

# Generated at 2022-06-21 01:28:40.093966
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.definition import DEFAULT_ROLE_BODY
    data = {u'name': u'foobar', u'block': DEFAULT_ROLE_BODY, u'action': u'include_role'}
    task1 = IncludeRole.load(data=data, block=None, role=None)
    task2 = task1.copy(exclude_tasks=False)

    assert(task1._from_files == task2._from_files)
    assert(task1._role_name == task2._role_name)
    assert(task1._role_path == task2._role_path)

# Generated at 2022-06-21 01:28:48.940168
# Unit test for method get_include_params of class IncludeRole

# Generated at 2022-06-21 01:28:57.887131
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ''' test_IncludeRole_copy
    This test case used to verify the correct execution of the method copy
    in the class IncludeRole.
    '''
    # we create a Block object with two Tasks
    b = Block([])
    t1 = IncludeRole(block=b, role=None, task_include=None)
    t2 = IncludeRole(block=b, role=None, task_include=None)
    t1.name = 'my_role'
    t1.action = 'include_role'
    t2.name = 'my_role2'
    t2.action = 'include_role'
    b._tasks = [t1, t2]

    # we copy the Block as a Block
    b_new_me = b.copy(exclude_tasks=True)
    # we verify that

# Generated at 2022-06-21 01:29:05.512294
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.role import Role
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    ir = IncludeRole()
    ir._parent_role = Role(name='dummy', metadata=dict(dependencies=[]))

    hostvars = HostVars({}, UnsafeProxy({'foo': 'bar'}))
    vars_params = ir.get_include_params(hostvars)


# Generated at 2022-06-21 01:29:15.385135
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def test_IncludeRole_load_with_invalid_arg():
        data = '''
        - name: Test include role
          import_playbook: apb1.yml
          vars:
              var1: var.val
              invalid: try it
        '''
        yaml_input = yaml.safe_load(data)
        yaml_input = yaml_input[0]
        include_role = IncludeRole.load(yaml_input)
        include_role._validate_options()
        assert isinstance(include_role, IncludeRole)

    def test_IncludeRole_load_with_public_arg():
        data = '''
        - include_role:
            name: Test include role
            tasks_from: taskfile.yml
            public: yes
        '''
        yaml_

# Generated at 2022-06-21 01:29:25.425556
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import pytest
    from ansible.playbook.role.definition import RoleDefinition
    class ParentRole:
        role_definition = RoleDefinition.load(from_files={
            'vars': 'role_vars.yml',
            'tasks': 'tasks/main.yml',
            'meta': 'meta/main.yml',
            'handlers': 'handlers/main.yml',
            'defaults': 'defaults/main.yml',
        })

    r = IncludeRole.load({'name': 'foobar'})
    assert(r._role_name == 'foobar')

    r = IncludeRole.load({'role': 'foobar'})
    assert(r.name == 'foobar')


# Generated at 2022-06-21 01:29:56.124514
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-21 01:29:57.022683
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    myIncludeRole = IncludeRole()
    assert myIncludeRole is not None


# Generated at 2022-06-21 01:30:01.430864
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(role=Role())
    assert ir.allow_duplicates is True
    assert ir.public is False
    assert ir.rolespec_validate is True
    assert ir.statically_loaded is False
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True

# Generated at 2022-06-21 01:30:12.430451
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    t = TaskInclude()
    ir = IncludeRole(task_include=t)
    ir.name = "test-name"
    ir._from_files["test-from-file"] = "test-value"
    ir._parent_role = "test-parent"
    ir._role_name = "test-role-name"
    ir._role_path = "test-role-path"

    copy = ir.copy(False, False)
    assert copy.name == "test-name"
    assert ir._from_files == copy._from_files
    assert ir._parent_role == copy._parent_role
    assert ir._role_name == copy._role_name
    assert ir._role_path == copy._role_path

# Generated at 2022-06-21 01:30:16.786847
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test variable
    test_role = IncludeRole()
    test_name = 'include_role'
    test_role_name = 'Apache'

    test_role._role_name = test_role_name
    assert test_role.get_name() == test_role_name
    # Only role_name is assigned, action will be 'include_role'
    assert test_role.get_name() == test_name + ' : ' + test_role_name

# Generated at 2022-06-21 01:30:26.142566
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    o = IncludeRole(block=Block(), role=Role())
    o._parent = '1'
    o._tasks = ['t']
    o._role_name = 'r_name'
    o._role_path = 'r_path'
    o._from_files = {'dict': 'value'}

    copy_o = o.copy(exclude_parent=False, exclude_tasks=False)
    assert o._parent is not copy_o._parent
    assert o._tasks is not copy_o._tasks
    assert o._role_name is copy_o._role_name
    assert o._role_path is copy_o._role_path
    assert o._from_files is not copy_o._from_files


# Generated at 2022-06-21 01:30:34.246090
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.vars import AnsibleVars
    from ansible.utils.display import Display
    from ansible.constants import DEFAULT_VAULT_ID_MATCH

    display = Display()
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)



# Generated at 2022-06-21 01:30:44.452493
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-21 01:30:56.274643
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    r = Role()
    r.name='my_role'
    ir = IncludeRole(role=r)
    assert ir.name is None
    assert ir.action == 'include_role'
    assert ir.allow_duplicates is True
    assert ir.vars is None
    assert ir.role == r
    assert ir.block is None
    assert ir.tags is None
    assert ir.when is None
    assert ir.always_run is False
    assert ir.register is None
    assert ir.delegate_to is None
    assert ir.rolename is None
    assert ir.loop is None
    assert ir.loop_with is None
    assert ir.first_available_file is None
    assert ir.ignore_errors is False
    assert ir.loop_control is None
    assert ir._parent is None
    assert ir

# Generated at 2022-06-21 01:31:04.002602
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    
    # Test for inclusion in tasks
    a = IncludeRole()
    a.name = 'a'
    a.role.name = 'b'
    a.vars = {'a':{'b':'c'}}
    a.role.vars = {'c':{'d':'e'}}
    a.role.default_vars = {'f':{'g':'h'}}
    a.role._role_path = 'a'
    a.role.get_role_params = lambda: {'a':'b'}


# Generated at 2022-06-21 01:32:16.754181
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.unsafe_proxy import UnsafeProxy

    role1 = Role()
    role1.name = 'role1'
    role_path1 = '/path/to/role1/'
    role1._role_path = role_path1
    role1_params = {'role_name': role1.name,
                    'role_path': role_path1,
                    'role_uuid': role1.uuid}
    role1.set_role_params(role1_params)
    assert role1.get_name() == 'role1'
    assert role1._role_path == role_path1
    assert role1.get_role_params() == role1_params

    role2 = Role

# Generated at 2022-06-21 01:32:17.906291
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    my_role = IncludeRole()
    assert(my_role)

# Generated at 2022-06-21 01:32:25.099123
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    playbook_path = C.DEFAULT_PLAYBOOK_PATH
    if playbook_path is None:
        playbook_path = ["."]
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    host = inventory.get_host(inventory.get_hosts()[0].name)
    play_context = PlayContext()

# Generated at 2022-06-21 01:32:38.081232
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Constructor test:
    ir = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude())
    assert ir

    # Constructor test w/ args:
    ir = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude(), allow_duplicates=True, public=False, rolespec_validate=True,
                     _from_files={"tasks": "main.yml", "vars": "extra_vars.yml", "defaults": "defaults.yml", "handlers": "handlers.yml"})
    assert ir

    # Call load() and make sure it doesn't raise an exception

# Generated at 2022-06-21 01:32:44.922278
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import sys
    import os
    import collections
    import data_structures
    from . import data_structures as ds
    from . import utils


# Generated at 2022-06-21 01:32:54.354491
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.role import Role
    from ansible.collection import CollectionLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a template
    loader = CollectionLoader()
    #collection = loader.load(["~/.ansible/collections/ansible_collections/openstack/os_magnum/tasks/cluster_template.yml"])
    #print(collection)
    #exit(1)
    # Create a role
    role = Role(loader=loader)

    # Create an include role
    task_include = IncludeRole(role=role)
    task_include._role_name = "openstack.os_magnum.tasks.cluster_template"
    #task_include

# Generated at 2022-06-21 01:33:05.208455
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    sudo_pass = '$5$JvmAbW9B$KyKz.WeY.YG8ZkWgdJv1QZ13QFZgP0TycW9XJHrFb53'
    block = Block()
    role = Role()

    task_include_vars = dict(
        name='test_include_role',
        connection='local',
        when=dict(test_include_role='success'),
        become='no',
        become_user='james',
        become_method='sudo',
        sudo_flags=u'h',
        become_ask_pass=False,
        sudo_pass=sudo_pass,
        tags=['test_include_role'],
        register='test_include_role'
    )

# Generated at 2022-06-21 01:33:14.614883
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    # Create object IncludeRole
    test_role1 = IncludeRole(block=Block())

    # Set values to attributes
    test_role1.statically_loaded = False
    test_role1._from_files = {
        "tasks": "main.yml",
        "handlers": "handlers.yml"
    }
    test_role1._parent_role = "test_parent_role"
    test_role1._role_name = "test_role_name"
    test_role1._role_path = "test_role_path"

    # Create object IncludeRole
    test_role2 = test_role1.copy()

    # Check values of attributes
    assert test_role2.statically_loaded == test_role1.statically_loaded
    assert test_role2._from_files['tasks']

# Generated at 2022-06-21 01:33:24.507073
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class LoaderMock:
        def find_file_in_search_path(self, *args):
            return "/path/to/myfile.yml"

    class PlaybookMock:
        def __init__(self):
            self.host_vars = AnsibleMapping()
            self.vars = AnsibleMapping()

        def get_variable_manager(self):
            return VariableManager(loader=LoaderMock())

    class RoleMock:
        def __init__(self, vars=None):
            self.vars = vars or AnsibleMapping()

# Generated at 2022-06-21 01:33:28.987665
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.utils.vars import combine_vars

    ir = IncludeRole()
    ir_data = dict(name='nginx')
    print(IncludeRole.load(ir_data))