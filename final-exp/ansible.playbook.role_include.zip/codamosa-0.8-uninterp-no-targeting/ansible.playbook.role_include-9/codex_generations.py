

# Generated at 2022-06-21 01:24:45.307624
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_ds = dict(
        name="test play",
        hosts='all',
        gather_facts='no'
    )
    play = Play.load(play_ds, variable_manager=None, loader=None)
    play.default_vars = dict(
        role_param1='common',
        role_param2='common',
        role_param3='common',
    )
    play.set_variable_manager(variable_manager=None)
    play_context = PlayContext(play=play)

# Generated at 2022-06-21 01:24:56.868819
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    block = '''
- include_role:
    name: include_role_test_role
'''

    test_role = './test_role/'

    from ansible.vars.manager import VariableManager

    # create the play
    play = Play().load({'name': 'test', 'hosts': 'localhost', 'gather_facts': 'no', 'tasks': [dict(action='debug', msg='{{ item }}') for item in ['a', 'b', 'c', 'd']]}, variable_manager=VariableManager(), loader=None)

    #

# Generated at 2022-06-21 01:25:08.811918
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    #include_role is a new feature of Ansible v2.5 so we need to use this version
    C._ANSIBLE_VERSION = '2.5.1'

    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    #Set some variables
    play_context = PlayContext()
    play_context.remote_addr = 'localhost'
    new_host = Host('localhost')
    new_host.vars = {'ansible_playbook_python': '/usr/bin/python2'}
    inventory = dict(all=dict(children=dict(ping=dict(hosts=dict(localhost=new_host)))))
    variable_manager = VariableManager()


# Generated at 2022-06-21 01:25:20.530399
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    config = {
        "name": "bar",
        "action": "include_role",
        "args": {
            "role": "foo",
            "allow_duplicates": "True"
        }
    }

    block = Block()

    role = Role()
    role._role_name = "bar"
    role._role_path = "/home/foo/roles/bar"

    task_include = TaskInclude()
    task_include.action = "include_role"
    task_include.block = block
    task_include.role = role
    task_include.get_role_params = lambda: {"rolespec_validate": True,
                                            "tags": ["all"],
                                            "allow_duplicates": "True",
                                            "max_loops": "foo"}

   

# Generated at 2022-06-21 01:25:27.304557
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    role_name = "/Users/xxx/ansible-test/roles/new_role_1"
    role_path = "/Users/xxx/ansible-test/roles/new_role_1/tasks/main.yml"
    from_file = {"vars": "vars/main.yml", "tasks": "tasks/main.yml", "defaults": "defaults/main.yml", "handlers": "handlers/main.yml"}

    ir = IncludeRole()
    ir._role_name = role_name
    ir._role_path = role_path
    ir._from_files = from_file

    blocks, handlers = ir.get_block_list()
    for block in blocks:
        print(block)
        for task in block.block:
            print(task)
           

# Generated at 2022-06-21 01:25:36.030110
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test loading basic block
    block = Block()
    block.role = Role()
    block.parent_block = block.root_block = block
    block.vars = {'a': 1}
    block.collections = ['col1']
    # test creating role
    role_name = 'role'
    role_data = dict(name=role_name)
    data = dict(role=role_name)
    # create instance of IncludeRole
    ir = IncludeRole.load(data=data, block=block)
    assert ir.args == data
    assert ir._role_name == role_name
    assert ir._from_files == {}
    # assert that IncludeRole uses parent block vars
    # and play collections implicitly
    assert ir.vars == block.vars
    assert ir.collections == block.collections


# Generated at 2022-06-21 01:25:46.581668
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    block_1 = Block.load(
        dict(
            _hosts='127.0.0.1',
            _name='ir',
            _play=Play().load(
                dict(
                    name='test_play',
                    hosts='127.0.0.1',
                    gather_facts='no',
                    tasks=[],
                ),
                loader=None,
            ),
        )
    )
    role_1 = Role()
    role_1._role_path = "/role1"
    role_1._name = "role1"
    role_1._metadata = {"collections": [], "metadata": {"dependencies": [], "galaxy_info": None}}
    role_1.get_v

# Generated at 2022-06-21 01:25:47.303136
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-21 01:25:50.441958
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'a'
    assert ir.get_name() == "a"
    ir.name = None
    ir.action = 'action'
    ir._role_name = 'b'
    assert ir.get_name() == "action : b"

# Generated at 2022-06-21 01:26:00.337784
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    my_block = Block(play=None, role=None)
    my_block._loop = False  # force task_include to instantiate with Block()
    my_include_role = IncludeRole(block=my_block)
    my_include_role.statically_loaded = True
    my_include_role._from_files = {'my_key': 'my_value'}
    my_include_role._parent_role = 'my_parent_role'
    my_include_role._role_name = 'my_role_name'
    my_include_role._role_path = 'my_role_path'
    my_include_role.rolespec_validate = False
    my_copy = my_include_role.copy()
    assert my_copy.statically_loaded == my_include_role.statically_

# Generated at 2022-06-21 01:26:18.948346
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import pytest

    # Ensure that IncludeRole loads tasks_from, handlers_from, defaults_from and vars_from
    # as expected

    ir = IncludeRole.load({ 'name': 'dummy', 'tasks_from': 'templates/tasks.yml' }, None)
    assert (ir._from_files['tasks'] == 'tasks.yml')

    ir = IncludeRole.load({ 'name': 'dummy', 'handlers_from': 'templates/handlers.yml' }, None)
    assert (ir._from_files['handlers'] == 'handlers.yml')

    ir = IncludeRole.load({ 'name': 'dummy', 'vars_from': 'templates/vars.yml' }, None)

# Generated at 2022-06-21 01:26:26.100601
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir.action in C._ACTION_INCLUDE_ROLE
    assert ir.collections is None
    assert not ir.apply
    assert ir.allow_duplicates
    assert not ir.public
    assert not ir.static_loaded
    assert not ir.statically_loaded
    assert ir._from_files == {}
    assert ir._rolespec_validate

    assert ir._parent_role is None
    assert ir._role_name is None
    assert ir._role_path is None

# Generated at 2022-06-21 01:26:38.757886
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    yaml_str = """
    - name: include first parent
      hosts: all
      tasks:
        - include_role:
            name: first
    """
    yaml = YAML()
    playbook = yaml.load(yaml_str)
    include_role = playbook[0].get_blocks()[0].get_tasks()[0]
    include_role.set_loader(DataLoader())
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo='bar')
    variable_manager.options_vars = dict(foo='baz')
    variable_manager.set_inventory(Inventory())
    result = include_role.get_include_params()

# Generated at 2022-06-21 01:26:47.940428
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    host_vars = {}
    host_vars['mock_host'] = {
        "mock_var1": "100",
        "mock_var2": "200"
    }
    loader = DictDataLoader({
        'hosts': [],
        'vars': {},
        'host_vars': host_vars
    })
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    variable_manager = inventory.get_variable_manager()
    playbook = Playbook.load(playbook_path='test/test_playbooks/playbook_test_play.yml', variable_manager=variable_manager, loader=loader)
    block = Block()
    role = Role(name="test_role")

# Generated at 2022-06-21 01:26:59.558829
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Create fake data
    data = {}
    data['name'] = 'fakeName'

    class FakeInclureRole:
        args = {}
        action = 'include_role'

    class FakeBlock:
        def __init__(self):
            self.vars = {}

    class FakeVariables:
        def get_vars(self, play=None, task=None):
            return {}

    class FakeLoader:
        pass

    # Create module
    module = IncludeRole.load(data, block=FakeBlock(), variable_manager=FakeVariables(), loader=FakeLoader())

    # Try to assert the name is equal to the fake name
    assert(module.name == 'fakeName')

    # Try to assert the args are equal to the fake args
    assert(module.args == {})

    # Try to assert the action is equal

# Generated at 2022-06-21 01:27:01.346400
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)
    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-21 01:27:10.444984
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    IncludeRole:
      - load():
    '''

    # test: no name given
    args = {'role': 'foo'}
    data = {'args': args}
    block = Block()
    ir = IncludeRole(block=block)


# Generated at 2022-06-21 01:27:14.981771
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = None
    ir.action = 'include'
    ir._role_name = 'test'
    name = ir.get_name()
    assert name == 'include : test'
    ir.name = 'test'
    name = ir.get_name()
    assert name == 'test'



# Generated at 2022-06-21 01:27:26.250856
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test case 1
    # when allow_duplicates is set True and roles is empty, then return an empty list
    ir = IncludeRole(task_include=TaskInclude())
    ir.vars = {}
    ir._role_name = 'example_role'
    ir._parent_role = None
    ir._role_path = None
    ir._from_files = {}
    ir._allow_duplicates = True
    ir._public = False
    ir._rolespec_validate = True
    assert ir.get_block_list()[0] == []

    # test case 2
    # when allow_duplicates is set False and roles is empty, then raise an exception
    ir = IncludeRole(task_include=TaskInclude())
    ir.vars = {}
    ir._role_name = 'example_role'

# Generated at 2022-06-21 01:27:33.509981
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    class MyRole(Role):
       @property
       def _parent(self):
           return None

       @_parent.setter
       def _parent(self, parent):
           self._block = None

    MyRole.load = lambda rolespec, role_name, role_path, play=None, variable_manager=None, loader=None, dep_chain=None, from_files=None, collection_list=None: MyRole(name=role_name, path=role_path)
    MyRole.get_handler_blocks = lambda self, play=None: []
    MyRole.compile = lambda self, play=None, dep_chain=None: []
    MyRole.get_role_params = lambda self: None



# Generated at 2022-06-21 01:27:56.606850
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    task = IncludeRole(block=Block(), role='test', task_include='test')

    # check data types of all fields
    assert isinstance(task.block, Block)
    assert isinstance(task.role, string_types)
    assert isinstance(task.task_include, string_types)
    assert isinstance(task._from_files, dict)
    assert isinstance(task._parent_role, string_types)
    assert isinstance(task._role_name, string_types)
    assert isinstance(task._role_path, string_types)

    # check defaults of all fields
    assert task.block is not None
    assert task.role == 'test'
    assert task.task_include == 'test'
    assert task._from_files == {}
    assert task._parent_role is None
    assert task._role_

# Generated at 2022-06-21 01:27:59.230588
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'foo'
    ir._role_name = 'bar'
    assert ir.get_name() == ir.name or "%s : %s" % (ir.action, ir._role_name)

# Generated at 2022-06-21 01:28:06.767573
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    from ansible.plugins.action.include_role import ActionModule as RoleIncludeAction
    action_loader.add('include_role', RoleIncludeAction)

    from ansible.plugins.action.import_role import ActionModule as RoleImportAction
    action_loader.add('import_role', RoleImportAction)


# Generated at 2022-06-21 01:28:10.556070
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude())
    ir._role_name = 'test_role'
    assert ir.get_name() == 'include_role : test_role'

# Generated at 2022-06-21 01:28:21.437099
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    parent = Block([], [])
    ir = IncludeRole(parent, task_include=TaskInclude(parent))
    assert isinstance(ir, Block)
    assert isinstance(ir, IncludeRole)
    assert ir.action == 'include_role'
    assert ir.args == {}
    assert ir.vars == {}
    assert ir._parent._parent is parent # pylint: disable=protected-access
    assert ir._parent._block is ir # pylint: disable=protected-access
    assert ir._statically_loaded is False
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True
    assert ir._from_files == {}
    assert ir._parent_role == None
    assert ir._role_name == None
    assert ir._role_path

# Generated at 2022-06-21 01:28:33.947893
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role

    # mock Role
    class MockedRole(Role):
        display = Display()

        def __init__(self, *args, **kwargs):
            super(MockedRole, self).__init__(*args, **kwargs)
            self._role_name = 'myrole'
            self._parents = []
            self._metadata = None
            self.get_vars = {}
            self.collections = []

        def get_role_params(self):
            return {}

        def get_name(self):
            return self._role_name

        def get_vars_files(self):
            return []

        def get_default_vars(self):
            return {}

        def get_role_dep_chain(self):
            return []

    # test copy()


# Generated at 2022-06-21 01:28:45.413276
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    include_role = IncludeRole(block, role)

    # Set values of some attributes which are not in set difference
    # of IncludeRole.BASE, IncludeRole.VALID_ARGS, IncludeRole.FROM_ARGS
    # and IncludeRole.OTHER_ARGS
    include_role.always_run = True
    include_role.any_errors_fatal = False
    include_role.changed_when = False
    include_role.collections = 'collection'
    include_role.connection = 'local'
    include_role.delegate_facts = False
    include_role.delegate_to = 'localhost'
    include_role.do_not_log = True
    include_role.ignore_errors = False
    include_role.loop = 'item'
    include

# Generated at 2022-06-21 01:28:47.729187
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    args = dict(name = 'role1')
    ans_obj = IncludeRole.load(args)
    assert ans_obj._role_name == 'role1'

# Generated at 2022-06-21 01:28:57.428896
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    import ansible.playbook.role as role
    r = role.Role()
    role_name = r.get_name()
    role_path = r._role_path
    ir = IncludeRole()
    ir_name = ir.get_name()
    ir_parent_role = ir._parent_role
    ir_role_name = ir._role_name
    ir_role_path = ir._role_path
    ir_statically_loaded = ir.statically_loaded
    ir_from_files = ir._from_files
    ir_collections = ir.collections
    ir_rolespec_validate = ir.rolespec_validate
    ir_allow_duplicates

# Generated at 2022-06-21 01:29:05.355249
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Call constructor without parameters
    f1 = IncludeRole.load(dict(name='foo'))
    assert f1.statically_loaded is False
    assert f1._from_files == {}
    assert f1._parent_role is None
    assert f1._role_name == 'foo'
    assert f1._role_path is None

    # Call constructor with parameters
    f1 = IncludeRole.load(dict(name='foo'), statically_loaded=True, _from_files={'a': 'b'}, _parent_role={'a': 'b'}, _role_name='bar', _role_path='baz')
    assert f1.statically_loaded is True
    assert f1._from_files == {'a': 'b'}
    assert f1._parent_role == {'a': 'b'}
   

# Generated at 2022-06-21 01:29:41.026076
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test load with an invalid option
    ir1 = IncludeRole.load({'name':'no-value','invalid':'value','static': 'value'})
    assert ir1._role_name == 'no-value'
    assert ir1.statically_loaded == True
    ir1.validate()

    # Test load with valid options
    ir2 = IncludeRole.load({'name':'role-with-value','static':'value','apply':'value'})
    assert ir2._role_name == 'role-with-value'
    assert ir2._from_files == {}
    assert ir2.statically_loaded == True
    assert ir2.public == False
    assert ir2.allow_duplicates == True
    ir2.validate()

    # Test load with non string 'from' option of apply
    ir

# Generated at 2022-06-21 01:29:53.565415
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    role = Role.load('../../../test/unit/library/not_there', play=None, variable_manager=None, loader=None, collection_list=None)
    role.vars['a'] = 'a'
    role.tags.add('a')
    role.deps['a'] = 'a'
    role.run_once = True
    role.private = True
    role.allow_duplicates = True
    role.metadata = {'a': 'a'}
    role.role_path = 'a'
    role._role_name = 'a'
    role._role_params = {'a': 'a'}
    role._parents = [1, 2, 3]
    role._

# Generated at 2022-06-21 01:30:02.086247
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition

    include_role_action = C._ACTION_INCLUDE_ROLE[0]

    play_yaml = '''

    ---
    - hosts: localhost
      roles:
        - role: include_role_test_role

    '''
    play = Play.load(play_yaml, variable_manager=None, loader=None)

    # Validate options

# Generated at 2022-06-21 01:30:13.750149
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 01:30:16.211175
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    a, b = IncludeRole(), IncludeRole()
    for i, j in zip(a.__dict__.keys(), b.__dict__.keys()):
        assert a.__dict__[i] == b.__dict__[j]

# Generated at 2022-06-21 01:30:25.698037
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.playbook.play as play
    import ansible.playbook.handler as handler
    # here we need to check the constructor of IncludeRole through __init__
    # create some dummy data to pass to the constructor
    role = Role.load('some_role')
    task_include = TaskInclude()
    block = Block()
    test_IncludeRole = IncludeRole(role=role, task_include=task_include, block=block)
    # check attributes
    assert test_IncludeRole._allow_duplicates is True
    assert test

# Generated at 2022-06-21 01:30:33.885936
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import sys
    if sys.version_info.major >= 3:
        import unittest
        import unittest.mock as mock
    else:
        import mock
        import unittest2 as unittest

    data = dict(
        name='test_role',
        tasks_from='tasks/main.yml'
    )
    ir = IncludeRole()
    ir.ROLE_NAMESPACE='role/'
    # The following has been created using the playbook test_IncludeRole_load
    expected_role_name = 'role/test_role'
    expected_task_name = "%s : %s" % (ir.action, expected_role_name)
    expected_role_path = 'tasks/test_role.yml'

# Generated at 2022-06-21 01:30:39.024642
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    ir._role_name = 'test'
    ir.name = 'test_name'
    assert ir.get_name() == 'test_name'

# Generated at 2022-06-21 01:30:46.819242
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    unit test for method load of class IncludeRole
    """
    import sys
    import os
    import tempfile
    import json
    from ansible.module_utils.six import string_types

    script_dir = os.path.dirname(__file__)
    sys.path.append(script_dir)
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Default values
    options = {'role': 'test_role', 'apply': {}}
    data = {}

# Generated at 2022-06-21 01:30:57.805423
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    p = Play().load({
        'name': 'test',
        'hosts': 'all',
        'roles': [
            {
                'role': 'foo',
                'vars': {'foo': 'bar'}
            }, {
                'role': 'bar',
                'vars': {'bar': 'baz'}
            }
        ]
    }, variable_manager=dict(), loader=None)
    assert p.roles
    # Test with a play

# Generated at 2022-06-21 01:32:22.157637
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import load_extra_vars
    from ansible.galaxy.collection_finder import CollectionFinder
    from ansible.galaxy.collection import CollectionRequirement
    from ansible.compat.tests import unittest

    host = Host('localhost')
    group = Group('all')
    group.add_host

# Generated at 2022-06-21 01:32:29.383178
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    AnsibleRoleTest: Test of constructor of class IncludeRole.
    """
    block = Block()
    role = Role()
    include_role = IncludeRole(block, role)

    assert include_role._allow_duplicates == True
    assert include_role._public == False
    assert include_role._role_name == None
    assert include_role._role_path == None

# Unit test get_name() method of class IncludeRole

# Generated at 2022-06-21 01:32:30.560222
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-21 01:32:34.622783
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Unit test for method get_block_list of class IncludeRole
    :return:
    '''

    # TODO: it is not known how to implement
    pass

# Generated at 2022-06-21 01:32:43.533759
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes
    import os
    import sys
    import pytest
    import json
    display = Display()
    my_loader = DataLoader()
    variable_manager = Variable

# Generated at 2022-06-21 01:32:53.930958
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    import ansible.playbook.role as pr
    ir = IncludeRole(role=pr.Role({}))
    assert isinstance(ir, IncludeRole)

    try:
        IncludeRole()
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert str(e) == 'role must be provided.'

    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir._rolespec_validate == False

    assert ir.BASE == ('name', 'role')
    assert ir.FROM_ARGS == ('tasks_from', 'vars_from', 'defaults_from', 'handlers_from')
    assert ir.OTHER_ARGS == ('apply', 'public', 'allow_duplicates', 'rolespec_validate')
    assert ir.VAL

# Generated at 2022-06-21 01:32:57.964351
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    myIncludeRole = IncludeRole()
    print(myIncludeRole.get_name())
    myIncludeRole.get_block_list()

# Generated at 2022-06-21 01:33:06.265166
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    test_role = Role(name='test_role',
            tasks=[
                Task.load({
                    'include_role': {
                        'name': 'include_role_1',
                        'tasks_from': 'tasks/main.yml',
                        'vars_from': 'vars/main.yml',
                        'defaults_from': 'defaults/main.yml',
                        'handlers_from': 'handlers/main.yml'
                        },
                    }),
                ])
    test_block = Block(role=test_role)
    test_block.load(None)

    # test_include_role
    test_include_role = test_

# Generated at 2022-06-21 01:33:12.982351
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(None,None,None)
    ir.name = 'test name'
    ir.action = 'test action'
    ir._role_name = 'test role name'
    if ir.get_name() != "test name" :
        print("Unit test for method get_name of class IncludeRole failed!")
    ir.name = None
    if ir.get_name() != "test action : test role name" :
        print("Unit test for method get_name of class IncludeRole failed!")


# Generated at 2022-06-21 01:33:22.981356
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook import Play
    from ansible.playbook import PlayContext

    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='local',
        gather_facts='no',
        tasks=[
            dict(
                action='include_role',
                args=dict(
                    name='test',
                )
            )
        ]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)
    block = play.compile()
    task = block.block[0].block[0]
    assert task.get_name() == "include_role : test"
