

# Generated at 2022-06-21 01:24:33.551196
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role = IncludeRole()
    include_role._parent_role = Role()
    include_role._parent_role.get_name = lambda : 'parent_role'
    include_role._parent_role._role_path = 'parent-role-path'
    params = include_role.get_include_params()

    assert params.get('ansible_parent_role_names') == ['parent_role']
    assert params.get('ansible_parent_role_paths') == ['parent-role-path']


# Generated at 2022-06-21 01:24:44.663175
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test with valid role name
    data = dict(
        name='foo_role',
        tasks_from='/some/path/foo_role/tasks/main.yaml',
    )
    ir = IncludeRole.load(data)
    assert ir.role_name == 'foo_role'

    # Test with missing role name
    data = dict(
        tasks_from='/some/path/foo_role/tasks/main.yaml',
    )
    try:
        ir = IncludeRole.load(data)
    except AnsibleParserError as e:
        assert 'is a required field for include_role' in str(e)

    # test public with include_role
    data = dict(
        task='foo_role',
        public='true'
    )

# Generated at 2022-06-21 01:24:56.321276
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ''' include_role.py:IncludeRole

        include_role
          - name: test.role_name
            public: True
            tasks_from: test.role_name/main.yml
            vars_from: test.role_name/vars/main.yml
            defaults_from: test.role_name/defaults/main.yml
            handlers_from: test.role_name/handlers/main.yml
            apply: meta: test_meta_dict
              file: /etc/ansible/test_file
    '''

    # TODO(jrjohnson): Improve test coverage.
    # TODO(jrjohnson): Add test coverage for AnsibleParserError.

    # Constructor tests

# Generated at 2022-06-21 01:25:07.981391
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
        tasks_from_path = "./unit_tests/library/ansible_collections/my_collection/roles/test_role/tasks/main.yml"
        vars_from_path = "./unit_tests/library/ansible_collections/my_collection/roles/test_role/vars/main.yml"
        defaults_from_path = "./unit_tests/library/ansible_collections/my_collection/roles/test_role/defaults/main.yml"
        handlers_from_path = "./unit_tests/library/ansible_collections/my_collection/roles/test_role/handlers/main.yml"


# Generated at 2022-06-21 01:25:19.761635
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    i_r1 = IncludeRole()
    i_r2 = i_r1.copy()
    assert i_r1.statically_loaded == i_r2.statically_loaded
    assert i_r1._from_files == i_r2._from_files
    assert i_r1._parent_role == i_r2._parent_role
    assert i_r1._role_name == i_r2._role_name
    assert i_r1._role_path == i_r2._role_path

    # different object id
    assert not hasattr(i_r1, '_attributes')
    i_r1._attributes = {}
    i_r2 = i_r1.copy()
    assert i_r1._attributes is not i_r2._attributes

    # different parent
   

# Generated at 2022-06-21 01:25:26.955463
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # test default constructors
    myincluderole = IncludeRole(block=None, role=None, task_include=None)
    assert myincluderole.args == {}
    assert myincluderole._role_name == None
    assert not myincluderole._role_path
    assert not myincluderole._parent_role
    assert myincluderole._allow_duplicates
    assert not myincluderole._public

    # test load
    myincluderole = IncludeRole(block=None, role=None, task_include=None)
    myincluderole.load(dict(name="myrole", tasks_from="./main.yml", vars_from="./vars.yml", apply=dict(become=True)))

# Generated at 2022-06-21 01:25:35.870630
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Prepare test
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins.loader import role_loader

    from ansible.playbook.block import Block

    import sys
    import os

    test_dir = os.path.dirname(__file__)
    test_config_dir = os.path.join(os.path.dirname(test_dir), 'config')
    test_data_dir = os.path.join(os.path.dirname(test_dir), 'unit', 'data')

    # Load

# Generated at 2022-06-21 01:25:39.953309
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole(block=None, role=None, task_include=None)
    print(type(ir))
    print(ir.args)
    print(ir._role_name)

# test_IncludeRole()

# Generated at 2022-06-21 01:25:49.047807
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
        IncludeRole: test load
    """
    template_variables = "template_variables"
    mock_VariableManager = "mock_VariableManager"
    mock_loader = "mock_loader"
    task_include = "task_include"
    args = {'name':'test', 'with_items': 'item1'}
    data = "data"
    block = "block"
    role = "role"
    ir = IncludeRole.load(data=data, block=block, role=role, task_include=task_include)
    assert ir.action == 'include_role'
    assert ir._role_name == 'test'
    assert ir.args == {'name':'test'}

    args = {'role':'test', 'vars': {'test1': 'test'}}
    ir

# Generated at 2022-06-21 01:25:55.096448
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    display.verbosity = 3
    yaml_data = """
    - include_role:
    """.format()

    try:
        include_role = IncludeRole.load(data=yaml_data, variable_manager=None, loader=None)
        assert False, 'Expected a failure here'
    except AnsibleParserError:
        pass

    yaml_data = """
    - include_role:
        name: test_role
        apply:
          tags:
            - tag1
            - tag2
        vars_from:
          - '{{ role_root }}/vars.yml'
        handlers_from: main.yml
      with_items:
        - '{{ role_root }}/tests/test1'
        - '{{ role_root }}/tests/test2'
    """.format()



# Generated at 2022-06-21 01:26:15.437093
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.plugins.callback import CallbackBase
    import os
    import yaml

    class CallbackModule(object):
        """
        dummy callback module
        """
        def __init__(self):
            self.a = "a"


# Generated at 2022-06-21 01:26:26.054273
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax', 'sudo_user', 'sudo'])

# Generated at 2022-06-21 01:26:34.251897
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Initializing an IncludeRole Object with null values
    block = None
    role = None
    obj = IncludeRole(block, role)

    # Create a new field attribute object
    field_attribute = FieldAttribute(isa='bool', default=True, private=True)
    obj._allow_duplicates = field_attribute

    # Checking the type of the object created
    assert isinstance(obj, IncludeRole)
    assert isinstance(obj._allow_duplicates, FieldAttribute)

# Generated at 2022-06-21 01:26:38.549704
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole(role=None, block=None, task_include=None)
    task.name = 'test_name'
    task._role_name = 'test_role'
    assert task.get_name() == 'test_name : test_role'

# Generated at 2022-06-21 01:26:39.237588
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-21 01:26:42.126451
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir._role_name = "test"

    # No name given => return role name
    assert ir.get_name() == "include_role : test"

    ir.name = "name"
    assert ir.get_name() == "name"

# Generated at 2022-06-21 01:26:46.568715
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_incl = TaskInclude()
    task = IncludeRole(block=block, role=role, task_include=task_incl)

    name = task.get_name()
    assert name == 'include_role : None'

# Generated at 2022-06-21 01:26:58.748356
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins.loader import action_loader, lookup_loader
    import ansible.constants as C

    # sample play to be compiled

# Generated at 2022-06-21 01:27:02.305754
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create a new IncludeRole object
    obj = IncludeRole(block=None, role=None, task_include=None)
    # Set name attribute of obj
    obj.name = 'test_name'
    # Call get_name method of obj
    obj.get_name()
    # Check if get_name matches expectations
    assert obj._role_name == 'test_name'
    # Check if get_name matches expectations
    assert obj.name == 'test_name'


# Generated at 2022-06-21 01:27:08.008351
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test1: Missing 'name' for include_role
    data = {
        'include_role': {
            'public': True,
            'apply': {
                'var1': 'value1',
                'var2': 'value2'
            }
        }
    }
    with pytest.raises(AnsibleParserError) as execinfo:
        IncludeRole.load(data)
    assert "name is a required field for include_role." in str(execinfo.value)

    # test2: Invalid option public
    data = {
        'include_role': {
            'name': 'role1',
            'public': True,
            'apply': {
                'var1': 'value1',
                'var2': 'value2'
            }
        }
    }

# Generated at 2022-06-21 01:27:22.197616
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test data, with a mix of 'role', 'name', and 'tags'
    data = dict(
        name="some.role1",
        apply=dict(
            tags=["some_tag", "other_tag"],
        ),
    )

    try:
        IncludeRole.load(data, loader=DictDataLoader())
    except AnsibleParserError as e:
        raise Exception('Exception when calling load: %s' % e)

# Generated at 2022-06-21 01:27:31.729196
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # object of class Block
    block = Block()
    # object of class Role
    role = Role()
    # object of class TaskInclude
    task_include = TaskInclude()

    # create object of class IncludeRole
    ir = IncludeRole(block, role, task_include)
    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir._rolespec_validate == True
    assert ir._from_files == {}
    assert ir._parent_role == role
    assert ir._role_name == None
    assert ir._role_path == None

    # ir._allow_duplicates == False
    ir = IncludeRole(block, role, task_include, allow_duplicates=False)
    assert ir._allow_duplicates == False
    ir.allow_duplicates = True

# Generated at 2022-06-21 01:27:43.841498
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import tempfile

    # Create a data loader and variable manager to be shared by all blocks.
    loader = DataLoader()
    variable_manager = VariableManager()

    # Create an inventory manager to be shared by all blocks.
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    # Create all the blocks that will be used in this test.
    block1 = Block

# Generated at 2022-06-21 01:27:48.969032
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition

    # build trytond role
    ri = RoleInclude()
    ri.name = 'tryton/ansible-role-trytond'
    ri.role = 'tryton.trytond'
    ri.parsed = True

    role_definition = RoleDefinition.load(ri, '', None, None, None)
    role_definition.init_paths('')

    # build trytond task
    data = {
        'include_role': {
            #'apply': {},
            'name': 'tryton.trytond'}
        }
    myblock = Block()
    mytask = IncludeRole.load(data, block=myblock, role=role_definition)

    blocks, handlers = mytask.get_block_

# Generated at 2022-06-21 01:28:01.342491
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='test1',
        public=True,
        tasks_from='file1',
        vars_from='file2',
        defaults_from='file3',
        handlers_from='file4',
        apply=dict(),
        rolespec_validate=True
    )
    ir = IncludeRole.load(data)
    # Verify that name and role parameters are not None (validation in load method)
    assert ir._role_name is not None

    # Verify that stored name and role parameters are equals
    assert ir._role_name == data['name']

    # Verify that validation works well for invalid keys

# Generated at 2022-06-21 01:28:07.955724
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    t = IncludeRole.load({'include_role': {'name': 'myrole'}})
    assert t.args == {'name': 'myrole'}
    assert t._role_name == 'myrole'
    assert t._from_files == {}
    assert t.public is False
    assert t._allow_duplicates is True
    assert t.apply is None

    t = IncludeRole.load({'include_role': {'name': 'some_role', 'apply': {}, 'vars': {}, 'tasks_from': 'a.yml', 'vars_from': {}, 'defaults_from': 'b.yml', 'handlers_from': 'c.yml', 'public': True, 'allow_duplicates': False}})

# Generated at 2022-06-21 01:28:10.288789
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    include_role = IncludeRole()
    assert isinstance(include_role, IncludeRole)


# Generated at 2022-06-21 01:28:18.159335
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Test the method load of class IncludeRole
    '''
    result = IncludeRole.load({'name': 'foo'})
    assert result._role_name == 'foo'
    result = IncludeRole.load({'role': 'foo'})
    assert result._role_name == 'foo'

    try:
        result = IncludeRole.load({'public': True})
    except AnsibleParserError as e:
        assert "Invalid options for include_role: public" in e.message
    try:
        result = IncludeRole.load({'apply': {}})
    except AnsibleParserError as e:
        assert "Invalid options for include_role: apply" in e.message

# Generated at 2022-06-21 01:28:27.217629
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """This is a test of creating object IncludeRole"""
    display.test_test_header('Create IncludeRole object')
    # base_dir
    base_dir = '/home/ansible/'
    # file_name
    file_name = 'nginx.yml'
    # display.test_test_header('Create IncludeRole object')
    # display.test_begin()
    t = IncludeRole(file_name, base_dir)
    display.test_case_name(file_name)
    display.test_test_name("IncludeRole")
    display.test_test_description("test_test_description")
    display.test_test_result(True)
    display.test_test_id("test_test_id")
    display.test_test_state("test_test_state")
    display.test_

# Generated at 2022-06-21 01:28:34.059480
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test'
    ir._parent = Block()
    ir._parent.name = 'block_name'
    assert ir.get_name() == "block_name : test"

    ir1 = IncludeRole()
    ir1.name = 'test'
    ir1._parent = None
    ir1.action = 'include_role'
    ir1._role_name = 'role_name'
    assert ir1.get_name() == "include_role : role_name"



# Generated at 2022-06-21 01:28:51.237983
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole()

    assert not ir._role_name
    assert not ir._from_files
    assert not ir._parent_role



# Generated at 2022-06-21 01:28:57.769210
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_IncludeRole = IncludeRole()
    test_IncludeRole.action = 'include_role'
    test_IncludeRole._role_name = 'test_role'
    test_IncludeRole.name = 'Test Task'

    assert test_IncludeRole.get_name() == 'Test Task'


# Generated at 2022-06-21 01:29:05.170049
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block('test_include_role', [], [])
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    ir._allow_duplicates = False
    ir._public = True
    ir._rolespec_validate = False
    ir._from_files = {'tasks': 'tasks_value', 'vars': 'vars_value', 'defaults': 'defaults_value', 'handlers': 'handlers_value'}
    ir._parent_role = 'test_parent_role'
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'

    new_me = ir.copy()

    assert new_me._allow_duplicates == ir._allow_du

# Generated at 2022-06-21 01:29:15.283126
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    pb_loader = ansible.plugins.loader.module_loader.ActionModuleLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-21 01:29:25.364524
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # simple test with valid test case (single role)
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    display.verbosity = 3
    variable_manager = VariableManager()
    loader = variable_manager._loader

    play_context = PlayContext()
    play_context._run_context = None

    # create parent role and set some values to inherit
    parent_role = Role()
    parent_role._role_name = 'the_parent_role'
    parent_role._role_path = 'the_parent_role_path'
    parent_role._metadata = {}
    parent_role._metadata.allow_duplicates = True

# Generated at 2022-06-21 01:29:35.150107
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    var_manager = DummyVars()
    include_role = IncludeRole.load(dict(name='include_role_1'), variable_manager=var_manager)
    assert include_role.get_include_params() == {'role_name': 'include_role_1', 'role_path': None}

    include_role = IncludeRole.load(dict(name='include_role_2'), variable_manager=var_manager)
    assert include_role.get_include_params() == {'role_name': 'include_role_2', 'role_path': None}

    parent_role = Role.load(dict(name='parent_role'), variable_manager=var_manager)
    include_role = IncludeRole.load(dict(name='include_role_3'), variable_manager=var_manager, role=parent_role)
   

# Generated at 2022-06-21 01:29:43.300969
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role = Role()

    role.name = "testrole"
    role._role_path = "/tmp/testrole"
    role._metadata = {}
    role._metadata['namespace'] = 'namespace'
    role._metadata['name'] = 'name'
    role._metadata['version'] = 'version'
    role._metadata['collection'] = 'collection'

    ir = IncludeRole(block=block, role=role)

    params = ir.get_include_params()

    print(params)


# Generated at 2022-06-21 01:29:54.202859
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # In this unit test, we set up some objects required by IncludeRole.load
    from ansible.playbook import Play, Playbook
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play.load(dict(
        name="a",
        hosts="all",
        gather_facts="no",
        roles=[dict(name="b", tasks=[dict(import_role=dict(name="my_role_name"))])]
    ), variable_manager=variable_manager, loader=loader)
    play.post_validate(play._ds, [])
    playbook = Playbook()
    playbook._entries.append(play)

# Generated at 2022-06-21 01:30:01.615081
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    loader=None
    variable_manager=None
    play=None
    from ansible.plugins.loader import task_loader
    ir = IncludeRole(role=None, task_include=TaskInclude.load({'include': 'test'}, task_loader=task_loader))
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'
    ir._parent_role = None
    result = ir.get_include_params()
    assert result['ansible_include_role_name'] == 'role_name'
    assert result['ansible_include_role_path'] == 'role_path'

# Generated at 2022-06-21 01:30:13.629981
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    def _load_data(data):
        ds = DataLoader()
        variable_manager = VariableManager()
        variable_manager.set_inventory(ds.load_inventory('localhost', variable_manager=variable_manager))
        return IncludeRole.load(data, variable_manager=variable_manager, loader=ds)

    i = _load_data({
        'include_role': {
            'name': 'foo'
        }
    })
    assert i._role_name == 'foo'
    assert i._parent_role is None
    assert i._role_path is None

# Generated at 2022-06-21 01:30:38.026471
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.template import Templar

    # test constructor
    p = IncludeRole()
    assert p._task_include is None
    assert p._role is None
    assert p._parent is None
    assert p._dep_chain == []
    assert p.name is None
    assert p.action == 'include_role'
    assert p.args == {}
    assert p.vars == {}
    assert p._role_name is None

# Generated at 2022-06-21 01:30:42.312765
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os.path
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task_include
    import ansible.playbook.role
    import ansible.playbook.block

    # Test data
    action = "include_role"  # action name
    args = dict(
        name = 'myrole',
    )
    variable_manager = ansible.playbook.variable_manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()

    # IncludeRole object from ansible.playbook.task_include.TaskInclude dependecy class
    #   this method does not have an integrated test

# Generated at 2022-06-21 01:30:44.089655
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.args = dict(name='role', role='role')
    assert ir.get_name() == 'role : role'

# Generated at 2022-06-21 01:30:49.381627
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    Test the IncludeRole method get_include_params
    """
    # build role structure
    role1 = Role()
    role1.name = 'role1'
    role1.vars = dict(a=1, b=2)

    role2 = Role()
    role2.name = 'role2'

    block1 = Block()
    block1.task_list = [
        dict(name='Task role1.1'),
    ]
    block2 = Block()
    block2.task_list = [
        dict(name='Task role2.1'),
    ]

    role1._compile_block_list = lambda _: [block1]
    role2._compile_block_list = lambda _: [block2]

    # Test when there is no parent role

# Generated at 2022-06-21 01:30:59.601191
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """IncludeRole.get_include_params() should return an empty dict if the
    include has no parent role. If it has a parent, then it should invoke
    get_role_params and add the name and path of its parent role."""
    include = IncludeRole()
    assert include.get_include_params() == {}

    parent = Role()
    parent.get_role_params = lambda: {'foo': 'bar'}
    parent.get_name = lambda: 'my_name'
    parent._role_path = '/my/path/my_name'
    include._parent_role = parent

# Generated at 2022-06-21 01:31:08.384764
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role = Role()
    role._role_name = "r1"
    role._role_path = "./r1"
    ir = IncludeRole(role=role)
    ir._role_name = "r2"
    ir._role_path = "./r2"
    ir._tasks = [{"action": "setup"}, {"action": "debug"}]
    ir._from_files = {"tasks": "tasks.yml"}
    new_ir = ir.copy(exclude_parent=True, exclude_tasks=True)

# Generated at 2022-06-21 01:31:13.342903
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.module_utils.six import iteritems

    # Load example data from fixture
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(include_role=dict(name='apache2'))),
        ]
    )

# Generated at 2022-06-21 01:31:23.900748
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
  '''
  Test the copy method of class IncludeRole.
  '''
  ir = IncludeRole(block=None, role=None, task_include=None)
  ir.action = 'include_role'
  ir.name = 'test_IncludeRole'
  ir.tags = ['role']
  ir.when = None
  ir.args = {
    'name': 'test_role',
    'apply': {
      'vars': {
        'key1': 'value1'
      }
    }
  }
  ir._tasks = list()
  ir._have_tasks = False

  new_ir = ir.copy(exclude_parent=False, exclude_tasks=False)
  assert new_ir.action == ir.action
  assert new_ir.name == ir.name
  assert new

# Generated at 2022-06-21 01:31:32.969278
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    example_data = {
        'role': 'setup_dummy_test',
        'name': 'dummy_role_name'
    }

    task_include = TaskInclude.load(example_data, loader=None, variable_manager=None, play=None)
    task_include_role = IncludeRole.load(example_data, loader=None, variable_manager=None, play=None)

    include_task_name = task_include.get_name()
    include_role_name = task_include_role.get_name()

    assert include_task_name == 'setup_dummy_test'
    assert include_role_name == 'dummy_role_name'

# Generated at 2022-06-21 01:31:43.893714
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    # Coding style
    import os
    import json
    try:
        from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    except ImportError:
        # Ansible <2.7
        from ansible.parsing.yaml.objects import AnsibleUnicode

        class AnsibleBaseYAMLObject(AnsibleUnicode):
            pass

        class AnsibleUnsafeLoader(object):
            @staticmethod
            def construct_yaml_seq(self, node):
                return AnsibleSequence(node.value)

            @staticmethod
            def construct_yaml_map(self, node):
                return AnsibleMapping(node.value)


# Generated at 2022-06-21 01:32:23.599597
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # setup a test task (we execute `setup_loader()`/`setup_args()` for testing)
    task_data = dict(name='test')
    task = IncludeRole.load(task_data)
    task.setup_loader()
    task.setup_args()

    # test with just a task
    t2 = task.copy()
    for k in task.args:
        assert task.args[k] == t2.args[k]

    # test with a task, a parent role but no parent block
    p_role = Role()
    t2 = task.copy(exclude_parent=True)
    for k in task.args:
        assert task.args[k] == t2.args[k]

    # test with a task, a parent role and a parent block
    p_block = Block()
   

# Generated at 2022-06-21 01:32:30.222088
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    data = dict(
        include_role="name={{role_path}}",
        args=dict(
            src="./files/{{role_name}}.tar.gz",
            dest="/var/lib/{{role_name}}.tar.gz",
        )
    )
    block = Block()
    role = Role()
    ir = IncludeRole(block=block, role=role)
    ir.load_data(data)




# Generated at 2022-06-21 01:32:31.032062
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    pass

# Generated at 2022-06-21 01:32:36.943591
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    def _import_module(name):
        assert name == "include_role"
        return IncludeRole

    with patch("ansible.parsing.mod_args.import_module", new=_import_module):
        assert IncludeRole.load({}).name == "include_role"

# Generated at 2022-06-21 01:32:43.714096
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    Tests that IncludeRole.get_include_params() returns expected values
    """

    class TestRole(Role):
        """
        Define a Role class derived from Role for testing purposes
        """
        def __init__(self, data=None, name='test_role'):
            super(TestRole, self).__init__(name=name)
            if data is not None:
                self._role_params = data


# Generated at 2022-06-21 01:32:53.957673
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    play = Play().load({'name': 'test play',
                        'hosts': 'all',
                        'roles': [{'name': 'test role'}]},
                        variable_manager=None, loader=None)
    play._included_file = '/path/to/testhost.yml'

    task = Task().load({'include_role': {'name': 'test role'}}, play=play, variable_manager=None, loader=None)

    IncludeRole.load(task._attributes, block=None, role=None, task_include=task,
                     variable_manager=None, loader=None)

    blocks, handlers = task.get_block_list()

    assert len(blocks) == 2
    assert len

# Generated at 2022-06-21 01:33:05.146465
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Make the test configuration mimic the runtime configuration
    C.DEFAULT_ROLES_PATH = '../test/units/library/ansible_playbook_test_block_list_includes/test_playbook'
    C.DEFAULT_PRIVATE_ROLE_VARS = False

    # import the role locally
    from ansible_playbook_test_block_list_includes.skeleton2.role2 import Role2

    # import the parent task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Set a fake ansible.vars to mimic the real one
    import ansible
    ansible.vars = { 'role2_var' : "role2_var_value" }

    # Create a fake play to test

# Generated at 2022-06-21 01:33:10.061241
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block1 = Block()
    role1 = Role()
    task_include1 = TaskInclude()
    testinstance = IncludeRole(block=block1, role=role1, task_include=task_include1)
    testinstance.load_data({},{})

# Generated at 2022-06-21 01:33:19.892622
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(task_include=TaskInclude(name='test_include')).get_name() == 'test_include'
    assert IncludeRole(role='test_role', task_include=TaskInclude(name='test_include', block=Block(parent=None))).get_name() == 'test_include'
    assert IncludeRole(role='test_role', task_include=TaskInclude(name=None, block=Block(parent=None))).get_name() == 'include_role : test_role'



# Generated at 2022-06-21 01:33:31.506478
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # get_block_list docstring
    """
    Return the list of blocks for this Task or TaskInclude object, after
    applying all inheritance rules.
    """

    # get_block_list implementation
    # 1. read info from playbook file and create playbook object:
    # p = Playbook.load('/Users/julius/my_playbook.yml', variable_manager=None, loader=None)
    # 2. read info from hosts file and create inventory object:
    # i = Inventory(loader=None, variable_manager=None, host_list='/Users/julius/ansible/hosts')
    # 3. create variable manager object:
    # variable_manager = VariableManager(loader=None, inventory=i)
    # 4. create datastructure to run:
    # tqm = None
    # try