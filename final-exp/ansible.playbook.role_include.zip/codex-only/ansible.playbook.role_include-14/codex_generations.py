

# Generated at 2022-06-23 07:05:47.946393
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # TODO: write this unit test asap
    pass

# Generated at 2022-06-23 07:05:59.283516
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars
    from collections import namedtuple

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    loader = DataLoader()
    variable_manager = VariableManager()
    playcontext = PlayContext(loader=loader, options=Options, variable_manager=variable_manager)


    host

# Generated at 2022-06-23 07:06:08.872631
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader
    ds = DataLoader()
    inv_data = """
    myhost ansible_connection=local
    """
    inv_obj = InventoryManager(ds, sources=[inv_data])
    # store these temporary objects in the cache
    ds.set_inventory_sources(inv_obj)

    # create play

# Generated at 2022-06-23 07:06:16.554495
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
  from ansible.playbook.role import Role
  from ansible.playbook.base import Base
  from ansible.template import Templar

  task = IncludeRole.load({'name': 'test_role'})
  task._block = Block.load({'name': 'TASK 1'}, None, None, None, None, None)
  task._parent_role = Role()
  task._parent_role._role_path = 'test_role_path'
  task._parent_role._parent = Base()
  task._parent_role._parent._play = Base()
  task._parent_role._parent._play._playbook = Base()
  task._parent_role._parent._play._playbook._loader = Base()
  task._parent_role._parent._play._playbook._loader._basedir = 'test_basedir'

 

# Generated at 2022-06-23 07:06:27.593007
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    IncludeRole: load()
    This is basically a copy of the actual load() method to unit test
    its functionality on the class.
    """
    # Define the data structure which is passed to load()
    data = {'apply': {}, 'name': 'a_role_name'}
    ir = IncludeRole()
    # Run the actual load() method
    ir.load(data)
    # Test the result
    assert ir._role_name == 'a_role_name'
    assert ir._allow_duplicates == True
    assert ir._public == False
    # Run the actual load() method
    data['public'] = True
    ir.load(data)
    # Test the result
    assert ir._allow_duplicates == True
    assert ir._public == True

# Generated at 2022-06-23 07:06:37.710180
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()

    ###############################################################################
    # Test for '- include_role: ...'

    # Scenario 1 - name is not specified
    # Expected Result: Raise an AnsibleParserError
    #                   msg: "'name' is a required field for include_role."
    data = {
        "action": "include_role",
    }

# Generated at 2022-06-23 07:06:48.393015
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = 1
    ir._from_files = {'tasks':'tasks.yml'}
    ir._parent_role = 1
    ir._role_name = 'test-role'
    ir._role_path = './test-role'
    ir._collections = ['test-collections']

    new_ir = ir.copy()
    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from_files == ir._from_files
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_name == ir._role_name
    assert new_ir._role_path == ir._role_path
    assert new_ir._collections == ir._collections

# Generated at 2022-06-23 07:06:59.654644
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.play import Play

    data = dict(
      name='test',
      hosts=['localhost'],
      gather_facts='no',
      roles=['testrole'],
      vars=[
        dict(
          foo=[1, 2],
          bar=[3, 4],
        ),
      ],
    )

    play = Play().load(data, variable_manager=None, loader=None)

    block = play.compile()

    task = block.block[0]

    task_copy_1 = task.copy()

    assert task_copy_1.name == 'test'
    assert task_copy_1.tags == set(['include_role'])
    assert task_copy_1.failed_when == []
    assert task_copy_1.when == 'True'
    assert task_

# Generated at 2022-06-23 07:07:10.455393
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Arrange
    class Role():
        def __init__(self):
            self._role_path = 'role_path'
            self._metadata = {'name': 'role_name'}
        def get_name(self):
            return self._metadata['name']

    class IncludeRole():
        def __init__(self):
            self._parent_role = Role()
    include_role = IncludeRole()
    # Act
    include_params = include_role.get_include_params()
    # Assert
    assert include_params['ansible_role_name'] is 'role_name'
    assert include_params['ansible_role_path'] is 'role_path'
    assert include_params['ansible_parent_role_names'] == ['role_name']

# Generated at 2022-06-23 07:07:15.949911
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    a = Block()
    b = RoleDefinition()
    c = IncludeRole(block=a, role=b)
    assert c._allow_duplicates == True
    assert c._public == False
    assert c._rolespec_validate == True


# Generated at 2022-06-23 07:07:21.748474
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
  from ansible.module_utils.six import PY3
  from ansible.playbook.block import Task
  from ansible.playbook.task import Task as AnsibleTask
  from ansible.playbook.task_include import TaskInclude as AnsibleTaskInclude
  from ansible.playbook.role.definition import Task as RoleTask
  from ansible.playbook.role.include import RoleInclude as AnsibleRoleInclude
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.play import Play
  from ansible.template import Templar
  import json, io, os
  if PY3:
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText as AnsibleUnsafeText
  else:
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-23 07:07:32.913610
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Unit test for method load of class IncludeRole
    '''
    vault_secrets = []
    loader, inventory, variable_manager = (None, None, None)
    in_action = 'include_role'
    name = 'some_name'
    namespace = 'some_namespace'
    file_name = 'some_file'
    data = {'action': in_action, 'name': name, 'namespace': namespace, 'file': file_name, 'apply': 'some_apply', 'public': False, 'allow_duplicates': False}

    p_block = Block(parent=None, role=None, task_include=None, use_handlers=False, always_run=True)

    ir = IncludeRole(block=p_block, task_include=None).load(data=data)


# Generated at 2022-06-23 07:07:33.474401
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-23 07:07:42.330606
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    ir = IncludeRole(role=Role(), task_include=TaskInclude())
    ir.name = "foo"
    ir._role_name = "bar"
    assert ir.get_name() == 'foo : bar'

    ir = IncludeRole(role=Role(), task_include=TaskInclude())
    ir._role_name = "bar"
    assert ir.get_name() == 'include_role : bar'


# Generated at 2022-06-23 07:07:56.079707
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys
    import os.path

    # root_loader = AnsibleFileLoader('')
    # collection_loader = CollectionLoader(root_loader)
    # role_loader = DataLoader()

    # We need a very simple module definition, so we just fake it.
    # The definition needs to be a class definition, so we provide it as a series of strings.

# Generated at 2022-06-23 07:08:03.718163
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Can't use builtin assertRaises here because it don't return any argument
    # pylint: disable=unused-argument
    # pylint: disable=no-member
    # pylint: disable=too-many-locals
    from ansible.playbook.task import Task
    from ansible.playbook.role import ROLE_CACHE, Role
    from ansible.template import Templar

    # Method load depends on Role (must have a parent role)
    # and on the method load_data of the class FieldAttribute
    # that depends on the class Play (must have a play)
    # and on the method load of the class FieldAttribute
    # that depends on the class Play (must have a play)
    # and on the method load of the class FieldAttribute
    # that depends on the class Play (must have a play)

# Generated at 2022-06-23 07:08:15.115789
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    class FakeRole(RoleMetadata):

        @classmethod
        def load(cls, name, play=None, variable_manager=None, loader=None, collection_list=None):
            return cls(name, None)

    def fake_get_host_vars(host):
        return {"hostvars_%s" % host: 1}


# Generated at 2022-06-23 07:08:22.572080
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole().get_name() == ": "
    assert IncludeRole(block=Block()).get_name() == ": "
    assert IncludeRole(role=Role()).get_name() == ": "
    assert IncludeRole(block=Block(), role=Role()).get_name() == ": "
    assert IncludeRole(task_include=TaskInclude("debug")).get_name() == "debug : "
    assert IncludeRole(block=Block(), role=Role(), task_include=TaskInclude("debug")).get_name() == "debug : "

# Generated at 2022-06-23 07:08:32.958249
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    # Constructor test without any arguments
    ir = IncludeRole()
    assert ir._role is None
    assert ir._block is None
    assert ir.statically_loaded is None
    assert ir._parent is None
    assert ir._from_files == {}
    assert ir._role_name is None
    assert ir._role_path is None

    # Constructor test with arguments
    play_context = PlayContext()
    block = Block()

# Generated at 2022-06-23 07:08:39.028448
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # pylint: disable=E0602, C0103
    irole = IncludeRole()
    record = irole.copy()
    assert (record.statically_loaded == irole.statically_loaded)
    assert (record._from_files == irole._from_files)
    assert (record._parent_role == irole._parent_role)
    assert (record._role_name == irole._role_name)
    assert (record._role_path == irole._role_path)


# Generated at 2022-06-23 07:08:50.304772
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    import os
    cwd = os.getcwd()

# Generated at 2022-06-23 07:08:59.473889
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    include_role: name=test
    """
    args = dict(
        name='test',
    )
    d = dict(
        action='include_role',
        args=args
    )
    include = IncludeRole.load(d)

    assert include._role_name == 'test'
    assert include.static_vars == {}
    assert include.role._metadata.name == 'test'
    assert include.role._metadata.allow_duplicates is True

    print("Constructor of class IncludeRole works well")


if __name__ == "__main__":
    test_IncludeRole()

# Generated at 2022-06-23 07:09:07.206158
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins.loader import role_loader

    ir = IncludeRole.load(dict(args=dict(name='foobar')), role=role_loader.get('foo', 'bar'))
    assert not ir.private

    ir = IncludeRole.load(dict(private=dict(hosts=dict(ansible_host='localhost'))), role=role_loader.get('foo', 'bar'))
    assert ir.private == {'hosts': {'ansible_host': 'localhost'}}

    ir = IncludeRole.load(dict(args=dict(rolespec_validate=True)), role=role_loader.get('foo', 'bar'))
    assert ir.rolespec_validate


# Generated at 2022-06-23 07:09:19.071577
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    b = Block()
    r = Role()
    ir = IncludeRole(block=b, role=r)
    ir.vars['foo'] = 'bar'
    ir._from_files['foofile'] = 'foorolefile'
    ir._parent_role = r
    ir._role_name = 'testrole'
    ir._role_path = '/path/to/testrole'
    ir.statically_loaded = True
    ir.allow_duplicates = True
    ir.public = True
    copied_ir = ir.copy()
    assert copied_ir.vars['foo'] == 'bar'
    assert copied_ir._from_files['foofile'] == 'foorolefile'
    assert copied_ir._parent_role == r
    assert copied_ir._role_name == 'testrole'


# Generated at 2022-06-23 07:09:19.676726
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-23 07:09:23.552947
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

  block = Block()
  role = Role()

  ir = IncludeRole(block, role)

  myplay = "play"
  variable_manager = "variable_manager"
  loader = "loader"

  result = ir.get_block_list(play=myplay, variable_manager=variable_manager, loader=loader)
  assert result == ([], [])

# Generated at 2022-06-23 07:09:36.476661
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.play_context import PlayContext

    task_include = TaskInclude()

    task_include.name = "include_tasks"
    assert task_include.name == "include_tasks"
    assert task_include.get_name() == "include_tasks : "

    task_include.action = "include_tasks"
    assert task_include.action == "include_tasks"
    assert task_include.get_name() == "include_tasks : "

    task_include.name = "include_tasks"
    assert task_include.name == "include_tasks"
    assert task_include.get_name() == "include_tasks : "


# Generated at 2022-06-23 07:09:38.300707
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir.get_name() == 'include_role : '



# Generated at 2022-06-23 07:09:48.994140
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest

    from ansible.module_utils._text import to_bytes

    class FakeRoleInclude(object):
        def __init__(self, name):
            self.name = name
            self.vars = {}

    class FakeRole(object):
        def __init__(self, name):
            self.name = name
            self.vars = {}

    class FakePlay(object):
        def __init__(self):
            self.roles = []

    class FakeVariableManager(object):
        def __init__(self):
            return

    class FakeLoader(object):
        def __init__(self):
            return

    fake_role_include = FakeRoleInclude("fake_role_name")
    fake_role = FakeRole("fake_role_name")
    fake_play = FakePlay()


# Generated at 2022-06-23 07:10:01.261661
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager('/etc/ansible/hosts', loader=loader)
    pbex = PlaybookExecutor(playbooks=['/etc/ansible/roles/dummy/tests/test.yml'],
                            inventory=inventory,
                            variable_manager=variable_manager,
                            loader=loader,
                            options=PlaybookExecutor.get_default_options(),
                            passwords={})

# Generated at 2022-06-23 07:10:06.026171
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert not ir.apply
    assert ir.allow_duplicates
    assert not ir.public
    assert ir.rolespec_validate
    assert not ir._parent_role
    assert ir._role_name is None
    assert ir._role_path is None


# Generated at 2022-06-23 07:10:18.411111
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    Test IncludeRole.get_include_params function
    """
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 07:10:24.156802
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import tempfile
    import shutil
    import sys
    import unittest

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-23 07:10:29.714232
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    ir = IncludeRole(block=block, role=role)
    ir.args = {'name':'test_role','role':'test'}
    assert ir.get_name() == "include_role : test_role"


# Generated at 2022-06-23 07:10:38.967109
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class FakeRole:
        def get_role_params(self):
            return {"k1": "v1"}

        def get_name(self):
            return "fake_role"

    class FakeParentRole:
        def get_role_params(self):
            return {"k1": "v1"}

        def get_name(self):
            return "fake_parent_role"

    ir = IncludeRole()

    # no parent role
    assert ir.get_include_params() == {}

    ir._parent_role = FakeParentRole()

    # no role_path
    assert ir.get_include_params() == {"k1": "v1", "ansible_parent_role_names": ["fake_parent_role"], "ansible_parent_role_paths": []}


# Generated at 2022-06-23 07:10:45.378555
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    role.name = 'myrole'
    task_include = IncludeRole(block=block, role=role)
    task_include.name = "toto"

    display.verbosity = 3
    res = task_include.get_name()
    assert res == "toto"

    task_include.name = None
    res = task_include.get_name()
    assert res == "include_role : myrole"
    display.verbosity = 0

# Generated at 2022-06-23 07:10:56.767576
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import mock
    import sys
    # Construct a mock play
    play = mock.Mock(base_vars={
        'a': 1,
        'b': 'foo'
    })

    # Mock a parent role to attach to it
    parent_role = mock.Mock()
    parent_role.get_role_params.return_value = {
        'c': 2,
        'd': 'bar'
    }

    # Construct a mock block to use for the task under test
    block = mock.Mock(child_blocks=[])
    block.get_vars.return_value = {
        'e': 3,
        'f': 'baz'
    }

    # Construct a mock variable maneger to use in the task under test
    variable_manager = mock.Mock()
    variable_manager.get_

# Generated at 2022-06-23 07:11:04.076981
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Test IncludeRole.load()

    """
    display.quiet()
    C.config.set_config_attr('DEFAULT_ROLES_PATH', '/tmp/')

    yaml_data = """
    - name: test_role,
    tasks_from: val1
    vars_from: val2
    """

    data = yaml.safe_load(yaml_data)
    ir = IncludeRole.load(data)

    assert ir._from_files == dict(tasks='val1', vars='val2')


# Generated at 2022-06-23 07:11:06.625902
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create the object IncludeRole and assign a value to the attribute '_role_name'
    ir = IncludeRole(role='mocked_role')
    ir._role_name = 'mocked_role_name'
    assert ir.get_name() == 'include_role : mocked_role_name'

# Generated at 2022-06-23 07:11:18.209024
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)

    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, TaskInclude)

    # Assert that all member variables are correctly initialized
    assert isinstance(ir._parent_role, Role)
    assert isinstance(ir._from_files, dict)
    assert isinstance(ir._role_name, (type(None), string_types))
    assert isinstance(ir._role_path, (type(None), string_types))

    # Assert that all default values are correctly initialized
    assert ir._rolespec_validate is True
    assert ir._allow_duplicates is True
    assert ir._public is False

# Generated at 2022-06-23 07:11:29.038653
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pb = Mock()
    myrole = Mock(spec=Role, _play=pb)
    myblock = Block()
    myblock.role = myrole
    myblock.role._parents = [myrole, myrole]
    myblock.role._metadata = Mock()
    myblock.role._path = "/dev/null"

    ir = IncludeRole()
    ir.name = "testrole"
    other_ir = ir.copy()

    assert ir.name == other_ir.name
    assert ir._rolespec_validate == other_ir._rolespec_validate
    assert ir._allow_duplicates == other_ir._allow_duplicates
    assert ir._public == other_ir._public
    assert ir._parent_role == other_ir._parent_role
    assert ir._from_files == other_

# Generated at 2022-06-23 07:11:39.459394
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test get_name method of class IncludeRole
    # init block object
    blockObj = Block()

    # Add task to block object
    taskObj = TaskInclude()
    blockObj.block = [taskObj]

    # Test task name is None
    incRoleObj = IncludeRole(block=blockObj)
    incRoleObj.action = 'IncludeRole'
    incRoleObj._role_name = 'testRole'
    actualResult = incRoleObj.get_name()
    expectedResult = 'IncludeRole : testRole'
    assert expectedResult == actualResult

    # Test task name is not None
    incRoleObj = IncludeRole(block=blockObj)
    incRoleObj.action = 'IncludeRole'
    incRoleObj.name = 'testRole'
    actualResult = incRoleObj.get_name()
    expected

# Generated at 2022-06-23 07:11:51.311061
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir1 = IncludeRole.load({'name': 'myrole'})
    assert ir1.get_name() == "myrole"

    ir1 = IncludeRole.load({'role': 'myrole'})
    assert ir1.get_name() == "myrole"

    ir1 = IncludeRole.load({'name': 'myrole', 'apply': 'all'})
    assert ir1.get_name() == "include_role : myrole"

    ir1 = IncludeRole.load({'role': 'myrole', 'apply': 'all'})
    assert ir1.get_name() == "include_role : myrole"

    ir1 = IncludeRole.load({'role': 'myrole', 'apply': 'failed'})
    assert ir1.get_name() == "include_role : myrole"


# Generated at 2022-06-23 07:12:01.482205
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import ansible.plugins.loader as plugin_loader

    collection_list = plugin_loader._get_collection_list('collections')
    templar_ctx = dict(loader=None, variable_manager=None, task=None, hostvars=None, collection_list=collection_list)

    # Create test role
    role_name = 'test_role'
    role_path = 'test/path'

    t = Role(name=role_name, collection_list=collection_list)
    t._role_path = role_path

    blocks, handlers = t.compile(play=None, dep_chain=None)

    # Create task
    i = IncludeRole()
    i._role_

# Generated at 2022-06-23 07:12:03.363172
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    display.display('UNIT TEST: %s' % __file__)

    # Constructor test:
    #      Expected result:
    #      - return object of IncludeRole
    assert IncludeRole(block=None, role=None, task_include=None)

# Generated at 2022-06-23 07:12:06.217937
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    data = {"name": 'test', "role": 'test_role'}
    ir = IncludeRole.load(data, '')
    assert ir._role_name == 'test_role'

# Generated at 2022-06-23 07:12:16.600016
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role.statically_loaded = True
    include_role._from_files = {}
    include_role._parent_role = role
    include_role._role_name = 'role_name'
    include_role._role_path = 'role_path'

    # Exclude parent and task
    new_me = include_role.copy(exclude_parent=True, exclude_tasks=True)
    assert new_me.statically_loaded == include_role.statically_loaded
    assert new_me._from_files == include_role._from_files
    assert new_me._parent_role == include_role._parent_role
    assert new_me._

# Generated at 2022-06-23 07:12:19.904512
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    pl = IncludeRole()
    assert pl.public == False
    assert pl.allow_duplicates == True
    assert pl.rolespec_validate == True

# Generated at 2022-06-23 07:12:28.040585
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.role.tasks import Task

    # test using a simple block
    r = Role()
    ir = IncludeRole(role=r)
    new_ir = ir.copy()

    assert ir == new_ir
    assert ir._parent_role == new_ir._parent_role
    assert ir._role_name == new_ir._role_name
    assert ir._role_path == new_ir._role_path
    assert ir._from_files == new_ir._from_files
    assert ir.statically_loaded == new_ir.statically_loaded

    # test using a block with children
    r = Role()
    r.tasks.append(Task())
    ir = IncludeRole(role=r)
    new_ir = ir.copy()



# Generated at 2022-06-23 07:12:35.166316
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    t1 = IncludeRole(role='role_a')
    t1._role_path = 'role_a/_main.yml'
    t1._role_name = 'role_a'
    t2 = t1.copy()
    assert t2.statically_loaded is True
    assert t2._role_path == 'role_a/_main.yml'
    assert t2._role_name == 'role_a'
    assert t2._from_files == {}



# Generated at 2022-06-23 07:12:45.613923
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os

    pb = os.path.join(os.path.dirname(__file__), "../../../test/playbooks/include_role_playbook.yml")
    display.verbosity = 3

# Generated at 2022-06-23 07:12:50.132864
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    ir = IncludeRole(block=block, role=role)

    assert ir.block == block
    assert ir.role == role

# Generated at 2022-06-23 07:12:50.999098
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:12:55.020804
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from pytest import raises

    play_ctx = PlayContext()
    block = Block()

    with raises(AnsibleParserError):
        ir = IncludeRole(block, task_include=None)
        ir.get_block_list(play=None)

# Generated at 2022-06-23 07:13:04.112326
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Good input
    task_name = 'test_role'
    include_role = IncludeRole()
    include_role._role_name = task_name
    assert include_role.get_name() == 'include_role : test_role'

    # Wrong input
    include_role._role_name = ''
    assert include_role.get_name() == 'include_role : ' or \
           include_role.get_name() == 'include_role :  ' or \
           include_role.get_name() == 'include_role :   '

# Generated at 2022-06-23 07:13:12.508298
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Creating a test Block
    block_obj = Block()
    block_obj._parent = True

    # Creating a test Role
    role_obj = Role()
    role_obj._role_params = {'test_key': 'test_value'}
    role_obj._parent = True

    # Creating a test IncludeRole
    inc_role_obj = IncludeRole(block=block_obj, role=role_obj)
    inc_role_obj.action = 'test_action'
    inc_role_obj.set_loader(None)
    inc_role_obj.vars = {'test_key': 'test_value'}

    # Calling get_include_params of IncludeRole
    inc_role_obj.get_include_params()

    # Retrieve from global dict
    include_params = inc_role_obj.include

# Generated at 2022-06-23 07:13:16.455071
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    import ansible.playbook.role
    import ansible.playbook.block
    block = ansible.playbook.block.Block()
    role = ansible.playbook.role.Role()
    ir = IncludeRole(block=block, role=role)
    assert isinstance(ir, IncludeRole)
    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir._rolespec_validate == True
    assert ir._from_files == {}
    assert isinstance(ir._parent_role, ansible.playbook.role.Role)
    assert ir._role_name is None
    assert ir._role_path is None


# Generated at 2022-06-23 07:13:24.057075
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    Unit test for constructor of class IncludeRole
    """
    # test no arguments passed
    with pytest.raises(TypeError) as excinfo:
        IncludeRole()
    assert "__init__() missing 1 required positional argument: 'role'" in str(excinfo.value)

    # test role argument passed
    fake_block = Block()
    fake_role = Role()
    ir = IncludeRole(role=fake_role)
    assert ir._parent_role == fake_role

# Generated at 2022-06-23 07:13:24.680075
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:13:33.752813
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    ir = IncludeRole(block=block, role=role)
    ir.name = 'role_name'
    ir.allow_duplicates = True
    ir.rolespec_validate = True
    ir.action = 'include_role'
    ir.statically_loaded = True
    ir.vars = dict(test_1 = '1')
    ir._from_files = dict(test_2 = '2')
    ir._parent_role = 'parent_role'
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'
    new_ir = ir.copy()
    assert new_ir.allow_duplicates is True
    assert new_ir.rolespec_validate is True

# Generated at 2022-06-23 07:13:44.376839
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    play_context = dict(
        basedir='.',
        verbosity=0,
        forks=C.DEFAULT_FORKS,
        become=None,
        become_method=None,
        become_user=None,
        remote_user=None,
        module_path=None,
        diff=False)
    loader = None
    play = Play().load({'name': 'test_play'}, variable_manager=VariableManager(), loader=loader)

    include_role = IncludeRole()

# Generated at 2022-06-23 07:13:54.546928
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    # create an instance of IncludeRole
    ir = IncludeRole()

    ir.name = None
    ir._role_name = 'nameless_role_name'
    assert ir.get_name() == 'nameless : nameless_role_name'

    ir.name = 'named_name'
    ir._role_name = 'nameless_role_name'
    assert ir.get_name() == 'named_name : nameless_role_name'

    ir.name = 'named_name'
    ir._role_name = 'named_role_name'
    assert ir.get_name() == 'named_name : named_role_name'

# Generated at 2022-06-23 07:14:08.077329
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.verbosity = 3
    import os
    import sys
    import tempfile
    import ansible.utils.module_docs as m_docs
    import ansible.utils.display as display
    import ansible.inventory.manager
    import ansible.playbook.play_context
    import ansible.playbook.role.definition
    import ansible.plugins
    import ansible.template

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser

    # preparing required objects
    fake_loader = DataLoader()
    fake_loader.set_basedir(tempfile.mkdtemp(prefix=""))
    fake_inventory = ansible.inventory.manager.InventoryManager(loader=fake_loader, sources="localhost")
    fake_variable_manager = ans

# Generated at 2022-06-23 07:14:18.822654
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Declare a mock of the task block_list
    class mock_Block:

        # Mock the name attribute
        @property
        def name(self):
            return 'Mock Block'

    # Create the task
    a = IncludeRole()

    # Create values for parametres
    play = 'Mock Play'
    variable_manager = 'Mock Variable Manager'
    loader = 'Mock Loader'
    expected_blocks = [mock_Block()]
    expected_handlers = ['Mock Handlers']

    # Expect that when parametres are called a certain way then the expected_blocks mut be returned
    a.get_block_list = MagicMock(return_value=(expected_blocks, expected_handlers))

    # Assert that the call to thr method with parameters returns the expected_blocks
    assert a.get_block

# Generated at 2022-06-23 07:14:31.043809
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    play = Play.load(dict(name='placeholder', roles=[]), variable_manager=VariableManager())
    role = RoleDefinition.load(dict(name='placeholder', tasks=[]), play=play)
    role._metadata = Role()

    ir = IncludeRole(task_include=Task(), role=role)
    assert ir.get_include_params() == dict(ansible_parent_role_names=['placeholder'],
                                           ansible_parent_role_paths=[u'placeholder'])



# Generated at 2022-06-23 07:14:41.990953
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """IncludeRole: get_name() => str"""
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)

    pb = Playbook()
   

# Generated at 2022-06-23 07:14:51.744891
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # dnf_block: Used to construct Block object
    # dnf_role:  Used to construct IncludeRole object
    # dnf_metadata: Variable to pass in get_block_list method
    dnf = dict()
    dnf["block"] = dict()
    dnf["block"]["dnf_package"] = dict()
    dnf["block"]["dnf_package"]["name"] = "dnf"
    dnf["block"]["dnf_package"]["state"] = "installed"
    dnf["role"] = dict()
    dnf["role"]["name"] = "dnf"
    dnf["role"]["dnf_package"] = dict()
    dnf["role"]["dnf_package"]["block"] = d

# Generated at 2022-06-23 07:14:52.373817
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-23 07:14:55.548501
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    try:
        ir = IncludeRole.load({'name':'testrole','vars_from':'testrole.yml'}, None)
        assert ir._role_name == 'testrole'
        assert ir._from_files['vars'] == 'testrole.yml'
    except Exception as err:
        assert False, "An exception was raised: %s" % err


# Generated at 2022-06-23 07:15:08.424156
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from units.mock.loader import DictDataLoader

    class MockDisplay(object):
        def display(self, *args, **kwargs):
            return

    display = MockDisplay()

    block = Block()

    ir = IncludeRole(block, None)
    ir._role_name = 'include_role_test'
    ir._role_path = 'include_role_test_path'

    # Create mock role
    role = Role()
    role._metadata = {'name': 'include_role_test'}
    role._role_path = 'include_role_test_path'

    # Create mock play
    play = {'hosts': 'all', 'roles': []}

    # Create mock variable_manager

# Generated at 2022-06-23 07:15:16.336329
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

        # Test get_name of IncludeRole with name being 'None'
        ir1 = IncludeRole()
        ir1.name = None
        ir1._role_name = 'common'
        assert ir1.get_name() == 'include_role : common'

        # Test get_name of IncludeRole with name being not 'None'
        ir2 = IncludeRole()
        ir2.name = 'testing'
        ir2._role_name = 'common'
        assert ir2.get_name() == 'testing'


# Generated at 2022-06-23 07:15:23.925946
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import pathlib
    import tempfile
    import ansible.executor.task_queue_manager
    import ansible.vars
    import ansible.inventory
    import ansible.module_utils.basic
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.template
    import ansible.utils.display
    import ansible.playbook.role
    import ansible.playbook.block

    temp_dir = tempfile.TemporaryDirectory()

    loader  = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.VariableManager()
    inventory = ansible.inventory.Inventory(loader, variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 07:15:36.133894
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import json
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    import pdb
    #pdb.set_trace()

    # inventory
    inventory = InventoryManager(loader=DataLoader(), sources='./tests/inventory_test.ini')
    # variable_manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    # play_context
    play_context

# Generated at 2022-06-23 07:15:45.203036
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    vars_manager = VariableManager()
    loader = 'ansible.parsing.dataloader.DataLoader'
    inventory = Inventory(loader,vars_manager, host_list=[])

# Generated at 2022-06-23 07:15:51.686283
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # pylint: disable=too-many-locals
    def _execute_playbook(playbook_path):
        pending_results = []
        task_queue_manager = TaskQueueManager(
            inventory=inventory,
            variable_manager=variable_manager,
            loader=loader,
            passwords={},
            stdout_callback='default',
        )

