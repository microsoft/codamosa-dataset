

# Generated at 2022-06-23 07:05:52.130557
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print(IncludeRole(Role(), "test", RoleInclude(role_name="foo")).get_name())
    print(IncludeRole(Role(), "test", RoleInclude(role_name="foo")).get_name())
    print(IncludeRole(Role(), "test", RoleInclude(role_name="")).get_name())
    print(IncludeRole(Role(), "name", RoleInclude(role_name="foo")).get_name())
    print(IncludeRole(Role(), "", RoleInclude(role_name="foo")).get_name())

if __name__ == '__main__':
    test_IncludeRole_get_name()

# Generated at 2022-06-23 07:05:59.565769
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """Testing IncludeRole.get_name"""

    # Case 1: no name and role
    include_role = IncludeRole()
    assert include_role.get_name() == "include_role : None"

    # Case 2: role not none and name is None
    include_role = IncludeRole(role='testing')
    assert include_role.get_name() == "include_role : testing"

    # Case 3: both name and role has a value
    include_role = IncludeRole(role='testing', name='name')
    assert include_role.get_name() == "name : testing"

# Generated at 2022-06-23 07:06:09.116632
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    ir = IncludeRole()
    ir._parent = Block()
    ir._parent._parent = Role()
    ir._role_name = 'my_role'
    ir._role_path = '/path/to/my_role'
    ir._from_files = {'tasks': 'tasks.yml', 'vars': 'vars.yml', 'defaults': 'defaults.yml', 'handlers': 'handlers.yml'}
    ir.apply = {'ignore_errors': 'True'}
    ir.public = True

    new_ir = ir.copy()
    assert ir is not new_ir
    assert ir._parent is not new_ir._parent
    assert ir._role_name == new_ir

# Generated at 2022-06-23 07:06:14.270964
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create an instance of IncludeRole and assert the name is set
    ir = IncludeRole(role=Role())
    ir._role_name = "fakeRole"
    assert ir.get_name() == "%s : %s" % (ir.action, ir._role_name), "IncludeRole: get_name was not set correctly"
# End of unit test for method get_name of class IncludeRole

# Generated at 2022-06-23 07:06:26.632147
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Load test_role and test_child_role (which is included in test_role)
    role_include = RoleInclude.load('test_role', None, None, None)
    test_role_actual = Role.load(role_include, None, None, None)
    role_include = RoleInclude.load('test_child_role', None, None, None)
    test_child_role_actual = Role.load(role_include, None, None, None)

    # Create two blocks (both are Tasks), one for test_role and one for test_child_role

# Generated at 2022-06-23 07:06:33.155704
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.plugins.loader as plugin_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    class Role:
        def __init__(self, name):
            self._name = name
            self._role_path = name
        def get_name(self):
            return self._name
        def get_role_params(self):
            return self._name

    class Play:
        def __init__(self):
            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._host_manager = InventoryManager()
            self.roles = []
            self.handlers = []


# Generated at 2022-06-23 07:06:45.870342
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook import Play
    from ansible.utils.vars import combine_vars

    class VariableManager(object):
        def __init__(self, inventory):
            self._host_vars_files = []
            self._group_vars_files = []
            self._inventory = inventory
            self._vars_cache = dict()

        def get_vars(self, play=None, task=None, host=None, include_hostvars=True, include_delegate_to=True):
            return dict()

    class CustomIncludeTask(IncludeRole):
        """
        A custom class for testing IncludeRole.get_include_params

        This class is used to be able to execute get_include_params:
        we need workflow to be set, and to have the constructor called
        """

# Generated at 2022-06-23 07:06:57.434588
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    var_manager = DummyVarsManager()
    loader = DummyLoader()
    display = DummyDisplay()
    data = {'include_role': './examples/roles/example1'}
    ir = IncludeRole.load(data, task_include=None, loader=loader, variable_manager=var_manager, display=display)
    ir._role_name='./examples/roles/example1'
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'tasks/main.yml'}
    ir._parent_role = 'TestParent'
    ir._role_name = 'TestRole'
    ir._role_path = 'TestRolePath'
    new_me = ir.copy(exclude_parent=False, exclude_tasks=False)
    assert new

# Generated at 2022-06-23 07:07:09.071692
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Mock of the class Block and its method get_vars
    class Block(object):

        def get_vars(self):
            return {'foo': 'bar'}

    # Mock of the class Role and its method get_vars
    class Role(object):

        def get_vars(self):
            return {'bar': 'foo'}

    # Mock of the class VariableManager and its method get_vars
    class VariableManager(object):

        def get_vars(self):
            return {'baz': 'baz'}

    # Mock of the class Loader and its method get_basedir
    class Loader(object):

        def get_basedir(self):
            return 'basedir'

    # Mock of the class Play and its method get_handler_blocks

# Generated at 2022-06-23 07:07:20.094501
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.role = "test role"
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'task.yaml',
                      'vars': 'var.yaml',
                      'handlers': 'handler.yaml'}
    ir._role_name = "test_role"
    ir._parent_role = Role(name="role_parent")
    ir._role_path = "/role/path/"

    new_ir = ir.copy()
    assert ir.role == new_ir.role
    assert ir.statically_loaded == new_ir.statically_loaded
    assert ir._from_files == new_ir._from_files
    assert ir._role_name == new_ir._role_name
    assert ir._parent_role == new_ir._parent_

# Generated at 2022-06-23 07:07:32.015557
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    inc_role = IncludeRole()
    inc_role._role_name = 'my_role'
    inc_role.action = 'include_role'
    assert inc_role.get_name() == 'include_role : my_role'

    inc_role = IncludeRole()
    inc_role._role_name = 'my_role'
    inc_role.action = 'import_role'
    assert inc_role.get_name() == 'import_role : my_role'


# Generated at 2022-06-23 07:07:38.833348
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Unit test for method load of class IncludeRole

    Unit test for method load of class IncludeRole with the following args: (data, block, role, task_include, variable_manager, loader)

    Returns:
      None

    """

    ################################################################################
    # IncludeRole.load() Execution
    ################################################################################

    # Execute the IncludeRole.load() method with valid arguments
    print('Testing IncludeRole.load() with valid arguments')

    # Mock the args needed by the IncludeRole.load() method
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # Execute the IncludeRole.load() method with valid arguments
    IncludeRole.load(data, block, role, task_include, variable_manager, loader)




# Generated at 2022-06-23 07:07:53.448493
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.ansible_api import AnsibleApi

    data = {'hosts': 'localhost', 'gather_facts': 'no', 'vars': {}, 'tasks': [{'action': 'meta', 'tasks': [], 'include_role': {'name': 'test', 'vars': {'myvar': 'myvalue'}}}]}
    play = AnsibleApi._do_create_play_from_data(data, VariableManager(), False)._entries[0]

    play.vars = {}
    play.extra_vars = {}

# Generated at 2022-06-23 07:08:00.088563
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)
    assert ir is not None

# Generated at 2022-06-23 07:08:08.815010
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Mock a Block
    block = Block()

    # Mock a Role
    role = Role()

    # Mock an IncludeRole object
    ir = IncludeRole(block, role)

    # Test the method copy
    new_me = ir.copy()

    assert new_me.statically_loaded == ir.statically_loaded
    assert new_me._from_files == ir._from_files
    assert new_me._parent_role == ir._parent_role
    assert new_me._role_name == ir._role_name
    assert new_me._role_path == ir._role_path

# Generated at 2022-06-23 07:08:12.957263
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block(play=None)
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)
    assert ir.get_name() == ": "
    ir.name = 'test'
    assert ir.get_name() == 'test'

# Generated at 2022-06-23 07:08:23.671455
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    vars_dict = {'var1': 'value1'}
    parent_role = Role()
    parent_role.vars = vars_dict
    parent_role._parents = []
    parent_role._role_name = "parent_role"
    parent_role._role_path = "./parent_role"
    include_role = IncludeRole(role=parent_role)
    include_role._parent_role = parent_role
    include_role.vars = vars_dict
    assert include_role.get_include_params() == {'var1': 'value1', 'ansible_parent_role_names': ['parent_role'], 'ansible_parent_role_paths': ['./parent_role']}

# Generated at 2022-06-23 07:08:33.524696
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_playbook_data = dict(
        hosts='all',
        roles='some_name',
        gather_facts='no',
        vars={
            'some_var': 'yes'
        },
        tasks=[]
    )
    runner = Playbook.load(test_playbook_data, loader=DictDataLoader(), variable_manager=VariableManager())
    test_include_data = dict(
        name='test_role'
    )
    from ansible.playbook.block import Block
    test_block = Block.load(data=dict(
        name='test_block',
        hosts='all',
        tasks=[
            test_include_data
        ]
    ), play=runner._play, task_include=None, role=None)

# Generated at 2022-06-23 07:08:34.166388
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-23 07:08:38.205236
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print('Testing method get_name()')
    test_obj = IncludeRole(block=None, role=None, task_include=None)
    result = test_obj.get_name()
    assert result == "include_role :"
    print('Method get_name() passed')

# Generated at 2022-06-23 07:08:46.951731
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Basic sanity test for IncludeRole class
    """
    import ansible.playbook.play

    parent_role = ansible.playbook.play.Role()
    task_include = TaskInclude()

    task = IncludeRole(role=parent_role, task_include=task_include)
    task.name = 'foo'
    assert task.get_name() == 'foo'

    task = IncludeRole(role=parent_role, task_include=task_include)
    task.name = None
    task._role_name = 'bar'
    assert task.get_name() == 'include_role : bar'

# Generated at 2022-06-23 07:08:50.305792
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    This testcase is to unittest the above method IncludeRole.get_block_list
    """
    pass

# Generated at 2022-06-23 07:09:01.568597
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
  import ansible.utils.module_docs as mud
  import ansible.module_utils.basic as mub
  import ansible.plugins.loader as pld
  import pprint
  import ansible.plugins.task as tsk
  import ansible.plugins.action as act
  import ansible.plugins.connection as con
  import ansible.template as tmp
  import ansible.vars as vrs
  import ansible.playbook.play_context as pcx
  import ansible.playbook.play as pla
  import ansible.playbook.role as role
  import ansible.playbook.block as blk
  import ansible.playbook.task_include as tki
  import ansible.playbook.included_file as inc
  import ansible.playbook.handler_task_include as hti
 

# Generated at 2022-06-23 07:09:14.201584
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    result = IncludeRole().get_include_params()
    assert 'ansible_parent_role_names' not in result
    assert 'ansible_parent_role_paths' not in result

    result = IncludeRole(role=Role()).get_include_params()
    assert result['ansible_parent_role_names'] == [None]
    assert result['ansible_parent_role_paths'] == [None]

    result = IncludeRole(role=Role('test')).get_include_params()
    assert result['ansible_parent_role_names'] == ['test']
    assert result['ansible_parent_role_paths'] == [None]

    result = IncludeRole(role=Role('test', _role_path='path/to/role')).get_include_params()

# Generated at 2022-06-23 07:09:25.671939
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    hostvars = {'host1' : 'host1'}
    ROLE_NAME = 'role-name'
    PARENT_ROLE_NAME = 'parent-role'
    PARENT_ROLE_PATH = '/path/to/parent/role'

    # Create variable manager
    variable_manager = ansible.vars.VariableManager()
    variable_manager._extra_vars = {'a': 1, 'b': 2, 'hostvars': hostvars}

    # Create fake role instance
    role = Role()
    role._role_name = ROLE_NAME
    role._role_path = '/path/to/role'

    # Create new IncludeRole instance
    include_role = IncludeRole()


# Generated at 2022-06-23 07:09:37.178815
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.parsing.dataloader import DataLoader
    display.verbosity = 3
    data_loader = DataLoader()
    variable_manager = None
    loader = None
    play = None
    data = dict(
        name='role-name',
        include_role=dict(name='role-name'),
        apply=dict(),
        public=True,
        allow_duplicates=True,
        rolespec_validate=False
    )
    role = Role.load(
        data=dict(name='role-name'),
        play=play,
        variable_manager=variable_manager,
        loader=loader
    )

# Generated at 2022-06-23 07:09:44.503255
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders, PluginLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars, load_options_vars

    display = Display()
    vault_secrets_file = os.path.join(os.path.dirname(__file__), 'data', 'test_vault.yml')

# Generated at 2022-06-23 07:09:56.929134
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    class MockRole(object):
        def __init__(self):
            self.name = "role_name"
            self.path = "path"
            self.context = "fake_context"
            self.dep_chain = "fake_dep"
            self.metadata = MockMetadata()
            self.collections = []
            self.statically_loaded = False
            self.tags = []
            self._cleaned_up = False
            self._parents = []
            self._tasks = []

    class MockBlock(Block):
        def __init__(self):
            self._parent = None
            self._play = MockPlay()
            self._role = MockRole()

    class MockPlay(object):
        def __init__(self):
            self.roles = []
            self.handlers = []

# Generated at 2022-06-23 07:10:03.952636
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import ansible.playbook.play

    test_name = 'Role name'
    test_action = 'Role action'
    test_args = dict(name=test_name, action=test_action)

    test_play = ansible.playbook.play.Play().load(dict(
        name="Test Play",
        hosts='all',
        gather_facts='no',
        tasks=[test_args]))

    task = test_play.compile()
    assert task[0].get_name() == 'Role name : Role name'

# Generated at 2022-06-23 07:10:12.562948
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.block import TaskBlock
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import task_loader

    ir = IncludeRole(Block.load(dict(), task_loader=task_loader), None)
    ir.name = "test"
    ir._role_name = "role_name"
    ir._from_files = { "tasks": "tasks.yml",
                       "vars": "vars.yml",
                       "handlers": "handlers.yml",
                       "defaults": "defaults.yml",
                       }
    ir._apply_attrs = {
        "static": [ "static_attribute" ],
        "with_items": [ "item_attribute" ],
    }
    blocks

# Generated at 2022-06-23 07:10:23.845591
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    task = TaskInclude()
    task._parent = 'test'
    task._static_vars = {'a': 1}
    task._args = {'a': 1, 'b': 2}

    role = Role()
    role._role_name = '1'
    role._role_path = 'path1'
    task._parent_role = role

    new_task = task.copy()
    assert new_task._parent == 'test'
    assert new_task._static_vars == {'a': 1}
    assert new_task._args == {'a': 1, 'b': 2}
    assert new_task._parent_role._role_name == '1'
    assert new_task._parent_role._role_path == 'path1'

# Generated at 2022-06-23 07:10:36.066728
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    # Setup
    block = Block()
    role = Role()
    ir = IncludeRole(block, role)
    ir.action = 'include_role'
    ir.statically_loaded = True
    ir._from_files = {'test_key': 'test_value'}
    ir._parent_role = 'test_role'
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'

    # Test
    new_me = ir.copy()

    # Verify
    assert new_me.action == 'include_role'
    assert new_me.statically_loaded is True
    assert new_me._from_files == {'test_key': 'test_value'}
    assert new_me._parent_role == 'test_role'
    assert new_

# Generated at 2022-06-23 07:10:37.882244
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: Implement real unit test
    pass

# Generated at 2022-06-23 07:10:40.629205
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole.load(dict(name='test'))
    assert include_role._role_name == 'test'


# Generated at 2022-06-23 07:10:52.056263
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Initialize
    ir = IncludeRole()

    ir.statically_loaded = True
    ir._from_files = {'var': 'test'}
    ir._parent_role = Role()
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'

    # Copy
    result = ir.copy()

    # Verify
    assert result is not None
    assert type(result) is IncludeRole
    assert result.statically_loaded is True
    assert result._from_files == {'var': 'test'}
    assert result._parent_role is not None
    assert type(result._parent_role) is Role
    assert result._role_name == 'test_role_name'
    assert result._role_path == 'test_role_path'


# Generated at 2022-06-23 07:11:03.579303
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # GIVEN a IncludeRole instance with a _parent_role attribute
    class MyObj(object):
        def __init__(self, name, path, depth=-1):
            self.name = name
            self.path = path
            self.depth = depth
            self.parent = None
            self._parents = []

        def get_name(self):
            return self.name

        def get_role_params(self):
            return {'ansible_role_name': self.name, 'ansible_role_path': self.path, 'ansible_role_depth': self.depth}

    obj = MyObj('role1', './role1')
    ir = IncludeRole(role=obj)

    # WHEN the method copy is called
    new_ir = ir.copy()

    # THEN the new instance must have:
   

# Generated at 2022-06-23 07:11:15.361420
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Define a bare RoleInclude
    ri_a = RoleInclude()

    # Define a bare Role
    r_a = Role()

    # Define a Role containing a RoleInclude, and vice versa
    ri_b = RoleInclude(role=r_b)
    r_b = Role(task_includes=[ri_b])

    # Test the behaviour of a bare IncludeRole
    ir_a = IncludeRole()
    assert ir_a.get_include_params() == {}

    # Test the behaviour of an IncludeRole with a RoleInclude (non-role) parent
    ir_b = IncludeRole(role=ri_a)
    assert ir_b.get_include_params() == {}

    # Test the behaviour of an IncludeRole with a RoleInclude with a Role as parent
    ir_c = IncludeRole

# Generated at 2022-06-23 07:11:26.644794
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    loader_mock = MagicMock()
    display_mock = MagicMock()

    context_args = dict(
        become=False,
        become_method=None,
        become_user=None,
        check_mode=False,
        connection='local',
        diff=False,
        forks=100,
        remote_user='root',
        timeout=10,
        vault_password=None,
    )

    context = PlayContext(**context_args)

    variable_manager = VariableManager()
    variable_manager.extra_vars = {"bar": "baz"}

    data = {"role": "test_role"}


# Generated at 2022-06-23 07:11:37.900452
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Test for loading an Inclusion role 
    '''

    # Construct the role
    role = IncludeRole.load({
        "name": "Common_Role",
        "defaults_from": "../../Common_Role/defaults/main.yml",
        "vars_from": "../../Common_Role/vars/main.yml",
        "tasks_from": "../../Common_Role/tasks/main.yml",
        "handlers_from": "../../Common_Role/handlers/main.yml",
        "tags": [],
        "apply": {}
    })

    # Check role is constructed correctly
    assert role._role_name == "Common_Role"
    assert role._from_files["defaults"] == "main.yml"
    assert role._from_files

# Generated at 2022-06-23 07:11:41.380379
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.playbook.role
    include_role = ansible.playbook.role.IncludeRole()
    params = include_role.get_include_params()
    assert params == {}
    # TODO: more tests

# Generated at 2022-06-23 07:11:53.219138
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Fake Block
    class Block(object):
        def __init__(self):
            self.module = "Block"
            self.name = "fake_name"
            self.args = dict(
                name="Block",
                test=True,
            )
        def __str__(self):
            return self.name

    # Fake Role
    class Role(object):
        def __init__(self):
            self.module = "Role"
            self.name = "fake_name"
            self.args = dict(
                name="Role",
                test=True,
            )

# Generated at 2022-06-23 07:12:01.474748
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = dict(
        name="role1",
        apply={"tags": "this"}
    )
    ir = IncludeRole.load(data, loader=None, variable_manager=None)
    ir.post_validate(loader=None, templar=None)

    # Validate options
    my_arg_names = frozenset(ir.args.keys())

    # name is needed, or use role as alias
    ir._role_name = ir.args.get('name', ir.args.get('role'))
    if ir._role_name is None:
        raise AnsibleParserError("'name' is a required field for %s." % ir.action, obj=data)

    if 'public' in ir.args and ir.action not in C._ACTION_INCLUDE_ROLE:
        raise AnsibleParser

# Generated at 2022-06-23 07:12:06.125921
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    real_block = Block()
    real_role = Role()
    test_Include = IncludeRole(block=real_block, role=real_role)

    # test for class attributes
    data = {'_role_name': None,
            '_role_path': None,
            '_allow_duplicates': True,
            '_public': False,
            '_rolespec_validate': True
            }
    for key,value in data.items():
        if not hasattr(test_Include, key):
            raise AssertionError("IncludeRole instance has no '%s' attribute" % key)

# Generated at 2022-06-23 07:12:15.709630
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    import sys
    import inspect
    import ansible.utils.ansible_search_path
    # This Module's path
    try:
        # Python 3
        this_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    except:
        # Python 2
        this_dir = os.path.dirname(inspect.getfile(inspect.currentframe()))
    # ansible/lib dir
    lib_dir = os.path.dirname(this_dir)
    # ansible/ dir
    lib_dir = os.path.dirname(lib_dir)
    # Add ansible/lib to sys.path
    sys.path.insert(0, lib_dir + "/lib")

# Generated at 2022-06-23 07:12:26.217992
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    dldr = DataLoader()
    varmgr = VariableManager(dldr)

    block = Block.load(dict(
            name='task block',
            tasks=[],
            authority='block author',
        ))

    role = Role.load(dict(
            name='test-role',
            tasks=[],
            handlers=[],
            defaults={},
            vars={},
            authority='role author',
        ))

    ctx = PlayContext()
    ctx.vars = dict()


# Generated at 2022-06-23 07:12:29.513928
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    irole = IncludeRole()
    assert irole.get_block_list() == ([], [])

# Generated at 2022-06-23 07:12:39.848488
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    def Mock_IncludeRole(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        include_role = IncludeRole(block, role, task_include=task_include)
        include_role.load_data(data, variable_manager=variable_manager, loader=loader)
        return include_role


# Generated at 2022-06-23 07:12:48.192614
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pb = IncludeRole()
    assert pb.get_include_params() == {}

    pb = IncludeRole()
    pb._parent_role = Role()
    assert (pb.get_include_params() == {'ansible_parent_role_names' : [None], 'ansible_parent_role_paths' : [None]})
    
    pb = IncludeRole()
    pb._parent_role = Role()
    pb._parent_role.set_name("parent_role_name")
    pb._parent_role._role_path = "parent_role_path"
    assert (pb.get_include_params() == {'ansible_parent_role_names' : ['parent_role_name'], 'ansible_parent_role_paths' : ['parent_role_path']})

# Generated at 2022-06-23 07:12:52.025194
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_task = IncludeRole()
    # Validate the output of get_include_params when the parent role is set to None
    assert include_task.get_include_params() == include_task.vars


# Generated at 2022-06-23 07:12:59.289422
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # create a sample role
    task_block = Block()
    parent_role = Role()
    task_include = IncludeRole(block=task_block, role=parent_role)
    task_include._role_name = 'rolex'
    task_include._role_path = '/home/rolex/tasks/main.yml'
    task_include.statically_loaded = False
    task_include._from_files = {
        'tasks': 'main.yml',
        'vars': 'main.yml',
        'handlers': 'main.yml',
        'defaults': 'main.yml',
    }
    task_include._parent_role = parent_role
    # copy the role
    task_include_copy = task_include.copy()
    # check the attributes
    assert task_

# Generated at 2022-06-23 07:12:59.939789
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-23 07:13:01.786256
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    Test the copy method of IncludeRole class
    """
    pass

# Generated at 2022-06-23 07:13:10.937044
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader as plugin_loader, module_loader
    from ansible.executor.task_result import TaskResult
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.config.manager import ConfigManager
    import ansible.constants as C
    from ansible.executor.play_iterator import PlayIterator

    pb = Playbook()
    pb.add_block(Block(block=dict(role=dict(name='myrole1')), role=Role()))
    pb.add_block(Block(block=dict(role=dict(name='myrole2')), role=Role()))
    pb.add_

# Generated at 2022-06-23 07:13:21.581292
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import shared_loader_obj
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    import pytest
    my_loader = DataLoader()
    my_inv = InventoryManager(loader=my_loader, sources=C.DEFAULT_HOST_LIST)
    my_variable_manager = VariableManager(loader=my_loader, inventory=my_inv)
    play_context = PlayContext(remote_user='root')

# Generated at 2022-06-23 07:13:25.688862
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = "test_role_name"
    assert ir.get_name() == "include_role : test_role_name"

    ir.action = "include_role"
    assert ir.get_name() == "include_role : test_role_name"

    ir.name = "test_include"
    assert ir.get_name() == "test_include"

# Generated at 2022-06-23 07:13:34.232088
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    play = {}
    block = Block()
    block._parent = play
    role = Role()
    role._role_path = '/tmp/roles/a_role'
    role._metadata = {'name': 'a_role'}
    role._parent_role = None
    role._parents = []
    ir = IncludeRole(block=block, role=role)
    params = ir.get_include_params()
    assert params == {'ansible_parent_role_names': [], 'ansible_parent_role_paths': ['/tmp/roles/a_role']}

    role2 = Role()
    role2._role_path = '/tmp/roles/a_role2'
    role2._metadata = {'name': 'a_role2'}
    role2._parent_role = role
    role

# Generated at 2022-06-23 07:13:44.750999
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test include_role with only module option 'name'
    data = {'include_role': {'name': 'test_include_role'}}
    include_role = IncludeRole.load(data)
    assert include_role._role_name == 'test_include_role'
    assert include_role._from_files == {}
    assert include_role._parent_role == None
    assert include_role._role_path == None
    assert include_role._allow_duplicates == True
    assert include_role._public == False
    assert include_role._rolespec_validate == True

    # Test include_role with module option 'role'
    data = {'include_role': {'role': 'test_include_role'}}
    include_role = IncludeRole.load(data)
    assert include_role._role_name

# Generated at 2022-06-23 07:13:48.744593
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    a = IncludeRole()
    a._role_name = "test_name"
    a.action = "include_role"
    assert a.get_name() == "include_role : test_name"

# Generated at 2022-06-23 07:13:55.108266
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Tested method: get_block_list
    # Tested class: IncludeRole

    # Tested function with arguments: (play, variable_manager, loader)

    # Tested function with arguments: (play, variable_manager, loader)
    ###################################################################################################################
    """
    In this test, it is verified if the method get_block_list works correctly given a valid instance of class IncludeRole.
    """
    display.display("########## Start test of method get_block_list of class IncludeRole ##########")

    # Create an IncludeRole object
    role_obj = IncludeRole()

    # Create a dict to build the get_block_list function
    # Create a dict to be used to build the function
    test_dict = dict()
    test_dict['name'] = 'test_role'

# Generated at 2022-06-23 07:14:06.393128
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    hostvars = dict(ansible_hostname='hostname')
    role_name = "role1"
    role = Role.load(role_name, variable_manager={}, loader={}, hostvars=hostvars)
    task_name = "task1"
    task_action = "action1"
    task_include_name = "include_role"
    task_include = IncludeRole.load({
        'include': task_include_name,
        'name': task_name,
        'name': role_name
    }, block=None, role=role, task_include=None)
    assert task_include._role_name == role_name

# Generated at 2022-06-23 07:14:17.297251
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.collections.ansible.misc.tests.unit.compat.mock import Mock

    class MockTaskInclude(Mock):

        _tasks = [Mock(vars={'my_var': '{{ my_var }}'})]

        def get_include_params(self):
            return {'my_var': 'my_var'}

    task_include = MockTaskInclude()
    play_context = PlayContext()
    loader = DataLoader()
    variable_

# Generated at 2022-06-23 07:14:28.969075
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block(parent_block=None)
    role = Role()
    ir = IncludeRole(block=block, role=role)

    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, TaskInclude)
    assert isinstance(ir, Block)
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True
    assert ir._role_name is None
    assert ir._role_path is None

    # Allow duplicates
    ir = IncludeRole(block=block, role=role, task_include=False, allow_duplicates=True)
    assert ir._allow_duplicates is True

    # Not allow duplicates

# Generated at 2022-06-23 07:14:38.100733
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(loader=DataLoader(), variable_manager=variable_manager, host_list='tests/inventory'))
    loader = DataLoader()
    play = Play()
    ir = IncludeRole()
    ir.name = None
    ir._role_name = 'no_dependencies'
    ir._from_files = {}
    ir._parent_role = None
    ir.loader = loader
    ir.variable_manager = VariableManager()

# Generated at 2022-06-23 07:14:48.831928
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import task_loader, lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    
    from ansible.parsing.dataloader import DataLoader

    playbook = Playbook.load(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader()), variable_manager=VariableManager(), loader=DataLoader())
    
    play_context = PlayContext(play=playbook, options=None, passwords=dict())
    
    assert(play_context != None)
    
    block_list = []
    task_list = []
    

# Generated at 2022-06-23 07:14:51.805920
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole('name')
    assert ir.get_name() == "name"
    ir = IncludeRole()
    assert ir.get_name() == "include_role : None"


# Generated at 2022-06-23 07:15:00.485770
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # TEST 1
    block = Block()
    role = Role()
    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.name = 'my_name'
    task_include.role = 'my_role'
    ir = IncludeRole(block, role, task_include=task_include)
    assert ir.get_name() == 'my_name : my_role'
    # TEST 2
    block = Block()
    role = Role()
    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.role = 'my_role'
    ir = IncludeRole(block, role, task_include=task_include)
    assert ir.get_name() == 'include_role : my_role'

# Unit test

# Generated at 2022-06-23 07:15:12.113709
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """ test_IncludeRole_copy: test copy method of IncludeRole """

    from ansible.playbook.role import ROLE_CACHE
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import os

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 07:15:22.032653
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ''' Usage: python3 -c "exec(open('./test/units/include_role.py').read())" '''
    import sys
    import os
    import json
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role import Role

# Generated at 2022-06-23 07:15:23.462182
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    #TODO
    pass

# Generated at 2022-06-23 07:15:35.597663
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    display.verbosity = 3
    block = Block()
    role = Role()
    play = Play().load({}, variable_manager={}, loader=None)
    task_include = TaskInclude()
    task1 = IncludeRole.load({'name': 'fake_name',
                        'vars_from': 'fake_vars_from'},
                        block=block, role=role, task_include=task_include)
    assert task1._allow_duplicates == True, "_allow_duplicates must be 'True'"
    assert task1._public == False, "_public must be 'False'"
    assert task1._rolespec_validate == True, "_rolespec_validate must be 'True'"

# Generated at 2022-06-23 07:15:36.322590
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:15:44.902810
# Unit test for method get_block_list of class IncludeRole