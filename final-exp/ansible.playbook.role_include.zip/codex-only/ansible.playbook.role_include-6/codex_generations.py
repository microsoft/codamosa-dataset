

# Generated at 2022-06-23 07:05:54.434917
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # no parent role
    ir = IncludeRole()

    # test output with no parent
    v = ir.get_include_params()
    assert not v

    # mock parent role
    class MockRole(object):
        def get_role_params(self):
            return {'mock': 'role'}

        def get_name(self):
            return 'mock_role'

    # mock _role_path
    ir._role_path = 'role_path'

    # test output with parent
    ir._parent_role = MockRole()
    v = ir.get_include_params()
    assert v['role_params']['mock'] == 'role'
    assert v['ansible_parent_role_names'] == ['mock_role']

# Generated at 2022-06-23 07:06:01.522375
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole(role=None, task_include=None, block=Block.load(data=dict(
        name="include_role_test",
        tasks=[
            dict(
                name="include_role_test_task1",
                include_role=dict(
                    name="test_role_include_task1",
                    tasks_from="tasks.yml"
                )
            ),
            dict(name="include_role_test_task2")
        ]
    ), parent_block=dict()))


# Generated at 2022-06-23 07:06:10.574611
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    block = Block()
    role = Role()

    task_include = TaskInclude()

    my_data = dict(
        name = "test"
    )

    # test load of class IncludeRole
    my_include_role = IncludeRole.load(
        data = my_data,
        block = block,
        role = role,
        task_include = task_include,
        variable_manager = None,
        loader = None
    )

    assert my_include_role == my_include_role

# Generated at 2022-06-23 07:06:17.768760
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    x = IncludeRole(role=Role())
    v = x.get_include_params()
    assert v == {}, "IncludeRole.get_include_params() failed."

    y = IncludeRole(role=Role())
    z = IncludeRole(role=y)
    v = z.get_include_params()
    assert v == {'ansible_parent_role_names': ['<unknown>'],
                 'ansible_parent_role_paths': ['<unknown>']}, "IncludeRole.get_include_params() failed."

    y = IncludeRole(role=Role(name='xyz', role_path='path_xyz'))
    z = IncludeRole(role=y)
    v = z.get_include_params()

# Generated at 2022-06-23 07:06:19.789503
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole().get_name() == "TASK"

# Generated at 2022-06-23 07:06:24.777674
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    my_test_vars = dict(foo="foo", bar="bar")
    my_parent_role = Role()
    my_parent_role.vars.update(my_test_vars)

    my_include_role = IncludeRole()
    my_include_role._parent_role = my_parent_role
    ansible_parent_role_names = []
    ansible_parent_role_paths = []

    include_params = my_include_role.get_include_params()
    assert include_params['foo'] == "foo"
    assert include_params['bar'] == "bar"
    assert include_params['ansible_parent_role_names'] == ansible_parent_role_names
    assert include_params['ansible_parent_role_paths'] == ansible_parent_role_paths

   

# Generated at 2022-06-23 07:06:25.724121
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # FIXME: How to test this class?
    pass

# Generated at 2022-06-23 07:06:32.782254
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    loader = DictDataLoader({
        "roles/test/meta/main.yml": """
---
dependencies: []
"""})
    variable_manager = VariableManager()

    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))
    tqm = TaskQueueManager(
        inventory=variable_manager.inventory,
        variable_manager=variable_manager,
        loader=loader,
    )

# Generated at 2022-06-23 07:06:45.652328
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    ir_test = IncludeRole(block=Block(), role=RoleDefinition())
    ir_test.args = {'role': 'foo', 'other1': 'this1', 'other2': 'that', 'other3': 'another'}
    ir_test.statically_loaded = False
    ir_test.action = 'include_role'

    # Build fake data
    ir_test._parent = Play()
    ir_test._role_name = 'foo'

    play = Play()
    play.roles = [RoleDefinition()]

    # Build fake Task
    task = Task()
    task._role = RoleDefinition()
   

# Generated at 2022-06-23 07:06:55.153667
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    args = {'tasks': 'tasks', 'vars': 'vars', 'defaults': 'defaults', 'handlers': 'handlers'}
    h = IncludeRole(block=Block(), task_include=TaskInclude(block=Block()), role=Role(block=Block()))
    h._role_name = "test_role"
    assert h.get_name() == "include_role : test_role"
    h._from_files = args
    assert h.get_name() == "include_role : test_role"
    h.name = "test"
    assert h.get_name() == "test"

# Generated at 2022-06-23 07:06:56.146495
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole()

# Generated at 2022-06-23 07:07:01.573764
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader, action_loader


# Generated at 2022-06-23 07:07:08.561794
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    This unit test is to check method get_name of class IncludeRole.
    :return:
    """
    # Create an object of class IncludeRole
    ir = IncludeRole()
    assert ir.get_name() == ": "

    # Create an object of class IncludeRole
    ir = IncludeRole(name="name1")
    assert ir.get_name() == "name1: "

    # Create an object of class IncludeRole
    ir = IncludeRole(role="role1")
    assert ir.get_name() == ": role1"

# Generated at 2022-06-23 07:07:09.915450
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass


# Generated at 2022-06-23 07:07:20.534917
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    v = {
        "ansible_collection_name": "b.c.d",
        "ansible_collection_version": "2.3.4",
        "ansible_playbook_python": "/usr/bin/python",
        "ansible_host": "hostname",
        "ansible_version": {"full": "1.2.3"},
        "ansible_python": {"executable": "/usr/bin/python3", "version": {"major": 3, "minor": 5, "patch": 0}, "bits": 64, "full_version": "3.5.0"},
    }
    ri = RoleInclude()
    ri._metadata = Role()
    ri._metadata.name

# Generated at 2022-06-23 07:07:25.337725
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    block = Block(play=None, role=None)
    role = Role(name='test_IncludeRole', collection_list=None, loader=None)
    task_include = TaskInclude(block=block, role=role)
    task_include.action = 'include_role'
    task_include.args = {'role': 'test_role'}

    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    assert include_role.get_name() == 'include_role : test_role'

# Generated at 2022-06-23 07:07:35.270883
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    This tests that the method IncludeRole.get_include_params of class IncludeRole works as expected
    """
    class FakeRole:
        def __init__(self, _role_name, _role_path):
            self._role_name = _role_name
            self._role_path = _role_path
        def get_name(self):
            return self._role_name
        def get_role_params(self):
            return {'role_path': self._role_path}

    #create a fake include role
    ir = IncludeRole()
    ir._parent_role = FakeRole('parent', '/parent/path')
    ir._role_name = 'role_name'
    ir._role_path = '/role/path'
    ir.vars = {
        'var1': 'value1'
    }

# Generated at 2022-06-23 07:07:50.767966
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    class fake_block:
        def __init__(self):
            self.name = None
            self.block = None

    class fake_collection:
        def __init__(self, namespace, name):
            self.namespace = namespace
            self.name = name
            self.subcollections = dict()

    class fake_play:
        def __init__(self):
            self.roles = []

    class fake_variable_manager:
        def __init__(self):
            self.vars = dict()

    class fake_loader:
        def __init__(self):
            self.loaders = []

        def get_basedir(self, path):
            return path

    for i in range(3):
        # create test data
        data = {}
        data['name'] = 'my_role'
       

# Generated at 2022-06-23 07:07:55.152719
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    assert ir.get_name() == "include_role : "
    ir.name = "name"
    assert ir.get_name() == "name"
    ir.name = None
    ir._role_name = "role_name"
    assert ir.get_name() == "include_role : role_name"

# Generated at 2022-06-23 07:08:03.590060
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # test case where parent role is present
    ir = IncludeRole()
    ir._role_name = 'test-role'
    ir._role_path = 'path/to/test-role'
    ir._parent_role = Role()
    ir._parent_role._role_path = 'path/to/parent-role'
    ir._parent_role.name = 'parent-role'
    ir.name = 'name'
    expected = {
        'ansible_role_name': 'name',
        'ansible_role_path': 'path/to/test-role',
        'ansible_parent_role_names': ['parent-role'],
        'ansible_parent_role_paths': ['path/to/parent-role']
    }
    assert expected == ir.get_include_params()

    # test case

# Generated at 2022-06-23 07:08:07.073618
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Testing IncludeRole.get_block_list
    """
    #testing method without input params
    assert IncludeRole().get_block_list()

# Generated at 2022-06-23 07:08:16.742866
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    # block = None and valid action
    include_role = IncludeRole()
    include_role.action = 'include_role'
    include_role._role_name = 'RoleName'
    assert 'include_role: RoleName' == include_role.get_name()

    # block = None and invalid action
    include_role.action = 'include'
    assert 'include_role : RoleName' == include_role.get_name()

    # block = 'block' and valid action
    include_role.action = 'include_role'
    block = Block()
    block.name = 'BlockName'
    include_role.block = block
    assert 'BlockName : include_role: RoleName' == include_role.get_name()

    # block = 'block' and invalid action
    include_role.action = 'include'


# Generated at 2022-06-23 07:08:29.139852
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders

    loader = get_all_plugin_loaders()
    play_context = PlayContext()

    #Testing with a simple role
    block = {
        'include_role': {
            'name': 'ir_test_role'
        }
    }
    ir = IncludeRole(block=block)
    (blocks, handlers) = ir.get_block_list(loader=loader, play=None, variable_manager=None)
    assert(len(blocks) == 1)
    assert(blocks[0]['tasks'][0]['action']['msg'] == 'hello')

    #Testing with a role that includes a role

# Generated at 2022-06-23 07:08:39.562155
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.role.meta import RoleMeta

    meta = RoleMeta()
    block = Block(play=Play().load(dict(name="IncludeRole test")))
    role_def = RoleDefinition(name="test_role", filename="test_role.yml", repository_name=None, scm_revision=None, scm=None,
                              path="path/to/roles/test_role", parent_role=None, Collections=None,
                              play=Play().load(dict(name="RoleDefinition test")))
   

# Generated at 2022-06-23 07:08:50.896031
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    host = Inventory("", loader)
    host.parse_inventory(['localhost'])

    host_vars = HostVars(
        host=host,
        inventory=host,
        connection='local',
        loader=loader,
        play_context=PlayContext()
    )


# Generated at 2022-06-23 07:09:01.938169
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import os
    import shutil
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.add_inventory(inventory)
    playbook_path = C.DEFAULT_PLAYBOOK_PATH_IOS
    pb = Play

# Generated at 2022-06-23 07:09:14.247518
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # No grand parents
    ir = IncludeRole(role=Role())
    v = ir.get_include_params()
    assert v['ansible_role_names'] == []
    assert v['ansible_role_paths'] == []

    # One grand parent
    r1 = Role()
    r1._role_name = "one"
    r1._role_path = "one"
    ir = IncludeRole(role=r1)
    v = ir.get_include_params()
    assert v['ansible_role_names'] == ["one"]
    assert v['ansible_role_paths'] == ["one"]

    # Two grand parents
    r2 = Role()
    r2._role_name = "two"
    r2._role_path = "two"

# Generated at 2022-06-23 07:09:25.060563
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    loader = None
    oRole = Role()
    oRoleDefinition = RoleDefinition("ansible_test", oRole, loader)
    oRole.definition = oRoleDefinition
    oBlock = Block(oRoleDefinition, [])
    oIncludeRole = IncludeRole(oBlock)
    oIncludeRole.name = None
    oIncludeRole.action = "action of role include"
    oIncludeRole._role_name = "roledefinition name of role include"
    assert oIncludeRole.get_name() == "action of role include : roledefinition name of role include"

# Generated at 2022-06-23 07:09:36.974515
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    display.verbosity = 3
    # make sure name is required
    data = dict(
        role='foo'
    )
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    assert IncludeRole.load(data, block, role, task_include, variable_manager, loader)._role_name == 'foo'

    data = dict(
        role='foo'
    )
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    assert IncludeRole.load(data, block, role, task_include, variable_manager, loader)._role_name == 'foo'

    data = dict(
        name=False
    )
    block = Block()
   

# Generated at 2022-06-23 07:09:44.363496
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.block import Task

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    play_context = {}
    loader = True
    variable_manager = True

    # set up task
    block = Block()
    t = Task(block=block)
    t.action = 'include_role'
    t.args = {'name': 'tests.units.playbook.role_units', 'tasks_from': 'main.yml'}

    # set up role
    role = Role()
    role.name = 'tests.units.playbook.role_units'
    role.default_vars = {'a': 'A'}
    role.vars_files = ['group_vars/all']

# Generated at 2022-06-23 07:09:55.166150
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.compat.tests.mock import patch
    with patch("ansible.playbook.role.Role._load_role") as mock_load_role:
        mock_load_role.return_value = Role()
        ri = RoleInclude.load("test_role_name")
        ir = IncludeRole(role=ri)
        res = ir.get_include_params()
        assert res == {'ansible_parent_role_names': ['test_role_name'], 'ansible_parent_role_paths': ['.']}

# Generated at 2022-06-23 07:10:01.056942
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = {'include': 'somemodule'}
    includeRole = IncludeRole.load(data)
    assert includeRole.static
    assert includeRole.action == 'include'
    assert includeRole.args == {'include': 'somemodule'}
    assert includeRole.role is None
    assert includeRole.block is None


# Generated at 2022-06-23 07:10:11.115682
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """Unit test to validate IncludeRole.get_include_params() method"""
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager._options['role_paths'] = ['..']
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))

    from ansible.playbook import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            'include_role',
        ]
    )

# Generated at 2022-06-23 07:10:23.723901
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import yaml

    r_str = '''
- hosts: localhost
  gather_facts: false
  roles:
    - role: subrole
  tasks:
    - debug:
        msg: "running subrole"
    - include_role:
        name: subrole
'''
    r_yaml = yaml.safe_load(r_str)[0]
    r_role = Role().load(r_yaml, play=Play().load(r_yaml))
    runner = PlaybookRunner(playbook=Playbook().load(r_yaml), inventory=Inventory(host_list=[]), variable_manager=VariableManager())
    t = r_role._get_block_list(Play())
    t = r_role._set_parent_blocks(t)
    runner._tqm._unreachable_

# Generated at 2022-06-23 07:10:33.695034
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole()

    assert ir.BASE == ('name', 'role')
    assert ir.FROM_ARGS == ('tasks_from', 'vars_from', 'defaults_from', 'handlers_from')
    assert ir.OTHER_ARGS == ('apply', 'public', 'allow_duplicates', 'rolespec_validate')
    assert ir.VALID_ARGS == (('name', 'role'), ('tasks_from', 'vars_from', 'defaults_from', 'handlers_from'), ('apply', 'public', 'allow_duplicates', 'rolespec_validate'))

# Generated at 2022-06-23 07:10:36.489372
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert IncludeRole(role=Role()).get_include_params() == {'ansible_parent_role_names': ['ROOT'], 'ansible_parent_role_paths': ['.']}


# Generated at 2022-06-23 07:10:47.122501
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    role_name = 'test-role'
    role_path = 'some/role/path'

    # test shallow copy
    ir = IncludeRole()
    ir._parent_role = Role()
    ir._role_name = role_name
    ir._role_path = role_path

    new_ir = ir.copy()
    assert new_ir is not ir
    assert new_ir._parent_role is ir._parent_role
    assert new_ir._role_name is ir._role_name
    assert new_ir._role_path is ir._role_path

    # test deep copy of parent role
    ir = IncludeRole()
    ir._parent_role = Role()
    ir._role_name = role_

# Generated at 2022-06-23 07:10:49.900921
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    mr = IncludeRole(Block(parent_block=task_include, role=role))
    mr.action = 'include_role'
    mr.name = 'some name'
    assert mr.get_name() == 'some name'

    mr._role_name = 'some role'
    assert mr.get_name() == 'some name'

    mr.name = None
    assert mr.get_name() == 'include_role : some role'

# Generated at 2022-06-23 07:11:01.914293
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # setup test
    block = Block()
    role = Role()
    task_include = TaskInclude()
    data = {
        'name': 'test_role',
        'tasks_from': 'tasks/main.yaml',
        'vars_from': 'defaults/main.yaml',
        'defaults_from': 'defaults/main.yaml',
        'handlers_from': 'handlers/main.yaml',
        'apply': {
            'tags': 'test'
        },
        'public': True,
        'allow_duplicates': False,
        'rolespec_validate': False
    }
    ir = IncludeRole(block, role, task_include=task_include)
    ir.name = 'test_include'
    ir.action = 'include_role'

# Generated at 2022-06-23 07:11:13.275964
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader

    play = Play().load(dict(
        name = "test play",
        hosts = 'test_host',
        gather_facts = False,
        connection = 'local',
        roles = ['test_role'],
    ), loader = DataLoader(), variable_manager = None)
    assert play

    ir = IncludeRole()
    ir.load(dict(
        name = 'test_task',
        role = 'test_role'
    ))
    assert ir.get_name() == "test_role : test_task"

    ir.load(dict(
        role = 'test_role'
    ))
    assert ir.get_name() == "include_role : test_role"


# Generated at 2022-06-23 07:11:23.705844
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # test with simple string tags
    data = dict(
        name='test_role'
    )
    ir = IncludeRole.load(data)
    assert ir._role_name == 'test_role'
    assert ir.get_name() == "%s : test_role" % ir.action
    assert ir.args == data

    # test with tasks from file string
    data = dict(
        name='test_role',
        tasks_from='some_file'
    )
    ir = IncludeRole.load(data)
    assert ir._role_name == 'test_role'
    assert ir._from_files == dict(tasks='some_file')
    assert ir.args == data

    # test with tasks

# Generated at 2022-06-23 07:11:36.399816
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = dict()
    loader = dict()
    data = dict()
    ir = IncludeRole(block, role, task_include, variable_manager, loader, data)
    assert isinstance(ir, IncludeRole)


if __name__ == '__main__':
    def main():
        block = Block()
        role = Role()
        task_include = TaskInclude()
        variable_manager = dict()
        loader = dict()
        data = dict()
        ir = IncludeRole(block, role, task_include, variable_manager, loader, data)
        print(ir.get_include_params())
        # print(ir.get_block_list())
        print(ir.get_name())
    main()

# Generated at 2022-06-23 07:11:45.429765
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    context = PlayContext()
    play = PlaybookExecutor(loader=loader,
                            inventory=InventoryManager(loader=loader, sources=['localhost,all']),
                            variable_manager=VariableManager(loader=loader,inventory=InventoryManager(loader=loader, sources=['localhost,all'])),
                            context=context,
                            passwords={})

# Generated at 2022-06-23 07:11:57.764643
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    ri = IncludeRole(Block(play=None, role=None), role=None, task_include=None)
    assert ri.copy() is not ri
    assert not isinstance(ri.copy(), Task)
    assert isinstance(ri.copy(), IncludeRole)

    # init object TaskInclude
    role = Role()
    block = Block(play=None, role=role)
    task_include = TaskInclude(block=block)
    # init object IncludeRole
    ri = IncludeRole(block=block, role=role, task_include=task_include)
   

# Generated at 2022-06-23 07:11:59.560072
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_subject = IncludeRole()
    assert test_subject.get_block_list() is not None

# Generated at 2022-06-23 07:12:11.439402
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.included_file import IncludedFile

    block = Block(play=Play().load({'name': 'test', 'hosts': 'localhost'}, variable_manager=None, loader=None))
    defined_role = RoleDefinition()
    defined_role._role_name = 'test_role'
    defined_role._role_path = 'path/to/test_role'
    defined_role._metadata_path = 'path/to/test_role/meta/main.yml'

# Generated at 2022-06-23 07:12:23.020422
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    def test(incl, expect_validate, expect_allow_duplicates, expect_public):
        ir = IncludeRole.load({'include_role': incl}, role=None)
        assert(ir.rolespec_validate == expect_validate)
        assert(ir._allow_duplicates == expect_allow_duplicates)
        assert(ir.public == expect_public)

    test(dict(name='role1'), True, True, False)
    test(dict(name='role1', rolespec_validate=False), False, True, False)
    test(dict(name='role1', rolespec_validate=True), True, True, False)
    test(dict(name='role1', allow_duplicates=False), True, False, False)

# Generated at 2022-06-23 07:12:30.336797
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # FIXME: use the pytest fixture to create a role and it's parent role
    #        (a good candidate for cleanup in the future)
    parent_role = Role()
    parent_role.name = 'parent_role'
    parent_role.path = '/path/to/parent/role'

# Generated at 2022-06-23 07:12:43.204936
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    def verify_IncludeRole_instance(include_role, expected_statically_loaded=None, expected_from_files=None,
                                    expected_allow_duplicates=None, expected_public=None, expected_rolespec_validate=None,
                                    expected_parent_role=None, expected_role_name=None, expected_role_path=None):
        assert(isinstance(include_role, IncludeRole))
        assert(include_role._statically_loaded == expected_statically_loaded)
        assert(include_role._from_files == expected_from_files)
        # include_role.allow_duplicates and include_role.public are private properties, cannot be directly accessed
        assert(include_role._allow_duplicates == expected_allow_duplicates)

# Generated at 2022-06-23 07:12:55.170383
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    Test_IncludeRole_copy : ensure copy returns correct name, parent, and tasks
    """

    # Build a mock task
    include_task = IncludeRole()
    include_task.action = 'include_role'
    include_task.name = 'include_role'

    # Build a mock block
    block = Block()

    # Build a mock role
    role = Role()
    role.action = 'test_role'
    role.name = 'test_role'

    # Build a mock role2
    role2 = Role()
    role.action = 'test_role2'
    role.name = 'test_role2'

    # Set mock role as parent for include_task
    include_task._parent_role = role
    include_task._parent = block
    include_task.tasks = [role2]

# Generated at 2022-06-23 07:13:01.736774
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = IncludeRole(block=block, role=role)
    task_include._role_name = 'test_name'
    result = task_include.get_name()
    print(result)
    assert result == "include_role : test_name"


# Generated at 2022-06-23 07:13:11.099889
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # prepare
    TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), '../templates')
    DEFAULT_BASEDIR = os.path.join(os.path.dirname(__file__), '../')
    loader = DataLoader()
    variable_manager = VariableManager()

    # play

# Generated at 2022-06-23 07:13:21.618426
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    ir = IncludeRole()

    # test name property
    assert ir.name == 'include_role'

    # test name attribute
    ir.name = 'imported'
    assert ir.name == 'imported'

    # test role property
    ir.name = None
    ir.role = 'foo'
    assert ir.name == 'include_role : foo'

    # test role attribute
    ir.role = 'bar'
    assert ir.name == 'include_role : bar'

    # test block
    ir.name = None
    ir.role = None

# Generated at 2022-06-23 07:13:31.673209
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class mock_Role(object):
        def __init__(self,name,path):
            self._name = name
            self._path = path
        def get_name(self):
            return self._name
        def get_role_params(self):
            return {'ansible_role_name': self._name,
                    'ansible_role_path': self._path}
    class mock_parent_class(object):
        def __init__(self,tasks,vars):
            self.tasks = tasks
            self.vars = vars
    class mock_block(object):
        def __init__(self):
            self.vars = {'foo': 'bar'}
        def get_vars(self):
            return self.vars


# Generated at 2022-06-23 07:13:38.970162
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    class CustomRole(Role):
        def get_role_params(self):
            return self.vars


    ir = IncludeRole()
    # test with parent_role none
    assert ir.get_include_params() == {}

    # test with parent_role present
    ir._parent_role = CustomRole()
    ir._parent_role.vars = {'a': 'b'}
    assert ir.get_include_params() == {'a': 'b'}

# Generated at 2022-06-23 07:13:47.927111
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def _assert_item(attr_name, test_data, expected, actual):
        if expected != actual:
            display.error('attr_name: %s, test_data: %s, expected: %s, actual: %s' % (attr_name, test_data, expected, actual))
            assert False

    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar


# Generated at 2022-06-23 07:13:52.707913
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create an IncludeRole with both name (specific) and role (default)
    # We will expect the name to be returned.
    ir = IncludeRole(name='test-role')

    assert ir.get_name() == 'test-role'


# Generated at 2022-06-23 07:13:57.592510
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    block1 = Block()

    ir = IncludeRole(block=None, role=None)
    assert ir.get_include_params() == {}, 'incorrect empty result for IncludeRole.get_include_params()'

    ir = IncludeRole(block=block1, role=None)
    assert ir.get_include_params() == {}, 'incorrect empty result for IncludeRole.get_include_params()'

# Generated at 2022-06-23 07:14:10.335601
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play 1",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )


# Generated at 2022-06-23 07:14:14.415241
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    loader = None
    block_data = """
include_role:
  name: test_role
"""
    data = {
        'name': 'test_role',
        'action': 'include_role'
    }
    block = Block.load(data, play=None, variable_manager=None, loader=loader)
    role = Role()
    include_role = IncludeRole.load(block_data, block, role, task_include=None)
    params = include_role.get_include_params()
    assert params['ansible_include_role_names'] == ['test_role']
    assert params['ansible_include_params'] == {'name': 'test_role'}

# Generated at 2022-06-23 07:14:24.160847
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils._text import to_text

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block(play=None)

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

    # valid
    data = dict(
        name='include_me',
    )

    ir = IncludeRole.load(data, block=block)
    assert ir._role_name == 'include_me'
    assert ir.statically_loaded is True

    # unknown arg
    data = dict(
        name='include_me',
        unknown_arg=True,
    )

# Generated at 2022-06-23 07:14:28.370555
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block([], [])
    ir = IncludeRole(block, None, task_include='- include_role: name=foo')
    assert ir.get_name() == 'include_role : foo'

# Generated at 2022-06-23 07:14:36.573629
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    r = Role()
    i = IncludeRole()
    i.name = "test2"
    i._role_name = "test"
    assert i.get_name() == "test2"
    assert i.get_name() != None
    assert i.get_name() != "test"
    i.name = None
    assert i.get_name() == "include_role: test"
    assert i.get_name() != "test"
    assert i.get_name() != None


# Generated at 2022-06-23 07:14:37.317309
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:14:47.944355
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # split parent role path
    parent_role_path = '/path/to/parent/roles/parent'
    include_role_path = '/path/to/include/roles/include'
    parent_role_split_path = parent_role_path.split('/')
    include_role_split_path = include_role_path.split('/')
    parent_role_name = 'parent'
    include_role_name = 'include'

    # create objects
    include_role_object = IncludeRole()
    parent_role_object = Role()

    # set the attribute of include_role_object
    include_role_object._role_path = include_role_path

    # set the attribute of parent_role_object
    parent_role_object.name = parent_role_name
    parent_role_object._role

# Generated at 2022-06-23 07:14:51.918095
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    i_role = IncludeRole()
    assert isinstance(i_role, TaskInclude)
    assert isinstance(i_role, Block)
    assert isinstance(i_role, IncludeRole)


# Generated at 2022-06-23 07:14:57.347408
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    Test the IncludeRole class's method copy which makes a
    new object that is a deep copy of the original.
    """

    # test a role with no options
    test_role = dict(
        name = 'test_role1',
        apply = None,
        allow_duplicates = None,
        public = False,
        tasks = []
    )

    # add one var
    test_role['vars'] = dict(
        test_var1 = dict(
            test_subvar1 = 'test_subvar1_value'
        ),
    )

    # add one task
    test_role['tasks'] = [
        dict(
            debug = dict(
                msg = 'test task1'
            )
        )
    ]

    # create the original object

# Generated at 2022-06-23 07:15:09.874224
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import yaml

    r = Role()
    ir = IncludeRole()
    ir.vars = {"var1": "value1", "var2": 2}
    ir.statically_loaded = True
    ir.args = {"apply": {"new_var": "new_value"}}
    ir._from_files = {"tasks": "my_tasks"}
    ir._parent_role = r
    ir

# Generated at 2022-06-23 07:15:20.600142
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'main.yml'}
    ir._parent_role =  Role()
    ir._role_name = 'a_role'
    ir._role_path = 'a_role_path'

    new_ir = ir.copy()

    assert ir is not new_ir, "Expected copy to create a new object"
    assert ir.statically_loaded == new_ir.statically_loaded, "statically_loaded not copied"
    assert ir._from_files == new_ir._from_files, "_from_files not copied"
    assert ir._parent_role == new_ir._parent_role, "_parent_role not copied"

# Generated at 2022-06-23 07:15:33.417422
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class FakeIncludeRole():
        def __init__(self):
            self.IncludeRole = IncludeRole(None, None, None)
            self.IncludeRole._parent_role = FakeParentRole('CrazyTown')
            self.IncludeRole._parent_role._role_path = 'CrazyTown_path'
            self.IncludeRole._parent_role._role_params = {'ansible_role_name': 'CrazyTown'}

    class FakeParentRole():
        def __init__(self, name, **kwargs):
            self.get_name = lambda: name
            self._role_path = kwargs['role_path']
            self.get_role_params = lambda: kwargs['role_params']


# Generated at 2022-06-23 07:15:43.500845
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # setup
    p = Play().load({'name': 'test_IncludeRole_name',
                     'hosts': ['all'],
                     'roles': [],
                     'tasks': [{
                         'block': [{
                             'include_tasks': 'tasks.yml'
                         }]
                     }]
    }, variable_manager=None, loader=None)
    block = Block.load(p.block_list[0], play=p)
    rd = RoleDefinition()
    rd.name = 'test_IncludeRole_name'

# Generated at 2022-06-23 07:15:50.882718
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()

    ir = IncludeRole()
    ir_copy = ir.copy()

    assert ir is not ir_copy
    assert ir._parent is None
    assert ir_copy._parent is None

    ir._parent = Block()
    ir_copy = ir.copy()
    assert ir is not ir_copy
    assert ir._parent is not ir_copy._parent
    assert ir._parent._parent is None
    assert ir_copy._parent._parent is None

    ir._parent._parent = Playbook()
    ir_copy = ir.copy()
    assert ir is not ir_copy
    assert ir._parent is not ir_copy._parent
    assert ir._parent._parent is not ir_copy._parent._parent