

# Generated at 2022-06-23 07:05:54.871286
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    r = IncludeRole()
    r.action = 'include_role'
    r.statically_loaded = False
    r._from_files = {"foo":"bar"}
    r._parent_role = None
    r._role_name = 'Foo'
    r._role_path = 'Bar'
    r.name = 'Foobar'
    r.collections = 'Barfoo'

    new_r = r.copy()

    assert new_r.action == 'include_role'
    assert new_r.statically_loaded == False
    assert new_r._from_files == {"foo": "bar"}
    assert new_r._parent_role == None
    assert new_r._role_name == 'Foo'
    assert new_r._role_path == 'Bar'

# Generated at 2022-06-23 07:06:05.464840
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    import sys
    import pytest

    pytestmark = [pytest.mark.unittest]

    mock_ansible_vars_validate = {
        'test_var': 'test_var_1_value',
    }

    class MockIncludeRole:
        def __init__(self):
            self.vars = {}

    def mock_get_role_params(self):
        return {'ansible_role_name': 'role01', 'ansible_role_path': 'role01_path'}

    class MockParentRole:
        def __init__(self):
            self.get_role_params = mock_get_role_params

    class MockIncludeRoleBlock:
        def __init__(self):
            self.parent = MockParentRole()


# Generated at 2022-06-23 07:06:07.021815
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir is not None


# Generated at 2022-06-23 07:06:17.462256
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # create instance of class IncludeRole
    ir = IncludeRole()
    # set role name to "role01"
    ir._role_name = "role01"
    # get role params of include role instance
    v = ir.get_include_params()
    # check role name
    assert v.get('ansible_role_name') == "role01"
    # check params for the parent role
    assert len(v.get('ansible_parent_role_names')) == 0
    assert len(v.get('ansible_parent_role_paths')) == 0
    # create a instance of class Role()
    ri = Role()
    # set role's name to role02"
    ri.name = "role02"
    # set role's path to "/path/to/role02"
    ri._role_

# Generated at 2022-06-23 07:06:28.476132
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    This test checks if method copy of class IncludeRole works properly
    """
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    block = Block()
    task = Task()
    block.block = [task]
    play = Play()

    role = Role()
    ir = IncludeRole(block=block, role=role)
    ir2 = ir.copy(exclude_parent=True, exclude_tasks=True)
    assert ir2.statically_loaded == ir.statically_loaded
    assert ir2._from_files == ir._from_files
    assert ir2._parent_role == ir._parent_role
    assert ir2._role_name == ir._role_name
    assert ir2._role_path == ir

# Generated at 2022-06-23 07:06:33.053803
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole(task_include=TaskInclude())
    task.action = 'include_role'
    task._role_name = 'my_role'
    assert task.get_name() == 'include_role : my_role'

# Generated at 2022-06-23 07:06:45.870346
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import ROLE_CACHE

    def _setup_play():
        ROLE_CACHE.clear()
        play_ds = dict(
            name="Ansible Play",
            hosts="all",
            gather_facts="no",
            roles=["test_role"],
            tasks=[
                dict(action="debug", msg="Hello world!")
            ]
        )
        play = Play().load(play_ds, variable_manager=variable_manager, loader=loader)
        block = Block()
        block.block = [Task().load(play_ds['tasks'][0], block=block, task_include=None)]


# Generated at 2022-06-23 07:06:48.026788
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    block = Block()
    role = Role()
    task_include = TaskInclude()
    assert IncludeRole(block, role, task_include) is not None

# Generated at 2022-06-23 07:06:59.352349
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    r = IncludeRole()
    assert not r.ignore_errors
    assert r.name is None
    assert r.tags == set()
    assert r.when == set()
    assert r.async_val is None
    assert r.poll == 0
    assert r.until is None
    assert r.run_once is None
    assert r.delegate_to is None
    assert r.async_val is None
    assert r.notify == []
    assert r.first_available_file is None
    assert r.action is None
    assert r.args == {}
    assert r.free_form is None
    assert r.loop is None
    assert r.loop_with is None
    assert r.loop_control is None
    assert r.register is None
    assert r.ignore_errors is False
    assert r.changed

# Generated at 2022-06-23 07:07:10.426716
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=hosts)
    play_context = {"become": False}


# Generated at 2022-06-23 07:07:20.871542
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Test if the method returns the expected values for a given target
    def execute_test(target, expected_value):
        test_result = target.get_include_params()
        if test_result != expected_value:
            print ('Error. Test Failed. Expected output: {0} ; Actual output: {1}'
                   .format(expected_value, test_result))
        else:
            print ('Success. Test passed. Output is: {0}'.format(test_result))


    # Test 1: Test if the method returns the expected values when the object has a parent role
    print ()
    print ('Test 1: Test if the method returns the expected values when the object has a parent role')
    test_target = IncludeRole(role='test_role')

# Generated at 2022-06-23 07:07:22.857919
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, Block)
    assert isinstance(ir, TaskInclude)

# Generated at 2022-06-23 07:07:29.965570
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # test construct with struct data
    data = dict(
        name="example"
    )
    ir = IncludeRole.load(
        data,
        block=Block(),
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert ir._role_name == "example"
    assert ir._parent_role == None
    assert ir.args['name'] == "example"

# Generated at 2022-06-23 07:07:35.803277
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block(parent_block=None)
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    assert include_role.get_block_list() == ({}, {})

# Generated at 2022-06-23 07:07:43.600150
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole({
        "name": "test_name",
        "role": "test_role"
    }).get_name() == "test_name : test_role", \
        "should format a correct task name"
    assert IncludeRole({
        "role": "test_role"
    }).get_name() == "include_role : test_role", \
        "should format a correct task name when no name"



# Generated at 2022-06-23 07:07:57.076283
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_all_plugin_dirs

    # Load plugins
    add_all_plugin_dirs()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    play_context = PlayContext()
    tqm = None

# Generated at 2022-06-23 07:08:09.883713
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.playbook.attribute import Attribute
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '10.10.10.10'
    play_context.remote_user = 'einstein'

    loader = DataLoader()
    play = Play()
    play.hosts = ['10.10.10.10']
    play.name = "test_play"
    play.connection = 'local'
    play.port = 22

# Generated at 2022-06-23 07:08:22.773893
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import module_loader

    # Scenario:
    # 1. IncludeRole is a TaskInclude and a Block, so first
    #    test the loading of TaskInclude
    # 2. Test the loading of IncludeRole
    # 3. Test that IncludeRole properties are properly set.
    # 4. Test the loading of RoleInclude
    # 5. Test the loading of Role

    # IncludeRole is a TaskInclude and a Block, so first
    # test the loading of TaskInclude
    # --------------------------------------------------

    # test load() of TaskInclude

# Generated at 2022-06-23 07:08:32.995197
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import collections
    import sys
    import os
    import ansible.playbook
    import ansible.utils
    import ansible.utils.lnx
    import ansible.cli
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.module_utils.six import string_types
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    display = Display()
    playbook_path = 'roles/test/molecule/default/playbook.yml'

    # initialize required objects
    tqm = ansible.cli.CLI.setup_inventory(options=None, variables=None)
    vars_manager = tqm._variable_manager
    loader

# Generated at 2022-06-23 07:08:41.458454
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Base class
    display.debug("IncludeRole(object): begin")

    block = Block()
    role = Role()
    task_include = TaskInclude(block, role)

    obj_IncludeRole = IncludeRole(block, role, task_include=task_include)
    display.debug("type(obj_IncludeRole)= %s" % str(type(obj_IncludeRole)))
    display.debug("obj_IncludeRole.private_vars= %s" % str(obj_IncludeRole.private_vars))
    display.debug("obj_IncludeRole.vars= %s" % str(obj_IncludeRole.vars))
    assert (obj_IncludeRole.private_vars == {})
    assert (obj_IncludeRole.vars == {})

    # get_name()


# Generated at 2022-06-23 07:08:43.998184
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role  = Role()
    include_role = IncludeRole(block, role)
    include_role.action = 'include_role'
    include_role._role_name ='test_role'
    assert include_role.get_name() == 'include_role : test_role'

# Generated at 2022-06-23 07:08:53.408183
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    class MockIncludeROle(IncludeRole):
        _allow_duplicates = True
        _public = True
        _rolespec_validate = True

        def __init__(self, block=None, role=None, task_include=None):
            self.statically_loaded = True
            self._from_files = {'tasks': 'tasks', 'vars': 'vars.yml'}
            self._parent_role = role
            self._role_name = 'role_name'
            self._role_path = 'role_path'

    include_role = MockIncludeROle()
    assert include_role.copy() is not None

# Generated at 2022-06-23 07:09:03.153752
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import yaml

    yaml_data = '''---
- name: role_name1
  tasks:
    - shell: exit 0
'''
    yaml_data = yaml.safe_load(yaml_data)
    args = {'role': 'role_name1'}
    block = Block(parent_block=None, role=None, task_include=None, use_handlers=False, task=None)
    block = block.load(args, yaml_data)
    ir = IncludeRole.load(block, role=None, task_include=None)

# Generated at 2022-06-23 07:09:14.693642
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # test with minimal argument
    role = IncludeRole({'name': 'role_name'})
    assert role.action == 'include_role'
    assert role.allow_duplicates
    assert not role.public
    assert role.role == 'role_name'
    assert role._role_name == 'role_name'
    assert role.statically_loaded is False
    assert role.tasks_from is None
    assert role.rolespec_validate is True
    assert role._from_files == {}

    # test with full arguments

# Generated at 2022-06-23 07:09:25.897940
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import yaml
    from ansible import context

    def _assertIncludeRoleAttributes(play, role, check_block_list, check_handler_list):
        ir = IncludeRole()
        ir._parent = play
        ir._role_name = role.get_name()
        ir._role_path = role._role_path

        blocks, handlers = ir.get_block_list()
        assert blocks == check_block_list
        assert handlers == check_handler_list

    def _assertWithRole(statically_loaded, public, check_block_list, check_handler_list):
        # -----
        # Setup
        # -----
        from ansible_collections.nsxt.nclu.plugins.module_utils.networking_nsxt.nsxt_role import NetworkingNsxtRole

# Generated at 2022-06-23 07:09:30.215946
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, TaskInclude)
    assert isinstance(ir, Block)

# Generated at 2022-06-23 07:09:41.502937
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # IncludeRole.copy(self, exclude_parent=False, exclude_tasks=False):
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude


    # Setup test variables

    # First test variables
    block_01 = Block()
    role_01 = RoleDefinition.load()
    task_include_01 = TaskInclude()
    task_01 = Task()
    task_01.action = 'test_var'
    task_01.name = 'my_task'
    block_01.block = [task_01]
    block_01.role = role_01
    task_include_01.block = block_01
    task_include_01.role = role_01
    include_role_

# Generated at 2022-06-23 07:09:47.051021
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    task = IncludeRole()
    assert task._role_name is None
    assert task._role_path is None
    assert task._parent_role is None
    assert task._parent is None
    assert task.statically_loaded is False
    assert task.allow_duplicates is True
    assert task.public is False
    assert task._apply is None
    assert task._rolespec_validate is True

    loaded_role = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude())
    assert loaded_role._role_name is None
    assert loaded_role._role_path is None
    assert loaded_role._parent_role is not None
    assert isinstance(loaded_role._parent_role, Role)

# Generated at 2022-06-23 07:09:58.886134
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    # Arrange

    class MockBlock(Block):
        pass

    class MockRole(Role):
        pass

    class MockTaskInclude:
        _parent = MockBlock()
        _role = MockRole()
        _role_name = 'role_name'
        _role_path = 'role_path'

    t_mock = MockTaskInclude()

    # Act
    ir = IncludeRole(task_include=t_mock)

    # Assert
    assert isinstance(ir, IncludeRole)
    assert ir._parent == t_mock._parent
    assert ir._role == t_mock._role
    assert ir._role_name == t_mock._role_name
    assert ir._role_path == t_mock._role_path
    assert isinstance(ir.get_block_list(), tuple)


# Generated at 2022-06-23 07:10:10.268432
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.module_utils.six import PY3
    if not PY3:
        from mock import MagicMock
    else:
        from unittest.mock import MagicMock

    test_params = {'test_param_1': 'test_value_1', 'test_param_2': 'test_value_2', 'test_param_3': 'test_value_3'}
    test_name = 'test_name'
    test_path = 'test_path'

    mock_role = MagicMock()
    mock_role.get_name.return_value = test_name
    mock_role._role_path = test_path
    mock_role.get_role_params.return_value = test_params

    ir = IncludeRole()
    ir._parent_role = mock_role

    included

# Generated at 2022-06-23 07:10:15.513422
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Arrange
    test_data = {'name': 'test_role'}

    # Act
    ir = IncludeRole.load(test_data)

    # Assert
    assert ir._role_name == 'test_role'
    assert ir._parent_role is None
    assert ir._role_path is None
    assert ir._from_files == {}

# Generated at 2022-06-23 07:10:25.530900
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    #
    # Load block tree of include_role task
    #
    block = Block()
    test_role_name = "my_test_role"
    test_role_name_prefix = "test_role"

    # The test_role structure is created by a recursive call to load_role on the
    # test_role_name_prefix, which is a test role with _tasks.yml that includes 
    # a task that recursively includes it.
    #
    # Note - this has a nasty side-effect of creating the actual test_role_name
    #        role in the path, so its best to keep the prefix not matching the
    #        role name.
    #
    # Expected results:
    # - There are two blocks:
    #   - A block containing the parent task
    #   - A block containing the

# Generated at 2022-06-23 07:10:36.847318
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    # Create object of class Play
    play_obj = Play()

    # Create object of class RoleDefinition
    role_definition_obj = RoleDefinition(block=None, role=None, task_include=None)

    # Create object of class IncludeRole
    include_role_obj = IncludeRole(block=None, role=None, task_include=role_definition_obj)

    # Assign value to argument of method get_block_list of class IncludeRole
    include_role_obj._role_name = "test1"

    # Assign value to argument of method get_block_list of class IncludeRole
    include_role_obj._from_files = {}

    # Assign value to argument of method get_block_list of class Include

# Generated at 2022-06-23 07:10:47.160185
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.helpers import load_list_of_blocks

    role = RoleDefinition.load(dict(
        name="test_role",
        tasks=[
            {'name': 'task 1', 'action': {'module': 'Debug', 'args': {'msg': 'Hello World'}}}
        ]
    ))

    # This is the expected block list in tasks.yml

# Generated at 2022-06-23 07:10:51.557690
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.playbook.play_context as play_context

    def _load(data):
        data['block'] = Block()
        role = Role()
        ir = IncludeRole.load(data, block=data['block'], role=role)
        ir.post_validate(play_context.PlayContext())
        return ir

    def assert_include_attrs(ir, include_role_args, attrs):
        for k, v in include_role_args.items():
            assert getattr(ir, k) == v

        for k, v in attrs.items():
            assert getattr(ir, k) == v

    # test with no args
    data = {'action': 'include_role',
            'name': 'role_name'}
    ir = _load(data)

# Generated at 2022-06-23 07:10:55.510015
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    name = 'test_name'

    ir = IncludeRole(block=None, role='', task_include=None)
    ir.name = name
    assert ir.get_name() == name


# Generated at 2022-06-23 07:11:05.567360
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    first = IncludeRole(
        task_include=TaskInclude(block=Block(
            parent_block=Block(),
            role=Role(
                name="role"))))
    assert first is not None
    assert first._parent is not None
    assert first.task_include is not None
    assert first.task_include.block is not None
    assert first.task_include.block.parent_block is not None
    assert first.task_include.block.role is not None
    assert first.task_include.block.role.name is not None

    second = first.copy()
    assert second is not None
    assert second._parent is None
    assert second.task_include is not None
    assert second.task_include.block is not None
    assert second.task_include.block.parent_block is None
    assert second.task

# Generated at 2022-06-23 07:11:10.324179
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class FakePlay:
        def __init__(self):
            self.host_vars = {}
            self.group_vars = {}
            self.groups = {}
            self.current_vars = []

    class FakeRole:
        def __init__(self):
            self.get_role_params = lambda : {'host_vars': 'fake_host_vars', 'group_vars': 'fake_group_vars'}

    class FakeBlock:
        def __init__(self):
            self.vars = {'hello': 'world'}
            self.play = FakePlay()

    role = FakeRole()
    block = FakeBlock()
    ir = IncludeRole(block=block, role=role)
    v = ir.get_include_params()

# Generated at 2022-06-23 07:11:21.228762
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    class MyIncludeBlock(Block):
        pass

    # Test1: no name or role
    # For some reason this is not triggering an AnsibleParserError, but throwing a KeyError
    data = dict(include=dict())
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data, block=MyIncludeBlock())

    # Test2: one of name or role missing
    data = dict(include=dict(name=dict()))
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data, block=MyIncludeBlock())

    # Test3: no bad options
    data = dict(include=dict(name='myrole'))
    assert IncludeRole.load(data, block=MyIncludeBlock())

    # Test4: bad option

# Generated at 2022-06-23 07:11:29.204456
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    parent_role = Role()
    parent_role.name = 'parent_role'
    parent_role._role_path = 'parent_role_path'
    parent_role.vars = dict(foo='baz')
    parent_role_parents = parent_role.get_ancestor_roles()
    for grand_parent_role in parent_role_parents:
        parent_role.update_dep_env(grand_parent_role)
    parent_role_children = parent_role.get_child_roles()
    for child_role in parent_role_children:
        child_role.update_dep_env(parent_role)
        
    target_role_path = 'target_role_path'
    target_role = Role()
    target_role._role_path = target_role_path
    target_

# Generated at 2022-06-23 07:11:39.585436
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create a mock ansible.module_utils.basic.AnsibleModule object
    mod = mock.Mock()
    
    # Create a mock ansible.parsing.utils.datastructure.AnsibleVars object
    var = mock.Mock()
    # This mock is a dict-like object
    var.copy = mock.Mock()
    # Using mock_add_spec, the attributes of this mock are added
    var.mock_add_spec(dict)
    # Set an attribute
    var['ansible_parent_role_names'] = ['role1','role2']
    var['ansible_parent_role_paths'] = ['path1','path2']
    var['myvars'] = 'myvalue'

    mod.params = var

    # Create a mock ansible.playbook.block.

# Generated at 2022-06-23 07:11:45.313873
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Load from include
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)
    assert ir is not None

    # Load from task
    ir = IncludeRole(block, role)
    assert ir is not None

    # Load from role
    ir = IncludeRole(block, role)
    assert ir is not None

# Generated at 2022-06-23 07:11:51.641495
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    task = IncludeRole()
    task.action = 'foobar'
    task._from_files = {'abc': 'abc.yml', 'def': 'def.yml'}
    task.name = 'name'
    task._allow_duplicates = False
    task._public = True
    task._rolespec_validate = False
    task.statically_loaded = True
    parent_role = Role()
    parent_role._role_path = '/my/new/role'
    task._parent_role = parent_role

    new_task = task.copy()
    assert new_task.action == task.action
    assert new_task._from_files == task._from_files
    assert new_task.name == task.name
    assert new_task._allow_duplicates == task

# Generated at 2022-06-23 07:11:59.964946
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # test constructor
    ir = IncludeRole()
    assert not ir._parent_role
    assert not ir._role_path
    assert not ir._role_name
    assert ir._allow_duplicates is True
    assert ir._rolespec_validate is True

    # test loading a simple include
    data = dict(
        name='test.yml',
    )
    ir = IncludeRole.load(data, loader=None, variable_manager=None)
    assert ir._role_name == 'test.yml'
    assert not ir._parent_role
    assert not ir._role_path

# Generated at 2022-06-23 07:12:11.867563
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(role="test")
    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir.args == {}
    assert ir._parent_role == None


    ir = IncludeRole(role="test", allow_duplicates=False)
    assert ir._allow_duplicates == False
    assert ir.args == {}

    ir = IncludeRole(role="test", _allow_duplicates=False)
    assert ir._allow_duplicates == False
    assert ir.args == {}

    ir = IncludeRole(role="test", _allow_duplicates=False, allow_duplicates=True)
    assert ir._allow_duplicates == False
    assert ir.args == {}



# Generated at 2022-06-23 07:12:23.206431
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play
    import json


# Generated at 2022-06-23 07:12:35.785325
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os.path

    dirname_main = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    dirname_playbook = os.path.join(dirname_main, 'lib/ansible/playbook')
    dirname_roles = os.path.join(dirname_main, 'test/integration/targets/test-collections/ansible_collections/testns/testcoll/roles')

   

# Generated at 2022-06-23 07:12:41.048472
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    assert include_role._from_files == {}
    assert include_role._parent_role == role
    assert include_role._role_name is None
    assert include_role._role_path is None

# Generated at 2022-06-23 07:12:51.407278
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.role_context import RoleContext
    from ansible.template import Templar

    # --------------------------------------------------------------------------------------
    # List of expected role parameters for IncludeRole.get_include_params()
    #
    # This list is built from test data, see the variable 'yaml_include_role_data'
    # To update this list, run the test with the variable DEBUG_UNITTEST set to true
    # --------------------------------------------------------------------------------------

# Generated at 2022-06-23 07:12:59.038167
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    TaskInclude_params = {'foo': 'bar', 'name': 'task1'}
    TaskInclude_expected_result = {'foo': 'bar', 'name': 'task1',
                                   'ansible_role_names': ['task1'],
                                   'ansible_role_paths': [-1],
                                   'ansible_parent_role_names': [],
                                   'ansible_parent_role_paths': []}
    task1 = TaskInclude(args=TaskInclude_params)
    assert TaskInclude_expected_result == task1.get_include_params()

    IncludeRole_params = {'foo': 'bar', 'name': 'task1', 'role': 'role1'}

# Generated at 2022-06-23 07:13:01.194334
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    host_vars = dict(foo='bar')
    assert host_vars == IncludeRole().get_include_params()

# Generated at 2022-06-23 07:13:06.270851
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class Dummy:
        pass
    dummy = Dummy()
    dummy.action = 'include_role'
    dummy.args = {'name': 'role_name'}
    dummy._role_name = None
    ir = IncludeRole(task_include=dummy)
    ir = ir.load({}, role=True)
    assert ir._role_name == 'role_name'

# Generated at 2022-06-23 07:13:13.680492
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    init_args_dict = dict(
        name='name',
    )


# Generated at 2022-06-23 07:13:16.088829
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = ''
    ir = IncludeRole(block, role, task_include=task_include).load_data({'name': 'test', 'rolespec_validate': True, 'apply': {}, 'tasks_from': 'main'}, loader=None)
    assert ir.get_name() == 'include_role : test'


# Generated at 2022-06-23 07:13:23.741743
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    task = Task()
    task._role = Role()
    task._role._metadata = dict(role_name="role_name", role_path="role_path")
    ir = IncludeRole(task_include=task)
    params = ir.get_include_params()
    assert(params.get('ansible_parent_role_names') == ["role_name"])
    assert(params.get('ansible_parent_role_paths') == ["role_path"])
    assert(params.get('ansible_parent_role_name') == "role_name")

# Generated at 2022-06-23 07:13:24.764097
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-23 07:13:30.524055
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task = IncludeRole(block, role, name='test')
    assert task.get_name() == 'test'
    task = IncludeRole(block, role, task_include=dict(name='test role'))
    assert task.get_name() == 'role : test role'
    task = IncludeRole(block, role)
    assert task.get_name() == 'role : '

# Generated at 2022-06-23 07:13:32.032492
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    a = IncludeRole()
    assert a

# Generated at 2022-06-23 07:13:43.228734
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.utils import context_objects as co

    # Create a test task
    block = Block()
    block.roles = [Role()]
    include_role = IncludeRole(block)

    # Create a test role with a task
    role = Role()
    role.tasks = [Task()]

    # Create a test Play
    play = Play()
    play.roles = [role]

    # Setup the block list and handler list
    (block_list, handler_list) = include_role.get_block_list(play=play, variable_manager=co.VariableManager(), loader=co.Loader())

   

# Generated at 2022-06-23 07:13:53.522620
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude(block, role)
    assert IncludeRole(block, role, task_include)._parent_role == role
    assert IncludeRole(block, role, task_include)._role_name is None
    assert IncludeRole(block, role, task_include)._role_path is None
    assert IncludeRole(block, role, task_include).statically_loaded is False

    # Ensure that IncludeRole.get_name() returns the name of the task
    assert IncludeRole(block, role, task_include).get_name() == ": "


# Generated at 2022-06-23 07:13:54.065161
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert isinstance(IncludeRole(), IncludeRole)

# Generated at 2022-06-23 07:13:59.810448
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole(block=None, role=None)
    include_role.name = "foo"
    include_role._role_name = "bar"
    assert include_role.get_name() == "foo : bar"

# Generated at 2022-06-23 07:14:11.345787
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()
    ir.action = 'block.include_role'
    ir._from_files = {'tasks': 'tasks/main.yml', 'handlers': 'handlers/main.yml'}
    ir.args = dict(name='test_role', tasks_from='tasks/main.yml', handlers_from='handlers/main.yml')

    # Create parent role
    pr = Role()
    pr._role_name = 'parent_role'
    pr._role_path = 'test/parent_role'
    pr._metadata.project_name = 'test_project'
    pr._metadata.name = 'test_role'
    pr._metadata.version = '1.0'
    pr._metadata.description = 'test role'

# Generated at 2022-06-23 07:14:18.469029
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    ir = IncludeRole(block=block).load_data({'role': 'test_role'})
    myplay = object()
    variable_manager = object()
    loader = object()
    assert ir.get_block_list(play=myplay, variable_manager=variable_manager, loader=loader) == (ir.get_block_list(), ir.get_block_list()[1])
    # assert ir.get_block_list(play=myplay, variable_manager=variable_manager, loader=loader) == ([], [])

# Generated at 2022-06-23 07:14:26.582840
# Unit test for constructor of class IncludeRole

# Generated at 2022-06-23 07:14:38.699018
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os
    import sys
    import json

    # Create objects to be used in our test
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

# Generated at 2022-06-23 07:14:49.720169
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook import Play, Role

    playbook_path = 'test/functional/ansible/playbooks/include_role/main.yml'
    loader, inventory, variable_manager = C.COMMAND_BUILDERS['playbook'](playbook_path)

# Generated at 2022-06-23 07:14:55.497886
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    from_files = {'tasks': 'main.yml'}
    role_name = 'foo'

    include_role = IncludeRole(block, role, task_include)
    include_role._from_files = from_files
    include_role._role_name = role_name

    new_me = include_role.copy()
    assert include_role._from_files == new_me._from_files
    assert include_role._role_name == new_me._role_name
    assert include_role.statically_loaded == new_me.statically_loaded

# Generated at 2022-06-23 07:15:08.372534
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.module_utils import basic
    from units.compat import unittest

    fake_loader = basic.AnsibleModuleLoader()

    class TestIncludeRole_load(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_with_required_valid_args(self):

            data = dict(
                action='include_role',
                name='myrole',
                tasks_from='tasks.yml',
                vars_from='vars.yml',
                handlers_from='handlers.yml',
                defaults_from='defaults.yml',
                apply=dict(status="enabled"),
                public=False,
                allow_duplicates=True,
            )
            ir = IncludeRole.load(data)

# Generated at 2022-06-23 07:15:09.949178
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ''' Unit test for method load of class IncludeRole '''
    pass

# Generated at 2022-06-23 07:15:20.047228
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.modules.system import ping
    from ansible.playbook.task import Task

    t = Task()
    t.action = 'ping'
    t.args = dict(data='pong')
    t.set_loader(ping.__loader__)

    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = dict(name='my_role')
    assert ir.get_name() == 'include_role : my_role'

    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = dict(role='my_role')
    assert ir.get_name() == 'include_role : my_role'

    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = dict(name='my_role')


# Generated at 2022-06-23 07:15:33.326702
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import pytest
    from ansible.playbook.play_context import PlayContext

    t = IncludeRole()

    # base
    t._role_name = 'debug'
    t._role_path = ['a', 'b', 'c']
    t._parent_role = 'parent'
    t._statically_loaded = True

    # from args
    t._from_files = {'vars': 'vars_file.yml', 'defaults': 'defaults_file.yml', 'tasks': 'tasks_file.yml', 'handlers': 'handlers_file.yml'}

    # other args
    t._public = True
    t._allow_duplicates = True
    t._rolespec_validate = True

    # TODO: add assert for this
    
    return

# Generated at 2022-06-23 07:15:42.257739
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.callbacks as callbacks
    import ansible.constants as C
    import json
    options1=callbacks.DefaultRunnerCallbacks()
    options1._options=C.Options()
    options1._options.module_path=''

# Generated at 2022-06-23 07:15:44.656547
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = 'role.name'
    expected = 'role.name'
    assert ir.get_name() == expected