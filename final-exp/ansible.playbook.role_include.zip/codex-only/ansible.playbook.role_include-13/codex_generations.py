

# Generated at 2022-06-23 07:05:57.703054
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole(block=None, role=None, task_include=None)
    ir.name = 'include_role'

    assert ir.action == 'include_role'
    assert ir.name == 'include_role'

    ir_dict = dict(name='include_role', vars=dict(someday=dict(somekey='somevalue')), rolename='myrolename')
    ir2 = IncludeRole(block=None, role=None, task_include=None)
    ir2.load_data(ir_dict, variable_manager=None, loader=None)

    assert ir2.vars == dict(someday=dict(somekey='somevalue'))

# Generated at 2022-06-23 07:05:59.400902
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # we can run the class constructor unit tests here, but constructor inheritance is not handled at the moment.
    pass

# Generated at 2022-06-23 07:06:07.944984
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # test create objects
    ir = IncludeRole()
    # test class attributes
    assert ir.action == 'include_role'
    assert ir.loop is None
    assert ir.until is None
    assert ir.retries == 3
    assert ir.delay == 3
    assert ir.register == ''
    assert ir.ignore_errors is False
    assert ir.first_available_file is None
    assert ir.when is None
    assert ir.tags == []
    assert ir.until_tags == []
    assert ir.notify == []
    assert ir.when_failed == 'continue'
    assert ir.changed_when is None
    assert ir.failed_when is None

# Generated at 2022-06-23 07:06:13.413984
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    sub = IncludeRole()
    sub.action = "include_role"
    sub._role_name = "test role name"
    assert sub.get_name() == "include_role : test role name"
    sub.name = "test name"
    assert sub.get_name() == "test name"
    del sub


# Generated at 2022-06-23 07:06:20.693880
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create mock objects
    ir = IncludeRole()
    ir.name = "I'm a role"
    ir._role_name="Task Man"
    assert ir.get_name() == "I'm a role"

    ir.name = None
    ir._role_name="Task Man"
    assert ir.get_name() == "include_role : Task Man"

# Generated at 2022-06-23 07:06:30.410658
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.six import string_types
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.meta import RoleMetadata
    #from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    from collections import MutableMapping

    from shlex import split
    from copy import copy


# Generated at 2022-06-23 07:06:38.879120
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    variable_manager = None
    loader = None

    # Test with arguments name and role
    data = dict(
        name="test",
        role="test"
    )

    p = Play().load(dict(
        name="test play",
        hosts=["all"],
        gather_facts="yes",
        tasks=[
            dict(
                action="include_role",
                args=dict(
                    name="test",
                    role="test"
                )
            )
        ]
    ), variable_manager=variable_manager, loader=loader)

    t = Task().load(data, play=p)

# Generated at 2022-06-23 07:06:49.049866
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    parent_role = Role()
    task_include = TaskInclude()
    task_include.args = {'name': 'test_name', 'role': 'test_role', 'x': 'a', 'public': False, 'allow_duplicates': False, 'rolespec_validate': False}
    role = IncludeRole(block, parent_role, task_include=task_include)
    new_role = role.copy()
    assert new_role.statically_loaded is False
    assert new_role._parent_role == parent_role
    assert new_role._role_name == 'test_role'
    assert new_role._role_path is None
    assert new_role.vars == {}
    assert new_role.static_vars == {}

# Generated at 2022-06-23 07:07:00.129033
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test for static load method
    data = dict(
        name='some_role',
        role='some_role',
        tasks_from='main.yml',
        vars_from='vars/main.yml',
        defaults_from='defaults/main.yml',
        handlers_from='handlers/main.yml',
        public='True',
        apply='True',
        allow_duplicates='True',
        rolespec_validate='True',
    )
    block = Block()
    role = Role()
    task_include = TaskInclude()
    expected_result = 'include_role : some_role'
    test_obj = IncludeRole.load(data, block, role, task_include)
    actual_result = test_obj.get_name()
    assert expected_result == actual_

# Generated at 2022-06-23 07:07:09.185384
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    role_instance = Role()
    role_instance._role_path = '/Users/home/ansible/roles/test'
    role_instance._role_name = 'test'

    test_instance = IncludeRole(role=role_instance)
    result = test_instance.get_include_params()

    assert result['ansible_parent_role_names'].__getitem__(0) == 'test'
    assert result['ansible_parent_role_paths'].__getitem__(0) == '/Users/home/ansible/roles/test'


# Generated at 2022-06-23 07:07:18.808042
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    class Returned:
        pass
    class NewOne:
        @staticmethod
        def get_name():
            return 'role_abc'
    class Original:
        @staticmethod
        def get_name():
            return 'role_abc'
    r = Returned()
    r._task_include = NewOne()
    r.statically_loaded = False
    r._from_files = dict()
    r._parent_role = Original()
    r._role_name = 'role_name'
    r._role_path = 'role_path'
    copy_role = r.copy()
    assert copy_role.get_name() == 'role_abc'

# Generated at 2022-06-23 07:07:31.329398
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys

    import ansible
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    class TestTemplar(Templar):

        def __init__(self, loader, variables):
            super(Templar, self).__init__(loader, variables)

        def template(self, value, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, overrides=None):
            return value

    block = Block()

# Generated at 2022-06-23 07:07:38.428071
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    import tempfile
    import textwrap
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    file_name = 'test_IncludeRole.yml'
    tmp_dir = tempfile.mkdtemp()
    path = os.path.join(tmp_dir, file_name)

# Generated at 2022-06-23 07:07:53.223858
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    '''
    unit test for constructor of IncludeRole class.
    :return:
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import ROLE_CACHE
    from collections import namedtuple

    data = dict(
        name='test',
        become=False,
        become_user=None,
        check=False,
        gather_facts='smart')

    context = PlayContext()
    context.become = False
    context.become_method = None
    context.become_user = None
    context.remote_addr = None
    context.connection = 'local'
    context.timeout = 10
    context.shell = None
    context.remote

# Generated at 2022-06-23 07:08:04.661762
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    '''
    Method to test the get_method of class IncludeRole
    '''
    block = Block(0, None)
    role = Role()
    task_include = TaskInclude()
    task_include.name = 'task_include'
    task_include.args = {'name': 'test_1'}
    task_include.static = True
    task_inc = IncludeRole(block, role, task_include)
    name = task_inc.get_name()
    assert name == 'task_include: test_1'

# Generated at 2022-06-23 07:08:06.814391
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block
    IncludeRole(Block())


# Generated at 2022-06-23 07:08:16.579695
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.constants as C
    import ansible.playbook.role as role
    import ansible.playbook.role.include as rinclude
    import ansible.playbook.task as task
    import ansible.playbook.task_include as tinclude

    class MyRole(role.Role):
        pass

    class MyRoleInclude(rinclude.RoleInclude):
        pass

    class MyTaskInclude(tinclude.TaskInclude):
        pass

    class MyTask(task.Task):
        pass

    data = dict(
        name = 'foo',
        apply = dict(
            free_form = 1,
        ),
        public = 1,
        allow_duplicates = 0,
    )
    role = MyRole(name='bar')

# Generated at 2022-06-23 07:08:29.134115
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Set up the object IncludeRole under test
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    # Data for test
    data = {'name': "test_role", 'role': "test_role"}

    def_block = Block.load(data, play=None, task_include=None, role=None, loader=None, variable_manager=None, templar=None)
    role = Role.load(def_block, play=None, variable_manager=None, loader=None)
    task_include = IncludeRole.load(data, block=None, role=role, task_include=None, variable_manager=None, loader=None)

    # Unit test
    assert task_include.get_name() == 'include_role : test_role'



# Generated at 2022-06-23 07:08:38.767928
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    my_role = Role()
    my_block = Block()
    my_block.role = my_role
    my_block.vars = {'name': 'test_name'}
    my_role._role_path = 'test_role_path'
    my_role._metadata.name = 'test_title'

    my_include = IncludeRole(block=my_block, role=my_role)
    my_include_params = my_include.get_include_params()

    assert 'ansible_role_title' in my_include_params
    assert 'ansible_role_name' in my_include_params
    assert 'ansible_role_path' in my_include_params
    assert 'ansible_role_version' in my_include_params
    assert 'ansible_role_vars' in my_

# Generated at 2022-06-23 07:08:50.000346
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleParserError
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    v = dict(
        ansible_role_name="test_role",
        ansible_role_uuid="test_uuid",
        ansible_role_names=["test_role_2"],
        ansible_role_paths=["test_path"],
    )
    p = PlayContext()

# Generated at 2022-06-23 07:09:00.277131
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    p = Play()
    rr = RoleRequirement()
    rr.role_spec={'index': "localhost", 'role': "test", }
    p.roles.append(rr)
    rd = RoleDefinition.load({'name': 'test'})
    rr.role = rd
    ir = IncludeRole.load({'role': 'test', 'name': 'test'}, role=p)
    assert ir._role_name == 'test'
    assert ir.name == 'include_role : test'

# Generated at 2022-06-23 07:09:05.945969
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block0 = Block()
    role0 = Role()
    task_include0 = TaskInclude()
    ir = IncludeRole(block=block0, role=role0, task_include=task_include0)
    assert ir is not None
    assert ir._parent_role == role0
    assert ir._role_name == None
    assert ir._role_path == None

    data = {
        'name': 'role0',
        'public': True,
        'allow_duplicates': False,
        'rolespec_validate': True
    }
    ir = IncludeRole.load(data)
    assert ir is not None
    assert ir._parent_role == None
    assert ir._role_path == None
    assert ir._role_name == 'role0'
    assert ir.allow_duplicates == False
   

# Generated at 2022-06-23 07:09:16.842044
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    _block = Block()
    _block.role = Role()

    _ir = IncludeRole(block=_block, role=_block.role)

    # select attributes are private
    private_attrs = {'_allow_duplicates', '_public'}

    # set all attributes
    _ir.allow_duplicates = False
    _ir.loop = '{{ some_var_with_the_value_loop }}'
    _ir.public = True
    _ir.rolespec_validate = False
    _ir._role_name = 'rspec'
    _ir._from_files = {'tasks': 'tasks.yml', 'handlers': 'handlers.yml'}
    _ir.vars = {'var1': 'value1', 'var2': 'value2'}
    _

# Generated at 2022-06-23 07:09:26.682178
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    import json
    import yaml
    from ansible.utils.vars import combine_vars

    block_data = dict(
        name = 'test_role'
    )

    block = Block.load(block_data, play=None)
    assert block is not None
    assert isinstance(block, Block)

    task_include_data

# Generated at 2022-06-23 07:09:32.036360
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()

    task_include = IncludeRole(block=block, role=role)
    task_include._role_name = "role_name"

    assert task_include.get_name() == "- role_name"


# Generated at 2022-06-23 07:09:43.774368
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = {'name': 'test',
                   'hosts': 'localhost',
                   'gather_facts': 'no',
                   'tasks': [{'include_role': {'name': 'foobar'}}]}
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None
    play = play.instantiate(tqm)
    play._task

# Generated at 2022-06-23 07:09:56.223993
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible_collections.kbrebanov.cloudformation.tests.unit.playbooks import base_playbook
    from ansible_collections.kbrebanov.cloudformation.tests.unit.playbooks import test_playbook

    from ansible_collections.kbrebanov.cloudformation.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.kbrebanov.cloudformation.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.kbrebanov.cloudformation.tests.unit.modules.utils import ModuleTestCase

    # Setup the testcase
    results = dict(
        changed=False,
        original_message='',
        message=''
    )


# Generated at 2022-06-23 07:10:03.237377
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include = IncludeRole()
    include.name = 'test_include'
    include.action = 'include_role'
    include._parent_role = object()
    include._role_name = 'test_role'
    include._role_path = 'test_role_path'

    # Test get_include_params method
    v = include.get_include_params()
    assert v['ansible_role_name'] == 'test_role'
    assert v['ansible_role_path'] == 'test_role_path'

# Generated at 2022-06-23 07:10:10.678122
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """ Return (boolean, integer) : (test_result, number_of_tests) """
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.playbook.block import Block

    from units.mock.loader import DictDataLoader

    from ansible.errors import AnsibleParserError
    from ansible.utils.display import Display

    display = Display()

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}

    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    block = Block(play=lambda: 0)
    block._parent_role

# Generated at 2022-06-23 07:10:20.109728
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create some parents to put in the chain
    parent_role_mock = type('parent_role', (object,), {'get_role_params': lambda s: {'role_param': 1}, 'get_name': lambda s: 'parent_name'})()
    # Create a block for the parent_role
    parent_block = Block(block=None, role=parent_role_mock)
    # Create a new class for the include_role that overwrites the parent role
    my_include_role = type('my_include_role', (IncludeRole,), {'_parent_role': parent_role_mock, '_parent': parent_block})
    params = my_include_role().get_include_params()


# Generated at 2022-06-23 07:10:28.374234
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create a IncludeRole object
    ir = IncludeRole()

    # Call method: get_name of ir
    ret = ir.get_name()
    assert ret is None, 'Failed to get the default value of property: name'

    # Set the property: name
    ir.name = 'r1'
    ret = ir.get_name()
    assert ret == 'r1', 'Failed to set the value of property: name'

    # Create a IncludeRole object
    ir = IncludeRole()

    # Assign the property: ir._parent._play
    ir._parent._play = Play()

    # Assign the property: ir._role_name
    ir._role_name = 'role1'

    # Call method: get_name of ir
    ret = ir.get_name()

# Generated at 2022-06-23 07:10:29.669185
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = "nginx"
    assert ir.get_name() == "include_role : nginx"


# Generated at 2022-06-23 07:10:38.599835
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    data = {'role': 'test_role'}
    ir = IncludeRole.load(data, block, role)
    ir.static_vars = {'test_var': 'test_value'}

    new_ir = ir.copy()
    assert new_ir.static_vars == {'test_var': 'test_value'}
    assert id(new_ir) != id(ir)
    assert id(new_ir._from_files) != id(ir._from_files)
    assert new_ir._from_files == {}
    assert new_ir._parent_role is None
    assert new_ir._role_name == 'test_role'
    assert new_ir._role_path is None

# Generated at 2022-06-23 07:10:48.350249
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    with pytest.raises(AnsibleParserError) as exc:
        IncludeRole.load({'action': 'include_role', 'args': {'name': 'test_role'}})
    assert exc.value.message == "'name' is a required field for include_role."
    with pytest.raises(AnsibleParserError) as exc:
        IncludeRole.load({'action': 'include_role', 'args': {'name': 'test_role', 'public': True}})
    assert exc.value.message == 'Invalid options for include_role: public'
    with pytest.raises(AnsibleParserError) as exc:
        IncludeRole.load({'action': 'include_role', 'args': {'name': 'test_role', 'invalid_args': True}})
    assert exc.value.message

# Generated at 2022-06-23 07:10:59.009640
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = 'test'
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    new_ir = ir.copy()
    assert isinstance(new_ir, IncludeRole)
    assert new_ir._parent == block
    assert new_ir.action == task_include
    assert new_ir._parent_role == role
    assert new_ir._role_name == None
    assert new_ir._role_path == None
    assert new_ir._from_files == {}
    assert new_ir.statically_loaded == False
    assert new_ir.allow_duplicates == True
    assert new_ir.public == False
    assert new_ir.apply == {}
    assert new_ir.tags == set()
    assert new_

# Generated at 2022-06-23 07:11:08.584973
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    b = Block()
    r = Role()
    ir = IncludeRole(b, r)
    ir._role_name = 'role1'
    ir._parent_role = 'role2'
    ir._from_files = {'a': 'b'}
    ir._allow_duplicates = False
    ir._public = False
    ir._rolespec_validate = False
    ir.rolespec_validate = False
    ir.allow_duplicates = False
    ir.public = False

    new_me = ir.copy()
    assert ir.action == new_me.action
    assert ir.args == new_me.args
    assert ir._role_name == new_me._role_name
    assert ir._parent_role == new_me._parent_role
    assert ir._from_files == new_

# Generated at 2022-06-23 07:11:15.869646
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    data = {}
    variable_manager = {}
    loader = {}
    includeRole = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    includeRoleCopy = includeRole.copy()
    assert includeRoleCopy._block == block
    assert includeRoleCopy._role == role
    assert includeRoleCopy._task_include == task_include

# Generated at 2022-06-23 07:11:25.460024
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader

    ir = IncludeRole(block=Block(), role=RoleDefinition(), task_include=TaskInclude(block=Block(), task=Task()) )
    ir._role_name = 'test'
    ir._role_path = 'test'
    ir._parent = Block()
    ir._parent_role = RoleDefinition()

    loader = DataLoader()
    # loader.set_basedir('test')

    # test inshoud return Block_list
    result = ir.get_block_list(play='test', loader=loader)
    assert isinstance(result, tuple)

# Generated at 2022-06-23 07:11:30.276520
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition

    action = "test_include_role"
    args = {"name": "test_role", 'collection': 'test_collection'}
    task = IncludeRole(action=action, args=args)

    role_name = "test_role"
    role_path = "test_collection.test_role"
    role_args = {"name": role_name, "collection": 'test_collection'}
    role_definition = RoleDefinition(role_args=role_args)

    assert isinstance(task.get_block_list(role=role_definition)[0], list)

# Generated at 2022-06-23 07:11:40.792891
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # test for good role name and role_name only, for an statically loaded role
    block = Block()
    role = Role()
    task_include = TaskInclude()
    data = {'name': 'foo', 'public': True, 'statically_loaded': True}
    ir = IncludeRole.load(data=data, block=block, role=role, task_include=task_include)
    assert ir.statically_loaded == True
    assert ir.public == True
    assert ir._role_name == 'foo'
    assert ir.statically_loaded == True
    assert ir.args == data

    # test for good role name and role_name only, for an dynamically loaded role
    block = Block()
    role = Role()
    task_include = TaskInclude()

# Generated at 2022-06-23 07:11:52.684825
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role_name = "test_role"
    role_path = "path/to/role"
    from_files = {"tasks": "tasks/main.yml", "handlers": "handlers/main.yml"}
    parent_role = Role()
    _parent_role = Role()
    task = IncludeRole()
    task.statically_loaded = True
    task._from_files = from_files
    task._parent_role = parent_role
    task._role_name = role_name
    task._role_path = role_path
    new_me = task.copy(exclude_parent=False, exclude_tasks=False)
    assert vars(new_me) == vars(task)
    assert new_me is not task
    # test exclude_parent=True

# Generated at 2022-06-23 07:12:01.448003
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from werkzeug.datastructures import ImmutableMultiDict
    import ansible.playbook.role.include
    import ansible.playbook
    import ansible.constants
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.template.template
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.playbook.play_context

    # Create a role
    role = ansible.playbook.role.include.RoleInclude.load('TestRoleInclude')

    # Create a block with the role

# Generated at 2022-06-23 07:12:12.689274
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.block
    import ansible.playbook.role

    class AnsibleTask(ansible.playbook.block.Block):
        def __init__(self, parent, role):
            super(AnsibleTask, self).__init__(parent)
            self._role = role

        def get_vars(self):
            return {}

        def load_data(self, ds):
            return self

        def get_include_params(self):
            return {}

    class AnsibleRole(ansible.playbook.role.Role):
        def __init__(self, role_name=None, name=None, play=None, dep_chain=None, parent_role=None, from_files=None, from_include=False, validate=True):
            super(AnsibleRole, self).__init

# Generated at 2022-06-23 07:12:23.418881
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Assign
    block = Block()
    role = Role()
    role._role_path = '../../role_foo'
    role.name = 'role_foo'
    role.default_vars = {'v1': 'value1'}
    task_include = TaskInclude()
    task_include.vars = {'v2': 'value2'}
    ir = IncludeRole(block=block, role=role, task_include=task_include)

    # Act
    result = ir.get_include_params()

    # Assert

# Generated at 2022-06-23 07:12:24.163116
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir is not None

# Generated at 2022-06-23 07:12:32.491339
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    display.verbosity = 3
    ir = IncludeRole(block=None)
    assert ir._role is None
    assert ir._task_include is None
    assert ir._parent_role is None
    assert ir._public is False
    assert ir._allow_duplicates is True
    assert ir._from_files == {}
    assert ir._rolespec_validate is True
    assert ir._action == 'include_role'

# Generated at 2022-06-23 07:12:44.324820
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.verbosity = 3
    obj = IncludeRole()
    obj._parent_role = Role()
    obj._parent_role.get_role_params = lambda: {'ansible_role_names': ['foo', 'bar'], 'ansible_role_paths': ['baz', 'qux']}
    obj._parent_role.get_name = lambda: 'lorem'

    # The role_names and role_paths value for the parent role are expected to be prepended to the ones for the current role
    assert obj.get_include_params() == {'ansible_role_names': ['lorem', 'foo', 'bar'], 'ansible_role_paths': ['lorem', 'baz', 'qux']}

# Generated at 2022-06-23 07:12:56.462972
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Setup mock data
    mock_play_data = MockPlayData()
    mock_play_data.name = 'my_play'
    mock_play_data.base_path = 'my_play_base_path'

    mock_play_data.roles_path = []

    mock_play = MockPlay()
    mock_play.vars = {'some_var': 'some_value'}
    mock_play._dep_chain = []

    task_data = {}
    task_data['block'] = 'block1'
    task_data['name'] = 'my_task'
    task_data['include_role'] = 'my.role.name'
    task_data['collections'] = ['my_collection']
    task_data['no_log'] = True

    mock_parent_role = MockRole()


# Generated at 2022-06-23 07:13:05.834372
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name="test",
    )

    options = dict(
        vars=dict(test_var=5),
        tasks="test",
        role="test",
        tags=["test"],
    )

    role_data = dict(
        data,
        **options
    )

    block = Block()

    ir = IncludeRole.load(role_data, block=block)

    for key, value in options.items():
        assert getattr(ir, key) == value

    for key, value in data.items():
        assert getattr(ir, key) == value


# Generated at 2022-06-23 07:13:13.446504
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create P, R0, R1
    P = Role()
    R0 = Role(name='my-role-0')
    R1 = Role(name='my-role-1')

    # P |-> R0 |-> IR0
    P.add_child(R0)
    IR0 = IncludeRole()
    R0.add_child(IR0)

    # P |-> R1 |-> IR1
    P.add_child(R1)
    IR1 = IncludeRole()
    R1.add_child(IR1)

    params = IR1.get_include_params()

    assert params['ansible_role_name'] == 'my-role-0.my-role-1'

# Generated at 2022-06-23 07:13:22.776839
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.play_context import PlayContext

    t = IncludeRole()
    t._parent = Block()
    t.action = 'include_role'
    t.statically_loaded = True
    t._from_files = {'tasks':'test_tasks_filename', 'vars':'test_vars_filename'}
    t._parent_role = 'test_parent_role'
    t._role_name = 'test_role_name'
    t._role_path = 'test_role_path'
    t.apply = {'test_apply_key':'test_apply_value'}
    t.allow_duplicates = False

# Generated at 2022-06-23 07:13:32.286842
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    x = IncludeRole()
    x._role_name = 'test-role'
    x._role_path = 'test-path'
    x._parent_role = "test-parent"
    x._from_files = {"tasks": "tasks", "vars": "vars", "defaults": "defaults", "handlers": "handlers"}
    assert x.name == '- include_role: test-role'
    assert x._parent_role == 'test-parent'
    assert x._role_name == 'test-role'
    assert x._role_path == 'test-path'
    assert x._from_files == {"tasks": "tasks", "vars": "vars", "defaults": "defaults", "handlers": "handlers"}


# Generated at 2022-06-23 07:13:43.272783
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def _test_load(test_case, data, variable_manager=None, loader=None):
        _task = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
        _task_obj = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
        _task_obj.__class__ = IncludeRole
        _task_obj._parent = Block()

        for attr in ['_role_name', '_role_path', '_parent_role', '_from_files']:
            if getattr(_task, attr) != getattr(_task_obj, attr):
                display.display(u"%s: %s" % (attr, getattr(_task_obj, attr)))
                test_case.fail("%s is not equal" % attr)

   

# Generated at 2022-06-23 07:13:48.377950
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class test_IncludeRole(IncludeRole):
        pass

    test_IncludeRole_obj = test_IncludeRole(name='test_role')

    assert test_IncludeRole_obj.get_name() == 'test_role'


# Generated at 2022-06-23 07:13:53.319707
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.block import Block

    b = Block()

    ir1 = IncludeRole(block=b)
    ir2 = ir1.copy(exclude_tasks=True)

    assert(ir1._block is None)
    assert(ir2._block is None)

# Generated at 2022-06-23 07:13:57.133979
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    obj = IncludeRole()

    # Check the values of variables
    assert hasattr(obj, '_allow_duplicates')

    assert hasattr(obj, '_from_files')

    assert hasattr(obj, '_public')

    assert hasattr(obj, '_rolespec_validate')


# Generated at 2022-06-23 07:13:58.623121
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-23 07:14:04.864941
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Test constructor with defaults
    i = IncludeRole()
    assert i.action == 'include_role'
    assert i.statically_loaded is False
    assert i._from_files == {}
    assert i._parent_role is None
    assert i._role_name is None
    assert i._role_path is None

    # Test constructor with initializating parameters
    # Initializating with object of Block Class
    i_b = IncludeRole(block=Block())
    assert i_b.block.block  == []
    assert i_b.block.always == []
    assert i_b.block.rescue == []
    assert i_b.block.any_errors_fatal == False

    # Initializating with object of Role Class
    i_r = IncludeRole(role=Role())
    assert i_r.role._role

# Generated at 2022-06-23 07:14:13.403762
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    #
    # Construct a role for the test
    #
    class FakeRole(object):
        pass

    r = FakeRole()
    r.get_role_params = lambda: {'foo': 'bar'}

    #
    # Test the method
    #

    # make a dictionary that matches the arguments

# Generated at 2022-06-23 07:14:23.391353
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ur = IncludeRole()
    # Incorrect arguments
    try:
        ur.copy(exclude_parent=False, exclude_tasks=False, extra_arg=True)
        assert False
    except TypeError:
        assert True
    # Correct arguments

# Generated at 2022-06-23 07:14:26.284624
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert IncludeRole().get_include_params() == {'ansible_parent_role_names': [], 'ansible_parent_role_paths': []}


# Generated at 2022-06-23 07:14:37.133176
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    r = IncludeRole()

    r.statically_loaded = True
    r._from_files = {}
    r._parent_role = "parent role"
    r._role_name = "my role name"
    r._role_path = "path/to/roles"

    new_r = r.copy()

    assert new_r.statically_loaded == r.statically_loaded
    assert new_r._from_files == r._from_files
    assert new_r._parent_role == r._parent_role
    assert new_r._role_name == r._role_name
    assert new_r._role_path == r._role_path

    # the result of the copy should be the same if exclude_parent is True or not
    # in the call of copy method


# Generated at 2022-06-23 07:14:47.769853
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class MockRole(object):
        def __init__(self, name):
            self._metadata = type('obj', (object,), {
                'role_name': name,
                'role_path': name,
            })
        def get_name(self):
            return self._metadata.role_name
        def get_role_params(self):
            rtn = type('obj', (object,), self._metadata.__dict__.copy())
            rtn.allow_duplicates = True
            return rtn
    role1 = MockRole('mock1')
    role2 = MockRole('mock2')
    role3 = MockRole('mock3')


# Generated at 2022-06-23 07:14:58.412266
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import sys
    import os
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile

    block = Block()

    included_file = IncludedFile()
    included_file._filename = 'group_vars/all.yml'
    included_file._parent_role = None
    included_file._role_name = 'all'
    included_file._role_path = 'group_vars/all.yml'

    root_dir = os.path.dirname(sys.modules['ansible'].__file__)
    root_dir = root_dir[:-5]

    play = Play()
    play._basedir = root_dir
    play._file_name = os.path.join(play._basedir, 'group_vars/all.yml')


# Generated at 2022-06-23 07:15:07.836348
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Arrange
    ir = IncludeRole(name='role1')
    ir._parent_role = Role()
    ir._role_name = 'role1'
    ir.private = True
    ir._from_files = {}
    expected = IncludeRole(name='role1')
    expected._parent_role = Role()
    expected._role_name = 'role1'
    expected.private = True
    expected._from_files = {}
    # Act
    actual = ir.copy()
    # Assert
    assert actual.__dict__ == expected.__dict__


# Generated at 2022-06-23 07:15:14.220664
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = None
    ir = IncludeRole(block, role, task_include)
    ir.action='- include_role:'
    ir._role_name = 'role1'
    assert ir.get_name()=='role1'
    ir.name = 'include name 1'
    assert ir.get_name()=='include name 1'


# Generated at 2022-06-23 07:15:22.800798
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Test IncludeRole's method get_name.
    """
    
    # Test action is not valid.
    try:
        my_task_include = IncludeRole(
            block = Block(
                task_include = TaskInclude(
                    action = 'include_foo',
                    args = dict(),
                ),
            )
        )
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Should raise an exception when action is not valid.')

    # Test action is valid.
    my_task_include = IncludeRole(
        block = Block(
            task_include = TaskInclude(
                action = 'include_role',
                args = dict(),
            ),
        )
    )
    
    # Test error when name is not valid.

# Generated at 2022-06-23 07:15:34.497813
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common._collections_compat import MutableMapping

    # TODO: Move this to RoleInclude.load() as a real test
    # TODO: Move this to Role.load() as a real test

    inventory = InventoryManager

# Generated at 2022-06-23 07:15:38.931912
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole(role='role1')
    assert include_role.get_name() == ": role1"

    include_role = IncludeRole(name='name1', role='role1')
    assert include_role.get_name() == "name1 : role1"

# Generated at 2022-06-23 07:15:47.919977
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    from ansible_collections.ansible.community.tests.unit.mock.loader import DictDataLoader
    from ansible_collections.ansible.community.tests.unit.mock.vars import VariableManager
