

# Generated at 2022-06-23 07:05:53.718885
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    myIncludeRole = IncludeRole()
    assert isinstance(myIncludeRole, IncludeRole)
    assert isinstance(myIncludeRole, TaskInclude)
    assert isinstance(myIncludeRole, Block)
    assert myIncludeRole._parent_role is None
    assert myIncludeRole._from_files == {}
    assert myIncludeRole.statically_loaded is False
    assert myIncludeRole.name is None
    assert myIncludeRole.args == {}
    assert myIncludeRole.allow_duplicates is True
    assert myIncludeRole.rolespec_validate is True
    assert myIncludeRole.vars == {}


# Generated at 2022-06-23 07:06:04.448923
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import StringIO
    from ansible.plugins.loader import task_loader
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play_context
    import yaml
    yaml.SafeDumper.ignore_aliases = lambda self, data: True

    # save the existing stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    # with the existing stdout saved create a new stdout
    class MyStdout(object):
        def write(self, txt):
            mystdout.write(str(txt))
    sys.stdout = MyStdout()

    # data object of IncludeRole

# Generated at 2022-06-23 07:06:13.567418
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = dict(
        name='test-role',
        tasks_from='src/tasks.yml',
        vars_from='src/vars.yml',
        handlers_from='src/handlers.yml',
        defaults_from='src/defaults.yml',
        allow_duplicates=False,
        public=True,
    )
    ir = IncludeRole.load(data)
    assert ir._role_name == 'test-role'
    assert len(ir._from_files) == 4
    assert ir.allow_duplicates == False
    assert ir.public == True
    assert ir._block is None

# Generated at 2022-06-23 07:06:26.539397
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    import ansible.constants as C
    import ansible.utils.vars as avs
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'foo',
                                   'b': 'bar',
                                   'c': 'baz',
                                   'd': {'e': 'f',
                                         'g': 'h'}}

    templar = Templar(loader=loader, variables=variable_manager.get_vars())


# Generated at 2022-06-23 07:06:33.118812
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # As the methods are returning objects which are difficult to
    # compare as they are classes with many methods, we just check
    # if we are getting a block with same name. This should be
    # sufficient to check.
    action = 'include-role'
    data = {
        'name': 'test-role'
    }
    class TestBlock:
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name
    class TestRole:
        def __init__(self, role_name, role_path):
            self._role_path = role_path
            self._metadata = {
                'name': role_name,
                'allow_duplicates': True
            }

# Generated at 2022-06-23 07:06:45.870129
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """Return a dictionary of variables to use with the (parent) role in the context of the include task"""
    data = dict(
        name='fake_name',
        action='include',
        block=dict(
            name='fake_block_name',
            tasks=list()
        )
    )
    task_include = IncludeRole.load(data, block=Block(), loader=None)

    assert task_include.get_include_params() == {}

    data = dict(
        name='fake_name',
        action='include',
        block=dict(
            name='fake_block_name',
            tasks=list()
        ),
        role=Role(),
    )
    task_include = IncludeRole.load(data, block=Block(), loader=None)

# Generated at 2022-06-23 07:06:52.900862
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """include_role: Test IncludeRole.get_include_params"""
    def is_vars_equal(v, w):
        """Returns if variable v is equal to variable w"""
        #some of the variable types are not hashable
        #hence we convert them to dict
        if isinstance(v, dict) or isinstance(w, dict):
            return v == w
        return hash(type(v)) == hash(type(w)) and v == w

    def check_role_obj(ir, r):
        """Assert that IncludeRole objects ir and r have same parent_role"""
        assert is_vars_equal(ir._parent_role, r._parent_role)

    #Test a simple case where there is no parent role
    role1 = Role('/tmp/j', 'j', {}, [], [], {})


# Generated at 2022-06-23 07:06:57.723465
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_task = TaskInclude()
    include_role = IncludeRole()
    include_role.action = 'include_role'
    include_role.name = 'some_name'
    include_role._role_name = 'some_role_name'
    assert include_role.get_name() == include_task.get_name()

# Generated at 2022-06-23 07:07:02.691343
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(block=Block())
    assert ir.action != None
    assert ir.name != None
    assert ir.vars == dict()
    assert ir.args == dict()
    assert ir.block == Block()

# Generated at 2022-06-23 07:07:11.422447
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # setup data structures needed to run playbooks
    loader = DataLoader()
    playbook_path = 'playbook.yml'

    context = PlayContext()


# Generated at 2022-06-23 07:07:21.541720
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir._allow_duplicates = True
    ir._public = True
    ir._rolespec_validate = False

    new_ir = ir.copy()
    assert new_ir is not ir
    assert new_ir.statically_loaded is ir.statically_loaded
    assert new_ir._allow_duplicates is ir._allow_duplicates
    assert new_ir._public is ir._public
    assert new_ir._rolespec_validate is ir._rolespec_validate
    assert new_ir._parent_role is ir._parent_role
    assert new_ir._role_name is ir._role_name
   

# Generated at 2022-06-23 07:07:32.768069
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # This method accept different parameters, but the only one it is using is the block parameter
    block = Block()
    # It is initializing the other parameters to None or a empty list
    role = None
    task_include = None
    # since we do not need to validate the parameters of the method, we need to bypass them
    # for this purpose we are creating a class (IncludeRole_Mock) that inherits from IncludeRole,
    # and we are going to override the __init__ method so it does not validate the parameters
    # and we are going to pass a empty dict as the data parameter

# Generated at 2022-06-23 07:07:46.246343
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.vars import VarsModule

    pc = PlayContext()
    ds = DictDataLoader({})
    t = Templar(loader=ds)
    vars_mgr = VariableManager()

    # get the base of the block
    data = dict(
        name='test',
        role='test_role'
    )
    ir = IncludeRole()
    ret = ir.load(data=data, block=Block(), role=None, task_include=None, variable_manager=vars_mgr, loader=ds)
    assert ret._role_name == 'test_role'

# Generated at 2022-06-23 07:07:55.468715
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    block = Block()
    role = Role()
    role._role_path = 'roles/test/tasks'
    role._role_name = 'test'
    role._metadata = {'private_role': True}
    role._variable_manager = None
    role._dep_chain = None
    role._play = None
    role._loader = loader
    role._tqm = None
    role._collections = ''
    role._metadata.allow_duplicates = True
    role.tasks.append('test role tasks')
    role.handlers.append('test role handlers')

# Generated at 2022-06-23 07:08:03.644836
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import collections
    dct1 = {'a': 1, 'b': 2}
    dct2 = {'c': 3, 'd': 4}
    lst = [dct1, dct2]
    class mock_Block:
        def build_parent_block(self):
            return self
    class mock_Role:
        def get_name(self):
            return 'role_name'
        def get_role_params(self):
            return dct1
        def get_collections(self):
            return dct2
        def __init__(self):
            self._parents = collections.deque()
        def append(self, role):
            self._parents.append(role)
    class mock_variable_manager:
        pass
    class mock_loader:
        pass

    block = mock_Block()

# Generated at 2022-06-23 07:08:15.077859
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # test default values
    ir = IncludeRole(
        loader=loader,
        variable_manager=variable_manager,
        block=Block(),
        role=None,
        task_include=None
    )

    assert ir.allow_duplicates == True
    assert ir.rolespec_validate == True
    assert ir._role_name is None
    assert ir._role_path is None
    assert ir._from_files == {}
    assert isinstance(ir._parent_role, type(None))

    # test constructor with valid and invalid parameters

# Generated at 2022-06-23 07:08:21.179744
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class DummyRole():
        def __init__(self, name='test_DummyRole', role_path='/tmp/role_path'):
            self._name = name
            self._role_path = role_path
        def get_name(self):
            return self._name
        def get_role_params(self):
            return {'role_name': self._name}

    ir = IncludeRole()
    assert ir.get_include_params() == {}

    ir._parent_role = DummyRole()
    assert ir.get_include_params() == {'role_name': 'test_DummyRole',
                                       'ansible_parent_role_names': ['test_DummyRole'],
                                       'ansible_parent_role_paths': ['/tmp/role_path']}

# Generated at 2022-06-23 07:08:32.784843
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    o = IncludeRole()
    o._role_name = 'test_role'
    o._parent_role = Role()
    o._parent_role._role_path = '/path/to/parent/role'
    o._parent_role._role_name = 'parent_role'
    o._parent_role._metadata = Role()
    o._parent_role._metadata.dependencies = []
    o._parent_role._metadata.allow_duplicates = True
    o.public = False
    o.statically_loaded = False
    o.apply = {}
    o.allow_duplicates = True
    o._from_files = {}
    o.args = {}
    o.collections = []

    # Define the class RoleInclude.load to avoid error

# Generated at 2022-06-23 07:08:41.911195
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import Role
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.executor.task_result import TaskResult
    import ansible.utils.display as Display
    Display.verbosity = 4
    # role_name, role_path
    role_obj = Role.load('test_rolename')

    myblock = Block()

    # args, name, block, role, task_include, variable_manager, loader
    # args, name, block, role, task_include, loader
    include_obj = IncludeRole.load({'name': 'common'}, block=myblock, role=role_obj)

    # args
    assert include_obj.args == {'name': 'common'}

    # block
    assert include_obj.block == my

# Generated at 2022-06-23 07:08:53.929707
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    variable_manager = DummyVars()
    loader = DummyLoader()
    block = Block()
    task_include = TaskInclude()
    ir = IncludeRole(block, task_include=task_include)
    ir._action = 'include_role'
    ir.name = 'role_name'
    ir.args = {'apply': {}, 'public': True, 'allow_duplicates': False, 'rolespec_validate': False}
    ir.vars = {'role_name': 'role_1'}
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'test1.yml'}
    ir._role_name = 'test1'
    ir._role_path = 'test1'
    ir._parent_role = None
    new_ir = ir

# Generated at 2022-06-23 07:08:56.197321
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.collections.ansible.builtin.plugins.module_utils.common.removed import removed
    removed()


# Generated at 2022-06-23 07:09:00.035991
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    # Case 01
    ar1 = IncludeRole()
    ar1.statically_loaded = True
    ar1._from_files = {"tasks_from": "/home/ar1/tasks.yaml", "vars_from": "/home/ar1/vars.yaml", "defaults_from": "/home/ar1/defaults.yaml"}
    ar1._parent_role = "role1"
    ar1._role_name = "ar1"
    ar1._role_path = "/tmp/ar1"
    r1 = Block()
    r1._parent = 'apple'
    a = {"name": "apple"}
    r1.load_data(a, templar=None, attribute_errors=None)
    ar1._parent = r1

# Generated at 2022-06-23 07:09:03.706361
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include=task_include)
    assert ir._allow_duplicates.default == True
    assert ir._allow_duplicates.private == True
    assert ir._public.default == False
    assert ir._public.private == True
    assert ir._rolespec_validate.default == True

# Generated at 2022-06-23 07:09:15.236865
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Test function for IncludeRole._load
    '''
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    role_path = 'test/data/roles/test_role/'

    def _gen_ir(name, task_key, block_key, block, args):
        from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
        from ansible.template import Templar
        t = Templar(loader)

        # create role include
        action = AnsibleUnicode(name)
        block = Block.load(block_key, block, action=action, parent_block=block)
        task_include = AnsibleMapping(dict(args=t.template(args)))

# Generated at 2022-06-23 07:09:25.964721
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def test_load_with_parameters(action, data, role_name, parameters_dict,
                                  invalid_options_list=None, invalid_type_list=None):
        try:
            include_role = IncludeRole.load({'include': data}, task_include=Block.load({'block': 'task'}, role=Role.load({'name': 'my_role'}))).get_vars()
        except AnsibleParserError as e:
            assert str(e) == "Invalid options for %s: %s" % (action,
                                                             ','.join(invalid_options_list))
            return

# Generated at 2022-06-23 07:09:37.421171
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.parsing.mod_args import ModuleArgsParser

    yaml_data = dict(
        name="test_role",
        tasks=[
            dict(action=dict(module="command", args=dict(echo='hello')))
        ],
    )
    loader, inventory, variable_manager = C.load_extra_vars({})
    variable_manager = variable_manager
    play = C.load_playbook_file(yaml_data, variable_manager=variable_manager, loader=loader)

    module_args = dict(
        name=None,
        role="test_role"
    )
    parser = ModuleArgsParser(module_args, play)
    role_object = Role().load(yaml_data, variable_manager=variable_manager, loader=loader)
    task_include_object = TaskIn

# Generated at 2022-06-23 07:09:44.649802
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """ Load include_role tasks. """

    include_role_data = """
    - name: foo
      include_role:
        name: foo
    - name: bar
      include_role:
        name: bar
        tasks_from: foo/main.yml
        vars_from: foo/main.yml
        apply:
           tags:
             - foo
    - include_role:
        name: foobar
        role: foobar
    - name: foobaz
      include_role:
        name: foobaz
        apply:
          tags:
            - foobaz
    - name: foobaz2
      include_role:
        name: foobaz2
        apply:
          tags:
            - foobaz2
    """

    # Create a basic block for testing
    testblock = Block

# Generated at 2022-06-23 07:09:48.619351
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(task_include={'role': 'some_role', 'name': 'some_role'})
    assert ir.statically_loaded
    assert ir._parent is None
    assert ir._role_name == 'some_role'
    assert ir._role_path == None


# Generated at 2022-06-23 07:09:54.033946
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = "IncludeRole"
    assert ir.get_name() == "IncludeRole"
    ir.name = None
    ir.action = "action"
    ir._role_name = "role_name"
    assert ir.get_name() == "action : role_name"


# Generated at 2022-06-23 07:10:02.838938
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    include_role.name = 'test_get_name'
    assert include_role.get_name() == 'test_get_name'
    include_role.name = None
    include_role.action = 'include'
    include_role._role_name = 'test_get_name'
    assert include_role.get_name() == 'include : test_get_name'


# Generated at 2022-06-23 07:10:03.467164
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:10:08.837571
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    include_role_obj = IncludeRole()
    assert include_role_obj._allow_duplicates is True
    assert include_role_obj._parent_role is None
    assert include_role_obj._public is False
    assert include_role_obj._role_name is None
    assert include_role_obj._role_path is None
    assert include_role_obj._rolespec_validate is True

# Generated at 2022-06-23 07:10:14.868208
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    host_variables = dict(group1=dict(fqdn="google.com"), group2=dict(fqdn="yahoo.com"))
    expected_task_name = "include_role : google.com"

    # Create the Block object
    block = Block()

    # Create the Role object
    role = Role()
    role._role_path = "/a/b/c"

    # Create the TaskInclude object
    task_include = TaskInclude('include_role')
    task_include.args = dict(name="google.com")

    # Create an IncludeRole object
    ir = IncludeRole(block=block, role=role, task_include=task_include)

    # Check the IncludeRole object created matches what was expected
    assert ir.action == task_include.action
    assert ir.args == task_include.args

# Generated at 2022-06-23 07:10:17.302361
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.name = ''
    ir._role_name = 'role'
    assert ir.get_name() == 'include_role : role'

# Generated at 2022-06-23 07:10:26.417097
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import os

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader)
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    fake_play_context = PlayContext()


# Generated at 2022-06-23 07:10:30.231590
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play import Play

    play_context = Play().set_play_context(None)
    play_context.set_variable_manager(None)
    play_context.set_loader(None)

# Generated at 2022-06-23 07:10:39.118695
# Unit test for constructor of class IncludeRole

# Generated at 2022-06-23 07:10:48.589678
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role

    mock_play = Play()
    # stub role_name
    role_name = "test_role"
    # stub role_path
    role_path = "path/to/role"
    # stub parent_role
    parent_role = Role()
    # stub role_include
    role_include = RoleInclude(role_name, mock_play)
    # stub include_role_obj
    include_role_obj = IncludeRole(role=parent_role, role_include=role_include)
    # give include_role_obj a role_path
    include_role_obj._role_path = role_path
    # run method
    include_params = include

# Generated at 2022-06-23 07:10:54.201008
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    result = IncludeRole()

    assert result
    assert result.action == 'include_role'
    assert result.parent is None
    assert result.args is None
    assert result.vars is None
    assert result.default_vars is None
    assert result.always is None
    assert result.changed_when is None
    assert result.when is None
    assert result.register is None
    assert result.delegate_to is None
    assert result.run_once is None
    assert result.run_once_enabled is None
    assert result.ignore_errors is None
    assert result.free_form is None
    assert result.role is None
    assert result.loop is None
    assert result.notify is None
    assert result.tags == set([])
    assert result.meta is None
    assert result.collections is None
   

# Generated at 2022-06-23 07:11:04.370264
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    From_data = {
        "block": [{
            "name": "tasks",
            "children": [{
                "name": "role",
                "args": {
                    "name": "webserver"
                },
                "block": []
            }]
        }],
        "role": {
            "name": "test_role",
            "path": "/etc/ansible/roles/test_role",
        },
    }
    f = IncludeRole(**From_data)
    assert f.get_name() == 'include_role : webserver'
    assert f._parent_role.name == 'test_role'
    assert f._role_name == 'webserver'
    assert f._role_path == '/etc/ansible/roles/test_role'

# Generated at 2022-06-23 07:11:14.669353
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(Block(parent_block=dict(role=Role())), Role())
    assert ir.get_name() == 'set_fact: null'
    ir2 = IncludeRole(Block(parent_block=dict(role=Role())), Role(), args=dict(name='toto'))
    assert ir2.get_name() == 'toto'
    ir3 = IncludeRole(Block(parent_block=dict(role=Role())), Role(), args=dict(role='toto'))
    assert ir3.get_name() == 'toto'
    ir4 = IncludeRole(Block(parent_block=dict(role=Role())), Role(), args=dict(name='toto', role='tutu'))
    assert ir4.get_name() == 'toto'

# Generated at 2022-06-23 07:11:24.705112
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test case 1:
    # Test object with _parent_role: None and
    #               role_params: {}
    ir1 = IncludeRole()
    ir1._parent_role = None
    ir1.role_params = {}
    assert ir1.get_include_params() == {}

    # Test case 2:
    # Test object with _parent_role: a Role object and
    #               role_params: {}
    ir2 = IncludeRole()
    ir2._parent_role = Role()
    ir2._parent_role.get_name = lambda : "TestRole"
    ir2._parent_role.get_role_params = lambda : {}
    ir2.role_params = {}

# Generated at 2022-06-23 07:11:36.893170
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.meta import RoleMetadata
    meta_args = {
        'name': 'role-name',
        'namespace': 'namespace',
    }
    meta = RoleMetadata.from_name('role-name', **meta_args)
    parent_role = Role(name='parent-role', role_path='/parent-role', metadata=meta)

    meta_args['name'] = 'child-role'
    meta_args['namespace'] = 'child-namespace'
    meta = RoleMetadata.from_name('child-role', **meta_args)
    child_role = Role(name='child-role', role_path='/child-role', metadata=meta)

    ir = IncludeRole(role=parent_role)
    ir._parent_role = parent_role
    ir._

# Generated at 2022-06-23 07:11:48.909065
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.template import Templar
    class IncludeRole_Test:
        def __init__(self):
            self.templar = Templar(loader=None)
            self.action = 'include_role'
            self.args = {
                'name': 'myrole'
            }
            self.allow_duplicates = True
            self.public = True
            self.rolespec_validate = True
            self._parent = None
            self._parent_role = None
            self._role_name = None
            self._role_path = None

    class Role_Test:
        def __init__(self):
            self._rolespec_validate = True
            self._metadata = self
            self._role

# Generated at 2022-06-23 07:11:55.204534
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    task = IncludeRole()
    task._parent_role = TaskInclude()
    task._parent_role._role_path = '/path1'
    assert task.get_include_params() == {'ansible_parent_role_names': ['include_role'],
                                         'ansible_parent_role_paths': ['/path1']}

# Generated at 2022-06-23 07:11:58.839795
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # constructor with base class
    ir = IncludeRole(block=Block())

    # constructor with Role class
    role = Role()
    ir = IncludeRole(role=role)

    # constructor with TaskInclude class
    ti = TaskInclude(block=Block())
    ir = IncludeRole(task_include=ti)

# Generated at 2022-06-23 07:12:06.784138
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    task = dict(name="test")
    test_block = Block.load(task, task, role=None)
    test_obj = IncludeRole.load(task, block=test_block)
    assert(isinstance(test_obj, IncludeRole))
    assert(isinstance(test_obj.copy(exclude_parent=False), IncludeRole))
    assert(isinstance(test_obj.copy(exclude_parent=True), IncludeRole))
    assert(isinstance(test_obj.copy(exclude_tasks=False), IncludeRole))

# Generated at 2022-06-23 07:12:16.813411
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """IncludeRole - load"""
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.errors import AnsibleParserError
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = variable_manager._loader

    play_source = dict(
        name="Ansible Play 1",
        hosts='localhost',
        gather_facts='no',
        roles=['test_role']
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    role = play.get_roles()[0]
    task_include_source

# Generated at 2022-06-23 07:12:26.233898
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # case 1:
    # testing with no block no task_include
    ir1 = IncludeRole()
    assert ir1._block is None
    assert ir1._task_include is None
    assert ir1.static is False
    assert ir1.statically_loaded is False
    assert ir1._parent is None
    assert ir1._role is None
    assert ir1._role_name is None
    assert ir1._role_path is None
    assert ir1._from_files is None
    assert ir1._parent_role is None

    # case2:
    # testing without role
    ir2 = IncludeRole(block=Block())
    assert isinstance(ir2._block, Block)
    assert ir2._task_include is None
    assert ir2.static is False
    assert ir2.statically_loaded is False

# Generated at 2022-06-23 07:12:38.358773
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create a class object of class IncludeRole without params
    # Parameters
    ir_obj = IncludeRole()
    # Create a string for action
    action = 'include_role'
    # Create a dict for data
    data = {'role': 'test_role', 'allow_duplicates': True}
    # load the parameters from data
    ir_obj.load(data, action=action)
    # assert the name of the role
    assert ir_obj._role_name == 'test_role'
    # assert the allow_duplicates
    assert ir_obj.allow_duplicates == True
    # Create a dict for data with extra attribute
    data = {'role': 'test_role', 'allow_duplicates': True, 'register': "result"}

# Generated at 2022-06-23 07:12:40.737775
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole({'name': 'test'}, {'name': 'test'})
    assert task.get_name() == 'test : test'

# Generated at 2022-06-23 07:12:45.182267
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test 1
    # Data in
    test1_data = {
        'block': 'block'
    }
    # Expected result
    test1_expected = (None, None)
    test1_instance = IncludeRole(test1_data.get('block'))

    assert(test1_instance.get_block_list() == test1_expected)

# Generated at 2022-06-23 07:12:51.179392
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    class TestRole(Role):
        def get_role_params(self):
            return {'key0': 'value0'}
        def get_name(self):
            return 'role0'

    play_context = PlayContext()
    play_context.become = True
    play_context.diff = True
    play_context.remote_addr = 'remote_addr1'


# Generated at 2022-06-23 07:12:58.950277
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import os
    import tempfile
    import shutil

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create temporary files
    main = tempfile.mkstemp(prefix='main', suffix='.yml', dir=tmp_dir)
    os.close(main[0])

    # create role files
    role1 = tempfile.mkdtemp(prefix='role1', dir=tmp_dir)
    os.mkdir(os.path.join(role1, 'tasks'))
   

# Generated at 2022-06-23 07:13:04.020344
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task_include = IncludeRole()
    task_include.args = dict(name='role_name', apply=dict())
    assert task_include.get_name() == 'role_name'
    task_include.name = 'my_name'
    assert task_include.get_name() == 'my_name'



# Generated at 2022-06-23 07:13:12.447362
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # TODO: rewrite this test. get_block_list is not doing what is says in the documentation.
    #       It should not return anything, it should add it to the play's blocks, usually via calling get_handler_blocks
    #       To get something back, you call play.compile().
    #       In the end it should be a function that adds the returned block and the handler block to the play.

    # case1:
    # The method get_block_list, adds the role to a block, which is then attached to the play.
    # No handler is involved in this and no handler is returned by get_block_list.
    loader, inventory, variable_manager = BaseTest.get_loader_inventory_variable_manager('test_data/include_role_case1')

# Generated at 2022-06-23 07:13:14.513862
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    a = IncludeRole()
    assert isinstance(a.copy(), IncludeRole)

# Generated at 2022-06-23 07:13:25.312813
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role = Role()
    role._metadata = {"name": "test_role", "path": "/test_path"}
    role.tasks = ["tasks/main.yml"]
    role.defaults = ["defaults/main.yml"]
    role.meta = ["meta/main.yml"]
    role.handlers = ["handlers/main.yml"]
    role.vars = ["vars/main.yml"]

    ir = IncludeRole()
    ir.statically_loaded = True
    ir._role_name = "test_role"
    ir._role_path = "/test_path"
    ir._parent_role = role
    new_ir = ir.copy()
    assert new_ir.statically_loaded
    assert new_ir._role_name == ir._role_name
    assert new_

# Generated at 2022-06-23 07:13:34.092537
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import role_loader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost'])

    play = Play()
    play.role_names = ['test_role']

    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Get the Role
    test_role = role_loader.get('test_role', play=play, variable_manager=variable_manager, loader=loader)
    # Test Role

# Generated at 2022-06-23 07:13:43.931601
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = IncludeRole(block, role)

    # First copy should use the defaults
    new_task_include = task_include.copy()
    assert new_task_include._from_files == {}
    assert new_task_include.statically_loaded == False

    # Second copy should use the defined test values
    task_include._from_files = {'tasks': 'test_tasks.yml'}
    task_include.statically_loaded = True
    new_task_include = task_include.copy()
    assert new_task_include._from_files == {'tasks': 'test_tasks.yml'}
    assert new_task_include.statically_loaded == True

# Generated at 2022-06-23 07:13:56.248107
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext

    rd = dict(
        name="rd",
    )

    ir = IncludeRole(rd)

    assert ir._role_name == 'rd'
    assert not ir.statically_loaded
    assert not ir.static_loaded
    assert ir.vars == {}
    assert ir.tags == []
    assert ir.when is None
    assert ir.always is None
    assert ir.delegate_to is None
    assert ir.loop is None
    assert ir.connection == ''
    assert ir.loop_control is None
    assert ir.register is None
    assert ir.ignore_errors is None
    assert ir.local_action is None
    assert ir.transport is None
    assert ir.any_errors_fatal is None
    assert ir.notify is None

# Generated at 2022-06-23 07:14:00.313707
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    assert IncludeRole(block, role, task_include)

# Generated at 2022-06-23 07:14:09.435758
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    data = {}
    block = {}
    task_include = {}
    role = {}
    variable_manager = {}
    loader = {}
    ir = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    ir.name = 'name_OK'
    ir._role_name = 'ir_role_name_OK'
    assert ir.get_name() == 'name_OK'
    ir.name = ''
    assert ir.get_name() == 'ir_role_name_OK'


# Generated at 2022-06-23 07:14:12.863662
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir._role is None
    assert ir._parent_role is None
    assert ir._role_name is None
    assert ir._role_path is None
    assert ir._from_files == {}
    assert ir._tasks == []
    assert ir.apply == {}
    assert ir.name is None
    assert ir.action == 'include_role'
    assert ir.vars == {}

# Generated at 2022-06-23 07:14:23.109864
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # pylint: disable=too-many-locals,too-many-statements
    # pylint: disable=line-too-long
    try:
        from ansible.plugins.loader import add_all_plugin_dirs, find_plugin
        from ansible.playbook.play_context import PlayContext
    except ImportError:
        return

    class PlayContextShim(object):
        def __init__(self):
            self.cur_host = 'localhost'
            self.hostvars = {
                'localhost': dict()
            }
            self.vars = dict()
            self.defer_facts = False

        def get_vars(self, play, task):
            return self.vars

    class RunnerShim(object):
        def __init__(self):
            self.get_extra

# Generated at 2022-06-23 07:14:25.614649
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(block=Block(parent_block=Block(), role=Role()), role=Role())
    ir._role_name = 'role_name'
    assert ir.get_name() == 'include_role : role_name'


# Generated at 2022-06-23 07:14:34.453817
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test for error: 'name' is a required field for include_role
    fake_loader = DictDataLoader({
        '/foo/bar/myrole.yml': '',
    })

    data = dict(
        name='myrole',
        role=dict(
            name='myrole',
            tasks_from='/foo/bar/myrole.yml',
        )
    )
    test_include_role = IncludeRole.load(data, loader=fake_loader)
    test_include_role.copy()


# Generated at 2022-06-23 07:14:45.723829
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, Block)
    assert ir.BASE == ('name', 'role')
    assert ir.FROM_ARGS == ('tasks_from', 'vars_from', 'defaults_from', 'handlers_from')
    assert ir.OTHER_ARGS == ('apply', 'public', 'allow_duplicates', 'rolespec_validate')
    assert ir.VALID_ARGS == frozenset(ir.BASE + ir.FROM_ARGS + ir.OTHER_ARGS)

    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True

    assert ir._from_files == dict()
    assert ir._parent_role is None

# Generated at 2022-06-23 07:14:56.701583
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    b1 = Block()
    b1.parent = None
    b1.role = 'role1'

    ir1 = IncludeRole(block=b1)
    ir1.args = {'name': 'role2'}

    ir2 = ir1.copy()
    assert ir1.block == None
    assert ir1.tasks == None
    assert ir1.role == 'role1'
    assert ir1.args == {'name': 'role2'}
    assert ir1.statically_loaded == None

    assert ir2.block == None
    assert ir2.tasks == None
    assert ir2.role == 'role1'
    assert ir2.args == {'name': 'role2'}
    assert ir2.statically_loaded == None

# Generated at 2022-06-23 07:15:09.505989
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.plugins.loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-23 07:15:17.079257
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    taskinc = TaskInclude()
    role.action = "include_role"
    role._role_name = "include_role_test"
    ir = IncludeRole(block, role, taskinc)
    # We don't care much what the name will be.
    #The only important thing is that it is the same in python2 and python3
    #and that it has the role name included_role_test.
    assert ir.get_name() == "include_role"
    assert "include_role_test" in ir.get_name()

# Generated at 2022-06-23 07:15:22.359828
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    role.name = "test_name"
    task_include = TaskInclude()
    task_include.name = "test_name"
    role_include = IncludeRole(block, role, task_include)
    role_include.name = "test_name"
    assert role_include.get_name() == "test_name : test_name"

    task_include.name = None
    assert role_include.get_name() == "include_role : test_name"

# Generated at 2022-06-23 07:15:29.629712
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    i = IncludeRole()
    i.action = 'toto'
    i.args = {'role': 'test_role'}
    i._role_name = 'test_role'
    t = {'action': 'toto', 'from_files': {}}
    display.debug = lambda *args, **kwargs: None
    assert i.get_block_list()[0][0].serialize() == t

# Generated at 2022-06-23 07:15:37.125217
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Setup test data
    data = {
        'block': None,
        'role': None,
        'task_include': None,
        'args': {
            'name': 'role_name',
            'apply': {}
        }
    }

    # Create a IncludeRole object
    ir = IncludeRole.load(data)

    # Run get_include_params function
    result = ir.get_include_params()

    # Verify test result
    assert isinstance(result, dict)

# Generated at 2022-06-23 07:15:41.595563
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Unit test for method get_block_list of class IncludeRole
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import display
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import Role

# Generated at 2022-06-23 07:15:45.841322
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'some_name'
    ir.action = 'some_action'
    ir._role_name = 'some_role_name'
    assert ir.get_name() == 'some_name : some_role_name'

    ir.name = None
    assert ir.get_name() == 'some_action : some_role_name'

# Generated at 2022-06-23 07:15:51.922764
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.inventory.host as host
    import ansible.parsing.yaml.data as data
    import ansible.utils.vars as utils_vars

    play_context = PlayContext()
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.check_mode = False
    play_context.network_os = 'network'
    play_context.remote_addr = '0.0.0.0'