

# Generated at 2022-06-23 07:05:53.688633
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Unit test for method load of class IncludeRole.
    """
    import ansible.errors as ans_err
    import ansible.playbook.task_include as ans_t_i

    import ansible.playbook.play_context as p_play_c
    context = p_play_c.PlayContext()

    role = ans_t_i.RoleInclude()
    role.action = 'include'
    role.name = 'role'

    # test if the AnsibleParserError is thrown if parameter 'name' is set to None
    data = {'name' : None}
    try:
        ans_t_i.IncludeRole.load(data, block=None, role=role, task_include=None)
        assert False
    except AnsibleParserError as e:
        assert True

    # test if the

# Generated at 2022-06-23 07:05:58.467332
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    test_obj = IncludeRole()
    try:
        test_obj.get_include_params()
    except Exception as exc:
        assert False, "Calling IncludeRole().get_include_params() raised Exception '%s'" % (exc)

# unit testing
if __name__ == "__main__":
    test_IncludeRole_get_include_params()

# Generated at 2022-06-23 07:06:08.286108
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    # Create a simple task to include
    playbook_path = '/etc/ansible/test_playbook.yml'
    play_ds =  dict(
        name = "Ansible Play Test",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = []
    )

    # Create a simple block to include
    block_ds =  dict(
        name = "Test Task Block",
        rescue = [],
        always = [],
        tasks = []
    )

    # Create a simple role to include
    role_ds =  dict(
        name = "Ansible Role Test",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = []
    )

    # Create a simple block to include

# Generated at 2022-06-23 07:06:18.260284
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # This test should assert the load function of class IncludeRole
    # By setting arguments to the function, we can test whether the function always works correctly
    # We can test the load function by setted values or not
    import imp
    import os
    import sys
    import unittest

    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.dataloader import DataLoader

    from units.mock.loader import DictDataLoader

    class TestIncludeRoleClass(unittest.TestCase):
        ''' include_role module unit test class'''

        maxDiff = None
        def setUp(self):
            self._loader = DictDataLoader({})
            self._basedir = os.getcwd()


# Generated at 2022-06-23 07:06:19.491588
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:06:29.633054
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole()
    ir._validate_options = lambda *a, **k: None

    # All valid_args are passed in
    assert (sorted(ir.load({'name': 'name',
                            'apply': {},
                            'tasks_from': 'tasks_from',
                            'vars_from': 'vars_from',
                            'defaults_from': 'defaults_from',
                            'handlers_from': 'handlers_from',
                            'allow_duplicates': True,
                            'public': True}).args) ==
            sorted(IncludeRole.VALID_ARGS))

    # Invalid options are passed in

# Generated at 2022-06-23 07:06:31.367061
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    obj = IncludeRole()
    assert isinstance(obj, IncludeRole)

# Generated at 2022-06-23 07:06:39.464897
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Test with valid arguments
    valid_arguments = dict(
        name='valid_name'
    )
    ir = IncludeRole().load(dict(include_role=valid_arguments), loader=None, variable_manager=None)
    assert ir.name == 'valid_name'

    # Test with invalid arguments (non-existing keys)
    invalid_arguments = dict(
        non_existing_key='invalid_value'
    )
    try:
        ir = IncludeRole().load(dict(include_role=invalid_arguments), loader=None, variable_manager=None)
    except AnsibleParserError:
        pass
    else:
        assert False, "Should have raised AnsibleParserError"

    # Test with invalid arguments (wrong value type)

# Generated at 2022-06-23 07:06:41.809867
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role = Role()
    role.name = 'a_role'
    role._role_path = 'path'
    include_role = IncludeRole(role=role)
    res = include_role.get_include_params()
    assert res == {'ansible_parent_role_names':['a_role'], 'ansible_parent_role_paths':['path']}

# Generated at 2022-06-23 07:06:50.789308
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir._parent is None
    assert ir.post_validate is None
    assert ir.always is None
    assert ir.register is None
    assert ir.ignore_errors is None
    assert ir.when is None
    assert ir.delegate_to is None
    assert ir.notify is None
    assert ir.first_available_file is None
    assert ir.tags == []
    assert ir._loop is None
    assert ir.name is None
    assert ir._role_name is None
    assert ir.action == 'include_role'
    assert ir._role_path is None
    assert ir.when_file is None
    assert ir.loop_control is None
    assert ir._role_params is None
    assert ir._role_name is None
    assert ir._parent_role is None
   

# Generated at 2022-06-23 07:06:52.374712
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(data={'name': 'webservers'})
    assert ir.name == 'webservers'
    assert ir.args == {'name': 'webservers'}


# Generated at 2022-06-23 07:06:57.979467
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    block = Block()
    role = Role()
    task_include = TaskInclude()

    include_role = IncludeRole(block, role, task_include)
    include_role.vars = {'myvar': 'myvalue'}

    assert include_role.get_include_params() == {'myvar': 'myvalue'}

# Generated at 2022-06-23 07:07:09.736804
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    block_list = []

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        "foo": "bar",
        "baz": "baz_value"
    }
    variable_manager.options_vars = {
        "foo": "bar",
        "baz": "baz_value"
    }


# Generated at 2022-06-23 07:07:20.049942
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import json

    def load(data):
        loader, blocks, variable_manager = setup_loader()
        ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
        return ir._from_files



# Generated at 2022-06-23 07:07:32.019672
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class MockRoleDefinition(RoleDefinition):
        def __init__(self):
            pass

    class MockRoleInclude(RoleInclude):
        def __init__(self):
            pass

    class MockTemplar(Templar):
        def __init__(self):
            pass

    class MockVariableManager(VariableManager):
        def __init__(self):
            pass

    ir = IncludeRole()
    ir._role_name = 'foo'

# Generated at 2022-06-23 07:07:36.750826
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    obj = IncludeRole(block=block, role=role)
    assert obj is not None and obj._parent_role == role and obj._role_name is None and obj._role_path is None

# Generated at 2022-06-23 07:07:52.003225
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    # Test cases
    #
    # Whether the spec of
    # a role include is correct or not
    #
    # Following are test cases.
    #
    # "case00"
    #   name: test
    #   apply:
    #     tags: test
    #     ignore_tags: ignore
    #   vars_from: path/to/vars
    #
    # "case01"
    #   name: test
    #   tasks_from: path/to/tasks
    #   handlers_from: path/to/handlers
    #   vars_from: path/to/vars
    #   defaults_from: path/to/defauls
    #
    # "

# Generated at 2022-06-23 07:07:58.801760
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.plays import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.plugins import module_loader
    from ansible.module_utils.six import string_types
    # Load plugins
    module_loader.add_directory(module_loader._get_path_to('modules'))
    add_all_plugin_dirs()

    # variables
    display = Display()

# Generated at 2022-06-23 07:08:10.231734
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role_params = include_role.get_include_params()
    assert include_role_params == {}

    block = Block()
    role = Role()
    role.set_name("test_role")
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role_params = include_role.get_include_params()
    assert include_role_params == {'ansible_parent_role_names': ['test_role'], 'ansible_parent_role_paths': [None]}


# Generated at 2022-06-23 07:08:10.976938
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-23 07:08:24.010485
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes

    class Options:
        _private = 0
        verbosity = 0
        inventory = "localhost,"
        listhosts = None
        subset = None
        module_paths = None
        extra_vars = None
        forks = None
        ask_vault_pass = None
        vault_password_files = None
        new_vault_password_file = None
        output_file = None
        tags = []
        skip_tags = []
        one_line = None
        tree = None
        ask_sudo_pass = None
        ask_su_pass = None
        sudo = None
        sudo_user = None
        become = None
        become

# Generated at 2022-06-23 07:08:34.298454
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import role_loader


# Generated at 2022-06-23 07:08:36.456092
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole(block=None, role=None, task_include=None)
    assert ir is not None


# Generated at 2022-06-23 07:08:43.453519
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    r1 = IncludeRole(role=Role())
    r1._parent = Block(play=Play())
    r1._parent_role = Role()
    r1._parent_role.name = 'test'
    r1._parent_role.path = 'test'
    r1._parent_role._role_path = 'test'
    assert 'ansible_role_names' in r1.get_include_params().keys()
    assert 'ansible_role_paths' in r1.get_include_params().keys()
    assert 'test' in r1.get_include_params()['ansible_role_names']
    assert 'test' in r1.get_include_params()['ansible_role_paths']
    assert 'ansible_parent_role_names' in r1.get_include_params().keys

# Generated at 2022-06-23 07:08:54.924895
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    block = Block()
    block.register_inclusion_path('foo', 'baz')
    parent_role = Role()

    ir1 = IncludeRole(block, role=parent_role)
    ir1.statically_loaded = True
    ir1.apply = 'foo'
    ir1.public = False
    ir1.allow_duplicates = False
    ir1._from_files = {'tasks': 'tasks.yml'}
    ir1._parent_role = parent_role
    ir1._role_name = 'my_role'
    ir1._role_path = 'role/path'

    ir2 = ir1.copy()
    if id(ir1) == id(ir2):
        raise AssertionError("id(ir1) should not equal id(ir2)")


# Generated at 2022-06-23 07:09:03.006038
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    C.DEFAULT_ROLES_PATH = '/foo'
    C.DEFAULT_ROLES_PATH = '/foo:/bar'
    display.verbosity = 3
    display.deprecated('TEST')
    ds = dict(
        name="parent_role",
        dependencies=None,
        tasks=None,
        default_vars=None,
        vars_files=None,
        handlers=None,
    )
    data = Block.load(ds, play=None, variable_manager=None, loader=None)
    data.post_validate(templar=Templar(loader=None, variables={}))
    role = Role().load(data, play=None)
    role.post_validate(templar=Templar(loader=None, variables={}))
    ds = dict

# Generated at 2022-06-23 07:09:04.549298
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole.__name__ == "IncludeRole"



# Generated at 2022-06-23 07:09:15.958152
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    # Create Play
    play_name = AnsibleUnicode('test_play')
    play_hosts = AnsibleUnicode('all')
    play_roles = []
    play_tasks = []
    play_handler = {}
    play_vars = {}
    play_vars_prompt = {}
    play_

# Generated at 2022-06-23 07:09:26.263945
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    yaml_data = """
    - hosts: localhost
      roles:
      - role: test_foo
    """
    # setup the play and include role instance
    play_ctx = PlayContext()
    play = Play().load(yaml_data, play_context=play_ctx, variable_manager=None)
    block = play.get_block_list()[0]
    task = block.block[0]
    task._role._role_path = '/path/to/roles/test_foo'
    role = task._role
    role.vars = dict()
    role_name = task._role_name

    # setup the include role instance
    play_ctx1 = PlayContext()

# Generated at 2022-06-23 07:09:34.391116
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    v = dict()
    v.setdefault('ansible_parent_role_names', []).insert(0, 'ansible_parent_role_name')
    v.setdefault('ansible_parent_role_paths', []).insert(0, 'ansible_parent_role_path')
    assert v == {'ansible_parent_role_names': ['ansible_parent_role_name'], 'ansible_parent_role_paths': ['ansible_parent_role_path']}


# Generated at 2022-06-23 07:09:42.918849
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 07:09:55.990512
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ansible_collections = None
    block = Block()

    #
    # TEST 1: include with name
    #
    include_task = IncludeRole.load(data={'name': 'foobar'}, block=block, task_include=TaskInclude(), variable_manager=object(), loader=object())
    assert isinstance(include_task, IncludeRole)
    assert include_task.name == 'foobar'

    #
    # TEST 2: include with role
    #
    include_task = IncludeRole.load(data={'role': 'foobar'}, block=block, task_include=TaskInclude(), variable_manager=object(), loader=object())
    assert isinstance(include_task, IncludeRole)
    assert include_task.name == 'foobar'

    #
    # TEST 3: include with name "test" and "

# Generated at 2022-06-23 07:10:02.921753
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    blk = Block()
    role = Role()
    task_include = TaskInclude()
    IncludeRole(block=blk, role=role, task_include=task_include)

# Generated at 2022-06-23 07:10:11.993195
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.tasks = []
    ir._role_name = 'test'
    ir._role_path = '/path/to/role'
    ir._from_files = {'tasks': 'tasks_filename', 'meta': 'meta_filename'}
    ir.statically_loaded = True

    new_ir = ir.copy(exclude_parent=True, exclude_tasks=True)

    assert new_ir.tasks == []
    assert new_ir._role_name == 'test'
    assert new_ir._role_path == '/path/to/role'
    assert new_ir._from_files == {'tasks': 'tasks_filename', 'meta': 'meta_filename'}
    assert new_ir.statically_loaded == True
    assert new_ir._parent_role

# Generated at 2022-06-23 07:10:24.006470
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class RoleObject:
        def __init__(self, name, path):
            self._role_name = name
            self._role_path = path
        def get_name(self):
            return self._role_name
        def get_role_params(self):
            return dict(
                ansible_role_name=self._role_name,
                ansible_role_path=self._role_path)

# Generated at 2022-06-23 07:10:36.066704
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.plugins
    import ansible.plugins.loader

    block = ansible.plugins.loader._create_dynamic_module('block', None)
    role = ansible.plugins.loader._create_dynamic_module('role', None)
    include = ansible.plugins.loader._create_dynamic_module('include', None)

    # set up the dynamic class and assign the module to the block object
    d = IncludeRole(block, role, task_include=include)
    d._parent_role = AnsibleRole()

# Generated at 2022-06-23 07:10:46.931330
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test the vars_from and tasks_from options.
    # By default it uses the default validate value (True).
    # The vars_from is not None and the tasks_from is not None
    data = {'action': "Test role", 'role': 'test', 'name': 'test', 'vars_from': './test/vars',
            'tasks_from': './test/tasks', 'defaults_from': './test/defaults', 'handlers_from': './test/handlers'}
    ir = IncludeRole.load(data)
    assert ir._from_files == {'vars': 'vars', 'tasks': 'tasks', 'defaults': 'defaults', 'handlers': 'handlers'}
    assert ir._role_path is None

# Generated at 2022-06-23 07:10:52.784865
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    Test creation of IncludeRole

    Tests the IncludeRole constructor.
    """
    test_role = IncludeRole.load({'name': 'testrole'})
    assert test_role.name == 'testrole'
    assert not test_role.statically_loaded
    assert test_role.public is False
    assert test_role.allow_duplicates is True

# Generated at 2022-06-23 07:10:59.767693
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.block

    # block and role are required parameters
    # task_include is not required so we only pass block and role
    ir = IncludeRole(ansible.playbook.block.Block(), ansible.playbook.block.Block())
    assert ir.get_block_list(None, None, None) == ([], [])

    ir._role_name = 'test_role'
    assert ir.get_block_list(None, None, None) == ([], [])


# Generated at 2022-06-23 07:11:12.602266
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    return_value =  IncludeRole.load(
        data={
            'name': 'common',
            'apply': {
                'tags': ['tag_a', 'tag_b']
            }
        },
        block=Block(),
        role=Role(),
        task_include=TaskInclude()
    )

    assert return_value.name == 'common', 'The name of the return_value should equal "common"'
    assert return_value.action == 'include_role', 'The action of the return_value should equal "include_role"'

# Generated at 2022-06-23 07:11:23.086705
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    This function is used to test class IncludeRole's constructor
        """
    # call class IncludeRole's constructor in test mode
    test_object = IncludeRole(block=Block(), role=Role(), task_include=TaskInclude(block=Block(), role=Role()))

    # check is there a attr _allow_duplicates in test_object
    assert test_object._allow_duplicates == True
    
    # check is there a attr _public in test_object
    assert test_object._public == False
    
    # check is there a attr _rolespec_validate in test_object
    assert test_object._rolespec_validate == True
    
    # check is there a attr _from_files in test_object
    assert test_object._from_files == {}
    
    # check is

# Generated at 2022-06-23 07:11:34.433868
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    action = 'include_role'
    block = Block()
    block.parent = None
    block.role = None
    task_include = None
    include_role = IncludeRole(block, task_include=task_include)
    role1 = Role()
    role1.name = 'TRN_role1'
    role2 = Role()
    role2.name = 'TRN_role2'
    role2._role_path = '/path/to/roles/role1'
    role1._parents = [role2]

    data = { 'name': 'TRN_role3', 'vars': {'var1': 'value1'} }
   

# Generated at 2022-06-23 07:11:43.986346
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude


# Generated at 2022-06-23 07:11:55.257642
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    task_data = [{
        u'skip_tags': [u'debug'],
        u'static': u'yes',
        u'allow_duplicates': False,
        u'block': None,
        u'apply': {
            u'one': 1,
            u'two': 2
        },
        u'rolespec_validate': True,
        u'public': True,
        u'name': u'role1',
        u'role': u'role1',
        u'when': u'ansible_os_family == "RedHat"'
    }]

    display = Display()
    display.verbosity

# Generated at 2022-06-23 07:12:02.476585
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.display("Testing method IncludeRole.get_include_params")
    ir = IncludeRole()
    assert ir.get_include_params() == {}
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.browser import Browser
    from ansible.utils.collection_loader import AnsibleCollectionRef
    pl = Play.load(dict(name='play 1', hosts=['localhost'], roles=['role1']), loader=None, variable_manager=None)
    r = Role.load(dict(name='role1', collection=AnsibleCollectionRef.from_string('dummy.collection')), play=pl)
    br = Browser(basedir='/dummy/path', loader=None, play=pl, collection_loader=None)

# Generated at 2022-06-23 07:12:13.375472
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.inventory
    import ansible.vars
    import ansible.parsing.dataloader
    test_data_loader=ansible.parsing.dataloader.DataLoader()
    test_inventory=ansible.inventory.Inventory(loader=test_data_loader, variable_manager=ansible.vars.VariableManager(), host_list=['localhost'])
    test_variable_manager=ansible.vars.VariableManager()
    test_playbook=ansible.playbook.Playbook.load(playbook_path='playbook.yml', variable_manager=test_variable_manager, loader=test_data_loader)
    test_play=test_playbook.get_plays()[0]
    test_task=test_play.get_tasks()

# Generated at 2022-06-23 07:12:24.417599
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    ###############################################################################
    # NOTE: Loader.load_from_file() is VERY strict in parsing the file,
    #       we don't need to post process the output, just verify that load_data doesn't
    #       raise any exception
    ###############################################################################

    # In this test we are going to verify the load() method of class IncludeRole
    # We are going to use an invalid 'action': 'include_role' instead of 'include_role'
    # and an invalid option: 'public'.
    # Invalid options are also include in the spec_loader_test.yml
    loader = DataLoader()
    var_manager = VariableManager()
    file_name = './lib/ansible/playbook/includerole_loader_test.yml'
    from ansible.parsing.dataloader import Data

# Generated at 2022-06-23 07:12:37.353631
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # the unit tests use string paths, so we need to disable validation here
    display.verbosity = 3

    from ansible.playbook.play_context import PlayContext

    fake_loader = DictDataLoader({})
    fake_variable_manager = VariableManager()
    fake_options = Options(tags=['tag1', 'tag2'])
    fake_variable_manager.extra_vars = {'tags': ['tag1', 'tag2']}
    fake_inventory = Inventory(fake_loader, variable_manager=fake_variable_manager)
    fake_play_context = PlayContext(fake_options, fake_variable_manager, fake_inventory)

# Generated at 2022-06-23 07:12:38.953691
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole(role=Role(),task_include=TaskInclude())==IncludeRole()

# Generated at 2022-06-23 07:12:40.159093
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: implement this
    pass

# Generated at 2022-06-23 07:12:48.377605
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.vars import VariableManager
    from ansible.module_utils._text import to_text

    # config and dummy injectors
    class Data:
        def __init__(self, data):
            self.data = data


# Generated at 2022-06-23 07:12:56.318625
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    data = dict(
        name="test",
        connection="local",
        include=dict(
            role="testrole",
            apply=dict(
                bar="blah"
            )
        )
    )
    # test without excluding parent role
    ir = IncludeRole.load(data)
    copy_ir = ir.copy()
    assert copy_ir._parent_role is ir._parent_role
    # test with excluding parent role
    ir = IncludeRole.load(data)
    copy_ir = ir.copy(exclude_parent=True)
    assert copy_ir._parent_role is None

# Generated at 2022-06-23 07:13:08.107782
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class FakeRole(object):
        def __init__(self, name, role_params):
            self.name = name
            self.role_params = role_params

        def get_role_params(self):
            return self.role_params

        def get_name(self):
            return self.name

    class FakeBlock(Block):
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self):
            return self.vars

    block = FakeBlock({'foo': 'bar'})
    role = FakeRole('fake_role_name', {'fake_role_param': 'fake_role_param_value'})
    ir = IncludeRole(block, role)
    ir.vars = {'role_var': 'role_var_value'}

   

# Generated at 2022-06-23 07:13:11.568105
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, TaskInclude)
    assert isinstance(ir, Block)
    assert not ir.apply
    assert not ir.allow_duplicates
    assert not ir.public
    assert ir.rolespec_validate



# Generated at 2022-06-23 07:13:21.920239
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    rd = RoleDefinition.load(filename='test_include_params',
                             role_name='test_include_params',
                             loader=loader)

    top_ir = rd.get_task_include()
    assert top_ir._parent_role is rd
    assert top_ir._role_name == 'test_include_params'
    assert top_ir._role_path == 'test_include_params'
    v = top_ir.get_include_params()

    assert v['ansible_role_name'] == 'test_include_params'
    assert v['ansible_role_path'] == 'test_include_params'

# Generated at 2022-06-23 07:13:31.906160
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''
    Test method get_include_params of class IncludeRole for correct handling of
    the two variable names `ansible_parent_role_names` and `ansible_parent_role_paths`
    '''
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 07:13:35.279471
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    ir = IncludeRole(block=block, role=role)
    ir.name = "role_name"
    ir._role_name = "include_role_name"
    assert ir.get_name() == 'role_name : include_role_name'

    ir.name = None
    assert ir.get_name() == 'include_role : include_role_name'

# Generated at 2022-06-23 07:13:45.449553
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    from ansible.errors import AnsibleError
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    os.path.isfile = lambda x, d=None: True

    # Mock variable manager
    variable_manager = VariableManager(loader=DataLoader())

    # Mock inventory manager
    inventory = InventoryManager(loader=DataLoader(), variable_manager=variable_manager, host_list=[])

    # Mock play context
    pc = dict(
        playbook=dict(
            basedir="."
        )
    )

    # Mock role

# Generated at 2022-06-23 07:13:56.861923
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.include import RoleInclude

    vm = MockVM()

    play = Play.load(dict(
        name="mock_play",
        hosts='all',
        roles=[]
    ), variable_manager=vm, loader=vm)

    block = Block.load(
        dict(
            task_includes=[]
        ), play=play, variable_manager=vm, loader=vm)

    role = RoleDefinition.load(
        dict(
            name = 'mock-role',
        ), variable_manager=vm, loader=vm)

    role_include = Role

# Generated at 2022-06-23 07:14:10.097600
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
   # Arrange
   from ansible.playbook.role import Role
   from ansible.playbook.block import Block
   from ansible.playbook.task import Task
   from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping
   from ansible.vars.manager import VariableManager
   block = Block()
   role = Role()
   task = Task()
   variable_manager = VariableManager()
   block._parent = task
   task._parent = role

# Generated at 2022-06-23 07:14:20.139047
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables={})
    vault_secrets_lookup_plugin = VaultLib()
    vault_secrets_lookup_plugin.prepare()
    vault_secrets_lookup_plugin.set_vault_id(None)

    # Expected result

# Generated at 2022-06-23 07:14:32.276013
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    display = Display()
    display.add_plugin(plugin='junit', name='junit')

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Loading inventory from files
    inventory = InventoryManager(loader=None, sources=['../tests/units/inventory.yml'])

    # Setting the inventory objects
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = None

    # Setting the tasks

# Generated at 2022-06-23 07:14:35.961501
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block(parent_block=None, role=None)
    role = Role()
    task_include = TaskInclude(block=block, role=role, task_include=None)
    ir = IncludeRole(block=block, role=role, task_include=task_include)

    assert ir.args == {}

# Generated at 2022-06-23 07:14:47.584030
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """IncludeRole: test load method"""
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

   

# Generated at 2022-06-23 07:14:58.232434
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ''' This function is used to test IncludeRole method get_name '''

    ir = IncludeRole()

    # test case 1
    # when action = include_role, name = None, role = None
    ir.action = 'include_role'
    ir.name = None
    ir._role_name = None
    assert ir.get_name() == 'include_role : None'

    # test case 2
    # when action = include_role, name = 'role_name', role = None
    ir.name = 'role_name'
    assert ir.get_name() == 'include_role : role_name'

    # test case 3
    # when action = include_role, name = None, role = 'role_name'
    ir.name = None
    ir._role_name = 'role_name'

# Generated at 2022-06-23 07:15:07.682567
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Test with dictionary argument
    include_role1 = IncludeRole(None, role=None)
    include_role2 = IncludeRole(None, role=None)
    include_role1.load_data({'role': 'test_role'})
    assert include_role1.role == 'test_role', 'Role creation failed with dictionary'

    # Test with IncludeRole argument
    include_role3 = include_role2.load(include_role1)
    assert include_role3.role == 'test_role', 'Role creation failed with IncludeRole object'


# Generated at 2022-06-23 07:15:18.866253
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Create a IncludeRole object
    ir = IncludeRole(Role(), role=Role(), task_include=TaskInclude())
    assert isinstance(ir, IncludeRole)

    # Assign value to name
    path = './'
    name = "tom"
    ir.name = name
    assert ir.name == name

    # Assign value to _allow_duplicates
    _allow_duplicates = 1
    ir._allow_duplicates = _allow_duplicates
    assert ir._allow_duplicates == bool(_allow_duplicates)

    # Assign value to _public
    _public = 1
    ir._public = _public
    assert ir._public == bool(_public)

    # Assign value to _rolespec_validate
    _rolespec_validate = 1
    ir._roles

# Generated at 2022-06-23 07:15:26.233310
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play

    p = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'tasks': [
            {'block': [
                {'include_role': {'name': 'test_role_foo'}},
                {'include_role': {'name': 'test_role_bar'}},
            ]},
        ],
    }, variable_manager=None, loader=None)
    p._tasks = p.compile()
    block = p._tasks[0]

    first_task = block._block[0]
    block_list, handler_list = first_task.get_block_list(play=p, variable_manager=None, loader=None)

# Generated at 2022-06-23 07:15:38.016415
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Load test include_role.yml test file
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=None)

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition


    root_dir_path = os.path.join(os.path.dirname(__file__), "../../")

# Generated at 2022-06-23 07:15:47.140297
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print("testing:")
    import os
    import os.path
    import sys
    import datetime
    import json
    import copy
    import tempfile
    import shutil
    import unittest

    import ansible.utils.display
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task_include import TaskInclude

    import ansible.constants as C

    def setup_test_tmp_dir(tmp_dir):
        test