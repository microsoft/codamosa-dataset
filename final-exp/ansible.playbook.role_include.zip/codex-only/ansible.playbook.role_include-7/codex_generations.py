

# Generated at 2022-06-23 07:05:59.196048
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole(role=Role())
    ir.allow_duplicates = True
    ir.statically_loaded = False
    ir._from_files = {'tasks': 'test.yml'}
    ir._role_name = 'galaxy.role'
    ir._role_path = '/home/user/galaxy_test/roles/galaxy.role'

    ir2 = ir.copy()

    assert ir2._allow_duplicates == ir._allow_duplicates
    assert ir2._public == ir._public
    assert ir2._rolespec_validate == ir._rolespec_validate

    assert ir2.statically_loaded == ir.statically_loaded
    assert ir2._from_files == ir._from_files
    assert ir2._role_name == ir._role_name


# Generated at 2022-06-23 07:06:05.617998
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = Role()
    role._role_name = 'foo'
    role._role_path = ''
    ir = IncludeRole(role=role)
    ir.vars = dict(foo='bar')
    assert ir.get_name() == '%s : %s' % (ir.action, role._role_name), 'get_name() of class IncludeRole should return the name composed of string format of the action attribute and role_name attribute of role'



# Generated at 2022-06-23 07:06:16.395029
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play

    class IncludeRole_test(IncludeRole):
        skip_zero_check = True
        _allow_duplicates = FieldAttribute(isa='bool', private=True)
        _public = FieldAttribute(isa='bool', private=True)

        def __init__(self):
            self._parent = Play()
            self._from_files = {}
            self._parent_role = Role()
            self._role_name = ""
            self._role_path = ""


# Generated at 2022-06-23 07:06:22.467736
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    root_block = Block()
    root_block._role = None
    root_block._parent = None
    root_block._play = None
    ir = IncludeRole()

    ir._parent = root_block
    blocks, handlers = ir.get_block_list()
    assert(blocks == [])
    assert(handlers == [])


# Generated at 2022-06-23 07:06:27.857354
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir_task = IncludeRole()

    # Test with name
    ir_task.name = 'test'
    assert ir_task.get_name() == 'test'

    # Test without name
    ir_task.name = None
    ir_task._role_name = 'sample'
    assert ir_task.get_name() == "%s : %s" % (ir_task.action, ir_task._role_name)

# Generated at 2022-06-23 07:06:35.065871
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class Role_Mock(object):
        def get_name(self):
            return 'role_name'
        def get_role_params(self):
            return {'key': 'value'}
    incl_role = IncludeRole(role=Role_Mock())
    assert incl_role.get_include_params() == {
        'ansible_parent_role_names': ['role_name'],
        'ansible_parent_role_paths': [None],
        'key': 'value'
    }

# Generated at 2022-06-23 07:06:47.172586
# Unit test for method load of class IncludeRole

# Generated at 2022-06-23 07:06:58.641261
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''
    :param ansible.playbook.role.include.IncludeRole:
    :return:
    '''
    ir = IncludeRole()
    v = ir.get_include_params()
    assert {} == v

    class ParentRole():
        def __init__(self):
            self._role_path = 'path/to/role'
            self._role_name = 'rolename'
            self._metadata_for_host = dict
            self._role_params = dict
            self.get_role_params = "ansible.playbook.role.include.IncludeRole.test_IncludeRole_get_include_params.<locals>.ParentRole.get_role_params"

        def get_role_params(self):
            return dict(self._role_params)

    parent_role = ParentRole()
   

# Generated at 2022-06-23 07:06:59.647946
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:07:10.467830
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import pytest
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-23 07:07:10.894479
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-23 07:07:12.341056
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.verbosity = 2
    try:
        IncludeRole.get_include_params()
    except TypeError:
        pass



# Generated at 2022-06-23 07:07:22.092545
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    class DummyRole(object):
        def __init__(self, **kwargs):
            self.name = kwargs['name']
            self._role_path = kwargs['role_path']
        def get_name(self):
            return self.name
        def get_role_params(self):
            return dict(ansible_role_name=self.name, ansible_role_path=self._role_path)

    role_name = 'test_role'
    parent_role = DummyRole(name=role_name, role_path='test_role_path')
    ir = IncludeRole(role=parent_role)

    include_params = ir.get_include_params()
    assert include_params['ansible_role_name'] == role_name

# Generated at 2022-06-23 07:07:33.110880
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import unittest.mock
    from ansible.playbook.role.definition import Task
    
    # Create the IncludeRole instance
    include_role = IncludeRole()
    include_role._role_name = 'role_simple'

    # mock of the play object
    play = unittest.mock.MagicMock()
    play.roles = []

    # Create a mock of the Role object
    role = unittest.mock.MagicMock()
    role._metadata.allow_duplicates = False
    role.get_handler_blocks = lambda play: []
    # Create a mock of the Block object
    role.compile = lambda *args, **kwargs: [Block(role=role)]
    # Create a mock of the Task object

# Generated at 2022-06-23 07:07:46.702327
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    role_include_list = []

    # Test case of exclude_tasks is False
    # Test case of exclude_tasks is True
    for exclude_tasks in [False, True]:
        # Test case of exclude_parent is False
        # Test case of exclude_parent is True
        for exclude_parent in [False, True]:
            ir = IncludeRole(block=block, role=role, task_include=task_include)
            new_ir = ir.copy(exclude_parent=exclude_parent, exclude_tasks=exclude_tasks)
            #Type check
            assert isinstance(new_ir, IncludeRole)
            #static_loaded
            assert new_ir.statically_loaded == ir.statically_loaded
           

# Generated at 2022-06-23 07:07:50.963477
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    '''
    功能描述：测试代码
    输入参数：NONE
    输出参数：NONE
    返 回 值：NONE
    '''
    role_obj = IncludeRole()

# Generated at 2022-06-23 07:08:00.559531
# Unit test for method copy of class IncludeRole

# Generated at 2022-06-23 07:08:07.756616
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Prepare mock object for role to create an object of class IncludeRole
    n = mock.Mock()
    n.name = "TestAutoLoader"
    n.args = {}

    # Prepare include_role by passing mock object
    ir = IncludeRole(n)

    # Prepare expected output
    expected = "include_role : TestAutoLoader"

    # Get actual output from the tested function
    actual = ir.get_name()

    # check if actual and expected are same
    assert actual == expected



# Generated at 2022-06-23 07:08:16.828350
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Test the case of an empty IncludeRole (defaults)
    ir = IncludeRole(None, None)
    assert ir.copy() == ir

    # Test the case of an IncludeRole with properties specified
    ir = IncludeRole(None, None)
    ir.when = "1==1"
    ir.loop = "item"
    assert ir.copy() != ir

    # Test the case of an IncludeRole with properties specified, excluding params.
    ir = IncludeRole(None, None)
    ir.when = "1==1"
    ir.loop = "item"
    ir_copy = ir.copy()
    ir_copy.when = "2==2"
    ir_copy.loop = "item2"
    assert ir.copy(exclude_parent=True) == ir_copy

# Generated at 2022-06-23 07:08:22.148960
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    assert include_role.get_name() == "include_role : "
    include_role.name = "hello"
    assert include_role.get_name() == "hello"
    include_role.name = None
    include_role._role_name = "world"
    assert include_role.get_name() == "include_role : world"

# Generated at 2022-06-23 07:08:32.872259
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir= IncludeRole()
    #ir.statically_loaded = True
    ir.allow_duplicates = False
    ir.rolespec_validate = False
    ir.public = True
    #ir._from_files =
    ir._parent_role = None
    ir.args={'tasks_from':"tasks_from.yml", 'vars_from':"vars_from.yml", 'defaults_from':"defaults_from.yml", 'handlers_from':"handlers_from.yml", 'apply':{} ,'public':True, 'allow_duplicates':False, 'rolespec_validate':False}
    ir._role_name = "role name"
    ir._role_path = "/home/user"

    res = ir.copy()
    assert ir._

# Generated at 2022-06-23 07:08:41.972695
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # Create a parent_role
    tb = Block()
    tb.block  = [ Task() ]
    parent_role = Role()
    parent_role._role_name = 'parent_role'
    parent_role._role_path = 'parent/role/path'
    parent_role._parents = ['parent0', 'parent1']
    parent_role._tasks = tb
    parent_role._role_params = {'param1': 'value1', 'param2': 'value2'}
    parent_role._metadata = {'allow_duplicates': True}
    actual_role = Role()
    actual_role._role_name = 'actual_role'


# Generated at 2022-06-23 07:08:46.951095
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Setup
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    # Exercise
    IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    # Verify

# Generated at 2022-06-23 07:08:59.969791
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variables = dict(
        foo='bar'
    )

    loader, inventory, variable_manager = C.get_loader(), C.get_inventory(), C.get_variable_manager()
    loader.set_basedir('.')
    variable_manager.extra_vars = variables
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, task=None))

    block_args = dict(
        name='test-role',
        apply=dict(
            become=True,
            become_user='nobody',
            tags=['test_tag']
        ),
        args=dict(
            foo='{{ foo }}'
        )
    )

    obj = IncludeRole.load

# Generated at 2022-06-23 07:09:05.764617
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # create a fake play
    import ansible.playbook.play
    play = ansible.playbook.play.Play().load({
        'name': 'test_play',
        'hosts': 'all',
        'gather_facts': 'no',
        'roles': [
            'role1',
            {'name': 'role2'},
            {'name': 'role3', 'path': 'role3'},
            {'name': 'role4', 'include_role': {'name': 'role5'}, 'include': 'role6'},
            {'name': 'role6', 'include_role': {'name': 'role7'}},
        ]
    }, variable_manager=None, loader=None)

    # create a fake role1
    import ansible.playbook.role
    role_

# Generated at 2022-06-23 07:09:16.736521
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import find_plugin_files
    from ansible.plugins import plugin_loader, module_loader
    import os
    import ansible

    role_fixture_path = os.path.join(os.path.dirname(__file__), 'role_fixture')
    target_path = os.path.join(role_fixture_path, 'roles', 'test-role-1')
    loader = DataLoader()


# Generated at 2022-06-23 07:09:26.660695
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils import context_objects as co
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    co.GlobalCLIArgs._Singleton__instance = None

    context = PlayContext()
    loader = DataLoader()
    variable_manager = VariableManager()

    # Create play and templar for testing
    playvars = dict()
    playblock = Block()
    playblock._role = None
    playblock.vars = playvars
    playblock.vars.update(variable_manager.get_vars(play=playblock))
   

# Generated at 2022-06-23 07:09:33.619391
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    test_obj = IncludeRole()
    assert test_obj._allow_duplicates is True
    assert test_obj._public is False
    assert test_obj._rolespec_validate is True
    assert test_obj._from_files == {}
    assert test_obj._parent_role is None
    assert test_obj._role_name is None
    assert test_obj._role_path is None

# Generated at 2022-06-23 07:09:39.814365
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook import role
    from ansible.template import Templar
    from ansible.playbook.role.definition import RoleDefinition


# Generated at 2022-06-23 07:09:49.723471
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    display.vvvv = True
    block = Block()
    block._parent = Block()
    block._parent.vars = dict(a=1, b=2)
    ir = IncludeRole(block)
    ir._from_files = dict(e=1, f=2)
    ir._parent_role = Role()
    ir._parent_role._role_path = 'roles/path/a'
    ir._parent_role.get_role_params = lambda: dict(c=3, d=4)
    ir._role_name = 'role_name'

    # case: exclude_parent is False, exclude_tasks is False
    new_ir = ir.copy()
    assert new_ir is not ir
    assert new_ir.block is not ir.block
    assert new_ir.block._parent is ir.block

# Generated at 2022-06-23 07:09:59.467972
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    include = IncludeRole()
    include.action = 'include'
    include.name = 'test_case'
    include.tags = ['test_case']
    include.when = 'test_case'
    include._role_name = 'test_case'
    include._role_path = 'test_case'
    include.statically_loaded = False
    include._task_include = Block()
    include._parent_role = Role()
    new_include = include.copy()
    assert new_include.action == 'include'
    assert new_include.name == 'test_case'
    assert new_include.tags == ['test_case']
    assert new_include.when == 'test_case'
    assert new_include._role_name == 'test_case'

# Generated at 2022-06-23 07:10:03.366824
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    assert ir

# Generated at 2022-06-23 07:10:10.302934
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    include_role = IncludeRole()
    include_role._parent_role = None
    include_role._role_name = None
    include_role._role_path = None
    include_role.statically_loaded = True
    include_role._from_files = None
    result = include_role.copy()
    assert result.statically_loaded == True
    assert result._from_files == {}
    assert result._parent_role is None
    assert result._role_name is None
    assert result._role_path is None


# Generated at 2022-06-23 07:10:15.804351
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    ir = IncludeRole(block)
    ir.name = 'name'
    assert ir.get_name() == 'name'
    ir = IncludeRole(block)
    ir._role_name = 'role name'
    assert ir.get_name() == 'include_role : role name'

# Generated at 2022-06-23 07:10:25.718156
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    role_include = IncludeRole(task_include=None, block=Block(), role=["role1", "role2"])
    role_include.vars = {"name": "role3"}
    assert "role3" == role_include.get_name()

    role_include = IncludeRole(task_include=None, block=Block(), role=["role1", "role2"])
    role_include.action = "action"
    assert "action : " == role_include.get_name()

    role_include = IncludeRole(task_include=None, block=Block(), role=["role1", "role2"])
    role_include.action = "action"

# Generated at 2022-06-23 07:10:36.945837
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ''' Unit test for method copy of class IncludeRole '''
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    vars_file = dict(
        foo='foo',
        bar='bar',
        )

    ir = IncludeRole()
    ir._role_name = 'test_role'
    ir._parent_role = RoleDefinition.load(dict(name='base_role'), play=None, variable_manager=None, loader=None)
    ir.vars.update(vars_file)

    new_ir = ir.copy()
    assert ir._from_files == new_ir._from_files
    assert ir._parent_role == new_ir._parent_role
    assert ir._role_name == new_ir._role_name
    assert ir._role_

# Generated at 2022-06-23 07:10:47.492700
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Testing with included_role action with valid data
    data = dict(
        name='foo',
        apply=dict(a=1, b=2),
        allow_duplicates=False,
        public=False,
    )
    actual = IncludeRole.load(data, role=None, task_include=None)
    assert data == actual.args
    assert isinstance(actual._parent, Block)

    # Testing with included_role action with invalid role name
    data = dict(
        apply=dict(a=1, b=2),
        allow_duplicates=False,
        public=False,
    )
    try:
        actual = IncludeRole.load(data, role=None, task_include=None)
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 07:10:58.200181
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    class FakeRole(object):
        def __init__(self, name='fake'):
            self.name = name
            self.fake_role_vars = dict()
        def get_role_params(self):
            return self.fake_role_vars

    ir = IncludeRole()
    ir._parent_role = FakeRole(name='fake')
    ir._parent_role.fake_role_vars = dict(a=1, b=2)
    # copy without exclude parent role
    new_ir = ir.copy(exclude_parent=False)
    assert new_ir._parent_role is ir._parent_role
    assert new_ir._parent_role.fake_role_vars is ir._parent_role.fake_role_vars
    # copy with exclude parent role

# Generated at 2022-06-23 07:11:05.544908
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Case 1
    role = Role(name='test-role')
    include_role = IncludeRole(role=role)
    include_role.name = "test"
    include_role.action = "include_role"
    include_role._role_name = "test-role"
    assert include_role.get_name() == 'test : test-role'

    # Case 2
    role = Role(name='test-role')
    include_role = IncludeRole(role=role)
    include_role.name = None
    include_role.action = "include_role"
    include_role._role_name = "test-role"
    assert include_role.get_name() == 'include_role : test-role'

# Generated at 2022-06-23 07:11:15.911857
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Invalid Options
    test_data = {}
    test_data.update(apply={})
    test_data.update(vars=None)
    test_data.update(name='name')
    include_role = IncludeRole(role='role')
    try:
        include_role.load(test_data)
    except AnsibleParserError as e:
        assert 'role' in e.message
    else:
        raise AssertionError('Expected exception')

    # Valid Options
    test_data = {}
    test_data.update(apply={})
    test_data.update(vars=None)
    test_data.update(name='name')
    include_role = IncludeRole(role='role')
    obj = None

# Generated at 2022-06-23 07:11:24.063432
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Unit test for method get_name
    """
    ir = IncludeRole()
    ir._role_name = "common"
    ir.name = "common : include role"
    assert ir.get_name() == "common : include role"
    ir.name = None
    assert ir.get_name() == "include_role : common"
    ir = IncludeRole()
    ir._role_name = None
    ir.name = "common : include role"
    assert ir.get_name() == "common : include role"
    ir.name = None
    assert ir.get_name() == "include_role : None"

# Generated at 2022-06-23 07:11:34.876823
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    field_attribute = FieldAttribute(isa='bool', default=True, private=True)
    role_path = FieldAttribute(isa='bool', default=True, private=True)

    ir = IncludeRole(block=None, role=None, task_include=None)
    ir._allow_duplicates = field_attribute
    ir._role_name = 'test'
    ir._role_path = role_path

    # The role is not statically loaded
    assert ir.get_name() == 'include_role : test'

    # The role is statically loaded
    ir.statically_loaded = True
    assert ir.get_name() == 'test'

# Generated at 2022-06-23 07:11:48.076944
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert IncludeRole.load({'include_role': 'foo'}, task_include=True)

    try:
        assert IncludeRole.load({'include_role': 'foo'})
        assert False, "Expected error"
    except AnsibleParserError:
        pass

    x = IncludeRole.load({'include_role': 'foo', 'public': True}, task_include=True)
    assert isinstance(x.tasks, list)
    assert isinstance(x.handlers, list)
    assert isinstance(x.block, Block)
    assert x.vars == {}
    assert x.tags == set()
    assert not x.loop
    assert x.any_errors_fatal is None
    assert x._role_name == 'foo'
    assert x._action == 'include_role'

# Generated at 2022-06-23 07:11:59.844468
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    class MockRole(object):
        def __init__(self, name, collection_list=None):
            self._collection_list = collection_list
            self.get_name = lambda: name

    role = MockRole('test.role')

    # test name and role
    data = {'name': 'test.role'}
    include_role = IncludeRole.load(data, role=role)
    assert include_role._role_name == 'test.role'
    assert not include_role.statically_loaded
    assert include_role.get_name() == 'include_role: test.role'
    assert include_role.collections == role._collection_list

    # test name, role
    data = {'role': 'test.role'}
    include_role = IncludeRole.load(data, role=role)
   

# Generated at 2022-06-23 07:12:11.736438
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import ansible.playbook.role_include as role_include
    from ansible.playbook.role import Role
    from ansible.plugins import module_loader

    role = Role(name='test_role')
    ir = IncludeRole.load(dict(role='test_role'), role=role)

    ir.dep_chain = [1, 2, 3]
    ir.statically_loaded = True
    ir._from_files = dict(a=1, b=2, c=3)
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'
    ir.role = role
    ir.apply = dict(a=1, b=2, c=3)
    ir.public = True
    ir.allow_duplicates = True
    ir.roles

# Generated at 2022-06-23 07:12:14.602309
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    sample_role = Role()
    ir = IncludeRole(role=sample_role)
    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-23 07:12:24.909997
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'root'
    play_context.remote_user = 'test'

    play_source = dict(
        name="test",
        hosts='test',
        gather_facts='no',
        become='yes',
        become_method='enable',
        become_user='test',
        remote_user='test',
        roles=[]
    )

# Generated at 2022-06-23 07:12:37.662764
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.utils.module_docs
    import os
    import tempfile
    import shutil
    import ansible.template
    import ansible.constants
    ansible.constants.DEFAULT_PRIVATE_ROLE_VARS = False
    project_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))))
    playbooks_dir = os.path.join(project_dir, 'lib/ansible/playbook')
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-23 07:12:47.113754
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir_1 = IncludeRole.load(
        data={
            'name': 'include_role_name',
            'tasks_from': "/path/to/file",
            'vars_from': "/path/to/file",
            'defaults_from': "/path/to/file",
            'handlers_from': "/path/to/file",
            'apply': {'some_key': "some_value"},
            'public': True,
            'allow_duplicates': False,
            'rolespec_validate': False,
        }
    )
    ir_2 = ir_1.copy(exclude_parent=True, exclude_tasks=True)

    # check that task argument states are copied
    assert ir_1.statically_loaded is False

# Generated at 2022-06-23 07:12:54.387637
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block.load(dict(
        tasks=[dict(action=dict(include=dict(name='test')))]),
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None)

    ir = IncludeRole(block=block, role=None, task_include=None)

    assert isinstance(ir, IncludeRole)
    assert ir.name == 'test'


# Generated at 2022-06-23 07:13:00.517052
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    blocks = []
    tasks = TaskInclude.load(
        dict(
            name='test',
            include='test.yml',
        ),
    )

    try:
        blocks.append(tasks)
    except Exception as e:
        print("Exception: {0}".format(str(e)))

# Generated at 2022-06-23 07:13:04.972057
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    vars = {'role':'webserver'}
    role = IncludeRole(block=None, role=None, task_include=None)
    role.vars = vars
    role.name = 'include_role'
    assert role.get_name() == 'include_role : webserver'

# Generated at 2022-06-23 07:13:07.543434
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    r = Role()
    r._metadata = object()
    ir = IncludeRole(role=r)

    assert ir.get_include_params()['role_metadata'] == r._metadata

# Generated at 2022-06-23 07:13:13.906325
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    Create a dummy class
    :return:
    # Create a dummy class
    """
    class TestObj():
        pass
    test_obj = TestObj()
    test_obj.rolespec_validate = True
    test_obj.allow_duplicates = True
    test_obj.public = True
    test_obj.block = Block()
    test_obj.role = Role()
    test_obj.__dict__ = {'rolespec_validate': True, 'allow_duplicates': True, 'public': True, 'block': Block(), 'role': Role()}

# Generated at 2022-06-23 07:13:22.902004
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Create a simple task block
    tb = Block()
    tb.block = [dict(task=dict(name='generic task'))]

    # Create a simple role
    myrole = Role()
    # Set the name and the parent role
    myrole.name = 'myrole'
    myrole.parent_role = 'myparentrole'

    # Create the include role object
    myincluderole = IncludeRole(block = tb, role = myrole)

    # Enable static loading of include
    myincluderole.statically_loaded = True

    # Add from files
    myincluderole._from_files = dict(vars='vars.yaml')

    # Add parent role
    myincluderole._parent_role = 'myparentrole'

    # Add role name
    myincluder

# Generated at 2022-06-23 07:13:26.483103
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    my_task = IncludeRole()
    my_task._role_name = "test_role"

    assert my_task.get_name() == "%s : %s" % (my_task.action, "test_role")

# Generated at 2022-06-23 07:13:36.574380
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager._extra_vars = {"x": "y"}
    inventory = InventoryManager(loader=loader, sources=[''])

    role_include = RoleInclude.load("myrole", play=None, variable_manager=variable_manager, loader=loader, collection_list=None)
    block = Block().load("block", play=None, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 07:13:38.237929
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    class MyRole(Role):
        _role_name = 'foo'

    ri = IncludeRole(role=MyRole())
    ri.load_data(dict(name='api'))

# Generated at 2022-06-23 07:13:42.660349
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert IncludeRole().get_include_params() == dict()
    assert IncludeRole().copy(exclude_parent=True).get_include_params() == dict()
    role = Role()
    role._role_path = "/tmp"
    role_p = role.copy().get_include_params()
    assert role_p["ansible_role_names"] == ["ROLE"]
    assert role_p["ansible_role_paths"] == ["/tmp"]
    role_p["ansible_role_names"].insert(0, "1")
    role_p["ansible_role_paths"].insert(0, "2")
    assert IncludeRole(role=role).get_include_params() == role_p


# Generated at 2022-06-23 07:13:51.005564
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # This test methods is used to test the method get_block_list of IncludeRole class.
    # The following assertions are tested in the test cases:
    # 1. the return value of method is correct
    # 2. Test case for validating from_files is correct
    # 3. Test case for validating role path (self._role_path) is correct

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    class MockVariableManager():

        def get_vars(self, play, task):
            return dict()

    class MockPlay():

        def __init__(self):
            self.handlers = []
            self.roles = []


# Generated at 2022-06-23 07:13:59.675164
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.constants as C
    import ansible.playbook.role.include as role_include
    import ansible.plugins.loader as loader_pkg
    import ansible.plugins.task.include_role as task_include_role
    import ansible.template as template_pkg
    import ansible.utils.display as display_pkg
    from ansible.playbook.task import Task

    # instantiate the class to be tested
    data = {'include_role': {}, 'include': {}}
    for key, value in data.items():
        data[key]['name'] = 'test_include_role'
    for key in ('apply', 'public', 'allow_duplicates', 'rolespec_validate'):
        data['include_role'][key] = True
        data['include'][key] = True

# Generated at 2022-06-23 07:14:00.437646
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    pass

# Generated at 2022-06-23 07:14:07.916988
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole().action == 'include_role'
    assert IncludeRole()._parent is None
    assert IncludeRole(block=Block())._parent is not None
    assert IncludeRole()._parent_role is None
    assert IncludeRole()._role_name is None
    assert IncludeRole()._role_path is None
    assert IncludeRole().statically_loaded is True
    assert IncludeRole()._allow_duplicates is True
    assert IncludeRole()._public is False


# Generated at 2022-06-23 07:14:18.749149
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    t = IncludeRole()
    # No variables found at all
    assert t.get_include_params() == dict()
    # Only variable role is found
    t.vars = dict(role=dict(name="role"))
    assert t.get_include_params() == dict(role=dict(name="role"))
    # Only variable ansible_parent_role_names is found
    t.vars = dict(ansible_parent_role_names=["ansible"])
    assert t.get_include_params() == dict(ansible_parent_role_names=["ansible"])
    # Both role and ansible_parent_role_names are found
    t.vars = dict(role=dict(name="role"), ansible_parent_role_names=["ansible"])
    assert t.get_include_params()

# Generated at 2022-06-23 07:14:26.735384
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.playbook.role import Role

    data = dict(
        _role_name='foo',
        _parent_role=None,
        _role_path='/foo/bar',
    )
    r = IncludeRole()
    assert not r._role_name
    for k in data:
        setattr(r, k, data.get(k))
    assert r._role_name == 'foo'
    assert not r._parent_role
    assert r._role_path == '/foo/bar'

    data = dict(
        _role_name='foo',
        _parent_role=Role(),
        _role_path='/foo/bar',
    )
    r = IncludeRole()
    assert not r._role_name

# Generated at 2022-06-23 07:14:31.603087
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = True
    ir._from_files = {"a": 1}
    ir._parent_role = 1
    ir._role_name = 2
    ir._role_path = 3
    ir.post_validate = lambda a, b, c, d, e: None
    new_ir = ir.copy()
    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from_files == ir._from_files
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_name == ir._role_name
    assert new_ir._role_path == ir._role_path
    assert new_ir.post_validate == ir.post_validate

# Generated at 2022-06-23 07:14:42.494148
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # init a play with a play context
    pc = PlayContext()
    pc._vars_per_host = {
        "ansible_ssh_user": "kim",
        "ansible_ssh_host": "10.0.1.1"
    }
    parent_play = {
        'play': {
            'name': "fake_play",
            'hosts': ['all'],
            'connection': 'ssh',
            'gather_facts': 'no',
            'tasks': [],
            'context': pc
        }
    }

    # init a role with a role context
    rc = Role()

# Generated at 2022-06-23 07:14:52.096678
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Test data
    test_item = {'include_role': dict(name='foobar')}
    test_block = dict(
        header=dict(
            name="blackhole",
            lineno=1,
            parent_block=None
        ),
        task_blocks=[]
    )
    test_context = PlayContext()
    tt = Templar(loader=None, variables={})

    # Execute
    obj = IncludeRole.load(data=test_item, block=test_block, role=None, task_include=None, variable_manager=None, loader=None)
    result = None
    try:
        result = obj.get_name()
    except:
        pass

    # Verify results

# Generated at 2022-06-23 07:14:57.373125
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    display.verbosity = 3
    ir = IncludeRole.load(
        dict(name='foo',
             apply={'filters': 'filter'},
             public=True,
             allow_duplicates=False,
             rolespec_validate=False), block=Block(), role=Role(), task_include=TaskInclude())

    print('#' * 10)
    print(ir)

    return ir


# Generated at 2022-06-23 07:15:03.606334
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    with open('./test_IncludeRole.yml', 'r') as f:
        test_block = Block.load(f.read(), task_include=IncludeRole)

    assert test_block.name == 'my-play', 'test_IncludeRole failed'

    print("test_IncludeRole.py SUCCESS")

# Generated at 2022-06-23 07:15:14.364165
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.base import PlaybookBase
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    import ansible.constants as C
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    host = Host(name='192.168.0.1')

# Generated at 2022-06-23 07:15:22.725355
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Setup
    class MockIncludeRole(IncludeRole):
        def __init__(self):
            self._load_name = 'foo'
            self._from_files = {'tasks': 'foo'}
            self.statically_loaded = False
            self._parent_role = 'foo'
            self._role_name = 'foo'
            self._role_path = 'foo'

    # Test
    test_obj = MockIncludeRole()
    rval = test_obj.copy()

    # Assertions
    assert rval.load_name == 'foo'
    assert rval._from_files == {'tasks': 'foo'}
    assert rval.statically_loaded == False
    assert rval._parent_role == 'foo'
    assert rval._role_name == 'foo'
   

# Generated at 2022-06-23 07:15:34.450745
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Setup
    role = Role()
    role.vars = {"k": "o", "k2": "v2"}
    role.name = "name"
    role._role_path = "/path"
    role._metadata = {"allow_duplicates": False}
    role._parents = []
    role.parent = None
    role.statically_loaded = True

    # Execution
    copied_role = role.copy()

    # Assertions
    assert copied_role.vars == {"k": "o", "k2": "v2"}
    assert copied_role.name == "name"
    assert copied_role._role_path == "/path"
    assert copied_role._metadata == {"allow_duplicates": False}
    assert copied_role.parent is None

# Generated at 2022-06-23 07:15:37.769972
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(task_include=None, block=None, role=None)
    ir._role_name = 'test_role'
    assert ir.get_name() == 'include_role : test_role'



# Generated at 2022-06-23 07:15:46.179191
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    '''
    class IncludeRole:
    def __init__(self, block=None, role=None, task_include=None):
        super(IncludeRole, self).__init__(block=block, role=role, task_include=task_include)
        self._from_files = {}
        self._parent_role = role
        self._role_name = None
        self._role_path = None
    '''
    #
    ###
    ##
    #
    #
    ##
    ###
    #
    #
    ##
    ###
    #
    #
    ##
    ###
    #
    #
    ##
    ###
    #
    #
    ##
    ###
    #
    #
    ##
    ###
    #
    #
    ##
    ###
    #



# Generated at 2022-06-23 07:15:49.792792
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, Block)
    assert isinstance(ir, TaskInclude)
    assert ir._role is None
    assert ir._parent_role is None
    assert ir._role_name is None
    assert ir._role_path is None
    assert ir._from_files == {}