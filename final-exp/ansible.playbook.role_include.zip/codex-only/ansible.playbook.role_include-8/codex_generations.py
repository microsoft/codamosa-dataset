

# Generated at 2022-06-23 07:05:59.196549
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 3
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
    inventory.extra_vars = {'ansible_ssh_port' : 10022}

    play_context = PlayContext()

    ir_data = {'name': 'test', 'roles': ['role1']}
    block = Block(play=None, parent_block=None)
    role = Role()
    task_include = TaskInclude(block, role)

# Generated at 2022-06-23 07:06:08.813281
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    load = IncludeRole.load
    load_data = IncludeRole.load_data
    setattr(load, '__name__', 'IncludeRole.load')

    # Issue #51519: IncludeRole should use `from_files` value to do block compilation
    setattr(load_data, '__name__', 'IncludeRole.load_data')
    block = Block()
    fake_loader = Mock()
    fake_loader._find_path_of_role.return_value = 'fake_role_path'
    block.set_loader(fake_loader)
    fake_variable_manager = Mock()
    fake_variable_manager.get_vars.return_value = {}

    ir = load(dict(name='fake_role_name'), block=block, variable_manager=fake_variable_manager, loader=fake_loader)


# Generated at 2022-06-23 07:06:12.949481
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    new_IncludeRole = IncludeRole(block=block, role=role)
    new_IncludeRole._role_name = 'myrole'
    assert new_IncludeRole.get_name() == 'include_role : myrole'

# Generated at 2022-06-23 07:06:19.801431
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    ir = IncludeRole()
    ir.name = "task name"
    ir.action = "include action"
    ir._role_name = "role name"

    assert ir.get_name() == "task name : role name"

    ir.name = None

    assert ir.get_name() == "include action : role name"


# Generated at 2022-06-23 07:06:22.781728
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: why does this test require a loader? is a loader not required to just read a file?
    # TODO: why does this test require a play?
    pass

# Generated at 2022-06-23 07:06:31.534912
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    v_manager = None
    loader = None
    def_data = {"name" : "role_name", "vars" : {"var1" : 1, "data" : [1,2,3]}}
    test_def = RoleDefinition.load(def_data, block=None, use_handlers=False,
                                   dependency_depth=0, role_name='test_role_name',
                                   parent_role=None, loader=loader, variable_manager=v_manager)
    test_include = IncludeRole(block=None, role=test_def)

# Generated at 2022-06-23 07:06:37.227012
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    contents = dict(
        name="role_name",
    )
    fake_loader = 'fake_loader'
    fake_block = 'fake_block'
    fake_play = 'fake_play'
    fake_variable_manager = 'fake_variable_manager'
    fake_task_include = 'fake_task_include'

    ir = IncludeRole.load(contents, block=fake_block, task_include=fake_task_include)
    assert ir.get_name() == 'role_name : role_name'

# Generated at 2022-06-23 07:06:48.108500
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-23 07:06:56.168267
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Case 1: No parent role
    ir = IncludeRole()
    assert ir.get_include_params() == {}

    # Case 2: With parent role
    pr = Role()
    pr._role_params = {"key1":"value1", "key2":"value2"}
    ir._parent_role = pr
    assert ir.get_include_params() == {"key1":"value1", "key2":"value2", "ansible_parent_role_names":[""], "ansible_parent_role_paths":[""]}

# Generated at 2022-06-23 07:07:04.734579
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    role = Role()
    role._role_params = dict(name1='value1', name2='value2', name3='value3')
    role._role_path = 'roles/role1'
    role.name = 'role1'

    include = IncludeRole(role=role)
    params = include.get_include_params()
    assert params == dict(name1='value1', name2='value2', name3='value3', ansible_parent_role_names=['role1'], ansible_parent_role_paths=['roles/role1'])

# Generated at 2022-06-23 07:07:16.623928
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import copy
    import os
    import sys
    import tempfile

    def _get_stdout():
        # get the standard output and then clear it, so we don't have it in the test output
        v = sys.stdout.getvalue()
        sys.stdout = StringIO()
        return v


# Generated at 2022-06-23 07:07:24.820084
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play

    myplay = Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        vars = {'myvar': 'myvalue'},
        tasks = [
            dict(
                action = 'set_fact',
                args   = dict(
                    myvar='myvalue2'
                )
            ),
            dict(
                action = 'include_role',
                args   = dict(
                    name='testrole',
                    tasks_from='set_fact.yml'
                )
            ),
        ]
     ), loader=None, variable_manager=None)

    queue_manager = TaskQueueManager(play=myplay)
    queue_manager

# Generated at 2022-06-23 07:07:29.097463
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Validate the copy method of IncludeRole
    foo = IncludeRole()
    bar = IncludeRole()
    assert foo.copy() != bar.copy()
    assert isinstance(foo.copy(), IncludeRole)
    assert foo.copy().__dict__.keys() == bar.copy().__dict__.keys()



# Generated at 2022-06-23 07:07:36.317860
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    r = IncludeRole.load(dict(include='test'))
    assert r.get_name() == 'include_role : test'
    r = IncludeRole.load(dict(include='test'), role=Role())
    assert r.get_name() == 'include_role : test'
    r = IncludeRole.load(dict(include='test', name='myname'))
    assert r.get_name() == 'include_role : myname'
    r = IncludeRole.load(dict(include='test', name='myname'), role=Role())
    assert r.get_name() == 'include_role : myname'


# Generated at 2022-06-23 07:07:51.791961
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Ensure that when loading IncludeRole it will not fail
    """
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    play_context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 07:07:56.619812
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # setup
    include_role = IncludeRole()
    include_role.action = 'include_role'

    # test
    actual = include_role.get_include_params()
    expected = {'include_role_params': {'role_name': None, 'tasks_from': None, 'role_path': None, 'vars_from': None, 'handlers_from': None}, 'ansible_role_names': [], 'ansible_role_paths': []}
    assert actual == expected



# Generated at 2022-06-23 07:08:04.023489
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'block': Block(), 'role': None, 'task_include': None, 'variable_manager': None, 'loader': None,\
        'data': {'include': 'roleName1', 'name': 'roleName1', 'allow_duplicates': True, 'apply': {}, 'public': False, 'allow_duplicates': True, 'rolespec_validate': True},\
        'block_args': None, 'args': {'include': 'roleName1', 'name': 'roleName1', 'allow_duplicates': True, 'apply': {}, 'public': False, 'allow_duplicates': True, 'rolespec_validate': True}}

# Generated at 2022-06-23 07:08:09.881296
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    r = IncludeRole()
    r._role_name = 'Foo'
    assert r.get_name() == "include_role : Foo"
    r = IncludeRole()
    r._role_name = 'Foo'
    r.name = 'Bar'
    assert r.get_name() == "Bar"

# Generated at 2022-06-23 07:08:16.568034
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Load the task and test that the correct attributes are set
    # Test with apply options
    block_data = {
        "args": {
            "name": "test-role",
            "tasks_from": "./tasks",
            "defaults_from": "../defaults",
            "vars_from": "../../vars/app.yml",
            "handlers_from": "../handlers",
            "apply": {
                "when": "application_state == 'started'"
            }
        },
        "block": "role_name",
        "module_args": "include_role"
    }
    ir = IncludeRole.load(block_data)
    assert ir.name == "test-role"

# Generated at 2022-06-23 07:08:26.545815
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars

    
    #Create dataloader
    loader = DataLoader()
    # Create variable manager
    variable_manager = VariableManager()
    # create inventory and pass to var manager
    inventory = InventoryManager(loader=loader,  sources=["/ansible/inventory"])

# Generated at 2022-06-23 07:08:36.817147
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    m_play = Mock()
    # Create a block
    task_block = Block.load(data=dict(name="Task Block", meta=dict()), play=m_play, task_include=None, role=None)
    # Create a role
    role = Role.load(data=dict(name="dummy_role"), play=m_play, variable_manager=Mock(), loader=Mock())
    task_include = IncludeTask()

    # test 1, name is None and role is None
    include_role = IncludeRole(block=task_block, role=role, task_include=task_include)
    assert include_role.get_name() == "include_tasks : None", "IncludeRole.get_name() failed to get the name correctly when name is None and role is None"

    # test 2, name is not None

# Generated at 2022-06-23 07:08:38.821881
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task = IncludeRole(block=block, role=role)
    assert task

# Generated at 2022-06-23 07:08:50.042934
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    basedir = '/tmp/ansible1/roles1'
    parent_role = Role()
    parent_role._role_name = 'test_parent_role'
    parent_role.name = 'test_parent_role'
    parent_role._role_path = basedir + '/test_parent_role'
    parent_role.tags = ['mytag1', 'mytag2']
    parent_role.loop = '{{test_parent_role_loop}}'
    parent_role.when = '{{test_parent_role_when}}'
    parent_role.become = True
    parent_role.become_method = 'sudo'
    parent_role.become_user = 'root'
    parent_role.set_loop_context('test_parent_role_loop')

    ir = IncludeRole()
    ir

# Generated at 2022-06-23 07:09:01.313238
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    get_include_params should return
    {
        'ansible_parent_role_names': [...],
        'ansible_parent_role_paths': [...],
        'ansible_parent_role_params': {...}
    }
    """

    # Create a simple Role object
    role = Role()
    role._metadata = {'name': 'test', 'namespace': 'test', 'collection': 'test.collection'}
    role_path = 'Roles/test/tasks/main.yml'
    role.set_parents({'role_path': role_path, 'role_names': [role_path]})
    # Set parent_role attribute to a Role object
    include_role = IncludeRole(role=role)

    # Here is the expected result

# Generated at 2022-06-23 07:09:14.151420
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    import io
    import os
    import shutil
    import tempfile

    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import role_loader, add_all_plugin_dirs, get_all_plugin_loaders, get_all_roles, get_role_path
    from ansible.plugins.loader import path_dwim_relative

    collection_dir = path_dwim_relative(__file__, '..', '..', 'test_collections', 'test_roles_include')
    add_all_plugin_dirs(directory_path=collection_dir, subdirectory='roles')
    get_all_plugin_loaders()

    test_role_dir = tempfile.mkdtemp()
   

# Generated at 2022-06-23 07:09:25.683151
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    def validate_copied_object(copied_object, original_object):

        assert copied_object.name == original_object.name
        assert repr(copied_object.args) == repr(original_object.args)
        assert repr(copied_object.tags) == repr(original_object.tags)
        assert copied_object.when == original_object.when
        assert copied_object.register == original_object.register
        assert copied_object.delegate_to == original_object.delegate_to
        assert copied_object.environment == original_object.environment
        assert repr(copied_object.vars) == repr(original_object.vars)
        assert repr(copied_object.notify) == repr(original_object.notify)

# Generated at 2022-06-23 07:09:35.108582
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.playbook

    task = IncludeRole()
    task._parent_role = ansible.playbook.Role()
    task._parent_role._role_path = 'path/to/roles/test'
    task._parent_role._role_name = 'test'
    task._parent_role.get_role_params = lambda: dict(foo='bar')

    assert task.get_include_params() == dict(foo='bar',
                                             ansible_parent_role_paths=['path/to/roles/test'],
                                             ansible_parent_role_names=['test'])

# Generated at 2022-06-23 07:09:43.225214
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    loader = DataLoader()

    hosts = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=hosts)

    name = 'test_play'
    play_source =  dict(
            name = name,
            hosts = 'localhost',
            gather_facts = 'no',
            roles = [
                dict(
                    name = 'some-role'
                ),
                dict(
                    name = 'some-other-role'
                )
            ]
        )
    play = Play.load

# Generated at 2022-06-23 07:09:56.075465
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import os
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    block = Block()
    role = Role()
    task_include = TaskInclude()
    loader = DataLoader()
    variable_manager = VariableManager

# Generated at 2022-06-23 07:10:08.508368
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'name': 'some_name',
        'action': 'include_role',
        'args': {
            'tasks_from': 'some_tasks_from',
            'vars_from': 'some_vars_from',
            'defaults_from': 'some_defaults_from',
            'handlers_from': 'some_handlers_from',
            'allow_duplicates': True,
            'public': True,
            'apply': {},
            'rolespec_validate': True,
        }
    }

    task = IncludeRole.load(data=data)
    assert task._role_name == 'some_name'
    assert task._from_files['tasks'] == 'some_tasks_from'

# Generated at 2022-06-23 07:10:19.999292
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # real test should be done in test/units/test_include_role.py
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import os

    display.verbosity = 3
    collection_name = 'test_collection.test_ns'
    collection_path = './test/units/utils/collection_loader/test_collections/%s' % collection_name
    parent_role_name = 'test_role'
    parent_role_path = '%s/roles/%s' % (collection_path, parent_role_name)
    role_name = 'test_role_included'

# Generated at 2022-06-23 07:10:23.300435
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    task = IncludeRole(block=block, role=role, task_include=task_include)
    assert type(task._from_files) == dict

# Generated at 2022-06-23 07:10:35.677095
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role_block = Block()
    role_block.name = 'dummy'
    include_role_obj = IncludeRole(role_block)
    include_role_obj._role_name = 'test'
    include_role_obj.vars.update({'var1': 'test'})
    include_role_obj.statically_loaded = True
    include_role_obj._from_files.update({'var2': 'test'})

    include_role_obj_new = include_role_obj.copy()

    assert len(include_role_obj_new.vars) == 1
    assert include_role_obj_new.vars['var1'] == 'test'
    assert include_role_obj_new._role_name == 'test'

# Generated at 2022-06-23 07:10:46.622712
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager

    variable_manager = VariableManager()

    # Set up an IncludeRole class instance
    t = Task()
    b1 = Block()
    r = Role()
    include = IncludeRole(block=b1, role=r, task_include=t)
    include._role_name = "role_name"
    include._role_path = "role_path"
    include._from_files = {"from_key":"from_file"}

# Generated at 2022-06-23 07:10:57.780976
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 07:11:05.926149
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    '''
    Returns the name of the include_role statement as a string.
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    import os

    test_dir = os.path.dirname(__file__)
    baselib = os.path.abspath(os.path.join(test_dir, '..', 'lib'))
    if baselib not in sys.path:
        sys.path.insert(0, baselib)

    test_cases = [
        {
            "name": "include_role",
            "expected_output": "include_role: myrole"
        }
    ]


# Generated at 2022-06-23 07:11:16.103137
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # pylint: disable=protected-access
    include_role = IncludeRole()
    assert (include_role.get_include_params() is not None)

    # Setup a parent include_role
    parent_include_role = IncludeRole()
    parent_include_role._parent_role = Role()
    parent_include_role._parent_role.vars = {
        'key1': 'value1',
        'key2': 'value2',
    }
    parent_include_role._parent_role.name = 'parent_role'
    parent_include_role._parent_role._role_path = '/path/to/parent_role'
    v = parent_include_role.get_include_params()
    assert (isinstance(v, dict))
    assert (len(v) == 4)

# Generated at 2022-06-23 07:11:17.100273
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()


# Generated at 2022-06-23 07:11:28.624618
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    host = "127.0.0.1"
    block1 = Block()
    block1.block  = list()
    block1.rescue = list()
    block1.always = list()
    block2 = Block()
    block2.block  = list()
    block2.rescue = list()
    block2.always = list()
    block1.load({"block": [{"include_role": {"name": "common"}}]})
    block2.load({"block": [{"include_role": {"name": "common"}}]})
    from ansible.playbook.role import Role
    role = Role()
    role._role_path = "/etc/ansible/roles/role_name"
    block1.resolve_task_include("include_role", host, [], False, False, role)

# Generated at 2022-06-23 07:11:40.147476
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    # prepare play
    play = Play().load({'name': 'fakeplay', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=None, loader=None)
    play._role_names = ['firstrole']
    play._role_paths = ['/path/to/firstrole']
    task_vars = {'ansible_parent_role_names': ['firstrole'], 'ansible_parent_role_paths': ['/path/to/firstrole']}

    play_context = PlayContext()

    #

# Generated at 2022-06-23 07:11:52.036634
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.playbook
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.disable_warnings import DisableWarningsContext

    assert isinstance(IncludeRole.get_include_params, ansible.playbook.attribute.Attribute)

    assert isinstance(ansible.playbook.attribute.FieldAttribute.__get__, object.__getattribute__)

    assert isinstance(ansible.playbook.attribute.FieldAttribute.__set__, object.__setattr__)

    assert isinstance(ansible.playbook.attribute.FieldAttribute.__delete__, object.__delattr__)


    with DisableWarningsContext():
        x = IncludeRole()

    assert isinstance(x, IncludeRole)

# Generated at 2022-06-23 07:11:55.773661
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    '''Unit test for get_name function of class IncludeRole.'''
    assert IncludeRole._get_name() == '%s : %s'


# Generated at 2022-06-23 07:11:58.802827
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    obj = IncludeRole()
    obj.action = "set_fact"
    obj._role_name = "test_role_name"
    assert obj.get_name() == "set_fact : test_role_name"


# Generated at 2022-06-23 07:12:10.482543
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    attr_map = dict()
    display = Display()
    ansible_version = dict()
    ansible_version['full'] = '2.5.5'
    ansible_version['major'] = '2'
    ansible_version['minor'] = '5'
    ansible_version['revision'] = '5'
    ansible_version['string'] = '2.5.5'
    attr_map['_parent'] = role
    attr_map['_role'] = role
    attr_map['action'] = 'include_role'
    attr_map['args'] = {}
    attr_map['loop'] = dict()
    attr_map['name'] = 'include_role_test'

# Generated at 2022-06-23 07:12:22.360471
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    play_context = PlayContext()
    loader = None
    variable_manager = None
    play = Play().load(dict(name="test play",
                            hosts=['all'],
                            gather_facts='no',
                            roles=['test_role']),
                       variable_manager=variable_manager, loader=loader)
    display.verbosity = 3
    block = Block(play=play)
    role = None
    task_include = None
    include_role = IncludeRole(block, role, task_include)
    include_role.args = {'name' : 'test_role'}
    include_role.action = 'include_role'
    include_role._role_name = 'test_role'

# Generated at 2022-06-23 07:12:29.851086
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    #Load a IncludeRole object with no data
    ir = IncludeRole.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    #Make sure that the load method creates the correct IncludeRole object
    assert ir._parent_role is None
    assert ir._role_name is None
    assert ir._role_path is None
    assert ir._from_files == {}
    assert ir.statically_loaded is False
    assert ir.public is False

    #Load a IncludeRole object with valid data
    data={'include_role': {}}
    ir = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    #Make sure that the load method creates the correct IncludeRole object
    assert ir._parent_

# Generated at 2022-06-23 07:12:42.494484
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''
    Unit test for method get_include_params of class IncludeRole
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 07:12:43.045218
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass  # TODO

# Generated at 2022-06-23 07:12:46.662406
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = "name"
    ir._role_name = "role_name"
    assert ir.get_name() == ir.name
    ir.name = None
    assert ir.get_name() == "%s : %s" % (ir.action, ir._role_name)

# Generated at 2022-06-23 07:12:57.651213
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print()
    print("test get_block_list")

    # Test setup: Data to test

# Generated at 2022-06-23 07:13:03.870624
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    class MockRole(object):
        def get_name(self):
            return 'name'

        def get_role_params(self):
            return {'k1': 'v1'}

    ir = IncludeRole()
    ir._parent_role = MockRole()

    assert ir.get_include_params() == { 'k1': 'v1',
                                        'ansible_parent_role_names': ['name'],
                                        'ansible_parent_role_paths': [None] }

# Generated at 2022-06-23 07:13:12.353207
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    IncludeRole: Tests the get_block_list method of the IncludeRole class
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.block import Block

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    block = Block()

    ir = IncludeRole()

    # Test the return format of an empty block
    assert ir.get_block_list() == ([], []), \
        "When the block is empty, it should return a tuple of empty lists."

    # Test with an empty role
    ir._role_name = 'this-should-not-be-valid'

# Generated at 2022-06-23 07:13:22.390310
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test should be performed only if ansible-base is not installed
    if C.DEFAULT_MODULE_PATH:
        return

    # Test for IncludeRole.get_include_params
    # pylint: disable=missing-docstring
    import unittest
    import os

    class TestIncludeRoleGetIncludeParams(unittest.TestCase):
        def test_get_include_params_with_parent_role(self):
            data = """
- name: Test IncludeRole.get_include_params
  hosts: localhost
  roles:
    - test_include_role
            """
            current_dir = os.path.dirname(os.path.realpath(__file__))
            role_path = os.path.join(current_dir, "role_for_testing")

            # Collect tasks
           

# Generated at 2022-06-23 07:13:27.052428
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()

    ri = RoleInclude.load('foo', block=block, role=role)
    role_include = IncludeRole(block=block, role=role, task_include=ri)

    assert role_include.get_name() == 'foo : foo'


# Generated at 2022-06-23 07:13:37.710424
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    add_all_plugin_dirs()
    loader = AnsibleCollectionLoader()

    playbook = """
    - hosts: localhost
      tasks:
        - name: include first level
          include_role:
            name: my.first_level_role
    """


# Generated at 2022-06-23 07:13:38.370916
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()

# Generated at 2022-06-23 07:13:40.220329
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()
    result = ir.get_include_params()
    assert not result

# Generated at 2022-06-23 07:13:47.965700
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    block = Block()
    role = Role()
    role._role_path = "test_role_path"
    role.get_role_params = lambda: {'test_role_param': 1}
    role.get_name = lambda: 'test_parent_role_name'

    ir = IncludeRole(block=block, role=role)

    v = ir.get_include_params()
    expected = {'test_role_param': 1,
                'ansible_parent_role_names': ['test_parent_role_name'],
                'ansible_parent_role_paths': ['test_role_path']}
    assert v == expected, "IncludeRole.get_include_params method returned wrong value"

# Generated at 2022-06-23 07:13:58.485023
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    block = Block()
    role = Role()

    data = {'include_role': {'name': 'ceph-monitor'}}
    # data without a name
    data_no_name = {'include_role': {}}
    # data with invalid options
    data_invalid_options = {'include_role': {'name': 'ceph-monitor', 'invalid': ''}}

    # test a successful data load

# Generated at 2022-06-23 07:14:08.670653
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    role._role_path = 'path/to/my/role/'
    include = IncludeRole(block=block, role=role)
    include._role_name = 'jdoe.myrole'
    assert include.get_name() == 'include_role : jdoe.myrole'
    block = Block()
    role = Role()
    role._role_path = 'path/to/my/role/'
    include = IncludeRole(block=block, role=role)
    include.name = 'My Custom Name'
    assert include.get_name() == 'My Custom Name'


# Generated at 2022-06-23 07:14:19.483464
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task

    # Declare some classes and objects we need
    # Variables
    variables = {
        'role': 'test_role',
        'playbook_dir': 'playbook_dir',
        'namespace': 'namespace',
        'repo_url': 'https://github.com/ansible-collections/test_collection',
        'allow_duplicates': 'true',
        'vars_from_files': ['b.yml'],
        'vars_from_files_B': 'b.yml',
    }
    # Variable Manager
    variable_manager = ansible.vars.VariableManager()
    variable_manager._extra_vars = variables
    # Executor

# Generated at 2022-06-23 07:14:31.450014
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role import include_role_tasks
    _block_loader =  Block.load
    def _mock_Block_load(data, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        if '_include' in data:
            return IncludeRole.load(data, block=block, role=role, task_include=task_include,
                                    variable_manager=variable_manager, loader=loader)
        else:
            return _block_loader(data, block=block, role=role, task_include=task_include,
                                 use_handlers=use_handlers, variable_manager=variable_manager, loader=loader)
    Block.load = _mock_Block_load

# Generated at 2022-06-23 07:14:32.039665
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:14:33.218841
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole('')

# Generated at 2022-06-23 07:14:43.835074
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    task_class = IncludeRole
    task_name = 'foo'
    block_data = {'name': 'foo', 'foo': 'bar'}
    role_block = Block.load(block_data, task_name=task_name, role=None, task_include=None)

    ir = task_class.load(block_data, block=role_block, role=None, task_include=None)
    assert ir.name == 'foo'
    assert ir._role_name == 'foo'
    assert ir.foo == 'bar'
    assert ir.statically_loaded == True
    assert 'name' in ir.args
    assert ir.args['name'] == ir.name

    # test optional role name

# Generated at 2022-06-23 07:14:55.735928
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir1 = IncludeRole(role='test_role', apply={'tags': 'foo, bar'})
    assert isinstance(ir1, IncludeRole)
    assert isinstance(ir1, Block)
    assert isinstance(ir1, TaskInclude)

    # getattr test
    assert ir1.role == 'test_role'
    assert ir1.action == 'include_role'
    assert ir1.apply == {'tags': 'foo, bar'}

    # get_name test
    assert ir1.get_name() == ': test_role'

    # get_include_params test
    assert ir1.get_include_params() == {}

    data = {
        'include': 'test_role',
        'apply': {'tags': 'foo, bar'}
    }
    variable_manager = {}
   

# Generated at 2022-06-23 07:15:07.049046
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Setup
    block = Block()
    role = Role().load({'name': 'role1', 'hosts': 'localhost', 'tasks': []})
    task_include = TaskInclude()
    data = {'name': 'task1', 'args': {'role': 'role2'}}

    # Exercise
    include_role = IncludeRole(block, role, task_include)
    include_role.copy()

    # Verify
    assert not include_role.statically_loaded
    assert not include_role._from_files
    assert not include_role._parent_role
    assert not include_role._role_name
    assert not include_role._role_path

# Generated at 2022-06-23 07:15:18.317525
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.verbosity = 3
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager

    test_action = '- include_role: name=apache_role'

    example_play = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [],
        tasks = [
            dict(action=test_action)
          ]
        )

    block_loader = action_loader.get('include_role')
    block = IncludeRole.load(example_play['tasks'][0], block=Block(parent_block=None, role=None, task_include=None), role=None, task_include=None)

# Generated at 2022-06-23 07:15:31.499593
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import ansible
    import os
    import sys

    # the block and role were just to load the task_include,
    # they are not needed here
    block

# Generated at 2022-06-23 07:15:36.127985
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = task_include(block, role)
    test_class = IncludeRole(block, role, task_include)

    assert "include_role : some_role" == test_class.get_name()


# Generated at 2022-06-23 07:15:39.454242
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    target = IncludeRole()
    target.action = 'include_role'
    target._role_name = 'sample_role'

    expect = 'include_role : sample_role'
    actual = target.get_name()

    assert expect == actual



# Generated at 2022-06-23 07:15:48.348617
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    name = "name"
    role = Role(name="role")
    block = Block(role=role, parent=None)

    include_role = IncludeRole(block=block, role=role)
    include_role.statically_loaded = False
    include_role._from_files = { "from_files" : {"from_files_key": "from_files_value"} }
    include_role._parent_role = "parent_role"
    include_role._role_name = "role_name"
    include_role._role_path = "role_path"

    exclude_parent = "exclude_parent"
    exclude_tasks = "exclude_tasks"

    new_me = include_role.copy(exclude_parent=exclude_parent, exclude_tasks=exclude_tasks)

    assert new