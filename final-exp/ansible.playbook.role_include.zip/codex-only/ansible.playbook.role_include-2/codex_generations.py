

# Generated at 2022-06-23 07:05:48.439131
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    ir = IncludeRole()

    assert isinstance(ir, Task)
    assert isinstance(ir._variable_manager, VariableManager)

# Generated at 2022-06-23 07:05:59.361474
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    # build a Role
    data = dict(name="test_role")
    role = Role.load(data)

    # build an IncludeRole
    data = dict(name='include_role_test')
    ir = IncludeRole.load(data, role=role)

    # copy the IncludeRole
    new_ir = ir.copy()

    # check result
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_name == ir._role_name
    assert new_ir._role_path == ir._role_path
    assert new_ir._from_files == ir._from_files
    assert new_ir.allow_duplicates == ir.allow_duplicates
    assert new_ir.public == ir.public
    assert new_ir.rolespec_validate == ir.roles

# Generated at 2022-06-23 07:06:08.998251
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils.basic import AnsibleModule

    # Setup
    set_module_args({})
    AnsibleModule.load_ansible_module = lambda x: None
    AnsibleModule.exit_json = lambda x, **kwargs: None
    AnsibleModule.fail_json = lambda x, **kwargs: None

    display = Display()
    display.verbosity = 3

    mytask = IncludeRole()

    mytask.action = 'include_role'
    mytask.name = 'test_task'
    mytask._role_name = 'test_role'
    mytask._from_files['tasks'] = 'main.yml'


# Generated at 2022-06-23 07:06:18.349295
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # create include role
    data = {'name':'smeagol'}
    ir = IncludeRole.load(data)
    assert ir._role_name == 'smeagol'

    # create include role
    data = {'role':'gollum'}
    ir = IncludeRole.load(data)
    assert ir._role_name == 'gollum'

    # create include role
    data = {'role':'gollum', 'tasks_from':'main.yml'}
    ir = IncludeRole.load(data)
    assert ir._role_name == 'gollum'
    assert ir._from_files['tasks'] == 'main.yml'

    # create include role
    data = {'role':'gollum', 'apply':{}}
    ir = IncludeRole.load

# Generated at 2022-06-23 07:06:29.216358
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    # Maybe a bit complex, but we want to pass a test :)
    task = Task()
    task._role = Role()
    task._role._play = PlayContext()
    task._role._play.handlers = [Block()]
    task._role._play.roles = [Role()]


# Generated at 2022-06-23 07:06:34.156561
# Unit test for constructor of class IncludeRole

# Generated at 2022-06-23 07:06:46.675079
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Declare a task
    my_task = IncludeRole(
        role=Role(),
        block=(
            Block(
                role=Role(),
                task_include=IncludeRole(
                    role=Role(),
                    block=Block(
                        role=Role(),
                        task_blocks=[]
                    )
                )
            ),
            Block(
                role=Role(),
                task_blocks=[]
            )
        ),
    )

    # Declare an IncludeRole with a task
    include_role = IncludeRole(
        role=Role(),
        block=Block(
            role=Role(),
            task_blocks=[
                my_task
            ]
        )
    )

    # Test
    assert include_role.get_name() == "include_role :"

    # Declare the name of an IncludeRole
    include

# Generated at 2022-06-23 07:06:58.278909
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    obj = IncludeRole()
    obj._from_files = dict(a='a')
    obj._parent_role = '_parent_role'
    obj._role_name = '_role_name'
    obj._role_path = '_role_path'
    obj.allow_duplicates = True
    obj.apply = 'apply'
    obj.args = dict(a='a')
    obj.collections = ['collections']
    obj.delegate_to = 'delegate_to'
    obj.delegate_facts = 'delegate_facts'
    obj.deprecated = 'deprecated'
    obj.loop = ['loop']
    obj.loop_args = dict(a='a')
    obj.loop_with_items = ['loop_with_items']
    obj.loops = 'loops'
   

# Generated at 2022-06-23 07:07:07.312594
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ri = IncludeRole(block=Block(parent_block=None, role=None))
    assert ri.get_name() == 'meta : <unknown>'
    ri = IncludeRole(block=None, role=None)
    assert ri.get_name() == '<unknown> : <unknown>'
    ri = IncludeRole(block=Block(parent_block=None, role=None), role=None)
    assert ri.get_name() == '<unknown> : <unknown>'

# Generated at 2022-06-23 07:07:18.762219
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = None
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'include_role_name':'common'}

    # create a dummy include role object
    block = Block()
    role = Role()
    role._role_name = 'common'
    role._role_path = 'common'
    role._metadata_path = 'common'
    task_include = IncludeRole(block=block, role=role)

# Generated at 2022-06-23 07:07:31.286534
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """Unittest for `IncludeRole.load`
    """
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import ansible.playbook.role as role
    import ansible.playbook.task_include as task_include

    test_dict = dict(
        name='test-role',
        tasks_from='test-role/tasks/main.yml',
        vars_from='test-role/vars/main.yml',
        defaults_from='test-role/defaults/main.yml',
        handlers_from='test-role/handlers/main.yml',
        apply={},
        public=False,
        allow_duplicates=True,
    )

    test_obj = IncludeRole.load(test_dict)
   

# Generated at 2022-06-23 07:07:38.414269
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.playbook

    play = ansible.playbook.Play().load({'name': 'test play', 'hosts': 'localhost'}, variable_manager=None, loader=None)
    include_name = 'include name'
    parent_role_name = 'parent role name'
    parent_role_path = 'parent role path'
    parent_role = ansible.playbook.Role().load({'name': parent_role_name, 'path': parent_role_path}, play=play, variable_manager=None, loader=None)
    # create a Block but do not assign it to a Task. task_include.Block is not exposed by Ansible.
    block = ansible.playbook.block.Block()

# Generated at 2022-06-23 07:07:53.186089
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.playbook.play

    # Create role object
    blocks = [
        ansible.playbook.block.Block(role=None,parent=None).load({u'block': [{u'debug': {u'msg': u'all done'}}], u'apply': {u'load_vars': u'{{ play_vars }}'}})
        ]
    role = ansible.playbook.role.Role(
        name="test",
        collection_list=[],
        loader=None,
        variable_manager=None,
        metadata=None,
        play=None
    ).load({'block': blocks, 'defaults': []})

    # Create include object
    data = {u'include_role': {u'name': u'common', u'vars': {}, u'apply': {}}}


# Generated at 2022-06-23 07:08:08.963741
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    host_vars = {
        'test_host': {
            'test_var': 'test_value'
        }
    }
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader()))
    variable_manager.add_vars(host_vars)
    variable_manager.set_vars(host_vars['test_host'])

    parent_role = Role()
    parent_role._role_path = '/test/test_playbook/roles/test_role'

    ir = IncludeRole()
    ir._parent_role = parent_role

    v = ir.get_include_params()

# Generated at 2022-06-23 07:08:09.606735
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:08:18.421827
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Setup
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role.statically_loaded = True
    include_role._from_files = {'a': 'b'}
    include_role._parent_role = role
    include_role._role_name = 'role_name'
    include_role._role_path = 'path'

    # Exercise
    new_include_role = include_role.copy()

    # Verify
    assert isinstance(new_include_role, IncludeRole)
    assert new_include_role.statically_loaded == True
    assert new_include_role._from_files == {'a': 'b'}
    assert new_include_role._parent_role == role


# Generated at 2022-06-23 07:08:23.052603
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.verbosity = 3
    mydir = os.path.dirname(__file__)
    myplaybook = os.path.join(mydir, 'test_playbook.yml')
    mygalaxy_path = os.path.join(mydir, 'test_galaxy_role')

# Generated at 2022-06-23 07:08:32.914594
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole(block=None, role=None, task_include=None)
    ir.statically_loaded = 1
    ir._from_files = {'test': 'test'}
    ir._parent_role = 'tag'
    ir._role_name = 'test'
    ir._role_path = 'test'
    new_me = ir.copy()
    assert new_me.statically_loaded == ir.statically_loaded
    assert new_me._from_files == ir._from_files
    assert new_me._parent_role == ir._parent_role
    assert new_me._role_name == ir._role_name
    assert new_me._role_path == ir._role_path

# unit test for method load of class IncludeRole

# Generated at 2022-06-23 07:08:42.002903
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    role = RoleInclude()
    role._role_name = "test"
    role.args = dict(
        name="test",
        apply={},
        tasks_from="test",
        vars_from="test",
        defaults_from="test",
        handlers_from="test",
        public=False,
        allow_duplicates=True,
        rolespec_validate=True
    )

    play_context = dict(
        play=Play().load(dict(
            hosts=['localhost'],
            gather_facts='no',
            connection='local',
            roles=[]
        ), variable_manager=VariableManager())
    )

# Generated at 2022-06-23 07:08:45.324502
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class DummyIncludeRole(IncludeRole):
        def __init__(self, block, role, task_include):
            super(DummyIncludeRole, self).__init__(block, role, task_include)
            self.name = None
            self._role_name = 'foo'

    assert DummyIncludeRole(None, None, None).get_name() == 'include_role : foo'
    assert DummyIncludeRole(None, None, None, name='bar').get_name() == 'bar'

# Generated at 2022-06-23 07:08:56.553319
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # create a temp block and role to use to load in the data
    b = Block()
    r = Role()
    data = dict(
        name='testrole',
        role='testrole',
        allow_duplicates=True,
        static=True,
        public=True,
        apply=dict(
            a='b',
            c=dict(
                d=5,
            ),
        ),
        tasks_from='tasks/main.yml',
        vars_from='vars/main.yml',
    )
    # check loading of data
    tr = IncludeRole.load(data=data, block=b, role=r)
    assert 'name' in tr.args
    assert tr.args['name'] == 'testrole'
    assert 'role' in tr.args
    assert tr.args

# Generated at 2022-06-23 07:09:00.307507
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'name'
    assert ir.get_name() == 'name'
    ir.name = None
    ir.action = 'action'
    ir._role_name = 'role_name'
    assert ir.get_name() == 'action : role_name'

# Generated at 2022-06-23 07:09:07.778108
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    new_ir = ir.copy()

    assert type(new_ir) == IncludeRole
    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from_files == ir._from_files
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_name == ir._role_name
    assert new_ir._role_path == ir._role_path
    assert new_ir.action == ir.action
    assert new_ir.always_run == ir.always_run

# Generated at 2022-06-23 07:09:19.573004
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    options = {'a': 1, 'b': 2}
    with pytest.raises(AnsibleParserError) as excinfo:
        incrole = IncludeRole(block=None, role=None, task_include=None)
    assert '`block` is a required argument for IncludeRole' in str(excinfo.value)
    incrole = IncludeRole(block=Block(), role=None, task_include=None)
    assert not incrole.name
    assert not incrole.action
    assert not incrole.args
    assert not incrole.notify
    assert not incrole.when
    assert not incrole.errors
    assert incrole.always_run
    assert incrole.changed_when

# Generated at 2022-06-23 07:09:27.893300
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.vars import VariableManager, combine_vars
    from ansible.inventory import Inventory
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader

    parser = Playbook.load('../../../test/units/parsing/yaml/role_include.yaml')
    hosts = Inventory(loader=DataLoader(), variable_manager=VariableManager()).get_hosts()
    play = next(parser.get_plays_for_hosts(hosts))

    include_role = play.compile()
    final = combine_vars(play._variable_manager, play._loader)
    play.variable_manager = play._variable_manager = VariableManager(loader=play._loader, inventory=play.inventory)

# Generated at 2022-06-23 07:09:40.150969
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class Role1:
        def __init__(self,name):
            self._name = name

        def get_name(self):
            return self._name

    class Role2:
        def __init__(self,name):
            self._name = name

        def get_role_params(self):
            return dict(self._name)

    class Play1:
        def __init__(self,name):
            self._name = name

        def get_name(self):
            return self._name

    class Block1:
        def __init__(self,name):
            self._name = name

        def get_name(self):
            return self._name

    block1 = Block1('block1')
    play1 = Play1('play1')
    role1 = Role1('role1')
    role2 = Role

# Generated at 2022-06-23 07:09:50.494177
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import find_plugin

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(
                include_role=dict(name='myrole')
            ))
        ]
    )


# Generated at 2022-06-23 07:09:59.611051
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class MockRole:
        def __init__(self):
            self._metadata = None
            self._parents = None
        def get_name(self):
            return 'my_role'

    class MockVariableManager:
        def __init__(self):
            pass

    class MockLoader:
        def __init__(self):
            pass

    class MockBlock:
        def __init__(self):
            self.vars = None
            self.parent = None
            self.always = None
            self.name = None
            self.when = None
            self.register = None

    class MockTaskInclude:
        def __init__(self):
            self.vars = None

    class MockPlay:
        def __init__(self):
            self.roles = None

    role = MockRole()

# Generated at 2022-06-23 07:10:10.786548
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import tempfile
    import stat
    from ansible.constants import THEMES_PATH
    ROLE_NAME = 'role_foobar'
    role_dir = tempfile.mkdtemp()
    tasks_path = os.path.join(role_dir, 'tasks')
    os.makedirs(tasks_path)
    open(os.path.join(tasks_path, 'main.yml'), 'w+').close()
    tmp_api = tempfile.NamedTemporaryFile(mode='w+', suffix='.py')
    tmp_api.write("__version__ = '1.0'\n")
    tmp_api.flush()
    # Make the custom module available for import testing

# Generated at 2022-06-23 07:10:23.300824
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    r = Role()
    task = IncludeRole(role=r, args={'name': 'foo'})

    # Test task with no parent role
    params = task.get_include_params()
    assert params == {
        'ansible_include_role_names': ['foo'],
        'ansible_include_role_path': None
    }

    # Test task with a parent role
    r.name = 'bar'
    r._role_path = '/path/to/bar'
    r._metadata.collections = [('namespace', 'collection')]
    r._metadata.namespace = 'namespace'

    r2 = Role()
    r2.name = 'baz'
    r2._role_path = '/path/to/baz'
    r.parents.append(r2)

    params = task

# Generated at 2022-06-23 07:10:35.677184
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Test with no parameters
    ir = IncludeRole()
    assert ir.get_name() == 'include_role : UNDEF'
    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir._rolespec_validate == True
    assert ir._parent_role == None
    assert ir._role_name == None
    assert ir._role_path == None
    assert ir._from_files == {}

    # Test with some parameters (don't validate path)
    ir = IncludeRole(name='test', public=True, rolespec_validate=False)
    assert ir.get_name() == 'test'
    assert ir._allow_duplicates == True
    assert ir._public == True
    assert ir._rolespec_validate == False
    assert ir._parent_role == None

# Generated at 2022-06-23 07:10:40.006517
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    ir = IncludeRole(block, role, task_include)
    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-23 07:10:41.091848
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    i = IncludeRole()
    assert i is not None

# Generated at 2022-06-23 07:10:52.608349
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    block1 = Block()
    block1.vars = UnsafeProxy({'file_role_tasks': 'tasks/main.yml'})
    variable_manager = VariableManager()
    variable_manager.set_inventory(DataLoader().load_inventory('examples/ansible_hosts'))
    variable_manager.set_playcontext(PlayContext(play=Play()))

    templar = Templar(loader=None, variables=variable_manager.get_vars())
   

# Generated at 2022-06-23 07:11:03.609424
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    my_role = Role()
    my_copy_role = Role()
    my_role._role_path = 'my_role_path'
    my_copy_role._role_path = 'my_copy_role_path'
    my_role_parent = my_role

    my_block = Block(play=None, parent_block=my_role)
    my_block._parent_role = my_role

    my_copy_block = Block(play=None, parent_block=my_copy_role)
    my_copy_block._parent_role = my_copy_role

    my_ir = IncludeRole(block=my_block, role=my_role)
    my_ir._parent_role = my_role


# Generated at 2022-06-23 07:11:04.085251
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-23 07:11:16.147698
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    display.verbosity = 3
    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'testhost',
        gather_facts = 'no',
        tasks = [dict(action=dict(module='shell', args='ls'))]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)
    t = IncludeRole()
    task = Task()
    task._role = play
    t._parent = task
    t.load(dict(name = 'dummy'))
    print(t._role_name)
    print(t.action)
    print

# Generated at 2022-06-23 07:11:28.035035
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    # Simulate a Play
    p = Play()
    p.vars = dict()
    p.vars['foo'] = 'bar'

    # Creaate a mock block (task)
    b = Base()
    b._role = None
    b._play = p
    b._variable_manager = VariableManager(loader=None)

    # Create a mock include role task
    ir = IncludeRole()
    ir._role_name = 'foo'
    ir._parent = b
    ir.role = 'foo'
    ir.rolespec_validate = True
    ir.allow_duplicates = True

# Generated at 2022-06-23 07:11:38.474685
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    block = Block().load({
        'vars': dict(),
        'block': [
            {
                'include_role': {
                    'name': 'foo',
                },
            }
        ]
    }, variable_manager=variable_manager, loader=loader)

    role = RoleInclude().load({}, block=block, variable_manager=variable_manager, loader=loader)

    assert block.block[0].get_name() == 'include_role : foo'
    assert block.block[0].get_block().block[0].get_name() == 'foo'

# Generated at 2022-06-23 07:11:43.632515
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    loader = None
    t = IncludeRole(block=None, role=None, task_include=None)
    t.name = "test"
    t._role_name = 'test1'
    assert t.get_name() == "test : test1"
    t.name = None
    assert t.get_name() == "include_role : test1"

# Generated at 2022-06-23 07:11:55.051453
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    IncludeRole: the method load should work in the following cases.
    """
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    # make sure include role action is enabled
    if C._ACTION_INCLUDE_ROLE not in C.BUILTIN_ACTION_PLUGINS:
        pytest.skip("Please enable include role action")


    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 07:12:02.367461
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
  """
  Call method copy of class IncludeRole and compare it with the value returned by a direct call to constructor.
  """
  t = IncludeRole(role=Role())
  t.rolename = 'rolename'
  t.tasks = ['tasks']
  t.statically_loaded = 'statically_loaded'
  t._from_files = { 'from_files' : 'from_files' }
  t._parent_role = 'parent_role'
  t._role_name = 'role_name'
  t._role_path = 'role_path'
  new_copy = t.copy()
  new_constructor = IncludeRole(role=Role())
  new_constructor.rolename = 'rolename'
  new_constructor.tasks = ['tasks']
  new_constructor.statically_loaded

# Generated at 2022-06-23 07:12:13.380648
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    templar=Templar()
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.errors import AnsibleParserError

    display = Display()
    tmp_dir = C.DEFAULT_LOCAL_TMP
    loader = DataLoader()
    collection = AnsibleCollectionRef.from_string('test.test')
    collection._paths = ['../../test/test_collections/test_ns/test_plugin']
    collection._paths.reverse()

# Generated at 2022-06-23 07:12:24.385571
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    When testing IncludeRole.get_include_params() method using a test
    role named 'test_role', the returned dict should contain
    keys named 'ansible_role_names', 'ansible_role_paths',
    'ansible_parent_role_names', 'ansible_parent_role_paths'.
    """
    import ansible
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 07:12:37.349752
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Check that the base object constructor is working properly
    inc1 = IncludeRole()

    # Check that the subclass object constructor is working properly
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    inc2 = IncludeRole(Block(), Task())

    # Check that the load method is working properly
    assert inc1.load(dict(name='role1', apply='all')) is inc1
    assert inc2.load(dict(name='role2', apply='all')) is inc2

    # Check that the get_block_list method is working properly
    assert len(inc1.get_block_list()) == 2
    assert len(inc2.get_block_list()) == 2

    # Check that the copy method is working properly
    assert inc1.copy() is not inc1
    assert inc2

# Generated at 2022-06-23 07:12:46.969288
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    myplay = 'myplay'
    myrole = 'myrole'
    mypath = 'mypath'
    mytasks = ['mytask1', 'mytask2']
    ir = IncludeRole(role=myrole, tasks=mytasks, task_include=None)
    ir.statically_loaded = False
    ir._from_files = {'task': 't.yml'}
    ir._parent_role = 'parent_role'
    ir._role_name = 'role_name'
    ir._role_path = mypath
    ir_copy = ir.copy()
    assert ir_copy.statically_loaded == ir.statically_loaded
    assert ir_copy._from_files == ir._from_files
    assert ir_copy._parent_role == ir._parent_role
    assert ir_copy._role

# Generated at 2022-06-23 07:12:57.651333
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    pb = Play().load({
        'name': 'Test Playbook',
        'hosts': 'localhost',
        'connection': 'local',
        'gather_facts': 'yes',
        'vars': {},
    }, variable_manager={})
    block = Block(play=pb)
    task = Task().load({'include_role': {'name': 'testrole'}}, block=block, role=None)
    ri = IncludeRole().load(task.args, block=block)
    assert ri.vars == {}
    assert ri.tasks_from is None
    assert ri.handlers_from is None
    assert ri._role_

# Generated at 2022-06-23 07:13:01.093500
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert not ir.allow_duplicates
    assert not ir.public
    assert ir.rolespec_validate

    ir.allow_duplicates = True
    ir.public = True
    ir.rolespec_validate = False

    assert ir.allow_duplicates
    assert ir.public
    assert not ir.rolespec_validate

# Generated at 2022-06-23 07:13:04.100963
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    a = IncludeRole()
    assert a.action == 'include_role'
# end of test

# Generated at 2022-06-23 07:13:12.479801
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    c_name = 'test_IncludeRole_get_block_list'
    r_name = 'test_role'
    b_name = 'test_block'
    t_name = 'test_task'

    r_block = Block(role=Role())

    # For some reason, it is not possible to create a child block without a parent
    # so we need to create a block with a role first, then we can create a child block
    # from it.
    r_block = Block(role=Role())
    block = Block.load(dict(name=b_name, parent=r_block), r_block, task_include=IncludeRole())
    task = Block.load(dict(name=t_name, action=dict(module='test')), block)
    block._resolve_task_include(task)

    ir

# Generated at 2022-06-23 07:13:22.448367
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import sys
    import os
    file_path = os.path.realpath(__file__)
    root_path = str(file_path).split('/')[-5]
    sys.path.append(root_path)
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import string_types

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
   

# Generated at 2022-06-23 07:13:23.051673
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:13:26.911746
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    Unit test for method get_include_params of class IncludeRole

    Tests a scenario without a parent role
    """
    ir = IncludeRole()
    v = ir.get_include_params()

    assert v == {}



# Generated at 2022-06-23 07:13:34.805081
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data_file_path = '../lib/ansible/playbook/test/unit/data/include_role.yml'
    with open(data_file_path, 'rb') as f:
        data = yaml.safe_load(f.read())

    role = Role()
    role._role_path = os.path.dirname(data_file_path)
    include_role = IncludeRole.load(data, role=role, loader=None)

    assert include_role.name == 'Foo'
    assert include_role.apply == {'tags': 'bar'}
    assert include_role.public
    assert include_role._from_files['vars'] == 'my.yml'
    assert include_role.no_log
    assert include_role._do_not_log
    assert include_role.allow

# Generated at 2022-06-23 07:13:37.504339
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create class instance
    ir = IncludeRole()
    assert ir.get_name() == 'include_role : '''


# Generated at 2022-06-23 07:13:38.569943
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-23 07:13:47.647005
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    role0 = Role()
    role1 = Role()
    role0._role_path = "abc"
    role1._role_path = "123"
    block0 = Block()
    block0.parents = [role0]
    block1 = Block()
    block1.parents = [role1]
    include = IncludeRole(block=block1, role=role1)
    expect1 = {'ansible_parent_role_names': [role1.get_name()],
               'ansible_parent_role_paths': [role1._role_path]}
    expect2 = {'ansible_parent_role_names': [role1.get_name(), role0.get_name()],
               'ansible_parent_role_paths': [role1._role_path, role0._role_path]}

# Generated at 2022-06-23 07:13:55.688721
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.debug('Entering test_IncludeRole_get_name')

    b = Block()
    r = Role()
    ir = IncludeRole(block=b, role=r)

    r._role_name = 'test_name'
    ir.action = 'test_action'

    assert ir.get_name() == 'test_name : test_action'

    ir.name = 'test_name2'
    assert ir.get_name() == 'test_name2'


# Generated at 2022-06-23 07:14:09.141707
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    # We do not have direct access to the parent_role in Role but we know it is
    # not None so we can check the value of the 'ansible_parent_role_paths' key
    # in the dictionary returned by the method
    class MyRole(Role):
        pass

    my_play = Play().load({'name': 'my_play', 'hosts': 'all'})
    my_variable_manager = VariableManager()
    my_loader = None

# Generated at 2022-06-23 07:14:20.064821
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import yaml

    class Playbook():
        pass

    class Block():
        pass

    pb = Playbook()
    p_block = Block()

    my_variable_manager = {}

    class Loader():
        pass

    loader = Loader()
    loader.path_dwim = lambda *args, **kwargs: args[0]

    include_role = IncludeRole()
    include_role._parent_role = None
    include_role._role_name = "test-role"
    include_role._parent = p_block
    include_role.action = 'include_role'
    include_role.args = {'name':'test-role'}
    include_role.statically_loaded = True


    class TestRole1():
        pass

    tr1 = TestRole1()
    tr1.get

# Generated at 2022-06-23 07:14:32.120038
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    new_me = ir.copy()

    assert new_me.statically_loaded == ir.statically_loaded
    assert new_me._from_files == ir._from_files
    assert new_me._parent_role == ir._parent_role
    assert new_me._role_name == ir._role_name
    assert new_me._role_path == ir._role_path
    assert new_me._action == ir._action
    assert new_me._always_run == ir._always_run
    assert new_me._any_errors_fatal == ir._any_errors_fatal
    assert new_me._any_errors_fatal_set == ir._any_errors_fatal_set
    assert new_me._any_errors_fatal_unset == ir._any_errors_fatal

# Generated at 2022-06-23 07:14:39.416489
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block1 = Block()
    block1.vars.update({ "var1": "value1" })
    block1.tags.update({ "tag1" })
    block2 = Block()
    role = Role()
    role.vars.update({ "var2": "value2" })
    role.tags.update({ "tag2" })

    include_test1 = IncludeRole(block=block1, role=role)
    include_test1.name = "Test1"
    include_test1.vars.update({ "var3": "value3" })
    include_test1.tags.update({ "tag3" })
    include_test1.args.update({ "name": "role1" })
    include_test1._role_name = "role1"

# Generated at 2022-06-23 07:14:40.638466
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-23 07:14:50.900281
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    d = dict(
        name='foo',
        static=True,
        tasks=dict(arg='val'),
        apply=dict(arg='val'),
        vars_from='test',
        rolespec_validate=False,
    )
    ir = IncludeRole.load(d)
    new_ir = ir.copy()

    assert new_ir._role_name == ir._role_name
    assert new_ir._from_files == ir._from_files
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_path == ir._role_path

    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir.apply == ir.apply
    assert new_ir.block is not ir.block
    assert new_ir.rolespec_valid

# Generated at 2022-06-23 07:14:59.955515
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir1 = IncludeRole()
    ir1._role_name = 'test'
    ir1.statically_loaded = True
    ir1._from_files = {'test_key': 'test_val'}
    ir1._parent_role = 'test_parent_role'
    ir1._role_path = 'test_role_path'
    ir1.public = True
    ir1.rolespec_validate = False
    ir1.allow_duplicates = False
    ir2 = ir1.copy()
    assert ir1._role_name == ir2._role_name
    assert ir1.statically_loaded == ir2.statically_loaded
    assert ir1._from_files == ir2._from_files
    assert ir1._parent_role == ir2._parent_role
    assert ir1._role

# Generated at 2022-06-23 07:15:11.654391
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class play1:
        name = "play1"
    class play2:
        name = "play2"

    class block1:
        parent = play1
        name = "block1"
        _role = "role1"
        all_parents = None
        _dependencies = []
        _apply_level = 0
        get_apply_level = lambda self: self._apply_level
        set_apply_level = lambda self, lvl: setattr(self, '_apply_level', lvl)

    class block2:
        parent = play2
        name = "block2"
        _role = "role2"
        all_parents = None
        _dependencies = []
        _apply_level = 0
        get_apply_level = lambda self: self._apply_level

# Generated at 2022-06-23 07:15:21.733927
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Execute context:
    # set up test objects
    module_utils_path = 'my_package.module_utils'
    display.verbosity = 1
    display.deprecated_errors = False
    data = {'action': 'include_role'}

    # validate with both None and some play and variable manager and loader
    assert IncludeRole.load(data)
    assert IncludeRole.load(data, variable_manager='var_man', loader='loader')
    assert IncludeRole.load(data, play='some_play', variable_manager='var_man', loader='loader')

    # validate with non-string values passed for name
    data['name'] = ['some_name']

# Generated at 2022-06-23 07:15:32.433236
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_include_role = IncludeRole()
    assert test_include_role.get_name() == 'include_role : None'
    test_include_role.name = "name"
    test_include_role._role_name = "role"
    assert test_include_role.get_name() == "name : role"
    test_include_role2 = IncludeRole()
    assert test_include_role2.get_name() == "include_role : None"
    test_include_role.name = None
    test_include_role._role_name = None
    assert test_include_role.get_name() == 'include_role : None'


# Generated at 2022-06-23 07:15:36.595482
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    r = IncludeRole(task_include=True)
    assert r
    assert isinstance(r, IncludeRole)
    assert isinstance(r, TaskInclude)
    assert r.action == 'meta'

# Unit tests for method load() of class IncludeRole

# Generated at 2022-06-23 07:15:45.145493
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # test variables used in test methods
    data_blocks = [
        dict(
            block=dict(
                name="test_role_inclusion",
                tasks=[
                    dict(
                        name="task",
                        include_role=dict(
                            name="test_role_inclusion"
                        )
                    )
                ]
            ),
            role=dict(
                name="test_role_inclusion_name",
                file_name="test_role_inclusion_file_name.yml",
                default_vars=dict(
                    foo=1
                )
            )
        )
    ]
    for data_block in data_blocks:
        block = Block.load(data_block.get('block'), task_include=dict(action='include_role'))