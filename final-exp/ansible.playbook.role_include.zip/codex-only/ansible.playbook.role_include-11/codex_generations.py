

# Generated at 2022-06-23 07:05:53.249262
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, TaskInclude)


# Generated at 2022-06-23 07:06:03.894505
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext

    m_options = {}

    m_options['connection'] = 'smart'
    m_options['forks'] = 10
    m_options['gather_facts'] = 'no'
    m_options['remote_user'] = 'test_user'
    m_options['sudo'] = True
    m_options['sudo_user'] = 'sudo_test_user'
    m_options['sudo_pass'] = 'test_pass'

    m_options['module_path'] = 'test_module_path'
    m_options['module_name'] = 'test_module_name'
    m_options['module_args'] = 'test_module_args'
    m_options['module_lang'] = 'test_module_lang'

# Generated at 2022-06-23 07:06:07.689682
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.playbook.block import Block

    block = Block()
    role = 'common'
    task_include = 'common.yml'

    # Test for class initialization
    includeRole_Ins = IncludeRole(block, role, task_include)

# Generated at 2022-06-23 07:06:17.985635
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play

    pb = Play.load({u'name': u'Test', u'roles': [u'role1']})
    rd = RoleDefinition()
    rd.name = u'role1'
    rd._role_path = u'./test/data'
    ir = IncludeRole()
    ir.action = u'include_role'
    ir._role_name = u'role1'
    ir.args = {u'name': u'role1'}
    ir._parent = pb
    ir._parent_role = rd

    blocks, handlers = ir.get_block_list(pb)

# Generated at 2022-06-23 07:06:28.926805
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    block = Block(play=None, parent=None)
    role = 'foo'
    task_include = None
    variable_manager = VariableManager()
    loader = None

    test_role_name = 'foo'
    test_block_vars = {}
    test_block_tags = []
    test_block_collections = []

    def test_get_block_list():
        test_task_include = IncludeRole(block=block, role=role, task_include=task_include)
        test_task_include._role_name = test_role_name
        test_task_include._from_files = test_block_vars
        test_task_include._parent_role = test_block_tags
        test

# Generated at 2022-06-23 07:06:38.444540
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    IncludeRole.load({'role': 'my_role'})
    IncludeRole.load({'role': 'test.test_role'})
    IncludeRole.load({'name': 'test.test_role'})
    IncludeRole.load({'role': 'test-test_role'})
    IncludeRole.load({'name': 'test-test_role'})

    try:
        IncludeRole.load({})
        assert False
    except AnsibleParserError:
        assert True

    try:
        IncludeRole.load({'role': 'test.test_role', 'bad_args': 'bob'})
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-23 07:06:43.694043
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test with name
    data = {"name": "remote.yml",
            "private": False,
            "tasks_from": "remote.yml"}
    ir = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert ir._role_name == "remote.yml"
    assert ir._public == False
    assert ir._from_files['tasks'] == "remote.yml"

    # test with role
    data = {"role": "remote.yml",
            "private": False,
            "tasks_from": "remote.yml"}
    ir = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert ir._role_name

# Generated at 2022-06-23 07:06:55.398472
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role = Role()
    task_include = RoleInclude()

    # Test case 1: parent role is None
    include_role = IncludeRole(block=block, task_include=task_include)
    result = include_role.get_include_params()
    assert result == {}, 'Expected empty dict, but result is %s' % result

    # Test case 2: parent role is not None
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    result = include_role.get_include_params()

# Generated at 2022-06-23 07:07:02.064830
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    include_role = IncludeRole()
    include_role.allow_duplicates = True
    include_role.public = False
    include_role.statically_loaded = False

    new_include_role = include_role.copy()

    # check of type
    assert isinstance(new_include_role, IncludeRole)
    # check by attributes of class
    assert new_include_role.allow_duplicates == True
    assert new_include_role.public == False
    assert new_include_role.statically_loaded == False

# Generated at 2022-06-23 07:07:05.275990
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = "include_role1"
    ir.name = "my_include"

    assert ir.get_name() == "my_include : "


# Generated at 2022-06-23 07:07:16.934045
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    r = Role()
    r.name = "role_name"
    block = Block()
    ir = IncludeRole(block, role=r)
    ir.action = 'role_name'
    ir.name = 'my_name'
    ir.role = 'role_2'
    ir.statically_loaded = True
    ir._from_files = {'keys': 'values'}
    ir._parent_role = "parent_role"
    ir._role_name = "role_name"
    ir._role_path = "/my/path"
    new_me = ir.copy()
    assert new_me.name == 'my_name'
    assert new_me.role == 'role_2'
    assert new_me.statically_loaded == True

# Generated at 2022-06-23 07:07:25.142306
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Unit test for IncludeRole.get_name()
    """
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # test IncludeRole.get_name()
    blocks = []
    r = Role()
    r._role_path = 'role1'
    r._parents = [Role()]
    r._parents[0]._role_path = 'role0'
    t = Task()
    b = Block(r)
    b._parent = r
    t._parent = b
    t._role = r
    t._role._role_path = 'role1'
    blocks.append(t)
    variable_manager = VariableManager()
    variable_manager._

# Generated at 2022-06-23 07:07:34.823724
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # create play
    from ansible.playbook import Play
    p = Play()
    p._loader = MockLoader()
    p.post_validate(p._loader)

    # create base task
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    t = Task()
    t._role = RoleDefinition()

    # include_role
    da = {'include_role': {'name': 'apache'}}
    t = IncludeRole.load(da, task_include=t)

    # TODO: test
    #include_tasks
    da = {'include_tasks': 'apache.yaml'}
    t = IncludeRole.load(da, task_include=t)


# Generated at 2022-06-23 07:07:47.640377
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block()
    role_name = 'my_first_role'
    role_path = '/tmp/' + role_name
    task_include = IncludeRole(block=block, role_name=role_name, role_path=role_path)
    block.children.append(task_include)
    block2 = Block()
    role_name2 = 'my_second_role'
    role_path2 = '/tmp/' + role_name2
    task_include2 = IncludeRole(block=block2, role_name=role_name2, role_path=role_path2)
    block2.children.append(task_include2)
    block.children.append(task_include2)
    v = task_include.get_include_params()

# Generated at 2022-06-23 07:08:00.347748
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = True
    ir._from_files = "from_files"
    ir.name = "name"
    ir.action = "action"
    ir.loop = "loop"
    ir.any_errors_fatal = "any_errors_fatal"
    ir.ignore_errors = "ignore_errors"
    ir.first_available_file = "first_available_file"
    ir.vars = {'key1': 1, 'key2': 2}
    ir.when = "when"
    ir.delegate_to = "delegate_to"
    ir.register = "register"
    ir.run_once = "run_once"
    ir.free_form = "free_form"
    ir.block = Block()

# Generated at 2022-06-23 07:08:05.323059
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    r = Role()
    r.name = "test_role"
    r._role_path = '/test_role'
    ir = IncludeRole(role=r)

    v = ir.get_include_params()
    assert v == {'ansible_parent_role_names': [r.name], 'ansible_parent_role_paths': [r._role_path]}

# Generated at 2022-06-23 07:08:10.816854
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = {'name': 'test_role'}
    name = ir.get_name()
    assert name == 'include_role : test_role'
    ir.name = 'task1'
    name = ir.get_name()
    assert name == 'task1'

# Generated at 2022-06-23 07:08:24.008967
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # set up mocks for
    # load method of class RoleInclude
    # compile method of class Role
    # __init__ method of class Block

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata

    def load(role_name, play=None, variable_manager=None, loader=None, collection_list=None):
        ri = RoleInclude()
        ri.role_name = role_name
        ri.static = False
        ri.role_path = 'dummy'
        return ri

    RoleInclude.load = load


# Generated at 2022-06-23 07:08:35.225395
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    display.verbosity = 3
    display.debug("Test: test_IncludeRole_load")

    # Test for missing name (and missing role)
    data = dict(apply=dict(x='apply_x'), foo='bar')
    try:
        IncludeRole.load(data)
        assert False, "IncludeRole.load did not raise an exception"
    except AnsibleParserError as e:
        assert 'is a required field' in str(e)

    # Test for missing name (and missing role)
    data = dict(name=None, apply=dict(x='apply_x'), foo='bar')
    try:
        IncludeRole.load(data)
        assert False, "IncludeRole.load did not raise an exception"
    except AnsibleParserError as e:
        assert 'is a required field' in str(e)

# Generated at 2022-06-23 07:08:47.057708
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name = 'role_name'
    )
    block = None
    role = None
    task_include = 'not_None'
    variable_manager = None
    loader = None
    ir=IncludeRole.load(data, block=None, role=None, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert ir.name == 'role_name'
    assert ir.action == 'include_role'
    assert ir._role_name == 'role_name'
    assert ir._from_files == {}
    assert ir._parent_role == None
    assert ir._role_path == None


# Generated at 2022-06-23 07:08:56.121206
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # set up test object
    data = dict(
        name='test_role',
        tasks_from='test.yml',
        rolespec_validate=False
    )
    ir = IncludeRole.load(data, block=Block())
    assert ir.name == 'test_role'
    assert ir._from_files['tasks'] == 'test.yml'
    assert ir.rolespec_validate is False
    assert ir._rolespec_validate is False

# Generated at 2022-06-23 07:08:59.396656
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    i1 = IncludeRole()
    assert i1.get_name() == 'include_role : None'

    i1 = IncludeRole()
    i1.name = 'foo'
    assert i1.get_name() == 'foo'


# Generated at 2022-06-23 07:09:05.392012
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.verbosity = 0
    host_vars = dict(ansible_user='root', ansible_connection='local')

    loader = DictDataLoader({
        "main.yml": """
        - meta: clear_host_errors
        - include_role:
            name: some-role
            tasks_from: some-tasks/main.yml
        """,
        "some-tasks/main.yml": """
        - fail:
            msg: "role error"
        """,
    })

    mock_options = Mock()
    mock_options.skip_tags = []
    mock_options.tags = []


# Generated at 2022-06-23 07:09:16.518475
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # This test class is used because mocks are not sufficient:
    #  1) We need to use a class name (that is not a mock) as the first argument of __init__.
    #  2) The properties _parent_role and _role_name are set by the __init__ method, not as actions on the mocks.
    class IncludeRoleWithProperties(IncludeRole):
        def __init__(self, action, name, parent_role_name, role_name):
            # add super class attributes to properly test our class
            self._parent_role = ParentRoleMock(name=parent_role_name)
            self._role_name = role_name
            self.action = action
            self.name = name

    class ParentRoleMock(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-23 07:09:26.570352
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import os
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role, ROLE_SUFFIX
    from ansible.playbook.role.definition import TaskDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    # Create playbook instance and add a play to it
    p = Playbook()
    play_context = PlayContext()
    play_context.CLIARGS = {}
    play_context.set_play

# Generated at 2022-06-23 07:09:39.175124
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    context = PlayContext()
    context._task = IncludeRole()

    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=DictDataLoader({})))

    context.variable_manager = variable_manager


# Generated at 2022-06-23 07:09:49.216783
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.inventory
    import ansible.vars.manager
    import ansible.parsing.dataloader

    pb = ansible.playbook.Playbook()
    # TODO
    # pb._variable_manager = ansible.vars.manager.VariableManager()
    # pb._loader = ansible.parsing.dataloader.DataLoader()
    # pb._loader.set_basedir(pb._basedir)

    # unit test for r_1
    r_1 = Role()
    r_1._role_path = '/roles/role_1'
    r_1._metadata = ansible.playbook.RoleMetadata()
    r_1._metadata.allow_duplicates = True

# Generated at 2022-06-23 07:10:01.422203
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.inventory.manager import InventoryManager

    def _get_loader():
        from ansible.parsing.dataloader import DataLoader
        return DataLoader()

    # pylint: disable=unused-argument
    def _get_variable_manager(loader=None, inventory=None):
        from ansible.vars.manager import VariableManager
        group_vars_path = C.DEFAULT_GROUP_VARS_PATH
        group_vars_plugins = C.DEFAULT_GROUP_VARS_PLUGIN_PATH
        host_vars_path = C.DEFAULT_HOST_VARS_PATH
        host_vars_plugins = C.DEFAULT_HOST_VARS_PLUGIN_PATH


# Generated at 2022-06-23 07:10:09.914470
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.block

    include_role = IncludeRole()
    include_role.args = {
        "name": "_test_role",
    }
    include_role._parent_role = None
    include_role._role_name = "_test_role"
    include_role._role_path = "/_test_role"

    blocks, handler_blocks = include_role.get_block_list()
    assert len(blocks) == 1
    assert isinstance(blocks[0], ansible.playbook.block.Block) == True
    assert blocks[0].role == None

    assert len(handler_blocks) == 0

# Generated at 2022-06-23 07:10:21.987583
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Setup
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    import io

    # Test
    # pylint: disable=protected-access
    # pylint: disable=no-member

    task_1 = Task()
    task_1._parent = Block()
    task_1._role = Role()
    task_1._role._role_name = "test_role_1"
    task_1._role._metadata.rolespec.role_name = task_1._role._role_name
    task_1._role._role_path = "/test/file/path"
    task_1._role._metadata.rolespec.role_path = task_1._

# Generated at 2022-06-23 07:10:34.868701
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role = IncludeRole()
    include_role._parent_role = None
    assert include_role.get_include_params() == {
            'playbook_dir': None,
            'playbook_file': None,
            'playbook_basedir': None,
            'playbook_invocation': None,
            'playbook_name': None,
            'role_name': None,
            'role_path': None,
            'role_metadata': {},
            'ansible_parent_role_names': [],
            'ansible_parent_role_paths': [],
            'role_params': {},
            }

    include_role._parent_role = Role(name='foo', loader=None)

# Generated at 2022-06-23 07:10:41.240655
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    args = {'name': 'apache-config', 'vars_from': '/path/to/file'}
    ir = IncludeRole.load(args, dict(action='include_role', args=args))
    assert ir._role_name == 'apache-config'
    assert ir._from_files == {'vars': 'file'}

# Generated at 2022-06-23 07:10:52.701188
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext

    ir = IncludeRole(task_include=TaskInclude(task_include=TaskInclude(task_include=TaskInclude())))
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir.task_include, TaskInclude)

    block = Block(parent_block=Block(parent_block=Block(parent_block=Block())))
    ir = IncludeRole(block=block)
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir.task_include, TaskInclude)

    role = Role()
    ir = IncludeRole(role=role)
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir.task_include, TaskInclude)

    role = Role()

# Generated at 2022-06-23 07:11:02.471320
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    variable_manager = VariableManager()
    loader = C.AnsibleLoader(None)

# Generated at 2022-06-23 07:11:14.454832
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = None
    ir = IncludeRole(role=role, block=block, task_include=task_include)
    assert ir.get_name() == "include_role : "

    ir = IncludeRole(role=role, block=block, task_include=task_include)
    ir.name = "Test include_role"
    assert ir.get_name() == "Test include_role"

    ir = IncludeRole(role=role, block=block, task_include=task_include)
    ir._role_name = "Test role_name"
    assert ir.get_name() == "include_role : Test role_name"

    ir = IncludeRole(role=role, block=block, task_include=task_include)

# Generated at 2022-06-23 07:11:23.581298
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    Unit test for class IncludeRole
    """
    ir = IncludeRole()
    assert ir
    assert ir.allow_duplicates
    assert not ir.public
    assert ir.rolespec_validate

    ir = IncludeRole(allow_duplicates=False, public=True, rolespec_validate=False)
    assert not ir.allow_duplicates
    assert ir.public
    assert not ir.rolespec_validate

    ir = IncludeRole(allow_duplicates=True, public=False, rolespec_validate=True)
    assert ir.allow_duplicates
    assert not ir.public
    assert ir.rolespec_validate



# Generated at 2022-06-23 07:11:36.279288
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    my_class = IncludeRole
    my_obj = my_class()

    my_class.__dict__['_allow_duplicates'] = FieldAttribute(isa='bool', default=True, private=True)
    my_class.__dict__['_public'] = FieldAttribute(isa='bool', default=False, private=True)
    my_class.__dict__['_rolespec_validate'] = FieldAttribute(isa='bool', default=True)

    my_obj = my_class(block=Block(play=None), role=Role(play=None), task_include=None)
    my_obj._parent_role = Role(play=None)
    my_obj._role_name = 'my_role_name'
    my_obj._role_path = 'my_role_path'
    my_obj._allow_

# Generated at 2022-06-23 07:11:48.799214
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.become import Become

    # Test block inheritance
    block = Block()
    block.vars['ignored'] = 'ignored'
    block2 = Block()
    block2.vars['ignored'] = 'ignored'
    block2._parent = block
    role = Role()
    block.tags = ['tag1']
    block2.tags = ['tag2']
    role._parent = block2
    play = Play()
    play._handlers = [Become()]
    play._handlers[0]._become = True
    play._handlers[0]._become_user = 'root'
    play._handlers[0]._become_method = 'sudo'
   

# Generated at 2022-06-23 07:12:00.025803
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Unit test for method load of class IncludeRole
    """
    # Setup
    args = {  'allow_duplicates': True,
              'apply': {},
              'collection_path': [ '/home/ansible_tester/.ansible/collections/ansible_collections/test/nested_module' ],
              'name': 'test.nested_module',
              'public': False,
              'rolespec_validate': True
            }
    task = IncludeRole()
    IncludeRole = task.load(args)
    # assert
    assert all(item in args for item in task.args if item in ['name', 'collection_path'])

    # Setup
    args = {'role': 'nested_module', 'rolespec_validate': 'False'}
    task = IncludeRole()


# Generated at 2022-06-23 07:12:11.949036
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ''' unit test for IncludeRole load method '''
    # Setup include role
    ir = IncludeRole()
    data = dict(name='new role', apply=dict(a=1, b=2))
    role = 'ansible.builtin.apt'
    ir.load(data, role)

    # Verify result
    assert ir._role_name == data['name']
    assert ir.name == ir._role_name
    assert ir.args == data
    assert ir.apply == data['apply']
    assert ir._from_files == {}
    # validate bad args

# Generated at 2022-06-23 07:12:23.291348
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # pylint: disable=unused-argument
    # pylint: disable=too-many-arguments
    """
    Unit test for method load of class IncludeRole
    """
    # **************************************************
    # Test cases

    # case #1: 'name' is a required field for include_role
    test_data = dict(
        x = dict(
            y = dict(
                include_role = dict(
                    some = 'thing'
                )
            )
        )
    )
    try:
        IncludeRole.load(test_data.get('x').get('y').get('include_role'), task_include=TaskInclude)
    except AnsibleParserError as err:
        if 'name' not in err.message:
            return False
    return True


# Generated at 2022-06-23 07:12:29.732556
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    ir = IncludeRole(block, role)

    ir.name = "X"
    assert ir.get_name() == "X"

    ir.name = None
    ir._role_name = "Y"
    assert ir.get_name() == "include_role : Y"

# Generated at 2022-06-23 07:12:33.658070
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_block = Block(parent_block=None, role=None)
    test_include = IncludeRole(block=test_block, role=None)
    test_include.action = 'include_role'
    test_include._role_name = 'include_role_test'
    assert test_include.get_name() == "include_role : include_role_test"

# Generated at 2022-06-23 07:12:45.472220
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # see http://www.voidspace.org.uk/python/mock/index.html
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    # create the mocks
    my_role = MagicMock(spec=Role)
    my_role.get_name.return_value = 'role_name'
    my_role._role_path = 'role_path'

    # add the test for get_include_params:
    my_incl_role = IncludeRole(role=my_role)

    v = my_incl_role.get_include_params()
    assert(v.get('ansible_role_name') == 'role_name')

# Generated at 2022-06-23 07:12:56.956820
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create necessary objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a play

# Generated at 2022-06-23 07:13:07.312165
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print('Testing get_name')
    assert IncludeRole.load({'tasks': [{'include_role': {'name':'test_name'}}], 'name':'test_play'})
    assert IncludeRole.load({'tasks': [{'include_role': {'role':'test_role'}}], 'name':'test_play'})
    assert IncludeRole.load({'tasks': [{'include_role': {'role':'test_role'}}], 'name':'test_play'})
    assert IncludeRole.load({'tasks': [{'include_role': {'role':'test_role'}}], 'name':'test_play'})


# Generated at 2022-06-23 07:13:10.417139
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = IncludeRole(name='include_role_name', role='include_role_path')
    assert role.get_name() == 'include_role_name'
    role = IncludeRole(role='include_role_path')
    assert role.get_name() == 'include_role : include_role_path'

# Generated at 2022-06-23 07:13:21.195782
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole(block=None, role=None, task_include=None)
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'test_tasks', 'vars': 'test_vars', 'handlers': 'test_handlers', 'defaults': 'test_defaults'}
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'

    new_ir = ir.copy()

    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from_files == ir._from_files
    assert new_ir._role_name == ir._role_name
    assert new_ir._role_path == ir._role_path

# Generated at 2022-06-23 07:13:27.610811
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.utils.display import Display
    d = Display()
    d.verbosity = 0

    blocks = []
    handlers = []
    play = FakePlay()

    ir = IncludeRole()
    ir._role_name = 'geerlingguy.java'
    vars = {}
    loader = FakeLoader()

    (blocks, handlers) = ir.get_block_list(play, vars, loader)


# Generated at 2022-06-23 07:13:38.412536
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    test_IncludeRole_get_include_params
    """

    class RoleMock():
        _role_path = '/path/to/role'

        def __init__(self):
            self.vars = {
                'foo': 'bar',
            }

        def get_role_params(self):
            return {
                'ansible_role_name': 'role_name',
                'ansible_role_path': '/path/to/role',
            }

    block = Block()
    task1 = IncludeRole(block, role=RoleMock())
    task2 = IncludeRole(block, role=RoleMock())

    task1.name = 'task1'
    task2.name = 'task2'

    # Test that the variable is available in task1
    params = task1.get_include

# Generated at 2022-06-23 07:13:47.541367
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # this test must be in the same file as class IncludeRole to patch class
    # IncludeRole.__new__ method because patch decorator does not work with
    # class_decorator
    # pylint: disable=no-member
    IncludeRole.__new__ = lambda cls, *args, **kwargs: super(cls, cls).__new__(cls, *args, **kwargs)
    # pylint: disable=protected-access
    my_include_role = IncludeRole()
    # pylint: disable=no-member
    my_include_role.action = 'include_role'

# Generated at 2022-06-23 07:13:53.371857
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    role._role_name = "test_role_name"
    include_role = IncludeRole(block=block, role=role)
    assert include_role.get_name() == "include_role : test_role_name"


# Generated at 2022-06-23 07:14:00.668172
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Setup
    def values_generator():
        for i in range(0, 2):
            yield i
    role = Role()

    # Test with legacy values
    data = dict(
        name='foo',
        public=True,
        apply=dict(
            a=1,
            b=2,
        ),
        task_includes=[{
            'name': 'blah'
        }]
    )

    ir = IncludeRole.load(data, role=role)
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir._from_files, dict)
    assert ir._from_files['tasks'] == 'main.yml'
    assert ir._from_files['vars'] == 'main.yml'
    assert ir._from_files['handlers'] == 'main.yml'


# Generated at 2022-06-23 07:14:12.777728
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import find_plugin, module_loader
    from ansible.plugins.strategy.linear import LinearStrategy
    from ansible.playbook.helpers import load_list_of_tasks

    test_play1 = '''
---
- hosts: localhost
  gather_facts: no
  vars:
    role_name: test_role_include
  tasks:
  - include_role:
      name: test_role_include
'''


# Generated at 2022-06-23 07:14:23.070819
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Test case 1: read a block of tasks
    # Expected result: a IncludeRole instance is created
    ir1 = IncludeRole.load(dict(include="foo.yml"))
    assert isinstance(ir1, IncludeRole)
    assert ir1._role_name == "foo.yml"

    # Test case 2: read a block of tasks
    # Expected result: a IncludeRole instance is created
    ir2 = IncludeRole.load(dict(include="foo.yml", static=True))
    assert isinstance(ir2, IncludeRole)
    assert ir2._role_name == "foo.yml"

    # Test case 3: read a block of tasks
    # Expected result: a IncludeRole instance is created

# Generated at 2022-06-23 07:14:32.934226
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    obj = IncludeRole()
    obj.statically_loaded = True
    obj._from_files = dict()
    obj._parent_role = ""
    obj._role_name = ""
    obj._role_path = ""
    new_obj = obj.copy(exclude_parent=False, exclude_tasks=False)
    assert new_obj.statically_loaded is True
    assert new_obj._from_files == dict()
    assert new_obj._parent_role == ""
    assert new_obj._role_name == ""
    assert new_obj._role_path == ""


# Generated at 2022-06-23 07:14:43.541175
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = { 'name': 'foobar', 'rolespec_validate': True, 'boom': 'bang' }
    result = IncludeRole.load(data, task_include=True)
    assert result.rolespec_validate is True, "IncludeRole.load() did not handle boolean attributes"
    assert result.rolespec_validate is True, "IncludeRole.load() did not handle boolean attributes"
    assert result._role_name == 'foobar', "IncludeRole.load() did not properly handle name"
    assert result._from_files == {}, "IncludeRole.load() did not handle _from_files"
    assert hasattr(result, 'boom'), "IncludeRole.load() removes invalid options from result"

# Generated at 2022-06-23 07:14:52.824564
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block()
    role = Role()
    role._role_path = 'some_path'
    task_include = TaskInclude()
    my_include_role = IncludeRole(block, role, task_include)
    my_include_role.name = 'subflow'
    my_include_role.args = dict(
        role='some_role',
        collections=['some_collection']
    )

    play_context = PlayContext()

    loader = DataLoader()
    variable_manager

# Generated at 2022-06-23 07:14:57.640281
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block

    block = Block()
    role = Role()
    task_include = TaskInclude()
    task_include.load({'role': 'webserver', 'loop': 'my_hosts', 'loop_control': {'label': 'roles'}})

    include_role = IncludeRole(block, role, task_include)

# Generated at 2022-06-23 07:15:10.078202
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    myloader = DataLoader()
    myinvent = InventoryManager(loader=myloader, sources='localhost')
    context = PlayContext()
    host_list = [inventory_item.name for inventory_item in \
                 myinvent._inventory.get_hosts()]
    host_vars = HostVars(loader=myloader, host_list=host_list)
    variable_manager = VariableManager(loader=myloader, inventory=myinvent)

# Generated at 2022-06-23 07:15:20.045978
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no'
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 07:15:33.326543
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    import json
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext()

    display.verbosity = 3

    task_data = dict(action='include_role')
    include_role = IncludeRole.load(data=task_data, variable_manager=variable_manager, loader=None)
    assert include_role
    assert isinstance(include_role, IncludeRole)
    #print (yaml.safe_dump(include_role.__dict__, default_flow_style=False))


# Generated at 2022-06-23 07:15:43.428094
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    template_task = {
        'action': 'include_role',
        'name': 'foo',
        'apply': {
            'tags': ['bar'],
        },
        'vars_from': 'foo.yml',
        'handlers_from': 'bar.yml',
    }
    role = Role()
    play_context = dict()
    ir = IncludeRole.load(template_task, task_include=None, role=role, variable_manager=None, loader=None)
    ir_copy = ir.copy()
    assert isinstance(ir_copy, IncludeRole)
    assert ir_copy.name == 'foo'
    assert isinstance(ir_copy.apply, dict)
    assert ir_copy.apply['tags'] == ['bar']
    assert ir_copy._from_files == ir._from_

# Generated at 2022-06-23 07:15:46.256902
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task = IncludeRole(block, role)
    task.name = 'test name'
    task._role_name = 'test role name'
    assert task.get_name() == 'test name'

# Generated at 2022-06-23 07:15:52.508460
# Unit test for method load of class IncludeRole