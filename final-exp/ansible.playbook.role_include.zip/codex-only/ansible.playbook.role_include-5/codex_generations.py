

# Generated at 2022-06-23 07:05:48.248928
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole()

# Generated at 2022-06-23 07:05:59.360692
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_data = {
        'include_role': {
            'name': 'test_role',
            'apply': {
                'a': 1,
                'b': 2,
            },
            'x_from': 'xxx',
            'tasks_from': 'tasks/main.yml',
            'vars_from': 'vars/main.yml',
            'defaults_from': 'defaults/main.yml',
            'handlers_from': 'handlers/main.yml',
        }
    }

    my_parent_role = Role()
    my_block = Block()

    ir = IncludeRole.load(my_data, block=my_block, role=my_parent_role, task_include=None)

    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-23 07:06:08.932016
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir._from_files = {'handlers': 'handlers/main.yml'}
    ir.statically_loaded = False
    ir.action = 'include_role'
    ir.name = 'test'
    ir._parent_role = Role()
    ir._parent_role_name = 'test2'
    ir._role_name = 'test3'
    ir._role_path = 'test4'

    new_me = ir.copy()
    assert new_me._from_files == {'handlers': 'handlers/main.yml'}
    assert new_me.statically_loaded == False
    assert new_me.action == 'include_role'
    assert new_me.name == 'test'
    assert new_me._parent_role is None
    assert new_

# Generated at 2022-06-23 07:06:10.349963
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO
    pass

# Generated at 2022-06-23 07:06:15.609349
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir._allow_duplicates is True
    assert ir._public is False
    assert ir._rolespec_validate is True

IncludeRole.register_lookup('role_names', lambda role: role._parent_role.get_role_params()['role_names'])
IncludeRole.register_lookup('role_paths', lambda role: role._parent_role.get_role_params()['role_paths'])

# Generated at 2022-06-23 07:06:27.629962
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    class MockRole(object):
        name = u"test-role"
        def get_role_params(self):
            return dict(role_params=u"foo")
        def get_name(self):
            return self.name

    def get_include_params(role):
        ir = IncludeRole(role=role)
        return ir.get_include_params()

    assert get_include_params(None) == dict()
    assert get_include_params(MockRole()) == dict(role_params=u"foo", ansible_parent_role_names=[u"test-role"], ansible_parent_role_paths=[None])

# Generated at 2022-06-23 07:06:37.679208
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # https://github.com/ansible/ansible/issues/59140
    display.verbosity = 3
    def test_exclude_parent(obj, expected):
        obj_copy = obj.copy(exclude_parent=True)
        assert obj_copy._parent is None
    def test_exclude_tasks(obj, expected):
        obj_copy = obj.copy(exclude_tasks=True)
        assert len(obj_copy.block) == 0

    blk = Block.load(dict(hosts='localhost', tasks=[{'debug': {'msg': 'hello world'}}]), task_include=None, role=None, use_handlers=False)
    ir = IncludeRole.load(dict(name='some_role', public=False), block=blk, role=None, task_include=None)


# Generated at 2022-06-23 07:06:48.382104
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """ Unit test for include_role.load method """

    def _test(test_case, loader):
        data = test_case.get('data')
        include_role = IncludeRole.load(data)

        assert include_role.rolespec_validate == test_case.get('rolespec_validate')
        assert include_role.allow_duplicates == test_case.get('allow_duplicates')

        if test_case.get('exception'):
            return
        assert include_role._role_name == test_case.get('role_name')
        assert include_role._from_files == test_case.get('from_files')
        assert include_role._public == test_case.get('public')

    # Create test cases
    cases = list()

    # no exception, allow_duplicates

# Generated at 2022-06-23 07:06:54.729609
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    args = { 'name': 'test' }
    t = IncludeRole(block=None, role=None, task_include=None)
    t = t.load(args)
    assert t._role_name == 'test'
    assert t._allow_duplicates == True
    assert t._public == False
    assert t._role_path is None


# Generated at 2022-06-23 07:07:01.275277
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    # First, create required objects to pass to constructor of IncludeRole
    # First argument is the data to be loaded using Loader and the second is the VariableManager
    # This is not required, but needed for testing
    task = Task()
    task.action = 'include_role'

# Generated at 2022-06-23 07:07:10.648123
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    inc_role = RoleInclude(role={'name': 'test', 'tasks': [{'name': 'foo', 'include_role': {'role': 'name'}}, {'include_role': {'role': 'test_role'}}]})
    inc_role.name = 'role_name'
    include_obj = {'role': 'name'}
    include_role = RoleInclude(role=include_obj)
    role_name = include_role.get_name()
    assert role_name == 'name', "Role name not matching"

    # testing for IncludeRole class
    for include_obj in inc_role.get_dep_chain():
        assert include_role.copy() is not include_role
        assert include_role.get_name() == 'name', "Role name not matching"

# Generated at 2022-06-23 07:07:11.104926
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole()

# Generated at 2022-06-23 07:07:14.746648
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)

    assert isinstance(ir, IncludeRole)

# Generated at 2022-06-23 07:07:23.453035
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from .. import Play
    from .. import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    myplay = Play.load({
        "name": "test",
        "hosts": ["myhost"],
        "connection": "local",
        "tasks": [{"include_role": {"name": "foo"}}]
    })
    myplay._loader = None
    myplay._variable_manager = None

    foo_role = Role.load({
        'name': 'foo',
        'tasks': [{'name': 'just_testing', 'debug': {
            'msg': '{{myvar}}'}}]},
        play=myplay,
        variable_manager=myplay._variable_manager,
        loader=myplay._loader)



# Generated at 2022-06-23 07:07:24.505617
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ir = IncludeRole()
    assert not ir


# Generated at 2022-06-23 07:07:34.018402
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible_collections.nsbl.test.targets.hosts as hosts

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=hosts.hosts)

    play_source =  dict(
            name = "Ansible Play 1",
            hosts = 'target',
            gather_facts = 'no',
            roles = [
                'test-role-a'
            ]
        )


# Generated at 2022-06-23 07:07:47.509858
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    ir = IncludeRole()

    ir.statically_loaded = True
    ir._from_files = {
        'tasks': 'tasks_file.yml'
    }
    ir._parent_role = Role()
    ir._role_name = 'test_role'
    ir._role_path = '/path/to/test_role'

    new_ir = ir.copy()
    assert new_ir.statically_loaded == ir.statically_loaded
    assert new_ir._from_files == ir._from_files
    assert new_ir._parent_role == ir._parent_role
    assert new_ir._role_name == ir._role_name
    assert new_ir._role_path == ir._role_path


# Generated at 2022-06-23 07:07:54.134139
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = {'role': 'common', 'tasks': [], 'handlers': []}
    d = IncludeRole.load(data, task_include=None)
    assert d.get_name() == 'include_role : common'

# Generated at 2022-06-23 07:08:09.686430
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    '''
    constructor test of class IncludeRole
    '''

# Generated at 2022-06-23 07:08:18.448899
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test case #1: no parent role, no args
    # Expectation: empty args
    loader, inventory, variable_manager = (None,)*3
    blk = Block()
    ir = IncludeRole(block=blk, loader=loader, inventory=inventory, variable_manager=variable_manager)
    ir.args = {}
    v = ir.get_include_params()
    assert v == {}

    # Test case #2: no parent role, with args
    # Expectation: args are returned
    ir.args = {
        'foo': 'bar',
        'frozzle': 'baz',
    }
    v = ir.get_include_params()
    assert v == ir.args

    # Test case #3: parent role, no args
    # Expectation: args are inherited from parent role

# Generated at 2022-06-23 07:08:30.383969
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Constructor of IncludeRole can take no arguments and create an empty object
    ir = IncludeRole()
    assert ir is not None
    assert ir.action == 'include_role'
    assert isinstance(ir.skip_tags, list)
    assert not ir.skip_tags
    assert isinstance(ir.only_tags, list)
    assert not ir.only_tags
    assert ir.when == ''
    assert ir.loop is None
    assert ir.loop_control == {}
    assert ir.register is None
    assert ir._attributes == {}
    assert isinstance(ir.any_errors_fatal, bool)
    assert ir.any_errors_fatal is True
    assert ir.no_log == 'off'
    assert ir.delegate_to is None
    assert ir.delegate_facts is False

# Generated at 2022-06-23 07:08:40.754623
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test when the parent role is not provided
    # This is the use case for the test of a role loaded from import_role
    ir = IncludeRole()
    v = ir.get_include_params()
    assert(v == {})

    # Test when the parent role is provided
    # This is the use case for the test of a role loaded from a play
    parent_role = Role()
    ir = IncludeRole(role=parent_role)
    v = ir.get_include_params()
    assert(v == {}) # No parameter is defined

    # Test when the parent role is provided and has some parameters
    # This is the use case for the test of a role loaded from a play
    vars = {'a': 'b'}
    parent_role = Role(vars=vars)

# Generated at 2022-06-23 07:08:46.459204
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task_include_object = TaskInclude()
    task_include_object.action = "include"
    task_include_object._task = {"name": "test"}
    task_include_object.name = "test"
    assert task_include_object.get_name() == "include : test"

# Generated at 2022-06-23 07:08:59.881332
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.manager import VariableManager
    from ansible.galaxy.collection import CollectionRequirement
    from ansible.collections.ansible.local_collections.all import AllCollectionsRequirement
    from ansible.utils.collection_list import AnsibleCollectionRef
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from collections import namedtuple

    # generate required objects
    block = Block()
    role = Role()
    role.args = {}
    task_include = TaskInclude()
    task_include.args = {}
    variable_manager = VariableManager()
    loader = action_loader.ActionModuleLoader(play_context=PlayContext(), variable_manager=variable_manager)

# Generated at 2022-06-23 07:09:07.487730
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block(site=None)
    role = Role()
    task_include = TaskInclude(block=block)
    inc_role = IncludeRole(block=block, role=role, task_include=task_include)
    inc_role.allow_duplicates = True
    inc_role.rolespec_validate = False
    inc_role.statically_loaded = True
    inc_role._from_files = {"a":"b"}
    inc_role._parent_role = "role"
    inc_role._role_name = "name"
    inc_role._role_path = "path"
    inc_role.args = {'a':'b'}
    new_inc_role = inc_role.copy()
    assert new_inc_role.allow_duplicates == inc_role.allow_du

# Generated at 2022-06-23 07:09:11.718706
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block_ = Block()
    role_ = Role()
    task_include_ = TaskInclude()
    include_role = IncludeRole(block=block_, role=role_, task_include=task_include_)

    assert include_role._parent_role is role_

# Generated at 2022-06-23 07:09:22.599821
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class FakeParentRole:
        def __init__(self):
            self.tags = ['tag1', 'tag2']
            self.post_validate_data = {}
            self._valid_attrs = {}

    task_include = TaskInclude()
    task_include.action = 'include'
    block = Block()
    block.task_vars = {
        'role1': 'role1_data',
        'role2': 'role2_data',
    }

    # name is needed
    data = {'tasks': 'tasks'}
    fake_ir = IncludeRole(block=block, role=FakeParentRole(), task_include=task_include)
    with pytest.raises(AnsibleParserError) as excinfo:
        fake_ir.load(data)

# Generated at 2022-06-23 07:09:35.951832
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''Unit test for method load of class IncludeRole'''
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    class MockAnsibleUnsafeText():
        '''Mock class to imitate AnsibleUnsafeText'''
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value
    class MockVariableManager():
        '''Mock class to imitate VariableManager'''
        def __init__(self):
            self._vars = {}
        def get_vars(self, play=None, task=None):
            return self._vars

# Generated at 2022-06-23 07:09:39.839081
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test data
    data = {
        'include_role': {
            'name': 'role'
        }
    }

    # call method
    block = Block.load(data, task_include=None)
    role = None
    variable_manager = None
    loader = None
    result = IncludeRole.load(block.block, block=block, role=role, variable_manager=variable_manager, loader=loader)

    # test result
    assert len(result.args) == 1
    assert result.name == 'role'

# Generated at 2022-06-23 07:09:49.723793
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host = Host(name="myhost")
    group = Group(name="mygroup")
    group.add_host(host)
    inventory = InventoryManager(
        sources=None,
        sources_list=[],
        groups={"my_all_group": group}
    )
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager = VariableManager(inventory=inventory)

# Generated at 2022-06-23 07:09:59.469695
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_executor import TaskExecutor
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import PY2

    # pylint: disable=unused-argument
    class DummyPlugin(object):
        def __init__(self, play):
            pass

        def get_vars(self, loader, play, task, from_cache=False):
            return dict

# Generated at 2022-06-23 07:10:08.880975
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext

    ir = IncludeRole()
    ir._role_name = "role_name"
    assert ir.get_name() == 'include_role : role_name'

    context = PlayContext()
    context.become = True
    context.become_user = "become_user"

    ir = IncludeRole()
    ir._role_name = "role_name"
    ir._parent = Block()
    ir._parent._role = Role()
    ir._parent._role._context = context
    assert ir.get_name() == 'include_role (as become_user) : role_name'

# Generated at 2022-06-23 07:10:13.819289
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.vars

    include = IncludeRole(name="test include_role")
    include._role_name = "test role"

    # mimic the result of RoleInclude.load()
    role_include = {
        "name": "test role",
        "path": "/path/to/test role",
        "collections": ["test collection", "another test collection"],
    }

    # mimic the result of Role.load()
    role = ansible.playbook.Role()
    role._role_name = "test role"
    role._role_path = "/path/to/test role"
    role._collections = ["test collection", "another test collection"]

    blocks, handlers = include.get_block_list(role=role)

    assert len(blocks) == 1

# Generated at 2022-06-23 07:10:24.834958
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    data = parse_yaml("- name: test_role")
    ir = IncludeRole.load(data)
    assert ir._role_name == 'test_role'
    assert ir.action == 'include_role'
    assert not ir.statically_loaded

    # name is needed or use role as alias, test case for role
    data = parse_yaml("- role: test_role")
    ir = IncludeRole.load(data)
    assert ir._role_name == 'test_role'
    assert ir.action == 'include_role'
    assert not ir.statically_loaded

    # raise error if both name and role are not specified
    data = parse_yaml("- test_role")

# Generated at 2022-06-23 07:10:28.405134
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole()
    task.action = 'test'
    task._role_name = 'name'
    assert task.get_name() == 'test : name'


# Generated at 2022-06-23 07:10:34.031411
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    fake_block = Block()
    fake_role = Role()

    # (1) test invalid option
    data = dict(
        name='test_ansible_action_module',
        action='include_role',
        play=dict(
            roles=dict(
                test_ansible_role=dict(
                    meta=dict(
                        foo="test_foo",
                        bar="test_bar",
                    )
                )
            )
        ),
        variable_manager='test_variable_manager',
        loader='test_loader',
        invalidoption='test_invalidoption',
    )
    with pytest.raises(AnsibleParserError) as excinfo:
        IncludeRole.load(data, block=fake_block, role=fake_role)

# Generated at 2022-06-23 07:10:46.087301
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test for when no name is provided and action is import_tasks
    # Tests tasks/include_role.yml and tasks/no_name_import_tasks.yml
    block1 = Block()
    includeRole1 = IncludeRole(block=block1, task_include={"action": "import_tasks"})
    assert includeRole1.get_name() == "import_tasks : None"
    assert includeRole1.action == "import_tasks"
    # Test for when name is provided and action is import_tasks
    # Tests tasks/include_role.yml and tasks/name_import_tasks.yml
    block2 = Block()
    includeRole2 = IncludeRole(block=block2, task_include={"action": "import_tasks", "name": "test"})
    assert includeRole2

# Generated at 2022-06-23 07:10:51.682452
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = 'test/get_name'
    action = 'action'
    block = Block()
    include_role = IncludeRole(block=block, role=role)
    include_role.action = action
    include_role._role_name = role
    assert include_role.get_name() == '%s : %s' % (action, role)

# Generated at 2022-06-23 07:10:54.032667
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-23 07:11:00.441693
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    This test validate that the copy of IncludeRole object
    is identical (= the same object) of the original one.
    """
    sut = IncludeRole()
    sut.apply = dict(x=1, y=2)
    sut._from_files = dict(a=1, b=2)

    actual = sut.copy()
    assert actual.apply == sut.apply
    assert actual._from_files == sut._from_files

# Generated at 2022-06-23 07:11:02.226596
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-23 07:11:13.483190
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.verbosity = 4

    print("test_IncludeRole_get_block_list")
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.role_include as role_include
    import ansible.template as template
    import ansible.vars as vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play = {
        'hosts': 'localhost',
        'gather_facts': False,
        'roles': [],
        'tasks': [],
        'post_tasks': [],
        'handlers': [],
    }


# Generated at 2022-06-23 07:11:23.784868
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    variable_manager = VariableManager()
    play = Play.load(dict(
        name='test',
        hosts=['localhost'],
        roles=[
            'first_role'
        ]),
        variable_manager=variable_manager, loader=loader,
    )
    block = Block()
    role = Role()

    role.get_vars.return_value = { 'ansible_test': 2 }
    role.block = Block()
    role.block._role = role
    role.get_name.return_value = 'ParentRole'

    includerole = IncludeRole(block=block, role=role)
    includer

# Generated at 2022-06-23 07:11:36.484236
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Check the load method without private attribute '_needs_static_load'
    data = dict(
        include_role='common',
        name='common',
        allow_duplicates=True,
        public=False,
        rolespec_validate=True
    )

    obj = IncludeRole.load(data)
    assert obj.args == data
    assert obj.name == 'common'
    assert obj.allow_duplicates == True
    assert obj._public == False
    assert obj.rolespec_validate == True

    # Check the load method with private attribute '_needs_static_load'

# Generated at 2022-06-23 07:11:48.861825
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import ROLE_CACHE

    ROLE_CACHE.clear()
    ir = IncludeRole.load({'include_role': {'name': 'role0', 'allow_duplicates': True, 'public': True, 'rolespec_validate': True}})
    assert ir._allow_duplicates is True
    assert ir._public is True
    assert ir.rolespec_validate is True

    new_ir = ir.copy()
    assert new_ir._allow_duplicates is True
    assert new_ir._public is True
    assert new_ir.rolespec_validate is True

    # Verify that the parent attribute is not set
    assert new_ir._parent is None

    # Verify that the tasks attribute is not set
    assert new_ir._tasks is None

# Generated at 2022-06-23 07:12:00.060856
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()

    data = dict(role='b')

    include_role = IncludeRole.load(data=data, variable_manager=variable_manager, loader=None)

    assert include_role._role_name == 'b'
    assert include_role._from_files == {}
    assert include_role._parent_role == None
    assert include_role._role_path is None
    assert include_role.name == 'include_role : b'
    assert include_role.args == {"role": "b"}
    assert include_role.action == 'include_role'
    assert include_role._valid_attrs['ignore_errors'] is False
    assert include

# Generated at 2022-06-23 07:12:09.175345
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    Test that IncludeRole.get_name() returns the delegated name if it is specified
    and the expected output when it isn't.
    """
    name = 'TestRole'
    # Test with a name.
    ir = IncludeRole()
    ir.name = name
    assert ir.get_name() == name, "Failed to return the delegated name."
    # Test without a name.
    ir = IncludeRole()
    ir.action = 'include'
    ir._role_name = 'TestRole'
    assert ir.get_name() == 'include : TestRole', "Failed to return the expected output."

# Generated at 2022-06-23 07:12:15.049024
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    ir = IncludeRole()

    ir.action = 'include_role'
    ir.name = 'my_name'
    assert ir.get_name() == 'my_name'

    ir.name = None
    ir.action = 'include_role'
    ir.args['name'] = 'role'
    assert ir.get_name() == 'include_role : role'


# Generated at 2022-06-23 07:12:25.218513
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import find_plugin
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    loader = DataLoader()
    var_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,127.0.0.1,'])
    play_context = PlayContext()

# Generated at 2022-06-23 07:12:37.658110
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    role_include = {
        'block': None,
        'action': 'include_role',
        'args': {
            'name': 'name',
            'role': 'role',
            'tasks_from': 'tasks_from',
            'vars_from': 'vars_from',
            'defaults_from': 'defaults_from',
            'handlers_from': 'handlers_from',
            'apply': {},
            'public': True,
            'allow_duplicates': True,
            'rolespec_validate': True,
            'invalid_key': 'invalid_key',
        }
    }
    obj = {'include': role_include}
    role

# Generated at 2022-06-23 07:12:47.109462
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import json
    import ansible.playbook.role.definition
    from ansible.playbook.role.definition import RoleDefinition
    import tempfile
    import ansible.utils.vars

    class FakeVars(object):
        pass

    class FakeRole(object):
        def __init__(self):
            self.get_role_params = lambda: {'test_role_params_key': 'test_role_params_value'}
            self.get_name = lambda: 'role_name_A'

    def load_roles_admin_principal(role, play, variable_manager=None, loader=None, collection_list=None):
        # returns: RoleInclude
        ri = RoleInclude(role=role)
        return ri


# Generated at 2022-06-23 07:12:55.370086
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole

    role = RoleDefinition()
    block = Block(parent_block=role)
    data = dict(action='include_role', name='test_role')

    task_include = IncludeRole(block=block, role=role)
    task_include.load_data(data)

    assert task_include.get_name() == "include_role : test_role"

# Generated at 2022-06-23 07:13:02.590831
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(block=Block())
    # set needed properties to simulate a dynamic include_role
    ir._role_name = "test_include_role"
    ir._role_path = "/dummy/path/to/role"
    # call the method
    name = ir.get_name()

    assert name == "tasks/main.yml : test_include_role"


# Generated at 2022-06-23 07:13:09.267314
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # set up class and objects
    test_block = Block()
    test_role = Role()
    test_TaskInclude = TaskInclude()

    # set up inputs and test object
    test_name = "test_name"
    test_task = IncludeRole(block=test_block, role=test_role, task_include=test_TaskInclude)
    test_task._role_name = test_name

    # get name
    name = test_task.get_name()

    # check
    assert name == test_name



# Generated at 2022-06-23 07:13:14.055866
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = IncludeRole()
    task._role_name = 'test_role_name'
    assert task.get_name() == "include_role : test_role_name"

# Generated at 2022-06-23 07:13:17.860993
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import pytest
    blocked = Block()
    t = IncludeRole(block=blocked)

    assert t.get_name() == "meta: include_role"

    t.name = "foo"
    assert t.get_name() == "foo"

# Generated at 2022-06-23 07:13:29.125082
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
	from ansible.playbook.role import Role
	from ansible.module_utils.common._collections_compat import MutableMapping
	from ansible.template import Templar
	from ansible.vars.manager import VariableManager
	from ansible.module_utils._text import to_text
	from ansible.parsing.dataloader import DataLoader

	display = Display()
	# Create a mock role
	rolename = "base"
	rolepath = "/roles/base"
	v = VariableManager()
	loader = DataLoader()
	role = Role.load(rolename, role_path=rolepath, variable_manager=v, loader=loader,
					allow_duplicates=True, role_name=rolename, collection_list=[])
	role._metadata.description="description"
	

# Generated at 2022-06-23 07:13:35.992220
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """ Unit test for method get_include_params of class IncludeRole """
    # Create a simple Role instance to be the parent role
    role_name = "my_test_role"
    role_path = "my_test_role"
    role_vars = dict()
    role_dep_attrs = dict()
    role_metadata = dict()

    parent_role = Role(name=role_name, role_path=role_path, vars=role_vars, dep_attrs=role_dep_attrs, metadata=role_metadata)

    # The tests are run in this order:
    # 1) Method get_include_params does not return any parameter
    # 2) Method get_include_params returns the parameters of the parent role
    # 3) Method get_include_params returns the number of the parent role

    # Test 1

# Generated at 2022-06-23 07:13:36.739225
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:13:46.488799
# Unit test for method copy of class IncludeRole

# Generated at 2022-06-23 07:13:57.558159
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    class Foo(object):
        def __init__(self):
            self._attrs = dict()

        def __setattr__(self, name, value):
            # set attribute normally if name is not '_attrs'
            if name != "_attrs":
                object.__setattr__(self, name, value)
            # set attribute for _attrs
            else:
                object.__setattr__(self, name, value)

        def update_vars(self, update_dict):
            self._attrs.update(update_dict)

        def __getitem__(self, name):
            return getattr(self, name)

        def get_name(self):
            return self._attrs.get('name')


# Generated at 2022-06-23 07:14:10.331064
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Test Constructor
    ir = IncludeRole()
    # Test _allow_duplicates
    ir._allow_duplicates = False
    assert not ir._allow_duplicates
    # Test _public
    ir._public = False
    assert not ir._public
    # Test _rolespec_validate
    ir._rolespec_validate = True
    assert ir._rolespec_validate
    # Test _from_files
    ir._from_files = {'vars': "test"}
    assert ir._from_files.get('vars') == 'test'
    # Test _parent_role
    role = Role()
    role._role_name = 'test'
    ir._parent_role = role
    assert ir._parent_role._role_name == 'test'
    # Test _role_name


# Generated at 2022-06-23 07:14:20.411840
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
   ir = IncludeRole(role_name="foo")
   ir._role_name = "foo"
   ir.name = "foo"
   ir._parent_role = "foo"
   ir.statically_loaded = "foo"

   new_ir = ir.copy(exclude_parent=True)
   assert ir._role_name == new_ir._role_name
   assert ir.name == new_ir.name
   assert ir.statically_loaded == new_ir.statically_loaded

   new_ir = ir.copy(exclude_tasks=True)
   assert not new_ir.tasks
   assert ir._role_name == new_ir._role_name
   assert ir.name == new_ir.name
   assert ir._parent_role == new_ir._parent_role
   assert ir.statically_loaded

# Generated at 2022-06-23 07:14:32.828943
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = None

    module1 = 'test1.yml'
    name1 = 'test_1'
    include_role1 = IncludeRole()
    include_role1.action = 'test'
    include_role1.statically_loaded = True
    include_role1._from_files = {'tasks': 'test_1.yml'}
    include_role1._parent_role = Role()
    include_role1._role_name = 'test1'
    include_role1._role_path = 'test1'
    include_role1.name = 'test_1'

    var_manager = VariableManager()
    loader

# Generated at 2022-06-23 07:14:34.805475
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'Test'
    assert ir.get_name() == 'Test'


# Generated at 2022-06-23 07:14:45.727405
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # FIXME: the current test framework fails to load modules properly
    #        so we cannot import IncludeRole here
    #from ansible.playbook.role.include import IncludeRole

    include_role_data = dict(
        name=dict(str="my_role"),
        tasks_from=dict(str="main.yml"),
        public=dict(bool=True),
        apply=dict(
            dict=dict(
                x=dict(int=1)
            )
        )
    )

    with pytest.raises(AnsibleParserError) as excinfo:
        IncludeRole.load(include_role_data, role=None, task_include=None)
    assert "Invalid options for include_role: my_role" in str(excinfo.value)

# Generated at 2022-06-23 07:14:57.033582
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager, ensure_type
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=C.DEFAULT_LOADERS, sources=['localhost,'])
    playbook = Playbook.load('test_include_role.yml', variable_manager=VariableManager(loader=C.DEFAULT_LOADERS, inventory=inventory), loader=C.DEFAULT_LOADERS)
    play = playbook.get_plays()[0]
    # Because of the way the inventory manager works

# Generated at 2022-06-23 07:15:03.499811
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    display.display("test_IncludeRole")

    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block=block, role=role, task_include=task_include)

    display.display(include_role)

    return include_role


# Generated at 2022-06-23 07:15:15.255930
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    pb = Playbook.load("../../../test/units/parsing/parseable/include_role/playbook.yml", variable_manager=VariableManager(), loader=None)
    p = Play.load(pb.data[0], pb.variable_manager, pb.loader)
    task = p.get_tasks()[0].copy()
    task._role = Role.load("../../../test/units/parsing/parseable/include_role/roles/role_a", pb.variable_manager, pb.loader)
    pb

# Generated at 2022-06-23 07:15:15.881758
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:15:19.258392
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    context = PlayContext()
    block = Block()
    role = Role()
    role.name = 'test'
    IncludeRole(block=block, role=role)

# Generated at 2022-06-23 07:15:25.215793
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.verbosity = 3

    # no parent
    test_ir = IncludeRole(role=Role('name1','path1'), block=Block.load(dict(tasks=[{'debug': dict(msg="TESTTASK1")}]), 'hosts', 'name'))

    # no parent
    assert 'ansible_parent_role_names' not in test_ir.get_include_params()
    assert 'ansible_parent_role_paths' not in test_ir.get_include_params()
    assert 'ansible_role_name' not in test_ir.get_include_params()
    assert 'ansible_role_path' not in test_ir.get_include_params()

    # parent

# Generated at 2022-06-23 07:15:37.605976
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins.loader import action_loader

    from_file_data = '''
- hosts: all
  tasks:
    - name: test task
      local_action:
        module: ping
    - name: include role
      include_role:
        name: role_name
        apply:
          tags:
            - role_name
          when:
            - role_name is defined
            - role_name
      tags: [test_tag]
    '''
    data = action_loader.load('include_role', None, from_file_data)

    validate_name = 'role_name'
    validate = data.get_dep_chain()[1]

# Generated at 2022-06-23 07:15:42.635093
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    try:
        ir = IncludeRole()
        ir.action = 'include_role'
        ir._role_name = 'some_role'
        assert ir.get_name() == "%s : %s" % (ir.action, ir._role_name)
        ir.name = 'some_name'
        assert ir.get_name() == ir.name
    except AssertionError as e:
        print(e)



# Generated at 2022-06-23 07:15:50.439405
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            role=dict(type='str'),
            tasks_from=dict(type='str'),
            vars_from=dict(type='str'),
            defaults_from=dict(type='str'),
            handlers_from=dict(type='str'),
            apply=dict(type='dict'),
            public=dict(type='bool'),
            allow_duplicates=dict(type='bool'),
            rolespec_validate=dict(type='bool'),
        ),
        supports_check_mode=True
    )

    task_args = {}
    role_args = {}
    role_args['name'] = 'myrole'
    role_args['role'] = 'myrole'
    role_args['allow_duplicates']