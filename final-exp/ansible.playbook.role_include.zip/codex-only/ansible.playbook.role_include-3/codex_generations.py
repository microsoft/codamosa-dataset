

# Generated at 2022-06-23 07:05:54.949459
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.clean import module_response_deepcopy

    r = RoleDefinition()
    r.name = 'test1'
    r.static_vars = {'test_static_var' : 'test value'}
    r._role_path = '/path/to/role'

    ir = IncludeRole(role = r)
    ir.vars = {'test_include_var' : 'test value'}
    ir.args = {'name': 'test2', 'allow_duplicates': False, 'apply': {'test_apply_var': 'test value'}}


# Generated at 2022-06-23 07:06:05.504107
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import sys
    import tempfile
    import shutil
    import yaml

    # test case 1: normal case
    # tmp

# Generated at 2022-06-23 07:06:11.719481
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    ex_opts = dict(
        ignore_errors=True,
        verbosity=3,
        start_at_task='/path/to/start/task',
    )

# Generated at 2022-06-23 07:06:19.778518
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    task = IncludeRole()
    task.from_list = ['from_list']
    task.from_file = 'from_file'
    task.from_action = 'from_action'
    task.from_task = 'from_task'
    task._from_files = {'from_file': 'from_file'}
    task._role_name = 'role_name'
    task.statically_loaded = True
    new_task = task.copy()
    assert new_task.from_list == task.from_list
    assert new_task.from_file == task.from_file
    assert new_task.from_action == task.from_action
    assert new_task.from_task == task.from_task
    assert new_task._from_files == task._from_files
    assert new_task._role

# Generated at 2022-06-23 07:06:29.817215
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    my_play = dict(
        name="play 1",
        hosts="all",
        roles=["role1", "role2"],
        tasks=[dict(
            include_role=dict(
                name="role1",
                tasks_from="task_file_in_role1",
            )
        )],
    )
    my_loader = None
    my_variable_manager = None

    b = Block.load(my_play, my_loader, my_variable_manager, None)
    role1 = b.block.get_roles()[0]
    role2 = b.block.get_roles()[1]

# Generated at 2022-06-23 07:06:38.676247
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    '''
    Test method copy for class IncludeRole
    '''
    r = Role()
    r.vars = dict(foo='bar')
    a = Block()
    t = IncludeRole(a, role=r)
    t.vars.update(dict(g1='v1', g2='v2'))
    t.action = 'do_something'

    y = t.copy()
    # make sure only the copied object is modified when updating values
    y.vars.update(dict(g1='v3', g4='v4'))
    assert y.vars['g1'] == 'v3'
    assert y.vars['g2'] == 'v2'
    assert y.vars['g4'] == 'v4'
    assert t.vars['g1'] == 'v1'

# Generated at 2022-06-23 07:06:44.592277
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    block = Block()
    role = Role()
    task_include = TaskInclude(block=block, role=role)

    ir = IncludeRole(block=block, role=role, task_include=task_include)
    assert isinstance(ir.allow_duplicates, bool)
    assert isinstance(ir.public, bool)
    assert isinstance(ir.rolespec_validate, bool)

# Generated at 2022-06-23 07:06:56.424388
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create an IncludeRole object
    ir = IncludeRole()
    
    # Create a mock Role object
    role = Role()
    role._role_params = dict()
    role.name = 'Test_Role'
    role._role_path = 'Test_Path'
    
    # Use the mock role as the parent role of the IncludeRole instance
    ir._parent_role = role
    
    # Check that the method get_include_params returns the expected value
    assert ir.get_include_params() == {
        'ansible_role_name': 'Test_Role',
        'ansible_role_path': 'Test_Path',
        'ansible_parent_role_names': ['Test_Role'],
        'ansible_parent_role_paths': ['Test_Path']
    }

# Generated at 2022-06-23 07:07:01.717918
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    ir = IncludeRole(block, role, task_include)
    assert type(ir) == IncludeRole
    assert ir._parent_role == role
    assert ir._role_name == None
    assert ir._role_path == None
    assert ir._allow_duplicates == True
    assert ir._public == False
    assert ir._rolespec_validate == True
    assert ir.allow_duplicates == True
    assert ir.apply == {}
    assert ir.public == False
    assert ir.rolespec_validate == True

    ir2 = IncludeRole(block, role)
    assert type(ir2) == IncludeRole
    assert ir2._parent_role == role
    assert ir2._role_name == None
    assert ir

# Generated at 2022-06-23 07:07:08.642996
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()

    # Case 1: name is not None
    include_role.name = "Test name"
    include_role._role_name = "Test role_name"
    expected_result = "Test name"
    result = include_role.get_name()
    assert result == expected_result

    # Case 2: name is None
    include_role.name = None
    expected_result = "include_role : Test role_name"
    result = include_role.get_name()
    assert result == expected_result

# Generated at 2022-06-23 07:07:14.319529
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.action = 'include_role'
    ir.args = {'role': 'myrole'}
    ir._role_name = 'myrole'
    assert "include_role : myrole" == ir.get_name()
    ir.name = 'myname'
    assert "myname" == ir.get_name()

# Generated at 2022-06-23 07:07:21.763207
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block(parent=None)
    role = Role()

    #run constructor
    include_role = IncludeRole(block=block, role=role)

    #assert objects
    assert isinstance(include_role, IncludeRole)
    assert isinstance(include_role._allow_duplicates, FieldAttribute)
    assert isinstance(include_role._public, FieldAttribute)
    assert isinstance(include_role._rolespec_validate, FieldAttribute)
    assert include_role._from_files == {}
    assert role == include_role._parent_role
    assert include_role._role_name is None
    assert include_role._role_path is None

# Generated at 2022-06-23 07:07:32.216719
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    import sys
    import unittest
    import yaml
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-23 07:07:42.831708
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    b = Block().load({'name': 'test_block', 'hosts': 'localhost'}, play=None)
    assert IncludeRole(block=b).get_name() == '- include_role : '
    assert IncludeRole(block=b, role='role_name').get_name() == '- include_role : '
    assert IncludeRole(block=b, name='test_name').get_name() == '- include_role : test_name'
    assert IncludeRole(block=b, role='role_name', name='test_name').get_name() == '- include_role : test_name'

# Generated at 2022-06-23 07:07:56.517443
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # test ./hacking/tests/units/test_playbook_tasks.py:test_include_role
    with open("./hacking/tests/units/files/include_tasks.yml", "r") as stream:
        data = yaml.load(stream)

    from_files = {'defaults': 'vars.yml', 'handlers': 'handlers/main.yml', 'tasks': 'tasks/main.yml', 'vars': 'vars/main.yml'}
    include = IncludeRole(role=Role(), role_name="foobar", from_files=from_files)
    block, handlers = include.get_block_list()
    assert type(block) is list
    assert len(block) == 1
    assert type(block[0]) is Block

    # test ./

# Generated at 2022-06-23 07:07:57.084941
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
  pass

# Generated at 2022-06-23 07:08:00.664576
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    pass

# Generated at 2022-06-23 07:08:04.852593
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = 'roleone'
    ir.action = 'include_role'
    assert ir.get_name() == "include_role : roleone"

# Generated at 2022-06-23 07:08:11.207066
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test_name'
    assert ir.get_name() == 'test_name', 'test_IncludeRole_get_name failed'
    ir._role_name = 'test_role'
    ir.action = 'test_action'
    assert ir.get_name() == 'test_action : test_role', 'test_IncludeRole_get_name failed'

# Generated at 2022-06-23 07:08:19.254023
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import os
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    #Create an include role task
    data = dict(
        role = 'test_role',
        vars = {'testVar1': 'val1', 'testVar2': 'val2'},
        tasks = [
            dict(name="task1", action=dict(module="test_module", args="test_arg")),
            dict(name="task2", action=dict(module="test_module", args="test_arg"))
        ]
    )

    #Create a parent role
    role = Role()
    role.name = 'test_role'
    role.v

# Generated at 2022-06-23 07:08:20.220328
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert IncludeRole(None, None).get_include_params() == {'ansible_current_role_names': []}

# Generated at 2022-06-23 07:08:32.510803
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.parsing.yaml.loader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    class MyLoader(object):
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager

        def get_basedir(self):
            return '.'

    # define a data structure which will cause load to fail
    data = {
        'include_role': 'bad value'
    }

    # instantiate the loader
    vars_manager = VariableManager()
    lm = MyLoader(vars_manager)

    # parse the data, expecting an error as the pre-condition is false

# Generated at 2022-06-23 07:08:41.783802
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ''' unit test for IncludeRole object '''

    # test with invalid data (no action)
    invalid_data = {
        'include_tasks': {'nom': 'nom'}
    }
    try:
        IncludeRole.load(invalid_data)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Should have raised AnsibleParserError with invalid data')

    # test with valid data
    valid_data = {
        'include_role': {
            'name': 'myrole'
        }
    }
    ir = IncludeRole.load(valid_data)
    assert ir.action == 'include_role'
    assert ir._role_name == 'myrole'
    assert 'name' in ir.args

    # test with assign args

# Generated at 2022-06-23 07:08:51.628984
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Given a source Includerole
    # we retrieve a collection of block
    source = {'name': 'test_role', 'apply': {'a': 1}, 'vars_from': 'file'}
    include_role = IncludeRole.load(source, block)
    block_list, handler_list = include_role.get_block_list(play=None, variable_manager=variable_manager, loader=loader)

    # Then the collection of block is not null
    assert(block_list != None)

# Generated at 2022-06-23 07:09:02.237295
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class SimpleRole():
        def get_name(self):
            return "SimpleRole_get_name"
        def get_role_params(self):
            return { 'RoleParamsKey1': 1, 'RoleParamsKey2': 2 }

    class SimpleBlock():
        def get_name(self):
            return "test_get_name"
        def get_vars(self):
            return { 'BlockParamsKey1': 101, 'BlockParamsKey2': 102 }

    role = SimpleRole()
    block = SimpleBlock()
    ir = IncludeRole(block=block, role=role)

    v = ir.get_include_params()

# Generated at 2022-06-23 07:09:14.299765
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    task_block = Block()
    ir = IncludeRole(block=task_block)
    ir._role_name = 'test_role'
    ir._from_files['vars'] = 'vars_file'
    ir._from_files['tasks'] = 'tasks_file'
    ir._from_files['defaults'] = 'defaults_file'
    ir._from_files['handlers'] = 'handlers_file'
    variables = dict()
    ri = RoleInclude.load(ir._role_name, play=None, variable_manager=None, loader=None, collection_list=None)
    actual_role = Role.load(ri, play=None, parent_role=None, from_files=ir._from_files, from_include=True, validate=True)
    task_block._parent = ir

# Generated at 2022-06-23 07:09:25.747479
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    block = Block()

    play = Play()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(loader.load_inventory('tests/unit/inventory'))
    variable_manager.extra_vars = {'ANSIBLE_CONFIG':'ansible.cfg'}

    ir = IncludeRole()
    ir._role_name = 'test_role'
    ir._parent_role = None
    ir._from_files = {}

    (blocks, handlers) = ir.get_block_list(play, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 07:09:37.259217
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # IncludeRole class doesn't have this attribute
    import ansible.utils.unsafe_proxy
    ansible.utils.unsafe_proxy.AnsibleUnsafeText = lambda x: x

    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.play_context as play_context
    import ansible.playbook.play as play
    from ansible.vars.clean import module_response_deepcopy

    test_action = 'include_role'
    test_name = 'test_include_role'
    test_args = 'foobar'
    test_play_context = play_context.PlayContext()
    test_loader = plugin_loader.ActionModuleLoader(play_context=test_play_context)
    test_task = Block()


# Generated at 2022-06-23 07:09:44.550651
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Create a Block
    block = Block()

    # Create a parent Role
    parent_role = Role()

    # Create a TaskInclude
    task_include = TaskInclude()

    # Create the IncludeRole Object
    ir = IncludeRole(block=block, role=parent_role, task_include=task_include)

    # Populate the variables
    ir.statically_loaded = True
    ir._from_files = {"var1": "val1", "var2": "val2"}
    ir._parent_role = parent_role
    ir._role_name = "role1"
    ir._role_path = "role_path"

    # Call the copy method
    new_ir = ir.copy()

    # Check the type of new_ir
    assert(isinstance(new_ir, IncludeRole))

    # Check

# Generated at 2022-06-23 07:09:55.215908
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block1 = Block()
    role1 = Role()

    ir_test = IncludeRole(block1, role1)
    assert ir_test.block == block1
    assert ir_test.role == role1
    assert ir_test.task_include is None
    assert ir_test._allow_duplicates
    assert not ir_test._public
    assert ir_test._rolespec_validate
    assert ir_test._from_files == {}
    assert ir_test._parent_role == role1
    assert ir_test._role_name is None
    assert ir_test._role_path is None
    print('Unit test for Constructor of class IncludeRole passed.')


# Generated at 2022-06-23 07:09:58.024179
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    includeRole = IncludeRole()
    includeRole._role_name = "test_role"
    assert includeRole.get_name() == "include_role : test_role"

# Generated at 2022-06-23 07:10:09.788007
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    data = {
        "name": "apache",
        "tasks_from": "../tasks/main.yml",
        "vars_from": "../vars/main.yml",
        "handlers_from": "../handlers/main.yml",
        "defaults_from": "../defaults/main.yml",
        "apply": {
            "tags": "apache"
        }
    }

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()

# Generated at 2022-06-23 07:10:15.699917
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    role_include = IncludeRole(block, role, task_include=task_include)
    role_include.action = "bla action"
    role_include._role_name = "role name"
    assert role_include.get_name() == "bla action : role name"



# Generated at 2022-06-23 07:10:21.613075
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import unittest
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    suite.addTest(IncludeRoleTestCase('test_get_name'))
    unittest.TextTestRunner().run(suite)


# Generated at 2022-06-23 07:10:34.352106
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Setup data needed for test
    role = Role()
    role._role_name = 'test_role'
    block = Block()

    # Test construction of object IncludeRole
    include_role = IncludeRole(block=block, role=role)
    include_role.statically_loaded = 'test_statically_loaded'
    include_role._from_files = 'test_from_files'
    include_role._parent_role = 'test_parent_role'
    include_role._role_name = 'test_role_name'
    include_role._role_path = 'test_role_path'

    # Test copy method of object IncludeRole
    new_include_role = include_role.copy()

    assert new_include_role.statically_loaded == include_role.statically_loaded
    assert new_include_role

# Generated at 2022-06-23 07:10:46.217857
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.collections import defaultdict
    from ansible.playbook.included_file import IncludedFile



# Generated at 2022-06-23 07:10:52.260066
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.args = {'name': 'test_name'}
    assert ir.get_name() == 'include_role : test_name'
    ir.action = 'test_action'
    ir.args = {'role': 'test_role'}
    assert ir.get_name() == 'test_action : test_role'


# Generated at 2022-06-23 07:11:03.575455
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    ir = IncludeRole(role=None)

    # Excluding tasks when copying
    ir_copy = ir.copy(exclude_tasks=True)

    assert ir_copy.block is None
    assert ir_copy.role is None
    assert ir_copy.task_include is None
    assert ir_copy.play is None
    assert ir_copy.apply is None
    assert ir_copy.loop is None
    assert ir_copy.loop_with is None
    assert ir_copy.until is None
    assert ir_copy.tags == []
    assert ir_copy.when is None
    assert ir_copy.when_file is None
    assert ir_copy.when_items is None
    assert ir_copy.when_first_found is None
    assert ir_copy.when_last_found is None

# Generated at 2022-06-23 07:11:08.989817
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Define a mock class for the AnsibleModule to create an instance
    class ModuleMock(object):

        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')


    # Create an instance for the test
    module = ModuleMock(
        role='my-role',
        from_files='my-role/tasks/main.yml',
        validate=False,
        allow_duplicates=False,
        public=False,
        static=False,
        apply=dict()
    )

    # Create an instance of IncludeRole
    include_role = IncludeRole()

    # Load
    include

# Generated at 2022-06-23 07:11:20.028342
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display = Display()
    display.verbosity = 4
    playbook = u'''
- name: test load role
  hosts: all
  gather_facts: no
  tasks:
    - include_role:
        name: include_role_test_role
'''
    print(playbook)

    # Create a temporary directory to test
    import tempfile
    tmp_dir = tempfile.TemporaryDirectory()

    host_list = [u'localhost']
    play_source = dict(
        name="Ansible Play",
        hosts=host_list,
        gather_facts='no',
        tasks=[
            dict(
                include_role=dict(
                    name='include_role_test_role',
                ),
            )
        ]
    )

    loader = DataLoader()

    variable_manager = VariableManager()


# Generated at 2022-06-23 07:11:28.470218
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    import ansible.constants as C
    import ansible.playbook.role as role

    mock_loader = 'Fake loader object'

    # Begin test cases
    # Case 1: When role_path is None

    role_to_test = IncludeRole()
    role_to_test._role_path = None
    role_to_test.action = C._ACTION_INCLUDE_ROLE

    # Begin fake out RoleInclude.load to return the desired role object
    fake_role = role.Role()
    fake_role._metadata = role._RoleMetadata()
    fake_role._metadata.name = "fake_role_name"
    fake_role._metadata.path = "/foo/fake/path"

# Generated at 2022-06-23 07:11:39.073645
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    play = Play()
    play.vars = dict(a='A', b='B')
    role = Role()
    role.vars = dict(c='C', d='D')

    ir = TaskInclude(dict(name='test'))
    ir._role_name = 'foo'

    assert ir.get_include_params() == dict(
        ansible_role_names=['test'],
        ansible_role_paths=[None],
    )

    ir._parent_role = role

# Generated at 2022-06-23 07:11:45.204638
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block(play=None, parent=None)
    role = Role()
    task_include = None
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    assert include_role.apply == {}
    assert include_role.public == False
    assert include_role.allow_duplicates == True
    assert include_role.rolespec_validate == True


# Generated at 2022-06-23 07:11:50.151111
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    try:
        from ansible.playbook.role.definition import RoleDefinition
    except ImportError:
        from ansible.playbook.role.meta import RoleDefinition

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # create a fake role object
    fake_role = RoleDefinition()
    fake_role._role_path = 'fake_role_path'
    fake_role._role_name = 'fake_role_name'

    # create a fake parent role object
    fake_parent_role = RoleDefinition()
    fake_parent_role._role_path = 'fake_parent_role_path'
    fake_parent_role._role_name = 'fake_parent_role_name'

    # create a fake block object
    fake_block = Block()

    # create a fake task

# Generated at 2022-06-23 07:12:00.909118
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    """
    For constructor of class IncludeRole, a Role object is required.

    This unit test verifies the Role object.
    """
    import os
    from ansible.module_utils.six import StringIO

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    data = dict(
        name='foo',
        src='bar',
        collection='foo',
        private=False
    )
    meta = dict(
        collection='foo'
    )
    config = AnsibleCollectionConfig(StringIO(u''))
    # include = IncludeRole.load(data, variable_manager=self.variable_manager, loader=self.loader)


# Generated at 2022-06-23 07:12:05.915026
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.args = {'name': 'role_name'}
    assert ir.get_name() == 'include_role : role_name'
    ir.args = {'role': 'role_name'}
    assert ir.get_name() == 'include_role : role_name'

# Generated at 2022-06-23 07:12:15.930111
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.module_utils.six import StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    test_data = {
        'name': 'test include role',
        'include_role': {
            'name': 'test_role',
            'tasks_from': './some_file',
            'vars_from': 'test_vars/main.yml',
            'handlers_from': 'some_handlers',
            'defaults_from': 'roles/test/defaults/main.yml',
            'allow_duplicates': True,
            'rolespec_validate': False,
            'public': True,
            'apply': {},
        },
    }

    play_context = PlayContext()
   

# Generated at 2022-06-23 07:12:25.729770
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # No role, no action
    try:
        IncludeRole(None, None)
    except:
        raise AssertionError('IncludeRole should not fail without a role or an action.')
    else:
        pass
    
    # Invalid action
    try:
        IncludeRole(None, None, None, 'invalid_action')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('IncludeRole should fail when an invalid action is specified.')
        
    # Invalid role
    try:
        IncludeRole(Block(), True)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('IncludeRole should fail when an invalid role is specified.')

# Generated at 2022-06-23 07:12:37.992789
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import tempfile
    import shutil
    import mock
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.vars.manager import VariableManager

    ROLE_NAME = 'test_role'

    basedir = tempfile.mkdtemp(dir=C.DEFAULT_LOCAL_TMP)
    test_dir = os.path.join(basedir, ROLE_NAME)
    # the next two directories should be inside `test_

# Generated at 2022-06-23 07:12:47.347839
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.vars import merge_hash

    class A:
        pass

    a = A()
    b = A()
    a.parent = b
    b._tasks = [1, 2, 3]
    b._metadata = {'a': 1}
    b._dep_chain = ['b', 'c', 'd']
    b.post_validate_block = None
    b.get_role_params = lambda : {'a': 1, 'b': 2}
    b.get_name = lambda : 'foo'

    c = Block()
    c._parent = a
    c._tasks = [1, 2, 3]

# Generated at 2022-06-23 07:12:55.089408
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Basic test case with simple IncludeRole
    include_role = IncludeRole(role='test_role')
    assert include_role._role_name == 'test_role'

    # Test IncludeRole with passing in additional args
    include_role = IncludeRole(role='test_role', vars=dict(a=1, b=2))
    assert include_role._role_name == 'test_role'
    assert include_role.vars == dict(a=1, b=2)


# Generated at 2022-06-23 07:13:01.242145
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    pb = Block()
    task = IncludeRole(block=pb, role=None, task_include=None)
    task.name = 'name'
    task._role_name = 'role name'
    assert task.get_name() == 'name' or task.get_name() == 'role name'

# Generated at 2022-06-23 07:13:10.625436
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_done_callback import TaskDoneCallback
    from ansible.playbook.task import Task
    from ansible.plugins.loader import get_all_plugin_loaders

    # Temporary block class mock
    class BlockMock(Block):
        def __init__(self):
            self._parent = None

    # Temporary task class mock
    class TaskMock(Task):
        def __init__(self):
            self._parent = None
            self._role = None
            self._metadata = None
            self._role_path = None
            self._dep_chain = None

        def compile(self):
            return [BlockMock(), BlockMock(), BlockMock()]


# Generated at 2022-06-23 07:13:11.600898
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-23 07:13:21.946034
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    p = Block()
    p.hosts = 'host_0'
    p.name = 'test_play'
    p.role = 'test_role'
    p.vars = {'test_var': 'test_value'}

# Generated at 2022-06-23 07:13:31.904420
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars

    # Test-specific imports
    from ansible.module_utils.six import string_types
    from ansible.vars.manager import VariableManager

    from io import StringIO

    # Setup the test play

# Generated at 2022-06-23 07:13:43.184696
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task.handler import Handler
    from ansible.inventory.host import Host, Group

    # block
    block = Block.load(
        dict(
            tasks=[{'include_role': {'name': 'role_name'}}],
            # handlers=[{'include_role': {'name': 'role_name'}}],
        ),
        play=None
    )

    # role

# Generated at 2022-06-23 07:13:55.688963
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # Create roles
    role_a = Role()
    role_a._role_path = '/path/to/role_a'
    role_a._role_name = 'role_a'
    role_b = Role()
    role_b._role_path = '/path/to/role_b'
    role_b._role_name = 'role_b'

    # Create tasks
    task = Task()
    task._role = role_a
    task._role._parent = role_b
    task._role._parent._parent = role_b

    # Create play context
    play_context = PlayContext()


# Generated at 2022-06-23 07:14:09.139317
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.role import Role
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars

    role = Role()
    role._role_path = "roles/foo/bar/baz"
    role._metadata = {"galaxy_info": {'name': 'supercalifragilisticexpialidocious'}, "name": "foobar"}
    role._tasks = Tasks()
    block = Block()
    block.deprecated = False
    block._deprecate_valid = True
    block._role = role
    block._play = 1
    task_include = TaskInclude(block=block, role=role)
    task_include._parent = block
    block

# Generated at 2022-06-23 07:14:19.534739
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # The GET_BLOCK_LIST method adds tasks to the parent block.
    # This specific test checks that a child defined in another role is
    # properly merged into the parent's list of children.

    # The task we want to add to the parent block
    class MockTask:
        name = None
        def get_name(self):
            return 'my_task'

        def __repr__(self):
            return str(self)

        def __str__(self):
            return "MockTask(name=%s)" % (self.name)

    task = MockTask()
    task.name = 'task'

    # The task block we will use to add the task
    class MockTaskBlock:
        def add_task(self, task):
            self.tasks.append(task)


# Generated at 2022-06-23 07:14:24.627113
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    from ansible.playbook.block import Block

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata

    from ansible.vars.manager import VariableManager

    import os

    # compile without play
    def test1():
        # load data
        data = {'name': 'role_include', 'role': '../test_role1'}
        data_loader = DataLoader()
        variable_manager = VariableManager()
        block = Block.load(data, None, VariableManager(), loader=data_loader)
        ri = IncludeRole.load(data, block)
       

# Generated at 2022-06-23 07:14:26.002638
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass


# Generated at 2022-06-23 07:14:34.610489
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    role = Role()
    block = Block()
    ir = IncludeRole(role=role, block=block)
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, Block)
    assert isinstance(ir, TaskInclude)
    assert ir._parent == block
    assert ir._parent_role == role
    assert set(ir.collections) == set([])
    assert ir._role_name is None
    assert ir._role_path is None
    assert ir._from_files == {}
    assert ir.statically_loaded is True

# Generated at 2022-06-23 07:14:39.559250
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test_name'
    ir._role_name = 'test_role_name'
    result = ir.get_name()
    # Check that result is equal to expected value
    assert result == 'test_name : test_role_name'


# Generated at 2022-06-23 07:14:50.379300
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class FakeRole(object):
        def __init__(self, name, path, params):
            self._name = name
            self._role_path = path
            self.params = params

        def get_name(self):
            return self._name

        def get_role_params(self):
            return self.params

    # Unit test case with null parent_role
    display.verbosity = 3
    ir = IncludeRole()
    assert ir.get_include_params() == {}

    # Unit test case with parent_role but null role params
    ir._parent_role = FakeRole("Arole", "ArolePath", {})
    assert ir.get_include_params() == {'ansible_parent_role_names': ['Arole'], 'ansible_parent_role_paths': ['ArolePath']}

    #

# Generated at 2022-06-23 07:14:56.547032
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    display.vvv('Testing IncludeRole.get_include_params')
    display.vvv('TEST1: No parent role')
    test_playbook = """
    - hosts: all
      tasks:
        - name: Include role without parent role
          include_role:
            name: myrole
    """
    from ansible.plugins.loader import play_loader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()
    t = Templar(loader=dataloader)
    pb = play_loader.load(test_playbook, variable_manager=VariableManager(), loader=dataloader)
    role_include = pb.get_tasks()[0].copy()


# Generated at 2022-06-23 07:15:09.456991
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Unit test for method load of class IncludeRole
    #
    # create test data
    data = dict(
        _raw_params=dict(
            name='foo',
            tasks_from='bar',
            vars_from='baz',
            defaults_from='qux',
            handlers_from='quux',
            allow_duplicates=True,
            public=True,
            apply='yes please',
        )
    )

    # create an include role
    ir = IncludeRole.load(data)

    # assert type
    assert isinstance(ir,IncludeRole)

    # assert attributes
    assert ir.name == 'foo'
    assert ir._from_files == {'tasks': 'bar', 'vars': 'baz', 'defaults': 'qux', 'handlers': 'quux'}


# Generated at 2022-06-23 07:15:10.591457
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-23 07:15:20.080665
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # initialize needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    block = Block()
    role = Role()

    # test empty case
    r = IncludeRole.load({}, block=block, role=role)
    assert r.action == 'include_role'
    assert r.args == {}

    # test invalid args

# Generated at 2022-06-23 07:15:23.063168
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert IncludeRole.get_block_list() == 'pass'

# Generated at 2022-06-23 07:15:35.239734
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert IncludeRole().get_include_params() == {}
    assert IncludeRole(role=Role()).get_include_params() == {}
    assert IncludeRole(role=Role(name='role')).get_include_params() == {'ansible_role_name': 'role'}
    assert IncludeRole(role=Role(path='path')).get_include_params() == {'ansible_role_path': 'path'}
    assert IncludeRole(role=Role(name='role', path='path')).get_include_params() == {
        'ansible_role_name': 'role',
        'ansible_role_path': 'path'
    }

    assert IncludeRole(role=Role(
        name='role',
        path='path',
        parents=[Role(name='parent')]
    )).get_include_

# Generated at 2022-06-23 07:15:43.988026
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''
    test methods of IncludeRole class
    '''
    # test method get_include_params
    # create tasks include, parent_role is None
    tasks_include = {
        'include_role': 'name=test_role'
    }
    block = Block()
    role_include = IncludeRole(block=block, role=None)
    role_include.load_data(tasks_include, variable_manager=None, loader=None)

    # test parent_role is None
    v = role_include.get_include_params()

    assert v['ansible_parent_role_names'] == []
    assert v['ansible_parent_role_paths'] == []

    # create parent_role for testing
    parent_role_name = 'test_parent_role'

    block = Block()
    parent_

# Generated at 2022-06-23 07:15:51.148304
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar', 'role1_x': 'role1_x_static'}
    variable_manager.options_vars = {"roles_path": "./test/unit/lib/ansible/roles"}
    variable_manager.host_vars = {'host1': {'bar': 'foo'}}

    play_context = PlayContext()
    play_context._options = {}