

# Generated at 2022-06-23 07:05:53.358539
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    block.role = role
    task_include = TaskInclude()

    # This is the original IncludeRole class
    ir = IncludeRole(block=block, role=role, task_include=task_include)

    # This is the new IncludeRole class which will be used for testing
    new_ir = ir.copy(exclude_parent=False, exclude_tasks=False)

    # Test Case 1: Testing the attributes of Includer Role copy
    assert new_ir.static_loading == ir.static_loading
    assert new_ir.always_run == ir.always_run
    assert new_ir.any_errors_fatal == ir.any_errors_fatal
    assert new_ir._allow_duplicates == ir._allow_duplicates
    assert new_ir.action

# Generated at 2022-06-23 07:05:58.855139
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    '''
    Test get_name method of the IncludeRole class
    '''
    ir = IncludeRole()
    ir.name = 'test_name'
    assert ir.get_name() == 'test_name'

    ir = IncludeRole()
    ir._role_name = 'test_role_name'
    ir.action = 'test_action'
    assert ir.get_name() == 'test_action : test_role_name'

# Generated at 2022-06-23 07:06:08.580181
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=["localhost"])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_parent_role_names }}')))
        ]
    )

# Generated at 2022-06-23 07:06:18.291079
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'my_require': {
            'role': 'apache',
            'foo': 'bar',
            'vars_from': 'some_file',
            'tasks_from': 'other_file',
            'defaults_from': 'another_file',
            'handlers_from': 'yet_another_file',
            'allow_duplicates': False,
            'apply': {
                'tags': ['a', 'b', 'c'],
                'strategy': 'free',
            },
            'public': True,
        }
    }

    # create role and initialize variables
    role = Role()
    role._role_path = 'test_role_path'
    role._metadata = {}
    role._metadata['path'] = 'path/to/role'

# Generated at 2022-06-23 07:06:28.845318
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role

    # 1. Init a IncludeRole without role and task_include
    ir = IncludeRole()
    assert isinstance(ir, Block)
    assert not ir.role
    assert not ir.task_include

    # 2. Init a IncludeRole with a TaskInclude
    ti = TaskInclude()
    ir2 = IncludeRole(task_include=ti)
    assert isinstance(ti, TaskInclude)
    assert ir2.task_include == ti

    # 3. Init a IncludeRole with a Role
    ri = Role()
    ir3 = IncludeRole(role=ri)
    assert isinstance(ri, Role)
    assert ir3.role == ri

# Generated at 2022-06-23 07:06:36.700946
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block.load(dict(
        tasks = [
            dict(action=dict(module='test_module', args=dict(test_arg1='arg1', test_arg2='arg2')))
        ]
    ), play=None)
    role = Role()
    task_include = TaskInclude()
    test_class = IncludeRole(block, role, task_include=task_include)
    test_class.action = 'test_action'
    test_class._role_name = 'test_role_name'
    assert test_class.get_name() == "test_action : test_role_name"

# Generated at 2022-06-23 07:06:47.229459
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task = {}
    task['action'] = 'include_role'
    task['name'] = 'myrolename'
    include = IncludeRole()
    include.load(task, load_tasks=False)
    assert include.get_name() == 'include_role : myrolename'

    task['name'] = 'role_name'
    task['role'] = 'rolename'
    include.load(task, load_tasks=False)
    assert include.get_name() == 'include_role : rolename'

    task['name'] = None
    task['role'] = 'rolename'
    include.load(task, load_tasks=False)
    assert include.get_name() == 'include_role : rolename'

# Generated at 2022-06-23 07:06:58.692615
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ''' test method get_include_params of class IncludeRole '''
    class FakeTaskInclude():
        _parent_role = FakeRole()
        _parent_role._metadata = FakeRoleMetadata()
        _parent_role._metadata.name = "test_name"
        _parent_role._role_path = "test_role_path"
        def get_role_params(self):
            return {'ansible_parent_role_names': [], 'ansible_parent_role_paths': []}
    class FakeRole():
        pass
    class FakeRoleMetadata():
        pass
    # role without parent role
    ir = IncludeRole()
    empty_v = dict()
    assert ir.get_include_params() == empty_v
    # role with parent role
    ir_with_parent_role = IncludeRole()

# Generated at 2022-06-23 07:07:08.993427
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Setup
    ir = IncludeRole()
    ir._parent_role = Role()
    ir._parent_role._role_params = {'params1': 'value1', 'params2': 'value2'}
    ir._parent_role._name = 'parentrole'


    # Exercise
    ret = ir.get_include_params()

    # Verify
    assert ret.get('ansible_parent_role_names') == ['parentrole']
    assert ret.get('ansible_parent_role_paths') == ['']
    assert ret.get('params1') == 'value1'
    assert ret.get('params2') == 'value2'


# Generated at 2022-06-23 07:07:15.502358
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.requirement import RoleRequirement
    play = Play()
    ir = RoleRequirement.load({'role':'test_role_name'}, play=play)
    ir.role.get_role_params = lambda: dict(a=1)
    params = ir.get_include_params()
    assert params == dict(a=1)


# Generated at 2022-06-23 07:07:17.509130
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
  ir = IncludeRole()
  ir._role_name = 'test'
  assert ir.get_name() == 'include_role : test'

# Generated at 2022-06-23 07:07:31.071458
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()

    task_include_1 = IncludeRole(block=block, role=role)
    task_include_1.static_load = True
    task_include_1._from_files = {'defaults_from': 'role.yml'}
    task_include_1._parent_role = role
    task_include_1._role_name = 'nested-role'
    task_include_1._role_path = '.../nested-role'

    task_include_2 = task_include_1.copy()
    assert task_include_2._parent == task_include_1._parent
    assert task_include_2.statically_loaded == task_include_1.statically_loaded
    assert task_include_2._from_files == task_include_1._from_

# Generated at 2022-06-23 07:07:38.054085
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Create a mock role
    mock_role = Role()
    mock_role._role_name = 'mock_role'
    mock_role._role_params = {'role_param': 'mock_role'}
    mock_role._metadata = Role._metadata_class()

    # Create an IncludeRole with a mock role
    include_role = IncludeRole()
    include_role._parent_role = mock_role
    
    # Assert that the dictionary returned by get_include_params is correct
    expected = {'role_param': 'mock_role',
                'ansible_parent_role_names': ['mock_role'],
                'ansible_parent_role_paths': [None]}
    assert include_role.get_include_params() == expected

# Generated at 2022-06-23 07:07:52.986290
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import json
    import sys
    import os.path
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    # Dump inventory to json

# Generated at 2022-06-23 07:07:53.493305
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    assert IncludeRole()

# Generated at 2022-06-23 07:08:09.105537
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'mytasks'}
    ir._parent_role = False
    ir._role_name = 'rolename'
    ir._role_path = 'rolepath'
    new_ir = ir.copy()
    assert hasattr(new_ir,'statically_loaded')
    assert hasattr(new_ir,'_from_files')
    assert hasattr(new_ir,'_parent_role')
    assert hasattr(new_ir,'_role_name')
    assert hasattr(new_ir,'_role_path')
    assert new_ir.statically_loaded == True
    assert new_ir._from_files == {'tasks': 'mytasks'}

# Generated at 2022-06-23 07:08:18.141910
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    display.verbosity = 3

    def get_final_value(obj, attr):
        return getattr(obj, attr)
    # ------------------------------------------------------

    # `- include_role: name=role1`
    test_block = Block()
    test_block.role = []
    test_include_role = IncludeRole(block = test_block, role = None, task_include=None)
    test_include_role.action = 'include_role'
    test_include_role.statically_loaded = False
    test_include_role.post_validate = True
    test_include_role.always_run = False
    test_include_role.ignore_errors = True
    test_include_role._role_path = 'test_role_path'
    test_include_role._parent_role = None
   

# Generated at 2022-06-23 07:08:29.648203
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest

    loader = None
    variable_manager = None

    def test_role_name(data, role_name):
        ir = IncludeRole.load(data=data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
        assert ir._role_name == role_name

    def test_from_files(data, from_files):
        ir = IncludeRole.load(data=data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
        assert ir._from_files == from_files

    def test_role_names(data, role_name):
        for parser in C._PARSERS:
            test_role_name(data=data, role_name=role_name)


# Generated at 2022-06-23 07:08:35.448682
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    source_block = """
- hosts: 127.0.0.1
  gather_facts: false
  roles:
    - leocornus.example_role_include
"""

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    inventory = InventoryManager(loader=loader, sources="127.0.0.1,")
    variable_manager.set_inventory(inventory)

    from ansible.playbook.play import Play
    play = Play.load(source_block, variable_manager=variable_manager, loader=loader)
    play._variable_manager = variable_manager
    play._loader

# Generated at 2022-06-23 07:08:47.472501
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # AnsibleAction templated
    include_role_task = IncludeRole(dict(
        name = 'test-name',
        when = 'test-when'
    ))
    assert include_role_task.name == 'test-name'
    assert include_role_task.when == 'test-when'

    # AnsibleBase templated
    include_role_task = IncludeRole(dict(
        block = Block(dict(
            tasks = [],
            handlers = [],
            rescue = [],
            always = []
        )),
        notify = [],
        tags = []
    ))
    assert include_role_task.notify == []
    assert include_role_task.tags == []

    # Task templated

# Generated at 2022-06-23 07:09:00.013708
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/lib/ansible/inventory/test_inventory'])
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context._init_globals()


# Generated at 2022-06-23 07:09:01.148486
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert IncludeRole.get_block_list() == [0]


# Generated at 2022-06-23 07:09:14.146818
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import imp
    import os

    # this is horrible, but doesn't seem to be a better way to test internals
    if "COVERAGE_TESTING" in os.environ:
        imp.load_source("ansible.constants", os.path.join("lib", "ansible", "constants.py"))

    from ansible.errors import AnsibleParserError
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook



# Generated at 2022-06-23 07:09:24.138767
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create a fake object
    loader = 'fake_loader'
    variable_manager = 'fake_variable_manager'
    role = 'fake_role'
    data = {'name': "test_name",
            'allow_duplicates': True,
            'rolespec_validate': True,
            'public': False,
            'apply': {},
            'tags': [],
            'tasks_from': 'fake_tasks_from',
            'vars_from': 'fake_vars_from',
            'defaults_from': 'fake_defaults_from',
            'handlers_from': 'fake_handlers_from'
            }
    ir = IncludeRole.load(data, role=role, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 07:09:25.996488
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    assert False, "Test not implemented"

# Generated at 2022-06-23 07:09:37.697843
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Given
    data = dict(
        name='role_name',
        tasks_from='tasks/main.yml',
        vars_from={'file': 'vars/main.yml', 'key': ['list', 'of', 'vars']},
        defaults_from='defaults/main.yml'
    )
    block = Block()
    role = Role()
    role_name = 'my_role'
    role.name = role_name

    # When
    ir = IncludeRole.load(data, block=block, role=role)

    # Then
    assert ir.block == block
    assert ir._role_name == 'role_name'

# Generated at 2022-06-23 07:09:48.933167
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    task = IncludeRole()
    task.statically_loaded = True
    task._from_files = {'defaults': 'foo.yml'}
    task._parent_role = 'role/foo/tasks/main.yml'
    task._role_name = 'role/foo/tasks/main.yml'
    task._role_path = 'role/foo'

    new_me = task.copy()
    assert new_me.statically_loaded is True
    assert new_me._from_files == {'defaults': 'foo.yml'}
    assert new_me._parent_role == 'role/foo/tasks/main.yml'
    assert new_me._role_name == 'role/foo/tasks/main.yml'

# Generated at 2022-06-23 07:09:49.654380
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
  pass

# Generated at 2022-06-23 07:10:01.660900
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test getting a list of handlers from a block object.
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    # Unload the collection, so we can replace the file.
    C.COLLECTIONS_PATHS = []

    # Set the ANSIBLE_ROLES_PATH env variable
    C.ANSIBLE_ROLES_PATH = './lib/ansible/roles'


# Generated at 2022-06-23 07:10:07.790641
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role_name = 'my_role'
    action = 'include_role'
    ir = IncludeRole(role=role_name, task_include=action)
    ir.get_name()
    assert ir.name is None
    assert ir.action == 'include_role'
    expected_res = "include_role : my_role"
    actual_res = ir.get_name()
    assert actual_res == expected_res


# Generated at 2022-06-23 07:10:19.998998
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.task import Task
    r = Role()
    rl = IncludeRole(role=r)
    t = Task()

    rl._role_name = "role_name"
    rl._parent_role = "parent_role"
    rl._role_path = "role_path"
    rl.statically_loaded = "statically_loaded"
    rl._from_files = {"key" : "value"}
    rl.name = "name"
    rl.action = "action"
    rl.loop = "loop"
    rl.until = "until"
    rl.retries = "retries"
    rl.delay = "delay"
    rl.first_available_file = "first_available_file"
    rl.tags = "tags"

# Generated at 2022-06-23 07:10:25.262753
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    #test of method copy of class IncludeRole
    block = Block()
    role = Role()
    #Case when exclude_parent=False and exclude_tasks=False
    assert IncludeRole(block=block, role=role).copy()
    #Case when exclude_parent=True and exclude_tasks=True
    assert IncludeRole(block=block, role=role).copy(exclude_parent=True, exclude_tasks=True)
    #Case when exclude_parent=False and exclude_tasks=True
    assert IncludeRole(block=block, role=role).copy(exclude_parent=False, exclude_tasks=True)
    #Case when exclude_parent=True and exclude_tasks=False
    assert IncludeRole(block=block, role=role).copy(exclude_parent=True, exclude_tasks=False)

#

# Generated at 2022-06-23 07:10:36.670814
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 07:10:44.405407
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    test class for IncludeRole
    '''
    data = '''
         name: foo
         vars_from: bar
         apply:
             parameters:
                 a: b
    '''
    role = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert role.name == "foo"
    assert role._from_files['vars'] == "bar"
    assert role.apply['parameters']['a'] == "b"

# Generated at 2022-06-23 07:10:52.785193
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # This test is not really needed, but it's just here to see if we have coverage on this method
    r = IncludeRole(Block())
    r.name = 'name_test'
    r.action = 'action_test'
    assert r.get_name() == 'name_test'
    r.name = None
    assert r.get_name() == 'action_test : '
    r._role_name = 'role_name_test'
    assert r.get_name() == 'action_test : role_name_test'

# Generated at 2022-06-23 07:10:56.912381
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    # Create a dummy Block to become parent of the blocks we will create
    p_block = Block()

    # Create a dummy RoleDefinition to become parent of the blocks we will create
    from_files = {'tasks': 'main.yml', 'vars': 'vars.yml', 'handlers': 'handlers.yml'}
    p_role = RoleDefinition.load('testrole', ['/tmp/testrole'], from_files, apply_defaults=None)

    for block in p_role.compile():
        block._parent = p_block
        block.vars = p_block.v

# Generated at 2022-06-23 07:11:00.424318
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    task_include = IncludeRole()
    task_include._role_name = "test_role"
    assert task_include.get_name() == "include_role : test_role"

# Generated at 2022-06-23 07:11:12.602123
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    a_roles_path = "/a/roles/path"
    a_role = Role()
    a_role._role_name = "my_role"
    a_role._role_path = a_roles_path
    a_include_role = IncludeRole(role=a_role)
    a_include_role._parent = Block()
    a_include_role.vars = {"var1": ["value1", "value2"]}
    a_include_role.tags = ["tag1", "tag2"]
    a_include_role.when = "when"
    a_include_role._from_files = {"a_key1": "a_value1"}
    a_include_role.args = {"a_key2": "a_value2"}

# Generated at 2022-06-23 07:11:23.085145
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    block = Block()
    task = Task()
    play_context = PlayContext()
    block._parent = task
    task._parent = play_context

    # TODO: Replace with mock
    data = {}
    role = {}
    task_include = {}

    # TODO: Replace with mock
    variable_manager = {}
    loader = {}

    include_role = IncludeRole(block, role, task_include=task_include)
    assert include_role.get_name() == 'include_role'
    assert include_role.statically_loaded is False
    assert include_role.wrap_async is False


# Generated at 2022-06-23 07:11:33.804923
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    """
    This is a test for the constructor of class IncludeRole
    """
    roleobj = Role()
    obj = IncludeRole(role=roleobj)
    assert obj._allow_duplicates == True, "Test Failed: " \
        "constructor of class IncludeRole failed to set _allow_duplicates=True"
    assert obj._public == False, "Test Failed: " \
        "constructor of class IncludeRole failed to set _public=False"
    assert obj._role_path == None, "Test Failed: " \
        "constructor of class IncludeRole failed to set _role_path=None"
    assert obj._role_name == None, "Test Failed: " \
        "constructor of class IncludeRole failed to set _role_name=None"

# Generated at 2022-06-23 07:11:35.595469
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    b = Block()
    r = Role()
    ir = IncludeRole(block=b, role=r)
    assert ir is not None

# Generated at 2022-06-23 07:11:41.281935
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    data_input = {'name': 'foo', 'block': 1, 'role': 2, 'task_include': 3, 'args': {'role': 'bar'}}

    ir = IncludeRole.load(data_input)
    name = ir.get_name()

    assert name == 'bar'

# Generated at 2022-06-23 07:11:50.197425
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ''' Unit test for method get_name of class IncludeRole '''
    my_block = Block()
    my_block.role = Role()
    # If name is None, then return the action with the role name
    ir = IncludeRole(my_block)
    ir._role_name = 'role_name'
    assert ir.get_name() == 'include_role : role_name'
    ir.name = 'role_name1'
    # If name is not None, then return that
    assert ir.get_name() == 'role_name1'


# Generated at 2022-06-23 07:12:00.939302
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    t = Task.load({"name": "assert if include_role_vars is not a dict", "include_role": {"name": "role_name", "include_role_vars": "not a dict"}})
    assert t.action == 'include_role'
    assert t.include_role_vars == dict()


# Generated at 2022-06-23 07:12:04.030500
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(role=None)
    ir.name = "mytest"
    ir._role_name = "mytest2"
    assert ir.get_name() == "mytest : mytest2"
    ir.name = ""
    assert ir.get_name() == ": mytest2"
    ir.name = "mytest"
    ir._role_name = ""
    assert ir.get_name() == "mytest"

# Generated at 2022-06-23 07:12:14.249065
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    Test for method copy of class IncludeRole
    """
    # init role
    role_block = Block()
    role = Role()
    role._role_path = "/path/"
    role.name = "a_name"
    role.action = "a_action"
    role.collections = "collections"
    role.dependencies = "dependencies"
    role._metadata = "metadata"
    role._rolespec = "rolespec"
    role.statically_loaded = False

    # init task_include
    task_include = TaskInclude()
    task_include.include = "toto"

    # init instance IncludeRole
    include_role = IncludeRole(block=role_block, role=role, task_include=task_include)
    include_role.action = "a_action"
   

# Generated at 2022-06-23 07:12:24.648279
# Unit test for method load of class IncludeRole

# Generated at 2022-06-23 07:12:37.393934
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()
    role.name = 'foo'
    role._role_path = '/path/to/foo'
    task_include = TaskInclude(block=block, role=role)
    task_include.action = 'include_role'
    task_include._apply_defaults_from_role()
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    include_role.vars = {'foo': 'bar'}
    include_role.tags = ['foo']
    include_role.collections = ['foo']
    include_role.name = 'test'
    include_role._role_name = 'bar'
    include_role._role_path = '/path/to/bar'

# Generated at 2022-06-23 07:12:46.895792
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test all supported arguments.
    ir = IncludeRole.load({'include_role': {'name': 'role_name', 'apply': {'key': 'value'}, 'tasks_from': 'role_name/tasks/main.yml',
                                            'vars_from': 'role_name/vars/main.yml', 'defaults_from': 'role_name/defaults/main.yml',
                                            'handlers_from': 'role_name/handlers/main.yml', 'allow_duplicates': False, 'public': True,
                                            'rolespec_validate': False}})
    assert ir._from_files['tasks'] == 'main.yml'
    assert ir._from_files['vars'] == 'main.yml'
    assert ir._from_

# Generated at 2022-06-23 07:12:50.128334
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    task_include = IncludeRole(block=Block())
    assert isinstance(task_include, IncludeRole)

# Generated at 2022-06-23 07:12:58.595260
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.runtime import PlayContext

    fake_task = IncludeRole()
    fake_task.args = dict(name="test-role")
    fake_task.action = 'my-include-role'
    fake_task.role = FakeRole()
    fake_task.vars = dict(my_var="global")
    fake_task.blocks = [FakeBlock()]
    fake_task._role_name = "test-role"
    fake_task._parent_role = FakeRole()
    fake_task.statically_loaded = False
    fake_task._from_files = dict(tasks="relative_path")
    fake_block = FakeBlock()
    fake_block._parent = None
    fake_block.name = "include_role"


# Generated at 2022-06-23 07:12:59.252755
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-23 07:13:09.429899
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook, PlaybookIterator
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    playbook_file = '../../docs/examples/ansible-playbook/include_role.yaml'
    base_role_example_file = '../../docs/examples/ansible-playbook/base_role/tasks/main.yaml'
    base_role_example_path = '../../docs/examples/ansible-playbook/base_role/tasks/'


# Generated at 2022-06-23 07:13:21.398767
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Execute the IncludeRole.get_include_params method and assert the result

    # Setup
    fake_role_name = "fake_role_name"
    fake_relative_path = "fake_relative_path"
    fake_role_params = { "fake_role_parameter_name": "fake_role_parameter_value" }

    fake_parent_role = "fake_parent_role"
    fake_parent_role_name = "fake_parent_role_name"

    my_include_params = { "name": fake_role_name, "role": fake_relative_path }
    my_include_role = IncludeRole(role=fake_parent_role)
    my_include_role._role_name = fake_role_name

# Generated at 2022-06-23 07:13:24.344161
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, Block)
    assert isinstance(ir, TaskInclude)

# Generated at 2022-06-23 07:13:33.530711
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    inclusion = IncludeRole(block=Block(), role=Role())
    inclusion.vars = dict(status = 'ok', role = 'web')
    inclusion._parent = object()
    inclusion.statically_loaded = False
    inclusion.statically_loaded
    inclusion._from_files = dict(var = 'test.yml')
    inclusion._role_name = 'test'
    inclusion._role_path = '/root/test'
    copy_of_inclusion = inclusion.copy()
    assert copy_of_inclusion.vars == inclusion.vars
    assert copy_of_inclusion._parent == inclusion._parent
    assert copy_of_inclusion.statically_loaded == inclusion.statically_loaded
    assert copy_of_inclusion._from_files == inclusion._from_files
    assert copy_of_inclusion._role_name

# Generated at 2022-06-23 07:13:44.175197
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    class_name = IncludeRole.__name__
    func_name = 'copy'
    display_unit_test_title('{0} - {1}'.format(class_name, func_name))
    block = Block()
    role = Role()
    include_role = IncludeRole(block, role)
    include_role.statically_loaded = True
    include_role._from_files = {'tasks': 'tasks', 'files': 'files'}
    include_role._parent_role = role
    include_role._role_name = 'role_name'
    include_role._role_path = 'role_path'
    include_role_new = include_role.copy()
    assert include_role_new.statically_loaded

# Generated at 2022-06-23 07:13:55.196789
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    il = IncludeRole()
    pr = Role()
    pr.get_name = lambda: 'ParentRoleName'
    pr._role_path = 'ParentRolePath'
    pr.get_role_params = lambda: {'a': 'aaa', 'b': 'bbb'}
    il._parent_role = pr
    include_params = il.get_include_params()
    assert include_params.get('ansible_parent_role_names') == ['ParentRoleName']
    assert include_params.get('ansible_parent_role_paths') == ['ParentRolePath']
    assert include_params.get('a') == 'aaa'
    assert include_params.get('b') == 'bbb'

# Generated at 2022-06-23 07:14:08.669913
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.block import Block

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    #####################################
    # test good
    args = dict(
        name = 'user-install',
        apply = dict(
            tags = 'USER_INSTALL'
        )
    )
    role_definition = RoleDefinition.load('name: user-install', data=args, variable_manager=VariableManager(), loader=DataLoader())
    role_definition.post_validate(loader=DataLoader())

    p = Play

# Generated at 2022-06-23 07:14:19.483736
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    display.current_app = 'ansible-playbook'
    display.verbosity = 3

    d = {'action': 'include_role', 'name': 'test', 'tasks_from': 'tasks/main.yaml', 'vars_from': 'vars/main.yaml', 'defaults_from': 'default/main.yaml', 'handlers_from': 'handlers/main.yaml', 'apply': {'tags': ['just_a_tag']}, 'public': True, 'allow_duplicates': False}
    role = IncludeRole.load(d)
    assert role.allow_duplicates is False
    assert role.apply == {'tags': ['just_a_tag']}
    assert role.defaults_from == 'default/main.yaml'

# Generated at 2022-06-23 07:14:20.149456
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-23 07:14:32.275389
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create fake object (block, role and task_include)
    fake_block = Block(None)
    fake_role = Role()
    fake_role._role_name = "fake_role_name"
    fake_task_include = TaskInclude()
    fake_task_include.name = "fake_task_include_name"

    # Test
    ir = IncludeRole(fake_block, fake_role, fake_task_include)
    # first use the name of the task_include
    assert ir.get_name() == "fake_task_include_name"

    # Then use the name of the role
    ir._name = None
    assert ir.get_name() == "fake_role_name : fake_role_name"

    # Then use the name of the action
    ir._role_name = None
    assert ir

# Generated at 2022-06-23 07:14:40.108127
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()

    r = Block()
    r.name = 'test name'
    r.action = 'test action'
    r.statically_loaded = True
    r.args.update({'tasks_from': 'test_tasks.yml', 'allow_duplicates': True, 'public': False, 'apply': {'test': 'test apply'}, 'rolespec_validate': True})
    r.collections = ['test_collection']

    assert r.name == 'test name'
    assert r.action == 'test action'
    assert r.statically_loaded == True

# Generated at 2022-06-23 07:14:43.344533
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir=IncludeRole()
    ir.action = 'role-include'
    ir._role_name = 'test_role_name'
    assert ir.get_name() == "role-include : test_role_name"

# Generated at 2022-06-23 07:14:52.710918
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Testing IncludeRole.get_name method with invalid input
    display.verbosity = 3
    data = {'name': 'helloworld', 'role': 'test'}
    block1 = Block(play=None, parent_block=None)
    block2 = Block(play=None, parent_block=None)
    role1 = Role(name='test')
    role2 = Role(name='test')
    ti1 = TaskInclude(block=block1, role=role1)
    ti2 = TaskInclude(block=block2, role=role2)

    # Testing with no name or role fields
    data = {'some': 'helloworld', 'other': 'test'}
    ir = IncludeRole(block=block1, role=role1, task_include=ti1).load_data(data)
    assert ir

# Generated at 2022-06-23 07:15:00.244791
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.verbosity = 4
    include_role = IncludeRole.load({'name': 'foo'})
    result = include_role.get_name()
    assert result == include_role.action + ' : ' + 'foo'

    include_role.name = 'name'
    result = include_role.get_name()
    assert result == 'name'

    include_role = IncludeRole.load({'role': 'foo'})
    result = include_role.get_name()
    assert result == include_role.action + ' : ' + 'foo'

    include_role = IncludeRole.load({})
    result = include_role.get_name()
    assert result == include_role.action


# Generated at 2022-06-23 07:15:11.972060
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    ir = IncludeRole.load({'name': 'geerlingguy.memcached'})
    assert ir.action == 'include_role'
    assert ir.statically_loaded is True
    assert ir._role_name == 'geerlingguy.memcached'
    assert ir._role_path is None
    assert ir._public is False
    assert ir._allow_duplicates is True
    assert ir.rolespec_validate is True

    ir = IncludeRole.load({'name': 'geerlingguy.memcached', 'allow_duplicates': False})
    assert ir.action == 'include_role'
    assert ir.statically_loaded is True
    assert ir._role_name == 'geerlingguy.memcached'
    assert ir._role_path is None
    assert ir._public is False


# Generated at 2022-06-23 07:15:21.945987
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    test function get_name
    """

    # test basic case
    test_include = IncludeRole(role='role1')
    test_include._role_name = 'role1'
    assert test_include.get_name() == "include_role : role1"

    # test name
    test_include = IncludeRole(role='role1')
    test_include._role_name = 'role1'
    test_include.name = 'test-name'
    assert test_include.get_name() == 'test-name'

    # test error case
    test_include = IncludeRole(role='role1')
    test_include._role_name = None

# Generated at 2022-06-23 07:15:31.402867
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    # Initialize block
    block = Block(
        role=Role(),
        parent=Role(),
    )

    # Initialize role
    role = Role(
        name='test-role',
        rbac_apply_to=1,
        parent=block,
    )

    # Initialize task
    task = IncludeRole(
        role=role,
        block=block,
    )

    # Assert attributes
    assert task.get_name() == "tasks : test-role"
    assert task.vars_files == []
    assert task.tags == []

# Generated at 2022-06-23 07:15:41.395393
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.template import Templar

    data = {
        'name': 'test_role',
        'tasks_from': 'role2/tasks'
    }

    # Construct task_include for use in IncludeRole.load()
    task_include = TaskInclude(block=None)
    task_include.action = 'include_role'
    task_include.statically_loaded = True

    # Construct fake Role object to pass as parent_role to IncludeRole.load()
    fake_role = Role()
    fake_role._role_path = './fake_role'
    fake_role.name = 'fake_role'

# Generated at 2022-06-23 07:15:49.524299
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    task_include = TaskInclude(block=Block())

    # test copy
    include_role = IncludeRole(task_include=task_include)
    include_role._from_files['tasks'] = 'main.yml'
    include_role._parent_role = Role()
    include_role._role_name = 'some_role'
    include_role._role_path = 'path/to/some_role'
    include_role.statically_loaded = False
    include_role.allow_duplicates = True
    include_role.public = False
    include_role.rolespec_validate = True

    new_include_role = include_role.copy()

    assert new_include_role.statically_loaded == False
    assert new_include_role.allow_duplicates == True
    assert new_