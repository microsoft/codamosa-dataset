

# Generated at 2022-06-23 07:05:54.259684
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    This unit test checks result of get_name() with different values of self.name and self._role_name
    :return:
    """
    name = "name"
    role_name = "role_name"
    action = "action"

    i_r = IncludeRole()

    # 1) self.name == None, self._role_name == None
    # Expected: %s : %s" % (self.action, self._role_name)
    i_r.name = None
    i_r._role_name = None
    i_r.action = action
    assert i_r.get_name() == "%s : %s" % (i_r.action, i_r._role_name)

    # 2) self.name == None, self._role_name == role_name
    # Expected

# Generated at 2022-06-23 07:06:04.991027
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    def assert_equal(one, two):
        for k, v in one.__dict__.items():
            if k == '_parent':
                assert v is None
            elif str(k).startswith('_'):
                assert v == one.__dict__[k]
            else:
                assert v == two.__dict__[k]
    ir = IncludeRole(block=Block(), role=Role())
    ir.statically_loaded = True
    ir._from_files = {'tasks':'test_1.yml'}
    ir._parent_role = 'pr'
    ir._role_name = 'rn'
    ir._role_path = 'rp'
    new_ir = ir.copy(exclude_parent=False, exclude_tasks=False)

# Generated at 2022-06-23 07:06:09.139010
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block()
    task_include = TaskInclude()
    parent_role = Role()
    ir = IncludeRole(block, role, task_include)
    assert ir
    assert hasattr(ir, '_from_files')

# Generated at 2022-06-23 07:06:18.434971
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """
    Make sure that an IncludeRole is copied as expected
    """
    display = Display()
    class FakeBaseLoader:
        def __init__(self):
            self.path = "path"
        def get_basedir(self):
            return self.path

    class FakeBlock:
        def __init__(self):
            self.block  = [
                dict(
                    include="no",
                    tags=["a"],
                    action="action",
                    when="when",
                    loop="loop",
                    rescue="rescue1",
                    always="always1",
                    any_errors_fatal="any_errors_fatal1"
                )
            ]

        def get_task_blocks(self):
            return self.block


# Generated at 2022-06-23 07:06:29.294038
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    key_not_in_dict = 'key_not_in_dict'
    key_not_in_valid_args = 'key_not_in_valid_args'
    key_in_other_args = 'allow_duplicates'
    key_in_from_args = 'tasks_from'

    data = {
        key_not_in_dict: 'value_1',
        key_not_in_valid_args: 'value_2',
        key_in_other_args: 'value_3',
        key_in_from_args: 'value_4',
    }

    # Test for block
    block = Block(play=None)
    block.vars = {'item': 'value_5'}
    role = Role()
    role._role_name = 'role_name'
    role

# Generated at 2022-06-23 07:06:38.476550
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    import ansible.playbook.play
    from ansible.playbook.block import Block

    from ansible.playbook.play import Play
    
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    from  ansible.inventory import host, group

    from ansible.vars import IncludeVars

    # Create data loader
    loader = DataLoader()

    # Create inventory and pass to var manager


# Generated at 2022-06-23 07:06:40.286077
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: add tests
    pass


# Generated at 2022-06-23 07:06:49.689219
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # create simple parent play
    p = Block()
    # create main role
    main_role = Role()
    main_role_tasks_block = Block()
    main_role_tasks_block.block = [dict(action='main_role_task1', args=dict(a='a')), dict(action='main_role_task2', args=dict(b='b'))]
    main_role.compile(block=main_role_tasks_block)
    # create included role
    included_role = Role()
    included_role_tasks_block = Block()
    included_role_tasks_block.block = [dict(action='included_role_task1', args=dict(c='c')), dict(action='included_role_task2', args=dict(d='d'))]


# Generated at 2022-06-23 07:07:00.381559
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Execute a test to verify bug #21686 and the fix in PR #22473.
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager

    # create a fake role made up of a single block
    play_data = dict(
        name='PR_22473 Test - IncludeRole.get_block_list',
    )
    variable_manager = VariableManager()
    myplay = Play().load(play_data, variable_manager=variable_manager, loader=variable_manager._loader)
    test_tasks = [dict(action='debug', args=dict(msg='PR_22473 Test'))]
    test_role = Role()

# Generated at 2022-06-23 07:07:05.498426
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    def _fake_role(role_name, **kwargs):
        r = Role()
        r.name = role_name
        r.get_role_params = lambda: kwargs
        return r

    # Test 1
    ir1 = IncludeRole()
    ir1._parent_role = _fake_role('foo', in_bar=1, in_baz=2, in_quux=3)
    ir1._parent_role._parents = [_fake_role('bar', in_bar=1, in_baz=2, in_quux=3)]
    ir1._parent_role._parents.insert(0, _fake_role('baz', in_bar=1, in_baz=2, in_quux=3))


# Generated at 2022-06-23 07:07:17.021550
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    # Simple case with no parent
    ir = IncludeRole()
    ir._parent_role = None
    new_ir = ir.copy()

    assert ir == new_ir
    assert ir._parent_role is None
    assert new_ir._parent_role is None

    # Non-trivial case with parent
    pr = Role()
    pr._role_path = "/path/to/parent/role"
    ir._parent_role = pr
    ir.statically_loaded = True
    ir._from_files = {"tasks": "tasks.yml", "vars": "vars.yml"}
    ir._role_name = "role_name"
    ir._role_path = "/path/to/role"

    new_ir = ir.copy()

    assert ir == new_ir
    assert ir._parent_

# Generated at 2022-06-23 07:07:25.069282
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.role.definition import RoleDefinition

    # The value of role_parent (, role._parent_role) is a RoleDefinition, or a Role.
    # The method get_role_params of RoleDefinition returns a dict
    # The method get_role_params of Role returns a dict
    # The method get_include_params of IncludeRole returns a dict


# Generated at 2022-06-23 07:07:31.656408
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = "test_name"
    ir.action = "test_action"
    ir._role_name = "test_role_name"
    assert ir.get_name() == "test_name"
    ir.name = "test_name2"
    assert ir.get_name() != "test_name"
    ir.name = None
    assert ir.get_name() == "test_action : test_role_name"

# Generated at 2022-06-23 07:07:44.852541
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    display.verbosity = 3
    role = Role()
    role._role_path = 'test_role_path'
    role._metadata = dict(
        dependencies=dict(role_A=True, role_B=True),
        galaxy_info={}
    )
    ir = IncludeRole(role=role, task_include=TaskInclude(role=role))
    ir.name = 'test_include_role'
    ir._allow_duplicates = True
    ir._public = False
    ir._rolespec_validate = True
    ir.vars = {'foo': 'bar'}
    ir.statically_loaded = False
    ir._from_files = dict()
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'
    new_

# Generated at 2022-06-23 07:07:50.321748
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    role = Role()
    task_include = TaskInclude(block, role)

    ir = IncludeRole(block, role, task_include)
    assert ir._parent == block

# Generated at 2022-06-23 07:07:58.153617
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    role = Role()
    role._role_name = 'foo'
    role._role_path = '/path/to/foo'
    role._metadata = 'role_meta'
    arg_data = dict(
        name='bar',
        private='yes',
        role='foo',
        rolespec_validate=True,
        apply='apply_test',
        allow_duplicates=True,
        public=True,
        tasks_from='tasks_from_test',
        vars_from='vars_from_test',
        defaults_from='defaults_from_test',
        handlers_from='handlers_from_test',
    )

    # Initialize IncludeRole
    ir = IncludeRole(role=role)

# Generated at 2022-06-23 07:08:10.584563
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    # Test the copying of a IncludeRole object.
    ir = IncludeRole()
    ir._parent = 'parent'
    ir._parent_role = 'parent_role'
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'
    ir.apply = {'a': 1, 'b': 2}
    ir.args = 'args'
    ir.action = 'action'
    ir.any_errors_fatal = 'any_errors_fatal'
    ir.always_run = 'always_run'
    ir.allowed_includes = 'allowed_includes'
    ir.allow_duplicates = 'allow_duplicates'

# Generated at 2022-06-23 07:08:20.546778
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t  = Templar(pc)

    args = [{'name': 'myrolename'}, {'role': 'myrolename'}]
    for arg in args:
        myargs = {'action': '- include_role:', 'args': arg}
        ir = IncludeRole.load(myargs)

        myname = ir.get_name()

        assert myname == '- include_role: myrolename'

# Generated at 2022-06-23 07:08:32.694543
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    from ansible.utils.display import Display
    display = Display()

    data = {
        'name': 'test_name',
        'role': 'test_role',
        'tasks_from': 'test_tasks_from',
        'vars_from': 'test_vars_from',
        'defaults_from': 'test_defaults_from',
        'handlers_from': 'test_handlers_from',
        'apply': {
            'test': 'value',
            },
        'public': False,
        'allow_duplicates': True,
        }

    ir = IncludeRole.load(data=data, block=Block(), role=Role(), task_include=None)


# Generated at 2022-06-23 07:08:38.492104
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block_name = "Block name"
    role_name = "Role name"
    ir = IncludeRole(Block(block_name), Role(role_name))
    ir._role_name = "My Role"
    ir.name = "My Task"
    assert ir.get_name() == "My Task : My Role"
    ir.name = None
    assert ir.get_name() == "include_role : My Role"


# Generated at 2022-06-23 07:08:49.648504
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.role.include
    import ansible.template
    import ansible.vars.manager
    import ansible.vars.hostvars

    # Create the object that is normally created by the playbook loader
    from ansible.playbook import Play, Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DictDataLoader(dict())

   

# Generated at 2022-06-23 07:09:01.015865
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Constructor test without block or role
    ir = IncludeRole()
    assert ir._parent is None
    assert ir._name is None
    assert ir._role_name is None
    assert ir._role_path is None
    # Constructor test with block but without role
    b = Block()
    ir = IncludeRole(block=b)
    assert ir._parent == b
    assert ir._name is None
    assert ir._role_name is None
    assert ir._role_path is None
    # Constructor test without block but with role
    r = Role()
    ir = IncludeRole(role=r)
    assert ir._parent is None
    assert ir._name is None
    assert ir._role_name == r.name
    assert ir._role_path == r._role_path
    # Constructor test with both block and role
   

# Generated at 2022-06-23 07:09:14.093976
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import json
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    test_dir = "tests/units/module_utils/cloud/amazon/playbooks/test_IncludeRole_get_include_params_roles"
    roles_dir = os.path.join(tmp_dir, "roles")
    shutil.copytree(test_dir, roles_dir)

    def _load_role(role_path):
        data = open(role_path).read()
        data = json.loads(data)
        block = Block.load(data, play=None)
        return block.block


    # Testing empty parent role
    base = _load_role(os.path.join(roles_dir, "base", "meta", "main.yml"))

   

# Generated at 2022-06-23 07:09:16.013068
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-23 07:09:26.289962
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # create a Block to hold the IncludeRole
    test_block = Block()
    # create a task
    mytask = IncludeRole()
    mytask.name = "something"
    mytask.allow_duplicates = False
    mytask.args = dict()
    mytask.args['vars_from'] = 'testfile.yml'
    # add the task to the Block
    test_block.block = [mytask]
    # copy the IncludeRole task to a new variable
    mytask_copy = mytask.copy()
    # check that the variable is of the type IncludeRole
    assert(isinstance(mytask_copy,IncludeRole))
    # check the copied variable has the same value of the variable which the copy was made from
    assert(mytask_copy.name == mytask.name)

# Generated at 2022-06-23 07:09:36.362808
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    task_loader = AnsibleLoader()
    role_loader = RoleLoader()

    # create a fake role with one block and append a task to it
    def create_fake_role(name, task_file):
        r = Role().load({'name': name})
        b = Block().load({'name': name})
        task_data = yaml.load(open(task_file))
        b.append(task_loader.load(task_data, variable_manager=None, loader=None))
        r._compiled_block_list = [b]
        return r

    # create a fake role for each role in the test file

# Generated at 2022-06-23 07:09:41.904393
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # We have to do the following dance because the field __class__ is not copied by the
    # copy.copy() function.  This is because __class__ is not a class attribute; it's
    # a special attribute
    ir_dict = IncludeRole().__dict__.copy()
    ir_copy_dict = ir_dict.copy()
    IncludeRole().__dict__ = ir_copy_dict
    ir_copy = IncludeRole().copy()
    IncludeRole().__dict__ = ir_dict

    assert (ir_copy.__class__ == IncludeRole())

# Generated at 2022-06-23 07:09:51.984925
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''Test function get_include_params of class IncludeRole'''

    my_class = IncludeRole()
    # Test empty case
    result = my_class.get_include_params()

    if not isinstance(result, dict):
        raise AssertionError('returned value "%s" of type "%s" is not a dictionary as expected' % (result, type(result)))

    if result:
        raise AssertionError('returned dictionary is not empty as expected')

    # Test with parent role
    class MockRole(object):
        '''Mock class to test IncludeRole'''

        def __init__(self):
            self.name = 'role_name'
            self._role_path = '/path'

        def get_name(self):
            return self.name


# Generated at 2022-06-23 07:09:54.272652
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    a = IncludeRole()
    assert not a._allow_duplicates
    assert not a._public
    assert a._rolespec_validate

# Generated at 2022-06-23 07:10:01.422191
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    b = Block(parent_block=Block())
    r = Role()
    t = IncludeRole(block=b, role=r)

    # from_files dict should be copied in copy
    t._from_files = {'tasks': 'tasks.yml'}

    new_me = t.copy(exclude_tasks=True)

    assert 'tasks' in new_me._from_files


# Generated at 2022-06-23 07:10:08.910667
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole(block=Block(), role=Role())
    ir.name = 'test'
    ir._parent_role = 'role'
    ir._role_name = 'role_name'
    ir._role_path = 'role_path'
    ir._from_files = {'default': None}

    result = ir.copy()

    assert result.name == ir.name
    assert result._parent_role == ir._parent_role
    assert result._role_name == ir._role_name
    assert result._role_path == ir._role_path
    assert result._from_files == ir._from_files
    assert result.statically_loaded == ir.statically_loaded
    assert result.action == ir.action
    assert result.loop is None
    assert result.when is None
    assert result.unless is None


# Generated at 2022-06-23 07:10:14.904078
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class FakeParent(object):
        def get_role_params(self):
            return {"ansible_role_params_foo": "foo"}
        def get_name(self):
            return "foo"
    class FakePlay(object):
        def __init__(self, loader):
            self.loader = loader
    class FakeVarMgr(object):
        def __init__(self, play):
            self.play = play
        def get_vars(self, task=None, play=None, host=None):
            return {"ansible_play_vars_foo": "foo"}

    # Create a fake loader for lookup plugins
    class FakeLoader(object):
        def __init__(self, basedir):
            self.basedir = basedir

# Generated at 2022-06-23 07:10:19.431403
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    loader = FakeLoader()
    sources = 'localhost,'
    vault_password = None
    inventory = InventoryManager(loader=loader, sources=sources)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=''))
            ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # for a static role
    block = Block()
    role = Role()
    role._role_

# Generated at 2022-06-23 07:10:24.746925
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    my_block = Block()

    my_role = Role()
    my_mi = IncludeRole(block=my_block, role=my_role)

    assert(my_mi.parent == my_block)
    assert(my_mi._parent_role == my_role)
    assert(my_mi.args == {})

    my_mi._role_name = 'my_role'
    assert(my_mi._role_name == 'my_role')

# Generated at 2022-06-23 07:10:36.452383
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.playbook.role.definition

    test_obj = ansible.playbook.role.definition.RoleDefinition()
    test_obj.task_loader = None
    test_obj.role_loader = None
    test_obj.variable_manager = None

    def _set_args(module_name,module_args='',task_name=None,task_args=None):
        if module_name is not None:
            m = ansible.playbook.block.Block()
            m.module_name = module_name
            test_obj.module_name = module_name
            test_obj.action = m
            if module_args is not None:
                test_obj.args = module_args
        if task_name is not None:
            t = ansible.playbook.task.Task()
            t.name

# Generated at 2022-06-23 07:10:41.465709
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block()
    role = Role()
    task_include = RoleInclude()
    ir = IncludeRole(block, role, task_include)

    res = ir.get_name()
    assert res == 'include_role: None'



# Generated at 2022-06-23 07:10:52.698805
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import copy, os, sys

    # --------------------
    # IncludeRole.load()
    # --------------------
    # @mock.patch('ansible.playbook.role.Role.load')
    # @mock.patch('ansible.playbook.role.include.RoleInclude.load')
    # def test_load(self, mock_ri, mock_r):
    #     ''' test IncludeRole.load() '''
    #
    #     mock_ri.return_value = 'fake_role_include'
    #     mock_r.return_value = 'fake_role'
    #
    #     # Missing role name in load args data
    #     args = {'blah': 'blah'}
    #     data = copy.deepcopy(self._IncludeRole_data)
    #     data['include_role

# Generated at 2022-06-23 07:11:02.438089
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    main_role = Role()
    main_role.name = 'main_role'
    main_role.role_path = '/home/user/path/main_role'
    test_params = {"test": "OK"}
    block1 = Block()
    task1 = IncludeRole()
    role1 = Role()
    role1.name = 'role1'
    role1.role_path = '/home/user/path/role1'
    role1.params = test_params
    block1._parent = role1
    task1._parent = block1
    task1._parent_role = role1
    task1.collections = ['col1',]

    assert task1.get_include_params() == test_params

# Generated at 2022-06-23 07:11:03.505581
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole().get_name() is not None

# Generated at 2022-06-23 07:11:14.182206
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    role_name = 'test_role'
    role_path = './test/test_play/test_play_roles/' + role_name
    block = Block(loader=DataLoader(), role=Role(), parent_block=[], role_hierarchy=[role_path])
    variable_manager = VariableManager()
    loader = DataLoader()

    # Load data using method load

# Generated at 2022-06-23 07:11:24.336026
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    class Play(object):
        pass
    p = Play()
    p.vars = dict()
    
    class Block(object):
        pass
    b = Block()
    b._play = p
    b._parent = None
    b._load_name = 'test_include_role'
    b._role_name = 'test_include_role'

    class Role(object):
        pass
    r = Role()
    r.get_role_params = get_role_params
    r.get_name = get_name

    class IncludeRole(object):
        pass
    ir = IncludeRole()
    ir._parent_role = r
    ir._role_name = 'test_include_role'

    # Test

# Generated at 2022-06-23 07:11:35.231905
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext

    vars_manager =  None # FIXME
    loader = None # FIXME
    play = None # FIXME

    # Test case with one task (not a block)
    playbook_yml = """
    - name: setup
      role: /tmp/ansible_2.9.0/tests/unit/modules/test_include_role/deps/role_a
    """
    block = Block.load(playbook_yml, play=play, task_include=None, variable_manager=vars_manager, loader=loader)
    tasks = block.block

    tasks[0]._parent_role = None

# Generated at 2022-06-23 07:11:38.014383
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()



# Generated at 2022-06-23 07:11:49.787717
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Setup
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = AnsibleLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-23 07:12:00.691929
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 3
    loader = DataLoader()
    role_name = 'test_role'
    path = loader.path_dwim_relative(None, 'test_data/test_role', '')
    test_role = RoleDefinition.load(role_name, path, loader, variable_manager=None)
    test_role.compile()
    role_block = test_role.get_block()

    block = Block()
    role = Role()
    role.compile()
    role.add_parent(role_block)

    # IncludeRole('- include_role: test_role')
    include_role = IncludeRole()

# Generated at 2022-06-23 07:12:12.306607
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import fragment_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class UtClass(object):
        def __init__(self):
            self._dfs = False

    def load_utils():
        return UtClass()

    # fragment_loader.get('.')
    # fragment_loader.get('..')

    # collection_list = ['ansible.builtin']
    collection_list = []

    ###################################################################################
    # collection default role

    role = Role()
    role.name = "test_default_collection"
    # role.apply = dict(omit)


# Generated at 2022-06-23 07:12:18.824501
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext

    role_name = 'test_role'
    parent_role = Role()
    parent_role._role_path = '/path/to/' + role_name
    parent_role.name = role_name

    ir = IncludeRole()
    ir._parent_role = parent_role

    pc = PlayContext()
    print(ir.get_include_params())
    assert ir.get_include_params() == {'ansible_parent_role_names': [role_name], 'ansible_parent_role_paths': [parent_role._role_path]}

# Generated at 2022-06-23 07:12:27.150250
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.meta import RoleMeta
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # build first three roles in dep_chain
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'name': 'default'}


# Generated at 2022-06-23 07:12:38.510760
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    context = PlayContext()

    context.roles = []
    context.become = False
    context.become_method = ''

    pb = Play()

    pb.get_variable_manager = lambda: VariableManager()

    ir = IncludeRole.load(dict(
        include='role_name',
    ))

    ir = IncludeRole.load(dict(
        include='role_name',
        static=True,
    ))


# Generated at 2022-06-23 07:12:47.536989
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    """
      test file for method get_block_list of class IncludeRole
    :return:
    """

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_native

    if PY3:
        builtin_open = 'builtins.open'
    else:
        builtin_open = '__builtin__.open'


    # use a dummy display class to capture task start/end
    class MyDisplay(Display):
        def __init__(self):
            self.task_calls = []
            self.task_items = []


# Generated at 2022-06-23 07:12:55.645502
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import yaml
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # declare a role
    role_data = yaml.safe_load('''
    [
      {
        "role": {
          "__ansible_module__": "test",
          "args": {
            "name": "test-role",
            "tasks_from": "test"
          }
        }
      },
      {
        "set_fact": {
          "name": "test-role",
          "some-var": "test"
        }
      }
    ]''')
    role_data[0]['role']['args']['tasks_from'] = 'test'

    # load test
    variable_manager = VariableManager()
    loader = DataLoader

# Generated at 2022-06-23 07:13:07.526134
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Create a IncludeRole object
    ir = IncludeRole()

    # Set some parameter value
    ir.statically_loaded = False
    fre = {'tasks': [None], 'handlers': [None], 'vars': [None], 'defaults': [None]}
    ir._from_files = fre
    ir._role_name = 'test_name'
    ir._role_path = 'test_path'

    # Call copy
    ir_copy = ir.copy()

    # Check copy
    assert ir_copy is not None
    assert ir_copy.statically_loaded == ir.statically_loaded
    assert ir_copy._from_files == ir._from_files
    assert ir_copy._role_name == ir._role_name
    assert ir_copy._role_path == ir._role_path

# ------------------------------------------------------------------------------

# Generated at 2022-06-23 07:13:13.884239
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    loader = 'Fake loader'
    variable_manager = 'Fake variable manager'
    ri = IncludeRole.load({'name': 'test'}, loader=loader, variable_manager=variable_manager)
    assert 'include_role' == ri.action
    assert 'test' == ri._role_name
    assert ri.get_name() == 'test'
    # Test if name is empty
    loader = 'Fake loader'
    variable_manager = 'Fake variable manager'
    ri = IncludeRole.load({'role': 'test'}, loader=loader, variable_manager=variable_manager)
    assert 'include_role' == ri.action
    assert 'test' == ri._role_name
    assert ri.get_name() == 'include_role : test'


# Generated at 2022-06-23 07:13:14.523912
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    pass

# Generated at 2022-06-23 07:13:23.190046
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # test cases
    import os


# Generated at 2022-06-23 07:13:29.876551
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    t = IncludeRole()
    for key in ['statically_loaded', '_from_files', '_parent_role', '_role_name', '_role_path']:
        setattr(t, key, 'dummy_value')

    t2 = t.copy()

    for key in ['statically_loaded', '_from_files', '_parent_role', '_role_name', '_role_path']:
        assert getattr(t, key) == getattr(t2, key)

# Generated at 2022-06-23 07:13:41.849116
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Check method when no parent role is defined
    ir = IncludeRole()
    assert ir.get_include_params() == {}

    # Check method when no variables defined in parent role
    ir = IncludeRole()
    ir._parent_role = Role()
    assert ir.get_include_params() == {}

    # Check method when parent role defines variables
    ir = IncludeRole()
    ir._parent_role = Role()
    ir._parent_role._role_params = {'role_var':'value'}
    assert ir.get_include_params() == {'role_var':'value'}

    # Check method when parent role has parent
    ir = IncludeRole()
    parent_role = Role()
    parent_role._role_params = {'parent_role_var':'value2'}

# Generated at 2022-06-23 07:13:42.283091
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-23 07:13:54.266228
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    loader = None
    variable_manager = None
    role1 = Role()
    role1._role_path = 'role1'
    role1._metadata = {frozenset({}): {}}
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    play.roles.append(role1)
    include_role = IncludeRole.load({'name': 'role1'}, play=play)
    include_role._parent_role = role1
    include_role._parent = Block()
    include_role._parent.play = play
    include_role._parent.play.roles = play.roles
    role2 = Role()
    role2._role_path = 'role2'


# Generated at 2022-06-23 07:14:07.972863
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    import os

    if not os.path.exists('/tmp/test_playbook.yml'):
        with open('/tmp/test_playbook.yml', 'w') as fp:
            fp.write('---\n')
            fp.write('- hosts: localhost\n')
            fp.write('  gather_facts: False\n')
            fp.write

# Generated at 2022-06-23 07:14:18.473938
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    data = dict(
        name="test_name",
        apply=dict(
            x=1,
            y=2
        ),
        tasks_from="tasks",
        allow_duplicates=True,
        public=False,
        rolespec_validate=True
    )
    ir = IncludeRole.load(data)
    params = ir.get_include_params()
    assert(params["role_name"] == "test_name")
    assert(params["x"] == 1)
    assert(params["y"] == 2)
    assert(params["tasks_from"] == "tasks")
    assert(params["allow_duplicates"] == True)
    assert(params["public"] == False)
    assert(params["rolespec_validate"] == True)

# Generated at 2022-06-23 07:14:30.575341
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # create an IncludeRole object to test its get_include_params method
    import ansible.playbook.play
    import ansible.playbook.role

    block = Block()
    variable_manager = ansible.vars.manager.VariableManager()
    loader_mock = ansible.parsing.dataloader.DataLoader()
    play = ansible.playbook.play.Play().load(dict(
        name = "test",
        hosts = "localhost",
        gather_facts = "no",
        roles = [
            dict(
                include_role = dict(
                    name = "test_role",
                    tasks_from = "/tmp/test_role/tasks/test_task.yml",
                )
            )
        ]
    ), variable_manager=variable_manager, loader=loader_mock)



# Generated at 2022-06-23 07:14:34.531682
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ''' unit test for get_name method of class IncludeRole '''
    ir = IncludeRole()
    ir._action = 'include_role'
    ir._role_name = 'role_name'
    assert 'include_role : role_name' == ir.get_name()

# Generated at 2022-06-23 07:14:45.762154
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play = Play()
    play._variable_manager = variable_manager

    block = Block()

    data = {'name':'test_role'}
    include_role = IncludeRole.load(data=data, block=block, task_include=None)

    (blocks, handlers) = include_role.get_block_list(play=play)

    assert(len(blocks) == 1)

    block = blocks[0]

# Generated at 2022-06-23 07:14:56.354905
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    role = ansible.playbook.role.Role()
    role.name = 'test'
    role._role_path = '/path/to/role'
    role.params = {'test1': 'test1', 'test2': 'test2'}
    task_include = IncludeRole(role=role)
    result = task_include.get_include_params()
    assert 'ansible_parent_role_names' in result
    assert 'ansible_parent_role_paths' in result
    assert 'test1' in result
    assert 'test2' in result
    assert result['ansible_parent_role_names'] == ['test']
    assert result['ansible_parent_role_paths'] == ['/path/to/role']

# Generated at 2022-06-23 07:15:09.264161
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    assert(IncludeRole().get_include_params() == {'ansible_role_names': [],
                                                 'ansible_role_paths': [],
                                                 'ansible_parent_role_names': [],
                                                 'ansible_parent_role_paths': []})
    assert(IncludeRole(role=Role()).get_include_params() == {'ansible_role_names': [],
                                                             'ansible_role_paths': [],
                                                             'ansible_parent_role_names': ['<default>'],
                                                             'ansible_parent_role_paths': ['<default>']})

# Generated at 2022-06-23 07:15:20.235358
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = AnsibleCollectionLoader()
    blocks = []
    pb = Playbook.load('playbook_get_block_list.yml', loader=loader)
    collection_list = pb.get_collections(loader)
    pb._entries[0]._

# Generated at 2022-06-23 07:15:33.368287
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    mock_loader= lambda: None
    mock_loader.file_basedir = '.'
    mock_play_context = PlayContext()
    test_block = Block.load('', dict(tasks=[]) , play=mock_play_context, loader=mock_loader, role=None)
    test_block._parent = None
    test_block._role = None
    test_block._play = mock_play_context
    test_role = Role.load(dict(name='test_role'), mock_play_context, parent_role=None)
    test_task_include = IncludeRole(block=test_block, role=test_role, task_include=None)
    test_task_include._role_name = 'test_role'
    test_task_include

# Generated at 2022-06-23 07:15:36.816622
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_IncludeRole = IncludeRole()
    test_IncludeRole._role_name = "my_role"
    assert test_IncludeRole.get_name() == "include_role : my_role"


# Generated at 2022-06-23 07:15:45.766170
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    """Make sure IncludeRole.copy() works."""
    import ansible.playbook
    import ansible.playbook.role
    tasks = [
        dict(action='include_role', args=dict(name='role1')),
        dict(action='fail', args=dict(msg='should not copy this')),
    ]

# Generated at 2022-06-23 07:15:52.245875
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole(role=None)
    ir.block = Block()
    ir.block._role = Role()
    ir.block._play = None
    ir.name = "name"
    ir.action = "action"
    ir.statically_loaded = True
    ir._from_files = {'test_key': 'test_value'}
    ir._parent_role = Role()
    ir._role_name = "role_name"
    ir._role_path = "role_path"
    ir.vars = {"test_var_key": "test_var_value"}
    ir.args = {"test_args_key": "test_args_value"}

    new_me = ir.copy()

    assert ir.block == new_me.block
    assert ir.name == new_me.name