

# Generated at 2022-06-23 07:05:48.129068
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    ir._parent_role = Role()
    new_ir = ir.copy()
    assert ir._parent_role is not new_ir._parent_role


# Generated at 2022-06-23 07:05:54.871978
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # A role include with no parent role
    ir1 = IncludeRole(block=Block, role=None)

    # A role include with a parent role
    ir2 = IncludeRole(block=Block, role=Role())

    # Test
    assert ir1.get_include_params() == {}
    assert ir2.get_include_params() == ir2._parent_role.get_role_params()

# Generated at 2022-06-23 07:05:57.485759
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert isinstance(ir, IncludeRole)
    assert isinstance(ir, TaskInclude)
    assert isinstance(ir, Block)

# Generated at 2022-06-23 07:06:07.513214
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display = Display()
    display.verbosity = 3
    ir = IncludeRole()
    ir._role_name = 'git'
    ir._role_path = '/home/sheep/ansible-role-git'
    ir._parent_role = None

    # Method get_block_list of class IncludeRole
    # If a role have no sub-role (role-dependency)
    # Expected result is a list of ansible.playbook.block.Block instance
    result = ir.get_block_list()
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert id(result[0]) == id(result[1])
    assert len(result[0]) == 0
    for block in result[0]:
        assert isinstance(block, Block)

    # If a role has a sub-role

# Generated at 2022-06-23 07:06:17.850223
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Setup Ansible for unit test
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.parsing.dataloader

    # We are using Ansible objects directly instead of using the AnsibleModule
    # interface

    # Create a fake inventory (which is always needed)
    parser = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader=parser, sources='localhost,')

    # Create a fake play with a task

# Generated at 2022-06-23 07:06:28.805673
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # create a mock role
    hostvars = dict(foo='bar')
    role = dict(
        name='foo',
        tasks=['/tmp/tasks.yml'],
        handlers=['/tmp/handlers.yml'],
        vars=['/tmp/vars.yml'],
        defaults=['/tmp/defaults.yml'],
        meta=['/tmp/meta.yml'],
        files=['/tmp/files.yml']
    )
    role_name = role['name']
    role_path = '/tmp/foo'

    # create a mock task

# Generated at 2022-06-23 07:06:38.711124
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    Test validate get_include_params method
    """
    block = Block()
    role = Role()
    role._role_path = '/roles/test/'
    role.name = 'test'
    task_include = TaskInclude()

    ir = IncludeRole(block=block, role=role, task_include=task_include)
    assert ir.get_include_params() == {'role_path': '/roles/test/', 'role_name': 'test', 'ansible_role_name': 'test', 'ansible_role_path': '/roles/test/',
                            'ansible_parent_role_names': ['test'], 'ansible_parent_role_paths': ['/roles/test/']}

# Generated at 2022-06-23 07:06:43.896298
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Needs to be here because Includerole uses the Role class
    class TestRole():
        def __init__(self):
            self._parents = ['parent']
            self._role_path = 'path'
            self.metadata = {'allow_duplicates': False}

    class TestRoleInclude():
        def __init__(self):
            self.collections = 'collections'

    block = Block(parent=None, role=None)

    test_include_role = IncludeRole(block=block, role=TestRole())
    test_include_role._parent_role = TestRoleInclude()
    test_include_role._role_path = 'path'
    test_include_role._role_name = 'name'
    test_include_role.vars = 'vars'
    test_include_role.t

# Generated at 2022-06-23 07:06:48.187100
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    role = IncludeRole()

    role.name = 'testTaskName'
    assert role.get_name() == 'testTaskName'
    role.name = None
    role._role_name = 'testRoleName'
    assert role.get_name() == 'include_role : testRoleName'


# Generated at 2022-06-23 07:06:58.223975
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    block._play = Play()
    task_include = TaskInclude()
    task_include.__dict__['_task_fields'] = ['args', 'action', 'delegate_to', 'name']

    ir = IncludeRole(block=block, task_include=task_include)
    ir.args = dict(name='apache', tasks_from='main')
    ir._parent_role = None
    ir._role_name = 'apache'
    ir._role_path = None
    
    new_me = ir.copy()

    assert new_me == ir, "expect %s but got %s" % (ir, new_me)



# Generated at 2022-06-23 07:07:04.310356
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    with open(os.path.join(os.path.dirname(__file__), 'test_data', 'include.yaml')) as f:
        data = yaml.safe_load(f)

    include = IncludeRole.load(data, loader=DictDataLoader())
    assert include.action == 'include'
    assert include.name == 'include just for unit test.'
    assert include.statically_loaded == False
    assert include.allow_duplicates == True
    assert include.public == False
    assert include.rolespec_validate == True
    assert include._from_files.get('tasks') == 'tasks/main.yml'
    assert include._from_files.get('vars') == 'vars/main.yml'

# Generated at 2022-06-23 07:07:16.505070
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    class Block(object):
        pass
    class Role(object):
        pass
    class TaskInclude(object):
        pass
    block_obj = Block()
    role_obj = Role()
    obj = IncludeRole(block=block_obj, role=role_obj, task_include=TaskInclude())
    obj.action = 'role'
    obj.name = 'some_role'
    assert obj.get_name() == 'some_role'
    obj.name = None
    obj._role_name = 'some_role'
    assert obj.get_name() == 'role : some_role'
    obj.name = 'some_role'
    assert obj.get_name() == 'some_role'
    obj.name = None
    obj._role_name = None

# Generated at 2022-06-23 07:07:24.760997
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Role

    play_context = PlayContext()
    loader = False
    variable_manager = False
    # -----
    # This IncludeRole statement has one of each from_attribute we wish to test
    # It also is the minimum required structure with a single task

# Generated at 2022-06-23 07:07:34.110011
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # test with exclude_tasks=True, exclude_parent=True
    test_object = IncludeRole()
    new_object = test_object.copy(exclude_tasks=True, exclude_parent=True)
    assert new_object._role is None
    assert new_object._parent is None
    assert new_object._parent_role is None
    assert new_object.handler is None
    assert new_object.block is None 
    assert new_object.always is None
    assert new_object.changed_when is None
    assert new_object.failed_when is None
    assert new_object.until is None
    assert new_object.retries is None
    assert new_object.delay is None
    assert new_object.first_available_file is None
    assert new_object._role_name is None
    assert new

# Generated at 2022-06-23 07:07:47.509944
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # First create an IncludeRole object
    from units.mock.loader import DictDataLoader

# Generated at 2022-06-23 07:07:56.084475
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    block = Block()
    role = Role()

    #include_role without args
    ir = IncludeRole(block=block, role=role)
    ir.args = {'name': 'TestRole'}
    ir.statically_loaded = True
    ir._from_files = {'tasks': 'main.yml'}
    ir._parent_role = role
    ir._role_name = 'TestRole'
    ir._role_path = '/path/to/TestRole'
    ir.action = 'include_role'
    ir.allow_duplicates = True
    ir.apply = 'Test_apply'
    ir.delegate_to = 'Test_delegate_to'
    ir.delimiters = ('(', ')')
    ir.loop = 'Test_loop'
    ir.loop_arg

# Generated at 2022-06-23 07:08:01.041576
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.plugins.loader import action_loader, module_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.vault import VaultSecret

    class TestIncludeRole(IncludeRole):
        def __init__(self):
            class TestVars():
                def __init__(self):
                    self._valid_attrs = set()
                    self._data = {}

                # Mock the behaviour of object AttributeDict from objects.py

# Generated at 2022-06-23 07:08:12.950490
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    ir = IncludeRole()
    new_ir = ir.copy()

    assert ir is not new_ir
    assert ir.vars is not new_ir.vars
    assert ir._parent is new_ir._parent
    assert ir._parent_role is new_ir._parent_role
    assert ir._role_name is new_ir._role_name
    assert ir._role_path is new_ir._role_path
    assert ir._allow_duplicates is new_ir._allow_duplicates
    assert ir._public is new_ir._public
    assert ir._rolespec_validate is new_ir._rolespec_validate
    assert ir.statically_loaded is new_ir.statically_loaded
    assert ir.tasks is new_ir.tasks
    assert ir.conditional is new_ir.cond

# Generated at 2022-06-23 07:08:21.785571
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    import unittest
    from ansible.playbook.task import Task

    class TestIncludeRole(unittest.TestCase):
        def test_get_name(self):
            ir = IncludeRole()
            ir.action = 'include_role'
            ir._role_name = 'my_role'
            self.assertEqual(ir.get_name(), 'include_role : my_role')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestIncludeRole)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 07:08:32.828725
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():

    data = {}
    block = Block(parent=None)
    role = Role()
    task_include = TaskInclude()

    # Init IncludeRole
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir.action = 'test_action'
    ir.name = 'test_name'
    ir.when = 'test_when'
    ir.async_val = 'test_async_val'
    ir.poll = 'test_poll'
    ir.ignore_errors = 'test_ignore_errors'
    ir.first_available_file = 'test_first_available_file'
    ir.include_tasks = 'test_include_tasks'
    ir.include_role = 'test_include_role'

# Generated at 2022-06-23 07:08:35.685264
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.deprecated('The IncludeRole module is not tested here. This is just a placeholder required for test-base to avoid No module named IncludeRole \'errors\'')
    assert True

# Generated at 2022-06-23 07:08:43.534280
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ir = IncludeRole()
    ir.statically_loaded = True
    ir._from_files = {'tasks_from':'filename1','vars_from':'filename2','defaults_from':'filename3','handlers_from':'filename4'}
    ir._parent_role = Role()
    ir._role_name = 'RoleName'
    ir._role_path = '/etc/ansible/roles'
    new_ir = ir.copy()
    assert new_ir.statically_loaded == True

# Generated at 2022-06-23 07:08:47.616138
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {}
    role = Role()
    role.apply_defaults()
    expected = IncludeRole(role=role)
    actual = IncludeRole.load(data, role.get_default_block(), role)
    assert expected == actual

# Generated at 2022-06-23 07:08:58.738274
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    pb_ex = PlaybookExecutor()
    pb_ex._tqm = None
    play_context = PlayContext()
    inventory = InventoryManager(loader=pb_ex._loader, sources='localhost,')

# Generated at 2022-06-23 07:09:06.685747
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    block = Block.load(dict(roles=[
        {'name': 'include_role'},
    ]))
    ir = IncludeRole(block=block, role=Role())
    ir.args = {'name': 'foo', 'static': True}
    assert ir.get_name() == 'include_role : foo'

    ir.args = {'name': 'foo', 'static': False}
    assert ir.get_name() == 'include_role : foo'

    ir = IncludeRole(block=block, role=Role())
    ir.args = {'role': 'foo', 'static': True}
    assert ir.get_name() == 'include_role : foo'

    ir.args = {'role': 'foo', 'static': False}
    assert ir.get_name() == 'include_role : foo'



# Generated at 2022-06-23 07:09:18.620295
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    ##############
    #
    # Construct a static IncludeRole object
    #
    ##############

    # Construct a static IncludeRole object
    # Construct a static Block object
    block1 = Block()
    # Construct a static Role object
    role1 = Role()
    include_role1 = IncludeRole(block1, role1)

    # (Static) role attribute is a Role object
    assert isinstance(include_role1.role, Role)
    # (Static) role attribute is role1
    assert include_role1.role is role1
    # (Static) role attribute is None
    assert IncludeRole(block1).role is None
    # (Static) block attribute is a Block object
    assert isinstance(include_role1.block, Block)
    # (Static) block attribute is block1

# Generated at 2022-06-23 07:09:27.118595
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    block = Block(play=None)
    role = Role()
    role._role_params = {'role_param': 'role_param_value'}
    task_include = TaskInclude()

    ir = IncludeRole(block=block, role=role, task_include=task_include)
    ir._role_name = 'test_role_name'
    ir._role_path = 'test_role_path'

    v = ir.get_include_params()

    # Test role param
    assert v['role_param'] == 'role_param_value'

    # Test parent role name
    assert v['ansible_parent_role_names'][0] == ir.get_name()

    # Test parent role path
    assert v['ansible_parent_role_paths'][0] == ir._role_path



# Generated at 2022-06-23 07:09:31.081424
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir._role_name = "role_name"
    assert ir.get_name() == "%s : role_name" % 'include_role'

# Generated at 2022-06-23 07:09:42.800838
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    class Play:
        def __init__(self):
            self.vars = {}

    class ParentRole:
        def __init__(self, p_name, p_path):
            self._name = p_name
            self._role_path = p_path
        def get_name(self):
            return self._name
        def get_role_params(self):
            return {'ansible_parent_role_name': self._name, 'ansible_parent_role_path': self._role_path}

    class RoleInclude:
        def __init__(self, r_name):
            self._name = r_name
            self.vars = {}
        def get_name(self):
            return self._name


# Generated at 2022-06-23 07:09:55.991248
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    data = {
        'hosts': 'all',
        'vars': {
            'foo': 'bar'
        },
        'tasks': [
            {
                'include_role': {
                    'name': 'test'
                },
                'include': 'other'
            }
        ]
    }
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    pb = Playbook.load(data, variable_manager=VariableManager(), loader=DataLoader())
    block = pb.get_plays()[0]._included_files[0]
    include_role = block.block[0]
   

# Generated at 2022-06-23 07:10:05.411031
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    import ansible.playbook.role
    import ansible.utils.vars
    class SampleInput(object):
        pass
    role_name='my_role'
    role_path='/path/to/my/role'
    parent_role=SampleInput()
    parent_role.get_role_params=ansible.playbook.role.Role.get_role_params
    parent_role.get_name=lambda x: role_name
    parent_role._role_path=role_path
    ir=IncludeRole()
    ir._parent_role=parent_role
    assert ir.get_include_params()=={'ansible_parent_role_names':[role_name], 'ansible_parent_role_paths':[role_path]}

# Generated at 2022-06-23 07:10:10.716830
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    a = IncludeRole()
    assert a.get_name() is None
    a.name = ''
    assert a.get_name() == ''
    a.name = 'test'
    assert a.get_name() == 'test'
    a._role_name = 'test2'
    assert a.get_name() == 'test'
    a.name = None
    assert a.get_name() == 'test : test2'

# Generated at 2022-06-23 07:10:20.135908
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.role.include
    import ansible.playbook.block
    import ansible.executor.playbook_executor


    # Simple use case: no parent_role or dep_chain or apply_attrs
    role_name = 'my_role'
    args = {'role': role_name}
    ir = IncludeRole()
    ir.load_data(args)

    play = ansible.playbook.Play()
    play.post_validate(templar=None)


# Generated at 2022-06-23 07:10:28.374233
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.plugins.loader import action_loader
    import os.path

    # The source code of the role test_role get_include_params is as follows:
    #
    #

# Generated at 2022-06-23 07:10:38.129568
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader, action_loader
    from ansible.parsing.vault import VaultLib

    display.verbosity = 3
    import sys
    import json
    sys.path.append('/home/vagrant/ansible/lib/ansible/plugins/roles')

    p = Play().load(dict(
        name = "ir test play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [ 'foo' ]
        ),
        variable_manager = None,
        loader = None)

    tqm = None

# Generated at 2022-06-23 07:10:48.085122
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    import ansible.playbook.role
    import ansible.playbook.block
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.play import Play
    import ansible.utils.display

    class MyBlock(Block):
        pass

    role = Role()
    block = MyBlock()
    my_task = TaskInclude(block=block, role=role)

    new_me = my_task.copy(exclude_parent=False, exclude_tasks=False)
    assert new_me.action == my_task.action
    assert new_me

# Generated at 2022-06-23 07:10:58.761443
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test for include_role
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts import default_fact_collection
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # initialize
    play_context = PlayContext()

# Generated at 2022-06-23 07:11:08.337601
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test setup

    test_Role = Role()
    test_Role._role_name = 'test role name'

    test_Block = Block()
    test_Block._role = test_Role

    # Test without role
    test_data = {}
    test_variable_manager = None
    test_loader = None

    _IncludeRole = IncludeRole()
    _IncludeRole_load = _IncludeRole.load(test_data, block = test_Block, variable_manager = test_variable_manager, loader = test_loader)

    assert _IncludeRole_load._parent_role == test_Role
    assert _IncludeRole_load._role_name == None

    # Test with role

# Generated at 2022-06-23 07:11:09.278431
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    ir = IncludeRole()
    assert ir is not None

# Generated at 2022-06-23 07:11:20.288549
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    def test_load(obj_data, expected_name, expected_role_name, expected_allow_duplicates, expected_public, expected_rolespec_validate):
        obj = IncludeRole.load(
            obj_data,
            block=dict(name='test_block')
        )
        assert obj.name == expected_name
        assert obj._role_name == expected_role_name
        assert obj.allow_duplicates == expected_allow_duplicates
        assert obj.public == expected_public
        assert obj.rolespec_validate == expected_rolespec_validate


# Generated at 2022-06-23 07:11:20.974186
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    Block()

# Generated at 2022-06-23 07:11:29.012875
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """ test include_role: module parameter validation """

    def task_from_data(self, data, block=None, role=None, **kwargs):
        return IncludeRole.load(data, block=block, role=role, **kwargs)

    def check_attr(attr):
        if attr.startswith('__'):
            return attr
        return None

    from ansible.playbook.role.definition import RoleDefinition
    #from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    #import types

    # FIXME: Since these are really testing the Task.module_path, and not loading any role,
    # do we really need to mock them all?
    parent_role = RoleDefinition.load({'name': 'foo'})
    parent_role._role

# Generated at 2022-06-23 07:11:39.466117
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Tests IncludeRole class method load.
    """
    def get_manifest_path(path):
        return "/tmp/ansible_test_roles/" + path

    #Test invalid options and check if error is thrown
    class MyPlay():
        pass
    class MyRole():
        def __init__(self):
            self._metadata = MyMetadata()
        def get_vars(self):
            return {'roles_invalid': ['test_role']}
    class MyMetadata():
        def __init__(self):
            self.roles_invalid = ['test_role']
            self.roles_valid = ['test_role']
    play = MyPlay()
    role = MyRole()

# Generated at 2022-06-23 07:11:49.083984
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test load with no data
    result = IncludeRole().load({})
    assert result.role.name is None, result

    # Test load with name but no role
    result = IncludeRole().load({'name': 'test_role', 'some_param': 'some_value'})
    assert result.role.name == 'test_role'
    assert result.role.vars.get('some_param') == 'some_value', result.role.vars

    # Test load with role but no name
    result = IncludeRole().load({'role': 'test_role', 'some_param': 'some_value'})
    assert result.role.name == 'test_role'
    assert result.role.vars.get('some_param') == 'some_value', result.role.vars

    # Test load with no options
   

# Generated at 2022-06-23 07:11:50.146266
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-23 07:11:55.616751
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    role = Role()
    role._role_name = 'foo'
    role._role_path = 'bar'
    include_role = IncludeRole()
    include_role._parent_role = role
    assert include_role.get_include_params() == {'ansible_parent_role_names': ['foo'], 'ansible_parent_role_paths': ['bar']}

# Generated at 2022-06-23 07:11:59.205959
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    include_role.name = "include_role_name"
    include_role._role_name = "role_name"
    result = include_role.get_name()
    assert result == "include_role_name : role_name"


test_IncludeRole_get_name()

# Generated at 2022-06-23 07:12:10.961841
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # data passed in with default tag_name 'include_role'
    data = dict(apply=dict(time=30, debug=True))
    x = IncludeRole.load(data=data)
    assert x.apply['time'] == 30
    assert x.apply['debug'] is True
    assert x.args['apply'] == data['apply']

    # data passed in with tag_name 'include'
    data = dict(apply=dict(time=30, debug=True))
    x = IncludeRole.load(data=data, task_include=dict(action='include'))
    assert x.apply['time'] == 30
    assert x.apply['debug'] is True
    assert x.args['apply'] == data['apply']

    # data passed in with tag_name 'import_role'

# Generated at 2022-06-23 07:12:11.968485
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass

# Generated at 2022-06-23 07:12:13.410819
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    assert IncludeRole(block=Block(), role=Role(), task_include=IncludeRole());

# Generated at 2022-06-23 07:12:24.417899
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars = {}
    pc = PlayContext()
    play = Play().load(dict(
        name = "Test",
        hosts = '127.0.0.1',
        gather_facts = 'no',
        roles = [
            dict(
                name = 'test',
                tasks = [
                    dict(action = dict(module = 'debug', args = dict(msg = 'inside')))
                ]
            )
        ]
    ), loader=loader, variable_manager=vars, loader_cache=vars)

# Generated at 2022-06-23 07:12:36.531889
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    # setup test
    loader = None
    variable_manager = None
    display = Display()
    options = None
    variable_manager = VariableManager()
    loader = DataLoader()

    include_role = IncludeRole.load(
        dict(
            name='test_role',
            tasks='tasks/main.yml',
            vars='vars/main.yml',
            handlers='handlers/main.yml',
            defaults='defaults/main.yml'),
        block=Block(),
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader)

    expected_name = "test_role : test_role"

    assert expected_name == include_role.get_name()

# Generated at 2022-06-23 07:12:46.393072
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    # Create some values
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role.statically_loaded = True
    include_role._from_files = {'some_key': 'some_value'}
    include_role._parent_role = role
    include_role._role_name = 'some_role'
    include_role._role_path = 'some_path'

    # Make copy
    new_include_role = include_role.copy()

    # Check if copy has been made correctly
    assert include_role.statically_loaded == new_include_role.statically_loaded
    assert include_role._from_files == new_include_role._from_files
    assert include_role._parent_

# Generated at 2022-06-23 07:12:54.964266
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    i_r = IncludeRole()
    i_r.statically_loaded = 'True'
    i_r._from_files = {'role1': 'test1'}
    i_r._parent_role = 'teest2'
    i_r._role_name = 'test3'
    i_r._role_path = 'test4'

    i_r_copy = i_r.copy()
    assert i_r_copy.statically_loaded == 'True'
    assert i_r_c

# Generated at 2022-06-23 07:13:07.265589
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    play_source =  dict(
        name = "Ansible Play ",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)

# Generated at 2022-06-23 07:13:13.715956
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.playbook.role.definition import RoleDefinition

    # Setup parameter for method load of class IncludeRole
    data = {
        "include_role": {
            "name": "foo",
            "apply": {
                "bar": "baz"
            },
            "no_log": True
        }
    }

    # Setup parameter for method load of class IncludeRole
    block = Block()

    # Setup parameter for method load of class IncludeRole
    role = RoleDefinition()


# Generated at 2022-06-23 07:13:22.802278
# Unit test for method copy of class IncludeRole
def test_IncludeRole_copy():
    loader = None
    variable_manager = None
    block1 = Block(parent_block=None)
    role1 = Role()
    role1._role_path = 'a/b/c'
    role1._role_name = 'name1'
    include_role1 = IncludeRole(block=block1, role=role1)
    include_role1.statically_loaded = True
    include_role1._from_files = {'tasks': 'd/e/f', 'vars': 'g/h/i'}
    include_role1._parent_role = role1
    include_role1._role_name = 'name2'
    include_role1._role_path = 'j/k/l'
    include_role1.public = True
    include_role1.allow_duplicates = True


# Generated at 2022-06-23 07:13:32.614363
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play

    task_include = IncludeRole()
    task_include.action = 'tasks'
    task_include.block = Block()
    task_include.block.name = 'test'
    task_include.block._parent = Block()
    task_include.role = Role()

    # Test __init__ method
    assert task_include._parent_role is None
    assert task_include._role_name is None
    assert task_include._role_path is None
    assert task_include.action == 'tasks'
    assert task_include.block.name == 'test'
    assert task_include.role is not None
    assert task_include.statically_loaded is False
    assert task_include.validate is True

# Generated at 2022-06-23 07:13:38.252249
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    import pytest

    display = Display()


# Generated at 2022-06-23 07:13:47.393345
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    username = "username"
    test_name = "test_name"
    test_action = "test_action"
    test_path = "test_path"
    test_parent = "test_parent"
    test_block = Block()
    test_options = dict()
    test_tasks = dict()
    test_handlers = dict()
    test_defaults = dict()
    test_meta = dict()

    test_block.name = test_name
    test_block.action = test_action

    test_role = Role(path=test_path,name=test_name,parent=test_parent,block=test_block,options=test_options,tasks=test_tasks,handlers=test_handlers,defaults=test_defaults,meta=test_meta)


# Generated at 2022-06-23 07:13:57.744976
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create 'block' to use
    block = Block()

    # Create 'role' to use
    role = Role()

    # Create 'task_include' to use
    task_include = TaskInclude()

    # Create 'IncludeRole' to test
    include_role = IncludeRole(block, role, task_include)

    # Set 'name' and 'action'
    include_role.name = 'some_name'
    include_role.action = 'some_action'

    # Set '_role_name'
    include_role._role_name = 'some_role_name'

    # Get 'name'
    result = include_role.get_name()

    # Test result
    assert result == 'some_name'

# Generated at 2022-06-23 07:14:05.299369
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test the get_name method without arguments
    ir = IncludeRole()
    assert ir.get_name() == 'include_role'

    # Test the get_name method with arguments
    ir.name = 'name'
    assert ir.get_name() == 'name'
    ir._role_name = 'role_name'
    assert ir.get_name() == 'role_name'

# Generated at 2022-06-23 07:14:15.612786
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    class FakePlaybook:
        def __init__(self):
            self.tasks = []
            self.basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    class FakeTask:
        def __init__(self):
            self.blocks = []
            self.name = 'fake task name'
            self.tags = []
            self.role_name = "fake role name"
    class FakeBlock:
        def __init__(self):
            self.tasks = []
            self.name

# Generated at 2022-06-23 07:14:24.916582
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # initialize a mock Block:
    block_mock = Block()
    block_mock.QOS = 0  # workaround for a blocking issue in Ansible: https://github.com/ansible/ansible/pull/48900
    block_mock.soft_block = None

    # initialize a mock Role
    role_mock = Role()
    role_mock.get_dep_chain = lambda: []
    role_mock.get_handler_blocks = lambda: []
    role_mock.compile = lambda play, dep_chain: []
    role_mock._role_path = "/tmp"
    role_mock._metadata.allow_duplicates = True

    # initialize a mock RoleInclude
    role_include_mock = RoleInclude()
    role_include_mock.vars = {}
   

# Generated at 2022-06-23 07:14:36.181872
# Unit test for constructor of class IncludeRole
def test_IncludeRole():
    block = Block.load(dict(
        name="Hello Block",
        task_list=[]
    ))
    role = Role()
    role.name = "Hello Role"
    task_include = TaskInclude()
    task_include.name = "Hello Task Include"
    # Test initialization of class IncludeRole
    ir = IncludeRole(block=block, role=role, task_include=task_include)
    assert ir.block == block
    assert ir.role == role
    assert ir.task_include == task_include
    assert ir.name == "Hello Task Include"
    assert ir.action == "include_role"
    assert ir.args == {}
    assert ir._parent_role == role
    assert ir._role_name is None
    assert ir._role_path is None

# Generated at 2022-06-23 07:14:47.780799
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    display = Display()

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'str_var': 'str_value',
        'num_var': 42,
    }
    variable_manager.set_available_variables(loader=loader)

    # Test load without options
    test_data = '''
     - name: include role test
       include_role:
    '''

# Generated at 2022-06-23 07:14:58.411694
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # This test is made in two step
    # Step 1: two test cases are done to check that the methode raise an AnsibleParserError
    # Step 2: two test cases are done to check that the method return a IncludeRole object

    # Step 1
    # Two negative scenarios:
    #    - When the name is not provided in the argument,
    #    - When the role is not provided in the argument
    ################################################################################################################

    # Case 1
    # When the name is not provided in the argument
    data = {"not_name": "test"}
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data)

    # Case 2
    # When the role is not provided in the argument
    data = {"no_role": "test"}

# Generated at 2022-06-23 07:15:10.799546
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = C.get_config_loader()
    inventory_manager = InventoryManager(loader, sources=["localhost"])

    # make a namespace to call get_include_params()
    def_loader = loader.load_from_file('roles/role1/tasks/main.yaml')
    rdef = RoleDefinition.load(def_loader, variable_manager=variable_manager, loader=loader)
    rdef._role_name = "role1"
    rdef._role_

# Generated at 2022-06-23 07:15:21.223549
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.executor.playbook_executor import PlaybookExecutor


    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    display.verbosity = 3


# Generated at 2022-06-23 07:15:33.668017
# Unit test for constructor of class IncludeRole
def test_IncludeRole():

    # Test case without name (role)
    data1 = {'action': 'include_role'}
    ir1 = IncludeRole.load(data1)
    assert ir1.name is None
    assert ir1._role_name is None

    # Test case with name (role)
    data2 = {'action': 'include_role', 'name': 'test'}
    ir2 = IncludeRole.load(data2)
    assert ir2.name == 'test'
    assert ir2._role_name == 'test'

    # Test case with invalid option
    data3 = {'action': 'include_role', 'name': 'test', 'invalid': 'foobar'}

# Generated at 2022-06-23 07:15:42.499921
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """Test method get_include_params of class IncludeRole"""
    import json
    import sys
    import unittest
    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-23 07:15:50.351596
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    add_all_plugin_dirs()

    data = {
        "name": "foobar",
        "connection": "local",
        "rolespec_validate": False,
        "roles": "../foobar"
    }

    display.verbosity = 3
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=Options(tags=['always']))
    playground = Play().load(data, variable_manager=variable_manager, loader=loader)

    p