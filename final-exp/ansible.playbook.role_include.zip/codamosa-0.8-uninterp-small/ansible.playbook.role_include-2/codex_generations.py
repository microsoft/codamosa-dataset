

# Generated at 2022-06-25 06:05:49.875607
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    parser = IncludeRole()

    test_data = dict(name='test')
    assert parser.load(test_data)
    assert parser._role_name == 'test'

    test_data = dict(role='test')
    assert parser.load(test_data)
    assert parser._role_name == 'test'

    test_data = dict(name='test', public=False, apply=dict(a='1', b='2'))
    assert parser.load(test_data)
    assert parser._role_name == 'test'
    assert parser.public is False
    assert parser.apply == dict(a='1', b='2')


# Generated at 2022-06-25 06:05:58.775220
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.executor.task_queue_manager import TaskQueueManager

    display.verbosity = 3

    parent_role_path = './test/units/library/include_role/parent_role'
    parent_play_vars = dict(role_path=parent_role_path)

    role_block = Block()
    role_block.vars = parent

# Generated at 2022-06-25 06:06:02.415920
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {}
    block = Block()
    role = Role()
    variable_manager = None
    loader = None
    include_role_0 = IncludeRole.load(data, block, role, variable_manager, loader)


# Generated at 2022-06-25 06:06:03.668754
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()


# Generated at 2022-06-25 06:06:08.421356
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test 1
    include_role_0 = IncludeRole()
    role_1 = Role()
    block_2 = Block()
    loader = Loader()
    variable_manager = VariableManager()
    play_3 = Play()
    print(include_role_0.get_block_list(play_3, variable_manager, loader))



# Generated at 2022-06-25 06:06:14.432409
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role.name = 'test'
    include_role.allow_duplicates = True
    include_role.rolespec_validate = True

    assert include_role.get_name() == '''test : None'''
    assert include_role.get_block_list() == ([], [])

# Generated at 2022-06-25 06:06:25.720765
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block_0 = Block()
    block_0._parsed_from_task = True
    block_0._line_number = 1
    role_0 = Role()
    role_0._role_name = 'role_name_2'
    role_0.task_blocks = ['task_blocks_2']
    role_0._role_path = '/home/ansible/test_workspace/roles/test'
    role_0._metadata = dict()
    role_0._metadata.allow_duplicates = True
    role_0._metadata.collections = ['collections_2']
    role_0._metadata.dependencies = ['dependencies_2']
    role_0._metadata.galaxy_info = dict()

# Generated at 2022-06-25 06:06:29.077826
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    # Placeholder
    block_list_result = include_role_0.get_block_list()
    assert block_list_result is not None



# Generated at 2022-06-25 06:06:39.307925
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    include_role = IncludeRole()
    include_role.set_loader(None)

    ar_params = include_role.get_include_params()
    assert ar_params.get("role_name") is None
    assert ar_params.get("role_path") is None
    assert ar_params.get("role_params") is None

    # create parent role
    pr = Role()
    pr.name = "parent_role"
    pr._role_path = "role_path/parent_role"
    pr_params = {"param1":"value1"}
    pr.set_role_params(pr_params)

    # create child role
    cr = Role()
    cr.name = "child_role"
    cr._role_path = "role_path/child_role"

# Generated at 2022-06-25 06:06:41.475923
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    include_role.load("file_name", "block", "role")  # TODO: This needs to be fixed to work with paramters

# Generated at 2022-06-25 06:07:00.506584
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test for missing name and role in block
    data = dict()
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data)

    data = dict(name="test", role="test")
    ir = IncludeRole.load(data)
    assert ir.args['name'] == "test"
    assert ir.args['role'] == "test"

    # Test if invalid options are detected
    data = dict(name="test", role="test", badop=True)
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data)

    # Test if apply option is not a dict
    data = dict(name="test", role="test", apply=[])
    with pytest.raises(AnsibleParserError):
        IncludeRole.load(data)

    # Test

# Generated at 2022-06-25 06:07:02.676024
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    args = {'name':'myrole'}
    include_role_0 = IncludeRole()
    blocks, handlers = include_role_0.get_block_list(play, variable_manager, loader)
    assert type(blocks) is list

# Generated at 2022-06-25 06:07:13.242374
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import httpapi_loader
   

# Generated at 2022-06-25 06:07:14.018339
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()

# Generated at 2022-06-25 06:07:24.030538
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print('Testing load')
    include_role = IncludeRole()
    assert include_role.load({'role': 'role'})
    assert include_role.load({'name': 'role'})
    assert include_role.load({'name': 'role', 'allow_duplicates': 1})
    assert include_role.load({'name': 'role', 'public': 1})
    assert include_role.load({'name': 'role', 'rolespec_validate': 1})
    assert include_role.load({'name': 'role', 'tasks_from': 'x'})
    assert include_role.load({'name': 'role', 'apply': {'x': True, 'y': False}})
    assert include_role.load({'name': 'role', 'unknown': 'x'})
    assert include_role

# Generated at 2022-06-25 06:07:29.769398
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    # Trying to call without a role parameter
    result_get_block_list = include_role_0.get_block_list()
    # Trying to call with a role parameter
    value_role = ''
    result_get_block_list = include_role_0.get_block_list(value_role)


# Generated at 2022-06-25 06:07:41.081604
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    vars1 = dict(
        param1 = 'value1',
        param2 = 'value2'
    )
    res = dict(
        apply = dict(
            vars1 = dict(
                param1 = 'value1'
            )
        )
    )
    display.verbosity = 4
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    testobj = IncludeRole.load(res,variable_manager=variable_manager, loader=DataLoader())
    data = testobj.get_vars()

# Generated at 2022-06-25 06:07:44.570270
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create an object of the IncludeRole class
    include_role_0 = IncludeRole()

    # Run the method get_block_list
    get_block_list_0 = include_role_0.get_block_list()

    print(get_block_list_0)

# Generated at 2022-06-25 06:07:55.160748
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Test for method get_block_list of class IncludeRole
    '''
    # TODO: implement test
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    import yaml
    loader = DataLoader()
    playbook = PlaybookExecutor(playbooks=['./test.yml'],
                                inventory=None,
                                variable_manager=VariableManager(),
                                loader=loader,
                                options=PlaybookExecutor.get_default_options(),
                                passwords={})
    results = playbook.run()
    print(results)


# Generated at 2022-06-25 06:08:06.972756
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create a task with arguments
    task = dict(
        name='Test the load with valid args only',
        include_role=dict(
            name='includes.valid_name',
            apply=dict(
                when=dict(
                    debug=True
                )
            ),
            allow_duplicates=False,
            public=True,
            rolespec_validate=True,
            tasks_from='includes/tasks/main.yml',
            vars_from='includes/vars/main.yml',
            handlers_from='includes/handlers/main.yml'
        )
    )

    # Create a data structure from task
    data = task.get('include_role')

    # Load the data structure as a role object
    include_role_1 = IncludeRole.load(data)

    assert include_

# Generated at 2022-06-25 06:08:39.031770
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Initialize with default value of dynamic=False
    ir1 = IncludeRole().load({'name': 'foo', 'public': True}, loader=None, variable_manager=None)
    assert ir1.name == 'foo'
    assert ir1.statically_loaded == False

    # Initialize with value of dynamic=True and check if dynamic is set to True
    ir2 = IncludeRole().load({'name': 'foo', 'dynamic': True, 'allow_duplicates': False}, loader=None, variable_manager=None)
    assert ir2.name == 'foo'
    assert ir2.statically_loaded == True
    assert ir2.allow_duplicates == False

    # Initialize with value of dynamic=False and check if dynamic is set to False

# Generated at 2022-06-25 06:08:42.593334
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # No exception should be raised
    task = IncludeRole.load(dict(args=dict(name='foo')), task_include=TaskInclude(action='- include_role: name=foo'))
    assert task._role_name == 'foo'
    assert task.statically_loaded is False


# Generated at 2022-06-25 06:08:44.985777
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_include_role = IncludeRole()
    assert my_include_role.load is not None


# Generated at 2022-06-25 06:08:47.687987
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    obj = IncludeRole()
    obj.name = 'test'
    assert obj.get_name() == obj.name
    obj = IncludeRole()
    obj._role_name = 'role_name'
    obj.action = 'action'
    assert obj.get_name() == "{} : {}".format(obj.action, obj._role_name)

# Generated at 2022-06-25 06:08:58.482114
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    executable = '/bin/ls'

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list=[host1])
    variable_manager.set_inventory(inventory) 

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='ping', args='')),
            ]
        )

# Generated at 2022-06-25 06:09:02.471962
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """Test the get_block_list method of the IncludeRole class"""
    block = Block()
    role = Role()
    include_role = IncludeRole(block=block, role=role)
    play = {}
    variable_manager = {}
    loader = {}
    include_role.get_block_list(play, variable_manager, loader)

# Generated at 2022-06-25 06:09:03.334874
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()

# Generated at 2022-06-25 06:09:07.334205
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        include_role=dict(name='foo_role.bar_role')
    )

    ir = IncludeRole.load(data, role=Role())

    # TODO: finish
    assert ir is not None

# Generated at 2022-06-25 06:09:16.641575
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    test_include_role = IncludeRole()
    # Test Case 0
    # No args provided
    assert not test_include_role.get_block_list()

    # Test Case 1
    # Only the required args provided
    test_include_role.name = 'main_role'

    # Test Case 1.1
    # No RoleDefinition object provided in the constructor
    assert not test_include_role.get_block_list()

    # Test Case 1.2
    # No parent role definition object provided in the constructor
    test_include_role._parent_role = RoleDefinition()
    assert not test_include_role.get_block_list()

    # Test Case 1.2.1
    # parent role definition object has no

# Generated at 2022-06-25 06:09:19.881500
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = 'var_manager'
    loader = 'loader'
    include_role_1 = IncludeRole(block, role, task_include)
    data = {}
    include_role_2 = include_role_1.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert data != include_role_2
    assert loader == include_role_2
    assert task_include == include_role_2

# Generated at 2022-06-25 06:09:49.795547
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    play = TaskInclude()
    variable_manager = Role()
    loader = loader=dict()
    include_role = IncludeRole.load(dict, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    include_role.get_block_list(play, variable_manager, loader)

# Generated at 2022-06-25 06:09:56.156253
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass
    # include_role = IncludeRole()
    # data = ""
    # block = ""
    # role = ""
    # task_include = ""
    # variable_manager = ""
    # loader = ""
    # IncludeRole.load.__dict__.__setitem__('stypy_call_defaults', defaults)
    # IncludeRole.load.__dict__.__setitem__('stypy_call_varargs', varargs)
    # IncludeRole.load.__dict__.__setitem__('stypy_call_kwargs', kwargs)
    # IncludeRole.load.__dict__.__setitem__('stypy_declared_arg_number', 1)
    # arguments = process_argument_values(localization, type_of_self, module_type_store, 'IncludeRole

# Generated at 2022-06-25 06:10:00.443783
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    include_role._role_name = "role_name"
    assert include_role.get_name() == "%s : %s" % (include_role.action, include_role._role_name)


# Generated at 2022-06-25 06:10:08.873000
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data = {
        'name': 'include_role_0',
        'allow_duplicates': True,
        'handlers_from': './handlers_from.yaml',
        'vars_from': './vars_from.yaml',
        'apply': {
            'when': 'when_0',
            'tags': ['tag_0', 'tag_1']
        },
        'tasks_from': './tasks_from.yaml',
        'defaults_from': './defaults_from.yaml',
        'public': True,
        'rolespec_validate': True
    }

    result = include_role_0.load(data, None, None, None, None, None)

# Generated at 2022-06-25 06:10:11.836518
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.info("***** testing get_block_list with dynamic block *****")
    IncludeRole()


# Generated at 2022-06-25 06:10:19.008586
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.executor import task_queue_manager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.vars import VariableManager

    data_loader = DataLoader()
    options = task_queue_manager.TaskQueueManager._default_options.copy()
    options.connection = 'local'
    options.remote_user = 'root'
    options.privilege_escalation = 'sudo'
    options.module_lang = 'C'
    options.module_set_locale = False
    options.module_compression = 'gzip'
    options.forks = 1
    options.become = 'True'
    options.become_method = 'sudo'
    options.become_user = 'root'

# Generated at 2022-06-25 06:10:24.586288
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir1 = IncludeRole()
    assert ir1.get_name() == 'include_role: '
    ir2 = IncludeRole(name='abc')
    assert ir2.get_name() == 'include_role: abc'
    ir3 = IncludeRole(name='abc', role='def')
    assert ir3.get_name() == 'include_role: abc'
    ir4 = IncludeRole(role='def')
    assert ir4.get_name() == 'include_role: def'

# Generated at 2022-06-25 06:10:32.973696
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    initial_block = Block.load(
        dict(
            name='test_get_block_list',
            tasks=[
                dict(
                    block=dict(
                        name='subblock',
                        tasks=[dict(
                            include_role=dict(
                                name='test_get_block_list_subrole'
                            )
                        )],
                    ),
                    media='test_get_block_list_subrole_media.tar'
                )
            ]
        )
    )
    role = Role()
    include_role = IncludeRole(block=initial_block, role=role)
    (subblocks, handlers) = include_role.get_block_list()
    assert len(subblocks) == 1
    block = subblocks[0]
    assert isinstance(block, Block)

# Generated at 2022-06-25 06:10:34.311049
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-25 06:10:36.478839
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole(action="test")
    assert include_role_0.get_name() == "include_role : test"


# Generated at 2022-06-25 06:11:43.004555
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    setattr(test_IncludeRole_load, '__qualname__', 'test_IncludeRole_load.<locals>.test_case_0')
    test_case_0()


# Generated at 2022-06-25 06:11:50.749257
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Create a play
    play = Play()

    # Create a task
    task = Task()

    # Create a task include
    task_include = TaskInclude(block=None, role=None, task_include=None)

    # Create an include role
    include_role = IncludeRole(block=None, role=None, task_include=task_include)

    # Call the method load with the include role and the task
    include_role.load(
        task,
        block=None,
        role=None,
        task_include=task_include,
        variable_manager=None,
        loader=None
    )


# Generated at 2022-06-25 06:11:54.439117
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Testing IncludeRole() class
    include_role = IncludeRole()
    # Testing for role
    block_data = {'name': 'test_role', 'remote_tmp': 'test_tmp'}
    role = Role(name='test_role', include_role=include_role)
    include_role = IncludeRole(block=block_data, role=role)
    result = include_role.load()
    assert result == 'test_role : test_role'


# Generated at 2022-06-25 06:11:59.762245
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Setup test data
    this_play = C._play
    this_variable_manager = None
    this_loader = C._loader
    include_role = this_play.get_tasks()[0]

    # Invoke method
    get_block_list_return = include_role.get_block_list(play=this_play, variable_manager=this_variable_manager, loader=this_loader)

    # Verify results
    assert get_block_list_return[0] is not None
    assert get_block_list_return[1] is not None

# Generated at 2022-06-25 06:12:03.840182
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    output = include_role_0.get_name()
    expected_output = ": "
    assert output == expected_output

# Generated at 2022-06-25 06:12:08.042058
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole.load(data={"name": "foo"}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert include_role_0.get_name() == "include_role : foo"

test_case_0()
test_IncludeRole_load()

# Generated at 2022-06-25 06:12:13.568153
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    globals()['_get_block_list_count'] = 0
    def mock_get_block_list(self, play=None, variable_manager=None, loader=None):
        globals()['_get_block_list_count'] += 1
        return (Block(), [])

    globals()['_get_block_list_exception_count'] = 0
    def mock_get_block_list_exception(self, play=None, variable_manager=None, loader=None):
        globals()['_get_block_list_exception_count'] += 1
        assert play == 'myplay'
        assert variable_manager == 'myvariable_manager'
        assert loader == 'myloader'
        raise AssertionError('An error has occurred')

    # Replace the method by a mock
    IncludeRole.get_block

# Generated at 2022-06-25 06:12:18.647462
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    include_role_0 = IncludeRole()
    result = include_role_0.get_name()
    assert result == ''



# Generated at 2022-06-25 06:12:21.582156
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole()
    ir.load_data()
    assert ir.allow_duplicates == True
    assert ir.apply == {}
    assert ir.private == True
    assert ir.public == False
    assert ir.rolespec_validate == True
    assert ir.tasks_from == {}


# Generated at 2022-06-25 06:12:27.087274
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Create test data
    include_role_0 = IncludeRole()
    include_role_0.name = None
    include_role_0.action = 'include_role'
    include_role_0._role_name = 'cisco-ios'
    # Run test method
    include_role_0_get_name = include_role_0.get_name()
    # Check results
    assert include_role_0_get_name == 'include_role : cisco-ios'


# Generated at 2022-06-25 06:15:18.393534
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    include_role_0.role = 0
    include_role_0._parent_role = 0
    try:
        include_role_0.get_block_list()
    except Exception as e:
        assert isinstance(e, AttributeError)



# Generated at 2022-06-25 06:15:29.448595
# Unit test for method load of class IncludeRole