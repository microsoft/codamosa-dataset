

# Generated at 2022-06-25 06:05:50.101747
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    IncludeRole: test load
    """
    include_role_0 = IncludeRole()
    display.display("include_role_0:", include_role_0)


# Generated at 2022-06-25 06:05:59.230000
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    yaml = """
    - hosts: all
      roles:
        - include_role: name=myrole
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    pbex = PlaybookExecutor()
    pbex._tqm._inventory = variable_manager.get_inventory()

    # Should not raise AnsibleError

# Generated at 2022-06-25 06:06:04.723275
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import ansible.constants as C

    # Create a play

# Generated at 2022-06-25 06:06:05.955731
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block_list = test_case_0()
    assert len(block_list) == 4, "Failed to get block list"


# Generated at 2022-06-25 06:06:07.209039
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert IncludeRole(None, None, None).get_name() == ": "

# Generated at 2022-06-25 06:06:18.483082
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    def test_case_0():
        include_role_0 = IncludeRole()
        block_0 = Block()
        block_0.parent = include_role_0
        include_role_0.block = block_0
        role_0 = Role()
        include_role_0.role = role_0
        task_include_0 = TaskInclude()
        task_include_0.parent = include_role_0
        include_role_0.task_include = task_include_0
        from ansible.parsing import vault
        vault_secret_0 = vault.VaultSecret(None)
        include_role_0.vault_secret = vault_secret_0
        include_role_0.statically_loaded = True
        include_role_0._from_files = {'': '', '': ''}


# Generated at 2022-06-25 06:06:27.462287
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    args = dict(
        name='dummy_role',
        tasks_from='Some/file/location.yml',
        vars_from='vars/file/location.yml',
        defaults_from='vars/file/location.yml',
        handlers_from='vars/file/location.yml',
        apply='yes',
        public='yes',
        allow_duplicates='yes',
        rolespec_validate='yes',
    )
    ir = IncludeRole.load(args, task_include=True)
    assert ir.tasks_from == 'location.yml'
    assert ir.vars_from == 'location.yml'
    assert ir.defaults_from == 'location.yml'
    assert ir.handlers_from == 'location.yml'

# Generated at 2022-06-25 06:06:37.665158
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    result = IncludeRole.load({u' apply': {u' diff': True}})
    assert result.apply == {u' diff': True}
    assert result.diff is False
    assert result.loop is None
    assert result.loop_control == {u'delay': 10, u'index_var': u'item', u'label': u'item'}
    assert result.module_name == u''
    assert result.notify is None
    assert result.register is None
    assert result.retries is 2
    assert result.until is None
    assert result.when is None
    assert result.async_val == -1
    assert result.always_run is False
    assert result.any_errors_fatal == [[u'missing']]
    assert result.changed_when is u''
    assert result.check_mode

# Generated at 2022-06-25 06:06:38.554913
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass


# Generated at 2022-06-25 06:06:43.102860
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role_0 = Role()
    task_include_0 = TaskInclude()
    include_role_0 = IncludeRole(block, role_0, task_include_0)
    play_0 = Play()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()

    include_role_0.get_block_list(play_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 06:06:52.349726
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == '%s : %s' % (include_role_0.action, include_role_0._role_name)


# Generated at 2022-06-25 06:07:00.199458
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    #
    #  Run it
    include_role_1 = IncludeRole()
    #
    #  Check it
    #
    #  output: None
    #
    #  side_effects: None
    #
    #  Next, we return...
    return None


######################################################################
#
#  TASK: Include
#
######################################################################


# Generated at 2022-06-25 06:07:04.466196
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """
    test_IncludeRole_get_name
    """
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() is None
    assert include_role_0.get_name() == include_role_0.get_name()


# Generated at 2022-06-25 06:07:12.706761
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role = IncludeRole()

    include_role._role_path = '/some/directory'
    include_role._parent_role = Role()
    include_role._parent_role._metadata = RoleMetadata()
    include_role._parent_role._metadata.role_path = '/some/other/directory'

    expected = {
        'ansible_role_name': None,
        'ansible_role_path': '/some/directory',
        'ansible_parent_role_names': [None],
        'ansible_parent_role_paths': ['/some/other/directory'],
        'ansible_search_path': []
    }

    assert include_role.get_include_params() == expected

# Generated at 2022-06-25 06:07:19.251719
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role()
    include_role = IncludeRole(block=block, role=role)
    play = Play()
    variable_manager = VariableManager()
    loader = DataLoader()
    include_role.get_block_list(play=play, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 06:07:20.621657
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role()
    i = IncludeRole(block, role)
    play = object()
    variable_manager = object()
    loader = object()
    i.get_block_list(play, variable_manager, loader)

# Generated at 2022-06-25 06:07:26.794432
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play

    # data.yml should be in the same folder as this file in order for the tests to work
    data = {'name': 'test1', 'hosts': 'localhost', 'connection': 'local', 'tasks': {'include_role': {'name': 'directory_exists'}, 'name': 'abc', 'tags': ['hello'], 'debug': {'msg': 'hello'}}}
    play = Play().load(data, variable_manager=None, loader=None)
    assert(play.task_blocks)
    assert(play.handlers)

    # data.yml should be in the same folder as this file in order for the tests to work

# Generated at 2022-06-25 06:07:35.819510
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    inventory = Inventory(DataLoader(), "/dev/null")
    variable_manager = VariableManager(loader=DataLoader())
    play_context = PlayContext(remote_user='root', remote_port=None, passwords={}, become_method='sudo', become_user='root', become_pass=None,
                               become=False, sudo=False, sudo_user='root', sudo_pass=None, become_exe=None, check=False, diff=False)
    loader = DataLoader()

# Generated at 2022-06-25 06:07:39.947845
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()
    ir.vars['foo'] = 'bar'
    ir.get_include_params()

# Generated at 2022-06-25 06:07:42.797063
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Testing
    include_role = IncludeRole()
    include_role._parent_role = Role()
    include_role._parent_role.get_role_params()
    include_role.get_include_params()



# Generated at 2022-06-25 06:08:07.078495
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    ir = IncludeRole()
    ir.vars = dict(a=1, b=dict(c=1), d=dict(e=1), f=dict(g=dict(h=1)))
    v = dict(a=1, b=dict(c=1), d=dict(e=1), f=dict(g=dict(h=1)))

    assert ir.get_include_params() == v
    assert isinstance(ir.get_include_params(), dict)

    ir2 = IncludeRole()
    v2 = dict()
    ir2.vars = dict()
    assert ir2.get_include_params() == v2
    assert isinstance(ir2.get_include_params(), dict)

    ir3 = IncludeRole()
    v3 = dict(a=1)
    ir3.vars = dict

# Generated at 2022-06-25 06:08:17.778432
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible import constants as C
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.template import Templar

    loader = DataLoader()

    variable_manager = VariableManager()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    host = Host(name='localhost', port=22)

# Generated at 2022-06-25 06:08:22.084849
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    x = include_role_0.get_name()


# Generated at 2022-06-25 06:08:23.610265
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # No tests
    pass

# Generated at 2022-06-25 06:08:28.301989
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    with pytest.raises(Exception) as exec_info:
        include_role_0.get_block_list()
    assert 'NotImplementedError' in str(exec_info.value)



# Generated at 2022-06-25 06:08:38.943532
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    try:
        # Test for "keyword 'public' is not known to loader" error
        # data = dict(a=dict(public=True) )
        # include_role = IncludeRole.load(data)
        assert False
    except AnsibleParserError as e:
        # import pdb; pdb.set_trace()
        assert e.message == "Invalid options for include_role: public"

    try:
        # Test for "keyword 'apply' is not known to loader" error
        # data = dict(a=dict(apply=dict(b=2)) )
        # include_role = IncludeRole.load(data)
        assert False
    except AnsibleParserError as e:
        # import pdb; pdb.set_trace()
        assert e.message == "Invalid options for include_role: apply"




# Generated at 2022-06-25 06:08:45.497425
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # Create an include block with some data
    i_block = Block()
    i_block.block += [
        dict(
            action=dict(
                meta=dict(
                    end_line=2,
                    start_line=2
                ),
                module='include_role',
                name='include_role_with_dict',
                args=dict(
                    role_name='myname',
                    role_path='/path/to/myname/',
                    role_vars={'ansible_user': 'ec2-user',
                               'ansible_password': 'StrongPassword',
                               'ansible_connection': 'smart'},
                    role_metadata=dict(
                        dependencies=[]
                    )
                )
            )
        )
    ]

    # Create a role with some data
    task_1 = dict

# Generated at 2022-06-25 06:08:54.997833
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print("*** test_IncludeRole_load ***")

    def _load_from_file(filename):
        with open(filename, 'r') as f:
            data = f.read()
        ir = IncludeRole.load(data, block=Block(), role=Role(), task_include=TaskInclude(), variable_manager=None, loader=None)
        print("  ir._from_files=%s" % ir._from_files)
        print("  ir.allow_duplicates=%s" % ir.allow_duplicates)
        return ir

    # test data/include_role/include_role_1.yaml
    ir = _load_from_file('./test/units/module_utils/ansible_test/_data/include_role/include_role_1.yaml')

# Generated at 2022-06-25 06:09:04.026431
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create a mock object of class Play
    empty_play = MockPlay()
    # Create a mock object of class Role
    empty_role = MockRole()
    # Create a mock object of class Block
    empty_block = MockBlock()
    # Create a mock object of class variable_manager
    variable_manager = MockVariableManager()
    # Create a mock object of class TaskInclude
    task_include = MockTaskInclude()
    # Create a mock object of class IncludeRole
    include_role = IncludeRole()
    # Create a mock object of class Loader
    loader = MockLoader()

    # Load include_role_0.yml file

# Generated at 2022-06-25 06:09:09.309408
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    # Try to test the get_block_list method
    try:
        block_list = include_role.get_block_list()
        return block_list
    except Exception as e:
        print("'get_block_list' method of 'IncludeRole' class has failed.", e)
        return False


# Generated at 2022-06-25 06:09:49.044240
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.display("test_IncludeRole_get_name")
    ir = IncludeRole()
    ir.name = "test_IncludeRole_get_name"
    assert ir.get_name() == "test_IncludeRole_get_name"


# Generated at 2022-06-25 06:09:54.205885
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    block_0 = Block()
    role_0 = Role()
    task_include_0 = TaskInclude()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    data_0 = {'foo': 'bar'}
    include_role_load_result = include_role_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)
    print(include_role_load_result)


# Generated at 2022-06-25 06:09:59.378726
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # test empty instance
    include_role = IncludeRole()
    assert include_role.get_block_list() == (None, None)
    # test empty instance
    include_role = IncludeRole(task_include=TaskInclude())
    assert include_role.get_block_list() == (None, None)
    # test empty instance
    include_role = IncludeRole(block=Block())
    assert include_role.get_block_list() == (None, None)



# Generated at 2022-06-25 06:10:01.239007
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    actual_result = include_role.get_block_list()
    expected_result = None
    assert actual_result == expected_result


# Generated at 2022-06-25 06:10:05.686183
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    temp_instance = IncludeRole(block=None, role=None, task_include=None)
    temp_instance._role_name = 'role-name'
    temp_tasks = temp_instance.get_block_list(play=None, variable_manager=None, loader=None)
    assert temp_tasks is None


# Generated at 2022-06-25 06:10:09.914843
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test case 1
    include_role_0 = IncludeRole()
    data = u'include_role'
    role = None
    result = include_role_0.load(data, role)
    assert isinstance(result, IncludeRole)

    # Test case 2
    include_role_0 = IncludeRole()
    data = u'include_role'
    role = None
    result = include_role_0.load(data, role)
    assert isinstance(result, IncludeRole)

# Generated at 2022-06-25 06:10:15.637873
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data_0 = dict(a=1, b=2)
    actual_result_0 = include_role_0.load(data=data_0)
    expected_result_0 = include_role_0
    assert actual_result_0 == expected_result_0, 'Expected: %s, but got: %s' % (expected_result_0, actual_result_0)


# Generated at 2022-06-25 06:10:22.996321
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class Module(object):
        pass
    Mod = Module()
    setattr(Mod, '_ACTION_INCLUDE_ROLE', C._ACTION_INCLUDE_ROLE)
    setattr(Mod, '_ACTION_INCLUDE_TASK', C._ACTION_INCLUDE_TASK)
    ir = IncludeRole()

# Generated at 2022-06-25 06:10:31.763063
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    data = {'include_role': {'name': 'common'}}
    ir = IncludeRole.load(data)
    assert ir.name == 'common'
    assert ir._role_name == 'common'
    assert ir._from_files == {}
    assert ir.collections is None
    assert ir.allow_duplicates is True
    assert ir.public is False

    data = {'include_role': {'name': 'common', 'allow_duplicates': False, 'public': True, 'tasks_from': 'main.yml'}}
    ir = IncludeRole.load(data)
    assert ir.name == 'common'
    assert ir._role_name == 'common'
    assert ir._from_files == {'tasks': 'main.yml'}
    assert ir.collections is None

# Generated at 2022-06-25 06:10:36.921372
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six import string_types

# Generated at 2022-06-25 06:11:50.529638
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Unit test for method get_block_list of class IncludeRole
    """
    from ansible import constants as C
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.variable_manager import VariableManager
    from ansible.template import generate_ansible_template_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager


# Generated at 2022-06-25 06:11:53.861483
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = None
    ir.action = 'include_role'
    ir._role_name = 'test'
    assert ir.get_name() == 'include_role : test'

# Generated at 2022-06-25 06:11:58.785327
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'include_role': 'name'}
    include_role_0 = IncludeRole.load(data)
    print(include_role_0)


# Generated at 2022-06-25 06:12:02.752250
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role.get_block_list()


# Generated at 2022-06-25 06:12:07.099301
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: reinstate the test when there is a plan to address the module deprecation warning
    return
    include_role_0 = IncludeRole()
    # TODO: reinstate the test when there is a plan to address the module deprecation warning
    # include_role_0.get_block_list()

# Generated at 2022-06-25 06:12:11.932493
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    result = include_role_0.get_name()
    assert result == "include_role : None"


# Generated at 2022-06-25 06:12:16.097822
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Expected data
    data = {
        'include_role': {
            'name': 'foo'
        }
    }

    # Expected Result
    result = {
        'name': 'foo',
        'allow_duplicates': True,
        'statically_loaded': False,
        'public': False,
        'rolespec_validate': True
    }

    # Init IncludeRole object
    include_role = IncludeRole()

    include_role.load_data(data, loader=None)

    # Assert results
    assert include_role.__dict__ == result


# Generated at 2022-06-25 06:12:22.022820
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
  data = dict()
  data['name'] = "test_IncludeRole_load"
  data['role'] = "test_name"
  block = Block()
  role = Role()
  task_include = TaskInclude()
  variable_manager = None
  loader = None
  ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
  assert ir.args['name'] == 'test_IncludeRole_load'
  assert ir.args['role'] == 'test_name'
  assert ir.action == 'include_role'

# Generated at 2022-06-25 06:12:23.376337
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    IncludeRole_object = IncludeRole()
    IncludeRole_object.load()


# Generated at 2022-06-25 06:12:29.861226
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    b = Block()
    role = Role()
    task_include = TaskInclude()
    data = {
        'name': 'namenotrequired',
        'role': 'rolename'
    }
    variable_manager = None
    loader = None
    result = IncludeRole.load(data, b, role, task_include, variable_manager, loader)
    assert result._role_name == "rolename"

# Generated at 2022-06-25 06:15:23.862181
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0.name = 'name'
    include_role_0.action = 'action'
    assert include_role_0.get_name() == 'name : action'


# Generated at 2022-06-25 06:15:32.898593
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    #
    # 1. No 'name' in args: task_include=False
    #
    # This test case is mainly for syntax check
    ir = IncludeRole(
            block=Block(
                parent=Play(),
                keep_vars=False,
                role=None,
                listens=None,
                loop=None
            ),
            role=None,
            task_include=False
        )
    ir.load({'args': {'foo': 'bar'}, 'action': 'include_role'})

    #
    # 2. No 'name' in args: task_include=True
    #

# Generated at 2022-06-25 06:15:40.055902
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    include_role_0 = IncludeRole()

    # Test 1: Error: 'name' is a required field for include_role.
    data = {
        "include_role": {}
    }
    with pytest.raises(AnsibleParserError):
        include_role_0.load(data)

    # Test 2: Error: 'name' is a required field for import_role.
    data = {
        "import_role": {}
    }
    with pytest.raises(AnsibleParserError):
        include_role_0.load(data)

    # Test 3: Error: 'name' is a required field for include_role.
    data = {
        "include_role": {
            "role": "common",
            "public": True
        }
    }