

# Generated at 2022-06-25 06:05:49.843463
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Constructor tests
    # 1. No params
    include_role_0 = IncludeRole()
    assert isinstance(include_role_0, Block)
    # 2. params
    include_role_1 = IncludeRole(block='block-1')
    assert isinstance(include_role_1, Block)
    assert include_role_1._parent == 'block-1'
    # 3. params
    include_role_2 = IncludeRole(block='block-2', role='role-2')
    assert isinstance(include_role_2, Block)
    assert include_role_2._parent == 'block-2'
    assert include_role_2._role == 'role-2'
    # load tests
    # 1. dict
    vars = dict()
    vars['name'] = 'role-0'
    include

# Generated at 2022-06-25 06:05:50.727870
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    test_case_0()

# Generated at 2022-06-25 06:06:00.178378
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Imports
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.playbook.task_include
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.template
    import ansible.vars.manager
    import ansible.inventory.manager
    # Setup
    include_role_1 = IncludeRole()
    # Create a Playbook
    play_1 = Play()
    play_1._ds = dict()
    play_1._ds.setdefault('name', "Unit test play")
    # Create a RoleDefinition
    role_definition_1 = RoleDefinition()
    role_definition_1._ds = dict()
    role_definition_1._ds.setdefault('name', "Unit test role")
   

# Generated at 2022-06-25 06:06:01.634617
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    a = IncludeRole()
    a.get_block_list()

# Generated at 2022-06-25 06:06:08.420679
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    role_1 = Role()
    tasks_0 = [dict()]
    block_0 = Block(parent=role_1, role=role_1, tasks=tasks_0)
    include_role_0 = IncludeRole(block=block_0, role=role_1)
    play_0 = object()
    variable_manager_0 = object()
    loader_0 = object()
    include_role_0.get_block_list(play=play_0, variable_manager=variable_manager_0, loader=loader_0)


# Generated at 2022-06-25 06:06:18.616601
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test with include_role_0:
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_include_params()
    assert var_0 == {}
    # Test with include_role_1:
    include_role_1 = IncludeRole()
    var_1 = include_role_1.get_include_params()
    assert var_1 == {}
    # Test with include_role_2:
    include_role_2 = IncludeRole()
    var_2 = include_role_2.get_include_params()
    assert var_2 == {}
    # Test with include_role_3:
    include_role_3 = IncludeRole()
    var_3 = include_role_3.get_include_params()
    assert var_3 == {}
    # Test with include_role

# Generated at 2022-06-25 06:06:20.933482
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_block_list()



# Generated at 2022-06-25 06:06:27.193953
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data_0 = include_role_0.load(data=data_0, block=block_0, role=role_0, task_include=task_include_0, variable_manager=variable_manager_0, loader=loader_0)
    include_role_1 = IncludeRole()
    data_1 = include_role_1.load(data=data_1, block=block_1, role=role_1, task_include=task_include_1, variable_manager=variable_manager_1, loader=loader_1)


# Generated at 2022-06-25 06:06:29.200113
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_name()


# Generated at 2022-06-25 06:06:36.375702
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Load the task content
    loader_0 = DataLoader()
    data_0 = 'dummy'
    variable_manager_0 = VariableManager()

    # create dummy objects
    block_0 = Block()
    role_0 = Role()

    # load the stat
    include_role_0 = IncludeRole(block=block_0, role=role_0)
    include_role_1 = IncludeRole()

    # invoke get_block_list
    include_role_1.get_block_list()


# Generated at 2022-06-25 06:06:51.945836
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    import os
    import sys

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition


# Generated at 2022-06-25 06:07:03.007171
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    include_role_1 = IncludeRole()
    include_role_2 = IncludeRole()
    include_role_3 = IncludeRole()
    include_role_4 = IncludeRole()
    include_role_5 = IncludeRole()
    include_role_6 = IncludeRole()
    include_role_7 = IncludeRole()
    include_role_8 = IncludeRole()
    include_role_9 = IncludeRole()
    assert include_role_0.get_include_params() == {}
    assert include_role_1.get_include_params() == {}
    assert include_role_2.get_include_params() == {}
    assert include_role_3.get_include_params() == {}
    assert include_role_4.get_include_params() == {}
    assert include_

# Generated at 2022-06-25 06:07:07.604234
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == "include_role : "

# Generated at 2022-06-25 06:07:14.028646
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Instantiate IncludeRole class
    include_role_0 = IncludeRole()

    # Test if include_role instance is of IncludeRole class
    assert isinstance(include_role_0, IncludeRole)


# Generated at 2022-06-25 06:07:21.574003
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Define some test values
    action = "action"
    _role_name = "role_name"
    include_role = IncludeRole()
    include_role.action = action
    include_role._role_name = _role_name

    # Actual result
    actual_result = include_role.get_name()

    # Expected result
    expected_result = "%s : %s" % (action, _role_name)

    # Assertion
    assert actual_result == expected_result


# Generated at 2022-06-25 06:07:23.206391
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_case_0()

# Run unit tests
if __name__ == "__main__":
    test_IncludeRole_load()

# Generated at 2022-06-25 06:07:28.334177
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()

    # RoleInclude.load() raises AnsibleParserError
    try:
        include_role_0.get_block_list()
    except AnsibleParserError:
        pass



# Generated at 2022-06-25 06:07:29.553726
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()


# Generated at 2022-06-25 06:07:33.865416
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    my_loader = DataLoader()
    my_inv = InventoryManager(loader=my_loader, sources=[])
    my_vars = VariableManager(loader=my_loader, inventory=my_inv)

    my_play = Play.load(play_ds, loader=my_loader, variable_manager=my_vars, inventory=my_inv)

    block_list = IncludeRole.load(include_role_ds, block=Block(), role=Role(), task_include=TaskInclude(), variable_manager=my_vars, loader=my_loader).get_block_list(play=my_play)

   

# Generated at 2022-06-25 06:07:36.844762
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    include_role_1.name = "foo"
    include_role_1.role = "bar"
    assert include_role_1.get_block_list() == None


# Generated at 2022-06-25 06:07:50.607207
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    include_role_1.statically_loaded = True
    include_role_1.name = 'include_role_1'
    include_role_1._role_name = 'include_role_1_name'
    include_role_1._from_files = {}
    include_role_1._parent_role = None

    include_role_1.get_block_list()

    print()
    print("The following error is expected for test_case_1:")
    print("Invalid options for include_role: public")


# Generated at 2022-06-25 06:07:53.284618
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    test_case_0()

# Generated at 2022-06-25 06:08:01.576726
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.parsing import vault
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.cli import CLI
    import ansible.constants as C
    import os
    import copy
    import json
    import sys

    # Test file paths.
    # ------------------------------------------------
    # Get the path of the Test File.
    current_dir = os.getcwd()

# Generated at 2022-06-25 06:08:09.371320
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    include_role_0 = IncludeRole()

    # Test case with normal args
    data = {
        'include_role': {
            'name': 'test_role',
            'public': False,
            'role': 'test_role',
            'rolespec_validate': True,
            'allow_duplicates': True,
            'apply': {'tags': ['test']}
        }
    }

    result = IncludeRole.load(data, role='test_role')

    blocks, handlers = result.get_block_list()

    assert result._role_name == 'test_role'
    assert result.allow_duplicates == True
    assert result.public == False
    assert result.rolespec_validate == True
    assert blocks
    assert handlers

# Generated at 2022-06-25 06:08:11.508956
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # TODO: implement proper tests
    include_role_0 = IncludeRole()
    name = include_role_0.get_name()


# Generated at 2022-06-25 06:08:20.058520
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # create an IncludeRole object
    include_role = IncludeRole()

    role_name_1 = "r1"
    role_name_2 = 'r'
    role_name_3 = "r3"
    role_name_4 = "r4"
    role_name_5 = "r5"
    role_name_6 = "r6"
    role_name_7 = "r7"
    role_name_8 = "r8"
    role_name_9 = "r9"

    # create two sample dictionaries for valid and invalid
    # arguments for the method test_case_0
    valid_argument = {'name': role_name_1, 'public': True, 'allow_duplicates': True, 'rolespec_validate': True}

# Generated at 2022-06-25 06:08:29.108256
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    action = 'include_role'
    meta = { 'allow_duplicates': False, 'public': True, 'rolespec_validate': True }
    include_role_data = dict(action='include_role',
                             args=dict(role='apb_role', name='apb_role_name',
                                       allow_duplicates=False, public=True,
                                       rolespec_validate=True))
    include_role_0 = IncludeRole.load(data=include_role_data)
    assert include_role_0.action == action
    assert include_role_0.args == meta
    assert include_role_0._role_name == include_role_0.args['role']

# Generated at 2022-06-25 06:08:34.008256
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block_list = include_role_0.get_block_list(play=None, variable_manager=None, loader=None)
    assert block_list == ([], [])  # Assertion error if the condition is false


# Generated at 2022-06-25 06:08:35.195781
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # FIXME: test for load is not written yet
    return True



# Generated at 2022-06-25 06:08:38.362831
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {}
    data.update({'name': 'apache'})
    variable_manager = {}
    loader = {}
    ir = IncludeRole.load(data, variable_manager, loader)
    assert ir.args == data
    assert ir.name == 'apache'
    assert ir._role_name == 'apache'

# Generated at 2022-06-25 06:08:57.796900
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # test for the get_name method of class IncludeRole
    # initializes include_role instance
    include_role = IncludeRole()
    # assign name to include_role instance
    include_role._role_name = "include_role_name"
    assert include_role.get_name() == "include_role : include_role_name"


# Generated at 2022-06-25 06:09:00.553316
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    get_name_ret_val = include_role_0.get_name()
    assert get_name_ret_val is None



# Generated at 2022-06-25 06:09:02.112116
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    include_role_0.load()


# Generated at 2022-06-25 06:09:09.184006
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    #
    # Set up test data
    #

    # include_role: ...
    data = {}
    data['include_role'] = {}
    data['include_role']['name'] = 'test_role'

    #
    # Run method
    #
    include_role = IncludeRole()
    include_role.load_data(data)
    result = include_role.get_include_params()

    #
    # Assertions
    #
    assert result == {}
    assert result is not None


# Generated at 2022-06-25 06:09:14.388099
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name = "maven",
        apply = dict(
            tags = "test"
        )
    )
    '''
    loader.set_basedir(".")
    display.verbosity = 6
    new_include_role_0 = IncludeRole.load(data)
    new_include_role_0.post_validate(templar=None)
    '''

# Generated at 2022-06-25 06:09:23.991571
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
#    # Test a regular include
#    data_in = dict(
#        src='test_task_include.yml',
#        private=True,
#    )
#    include_role = IncludeRole.load(data_in, block=None, role=None, task_include=None, variable_manager=None, loader=None)
#    # private is not a valid option, so we should get a failure
#    try:
#        include_role = IncludeRole.load(data_in, block=None, role=None, task_include=None, variable_manager=None,
#                                        loader=None)
#    except AnsibleParserError:
#        pass
#    else:
#        raise AssertionError('Able to load task include with an invalid option')
#
#    # test a valid include
    data_

# Generated at 2022-06-25 06:09:34.284442
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """Unit test for method get_block_list of class IncludeRole"""
    block = Block()
    role = Role()
    role._metadata.allow_duplicates = True
    role._role_path = "path_to_role"
    include_role = IncludeRole(block=block, role=role)
    include_role.action = "include_role"
    include_role._allow_duplicates = True
    include_role._public = False
    include_role._rolespec_validate = True
    include_role._from_files = {"tasks": "tasks", "vars": "vars", "defaults": "defaults", "handlers": "handlers"}
    include_role._parent_role = role
    include_role._role_name = "role_name"
    include_role._role_path

# Generated at 2022-06-25 06:09:43.400054
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    if ansible_version == '2.7.13':
        print("Skipping IncludeRole.load() unit test, due to known Ansible 'get_default_argspec' error in Ansible 2.7.13")
        return

    # Test a simple valid case
    # TEST CASE 1
    data_1 = dict(name='test_role', tasks_from='tasks/main.yml')
    # TEST CASE 2

# Generated at 2022-06-25 06:09:46.430849
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Implementation with only mandatory arguments
    include_role = IncludeRole()
    include_role_loaded = include_role.load()


# Generated at 2022-06-25 06:09:52.978711
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Method: def get_name(self):
    # Tests: Run once, with various inputs

    # Test 0: standard execute
    yaml_data = '- name: test_role\n  include_role: name=test_role'
    include_role_0 = IncludeRole.load(data=yaml_data)
    assert(include_role_0.get_name() == 'test_role')


# Generated at 2022-06-25 06:10:32.230498
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create an instance of the IncludeRole class
    include_role_1 = IncludeRole(block=Block())
    include_role_1.name='dummy'
    include_role_1.action='include_role'
    include_role_1._parent_role='foo_parent'
    include_role_1._from_files = {u'vars': u'vars_from_file', 
                                  u'tasks': u'tasks_from_file', 
                                  u'handlers': u'handlers_from_file'}
    include_role_1._role_name='foo'
    include_role_1._role_path='/path/to/role'
    include_role_1.statically_loaded=True
    include_role_1.allow_duplicates=True
    include_role_1

# Generated at 2022-06-25 06:10:39.380844
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleError
    import json

    playbooks = [
        # './test/integration/targets/include_role.yaml',
        './test/integration/targets/include_role_task.yaml'
    ]

   

# Generated at 2022-06-25 06:10:49.638014
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars.manager import VariableManager
    from ansible.vars.cleaner import AllVars, FilterableBaseVars
    include_role = IncludeRole()

    parent_role_name = "test_parent_role"
    parent_role_path = "/tmp/role_path/"
    parent_role = Role(name=parent_role_name, role_path=parent_role_path)
    include_role._parent_role = parent_role
    expected_res = {
        u'ansible_parent_role_names': [u'test_parent_role'],
        u'ansible_parent_role_paths': [u'/tmp/role_path/'],
    }


# Generated at 2022-06-25 06:10:55.643536
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    block_list = include_role.get_block_list(play=None, variable_manager=None, loader=None)
    assert type(block_list) == tuple
    assert len(block_list) == 2
    assert type(block_list[0]) == list
    assert type(block_list[1]) == list

# Generated at 2022-06-25 06:10:56.808187
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
  assert IncludeRole().get_name() == "include_role : None"


# Generated at 2022-06-25 06:11:05.737769
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:11:11.667810
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Expected different keyword arguments for constructor of class IncludeRole
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include=task_include)

    # Expected boolean value for argument allow_duplicates of method IncludeRole.load
    include_role.load()


# Generated at 2022-06-25 06:11:21.470444
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    unit tests for load method of IncludeRole
    """

    # Example dictionary
    # data = {"include_role": "test_role",
    #         "name": "test_role"}
    data = dict(include_role="test_role")
    role = Role()
    block = Block()
    task_include = TaskInclude()
    res_obj = IncludeRole.load(data, block=block, role=role, task_include=task_include)
    assert res_obj._action == "include_role"
    assert res_obj._parent_role.get_name() == "test_role"

# Generated at 2022-06-25 06:11:25.770473
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    res = include_role_0.get_name()
    assert res is not None
    assert type(res) is str
    assert res == ''


# Generated at 2022-06-25 06:11:33.374125
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test no args
    try:
        include_role_1 = IncludeRole()
        # get_block_list()
    except TypeError:
        pass
    # Test invalid value for play
    try:
        include_role_2 = IncludeRole()
        # get_block_list(play=2)
    except ValueError:
        pass
    # Test invalid value for variable_manager
    try:
        include_role_3 = IncludeRole()
        # get_block_list(variable_manager=2)
    except ValueError:
        pass
    # Test invalid value for loader
    try:
        include_role_4 = IncludeRole()
        # get_block_list(loader=2)
    except ValueError:
        pass
    # Test invalid value for parent

# Generated at 2022-06-25 06:12:38.618855
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    data = {
        'action': 'include_role',
        'name': 'foo',
        'apply': {
            'list_param': ['foo', 'bar'],
            'dict_param': {'foo': 'bar', 'baz': 'qux'}
        },
        'tags': ['one', 'two']
    }
    block = Block()
    role = Role()
    task_include = RoleInclude()
    variable_manager = 'foo'
    loader = 'bar'
    include_role_1.load(data, block, role, task_include, variable_manager, loader)
    assert isinstance(include_role_1, IncludeRole)
    assert isinstance(include_role_1.block, Block)

# Generated at 2022-06-25 06:12:43.708683
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test get_block_list method of IncludeRole
    """

    # Test Case 0
    data = {
        'role': 'foo.bar'
    }
    task_include = TaskInclude()
    include_role = IncludeRole(task_include=task_include)

    # get_block_list
    include_role.get_block_list(data)

    # Test Case 1
    pass



# Generated at 2022-06-25 06:12:51.310491
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Test IncludeRole class load method
    """

    display.display('TESTING IncludeRole load method...')
    include_role = IncludeRole()
    for action in C._ACTION_INCLUDE_ROLE:
        block = Block(play=None)
        data = dict(
            name="test_role",
            public="yes",
            apply=dict(foo="hello world")
        )
        try:
            include_role.load(data, block, action=action)
        except Exception as e:
            display.display('%s load FAILED: %s' % (action, e))
        else:
            display.display('%s load PASSED' % action)
    display.display('TESTING IncludeRole load method... PASSED')
    display.display('\n')


# Generated at 2022-06-25 06:12:53.685854
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    module = IncludeRole()
    module.name = None
    module._role_name = "test"
    assert module.get_name() == "include_role : test"


# Generated at 2022-06-25 06:12:54.642672
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() is None


# Generated at 2022-06-25 06:12:55.681319
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    assert include_role_0.get_block_list(play=play, variable_manager=variable_manager, loader=loader) == ([], [])

# Generated at 2022-06-25 06:13:05.514606
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    include_role_1.action = 'include_role'
    include_role_1.vars = {}
    include_role_1._from_files = {}
    include_role_1.private = False
    include_role_1.rolespec_validate = True
    include_role_1._parent_role = None
    include_role_1._role_name = 'test'
    include_role_1.allow_duplicates = True
    include_role_1._role_path = 'default'
    include_role_1.public = False
    include_role_1.statically_loaded = False
    include_role_1.no_log = False
    include_role_1.always_run = False
    include_role_1._play = 'default'

# Generated at 2022-06-25 06:13:14.964950
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    task_include = TaskInclude()
    block = Block()
    role = Role()
    include_role = IncludeRole(block, role, task_include=task_include)

    # Case 1: There are duplicate include_tasks instruction

# Generated at 2022-06-25 06:13:21.568877
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # data, block=None, role=None, task_include=None, variable_manager=None, loader=None
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = {u'include': u'role_name', u'public': True }
    block = Block()
    role = Role()
    task_include = IncludedFile()
    loader = DataLoader()
    play_context = PlayContext()
    play = Play().load({}, loader=loader, variable_manager=VariableManager())
    variable_manager = VariableManager()

# Generated at 2022-06-25 06:13:22.388552
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass
