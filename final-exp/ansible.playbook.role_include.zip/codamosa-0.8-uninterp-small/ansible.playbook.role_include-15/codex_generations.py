

# Generated at 2022-06-25 06:05:54.249749
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    include_role_1 = IncludeRole.load(data='data', block='block', role='role', task_include='task_include', variable_manager='variable_manager', loader='loader')
    assert include_role_1._from_files == include_role_0._from_files
    assert include_role_1._parent_role == include_role_0._parent_role
    assert include_role_1._role_name is include_role_0._role_name
    assert include_role_1._role_path is include_role_0._role_path
    assert include_role_1.action == include_role_0.action
    assert include_role_1.block == include_role_0.block
    assert include_role_1.collections == include_role_0.collections

# Generated at 2022-06-25 06:06:03.879543
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {"name": "Example"}
    block = {}
    role = 'Example'
    task_include = {'name': 'Example', 'action': 'include_role'}
    variable_manager = {}
    loader = {}
    test = IncludeRole.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert test
    assert test._role_name == 'Example'
    data = {"name": "Example"}
    block = {}
    role = 'Example'
    task_include = {'name': 'Example', 'action': 'include_role'}
    variable_manager = {}
    loader = {}

# Generated at 2022-06-25 06:06:08.303368
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    var = IncludeRole()
    var_0 = Block()
    var_0._play = Play()
    var_1 = var.get_block_list(var_0, VariableManager(), None)
    assert len(var_1[0]) > 0
    assert len(var_1[1]) > 0

# Generated at 2022-06-25 06:06:11.668107
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_name()

# Generated at 2022-06-25 06:06:14.792343
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    assert isinstance(include_role_0, IncludeRole) is True
    assert hasattr(include_role_0, '_role_name') is True
    assert hasattr(include_role_0, '_role_path') is True
    assert hasattr(include_role_0, '_parent_role') is True
    assert hasattr(include_role_0, '_from_files') is True


# Generated at 2022-06-25 06:06:18.370680
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_block_list()


# Generated at 2022-06-25 06:06:24.431037
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data0 = 'name0'

    block0 = include_role_0.block
    role0 = include_role_0.role
    task_include0 = include_role_0.task_include
    # Call method load of class IncludeRole with data0, block0 and
    # role0, task_include0
    include_role_1 = IncludeRole.load(data0, block0, role0, task_include0)


# Generated at 2022-06-25 06:06:29.073165
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    var_1 = include_role_1.get_block_list()


# Generated at 2022-06-25 06:06:32.033068
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    var_1 = include_role_1.load()


# Generated at 2022-06-25 06:06:38.162090
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    my_block = Block()
    my_role = Role()
    my_task_include = TaskInclude()
    test_case_0_IncludeRole = IncludeRole(block = my_block, role = my_role, task_include = my_task_include)
    assert my_block == test_case_0_IncludeRole.block
    assert my_role == test_case_0_IncludeRole.role
    assert my_task_include == test_case_0_IncludeRole.task_include


# Generated at 2022-06-25 06:06:47.628353
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()

    try:
        include_role_0.get_block_list(play=play_0)
    except AnsibleParserError as e:
        assert "Role name must be provided" in str(e)


# Generated at 2022-06-25 06:06:57.606856
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test 1: Example from the docs
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-25 06:07:03.910415
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    field_0 = include_role_1.BASE
    field_1 = include_role_1.VALID_ARGS
    field_2 = include_role_1.OTHER_ARGS
    field_3 = include_role_1.FROM_ARGS


# Generated at 2022-06-25 06:07:13.381121
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='test',
        tasks_from='test_tasks',
        vars_from='test_vars',
        handlers_from='test_handlers',
        defaults_from='test_defaults',
        allow_duplicates=False,
        apply=dict(
            tags=['test_tag'],
            when=['test_when'],
            ignore_errors=True,
            become=True,
            become_user='test_become',
            register='test_register',
            delegate_to='localhost',
            check_mode=True,
        ),
        public=True,
        rolespec_validate=False,
    )

    include_role = IncludeRole.load(data)
    assert include_role._name is None

# Generated at 2022-06-25 06:07:19.251148
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test name'
    assert ir.get_name() == 'test name'
    ir.name = None
    ir.action = 'test action'
    ir._role_name = 'test role name'
    assert ir.get_name() == 'test action : test role name'

# Generated at 2022-06-25 06:07:24.263846
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.include import RoleInclude

    # Instantiate an empty IncludeRole() object
    include_role_0 = IncludeRole()

    # Instantiate an empty RoleInclude() object
    role_include_0 = RoleInclude()

    # Call load() method
    include_role_1 = IncludeRole.load(data = dict(), block = None, role = None, task_include = None, variable_manager = None, loader = None)

    # Verify
    assert include_role_1 is not None


# Generated at 2022-06-25 06:07:29.628561
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    data = {'tasks': None, 'handlers': None, 'vars_files': None, 'always_run': False, 'any_errors_fatal': False, 'no_log': False, 'private': True, 'tags': []}
    include_role = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    print(include_role.__dict__)
    assert include_role.__dict__['_parent'] == block
    assert include_role.__dict__['_task_include'] == task_include
    assert include_role.__dict__['_role'] == role

# Generated at 2022-06-25 06:07:41.004612
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    role0 = Role()
    role0._role_params = [ AnsibleUnicode('role1_param1') ]
    role0._role_path = "/path/to/role1"
    role0._role_name = "role1"

    include_role_0 = IncludeRole(role=role0)

    expected_result = include_role_0.vars.copy()
    expected_result.update( { 'ansible_parent_role_names' : [ role0.get_name() ],
                              'ansible_parent_role_paths' : [ role0._role_path ] } )

    assert expected_result == include_role_0

# Generated at 2022-06-25 06:07:45.015880
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_data = {
        'action': 'include_role',
        'name': 'varun'
    }
    try:
        include_role_1 = IncludeRole.load(data=my_data)
    except Exception as e:
        raise e
    else:
        return include_role_1



# Generated at 2022-06-25 06:07:56.213816
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.template import Templar

    # set up args needed by load
    data = dict(
        name='role_name'
    )
    block = Block()
    role = Role()
    # set up args needed by get_block_list
    play = Play()
    variable_manager = Templar()
    loader = None

    # load the IncludeRole and call get_block_list
    ir = IncludeRole.load(data=data, block=block, role=role, variable_manager=variable_manager, loader=loader)
    blocks, handlers = ir.get_block_list(play=play)

    # assert blocks is not None
    assert(blocks != None)

    # assert

# Generated at 2022-06-25 06:08:07.353423
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    data_2 = {"include_role":"test_role"}
    ret_3 = IncludeRole.load(data_2,variable_manager=True,loader=True)
    assert ret_3 != None


# Generated at 2022-06-25 06:08:14.296539
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    try:
        include_role_0.get_name()
    except Exception as e:
        assert str(e) == "{}: get_name() is not implemented".format(type(include_role_0))


# Generated at 2022-06-25 06:08:16.453479
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_load = IncludeRole()
    # test if IncludeRole.args is dict
    assert isinstance(include_role_load.args, dict)


# Generated at 2022-06-25 06:08:23.985270
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.display("Testing IncludeRole get_block_list")
    # The following mock objects are used to test block_list
    class mock_play:
        def __init__(self):
            self.roles = []
        def __str__(self):
            return "Mocked_Play"

    class mock_role:
        def __init__(self):
            self.name = "name"
            self.handlers = {}
            self._metadata = None
            self._parents = []
        def __str__(self):
            return "Mocked_Role"

    class mock_metadata:
        def __init__(self):
            self.allow_duplicates = False
        def __str__(self):
            return "Mocked_Metadata"

    test_file = "test_file"

    # Test for the case

# Generated at 2022-06-25 06:08:29.259942
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    task_include_1 = TaskInclude()
    task_include_1.action = 'include_role'
    task_include_1.args = {'name': 'z_role', 'allow_duplicates': False}
    include_role_1._task_include = task_include_1
    assert include_role_1._role_name == 'z_role'
    assert include_role_1._allow_duplicates == False


# Generated at 2022-06-25 06:08:36.472782
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test1
    ir1 = IncludeRole()
    with pytest.raises(AnsibleParserError):
        ir1.load({})
    ir1_load = IncludeRole()
    ir1_load.load({'name': 'test',
                   'role': 'test'})
    # Test2
    # Test2.1
    ir2 = IncludeRole()
    with pytest.raises(AnsibleParserError):
        ir2.load({'name': 'test',
                  'role': 'test',
                  'bad_param': 'test'})
    # Test2.2
    ir3 = IncludeRole()
    with pytest.raises(AnsibleParserError):
        ir3.load({'name': 'test',
                  'role': 'test',
                  'apply': 'test'})
    #

# Generated at 2022-06-25 06:08:44.308778
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    import os
    import sys
    import pytest

    # Load the options
    variable_manager = VariableManager()

# Generated at 2022-06-25 06:08:49.283572
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    myblock = Block()
    myblock._role = Role()
    myblock._role._role_path = "foo"
    myblock._play = "bar"
    myblock._tasks = []

    new_me = IncludeRole(block=myblock)
    new_me._role_name = "foo"
    res = new_me.get_block_list()
    assert res[0] == []
    assert res[1] == []

# Generated at 2022-06-25 06:08:57.408924
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    test_play = Play()
    test_variable_manager = VariableManager()
    test_loader = DataLoader()
    include_role_0._role_name = 'foo'
    include_role_0._parent_role = Role()
    include_role_0._parent_role._role_path = 'foo_path'
    import os
    include_role_0._role_path = os.getcwd() + '/../../lib/ansible/galaxy/api/models.py' # TODO Add a test with a valid path to a role
    blocks, handlers = include_role_0.get_block_list(test_play, test_variable_manager, test_loader) # This raises an exception but it passes the test anyway. I don't know why.

# Generated at 2022-06-25 06:09:07.171243
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    data = dict()
    data['name'] = 'test_case_0'
    # set directly assigned attributes
    include_role_0._role_hash = '800f4bf0004eab4f36d8bcc218cbd25a'
    include_role_0.action = 'include_role'
    include_role_0.block = Block()
    include_role_0.always_run = True
    include_role_0.async_val = 10
    include_role_0.delegate_to = 'test_case_0'
    include_role_0.delegate_facts = True
    include_role_0.failed_when_val = ['failed_when_val_0']
    include_role_0.ignore_errors = True
    include_

# Generated at 2022-06-25 06:09:27.647783
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert IncludeRole.load(data=dict(name='test_role_0'))
    assert IncludeRole.load(data=dict(include='test_role_1'))


# Generated at 2022-06-25 06:09:30.284460
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    include_role._role_name = "MyTestRole"
    assert include_role.get_name() == "include_role : MyTestRole"


# Generated at 2022-06-25 06:09:38.457628
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_include_role = IncludeRole()

    # set up the block to be returned and the tasks to test
    test_block = Block()
    test_include_role._parent = test_block

    role_include = RoleInclude()
    role_include.vars = dict()

    test_include_role._role_name = 'test_include_role_object'

    test_include_role.rolespec_validate = True
    test_include_role.allow_duplicates = False

    # set up variables for the role blocks
    test_play = dict()
    test_variable_manager = dict()
    test_loader = dict()

    # get role blocks from role include
    role_blocks = role_include.compile(play=test_play, dep_chain=[])

    # test an empty block for the include_

# Generated at 2022-06-25 06:09:44.156082
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-25 06:09:46.103363
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # FIXME
    pass


# Generated at 2022-06-25 06:09:49.246832
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # test with None value of name and valid argument _role_name
    include_role = IncludeRole()
    include_role.name = None
    include_role._role_name = "tomcat"
    expected = "tomcat"
    actual = include_role.get_name()
    assert expected == actual


# Generated at 2022-06-25 06:09:59.037755
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader=DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {}}
    variable_manager.options_vars = {}

    # initialize a play
    play = Play()
    variable_manager = play.get_variable_manager()

    # initialize a role
    task = Task()
    role = Role()

    # initialize a reload task
    data = dict()
    data['name'] = 'test_role'
    rt = IncludeRole.load

# Generated at 2022-06-25 06:10:01.254766
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0.name = 'foo'
    assert include_role_0.get_name() == 'foo'


# Generated at 2022-06-25 06:10:03.751848
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Create a test object for class IncludeRole 
    include_role = IncludeRole()

    # Check if the object is of class IncludeRole
    assert isinstance(include_role,IncludeRole) == True

# Generated at 2022-06-25 06:10:11.073415
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: get rid of these tests and just document the class
    from ansible.playbook.task_include import TaskInclude
    import ansible.playbook.task as task
    import ansible.playbook.role as role
    import ansible.playbook.play as play
    import ansible.template as template

    task_name = 'test_task'
    role_name = 'test_role'
    play_name = 'test_play'

    # test bad args
    data = dict(
        name=task_name,
        action='include_role',
        args=dict(bad_args='bad_args')
    )

    try:
        IncludeRole.load(data=data)
        assert False
    except AnsibleParserError:
        assert True

    # test no name

# Generated at 2022-06-25 06:10:37.068488
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # make a data structure
    x = dict(
        name = "kadalu",
        tasks_from = "tasks/tasks1.yaml",
        vars_from = "vars/vars1.yaml",
        handlers_from = "handlers/handlers1.yaml",
        defaults_from = "defaults/defaults1.yaml",
        apply = dict(
            tags = ["install"],
            when = "ansible_distribution == Fedora",
            become=True),
        )

    # make display object
    display = Display()

    # make include_role

# Generated at 2022-06-25 06:10:46.593854
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play, Loader, Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    class MockPlaybook:
        class MockPlay:
            name = 'test'
            def __init__(self):
                self.tasks = []
        def __init__(self):
            self.hosts = "localhost"
            self.roles = []
            self.tasks = []
            self.handlers = []
        def get_plays(self):
            p = MockPlaybook.MockPlay()
            return [p]
    class MockIncludeRole:
        def __init__(self):
            self.tags = None
            self.when

# Generated at 2022-06-25 06:10:50.470147
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    loader = None
    variable_manager = None
    role = None
    include_role = IncludeRole(block, role)
    play = None
    include_role.get_block_list(play, variable_manager, loader)


# Generated at 2022-06-25 06:10:59.843500
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Setup blocks
    # --------------
    # Create a playbook to test the IncludeRole class
    pb = PlayBook(name='TestPb')
    pb.vars_files = []
    pb.roles = []

    # Create a play with a connection set as local
    p = Play()
    p._ds = {}
    p._ds["name"] = "TestPlay"
    p._ds["hosts"] = 'localhost'
    p._ds["gather_facts"] = 'no'
    p._ds["vars"] = {}

# Generated at 2022-06-25 06:11:10.434426
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = {}
    loader = {}
    ansible_module = IncludeRole()
    data = { "include_role": {
             "name": "CR1_12345_test_"
    }}

    with pytest.raises(AnsibleParserError):
        ansible_module.load(data, block, role, task_include, variable_manager, loader)
    data = { "include_role": {
             "name": "CR1_12345_test_",
             "apply": "some_value"
    }}
    with pytest.raises(AnsibleParserError):
        ansible_module.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-25 06:11:12.521993
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    my_include_role = IncludeRole()
    # TODO: Add test for IncludeRole.get_block_list()
    assert True


# Generated at 2022-06-25 06:11:22.186266
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:11:31.041412
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    action_1 = 'include_role'
    args_1 = dict()
    data_1 = dict(action=action_1)
    try:
        ir_1 = IncludeRole.load(data_1)
    except Exception as e:
        print("Failed to load data as IncludeRole: %s" % e)
    else:
        print("Successfully load data as IncludeRole : %s" % ir_1)

    action_2 = 'include_role'
    args_2 = dict(name='Apache')
    data_2 = dict(action=action_2, args=args_2)
    try:
        ir_2 = IncludeRole.load(data_2)
    except Exception as e:
        print("Failed to load data as IncludeRole: %s" % e)

# Generated at 2022-06-25 06:11:37.195943
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_instance = IncludeRole.load({"name": "test_IncludeRole", "include_role": {"test_include_role"}, "allow_duplicates": True})
    if test_instance.name != "test_IncludeRole" or test_instance.allow_duplicates is False or \
            test_instance.role != "test_include_role":
        print("IncludeRole load failed")
        return False
    return True

# Generated at 2022-06-25 06:11:42.921609
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    try:
        include_role_1 = IncludeRole()
        block=None
        play=None
        variable_manager=None
        loader=None
        include_role_1.get_block_list(play=play, variable_manager=variable_manager, loader=loader)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:12:05.966034
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:12:10.915107
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role.name = "test0"
    include_role.rolespec_validate = False
    include_role.tasks_from = "tasks/main.yml"
    include_role.vars_from = "vars/main.yml"
    include_role.handlers_from = "handlers/main.yml"
    include_role.defaults_from = "defaults/main.yml"
    include_role.apply = {"tags": ["TAG"] }
    include_role.public = False
    include_role.allow_duplicates = True

    play = Play()
    blocks, handlers = include_role.get_block_list(play=play)
    assert (blocks == [])

test_IncludeRole_get_block_list()

# Generated at 2022-06-25 06:12:16.923315
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.parsing.dataloader import DataLoader

    play_0 = Play().load({u'name': u'localhost',
                          u'hosts': u'localhost',
                          u'gather_facts': u'no',
                          u'roles': []})

    loader_0 = DataLoader()

    role_include_0 = RoleInclude.load(u'foo', play=play_0, loader=loader_0, collection_list=[])

    module_documentation_0 = read_docstring(loader_0, 'include_role')
    module_args_0 = module_documentation_0.get

# Generated at 2022-06-25 06:12:17.942712
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert True

# Generated at 2022-06-25 06:12:23.098321
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Initialize test environment
    display.debug("######################################################################################")
    display.debug("Starting test case execution 0: test_IncludeRole_get_block_list")
    display.debug("######################################################################################")
    include_role_0 = IncludeRole()
    Block()
    Role()
    task_include_0 = None
    include_role_0.block = None
    include_role_0.role = None
    include_role_0._role_name = 'ping'
    include_role_0._from_files = {'tasks': 'main.yml', 'vars': 'main.yml', 'handlers': 'main.yml'}
    include_role_0.vars = None
    variable_manager_0 = None
    loader_0 = None
    # Execute code to test

# Generated at 2022-06-25 06:12:29.223001
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Creating AnsibleBaseUnitTestCase instance for testing Ansible
    import ansible.plugins.loader
    from ansible.plugins.loader import role_loader, task_include_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from collections import namedtuple
    from ansible.utils.display import Display
    display = Display()
    am_plugins = ansible.plugins.loader.action_loader._create_directory_dictionary()
    am_plugins['lookup'] = ansible.plugins.loader.lookup_loader._create_directory_dictionary()
    am_plugins['filter'] = ansible.plugins.loader.filter_loader._create_directory_dictionary()
    am_plugins['test'] = ansible.plugins.loader

# Generated at 2022-06-25 06:12:37.369974
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='test_role',
        tasks_from='test_role/tasks/main.yaml',
        vars_from='test_role/vars/main.yaml',
        handlers_from='test_role/handlers/main.yaml',
        apply=dict(
            some_var=33
        ),
        public=True,
        allow_duplicates=False,
        rolespec_validate=True
    )

    display.display = lambda x: x
    ir = IncludeRole.load(data)
    print(ir)
    print(ir._from_files)
    print(ir.statically_loaded)
    print(ir.public)
    print(ir.allow_duplicates)
    print(ir.rolespec_validate)



# Generated at 2022-06-25 06:12:47.617847
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role     = IncludeRole()
    play             = Play()
    display.vvvv("play=%s\n", play)
    include_role.block = Block(play=play)
    include_role.validate_attributes()
    display.vvvv("include_role.block=%s\n", include_role.block)
    display.vvvv("include_role._parent._play=%s\n", include_role._parent._play)
    display.vvvv("include_role._parent._play._tasks=%s\n", include_role._parent._play._tasks)
    include_role.statically_loaded = True
    # Test conditional setting of allow_duplicates to False
    include_role.allow_duplicates = False
    include_role.public = False
    include_role.ro

# Generated at 2022-06-25 06:12:54.442350
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role.include_role = "{{ package_name }}"
    include_role.loop = "{{ range(1,1+1) }}"
    include_role.when = False
    include_role.vars = {"foo": "bar"}
    play = Play()
    variable_manager = None
    loader = None
    include_role.get_block_list(play, variable_manager, loader)


# Generated at 2022-06-25 06:12:58.314578
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    with pytest.raises(AnsibleParserError) as exec_info:
        include_role_0.get_block_list()
    assert str(exec_info.value) == "Test block"

# Generated at 2022-06-25 06:13:31.586335
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # given:
    include_role_0 = IncludeRole()
    # when:
    include_role_0.action = 'my_action'
    include_role_0._role_name = 'my_role'
    # then
    assert 'my_action : my_role' == include_role_0.get_name()


# Generated at 2022-06-25 06:13:32.555136
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    assert include_role.get_block_list() is not None


# Generated at 2022-06-25 06:13:33.949812
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ''' Test description '''
    my_IncludeRole = IncludeRole(block=None, role=None, task_include=None)


# Generated at 2022-06-25 06:13:40.094571
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    role_name = 'role_name'
    role = Role()
    role.name = role_name
    data = {'name': 'name', 'role': role_name}
    result_0 = include_role.load(data, role=role)
    assert result_0.name == 'name'
    assert result_0._role_name == role_name
    result_1 = include_role.load(data)
    assert result_1._role_name == role_name


# Generated at 2022-06-25 06:13:47.506789
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    hosts = [
        Host(name="host1", port=22)
    ]
    groups = [
        Group(name="group1")
    ]

    inventory = InventoryManager(loader=DataLoader(), sources=["localhost"])
    for host in hosts:
        inventory.add_host(host, group=groups[0])
   

# Generated at 2022-06-25 06:13:49.856091
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Maybe add a test for the function validate_role_name() in the module ansible.playbook.role_include
    include_role_object = IncludeRole()
    assert isinstance(include_role_object, IncludeRole) is True

# Generated at 2022-06-25 06:13:51.860267
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    include_role_1 = include_role_0.load(data)
    assert isinstance(include_role_1, IncludeRole)

# Generated at 2022-06-25 06:13:52.450038
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-25 06:13:57.350644
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_obj = IncludeRole()
    # Case 1
    # Test for method get_block_list() when blocks = []
    include_role_obj.block = Block(play=None)
    include_role_obj._role_name = ''
    include_role_obj._from_files = {}
    blocks = []
    handlers = []
    result = include_role_obj.get_block_list(play=None, variable_manager=None, loader=None, blocks=blocks, handlers=handlers)
    assert isinstance(result, tuple)
    assert result == ()


# Generated at 2022-06-25 06:14:03.460943
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.playbook.task import Task

    class _VariableManager(object):
        def get_vars(self):
            return {'A':'B'}

    class _Loader(object):
        def get_basedir(self, attr):
            return 'path'

    class _Play(object):
        block = Block()
        superblock = Block()
        tasks = []
        handlers = []
        vars = {}
        def __init__(self):
            self.iterator = PlayIterator(play=self, play_context=None)

    class _Task(Task):
        def __init__(self):
            self._parent = _Play()
            self.vars = {}


# Generated at 2022-06-25 06:15:10.118381
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Instantiate an IncludeRole using arguments
    include_role = IncludeRole(args={})

    # Instantiate an IncludeRole without arguments
    #include_role = IncludeRole()

    # Invoke method get_block_list on object 'include_role'
    try:
        #include_role.get_block_list()
        result = include_role.get_block_list()
    except Exception as e:
        display.display(str(e), color='red')

    display.display('IncludeRole.get_block_list() = {0}'.format(result))

# Generated at 2022-06-25 06:15:16.474033
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_1 = IncludeRole()
    include_role_1.name = "test_name"
    assert include_role_1.get_name() == "test_name"
    include_role_2 = IncludeRole()
    include_role_2.action = "test_action"
    include_role_2._role_name = "test_role_name"
    assert include_role_2.get_name() == "test_action : test_role_name"

# Generated at 2022-06-25 06:15:19.336124
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    param_0 = include_role_0.get_block_list()
    assert param_0[0] == []
    assert param_0[1] == []

# Generated at 2022-06-25 06:15:22.796643
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'name'
    if ir.name != ir.get_name():
        assert False, 'Test failed when calling method get_name of class IncludeRole'


# Generated at 2022-06-25 06:15:28.316671
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play
    include_role = IncludeRole()
    variable_manager = None
    include_role.get_block_list(play=None, variable_manager=variable_manager, loader=None)

# Generated at 2022-06-25 06:15:29.321660
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
