

# Generated at 2022-06-25 06:05:48.647160
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
  block_0 = Block()
  role_1 = Role()
  include_role_0 = IncludeRole(block=block_0, role=role_1)
  assume(include_role_0 is not None)
  assert include_role_0.get_block_list() is not None



# Generated at 2022-06-25 06:05:56.766876
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'include_role': {
            'name': 'test',
            'tasks_from': 'file.yaml',
            'apply': {'free_form_string': 'test'}
        },
    }
    exclude_parent = False
    exclude_tasks = False
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert ir._from_files == {'tasks': 'file.yaml'}
    assert ir.apply == {'free_form_string': 'test'}
    assert isinstance(ir, Block)

# Generated at 2022-06-25 06:06:02.544955
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.loader import DataLoader

    class MockPlay(object):
        def __init__(self):
            self.handlers = []
            self.roles = []

    class MockRoleInclude(RoleInclude):
        def __init__(self):
            super(MockRoleInclude, self).__init__()
            self.roles = []

    class MockRole(Role):
        def __init__(self):
            super(MockRole, self).__init__()
            self.handlers = []
            self._parents = []


# Generated at 2022-06-25 06:06:11.169790
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor import task_queue_manager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    display = Display()
    options = task_queue_manager.TaskQueueManager._create_default_loader_options()
    loader = DataLoader() # Takes care of finding and reading yaml, json and ini files
    passwords = dict(vault_pass='secret')

    # Instantiate our ResultCallback for handling results as they come in. Ansible expects this to be one of its main display outlets
    results_callback = ResultCallback()

# Generated at 2022-06-25 06:06:16.203839
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()

# Generated at 2022-06-25 06:06:23.301975
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole(role=None, task_include=None, block=None)
    data = dict(action='include_role', name='test')
    variable_manager=None
    loader=None
    include_role_0 = IncludeRole.load(data=data, role=include_role_0, variable_manager=variable_manager, loader=loader)
    assert include_role_0 is not None, 'AnsibleParserError: \'name\' is a required field for include_role.'


# Generated at 2022-06-25 06:06:28.454292
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    output = IncludeRole.get_block_list()
    assert output == {}, 'Test failed because wrong output: %s' % output


# Generated at 2022-06-25 06:06:38.678671
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Instantiate a IncludeRole object
    include_role_0 = IncludeRole()

    # get_block_list method expects 1 to 6 arguments: self, play=None, variable_manager=None, loader=None,
    # hostvars=dict(), namespace=None

    # AssertException if play is not a Play object
    with pytest.raises(AssertionError):
        include_role_0.get_block_list(play="test_play", variable_manager=None, loader=None)

    # AssertException if variable_manager is not a VariableManager object
    with pytest.raises(AssertionError):
        include_role_0.get_block_list(play=None, variable_manager="test_variable_manager", loader=None)

    # AssertException if loader is not a DataLoader object

# Generated at 2022-06-25 06:06:46.173393
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    result = IncludeRole.load("include_role", block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(result, IncludeRole)
    assert result.action == 'include_role'
    assert result.parent is None
    assert result.role is None
    assert result.block is None
    assert result.args == {}
    assert result.any_errors_fatal is False
    assert result.always_run is False
    assert result.any_errors_fatal is False
    assert result.any_errors_fatal is False
    assert result.any_errors_fatal is False
    assert result.tags == set()
    assert result.name is None
    assert result.run_once is False
    assert result.notify is None
    assert result.when is None
   

# Generated at 2022-06-25 06:06:49.031571
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    display.display('Test_Get_Name')

    include_role_0 = IncludeRole()
    include_role_0.name = 'common'
    include_role_0.action = 'include_role'
    include_role_0._role_name = 'common'

    assert include_role_0.get_name() == 'common : common', "Get_Name failed"


# Generated at 2022-06-25 06:06:57.429630
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    include_role_0.args = {"name": "", "tasks_from": ""}
    # Testing with play = None
    try:
        include_role_0.get_block_list()
    except Exception as e:
        if "object has no attribute" in str(e):
            assert True
        else:
            assert False


# Generated at 2022-06-25 06:07:02.102913
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    result = include_role.get_block_list()



# Generated at 2022-06-25 06:07:03.196541
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    IR = IncludeRole()
    IR.get_block_list()

# Generated at 2022-06-25 06:07:13.328191
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role.action = 'include_role'
    include_role._role_name = 'test_case_role'
    include_role.statically_loaded = True
    include_role.public = False
    include_role._allow_duplicates = True
    include_role._rolespec_validate = True
    include_role.statically_loaded = True
    include_role._parent = Block()
    include_role._parent._parent = Block()
    include_role._parent._parent._parent = Block()
    include_role._parent._parent._parent._parent = Block()
    include_role._parent._parent._parent._parent._parent = None
    include_role._parent.hosts = 'test-host'
    include_role.name = 'test case'

# Generated at 2022-06-25 06:07:23.539451
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ri = RoleInclude.load()
    ri.vars.update()
    available_variables = variable_manager.get_vars(play=myplay, task=self)
    templar = Templar(loader=loader, variables=available_variables)
    from_files = templar.template(self._from_files)
    actual_role = Role.load(ri, myplay, parent_role=self._parent_role, from_files=from_files,
                                from_include=True, validate=self.rolespec_validate)
    actual_role._metadata.allow_duplicates = self.allow_duplicates
    p_block = self.build_parent_block()
    p_block.collections = actual_role.collections

# Generated at 2022-06-25 06:07:33.940212
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create an instance of class IncludeRole
    include_role = IncludeRole()
    # Create an instance of class Play
    myplay = Play()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class Block
    block = Block()
    # Create an instance of class Role
    role = Role()
    # Create an instance of class RoleInclude
    ri = RoleInclude()
    # Create an instance of class VariableManager
    variable_manager = VariableManager()
    # Create an instance of class AnsibleFileLoader
    loader = AnsibleFileLoader()
    # Call method get_block_list of class IncludeRole
    blocks, handlers = include_role.get_block_list(play=myplay, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 06:07:36.269335
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole()
    assert not ir._parent.get_blocks()
    assert not ir.get_handler_blocks()
    assert not ir._dep_chain

# Generated at 2022-06-25 06:07:46.151505
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    #
    # Setup the test environment
    #

    # Create a Dictionary from the data to be loaded
    include_role_data = {"name": "test_role_0"}

    # Create a IncludeRole object
    include_role = IncludeRole.load(include_role_data)

    #
    # Validate IncludeRole Object
    #

    # check the return value of IncludeRole.load
    assert isinstance(include_role, IncludeRole)

    # check get_name()
    assert include_role.get_name() == "import_role : test_role_0"

    # check the role_name
    assert include_role._role_name == "test_role_0"


# Generated at 2022-06-25 06:07:57.359721
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    vars_file = "/path/to/vars"
    defaults_file = "/path/to/defaults"
    handlers_file = "/path/to/handlers"
    meta_file = "/path/to/meta"
    tasks_file = "/path/to/tasks"
    role_name = "dummy_role_name"
    apply_dict = {'tags': 'tags_val'}
    ri = {
        'tasks_from': tasks_file,
        'vars_from': vars_file,
        'defaults_from': defaults_file,
        'handlers_from': handlers_file,
        'meta_from': meta_file,
        'apply': apply_dict,
    }
    ir = IncludeRole()
    ir.args = ri
    ir._role_name

# Generated at 2022-06-25 06:08:01.254680
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test data
    include_role = IncludeRole()
    include_role.args ={'name': 'test_role'}
    # Test Custom Module
    include_role.get_block_list()



# Generated at 2022-06-25 06:08:18.602880
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ri = IncludeRole(role='my_role')
    blocks, handlers = ri.get_block_list()
    print (blocks)
    print (handlers)

# Generated at 2022-06-25 06:08:25.678317
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test fails
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.display import Display
    from ansible.utils.vars import merge_hash

    display = Display()
    loader = DataLoader() # Takes care of

# Generated at 2022-06-25 06:08:28.588567
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    block_0 = Block()
    task_include_0 = TaskInclude()
    include_role_1 = IncludeRole.load(data=None, block=block_0, role=None, task_include=task_include_0)

# Generated at 2022-06-25 06:08:35.205844
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ################################################################################
    # This test check the parameters allowed in the include_role:
    #
    #
    ################################################################################

    # The following test checks that all allowed parameters are handled
    # correctly.
    include_role_0 = IncludeRole()
    # This will check that only the two allowed parameters are accepted


test_case_0()
test_IncludeRole_load()

# Generated at 2022-06-25 06:08:43.241707
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    myplay = Play()
    myplay.roles = []
    myplay._variable_manager = VariableManager()
    include_role_0.statically_loaded = True
    include_role_0.name = 'name'
    include_role_0._parent_role = Role()
    include_role_0._role_name = 'role_name'
    include_role_0._parent_role._role_name = 'parent_role_name'
    include_role_0._parent_role._role_path = 'parent_role_path'
    include_role_0.vars = {}
    include_role_0._from_files = {'file1':'file1'}
    include_role_0.collections = []
    include_role_0._parent = Block

# Generated at 2022-06-25 06:08:45.445920
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_case_IncludeRole_get_block_list()


# Generated at 2022-06-25 06:08:49.303892
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role = IncludeRole()
    include_role._parent_role = "parent_role"
    include_role._parent_role.get_role_paths = MagicMock()
    include_role._parent_role.get_role_names = MagicMock()
    include_role.get_include_params()

# Generated at 2022-06-25 06:08:51.553502
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    # TODO: write test for IncludeRole.get_name here



# Generated at 2022-06-25 06:09:02.152811
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    example_data_get_block_list_0 = [
        {
            "allow_duplicates": False,
            "name": "role",
            "role": "../roles/foo",
            "tasks_from": "main.yml",
            "vars_from": "vars/main.yml",
            "apply": {
                "tags": [
                    "foo"
                ]
            }
        }
    ]

    include_role_get_block_list_0 = IncludeRole(
        block=Block(),
        role=Role()
    )

    include_role_get_block_list_0.load(
        example_data_get_block_list_0[0],
        role=Role(),
        task_include=TaskInclude()
    )

    include_role_get_

# Generated at 2022-06-25 06:09:10.246868
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import json
    import __builtin__
    dict_1 = {'foo': 'bar'}
    dict_2 = {'foo': 'baz'}
    with open('data/json/include-role.json') as f:
        data = json.load(f)
    # create mock object
    block = Block.load('block', dict_1, dict_2)
    #role = __builtin__.__import__('ansible.playbook.role').playbook.role.Role.load('role', dict_1, dict_2)
    #task_include = __builtin__.__import__('ansible.playbook.task_include').playbook.task_include.TaskInclude.load('task_include', dict_1, dict_2)

# Generated at 2022-06-25 06:09:37.067329
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    IncludeRole_get_block_list_object = IncludeRole()
    try:
        IncludeRole_get_block_list_object.get_block_list()
    except AttributeError as returned_error:
        assert returned_error.args[0] == 'self'
        return
    assert False


# Generated at 2022-06-25 06:09:46.404114
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    include_role = IncludeRole()
    include_role._role_name = "unit_test"
    include_role._role_path = "/path/to/the/role"

    # When no additional args are provided, the role_name and role_path are set correctly
    include_role_copy = include_role.copy()
    assert include_role_copy._role_name == "unit_test"
    assert include_role_copy._role_path == "/path/to/the/role"

    # When args are provided, the role_name and role_path are set correctly
    include_role_copy_2 = include_role.copy(exclude_tasks=True)
    include_role_copy_2.args['name'] = "new_unit_test"

# Generated at 2022-06-25 06:09:48.582440
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    result = include_role_0.get_name()
    assert result == 'include_role : UNDEF', result


# Generated at 2022-06-25 06:09:52.822097
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    def create_args():
        args_dict = dict()
        args_dict['name'] = 'a_role'
        args_dict['apply'] = dict()
        args_dict['public'] = True
        return args_dict

    args = create_args()

    # Need to create a Role and use it as the parent role
    role = Role()
    role.name = 'a_parent_role'
    block = Block()
    block.parent_role = role

    task = IncludeRole.load(args, block, variable_manager=None, loader=None)

    assert task._role_name, 'a_role'
    assert task.public, True

    # Uncomment the following line to observe a test failure
    # args.pop('name')
    # task = IncludeRole.load(args, block, variable_manager=None,

# Generated at 2022-06-25 06:09:54.979754
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    actual_result = IncludeRole.load(None)
    expected_result = None
    assert actual_result is expected_result, 'Test Failed'


# Generated at 2022-06-25 06:10:05.645238
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test
    include_role_1 = IncludeRole.load({u'role': u'common', u'apply': {u'vars': {u'hello': u'world'}}})
    bad_args_1 = IncludeRole.load({u'role': u'common', u'bad_arg': u'invalid'})
    bad_args_1 = IncludeRole.load({u'role': u'common', u'bad_args': [u'invalid1',u'invalid2']})
    bad_args_2 = IncludeRole.load({u'role': u'common', u'apply': {u'vars': u'world'}})
    bad_args_3 = IncludeRole.load({u'role': u'common', u'apply': u'world'})


# Generated at 2022-06-25 06:10:10.453320
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # IncludeRole object creation
    include_role = IncludeRole()

    # Check if the content of method get_include_params is equal to a dict with keys:
    # ansible_current_include_role_path, ansible_current_include_role_name, ansible_current_include_role_params
    assert(include_role.get_include_params() == {
        'ansible_current_include_role_path': None,
        'ansible_current_include_role_name': None,
        'ansible_current_include_role_params': {}
    })

# Generated at 2022-06-25 06:10:13.619915
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # (1) very simple case
    include_role_0 = IncludeRole()
    assert include_role_0.get_include_params() == {}


# Generated at 2022-06-25 06:10:20.847701
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create mock objects
    role = Role()
    role = role.load({
        "_role_path": "/home/ansible/roles/my_role",
        "_metadata": {
            "name": "my_role",
            "dependencies": [],
            "allow_duplicates": False,
            "collections": []
        },
        "name": "my_role",
        "tasks": [
            {
                "name": "test_1",
                "action": "test_action",
                "arguments": "test_args"
            }
        ]
    })
    block = Block()
    templar = Templar()
    templar.loader = mock.MagicMock()
    templar.environment = mock.MagicMock()

# Generated at 2022-06-25 06:10:29.618609
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    #from ansible.playbook.play import Play
    #from ansible.playbook.role import Role
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    #block = Block()
    #role = Role()
    try:
        include_role_0 = IncludeRole.load(None, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    except Exception as e:
        return False
    return include_role_0


# Generated at 2022-06-25 06:11:48.275748
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test bad args
    with pytest.raises(AnsibleParserError) as excinfo:
        IncludeRole.load({'static': 'yes', 'name': 'foo', 'public': 'yes'})
    assert "Invalid options for include_role: static" in str(excinfo.value)


# Generated at 2022-06-25 06:11:59.073874
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:12:10.529236
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play
    play = ansible.playbook.play.Play()
    role = Role()

    # test with all args set
    include_role = IncludeRole()
    include_role.role = role
    include_role._role_name = 'test_name'
    include_role._from_files = {}
    include_role.statically_loaded = True
    include_role.public = True
    blocks, handlers = include_role.get_block_list(play=play)

    # test with the minimum required args
    include_role = IncludeRole()
    include_role.role = role
    include_role._role_name = 'test_name'
    blocks, handlers = include_role.get_block_list(play=play)


# Generated at 2022-06-25 06:12:15.976595
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_block = Block()
    my_role = Role()
    my_task_include = TaskInclude()
    my_variable_manager = variable_manager()
    my_loader = loader()
    data = {'block': my_block, 'role': my_role, 'task_include': my_task_include, 'variable_manager': my_variable_manager, 'loader': my_loader}
    test_case_0_args = [data]
    if has_resource('ansible_task_run'):
        my_ansible_task_run = ansible_task_run()

# Generated at 2022-06-25 06:12:20.026911
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_include_role = IncludeRole()
    my_include_role_loaded = my_include_role.load({
        "role": "web"
    })

    assert(my_include_role_loaded._role_name == "web")


# Generated at 2022-06-25 06:12:27.744611
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    play_1 = Play()
    variable_manager_2 = VariableManager()
    loader_3 = DataLoader()
    include_role_0.get_block_list(play=play_1, variable_manager=variable_manager_2, loader=loader_3)
    # Negative tests. Should raise an exception on any of these.
    # from_files should be a dictionary
    from_files_4 = Block()
    try:
        include_role_0._from_files = from_files_4
    except Exception as e:
        assert type(e) is AssertionError

    # test_case_0()

# Generated at 2022-06-25 06:12:33.761958
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Build the object for IncludeRole without arguments
    include_role_0 = IncludeRole()
    # Invoke get_block_list method
    include_role_0.get_block_list()


# Generated at 2022-06-25 06:12:44.418842
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()

    # Replace the builtin open in order to be able to get Roles for unit testing
    display.verbosity = -1
    test_case = {
        'name': 'a_role_name',
        'apply': {},
        'allow_duplicates': 'yes',
        'vars_from': 'some_key'
    }
    include_role_0.load(data=test_case, block=Block(), role=Role(), task_include=TaskInclude())
    assert include_role_0.args['name'] == 'a_role_name'
    assert include_role_0.args['allow_duplicates'] == 'yes'
    assert include_role_0._role_name == 'a_role_name'
    assert include_role_0.allow_du

# Generated at 2022-06-25 06:12:47.481017
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: test if IncludeRole.get_block_list() works properly.
    pass


# Generated at 2022-06-25 06:12:50.858267
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
  include_role = IncludeRole()
  with pytest.raises(AnsibleParserError) as ex:
      include_role.load({}, variable_manager=None, loader=None)
  assert 'is a required field' in ex.value.message
  with pytest.raises(AnsibleParserError) as ex:
      include_role.load({'name': ''}, variable_manager=None, loader=None)
  assert 'is a required field' in ex.value.message

# Generated at 2022-06-25 06:15:25.866904
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole.load({
        'name' : 'name',
        'role' : 'role',
        'tasks_from' : 'tasks_from',
        'vars_from' : 'vars_from',
        'defaults_from' : 'defaults_from',
        'handlers_from' : 'handlers_from',
        'apply' : 'apply',
        'public' : 'public',
        'allow_duplicates' : 'allow_duplicates',
        'rolespec_validate' : 'rolespec_validate',
    })
    assert include_role_1._role_name == 'name'

# Generated at 2022-06-25 06:15:33.807012
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import pytest
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    dumper = AnsibleDumper(None)


# Generated at 2022-06-25 06:15:37.129648
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    name_0 = include_role_0.get_name()
    assert name_0 == "include_role : None"
