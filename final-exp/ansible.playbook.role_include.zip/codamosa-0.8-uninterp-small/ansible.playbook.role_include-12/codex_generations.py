

# Generated at 2022-06-25 06:05:43.292974
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass



# Generated at 2022-06-25 06:05:48.248311
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Initialization
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)

    # Call method
    include_role_0.get_block_list()


# Generated at 2022-06-25 06:05:51.471094
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    str_0 = include_role_0.get_name()
    assert str_0 == "include_role : include_role"

# Testing for class IncludeRole

# Generated at 2022-06-25 06:05:53.042659
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # FIXME: Test will fail until you implement this method.
    assert False


# Generated at 2022-06-25 06:05:59.774451
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()

    # Call method
    try:
        include_role_0.get_block_list(bool_0, bool_1, bool_2, bool_3, bool_4, bool_5)
    except SystemExit as exception:
        pass


# Generated at 2022-06-25 06:06:09.461479
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.utils.vars import merge_hash
    add_all_plugin_dirs()

    ds = Display()
    ds.verbosity = 100

    varman = VariableManager()
    loader = AnsibleLoader(ds, var_manager=varman, template_class=Templar)
    hostname = 'fakehost'
    filename = '/some/path/here'

    # test with 'weak' role name

# Generated at 2022-06-25 06:06:12.664248
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    include_role_0.get_block_list()


# Generated at 2022-06-25 06:06:17.276589
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # initialize with a few variables
    group = Group('local')
    host = Host(name='127.0.0.1')
    group.add_host(host)
    inventory = InventoryManager(loader="")
    inventory.add_group(group)
    variable_manager = VariableManager(loader="", inventory=inventory)
    variable_manager.set_host_variable(host, 'ansible_password', 'bogus')

    # create a play and role to load
    play_

# Generated at 2022-06-25 06:06:20.690759
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    float_0 = 2434.9834
    include_role_1 = IncludeRole(float_0)
    print('Test failed at: {}'.format(inspect.getframeinfo(inspect.currentframe())[:3]))


# Generated at 2022-06-25 06:06:27.555956
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_loader = None
    my_variable_manager = None
    my_task_include = None
    my_block = None
    my_role = None
    data = None
    test_result = IncludeRole.load(data, block=my_block, role=my_role, task_include=my_task_include, variable_manager=my_variable_manager, loader=my_loader)
    # Now test the method
    test_result.load(data, block=my_block, role=my_role, task_include=my_task_include, variable_manager=my_variable_manager, loader=my_loader)


# Generated at 2022-06-25 06:06:41.851295
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    include_role_0._from_files = dict()
    include_role_0._role_name = 'role_name_0'
    include_role_0._role_path = 'role_path_0'
    include_role_0._parent_role = 'parent_role_0'
    include_role_0.statically_loaded = False
    include_role_0.args = 'args_0'
    include_role_0.block = 'block_0'
    include_role_0.always_run = 'always_run_0'
    include_role_0.action = 'action_0'
    include_role_0.name = 'name_0'
    include_role_0.run_

# Generated at 2022-06-25 06:06:46.528169
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)


# Generated at 2022-06-25 06:06:56.986480
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data_0 = {'tags': ['task']}
    role_0 = Role()
    loader_0 = {}
    variable_manager_0 = {}
    block_0 = Block()
    task_include_0 = TaskInclude()
    include_role_0 = IncludeRole.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)
    print(include_role_0._role_name)
    print(include_role_0._from_files)
    print(include_role_0.get_name())
    print(include_role_0._allow_duplicates)
    print(include_role_0._public)
    print(include_role_0._rolespec_validate)

# Generated at 2022-06-25 06:07:03.232153
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block_0 = Block()
    role_0 = Role()
    task_include_0 = TaskInclude()
    include_role_0 = IncludeRole.load(block_0, role_0, task_include_0)


# Generated at 2022-06-25 06:07:06.140035
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    str_0 = include_role_0.get_name()
    assert str_0 == 'include_role : (TASK)', 'str_0 != "include_role : (TASK)"'


# Generated at 2022-06-25 06:07:08.765675
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    include_role_0.get_block_list()


# Generated at 2022-06-25 06:07:16.591102
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Initialize test variables
    block_0 = []
    play_0 = []
    variable_manager_0 = []
    loader_0 = []

    include_role_0 = IncludeRole(block_0)
    include_role_0.get_block_list(play_0, variable_manager_0, loader_0)

    # Asserts
    assert include_role_0


# Generated at 2022-06-25 06:07:22.756567
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    float_1 = 2434.9834
    include_role_0 = IncludeRole(float_1)
    str_0 = include_role_0.get_name()
    assert str_0 == 'Task :'


# Generated at 2022-06-25 06:07:29.633545
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    # Play object should be passed as argument for dynamic include roles
    # play_0 = Play()
    # assert include_role_0.get_block_list(play_0) == "abertura de um escritório de arquitetura"


# Generated at 2022-06-25 06:07:31.830241
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    float_0 = 697.14672
    include_role_0 = IncludeRole(float_0)
    include_role_0._parent_role = None
    include_role_0._role_path = '_role_path'
    # assert include_role_0.get_include_params() == {'ansible_role_path': '_role_path'}


# Generated at 2022-06-25 06:07:53.690751
# Unit test for method get_include_params of class IncludeRole

# Generated at 2022-06-25 06:08:00.917186
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    play_0 = Block()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    a_list_0, a_list_1 = include_role_0.get_block_list(play_0, variable_manager_0, loader_0)
    print(len(a_list_0))
    print(len(a_list_1))
    print(a_list_0)

if __name__ == "__main__":
    test_case_0()
    test_IncludeRole_get_block_list()

# Generated at 2022-06-25 06:08:08.384246
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    task_include_0 = TaskInclude(float_0)
    task_include_0._ds = [item for item in ['']]
    bool_5 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_

# Generated at 2022-06-25 06:08:11.840826
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Parameters

    # Return type:  (blocks, handlers)
    return_value = None # TODO make this return something
    expected_type = (tuple, tuple) # TODO make this return something
    assert isinstance(return_value, expected_type)


# Generated at 2022-06-25 06:08:20.356768
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # path/to/file.yml contains:
    # - hosts: all
    #   tasks:
    #   - include_role:
    #       name: test-playbooks.include_role

    play_path = 'path/to/file.yml'
    play_name = 'Test Play'

    loader, inventory, variable_manager = utils.load_resources(play_path=play_path, play_name=play_name)

    # create play, load based on file path
    play = Play()
    play.load(loader=loader, variable_manager=variable_manager, use_handlers=False)
    play._post_validate()

    assert len(play.tasks) == 1

    block_list, _ = play.tasks[0].get_block_list()


# Generated at 2022-06-25 06:08:24.537772
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # instantiate IncludeRole
    include_role_0 = IncludeRole()
    # load data for class IncludeRole
    include_role_0.load(include_role_0)
    # clean up


# Generated at 2022-06-25 06:08:30.105316
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
  # Below should raise error
  try:
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    block_1 = mock.Mock(Block)
    play_2 = mock.Mock(Play)
    variable_manager_3 = mock.Mock(VariableManager)
    loader_4 = mock.Mock(DictDataLoader)
    include_role_0.get_block_list(play=play_2, variable_manager=variable_manager_3, loader=loader_4)
  except Exception:
    pass


# Generated at 2022-06-25 06:08:32.610484
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    module_sig = IncludeRole(float_0)
    block_sig = IncludeRole(float_0)
    role_sig = IncludeRole(float_0)
    task_include_sig = IncludeRole(float_0)
    result = IncludeRole.load(module_sig, block_sig, role_sig, task_include_sig)
    assert result == None


# Generated at 2022-06-25 06:08:36.575422
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(name = 'foo', val = 43)
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = dict()
    loader = dict()
    tester = IncludeRole.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:08:45.826927
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # FIXME: May be deprecated in some future release.
    # FIXME: This test may fail for incorrect reasons.
    # FIXME: The fixture `_tmp_file_path` may fail for incorrect reasons.
    # FIXME: The fixture `_parser` may fail for incorrect reasons.
    # FIXME: The fixture `_loader` may fail for incorrect reasons.
    # FIXME: The fixture `_play` may fail for incorrect reasons.
    # FIXME: The fixture `_variables` may fail for incorrect reasons.
    # FIXME: Unclear if we will support `statically_loaded` in Ansible 2.0
    include_role_0 = IncludeRole(2434.9834)
    include_role_1 = IncludeRole(2434.9834)
    data_0 = C.DEFAULT_HASH
    task = include_

# Generated at 2022-06-25 06:09:03.100623
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    float_0 = 2434.9834
    ir_0 = IncludeRole(float_0)
    data_0 = 2434.9834
    block_0 = 2434.9834
    role_0 = 2434.9834
    task_include_0 = 2434.9834
    variable_manager_0 = 2434.9834
    loader_0 = 2434.9834
    ir_load_0 = ir_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 06:09:10.176014
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play
    from ansible.playbook.role import role_load

    myplay = Play(name='test_play')
    myplay.start_at_done = 'test_task'

    role_0 = role_load(dict(), play=myplay, variable_manager=None, loader=None) # Dummy value for play, variable_manager and loader
    include_role_0 = IncludeRole(role_0)
    include_role_0.get_block_list()


# Generated at 2022-06-25 06:09:16.441297
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    play_0 = {}
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    float_1 = 2434.9834
    loader_0 = {}
    variable_manager_0 = {}
    blocks, handlers = include_role_0.get_block_list(play_0, variable_manager_0, loader_0)
    testcases = [play_0, float_1, loader_0, variable_manager_0, blocks, handlers]


# Generated at 2022-06-25 06:09:18.653647
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    include_params_0 = include_role_0.get_include_params()
    print(include_params_0)


# Generated at 2022-06-25 06:09:22.185727
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 1168.17
    include_role_0 = IncludeRole(float_0)

    # In this case method arguments are not passed
    block_list_0 = include_role_0.get_block_list()

    # In this case method arguments are not passed
    block_list_1 = include_role_0.get_block_list()


# Generated at 2022-06-25 06:09:24.694244
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # load data from yaml file
    include_role_0 = IncludeRole(yaml_file_path)


# Generated at 2022-06-25 06:09:34.556355
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    a = Block()
    b = Block()
    c = Block()
    d = Block()
    e = Block()
    f = Block()
    g = Block()
    h = Block()
    i = Block()
    j = Block()
    k = Block()
    l = Block()
    m = Block()
    n = Block()
    o = Block()
    p = Block()
    q = Block()
    r = Block()
    s = Block()
    t = Block()
    u = Block()
    v = Block()
    w = Block()
    x = Block()
    y = Block()
    z = Block()
    include_role_0 = IncludeRole(a)
    include_role_0._role_name = "roles1"

# Generated at 2022-06-25 06:09:43.434715
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Checks that the method get_block_list of class IncludeRole
    # raises RuntimeError if the passed paramaters are not of type
    # ansible.playbook.play.Play or ansible.vars.manager.VariableManager or
    # ansible.parsing.dataloader.DataLoader.

    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)

    # Creating an instance of a class
    # which inherits from BaseException class
    try:
        # This method call the get_block_list method of class IncludeRole
        # with the above params and verify that it raises a RuntimeError
        # exception.
        include_role_0.get_block_list(None, None, None)
    except RuntimeError:
        assert True

    # Creating an instance of a class
   

# Generated at 2022-06-25 06:09:49.944142
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    #  given create an IncludeRole
    include_role_0 = IncludeRole()

    #  given given data to load
    data = {}

    #  given given a variable manager
    variable_manager = None

    #  given given a loader
    loader = None

    #  when when we load
    include_role_0 = include_role_0.load(data, variable_manager, loader)
    #  then should return
    assert include_role_0 != None, "Type error or assert error"

# Generated at 2022-06-25 06:09:56.245993
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()

    # test default value of parameter block = null
    # test default value of parameter role = null
    # test default value of parameter task_include = null
    # test default value of parameter variable_manager = null
    # test default value of parameter loader = null
    # ensure that IncludeRole._from_files is a dict
    assert isinstance(include_role_1._from_files, dict) is True

    # ensure that _from_files is empty
    assert len(include_role_1._from_files) == 0

    # ensure that parent role is None
    assert include_role_1._parent_role is None

    # ensure that role name is None
    assert include_role_1._role_name is None

    # ensure that role path is None

# Generated at 2022-06-25 06:10:36.173610
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # assert IncludeRole.get_block_list() == NotImplemented
    pass


# Generated at 2022-06-25 06:10:39.117696
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Parameters
    play = None
    variable_manager = None
    loader = None

    # Instantiate the class
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)

    # Call the method
    block_list = include_role_0.get_block_list()


# Generated at 2022-06-25 06:10:43.499149
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict()
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = object()
    loader = object()
    include_role_1 = IncludeRole.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:10:46.335393
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    try:
        float_1 = 2434.9834
        include_role_1 = IncludeRole(float_1)
        include_role_1.get_block_list()
    except:
        raise

# Generated at 2022-06-25 06:10:48.083842
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # FIXME: unit test this method
    return


# Generated at 2022-06-25 06:10:50.601117
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    str_0 = include_role_0.get_name()
    return str_0


# Generated at 2022-06-25 06:10:55.459413
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    result_0 = include_role_0.get_name()
    assert isinstance(result_0, basestring) or isinstance(result_0, StringType) or result_0 is None


# Generated at 2022-06-25 06:11:02.363613
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 515.20317
    include_role_0 = IncludeRole(float_0)
    boolean_0 = True
    dict_0 = dict()
    task_include_0 = TaskInclude(boolean_0)
    block_0 = Block(dict_0, task_include_0)
    include_role_0.get_block_list(block_0)


# Generated at 2022-06-25 06:11:10.179318
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    params = dict({'defaults_from': 'string_0', 'handlers_from': 'string_1', 'tasks_from': 'string_2', 'role': 'string_3', 'vars_from': 'string_4', 'name': 'string_5', 'allow_duplicates': False, 'public': True, 'rolespec_validate': False, 'apply': {'key_0': 'string_6', 'key_1': 'string_7'}})
    include_role_0 = IncludeRole(params)
    assert include_role_0.get_name() == 'include_role : string_5'


# Generated at 2022-06-25 06:11:19.698403
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_1 = 2434.9834
    include_role_1 = IncludeRole(float_1)
    # play was not specified and thus is None, however, in the actual code this is not a problem as _parent is not None
    # TODO: refactor this test once we have a test play setup that can be used to test dynamic behavior
    play_0 = None
    # variable_manager was not specified and thus is None, however, in the actual code this is not a problem as _parent is not None
    # TODO: refactor this test once we have a test play setup that can be used to test dynamic behavior
    variable_manager_0 = None
    # loader was not specified and thus is None, however, in the actual code this is not a problem as _parent is not None
    # TODO: refactor this test once we have a test play setup that can

# Generated at 2022-06-25 06:12:14.416448
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:12:19.670785
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # data = dict()
    # role = Role()
    # include_role_0 = IncludeRole(data, role)

    # TODO: implement assertions
    raise NotImplementedError('Unimplemented test case')


# Generated at 2022-06-25 06:12:24.694653
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)
    include_role_0.get_block_list()


# Generated at 2022-06-25 06:12:33.809923
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager

    myplaybook = Playbook.load(playbook_path='/etc/ansible/playbooks/test.yml')
    allhosts = myplaybook.inventory.get_hosts(pattern='*')
    variable_manager = VariableManager(loader=myplaybook._loader, inventory=myplaybook.inventory)
    variable_manager.extra_vars = ImmutableDict(ansible_ssh_user='vagrant')
    play_context = PlayContext()
    
    include_role_0 = IncludeRole()
    my

# Generated at 2022-06-25 06:12:39.806609
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    play_0 = Play()
    include_role_0 = IncludeRole(None)
    available_variables_0 = (include_role_0).get_vars(play_0, None)
    block_list_0, handlers_0 = (include_role_0).get_block_list(play_0, None, None)


# Generated at 2022-06-25 06:12:46.226014
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from collections import OrderedDict

    data = OrderedDict()
    data['name'] = "test"
    data['tasks_from'] = 'test.yml'
    data['vars_from'] = 'test'
    data['public'] = True

    display.display('data: %s' % data)
    ret = IncludeRole.load(data)
    display.display('ret: %s' % ret)
    display.display('ret.vars: %s' % ret.vars)

    assert ret is not None


# Generated at 2022-06-25 06:12:55.021860
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    yaml_0 = 'tasks : - include_role : name=webservers'
    block_0 = Block.load(yaml_0, task_include='/Users/automation/Documents/workspace/ansible_roles')
    variable_manager_0 = '/Users/automation/Documents/workspace/ansible_roles'
    loader_0 = '/Users/automation/Documents/workspace/ansible_roles'
    load_0 = IncludeRole.load(block_0, variable_manager=variable_manager_0, loader=loader_0)


# Generated at 2022-06-25 06:13:04.764978
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    float_0 = 2434.9834
    include_role_0 = IncludeRole(float_0)

    #
    # IncludeRole load()
    #
    # with params
    #
    list_0 = ['get_joke', 'nofun', 'pet']
    list_1 = ['name', 'role']
    dict_0 = dict(zip(list_1 + list_0, list_0 + list_1))
    dict_2 = dict_0.copy()
    dict_2['task'] = include_role_0.task
    dict_3 = dict_0.copy()
    dict_3['task'] = include_role_0.task
    dict_2['tags'] = include_role_0.tags
    dict_2['when'] = include_role_0.when

# Generated at 2022-06-25 06:13:09.209759
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Set up mock objects
    block = Block()
    role = Role()
    task_include = TaskInclude()

    # Call IncludeRole.load with mock objects
    include_role_0 = IncludeRole(block, role, task_include=task_include)
    include_role_1 = include_role_0.get_block_list(None, None, None)
    assert len(include_role_1) == 2


# Generated at 2022-06-25 06:13:17.473046
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    dict_0 = dict(extra="fubar")
    dict_1 = dict(default="fubar")
    dict_2 = dict(rval="fubar")
    dict_3 = dict(fubar="fubar")
    dict_4 = dict(type="fubar")
    dict_5 = dict(argspec="fubar")
    dict_6 = dict(meta="fubar")
    dict_7 = dict(type="fubar")
    dict_8 = dict(get_name="fubar")
    dict_9 = dict(get_role_params="fubar")
    dict_10 = dict(rval="fubar")
    dict_11 = dict(rval="fubar")
    dict_12 = dict(rval="fubar")
    dict_13