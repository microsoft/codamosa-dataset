

# Generated at 2022-06-25 06:05:45.934938
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Following test case checks when parent role is not specified, it is handled gracefully
    include_role_0 = IncludeRole()
    assert include_role_0.get_include_params() == {}

# Generated at 2022-06-25 06:05:48.654327
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole(None, None, None)
    assert 'None' == include_role_0.get_name()



# Generated at 2022-06-25 06:05:57.553737
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role._role_name = 'test_role'
    include_role.vars = dict()
    include_role._rolespec_validate = False
    include_role.collections = list()
    include_role.allow_duplicates = True
    include_role._from_files = dict()

    loader = None
    variable_manager = None
    role = Role()
    role.tasks = list()
    block = Block()
    block._role = role
    block._dependencies = list()
    include_role._parent = block

    class FakePlay:
        def __init__(self):
            self.handlers = list()
    play = FakePlay()


# Generated at 2022-06-25 06:06:06.828400
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    data = dict(
        name='myrole',
        apply=dict(
            tags=['tag'],
            ignore_errors=True
        ),
        tags=['tag1'],
        ignore_errors=False,
    )
    include_role = IncludeRole.load(data)
    assert include_role.name == 'myrole'
    assert include_role.tags == ['tag1']
    assert include_role.ignore_errors is False
    assert include_role.get_block().tags == ['tag']
    assert include_role.get_block().ignore_errors is True


# Generated at 2022-06-25 06:06:12.710927
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_case_1_include_role_1 = IncludeRole()
    assert test_case_1_include_role_1.get_name() == "include_role : "


# Generated at 2022-06-25 06:06:21.809574
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    include_role_0.name = 'some name'
    result = include_role_0.get_include_params()
    assert result['include_role_name'] == include_role_0.name
    assert result['include_role_file'] == None
    assert result['include_role_tasks'] == []
    assert result['include_role_vars'] == []
    assert result['include_role_handlers'] == []
    assert result['include_role_defaults'] == []
    assert result['include_role_meta'] == {}
    assert result['include_role_deps_files'] == []
    assert result['include_role_deps'] == []
    assert result['include_role_paths'] == []
    assert result['include_role_names'] == []


# Generated at 2022-06-25 06:06:28.554690
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    include_role_2 = IncludeRole()
    include_role_3 = IncludeRole()
    include_role_4 = IncludeRole()
    include_role_5 = IncludeRole()
    include_role_6 = IncludeRole()
    include_role_7 = IncludeRole()
    include_role_8 = IncludeRole()
    include_role_9 = IncludeRole()
    include_role_10 = IncludeRole()
    include_role_11 = IncludeRole()


# Generated at 2022-06-25 06:06:34.349579
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.display("Testing: IncludeRole.get_block_list")
    include_role_1 = IncludeRole()
    assert include_role_1.get_block_list()[0] == []
    assert include_role_1.get_block_list()[1] == []

    print("done testing IncludeRole.get_block_list")


# Generated at 2022-06-25 06:06:35.259475
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    pass

# Generated at 2022-06-25 06:06:43.504290
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    parent_block_0 = Block()
    role_0 = Role()
    role_0._metadata = role_0
    role_0.name = 'name_0'
    parent_block_0.post_validate = parent_block_0.post_validate
    parent_block_0.vars = {}
    parent_block_0.roles = []
    parent_block_0.handlers = []
    parent_block_0._parent = role_0
    role_0.post_validate = role_0.post_validate
    role_0._dependencies = []
    role_0.path = 'path_0'
    role_0._parents = [role_0]
    role_0._role_path = 'path_1'
    role_0

# Generated at 2022-06-25 06:06:52.958300
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.info("---- test_IncludeRole_get_block_list ----")
    include_role = IncludeRole()
    block_list = include_role.get_block_list()
    assert block_list is None



# Generated at 2022-06-25 06:06:59.160724
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Construct an object of the class 'IncludeRole'
    include_role_0 = IncludeRole()
    # Call the method get_block_list of the object 'include_role_0'
    new_return_value = include_role_0.get_block_list()

# Generated at 2022-06-25 06:07:09.042079
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    try:
        test_template_0 = IncludeRole.load(
            dict(
                name='foo',
                role='bar'
            ),
            block=Block(),
            role=Role(),
            task_include=TaskInclude(),
            loader=None,
            variable_manager=VariableManager()
        )
    except AnsibleParserError as e:
        assert False



# Generated at 2022-06-25 06:07:17.755540
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block = Block()
    role = Role()
    task_include = TaskInclude()

    # TODO: replace with valid arguments that would be representative of the actual method in actual use
    mock_play = 'mock_play'
    mock_variable_manager = 'mock_variable_manager'
    mock_loader = 'mock_loader'
    blocks, handlers = include_role_0.get_block_list(play=mock_play, variable_manager=mock_variable_manager, loader=mock_loader)

    return blocks, handlers


# Generated at 2022-06-25 06:07:20.245944
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role._parent = Block(parent=None)
    block, handlers = include_role.get_block_list()
    assert block == []
    assert handlers == []

# Generated at 2022-06-25 06:07:23.070827
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    data = "Please create your data"
    IncludeRole.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-25 06:07:34.233577
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test when required parameters are not provided.
    play = mock.Mock(spec=Play)
    play.handlers = mock.Mock()
    play.handlers.__len__ = mock.Mock()
    play.handlers.__len__.assert_called_once()

    var_manager = mock.Mock(spec=VariableManager)
    var_manager.get_vars = mock.Mock()
    var_manager.get_vars.assert_called_once()

    loader = mock.Mock(spec=DataLoader)

    role = mock.Mock(spec=Role)
    block = mock.Mock(spec=Block)

    include_role = IncludeRole(block=block, role=role)


# Generated at 2022-06-25 06:07:36.190389
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    name = include_role_0.get_name()
    assert name is None


# Generated at 2022-06-25 06:07:44.183993
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role.meta import RoleMetadata
    role = Role()
    role._parent = Block()
    role._metadata = RoleMetadata("myrole")
    role._role_name = 'myrole'

    include_role = IncludeRole()
    include_role.name = 'include_role'
    include_role._parent_role = role

    params = include_role.get_include_params()
    assert params['ansible_parent_role_name'] == 'myrole'


# Generated at 2022-06-25 06:07:53.691149
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    print(test_IncludeRole_get_name.__doc__)

    # Test with empty IncludeRole
    test_case_0()

    # Test with IncludeRole where name is empty
    include_role_1 = IncludeRole()
    include_role_1._role_name = ''

    assert include_role_1.get_name() == "include_role : "

    # Test with IncludeRole where name not empty
    include_role_2 = IncludeRole()
    include_role_2._role_name = 'test_role_name'

    assert include_role_2.get_name() == "include_role : test_role_name"

    # Test with IncludeRole where name is None
    include_role_3 = IncludeRole()
    include_role_3._role_name = None


# Generated at 2022-06-25 06:08:12.341763
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    try:
        include_role_0 = IncludeRole()
        data = [
            {
                'foo': 'bar',
                'name': 'baz'
            }
        ]
        IncludeRole.load(data)
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-25 06:08:19.044838
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block(play=None)
    role = Role()
    task_include = TaskInclude()
    variable_manager = {}
    loader = {}
    data = {
        'name': 'test',
        'apply': {
            'a': 'b',
        },
    }
    try:
        include_role_instance = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Expected to raise AnsibleParserError but did not')


# Generated at 2022-06-25 06:08:27.563307
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_load_0 = IncludeRole()
    assert include_role_load_0.load_data({}) is None
    assert include_role_load_0.load_data({'name': 'toto'}) is None
    include_role_load_0.load_data({'name': 'toto', 'flags': 'yes'})
    assert include_role_load_0.load_data({'name': 'toto', 'rolespec_validate': 'no'}) is None

# Generated at 2022-06-25 06:08:33.153458
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Load the include_role task test_case_0
    include_role_task = IncludeRole.load(test_case_0(), block=Block(), role=Role(), task_include=TaskInclude())


# Generated at 2022-06-25 06:08:34.705125
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == ''


# Generated at 2022-06-25 06:08:37.246608
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    d = dict(
        name='some_role',
    )
    ir = IncludeRole.load(d)
    # Call method
    ir.get_block_list()

# Generated at 2022-06-25 06:08:44.581041
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    action_0 = "include_role"
    action_1 = "include_role"
    args_0 = dict()
    args_0["name"] = "a_name_0"
    args_1 = dict()
    args_1["name"] = "a_name_1"
    args_2 = dict()
    args_2["name"] = "a_name_2"
    args_2["public"] = "a_public_2"
    # TODO: how to create an object of class dict, which allows __getitem__
    # TODO: how to create an object of class dict, which allows __getitem__
    # TODO: how to create an object of class dict, which allows __getitem__
    # TODO: how to create an object of class dict, which allows __getitem__
    # TODO:

# Generated at 2022-06-25 06:08:45.021882
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert True

# Generated at 2022-06-25 06:08:54.019249
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
  include_role = IncludeRole()
  print("\nTesting load method of IncludeRole class\n")

# Generated at 2022-06-25 06:09:03.141278
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-25 06:09:20.247351
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    """Test for method get_name of class IncludeRole"""
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == 'include_role : None'


# Generated at 2022-06-25 06:09:22.068625
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_2 = IncludeRole()

    assert include_role_2.get_name() == 'include_role :'


# Generated at 2022-06-25 06:09:31.371685
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import ansible.parsing.dataloader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from collections import namedtuple
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.plugins import module_loader
    from ansible.parsing.mod_args import ModuleArgsParser
    
    # config = ansible.utils.config.Configuration()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-25 06:09:35.091059
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
  include_role_extended = IncludeRole()

  assert include_role_extended.get_include_params() == {'ansible_context_name': 'IncludeRole', 'ansible_context_key': 'IncludeRole'}


# Generated at 2022-06-25 06:09:40.069554
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block_0 = Block()
    play_0 = Play()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    result = include_role_0.get_block_list(play=play_0, variable_manager=variable_manager_0, loader=loader_0)
    assert result is not None, "IncludeRole: block_list is none"


# Generated at 2022-06-25 06:09:42.075142
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Need to compare the block_list data right after executing
    # raise error when not equal
    raise Exception('Test Not implemented')


# Generated at 2022-06-25 06:09:47.419587
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test for method get_block_list of class IncludeRole
    """
    play = AnsiblePlay()
    block = Block()
    role = Role()
    task_include = Include()
    obj = IncludeRole(block, role, task_include)

    with pytest.raises(AnsibleParserError):
        obj.get_block_list(play, None)

# Generated at 2022-06-25 06:09:50.129638
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0_0 = IncludeRole()
    include_role_0_0.args = dict()
    include_role_0_0.args['name'] = include_role_0_0
    include_role_0_0.load()

# Generated at 2022-06-25 06:09:53.883087
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_load = IncludeRole()
    setattr(include_role_load, '_parent', 'test_parent')
    include_role_load.load({'role': 'test_role_name'}, {'loader': 'test_loader'})
    role_name = include_role_load._role_name
    assert role_name == 'test_role_name'


# Generated at 2022-06-25 06:10:00.590821
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.debug("test_IncludeRole_get_block_list()")
    include_role = IncludeRole()
    include_role._role_name = 'role_name'

    # test 1 - block list

# Generated at 2022-06-25 06:10:26.853153
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Unit test for method load of class IncludeRole
    # Ensures that the method 'load' throws an exception when no name is provided
    include_role_1 = IncludeRole()
    dict_1 = dict()
    dict_1['role'] = 'test.test'
    dict_1['public'] = 'test.test'

    # include_role_1 is of class IncludeRole
    assert isinstance(include_role_1, IncludeRole)
    assert not isinstance(include_role_1, Block)

    dict_2 = dict()
    dict_2['role'] = 'test.test'

    # include_role_1 is of class IncludeRole
    assert isinstance(include_role_1, IncludeRole)
    assert not isinstance(include_role_1, Block)


# Generated at 2022-06-25 06:10:29.905292
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    if hasattr(IncludeRole, '_load'):
        delattr(IncludeRole, '_load')
    include_role_0 = IncludeRole()
    assert include_role_0._load('name') is None


# Generated at 2022-06-25 06:10:37.584044
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    import ansible.constants as C
    block = Block()
    role = Role(name='test_role')
    role._role_path = '/home/rol_name'
    task_include = TaskInclude.load('- name: test_task_include\n  test_option: test_value')
    include_role = IncludeRole(block=block, role=role, task_include=task_include)
    from ansible.playbook.task_include import TaskInclude
    blocks, handlers = include_role.get_block_list()
    # Check if blocks is a list and all elements in blocks are Block objects
    assert isinstance(blocks, list)
    all_block_objects = True
    for block in blocks:
        if not isinstance(block, Block):
            all

# Generated at 2022-06-25 06:10:39.269779
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    try:
        include_role_0.load("test_string")
    except SystemExit:
        pass


# Generated at 2022-06-25 06:10:41.985434
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role_0 = IncludeRole(block, role, task_include)
    play = Play()
    variable_manager = VariableManager()
    loader = DataLoader()
    include_role_0.get_block_list(play, variable_manager, loader)

# Generated at 2022-06-25 06:10:45.102006
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test for not enough arguments
    try:
        IncludeRole.load()
    except TypeError as e:
        assert str(e) == "<lambda>() missing 1 required positional argument: 'data'"



# Generated at 2022-06-25 06:10:52.071286
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # include_role = IncludeRole()

    action = 'include_role'
    args = {'name': 'foo', 'apply': {'x': 1}}
    block = '- include_role: name: foo\n  apply:\n    x: 1'

    # Test Role()
    role = Role()
    include_role = IncludeRole(block=block, role=role)

    # Test simple data element
    include_role.load(data=args)
    assert include_role.name == 'foo'

    # IncludeRole.load()
    include_role = IncludeRole.load(data=block)
    assert include_role.name == 'foo'
    assert include_role.apply.x == 1

# Generated at 2022-06-25 06:10:55.490464
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Test get_block_list method of class IncludeRole returns a list of blocks.
    '''
    test_0 = IncludeRole()
    assert test_0.get_block_list() is not None


# Generated at 2022-06-25 06:11:05.018277
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # The IncludeRole object for test
    ir = IncludeRole()
    # mock the role object
    from ansible.release import __version__ as ansible_version
    r = Role()
    r._metadata = r._metadata._replace(role_name = 'test_role')
    r.vars = {'a_var': 'a_value'}
    r.default_vars = {'a_default_var': 'a_value'}
    r.collections = ['col1', 'col2']
    ir._role_name = r.get_name()
    ir._parent_role = r
    ir._from_files = {'tasks': 'tasks.yml', 'vars': 'vars.yml', 'defaults': 'defaults.yml'}
    # mock the play object

# Generated at 2022-06-25 06:11:14.804660
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_cases = [
        { "action": "include_role",
          "args": { "name": "testing" }
        },
        { "action": "import_role",
          "args": { "name": "testing" }
        }
    ]

    display.verbosity = 3
    for test_case in test_cases:
        try:
            display.debug("testing: %s" % test_case)
            ir = IncludeRole.load(test_case)
            assert ir.action in C._ACTION_INCLUDE_ROLE
            assert ir.args["name"] == "testing"
        except AnsibleParserError as e:
            display.debug("Failed to load (%s): %s" % (test_case, e))
            assert False



# Generated at 2022-06-25 06:11:47.495988
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole(block=Block(role=Role()))
    name_0 = include_role_0.get_name()
    assert name_0 == ''


# Generated at 2022-06-25 06:11:54.922602
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test with valid parameters and loading a file
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    options = dict(connection='local', module_path=None, forks=10, remote_user='root',
                   private_key_file='/fake/key', verbosity=3, ansible_managed=C.DEFAULT_MANAGED_STR,
                   become=False, become_method=None, become_user=None, check=False,
                   listhosts=False, listtasks=False, listtags=False, syntax=False, diff=False)
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-25 06:12:00.838211
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    data = {
        'apply': {
            'foo': 'foovalue',
            'bar': 'barvalue'
        },
        'name': 'foobar.baz'
    }
    block = Block()
    role = Role()
    variable_manager = None
    loader = None
    include_role.load(data, block, role, variable_manager, loader)

# Generated at 2022-06-25 06:12:12.325969
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list=["127.0.0.1"])

    block = Block()
    role = Role()
    task_include = TaskInclude()

    include_role = IncludeRole.load({}, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 06:12:20.056629
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Load the include_role without any parameters
    include_role_0 = IncludeRole()
    # Assert that the action of the include_role is 'include_role'
    assert include_role_0.action == 'include_role'
    # Load the include_role with all valid parameters
    include_role_1 = IncludeRole.load({'name': 'myrole', 'public': True})
    # Assert that the include_role has the correct name
    assert include_role_1.name == 'myrole'

# Generated at 2022-06-25 06:12:28.566553
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-25 06:12:33.828597
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    role = "some_role"
    myrole = IncludeRole.load(dict(name=role))

    # Test case with no data
    assert myrole.get_block_list() is ([], [])

# Generated at 2022-06-25 06:12:37.548757
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    x = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 06:12:41.476665
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'foo': 'bar'}
    include_role_0 = IncludeRole()
    display.verbosity = 4
    assert include_role_0.load(data=data) == include_role_0


# Generated at 2022-06-25 06:12:47.055984
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data_0 = {}
    block_0 = Block()
    role_0 = Role()
    task_include_0 = TaskInclude()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    include_role_1 = include_role_0.load(data_0, block_0, role_0, task_include_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 06:14:30.876801
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole(block=None, role=None, task_include=None)
    assert include_role_1.get_block_list() is not False


# Generated at 2022-06-25 06:14:38.665384
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    role_dir = __file__.split('/lib/ansible/playbook/')[0] + '/test/integration/targets/include_role'
    data = {
        'block': None,
        'role': { 'path': '/nonexisting/role' },
        'args': { 'name': role_dir },
        'action': 'include_role',
        'include_role': { 'path': role_dir }
    }
    include_role_0 = IncludeRole.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    block_list = include_role_0.get_block_list()
    # TODO: validate block_list = ...
    # block_list = ...
    # assert block_list == ...

# Generated at 2022-06-25 06:14:39.925299
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    include_role_0 = include_role.load()


# Generated at 2022-06-25 06:14:46.105664
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert IncludeRole.load({})
    assert IncludeRole.load({}, role=Role(name='test'))
    assert IncludeRole.load({}, task_include=TaskInclude(name='test'))
    assert IncludeRole.load({'name': 'test'})


# Generated at 2022-06-25 06:14:53.355276
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test with openmesh
    print("Test with openmesh")
    include_role_0 = IncludeRole()
    display.vv("IncludeRole: %s"%include_role_0)

    # Test with localhost
    print("Test with localhost")
    include_role_1 = IncludeRole()
    display.vv("IncludeRole: %s"%include_role_1)



# Generated at 2022-06-25 06:14:55.210808
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
   pass


# Generated at 2022-06-25 06:15:01.789343
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Set up the test case
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)

    # Call the code under test
    result = include_role.get_block_list()
    assert not result


# Generated at 2022-06-25 06:15:07.149576
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def loader():
        return None

    def variable_manager():
        return dict()

    data = dict(
        name='role_name',
        vars=dict(),
        tasks=dict(),
        handlers=dict(),
        defaults=dict(),
        meta=dict()
    )

    # test with block
    block = Block()
    role = Role()
    task_include = IncludeRole()

    include_role = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 06:15:11.995081
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    mock_this = IncludeRole()
    mock_play = "mock_play"
    mock_variable_manager = "variable_manager"
    mock_loader = "loader"
    mock_this.get_block_list(mock_play, mock_variable_manager, mock_loader)


# Generated at 2022-06-25 06:15:22.882416
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    data_0 = {
        'include_role': {
            'name': 'b_role'
        }
    }

    ir_0 = IncludeRole.load(data_0)

    assert ir_0._from_files == {
        'tasks': None,
        'vars': None,
        'handlers': None,
        'defaults': None
    }

    assert ir_0._parent_role is None
    assert ir_0._role_name == 'b_role'
    assert ir_0._role_path is None

if __name__ == '__main__':
    test_cases = [
        test_case_0,
        test_IncludeRole_load
    ]