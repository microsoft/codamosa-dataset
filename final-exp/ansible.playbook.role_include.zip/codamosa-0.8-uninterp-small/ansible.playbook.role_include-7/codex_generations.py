

# Generated at 2022-06-25 06:05:52.276984
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # check load without params
    include_role_0 = IncludeRole()
    # check load with args
    include_role_1 = IncludeRole.load({'foo':'bar'})
    # check load with block
    include_role_2 = IncludeRole.load({'foo':'bar'}, block=Block())
    # check load with role
    include_role_3 = IncludeRole.load({'foo':'bar'}, role=Role())
    # check load with task_include
    include_role_4 = IncludeRole.load({'foo':'bar'}, task_include=TaskInclude())

# Generated at 2022-06-25 06:05:53.192437
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    my_include_role = IncludeRole()
    assert my_include_role.get_include_params().keys().__len__() == 0

# Generated at 2022-06-25 06:05:54.123261
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass


# Generated at 2022-06-25 06:05:56.113502
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    block_list = include_role_1.get_block_list()


# Generated at 2022-06-25 06:05:59.689986
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    def mockgetroleparams(self):
        return {}

    from mock import mock_open, patch
    with patch.object(IncludeRole, "get_role_params", new=mockgetroleparams):
        include_role = IncludeRole()
        include_role.get_include_params()

# Generated at 2022-06-25 06:06:04.798380
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # test case initialization
    ir = IncludeRole()
    # expected result
    expected_r = dict(ansible_role_name='', ansible_role_names=[''], ansible_role_path='', ansible_role_paths=[''])
    # testing
    actual_r = ir.get_include_params()
    # assert
    assert actual_r == expected_r, actual_r


# Generated at 2022-06-25 06:06:11.020744
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    block = Block()
    play = None
    variable_manager = None
    loader = None
    block_list = include_role_1.get_block_list(play, variable_manager,loader)
    assert block_list is not None, "%s should not be null" % block_list

# Generated at 2022-06-25 06:06:11.597497
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-25 06:06:13.618666
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(name="test_role")
    include_role = IncludeRole.load(data)
    assert include_role.name == "test_role", "expected name to be test_role, got {0}".format(include_role.name)



# Generated at 2022-06-25 06:06:25.605630
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.errors import AnsibleParserError

    config = {}
    config['data'] = """
    - name: my_role
      role: my_role
    """
    block = Block()
    role = Role()
    task_include = {}

    inc_role = IncludeRole.load(config['data'], block, role, task_include)
    assert inc_role == 'my_role'

    config['data'] = """
    name: my_role
    role: my_role
    """
    inc_role = IncludeRole.load(config['data'], block, role, task_include)
    assert inc_role == 'my_role'

    config['data'] = """
    - name: my_role
      role: my_role
      apply:
        tags:
          - always
    """
    inc

# Generated at 2022-06-25 06:06:33.353335
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole.load(dict(), block=Block(), role=Role(), task_include=None)


# Generated at 2022-06-25 06:06:40.410716
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    # print(include_role_0.__dict__)
    data = {'name': 'role_name', 'rolespec_validate': False, 'vars': {'item1': 'value1'}, 'tags': ['tag1', 'tag2'], 'tasks_from': 'task1.yml', 'handlers_from': 'handler1.yml', 'defaults_from': 'default1.yml'}
    loader_0 = None
    variable_manager_0 = None
    assert IncludeRole.load(data, loader=loader_0, variable_manager=variable_manager_0) != None

# Generated at 2022-06-25 06:06:45.322687
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()

    include_role.args = {'name': 'test_role',
                        'tasks_from': 'test_task',
                        'vars_from': 'test_var',
                        'allow_duplicates': True,
                        'public': True}

    fake_loader = object()
    fake_variable_manager = object()
    fake_play = object()
    fake_blocks = object()
    fake_handlers = object()

    def fake_RoleInclude_load(role_name, play=None, variable_manager=None, loader=None, collection_list=[]):
        if role_name != 'test_role':
            raise AssertionError("The role name does not match the given value")

# Generated at 2022-06-25 06:06:53.382075
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    display.debug('TEST: test_IncludeRole_load')

    # Create a Dict
    data_dict = {}
    data_dict['role'] = 'test_role'

    loader = data_dict

    # Create a Role
    ri = RoleInclude()
    ri.name = 'test_role_for_include'

    # Create a Block
    block = Block()

    # Create a Templat
    templar = Templar()

    # Load the IncludeRole
    include_role_0.load(data_dict, block, ri, templar, loader)

    # Check the IncludeRole
    assert include_role_0 is not None
    assert include_role_0.name == 'test_role_for_include'

# Generated at 2022-06-25 06:06:56.704833
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # test for: load method
    include_role_1 = IncludeRole()
    data1 = 'null'
    block1 = Block()
    role1 = Role()
    task_include1 = IncludeRole()
    variable_manager1 = VariableManager()
    loader1 = DataLoader()
    result = include_role_1.load(data1, block1, role1, task_include1, variable_manager1, loader1)
    assert(result != None)

# Generated at 2022-06-25 06:06:57.139198
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-25 06:07:07.597746
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    include_role_0.name = 'name'
    include_role_0.statically_loaded = False
    include_role_0.tasks_from = '<PATH>'
    include_role_0.vars_from = '<PATH>'
    include_role_0.defaults_from = '<PATH>'
    include_role_0.handlers_from = '<PATH>'
    include_role_0._role_name = '<VALUE>'
    include_role_0._role_path = '<VALUE>'
    include_role_0.args = {'name': 'role'}
    include_role_0.from_files = {'<KEY>': '<VALUE>'}
    include_role_0._parent_role = Role()

# Generated at 2022-06-25 06:07:13.967466
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    # Verify that dynamic loading is enabled by default
    assert include_role_0._dynamic_loading is True

    # Verify that load does nothing
    include_role_0.load(None)

    # Verify that dynamic is enabled after load with a simple dict
    include_role_0.load({})
    assert include_role_0._dynamic_loading is True

    # Verify that dynamic is enabled after load with a dict and a role name
    include_role_0.load({
        'include_role': {
            'name': 'foo'
        }
    })
    assert include_role_0._dynamic_loading is True

    # Verify that dynamic is disabled after load with a dict, a role name and a "static" value

# Generated at 2022-06-25 06:07:18.877561
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ''' Return the name of the task '''
    include_role = IncludeRole()
    # TODO: test
    #assert include_role.get_name() == "included"
    assert True



# Generated at 2022-06-25 06:07:24.435584
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Test the method IncludeRole.load
    :return:
    '''
    data = {'role': 'foo'}
    task_include = {'name': "name", 'private': False, 'tags': [], 'when': [], 'register': ""}
    role = Role()
    block = Block()
    include_role = IncludeRole.load(data, block=block, role=role, task_include=task_include)
    print(include_role)
    print(include_role.get_name())
    print(include_role.get_block_list())


# Generated at 2022-06-25 06:07:49.255283
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_include_role = IncludeRole()
    test_include_role.role_name = "Test"
    test_include_role.tasks_from = "TestTasks"
    test_include_role.vars_from = "Testvars"
    test_include_role.defaults_from = "Testdefaults"
    test_include_role.handlers_from = "Testhandlers"
    test_include_role.rolespec_validate = False

    # Test if get_block_list method return the list of blocks in the block list.
    assert(isinstance(test_include_role.get_block_list(), Block))


# Generated at 2022-06-25 06:08:00.301583
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

#    play_loader_0 = PlaybookLoader()

#    task_loader_0 = TaskLoader()

#    display_0 = Display()

#    role_loader_0 = RoleLoader()

#    block_0 = Block()

#    role_0 = Role()

#    inventory_loader_0 = InventoryLoader()

#    variable_manager_0 = VariableManager()

    my_play = None
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my_play
    my_play = my

# Generated at 2022-06-25 06:08:06.195749
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role._role_name = 'apb_test_role'
    include_role_blocks, include_role_handlers = include_role.get_block_list()
    assert len(include_role_blocks) == 1
    assert len(include_role_handlers) == 2
    assert include_role_blocks[0].__class__.__name__ == 'Play'
    assert include_role_handlers[0].__class__.__name__ == 'Handler'

# Generated at 2022-06-25 06:08:14.939234
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # create role as role_0
    role_0 = Role()

    # create test data

# Generated at 2022-06-25 06:08:15.470709
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass # todo

# Generated at 2022-06-25 06:08:17.267391
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == ": "


# Generated at 2022-06-25 06:08:21.944757
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    print(include_role_0.get_block_list())

# Generated at 2022-06-25 06:08:24.354682
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == None


# Generated at 2022-06-25 06:08:32.597332
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # first test
    include_role_0 = IncludeRole()
    include_role_0.load(data='{{ var_1 }}', block=Block(), role=None, task_include=None, variable_manager=None, loader=None)

    # second test
    include_role_1 = IncludeRole()
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-25 06:08:33.782736
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Setup fixture
    include_role_0 = IncludeRole()

    # Test method
    include_role_0.load("")



# Generated at 2022-06-25 06:09:05.133304
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play import Play

    play = Play()
    play.vars = {}
    play.vars['test_var'] = 'test_vars_set'

    include_role_0 = IncludeRole()
    play.vars['role_path'] = '../../../../../lib/ansible/modules/remote_management/dellemc/idrac'
    include_role_0._role_name = '../../../../../lib/ansible/modules/remote_management/dellemc/idrac'
    include_role_0.vars['test_var'] = 'test_var'
    include_role_0.vars['test_var2'] = 'test_var2'
    include_role_0.from_files['tasks'] = 'test_tasks'
    include_role

# Generated at 2022-06-25 06:09:10.901670
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    class MockIncludeRole_load:
        def __init__(self):
            self.args = {
                'apply': '{}',
                'name': 'ansible.posix'
            }
        def __init__(self):
            self.action = 'include_role'

    result = IncludeRole.load('include_role', MockIncludeRole_load())
    assert (isinstance(result, IncludeRole) == True)

# Generated at 2022-06-25 06:09:13.722877
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print("\nTESTING IncludeRole: get_name()")
    i = IncludeRole()
    print("TEST ENDED: IncludeRole: get_name()")



# Generated at 2022-06-25 06:09:21.715260
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    #Test function load with arguments 'data' and 'block' of type 'Block'
    data = {'name': 'apache'}
    block = Block()

    ir = IncludeRole.load(data, block=block)
    assert ir._parent_role is None
    assert ir._role_name == 'apache'
    assert ir._role_path is None
    assert ir._from_files == {}
    assert not ir._allow_duplicates
    assert not ir._public
    assert ir._rolespec_validate


# Generated at 2022-06-25 06:09:31.000408
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # init
    data = dict()
    data['action'] = 'include_role'
    data['name'] = 'test-name'
    data['apply'] = dict()
    data['allow_duplicates'] = 'a-dup'
    data['statically_loaded'] = 'a-static'
    data['shared_loader_obj'] = 'a-shared'
    data['args'] = dict()
    data['args']['test-a'] = 'test-a'
    data['args']['test-b'] = 'test-b'
    data['args']['test-c'] = 'test-c'
    data['when'] = dict()
    data['when']['test-d'] = 'test-d'
    data['when']['test-e'] = 'test-e'


# Generated at 2022-06-25 06:09:38.906114
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """Test load method"""

    block = Block()
    role = Role()
    task_include = TaskInclude()

    data = {
        u'allow_duplicates': False,
        u'apply': {},
        u'defaults_from': '../../defaults/main.yml',
        u'handlers_from': '../../handlers/main.yml',
        u'name': u'common',
        u'tasks_from': '../../tasks/main.yml',
        u'vars_from': '../../vars/main.yml'
    }

    loader = MockLoader()
    play = MockPlay()
    var_manager = MockVarManager()


# Generated at 2022-06-25 06:09:45.510907
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block0 = Block()
    role0 = Role()
    task_include0 = IncludeRole(role=role0, block=block0)
    data = {'name': 'test_name_0', 'role': 'test_role_0'}
    variable_manager0 = ''
    loader0 = ''
    include_role1 = IncludeRole.load(data, block=block0, role=role0, task_include=task_include0, variable_manager=variable_manager0, loader=loader0)
    assert include_role1._role_name == 'test_name_0'


# Generated at 2022-06-25 06:09:53.340600
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_load_0 = {'any_errors_fatal': False, 'ignore_errors': False, 'action': 'include_role', 'name': 'test_0'}
    include_role_load_1 = {'any_errors_fatal': False, 'ignore_errors': False, 'action': 'import_role', 'name': 'test_1'}
    include_role_load_2 = {'any_errors_fatal': False, 'ignore_errors': False, 'action': 'include_role', 'name': 'test_2', 'allow_duplicates': True}
    include_role_load_3 = {'any_errors_fatal': False, 'ignore_errors': False, 'action': 'include_role', 'name': 'test_3', 'public': True}
    include_role_load_

# Generated at 2022-06-25 06:10:01.146332
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    yaml_str = (
        '---\n'
        '-\n'
        '  action: include_role\n'
        '  name: Some_Role\n'
        '  public: yes\n'
        '  tasks_from: tasks.yml\n'
        '  vars_from: vars.yml\n'
        '  apply: { some_param: Some_Value }\n'
        '  allow_duplicates: False\n'
        '  rolespec_validate: False\n'
    )
    include_role = IncludeRole.load(data=yaml_str)
    assert isinstance(include_role, IncludeRole)
    assert include_role._public
    assert include_role.apply.get('some_param') == 'Some_Value'

# Generated at 2022-06-25 06:10:09.505610
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    assert include_role_0._parent_role is None
    assert include_role_0._from_files == {}
    assert include_role_0._role_name == None
    assert include_role_0._role_path == None

    # Single rolespec test
    include_role_1 = include_role_0.load(data = dict(role = 'test_role_0'), block = Block(), role = Role(), task_include = None)
    assert include_role_1._parent_role is None
    assert include_role_1._from_files == {}
    assert include_role_1._role_name == 'test_role_0'
    assert include_role_1._role_path == None

    # Multiple rolespec test

# Generated at 2022-06-25 06:11:13.875667
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # data is simply a string here to test the role
    data = ''
    # block is a dummy argument here
    block = Block()
    # role is a dummy argument here
    role = Role()
    # task_include is a dummy argument here
    task_include = ''
    # variable_manager is a dummy argument here
    variable_manager = ''
    # loader is a dummy argument here
    loader = ''
    try:
        include_role = IncludeRole.load(data, block, role, task_include,
                                        variable_manager, loader)
    except:
        include_role = ''

    assert include_role == ''


# Generated at 2022-06-25 06:11:22.922176
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    task_include_0 = IncludeRole()
    task_include_1 = task_include_0.load({'name': 'my_role', 'apply': {'a': 1, 'b': 2}})
    assert(task_include_1._role_name == 'my_role')
    assert(task_include_1._from_files == {})
    assert(task_include_1.apply == {'a': 1, 'b': 2})
    assert(task_include_1.allow_duplicates is True)
    assert(task_include_1.public is False)
    assert(task_include_1.rolespec_validate is True)

# Generated at 2022-06-25 06:11:31.453571
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Arrange
    display = Display()

    # setup mocks
    include_role = IncludeRole()
    include_role.args = {'name': 'testName'}
    include_role.action = 'testAction'
    include_role.allow_duplicates = True
    include_role.apply_vars = {}
    include_role.apply_var_files = ()
    include_role.become = None
    include_role.become_method = None
    include_role.become_user = None
    include_role.block = None
    include_role.collections = ()
    include_role.connection = None
    include_role.delegate_to = None
    include_role.delegate_facts = None
    include_role.environment = {}
    include_role.force_handlers = False

# Generated at 2022-06-25 06:11:35.742730
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role = IncludeRole()
    include_role.name = ''
    include_role._role_name = 'test_role_name'
    assert include_role.get_name() == 'include_role : test_role_name'

# Generated at 2022-06-25 06:11:38.644112
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: Get this working
    pass


# Generated at 2022-06-25 06:11:49.283676
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # data
    data = dict(
        _raw_params='test_role',
        args=dict(
            _raw_params='test_role',
            name='test_role',
        ),
        delegate_to=None,
        delegate_facts=False,
        action='include_role',
    )
    role_include_obj = IncludeRole.load(data)
    role_include_obj.block = Block.load(
        dict(
            name='test_block',
            parent=None,
            block = [],
            roles = [],
            handlers = {},
            vars = {},
            meta = {},
        )
    )

    # get_block_list method call
    (blocks, handlers) = role_include_obj.get_block_list()

    # test assertions

# Generated at 2022-06-25 06:11:54.362079
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: add mock loaders and variables
    # include_role = IncludeRole()
    # block = Block()
    # play = Play()
    # include_role.get_block_list(play, block)
    # FIXME: not implemented
    assert True



# Generated at 2022-06-25 06:12:00.522226
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    # assert include_role_0.get_name() == "%s : %s" % (include_role_0.action, include_role_0._role_name)
    assert include_role_0.get_name() == "%s : %s" % (include_role_0.action, "_role_name")


# Generated at 2022-06-25 06:12:11.771385
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play_context = PlayContext()
    play_context._set_loader(loader)

    # create three blocks
    tasks_0 = Block()
    tasks_1 = Block()
    tasks_2 = Block()

    play_context.vars = combine_vars(play_context.vars, {'a': 'A'})

# Generated at 2022-06-25 06:12:13.749884
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    include_role_0.load(data=dict(), block=Block(), role=Role(), task_include=TaskInclude(), variable_manager=None, loader=None)


# Generated at 2022-06-25 06:14:49.620958
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # tests for methods that are called directly from load
    from ansible.parsing.dataloader import DataLoader

    # this test data is from an actual task, but /dev/null is used as a stand-in instead of the actual file
    data = dict(
        name='test-role',
        role='/dev/null',
        tasks_from='tasks/main.yml',
        vars_from='defaults/main.yml',
        defaults_from=None,
        handlers_from='handlers/main.yml',
        tags=['create', 'convnet_image'],
        apply=dict(
            tags=['create', 'convnet_image'],
        ),
        allow_duplicates=True,
        public=False,
        validate=True,
    )

# Generated at 2022-06-25 06:14:56.408991
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    mydict = {
        "some": "dict",
        "some_other": "dict",
        "some_other_other": "dict",
        "some_other_other_other": "dict",
        }
    include_role_0.load(mydict)
    mydict['public'] = True
    include_role_0.load(mydict)
    mydict['public'] = False
    include_role_0.load(mydict)

# Generated at 2022-06-25 06:15:06.866628
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import json
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Get a dummy variable manager
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_available_variables({'a': 1, 'b': 2, 'c': 3})

    # Get a dummy loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Get a dummy block
    my_block = Block()

    # Get a dummy role
    from ansible.playbook.play import Play
    my_play = Play()
    my_play.name = 'Dummy Play'
    my_play.hosts = ['localhost']
    my_play.roles = []
    my_play.collections = []
   

# Generated at 2022-06-25 06:15:15.782376
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    module_args = dict(
        name='foo',
        tasks_from='./tasks/main.yml',
        vars_from='./vars/main.yml',
        defaults_from='./defaults/main.yml',
        handlers_from='./handlers/main.yml',
        apply={'tags': 'bar'},
        allow_duplicates=False,
        public=True,
        rolespec_validate=False,
    )
    include_role = IncludeRole()
    include_role.load(module_args)

# Generated at 2022-06-25 06:15:25.205466
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create a fixture of class IncludeRole
    include_role_fixture = IncludeRole()
    # Create a object of class Block
    block_fixture = Block()
    # Create a object of class Role
    role_fixture = Role()
    # Create a object of class TaskInclude
    task_include_fixture = TaskInclude()
    # Create a fixture of data
    data_fixture = {}
    # Create a object of class VariableManager
    variable_manager_fixture = VariableManager()
    # Create a object of class DataLoader
    loader_fixture = DataLoader()

    # Call method load of class IncludeRole by passing fixutres

# Generated at 2022-06-25 06:15:31.739491
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test_case_0
    import ansible.plugins.loader as loader_0
    import ansible.playbook.task as task_0
    import ansible.plugins.task as task_1
    data_0 = {}
    block_0 = Block()
    role_0 = Role()
    task_include_0 = task_1.TaskInclude()

    include_role_1 = include_role_0.load(data_0, block_0, role_0, task_include_0)

    assert include_role_1 is not None


# Generated at 2022-06-25 06:15:36.070913
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Unit test for method get_block_list of class IncludeRole
    '''
    include_role_get_block_list = IncludeRole()
    include_role_get_block_list.get_block_list()