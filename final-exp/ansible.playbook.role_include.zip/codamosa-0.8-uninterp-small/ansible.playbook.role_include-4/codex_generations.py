

# Generated at 2022-06-25 06:05:46.402071
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    float_0 = 255.48
    include_role_0 = IncludeRole(float_0)
    print(include_role_0.get_name())
    assert include_role_0.get_name() == ": "


# Generated at 2022-06-25 06:05:48.022397
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    float_0 = 2554.64
    include_role_0 = IncludeRole(float_0)
    # assertion not yet implemented


# Generated at 2022-06-25 06:05:50.994803
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict()
    block=object
    role=object
    task_include=object
    variable_manager=object
    loader=object

    ir=IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 06:05:55.332841
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    fields = {}
    args = {}
    include_role_0 = IncludeRole(fields, args)
    data = {}
    block = {}
    role = {}
    task_include = {}
    variable_manager = {}
    loader = {}
    include_role_0.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:05:56.975313
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    include_role_1 = IncludeRole(1)

    assert include_role_1 is not None


# Generated at 2022-06-25 06:06:07.334515
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(name="test.yml", tasks_from="../../main.yml")
    block = "Block"
    role = "Role"
    task_include = "TaskInclude"
    variable_manager = "VariableManager"
    loader = "Loader"
    include_role_2 = IncludeRole(block, role, task_include)
    try:
        include_role_2.load(data, block, role, task_include, variable_manager, loader)
    except AnsibleParserError:
        raise AssertionError()

    data = dict(name="test.yml")
    block = "Block"
    role = "Role"
    task_include = "TaskInclude"
    variable_manager = "VariableManager"
    loader = "Loader"

# Generated at 2022-06-25 06:06:11.218498
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    float_0 = 2554.64
    include_role_0 = I

# Generated at 2022-06-25 06:06:17.544038
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    float_1 = -6490.190
    role_0 = Role(Block(include_role_0, float_1), include_role_0, vars=dict())
    float_2 = 9.790
    loader_1 = DataLoader()
    variable_manager_1 = VariableManager()
    data_0 = None
    block_1 = Block(include_role_0, float_2)
    result = IncludeRole.load(data_0, block_1, role_0, loader_1, variable_manager_1)
    assert result is None


# Generated at 2022-06-25 06:06:26.801266
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # ensure AnsibleError is raised when role is not found
    include_role_0 = IncludeRole(None)
    include_role_0.get_block_list()

    # ensure AnsibleError is raised when a file is not found in the from data
    include_role_1 = IncludeRole(None)
    include_role_1.get_block_list()

    # ensure AnsibleError is raised when a file is not found in the from data
    include_role_2 = IncludeRole(None)
    include_role_2.get_block_list()

    # ensure AnsibleError is raised when a file is not found in the from data
    include_role_3 = IncludeRole(None)
    include_role_3.get_block_list()

    # ensure AnsibleError is raised when a file is not found in the from data
   

# Generated at 2022-06-25 06:06:30.998807
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    s = "{'name': 'role_name_0'}"
    r = IncludeRole.load(s)
    assert r._role_name == 'role_name_0'
    assert r.apply == None


# Generated at 2022-06-25 06:06:43.821030
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test with no-args
    try:
        assert IncludeRole.load() == None
    except TypeError as e :
        assert isinstance(e, TypeError)

    # Test with real-args
    try:
        assert IncludeRole.load(data=var_0) == None
    except TypeError as e :
        assert isinstance(e, TypeError)

    # Test with invalid keyword args
    try:
        assert IncludeRole.load(**var_0) == None
    except TypeError as e :
        assert isinstance(e, TypeError)



# Generated at 2022-06-25 06:06:46.170875
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # data = ""
    # block = ""
    # role = ""
    # task_include = ""
    # variable_manager = ""
    # loader = ""
    ir = IncludeRole
    ir.load()


# Generated at 2022-06-25 06:06:48.348422
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    var_0 = IncludeRole(block=None, role=None, task_include=None)
    # TODO: implement get_block_list test
    assert(var_0.get_block_list() == None)


# Generated at 2022-06-25 06:06:50.573606
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    var_0 = dict()


# Generated at 2022-06-25 06:06:52.986538
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Load example data from 'a_include_role.json'
    file_data = open('a_include_role.json', 'r').read()
    a_include_role = json.loads(file_data)

    test_case_0()


# Generated at 2022-06-25 06:07:03.085540
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:07:05.557566
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    var_0 = IncludeRole()
    var_1 = None
    var_2 = None
    var_3 = None
    obj = var_0.get_block_list(var_1, var_2, var_3)


# Generated at 2022-06-25 06:07:09.980747
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()


###############################################################################
# Main program
###############################################################################

if __name__ == '__main__':

    # import logging
    # logging.basicConfig(level=logging.DEBUG, format='(%(threadName)-9s) %(message)s', )

    unittest.main()

# Generated at 2022-06-25 06:07:13.213012
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    var_0 = IncludeRole()
    var_1 = dict()
    var_1 = {}
    var_2 = dict()
    var_2 = {}
    var_3 = dict()
    var_3 = {}
    var_0.get_block_list(play=var_1, variable_manager=var_2, loader=var_3)


# Generated at 2022-06-25 06:07:17.664575
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    print('Test for get_name of class IncludeRole')
    obj = IncludeRole(**var_0)
    assert obj.get_name() != None



# Generated at 2022-06-25 06:07:35.049425
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    var_1 = IncludeRole()
    var_1.action = 'foo'
    var_1._role_name = 'bar'
    var_1.get_name()



# Generated at 2022-06-25 06:07:36.923564
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    var_0 = dict()
    var_1 = IncludeRole(var_0,var_0,var_0).get_include_params()

# Generated at 2022-06-25 06:07:37.403833
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    var_0 = dict()



# Generated at 2022-06-25 06:07:39.139217
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    var_0 = dict()
    var_0 = dict()
    try:
        var_1 = IncludeRole()
        var_2 = var_1.get_name()
    except Exception as var_3:
        var_0 = var_3



# Generated at 2022-06-25 06:07:40.013173
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert True


# Generated at 2022-06-25 06:07:40.811034
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    var_1 = dict()
    var_2 = dict()


# Generated at 2022-06-25 06:07:41.991499
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-25 06:07:47.203526
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    block = dict()

    var_0 = IncludeRole()

    var_1 = play = dict()
    var_2 = variable_manager = dict()
    var_3 = loader = dict()

    var_0.get_block_list.assert_any_call(play=var_1, variable_manager=var_2, loader=var_3)


# Generated at 2022-06-25 06:07:58.492027
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    def test_IncludeRole_get_include_params_0():
        var_0 = dict()
        var_1 = IncludeRole(None, None, None)

        # Attempt to call a protected method
        # Raises: AttributeError: type object 'IncludeRole' has no attribute '_IncludeRole__get_include_params'
        # var_2 = var_1.IncludeRole._IncludeRole__get_include_params()
        var_2 = var_1.get_include_params()
        # print('var_2 = '+str(var_2))
        assert var_2 == var_0

    def test_IncludeRole_get_include_params_1():
        var_3 = dict()
        var_4 = IncludeRole(None, None, None)

        # call IncludeRole_get_include_

# Generated at 2022-06-25 06:08:00.197315
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Steps:
    # 1. Init an instance of IncludeRole
    # 2. Call method load

    test_0()


# Generated at 2022-06-25 06:08:20.879788
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # 1. Create a data structure to emulate a portion of an Ansible playbook
    data = {'ros_dependencies': ['rosserial', 'rosserial_arduino']}

    # 2. Create variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}

    # 3. Create loader
    loader = DataLoader()

    # 4. Create display
    display = Display()

    # 5. Create IncludeRole object to test
    include_role = IncludeRole()
    include_role.load(data, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 06:08:22.409570
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    assert isinstance(include_role_0.get_name(), basestring)

# Generated at 2022-06-25 06:08:32.503882
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_case = """
- include_role:
    name: apache
    tasks_from: tasks/main.yml
    apply:
        tags:
            - apache
- include_role:
    name: apache
    tasks_from: {{ main_yml }}
- include_role:
    name: apache
    tasks_from: {{ main_yml }}
    vars_from: vars/main.yml
- include_role:
    name: apache
    tasks_from: tasks/main.yml
    defaults_from: defaults/main.yml
    vars_from: vars/main.yml
    handlers_from: handlers/main.yml
"""

# Generated at 2022-06-25 06:08:40.734956
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole(block=None, role=None, task_include=None)
    #add role
    role = Role()
    role.name = 'role_name'
    role.play = None
    role._role_path = '/path/to/role'
    role._metadata = {'galaxy_info': {}}
    loader = None
    include_role_0._parent._play = None
    include_role_0._role_name = 'role_name'
    include_role_0._parent_role = role
    if include_role_0._role_name:
        include_role_0._role_path = '/path/to/role'
        if include_role_0._parent_role:
            include_role_0._parent_role._metadata.allow_duplicates = True

# Generated at 2022-06-25 06:08:45.445642
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test case 1
    include_role_1 = IncludeRole()
    results_1 = include_role_1.get_include_params()
    assert results_1 == {'role_names': [], 'role_paths': [], '_ansible_no_log': False}


# Generated at 2022-06-25 06:08:47.536559
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    print(include_role_0.get_block_list())



# Generated at 2022-06-25 06:08:50.725468
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0._role_name = "sample_role"
    assert include_role_0.get_name() == "include_role : sample_role"


# Generated at 2022-06-25 06:08:54.424069
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()

    play = Play()
    block = Block()
    variable_manager = VariableManager()
    loader = DataLoader()

    assert None == include_role.get_block_list(play, variable_manager, loader)

# Generated at 2022-06-25 06:09:03.411661
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Instantiate class IncludeRole.
    include_role_1 = IncludeRole()
    # Instantiate class FieldAttribute of attribute _allow_duplicates with value True and type bool
    field_attribute_1 = FieldAttribute(True, 'bool')
    # Assign FieldAttribute field_attribute_1 to attribute _allow_duplicates of class IncludeRole
    include_role_1._allow_duplicates = field_attribute_1
    # Instantiate class FieldAttribute of attribute _public with value False and type bool
    field_attribute_2 = FieldAttribute(False, 'bool')
    # Assign FieldAttribute field_attribute_2 to attribute _public of class IncludeRole
    include_role_1._public = field_attribute_2
    # Instantiate class FieldAttribute of attribute _rolespec_validate with value True and type bool
    field_attribute_3

# Generated at 2022-06-25 06:09:13.946726
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_obj = IncludeRole()
    # Test method load of class IncludeRole with valid data.
    include_role_obj.load({'name': 'role_name', 'tasks_from': 'tasks.yaml'})

    # Test method load of class IncludeRole with invalid data.
    # 'name' is a required field for include_role.
    with pytest.raises(AnsibleParserError) as exc:
        include_role_obj.load({'tasks_from': 'tasks.yaml'})
        assert 'name' in exc.exception
    # Invalid options for include_role: public.
    with pytest.raises(AnsibleParserError) as exc:
        include_role_obj.load({'name': 'role_name', 'public': True})

# Generated at 2022-06-25 06:09:49.754686
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: implement.
    return


# Generated at 2022-06-25 06:09:53.849623
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Tests with a specified _role_name
    test_case_0()


if __name__ == "__main__":
    test_IncludeRole_get_block_list()

# Generated at 2022-06-25 06:10:01.183269
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ansible = dict(
        variable_manager=None,
        loader=None,
        variable_manager=None,
    )

# Generated at 2022-06-25 06:10:06.206163
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    role_0 = Role()
    assert 'TASK: [debug msg="Loaded Tasks"]' in IncludeRole().get_block_list(role=role_0)[0][0].args['msg']
    assert 'TASK: [debug msg="Loaded Tasks"]' in IncludeRole().get_block_list(role=role_0)[0][0].args['msg']


# Generated at 2022-06-25 06:10:07.959267
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    print(include_role_0)
    # TODO: Add test cases


# Generated at 2022-06-25 06:10:13.214924
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir_0 = IncludeRole()
    assert ir_0.get_name() == 'include_role'
    ir_1 = IncludeRole()
    ir_1.name = "test-role"
    assert ir_1.get_name() == "test-role"


# Generated at 2022-06-25 06:10:16.145402
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0._role_name = "some_role"
    include_role_0.action = "include_role"
    assert include_role_0.get_name() == "include_role : some_role"


# Generated at 2022-06-25 06:10:20.322909
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = object
    loader = object
    data = object
    include_role = IncludeRole()
    result = include_role.load(data, block, role, task_include, variable_manager, loader)
    assert result == include_role


# Generated at 2022-06-25 06:10:23.579132
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create a include task
    include_role_1 = IncludeRole()
    result = include_role_1.get_block_list()
    assert result == ([], []), "Return unexpected value for feature get_block_list of class IncludeRole"

# Generated at 2022-06-25 06:10:32.123436
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:11:43.287367
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_Monkey = IncludeRole()
    test_Monkey.get_block_list()



# Generated at 2022-06-25 06:11:45.351521
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()  # noqa: F841



# Generated at 2022-06-25 06:11:51.733383
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Initialize the object
    include_role = IncludeRole.load(
                     data=dict(None, action='fake_action', args=dict(None, name='fake_name', role='fake_role')), 
                     block=None,
                     role=None,
                     task_include=None,
                     variable_manager=None,
                     loader=None)
    print (include_role)
    # TODO: Do we need to mock the play and other parameters being passed to the load function?


# Generated at 2022-06-25 06:11:52.426612
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-25 06:11:53.305375
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.vvv(test_case_0())

# Generated at 2022-06-25 06:12:03.880151
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # load_0
    include_role_obj_0 = IncludeRole()
    data_0 = {'name': 'Jasper', 'apply': {'gather_facts': True}, 'defaults_from': '../defaults/main.yml', 'role': '../roles/a', 'register': 'bar'}
    include_role_obj_0.load(data_0, loader=None, variable_manager=None)
    if not isinstance(include_role_obj_0, IncludeRole):
        raise AssertionError("Test for method 'load' of class IncludeRole failed. Expected class: 'IncludeRole', got: %s" % type(include_role_obj_0))

    # load_1
    include_role_obj_1 = IncludeRole()

# Generated at 2022-06-25 06:12:13.996117
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    role_1 = Role()
    block_2 = Block(parent=include_role_0)
    block_2.vars = dict()
    block_2.vars["var_3"] = False
    block_2.vars["var_4"] = True
    block_2.vars["var_5"] = False
    block_2.vars["var_6"] = "role_name_7"
    block_2.vars["var_8"] = True
    block_2.vars["var_9"] = False
    block_2.vars["var_10"] = True
    block_2.vars["var_11"] = "var_12"
    block_2.vars["var_13"] = False

# Generated at 2022-06-25 06:12:18.678181
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    assert (include_role_0.get_block_list() is [])


# Generated at 2022-06-25 06:12:25.355601
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == "include_role"

    include_role_1 = IncludeRole(name="Test")
    assert include_role_1.get_name() == "include_role: Test"

# Generated at 2022-06-25 06:12:33.858985
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Setup IncludeRole instance
    include_role = IncludeRole()
    print(include_role)

    # Initialize IncludeRole instance attributes

    print(include_role.statically_loaded)
    print(include_role._from_files)
    print(include_role._parent_role)
    print(include_role._role_name)
    print(include_role._role_path)

    include_role.statically_loaded = True
    include_role._from_files = {'defaults': 'defaults/main.yml'}
    include_role._parent_role = None
    include_role._role_name = 'a_role'
    include_role._role_path = ''

    # Execute IncludeRole.get_block_list(...)
    # TODO: add required arguments
    # TODO: add optional

# Generated at 2022-06-25 06:15:35.314507
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # test_case_0
    include_role_0 = IncludeRole()
    # test_case_0: expected value is "_IncludeRole(action=None, name=None, loop=None, loop_args=None, loop_with_items=None, loop_with_seq=None, when=None, failed_when=None, tags=[], skip_tags=[], always_run=False, run_once=False, delegate_to=None, delegate_facts=None, register=None, until=None, retries=None, delay=None, first_available_file=None, vars=[], role=None, src=None, environment={}, no_log=[], register_as=None, ignore_errors=False, rescue=[], always=[], changed_when=[], failed_when_result=False, check_mode=False, static_vars={},