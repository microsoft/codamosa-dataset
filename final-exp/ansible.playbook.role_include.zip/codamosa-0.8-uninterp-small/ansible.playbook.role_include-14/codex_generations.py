

# Generated at 2022-06-25 06:05:45.639756
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    input_data = {'name': 'test_role'}
    block = Block()
    include_role = IncludeRole.load(input_data, block, loader=None)
    assert include_role._role_name == 'test_role'
    assert include_role.name == 'test_role'


# Generated at 2022-06-25 06:05:55.070398
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    test_case_0_data = dict(
        name='test'
    )
    test_case_0_loader = DataLoader()
    test_case_0_play_context = PlayContext()
    test_case_0_variable_manager = VariableManager()
    test_case_0_templar = Templar(loader=test_case_0_loader, variables=dict(), shared_loader_obj=test_case_0_loader)

# Generated at 2022-06-25 06:06:04.656119
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    block_0 = Block()
    block_0._name = 'block'
    include_role_0 = IncludeRole(block_0)

    data_0 = dict(
        apply = dict(),
        rolespec_validate = True,
        role = 'modules/module_name',
        vars = dict(),
        name = 'module_name',
        allow_duplicates = True,
        public = False,
        when = None,
        block = block_0
    )

    # Validate parameters for the test case
    assert isinstance(data_0, dict)

    include_role_0 = IncludeRole.load(data_0, block_0)
    assert isinstance(include_role_0, IncludeRole)
    assert include_role_0.module_name == 'include_role'

# Generated at 2022-06-25 06:06:15.739390
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test to fail
    """
    include_role_0 = IncludeRole()

    import ansible.playbook.play
    play_0 = ansible.playbook.play.Play()
    import ansible.playbook.play_context
    play_context_0 = ansible.playbook.play_context.PlayContext()
    import ansible.vars.manager
    variable_manager_0 = ansible.vars.manager.VariableManager()
    import ansible.parsing.dataloader
    loader_0 = ansible.parsing.dataloader.DataLoader()

    try:
        blocks, handlers = include_role_0.get_block_list(play_0, variable_manager_0, loader_0)
    except Exception as e:
        assert type(e) == AnsibleParserError

# Generated at 2022-06-25 06:06:24.031215
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy

    pc = PlayContext()
    unsafeproxy = UnsafeProxy()

    # Example:
    # task_0 = IncludeRole()
    # blocks_0, handlers_0 = task_0.get_block_list(pc,unsafeproxy,unsafeproxy)

    # This test currently passes without error. It is currently not possible to
    # verify the returns values. However, the implementation was determined
    # by looking at the implementation of get_block_list.
    assert True

# Generated at 2022-06-25 06:06:26.213336
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # FIXME: Test needs implementation
    pass


# Generated at 2022-06-25 06:06:29.076827
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole(role="Test")
    ir.name = "test"
    name = ir.get_name()
    assert(name == "test : Test")

# Generated at 2022-06-25 06:06:32.087741
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block_list_0 = include_role_0.get_block_list()

# Generated at 2022-06-25 06:06:40.850348
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback.default import CallbackModule
    import ansible.constants as constants
    import os

    class TestIncludeRolePlaybookExecutor(PlaybookExecutor):

        def __init__(self, playbooks, inventory, variable_manager, loader,
                     options, passwords):
            self._playbooks = playbooks
            self._inventory = inventory
            self._variable_

# Generated at 2022-06-25 06:06:46.269930
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.mod_args import ModuleArgsParser

    loader = DictDataLoader({
        "tasks/main.yml": "---\n- name: test\n  include_role: name=test_role"
    })

    # Create mock objects
    play = mock.MagicMock()

    # Execute the method being tested
    include_role_instance = IncludeRole.load(data=dict(ModuleArgsParser.parsed('name=test_role')), play=play, loader=loader)

    assert include_role_instance._role_name == 'test_role'

# Generated at 2022-06-25 06:06:55.200968
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Run module
    test_case_0()

# Generated at 2022-06-25 06:06:58.856388
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    include_role = IncludeRole()
    result = include_role.get_name()
    assert ansible_role_0.name == ansible_role_0._role_name == result

# Generated at 2022-06-25 06:07:03.121701
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    result = include_role_0.get_name()
    assert result == 'include_role : '


# Generated at 2022-06-25 06:07:08.170908
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

if __name__ == "__main__":
    print(IncludeRole.load({'name': 'role_name'}))

# Generated at 2022-06-25 06:07:17.364989
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    include_role_1.name = 'test_name'
    include_role_1.args = {'apply': {}, 'name': 'test_name', 'allow_duplicates': False, 'public': True}
    myplay = ''
    variable_manager = ''
    loader = ''
    block_list, handler_list = include_role_1.get_block_list(myplay, variable_manager, loader)
    assert block_list == []
    assert handler_list == []


# Generated at 2022-06-25 06:07:22.271201
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0._role_name = "a_role"
    include_role_0.action = "include_role"
    include_role_0.name = ""
    assert include_role_0.get_name() == "include_role : a_role"
    include_role_0.name = "an_include_role"
    assert include_role_0.get_name() == "an_include_role"


# Generated at 2022-06-25 06:07:26.387127
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: add in cases required to assert correct behaviour
    assert True


# Generated at 2022-06-25 06:07:31.583930
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_instance_0 = IncludeRole()
    if True:  # just to make the IDE happy.
        # run the method.
        try:
            include_role_instance_0.get_block_list()
        except Exception:
            # maybe you're testing for an exception here?
            pass
    #include_role_instance_0.get_block_list()
    #assert False # add real tests here


# Generated at 2022-06-25 06:07:42.826284
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Load test data
    data = dict(
        _hosts='localhost',
        _raw_params='myrole',
        _role_name='myrole',
        action='include_role',
        args={},
        blocks=[],
        changed_when=None,
        failed_when=None,
        handlers=[],
        ignore_errors=False,
        loop=None,
        loop_args={},
        loop_with_items=None,
        meta={},
        name='myrole',
        notify=[],
        register=None,
        retries=0,
        role_name='myrole',
        when=None,
        loop_control=None,
    )
    my_obj = IncludeRole.load(data, role=Role())

    # Check for class

# Generated at 2022-06-25 06:07:45.219385
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    include_role_1 = include_role_0.load()
    assert include_role_1 is not None
    print(include_role_1)



# Generated at 2022-06-25 06:08:00.893487
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    # create mock object for the AnsibleRole class
    ansible_role_class = MockAnsibleRoleClass()
    include_role_1.load('test_include_role', block='test_block', role='test_role', task_include='test_task_include', variable_manager='test_variable_manager', loader=ansible_role_class)
    

# Generated at 2022-06-25 06:08:05.857284
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    class MyObject:
        def __init__(self, data):
            self.data = data
    my_object = MyObject(dict())
    include_role = IncludeRole()
    result = include_role.get_block_list(my_object)
    assert result == ([], [])


# Generated at 2022-06-25 06:08:06.685415
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:08:12.137500
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ansible = Ansible()
    ansible.plugins = Dict()
    ansible.plugins['action'] = Dict()
    ansible.plugins['action']['include_role'] = IncludeRoleModule()
    ansible._connection = Connection()
    ansible._shell = ShellModule()
    loader = Dict()
    loader._templates = Dict()
    loader._templates = 'templates'
    loader._basedir = os.getcwd()
    variable_manager = VariableManager()
    role = Role()
    role._role_path = 'test_role'
    block = Block()
    block.vars = {'name': 'test'}
    task_include = TaskInclude()
    task_include.args = {'name': 'test', 'public': True}

# Generated at 2022-06-25 06:08:20.606908
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:08:31.003531
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()

# Generated at 2022-06-25 06:08:32.847722
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert(include_role_0.get_name() == 'name: None')



# Generated at 2022-06-25 06:08:35.454122
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Set up object
    include_role_0 = IncludeRole()

    # Assert return value is not None
    assert include_role_0.load(block, role, task_include, variable_manager, loader) is not None

# Generated at 2022-06-25 06:08:37.697103
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole.load(
        dict(
             name='foo',
             bar='baz',
            )
        )
    assert include_role_1._role_name == 'foo'


# Generated at 2022-06-25 06:08:41.168956
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    data = {}
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    include_role.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:09:12.490939
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole.load(dict(
        name='foo',
        role='bar',
        apply='baz',
        public='foobaz',
        allow_duplicates=1,
        rolespec_validate='foobar',
        extra='foobarbaz'))
    assert include_role._parent_role is None
    assert include_role._role_name == 'foo'
    assert include_role._role_path is None
    assert include_role.allow_duplicates is True
    assert include_role.public is False
    assert include_role.rolespec_validate is True


# Generated at 2022-06-25 06:09:23.152189
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print("in test_get_block_list")
    dummy_block = Block()
    dummy_block.vars = {'test_var': 1}
    include_role = IncludeRole(block=dummy_block)
    include_role._parent = dummy_block
    include_role._role_name = "test_role"

    (blocks, handlers) = include_role.get_block_list()
    print("blocks: ", blocks, "handlers: ", handlers)
    dummy_block.block = blocks
    dummy_block.post_validate(dummy_block, dummy_block.block[0])
    print("after post_validate: ", dummy_block.block[0])

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:09:26.932652
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Testing get_include_params() method of IncludeRole class
    # Syntax : get_include_params(self)
    include_role_1 = IncludeRole()
    assert include_role_1.get_include_params() == {}


# Generated at 2022-06-25 06:09:32.914530
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: Write a unit test for method get_block_list of class IncludeRole
    # TODO: The test should verify that the method produces the correct result
    # TODO: The test should verify that the method produces a result consistent with the specification
    # TODO: The test should verify that the method produces a result consistent with the documentation
    # TODO: The test should verify that the method produces a result that agrees with the examples
    # TODO: The test should verify that the method produces a result that agrees with the tests
    assert False


# Generated at 2022-06-25 06:09:39.082132
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    '''
    Unit test for method get_name of class IncludeRole
    '''
    myinclude = IncludeRole.load(dict(action='include_role', name='myrole', tasks_from='main.yml'))
    assert myinclude._role_name == 'myrole'
    assert myinclude.get_name() == 'myrole : myrole'


# Generated at 2022-06-25 06:09:40.140393
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    assert False


# Generated at 2022-06-25 06:09:41.419862
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()
    ir.get_block_list()

# Generated at 2022-06-25 06:09:50.872415
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # pylint: disable=protected-access
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    data = {}

    include_role = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert include_role._parent is block
    assert include_role._role is role
    assert include_role._task_include is task_include
    assert include_role._role_name is None
    assert include_role._role_path is None
    assert include_role._parent_role is role
    assert include_role._from_files == {}
    assert include_role.allow_duplicates is True
    assert include_role.public is False
    assert include_role.rolespec_validate is True

# Generated at 2022-06-25 06:09:56.088896
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print('')
    display.display('TEST: test_IncludeRole_load()')

    try:
        include_role = IncludeRole(name='test_role')
        include_role_0 = include_role.load(data={'name':'test_role','apply':{}})
        assert include_role_0._role_name == 'test_role'
    except Exception as error:
        display.display('Caught error: ', error, traceback.format_exc())
        assert False


if __name__ == "__main__":
    # Test for class IncludeRole
    test_case_0()
    test_IncludeRole_load()
    pass

# Generated at 2022-06-25 06:10:01.768443
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'apply': {'serial': 1}}
    ir = IncludeRole.load(data)
    # test IncludeRole._apply_args
    assert ir._apply_args == {'serial': 1}
    # test IncludeRole._task_include.args
    assert ir._task_include.args == data
    # test IncludeRole.load_data
    assert ir.load_data(data) == ir


# Generated at 2022-06-25 06:11:02.354815
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    result = IncludeRole.load()


# Generated at 2022-06-25 06:11:08.207519
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Case 1 - without name
    ir_1 = IncludeRole()
    ir_1.role = 'Ansible.apache'
    ir_1.action = '- include_role'
    assert ir_1.get_name() == '- include_role : Ansible.apache'

    # Case 2 - with name
    ir_2 = IncludeRole()
    ir_2.name = 'test'
    ir_2.action = '- include_role'
    assert ir_2.get_name() == '- include_role : test'

# Generated at 2022-06-25 06:11:15.958856
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data = '[{"action": "include", "name": "test", "public": true, "collections": ["foobar"]}]'
    block = Block()
    block.role = Role()
    # TODO: Fix this
    #include_role_1 = IncludeRole.load(data, block=block)
    #assert include_role_1.action == 'include'
    #assert include_role_1.__class__.__name__ == 'IncludeRole'
    #assert include_role_1.args == {
    #    'name': 'test',
    #    'public': True,
    #    'collections': ["foobar"]
    #}
    #assert include_role_1.block == block
    #assert include_role_1.collections == ["foobar

# Generated at 2022-06-25 06:11:23.756182
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block = Block()
    role = Role()
    task_include = TaskInclude()

    # test case with all parameters
    # assert Raises(AnsibleParserError, include_role_0.get_block_list, play, variable_manager, loader)
    # TODO: Find method parameters and add to unit test

    # test case with none parameters
    # assert Raises(AnsibleParserError, include_role_0.get_block_list, None, None, None)  # TODO: Find method parameters and add to unit test

# Generated at 2022-06-25 06:11:32.421430
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import os
    import yaml

    # Create playbook, inventory and data loader
    loader = DataLoader()
    pwd = os.path.dirname(__file__)
    playbooks = ['/Users/julien/workspace/ansible-role-rabbitmq/tests/integration/targets/default/test.yml']
    my_playbooks = [os.path.basename(y) for y in playbooks]

# Generated at 2022-06-25 06:11:37.437060
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    values = [
        ('tasks/main.yml', '', {'tasks': 'tasks/main.yml'}),
        ('/var/tmp/tasks/main.yml', '', {'tasks': '/var/tmp/tasks/main.yml'}),
        ('/var/tmp/tasks/main.yml', '/etc/test/test.yml', {'tasks': '/var/tmp/tasks/main.yml', 'vars': '/etc/test/test.yml'}),
    ]

    for d in values:
        print('\n[+] d: %s' % str(d))
        # build data
        data = {}
        data['tasks'] = d[0]

# Generated at 2022-06-25 06:11:48.626981
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:11:57.445865
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name='some_role'
    )
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = ''
    loader = ''
    ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert ir is not None
    assert ir.name == 'some_role : some_role'
    assert ir.statically_loaded == 0
    assert ir._parent_role == role
    assert ir._role_name == 'some_role'
    assert ir._role_path is None


# Generated at 2022-06-25 06:12:00.328792
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    #Initialize the class IncludeRole
    include_role_1 = IncludeRole()
    #Test if the method get_name of class IncludeRole returns the expected value
    assert include_role_1.get_name() == None


# Generated at 2022-06-25 06:12:11.768176
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    include_role_1 = IncludeRole()
    include_role_1.role = "test_role"
    include_role_1.task_include = TaskInclude()
    include_role_1.task_include.static = True
    include_role_1.task_include._parent = Block()
    include_role_1.task_include._parent._play = Play()
    include_role_1.task_include._parent._play.roles = []
    include_role_1.task_include._parent._play._included_filenames = []
    include_role_1.task_include._role = Role()
    include_role_1.task_include._role._metadata = {}
    include_role_1.task_include._role._metadata['allow_duplicates'] = True

# Generated at 2022-06-25 06:14:45.339211
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Parameter initialization
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # IncludeRole construction
    include_role = IncludeRole(block, role, task_include)

    # Invoke method
    include_role.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:14:53.876811
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict()
    block = Block(parent_block=None)
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    """
    The following exception is raised:
    raise AnsibleParserError("'name' is a required field for include_role.", obj=data)
    assert False
    """


# Generated at 2022-06-25 06:14:57.957410
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    _myplay = None
    _variable_manager = None
    _loader = None
    include_role_get_block_list = IncludeRole(None,_myplay,_variable_manager,_loader)
    # include_role_get_block_list.get_block_list(_myplay,_variable_manager,_loader)


# Generated at 2022-06-25 06:15:07.148957
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    play_context = PlayContext()
    play = Play().load({ 'name': 'foo', 'hosts': 'all' }, variable_manager=VariableManager(), loader=DataLoader())
    task = Task()
    block = Block()

# Generated at 2022-06-25 06:15:11.350704
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block_0 = Block()
    role_0 = Role()

    result = include_role_0.get_block_list(block_0)
    assert len(result) == 2

# Generated at 2022-06-25 06:15:22.276247
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''Test IncludeRole.get_block_list'''
    # Test variables
    block_data = {'version': 1, 'name': 'VarsTest'}
    block = Block.load(block_data, DataLoader(), variable_manager=VariableManager())
    role = Role(name='MyRole', data=dict())
    role._role_path = '/home/vagrant/.ansible/collections/ansible_collections/nsrivastava/roles/MyRole'
    include_role = IncludeRole(block=block, role=role)
    include_role.vars = dict()
    myplay = Play().load(data=dict(), variable_manager=VariableManager(), loader=DataLoader())

    # Invoke method
    result = include_role.get_block_list(play=myplay)
    # Check result
   

# Generated at 2022-06-25 06:15:23.458822
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_case_0()
    assert IncludeRole.get_name()

# Generated at 2022-06-25 06:15:24.815074
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == "include_role : "

# Generated at 2022-06-25 06:15:30.916863
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # No exception expected because all parameters are valid
    display.verbosity = 3
    ir = IncludeRole()
    ir.load({'role': 'foobar', 'tasks_from': 'ok', 'vars_from': 'ok', 'defaults_from': 'ok', 'handlers_from': 'ok', 'apply': {'a':'b'}, 'public':True, 'allow_duplicates':True, 'meta': 'ok'}, block=Block())
    display.verbosity = 0
