

# Generated at 2022-06-25 06:05:54.460534
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data__0 = dict(test_0_test__0_test__0_test__0_test__0_test__0_test__0_test__0_test__0_test__0_test__0_test__0_test__0_test__0=dict(test__0='value', test__1='value', test__2='value', test__3='value', test__4='value', test__5='value', test__6='value', test__7='value', test__8='value', test__9='value'))
    block__0 = Block()
    role__0 = Role()
    task_include__0 = TaskInclude()
    variable_manager__0 = str()
    loader__0 = str()
    include_role__0 = IncludeRole()

# Generated at 2022-06-25 06:05:56.807601
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_include_params()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 06:05:59.356848
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_include_params()
    # test_case_0


# Generated at 2022-06-25 06:06:00.567008
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_case_0()


# Generated at 2022-06-25 06:06:04.005774
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    setattr(include_role_0, '_role_name', 'ntp')
    if include_role_0.get_name() != 'include_role : ntp':
        raise AssertionError


# Generated at 2022-06-25 06:06:11.662867
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # TaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # TODO
    #raise AnsibleParserError("'name' is a required field for %s." % self.action, obj=data)
    #raise AnsibleParserError('Invalid options for %s: %s' % (ir.action, ','.join(list(bad_opts))), obj=data)
    #raise AnsibleParserError('Invalid options for %s: apply' % ir.action, obj=data)
    #raise AnsibleParserError('Expected a dict for apply but got %s instead' % type(apply_attrs), obj=data)
    pass


# Generated at 2022-06-25 06:06:16.565114
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test the valid scenario, the ri must be an object of type RoleInclude
    try:
        r = IncludeRole.load(data={'name': "name"}, block={}, role={}, task_include={}, variable_manager={}, loader={})
    except Exception as err:
        assert False, "Unable to load instance of RoleInclude with valid parameters: " + str(err)
    else:
        assert True
    
    # Test the invalid scenario, the data must have a name, else it throws an AnsibleParserError
    try:
        r = IncludeRole.load(data={}, block={}, role={}, task_include={}, variable_manager={}, loader={})
    except Exception as err:
        assert isinstance(err, AnsibleParserError), "Exception thrown must be of type AnsibleParserError."
    else:
        assert False

# Generated at 2022-06-25 06:06:18.816520
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_obj = IncludeRole()
    result = include_role_obj.get_block_list()
    assert result is not None


# Generated at 2022-06-25 06:06:27.664449
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    data_0 = {'action': 'include_role',
              'args': {}}
    ir_0 = IncludeRole.load(data_0, block=block, role=role, task_include=task_include,
                            variable_manager=variable_manager, loader=loader)
    assert ir_0 is not None
    assert ir_0.action == 'include_role'
    assert ir_0.block == block
    assert ir_0.role == role
    assert ir_0.task_include == task_include
    assert ir_0.variable_manager == variable_manager
    assert ir_0.loader == loader
    assert ir_0.args == {}
    assert ir_0.allow_duplicates

# Generated at 2022-06-25 06:06:31.989689
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    blocks = includeRole_instance.get_block_list()
    assert type(blocks) == tuple

    assert len(blocks) == 2

    assert type(blocks[0]) == list

    assert type(blocks[1]) == list


# Generated at 2022-06-25 06:06:38.876297
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_case_0()

# Generated at 2022-06-25 06:06:46.290893
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Run the method load of class IncludeRole

    # Create a new object IncludeRole
    include_role_obj_0 = IncludeRole()

    # Define variable data
    data = None
    print('\n# Invoke method load of class IncludeRole with arguments: %s' % data)
    try:
        # Invoke the method load of class IncludeRole
        include_role_obj_0.load(data)
        print('\n# <Method \'load\' of class \'IncludeRole\' has been tested successfully at this time>\n')
    except Exception as e:
        print('\n# <Method \'load\' of class \'IncludeRole\' have been tested unsuccessfully at this time>\n')
        print('\n# Exception : %s' % e)
        return False

    # Define variable data

# Generated at 2022-06-25 06:06:48.078143
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_name()


# Generated at 2022-06-25 06:06:51.761951
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    result = include_role_0.get_name()
    assert result == 'include_role :'


# Generated at 2022-06-25 06:06:57.543601
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    include_role = IncludeRole()

# Generated at 2022-06-25 06:07:05.809952
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Setup
    my_dict = dict()
    my_dict['name'] = 'scenarios/query_values'
    my_dict['args'] = {'var_a': 'var_a', 'var_b': 'var_b'}
    block = Block()
    block.vars = {}
    obj = IncludeRole(block=block)
    obj.load(my_dict)
    # Execute
    res = obj.get_block_list()
    # Verify
    assert len(res) == 2


# Generated at 2022-06-25 06:07:07.785034
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    parent_role = Role()
    include_role = IncludeRole(block=block, role=parent_role)
    block_list_0 = include_role.get_block_list()
    assert block_list_0 is not None

# Generated at 2022-06-25 06:07:14.090041
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    IncludeRole_instance = IncludeRole()
    IncludeRole_instance.load(data={}, block={}, role={}, task_include={}, variable_manager={}, loader={})
    assert False


# Generated at 2022-06-25 06:07:18.876815
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
    Test if get_block_list works with good input
    """
    include_role_0 = IncludeRole()
    block_list_0 = include_role_0.get_block_list()


# Generated at 2022-06-25 06:07:21.282745
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Not implemented
    return 0

# Generated at 2022-06-25 06:07:28.377025
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass


# Generated at 2022-06-25 06:07:34.146453
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    args = {
        'include_role': {
            'name': 'Common',
            'vars': {
                'foo': 'bar'
            }
        }
    }
    inc_role = IncludeRole.load(
        args,
        block=Block.load(
            args,
            role=Role(),
            task_include=TaskInclude.load(args, role=Role())
        ),
        role=Role()
    )

    inc_role.get_block_list()

# Generated at 2022-06-25 06:07:42.046697
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test for case when vars is None
    import ansible.playbook.block
    include_role_0 = IncludeRole()
    block_0 = Block()
    var_0 = include_role_0.get_block_list(block=block_0)
    # Test for case when dep_chain is None
    include_role_1 = IncludeRole()
    block_1 = Block()
    var_1 = include_role_1.get_block_list(block=block_1)

# Generated at 2022-06-25 06:07:50.705339
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    inc_role = IncludeRole(block=Block(), role=Role())
    inc_role.action = 'include_role'
    inc_role.args = {'name': 'testinclude', 'tasks_from': '/some/fake/path', 'allow_duplicates': False}
    inc_role.statically_loaded = True
    inc_role.rolespec_validate = False
    other_inc_role = inc_role.load(inc_role)
    assert isinstance(other_inc_role, IncludeRole)
    assert other_inc_role._role_name == 'testinclude'
    assert other_inc_role._from_files == {'tasks': 'path'}
    assert other_inc_role.allow_duplicates == False
    assert other_inc_role.rolespec_validate == False

# Generated at 2022-06-25 06:08:01.060318
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # unit test of loading of include_role object from yaml data
    block1 = Block()

    # set up the parent block
    block1.vars = {'a': '1'}
    block1.tags = ['t1', 't2']

    # set up the include_role object
    include_role1 = IncludeRole(block=block1)
    include_role1.name = 'my_include_role'
    include_role1.action = 'include_role'
    include_role1.args = {'name': 'my_role'}
    include_role1.role = 'my_role'
    include_role1.statically_loaded = True
    include_role1.tags = ['t3', 't4']
    include_role1.block = block1

    # load the include_role object

# Generated at 2022-06-25 06:08:08.464501
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data_0 = {}
    block_0 = 'block_0'
    role_0 = 'role_0'
    task_include_0 = 'task_include_0'
    variable_manager_0 = 'variable_manager_0'
    loader_0 = 'loader_0'

    # Call method
    ir = IncludeRole.load(data=data_0, block=block_0, role=role_0, task_include=task_include_0, variable_manager=variable_manager_0, loader=loader_0)
    #assert ir._role_name == 'role_0'
    #assert ir.args == {}
    #assert ir.end_at == None
    #assert ir.env == {}
    #assert ir.tags == ['all']
    #assert ir.task_include == 'task_include_0'

# Generated at 2022-06-25 06:08:10.847006
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_include_params()
    assert var_0 is None

test_case_0()

# Generated at 2022-06-25 06:08:16.414353
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    print('test_IncludeRole_get_include_params')
#
# Testing if the IncludeRole exception is raised when expected
    try:
        test_case_0()
    except Exception as exception_instance:
        if isinstance(exception_instance, IncludeRole):
            print('Expected exception raised')
        else:
            print('Unexpected exception raised')
    else:
        print('Expected exception not raised')

test_IncludeRole_get_include_params()
print("AnsibleRole test completed")

# Generated at 2022-06-25 06:08:20.551326
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole()
    ir.load(data="", block=None, role=None, task_include=None, variable_manager=None, loader=None)



# Generated at 2022-06-25 06:08:26.945985
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    include_role_0 = IncludeRole()
    var_0 = IncludeRole()
    var_0.context = PlayContext(loader.load_from_file('../../test/units/mockdata/footer.yml'))
    include_role_0.name = 'test_include_role'
    include_role_0.args = {'test_string': 'test_value', 'test_int': 123, 'test_bool': False, 'test_dict': {'test_key': 'test_value'}, 'test_list': ['test_value']}
    var_1 = include_role_0.load(loader.load_from_file('../../test/units/mockdata/footer.yml'), block=var_0, loader=loader)


# Generated at 2022-06-25 06:08:42.089094
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    display.verbosity = 4
    options = basic.BASIC_BOOLEAN_OPTIONS + basic.BASIC_COMMUNICATION_OPTIONS
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.galaxy.role import RoleRequirement

    pbex = PlaybookExecutor(playbooks=None, inventory=None, variable_manager=None, loader=None, options=options, passwords=None)
    variable_manager = pbex._variable_

# Generated at 2022-06-25 06:08:50.103971
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    var_1 = dict(
        name="foo",
        tasks_from="main.yaml",
        vars_from="vars.yaml",
        handlers_from="handlers/main.yaml",
        defaults_from="defaults/main.yaml",
        allow_duplicates=False,
        public=False,
        apply=dict(foo=1, bar='bar'),
        tags=['foo', 'bar'],
        when=False,
    )
    obj_0 = IncludeRole.load(var_1)
    assert obj_0.get_block_list()


# Generated at 2022-06-25 06:08:54.698319
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_obj_0 = IncludeRole()
    myplay_0 = Block()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()

    include_role_obj_0.get_block_list(play=myplay_0, variable_manager=variable_manager_0, loader=loader_0)


# Generated at 2022-06-25 06:08:56.295787
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    var = include_role.load()

# Generated at 2022-06-25 06:09:01.027597
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
  play = Play()
  fake_block = Block()
  fake_variable_manager = VariableManager()
  fake_loader = DataLoader()
  fake_task_include = TaskInclude()
  fake_task_include.statically_loaded = True

  include_role = IncludeRole()

  blocks = include_role.get_block_list(play, fake_variable_manager, fake_loader)



# Generated at 2022-06-25 06:09:07.262864
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data_0 = '''name: example
  public: yes
  tasks_from: './example-tasks'
  vars_from: './example-vars'
  allow_duplicates: true
'''
    vars_0 = {
        'example': 'example'
    }
    include_role_1 = IncludeRole.load(data_0, variable_manager=vars_0)


# Generated at 2022-06-25 06:09:09.310820
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_block_list()


# Generated at 2022-06-25 06:09:12.610660
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    '''
    Unit test for method get_block_list of class IncludeRole
    '''
    include_role_0 = IncludeRole()
    include_role_0.get_block_list()


# Generated at 2022-06-25 06:09:23.429481
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # An exception should be thrown if invalid args are passed
    # Test with invalid args
    try:
        data = dict(action=C.ACTION_INCLUDE_ROLE)
        for k in ['role', 'name']:
            var = {}
            var[k] = 'include_role'
            data[k] = var[k]
            display.debug("data: %s" % data)
            IncludeRole.load(data)
    except:
        pass

    # Test with valid args
    data = dict(action=C.ACTION_INCLUDE_ROLE)
    for k in ['role', 'name']:
        var = {}
        var[k] = 'include_role'
        data[k] = var[k]
        display.debug("data: %s" % data)

# Generated at 2022-06-25 06:09:26.892493
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    role_0 = Role()
    task_include_0 = TaskInclude()
    include_role_0 = IncludeRole()
    var_0 = include_role_0.load()


# Generated at 2022-06-25 06:09:48.553864
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    data = dict()
    data['role'] = 'role_name'
    data['allow_duplicates'] = True
    data['apply'] = dict()
    data['public'] = False
    data['rolespec_validate'] = True
    tasks_from = "working/tasks.yml"
    vars_from = "working/vars.yml"
    defaults_from = "working/defaults.yml"
    handlers_from = "working/handlers.yml"
    data['tasks_from'] = tasks_from
    data['vars_from'] = vars_from
    data['defaults_from'] = defaults_from
    data['handlers_from'] = handlers_from
    include_role_0 = IncludeRole.load(data)
    block_list_0 = include_role

# Generated at 2022-06-25 06:09:52.476412
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    args = dict(
        name='foobar'
    )
    include_role_0 = IncludeRole()
    include_role_0.load_data(args, variable_manager=None, loader=None)
    play = None
    variable_manager = None
    loader = None
    include_role_0.get_block_list(play, variable_manager, loader)


# Generated at 2022-06-25 06:10:00.756244
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'name': 'my_role'}
    ri = IncludeRole(block=None, role=None, task_include=None)
    r = ri.load(data)

    assert r is not None
    assert r._role_name == 'my_role'

    bad_data = {'name': 123}
    try:
        r = ri.load(bad_data)
        assert False
    except AnsibleParserError as e:
        pass
    bad_data = {'name': 'my_role', 'public': 123}
    try:
        r = ri.load(bad_data)
        assert False
    except AnsibleParserError as e:
        pass
    bad_data = {'name': 'my_role', 'apply': 'bad'}

# Generated at 2022-06-25 06:10:02.392707
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir_0 = IncludeRole()

    assert ir_0.get_block_list() == ([], [])


# Generated at 2022-06-25 06:10:09.078347
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:10:13.059320
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Arranging
    include_role_0 = IncludeRole()

    # Act
    var_0 = include_role_0.get_name()

    # Assert
    assert var_0 is None


# Generated at 2022-06-25 06:10:22.403827
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    p_block = Block()
    p_block._parent = None
    p_play = Play()
    p_play._included_file = 'test_playbook.yml'
    p_play._dependent_path = 'dep_path.yml'
    p_play.hosts = ['host1']
    p_play.hosts = ['host2']
    p_play.hosts = ['host3']
    p_play.role_names = ['role1', 'role2', 'role3']
    p_task = Task()
    p_task._parent = p_block
    p_task.action = 'ok'
    p_task.args = {'no_log': True, 'no_print': False}
    p_task.delegate_to = 'localhost'
    p_task.delegate_

# Generated at 2022-06-25 06:10:24.465800
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    # This method is not implemented, and no tests were found for it.
    assert(False)



# Generated at 2022-06-25 06:10:28.245123
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {}
    block = {}
    variable_manager = {}
    loader = {}
    role = {}
    task_include = {}
    include_role_0 = IncludeRole()
    var_0 = include_role_0.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:10:36.444440
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    play = Play()
    play.name = "Ansible Play"
    play.hosts = "localhost"
    block = Block()
    block.name = "Ansible Block"
    block.parent = play
    block.task_includes = []
    block.vars = {}
    block.role = None
    block.block = None
    role = Role()
    role.name = "Ansible Role"
    role = role
    include_role = IncludeRole()
    include_role.block = block
   #include_role.role = role
    blocks = []
    handlers = []
#    loader = ?????
#    variable_manager = ?????
#    include_role.get_block_list(play, variable_manager, loader)
    print("Ansible Play included", blocks, "tasks.")
   

# Generated at 2022-06-25 06:11:10.244454
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_1 = IncludeRole()
    var_1 = include_role_1.get_name()


# Generated at 2022-06-25 06:11:16.011096
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    include_role_1 = IncludeRole()
    block_0 = Block(parent=[include_role_1])
    role_include_0 = RoleInclude(block=block_0)
    role_0 = Role()
    role_0._role_path = 'gQS9'
    data_0 = {}
    variable_manager_0 = None
    loader_0 = None
    result = IncludeRole.load(data_0, block_0, role_0, role_include_0, variable_manager_0, loader_0)
    assert isinstance(result, IncludeRole)



# Generated at 2022-06-25 06:11:25.151249
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole.load(data={'name': 'role1'})
    assert include_role_1.action == 'include_role'
    assert include_role_1._role_name == 'role1'
    assert include_role_1.get_name() == 'include_role : role1'
    assert include_role_1.get_block_list() == ([], [])
    assert include_role_1.copy() == include_role_1
    assert include_role_1.get_name() == 'include_role : role1'
    assert include_role_1.get_block_list() == ([], [])
    assert include_role_1.copy() == include_role_1

# Generated at 2022-06-25 06:11:27.814021
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    include_role.get_block_list()


# Generated at 2022-06-25 06:11:30.940204
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name = 'foobar',
        tasks = [dict(action=dict(module='shell', args='id'))]
    )

    var0 = IncludeRole.load(data)
    var1 = getattr(var0, '_role_name')
    assert var1 == 'foobar'

# Generated at 2022-06-25 06:11:34.248792
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # FIXME: https://github.com/ansible/ansible/issues/82012
    pass


# Generated at 2022-06-25 06:11:41.473606
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    myplay = Play()
    myplay.load(dict(
        name = "foo",
        hosts = "all",
        gather_facts = "no",
        roles = ["webserver"]
    ))
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())
    loader = DataLoader()

    # define variable_manager and loader
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())
    loader = DataLoader()

    # create IncludeRole
    include_role = IncludeRole()

# Generated at 2022-06-25 06:11:51.988007
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test for single values for each parameter
    include_role_1 = IncludeRole()
    var_1 = include_role_1.load(data = {'name': 'role_name', 'apply': {}})
    assert var_1._role_name == 'role_name'
    assert var_1.statically_loaded == False
    assert var_1._apply == {}
    # Test for multiple values for each parameter
    include_role_2 = IncludeRole()
    var_2 = include_role_2.load(data = {'name': 'role_name', 'apply': {'tags': ['tag_1', 'tag_2'], 'when': ['when_1', 'when_2']}})
    assert var_2._role_name == 'role_name'
    assert var_2.statically_loaded == False


# Generated at 2022-06-25 06:11:59.611790
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = None
    task_include = None
    data = {}
    variable_manager = None
    loader = None

    # Test if load correctly raises
    with pytest.raises(AnsibleParserError) as excinfo:
        include_role = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
        assert str(excinfo.value) == "'name' is a required field for include_role."

    # Test if load correctly returns an IncludeRole object
    data['name'] = "test"
    include_role = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 06:12:03.505084
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == "TASK"


# Generated at 2022-06-25 06:13:16.589757
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_include_params()
    templar_0 = Templar(loader=None, variables=None)
    var_0 = templar_0.template(var_0, fail_on_undefined=True, convert_bare=True)
    var_1 = VariableManager()
    var_1.set_nonpersistent_facts(var_0)
    # var_1.set_inventory(var_2)
    # var_1.set_variable("hostvars", var_3)

# Generated at 2022-06-25 06:13:21.432216
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    arg_dict = dict()
    arg_dict['block'] = Block()
    arg_dict['role'] = None
    arg_dict['task_include'] = None
    test_obj = IncludeRole.load(arg_dict)
    assert test_obj.get_block_list() == (
        [], [])

# Generated at 2022-06-25 06:13:24.461462
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print('BEGIN unit test for method get_block_list of class IncludeRole')
    include_role_0 = IncludeRole()
    var_0 = include_role_0.get_block_list()
    print(var_0)
    print('END unit test for method get_block_list of class IncludeRole')


# Generated at 2022-06-25 06:13:32.732845
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import mock

    # the module under test
    from ansible.playbook.role.include import IncludeRole

    # a mock of the class under test
    mock_include_role_obj = mock.Mock(spec=IncludeRole)

    # mock of arguments
    mock_play_arg = 'mock_play'
    mock_variable_manager_arg = 'mock_variable_manager'
    mock_loader_arg = 'mock_loader'

    # invocation of the method under test
    result = IncludeRole.get_block_list(mock_include_role_obj, mock_play_arg,
                                        mock_variable_manager_arg, mock_loader_arg)

    # assertions
    assert result is None



# Generated at 2022-06-25 06:13:33.903285
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    obj = IncludeRole()
    var = obj.get_block_list()
    print(var)


# Generated at 2022-06-25 06:13:42.084268
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data=dict()
    data["block"] = None
    data['action'] = 'include_role'
    data["ignore_errors"] = True
    data["always_run"] = False
    data["register"] = None
    data["delegate_to"] = None
    data["delegate_facts"] = False
    data["deprecated"] = None
    data["environment"] = None
    data["no_log"] = False
    data["notify"] = []
    data["poll"] = 0
    data["retries"] = 0
    data["until"] = None
    data["when"] = None
    data["args"] = dict()
    data["args"]['name'] = 'name'
    data["args"]['role'] = 'role'

# Generated at 2022-06-25 06:13:49.594283
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    var_0 = dict()
    var_0['action'] = 'include_role'
    var_0['allow_duplicates'] = True
    var_0['args'] = dict()
    var_0['args']['name'] = 'test'
    var_0['block'] = Block()
    var_0['block']._attributes = dict()
    var_0['block']._attributes['action'] = 'include_role'
    var_0['block']._attributes['allow_duplicates'] = True
    var_0['block']._attributes['args'] = dict()

# Generated at 2022-06-25 06:13:56.464699
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_IncludeRole_load_arg_names = set()
    test_IncludeRole_load_instance = IncludeRole()
    test_IncludeRole_load_arg_names.add('data')
    test_IncludeRole_load_arg_names.add('block')
    test_IncludeRole_load_arg_names.add('role')
    test_IncludeRole_load_arg_names.add('task_include')
    test_IncludeRole_load_arg_names.add('variable_manager')
    test_IncludeRole_load_arg_names.add('loader')
    def test_IncludeRole_load_mock(**kwargs):
        pass
    test_IncludeRole_load_instance.load = test_IncludeRole_load_mock

# Generated at 2022-06-25 06:13:58.423617
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    return_value = IncludeRole.get_block_list()
    assert return_value == (Block(), Block())


# Generated at 2022-06-25 06:14:03.235712
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {}
    block = {}
    role = {}
    task_include = {}
    variable_manager = {}
    loader = {}
    include_role = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    # Problem arises when 'task_include' is None or empty
    if task_include is None or task_include == {}:
        # Assigning a value to 'role' is correct
        print("Assigning a value to 'role' is correct")
    else:
        # Assigning a value to 'role' is incorrect
        print("Assigning a value to 'role' is incorrect")