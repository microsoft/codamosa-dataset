

# Generated at 2022-06-25 06:05:48.964745
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = """
include_role:
  name: Configure Cluster
"""
    include_role = IncludeRole.load(data)
    assert isinstance(include_role, IncludeRole)
    assert include_role._role_name == 'Configure Cluster'


# Generated at 2022-06-25 06:05:57.890747
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # import some sample data
    data = {
        'name': 'test',
        'tasks': 'main.yml',
        'handlers': 'handlers.yml',
        'defaults': 'defaults.yml',
        'vars': 'vars.yml',
        'meta': 'meta.yml',
        'files': 'files',
        'templates': 'templates',
        'vars_files': ['file1.yml', 'file2.yml'],
        'allow_duplicates': True
    }

    role_obj = IncludeRole.load(data)
    assert role_obj._role_name == 'test'

# Generated at 2022-06-25 06:06:01.875548
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # create an instance
    include_role = IncludeRole()

    # call method
    ansible_module_args = {
        "name": 'some_role',
    }

    include_role.load(ansible_module_args, task_include=True)



# Generated at 2022-06-25 06:06:10.717878
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test: load with valid action and with valid options
    data = dict(action='include_role', name='my_role', public=True)
    include_role_0 = IncludeRole.load(data)
    assert include_role_0.action == 'include_role'
    assert include_role_0.name == 'my_role'
    assert include_role_0.public == True

    # Test: load with invalid action and with valid options
    data = dict(action='template', name='my_role', public=True)
    try:
        include_role_1 = IncludeRole.load(data)
    except AnsibleParserError as exception:
        assert exception.message == "'public' is not a valid attribute for 'template' in include_role"

# Generated at 2022-06-25 06:06:12.848856
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == "include_role : None"


# Generated at 2022-06-25 06:06:15.186733
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # Test with no roles
    include_role_0 = IncludeRole()
    assert(include_role_0.get_include_params() == {})


# Generated at 2022-06-25 06:06:18.768235
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Arrange
    try:
        include_role = IncludeRole()

    except NameError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-25 06:06:27.640028
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    include_role_0.role = None
    include_role_0.vars = {'tag_Name': 'web',
                           'tag_Service': 'webserver',
                           'tag_Environment': 'test'}

    include_role_0._parent = None
    include_role_0._parent_role = None

    include_params = include_role_0.get_include_params()
    assert include_params == {'role_name': None,
                              'task_include_role': None,
                              'task_name': None,
                              'task_path': None,
                              'tag_Name': 'web',
                              'tag_Service': 'webserver',
                              'tag_Environment': 'test'}

# Generated at 2022-06-25 06:06:35.474754
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    assert IncludeRole.VALID_ARGS == ('name', 'role', 'tasks_from', 'vars_from', 'defaults_from', 'handlers_from', 'apply', 'public', 'allow_duplicates', 'rolespec_validate')
    include_role_1 = IncludeRole.load({'name': 'name_value', 'role': 'role_value', 'foo': 'foo_value'})
    assert include_role_1.args == {'name': 'name_value', 'role': 'role_value', 'foo': 'foo_value'}


# Generated at 2022-06-25 06:06:40.940035
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Set up the loader and inventory
    loader = DataLoader()
    host_list = [
        'localhost',
    ]
    inventory = InventoryManager(loader=loader, sources=host_list)

    # Set up the variable manager and play
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-25 06:06:51.404659
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    display.display(include_role_0.get_block_list())


# Generated at 2022-06-25 06:06:55.020941
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    b=Block(parent=None)
    ir=IncludeRole(block=b, role=None, task_include=None)
    ir._role_name="/home/vagrant"
    assert ir._role_path is None
    ir._from_files = {'tasks':'tasks/main.yml'}
    assert ir._parent_role is None
    play = MockPlay()
    vm = MockVariableManager()
    loader = MockLoader()
    ir.get_block_list(play=play, variable_manager=vm, loader=loader)
    assert ir._role_path == "/home/vagrant"

# Generated at 2022-06-25 06:07:03.392258
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook import Playbook
    from ansible.playbook.task.include_tasks import IncludeTask
    from ansible.playbook.task import Task
    import ansible.constants as C
    include_role_0 = IncludeRole()
    # Set up block
    block_0 = Block()
    # Set up role
    role_0 = Role()
    # Set up play
    play_0 = Playbook()
    include_role_0._parent = block_0
    include_role_0._parent_role = role_0
    include_role_0.action = 'include_role'
    # Set up variable_manager
    variable_

# Generated at 2022-06-25 06:07:09.641936
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    block_list_0 = include_role_0.get_block_list()

    assert type(block_list_0) == tuple, "Expected: <type 'tuple'>, Actual: %s" % type(block_list_0)
    block = Block()
    assert block_list_0[0][0].__class__ == block.__class__, "Expected: %s, Actual: %s" % (block_list_0[0][0].__class__, block.__class__)
    assert block_list_0[1][0].__class__ == block.__class__, "Expected: %s, Actual: %s" % (block_list_0[1][0].__class__, block.__class__)


# Generated at 2022-06-25 06:07:14.461874
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'role': '../test_role'}
    include_role_1 = IncludeRole()
    #Checking if the load method returns an IncludeRole object
    assert type(include_role_1.load(data,None,None)) == IncludeRole

# Generated at 2022-06-25 06:07:15.985016
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    pass



# Generated at 2022-06-25 06:07:16.620029
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()

# Generated at 2022-06-25 06:07:18.153397
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_case_get_block_list_0()


# Generated at 2022-06-25 06:07:22.833016
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    assert include_role_1.get_block_list() == ([], [])


# Generated at 2022-06-25 06:07:34.185584
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    '''
    TestCase:
    Get the parameters as a dict of key-value pairs for the include
    '''
    include_role_0 = IncludeRole()
    ansible_vars = {
        'role_name': 'my_role',
        'role_path': '/path/to/my_role',
        'tasks_from':'main.yml',
        'task_path':'/path/to/my_role/tasks/main.yml',
        'apply': {'tags':'tag1'},
        'allow_duplicates':True,
        'public':True,
        'rolespec_validate':True
        }
    ansible_parent_role_names = ['my_parent_role_name']

# Generated at 2022-06-25 06:07:49.168090
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    parent_role = Role.load('dummy_parent_role')
    parent_role.get_vars().update({'parent_role_var' : 'parent_role_value'})
    include_role = IncludeRole()
    include_role._parent_role = parent_role
    include_role.vars.update({'include_role_var' : 'include_role_value'})
    params = include_role.get_include_params()
    assert params['parent_role_var'] == 'parent_role_value'
    assert params['include_role_var'] == 'include_role_value'

# Generated at 2022-06-25 06:07:53.920474
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    display.display("test_IncludeRole_get_name")
    id_ = IncludeRole()
    assert isinstance(id_.get_name(), str)


# Generated at 2022-06-25 06:07:59.739091
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ansible_manager_0 = ansible_manager
    include_role_0 = IncludeRole()
    display.display(u'Unit test for method get_block_list of class IncludeRole')
    try:
        include_role_0.get_block_list()
    except Exception as exception:
        display.display(u'Exception caught: ' + str(exception), color=u'red')
        raise
    display.display(u'Unit test for method get_block_list of class IncludeRole: Success')


# Generated at 2022-06-25 06:08:02.621319
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()

    assert include_role_0.get_name() == "%s : %s" % (include_role_0.action, include_role_0._role_name)


# Generated at 2022-06-25 06:08:07.649157
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role = IncludeRole()
    assert include_role.get_include_params() == {
        'ansible_run_tags': [],
        'ansible_tags': [],
        'ansible_skip_tags': [],
        'role_names': None,
        'task_names': None,
    }

# Generated at 2022-06-25 06:08:10.639016
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    play = None
    variable_manager = None
    loader = None

    assert include_role_0.get_block_list(play, variable_manager, loader)


# Generated at 2022-06-25 06:08:18.074936
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
 
    display.display("TESTING load()")
    args = {'name': 'role_name'}
    role = Role()
    role.name = 'role_name'
    role.tasks = [Block()]
    include_role = IncludeRole(role=role)
    result = include_role.load(args)
    assert result == include_role, 'IncludeRole.load() result is not what it is expected'
    assert result._role_name == 'role_name', 'IncludeRole.load() result._role_name is not what it is expected'
    assert result.vars == include_role.vars, 'IncludeRole.load() result.vars is not what it is expected'

# Generated at 2022-06-25 06:08:21.757847
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role.get_block_list()

# Generated at 2022-06-25 06:08:24.537563
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_2 = IncludeRole()
    answer = None
    assert include_role_2.get_block_list() == answer


# Generated at 2022-06-25 06:08:26.206632
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    testcase = IncludeRole()
    testcase.__init__()
    testcase.get_block_list()

# Generated at 2022-06-25 06:08:46.634444
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible.playbook.play_context
    import ansible.utils.collection_loader
    import tempfile
    import os
    import shutil
    import sys
    import subprocess
    import shlex
    import tempfile

    (fd, tmp_path) = tempfile.mkstemp()
    with open(tmp_path, 'w') as tmp_file:
      tmp_file.write('#!/bin/sh\n')
      tmp_file.write('echo "hello world"\n')
    os.close(fd)
    os.chmod(tmp_path, 0o755)
    ansible_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    roles_path = '%s/tests/unit/test_data/test_roles'

# Generated at 2022-06-25 06:08:52.284480
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0._role_name = 'foo'
    include_role_0.action = 'my_action'
    assert include_role_0.get_name() == "my_action : foo"
    include_role_1 = IncludeRole()
    include_role_1.name = 'bar'
    include_role_1.action = 'my_action'
    assert include_role_1.get_name() == "bar"


# Generated at 2022-06-25 06:08:59.474530
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    my_arg_names = frozenset(include_role_0.args.keys())
    # validate bad args, otherwise we silently ignore
    bad_opts = my_arg_names.difference(IncludeRole.VALID_ARGS)
    if bad_opts:
        raise AnsibleParserError('Invalid options for %s: %s' % (include_role_0.action, ','.join(list(bad_opts))))

# Generated at 2022-06-25 06:09:01.372334
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == "include_role : None"


# Generated at 2022-06-25 06:09:05.754512
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    include_role_TaskInclude = IncludeRole(block=Block())
    return_value = include_role_TaskInclude.get_block_list(play=Block(), variable_manager=VariableManager(), loader=DictDataLoader())

    assert return_value[0] is None
    assert return_value[1] is None




# Generated at 2022-06-25 06:09:15.383027
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # initialize
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    include_role = IncludeRole(block=block, role=role, task_include=task_include)


    # setup arg data
    data = {'name':'username', 'role':'myrole', 'tasks_from':'username', 'vars_from':'username', 'defaults_from':'username', 'handlers_from':'username', 'apply':{}, 'public':True, 'allow_duplicates':True, 'rolespec_validate':True}


    # invoke method

# Generated at 2022-06-25 06:09:21.253727
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    # case 1
    # the name is empty string, it will return "include_role :"
    assert include_role_0.get_name() == "include_role :"
    # case 2
    # the name is not empty string, it will return "include_role :"
    include_role_0.name = "include_role"
    assert include_role_0.get_name() == "include_role"


# Generated at 2022-06-25 06:09:22.759155
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create an object of class IncludeRole
    include_role = IncludeRole()

    include_role.load()

# Generated at 2022-06-25 06:09:25.372145
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print("Testing load for IncludeRole")

    # result = IncludeRole.load()
    # assert result['rc'] == 0


# Generated at 2022-06-25 06:09:32.106272
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()

    print('ANSIBLE_LIBRARY: {}'.format(C.ANSIBLE_LIBRARY))
    print('ANSIBLE_MODULE_UTILS: {}'.format(C.ANSIBLE_MODULE_UTILS))
    print('DEFAULT_MODULE_UTILS_PATH: {}'.format(C.DEFAULT_MODULE_UTILS_PATH))

    try:
        blocks, handlers = include_role_0.get_block_list()
    except Exception as e:
        print('Exception occurred: {}'.format(e))
        pass



# Generated at 2022-06-25 06:10:01.600893
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # True if load returns a Block object
    block = Block()
    assert isinstance(IncludeRole.load({}, block), Block)


# Generated at 2022-06-25 06:10:09.796911
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print("Unit test for method load of class IncludeRole")
    b = Block()
    role = Role()
    task_include = TaskInclude()

    # case 0: The IncludeRole should be initialized with a Block, a Role and a TaskInclude
    try:
        include_role_0 = IncludeRole.load({'include_role': {'name': 'test.include'}}, block=b, role=role, task_include=task_include)
        assert True
    except Exception as e:
        print(e)
        assert False

    # case 1: The IncludeRole should be initialized with a dictionary of include_role

# Generated at 2022-06-25 06:10:16.969764
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Make a test instance and initialize variables
    include_role_obj = IncludeRole()
    arg_role_name = "DUMMY_VARIABLE"
    arg_play = "DUMMY_VARIABLE"
    arg_variable_manager = "DUMMY_VARIABLE"
    arg_loader = "DUMMY_VARIABLE"
    # Invoke method
    result = include_role_obj.get_block_list(arg_role_name, arg_play, arg_variable_manager, arg_loader)
    # Check result; not implemented
    assert True



# Generated at 2022-06-25 06:10:26.012036
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    assert include_role_0.get_include_params() == {'ansible_role_name': None, 'ansible_role_path': None, 'ansible_parent_role_names': [], 'ansible_parent_role_paths': []}

    include_role_1 = IncludeRole(
        block=Block(),
        role=Role(name='role_name_1', metadata={'collections': []}, path='/path/to/role')
    )

# Generated at 2022-06-25 06:10:33.937868
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # verify that login with 2 arguments fails
    try:
        IncludeRole.load(2)
    except Exception as e:
        print("test_IncludeRole_load: test_case 0: %s" % e)
        return

    # verify that login with 2 arguments fails
    try:
        IncludeRole.load("2")
    except Exception as e:
        print("test_IncludeRole_load: test_case 1: %s" % e)
        return

    # verify that login with 2 arguments fails
    try:
        IncludeRole.load("2")
    except Exception as e:
        print("test_IncludeRole_load: test_case 2: %s" % e)
        return

    raise Exception("test_IncludeRole_load: test case failed")


# Generated at 2022-06-25 06:10:36.667336
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    task = {'args': {'test1': 'testval1', 'test2': 'testval2'}}
    include_role = IncludeRole.load(data = task, block = None, role = None, task_include = None, variable_manager = None, loader = None)
    assert include_role.args == task['args']
    assert include_role.validate() == True


# Generated at 2022-06-25 06:10:37.779127
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_case_0()

# Generated at 2022-06-25 06:10:47.649452
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        tasks='test.yml',
        role='test_role',
        tasks_from='tasks_from.yml',
        vars_from='vars_from.yml',
        handlers_from='handlers_from.yml',
        apply=dict(
            ignore_unreachable=True,
            become=True,
            become_user='root',
            become_method='sudo',
            args='-lrb --debug',
            check='check'
        ),
        public=True,
        allow_duplicates=True,
        rolespec_validate=True
    )
    include_role_0 = IncludeRole()
    role = include_role_0.load(data)

# Generated at 2022-06-25 06:10:48.933589
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    actual = include_role.get_block_list()
    expected = ({}, [])
    assert actual == expected


# Generated at 2022-06-25 06:10:59.715399
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import ansible
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.strategy.linear import LinearStrategy
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    import sys
    import os

    # Explicitly override the display
    display = Display()
    display.verbosity = 3

    # Create a dictionary of all the variables we have and store it

# Generated at 2022-06-25 06:11:56.844225
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    assert True

# Generated at 2022-06-25 06:12:01.476563
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Setup the test
    include_role_0 = IncludeRole()
    vars_0 = {'key_0': 'value_0'}
    data_0 = {'key_0': 'value_0'}
    block_0 = Block()
    role_0 = Role()
    task_include_0 = TaskInclude()

    # Make the test
    result = include_role_0.load(data_0, block_0, role_0, task_include_0, vars_0)

    # Assert
    assert isinstance(result, IncludeRole)
    assert result is include_role_0



# Generated at 2022-06-25 06:12:07.137505
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data = {}
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = {}
    loader = {}
    include_role = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert include_role == include_role_0


# Generated at 2022-06-25 06:12:13.484350
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role = IncludeRole()
    params = include_role.get_include_params()
    assert params == {
        "ansible_parent_role_names": [],
        "ansible_parent_role_paths": [],
        "ansible_parent_role_params": {
            "role_name": None,
            "role_path": None,
        },
    }


# Generated at 2022-06-25 06:12:22.246512
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    data_1 = {u'allow_duplicates': True, u'name': u'web_servers', u'apply': {u'listen': u'5000'}}
    block_1 = None
    role_1 = None
    task_include_1 = None
    variable_manager_1 = None
    loader_1 = None

    result = include_role_1.load(data_1, block_1, role_1, task_include_1, variable_manager_1, loader_1)
    assert result.__class__.__name__ == IncludeRole



# Generated at 2022-06-25 06:12:25.027699
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0.name = 'name'
    assert include_role_0.get_name() == 'name'


# Generated at 2022-06-25 06:12:29.752545
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    results = include_role_0.load(
            data={
                                "name": "apache"
                                },
            variable_manager=None,
            loader=None)
    print(results)

if __name__ == '__main__':
    test_case_0()
    test_IncludeRole_load()

# Generated at 2022-06-25 06:12:32.441520
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole(block=Block())


# Generated at 2022-06-25 06:12:42.509898
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    data_1 = {'name': 'test1', 'apply': {'vars': {'a': '1'}}}
    # Check that the validation of the bad_opts is correct
    try:
        include_role_2 = IncludeRole()
        data_2 = {'name': 'test1', 'rolespec_validate': False, 'not_a_valid_name': False}
        include_role_2.load(data_2)
    except:
        include_role_1.load(data_1)


# Generated at 2022-06-25 06:12:43.879453
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Test the load method of Class IncludeRole
    """
    # Test the load method
    include_role_1 = IncludeRole()
