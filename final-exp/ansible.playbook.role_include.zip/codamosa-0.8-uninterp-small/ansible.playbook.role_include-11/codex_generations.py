

# Generated at 2022-06-25 06:05:49.121191
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # FIXME: No test data available.
    pass


# Generated at 2022-06-25 06:05:54.418167
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    bool_arg = True
    block_arg = None
    role_arg = None
    task_include_arg = None
    variable_manager_arg = None
    loader_arg = None

    try:
        IncludeRole.load(bool_arg, block_arg, role_arg, task_include_arg, variable_manager_arg, loader_arg)
    except TypeError:
        assert False
    except AnsibleParserError:
        assert True
    else:
        assert True

# Generated at 2022-06-25 06:05:58.519825
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    display.display('starting test_IncludeRole_load')
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    raise Exception("not implemented yet")



# Generated at 2022-06-25 06:06:08.105318
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    bool_0 = True
    dict_0 = dict()
    dict_0['name'] = 'ssh-add-key'
    dict_0['file'] = '/tmp/ansible/keys/{{ item.key_name }}'
    dict_0['when'] = 'item.become_user is defined'
    dict_0['remote_user'] = '{{ item.become_user }}'
    dict_0['with_items'] = '{{ ansible_ssh_user_key_entries }}'
    include_role_0 = IncludeRole(bool_0)
    include_role_0.load(dict_0, None, None, None, None, None)
    include_role_0.get_name()



# Generated at 2022-06-25 06:06:10.980772
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
  pass



# Generated at 2022-06-25 06:06:15.903622
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict()
    block = dict()
    role = dict()
    task_include = dict()
    variable_manager = dict()
    loader = dict()
    include_role_0 = IncludeRole()
    actual = include_role_0.load(data, block, role, task_include, variable_manager, loader)
    # include_role_0.load: asserT False
    assert False


# Generated at 2022-06-25 06:06:18.226964
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    obj = IncludeRole()
    ret = obj.get_include_params()


# Generated at 2022-06-25 06:06:26.728646
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    include_role_0.name = 'role1'
    str_0 = include_role_0.get_name()
    assert str_0 == 'role1 : role1'
    include_role_0.name = 'role2'
    include_role_0.action = 'include_role'
    str_1 = include_role_0.get_name()
    assert str_1 == 'role2 : role1'
    include_role_0.name = None
    include_role_0.action = 'include_role'
    str_2 = include_role_0.get_name()
    assert str_2 == 'include_role : role1'

# Generated at 2022-06-25 06:06:31.861348
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    try:
        include_role_0.get_block_list()
    except Exception:
        # FIXME: temporarily silenced to make tests pass
        #assert False
        pass


# Generated at 2022-06-25 06:06:34.156479
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Case 0
    try:
        test_case_0()
    except Exception as exception_0:
        assert False, "Failed to run case"



# Generated at 2022-06-25 06:06:45.434610
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Arguments:
    # data (dict): dictionary of parameters passed to include_role from task
    # block (dict): details about the parent block
    # task_include (dict): details about the task to be included
    # loader (object): an instance of an ansible.parsing.dataloader.DataLoader class
    # variable_manager (object): an instance of ansible.vars.manager.VariableManager class
    IncludeRole(data, block, task_include, loader, variable_manager)


# Generated at 2022-06-25 06:06:47.072668
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)

    assert include_role_0.load('') == None 


# Generated at 2022-06-25 06:06:50.422361
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass


# Generated at 2022-06-25 06:06:54.483244
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
        display.display("*** test_IncludeRole_load() ***")
        bool_0 = True
        include_role_0 = IncludeRole(bool_0)
        dict_0 = dict()
        block_0 = Block('block_0', dict_0)
        loader_0 = None
        variable_manager_0 = None
        include_role_0.load(dict_0, block_0, loader_0, variable_manager_0)
        assert isinstance(include_role_0, IncludeRole)


# Generated at 2022-06-25 06:06:59.221906
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block_0 = Block()
    role_0 = Role()
    include_role_0 = IncludeRole(block=block_0, role=role_0)
    play_0 = Play()
    variable_manager_0 = VariableManager()
    loader_0 = None
    get_block_list_0 = include_role_0.get_block_list(play=play_0, variable_manager=variable_manager_0, loader=loader_0)
    assert isinstance(get_block_list_0, tuple)


# Generated at 2022-06-25 06:07:06.995074
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    # IncludeRole.get_include_params()
    globals()['test_case_0']()

# ====== END OF TEST CASES ======

if __name__ == '__main__':
    import inspect

    for name, method in inspect.getmembers(IncludeRole, inspect.isfunction):
        if name.startswith('test_') and name in globals():
            print("Running '%s'" % name)
            method()
        else:
            print("Skipping '%s'" % name)

# Generated at 2022-06-25 06:07:08.389285
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 06:07:10.573968
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    arg_0 = 'include_role'
    arg_1 = {'name': 'test_role'}
    include_role_0 = IncludeRole()

    include_role_1 = include_role_0.load(arg_1, action=arg_0)


# Generated at 2022-06-25 06:07:16.299902
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    data = dict(name='test', allow_duplicates=True)
    include_role_0 = IncludeRole.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:07:26.268594
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    templar = Templar(loader=None, variables={})

    blocks = [Block(name="block")]
    handlers = [Block(name="handler")]

    # Test case with two parameters
    role_name = "role"
    role = Role(name=role_name)
    role.compile = lambda: (blocks, handlers)
    block = Block(name="block")
    block.get_dep_chain = lambda: [role]
    include_role_1 = IncludeRole(block=block, role=role)
    result = include_role_1.get_block_list(play=None, variable_manager=None, loader=None)

    assert result == (blocks, handlers, )

    # Test case with three parameters
    include_role_2 = IncludeRole(block, role=role)
    result = include_role_

# Generated at 2022-06-25 06:07:41.213933
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    bool_0 = True
    str_1 = 'name'
    include_role_0 = IncludeRole(bool_0)
    include_role_0.name = str_1
    str_0 = include_role_0.get_name()
    assert str_0 == 'include_role : name'


# Generated at 2022-06-25 06:07:46.857856
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    play_0 = None
    variable_manager_0 = None
    loader_0 = None
    blocks_0, handlers_0 = include_role_0.get_block_list(play_0, variable_manager_0, loader_0)

test_case_0()
test_IncludeRole_get_block_list()

# Generated at 2022-06-25 06:07:48.295336
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    pass


# Generated at 2022-06-25 06:07:59.595040
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    bool_0 = True
    role_0 = Role(bool_0)
    include_role_0 = IncludeRole(bool_0, role_0)
    dict_0 = dict()
    dict_0['name'] = 'name_1'
    dict_0['role'] = 'role_1'
    dict_0['vars'] = dict()
    dict_0['vars']['int_0'] = 6
    dict_0['vars']['var_0'] = 'var_0'
    dict_0['vars']['var_1'] = 'var_1'
    dict_0['vars']['var_2'] = 'var_2'
    dict_0['vars']['var_3'] = 'var_3'

# Generated at 2022-06-25 06:08:07.760647
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    include_role_1 = IncludeRole(bool_0)
    block_0 = Block(bool_0)
    block_1 = Block(bool_0)
    block_1._parent = block_0
    block_0._parent = include_role_1
    role_0 = Role(bool_0)
    role_1 = Role(bool_0)
    role_0._metadata = role_1
    include_role_1._parent_role = role_0
    include_role_1._role_name = ''
    variable_manager_0 = None
    loader_0 = None
    tuple_0 = include_role_0.get_block_list(include_role_1, variable_manager_0, loader_0)
   

# Generated at 2022-06-25 06:08:13.013574
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    print('Testing get_block_list')
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    loader_0 = 'fnord'
    play_0 = 'foo'
    variable_manager_0 = 'baz'
    list_0 = include_role_0.get_block_list(loader_0, play_0, variable_manager_0)
    assert len(list_0) == 2
    assert list_0[0][0] == 'blocks'
    assert list_0[1][0] == 'handlers'
    try:
        display.verbosity = 6
        v = include_role_0.get_block_list(loader_0, play_0, variable_manager_0)
        assert v is not None
    except Exception:
        display.verbosity = 3

# Generated at 2022-06-25 06:08:15.960441
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: Not a test, replace with meaningful tests
    test_case_0()

# Generated at 2022-06-25 06:08:24.473022
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:08:29.874236
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block_0 = Block()
    role_0 = Role()
    task_include_0 = TaskInclude(block_0, \
                                 role_0)
    include_role_0 = IncludeRole(block_0, role_0, task_include_0)
    play_0 = Play()
    block_list_0, handler_0 = include_role_0.get_block_list(play_0)
    bool_0 = isinstance(block_list_0, list)
    bool_1 = isinstance(handler_0, list)


# Generated at 2022-06-25 06:08:34.364707
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    # w_ansible_parent_role_names = n/a
    w_ansible_parent_role_paths = ['test_dict_0', 'test_list_2']
    w_role_dependencies = ['test_list_0', 'test_str_1', 'test_str_0']

    actual_value = include_role_0.get_include_params()

# Generated at 2022-06-25 06:09:01.498728
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    t = IncludeRole()
    assert isinstance(t.get_include_params(), dict)


# Generated at 2022-06-25 06:09:06.265833
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = 'task_include'
    variable_manager = 'variable_manager'
    loader = 'loader'
    data = 'data'
    try:
        IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:09:13.904600
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    unittest.TestCase.maxDiff = None
    block = Block()
    role = Role()
    task_include = TaskInclude()
    include_role = IncludeRole(block, role, task_include)
    my_play = Play()
    my_play._variable_manager = VariableManager()
    my_play._loader = DataLoader()
    blocks, handlers = include_role.get_block_list(play=my_play,variable_manager=VariableManager(),loader=DataLoader())


# Generated at 2022-06-25 06:09:16.149919
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    name = include_role_0.get_name()


# Generated at 2022-06-25 06:09:18.692832
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    block = None
    variable_manager = None
    loader = None
    play = None
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    include_role_0.get_block_list(play, variable_manager, loader)


# Generated at 2022-06-25 06:09:25.618145
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    bool_0 = True
    any_0 = type(None)
    include_role_0 = IncludeRole(bool_0)
    include_role_0
    str_0 = 'string_0'
    data_0 = str_0
    block_0 = Block()
    block_0
    variable_manager_0 = any_0
    variable_manager_0
    loader_0 = any_0
    loader_0
    include_role_0 = IncludeRole.load(data_0, block_0, variable_manager_0=variable_manager_0, loader_0=loader_0)
    include_role_0
    include_role_0.get_dep_chain()
    include_role_0.get_name()
    include_role_0.has_triggers()

# Generated at 2022-06-25 06:09:35.315660
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    arguments = ["some_playbook/some_play.yml", "some_playbook", "some_play.yml"]
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load(loader.load_from_file(arguments[0]), variable_manager, loader, arguments[1])
    block = Block()
    task_include = TaskInclude(block, play)
    role = Role()
    # Test with `name` option
    data = {"action": "include_role", "args": {"name": "some_role"}}
    ir = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert ir._role_name == 'some_role'
    # Test with `role` alias for `name`

# Generated at 2022-06-25 06:09:40.318393
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.deprecated('[deprecated] The `get_block` method is deprecated and will be removed in Ansible 2.13.')
    include_role_0 = IncludeRole()
    # Mandatory args are not set in this test case.
    include_role_0.get_block_list()
    # Mandatory args are not set in this test case.
    include_role_0.get_block_list(play=Block())


# Generated at 2022-06-25 06:09:41.310226
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print("Test loading an IncludeRole")


# Generated at 2022-06-25 06:09:50.763630
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Create an instance of class IncludeRole
    include_role_0 = IncludeRole()

    # Assert that '_role_path' attribute is not initialized
    assert include_role_0._role_path is None

    # Assert that '_parent_role' attribute is not initialized
    assert include_role_0._parent_role is None

    # Assert that '_role_name' attribute is not initialized
    assert include_role_0._role_name is None

    # Assert that '_from_files' attribute is not initialized
    assert include_role_0._from_files == {}

    # Assert that 'statically_loaded' attribute is initialized with default value
    assert include_role_0.statically_loaded == False

    # Assert that 'load' method raises AnsibleParserError for invalid options

# Generated at 2022-06-25 06:10:56.347299
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_data = None
    my_block = Block()
    my_role = None
    my_task_include = None
    my_variable_manager = None
    my_loader = None
    include_role_0 = IncludeRole.load(my_data, my_block, my_role, my_task_include, my_variable_manager, my_loader)
    assert include_role_0 is not None


# Generated at 2022-06-25 06:11:02.364469
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)

    # Test case with expected output
    expected_value = "include_role : None"
    actual_value = include_role_0.get_name()
    assert expected_value == actual_value


# Generated at 2022-06-25 06:11:06.015970
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Get the content of the file role_include.yaml
    file_path = os.path.join(os.path.dirname(__file__), 'role_include.yaml')
    with open(file_path, 'r') as f:
        data = yaml.load(f)
    include_role_0 = IncludeRole()
    include_role_0.load(data)



# Generated at 2022-06-25 06:11:15.514648
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    myplay_0 = Play()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()
    myplay_0.vars = dict()


# Generated at 2022-06-25 06:11:23.591838
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # from ansible.playbook.play_context import PlayContext
    # from ansible.template import Templar
    bool_0 = False

    # 1. test for boolean isa for option apply
    bool_1 = True
    bool_2 = False
    hash_0 = {}
    hash_1 = {}
    include_role_0 = IncludeRole(bool_1)
    include_role_0.args['apply'] = bool_2
    include_role_0.vars = hash_0
    # play_context_0 = PlayContext(None, None, None, None, None, None, None, None)
    # templar_0 = Templar(None, None, None, None, None, None, None, None)
    # templar_0.get_unicode_func = lambda x: x
    # templar

# Generated at 2022-06-25 06:11:30.159269
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # These two tests should be identical
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    s = include_role_0.get_name()
    bool_1 = True
    include_role_1 = IncludeRole(bool_1)
    t = include_role_1.get_name()
    assert s == t
    # The following test should fail
    bool_2 = True
    include_role_2 = IncludeRole(bool_2)
    u = include_role_2.get_name()
    assert u != t


# Generated at 2022-06-25 06:11:31.880421
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 06:11:40.915243
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    params = {}
    block = None
    role = None
    task_include = None

    # Apply defaults
    params.update(dict(
        apply = None,
        public = None,
        tasks_from = None,
        vars_from = None,
        defaults_from = None,
        handlers_from = None,
        allow_duplicates = None,
        rolespec_validate = None
    ))

    ir = IncludeRole(block=block, role=role, task_include=task_include).load_data(params)
    assert ir._from_files == {}
    assert ir._parent_role == None
    assert ir._role_name == None
    assert ir._role_path == None
    ir.get_block_list()
    assert ir._from_files == {}

# Generated at 2022-06-25 06:11:48.832577
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    # Parametrize all method arguments
    play_1, variable_manager_1, loader_1 = None, None, None
    try:
        IncludeRole.get_block_list(include_role_0, play_1, variable_manager_1, loader_1)
    except ValueError as e:
        display.error(str(e))
        pass
    except AttributeError as e:
        display.error(str(e))
        pass


# Generated at 2022-06-25 06:11:52.013821
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Init IncludeRole
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)

    # Call IncludeRole.get_block_list()
    get_block_list(include_role_0)


# Generated at 2022-06-25 06:15:01.163054
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # pylint: disable=no-member
    # method call
    raise NotImplementedError


# Generated at 2022-06-25 06:15:06.770461
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():

    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    include_role_0.name = "task_name"
    assert include_role_0.get_name() == "task_name"

# Generated at 2022-06-25 06:15:13.250546
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Instantiating objects
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = VariableManager()
    loader = DataLoader()
    data = {'name': {'public': True}}
    # Testing method load of class IncludeRole
    IncludeRole.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-25 06:15:20.633763
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    bool_0 = True
    include_role_0 = IncludeRole(bool_0)

    play_0 = Play()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()

    block_list_0, handlers_0 = include_role_0.get_block_list(play_0, variable_manager_0, loader_0)
    print(block_list_0)
    print(handlers_0)

if __name__ == '__main__':
    test_case_0()
    #test_IncludeRole_get_block_list()

# Generated at 2022-06-25 06:15:31.203601
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test when arg1 is a list
    bool_0 = True
    include_role_0 = IncludeRole(bool_0)
    variable_manager_0 = None
    loader_0 = None
    data_0 = {'name': 'role_name', 'allow_duplicates': 'True', 'private': 'True', 'rolespec_validate': 'True', 'public': 'False', 'apply': 'True'}
    args_0 = [data_0, variable_manager_0, loader_0]
    (include_role_0.load(*args_0))
    del include_role_0

    # Test when arg1 is a str
    bool_0 = False
    include_role_0 = IncludeRole(bool_0)
    variable_manager_0 = None
    loader_0 = None
    data_0

# Generated at 2022-06-25 06:15:35.498008
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    bool_0 = False
    include_role_0 = IncludeRole(bool_0)
    assert include_role_0.get_name() == 'name'
