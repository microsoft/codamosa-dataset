

# Generated at 2022-06-25 06:05:49.875700
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role.name = 'name'
    include_role._role_name = "role_name"
    include_role.args = {'name': 'role_name'}
    include_role.apply = {'tags': ['tag1', 'tag2']}
    include_role.collections = ['collection1', 'collection2']
    include_role._parent_role = 'parent_role'
    include_role._allow_duplicates = True
    include_role._public = True
    include_role.statically_loaded = False
    include_role._rolespec_validate = True
    include_role._from_files['tasks'] = 'tasks.yml'
    include_role._from_files['handlers'] = 'handlers.yml'
    include_

# Generated at 2022-06-25 06:05:52.237305
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    include_role._parent_role = "test_parent_role"
    include_role._role_name = "test_role_name"
    assert hasattr(include_role, 'get_block_list') and callable(getattr(include_role, 'get_block_list'))

# Generated at 2022-06-25 06:05:55.592437
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data_1 = {'role':'test', 'public':True}
    role_1 = include_role_0.load(data_1)
    assert role_1._role_name == 'test'
    assert role_1.public == True

# Generated at 2022-06-25 06:05:57.577895
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    result = include_role_0.get_block_list()
    assert result == ((), ())


# Generated at 2022-06-25 06:06:02.598791
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_0 = IncludeRole()
    params = include_role_0.get_include_params()
    assert params == {'ansible_role_name': None, 'ansible_role_path': None, 'ansible_role_version': None, 'ansible_role_short_name': None, 'ansible_role_namespace': None}


# Generated at 2022-06-25 06:06:06.056823
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    include_role_load_0 = IncludeRole()
    include_role_load_0.load({'name': 'admin'})
    assert include_role_load_0._role_name == 'admin'


# Generated at 2022-06-25 06:06:12.816888
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.deprecated('Un-deprecated')
    include_role = IncludeRole()
    with open('/etc/ansible/hosts') as f:
        data = {}
        data['name'] = '/etc/ansible/hosts'
        data['tasks_from'] = '/etc/ansible/hosts'
        data['vars_from'] = '/etc/ansible/hosts'
        data['defaults_from'] = '/etc/ansible/hosts'
        data['handlers_from'] = '/etc/ansible/hosts'
        data['allow_duplicates'] = True
        data['public'] = False
        data['rolespec_validate'] = True
        variable_manager = True
        loader = True
        block = True
        role = True
        task_include = True

# Generated at 2022-06-25 06:06:21.863270
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    role_1 = Role()

    # Load RoleInclude instance
    block_0 = Block()
    block_0._play = Play()
    block_0._play.register_variable('from_file_0', 'tasks', 'tasks/main.yml')
    block_0._play.register_variable('from_file_1', 'vars', 'vars/main.yml')
    block_0._play.register_variable('from_file_2', 'handlers', 'handlers/main.yml')
    block_0._play.register_variable('from_file_3', 'defaults', 'defaults/main.yml')


# Generated at 2022-06-25 06:06:27.612714
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # set the default arguments for task include role
    test_task_include_role_arguments = dict(
        name = 'test-role1',
        apply = dict(task1='task-param1')
    )

    # test returning the task from IncludeRole.load method
    return_task = IncludeRole.load(data=test_task_include_role_arguments, block=None)
    assert return_task.name == 'test-role1'
    assert return_task.apply == dict(task1='task-param1')

# Generated at 2022-06-25 06:06:33.339488
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test for invalid 'obj' value
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    ir = IncludeRole()
    play = ir
    assert ir.get_block_list(play=play, variable_manager=variable_manager, loader=loader) == ({}, {})


# Generated at 2022-06-25 06:06:43.279860
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:06:51.922043
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {u'name': u'testcase0'}
    include_role = IncludeRole.load(data, block=None,
                                    role=None,
                                    task_include=None,
                                    variable_manager=None,
                                    loader=None)

    assert not hasattr(include_role, 'meta')
    assert include_role._block is None
    assert not hasattr(include_role, 'tags')
    assert include_role._parent is None
    assert not hasattr(include_role, 'when')
    assert include_role._role is None
    assert not hasattr(include_role, 'always_run')
    assert not hasattr(include_role, 'delegate_to')
    assert not hasattr(include_role, 'notify')
    assert not hasattr(include_role, 'register')


# Generated at 2022-06-25 06:07:03.008684
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Arrange
    import os
    import sys
    import json
    import re
    import io
    sys.path.append('/home/arpit/Desktop/Ansible_Course/Ansible_Automation_Course_Day2_Downloads/ansible-2.9.10/lib/ansible/plugins/action')
    sys.path.append('/home/arpit/Desktop/Ansible_Course/Ansible_Automation_Course_Day2_Downloads/ansible-2.9.10/lib/ansible/plugins/action/__pycache__')

# Generated at 2022-06-25 06:07:08.142295
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()

    # TODO: Implement unit test
    raise Exception("not yet implemented")


# Generated at 2022-06-25 06:07:11.880935
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # TODO: needs to be implemented
    pass


# Generated at 2022-06-25 06:07:16.486335
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    role_info = RoleInclude()
    role_info.name = 'test-1'
    role_info.vars = {}
    assert len(include_role.get_block_list(role_info)) == 0


# Generated at 2022-06-25 06:07:26.467929
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():

    # No parent role set
    include_role_0 = IncludeRole()
    include_role_0.statically_loaded = True
    include_role_0._role_name = 'role_0'
    include_role_0._role_path = 'role_path_0'

    assert include_role_0.get_include_params() == {'role_name': 'role_0', 'role_path': 'role_path_0'}

    # Parent role set
    include_role_1 = IncludeRole()
    include_role_1.statically_loaded = True
    include_role_1._role_name = 'role_1'
    include_role_1._role_path = 'role_path_1'

    role_0 = Role()
    role_0.name = 'role_0'
    role_

# Generated at 2022-06-25 06:07:35.539547
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # create object
    ir = IncludeRole()

    fdict = {
        'name': 'role_name',
        'tasks_from': 'subdir/main.yaml',
        'vars_from': 'subdir/vars.yaml',
        'handlers_from': 'subdir/handlers.yaml',

        'apply': {
            'tags': ['test'],
            'when': 'test == 1',
            'with_items': [1, 2, 3]
        },

        'public': True,
        'allow_duplicates': False,
        'rolespec_validate': False,
    }

    ir.load(fdict)

    assert ir.name == 'role_name'
    assert ir.task_include == 'role_name'

# Generated at 2022-06-25 06:07:40.336904
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    if not isinstance(include_role_0, IncludeRole):
        raise Exception('failed to create an instance of IncludeRole')

# Generated at 2022-06-25 06:07:41.933762
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    # Call method load
    include_role_1.load()

# Generated at 2022-06-25 06:07:59.410215
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        role="test_role",
        name="test_role",
        tasks_from="test_role_task",
        vars_from="test_role_vars",
        defaults_from="test_role_def",
        handlers_from="test_role_handler",
        apply=dict(test_role_apply="test_role_apply"),
        public="test_role_public",
        allow_duplicates="test_role_allow_dup"
    )
    include_role = IncludeRole.load(data, variable_manager=None, loader=None)

    role_name = include_role._role_name
    assert role_name == "test_role"
    role_path = include_role._role_path
    assert role_path is None
    allow_duplicate = include_role

# Generated at 2022-06-25 06:08:07.646849
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    data = {'name': 'some_name'}
    variable_manager = None
    loader = None
    include_role.load(data, variable_manager, loader)
    assert include_role.name == 'some_name'
    assert include_role.public == False
    assert include_role.allow_duplicates == True
    assert include_role.rolespec_validate == True
    assert include_role._role_name == 'some_name'
    assert isinstance(include_role._from_files, dict)
    assert include_role._from_files == {'tasks': 'tasks.yml', 'vars': 'vars.yml', 'handlers': 'handlers.yml', 'defaults': 'defaults.yml'}


# Generated at 2022-06-25 06:08:17.821773
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None

    my_args = {'name': 'foo'}
    include_role_0 = IncludeRole.load(my_args, block, role, task_include, variable_manager, loader)

    # Validate args
    args_value = include_role_0.args.get('name')
    if not isinstance(args_value, string_types):
        raise AssertionError('Expected a string for name but got {0} instead'.format(type(args_value)))

    # Validate role_name
    role_name_value = include_role_0._role_name

# Generated at 2022-06-25 06:08:23.751057
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    x = IncludeRole()
    x.rolespec_validate = 'boo'
    y = Block()
    z = Role()

    x.get_block_list(play=y, role=z)

# Generated at 2022-06-25 06:08:26.759589
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    IncludeRole: get_include_params test cases
    """
    include_role_1 = IncludeRole()
    result_0 = include_role_1.get_include_params()
    print(result_0)


# Generated at 2022-06-25 06:08:38.484605
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import os
    import sys
    import types
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(test_dir)

    from test_cases.test_play import test_play

    test_play_1 = test_play.get_test_play_1()

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar

# Generated at 2022-06-25 06:08:41.548492
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    try:
        include_role = IncludeRole.load({}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    except AnsibleParserError as e:
        display.display(e)
        display.display("validation error in load")
        return(1)



# Generated at 2022-06-25 06:08:48.999400
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data = {'name': 'foo'}
    block = Block()
    role = Role()
    task_include = TaskInclude(block=block, role=Role())
    variable_manager = VariableManager()
    loader = DataLoader()
    include_role_1 = IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    assert include_role_1 is not None
    assert include_role_1._role_name == 'foo'


# Generated at 2022-06-25 06:08:51.064528
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    assert(include_role_1.get_block_list() == None)


# Generated at 2022-06-25 06:08:55.192082
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {u'include_role': {u'name': u'foobar', u'public': True}}
    my_ir = IncludeRole.load(data, task_include=TaskInclude.load(data))
    assert my_ir._role_name == 'foobar'
    assert my_ir.public == True

# Generated at 2022-06-25 06:09:17.829779
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Name of the test case
    name = "IncludeRole_load"

    # Object to hold the test data
    data = []

    # We have to pass this value, so that we can pass below arguments
    # to check whether they can be passed or not
    obj = IncludeRole(Block(play=None), None, None)

    # 1. Args: (data, block=None, role=None, task_include=None,
    # variable_manager=None, loader=None)
    # This function is called with arguments passed to the function.
    # We have to check with all possible combinations
    # of arguments, for that we will use all the arguments
    # which are defined above

    # 1.1. Argument passed is None

# Generated at 2022-06-25 06:09:20.602734
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test setup
    # Perform test
    include_role = IncludeRole.load(data={"include_role":{"name":"test"}})

    # Test assertions
    assert type(include_role) is IncludeRole


# Generated at 2022-06-25 06:09:26.595296
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print("==== test_IncludeRole_load ====")
    data = dict(name = 'TestRole')
    include_role = IncludeRole().load(data)
    assert isinstance(include_role, IncludeRole)
    assert include_role.get_name() == 'include_role : TestRole'
    assert include_role._parent is None
    assert include_role._role_name == 'TestRole'
    assert include_role._role_path is None
    assert include_role._from_files == {}


# Generated at 2022-06-25 06:09:36.079897
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Create an include role and load it (picks up test_playbook/roles/test_role)
    include_role = IncludeRole().load({"include_role": {"name": "test_role"}}, variable_manager=VariableManager(), loader=DataLoader())

    # IncludeRole has a list of parents, which is empty in this case
    assert(include_role.parents == [])

    # IncludeRole has a list of tasks, which is empty in this case
    assert(include_role.tasks == [])

    # IncludeRole has a list of handlers, which is empty in this case
    assert(include_role.handlers == [])

    # Verify that the include role is named
    assert(include_role.name == "test_role")

    # Now load the same role, but with a different name
    include_role2 = IncludeRole

# Generated at 2022-06-25 06:09:45.374116
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data_0 = {'rolespec_validate': False}
    result_0 = include_role_0.load(data_0)
    assert result_0._rolespec_validate is False
    assert result_0.rolespec_validate() is False
    assert result_0.rolespec_validate is False
    assert result_0.rolespec_validate is False

    # Example of assertion for the IncludeRole class's method load
    include_role_1 = IncludeRole()
    assert include_role_1.load("abc") is None

# Generated at 2022-06-25 06:09:48.357266
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    assert include_role_0.get_block_list() == ([],[])



# Generated at 2022-06-25 06:09:58.953543
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    display.verbosity = 4
    display.deprecated('The PlaybookInclude class is being deprecated soon.', version='2.12')
    # Test 1 - empty data
    data = {}
    result = IncludeRole.load(data, variable_manager=VariableManager(), loader=DataLoader())
    assert isinstance(result, IncludeRole)
    assert not result.name
    assert not result.args
    assert not result._valid
    # Test 2 - valid data - no options

# Generated at 2022-06-25 06:10:04.369040
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # load invalid data
    try:
        IncludeRole.load({})
    except AnsibleParserError as e:
        assert 'name is a required field for include_role.' in str(e)

    # load data with unknown parameters
    try:
        IncludeRole.load({'name': 'test', 'foobar': 'xyzzy'})
    except AnsibleParserError as e:
        assert 'Invalid options for include_role: foobar' in str(e)

    # load data with only minimal parameters
    include_role_1 = IncludeRole.load({'name': 'test'})
    assert 'test' == include_role_1.name
    assert 'name' in include_role_1.args
    assert 'test' == include_role_1.args['name']
    assert include_role_1.allow_duplicates
   

# Generated at 2022-06-25 06:10:07.997862
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    t_0 = dict(name="test")
    include_role_0 = IncludeRole.load(t_0)

    t_1 = dict(action="include")
    t_1.update(t_0)
    include_role_1 = IncludeRole.load(t_1)


# Generated at 2022-06-25 06:10:17.322049
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {
        'include_role': {
            'role': 'foo',
            'name': 'bar',
            'allow_duplicates': 'true',
            'apply': {
                'tags': ['tag1', 'tag2', 'tag3'],
                'when': 'true',
            },
            'tasks_from': 'tasks_file',
            'vars_from': 'vars_file',
            'defaults_from': 'defaults_file',
            'handlers_from': 'handlers_file',
            'also_this': 'is_bad'
        }
    }

    # Original test case
    try:
        IncludeRole.load(data)
    except:
        pass

# Generated at 2022-06-25 06:11:00.220904
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test case for loading a role
    include_role = IncludeRole()
    include_args = dict(
        name="test_role_simple_include",
        tasks_from="../../roles/test/vars/main.yml"
    )
    # Build test object
    include_role.load(
        include_args, 
        task_include=dict()
    )
    # Check the role name is set correctly
    assert include_role._role_name == "test_role_simple_include"
    # Check the role path is correct
    assert include_role._role_path == "../../roles/test/vars/main.yml"
    assert include_role._parent_role is None 
    # Check the collection list
    assert include_role.collections is None

    # Test case for loading a role

# Generated at 2022-06-25 06:11:03.661815
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    result = include_role_0.load({"role": "test"}, variable_manager={}, loader={})
    assert result.args['role'] == "test"


# Generated at 2022-06-25 06:11:10.737050
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole(block=Block())
    include_role_0._role_name = "roles/common/tasks/main.yml"
    answer = include_role_0.get_name()
    assert(answer == 'include_role : roles/common/tasks/main.yml')


# Generated at 2022-06-25 06:11:21.023134
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    import ansible.playbook.role.definition

    # set up test data
    data = dict(name="test1")
    role = ansible.playbook.role.definition.RoleDefinition()
    block = Block()

    include_role = IncludeRole.load(data, block=block, role=role)
    assert hasattr(include_role, '_allow_duplicates')
    assert hasattr(include_role, '_role_name')
    assert hasattr(include_role, 'args')
    assert hasattr(include_role, 'block')
    assert hasattr(include_role, 'delegate_to')
    assert hasattr(include_role, 'notify')
    assert hasattr(include_role, 'register')
    assert hasattr(include_role, 'retries')

# Generated at 2022-06-25 06:11:26.060321
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Instantiate class
    my_obj = IncludeRole()
    assert isinstance(my_obj, IncludeRole)
    assert isinstance(my_obj, TaskInclude)
    assert isinstance(my_obj, Block)
    assert True


# Generated at 2022-06-25 06:11:28.614786
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    assert include_role_0.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None) == include_role_0


# Generated at 2022-06-25 06:11:38.783180
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    print('# Unit test for method load of class IncludeRole')
    include_role_0 = IncludeRole()
    data = {} # Dummy data to load the object

    # Load data and test the fields
    include_role_0.load(data)
    assert include_role_0.get_name() == "%s : " % include_role_0.action
    assert include_role_0.get_vars() == {}

    # Load data with a name specified and test the fields
    data['name'] = 'test'
    include_role_0.load(data)
    assert include_role_0.get_name() == "%s : %s" % (include_role_0.action, 'test')

    # Load data with vars specified and test the fields
    data.pop('name')

# Generated at 2022-06-25 06:11:45.112427
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    logger = logging.getLogger('TestCase_IncludeRole_get_block_list')
    logger.debug('\n===  Unit test for method get_block_list of class IncludeRole')
    logger.debug('\n===  Unit test for method get_block_list started')
    # Create include_role_1 for testing
    include_role_1 = IncludeRole()
    logger.debug('\n===  Unit test for method get_block_list with parameter include_role_1 finished')
    # Create include_role_2 for testing
    include_role_2 = IncludeRole()
    logger.debug('\n===  Unit test for method get_block_list with parameter include_role_2 finished')
    # Create include_role_3 for testing
    include_role_3 = IncludeRole()

# Generated at 2022-06-25 06:11:53.794163
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # make-test.yml file is present in the directory containing this test script.
    # Executing this test script will convert test_case_1(show_content) method to a playbook,
    # which will call include_role in the 'tasks'
    # and it will look for the same file in 'path' present in the same directory.
    include_role_1 = IncludeRole(block = Block(), role = Role(name = 'test_case_1'))

    # Setting the attributes of Block object
    include_role_1.block.vars = {'test_var': 'test_val'}
    include_role_1.block.tags = ['all']

    # Setting the attributes of Role object
    include_role_1.role.default_vars = {'role_default_var': 'role_default_val'}


# Generated at 2022-06-25 06:11:57.556985
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_include_role_load = IncludeRole()


# Generated at 2022-06-25 06:13:04.530377
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    include_role_0.get_block_list()

# Generated at 2022-06-25 06:13:09.927194
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Data for test
    data = dict(
        name='common',
        apply=dict(
            vars=dict(
                foo=1
            )
        )
    )

    # Execute code under test
    include_role_1 = IncludeRole.load(data)

    # Assertions
    assert include_role_1.name == 'common'
    assert include_role_1._from_files == {'apply_vars': 'apply.yml'}
    assert include_role_1.args == data
    assert include_role_1._rolespec_validate

# Generated at 2022-06-25 06:13:18.119929
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    '''
    Unit test for method load of class IncludeRole
    '''
    # Load args into a dictionary
    args = {'name': 'test-role', 'tasks_from': 'abc', 'handlers_from': 'xyz', 'public': 'yes'}

    # Load the include_role with test args
    include_role_1 = IncludeRole.load(data=args)

    # Check that the name is correct
    assert include_role_1._role_name == 'test-role', "include_role_1._role_name value is incorrect!"

    # Check that the tasks_from is correct
    assert include_role_1._from_files['tasks'] == 'abc', "include_role_1._from_files value for 'tasks' is incorrect!"

    # Check that the handlers_from is correct
    assert include

# Generated at 2022-06-25 06:13:20.325244
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-25 06:13:22.965938
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Testing valid input
    include_role_0 = IncludeRole()
    assert include_role_0.load({"name": "debug", "tasks_from": "debug.yml"}) is not None, "A valid input should not fail!"

# Generated at 2022-06-25 06:13:29.454363
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Create a new IncludeRole.
    include_role = IncludeRole()

    # Get the block list for role included in this include_role.
    blocks_for_role_included = include_role.get_block_list()

    if blocks_for_role_included == None:
        return True
    else:
        return False

# Generated at 2022-06-25 06:13:33.147441
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    test_name0 = include_role_0.get_name()
    print("test_name0:", test_name0)


# Generated at 2022-06-25 06:13:34.731040
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # create object
    include_role = IncludeRole()

    #Verify the type of object returned by method load
    assert type(include_role.load({})) == IncludeRole

# Generated at 2022-06-25 06:13:40.738862
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    class MyRole:
        _metadata = None

    obj = IncludeRole()
    obj.task_include = "test"
    obj.args = dict(name=True)
    obj._parent = "test"
    obj._parent_role = MyRole()
    obj._role_name = "role1"
    obj._role_path = "/tmp/abc"
    obj.vars = dict()
    obj.collections = dict()
    assert obj.get_block_list() == (list(), list())

# Generated at 2022-06-25 06:13:41.239755
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass