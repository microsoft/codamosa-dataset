

# Generated at 2022-06-25 06:05:53.128412
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    fake_play_1 = FakePlay('fake_play_1')
    fake_variable_manager_2 = FakeVariableManager()
    fake_loader_3 = FakeLoader()

    try:
        include_role_0.get_block_list(play=fake_play_1, variable_manager=fake_variable_manager_2, loader=fake_loader_3)
    except:
        raise AssertionError(
            "Get block list method of IncludeRole class raised an exception. get_block_list(play=fake_play_1, variable_manager=fake_variable_manager_2, loader=fake_loader_3)")



# Generated at 2022-06-25 06:05:57.639776
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Test case.
    block_0 = Block()
    block_0._parent = Block()
    block_0._play = Play()
    role_0 = Role()
    ir_0 = IncludeRole(block_0, role_0)

    # Test instantiation of method.
    assert isinstance(ir_0.get_block_list(), (tuple, list))


# Generated at 2022-06-25 06:06:00.438662
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # create an object of the class IncludeRole
    include_role_obj = IncludeRole()

    #load method of class IncludeRole
    include_role_obj.load()



# Generated at 2022-06-25 06:06:02.858403
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_1 = IncludeRole()
    assert include_role_1.get_include_params() == include_role_1.vars


# Generated at 2022-06-25 06:06:05.961466
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    test_case = IncludeRole()
    expected = 'None : None'
    result = test_case.get_name()
    assert result == expected


# Generated at 2022-06-25 06:06:11.100435
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    include_role_1 = IncludeRole()
    result = include_role_1.get_include_params()
    assert isinstance(result, dict)


# Generated at 2022-06-25 06:06:14.710985
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create object of class Role
    role_obj = Role()

    # Create object of class IncludeRole
    include_role_obj = IncludeRole()

    # call the get_block_list() method of class IncludeRole
    include_role_obj.get_block_list(role_obj)

# Generated at 2022-06-25 06:06:16.214532
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    pass

# Generated at 2022-06-25 06:06:21.890910
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # include_role_load_0
    include_role_load_0 = {'include_role': {'name': 'test_role'}}
    display.debug = True
    include_role_load_result = IncludeRole.load(include_role_load_0)
    display.debug = False
    display.display(include_role_load_0)
    return include_role_load_result


# Generated at 2022-06-25 06:06:25.840374
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    parent_role = Block()
    parent_role.vars = {"name":"parent-role"}
    parent_role._role_params = {"name":"parent-role"}
    role_include = IncludeRole(block=Block(), role=parent_role)
    role_include.vars = {"name":"child-role"}
    role_include.action = "include_role"
    expected_result = {
        "name": "child-role",
        "ansible_parent_role_names": ["parent-role"],
        "ansible_parent_role_paths": ["None"]
    }
    assert role_include.get_include_params() == expected_result


# Generated at 2022-06-25 06:06:40.732151
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    host_list = ['localhost', 'localhost']
    play_source = dict(
        name='Ansible Play',
        hosts=host_list,
        gather_facts='no',
        roles=[]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)
    play = play.load()

    include_role = IncludeRole()
    include_role.name = 'Include Role'
    include_role.statically_loaded = True
    include_role._role_name = 'include_role_test'
    import sys
    include_

# Generated at 2022-06-25 06:06:47.578335
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    """
    x = IncludeRole()

    # test args
    args = dict(
        name='motd',
        tasks_from='tasks/main.yml',
        vars_from='defaults/main.yml',
        public=True,
        apply={"list": ["all"]},
    )

    test_data = dict(
        args=args,
        block=Block(),
        role='motd',
        task_include='motd',
        variable_manager='motd',
        loader='motd',
    )

    y = x.load(args, **test_data)
    assert y._role_path == 'motd'
    assert y.vars

# Generated at 2022-06-25 06:06:50.793910
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    test_case = IncludeRole()
    assert not test_case.get_block_list()

# Generated at 2022-06-25 06:06:56.772549
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    from ansible.playbook.role.definition import RoleDefinition

    role_definition_0 = RoleDefinition()
    role_definition_0.name = "test_name"

    include_role_0 = IncludeRole()
    include_role_0.name = "test_name"
    include_role_0.role = "test_role"
    include_role_0._parent_role = role_definition_0
    include_role_0.vars = "test_vars"
    include_role_0._from_files = "test_files"

    #
    from ansible.playbook.play import Play

    play_0 = Play()
    play_0.name = "test_name"
    play_0.hosts = "test_hosts"


# Generated at 2022-06-25 06:07:06.604612
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.verbosity = 3
    loader = DictDataLoader({})
    for path in ['ansible/test/units/lib/ansible/playbook/test_include_role.py',
                 'ansible/test/units/lib/ansible/playbook/test_include_role.yml']:
        path = os.path.realpath(path)
        if os.path.splitext(path)[-1] == '.py':
            loader.set_basedir(path)
        else:
            loader.set_basedir(os.path.dirname(path))
            loader.path_exists = lambda P: True if P == path else False
            loader.is_file = lambda P: True if P == path else False

# Generated at 2022-06-25 06:07:13.627117
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    play_context = PlayContext()

# Generated at 2022-06-25 06:07:20.659813
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    first_block = Block()
    second_block = Block()
    third_block = Block()
    fourth_block = Block()
    my_role = Role()
    my_parent_role = Role()
    include_role = IncludeRole(first_block,my_role,my_parent_role)
    include_role.get_block_list()
    assert first_block.get_name() == "include_role : test_role"

# Generated at 2022-06-25 06:07:21.757682
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()


# Generated at 2022-06-25 06:07:22.825263
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # TODO: write test
    pass


# Generated at 2022-06-25 06:07:29.305556
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Make sure load method simply raises exception
    parser_error = None
    try:
        IncludeRole.load(None)
    except AnsibleParserError as ex:
        parser_error = ex
    assert isinstance(parser_error, AnsibleParserError)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:07:50.542817
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    def check_result(r):
        assert r._role_name == 'foo'
        assert r._from_files == {
            'tasks': 'override.yml',
            'vars': 'vars.yml',
            'defaults': 'defaults.yml',
            'handlers': 'handlers.yml'
        }
        assert r.public == True
        assert r.allow_duplicates == False

    # test with action and role name

# Generated at 2022-06-25 06:08:00.949334
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    # Test a simple role include
    role_test_file_path = 'tests/integration/targets/test_include_role'
    display.vvv('ROLE LOADING: ' + role_test_file_path)
    role = Role.load(role_test_file_path)

    ir = IncludeRole(name='test_include_role')
    assert ir._role_name == 'test_include_role'
    blocks, handlers = ir.get_block_list(play=None, variable_manager=None, loader=None)

    assert len(blocks) == 4
    assert len(handlers) == 2

    assert isinstance(blocks[0], Block)
    assert isinstance(blocks[1], Block)
    assert isinstance(blocks[2], Block)
    assert isinstance(blocks[3], Block)


# Generated at 2022-06-25 06:08:08.405244
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # kwargs for method IncludeRole.load()
    data = {
      'name': 'test_role_name', 
      'tasks_from': 'test_tasks_from', 
      'vars_from': 'test_vars_from', 
      'defaults_from': 'test_defaults_from', 
      'handlers_from': 'test_handlers_from', 
      'apply': 'test_apply', 
      'public': 'test_public', 
      'allow_duplicates': 'test_allow_duplicates', 
      'rolespec_validate': 'test_rolespec_validate'
    }
    block = Block()
    role = Role()
    task_include = TaskInclude()

# Generated at 2022-06-25 06:08:14.355595
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """Test get_block_list method of class IncludeRole"""

    test_case_0()

if __name__ == '__main__':
    #import sys
    #sys.argv = ['', 'Test.testName']
    test_IncludeRole_get_block_list()

# Generated at 2022-06-25 06:08:23.651510
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    case_1 = dict(
        name='MyTestRole',
        tasks_from='some_file.yml',
        vars_from='some_other_file.yml',
        handlers_from='third_file.yml',
        apply='some_data.yml',
        public=True,
        allow_duplicates=False,
        rolespec_validate=False,
        somekey='somevalue',
    )

# Generated at 2022-06-25 06:08:25.885142
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-25 06:08:27.946116
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    ir = IncludeRole()
    assert ir.load is IncludeRole.load

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:08:36.353636
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    block_1 = Block()
    block_1.module_name = 'host_alias'
    block_1.args = 'hello'
    block_2 = Block()
    block_2.module_name = 'raw'
    block_2.args = 'world'
    block_list = [block_1, block_2]
    include_role_1._parent = block_list
    include_role_1.action = 'command'
    block_list[0].parent = block_list[1]

# Generated at 2022-06-25 06:08:44.245342
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    path = 'lib/ansible/tests/unit/targets/include_role_test_0.yml'
    role_path = 'lib/ansible/tests/unit/targets/include_role_test_1.yml'
    with open(path, 'r') as stream_include_role_0:
        include_data_0 = yaml.safe_load(stream_include_role_0)
    block_0 = Block.load(include_data_0[0], role=Role())
    task_include_0 = block_0.block[0]
    task_include_1 = IncludeRole(block=block_0, task_include=task_include_0)
    task_include_1._role_path = role_path

# Generated at 2022-06-25 06:08:53.986536
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_load_0 = IncludeRole()
    data_0 = {"rolespec_validate": True, "allow_duplicates": True, "_parent": {}, "_role": {}, "args": {"name": "apache", "public": True}}
    variable_manager_0 = {}
    loader_0 = {}

    include_role_load_1 = include_role_load_0.load(data_0, variable_manager=variable_manager_0, loader=loader_0)

    assert include_role_load_1._role_name == 'apache'
    assert include_role_load_1._from_files == {}
    assert include_role_load_1._allow_duplicates == True
    assert include_role_load_1._public == True


# Generated at 2022-06-25 06:09:42.954898
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Test AnsibleParserError when neither name nor role is defined.
    """
    include_role_0 = IncludeRole()
    with pytest.raises(AnsibleParserError) as error_info:
        include_role_0.load({}, {})
    assert str(error_info.value) == "IncludeRole._load(): 'name' is a required field for include_role."


# Generated at 2022-06-25 06:09:44.215586
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    """
    Tests load() in AnsibleModule
    """
    pass


# Generated at 2022-06-25 06:09:47.093836
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()
    include_role.load(['name=/home/abhinav/ansible/roles'])

# Generated at 2022-06-25 06:09:48.884534
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()

    assert include_role_0.get_name() == ": "



# Generated at 2022-06-25 06:09:55.361280
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.quiet(msg="Running test_IncludeRole_load ...")
    myblock = Block()
    myrole = Role()
    ir = IncludeRole(block=myblock, role=myrole).load_data({'include_role': {'name': 'test', 'vars': {}}})
    assert isinstance(ir, IncludeRole)


# Generated at 2022-06-25 06:10:05.825894
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block1 = Block().load(data={
        'name': 'Load Test',
    })
    block1.vars = {
        'var1': 'value1'
    }
    include_role_1 = IncludeRole(block=block1).load_data(data=dict(name='IncludeRole-1'))
    assert '''IncludeRole-1 : IncludeRole-1''' == include_role_1.get_name()
    assert dict(var1='value1') == include_role_1.vars
    assert '' == include_role_1.tasks_from
    assert '' == include_role_1.vars_from
    assert '' == include_role_1.defaults_from
    assert '' == include_role_1.handlers_from
    assert dict() == include_role_1.apply


# Generated at 2022-06-25 06:10:06.979637
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()


# Generated at 2022-06-25 06:10:16.641356
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    block = Block()
    role = Role()
    Play._variable_manager = VariableManager()
    try:
        result = IncludeRole.load({'name': 'web_servers'}, block, role, variable_manager=Play._variable_manager, loader=loader)
        assert result.get('_role_name') == 'web_servers', "Failed to load IncludeRole"
    except AnsibleParserError as ex:
        print(ex)
        assert False, "Unexpected AnsibleParserError exception"


# Generated at 2022-06-25 06:10:19.905540
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role = IncludeRole()
    test_result = include_role.get_block_list(play=None, variable_manager=None, loader=None)
    assert test_result == (None, None)


# Generated at 2022-06-25 06:10:22.185166
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    i = IncludeRole(None, None) 
    assert i.get_name() == "%s : %s" % (i.action, i._role_name)

# Generated at 2022-06-25 06:11:27.775108
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Setup
    include_role = IncludeRole()
    play = None
    variable_manager = None
    loader = None

    # Testing
    include_role.get_block_list(play=play, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-25 06:11:38.731574
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    example = {
        'foo': 'bar',
        'include': 'role.yml',
        'from': 'vars',
        'apply': {
            'task': '\\n   - shell: echo {{ bar }}',
            'block': '\\n   - name: foo\\n     block:\\n       - debug: msg="block"',
            'rescue': '\\n   - debug: msg="rescue"',
            'always': '\\n   - debug: msg="always"'
        }
    }
    block = Block()
    block.parent_block = Block()
    task = IncludeRole(block=block)
    task.load(example, block=block)

    assert task._from_files.get('vars') == 'role.yml'
    assert not task.apply
    assert not task.allow

# Generated at 2022-06-25 06:11:41.503797
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    test_data = {'name': 'test_name', 'apply': {'test': 'test'}, 'public': True}
    include_role_load = IncludeRole()
    include_role_load.load(test_data, block=Block(), role=Role())


# Generated at 2022-06-25 06:11:51.987417
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    include_role_0 = IncludeRole()
    include_role_0._parent=Block()
    include_role_0._parent._play=Play()
    include_role_0._parent._play.playbook=Playbook()
    include_role_0._parent._play.playbook.loader=VariableManager()
    include_role_0._parent._play.playbook.loader.set_basedir("/home/root1/ansible/")
    include_role_0._parent._play.context=PlayContext()
    include_role_0._parent._

# Generated at 2022-06-25 06:11:55.800383
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data = dict()
    block = Block()
    role = Role()
    variable_manager = VariableManager()
    loader = DataLoader()
    include_role_1 = include_role_0.load(data, block, role, variable_manager=variable_manager, loader=loader)
    assert include_role_1 is not None


# Generated at 2022-06-25 06:12:01.911193
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.display('Running IncludeRole load tests...')

    class TestIncludeRole(IncludeRole):

        def __init__(self, data, name=None):
            self.name = name
            include_role_0 = IncludeRole()
            self.action = include_role_0.action
            include_role_0._add_parent_attribute(self)
            IncludeRole.__init__(self, include_role_0._block, include_role_0._role, include_role_0._task_include)
            self._parent = include_role_0._parent
            include_role_0.load_data(data)
            self.args = include_role_0.args

    class FakePlaybook:
        pass

    playbook = FakePlaybook()
    playbook.handlers = []
    playbook.tasks = []
   

# Generated at 2022-06-25 06:12:13.046143
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.plugins.loader import role_loader

    action_0 = "include_role"
    line_0 = "19"
    name_0 = "include_role"
    tasks_0 = {"include_role": {"args": {"name": "foobar"}}}
    tasks_1 = {}
    tasks_2 = {}
    vars_0 = {}
    vars_1 = {"foobar_var": "barfoo"}
    hosts_0 = "localhost"
    roles_0 = []

# Generated at 2022-06-25 06:12:18.216174
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    display.display("Starting test_IncludeRole_load")
    include_role_0 = IncludeRole()
    assert include_role_0 is not None

    # Load the test data
    include_data = {'include_role': {'name': 'nginx'}}
    include_role_1 = IncludeRole.load(include_data, None, None, None, None, None)
    assert include_role_1._role_name == 'nginx'

    include_data = {'include_role': {'name': 'postgresql'}, 'vars': {'version': '10'}}
    include_role_2 = IncludeRole.load(include_data, None, None, None, None, None)
    assert include_role_2.vars == {'version': '10'}


# Generated at 2022-06-25 06:12:28.007067
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-25 06:12:34.767570
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(name='test', tasks_from='some.yml', allow_duplicates=False)
    ir = IncludeRole.load(data)
    assert ir._role_name == 'test'
    assert ir._from_files['tasks'] == 'some.yml'
    assert ir.allow_duplicates == False



# Generated at 2022-06-25 06:15:16.578963
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()
    data = {}
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    include_role_1 = include_role_0.load(data, block, role, task_include, variable_manager, loader)


# Generated at 2022-06-25 06:15:18.903584
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # role that does not exist
    ir = IncludeRole()
    ir._role_name = "dummy"
    ir.get_block_list()


# Generated at 2022-06-25 06:15:22.193096
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole.load({'include_role': dict()})
    assert include_role_1.action == 'include_role'



# Generated at 2022-06-25 06:15:31.898070
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    display.vvvv = True
    fake_loader = DictDataLoader({
        "/etc/ansible/roles/test/tasks/main.yaml": """
        - debug:
            msg: 'handlers test'
        """,
        "/etc/ansible/roles/test/handlers/main.yaml": """
        - debug:
            msg: 'tasks test'
        """
    })
    fake_variable_manager = VariableManager()
    fake_variable_manager.extra_vars = {'test': 'success'}


# Generated at 2022-06-25 06:15:33.281558
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()
    assert(isinstance(ir.get_block_list(), tuple))



# Generated at 2022-06-25 06:15:36.049065
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    a = IncludeRole()
    a.get_block_list()
