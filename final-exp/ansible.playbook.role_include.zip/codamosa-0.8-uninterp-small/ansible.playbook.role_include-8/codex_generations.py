

# Generated at 2022-06-25 06:05:50.396779
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    global include_role_0
    # Test call to method load of class IncludeRole with args: (({'apply': {}, 'role': 'foobar', 'public': True},), None,
    # None, None, None, None)
    include_role_0 = IncludeRole()
    assert include_role_0.load({'apply': {}, 'role': 'foobar', 'public': True}, None, None, None, None, None)



# Generated at 2022-06-25 06:05:52.998766
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    include_role_0._role_name = 'jeroen'
    assert 'include_role : jeroen' == include_role_0.get_name()

# Generated at 2022-06-25 06:05:57.059579
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ''' Unit test for method get_block_list of class IncludeRole '''
    # Test values
    role_name = 'test_role'

    # Test case
    role = Role(name=role_name)
    ir = IncludeRole(role=role)
    ir._role_name = role_name
    ir.get_block_list()

# Generated at 2022-06-25 06:06:00.652660
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Stub for load
    data = {
        "action": "include_role"
    }
    include_role_0 = IncludeRole.load(data)
    assert include_role_0.action == "include_role"


# Generated at 2022-06-25 06:06:09.998865
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Initialisations
    include_role_0 = IncludeRole()
    include_role_0.load_data({u'name': u'/tmp/role_file', u'allow_duplicates': u'yes', u'rolespec_validate': u'yes'})

    # Assertions
    assert isinstance(IncludeRole.load(data={u'name': u'/tmp/role_file', u'allow_duplicates': u'yes', u'rolespec_validate': u'yes'}), IncludeRole) == True
    assert isinstance(IncludeRole.load(data={u'name': u'/tmp/role_file', u'allow_duplicates': u'yes', u'rolespec_validate': u'yes'}, block=Block()), IncludeRole) == True

# Generated at 2022-06-25 06:06:11.793107
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # noinspection PyUnusedLocal
    include_role_0 = IncludeRole()
    # noinspection PyProtectedMember
    assert include_role_0._get_block_list()


# Generated at 2022-06-25 06:06:13.501922
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == None


# Generated at 2022-06-25 06:06:15.462379
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    display.display('TEST: test_IncludeRole_load')
    include_role = IncludeRole()
    include_role.load({})

# Generated at 2022-06-25 06:06:25.876531
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    my_task = IncludeRole()
    my_task.load(dict(role="a"))
    assert my_task.role == "a"
    assert my_task.get_name() == "include_role : a"
    assert my_task.allow_duplicates
    my_task.load(dict(role="b", allow_duplicates=False))
    assert not my_task.allow_duplicates
    assert my_task.args.get('role') == "b"
    assert my_task.role == "b"
    assert my_task.get_name() == "include_role : b"
    assert my_task.action == 'include_role'
    assert my_task.static
    assert my_task.delegate_to is None
    assert my_task.rolespec_validate

# Generated at 2022-06-25 06:06:29.118286
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_1 = IncludeRole()
    role_1 = Role()

    block_list_1 = include_role_1.get_block_list(role=role_1)


# Generated at 2022-06-25 06:06:36.179331
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_0 = IncludeRole()

# Generated at 2022-06-25 06:06:37.100371
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    #print("get_block_list")
    pass


# Generated at 2022-06-25 06:06:41.070942
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Variable initializations
    block = Block()
    role = Role()
    include = IncludeRole(block, role)

    play = None
    variable_manager = None
    loader = None

    # Validate if the block list is returned by the method get_block_list
    assert include.get_block_list(play, variable_manager, loader)


# Generated at 2022-06-25 06:06:44.003503
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    include_role_0 = IncludeRole()
    assert include_role_0.get_include_params() == {}
    role_0 = Role()
    include_role_1 = IncludeRole(role=role_0)
    assert include_role_1.get_include_params() == {u'ansible_parent_role_names': [u'default'],
                                                   u'ansible_parent_role_paths': [u'default']}

# Generated at 2022-06-25 06:06:48.944422
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Test for valid action
    for action in ['include_role', 'include_tasks']:
        include_role = IncludeRole()
        include_role.action = action
        with display.override_display(False):
            include_role.get_block_list()
    # Test for invalid action
    for action in ['task']:
        include_role = IncludeRole()
        include_role.action = action
        try:
            with display.override_display(False):
                assert include_role.get_block_list() == False
        except AnsibleError:
            pass



# Generated at 2022-06-25 06:06:50.900856
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()
    ir.get_block_list()

# Generated at 2022-06-25 06:06:55.165866
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # data to be used for IncludeRole.load test
    data = {
            "name": "myrole"
            }
    # run the IncludeRole.load test
    ir = IncludeRole(block=Block())
    result = ir.load(data, loader=None)
    #assert result is not None, "IncludeRole.load returned None"
    #assert type(result) is IncludeRole, "IncludeRole.load did not return an IncludeRole"
    assert result._role_name is not None, "IncludeRole.load did not set the _role_name"

# Generated at 2022-06-25 06:06:58.547362
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    result = include_role_0.get_name()
    assert(result == 'include_role')

# Generated at 2022-06-25 06:07:07.695528
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-25 06:07:17.341446
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'name': 'test'}
    task_include = None
    block = None
    role = None
    variable_manager = None
    loader = None
    include_role = IncludeRole.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert include_role.args == {'name': 'test'}
    assert include_role.name == None
    assert include_role._role_name == 'test'



# Generated at 2022-06-25 06:07:31.891332
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    vars = {'a': 'A'}
    args = {'name': 'test.role'}
    data = Block.load({'vars': vars, 'args': args}, task_include=True)
    include_role = IncludeRole(block=data)

    assert include_role.get_name() == "include_role : test.role"

# Generated at 2022-06-25 06:07:35.987826
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Should return a list with the block
    include_role = IncludeRole()
    include_role.statically_loaded = False
    block = Block()
    block.statically_loaded = False
    play = object
    block_list, handler_list = include_role.get_block_list(play=play)
    assert block_list == block._entries

# Generated at 2022-06-25 06:07:36.560971
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()

# Generated at 2022-06-25 06:07:47.316232
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    input_data = "{'action': 'include_role', 'attributes': {'rolespec_validate': False, 'apply': {'var1': 'val1', 'var2': 'val2'}, 'tasks_from': '/path/to/role/tasks/main.yml', 'name': 'test_role', 'allow_duplicates': False, 'public': True}, 'block': None, '_line_number': 26, 'original_block': None, 'role': None}"
    result = IncludeRole.load(input_data)
    assert result._rolespec_validate is False
    assert result.args['rolespec_validate'] is False
    assert result.apply == {'var1': 'val1', 'var2': 'val2'}

# Generated at 2022-06-25 06:07:51.660135
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    # Actual call
    result = include_role_0.get_name()
    assert result is None
    # FIXME: Failing test
    # expected_result = None
    # assert result == expected_result


# Generated at 2022-06-25 06:07:55.759933
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Set up test data
    role = IncludeRole()

    # Call method to test
    result = role.get_name()

    # Verify results
    assert result == 'tasks'


# Generated at 2022-06-25 06:08:00.757902
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    assert include_role_0.get_name() == "%s : %s" % (None, None)


# Generated at 2022-06-25 06:08:05.600106
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """
        This tests that get_block_list function of IncludeRole class
        throws a value error on passing invalid values
    """

    test_obj = IncludeRole()
    try:
        test_obj.get_block_list(play=None, variable_manager=None, loader=None)
    except Exception as e:
        if isinstance(e, ValueError):
            return True
    return False


# Generated at 2022-06-25 06:08:11.010500
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Get an instance of the IncludeRole class
    include_role_2 = IncludeRole()
    # Call the get_block_list method of the IncludeRole object
    try:
        include_role_2.get_block_list()
    except AnsibleParserError as ex:
        if 'missing 1 required positional argument' in str(ex):
            passed = True
        else:
            passed = False
    assert passed == True
    # Return the results
    return passed


# Generated at 2022-06-25 06:08:14.656607
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    play = Play()
    variable_manager = VariableManager()
    try:
        block_list = include_role_0.get_block_list(play, variable_manager)
    except Exception:
        block_list = None
    assert block_list is None


# Generated at 2022-06-25 06:08:31.001504
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {u'block': None, u'role': None, u'include_role': {u'name': u'myrolename'}}
    # assert AnsibleParserError

# Generated at 2022-06-25 06:08:39.353104
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    task0 = dict(
        name='test_role_0',
        action='include_role',
        args=dict(
            name='test_role_0',
            public=dict(
                var0=0
            ),
            apply=dict(
                a='b'
            )
        )
    )
    include_role_0 = IncludeRole.load(data=task0, role=None)
    assert include_role_0.action == 'include_role'
    assert include_role_0.name == 'test_role_0'
    assert include_role_0._role_name == 'test_role_0'
    assert include_role_0._from_files == dict()
    assert include_role_0.public == dict(
        var0=0
    )
    assert include_role_0.apply

# Generated at 2022-06-25 06:08:45.932359
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # NOTE: this test only tests the "happy path" of the method get_block_list.
    #       The other code paths are already tested through the tests for RoleInclude
    #       and Role.
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.constants import DEFAULT_DEBUG

    options = dict(
        connection='smart',
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        verbosity=DEFAULT_DEBUG,
        start_at_task=None,
    )
    loader = DataLoader()
    variable

# Generated at 2022-06-25 06:08:55.282835
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from collections import namedtuple
    from ansible.playbook.role.include import IncludeRole
    from copy import deepcopy
    in_dat = {'name': 'myrole', 'allow_duplicates': True}

# Generated at 2022-06-25 06:09:04.502090
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    test_include_role_0 = IncludeRole()
    test_data_0 = {"name": "myrole"}
    test_block_0 = Block()
    test_role_0 = Role()
    test_variable_manager_0 = VariableManager()
    test_loader_0 = None
    test_include_role_0.load(test_data_0, test_block_0, test_role_0, variable_manager=test_variable_manager_0, loader=test_loader_0)

    test_include_role_1 = IncludeRole()
    test_data_1 = {"name": "myrole"}
    test_block_1 = Block()
    test_role_1 = Role()
    test_variable_manager_1 = VariableManager()
    test_loader_1 = None

# Generated at 2022-06-25 06:09:06.541230
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    # put any test code here
    pass


# Generated at 2022-06-25 06:09:15.432085
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    loader = DummyLoader()
    play_file = AnsibleFile("/tmp/playbook", loader=loader)
    play = DummyPlay(play_file)
    play.hosts = 'host1'
    include_role = IncludeRole(play=play)

# Generated at 2022-06-25 06:09:16.289587
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    pass

# Generated at 2022-06-25 06:09:24.100750
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole()

# Generated at 2022-06-25 06:09:34.325664
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Return an AnsibleParserError with message ‘Invalid options for include_role: foo’
    # since ‘foo’ is not in VALID_ARGS
    with pytest.raises(AnsibleParserError) as exec_info:
        include_role = IncludeRole.load(dict(args=dict(foo=1)))
    assert 'Invalid options for include_role: foo' in str(exec_info.value)

    # Return an AnsibleParserError with message ‘Invalid options for include_tasks: public’
    # since ‘public’ is not valid for ‘include_tasks’
    with pytest.raises(AnsibleParserError) as exec_info:
        include_role = IncludeRole.load(dict(action='include_tasks', args=dict(public=True)))

# Generated at 2022-06-25 06:10:04.390872
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    ir = IncludeRole()
    ir._role_name = 'Set Root password'
    ir._role_path = '/home/prateek/workspace/ansible-playbook-project/ansible-playbook/include_role_test.yml'
    ir._parent_role = 'ansible-role-root-password'
    ir._metadata.allow_duplicates = True
    ir.statically_loaded = True
    ir.vars = {'validation_period': '1h',
               'validation_begin': '00:00',
               'validation_end': '00:00'}
    ir.public = False

# Generated at 2022-06-25 06:10:06.354432
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    """Tests that get_block_list method of class IncludeRole works correctly"""
    # Define a test IncludeRole object.
    include_role = IncludeRole()

    # Test that get_block_list method works correctly.
    include_role.get_block_list()

# Generated at 2022-06-25 06:10:11.276021
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test args should pass
    test_args = [
        {'name': 'test-role'},
        {'tasks_from': '', 'vars_from': '', 'defaults_from': '', 'handlers_from': ''},
        {'public': True},
        {'allow_duplicates': True},
        {'allow_duplicates': False},
        {'rolespec_validate': True},
        {'rolespec_validate': False},
        {'apply': {}}
    ]
    for arg in test_args:
        include_role = IncludeRole.load(arg)


# Generated at 2022-06-25 06:10:16.228505
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    include_role_0 = IncludeRole()
    print(include_role_0.get_block_list())

if __name__ == '__main__':
    test_case_0()
    test_IncludeRole_get_block_list()

# Generated at 2022-06-25 06:10:24.038121
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:10:26.961561
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {'action': 'include_role', 'name': 'my_role'}
    include_role_load_0 = IncludeRole.load(data)
    assert type(include_role_load_0) == IncludeRole


# Generated at 2022-06-25 06:10:35.027636
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # test if we load static role
    role_include = {'name': 'test_include_role'}
    include_role_0 = IncludeRole.load(data=role_include)
    assert include_role_0._role_name == "test_include_role"
    assert include_role_0.public is False
    assert include_role_0.allow_duplicates is True
    
    # test if we load dynamic role
    role_include = {'name': '{{ test_role }}'}
    include_role_0 = IncludeRole.load(data=role_include)
    assert include_role_0._role_name == "{{ test_role }}"
    assert include_role_0.public is False
    assert include_role_0.allow_duplicates is True
    # test if we load dynamic role with

# Generated at 2022-06-25 06:10:39.293830
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    # Create a instance of class IncludeRole
    include_role_obj = IncludeRole()

    # Create instance of class Block
    block_obj = Block()
    # Create an instance of class Role
    role_obj = Role()
    # Create an instance of class Play
    play_obj = Play()

    # Call to method get_block_list of class IncludeRole
    include_role_obj.get_block_list(block=block_obj, role=role_obj, play=play_obj)

# Generated at 2022-06-25 06:10:40.678441
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    i = IncludeRole()
    i.get_block_list()

# Generated at 2022-06-25 06:10:50.712890
# Unit test for method load of class IncludeRole

# Generated at 2022-06-25 06:11:19.385812
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_1 = IncludeRole()
    assert include_role_1.get_name()


# Generated at 2022-06-25 06:11:22.643591
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():

    block = Block()
    role = Role()

    include_role = IncludeRole(block, role)

    play = None
    variable_manager =None
    loader = None

    include_role.get_block_list(play, variable_manager, loader)

    return

# Generated at 2022-06-25 06:11:31.245857
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = dict(
        name = 'testrole'
    )

    roled = IncludeRole.load(data)

    assert roled.name == 'testrole'
    assert roled._role_name == 'testrole'

    data = dict(
        role = 'testrole'
    )

    roled = IncludeRole.load(data)

    assert roled.name == 'include_role'
    assert roled._role_name == 'testrole'

    data = dict(
        name = 'testrole',
        tasks_from = 'tasks.yml'
    )

    try:
        roled = IncludeRole.load(data)
    except AnsibleParserError as e:
        assert "Invalid options for include_role: tasks_from" in str(e)


# Generated at 2022-06-25 06:11:34.622557
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    include_role_0 = IncludeRole()
    result = include_role_0.get_name()
    assert result is None


# Generated at 2022-06-25 06:11:38.741523
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    _include_role_loader_data = dict(
            name=u'common',
            apply=dict(
                    set_fact=dict(
                            company_name=dict(
                                    value=u'Ansible, Inc.'))))
    _include_role_data = dict(
        include_role=_include_role_loader_data
    )
    print(IncludeRole.load(data=_include_role_data))

# Generated at 2022-06-25 06:11:49.321965
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Check attributes are correctly set
    yaml_snippet = {"name": "include_role_0", "include_role": {"name": "role_0"}}

    variable_manager = "variable_manager"
    loader = "loader"
    include_role_0 = IncludeRole.load(yaml_snippet, variable_manager=variable_manager, loader=loader)

    assert include_role_0.action == "include_role"
    assert include_role_0._role_name == "role_0"
    assert include_role_0.variable_manager == "variable_manager"
    assert include_role_0.loader == "loader"

    # Check attributes are correctly set

# Generated at 2022-06-25 06:11:51.884691
# Unit test for method get_block_list of class IncludeRole

# Generated at 2022-06-25 06:11:59.509289
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    include_role = IncludeRole()

    # load_data
    # arguments not passing with assertRaises(AnsibleParserError):
    # include_role.load_data(data={}, variable_manager=None, loader=None)
    # include_role.load_data(data=dict(action='include_role', name='my_role'), variable_manager=None, loader=None)
    # include_role.load_data(data=dict(action='include_role'), variable_manager=None, loader=None)

    # load
    # arguments not passing with assertRaises(AnsibleParserError)
    # IncludeRole.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    # IncludeRole.load(

# Generated at 2022-06-25 06:12:06.304101
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    include_role = IncludeRole()

    my_data = dict(
        name="test",
        tasks_from="path/to/main.yml"
    )
    include_role.load(my_data)

    assert include_role._role_name == "test"
    assert include_role._from_files == dict(tasks="main.yml")


# Generated at 2022-06-25 06:12:15.975796
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    import os
    import shutil
    import tempfile

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import load_plugins
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create temporary directory and create a role inside it
    tempdir = tempfile.gettempdir()
    tempdir = tempdir + "/temp123"
    os.makedirs(tempdir)
    tempdir = tempdir + "/testrole"
    os.makedirs(tempdir)
    tempdir = tempdir + "/tasks"
    os.makedirs(tempdir)

    # Add a task file

# Generated at 2022-06-25 06:14:36.774399
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    m = IncludeRole()
    display.vvvv = True
    # load(self, data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
    display.display('''
TEST: data = {
  'allow_duplicates': False,
  'apply': {},
  'name': 'my_role',
  'tasks_from': 'main.yml',
  'handlers_from': 'main.yml',
  'vars_from': 'vars/main.yml',
  'defaults_from': 'defaults/main.yml',
  'public': False,
}''')

# Generated at 2022-06-25 06:14:41.523332
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None

    include_role_load = IncludeRole.load(data={"_role_name":"apache", "vars": {"myrvar": "hello"}, "tasks_from": "myrole/tasks/main.yml",
                                   "apply": {"tags": "mytag"}, "rolespec_validate": True, "collections": [],
                                   "allow_duplicates": True}, block=block, role=role, task_include=task_include,
                                    variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 06:14:46.513521
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    data = {}
    variable_manager = None
    loader = None
    block = None
    role = None
    task_include = None
    # First call to IncludeRole.load
    test_case_0(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-25 06:14:57.435308
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    #tasks = [{'include_role': 'name=hardening'}, {'include_role': 'name=common'}, {'include_role': 'name=ansible_galaxy_info_adhoc.yml'}]
    tasks = [{'include_role': 'name=hardening'}]
    roles = {}
    include_role_0 = IncludeRole()
    ansible_task_0 = include_role_0.load(tasks[0], variable_manager=None, loader=None)
    '''
    TaskInclude.load() will first call IncludeRole.load()
    It will then add the attribute __ansible_task_include_dynamic_vars
    which is the return value of IncludeRole.__ansible_task_include_dynamic_vars()
    '''
    assert ansible_

# Generated at 2022-06-25 06:15:07.031969
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role = IncludeRole();
    data = {'name' : 'test_name', 'role' : 'test_role', 'public' : 'test_public', 'allow_duplicates' : 'test_allow_duplicates', 'rolespec_validate' : 'test_rolespec_validate', 'apply' : {}}
    include_role.load(data, loader=None, variable_manager=None)
    assert include_role._role_name == 'test_role'
    assert include_role._from_files == {}
    assert include_role._allow_duplicates == False
    assert include_role._public == False
    assert include_role._rolespec_validate == False

# Generated at 2022-06-25 06:15:16.467778
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    include_role_1 = IncludeRole()
    block_1 = Block()
    role_1 = Role()
    task_include_1 = TaskInclude()
    variable_manager_1 = None
    loader_1 = None
    # Insert only possible value of data
    data_1 = "variable"
    # Call method IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    test_case_1_actual_return = include_role_1.load(data_1, block_1, role_1, task_include_1, variable_manager_1, loader_1)


# Generated at 2022-06-25 06:15:25.785189
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Setup
    display.verbosity = 1

    # Data
    data = dict(
        name='my_role_name',
        tasks_from='my_task_file.yml',
        vars_from='my_vars_file.yml',
        defaults_from='my_defaults_file.yml',
        handlers_from='my_handlers_file.yml',
        apply=dict(
            ignore_errors=True,
        ),
        public=True,
        allow_duplicates=True,
        rolespec_validate=False,
    )

    # Exercise
    include_role_0 = IncludeRole.load(
        data,
        block=Block(),
        role=Role()
    )

    # Verify
    assert include_role_0.statically_loaded is None

# Generated at 2022-06-25 06:15:29.322678
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    block = Block()
    role = Role()
    task_include = TaskInclude()

    assert IncludeRole.load(data={'foo': 'bar'}, block=block, role=role, task_include=task_include)

# Generated at 2022-06-25 06:15:32.590528
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    display.display("Test test_IncludeRole_get_block_list is started")
    include_role_0 = IncludeRole(role="role_0")
    display.success("Test test_IncludeRole_get_block_list is succeed")

if __name__ == '__main__':
    test_case_0()
    test_IncludeRole_get_block_list()