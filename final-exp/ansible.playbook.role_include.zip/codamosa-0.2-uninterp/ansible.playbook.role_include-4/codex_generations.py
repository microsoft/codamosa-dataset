

# Generated at 2022-06-17 08:07:21.647226
# Unit test for method load of class IncludeRole

# Generated at 2022-06-17 08:07:33.164522
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import find_plugin
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_loader

    # load plugins
    add_all_plugin_dirs()
    get_all_plugin_loaders()

    # load inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

    # load play context
    variable_manager

# Generated at 2022-06-17 08:07:40.548988
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:07:49.728631
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:07:59.532676
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    # Test with invalid options
    data = dict(
        name="test_role",
        invalid_option="invalid_value",
    )
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = None
    loader = None
    try:
        IncludeRole.load(data, block, role, task_include, variable_manager, loader)
    except AnsibleParserError as e:
        assert 'Invalid options for include_role: invalid_option' in str(e)

    # Test with valid options

# Generated at 2022-06-17 08:08:09.005391
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 08:08:21.707721
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.errors import AnsibleParserError
    from ansible.utils.display import Display
    from ansible.module_utils.six import string

# Generated at 2022-06-17 08:08:33.463606
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import TaskInclude

# Generated at 2022-06-17 08:08:42.410006
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import cache_loader


# Generated at 2022-06-17 08:08:50.113235
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars

    class TestCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.host_ok = {}

# Generated at 2022-06-17 08:09:04.292131
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_bytes

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

# Generated at 2022-06-17 08:09:18.078400
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 08:09:30.986844
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
   

# Generated at 2022-06-17 08:09:42.077164
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.task_include import TaskInclude

# Generated at 2022-06-17 08:09:51.257839
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():

    # Test with invalid options
    data = dict(
        name='test_role',
        invalid_option='test_value'
    )
    try:
        IncludeRole.load(data)
    except AnsibleParserError as e:
        assert 'Invalid options for include_role: invalid_option' in str(e)

    # Test with valid options
    data = dict(
        name='test_role',
        tasks_from='test_tasks_file',
        vars_from='test_vars_file',
        defaults_from='test_defaults_file',
        handlers_from='test_handlers_file',
        apply=dict(
            test_key='test_value'
        ),
        public=True,
        allow_duplicates=True,
        rolespec_validate=True
    )
   

# Generated at 2022-06-17 08:09:59.418935
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:10:09.622634
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test case 1
    # Test with name and action
    ir = IncludeRole()
    ir.name = "test_name"
    ir.action = "test_action"
    assert ir.get_name() == "test_name : test_action"

    # Test case 2
    # Test with name
    ir = IncludeRole()
    ir.name = "test_name"
    assert ir.get_name() == "test_name"

    # Test case 3
    # Test with action
    ir = IncludeRole()
    ir.action = "test_action"
    assert ir.get_name() == "test_action"

    # Test case 4
    # Test with no name and action
    ir = IncludeRole()
    assert ir.get_name() == " : "

# Generated at 2022-06-17 08:10:19.983881
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_inventory(inventory)

    data = {'include_role': {'name': 'test_role'}}
    ir = IncludeRole.load(data, variable_manager=variable_manager, loader=loader)
    assert ir._role_name == 'test_role'
    assert ir.name == 'include_role : test_role'


# Generated at 2022-06-17 08:10:26.635466
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create a play
    play = Play.load(dict(
        name="Ansible Play",
        hosts=['localhost'],
        gather_facts='no',
        roles=[
            dict(
                name="test_role",
                tasks=[
                    dict(action=dict(module='debug', args=dict(msg='Hello World')))
                ]
            )
        ]
    ))

    # Create a variable manager
    variable_manager = VariableManager

# Generated at 2022-06-17 08:10:39.377801
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude

# Generated at 2022-06-17 08:11:05.270235
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:11:16.200216
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.template import Templar

# Generated at 2022-06-17 08:11:30.207962
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-17 08:11:39.171097
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.vars import Vars
    from ansible.playbook.role.defaults import Defaults
    from ansible.playbook.role.handlers import Handlers
    from ansible.playbook.role.meta import RoleMetadata
   

# Generated at 2022-06-17 08:11:51.821898
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'


# Generated at 2022-06-17 08:12:02.809153
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader


# Generated at 2022-06-17 08:12:14.642723
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    """
    Test method get_include_params of class IncludeRole
    """
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 08:12:21.063665
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()

# Generated at 2022-06-17 08:12:31.246060
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:12:43.209138
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.vars import Vars
    from ansible.playbook.role.defaults import Defaults
    from ansible.playbook.role.handlers import Handlers

# Generated at 2022-06-17 08:13:21.378996
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 08:13:33.775987
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'test'
    play_context.remote_addr = '127.0.0.1'

# Generated at 2022-06-17 08:13:44.315264
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'vagrant'
    play_context.become = False
    play_context.become_

# Generated at 2022-06-17 08:13:56.712806
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    # create a play
    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-17 08:14:03.355590
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(host_list='tests/inventory'))
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-17 08:14:10.544020
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'test'
    play_context.port = 22


# Generated at 2022-06-17 08:14:22.285447
# Unit test for method get_include_params of class IncludeRole
def test_IncludeRole_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import add_plugin_dirs
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader

# Generated at 2022-06-17 08:14:26.000769
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test_name'
    ir._role_name = 'test_role_name'
    assert ir.get_name() == 'test_name : test_role_name'
    ir.name = None
    assert ir.get_name() == 'include_role : test_role_name'


# Generated at 2022-06-17 08:14:29.585435
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test'
    assert ir.get_name() == 'test'
    ir.name = None
    ir.action = 'test'
    ir._role_name = 'test'
    assert ir.get_name() == 'test : test'

# Generated at 2022-06-17 08:14:39.193171
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.module_utils.six import string_types

    display = Display()
    loader

# Generated at 2022-06-17 08:15:56.781957
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:16:08.905296
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'vagrant'
    play_context.connection = 'ssh'

# Generated at 2022-06-17 08:16:20.582229
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-17 08:16:25.058848
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-17 08:16:32.430168
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    # Test with name
    ir = IncludeRole()
    ir.name = 'test_name'
    assert ir.get_name() == 'test_name'

    # Test with role_name
    ir = IncludeRole()
    ir._role_name = 'test_role_name'
    assert ir.get_name() == 'include_role : test_role_name'

    # Test with name and role_name
    ir = IncludeRole()
    ir.name = 'test_name'
    ir._role_name = 'test_role_name'
    assert ir.get_name() == 'test_name'


# Generated at 2022-06-17 08:16:42.384445
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars

# Generated at 2022-06-17 08:16:47.025437
# Unit test for method get_name of class IncludeRole
def test_IncludeRole_get_name():
    ir = IncludeRole()
    ir.name = 'test'
    ir._role_name = 'test'
    assert ir.get_name() == 'test : test'
    ir.name = None
    assert ir.get_name() == 'include_role : test'
    ir.name = 'test'
    ir._role_name = None
    assert ir.get_name() == 'test'
    ir.name = None
    assert ir.get_name() == 'include_role'

# Generated at 2022-06-17 08:16:53.914160
# Unit test for method get_block_list of class IncludeRole
def test_IncludeRole_get_block_list():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks

# Generated at 2022-06-17 08:17:02.708007
# Unit test for method load of class IncludeRole
def test_IncludeRole_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.become = False
    play_context.become_method = 'enable'
    play_context