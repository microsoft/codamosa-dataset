

# Generated at 2022-06-25 23:40:41.120218
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == True
    assert ImmutableList(1).__eq__(ImmutableList(1)) == True
    assert ImmutableList().__eq__(ImmutableList()) == True
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList(1, ImmutableList(2))) == False
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList()) == False
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList(2, ImmutableList(1, ImmutableList(3))))

# Generated at 2022-06-25 23:40:49.388320
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.filter(lambda x : False) == ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList()
    assert immutable_list_1.filter(lambda x : False) == ImmutableList()
    immutable_list_2 = ImmutableList.of(6)
    assert immutable_list_2.filter(lambda x : False) == ImmutableList()
    immutable_list_3 = ImmutableList.of(4, 5, 6)
    assert immutable_list_3.filter(lambda x : True) == ImmutableList.of(4, 5, 6)
    immutable_list_4 = ImmutableList.of(5, 2, 6, 2, 4)

# Generated at 2022-06-25 23:40:59.300344
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 4) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 1, 3).filter(lambda x: x == 1) == ImmutableList.of(1, 1)
    assert ImmutableList.of(1, 2, 1, 3).filter(lambda x: x == 4) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-25 23:41:02.210493
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of("a")
    value_0 = immutable_list_0.find(lambda x : x == "a")
    assert value_0 == "a"


# Generated at 2022-06-25 23:41:11.090805
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(None)
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList(None)
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList(None)
    immutable_list_7 = ImmutableList(None, immutable_list_6)
    immutable_list_8 = ImmutableList(immutable_list_1)
    immutable_list_9 = ImmutableList(immutable_list_1, immutable_list_7)
    immutable_list_10 = ImmutableList(immutable_list_8, immutable_list_7)

# Generated at 2022-06-25 23:41:13.888588
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:20.852999
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None, None, True)
    assert immutable_list_0.__eq__(True) == False
    immutable_list_1 = ImmutableList(3, None, False)
    assert immutable_list_0.__eq__(immutable_list_1) == False
    assert immutable_list_0.__eq__(immutable_list_0) == True
    immutable_list_2 = ImmutableList(False, immutable_list_0, True)
    assert immutable_list_0.__eq__(immutable_list_2) == False


# Generated at 2022-06-25 23:41:25.752726
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result = True
    for i in range(10):
        list_i = ImmutableList(i)
        for j in range(10):
            if list_i.find(lambda x: x == j) != i if j == i else None:
                result = False
                break
    assert(result)

# # Unit test for method reduce of class ImmutableList

# Generated at 2022-06-25 23:41:31.275530
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print('test_ImmutableList_find')
    immutable_list_0 = ImmutableList((4,))
    exception_raised = False
    try:
        immutable_list_0.find((lambda num: (num == 4)))
    except Exception:
        exception_raised = True
    
    assert (not exception_raised)
    print('test_ImmutableList_find done')
    

# Generated at 2022-06-25 23:41:41.197230
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(None, None, True)
    immutable_list_1 = ImmutableList((-1), None, True)
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_3 = ImmutableList.of(5, 6, 6, 3, 7, 8)
    immutable_list_4 = ImmutableList.empty()

    immutable_list_5 = immutable_list_0.filter(lambda x: x == 5)
    immutable_list_6 = immutable_list_1.filter(lambda x: x == 5)
    immutable_list_7 = immutable_list_2.filter(lambda x: x == 5)
    immutable_list_8 = immutable_list_3.filter(lambda x: x == 5)
    immutable_list_9

# Generated at 2022-06-25 23:41:51.118990
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_0 = immutable_list_0.filter(lambda x: x != 2)
    assert immutable_list_0 == ImmutableList.of(1, 3)


# Generated at 2022-06-25 23:41:56.277111
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.of(0)
    immutable_list_1 = immutable_list_1.filter((lambda x : (x >= 0)))
    assert immutable_list_1.head == 0
    assert immutable_list_1.tail is None
    assert immutable_list_1.is_empty is False


# Generated at 2022-06-25 23:42:06.815542
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList.empty())))
    test_list2 = ImmutableList.of(1, 2, 3, 4, 5)
    assert None == test_list.find(lambda x: x == 6)
    assert 2 == test_list.find(lambda x: x == 2)
    assert None == ImmutableList.empty().find(lambda x: x == 3)
    assert 3 == test_list2.find(lambda x: x == 3)


# Generated at 2022-06-25 23:42:18.324416
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda a: a < 2) is None
    assert ImmutableList.of(2).find(lambda a: a < 2) is None
    assert ImmutableList.of(1).find(lambda a: a < 2) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda a: a < 2) == 1
    assert ImmutableList.of(1, 3, 5, 7, 9, 11).find(lambda a: a > 10) == 11
    assert ImmutableList.of(1, 3, 5, 7, 9, 11).find(lambda a: a < 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda a: a > 5) == 6
    assert ImmutableList.of

# Generated at 2022-06-25 23:42:29.766204
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    # Unit test code for ImmutableList.find
    # if passed value is not equal to '1'
    # returns None

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(1)
    immutable_list_2 = ImmutableList.of(2)
    immutable_list_3 = ImmutableList.of(1, 2, 3)
    immutable_list_4 = ImmutableList.of(3, 4, 5)
    immutable_list_5 = ImmutableList.of(1, 3, 5)
    immutable_list_6 = immutable_list_5.unshift(0)

    def find_fn(x:int):
        if x == 1:
            return True
        return False

    ret_0 = immutable_list_0.find(find_fn)
    ret

# Generated at 2022-06-25 23:42:38.311218
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test 0
    # 1) Create new ImmutableList with elements [5, 3, 2, 1]
    # 2) Get first element that passed in fn
    # 3) Check getted result
    immutable_list_0 = ImmutableList.of(5, 3, 2, 4, 1)
    assert immutable_list_0.find(lambda x: x > 4) == 5

    # Test 1
    # 1) Create new ImmutableList with elements [5, 3, 2, 1]
    # 2) Get first element that passed in fn
    # 3) Check getted result
    immutable_list_1 = ImmutableList.of(5, 3, 2, 4, 1)
    assert immutable_list_1.find(lambda x: x == 3) == 3

    # Test 2
    # 1) Create new ImmutableList with elements [

# Generated at 2022-06-25 23:42:43.983282
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(12)
    immutable_list_1 = immutable_list_1.append(7)
    immutable_list_2 = ImmutableList()
    immutable_list_2 = immutable_list_2.append(12)
    immutable_list_1 = immutable_list_1.filter(lambda x: x != 7)
    assert immutable_list_1 == immutable_list_2


# Generated at 2022-06-25 23:42:53.595126
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    immutable_list_0 = ImmutableList()
    expected_immutable_list_0 = ImmutableList(is_empty=True)

    immutable_list_01 = ImmutableList.of(0, 1, 2, 3, 4)
    expected_immutable_list_01 = ImmutableList.of(1, 3)

    immutable_list_02 = ImmutableList.of(0, 1, 2, 3, 4)
    expected_immutable_list_02 = ImmutableList.of(0, 2, 4)

    # Act
    result_immutable_list_0 = immutable_list_0.filter(lambda x: True if x else False)
    result_immutable_list_01 = immutable_list_01.filter(lambda x: True if x % 2 else False)
    result_immutable_list

# Generated at 2022-06-25 23:42:57.726673
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, '3', True).filter(lambda x: x == True) == ImmutableList.of(True)
    assert ImmutableList.of('').filter(lambda x: x != '') == ImmutableList.of(True)


# Generated at 2022-06-25 23:43:03.889587
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) == None
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(32, ImmutableList(11)).find(lambda x: x == 11) == 11
    assert ImmutableList(32, ImmutableList(11)).find(lambda x: x == 32) == 32

# Generated at 2022-06-25 23:43:17.407974
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.find(lambda x: True) == None
    immutable_list_1 = ImmutableList(False,ImmutableList(True,None))
    assert immutable_list_1.find(lambda x: True) == False
    immutable_list_2 = ImmutableList(True,ImmutableList(0,ImmutableList(True,ImmutableList(1,ImmutableList(True,None)))))
    assert immutable_list_2.find(lambda x: True) == 0
    immutable_list_3 = ImmutableList(True,None)
    assert immutable_list_3.find(lambda x: True) == True

# Generated at 2022-06-25 23:43:24.635684
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = immutable_list_0.filter(lambda x : x > 3)
    assert immutable_list_1 == ImmutableList(is_empty=True)
    immutable_list_2 = ImmutableList.of(3, 5, 9, 11, 12, 15)
    immutable_list_3 = immutable_list_2.filter(lambda x : x > 8)
    assert immutable_list_3 == ImmutableList.of(9, 11, 12, 15)
    immutable_list_4 = ImmutableList.of(10, 18, 15, 12, 12, 1)
    immutable_list_5 = immutable_list_4.filter(lambda x : x > 12)
    assert immutable_list_5 == ImmutableList.of(18, 15)
    immutable_

# Generated at 2022-06-25 23:43:29.226809
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # test_case_0
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.filter(lambda arg_0: arg_0 > 2) == ImmutableList.empty()


# Generated at 2022-06-25 23:43:37.017237
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(99,98,97,96,95)
    immutable_list_1 = immutable_list_0.filter(lambda e: e < 99)
    assert isinstance(immutable_list_1, ImmutableList)
    assert immutable_list_1.head == 98
    assert immutable_list_1.tail.head == 97
    assert immutable_list_1.tail.tail.head == 96
    assert immutable_list_1.tail.tail.tail.head == 95
    assert immutable_list_1.tail.tail.tail.tail is None


# Generated at 2022-06-25 23:43:38.825600
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ImmutableList.filter() == True
    ImmutableList.filter() == False


# Generated at 2022-06-25 23:43:46.423903
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test for class ImmutableList
    # Test for find method
    assert ImmutableList.empty().find(lambda x: True) is None
    # Test for class ImmutableList
    # Test for find method
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) is 3
    # Test for class ImmutableList
    # Test for find method
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 2) is 3
    # Test for class ImmutableList
    # Test for find method
    assert ImmutableList.of(1).find(lambda x: x > 2) is None
    # Test for class ImmutableList
    # Test for find method
    assert ImmutableList.of(1, 2).find(lambda x: x > 2) is None
   

# Generated at 2022-06-25 23:43:49.519398
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4)
    boolean_0 = immutable_list_0.filter(lambda n: n > 5) is None
    assert boolean_0


# Generated at 2022-06-25 23:43:58.239389
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test 1
    immutable_list_1 = ImmutableList.of(3,4,5)
    immutable_list_1_filtered = immutable_list_1.filter(lambda x: x > 4)
    assert immutable_list_1_filtered.head == 5

    # Test 2
    immutable_list_2 = ImmutableList.of(3,4,5)
    immutable_list_2_filtered = immutable_list_2.filter(lambda x: x > 4)
    assert immutable_list_2_filtered.tail.head == 4


# Generated at 2022-06-25 23:44:04.563997
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    fn = lambda x: x == 5
    # When
    immutable_list_0 = ImmutableList(5, ImmutableList(6, ImmutableList(7)))
    # Then
    try:
        result_0 = immutable_list_0.find(fn)
        # Then
        assert result_0 == 5
    except AssertionError:
        raise AssertionError('test_ImmutableList_find() failed')
    print('test_ImmutableList_find() passed')


# Generated at 2022-06-25 23:44:11.742358
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(9)
    assert immutable_list_0.find(lambda x : x > 8) == 9
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_1.find(lambda x : x > 8) is None
    immutable_list_2 = ImmutableList.of('90x')
    assert immutable_list_2.find(lambda x : x > 8) is None
    immutable_list_3 = ImmutableList.of(4)
    assert immutable_list_3.find(lambda x : x > 8) is None
    immutable_list_4 = ImmutableList.of(7, 't')
    assert immutable_list_4.find(lambda x : x > 8) is None

# Generated at 2022-06-25 23:44:28.923277
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1, ImmutableList(2))
    var_0 = immutable_list_0.find(lambda it: it > 2)
    var_1 = immutable_list_0.find(lambda it: it >= 2147483647)
    var_2 = immutable_list_0.find(lambda it: it == 0)
    var_3 = immutable_list_0.find(lambda it: it == 0)
    var_4 = immutable_list_0.find(lambda it: it == 1)
    var_5 = immutable_list_0.find(lambda it: it < 1)
    assert var_0 is None
    assert var_1 is None
    assert var_2 is None
    assert var_3 is None
    assert var_4 == 1
    assert var_5 is None



# Generated at 2022-06-25 23:44:36.244680
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(True)
    immutable_list_2 = ImmutableList(False)
    immutable_list_3 = ImmutableList(-8035.727448372085)
    immutable_list_4 = ImmutableList(False, immutable_list_3)
    immutable_list_5 = ImmutableList(False)
    immutable_list_6 = ImmutableList(True, immutable_list_5)
    immutable_list_7 = ImmutableList(False)
    immutable_list_8 = ImmutableList(False, immutable_list_7)
    immutable_list_9 = ImmutableList(True, immutable_list_8)
    immutable_list_10 = ImmutableList(False)

# Generated at 2022-06-25 23:44:47.393062
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList.of(0, 1)
    if ((immutable_list_0.find(lambda x: (x == 5))) != None):
        raise RuntimeError("Expected None, but got " + str(immutable_list_0.find(lambda x: (x == 5))))
    else:
        print("find passed test 0")
    if ((immutable_list_1.find(lambda x: (x == 0))) != 0):
        raise RuntimeError("Expected 0, but got " + str(immutable_list_1.find(lambda x: (x == 0))))
    else:
        print("find passed test 1")

# Generated at 2022-06-25 23:44:50.304169
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    maybe_0 = ImmutableList.of(3, 5, 8)
    def lambda_0(val):
        return val > 5

    maybe_0 = maybe_0.filter(lambda_0)
    assert maybe_0.head == 8
    assert maybe_0.tail.head is None
    assert maybe_0.tail.tail is None


# Generated at 2022-06-25 23:44:55.968907
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1889,1770,1655)
    immutable_list_0.find(lambda x: (x >= 1770))
    immutable_list_1 = ImmutableList.of(145,1924)
    immutable_list_1.find(lambda x: (x < 1889))
    immutable_list_2 = ImmutableList.of(8,95)
    immutable_list_2.find(lambda x: (x > 1482))


# Generated at 2022-06-25 23:45:04.989044
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1.head = "a"
    immutable_list_1.tail = immutable_list_0
    immutable_list_1.is_empty = False
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = 3
    immutable_list_2.tail = immutable_list_1
    immutable_list_2.is_empty = False
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = immutable_list_1
    immutable_list_3.tail = immutable_list_2
    immutable_list_3.is_empty = False
    immutable_list_4 = ImmutableList()
    immutable_list_4.head = immutable_list_1
   

# Generated at 2022-06-25 23:45:15.575519
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # First test case
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = "dhf"
    immutable_list_0.tail = None
    immutable_list_0.is_empty = False
    lambda_0 = lambda immutable_list_0: immutable_list_0 == "dhf"
    immutable_list_0 = immutable_list_0.find(lambda_0)
    print(immutable_list_0)
    # Second test case
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = "dhf"
    immutable_list_0.tail = None
    immutable_list_0.is_empty = False
    lambda_0 = lambda immutable_list_0: immutable_list_0 == "hfdhf"
    immutable_list_0 = immutable

# Generated at 2022-06-25 23:45:22.366036
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)
    immutable_list_2 = ImmutableList(1)
    immutable_list_3 = ImmutableList(2)
    immutable_list_4 = ImmutableList(2)
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList(1)
    def fn_0(a0):
        return a0 > 1
    fn_1 = lambda x: fn_0(x)
    def fn_2(a0):
        return a0 >= 0
    fn_3 = lambda x: fn_2(x)
    def fn_4(a0):
        return a0 > 1
    fn_5 = lambda x: fn_4(x)

# Generated at 2022-06-25 23:45:28.233798
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of('a')
    immutable_list_0.find((lambda arg_0: arg_0 == 'a'))
    immutable_list_1 = ImmutableList.of('a')
    immutable_list_1.find((lambda arg_0: True))
    immutable_list_2 = ImmutableList.of('a')
    immutable_list_2.find((lambda arg_0: False))


# Generated at 2022-06-25 23:45:35.803188
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of("8", "O", "E", "P", "~", "H", "4", "x", "m", "E", "C", "]", "f", "q", "F", "B", "8", "j")
    immutable_list_0 = immutable_list_0.find((lambda item: item == 'P'))
    print(f'ImmutableList.find(immutable_list_0): {immutable_list_0}')


# Generated at 2022-06-25 23:45:55.475991
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = ImmutableList.of(90)
    immutable_list_0 = immutable_list_0.filter((lambda element_0 : element_0 == -40))
    immutable_list_0 = immutable_list_0.filter((lambda element_0 : element_0 > 0))
    immutable_list_0 = immutable_list_0.filter((lambda element_0 : element_0 == -68))
    immutable_list_0 = immutable_list_0.filter((lambda element_0 : element_0 == -8))
    immutable_list_0 = immutable_list_0.filter((lambda element_0 : element_0 == -8))
    immutable_list_0 = immutable_list_0.filter((lambda element_0 : element_0 < 0))
    immutable_list_

# Generated at 2022-06-25 23:45:58.400125
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1).filter(lambda x: True) == 1
    assert ImmutableList(False).filter(lambda x: True) == ImmutableList(is_empty=True)


# Generated at 2022-06-25 23:46:03.643959
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Test case for method filter of class ImmutableList.

    """
    immutable_list_0 = ImmutableList()
    immutable_list_0.append(0)
    immutable_list_0.append(1)
    immutable_list_0.append(2)
    immutable_list_0.append(3)
    immutable_list_0.append(4)
    immutable_list_0.append(5)
    immutable_list_0.append(6)
    immutable_list_0.append(7)
    immutable_list_0.append(8)
    immutable_list_0.append(9)
    immutable_list_0.append(10)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert immutable_list_1.head == 0

# Generated at 2022-06-25 23:46:06.124782
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert None is ImmutableList.empty().find(lambda x: x > 2)
    assert 5 is ImmutableList.of(2, 3, 5).find(lambda x: x > 2)
    assert 3 is ImmutableList.of(2, 3, 5).find(lambda x: x > 2 and x < 5)


# Generated at 2022-06-25 23:46:13.887293
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # We need to test empty list case
    immutable_list_0 = ImmutableList()
    immutable_list_0.filter(lambda x: x > 0)

    head_0 = 'immutable_list.head'
    tail_0 = 'immutable_list.tail'

    immutable_list_1 = ImmutableList(head_0)
    new_immutable_list = immutable_list_1.filter(lambda x: x > 0)

    assert new_immutable_list.head == head_0
    assert new_immutable_list.tail == None
    assert new_immutable_list.is_empty == False

    immutable_list_1 = ImmutableList(head_0, tail_0)
    new_immutable_list = immutable_list_1.filter(lambda x: x > 0)

    assert new_imm

# Generated at 2022-06-25 23:46:22.122238
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2)
    immutable_list_1 = immutable_list_0.filter(lambda x: x < 2)
    immutable_list_2 = immutable_list_0.filter(lambda x: x > 2)
    immutable_list_3 = immutable_list_1.filter(lambda x: x != 0)
    immutable_list_3 = immutable_list_3.filter(lambda x: x == 0)
    assert immutable_list_2 == ImmutableList.empty()
    assert immutable_list_1 == ImmutableList.of(0, 1)
    assert immutable_list_3 == ImmutableList.empty()



# Generated at 2022-06-25 23:46:29.042557
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(None).find(lambda item: True) == None
    assert ImmutableList(0).find(lambda item: True) == 0
    assert ImmutableList(1, ImmutableList(2, ImmutableList(None))).find(lambda item: not item) == None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(None))).find(lambda item: item) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(None))).find(lambda item: item == 2) == 2


# Generated at 2022-06-25 23:46:33.875608
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(0.0, 0.0)
    immutable_list_2 = ImmutableList.of(0.0, 0.0, 0.0, 0.0)
    immutable_list_3 = ImmutableList.of(39.84, 15.11)
    immutable_list_4 = ImmutableList.of(3.61, 4.71, 7.0, 8.79, 4.71, 1.79)
    immutable_list_5 = ImmutableList.of(-37.8, -46.0, -5.44, -84.89)
    immutable_list_6 = ImmutableList.of(-82.0, -19.57, -6.13, -93.18)
    immutable_list_7 = Immutable

# Generated at 2022-06-25 23:46:44.607009
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None)
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    immutable_list_3 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    immutable_list_4 = ImmutableList.of(4, 3, 2, 5, 2, 8, 9)
    immutable_list_5 = ImmutableList.of(4, 3, 2, 5, 2, 8, 9)
    immutable_list_6 = ImmutableList.of(4, 3, 2, 5, 2, 8, 9)

# Generated at 2022-06-25 23:46:49.283207
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    ret_1 = immutable_list_0.find(lambda x: x == 1)
    assert ret_1 == 1
    ret_2 = immutable_list_0.find(lambda x: x != 1 and x != 2 and x != 3)
    assert ret_2 is None


# Generated at 2022-06-25 23:47:12.587603
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(7, 4, 8, 4, 9)
    immutable_list_1 = immutable_list_0.filter(lambda x : x > 8)
    print('Test #0')
    print('Inputs: ', immutable_list_0, ' and', immutable_list_1)
    print('Output: ', immutable_list_0.filter(lambda x : x > 8))
    print('Expected: ImmutableList(9)')
    print('Test #1')
    print('Inputs: ', immutable_list_0, ' and', immutable_list_1)
    print('Output: ', immutable_list_0.filter(lambda x : x < 9))
    print('Expected: ImmutableList(7, 4, 8, 4)')
    print('Test #2')

# Generated at 2022-06-25 23:47:22.749093
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = immutable_list_0.filter(lambda x: x)
    assert immutable_list_1 is immutable_list_0
    assert immutable_list_1.is_empty
    assert immutable_list_1.head is None
    assert immutable_list_1.tail is None
    immutable_list_1 = immutable_list_0.filter(lambda x: True)
    assert immutable_list_1 is immutable_list_0
    assert immutable_list_1.is_empty
    assert immutable_list_1.head is None
    assert immutable_list_1.tail is None
    immutable_list_1 = immutable_list_0.filter(lambda x: False)
    assert immutable_list_1 is immutable_list_0
    assert immutable_

# Generated at 2022-06-25 23:47:28.053209
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList.of(42, True, -2.36)

    def is_positive(immutable_list_0):
        return immutable_list_0 >= 0

    immutable_list_0 = immutable_list_0.find(is_positive)
    # Test assertions
    assert immutable_list_0 == 42


# Generated at 2022-06-25 23:47:30.659336
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_0 = ImmutableList()

    value_0 = list_0.find(lambda x: False)

    assert value_0 is None


# Generated at 2022-06-25 23:47:34.274344
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    testlist = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert testlist.filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))


# Generated at 2022-06-25 23:47:42.810847
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(is_empty=True) == ImmutableList.empty()
    assert ImmutableList(42).filter(lambda x: x > 0) == ImmutableList(42)
    assert ImmutableList(42).filter(lambda x: x < 0) == ImmutableList(is_empty=True)
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 0) == ImmutableList(1, 2, 3)
    assert ImmutableList(1, 2, -3).filter(lambda x: x > 0) == ImmutableList(1, 2)
    assert ImmutableList(1, -2, 3).filter(lambda x: x > 0) == ImmutableList(1, 3)

# Generated at 2022-06-25 23:47:52.100781
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(5)
    immutable_list_3 = ImmutableList(is_empty=True)
    immutable_list_4 = ImmutableList(1, immutable_list_3)
    function_0 = lambda value_0 : value_0 > 5
    function_1 = lambda value_0 : value_0 < 1
    function_2 = lambda value_0 : value_0 > 0
    assert immutable_list_0.filter(function_0) == ImmutableList(is_empty=True)
    assert immutable_list_1.filter(function_0) == ImmutableList(is_empty=True)
    assert immutable_list_1.filter(function_2) == ImmutableList(1)

# Generated at 2022-06-25 23:48:00.560733
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(3)
    immutable_list_1 = ImmutableList(4, immutable_list_0)
    immutable_list_2 = ImmutableList(2, immutable_list_1)
    immutable_list_3 = ImmutableList(1, immutable_list_2)

    assert immutable_list_3.find(lambda x: x == 2) == 2
    assert immutable_list_3.find(lambda x: x == 3) == 3
    assert immutable_list_3.find(lambda x: x == 4) == 4
    assert immutable_list_3.find(lambda x: x == 5) == None


# Generated at 2022-06-25 23:48:11.078659
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('first', 'second', 'third')
    immutable_list_1 = immutable_list_0.filter((lambda x: (len(x) == 5)))
    assert immutable_list_1.to_list() == ['first', 'third']
    assert immutable_list_0.to_list() == ['first', 'second', 'third']

    immutable_list_2 = immutable_list_0.filter((lambda x: (len(x) == 6)))
    assert immutable_list_2.to_list() == ['second']
    assert immutable_list_0.to_list() == ['first', 'second', 'third']

    immutable_list_3 = immutable_list_0.filter((lambda x: (len(x) == 7)))
    assert immutable_list_3.is_empty
   

# Generated at 2022-06-25 23:48:18.333049
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    #execute test case 0
    test_case_0()
    # Assertion
    assert type(ImmutableList.find(None)) == None, 'AssertionError: Method find of class ImmutableList returned other value than None'
    # Test case 1
    #execute test case 1
    test_case_0()
    # Assertion
    assert immutable_list_0.find(None) == None, 'AssertionError: Method find of class ImmutableList returned other value than None'


# Generated at 2022-06-25 23:48:35.062161
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(((0,10),))
    fn_0 = lambda a: lambda b: a*b
    immutable_list_1 = immutable_list_0.filter(fn_0)
    assert isinstance(immutable_list_1, ImmutableList)


# Generated at 2022-06-25 23:48:39.027799
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1)
    immutable_list_1 = ImmutableList.of(2)
    fn_0 = lambda arg_0: arg_0
    fn_0 = lambda arg_0: arg_0
    fn_0 = lambda arg_0: arg_0
    return immutable_list_0.filter(fn_0)



# Generated at 2022-06-25 23:48:42.803267
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    fn_0 = lambda v: v
    fn_1 = lambda v, acc: acc
    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList.of('', '', '', '', '', '', '')
    assert immutable_list_1.find(fn_0) == ''
    assert immutable_list_0.find(fn_0) == 0
    assert immutable_list_0.reduce(fn_1, 0) == 0
    assert immutable_list_1.reduce(fn_1, '') == ''


# Generated at 2022-06-25 23:48:49.257979
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    int_0 = 17
    immutable_list_1 = immutable_list_0.filter(lambda x : x < int_0)
    assert immutable_list_1 == immutable_list_0
    immutable_list_2 = ImmutableList(is_empty=True)
    int_1 = 16
    immutable_list_3 = immutable_list_2.filter(lambda x : x > int_1)
    assert immutable_list_3 == immutable_list_2


# Generated at 2022-06-25 23:48:58.677947
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('', '', '', '')
    immutable_list_1 = immutable_list_0.filter((lambda it: (it == '')))
    assert immutable_list_1 == immutable_list_0
    immutable_list_2 = ImmutableList.of('R', '', '', 'V', 'u', '', 'V', '')
    immutable_list_3 = immutable_list_2.filter((lambda it: (it == '')))
    expected_0 = ImmutableList.of('', '', '', '')
    assert immutable_list_3 == expected_0
    immutable_list_4 = ImmutableList.of('', '', '', '')
    immutable_list_5 = immutable_list_4.filter((lambda it: (it == 'test')))
    immutable_list_

# Generated at 2022-06-25 23:49:07.438291
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create object of class ImmutableList with argument value
    immutable_list_0 = ImmutableList(2)

    # Create object of class ImmutableList with argument value
    immutable_list_1 = ImmutableList.of(
        1,
        2,
        3
    )

    # Method of class ImmutableList
    assert ImmutableList.empty().filter(lambda x: x < 5) == ImmutableList.empty()

    # Method of class ImmutableList
    assert immutable_list_0.filter(lambda x: x < 5) == ImmutableList.of(
        2
    )

    # Method of class ImmutableList
    assert immutable_list_1.filter(lambda x: x < 5) == ImmutableList.of(
        1,
        2,
        3
    )

    # Method of class ImmutableList


# Generated at 2022-06-25 23:49:12.499822
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 0, 2).filter(lambda x: x > 0) == ImmutableList.of(1, 2)
    assert ImmutableList.of(0).filter(lambda x: x > 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x > 0) == ImmutableList.empty()

# Generated at 2022-06-25 23:49:19.600596
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 7)
    immutable_list_1 = immutable_list_0.filter(
        lambda x: x % 2 != 0
    )
    assert immutable_list_1 == ImmutableList.of(1, 3, 5, 7)
    immutable_list_2 = immutable_list_0.filter(
        lambda x: x % 2 != 0
    ).filter(
        lambda x: x > 4
    )
    assert immutable_list_2 == ImmutableList.of(5, 7)



# Generated at 2022-06-25 23:49:22.174281
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    function_0 = lambda x: x > 5
    immutable_list_1 = immutable_list_0.filter(function_0)
    if immutable_list_1.head is not True:
        fail()


# Generated at 2022-06-25 23:49:31.397771
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test Case 0
    immutable_list_0 = ImmutableList()
    def fn_0(x: object) -> bool: return True
    immutable_list_0 = immutable_list_0.filter(fn_0)
    assert immutable_list_0.is_empty
    # Test Case 1
    immutable_list_2 = ImmutableList()
    immutable_list_2 = immutable_list_2.append(1)
    immutable_list_2 = immutable_list_2.append(2)
    immutable_list_2 = immutable_list_2.append(3)
    immutable_list_2 = immutable_list_2.append(4)
    immutable_list_2 = immutable_list_2.append(5)
    immutable_list_2 = immutable_list_2.append(6)

# Generated at 2022-06-25 23:49:55.616195
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    boolean_0 = immutable_list_0.filter((lambda val: (val >= 3))).find((lambda val: (val >= 3)))
    boolean_1 = immutable_list_0.filter((lambda val: (val >= 3))).find((lambda val: (val >= 3)))
    boolean_2 = immutable_list_0.filter((lambda val: (val >= 3))).find((lambda val: (val >= 3)))
    boolean_3 = immutable_list_0.filter((lambda val: (val >= 3))).find((lambda val: (val >= 1)))
    boolean_4 = immutable_list_0.filter((lambda val: (val >= 3))).find((lambda val: (val >= 1)))

    assert boolean_0 == 3

# Generated at 2022-06-25 23:50:00.853749
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # TEST CASE 0
    immutable_list_0 = ImmutableList()

    # TEST CASE 1
    immutable_list_1 = ImmutableList.of(67)

    # TEST CASE 2
    immutable_list_2 = ImmutableList.of(65, 67)

    # TEST CASE 3
    immutable_list_3 = ImmutableList.of(65, 67, 73)

    # TEST CASE 4
    immutable_list_4 = ImmutableList.of(65, 67, 73, 80)


# Generated at 2022-06-25 23:50:10.217821
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result = True
    immutable_list_0 = ImmutableList()

    immutable_list_1 = ImmutableList.of(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

    result = result and immutable_list_1.find(lambda element: True) == 0.0

    immutable_list_2 = ImmutableList.of(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0)

    result = result and immutable_list_2.find(lambda element: True) == 0.0


# Generated at 2022-06-25 23:50:19.527692
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1.3)
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 1.0)
    assert immutable_list_0.head == 1.3
    immutable_list_0 = immutable_list_0.filter(lambda x: x < 0.0)
    assert immutable_list_0.is_empty == True
    immutable_list_0 = immutable_list_0.filter(lambda x: x <= 0.0)
    assert immutable_list_0.is_empty == True
    immutable_list_0 = immutable_list_0.filter(lambda x: x >= 0.0)
    assert immutable_list_0.is_empty == True
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 1.0)

# Generated at 2022-06-25 23:50:23.982997
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    list1_filtered = ImmutableList.of(1, 3, 5, 7)

    assert list1.filter(lambda e: e % 2 == 1) == list1_filtered
