

# Generated at 2022-06-25 23:40:34.551793
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1

    immutable_list_2 = ImmutableList(1)
    assert not immutable_list_0 == immutable_list_2

    immutable_list_3 = ImmutableList(1, immutable_list_0)
    immutable_list_4 = ImmutableList(1, immutable_list_1)
    assert immutable_list_3 == immutable_list_4


# Generated at 2022-06-25 23:40:45.284719
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    test_ImmutableList___eq__.params = [
        ((ImmutableList(), ImmutableList()), True),
        ((ImmutableList(1), ImmutableList(1)), True),
        ((ImmutableList(1, ImmutableList(2)), ImmutableList(1, ImmutableList(2))), True),
        ((ImmutableList(), ImmutableList(1)), False),
        ((ImmutableList(1), ImmutableList(2)), False),
        ((ImmutableList(1, ImmutableList(2)), ImmutableList(2, ImmutableList(2))), False),
    ]

    for (param1, expected) in test_ImmutableList___eq__.params:
        got = param1[0].__eq__(param1[1])
        assert got == expected

    return 'test_ImmutableList___eq__ success!'



# Generated at 2022-06-25 23:40:48.972934
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_0.head = 'abc'
    immutable_list_1.head = 'abc'
    assert immutable_list_0.__eq__(immutable_list_1)


# Generated at 2022-06-25 23:40:58.836355
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    exception_list_0 = [None, None, None, None, None, None, None, None, True, None, None, None, None, None, None, None, None, None, None, None, None, None]
    exception_list_1 = [None, None, None, None, None, None, None, None, True, None, None, None, None, None, None, None, None, None, None, None, None, None]
    exception_list_2 = [None, None, None, None, None, None, None, None, True, None, None, None, None, None, None, None, None, None, None, None, None, None]

# Generated at 2022-06-25 23:41:09.901515
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create a new instance of class ImmutableList
    immutableList0 = ImmutableList()
    immutableList1 = ImmutableList()
    # Create a class "Callable[[Optional[T]], bool]" with a method "__call__"
    class Class0(object):
        def __call__(self, arg0):
            return False
    # Create an instance of class Class0
    class0 = Class0()
    # Call method "filter" of immutableList0 with argument class0
    assert immutableList0.filter(class0) == immutableList1

    # Create a new instance of class ImmutableList
    immutableList2 = ImmutableList()
    immutableList3 = ImmutableList()
    # Create a class "Callable[[Optional[T]], bool]" with a method "__call__"

# Generated at 2022-06-25 23:41:15.906985
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    var_0 = ImmutableList.of(1, 2, 3)

    var_1 = var_0.filter(lambda e: e > 2)
    var_2 = var_0.filter(lambda e: e == 3)
    var_3 = var_0.filter(lambda e: e == 0)

    assert var_1.to_list() == [3]
    assert var_2.to_list() == [3]
    assert var_3.to_list() == []


# Generated at 2022-06-25 23:41:18.240433
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:23.206246
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) is None
    assert ImmutableList(1).find(lambda x: True) == 1
    assert ImmutableList(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList(1, 2, 3).find(lambda x: x < 0) is None


if __name__ == '__main__':
    test_ImmutableList_find()

# Generated at 2022-06-25 23:41:30.769273
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(["", "A", "B", "C", "D"], ["E", "F", "G", "H", "I"], ["J", "K", "L", "M", "N"])
    var_0 = immutable_list_0.filter((lambda x: x.length == 2))
    assert var_0 == ImmutableList.of(["E", "F", "G", "H", "I"], ["J", "K", "L", "M", "N"])


# Generated at 2022-06-25 23:41:41.198680
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    def fn_1(var_0: int) -> bool:
        return var_0 % 2 == 0
    var_1 = immutable_list_0.filter(fn_1)
    assert len(var_1) == 2 and var_1.to_list() == [2, 4]
    def fn_2(var_0: int) -> bool:
        return var_0 == 1
    immutable_list_1 = immutable_list_0.filter(fn_2)
    assert len(immutable_list_1) == 1 and immutable_list_1.to_list() == [1]
    immutable_list_2 = ImmutableList.empty()
    def fn_3(var_0: int) -> bool:
        return var_

# Generated at 2022-06-25 23:41:45.105405
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda e: e == 1) == 1



# Generated at 2022-06-25 23:41:49.405878
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    f = lambda x: x < 5
    l = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    filtered_l = l.filter(f)

    assert filtered_l == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-25 23:41:58.391435
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert(immutable_list_0 == immutable_list_1)

    immutable_list_2 = ImmutableList.of(1)
    immutable_list_3 = ImmutableList.of(1)
    assert(immutable_list_2 == immutable_list_3)

    immutable_list_4 = ImmutableList.of(1, 3, 4, 5)
    immutable_list_5 = ImmutableList.of(1, 3, 4, 5)
    assert(immutable_list_4 == immutable_list_5)

    immutable_list_6 = ImmutableList.of(1, 4, 5)
    immutable_list_7 = ImmutableList.of(1, 3, 4, 5)

# Generated at 2022-06-25 23:42:08.495206
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    list_1 = list_0.filter(lambda x: x == 1)
    assert list_1.head == 1
    assert list_1.tail.head is None
    list_2 = list_0.filter(lambda x: x == 5)
    assert list_2.head == 5
    assert list_2.tail.head is None

    list_3 = list_0.filter(lambda x: x >= 3 and x <= 4)
    assert list_3.head == 3
    assert list_3.tail.head == 4
    assert list_3.tail.tail.head is None
    list_4 = list_0.filter(lambda x: x == 2 or x == 3 or x == 4 or x == 5)
    assert list_4

# Generated at 2022-06-25 23:42:13.897077
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    value_expected = ImmutableList.of(25, 50)

    def is_multiplied_by_25(value: int) -> bool:
        return value % 25 == 0

    value_actual0 = ImmutableList.of(25, 50).filter(is_multiplied_by_25)
    assert value_expected == value_actual0

    value_actual1 = ImmutableList.of(1, 25, 50, 100).filter(is_multiplied_by_25)
    assert value_expected == value_actual1

    value_expected = ImmutableList.empty()
    value_actual2 = ImmutableList.of(1, 3, 7).filter(is_multiplied_by_25)
    assert value_expected == value_actual2

    value_expected = ImmutableList.empty()
    value_actual3 = ImmutableList

# Generated at 2022-06-25 23:42:17.276195
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2).to_list() == [3, 4]


# Generated at 2022-06-25 23:42:28.961679
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Tests if method find works with empty list
    t_test_0 = ImmutableList.empty().find(
        lambda x: x == 1
    )

    assert t_test_0 is None, "empty list return None on find"

    # Tests if method find works with list with one element
    t_test_1 = ImmutableList(1).find(
        lambda x: x == 1
    )

    assert t_test_1 == 1, "one element list return itself if its equal to searched"

    # Tests if method find works with list with mulitple elements
    t_test_2 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9).find(
        lambda x: x == 5
    )


# Generated at 2022-06-25 23:42:37.667199
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    # Method is implemented
    assert hasattr(ImmutableList, "__eq__"), "Oops! It looks like you haven't implemented __eq__ method"
    
    # Unit test description: test1
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_1) == True, "Wrong implementation of method __eq__ of `ImmutableList`"
    
    # Unit test description: test2
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_1.__eq__(immutable_list_0) == True, "Wrong implementation of method __eq__ of `ImmutableList`"
    
    # Unit test description: test3
    immutable_

# Generated at 2022-06-25 23:42:43.762812
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0.append(4)
    immutable_list_0.append(3)
    immutable_list_0.append(2)
    immutable_list_0.append(1)
    immutable_list_0.append(0)
    def fn_0(arg_0: Optional[int]) -> bool:
        return arg_0 % 2 == 0

    immutable_list_1 = immutable_list_0.filter(fn_0)

    assert len(immutable_list_1) == 3


# Generated at 2022-06-25 23:42:46.449533
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1,2,3,4)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 2)
    assert immutabl

# Generated at 2022-06-25 23:43:01.135817
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(None, immutable_list_1)
    immutable_list_3 = ImmutableList(None, immutable_list_2)
    immutable_list_4 = ImmutableList(None, immutable_list_3)
    immutable_list_5 = ImmutableList(None, immutable_list_3)
    immutable_list_6 = ImmutableList(None, immutable_list_2)
    immutable_list_7 = ImmutableList(None, immutable_list_0)
    immutable_list_8 = ImmutableList(1)
    immutable_list_9 = ImmutableList(0, immutable_list_8)
    immutable_list_10 = ImmutableList(None, immutable_list_2)
   

# Generated at 2022-06-25 23:43:10.039315
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print("Unit test for method filter of class ImmutableList")
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    for i in range(10):
        immutable_list_0 = immutable_list_0.append(i)
        immutable_list_1 = immutable_list_1.append(i)
    immutable_list_1 = immutable_list_1.map(lambda item: item % 2 != 0)
    print("Unit test for method filter of class ImmutableList finished", end='\n\n')
    return immutable_list_0.filter(lambda item: item % 2 != 0) == immutable_list_1


# Generated at 2022-06-25 23:43:19.510842
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList()
    function_0 = lambda immutable_list_0: immutable_list_0.find(lambda x: x)
    assert_raise(TypeError, function_0, immutable_list_0)
    # Test case 1
    immutable_list_1 = ImmutableList()
    function_1 = lambda immutable_list_1: immutable_list_1.find(lambda x: x)
    assert_equal(None, function_1(immutable_list_1))
    # Test case 2
    immutable_list_2 = ImmutableList(False)
    def function_2(immutable_list_2):
        return immutable_list_2.find(lambda x: x)
    assert_equal(None, function_2(immutable_list_2))
    # Test case

# Generated at 2022-06-25 23:43:23.319170
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2)
    immutable_list_1 = immutable_list_0.filter((lambda x : (x > 0)))
    assert immutable_list_1 == ImmutableList.of(1, 2)


# Generated at 2022-06-25 23:43:29.329937
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda _: True) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

# Generated at 2022-06-25 23:43:39.478940
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    def test_fn(arg):
        return arg == 1
    immutable_list_0 = ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList())))
    immutable_list_1 = ImmutableList(1, ImmutableList())
    immutable_list_2 = ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList(1)))))
    immutable_list_3 = ImmutableList(1)
    immutable_list_4 = ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList(1))))))

# Generated at 2022-06-25 23:43:42.092900
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.filter(lambda t: t < 10) == ImmutableList(is_empty=True), "Should be equal"


# Generated at 2022-06-25 23:43:48.205472
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = ImmutableList.of(1, 2, 3)
    immutable_list_3 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_4 = ImmutableList.of(1, 2, 4)
    immutable_list_5 = ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    immutable_list_6 = ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    immutable_list_7 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(None)))))
    immutable_list_8 = ImmutableList(1)

# Generated at 2022-06-25 23:43:55.979086
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(2)
    immutable_list_1 = immutable_list_1.append(3)
    immutable_list_1 = immutable_list_1.append(4)
    immutable_list_1 = immutable_list_1.unshift(1)
    immutable_list_1 = immutable_list_1.filter(lambda x: x < 3)
    assert immutable_list_1.to_list() == [1, 2]


# Generated at 2022-06-25 23:44:00.688216
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(8)
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_0.find(lambda x: x > 5) == 8
    assert immutable_list_1.find(lambda x: x > 5) is None


# Generated at 2022-06-25 23:44:14.751634
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    try:
        immutable_list_0.find({})
    except Exception as instance:
        if type(instance) is TypeError:
            pass
        else:
            print('  Exception ', type(instance), ' unexpected.')


# Generated at 2022-06-25 23:44:25.255326
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case for passing list of maximum 4 elements
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter((lambda x: True))
    assert immutable_list_1 == ImmutableList()
    immutable_list_0 = ImmutableList(True, ImmutableList(True, ImmutableList(False), True))
    immutable_list_1 = immutable_list_0.filter((lambda x: True))
    assert immutable_list_1 == ImmutableList(True, ImmutableList(True, ImmutableList(False), True))
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.filter((lambda x: False))
    assert immutable_list_0 == ImmutableList(is_empty=True)

# Generated at 2022-06-25 23:44:26.816161
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(5, 10, 15, 20, 25, 30)
    immutable_list_0 = immutable_list_0.filter(lambda x : x % 2 == 0)
    assert immutable_list_0.to_list()==[10, 20, 30]


# Generated at 2022-06-25 23:44:27.832155
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_case_0()


# Generated at 2022-06-25 23:44:35.622010
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList()

    # Test case 1
    immutable_list_1 = ImmutableList(True)

    # Test case 2
    immutable_list_2 = ImmutableList(0)

    # Test case 3
    immutable_list_3 = ImmutableList(1)

    # Test case 4
    immutable_list_4 = ImmutableList(2)

    # Test case 5
    immutable_list_5 = ImmutableList(3)

    # Test case 6
    immutable_list_6 = ImmutableList(4)

    # Test case 7
    immutable_list_7 = ImmutableList(5)

    # Test case 8
    immutable_list_8 = ImmutableList(6)

    # Test case 9
    immutable_list_9 = ImmutableList(7)

   

# Generated at 2022-06-25 23:44:46.658289
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0_0 = ImmutableList(None)
    immutable_list_0_0_0 = ImmutableList(None, immutable_list_0_0, False)
    immutable_list_0_0_0_0 = ImmutableList(None, immutable_list_0_0_0, False)
    immutable_list_0_0_0_1 = ImmutableList(None, immutable_list_0_0_0, False)
    immutable_list_0_0_1 = ImmutableList(None, immutable_list_0_0_0_1, False)
    immutable_list_0_1 = ImmutableList(None, immutable_list_0_0_1)

# Generated at 2022-06-25 23:44:55.665640
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(1, 2, 3)
    immutable_list = immutable_list.filter(lambda x: x % 2 == 0)
    assert immutable_list == ImmutableList.of(2)

    immutable_list = ImmutableList.of(1, 2, 3)
    immutable_list = immutable_list.filter(lambda x: x % 2 == 0)
    assert immutable_list == ImmutableList.of(2)

    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list = immutable_list.filter(lambda x: x % 2 == 0)
    assert immutable_list == ImmutableList.of(2, 4)

    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-25 23:45:00.319671
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print("Testing ImmutableList find")
    def fn(x):
        if x > 0:
            return True
        return False
    head = [0, 1, 2, 3, 4]
    immutable_list_0 = ImmutableList.of(*head)
    immutable_list_1 = immutable_list_0.find(fn)
    if immutable_list_1 == 1:
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-25 23:45:10.461657
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(2)
    immutable_list_2 = ImmutableList(1, immutable_list_1)
    immutable_list_3 = ImmutableList.empty()
    immutable_list_4 = ImmutableList(2, immutable_list_1)
    immutable_list_5 = ImmutableList.of(3, immutable_list_4)
    immutable_list_6 = ImmutableList.of(2, 3, 4)
    immutable_list_7 = ImmutableList.of(1, 2, 3)
    immutable_list_8 = ImmutableList.of(1, 2)
    immutable_list_9 = ImmutableList.of(2, 3, 4)
    immutable_list_10 = ImmutableList.of(1, 2, 3)

# Generated at 2022-06-25 23:45:15.672183
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x>1) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x>100) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x<100) == 1

# Generated at 2022-06-25 23:45:40.321265
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # ImmutableList find tests
    list_0 = ImmutableList.of(0, 1, 2, 3, 4)
    find_0 = list_0.find(lambda x: x == 2)

    if find_0 != 2:
        raise Exception('TEST 0.0 FAILED')

    if list_0.find(lambda x: x == 10) is not None:
        raise Exception('TEST 0.1 FAILED')


# Generated at 2022-06-25 23:45:51.016865
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test when empty list
    immutable_list_0 = ImmutableList()
    if (immutable_list_0.find(lambda x: x % 2 == 0) is not None):
        print("Failed test_ImmutableList_find_0")
    else:
        print("Passed test_ImmutableList_find_0")
    # Test when empty list
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(1)
    if (immutable_list_1.find(lambda x: x % 2 == 0) is not None):
        print("Failed test_ImmutableList_find_1")
    else:
        print("Passed test_ImmutableList_find_1")
    # Test when empty list
    immutable_list_2 = ImmutableList()


# Generated at 2022-06-25 23:46:01.068215
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    with pytest.raises(ValueError):
        immutable_list_0 = ImmutableList()
        immutable_list_0.filter(lambda x: x == 0)
    with pytest.raises(ValueError):
        immutable_list_0 = ImmutableList(0)
        immutable_list_0.filter(lambda x: x == 0)
    with pytest.raises(ValueError):
        immutable_list_0 = ImmutableList(0, is_empty=True)
        immutable_list_0.filter(lambda x: x == 0)
    with pytest.raises(ValueError):
        immutable_list_0 = ImmutableList(0, is_empty=False)
        immutable_list_0.filter(lambda x: x == 0)
    with pytest.raises(ValueError):
        immutable_list_

# Generated at 2022-06-25 23:46:07.334327
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_1 = immutable_list_0.filter(lambda x: x)
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail.head == 2
    assert immutable_list_1.tail.tail.head == 3
    assert immutable_list_1.tail.tail.tail.head == 4
    assert immutable_list_1.tail.tail.tail.tail.head == 5
    assert immutable_list_1.tail.tail.tail.tail.tail is None


# Generated at 2022-06-25 23:46:16.364417
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList(
        "foo",
        ImmutableList(
            "bar",
            ImmutableList(
                "baz",
                ImmutableList(
                    "for",
                    ImmutableList(
                        "doo"
                    )
                )
            )
        )
    )
    assert immutable_list.filter(lambda x: len(x) > 3) == ImmutableList(
        "foo",
        ImmutableList(
            "bar",
            ImmutableList(
                "baz"
            )
        )
    )
    assert immutable_list.filter(lambda x: len(x) > 5) == ImmutableList(
        is_empty=True
    )

# Generated at 2022-06-25 23:46:18.322053
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # method find without argument
    immutable_list_0 = ImmutableList()

    immutable_list_0.find(lambda x: True)

# Generated at 2022-06-25 23:46:24.590749
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    # Test case 0
    immutable_list_0 = ImmutableList()

    assert immutable_list_0 is not ImmutableList()

    # Test case 1
    immutable_list_0 = ImmutableList(is_empty=True)

    assert immutable_list_0 is not ImmutableList(is_empty=True)

    # Test case 2
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)

    assert immutable_list_1 is not immutable_list_0


# Generated at 2022-06-25 23:46:35.046857
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # No exception should be raised for the scenario
    # where things should be equal
    assert (ImmutableList() == ImmutableList())
    # No exception should be raised for the scenario
    # where things should be equal
    assert (ImmutableList(None) == ImmutableList(None))
    # No exception should be raised for the scenario
    # where things should be equal
    assert (ImmutableList(1) == ImmutableList(1))
    # No exception should be raised for the scenario
    # where things should be equal
    assert (ImmutableList(1, ImmutableList()) == ImmutableList(1, ImmutableList()))
    # No exception should be raised for the scenario
    # where things should be equal
    assert (ImmutableList(None, ImmutableList()) == ImmutableList(None, ImmutableList()))
    # No exception should

# Generated at 2022-06-25 23:46:45.740993
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    If a filter predicate returns true or false,
    the ImmutableList.filter method should return new ImmutableList
    with only these elements, for which the filter returned True
    or an empty ImmutableList if the predicate returned false for each element
    """
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.filter(lambda num: num % 2 == 0) == ImmutableList.empty()

    immutable_list_1 = ImmutableList(is_empty=False)
    assert immutable_list_1.filter(lambda num: num % 2 == 0) == immutable_list_1

    immutable_list_2 = ImmutableList.of(1, 2, 3)
    filtered_immutable_list_2 = immutable_list_2.filter(lambda num: num % 2 == 0)
    assert filtered_imm

# Generated at 2022-06-25 23:46:50.548909
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2)
    immutable_list_0 = immutable_list_0.filter(is_greater_than_0)
    immutable_list_1 = ImmutableList.of(1, 2)
    immutable_list_1 = immutable_list_1.filter(is_greater_than_1)
    assert immutable_list_0 != immutable_list_1


# Generated at 2022-06-25 23:47:35.822443
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_0 = immutable_list_0.append(3)
    fn = lambda x: True
    result = immutable_list_0.find(fn)
    assert result == 1


# Generated at 2022-06-25 23:47:44.142770
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1, 2)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(1, ImmutableList(2)))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert Imm

# Generated at 2022-06-25 23:47:51.262969
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: x) == ImmutableList(1)
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 1) == ImmutableList(2, 3)
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 3) == ImmutableList(1, 2)
    assert ImmutableList(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList(2)


# Generated at 2022-06-25 23:47:57.541795
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)

    assert immutable_list_1 == ImmutableList.of(2, 4, 6, 8, 10)



# Generated at 2022-06-25 23:48:00.781729
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = immutable_list_1.filter(lambda x: True if x == 2 else False)
    list_1 = immutable_list_2.to_list()
    assert list_1 == [2]

# Generated at 2022-06-25 23:48:10.432227
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9, ImmutableList(10))))))))))
    assert test_list.find(lambda x: x > 1) == 2
    assert test_list.find(lambda x: x < 0) is None
    assert test_list.find(lambda x: x**2 < 10) == 3
    test_list2 = ImmutableList( None, ImmutableList(None, ImmutableList(0, None)))
    assert test_list2.find(lambda x: x is None) is None



# Generated at 2022-06-25 23:48:14.181302
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(None, None, None)

    ret_11 = immutable_list_0.find(lambda x: x>1)
    assert ret_11 == None



# Generated at 2022-06-25 23:48:20.394282
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    #assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2).to_list() == [2, 4]
    assert ImmutableList().filter(lambda x: x % 2).to_list() == []
    assert ImmutableList.of(1).filter(lambda x: x % 2).to_list() == [1]
    assert ImmutableList.of(1, 2).filter(lambda x: x % 2).to_list() == [2]


# Generated at 2022-06-25 23:48:28.878796
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test 0
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    # Test 1
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList.of(0)
    assert not immutable_list_2 == immutable_list_3
    # Test 2
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList.empty()
    assert immutable_list_4 == immutable_list_5
    # Test 3
    immutable_list_6 = ImmutableList()
    immutable_list_7 = ImmutableList.of(0)
    assert not immutable_list_6 == immutable_list_7
    # Test 4
    immutable_list_8 = ImmutableList

# Generated at 2022-06-25 23:48:38.052512
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create instance of class
    immutable_list_0 = ImmutableList(None, ImmutableList(1, ImmutableList(2), False), False)
    # Check that this instance can be passed into method filter of class ImmutableList
    assert isinstance(immutable_list_0, ImmutableList)
    # Call method filter of class ImmutableList with argument immutable_list_0(instance of ImmutableList) and None
    result_immutable_list_0 = immutable_list_0.filter(lambda x: x is not None)
    # Check that result is instance of ImmutableList
    assert isinstance(result_immutable_list_0, ImmutableList)
    # Check that result is instance of ImmutableList with value 1
    assert result_immutable_list_0.tail.head is 1
    # Check that result is instance of Immutable

# Generated at 2022-06-25 23:49:56.371484
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Case 0: is_empty = true
    # Expected result: find returns None
    assert ImmutableList().find(lambda x: x > 6) == None
    # Case 1: is_empty = false, tail = None
    # Expected result: find returns self.head that satisfies predicate
    assert ImmutableList(7).find(lambda x: x > 6) == 7
    # Case 2: is_empty = false, tail = ImmutableList
    # Expected result: find returns self.head that satisfies predicate
    assert ImmutableList(7, ImmutableList(8)).find(lambda x: x > 6) == 7
    # Case 3: is_empty = false, tail = ImmutableList
    # Expected result: find returns None
    assert ImmutableList(7, ImmutableList(8)).find(lambda x: x > 8) == None

# Generated at 2022-06-25 23:50:01.354169
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    print('Test method __eq__ of class ImmutableList')
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_1 == immutable_list_0
    immutable_list_2 = ImmutableList()
    assert immutable_list_0 == immutable_list_2
    assert immutable_list_2 == immutable_list_0
    immutable_list_3 = ImmutableList()
    assert immutable_list_1 == immutable_list_3
    assert immutable_list_3 == immutable_list_1
    immutable_list_4 = ImmutableList()
    assert immutable_list_2 == immutable_list_4
    assert immutable_list_4 == immutable_list_2
    immutable_list_5 = ImmutableList()


# Generated at 2022-06-25 23:50:04.059246
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1, 2, 3, 4, 5, 6, 7, 8, 9)
    assert immutable_list_0.find(lambda x: x == 2) == 2


# Generated at 2022-06-25 23:50:09.417497
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(True, True, False, True, True)
    try:
        retval_0 = immutable_list_0.find((lambda x : x))
        retval_1 = immutable_list_0.find((lambda x : not x))
        assert retval_0 == True
        assert retval_1 == False
    except Exception as e:
        print(e)


# Generated at 2022-06-25 23:50:17.894368
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    mapper = lambda x: x
    immutable_list = ImmutableList(0, ImmutableList(1, ImmutableList(2)))
    assert 2 == immutable_list.find(mapper)
    mapper = lambda x: x > 1
    assert 2 == immutable_list.find(mapper)
    mapper = lambda x: x > 3
    assert None == immutable_list.find(mapper)
    mapper = lambda x: x < -1
    assert None == immutable_list.find(mapper)
    mapper = lambda x: x > -1
    assert 0 == immutable_list.find(mapper)


# Generated at 2022-06-25 23:50:24.377394
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    on_empty_list_found = ImmutableList().find(lambda x: True)
    assert on_empty_list_found is None
    on_single_element_found = ImmutableList.of(1).find(lambda x: x == 1)
    assert on_single_element_found == 1
    on_many_elements_found = ImmutableList.of(1, 2, 3).find(lambda x: x == 2)
    assert on_many_elements_found == 2
