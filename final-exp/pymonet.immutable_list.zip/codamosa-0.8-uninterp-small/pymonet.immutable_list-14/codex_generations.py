

# Generated at 2022-06-25 23:40:35.168870
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert(immutable_list_0 == immutable_list_1)
    immutable_list_0 = ImmutableList('value')
    immutable_list_1 = ImmutableList('value')
    assert(immutable_list_0 == immutable_list_1)


# Generated at 2022-06-25 23:40:40.364807
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of("val_0", "val_1", "val_2")
    try:
        assert immutable_list_0.find(var_0=None) == "val_2"
    except AssertionError as e:
        raise AssertionError("ImmutableList.find failed") from e


# Generated at 2022-06-25 23:40:46.299488
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(
        2, 
        4, 
        6, 
        8
    )
    immutable_list_1 = immutable_list_0.filter(
        lambda x: x > 3
    )
    
    assert immutable_list_1 == ImmutableList(
        4, 
        ImmutableList(
            6, 
            ImmutableList(
                8
            )
        )
    )


# Generated at 2022-06-25 23:40:55.656974
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None, None, True)
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList(None, None, True)
    lst_0 = [immutable_list_1, immutable_list_2, immutable_list_3, immutable_list_4]
    lst_1 = [immutable_list_0, immutable_list_1, immutable_list_2, immutable_list_3]

# Generated at 2022-06-25 23:41:05.841603
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list = ImmutableList()
    immutable_list_0 = ImmutableList()
    if (immutable_list == immutable_list_0) != True:
        raise AssertionError()
    immutable_list = ImmutableList()
    immutable_list_0 = ImmutableList(False)
    if (immutable_list == immutable_list_0) != False:
        raise AssertionError()
    immutable_list = ImmutableList(False)
    immutable_list_0 = ImmutableList()
    if (immutable_list == immutable_list_0) != False:
        raise AssertionError()
    immutable_list = ImmutableList(False)
    immutable_list_0 = ImmutableList(True)
    if (immutable_list == immutable_list_0) != False:
        raise AssertionError()

# Generated at 2022-06-25 23:41:08.292250
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:15.326985
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ImmutableList.filter(ImmutableList.of(True), lambda x: bool(x)) == ImmutableList.of(True)
    ImmutableList.filter(ImmutableList.of(False), lambda x: bool(x)) == ImmutableList.empty()
    ImmutableList.filter(ImmutableList.of(True, True, False), lambda x: bool(x)) == ImmutableList.of(True, True)
    ImmutableList.filter(ImmutableList.of(True, False, False), lambda x: bool(x)) == ImmutableList.of(True)
    ImmutableList.filter(ImmutableList.empty(), lambda x: bool(x)) == ImmutableList.empty()


# Generated at 2022-06-25 23:41:18.935558
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 1)
    result_filter = immutable_list_0.filter(lambda i: i > 1)
    expected_filter = ImmutableList.of(2, 3)
    assert result_filter == expected_filter


# Generated at 2022-06-25 23:41:29.199484
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(1, ImmutableList(2))
    immutable_list_3 = ImmutableList(1, ImmutableList(2), True)
    immutable_list_4 = ImmutableList(1, ImmutableList(2))
    immutable_list_5 = ImmutableList(1, ImmutableList(3))
    immutable_list_6 = ImmutableList(1, ImmutableList(3, ImmutableList(4)))
    immutable_list_7 = ImmutableList(1, ImmutableList(3), True)
    immutable_list_8 = ImmutableList(1, ImmutableList(4))

    assert immutable_list_0 == immutable_list_0
    assert immutable_list_1 == immutable

# Generated at 2022-06-25 23:41:34.777208
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 != immutable_list_1


# Generated at 2022-06-25 23:41:41.097548
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    ImmutableList() == ImmutableList()


# Generated at 2022-06-25 23:41:51.363530
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(True, None)
    immutable_list_1 = ImmutableList(0, None)
    immutable_list_2 = ImmutableList(1, immutable_list_1)
    immutable_list_3 = ImmutableList(False, immutable_list_2)
    immutable_list_4 = ImmutableList(1, immutable_list_3)
    immutable_list_5 = ImmutableList(True, immutable_list_4)
    immutable_list_6 = ImmutableList(False, immutable_list_5)
    immutable_list_7 = ImmutableList(True, immutable_list_6)
    immutable_list_8 = ImmutableList(0, immutable_list_7)
    immutable_list_9 = ImmutableList(0, immutable_list_8)

# Generated at 2022-06-25 23:41:59.439178
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test cases
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(1)
    immutable_list_3 = ImmutableList(1, ImmutableList(2))
    immutable_list_3_copied = ImmutableList(1, ImmutableList(2))
    immutable_list_4 = ImmutableList(2, ImmutableList(1))
    immutable_list_5 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    immutable_list_6 = ImmutableList(1, ImmutableList(3, ImmutableList(3)))

    assert immutable_list_0 == immutable_list_0
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_0 != immutable_list_2

# Generated at 2022-06-25 23:42:11.280468
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_1.head = 0
    assert immutable_list_0 == immutable_list_1 
    immutable_list_1.head = 1
    assert immutable_list_0 != immutable_list_1 
    immutable_list_1.head = 0
    immutable_list_2.head = 0
    assert immutable_list_1 == immutable_list_2 
    immutable_list_2.head = 1
    assert immutable_list_1 != immutable_list_2 
    immutable_list_1.head = 0
    immutable_list_2.head = 0
    immutable_list_1.tail = immutable_list_0

# Generated at 2022-06-25 23:42:22.991129
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Case 0
    immutable_list_0 = ImmutableList(None, None, True)
    immutable_list_1 = ImmutableList(None, None, True)
    assert immutable_list_0 == immutable_list_1

    # Case 1
    immutable_list_0 = ImmutableList(None, None, True)
    immutable_list_1 = ImmutableList(None, None, False)
    assert immutable_list_0 != immutable_list_1

    # Case 2
    immutable_list_0 = ImmutableList(None, None, True)
    immutable_list_1 = ImmutableList(None, "", True)
    assert immutable_list_0 != immutable_list_1

    # Case 3
    immutable_list_0 = ImmutableList(True, None, False)

# Generated at 2022-06-25 23:42:34.013040
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert not (immutable_list_0 == None)
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList(None, immutable_list_1)
    immutable_list_3 = ImmutableList(None, immutable_list_2)
    immutable_list_4 = ImmutableList(None, immutable_list_1)
    immutable_list_5 = ImmutableList(immutable_list_1, immutable_list_0)
    immutable_list_6 = ImmutableList(None, immutable_list_5)
    immutable_list_7 = ImmutableList(immutable_list_4, immutable_list_2)

# Generated at 2022-06-25 23:42:39.711786
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.unshift(0)
    immutable_list_0 = immutable_list_0.unshift(0)
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    
    def fn_arg_0(x: Optional[int]) -> bool:
        return x % 2 == 0
    immutable_list_1 = immutable_list_0.filter(fn_arg_0)
    assert immutable_list_1.to_list() == [0, 0, 2]


# Generated at 2022-06-25 23:42:44.025570
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    try:
        # Local variable for test method ImmutableList::__eq__
        immutable_list_0 = ImmutableList()

        # Condition for test method ImmutableList::__eq__
        if immutable_list_0 == immutable_list_0:
            return True
        else:
            return False
    except Exception:
        return False


# Generated at 2022-06-25 23:42:53.640747
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert(immutable_list_0 == immutable_list_1)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    assert(immutable_list_0 == immutable_list_1)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = None
    assert(not (immutable_list_0 == immutable_list_1))
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.of('2')
    assert(not (immutable_list_0 == immutable_list_1))
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = Imm

# Generated at 2022-06-25 23:43:02.284582
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0 == immutable_list_1
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(None, None, False)
    assert not immutable_list_0 == immutable_list_1
    immutable_list_0 = ImmutableList(True, None, False)
    immutable_list_1 = ImmutableList(None, None, True)
    assert not immutable_list_0 == immutable_list_1
    immutable_list_0 = ImmutableList(3.14, None, False)
    immutable_list_1 = ImmutableList(3.14, None, False)
    assert immutable_list_0

# Generated at 2022-06-25 23:43:13.547246
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert test_list.find(lambda x: x < 1) == None
    assert test_list.find(lambda x: x > 6) == None
    assert test_list.find(lambda x: x == 4) == 4
    assert test_list.find(lambda x: x == 2) == 2
    assert test_list.find(lambda x: x == 6) == 6


test_ImmutableList_find()

# Generated at 2022-06-25 23:43:22.411514
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1

    immutable_list_2 = ImmutableList.of(4, 7, 3)
    immutable_list_3 = ImmutableList.of(4, 7, 3)
    assert immutable_list_2 == immutable_list_3

    immutable_list_4 = ImmutableList.of(5, immutable_list_2, immutable_list_0)
    immutable_list_5 = ImmutableList.of(5, immutable_list_3, immutable_list_1)
    assert immutable_list_4 == immutable_list_5

    immutable_list_6 = ImmutableList.of(6, immutable_list_4, immutable_list_1)
    immutable_list_7 = Immutable

# Generated at 2022-06-25 23:43:34.417124
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    immutable_list_0 = ImmutableList.of(3, 2, 1)
    # when
    immutable_list_1 = immutable_list_0.filter(lambda x: True )
    # then
    assert immutable_list_1._head == 3
    assert immutable_list_1._tail._head == 2
    assert immutable_list_1._tail._tail._head == 1
    # when
    immutable_list_2 = immutable_list_0.filter(lambda x: False )
    # then
    assert immutable_list_2._head is None
    # when
    immutable_list_3 = immutable_list_0.filter(lambda x: x == 2 )
    # then
    assert immutable_list_3._head == 2
    assert immutable_list_3._tail._head is None
    # when
    immutable

# Generated at 2022-06-25 23:43:43.458321
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(None)
    assert immutable_list_0.filter(lambda x: x == None) == ImmutableList.of(None)
    assert immutable_list_0.filter(lambda x: x is not None) == ImmutableList.empty()
    immutable_list_1 = ImmutableList.of(None, None)
    assert immutable_list_1.filter(lambda x: x == None) == ImmutableList.of(None, None)
    assert immutable_list_1.filter(lambda x: x is not None) == ImmutableList.empty()
    immutable_list_2 = ImmutableList.of(None, None, None)
    assert immutable_list_2.filter(lambda x: x == None) == ImmutableList.of(None, None, None)
    assert immutable_list_

# Generated at 2022-06-25 23:43:52.603899
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    number_0 = immutable_list_0.find(lambda x: x == "abcd")
    assert number_0 == None
    immutable_list_1 = ImmutableList.of(3)
    number_1 = immutable_list_1.find(lambda x: x == "abcd")
    assert number_1 == None
    immutable_list_2 = ImmutableList.of("abcd", "abcd", "abcd", "abcd", "abcd", "abcd")
    number_2 = immutable_list_2.find(lambda x: x == "abcd")
    assert number_2 == "abcd"
    immutable_list_3 = ImmutableList.of("abcd", "abcd", "abcd", "abcd", "abcd", "abcd")
   

# Generated at 2022-06-25 23:44:03.774943
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(10, 20, 30, 40)
    immutable_list_1 = immutable_list_0.filter(lambda value: value >= 30)
    assert immutable_list_1 == ImmutableList.of(30, 40)
    immutable_list_1 = immutable_list_0.filter(lambda value: value >= 30)
    assert immutable_list_1 == ImmutableList.of(30, 40)
    immutable_list_1 = immutable_list_0.filter(lambda value: value >= 30)
    assert immutable_list_1 == ImmutableList.of(30, 40)
    immutable_list_1 = immutable_list_0.filter(lambda value: value >= 30)
    assert immutable_list_1 == ImmutableList.of(30, 40)
    immutable_list_1 = immutable_

# Generated at 2022-06-25 23:44:09.719989
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    function_0 = lambda i, n : i + n
    function_1 = lambda n : n % 2 == 0
    function_2 = lambda i, n : function_0(i, n) + n
    function_3 = lambda n : n > 2

    assert immutable_list_0.filter(function_1).to_list() == [2,4]
    assert immutable_list_0.filter(function_3).to_list() == [3,4,5]

    # This is edge case when list is empty
    assert immutable_list_0.filter(function_3).unshift(6).to_list() == [6,3,4,5]



# Generated at 2022-06-25 23:44:13.276962
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of('a', 'b', 'c')
    immutable_list_1.filter(lambda x: x > 'b')


# Generated at 2022-06-25 23:44:23.725574
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    obj_0 = ImmutableList()
    obj_1 = ImmutableList()
    assert obj_0 == obj_1
    obj_1 = ImmutableList(head=1)
    assert False == (obj_0 == obj_1)
    obj_2 = ImmutableList(head=1)
    assert (obj_1 == obj_2) == (obj_1 == obj_1)
    obj_2 = ImmutableList(head=2)
    assert False == (obj_1 == obj_2)
    obj_1 = ImmutableList(tail=obj_2)
    assert False == (obj_1 == obj_0)
    obj_2 = ImmutableList(tail=obj_2)
    assert obj_1 == obj_2
    obj_0 = ImmutableList(head=0, tail=obj_0)
   

# Generated at 2022-06-25 23:44:33.064337
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(value=0)
    immutable_list_3 = ImmutableList(value=1)
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList(value=1)
    immutable_list_6 = ImmutableList(value=1)
    immutable_list_7 = ImmutableList(value=2)
    immutable_list_8 = ImmutableList(value=1)
    immutable_list_9 = ImmutableList(value=0)
    immutable_list_10 = ImmutableList(value=1)
    immutable_list_11 = ImmutableList(value=0)
    immutable_list_12 = ImmutableList(value=1)
    immutable_list_13 = ImmutableList(value=2)

# Generated at 2022-06-25 23:44:46.895875
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    # empty list

    immutable_list_0 = ImmutableList()

    # Before
    immutable_list_0.filter((lambda x: (x > (1))))
    
    # After


    # expected value
    expected_value = ImmutableList()
    # actual value
    actual_value = immutable_list_0
    
    # Test 
    assert actual_value == expected_value
    
            

# Generated at 2022-06-25 23:44:48.538769
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1).filter(lambda x: x == 1) == ImmutableList(1)


# Generated at 2022-06-25 23:44:51.543478
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Setup
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    # Assertion
    assert immutable_list.find(lambda x: x > 2) == 3



# Generated at 2022-06-25 23:44:54.930010
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert immutable_list.find(lambda x: x > 2) == 3
    assert immutable_list.find(lambda x: x < 0) == None


# Generated at 2022-06-25 23:44:57.485572
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(ImmutableList.empty(), ImmutableList.empty(), is_empty=True)
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:45:07.162274
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(True)
    immutable_list_2 = ImmutableList.of(False)
    immutable_list_3 = ImmutableList.of(True, False, False, True)
    immutable_list_4 = ImmutableList.of(False, True, True, False)
    immutable_list_5 = ImmutableList.of(True, False, True, False, True, False)
    immutable_list_6 = ImmutableList.of(False, True, False, True, False, True)

    assert immutable_list_0.filter(lambda x: x) == ImmutableList()
    assert immutable_list_1.filter(lambda x: x) == ImmutableList.of(True)

# Generated at 2022-06-25 23:45:13.417049
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Assume disabled before test
    assert ImmutableList.of(1).find(lambda x: x == 0) == None
    # Assume enabled before test
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(4, 2, 8).find(lambda x: x == 2) == 2
    assert ImmutableList.of(4, 2, 8).find(lambda x: x == 5) == None


# Generated at 2022-06-25 23:45:21.489883
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(3, 5, 7, 9)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 7)
    immutable_list_2 = immutable_list_1.filter(lambda x: x > 9)
    immutable_list_3 = immutable_list_2.filter(lambda x: x < 8)

    assert len(immutable_list_0) == 4 and immutable_list_0.to_list() == [3, 5, 7, 9]
    assert len(immutable_list_1) == 2 and immutable_list_1.to_list() == [7, 9]
    assert len(immutable_list_2) == 0 and immutable_list_2.to_list() == []
    assert len(immutable_list_3) == 0 and immutable

# Generated at 2022-06-25 23:45:32.716596
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = ImmutableList.of(4, 5, 6)
    immutable_list_3 = ImmutableList.of("1", "2", "3")
    immutable_list_4 = ImmutableList.of("4", "5", "6")
    immutable_list_5 = ImmutableList.of("4", "5")

    assert immutable_list_0 == immutable_list_1
    assert immutable_list_0 != immutable_list_2
    assert immutable_list_0 != immutable_list_3
    assert immutable_list_0 != immutable_list_4
    assert immutable_list_0 != immutable_list_5

    assert immutable_list_

# Generated at 2022-06-25 23:45:41.742083
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(0)
    immutable_list_2 = ImmutableList.of(0)
    immutable_list_3 = ImmutableList.of(0, 1)
    immutable_list_4 = ImmutableList.of(0, 1, 2)
    immutable_list_5 = ImmutableList.of(0, 0, 1, 2)
    immutable_list_6 = ImmutableList.of(0, 1, 2, 3)
    immutable_list_7 = ImmutableList.of(0, 1, 3)
    immutable_list_8 = ImmutableList.empty()
    immutable_list_9 = ImmutableList.empty()
    immutable_list_10 = ImmutableList.of(0, 1)

# Generated at 2022-06-25 23:45:51.728898
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1)
    immutable_list_0 = immutable_list_0.filter(is_odd)
    assert immutable_list_0 == ImmutableList(1)


# Generated at 2022-06-25 23:45:57.869983
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList.empty())))
    fn_0 = lambda arg_0: arg_0 == 2
    immutable_list_1 = immutable_list_0.filter(fn_0)
    fn_1 = lambda arg_0: arg_0 == 2
    immutable_list_2 = immutable_list_1.filter(fn_1)
    pass


# Generated at 2022-06-25 23:46:06.670478
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    mapper = lambda x: x

    # Single element list
    immutable_list_0 = ImmutableList.of(1)
    immutable_list_0_filtered = immutable_list_0.filter(lambda x: x == 1)
    immutable_list_0_filtered_other = immutable_list_0_filtered.map(mapper)
    assert len(immutable_list_0_filtered_other) == 1
    assert immutable_list_0_filtered_other.head == 1
    assert immutable_list_0_filtered.tail is None

    # Multiple elements list
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_1_filtered = immutable_list_1.filter(lambda x: x == 3)
    immutable_list_1_fil

# Generated at 2022-06-25 23:46:11.392265
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case where list is empty
    immutable_list_0 = ImmutableList.empty()

    assert(immutable_list_0.find(lambda x: x==1) is None)

    # Test case where list is not empty
    immutable_list_1 = ImmutableList.of(1)

    assert(immutable_list_1.find(lambda x: x==1) == 1)

    immutable_list_2 = ImmutableList.of(1, 2, 3)
    immutable_list_3 = immutable_list_2.append(4)

    assert(immutable_list_2.find(lambda x: x//2 == 0) == 2)
    assert(immutable_list_3.find(lambda x: x//2 == 0) == 2)


# Generated at 2022-06-25 23:46:21.028901
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print("Testing filter of class ImmutableList...", end='')

    if_even = lambda x: x % 2 == 0

    assert ImmutableList().filter(if_even) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(if_even) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(if_even) == ImmutableList(2)
    assert ImmutableList(2).filter(if_even) == ImmutableList(2)
    assert ImmutableList(1).filter(if_even) == ImmutableList.empty()

# Generated at 2022-06-25 23:46:30.373461
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
	# Arrange
	immutable_list_0 = ImmutableList(0)
	immutable_list_1 = ImmutableList(draw_random_int(), immutable_list_0)
	immutable_list_2 = ImmutableList(draw_random_int(), immutable_list_1)
	immutable_list_3 = ImmutableList(draw_random_int(), immutable_list_2)
	immutable_list_4 = ImmutableList(draw_random_int(), immutable_list_3)
	immutable_list_5 = ImmutableList(draw_random_int(), immutable_list_4)
	immutable_list_6 = ImmutableList(draw_random_int(), immutable_list_5)
	immutable_list_7 = ImmutableList(draw_random_int(), immutable_list_6)
	immutable_

# Generated at 2022-06-25 23:46:34.312360
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    
    # Object of class ImmutableList
    immutable_list_0 = ImmutableList(1, None)
    immutable_list_0 = immutable_list_1 = ImmutableList(2, immutable_list_0)
    immutable_list_0 = immutable_list_2 = ImmutableList(7, immutable_list_1)
    # Function object
    function_0 = lambda fn_arg_0 : fn_arg_0
    # Call operation
    immutable_list_0 = immutable_list_0.filter(function_0)
    # Check condition
    assert immutable_list_0 == ImmutableList.empty()

# Generated at 2022-06-25 23:46:42.466303
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert (immutable_list_0 == immutable_list_1) == True


# Generated at 2022-06-25 23:46:48.562443
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Empty case
    assert ImmutableList().find(lambda x: True) == None
    
    # Single element list
    immutable_list_0 = ImmutableList(1)
    assert immutable_list_0.find(lambda x: x == 1) == 1

    # Multi elements list
    immutable_list_1 = ImmutableList(2, ImmutableList(3), False)
    assert immutable_list_1.find(lambda x: x == 1) == None

    

# Generated at 2022-06-25 23:46:50.247237
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = immutable_list_0.filter(lambda x: x >= 0)
    expected = ImmutableList(0)
    actual = immutable_list_1
    assert actual == expected


# Generated at 2022-06-25 23:47:07.577827
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(3, 2, 5)
    int_0 = immutable_list_0.find(lambda el: True)
    int_1 = immutable_list_0.find(lambda el: False)
    immutable_list_1 = ImmutableList.of(2, 3, 3)
    int_2 = immutable_list_1.find(lambda el: True)
    immutable_list_2 = ImmutableList()
    int_3 = immutable_list_2.find(lambda el: True)
    assert 3 == int_0
    assert None == int_1
    assert 2 == int_2
    assert None == int_3


# Generated at 2022-06-25 23:47:13.866391
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_find_0 = ImmutableList.empty()
    immutable_list_find_1 = ImmutableList.of(5, 1, 4, 3, 2)
    immutable_list_find_2 = ImmutableList.of(4, 3, 2, 1, 2)
    immutable_list_find_3 = ImmutableList.of(3, 2, 1, 2, 3)
    immutable_list_find_4 = ImmutableList.of(2, 1, 2, 3, 4)
    immutable_list_find_5 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list_find_0.find(lambda el: True) == None
    assert immutable_list_find_1.find(lambda el: el == 1) == 1
    assert immutable_list_find_2.find

# Generated at 2022-06-25 23:47:23.741981
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_case_0_1 = ImmutableList.of(2, 3, 4, 5, 6, 7, 8)\
        .filter(lambda value: value > 5)
    assert test_case_0_1 == ImmutableList.of(6, 7, 8)

    test_case_0_2 = ImmutableList.of(2, 3, 4, 5, 6, 7, 8)\
        .filter(lambda value: value == 6)
    assert test_case_0_2 == ImmutableList.of(6)

    test_case_0_3 = ImmutableList.of(2, 3, 4, 5, 6, 7, 8)\
        .filter(lambda value: value == 1)
    assert test_case_0_3 == ImmutableList.empty()


# Generated at 2022-06-25 23:47:34.020994
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = ImmutableList.of("")
    assert immutable_list_0.find(lambda x: x == "") == ""
    immutable_list_1 = ImmutableList.of("hi")
    immutable_list_1 = immutable_list_1.append("")
    assert immutable_list_1.find(lambda x: x == "") == ""
    immutable_list_2 = ImmutableList.of("hi")
    immutable_list_2 = immutable_list_2.append("hi")
    assert immutable_list_2.find(lambda x: x == "") is None
    immutable_list_3 = ImmutableList.of("")
    immutable_list_3 = immutable_list_3.append("hi")

# Generated at 2022-06-25 23:47:36.716715
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(3, 4, 5, 6, 7, 10)\
    .filter(lambda x: x % 2 == 0)\
    == ImmutableList.of(4, 6, 10)


# Generated at 2022-06-25 23:47:39.390739
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    array = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    element = 3
    immutable_list_0 = ImmutableList.of(*array)
    immutable_list_1 = immutable_list_0.filter(lambda x: x == element)


# Generated at 2022-06-25 23:47:48.301926
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList(is_empty=True)
    immutable_list_3 = ImmutableList(is_empty=False)
    assert not (immutable_list_2 == immutable_list_3)
    immutable_list_4 = ImmutableList(is_empty=False)
    immutable_list_5 = ImmutableList(is_empty=False)
    assert immutable_list_4 == immutable_list_5
    immutable_list_5.tail = immutable_list_5
    assert immutable_list_5 == immutable_list_5

# Generated at 2022-06-25 23:47:59.050978
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = ImmutableList(42)
    immutable_list_2 = ImmutableList(False)
    immutable_list_3 = ImmutableList(None)
    immutable_list_4 = ImmutableList(42)
    immutable_list_5 = ImmutableList(False)
    immutable_list_6 = ImmutableList(None, immutable_list_3)
    immutable_list_7 = ImmutableList(42, immutable_list_4)
    immutable_list_8 = ImmutableList(False, immutable_list_5)
    immutable_list_9 = ImmutableList(None, immutable_list_3)
    immutable_list_10 = ImmutableList(42, immutable_list_4)

# Generated at 2022-06-25 23:48:10.327776
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()

    immutable_list_2 = ImmutableList(1)
    immutable_list_3 = ImmutableList(1)

    immutable_list_4 = ImmutableList(1, ImmutableList(2))
    immutable_list_5 = ImmutableList(1, ImmutableList(2))

    immutable_list_6 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    immutable_list_7 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert immutable_list_0 == immutable_list_1
    assert immutable_list_2 == immutable_list_3
    assert immutable_list_4 == immutable_list_5
    assert immutable_list_6 == immutable_list_7

# Generated at 2022-06-25 23:48:20.796610
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print("Test ImmutableList filter method")

    # Test case 0:
    print("\tTest case 0: filter empty ImmutableList")
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.filter(lambda a: False) == ImmutableList.empty(), "internal error on ImmutableList filter method (test case 0)"

    # Test case 1:
    print("\tTest case 1: filter non-empty ImmutableList")
    immutable_list_0 = ImmutableList.of(1,2,3,4,5,6)
    assert immutable_list_0.filter(lambda a: a > 3) == ImmutableList.of(4,5,6), "internal error on ImmutableList filter method (test case 1)"

    print("OK")
    print()


# Generated at 2022-06-25 23:48:44.049399
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_0_find = immutable_list_0.find(lambda x: x == 2)
    if immutable_list_0_find != 2:
        raise Exception('error: ImmutableList.find({}, lambda x: x == 2) = {} != 2'.format(
            immutable_list_0, immutable_list_0_find
        ))
    immutable_list_1 = ImmutableList.empty()
    immutable_list_1_find = immutable_list_1.find(lambda x: x == 2)

# Generated at 2022-06-25 23:48:54.499517
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    list_0 = immutable_list_0.to_list()
    immutable_list_3 = immutable_list_0.find(lambda x: x is None)
    assert immutable_list_3 is None
    immutable_list_3 = immutable_list_0.find(lambda x: x == list_0)
    assert immutable_list_3 is None
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    list_1 = immutable_list_0.to_list()
    immutable_list_3 = immutable_list_0.find(lambda x: x == list_1)
    assert immutable_list_3 is None
    immutable_list_3 = immutable_list_0.find(lambda x: x == 1)
    assert immutable_list

# Generated at 2022-06-25 23:48:58.842425
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(5)
    immutable_list_1 = immutable_list_0.filter(lambda element: element > 3)
    assert immutable_list_1.to_list() == [5]
    immutable_list_0 = ImmutableList.of(2)
    immutable_list_1 = immutable_list_0.filter(lambda element: element > 3)
    assert immutable_list_1.to_list() == []
    immutable_list_0 = ImmutableList.of(2)
    immutable_list_1 = immutable_list_0.filter(lambda element: element == 2)
    assert immutable_list_1.to_list() == [2]


# Generated at 2022-06-25 23:49:07.475997
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    #
    immutable_list_0 = ImmutableList(str, None)
    # assert immutable_list_0.find(lambda x: x % 2 == 0) == 0
    #
    # immutable_list_1 = ImmutableList(int, immutable_list_0)
    # assert immutable_list_1.find(lambda x: x % 2 == 0) == 0
    #
    # immutable_list_2 = ImmutableList(int, immutable_list_1)
    # assert immutable_list_2.find(lambda x: x % 2 == 0) == 2
    #
    # immutable_list_3 = ImmutableList(int, immutable_list_2)
    # assert immutable_list_3.find(lambda x: x % 2 == 0) == 2
    #
    # immutable_list_4 = ImmutableList(int

# Generated at 2022-06-25 23:49:17.815746
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of("aa")
    immutable_list_1 = ImmutableList.of("aa", "x", "aa")
    immutable_list_2 = ImmutableList.of("c", "b", "a")

# Generated at 2022-06-25 23:49:21.172730
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    
    # First argument of assertEqual should be the expected value
    # Second argument should be the value that is being tested
    assertEqual(ImmutableList(None, None, True), ImmutableList())
    assertEqual(ImmutableList(12, ImmutableList()), ImmutableList(12))
    assertEqual(ImmutableList(12, ImmutableList(13, ImmutableList())), ImmutableList(12, ImmutableList(13)))


# Generated at 2022-06-25 23:49:25.026140
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 8) == None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 5) == 5


# Generated at 2022-06-25 23:49:29.417213
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    res = immutable_list_0.find(lambda x: x * 2 == 2)
    assert res == 1

    immutable_list_1 = ImmutableList.of(False, 2)
    res = immutable_list_1.find(lambda x: not x)
    assert res == False


# Generated at 2022-06-25 23:49:33.214236
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(is_empty=True)

    obj_0 = immutable_list_0.find(lambda x: x == True)

    assert obj_0 is None


# Generated at 2022-06-25 23:49:38.289931
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    t = ImmutableList.of(1)
    t = t.append(2)
    t = t.append(3)
    t = t.append(4)
    t = t.append(6)
    t = t.filter(lambda x: x % 2 == 0)
    assert t == ImmutableList(2, ImmutableList(4, ImmutableList(6)))


# Generated at 2022-06-25 23:50:06.724778
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(None)
    assert immutable_list_0.find(lambda x: True) == None
    immutable_list_1 = ImmutableList.of(None, None)
    assert immutable_list_1.find(lambda x: True) == None
    immutable_list_2 = ImmutableList.of(None, None, None, None)
    assert immutable_list_2.find(lambda x: True) == None
    immutable_list_3 = ImmutableList.of(None, None, None, None, None)
    assert immutable_list_3.find(lambda x: True) == None
    immutable_list_4 = ImmutableList.of(None, None, None, None, None, None)
    assert immutable_list_4.find(lambda x: True) == None
    immutable_

# Generated at 2022-06-25 23:50:17.443814
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.find(lambda x: x == 0) == None

    immutable_list_1 = ImmutableList.of(34)
    assert immutable_list_1.find(lambda x: x == 0) == None
    assert immutable_list_1.find(lambda x: x == 34) == 34

    immutable_list_2 = ImmutableList.of(34, 23)
    assert immutable_list_2.find(lambda x: x == 0) == None
    assert immutable_list_2.find(lambda x: x == 23) == 23

    immutable_list_2 = ImmutableList.of(34, 23, -1)
    assert immutable_list_2.find(lambda x: x == 0) == None

# Generated at 2022-06-25 23:50:18.417135
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_case_0()

# Generated at 2022-06-25 23:50:23.779949
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_0.head = "head"
    immutable_list_0.tail = immutable_list_1

    assert immutable_list_0 == immutable_list_0
    assert immutable_list_1 == immutable_list_1
    assert immutable_list_0 != immutable_list_1
