

# Generated at 2022-06-25 23:40:33.243761
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0, 2, 4, 6, 8)

    result = immutable_list_0.find(lambda x: x == 8)
    assert result == 8


# Generated at 2022-06-25 23:40:44.026704
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None, is_empty=True)
    immutable_list_1 = ImmutableList(None, is_empty=True)
    assert immutable_list_0.__eq__(immutable_list_1) == True

    immutable_list_0 = ImmutableList(5)
    immutable_list_1 = ImmutableList(5)
    assert immutable_list_0.__eq__(immutable_list_1) == True

    immutable_list_0 = ImmutableList(5, ImmutableList(4))
    immutable_list_1 = ImmutableList(5, ImmutableList(4))
    assert immutable_list_0.__eq__(immutable_list_1) == True

    immutable_list_0 = ImmutableList(5)
    immutable_list_1 = ImmutableList()

# Generated at 2022-06-25 23:40:51.998631
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1, ImmutableList(3, ImmutableList(2)))
    assert immutable_list_0.filter(lambda x: x > 1) == ImmutableList(3, ImmutableList(2))
    assert immutable_list_0.filter(lambda x: True) == ImmutableList(1, ImmutableList(3, ImmutableList(2)))
    assert immutable_list_0.filter(lambda x: type(x) == int) == immutable_list_0
    assert immutable_list_0.filter(lambda x: x > 2) == ImmutableList(3)
    assert immutable_list_0.filter(lambda x: x < 4) == immutable_list_0
    assert immutable_list_0.filter(lambda x: x == 4) == ImmutableList(is_empty=True)
    immutable

# Generated at 2022-06-25 23:40:58.509550
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    immutable_list_0 = ImmutableList.of(None, None, None, None, None)
    immutable_list_1 = immutable_list_0.filter(bool)
    immutable_list_2 = immutable_list_1.filter(bool)
    immutable_list_3 = immutable_list_2.filter(bool)
    immutable_list_4 = immutable_list_3.filter(bool)
    immutable_list_5 = immutable_list_4.filter(bool)
    immutable_list_6 = immutable_list_5.filter(bool)
    immutable_list_7 = immutable_list_6.filter(bool)
    immutable_list_8 = immutable_list_7.filter(bool)
    immutable_list_9 = immutable_list_8.filter(bool)

# Generated at 2022-06-25 23:41:05.514371
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert_equals(ImmutableList().__eq__(ImmutableList()), True)
    assert_equals(ImmutableList(2).__eq__(ImmutableList(2)), True)
    assert_equals(ImmutableList(1, 2).__eq__(ImmutableList(1, 2)), True)
    assert_equals(ImmutableList(2).__eq__(ImmutableList(1)), False)
    assert_equals(ImmutableList(2).__eq__(ImmutableList(2, 2)), False)
    assert_equals(ImmutableList(1, 2).__eq__(ImmutableList(2)), False)
    assert_equals(ImmutableList(1, 2).__eq__(ImmutableList(2, 3)), False)


# Generated at 2022-06-25 23:41:13.362241
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_result = ImmutableList().find(lambda x: False)
    assert empty_result == None
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    expected_result_0 = 1
    actual_result_0 = immutable_list_0.find(lambda x: x % 2 == 0)
    assert actual_result_0 == expected_result_0
    immutable_list_1 = ImmutableList.of(11, 12, 13, 14, 15, 16, 17, 18)
    expected_result_1 = 13
    actual_result_1 = immutable_list_1.find(lambda x: x % 2 == 0)
    assert actual_result_1 == expected_result_1

# Generated at 2022-06-25 23:41:20.333259
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test 1:
    immutable_list_0 = ImmutableList()
    fn_0 = lambda x: x
    assert immutable_list_0.find(fn_0) == None
    
    # Test 2:
    immutable_list_1 = ImmutableList()
    fn_1 = lambda x: x
    assert immutable_list_1.find(fn_1) == None
    
    # Test 3:
    immutable_list_2 = ImmutableList()
    fn_2 = lambda x: x
    assert immutable_list_2.find(fn_2) == None
    


# Generated at 2022-06-25 23:41:24.500378
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1)
    immutable_list_1 = ImmutableList(0, immutable_list_0)
    immutable_list_2 = ImmutableList(None, immutable_list_1)
    assert immutable_list_2.find(lambda x: x == 0) == 0


# Generated at 2022-06-25 23:41:28.943096
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()

    immutable_list_1 = ImmutableList.of(4)
    immutable_list_2 = immutable_list_1.filter(lambda x: x < 5)
    immutable_list_3 = immutable_list_1.filter(lambda x: x > 5)


# Generated at 2022-06-25 23:41:37.612543
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(1, 2)
    immutable_list_1 = ImmutableList.of(1, 2)
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:47.033316
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print('Starting test_ImmutableList_find')
    immutable_list = ImmutableList.of(3, 2, 15)
    even_numbers_predicate = lambda x: x % 2 == 0
    found_even_number = immutable_list.find(even_numbers_predicate)
    assert found_even_number == 2
    print('Completed test_ImmutableList_find')


# Generated at 2022-06-25 23:41:56.444875
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # test with empty list
    assert ImmutableList().filter(lambda x: True).to_list() == []
    assert ImmutableList().filter(lambda x: False).to_list() == []

    # test with example
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 1).to_list() == [2, 3]
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 0).to_list() == [1, 2, 3]
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 2).to_list() == [1]
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 1).to_list() == []


# Generated at 2022-06-25 23:42:06.132886
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(None)
    immutable_list_0_expected_result = ImmutableList.empty()
    def lambda_0(elem: int) -> bool:
        return elem == 1
    immutable_list_0_result = immutable_list_0.filter(lambda_0)
    assert (immutable_list_0_result == immutable_list_0_expected_result)


# Generated at 2022-06-25 23:42:17.380784
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4)

    immutable_list_1 = immutable_list_0.filter(lambda x: x > 2)

    assert immutable_list_1.head == 3
    assert immutable_list_1.tail.head == 4
    assert immutable_list_1.tail.tail is None
    assert immutable_list_0.head == 0
    assert immutable_list_0.tail.head == 1
    assert immutable_list_0.tail.tail.head == 2
    assert immutable_list_0.tail.tail.tail.head == 3
    assert immutable_list_0.tail.tail.tail.tail.head == 4
    assert immutable_list_0.tail.tail.tail.tail.tail is None
    assert immutable_list_1.head == 3


# Generated at 2022-06-25 23:42:29.053621
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = immutable_list_0.filter((lambda x : (x & 1)))
    assert (immutable_list_1.tail == None)
    assert (immutable_list_1.head == None)
    assert (immutable_list_1.is_empty == True)
    immutable_list_2 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    immutable_list_3 = immutable_list_2.filter((lambda x : ((x & 1) == 0)))
    assert (immutable_list_3.tail.tail.tail.tail.tail.tail.tail.tail == None)

# Generated at 2022-06-25 23:42:37.741421
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    immutable_list_0 = ImmutableList()
    immutable_list_0.map(lambda x: isinstance(x, ImmutableList))
    immutable_list_0.filter(lambda x: isinstance(x, ImmutableList))
    immutable_list_0.reduce(lambda x, y: y.append(x), immutable_list_0)
    immutable_list_0.unshift(immutable_list_0)
    immutable_list_0.append(immutable_list_0)
    immutable_list_0 = immutable_list_0.__add__(immutable_list_0)
    immutable_list_0.append(immutable_list_0).filter(lambda x: isinstance(x, ImmutableList))

# Generated at 2022-06-25 23:42:44.247850
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1)
    immutable_list_1 = immutable_list_0.filter(lambda data : (data > 0))
    immutable_list_2 = immutable_list_0.filter(lambda data : (data == 0))
    immutable_list_3 = immutable_list_0.filter(lambda data : (data == 1))
    assert immutable_list_1 == ImmutableList.of(1)
    assert immutable_list_2 == ImmutableList.of(0)
    assert immutable_list_3 == ImmutableList.of(1)


# Generated at 2022-06-25 23:42:51.151200
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Coverage : 93 %
    immutable_list_0 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    immutable_list_1 = immutable_list_0.filter(lambda i: (i > 1))
    assert immutable_list_1.is_empty == False
    assert immutable_list_1.head == 2
    assert immutable_list_1.tail.is_empty == False
    assert immutable_list_1.tail.head == 3
    assert immutable_list_1.tail.tail == None


# Generated at 2022-06-25 23:43:00.831128
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList(0)
    immutable_list_2 = ImmutableList(0, immutable_list_0)
    immutable_list_3 = ImmutableList.empty()
    immutable_list_3 = immutable_list_3.append(1)
    immutable_list_3 = immutable_list_3.append(2)
    immutable_list_3 = immutable_list_3.append(3)
    immutable_list_3 = immutable_list_3.append(4)
    immutable_list_3 = immutable_list_3.append(5)
    immutable_list_3 = immutable_list_3.append(6)
    immutable_list_3 = immutable_list_3.append(7)
    immutable_list_3 = immutable_list_

# Generated at 2022-06-25 23:43:11.364617
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(2, 3, 0, 4)
    immutable_list_1 = ImmutableList.of(0, 1, 2, 3, 4)
    immutable_list_2 = ImmutableList.of(8, 0, 0, 7, 6, 5, 3)
    immutable_list_3 = ImmutableList.of(2, 3, 0, 4)
    immutable_list_4 = ImmutableList.of(8, 4, 0, 6)
    immutable_list_5 = ImmutableList.of(1, 8, 0, 7)
    immutable_list_6 = ImmutableList.of(9, 2, 0, 3)
    immutable_list_7 = ImmutableList.of(7, 0, 2, 8, 2, 3)

# Generated at 2022-06-25 23:43:29.723580
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list0 = ImmutableList()
    immutable_list_0 = ImmutableList.of(1)
    assert immutable_list_0.find(lambda x: x == 1) == 1
    assert immutable_list_0.find(lambda x: x == 2) == None

    immutable_list_1 = ImmutableList.of(1, 2, 3)
    assert immutable_list_1.find(lambda x: x == 1) == 1
    assert immutable_list_1.find(lambda x: x == 2) == 2
    assert immutable_list_1.find(lambda x: x == 3) == 3
    assert immutable_list_1.find(lambda x: x == 4) == None



# Generated at 2022-06-25 23:43:32.849927
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)

    assert immutable_list_0.filter(lambda a: a > 3).to_list() == [4]



# Generated at 2022-06-25 23:43:42.404401
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test 0
    immutable_list_0 = ImmutableList()
    condition_0 = (immutable_list_0.find(lambda x: x % 3 == 1) == None)
    # Test 1
    immutable_list_1 = ImmutableList(10)
    condition_1 = (immutable_list_1.find(lambda x: x % 2 == 0) == 10)
    # Test 2
    immutable_list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    condition_2 = (immutable_list_2.find(lambda x: x % 2 == 0) == 2)
    # Test 3
    immutable_list_3 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-25 23:43:48.373563
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    assert immutable_list_0.find(lambda x : x % 2 == 0) == 0
    assert immutable_list_0.find(lambda x : x > 5) == None
    immutable_list_1 = ImmutableList()
    assert immutable_list_1.find(lambda x : x % 2 == 0) == None
    immutable_list_2 = ImmutableList.of(0)
    assert immutable_list_2.find(lambda x : x % 2 == 0) == 0
    immutable_list_3 = ImmutableList.of(0, 1)
    assert immutable_list_3.find(lambda x : x % 2 == 0) == 0
    immutable_list_4 = ImmutableList.of(0, 1, 2)

# Generated at 2022-06-25 23:43:59.851416
# Unit test for method filter of class ImmutableList

# Generated at 2022-06-25 23:44:08.761933
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: True) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: False) == ImmutableList(is_empty=True)

# Generated at 2022-06-25 23:44:13.186145
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 3, 6)
    assert immutable_list_0.filter(lambda x: x % 2 == 0) == ImmutableList.of(6)
    assert immutable_list_0.filter(lambda x: x % 3 == 0) == ImmutableList.of(3)


# Generated at 2022-06-25 23:44:18.805452
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = immutable_list_0.filter(lambda x: x == 3)
    assert immutable_list_1 == ImmutableList.of(3)
    immutable_list_2 = immutable_list_0.filter(lambda x: x == 4)
    assert immutable_list_2 == ImmutableList.empty()

# Generated at 2022-06-25 23:44:29.056103
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 2)
    assert immutable_list_1 == ImmutableList(3)
    # Test case with empty immutable_list
    immutable_list_2 = ImmutableList().filter(lambda x: x > 2)
    assert immutable_list_2 == ImmutableList(is_empty=True)
    # Test case with Invalid argument
    invalid_immutable_list = ImmutableList.of(0, 1, 2, 3)
    try:
        invalid_immutable_list.filter('Hello World')
        assert False
    except TypeError:
        pass
    except:
        assert False


# Generated at 2022-06-25 23:44:36.316462
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter((lambda x : x >= 5))
    assert isinstance(immutable_list_1, ImmutableList)
    assert immutable_list_1.head == None
    assert immutable_list_1.tail == None
    assert immutable_list_1.is_empty == True
    immutable_list_2 = immutable_list_0.filter((lambda x : x < 0))
    assert isinstance(immutable_list_2, ImmutableList)
    assert immutable_list_2.head == None
    assert immutable_list_2.tail == None
    assert immutable_list_2.is_empty == True
    immutable_list_3 = immutable_list_0.filter((lambda x : x > 8))

# Generated at 2022-06-25 23:44:51.078769
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    mutable_list_0 = [1, 2, 3]
    immutable_list_0 = ImmutableList.of(
        1,
        2,
        3
    )
    predicate_lambda_0 = lambda x: x
    bool_0 = immutable_list_0.find(predicate_lambda_0)
    bool_1 = immutable_list_0.find(predicate_lambda_0)

    assert bool_0 == bool_1 == 1


# Generated at 2022-06-25 23:44:55.436322
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():


    # Testing filter with default arguments
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    filter_result = immutable_list.filter(lambda x: x < 3)
    expected_result = ImmutableList.of(1, 2)

    if filter_result != expected_result:
        return False

    return True


# Generated at 2022-06-25 23:45:01.107041
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(4).find(lambda x: (x % 2 == 0)) == 4
    assert ImmutableList(3).find(lambda x: (x % 2 == 0)) is None
    assert ImmutableList(2, ImmutableList(4, ImmutableList(6))).find(lambda x: (x % 2 == 0)) == 2
    assert ImmutableList(2, ImmutableList(4, ImmutableList(7))).find(lambda x: (x % 2 == 0)) == 2
    assert ImmutableList(3, ImmutableList(4, ImmutableList(7))).find(lambda x: (x % 2 == 0)) == 4
    assert ImmutableList(3, ImmutableList(5, ImmutableList(7))).find(lambda x: (x % 2 == 0)) is None


# Generated at 2022-06-25 23:45:11.360858
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    immutable_list_2 = ImmutableList.of(1, False, None, 3, True, 5)
    immutable_list_3 = ImmutableList.of(None, True, None, True, None)
    immutable_list_4 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    immutable_list_5 = ImmutableList.of(1, False, None, 3, True, 5)
    immutable_list_6 = ImmutableList.of(None, True, None, True, None)
    immutable_list_7 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    immutable_list_8 = Immutable

# Generated at 2022-06-25 23:45:20.477743
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    # Compare to expected result
    assert immutable_list_0.find(lambda x : x > 5) == None
    # Create object
    immutable_list_1 = ImmutableList.of(
        1,
        2,
        3
    )
    # Compare to expected result
    assert immutable_list_1.find(lambda x : x > 5) == None
    # Create object
    immutable_list_2 = ImmutableList.of(
        1,
        2,
        4
    )
    # Compare to expected result
    assert immutable_list_2.find(lambda x : x > 5) == None
    # Create object
    immutable_list_3 = ImmutableList.of(
        1,
        2,
        5
    )
    # Compare to expected result


# Generated at 2022-06-25 23:45:24.958136
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6)
    immutable_list_1 = immutable_list_0.filter(lambda v : v % 2 == 0)
    assert immutable_list_1 == ImmutableList.of(0, 2, 4, 6)


# Generated at 2022-06-25 23:45:35.086399
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)

    assert immutable_list_0.find(lambda x: x == 0) == 0
    assert immutable_list_0.find(lambda x: x == 1) is None

    immutable_list_1 = ImmutableList.of(1)

    assert immutable_list_1.find(lambda x: x == 0) is None
    assert immutable_list_1.find(lambda x: x == 1) == 1

    immutable_list_0_1 = ImmutableList.of(0, 1)

    assert immutable_list_0_1.find(lambda x: x == 0) == 0
    assert immutable_list_0_1.find(lambda x: x == 1) == 1


# Generated at 2022-06-25 23:45:37.538383
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: True) is ImmutableList()
    assert ImmutableList().filter(lambda x: False) is ImmutableList()


# Generated at 2022-06-25 23:45:42.777796
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.filter(lambda x: x)
    immutable_list_1 = ImmutableList()
    immutable_list_1.unshift("1")
    immutable_list_1.unshift("2")
    immutable_list_2 = immutable_list_1.filter(lambda x: x)
    assert(immutable_list_2 == ImmutableList("2", ImmutableList("1", ImmutableList())))


# Generated at 2022-06-25 23:45:50.678672
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) == None
    def filter_func(x):
        if x == 3:
            return True
        return False
    assert ImmutableList.of(5, 7, 3, 2, 1, 7, 8, 10).find(lambda x: True) == 5
    assert ImmutableList.of(5, 7, 3, 2, 1, 7, 8, 10).find(filter_func) == 3


# Generated at 2022-06-25 23:46:05.094703
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # assert (ImmutableList(is_empty = False).filter(lambda a: False) == )
    assert (ImmutableList().filter(lambda a: a < 5) == ImmutableList(is_empty = True))
    assert (ImmutableList(2, 3, 5).filter(lambda a: a < 5) == ImmutableList(2, 3))
    assert (ImmutableList(2, 3, 5).filter(lambda a: a % 2 == 0) == ImmutableList(2))
    assert (ImmutableList(2, 3, 5).filter(lambda a: True) == ImmutableList(2, 3, 5))


# Generated at 2022-06-25 23:46:06.272076
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty() == ImmutableList.empty().filter(lambda value: value < 10)


# Generated at 2022-06-25 23:46:08.030602
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.of(10, 20, 30, 40, 50)
    assert immutable_list.find(lambda x: x > 30) == 40


# Generated at 2022-06-25 23:46:12.990786
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(2, 3)
    immutable_list_1 = ImmutableList.empty()

    assert(immutable_list_0.find(lambda a: a == 2) == 2)
    assert(immutable_list_0.find(lambda a: a < 0) == None)
    assert(immutable_list_1.find(lambda a: a == 2) == None)


# Generated at 2022-06-25 23:46:22.677721
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test that ImmutableList filter actually filters elements
    def is_even(x):
        if x % 2 == 0:
            return True
        return False
    
    # Prepare list
    immutable_list_1 = ImmutableList.of(1, 4, 9, 16, 25, 36, 49, 64)
    expected_list = ImmutableList.of(4, 16, 36, 64)

    res = immutable_list_1.filter(is_even)

    assert expected_list == res
    
    # Test that ImmutableList filter returns new ImmutableList
    immutable_list_2 = ImmutableList.of(1, 2, 3)
    immutable_list_3 = immutable_list_2.filter(is_even)

    assert immutable_list_2 != immutable_list_3


# Generated at 2022-06-25 23:46:27.452794
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # arg 1:
    try:
        immutable_list_0 = ImmutableList()
    except Exception as e:
        print("An exception was raised: {}".format(e))
    # arg 2:
    try:
        immutable_list_0 = ImmutableList()
    except Exception as e:
        print("An exception was raised: {}".format(e))


# Generated at 2022-06-25 23:46:37.898057
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case 0:
    # result = ImmutableList.of()
    # expected = []
    # assertImmutableListEqual(result, expected)
    # Case 1:
    # result = ImmutableList.of(0, 1, 2, 3).filter(lambda x: x % 2 == 0)
    # expected = [2, 4]
    # assertImmutableListEqual(result, expected)


    # Case 0:
    result = ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda x: x % 2 == 0)
    expected = [2, 4, 6]
    assertImmutableListEqual(result, expected)

    # Case 1:
    result = ImmutableList.of(0, 1, 2, 3, 4).filter(lambda x: x == 3)
   

# Generated at 2022-06-25 23:46:48.131629
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None)
    immutable_list_2 = ImmutableList(0, None)
    immutable_list_3 = ImmutableList(0)
    immutable_list_4 = ImmutableList(0, ImmutableList(1))
    immutable_list_5 = ImmutableList(0, ImmutableList(1))
    immutable_list_6 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    immutable_list_7 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    immutable_list_8 = ImmutableList(0, ImmutableList(1))

# Generated at 2022-06-25 23:46:51.436642
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    # Arrange
    immutable_list_0 = ImmutableList([1, 2, 3, 4])

    # Act
    immutable_list_1 = immutable_list_0.find((lambda x: x % 2 == 1))

    # Assert
    assert immutable_list_1 == 1


# Generated at 2022-06-25 23:46:58.510870
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = immutable_list_0.filter(lambda x: False)
    immutable_list_2 = immutable_list_0.filter(lambda x: True)
    assert immutable_list_1.head == None
    assert immutable_list_2.head == 0
    # ImmutableList.filter(immutable_list_0, lambda p1: p1 < 0)
    # ImmutableList.filter(immutable_list_0, lambda p1: p1 > 0)



# Generated at 2022-06-25 23:47:22.747780
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def test_case_0():
        immutable_list_0 = ImmutableList()
        tuple_0 = immutable_list_0.filter((lambda x: x < 3))

        assert(tuple_0.is_empty == True)

    def test_case_1():
        immutable_list_0 = ImmutableList.of(2)
        immutable_list_1 = immutable_list_0.filter((lambda x: x < 3))

        assert(immutable_list_1.head == 2)

    def test_case_2():
        immutable_list_0 = ImmutableList.of(1, 2, 3)
        immutable_list_1 = immutable_list_0.filter((lambda x: x < 3))

        assert(immutable_list_1.head == 1)

    def test_case_3():
        immutable_

# Generated at 2022-06-25 23:47:33.052220
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Init test subject
    immutable_list_0 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))))
    # Call method filter on test subject with lambda as argument
    immutable_list_1 = immutable_list_0.filter(lambda x: True)
    # Init expected result
    immutable_list_2 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))))
    # Create assertion
    assert immutable_list_1 == immutable_list_2
    # Init test subject
    immutable_list_3 = ImmutableList(4, ImmutableList(4, ImmutableList(4, ImmutableList(4, ImmutableList(4)))))
    # Call method filter on test subject with lambda as

# Generated at 2022-06-25 23:47:41.820598
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print('Test ImmutableList find')
    immutable_list_0 = ImmutableList(6, ImmutableList.empty())
    immutable_list_1 = ImmutableList(10, ImmutableList(8, ImmutableList.empty()))
    immutable_list_2 = ImmutableList(0, ImmutableList(10, ImmutableList.empty()))
    immutable_list_3 = ImmutableList(7, ImmutableList(0, ImmutableList(3, ImmutableList(3, ImmutableList.empty()))))
    immutable_list_4 = ImmutableList(6, ImmutableList(0, ImmutableList(6, ImmutableList.empty())))
    immutable_list_5 = ImmutableList(7, ImmutableList(0, ImmutableList(3, ImmutableList(3, ImmutableList.empty()))))
    immutable_list

# Generated at 2022-06-25 23:47:46.385839
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Variables declarations
    immutable_list_0 = ImmutableList.of(None, None)
    immutable_list_1 = ImmutableList(None)
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList(None)
    immutable_list_4 = ImmutableList()

    # Tests
    raise Exception("Method test_ImmutableList_find is not implemented yet.")


# Generated at 2022-06-25 23:47:55.067589
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_2 = ImmutableList(immutable_list_0)
    immutable_list_1 = ImmutableList(immutable_list_2, '', True)
    # Test method find of class ImmutableList:
    try:
        assert immutable_list_2.find(lambda successor: True) == immutable_list_2, "immutable_list_2.find(lambda successor: True) == immutable_list_2"
    except AssertionError as e:
        print("AssertionError: {}".format(str(e)))


# Generated at 2022-06-25 23:48:09.855125
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Setup 1
    immutable_list_0 = ImmutableList(3.0)

    # Setup 1
    immutable_list_1 = ImmutableList(2.0)

    # Setup 2
    immutable_list_2 = ImmutableList(2.0, immutable_list_1)

    # Setup 3
    immutable_list_3 = ImmutableList(3.0, immutable_list_2)

    immutable_list_1.tail = immutable_list_0

    # Setup 4
    immutable_list_4 = ImmutableList(2.0)

    # Setup 5
    immutable_list_5 = ImmutableList(3.0, immutable_list_4)

    # Setup 6
    immutable_list_6 = ImmutableList(2.0)

    # Setup 7

# Generated at 2022-06-25 23:48:20.251380
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: x > 5) == None
    assert ImmutableList().find(lambda x: x < 5) == None
    assert ImmutableList(2).find(lambda x: x > 2) == None
    assert ImmutableList(2).find(lambda x: x == 2) == 2
    assert ImmutableList(3, 2, 1).find(lambda x: x < 3) == 2
    assert ImmutableList(1, 2, 3).find(lambda x: x > 1) == 2
    assert ImmutableList(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList(1, 2, 3, 4, 5, 6, 7).find(lambda x: x == 6) == 6

# Generated at 2022-06-25 23:48:23.793191
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print('test_ImmutableList_find:')
    immutable_list_0 = ImmutableList(object())
    value = immutable_list_0.find(lambda x: x == object())
    if isinstance(value, object):
        print('Test successfully')
    else:
        print('Test failed')


# Generated at 2022-06-25 23:48:32.549597
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(5)

    def fn1(element: int) -> bool:
        return element < 0
    immutable_list_1 = immutable_list_0.filter(fn1)

    def fn2(element: int) -> bool:
        return element > 0
    immutable_list_2 = immutable_list_0.filter(fn2)

    def fn3(element: int) -> bool:
        return element > 10
    immutable_list_3 = immutable_list_0.filter(fn3)

    def fn4(element: int) -> bool:
        return element < 10
    immutable_list_4 = immutable_list_0.filter(fn4)

    def fn5(element: int) -> bool:
        return element == 0
    immutable_list_5 = immutable_list_0

# Generated at 2022-06-25 23:48:41.734562
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = 5
    immutable_list_1 = ImmutableList()
    immutable_list_1.head = 5
    immutable_list_1.tail = ImmutableList()
    immutable_list_1.tail.head = 7
    immutable_list_1.tail.tail = ImmutableList()
    immutable_list_1.tail.tail.head = 3
    immutable_list_1.tail.tail.tail = ImmutableList()
    immutable_list_1.tail.tail.tail.head = 10
    immutable_list_1.tail.tail.tail.tail = ImmutableList()
    immutable_list_1.tail.tail.tail.tail.head = 9
    immutable_list_1.tail.tail.tail.tail.tail = ImmutableList()

# Generated at 2022-06-25 23:49:03.689137
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test cases for non empty list
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_1 = ImmutableList.of('a', 'b', 'c', 'd', 'e')
    # Test cases for empty list
    immutable_list_2 = ImmutableList.empty()
    # Test cases for normal list
    assert immutable_list_0.find(lambda el: el == 1) == 1
    assert immutable_list_0.find(lambda el: el == 2) == 2
    assert immutable_list_0.find(lambda el: el == 3) == 3
    assert immutable_list_0.find(lambda el: el == 4) == 4
    assert immutable_list_0.find(lambda el: el == 5) == 5

# Generated at 2022-06-25 23:49:12.141806
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(0)
    immutable_list_2 = ImmutableList(1, immutable_list_1)
    immutable_list_3 = ImmutableList(2, immutable_list_2)

    assert immutable_list_0.find(lambda x: x == 0) is None
    assert immutable_list_1.find(lambda x: x == 0) == 0
    assert immutable_list_2.find(lambda x: x == 0) == 0
    assert immutable_list_3.find(lambda x: x == 0) == 0


# Generated at 2022-06-25 23:49:19.260773
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()

    tmp_list = ImmutableList.of('z', 1, 'x', 'c', 2, 'b', 3, 'a')
    tmp_list = tmp_list.map(lambda x: 'x' if x == 'x' else x)
    assert(tmp_list.find(lambda x: x == 'x') == 'x')


# Generated at 2022-06-25 23:49:25.395169
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(1)
    immutable_list_2 = immutable_list_2.append(2)
    immutable_list_2 = immutable_list_2.append(3)
    immutable_list_2 = immutable_list_2.append(4)
    immutable_list_3 = immutable_list_3.append(3)
    immutable_list_3 = immutable_list_3.append(2)

# Generated at 2022-06-25 23:49:35.851892
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList()
    immutable_list_7 = ImmutableList()
    immutable_list_8 = ImmutableList()
    immutable_list_9 = ImmutableList()
    immutable_list_10 = ImmutableList()

    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_0 = immutable_list_0.append(3)

# Generated at 2022-06-25 23:49:43.370053
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # 1. test_ImmutableList_filter: test with empty list
    immutable_list_1 = ImmutableList.empty()
    immutable_list_1_f = immutable_list_1.filter(lambda x : x > 2)
    if (immutable_list_1_f.is_empty) == False:
        raise Exception("test_ImmutableList_filter #1")
    # 2. test_ImmutableList_filter: test with list that only has value that passes the predicate
    immutable_list_2 = ImmutableList.of(3)
    immutable_list_2_f = immutable_list_2.filter(lambda x : x > 2)
    if (immutable_list_2_f.to_list() != immutable_list_2.to_list()):
        raise Exception("test_ImmutableList_filter #2")

# Generated at 2022-06-25 23:49:55.416373
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Set up test values
    immutable_list_0 = ImmutableList.of(10)
    immutable_list_1 = ImmutableList.of(4, 2, 5, 2, 4)
    immutable_list_2 = ImmutableList.of(7, 9, 5, 2, 9, 9, 5)

    # Call method to test
    immutable_list_0_result = immutable_list_0.find(lambda x: x == 10)
    immutable_list_1_result = immutable_list_1.find(lambda x: x == 4)
    immutable_list_2_result = immutable_list_2.find(lambda x: x == 5)

    # Assert results
    assert immutable_list_0_result == 10
    assert immutable_list_1_result == 4
    assert immutable_list_2_result == 5


# Generated at 2022-06-25 23:50:08.754604
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_0 = immutable_list_0.filter((lambda n: n != 1))
    immutable_list_1 = ImmutableList.of(2, 3, 4, 5)
    if (immutable_list_0 == immutable_list_1):
        print("Test 0 PASSED")
    else:
        print("Test 0 FAILED")
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_0 = immutable_list_0.filter((lambda n: n != 4))
    immutable_list_1 = ImmutableList.of(1, 2, 3, 5)

# Generated at 2022-06-25 23:50:18.659611
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # empty list
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.filter(lambda x: True)
    assert immutable_list_0 == ImmutableList.empty()
    immutable_list_0 = ImmutableList(1)
    immutable_list_0 = immutable_list_0.filter(lambda x: False)
    assert immutable_list_0 == ImmutableList.empty()
    # non empty list
    immutable_list_1 = ImmutableList.of(1)
    immutable_list_1 = immutable_list_1.filter(lambda x: True)
    assert immutable_list_1 == ImmutableList.of(1)
    immutable_list_1 = ImmutableList.of(1)
    immutable_list_1 = immutable_list_1.filter(lambda x: False)

# Generated at 2022-06-25 23:50:25.690431
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()

    # Test case 0
    assert immutable_list_0.filter(lambda i: i % 2 == 0) == ImmutableList(), "Error in method filter of class ImmutableList"

    # Test case 1
    immutable_list_1 = ImmutableList()

    immutable_list_1.head = 0

    immutable_list_1.tail = ImmutableList()

    assert immutable_list_1.filter(lambda i: i % 2 == 0) == ImmutableList(), "Error in method filter of class ImmutableList"
