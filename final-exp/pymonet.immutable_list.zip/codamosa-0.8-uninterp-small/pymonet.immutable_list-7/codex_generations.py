

# Generated at 2022-06-25 23:40:32.284378
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    def fn(immutable_list_0):
        return immutable_list_0
    var_0 = immutable_list_0.filter(fn)


# Generated at 2022-06-25 23:40:43.056186
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_1) is True
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = "test"
    immutable_list_2.tail = immutable_list_0
    immutable_list_2.is_empty = True
    assert immutable_list_0.__eq__(immutable_list_2) is False
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = "test"
    immutable_list_3.tail = immutable_list_0
    immutable_list_3.is_empty = True
    immutable_list_2.is_empty = False

# Generated at 2022-06-25 23:40:50.397862
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(True, False, False, False, True)
    var_0 = immutable_list_0.find(lambda x: x)
    immutable_list_1 = ImmutableList.of(0, 1, 0, 2, 1, 2)
    var_1 = immutable_list_1.find(lambda x: x == 2)
    immutable_list_2 = ImmutableList.of(0, 1, 0, 2, 1, 2)
    var_2 = immutable_list_2.find(lambda x: x == 3)
    immutable_list_3 = ImmutableList.of(False, False, True, True, True)
    var_3 = immutable_list_3.find(lambda x: x)
    immutable_list_4 = ImmutableList.empty()

# Generated at 2022-06-25 23:41:00.232300
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList(is_empty=False)
    assert not immutable_list_1 == immutable_list_2
    immutable_list_3 = ImmutableList(is_empty=None)
    assert immutable_list_2 == immutable_list_3
    immutable_list_4 = ImmutableList(1)
    immutable_list_5 = ImmutableList(1)
    assert immutable_list_4 == immutable_list_5
    immutable_list_6 = ImmutableList(1, immutable_list_5, True)
    immutable_list_7 = ImmutableList(1, immutable_list_5, True)
    assert immutable_list_6 == immutable_

# Generated at 2022-06-25 23:41:02.443474
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(2, 4, 6, 8, 10)
    var_0 = immutable_list_0.find((lambda x: x > 5))
    assert var_0 == 6


# Generated at 2022-06-25 23:41:05.094161
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(3, 2, 1, None)
    var_0 = immutable_list_0.find(lambda var_1: var_1 >= 4)


# Generated at 2022-06-25 23:41:13.116823
# Unit test for method find of class ImmutableList

# Generated at 2022-06-25 23:41:16.287426
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(0, ImmutableList(1), True)
    immutable_list_1 = ImmutableList(0, ImmutableList(1), True)
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:22.995933
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(is_empty=True)
    var_1 = immutable_list_0.__eq__(immutable_list_1)
    immutable_list_2 = ImmutableList(is_empty=True)
    immutable_list_3 = ImmutableList(is_empty=False)
    var_2 = immutable_list_2.__eq__(immutable_list_3)
    test_bool = var_1 and not var_2
    assert test_bool, "Wrong behavior"


# Generated at 2022-06-25 23:41:32.657395
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.__eq__(ImmutableList()) == True
    immutable_list_0 = ImmutableList()
    immutable_list_0.tail = ImmutableList()
    immutable_list_0.head = 1
    assert immutable_list_0.__eq__(ImmutableList()) == False
    immutable_list_0 = ImmutableList()
    immutable_list_0.tail = ImmutableList()
    immutable_list_0.tail.tail = ImmutableList()
    immutable_list_0.head = 1
    immutable_list_0.head = 2
    immutable_list_0.tail.head = 2
    assert immutable_list_0.__eq__(ImmutableList()) == False


# Generated at 2022-06-25 23:41:44.678248
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # test case 0
    immutable_list_0 = ImmutableList()
    immutable_list_0_filtered = immutable_list_0.filter(lambda element: element > 1)
    assert immutable_list_0_filtered.is_empty
    # test case 1
    immutable_list_1 = ImmutableList.of(1, 2)
    immutable_list_1_filtered = immutable_list_1.filter(lambda element: element > 1)
    assert immutable_list_1_filtered.to_list() == [2]
    # test case 2
    immutable_list_2 = ImmutableList.of(1, 2)
    immutable_list_2_filtered = immutable_list_2.filter(lambda element: element < 2)
    assert immutable_list_2_filtered.to_list() == [1]


# Generated at 2022-06-25 23:41:52.319058
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_0 = immutable_list_0.filter(lambda x: x == 1)
    assert immutable_list_0 == ImmutableList(is_empty=True)
    immutable_list_0 = ImmutableList(1, ImmutableList(is_empty=True))
    immutable_list_0 = immutable_list_0.filter(lambda x: x == 1)
    assert immutable_list_0 == ImmutableList(1, ImmutableList(is_empty=True))
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    if ((not immutable_list_1.filter(lambda x: x < 0)) == 1):
        assert immutable_list_1 == ImmutableList.of(1, 2, 3)
    immutable_

# Generated at 2022-06-25 23:41:59.974094
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(13)
    immutable_list_1 = ImmutableList.of(True)
    immutable_list_2 = ImmutableList.of(None, 'c', -1.0, (int(11) == 11))
    immutable_list_3 = ImmutableList.of(13, 'c', -1.0, (int(11) == 11))
    assert immutable_list_0.filter(lambda it: it == 13).to_list() == [13]
    assert immutable_list_1.filter(lambda it: it == True).to_list() == [True]
    assert immutable_list_2.filter(lambda it: it == None).to_list() == [None]

# Generated at 2022-06-25 23:42:01.123205
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x > 1) == ImmutableList(2)


# Generated at 2022-06-25 23:42:08.621937
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Constructor for test class
    class test_class:
        pass

    # assserts are used for unit testing
    assert ImmutableList.empty().find(lambda x: x) is None

    assert ImmutableList.of(1).find(lambda x: x == 1) == 1

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None

    assert ImmutableList.of("A", "B", "C").find(lambda x: x == "C") == "C"

    assert ImmutableList.of("A", "B", "C").find(lambda x: x == "D") is None


# Generated at 2022-06-25 23:42:16.554505
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(None, None)
    immutable_list_0.find(lambda x: True)
    immutable_list_1 = ImmutableList(None)
    immutable_list_1.find(lambda x: True)
    immutable_list_2 = ImmutableList(None, ImmutableList())
    immutable_list_2.find(lambda x: True)
    immutable_list_3 = ImmutableList(None, ImmutableList())
    result = immutable_list_3.find(lambda x: True)


# Generated at 2022-06-25 23:42:28.421498
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = ImmutableList(True)
    immutable_list_3 = ImmutableList(True, immutable_list_1)
    immutable_list_4 = ImmutableList.of(True)
    immutable_list_5 = ImmutableList.of(True, False)
    immutable_list_6 = ImmutableList(True, immutable_list_5)
    immutable_list_7 = ImmutableList(False, immutable_list_6)

    assert immutable_list_1.filter(lambda x: x) == ImmutableList.empty()
    assert immutable_list_2.filter(lambda x: x) == ImmutableList(True)
    assert immutable_list_3.filter(lambda x: x) == ImmutableList

# Generated at 2022-06-25 23:42:37.252815
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0_filter = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert immutable_list_0_filter.to_list() == []
    immutable_list_0 = ImmutableList(1)
    immutable_list_0_filter = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert immutable_list_0_filter.to_list() == []
    immutable_list_0 = ImmutableList(2)
    immutable_list_0_filter = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert immutable_list_0_filter.to_list() == [2]

# Generated at 2022-06-25 23:42:42.616062
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(True, ImmutableList(False, ImmutableList(True, ImmutableList(False, ImmutableList(False, ImmutableList(True, ImmutableList(False, ImmutableList(False, ImmutableList()))))))))
    immutable_list_1 = immutable_list_0.filter(lambda immutable_list_0: immutable_list_0)
    assert immutable_list_1 == ImmutableList(True, ImmutableList(True, ImmutableList(True, ImmutableList())))
    immutable_list_0 = ImmutableList(True, ImmutableList(False, ImmutableList(True, ImmutableList(False, ImmutableList(False, ImmutableList(True, ImmutableList(False, ImmutableList(False, ImmutableList()))))))))
    immutable_list_1 = immutable_list_0.filter

# Generated at 2022-06-25 23:42:44.650345
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case for method find of class ImmutableList
    test_case_0()


test_ImmutableList_find()

# Generated at 2022-06-25 23:42:57.815911
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    def square(x):
        return x * x

    def check(n):
        return n % 2 == 0

    def add(x,y):
        return x + y

    immutable_list_0 = ImmutableList.of(0)
    assert immutable_list_0.find(check) == 0

    immutable_list_1 = ImmutableList.of(0,1,2,3,4,5,6,7,8)
    assert immutable_list_1.find(check) == 0

    immutable_list_2 = ImmutableList.of(9,1,2,3,4,5,6,7,8)
    assert immutable_list_2.find(check) == 2

    immutable_list_3 = ImmutableList.of(9,10,2,3,4,5,6,7,8)

# Generated at 2022-06-25 23:43:00.586060
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList(hash(0), ImmutableList(hash(1)))
    value = immutable_list.find(lambda x: True if x == hash(0) else False)
    assert value == hash(0)



# Generated at 2022-06-25 23:43:04.399947
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1, ImmutableList(2))
    integer_0 = immutable_list_0.find(lambda it: it == 2)
    assert integer_0 == 2


# Generated at 2022-06-25 23:43:13.548391
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_obj = ImmutableList.of(1,2,3)
    assert test_obj.find(lambda x: x == 1) == 1
    assert test_obj.find(lambda x: x == 4) == None

    test_obj = ImmutableList.of(None,2,3)
    assert test_obj.find(lambda x: x == None) == None
    assert test_obj.find(lambda x: x == 2) == 2

    test_obj = ImmutableList.of(1, None,3)
    assert test_obj.find(lambda x: x == None) == None
    assert test_obj.find(lambda x: x == 3) == 3
    assert test_obj.find(lambda x: x == 4) == None



# Generated at 2022-06-25 23:43:18.631374
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 3, 2, 6, 8)\
        .find(lambda x: x == 4) == None

    assert ImmutableList.of(1, 3, 2, 6, 8)\
        .find(lambda x: x == 2) == 2

    assert ImmutableList.of(1)\
        .find(lambda x: x == 1) == 1


# Generated at 2022-06-25 23:43:25.505177
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    case_0 = ImmutableList()
    case_1 = ImmutableList.of(1)
    case_2 = ImmutableList.of(1, 1)
    case_3 = ImmutableList.of(1, 2, 3, 4)

    def negate(value): return not value

    def value_checker(value): return value == 1

    assert case_0.find(negate) is None
    assert case_1.find(value_checker) == 1
    assert case_2.find(value_checker) == 1
    assert case_3.find(value_checker) == 1


# Generated at 2022-06-25 23:43:34.821765
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(True)
    immutable_list_2 = ImmutableList()

    assert(immutable_list_0 == immutable_list_2)
    assert(not immutable_list_0 == immutable_list_1)

    immutable_list_3 = ImmutableList(1, ImmutableList(2))
    immutable_list_4 = ImmutableList(1, ImmutableList(2))

    assert(immutable_list_3 == immutable_list_4)
    assert(not immutable_list_3 == immutable_list_2)

# Generated at 2022-06-25 23:43:43.785634
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Empty
    l = ImmutableList()
    assert l.find(lambda x: x == 10) is None
    l = ImmutableList(None)
    assert l.find(lambda x: x == 10) is None
    l = ImmutableList.of(None)
    assert l.find(lambda x: x == 10) is None

    # Single element
    l = ImmutableList(10)
    assert l.find(lambda x: x == 10) == 10
    assert l.find(lambda x: x == 11) is None
    l = ImmutableList.of(10)
    assert l.find(lambda x: x == 10) == 10
    assert l.find(lambda x: x == 11) is None
    l = ImmutableList.of(10, None, 10)

# Generated at 2022-06-25 23:43:50.550963
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test with empty array
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.find(lambda x: x == 2) is None

    # Test with not empty array and find element
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    assert immutable_list_1.find(lambda x: x == 2) == 2

    # Test with not empty array and not find element
    immutable_list_2 = ImmutableList.of(1, 2, 3)
    assert immutable_list_2.find(lambda x: x == 4) is None


# Generated at 2022-06-25 23:44:02.127038
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda _: True) is None
    assert ImmutableList.empty().find(lambda _: False) is None
    assert ImmutableList.of(1).find(lambda x: 1 == x) == 1
    assert ImmutableList.of(2).find(lambda x: 1 == x) is None
    assert ImmutableList.of(1, 2).find(lambda x: 1 == x) == 1
    assert ImmutableList.of(1, 2).find(lambda x: 2 == x) == 2
    assert ImmutableList.of(1, 2).find(lambda x: 3 == x) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: 2 == x) == 2

# Generated at 2022-06-25 23:44:16.902021
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(10)
    immutable_list_1 = ImmutableList(True, immutable_list_0)
    immutable_list_2 = ImmutableList('bc', immutable_list_1)
    immutable_list_3 = ImmutableList(0.0, immutable_list_2)
    immutable_list_4 = ImmutableList(10, immutable_list_3)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = ImmutableList.empty()
    immutable_list_4 = immutable_list_4.find(lambda elem: elem == 10)
    assert immutable_list_4 == 10


# Generated at 2022-06-25 23:44:26.904271
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(is_empty=True)
    immutable_list_3 = ImmutableList(is_empty=True)
    immutable_list_4 = ImmutableList(is_empty=False)
    immutable_list_5 = ImmutableList(is_empty=False)
    immutable_list_6 = ImmutableList(15, immutable_list_4)
    immutable_list_7 = ImmutableList(42, immutable_list_5)
    immutable_list_8 = ImmutableList(42, immutable_list_4)
    immutable_list_9 = ImmutableList(42, immutable_list_5)
    immutable_list_10 = ImmutableList(32, immutable_list_8)
    immutable_

# Generated at 2022-06-25 23:44:35.131213
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert(immutable_list_0 == immutable_list_1)

    immutable_list_2 = ImmutableList.of(1)
    immutable_list_3 = ImmutableList.of(1)
    assert(immutable_list_2 == immutable_list_3)

    immutable_list_4 = ImmutableList.of(2, 2)
    immutable_list_5 = ImmutableList.of(2, 2)
    assert(immutable_list_4 == immutable_list_5)

    immutable_list_7 = ImmutableList()
    assert(not immutable_list_0 == immutable_list_7)

    immutable_list_9 = ImmutableList.of(1)

# Generated at 2022-06-25 23:44:45.308791
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(None)
    assert immutable_list_0.find(lambda v: False) is None
    immutable_list_1 = ImmutableList(None, immutable_list_0)
    assert None == immutable_list_1.find(lambda v: False)
    immutable_list_2 = ImmutableList(False, immutable_list_1)
    assert None == immutable_list_2.find(lambda a: False)
    immutable_list_3 = ImmutableList(False, immutable_list_2)
    assert immutable_list_3.find(lambda a: a is True) is None
    immutable_list_4 = ImmutableList(-1, immutable_list_3)
    assert immutable_list_4.find(lambda a: a is False) is False

# Generated at 2022-06-25 23:44:55.089579
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)
    int_0 = 0
    int_1 = 1
    int_2 = 2
    # In this test case, the length of list is 1, so the function find makes a loop and compares an integer 0 with an integer 0.
    int_3 = immutable_list_0.find(lambda int_6: int_6 == int_0)
    # Test if the first element of the list is equal to 0
    assert(int_3 == int_0)

    immutable_list_1 = immutable_list_0.append(1)
    # In this test case, the length of list is 2, so the function find makes a loop and compares an integer 0 with an integer 0, and an integer 1 with an integer 0.

# Generated at 2022-06-25 23:44:56.787400
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'a') == 'a'


# Generated at 2022-06-25 23:45:06.294292
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Case 0
    immutable_list_0 = ImmutableList()
    fn_0 = lambda x: True
    immutable_list_0_find_ret_0 = immutable_list_0.find(fn_0)
    assert immutable_list_0_find_ret_0 is None
    # Case 1
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(2)
    immutable_list_1 = immutable_list_1.append(3)
    immutable_list_1 = immutable_list_1.append(4)
    immutable_list_1 = immutable_list_1.append(5)
    immutable_list_1 = immutable_list_1.append(6)
    fn_1 = lambda x: x < 5
    immutable_list_1_find_ret_

# Generated at 2022-06-25 23:45:16.673736
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1).find(lambda x: x != 1) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x != 1) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x != 5) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList

# Generated at 2022-06-25 23:45:19.373741
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(4, 4, 6, 7, 3).find(lambda x: x < 3) == None
    assert ImmutableList.of(4, 4, 6, 7, 3).find(lambda x: x < 5) == 4


# Generated at 2022-06-25 23:45:23.312659
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = immutable_list_1.append(2)
    immutable_list_3 = immutable_list_2.append(3)
    assert immutable_list_3.find(lambda x: x==3) == 3
    assert immutable_list_3.find(lambda x: x==4) == None


# Generated at 2022-06-25 23:45:42.702980
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(10.0, 15, 7)
    immutable_list_1 = ImmutableList.of(10.0, 15, 7)
    immutable_list_2 = ImmutableList.empty()
    immutable_list_3 = ImmutableList.empty()
    immutable_list_4 = ImmutableList.of(8, 8)
    immutable_list_5 = ImmutableList.of(8, 8)
    immutable_list_6 = ImmutableList.of(8, 8)
    immutable_list_7 = ImmutableList.of(8, 8)
    immutable_list_8 = ImmutableList.of(8, 6, 5, 8)
    immutable_list_9 = ImmutableList.of(8, 6, 5, 8)

# Generated at 2022-06-25 23:45:47.168303
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    assert type(immutable_list_0) is ImmutableList

    immutable_list_0 = ImmutableList.of(1, 2)
    assert immutable_list_0.find(lambda num: num > 1) == 2


# Generated at 2022-06-25 23:45:58.261628
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    bool_0 = immutable_list_0.find(lambda immutable_list_0: immutable_list_0) is None
    assert bool_0
    immutable_list_1 = ImmutableList.of(42)
    bool_1 = immutable_list_1.find(lambda immutable_list_1: immutable_list_1) == 42
    assert bool_1
    immutable_list_2 = ImmutableList.of(False, True)
    bool_2 = immutable_list_2.find(lambda immutable_list_2: immutable_list_2) == False
    assert bool_2
    bool_3 = immutable_list_2.find(lambda immutable_list_2: not immutable_list_2) == True
    assert bool_3


# Generated at 2022-06-25 23:46:05.142121
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    mock ImmutableList.find
    """
    immutable_list = ImmutableList.of(1)
    test_fn = lambda x: x == 1
    assert immutable_list.find(test_fn) == 1

    immutable_list = ImmutableList.of(1, 2, 3)
    test_fn = lambda x: x == 3
    assert immutable_list.find(test_fn) == 3

    immutable_list = ImmutableList.of(1, 2, 3)
    test_fn = lambda x: x == 4
    assert immutable_list.find(test_fn) is None


# Generated at 2022-06-25 23:46:10.224187
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutableList = ImmutableList(1)
    assert immutableList == 1, 'ImmutableList:__eq__:1'
    immutableList = ImmutableList(1)
    assert immutableList == immutableList, 'ImmutableList:__eq__:2'
    immutableList = ImmutableList(1, ImmutableList(1))
    assert immutableList == immutableList, 'ImmutableList:__eq__:3'
    immutableList = ImmutableList(1, ImmutableList(1))
    assert immutableList != 1, 'ImmutableList:__eq__:4'


# Generated at 2022-06-25 23:46:16.817520
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = ImmutableList(1, 2, 3)
    immutable_list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    immutable_list_3 = ImmutableList(immutable_list_2)
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_0 == immutable_list_2
    assert immutable_list_0 == immutable_list_3


# Generated at 2022-06-25 23:46:20.203824
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(2, 3).find(lambda x: x == 8) is None
    assert ImmutableList.empty().find(lambda x: x == 8) is None



# Generated at 2022-06-25 23:46:26.605416
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = ImmutableList.of(6, 5, 9)
    immutable_list_2 = ImmutableList.of(8, 1, 4, 5, 9)
    assert immutable_list_0.find(lambda x: x % 2 == 1) == None
    assert immutable_list_1.find(lambda x: x % 7 == 0) == 6
    assert immutable_list_2.find(lambda x: x % 2 == 1) == 1


# Generated at 2022-06-25 23:46:37.332836
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    try:
        immutable_list_0.find(1)
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError to be raised")
    immutable_list_1 = ImmutableList()
    immutable_list_1.head = 1
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = None
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = 1
    immutable_list_3.tail = immutable_list_0
    immutable_list_3.is_empty = True
    immutable_list_4 = ImmutableList()
    immutable_list_4.head = None
    immutable_list_4.tail = immutable_list_0

# Generated at 2022-06-25 23:46:47.588178
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_12 = ImmutableList.of(12)
    immutable_list_34 = ImmutableList.of(34)
    immutable_list_56 = ImmutableList.of(56)
    immutable_list_78 = ImmutableList.of(78)
    immutable_list_910 = ImmutableList.of(910)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = immutable_list_0.append(12)
    immutable_list_0 = immutable_list_0.append(34)
    immutable_list_0 = immutable_list_0.append(56)
    immutable_list_0 = immutable_list_0.append(78)
    immutable_list_0 = immutable_list_0.append(910)
    predicate = lambda element: element % 2 == 0

# Generated at 2022-06-25 23:47:18.967070
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_list = ImmutableList.empty()
    list_of_one = ImmutableList.of(1)
    list_of_few = ImmutableList.of(1, 2, 3, 4)

    test_cases = [
        [empty_list, lambda x: x == 1, None],
        [list_of_one, lambda x: x == 1, 1],
        [list_of_few, lambda x: x == 3, 3]
    ]

    for idx, test_case in enumerate(test_cases):
        result = test_case[0].find(test_case[1])
        test_case_name = 'test case #{}'.format(idx)


# Generated at 2022-06-25 23:47:30.169846
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_75_2_46_0_37_4_4_4_4_2_2_0 = ImmutableList.of(75, 2, 46, 0, 37, 4, 4, 4, 4, 2, 2, 0)
    assert list_75_2_46_0_37_4_4_4_4_2_2_0.find(lambda x: x == 46) == 46
    assert list_75_2_46_0_37_4_4_4_4_2_2_0.find(lambda x: x == 4) == 4
    assert list_75_2_46_0_37_4_4_4_4_2_2_0.find(lambda x: x == 99) is None
    list_98_98_98_98_98_98_98_98_98_

# Generated at 2022-06-25 23:47:39.119669
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) == None
    assert ImmutableList(True).find(lambda x: x) == True
    assert ImmutableList(-1).find(lambda x: x > 0) == None
    assert ImmutableList(None, None, None).find(lambda x: True) == None
    assert ImmutableList(10, "test", None).find(lambda x: x != None) == 10
    assert ImmutableList(0, 1, 2, 3).find(lambda x: x > 1) == 2
    assert ImmutableList(0, 1, 2, 3).find(lambda x: x > 3) == None
    assert ImmutableList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9).find(lambda x: x % 3 == 0) == 0

# Generated at 2022-06-25 23:47:47.870283
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ImmutableList_0 = ImmutableList.of("value", "value", "value", "value", "value", "value")
    ImmutableList_1 = ImmutableList.of("value", "value", "value", "value", "value", "value")
    ImmutableList_2 = ImmutableList.of("value", "value", "value", "value", "value", "value")
    ImmutableList_3 = ImmutableList.of("value", "value", "value", "value", "value", "value")
    ImmutableList_4 = ImmutableList.of("value", "value", "value", "value", "value", "value")
    ImmutableList_5 = ImmutableList.of("value", "value", "value", "value", "value", "value")

# Generated at 2022-06-25 23:47:49.863239
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    ## Test case for value in {(0)}
    # No assert statements

    # Call the test case
    test_case_0()


# Generated at 2022-06-25 23:48:00.351913
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(True, immutable_list_0)
    immutable_list_2 = ImmutableList(False, immutable_list_1)
    immutable_list_3 = ImmutableList(False, immutable_list_2)
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList(False, immutable_list_4)
    immutable_list_6 = ImmutableList(True, immutable_list_5)
    immutable_list_7 = ImmutableList(False, immutable_list_6)
    immutable_list_8 = ImmutableList(False, immutable_list_7)
    immutable_list_9 = ImmutableList()
    immutable_list_10 = ImmutableList(False, immutable_list_9)
    immutable_

# Generated at 2022-06-25 23:48:09.546576
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 1
    immutable_list = ImmutableList(8)
    result = immutable_list.find(lambda _: True)

    assert result == 8

    # Test case 2
    immutable_list = ImmutableList(9)
    result = immutable_list.find(lambda _: False)

    assert result == None

    # Test case 3
    immutable_list = ImmutableList(3,
                                 ImmutableList(5,
                                             ImmutableList(6,
                                                         ImmutableList(11))))
    result = immutable_list.find(lambda n: n > 4)

    assert result == 5


# Generated at 2022-06-25 23:48:19.830578
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    def assert_equals(expected, actual):
        assert expected == actual

    # Case 1
    immutable_list_0 = ImmutableList()
    int_0 = immutable_list_0.find(lambda elem: elem == int())
    assert_equals(int_0, None)

    # Case 2
    immutable_list_0 = ImmutableList()
    string_0 = immutable_list_0.find(lambda elem: elem == 'asd')
    assert_equals(string_0, None)

    # Case 3
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(int())
    immutable_list_0 = immutable_list_0.append(23234234234)
    immutable_list_0 = immutable_list_0.append(int())

# Generated at 2022-06-25 23:48:22.085071
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList(element, None, False)
    result_0 = immutable_list_0.find()
    

# Generated at 2022-06-25 23:48:26.403820
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(4, 2, 1, 3).find(lambda x: x > 2) == 4
    assert ImmutableList.of(4, 2, 1, 3).find(lambda x: x > 5) == None
    assert ImmutableList.of(4, 2, 1, 3, 1, 2, 3, 4, 5, 6, 7).find(lambda x: x > 5) == 6


# Generated at 2022-06-25 23:49:28.324957
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(object())
    immutable_list_2 = immutable_list_1
    immutable_list_3 = ImmutableList(object(), ImmutableList())
    immutable_list_4 = ImmutableList(object(), ImmutableList())
    immutable_list_5 = ImmutableList(object(), immutable_list_3)
    immutable_list_6 = ImmutableList(object(), immutable_list_3)
    
    assert (immutable_list_0 == immutable_list_0) == True, 'AssertionError: 0'
    assert (immutable_list_0 == immutable_list_1) == False, 'AssertionError: 1'

# Generated at 2022-06-25 23:49:32.041414
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    result_0 = immutable_list_0 == immutable_list_0
    assert result_0 == True

    result_1 = immutable_list_0 == immutable_list_0
    assert result_1 == True


# Generated at 2022-06-25 23:49:35.600915
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:49:43.210627
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_1 == immutable_list_0

    immutable_list_0_0 = ImmutableList(5)
    immutable_list_1_0 = ImmutableList(5)
    assert immutable_list_0_0 == immutable_list_1_0
    assert immutable_list_1_0 == immutable_list_0_0

    immutable_list_0_1 = ImmutableList(5, immutable_list_0_0)
    immutable_list_1_1 = ImmutableList(5, immutable_list_1_0)
    assert immutable_list_0_1 == immutable_list_1_1
    assert immutable_list_1_1

# Generated at 2022-06-25 23:49:48.661605
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_1 = ImmutableList(0)
    immutable_list_2 = ImmutableList(0)
    immutable_list_3 = ImmutableList(0, None)


# Generated at 2022-06-25 23:49:57.150806
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    #
    # Test case #0
    #
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1_copy = immutable_list_1
    assert immutable_list_0.__eq__(immutable_list_1) == immutable_list_1.__eq__(immutable_list_0)
    #
    # Test case #1
    #
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    assert immutable_list_0.__eq__(immutable_list_1) != immutable_list_1.__eq__(immutable_list_0)
    #
    # Test case #2
    #
    immutable_list_0 = ImmutableList(1)
    immutable_list_

# Generated at 2022-06-25 23:50:08.790705
# Unit test for method __eq__ of class ImmutableList

# Generated at 2022-06-25 23:50:18.685624
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_1 = ImmutableList(None)
    immutable_list_2 = ImmutableList(1)
    immutable_list_3 = ImmutableList(1, None)
    immutable_list_4 = ImmutableList(1, ImmutableList(1, None))
    immutable_list_5 = ImmutableList(None)
    immutable_list_6 = ImmutableList(1)
    immutable_list_7 = ImmutableList(1, None)
    immutable_list_8 = ImmutableList(1, ImmutableList(1, None))
    assert immutable_list_1 == immutable_list_5
    assert not (immutable_list_1 != immutable_list_5)
    assert immutable_list_2 == immutable_list_6
    assert not (immutable_list_2 != immutable_list_6)
    assert immutable

# Generated at 2022-06-25 23:50:27.399719
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    
    immutable_list_0 = ImmutableList(
        "string",
        ImmutableList(
            True, 
            ImmutableList(
                None, 
                ImmutableList(
                    "any", 
                    ImmutableList(
                        "string", 
                        None
                    )
                )
            )
        )
    )
    
    immutable_list_1 = ImmutableList(
        "any", 
        ImmutableList(
            "any", 
            ImmutableList(
                "string", 
                ImmutableList(
                    "any", 
                    ImmutableList(
                        True, 
                        ImmutableList(
                            "string", 
                            None
                        )
                    )
                )
            )
        )
    )
    
    immutable_list_2 = ImmutableList.of