

# Generated at 2022-06-25 23:40:38.446059
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(2, 4) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList() == ImmutableList(None, None, True)
    assert ImmutableList(3, ImmutableList(2, ImmutableList(4))) == ImmutableList(3, ImmutableList(2, ImmutableList(4)))
    assert ImmutableList(5, ImmutableList(5, ImmutableList(5))) == ImmutableList(5, ImmutableList(5, ImmutableList(5)))
    assert ImmutableList(4, ImmutableList(4, ImmutableList(4, ImmutableList(4)))) == ImmutableList(4, ImmutableList(4, ImmutableList(4, ImmutableList(4))))
    assert ImmutableList(1) == ImmutableList(1)

# Generated at 2022-06-25 23:40:43.804858
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList('07', immutable_list_0)
    immutable_list_2 = ImmutableList(None, immutable_list_1)
    v = immutable_list_2.find(lambda x : x == '07')
    assert v == '07'


# Generated at 2022-06-25 23:40:47.893000
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1)
    def fn(x):
        return isinstance(x,int)
    immutable_list_0.find(fn)
    immutable_list_1 = ImmutableList(2)
    def fn(x):
        return isinstance(x,int)
    immutable_list_1.find(fn)


# Generated at 2022-06-25 23:40:52.436709
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)
    if not (immutable_list_0 == immutable_list_1):
        print('Test failure')


# Generated at 2022-06-25 23:40:57.694394
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(1, ImmutableList(3, ImmutableList(3)))
    assert immutable_list_0 == immutable_list_0 # __eq__(self, other: object) -> bool

    immutable_list_1 = ImmutableList()
    assert immutable_list_0 != immutable_list_1 # __eq__(self, other: object) -> bool

    immutable_list_2 = ImmutableList(3, ImmutableList(3))
    assert immutable_list_1 != immutable_list_2 # __eq__(self, other: object) -> bool


# Generated at 2022-06-25 23:41:07.281741
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList(1, immutable_list_0)
    immutable_list_2 = ImmutableList(2, immutable_list_1)
    immutable_list_3 = ImmutableList(3, immutable_list_2)
    immutable_list_4 = ImmutableList(4, immutable_list_3)
    immutable_list_5 = ImmutableList(5, immutable_list_4)

    assert(immutable_list_5.find(lambda x: x == 0) == 0)
    assert(immutable_list_5.find(lambda x: x == 1) == 1)
    assert(immutable_list_5.find(lambda x: x == 2) == 2)

# Generated at 2022-06-25 23:41:14.776261
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    test_cases = [
        (
            ImmutableList(is_empty=True),
            True
        ),
        (
            ImmutableList(1),
            False
        ),
        (
            ImmutableList(1, ImmutableList(2)),
            False
        ),
        (
            ImmutableList(1, ImmutableList(2)),
            ImmutableList(1, ImmutableList(2))
        ),
    ]

    for ind, test_case in enumerate(test_cases):
        input_0, expected = test_case

        try:
            actual = input_0._ImmutableList__eq__(expected)
        except Exception as e:
            print("Error raised on test case {}".format(ind))
            print("  Input 0: {}".format(input_0))

# Generated at 2022-06-25 23:41:19.062192
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(immutable_list_0, immutable_list_1)
    immutable_list_3 = ImmutableList(immutable_list_0, immutable_list_1)
    assert immutable_list_2 == immutable_list_3



# Generated at 2022-06-25 23:41:29.290559
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_ImmutableList_filter_0(ImmutableList(), True)
    test_ImmutableList_filter_1(ImmutableList(2, ImmutableList(3)), True)
    test_ImmutableList_filter_2(ImmutableList(), True)
    test_ImmutableList_filter_3(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))), True)
    test_ImmutableList_filter_4(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))), True)
    test_ImmutableList_filter_5(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))), True)
    test_ImmutableList_filter_6(ImmutableList(0), True)


# Generated at 2022-06-25 23:41:41.166901
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList(is_empty=True)
    immutable_list_7 = ImmutableList(is_empty=True)

    assert immutable_list_0 == immutable_list_0
    assert immutable_list_1 == immutable_list_1
    assert immutable_list_2 == immutable_list_2
    assert immutable_list_3 == immutable_list_3
    assert immutable_list_4 == immutable_list_4
    assert immutable_list_5 == immutable_list_5
    assert immutable_list_6

# Generated at 2022-06-25 23:41:57.093707
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 9)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 2)
    assert immutable_list_1 == ImmutableList.of(3, 4, 5, 6, 7, 9)
    immutable_list_0 = ImmutableList.of(1, 1, 1, 1, 1, 1, 1, -8, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -10)
    immutable_list_1 = immutable_list_0.filter(lambda x: x == 1)

# Generated at 2022-06-25 23:42:04.495805
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    str_0 = immutable_list_0.find(lambda x: x is None)
    assert str_0 == None


# Generated at 2022-06-25 23:42:14.960906
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test: Empty list
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.find(lambda x: True) == None
    assert immutable_list_0.find(lambda x: False) == None

    # Test: List with 1 element
    immutable_list_0 = ImmutableList.of(1)
    assert immutable_list_0.find(lambda x: True) == 1
    assert immutable_list_0.find(lambda x: False) == None

    # Test: List with 2 elements
    immutable_list_1 = immutable_list_0.unshift(0)
    assert immutable_list_1.find(lambda x: True) == 0
    assert immutable_list_1.find(lambda x: False) == None

    # Test: List with 3 elements
    immutable_list_2 = immutable

# Generated at 2022-06-25 23:42:23.077043
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_0 = list()
    for i in range(0, 10):
        list_0.append(i)

    immutable_list_0 = ImmutableList.of(list_0[0], list_0[1], list_0[2], list_0[3], list_0[4], list_0[5], list_0[6], list_0[7], list_0[8], list_0[9])
    result = immutable_list_0.find((lambda x : x > 2))

    assert result == list_0[3]


# Generated at 2022-06-25 23:42:34.021875
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case for when head is None and tail is None
    def test_case_0():
        immutable_list_0 = ImmutableList()
        callback_test_case_0 = lambda _: True
        immutable_list_1 = ImmutableList(head = None, tail = None, is_empty = True)
        assert immutable_list_0.filter(callback_test_case_0) == immutable_list_1

    # Test case for when head is a value and tail is None
    def test_case_1():
        immutable_list_0 = ImmutableList(head = 1, tail = None)
        callback_test_case_0 = lambda _: False
        immutable_list_1 = ImmutableList(head = None, tail = None, is_empty = True)

# Generated at 2022-06-25 23:42:37.426514
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList.of(4, 5)
    immutable_list_2 = immutable_list_1.filter(lambda e: e % 2 == 1)
    immutable_list_3 = immutable_list_1.filter(lambda e: e % 2 == 0)
    immutable_list_4 = immutable_list_1.filter(lambda e: e % 3 == 0)
    immutable_list_5 = immutable_list_1.filter(lambda e: e < 4)


# Generated at 2022-06-25 23:42:42.261645
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(3747, 4592, 1455)
    immutable_list_1 = ImmutableList.of(0, 0)
    immutable_list_2 = ImmutableList.of(0, 0)

    # No exception is raised
    assert immutable_list_0 == immutable_list_0
    assert immutable_list_1 == immutable_list_2

    # ValueError is raised
    try:
        immutable_list_0 == 1
    except ValueError:
        pass
    else:
        raise AssertionError

    try:
        immutable_list_2 == 1
    except ValueError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 23:42:52.014274
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of('test_ImmutableList_find_0', 'test_ImmutableList_find_1', 'test_ImmutableList_find_2')
    immutable_list_2 = ImmutableList.of(-1, -1, -1)
    immutable_list_3 = ImmutableList.of('test_ImmutableList_find_1', 'test_ImmutableList_find_1', 'test_ImmutableList_find_1')
    immutable_list_4 = ImmutableList.of(0, 1, 2)
    immutable_list_5 = ImmutableList.of(0, 0, 0)

# Generated at 2022-06-25 23:42:58.812472
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    mapper_0 = ImmutableList.of(tuple([])).append(tuple([])).map(tuple)
    mapper_1 = ImmutableList.of(tuple([])).append(tuple([])).map(tuple)
    mapper_2 = ImmutableList.of(tuple([])).append(tuple([])).append(tuple([])).map(tuple)
    assert mapper_0 == mapper_1
    assert not mapper_0 == mapper_2


# Generated at 2022-06-25 23:43:10.482435
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList()
    immutable_list_7 = ImmutableList()
    immutable_list_8 = ImmutableList()


    assert immutable_list_0 == immutable_list_0
    assert immutable_list_1 == immutable_list_1
    assert immutable_list_2 == immutable_list_2
    assert immutable_list_3 == immutable_list_3
    assert immutable_list_4 == immutable_list_4
    assert immutable_list_5 == immutable_list_5
    assert immutable_list_

# Generated at 2022-06-25 23:43:33.751441
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    pass

    # immutabl_list_0 = ImmutableList()
    # assert immutabl_list_0.filter(lambda x: True) == ImmutableList(is_empty=True)

    # immutable_list_1 = ImmutableList.of(1, 2, 3)
    # assert immutable_list_1.filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

    # immutable_list_2 = ImmutableList.of(1, 2, 3)
    # assert immutable_list_2.filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

    # immutable_list_3 = ImmutableList.of(1, 2, 3)
    # assert immutable_list_3.filter(lambda x: x % 3 == 0) == ImmutableList.of(3

# Generated at 2022-06-25 23:43:41.552597
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # should create new ImmutableList
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = ImmutableList()

    # should check if ImmutableList_0 is equal to ImmutableList_1
    immutable_list_1 = immutable_list_0.__eq__(immutable_list_0)
    assert immutable_list_1

    # should check if ImmutableList_0 is not equal to ImmutableList_1
    immutable_list_1 = immutable_list_0.__eq__(immutable_list_1)
    assert not immutable_list_1


# Generated at 2022-06-25 23:43:43.470822
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 3, 3, 4, 5).find(lambda x: x == 2) is None


# Generated at 2022-06-25 23:43:48.872047
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(True)
    immutable_list_1 = ImmutableList(False, immutable_list_0)
    immutable_list_2 = ImmutableList(True, immutable_list_1)
    immutable_list_3 = ImmutableList(False, immutable_list_2)
    immutable_list_4 = ImmutableList(True, immutable_list_3)
    immutable_list_5 = ImmutableList(False, immutable_list_4)
    immutable_list_6 = ImmutableList(False, immutable_list_5)
    immutable_list_7 = ImmutableList(True, immutable_list_6)
    immutable_list_8 = ImmutableList(False, immutable_list_7)
    immutable_list_9 = ImmutableList(True, immutable_list_8)
    immutable_list_

# Generated at 2022-06-25 23:44:00.290767
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # MapTests.filter
    immutable_list_0 = ImmutableList.of(None)
    assert immutable_list_0.filter(lambda x : True) == ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_1.filter(lambda x : x > 1.69) == ImmutableList.empty()
    immutable_list_2 = ImmutableList.of(None, -3.18, -3.18, 0.0, -3.18, -3.18, None)
    assert immutable_list_2.filter(lambda x : False) == ImmutableList.empty()
    immutable_list_3 = ImmutableList.of(0, 0, 0)

# Generated at 2022-06-25 23:44:05.981463
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.find(lambda value: True) == None

    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list_1.find(lambda value: True) == 1

    assert immutable_list_1.find(lambda value: value > 5) == None
    assert immutable_list_1.find(lambda value: value == 5) == 5



# Generated at 2022-06-25 23:44:10.998156
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_0 = immutable_list_0.append(3)
    immutable_list_1 = immutable_list_0.filter(lambda x: x <= 2)
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail.head == 2
    assert immutable_list_1.tail.tail is None

# Generated at 2022-06-25 23:44:20.072247
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList.of(1)
    immutable_list_2 = ImmutableList.of(2, 3)
    immutable_list_3 = ImmutableList.of(3, 1, 4)

    assert immutable_list_1.find(lambda x: x == 1) == 1
    assert immutable_list_1.find(lambda x: x == 0) is None
    assert immutable_list_2.find(lambda x: x == 3) is 3
    assert immutable_list_2.find(lambda x: x == 4) is None
    assert immutable_list_3.find(lambda x: x > 1) is 3
    assert immutable_list_3.find(lambda x: x > 4) is None


# Generated at 2022-06-25 23:44:30.204652
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # construct ImmutableList(head=1, tail=ImmutableList(head=2, tail=None, is_empty=False), is_empty=False)
    ImmutableList2 = ImmutableList()
    ImmutableList2.head = 2
    ImmutableList1 = ImmutableList()
    ImmutableList1.head = 1
    ImmutableList1.tail = ImmutableList2
    # construct ImmutableList(head=1, tail=ImmutableList(head=2, tail=None, is_empty=False), is_empty=False)
    ImmutableList4 = ImmutableList()
    ImmutableList4.head = 2
    ImmutableList3 = ImmutableList()
    ImmutableList3.head = 1
    ImmutableList3.tail = ImmutableList4

    # assert ImmutableList(head=1, tail=

# Generated at 2022-06-25 23:44:36.723217
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_0)
    assert not immutable_list_0.__eq__(4)
    immutable_list_1 = ImmutableList(1)
    assert immutable_list_1.__eq__(immutable_list_1)
    immutable_list_2 = ImmutableList(3, ImmutableList(2, immutable_list_1), False)
    assert not immutable_list_2.__eq__(immutable_list_0)
    assert not immutable_list_2.__eq__(None)
    immutable_list_0.is_empty = False
    assert not immutable_list_2.__eq__(immutable_list_0)


# Generated at 2022-06-25 23:44:58.597668
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
	immutable_list_0 = ImmutableList(4)
	immutable_list_1 = ImmutableList.of(2, 3, 5)
	immutable_list_2 = ImmutableList.of(2, 3, 5)
	immutable_list_3 = ImmutableList.of(2, 3, 4, 5)
	immutable_list_4 = ImmutableList.of(1, 2, 3, 4)
	immutable_list_5 = ImmutableList.of(1, 2, 3, 4, 5, 6)
	assert ImmutableList.empty().filter(lambda n: n == 4) == ImmutableList.empty()
	assert immutable_list_0.filter(lambda n: n < 2) == ImmutableList.empty()
	assert immutable_list_1.filter(lambda n: n > 2) == Imm

# Generated at 2022-06-25 23:45:08.416930
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1)
    immutable_list_1 = immutable_list_0.filter(lambda k: k % 2 == 1)
    immutable_list_2 = immutable_list_1.filter(lambda k: k % 2 == 0)
    assert immutable_list_2.head == None
    assert immutable_list_2.tail == None
    assert immutable_list_2.is_empty == True
    assert immutable_list_2.__eq__(ImmutableList.of())
    immutable_list_3 = immutable_list_0.filter(lambda k: k % 2 == 0)
    assert immutable_list_3.head == 0
    assert immutable_list_3.tail.__eq__(ImmutableList.of())
    assert immutable_list_3.is_empty == False

# Generated at 2022-06-25 23:45:13.460658
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    immutable_list_0 = ImmutableList.of(12, "some random text", 'A', "some random text", 12)
    # Act
    result = immutable_list_0.find(lambda x : isinstance(x, (int, float)))
    # Assert
    assert result == 12, "result should be equal to 12"



# Generated at 2022-06-25 23:45:13.986712
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    pass


# Generated at 2022-06-25 23:45:21.513911
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.find(lambda x: x) is None
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4)
    assert immutable_list_1.find(lambda x: x == 0) is None
    assert immutable_list_1.find(lambda x: x == 3) == 3
    assert immutable_list_1.find(lambda x: x == 4) == 4
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4)
    assert immutable_list_2.find(lambda x: x == 0) is None
    assert immutable_list_2.find(lambda x: x == 3) == 3
    assert immutable_list_2.find(lambda x: x == 4) == 4
    immutable_

# Generated at 2022-06-25 23:45:31.156394
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    try:
        ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3, 4)
        raise Exception('AssertionError not thrown')
    except AssertionError:
        pass
    try:
        ImmutableList.of(1, 2) == ImmutableList.of(1, 2, 3)
        raise Exception('AssertionError not thrown')
    except AssertionError:
        pass
    try:
        ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
        pass
    except AssertionError:
        raise Exception('unexpected AssertionError')


# Generated at 2022-06-25 23:45:38.592783
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(
        (
            (
                'book',
                'book'
            ),
            (
                'book',
                'book'
            ),
            (
                'book',
                'book'
            )
        ))
    immutable_list_0 = immutable_list_0.filter(lambda item: lambda: item[1] == 'pen')
    my_find = immutable_list_0.find(lambda item: lambda: item[1] == 'pen')
    assert my_find == (
        'book',
        'book'
    )

# Generated at 2022-06-25 23:45:45.003739
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(True)
    immutable_list_1 = ImmutableList(bool)
    immutable_list_2 = ImmutableList(int)
    immutable_list_3 = ImmutableList(int)
    immutable_list_4 = ImmutableList(int)
    immutable_list_5 = ImmutableList(int)
    immutable_list_6 = ImmutableList(int)
    immutable_list_7 = ImmutableList(int)
    immutable_list_8 = ImmutableList(int)
    immutable_list_9 = ImmutableList(int)
    str_0 = immutable_list_0.find(lambda immutable_list_0: immutable_list_0 == True)
    str_1 = immutable_list_1.find(lambda immutable_list_1: immutable_list_1 == bool)
   

# Generated at 2022-06-25 23:45:49.613551
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2)
    immutable_list_1 = immutable_list_0.filter(lambda x : x % 2 ==0)

    assert immutable_list_1 == ImmutableList.of(2)


# Generated at 2022-06-25 23:45:59.552922
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_1)
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0.__eq__(immutable_list_1)
    immutable_list_0 = ImmutableList(0.0)
    immutable_list_1 = ImmutableList(0.0)
    assert immutable_list_0.__eq__(immutable_list_1)
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)

# Generated at 2022-06-25 23:46:23.353567
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case 0
    immutable_list_0 = ImmutableList()
    def _predicate_0(element: int) -> bool:
        return element < 0
    immutable_list_1 = immutable_list_0.filter(_predicate_0)
    assert immutable_list_1.is_empty is True
    # Case 1
    immutable_list_2 = ImmutableList(2)
    def _predicate_1(element: int) -> bool:
        return element < 0
    immutable_list_3 = immutable_list_2.filter(_predicate_1)
    assert immutable_list_3.is_empty is True
    # Case 2
    immutable_list_4 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    def _predicate_2(element: int) -> bool:
        return

# Generated at 2022-06-25 23:46:32.251134
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_1 = ImmutableList.of(1, 3, 5)
    # Test cases for method filter
    assert immutable_list_0.filter(lambda x: x % 2 == 0) != immutable_list_0
    assert immutable_list_0.filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert immutable_list_0.filter(lambda x: x % 2 == 1) != immutable_list_1
    assert immutable_list_0.filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]


# Generated at 2022-06-25 23:46:35.096088
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(2, 3)
    assert immutable_list_0.find(lambda x: x > 1) == 2


# Generated at 2022-06-25 23:46:36.148947
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    pass



# Generated at 2022-06-25 23:46:42.032662
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(None)
    x_0 = immutable_list_0.find(None)
    print("Test #0")
    print("x_0: ", x_0)

    immutable_list_1 = ImmutableList("")
    x_1 = immutable_list_1.find("")
    print("Test #1")
    print("x_1: ", x_1)
    print()


# Generated at 2022-06-25 23:46:46.231766
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # initializing arguments for method find of class ImmutableList
    arg_fn = lambda a: True
    result = ImmutableList.of(1, 2, 3).find(arg_fn)
    expected_result = 1
    assert result == expected_result


# Generated at 2022-06-25 23:46:53.855116
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = immutable_list_0.filter(lambda x: x == 1)
    assert immutable_list_1.is_empty == True
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 != 0)
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail.head == 3
    assert immutable_list_1.tail.tail.head == 5
    assert immutable_list_1.tail.tail.tail.is_empty == True
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-25 23:47:05.242453
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_2 = ImmutableList(0)
    immutable_list_4 = ImmutableList()
    immutable_list_4 = ImmutableList(0)
    immutable_list_2 = immutable_list_2.append(1)
    immutable_list_3 = immutable_list_2.filter(lambda x: x == 0)
    assert immutable_list_4 == immutable_list_3
    immutable_list_2 = ImmutableList(0)
    immutable_list_4 = ImmutableList()
    immutable_list_4 = ImmutableList(1)
    immutable_list_2 = immutable_list_2.append(1)
    immutable_list_3 = immutable_list_2.filter(lambda x: x == 1)

# Generated at 2022-06-25 23:47:17.979624
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append('hello')
    immutable_list_1 = immutable_list_1.append('world')
    immutable_list_1 = immutable_list_1.append('!')
    immutable_list_2 = ImmutableList()
    immutable_list_2 = immutable_list_2.append('hello')
    immutable_list_2 = immutable_list_2.append('world')
    immutable_list_2 = immutable_list_2.append('!')
    immutable_list_3 = ImmutableList()
    immutable_list_3 = immutable_list_3.append('hello')
    immutable_list_3 = immutable_list_3.append('world')

# Generated at 2022-06-25 23:47:29.190536
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.unshift(5.0)
    immutable_list_0 = immutable_list_0.append(5.0)
    immutable_list_0 = immutable_list_0.append(immutable_list_1)
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(immutable_list_1)
    immutable_list_0 = immutable_list_0.append(immutable_list_1)
    immutable_list_0 = immutable_list_0.append(immutable_list_1)
    immutable_list_0 = immutable_list_0.append(immutable_list_1)
   

# Generated at 2022-06-25 23:47:56.889416
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(5, 10)
    ImmutableList.filter(immutable_list_0, lambda x: (x > 3))
    ImmutableList.filter(immutable_list_0, lambda x: (x == 3))
    ImmutableList.filter(immutable_list_0, lambda x: (x < 30))
    ImmutableList.filter(immutable_list_0, lambda x: (x == 5))
    ImmutableList.filter(immutable_list_0, lambda x: (x == 10))
    ImmutableList.filter(immutable_list_0, lambda x: (x == None))


# Generated at 2022-06-25 23:48:02.066081
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert immutable_list_0.find(lambda i: i > 2) == 3


# Generated at 2022-06-25 23:48:11.733321
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList.of(False, None, True, False, True, "", "", "", "", "", "", "", "")
    immutable_list_3 = ImmutableList.of(False, None, True, False, True, "", "", "", "", "", "", "", "")
    immutable_list_4 = ImmutableList.of(False, None, True, False, True, "", "", "", "", "", "", "", "")
    immutable_list_5 = ImmutableList.of(False, None, True, False, True, "", "", "", "", "", "", "", "")

# Generated at 2022-06-25 23:48:21.471014
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Try to call find on empty ImmutableList
    try:
        ImmutableList().find((lambda value: True))
        raise ValueError('ImmutableList: for find method it is not allowed to call it on empty instance')
    except ValueError as err:
        pass

    # Try to call find for None value
    try:
        ImmutableList.of(None).find((lambda value: True))
        raise ValueError('ImmutableList: for find method input value can not be None')
    except ValueError as err:
        pass

    # Try to call find with None as argument
    try:
        ImmutableList.of(1).find(None)
        raise ValueError('ImmutableList: for find method mapper function must be callable')
    except ValueError as err:
        pass

    # Try to call find with None as argument
   

# Generated at 2022-06-25 23:48:26.152575
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 4, 5, 6)

    immutables_list_result = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert isinstance(immutables_list_result, ImmutableList)
    assert immutables_list_result == ImmutableList.of(2, 4, 6), 'ImmutableList filter test failed'


# Generated at 2022-06-25 23:48:28.907451
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.filter(lambda x: x is None)
    immutable_list_0 = immutable_list_0.filter(lambda x: None is x)
    immutable_list_0 = immutable_list_0.filter(lambda x: True)


# Generated at 2022-06-25 23:48:38.053315
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 2
    immutable_list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    def test_fn_2(x_0):
        if x_0 == 2:
            return True
        return False
    test_ImmutableList_filter_2 = immutable_list_2.filter(test_fn_2)
    assert test_ImmutableList_filter_2 == ImmutableList(2, ImmutableList(is_empty=True))

    # Test case 3
    immutable_list_3 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    def test_fn_3(x_0):
        if x_0 == 20:
            return

# Generated at 2022-06-25 23:48:45.952552
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    
    # Case 0: list with one element
    list_0 = ImmutableList.of(0)
    first_element = list_0.find(lambda x: x == 0)
    assert first_element == 0

    # Case 1: list with multiple elements
    list_1 = ImmutableList.of(0, 1, 2, 3)
    second_element = list_1.find(lambda x: x == 1)
    assert second_element == 1

    # Case 2: empty list
    list_2 = ImmutableList.empty()
    msg = "your find method must return None if no element was found"
    assert list_2.find(lambda x: x == 0) is None, msg

# Generated at 2022-06-25 23:48:49.295616
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0 == immutable_list_0
    immutable_list_1 = ImmutableList()
    assert immutable_list_1 == immutable_list_1


# Generated at 2022-06-25 23:48:58.667973
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(8)
    immutable_list_2 = ImmutableList(11, immutable_list_1)
    immutable_list_2 = immutable_list_2.append(12)
    immutable_list_2 = immutable_list_2.append(11)
    immutable_list_3 = ImmutableList(11, immutable_list_2)
    immutable_list_3 = immutable_list_3.append(11)
    immutable_list_3 = immutable_list_3.append(9)
    immutable_list_4 = ImmutableList(7, immutable_list_1)
    immutable_list_4 = immutable_list_4.append(7)
    immutable_list_2 = immutable_list_2.append(7)
    immutable_list_

# Generated at 2022-06-25 23:49:53.173553
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(-2599, -43, 20, 1, -4)
    immutable_list_1 = ImmutableList.of(-59, -25)
    immutable_list_0.filter(lambda element: element > (-2599))
    immutable_list_1.filter(lambda element: element < 1)

    assert immutable_list_0 == ImmutableList.of(-43, 20, 1)
    assert immutable_list_1 == ImmutableList.empty()


# Generated at 2022-06-25 23:50:04.448457
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
        assert ImmutableList.empty() == ImmutableList.empty()
        assert ImmutableList.of(1).__eq__(ImmutableList.of(1))
        assert ImmutableList.of(1, 2, 3).__eq__(ImmutableList.of(1, 2, 3))
        assert ImmutableList.of(1, 2, 3).__eq__(ImmutableList.of(1, 2, 3, 4)) == False
        assert ImmutableList.of(1, 2, 3).__eq__(ImmutableList.of(1, 2, 3, 4)) == False


# Generated at 2022-06-25 23:50:15.414152
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(3,4,5,6)
    immutable_list_1 = immutable_list_0.filter(lambda x: x >= 3)
    immutable_list_2 = immutable_list_0.filter(lambda x: x >= 5)
    immutable_list_3 = immutable_list_0.filter(lambda x: x >= 6)

    assert len(immutable_list_1) == 4
    assert immutable_list_1.to_list() == [3,4,5,6]
    assert len(immutable_list_2) == 2
    assert immutable_list_2.to_list() == [5,6]
    assert len(immutable_list_3) == 1
    assert immutable_list_3.to_list() == [6]



# Generated at 2022-06-25 23:50:25.482803
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('Garancija', 'Servis', 'Servis', 'Servis')
    immutable_list_1 = immutable_list_0.filter(lambda word: word.length() <= 6)
    assert immutable_list_1 == ImmutableList.of('Garancija')
    immutable_list_1 = immutable_list_0.filter(lambda word: len(word) <= 6)
    assert immutable_list_1 == ImmutableList.of('Garancija')
    immutable_list_1 = immutable_list_0.filter(lambda word: word == 'Servis')
    assert immutable_list_1 == ImmutableList.of('Servis', 'Servis', 'Servis')