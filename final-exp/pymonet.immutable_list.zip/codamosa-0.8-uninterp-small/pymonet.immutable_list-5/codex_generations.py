

# Generated at 2022-06-25 23:40:31.275043
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(1.0)

    assert immutable_list_0 == immutable_list_0


# Generated at 2022-06-25 23:40:34.808714
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('A', 'B', 'C')
    immutable_list_1 = immutable_list_0.filter(lambda x: x == 'A')
    assert immutable_list_1 == ImmutableList.of('A')


# Generated at 2022-06-25 23:40:45.502064
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    Test for method find with argument fn of class ImmutableList
    """
    # example 1
    immutable_list_2 = ImmutableList.of(1)
    def fn_1(x):
        return x >= 2
    result_2 = immutable_list_2.find(fn_1)
    assert result_2 is None
    result_3 = immutable_list_2.__str__()
    assert result_3 == 'ImmutableList[1]'
    # example 2
    immutable_list_3 = ImmutableList.of(1)
    def fn_2(x):
        return x == 1
    result_4 = immutable_list_3.find(fn_2)
    assert result_4 == 1
    result_5 = immutable_list_3.__str__()

# Generated at 2022-06-25 23:40:49.151992
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Set up test data
    immutable_list_0 = ImmutableList.of(None)
    def fn(x):
        return x is not None
    # Invoke method
    result = immutable_list_0.find(fn)
    # Retrieve and compare results
    assert result is None


# Generated at 2022-06-25 23:40:58.874464
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None)
    immutable_list_2 = ImmutableList(None)
    immutable_list_3 = ImmutableList(None)
    bool_0 = immutable_list_2.__eq__(immutable_list_3)
    bool_1 = immutable_list_0.__eq__(immutable_list_1)
    bool_2 = immutable_list_3.__eq__(immutable_list_1)
    bool_3 = immutable_list_1.__eq__(immutable_list_2)
    bool_4 = immutable_list_0.__eq__(immutable_list_2)
    bool_5 = immutable_list_1.__eq__(immutable_list_3)
    bool_6 = immutable_

# Generated at 2022-06-25 23:41:02.236083
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_0.__eq__(immutable_list_1)


# Generated at 2022-06-25 23:41:04.200751
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1)
    immutable_list_0.find(None)


# Generated at 2022-06-25 23:41:08.893441
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Setup
    test_list_0 = ImmutableList.of(2, 3, 1, 9)
    expected_list_0 = ImmutableList.of(1, 9)

    # Exercise
    actual_list_0 = test_list_0.filter(lambda x: x > 1)

    # Verify
    assert actual_list_0 == expected_list_0


# Generated at 2022-06-25 23:41:13.412872
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0.0, 0.0, 0.0)
    immutable_list_1 = immutable_list_0.filter((lambda x: (not (x <= (1.0 / (1.0 + math.exp(((math.pow((-5), 2.0) / (1.0 + (math.pow((-5), 2.0)))) - (-4))) / (1.0 + (math.pow((-5), 2.0)))))))))


# Generated at 2022-06-25 23:41:17.614347
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = immutable_list_0.filter(ImmutableList.filter)
    assert immutable_list_1.tail.tail is not None
    assert int(immutable_list_1.tail.tail.head) == 3


# Generated at 2022-06-25 23:41:23.038419
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert 0 == 0


# Generated at 2022-06-25 23:41:25.580237
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1).to_list() == [2, 3]


# Generated at 2022-06-25 23:41:34.398317
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_0 = ImmutableList.empty()
    list_1 = ImmutableList.of(0 )
    list_2 = ImmutableList.of(1 )
    list_3 = ImmutableList.of(2 )
    list_4 = ImmutableList.of(3 )
    list_5 = ImmutableList.of(4 )
    list_6 = ImmutableList.of(5 )
    list_7 = ImmutableList.of(0 , 1 , 2 , 3 , 4 , 5 )
    list_8 = ImmutableList.of(1 , 2 , 3 , 4 , 5 )
    list_9 = ImmutableList.of(0 )
    list_10 = ImmutableList.of(2 , 3 , 4 , 5 )
    
    f = lambda x: x % 2 == 0

# Generated at 2022-06-25 23:41:38.300590
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    val_0 = ImmutableList(None, None, True)
    val_1 = ImmutableList(None, None, True)
    res_0 = val_0 == val_1
    assert res_0 == True


# Generated at 2022-06-25 23:41:42.740807
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    var_0 = ImmutableList.of("Test 1", "Test 2", "Test 3", "Test 4", "Test 5")
    var_1 = var_0.filter(lambda a: a == "Test 1")
    var_2 = ImmutableList.of("Test 1")
    assert var_1 == var_2


# Generated at 2022-06-25 23:41:46.612497
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    var_0 = ImmutableList.of(12, 37, 18, 41, 36, 59, 48, 12, 24, 21)
    var_1 = var_0.filter(lambda var_2: var_2 > 40)
    assert var_1 == ImmutableList(41, 48, 59)


# Generated at 2022-06-25 23:41:53.722103
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    # Test if works with empty list
    assert ImmutableList.empty().find(lambda x: True) is None

    # Test if works with list with only one element
    head = 5
    assert ImmutableList.of(head).find(lambda x: True) == head

    # Test if works with list with more elements
    head, tail = 1, ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(head, *tail).find(lambda x: x == 3) == 3



# Generated at 2022-06-25 23:41:57.393340
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print('Testing ImmutableList.filter')
    var_0 = ImmutableList.of(1, 2, 3)
    var_1 = var_0.filter(lambda x: x)
    assert var_1 == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-25 23:42:08.071843
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # fun should be identity function
    fun = lambda x: x

    list_a = ImmutableList.of(1, 2, 3)
    assert list_a.find(fun) == 1

    # find element in empty list
    list_b = ImmutableList.empty()
    assert list_b.find(fun) == None

    # find elements on the middle of list
    list_c = ImmutableList.of(1, 3, 5)
    assert list_c.find(lambda x: x == 3) == 3

    # find elements on the end of list
    list_d = ImmutableList.of(1, 2, 3)
    assert list_d.find(lambda x: x == 3) == 3


# Generated at 2022-06-25 23:42:13.701822
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    global var_0
    var_0 = ImmutableList[int](0, ImmutableList[int](1, ImmutableList[int](2)))
    var_1 = var_0.filter(lambda e: e % 2)
    var_2 = var_1 == ImmutableList[int](1)
    assert var_2, var_2


# Generated at 2022-06-25 23:42:22.542075
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 5)
    int_0 = immutable_list_0.find(lambda maybe_0: maybe_0 == 1)
    int_1 = immutable_list_0.find(lambda maybe_0: maybe_0 == 4)
    assert int_0 == 1
    assert int_1 is None


# Generated at 2022-06-25 23:42:33.578412
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2, 3, 4)
    bool_0 = (immutable_list_0.filter((lambda var_0: (var_0 <= 2))) == ImmutableList.of(3, 4))
    immutable_list_1 = ImmutableList.of(2, 3, 4)
    bool_1 = (immutable_list_1.filter((lambda var_1: (var_1 >= 2))) == ImmutableList.of(2, 3, 4))
    immutable_list_2 = ImmutableList.of(1, 2, 3, 0)
    bool_2 = (immutable_list_2.filter((lambda var_2: (var_2 < 0))) == ImmutableList.of(1, 2, 3, 0))

# Generated at 2022-06-25 23:42:38.206114
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    result_0 = immutable_list_0.find(lambda x: x)
    assert result_0 == None, "expected None"

    immutable_list_1 = ImmutableList.of(1, 2, 3)
    result_1 = immutable_list_1.find(lambda x: x % 2 == 1)
    assert result_1 == 1, "expected 1"



# Generated at 2022-06-25 23:42:42.757888
# Unit test for method find of class ImmutableList

# Generated at 2022-06-25 23:42:46.103563
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = immutable_list_0.filter(lambda x:x < 2)



# Generated at 2022-06-25 23:42:56.357845
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case with empty ImmutableList
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)
    immutable_list_2 = ImmutableList()
    assert immutable_list_1 == immutable_list_2
    # Test case with one element
    immutable_list_3 = ImmutableList(8)
    immutable_list_4 = immutable_list_3.filter(lambda x: x % 2 == 0)
    immutable_list_5 = ImmutableList(8)
    assert immutable_list_4 == immutable_list_5
    immutable_list_6 = immutable_list_3.filter(lambda x: x % 2 == 1)
    immutable_list_7 = ImmutableList()
    assert immutable_list_6 == immutable_list_7


# Generated at 2022-06-25 23:43:03.354552
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(122)
    immutable_list_0 = immutable_list_0.append(398)
    immutable_list_0 = immutable_list_0.append(18)
    immutable_list_0 = immutable_list_0.append(98)
    immutable_list_0 = immutable_list_0.append(127)
    bool_0 = True
    immutable_list_0 = immutable_list_0.append(bool_0)
    immutable_list_0 = immutable_list_0.append(127)
    immutable_list_0 = immutable_list_0.append(304)
    immutable_list_0 = immutable_list_0.append(126)

# Generated at 2022-06-25 23:43:05.824348
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    str_0 = immutable_list_0.__str__()


# Generated at 2022-06-25 23:43:15.458784
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList.of(0)
    bool_0 = immutable_list_0.__eq__(immutable_list_1)
    immutable_list_2 = ImmutableList.of(0, 1, 2)
    immutable_list_3 = ImmutableList.of(0, 1, 2)
    bool_1 = immutable_list_2.__eq__(immutable_list_3)
    immutable_list_4 = ImmutableList.of("")
    bool_2 = immutable_list_2.__eq__(immutable_list_4)
    bool_3 = immutable_list_4.__eq__(immutable_list_3)
    immutable_list_5 = ImmutableList.empty()
    immutable_list_6

# Generated at 2022-06-25 23:43:19.890023
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    str_0 = immutable_list_0.__str__()

    list_0 = ImmutableList.of(1, 2, 3)

    assert list_0.find(lambda x: x < 2).__eq__(1)
    assert list_0.find(lambda x: x < 1) is None


# Generated at 2022-06-25 23:43:31.288917
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda fn: fn > 2)
    str_0 = immutable_list_1.__str__()


# Generated at 2022-06-25 23:43:34.915616
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    tester_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    assert tester_list.find(lambda x: x == 3) == 3



# Generated at 2022-06-25 23:43:39.653216
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    for i in range(1000):
        list_0 = [None, None, None]
        immutable_list_0 = ImmutableList.of(list_0[0], list_0[1], list_0[2])
        obj_0 = immutable_list_0.find(lambda l : l is not None)



# Generated at 2022-06-25 23:43:46.906617
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList.of(1)
    find_0 = immutable_list_1.find(lambda x : x > 1)
    assert find_0 == None
    immutable_list_2 = ImmutableList.of(1)
    find_1 = immutable_list_2.find(lambda x : x < 1)
    assert find_1 == None
    immutable_list_3 = ImmutableList.of(1)
    find_2 = immutable_list_3.find(lambda x : x == 1)
    assert find_2 == 1
    immutable_list_4 = ImmutableList.of(1, 2)
    find_3 = immutable_list_4.find(lambda x : x > 2)
    assert find_3 == None
    immutable_list_5 = ImmutableList.of(1, 2)

# Generated at 2022-06-25 23:43:58.188153
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(23, 34, 45, 56, 67, 78, 89)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)
    str_0 = immutable_list_1.__str__()
    str_1 = immutable_list_1.__add__(ImmutableList()).__str__()
    str_2 = immutable_list_1.__add__(ImmutableList()).__add__(ImmutableList.of(23, 34, 45, 56, 67, 78, 89)).__str__()
    str_3 = immutable_list_0.__add__(immutable_list_1).__str__()

# Generated at 2022-06-25 23:44:07.520073
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2, 3)
    immutable_list_1 = immutable_list_0.filter(ImmutableList.of(2, 3))
    immutable_list_0 = ImmutableList.of(2, 3)
    immutable_list_2 = immutable_list_0.filter(ImmutableList.of(2, 3))
    assert immutable_list_1.head == immutable_list_2.head
    assert immutable_list_1.tail.head == immutable_list_2.tail.head
    immutable_list_0 = ImmutableList.of(3, '3')
    immutable_list_1 = immutable_list_0.filter(ImmutableList.of(2, 3))
    immutable_list_0 = ImmutableList.of(3, '3')

# Generated at 2022-06-25 23:44:17.541098
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda x: True)
    assert immutable_list_1.__eq__(ImmutableList(is_empty=True))
    immutable_list_2 = ImmutableList()
    immutable_list_3 = immutable_list_2.filter(lambda x: False)
    assert immutable_list_3.__eq__(ImmutableList(is_empty=True))
    immutable_list_4 = ImmutableList.of(1)
    immutable_list_5 = immutable_list_4.filter(lambda x: True)
    assert immutable_list_5.__eq__(ImmutableList(1))
    immutable_list_6 = ImmutableList.of(1)

# Generated at 2022-06-25 23:44:23.982454
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    actual_result = ImmutableList.of(0, 1, 2, 3, 4, 5).filter(lambda number: number == 3)
    expected_result = ImmutableList.of(3)
    assert actual_result == expected_result

    actual_result = ImmutableList.of(0, 1, 2, 3, 4, 5).filter(lambda number: number > 3)
    expected_result = ImmutableList.of(4, 5)
    assert actual_result == expected_result


# Generated at 2022-06-25 23:44:33.248985
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    str_0 = immutable_list_0.__str__()
    fn_0 = lambda x : x < 10
    int_0 = immutable_list_0.find(fn_0)
    immutable_list_1 = ImmutableList(1)
    fn_1 = lambda x : x < 10
    int_1 = immutable_list_1.find(fn_1)
    immutable_list_2 = ImmutableList(3)
    fn_2 = lambda x : x < 10
    int_2 = immutable_list_2.find(fn_2)
    immutable_list_3 = ImmutableList(5)
    fn_3 = lambda x : x < 10
    int_3 = immutable_list_3.find(fn_3)
    immutable_list_4 = Immutable

# Generated at 2022-06-25 23:44:42.947703
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(4, ImmutableList(1, ImmutableList(2, ImmutableList(1, ImmutableList(4))))).find(lambda x: x > 2) == 4
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(0, ImmutableList(2, ImmutableList(0, ImmutableList(0, ImmutableList(0, ImmutableList(1, ImmutableList(0, ImmutableList(2, ImmutableList(1, ImmutableList(0, ImmutableList(1))))))))))))))).find(lambda x: x == 0) == 0

# Generated at 2022-06-25 23:45:01.520187
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(5)
    immutable_list_1 = ImmutableList(5)
    bool_0 = immutable_list_0.__eq__(immutable_list_1)
    assert bool_0 == True



# Generated at 2022-06-25 23:45:06.425970
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(None)
    
    immutable_list_expected = ImmutableList(None)

    immutable_list_result = immutable_list_0.filter(lambda c: c is not None)
    
    assert immutable_list_expected.__eq__(immutable_list_result) == True


# Generated at 2022-06-25 23:45:16.786426
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(ImmutableList.empty(), ImmutableList.empty(), True)
    immutable_list_0 = immutable_list_0.filter(lambda arg0 : arg0 is None)
    immutable_list_0 = immutable_list_0.filter(lambda arg0 : arg0 is not None)
    immutable_list_0 = immutable_list_0.filter(lambda x : x == 3)
    immutable_list_0 = immutable_list_0.filter(lambda x : x != 0)
    immutable_list_0 = ImmutableList.of(34, 8, 21, 9)
    immutable_list_0 = immutable_list_0.filter(lambda x : x == 0)
    immutable_list_0 = immutable_list_0.filter(lambda x : x != 42)
    immutable_list_0 = immutable

# Generated at 2022-06-25 23:45:20.487621
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1)
    def fn_0(immutable_list_0: int, immutable_list_1: int) -> int:
        str_0 = immutable_list_0 + immutable_list_1
        return str_0
    immutable_list_1 = immutable_list_0.filter(fn_0)
    assert immutable_list_1.head == 1


# Generated at 2022-06-25 23:45:31.411086
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_args = [[0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20], [1, 3, 5, 7, 9, 11, 13, 15, 17, 19], [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20], [], [0]]
    ImmutableList.of(list_args[0][0], *list_args[0][1:]).filter(lambda x: x % 2 == 0)
    ImmutableList.of(list_args[1][0], *list_args[1][1:]).filter(lambda x: x % 2 == 0)
    ImmutableList.of(list_args[2][0], *list_args[2][1:]).filter(lambda x: x % 2 == 0)

# Generated at 2022-06-25 23:45:34.687709
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1.is_empty = True
    assert not immutable_list_1.__eq__(immutable_list_0)


# Generated at 2022-06-25 23:45:38.623728
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('1', '2', '3')

    immutable_list_0 = immutable_list_0.filter(lambda x: x == '3')

    assert len(immutable_list_0) == 1
    assert immutable_list_0.head == '3'



# Generated at 2022-06-25 23:45:45.430928
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    immutable_list_2 = ImmutableList.of(0, 1, 2, 3, 4)
    immutable_list_1.filter(lambda x: x % 2 == 0)
    immutable_list_2.filter(lambda x: x % 2 == 0)
    immutable_list_2.filter(lambda x: x > 0)
    immutable_list_0.filter(lambda x: x in immutable_list_1.to_list())


# Generated at 2022-06-25 23:45:50.454040
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-25 23:45:55.086608
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Prepare
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    fn = lambda x: x > 1
    immutable_list_1 = immutable_list_0.filter(fn)
    # Assert
    assert immutable_list_1 == ImmutableList.of(2, 3)


# Generated at 2022-06-25 23:46:30.216042
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(3)
    immutable_list_0 = immutable_list_0.append(1)
    def fn_0(value_0):
        return value_0 < 2
    immutable_list_1 = immutable_list_0.filter(fn_0)
    assert immutable_list_1.__eq__(ImmutableList.of(1))


# Generated at 2022-06-25 23:46:32.405828
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_0 = ImmutableList(1, ImmutableList(1), ImmutableList(1))
    list_1 = list_0.filter(lambda x: x == 1)
    assert list_1 == ImmutableList(1, ImmutableList(1), ImmutableList(1))


# Generated at 2022-06-25 23:46:37.765481
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = ImmutableList(immutable_list_0)
    immutable_list_2 = ImmutableList(immutable_list_1)
    boolean_0 = immutable_list_2.find(lambda x: x == immutable_list_1)
    assert boolean_0 is immutable_list_1


# Generated at 2022-06-25 23:46:43.121653
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Init of the arguments
    list_0 = ImmutableList.of(None)
    # Call of the method
    try:
        value_1 = list_0.find(lambda x: x)
    except Exception as e:
        value_1 = str(e)
    # Asserting the returned value
    assert value_1 == None
    

# Generated at 2022-06-25 23:46:45.473823
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    int_0 = immutable_list_0.find( lambda v: True)


# Generated at 2022-06-25 23:46:49.038479
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0.__init__(None, None, False)
    int_0 = immutable_list_0.find(lambda immutable_list_0: immutable_list_0 is not None)
    assert isinstance(int_0, int)

# Generated at 2022-06-25 23:46:51.692370
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def fn_0(item):
        return item <= 3
    immutable_list_0 = ImmutableList(1, ImmutableList(2), ImmutableList(4))
    immutable_list_0.filter(fn_0)


# Generated at 2022-06-25 23:46:57.440490
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    str = immutable_list.find(lambda x: x == 4)
    assert str == 4
    str = immutable_list.find(lambda x: x == 2)
    assert str == 2
    str = immutable_list.find(lambda x: x == 6)
    assert str is None


# Generated at 2022-06-25 23:47:09.395142
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2)
    immutable_list_1 = immutable_list_0.filter(lambda x: x != 1)
    int_0 = immutable_list_1.__len__()
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_3 = immutable_list_2.filter(lambda x: x != 1 or x != 2 or x != 3 or x != 4)
    int_1 = immutable_list_3.__len__()
    immutable_list_4 = immutable_list_2.filter(lambda x: x != 1 or x != 2)
    int_2 = immutable_list_4.__len__()
    int_3 = immutable_list_3.__len__()
    immutable_list_5 = ImmutableList.of

# Generated at 2022-06-25 23:47:13.116216
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList.of("", "")
    callable_0 = lambda _: True
    immutable_list_1 = immutable_list_0.filter(callable_0)


# Generated at 2022-06-25 23:48:19.956313
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Set up test
    immutable_list_0 = ImmutableList(1)
    def function_0(value_0: None) -> bool:
        return value_0 > 0

    # Execute method against test
    rv = immutable_list_0.filter(function_0)

    # Validate test
    assert isinstance(rv, ImmutableList) == True
    assert rv.head == 1
    assert rv.tail == None
    assert rv.is_empty == False


# Generated at 2022-06-25 23:48:28.417826
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    str_0 = immutable_list_0.__str__()
    # Assert.expect(Compare.equals(str_0, "ImmutableList[]"))
    immutable_list_1 = ImmutableList((1 - 1), is_empty=1)
    str_1 = immutable_list_1.__str__()
    # Assert.expect(Compare.equals(str_1, "ImmutableList[]"))
    # Assert.expect(Compare.equals(immutable_list_1.is_empty, 1))
    immutable_list_2 = ImmutableList(1 + 1)
    # Assert.expect(Compare.equals(immutable_list_2.is_empty, 1))

# Generated at 2022-06-25 23:48:37.579164
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_2 = immutable_list_0.filter(lambda arg0: arg0)
    immutable_list_3 = immutable_list_0.filter(lambda arg0: arg0)
    assert immutable_list_2.is_empty
    assert immutable_list_3.is_empty
    immutable_list_6 = ImmutableList(True)
    immutable_list_8 = immutable_list_6.filter(lambda arg0: arg0)
    immutable_list_9 = immutable_list_6.filter(lambda arg0: arg0)
    assert immutable_list_8.head
    assert immutable_list_9.head
    immutable_list_12 = ImmutableList(True, ImmutableList(False))

# Generated at 2022-06-25 23:48:46.731010
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x % 2 == 0).to_list() == []
    assert ImmutableList.of(2, 3, 4, 6, 7, 8, 10).filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6, 8, 10]
    assert ImmutableList.of(2, 3, 4, 6, 7, 8, 10).filter(lambda x: x % 2 == 0).filter(lambda x: isinstance(x, int)).to_list() == [2, 4, 6, 8, 10]
    assert ImmutableList.of('abc', 2, 3, 4, 6, 7, 8, 10).filter(lambda x: isinstance(x, int)).to_list() == [2, 3, 4, 6, 7, 8, 10]

# Generated at 2022-06-25 23:48:50.635384
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 2)
    assert immutable_list_1.__eq__(ImmutableList.of(3, 4))


# Generated at 2022-06-25 23:48:59.949466
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1.head = 'x'
    immutable_list_1.tail = immutable_list_0
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = 'a'
    immutable_list_2.tail = immutable_list_1

    def test_function_1(x):
        return x == 'z'

    immutable_list_3 = immutable_list_2.filter(test_function_1)
    immutable_list_4 = ImmutableList()
    immutable_list_4.head = 'x'
    immutable_list_4.tail = immutable_list_0

    assert(immutable_list_3 == immutable_list_4)


# Generated at 2022-06-25 23:49:02.454959
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    str_0 = immutable_list_0.find(lambda bool_0: bool_0)
    assert str_0 is None


# Generated at 2022-06-25 23:49:08.014691
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(2, 3)
    bool_0 = immutable_list_0.find(lambda x: x == 4) is None
    bool_1 = immutable_list_0.find(lambda x: x == 3) is None
    bool_2 = immutable_list_0.find(lambda x: x == 2) is None
    bool_3 = immutable_list_0.find(lambda x: x == 0) is None


# Generated at 2022-06-25 23:49:18.342976
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0 == ()
    assert immutable_list_0 == immutable_list_0
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList()
    assert immutable_list_1 == immutable_list_2
    assert immutable_list_2 == immutable_list_1
    assert immutable_list_2 == immutable_list_0
    assert immutable_list_1 == immutable_list_0
    immutable_list_2 = ImmutableList(3)
    assert immutable_list_2 != ImmutableList()
    assert immutable_list_2 != immutable_list_0
    assert immutable_list_2 != immutable_list_1
    immutable_list_3 = ImmutableList(3)


# Generated at 2022-06-25 23:49:25.162831
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    from copy import deepcopy
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    bool_0 = immutable_list_0.__eq__(immutable_list_1)
    assert bool_0 == True

    tmp_immutable_list_0 = deepcopy(immutable_list_0)
    tmp_immutable_list_0.head = ''
    bool_1 = immutable_list_0.__eq__(tmp_immutable_list_0)
    assert bool_1 == False

    immutable_list_2 = ImmutableList()
    immutable_list_2.head = ''
    bool_2 = tmp_immutable_list_0.__eq__(immutable_list_2)
    assert bool_2 == True

    tmp_immutable_list_1 = deepcopy