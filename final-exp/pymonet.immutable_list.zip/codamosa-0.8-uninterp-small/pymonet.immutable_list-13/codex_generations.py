

# Generated at 2022-06-25 23:40:37.949299
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test with empty list
    immutable_list_0 = ImmutableList()
    var_0 = immutable_list_0.filter(lambda x: x < 5).to_list()
    # Test with one element
    immutable_list_1 = ImmutableList(10)
    var_1 = immutable_list_1.filter(lambda x: x < 5).to_list()
    # Test with multiple elements
    immutable_list_2 = ImmutableList(10, ImmutableList(9, ImmutableList(3, ImmutableList(8))))
    var_2 = immutable_list_2.filter(lambda x: x < 5).to_list()
    assert [var_0, var_1, var_2] == [[], [], [3]], 'ImmutableList -> filter : error in filter'


# Generated at 2022-06-25 23:40:45.805478
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11)
    immutable_list_1 = immutable_list_0.filter((lambda x: x % 3 == 0))
    assert immutable_list_1 == ImmutableList.of(0, 3, 6, 9)

    immutable_list_2 = ImmutableList.empty()
    immutable_list_3 = immutable_list_2.filter((lambda x: x % 3 == 0))
    assert immutable_list_3 == immutable_list_2



# Generated at 2022-06-25 23:40:50.755055
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    def func_immutable_list_filter_0(element):
        if element > 5:
            return True

        return False
    immutable_list_1 = immutable_list_0.filter(func_immutable_list_filter_0)
    immutable_list_2 = ImmutableList(6, ImmutableList(7))
    var_0 = immutable_list_1 == immutable_list_2
    immutable_list_3 = immutable_list_1.to_list()
    immutable_list_4 = immutable_list_2.to_list()


# Generated at 2022-06-25 23:40:59.564975
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(5, None, False)
    immutable_list_1 = ImmutableList(5, immutable_list_0, False)
    immutable_list_2 = ImmutableList(5, immutable_list_1, False)
    immutable_list_3 = ImmutableList(5, immutable_list_2, False)
    immutable_list_4 = ImmutableList(5, immutable_list_3, False)
    var_0 = immutable_list_4.find(lambda x: x == 5)
    assert(var_0 == 5)
    var_1 = immutable_list_4.find(lambda x: x == 4)
    assert(var_1 == None)


# Generated at 2022-06-25 23:41:04.178440
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of('lorem')
    immutable_list_2 = ImmutableList.of('ipsum')
    immutable_list_3 = immutable_list_1.__add__(immutable_list_2)
    immutable_list_4 = immutable_list_3.filter(lambda x: True)
    immutable_list_5 = immutable_list_4.filter(lambda x: False)
    assert immutable_list_5.is_empty is True


# Generated at 2022-06-25 23:41:08.162733
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of('foo', 'bar')
    var_0 = immutable_list_0.find(lambda var_0: var_0 == 'foo')
    var_1 = immutable_list_0.find(lambda var_1: var_1 == 'baz')


# Generated at 2022-06-25 23:41:14.613430
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 1
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(92)
    immutable_list_0 = immutable_list_0.append(13)
    immutable_list_0 = immutable_list_0.append(81)
    immutable_list_0 = immutable_list_0.append(81)
    var_0 = immutable_list_0.to_list()
    var_1 = immutable_list_0.filter(lambda x: x != 81)
    var_2 = var_1.to_list()

    # Test case 2
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(39)
    immutable_list_1 = immutable_list_1.append(77)
    immutable_list

# Generated at 2022-06-25 23:41:23.333565
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_1 = ImmutableList()
    assert immutable_list_1.__eq__(immutable_list_1) == True
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = 1
    immutable_list_2.tail = None
    immutable_list_2.is_empty = False
    assert immutable_list_1.__eq__(immutable_list_2) == False
    assert immutable_list_2.__eq__(immutable_list_2) == True
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = 2
    immutable_list_3.tail = None
    immutable_list_3.is_empty = False
    assert immutable_list_2.__eq__(immutable_list_3) == False


# Generated at 2022-06-25 23:41:26.891183
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    var_2 = immutable_list_0.__eq__(immutable_list_1)
    assert var_2 == True


# Generated at 2022-06-25 23:41:30.433173
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    var_0 = immutable_list_0.find( lambda x: x is 4)


# Generated at 2022-06-25 23:41:44.272904
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Empty list
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert immutable_list_1 == ImmutableList(is_empty = True)
    # List with one element
    immutable_list_2 = ImmutableList(1)
    immutable_list_2 = immutable_list_2.filter(lambda x: x % 2 == 0)
    assert immutable_list_2 == ImmutableList(is_empty = True)    
    immutable_list_3 = ImmutableList(2)
    immutable_list_3 = immutable_list_3.filter(lambda x: x % 2 == 0)
    assert immutable_list_3 == ImmutableList(2)   
    # List with odd size
    immutable_list_4 = ImmutableList

# Generated at 2022-06-25 23:41:52.085411
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(3)
    immutable_list_1 = ImmutableList.of(2, 5)
    immutable_list_2 = ImmutableList.of(5, 2)
    immutable_list_3 = ImmutableList.of(2, 3, 4)
    immutable_list_4 = ImmutableList.of(5, 5, 5)
    immutable_list_5 = ImmutableList.of(4, 4, 4, 4)
    immutable_list_6 = ImmutableList.of(3, 3, 3)
    immutable_list_7 = ImmutableList.of(1, 2, 3)
    immutable_list_8 = ImmutableList.of(4, 3, 2, 1)
    immutable_list_9 = ImmutableList.of(7, 6, 5, 4, 4)

# Generated at 2022-06-25 23:41:59.249813
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # case 1 - list is empty
    test_list_0 = ImmutableList.empty()
    assert test_list_0.find(lambda x: True) is None

    # case 2 - list is not empty, but does not contain any of elements that fullfill
    # given function
    test_list_1 = ImmutableList.of(1,2,3)
    assert test_list_1.find(lambda x: x % 2 == 0) == 2

    # case 3 - list is not empty, and contains given element
    test_list_2 = ImmutableList.of(1,2,3,4)
    assert test_list_2.find(lambda x: x % 2 == 0) == 2


# Generated at 2022-06-25 23:42:08.515388
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = ImmutableList.empty()
    immutable_list_3 = ImmutableList.empty()
    immutable_list_3.head = 'py'
    immutable_list_3.tail = immutable_list_2
    immutable_list_3.is_empty = False
    immutable_list_4 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_4.is_empty = False
    immutable_list_5 = ImmutableList.empty()
    immutable_list_6 = immutable_list_4
    assert immutable_list_4 == immutable_list_4, 'test 1'
    assert immutable_list_1 == immutable_list_2, 'test 2'
    assert immutable_

# Generated at 2022-06-25 23:42:19.997755
# Unit test for method find of class ImmutableList
def test_ImmutableList_find(): 
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList().append(10)
    immutable_list_2 = ImmutableList().append(10).append(20)
    immutable_list_3 = ImmutableList().append(10).append(20).append(30)
    immutable_list_4 = ImmutableList().append(10).append(20).append(30).append(40)
    
    
    def lambda0(a0 : int) -> bool:
        return a0 <= 20
    
    def lambda1(a0 : int) -> bool:
        return a0 >= 10
    
    def lambda2(a0 : int) -> bool:
        return a0 < 10
    
    def lambda3(a0 : int) -> bool:
        return a0 <= 40
    

# Generated at 2022-06-25 23:42:31.269568
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList(None, ImmutableList(None, None))
    assert immutable_list_0 != immutable_list_2
    immutable_list_3 = ImmutableList(None, None, True)
    assert immutable_list_0 != immutable_list_3
    immutable_list_4 = ImmutableList(None, None, False)
    assert immutable_list_0 != immutable_list_4
    immutable_list_5 = ImmutableList(True, None, False)
    assert immutable_list_0 != immutable_list_5
    immutable_list_6 = ImmutableList(False, None, False)
    assert immutable_list_0 != immutable_list

# Generated at 2022-06-25 23:42:39.455452
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(2)
    immutable_list_3 = ImmutableList(3)
    immutable_list_4 = ImmutableList(4)

    _list = ImmutableList.of(1, 2, 3, 4, 5)

    # Test case 0
    print(_list.filter(lambda x: x >= 3).to_list())

    # Test case 1
    print(_list.filter(lambda x: x < 0).to_list())

    # Test case 2
    print(_list.filter(lambda x: x <= 5).to_list())

    # Test case 3
    print(_list.filter(lambda x: x == 0).to_list())


# Generated at 2022-06-25 23:42:48.572548
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    assert immutable_list_0 != immutable_list_1

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(-7)
    assert immutable_list_0 != immutable_list_1

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)
   

# Generated at 2022-06-25 23:42:52.522993
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(2, 3, 4)

    assert immutable_list_0.find(lambda x: x >= 4) == 4
    assert immutable_list_0.find(lambda x: x == 6) == None


# Generated at 2022-06-25 23:43:01.670574
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case where list has exactly one element that match filter criteria
    head_0 = ImmutableList(1)
    immutable_list_0 = ImmutableList.of(1, head_0)
    immutable_list_1 = immutable_list_0.filter(lambda x: x == 1)
    assert(immutable_list_1 == ImmutableList.of(1))

    # Case where list has more than one element that match filter criteria
    immutable_list_2 = immutable_list_0.filter(lambda x: x != 2)
    assert(immutable_list_2 == ImmutableList.of(1))

    # Case where list has no elements that match filter criteria
    immutable_list_3 = immutable_list_0.filter(lambda x: x == 2)

# Generated at 2022-06-25 23:43:14.283672
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_0 = ImmutableList[int]()
    list_1 = ImmutableList.of(0)
    list_2 = ImmutableList.of(0, 2, 4, 6, 8)
    list_3 = ImmutableList.of(0, 2, 4, 6, 8)
    list_4 = ImmutableList.of(0, 2, 4, 6, 8)
    list_5 = ImmutableList.of(0, 2, 4, 6, 8)
    list_6 = ImmutableList.of(0, 2, 4, 6, 8)
    list_7 = ImmutableList.of(0, 2, 4, 6, 8)
    list_8 = ImmutableList.of(0, 2, 4, 6, 8)

# Generated at 2022-06-25 23:43:22.996682
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter(): 
    
    # Create list of element to append with [12, 34]
    int_list = ImmutableList.of(1, 2, 3)
    # Create lambda function to filter elements
    int_filter = lambda x: x % 2 == 0
    # Create list of elements to append with ['one', 'two']
    str_list = ImmutableList.of('one', 'two', 'three')
    # Create lambda function to filter elements
    str_filter = lambda x: x == 'one'
    # Create list of element to append with [1.1, 2.2]
    float_list = ImmutableList.of(1.14, 2.22, 3.33)
    # Create lambda function to filter elements
    float_filter = lambda x: x >= 2.0
    assert int_list.filter(int_filter).to_list

# Generated at 2022-06-25 23:43:34.473546
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    filter_fn_0 = ImmutableList()
    filter_fn_1 = ImmutableList()
    filter_fn_2 = ImmutableList()
    filter_fn_3 = ImmutableList()
    filter_fn_4 = ImmutableList()
    filter_fn_5 = ImmutableList()
    filter_fn_6 = ImmutableList(1, 2)
    filter_fn_7 = ImmutableList(2, 2)
    filter_fn_8 = ImmutableList(2, 1)
    filter_fn_9 = ImmutableList(1, 2)
    filter_fn_10 = ImmutableList(2, 2)
    filter_fn_11 = ImmutableList(2, 1)
    filter_fn_12 = ImmutableList()

# Generated at 2022-06-25 23:43:40.646397
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    for i in range(200):
        immutable_list_0 = ImmutableList()
        immutable_list_1 = ImmutableList()
        # AssertionError is raised if the two objects are not equal
        assert immutable_list_0 == immutable_list_1
        assert immutable_list_1 == immutable_list_0
        assert immutable_list_0.__eq__(immutable_list_1)
        assert immutable_list_1.__eq__(immutable_list_0)


# Generated at 2022-06-25 23:43:47.485687
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert True == ImmutableList.empty().__eq__(ImmutableList.empty())
    assert False == ImmutableList.empty().__eq__(None)
    assert False == ImmutableList.empty().__eq__(ImmutableList.empty().append(1))
    assert False == ImmutableList.empty().__eq__(ImmutableList.empty().append(1).append(2))
    assert False == ImmutableList.empty().__eq__(ImmutableList.empty().append(1).append(2).append(3))
    assert False == ImmutableList.empty().__eq__(ImmutableList.empty().append(1).append(2).append(3).append(4))

# Generated at 2022-06-25 23:43:51.387491
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1).__eq__(ImmutableList.of(1))
    assert ImmutableList.of(1, 2, 3, 4, 5).__eq__(ImmutableList.of(1, 2, 3, 4, 5))


# Generated at 2022-06-25 23:43:57.995744
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    fn = lambda x : x.length == 3
    immutable_list_0 = ImmutableList.of("foo", "bar", "baz", "qux")
    immutable_list_1 = immutable_list_0.filter(fn)
    immutable_list_2 = ImmutableList.of("foo", "bar", "baz")
    assert immutable_list_1 == immutable_list_2


# Generated at 2022-06-25 23:44:01.411949
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 0)
    assert immutable_list_1 != immutable_list_0


# Generated at 2022-06-25 23:44:04.220879
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    assert immutable_list_1.filter(lambda x: x == 1) == ImmutableList.of(1)


# Generated at 2022-06-25 23:44:09.253806
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 2)
    assert isinstance(immutable_list_1, ImmutableList)
    immutable_list_2 = immutable_list_1.filter(lambda x: x < 4)
    assert isinstance(immutable_list_2, ImmutableList)
    assert immutable_list_2.head == 3


# Generated at 2022-06-25 23:44:16.000123
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    immutable_list_1 = immutable_list_0.filter((lambda item: item > 2))


# Generated at 2022-06-25 23:44:20.072433
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.of(1, 2, -7, -1, 5, -7)
    assert immutable_list.find(lambda x: x == 2) == 2
    assert immutable_list.find(lambda x: x == 0) is None
    assert ImmutableList.empty().find(lambda x: x > 0) is None

# Generated at 2022-06-25 23:44:22.642973
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3)


# Generated at 2022-06-25 23:44:28.696024
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Case 1
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1.tail = immutable_list_0
    immutable_list_1.head = None
    immutable_list_0.tail = None
    immutable_list_0.head = None
    result_1 = (immutable_list_0 == immutable_list_1)
    assert result_1


# Generated at 2022-06-25 23:44:33.768551
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)
    immutable_list_2 = immutable_list_0.filter(lambda x: x % 3 == 0)
    assert immutable_list_1.to_list() == [0, 2]
    assert immutable_list_2.to_list() == [0, 3]


# Generated at 2022-06-25 23:44:43.739183
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3)
    assert immutable_list_0.filter(lambda x: x % 2 == 0).to_list() == [0, 2]
    immutable_list_1 = ImmutableList.of(0, 2, 4, 6)
    assert immutable_list_1.filter(lambda x: x % 2 == 0).to_list() == [0, 2, 4, 6]
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4)
    assert immutable_list_2.filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    immutable_list_3 = ImmutableList.of(1, 2, 4, 6)

# Generated at 2022-06-25 23:44:47.266405
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList())) == ImmutableList.of(1, 2)


# Generated at 2022-06-25 23:44:56.158326
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty_head_tail_false = ImmutableList(is_empty=False, head=None, tail=None)
    empty_head_tail_true = ImmutableList(is_empty=True, head=None, tail=None)
    empty_head_tail_true_another = ImmutableList(is_empty=True, head=None, tail=None)
    empty_head_tail_true_another_equals = empty_head_tail_true_another
    empty_head_tail_true_not_equals = ImmutableList(is_empty=False, head=None, tail=None)

    assert empty_head_tail_false != empty_head_tail_true_another
    assert empty_head_tail_true != empty_head_tail_true_not_equals
    assert empty_head_tail_true == empty_head

# Generated at 2022-06-25 23:45:00.739834
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, None))))
    immutable_list_1 = ImmutableList(2, ImmutableList(4, ImmutableList.empty()))
    immutable_list_2 = immutable_list_0.filter(lambda x: x%2 == 0)
    assert immutable_list_2 == immutable_list_1


# Generated at 2022-06-25 23:45:07.881479
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_0 = ImmutableList.of(2, 4, 5, 7, 8, 4, 5)
    list_1 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)

    assert list_0.find(lambda x: x > 3) == 4
    assert list_0.find(lambda x: x < 0) is None

    assert list_1.find(lambda x: x % 2 == 0) == 2
    assert list_1.find(lambda x: x % 2 == 1) == 1



# Generated at 2022-06-25 23:45:16.597832
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:45:18.869407
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(1)
    immutable_list_1 = ImmutableList(1)
    assert(immutable_list_0 == immutable_list_1)


# Generated at 2022-06-25 23:45:28.234209
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = immutable_list_0.filter(lambda element: element < 10)
    assert immutable_list_1 == immutable_list_0
    # Test case 1
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_3 = immutable_list_2.filter(lambda element: element < 10)
    assert immutable_list_3 == immutable_list_2
    # Test case 2
    immutable_list_4 = ImmutableList.of(1, 9, 3, 4, 5)
    immutable_list_5 = immutable_list_4.filter(lambda element: element < 10)
    immutable_list_6 = immutable_list_4.filter(lambda element: element > 10)

# Generated at 2022-06-25 23:45:35.478113
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Check that filter on empty ImmutableList returns empty list
    assert ImmutableList().filter(lambda x: True).is_empty

    # Check that filter on non empty ImmutableList returns expected result
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2).to_list() == [2]
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2).to_list() == [3]


# Generated at 2022-06-25 23:45:43.478138
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    immutable_list_0 = ImmutableList()

    immutable_list_0.find(lambda x : x > 0)

    immutable_list_1 = ImmutableList()

    immutable_list_1.find(lambda x : x == 0)

    immutable_list_2 = ImmutableList()

    immutable_list_2.find(lambda x : x >= 0)

    immutable_list_4 = ImmutableList()

    immutable_list_4.find(lambda x : x < 1)

    immutable_list_5 = ImmutableList()

    immutable_list_5.find(lambda x : x > 1)

    immutable_list_6 = ImmutableList()

    immutable_list_6.find(lambda x : x <= 1)

    immutable_list_7 = ImmutableList()


# Generated at 2022-06-25 23:45:55.226235
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(1,immutable_list_1)
    immutable_list_3 = ImmutableList(2,immutable_list_2)
    immutable_list_4 = ImmutableList(3,immutable_list_3)
    
    assert(immutable_list_0.find(lambda x: x==None)==None)
    assert(immutable_list_1.find(lambda x: x==1)==1)
    assert(immutable_list_2.find(lambda x: x==1)==1)
    assert(immutable_list_3.find(lambda x: x==2)==2)

# Generated at 2022-06-25 23:46:00.845503
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-25 23:46:08.529620
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.filter(lambda x: True) == ImmutableList.empty()
    immutable_list_1 = ImmutableList.of(0)
    assert immutable_list_1.filter(lambda x: True) == ImmutableList.of(0)
    assert immutable_list_1.filter(lambda x: False) == ImmutableList.of()
    immutable_list_2 = ImmutableList.of(0, 1, 2)
    assert immutable_list_2.filter(lambda x: x == 1) == ImmutableList.of(1)
    immutable_list_3 = ImmutableList.of(0, 1, 2)
    assert immutable_list_3.filter(lambda x: True) == ImmutableList.of(0, 1, 2)

# Generated at 2022-06-25 23:46:13.847989
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(0, 1, 2, 3)
    assert immutable_list.filter(lambda x: x % 2 == 0).to_list() == [0, 2]
    assert immutable_list.filter(lambda x: x % 2 == 1).to_list() == [1, 3]
    assert immutable_list.__eq__(ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3)))))


# Generated at 2022-06-25 23:46:19.293671
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    immutable_list_0 = ImmutableList.of("ImmutableList first element", "ImmutableList second element", "ImmutableList third element")
    # Act
    filtered_list = immutable_list_0.filter(lambda x: len(x) > len("ImmutableList second element"))
    # Assert
    assert filtered_list == ImmutableList("ImmutableList third element")


# Generated at 2022-06-25 23:46:42.129550
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # create test objects
    immutable_list_0 = ImmutableList(1)
    immutable_list_1 = ImmutableList(2, immutable_list_0)
    immutable_list_2 = ImmutableList(2, immutable_list_0)
    immutable_list_3 = ImmutableList(3, immutable_list_1)
    immutable_list_4 = ImmutableList(4, immutable_list_2)
    immutable_list_5 = ImmutableList(4, immutable_list_2)
    immutable_list_6 = ImmutableList(1)
    immutable_list_7 = ImmutableList(4, immutable_list_6)

    def fn_filter(value):
        # anonymous function that takes value as an argument and returns value > 3
        return value > 3

    # call filter method on mutable_list_1 with fn

# Generated at 2022-06-25 23:46:45.970144
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(5).filter(lambda x: x == 5).head == 5
    assert ImmutableList(5, ImmutableList(6, ImmutableList(7))).filter(lambda x: x > 5).head == 6


# Generated at 2022-06-25 23:46:53.693228
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(-2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648, -2147483648)
    immutable_list_1 = immutable_list_0.filter(lambda x : x <= -2147483648)
    immutable_list_2 = immutable_list_1.filter(lambda x : x > -2147483648)

# Generated at 2022-06-25 23:46:59.505909
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert (ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3)

    assert(ImmutableList.of(1, 2, 3).find(lambda x: x > 5) == None)

    assert(ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'b') == 'b')

    assert(ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'd') == None)



# Generated at 2022-06-25 23:47:08.573927
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList(0)
    assert 0 == list1.find(lambda x: x == 0)
    assert None == list1.find(lambda x: x == 1)
    list2 = ImmutableList(0, ImmutableList(1, ImmutableList(2)))
    assert 0 == list2.find(lambda x: x == 0)
    assert 2 == list2.find(lambda x: x == 2)
    assert None == list2.find(lambda x: x == 3)


# Generated at 2022-06-25 23:47:12.863358
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    test_case_0()

    # Test case 1
    immutable_list_1 = ImmutableList(1)

    # Test case 2
    immutable_list_2 = ImmutableList(1, immutable_list_1)



# Generated at 2022-06-25 23:47:16.559620
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(False, True, False)
    immutable_list_1 = immutable_list_0.filter((lambda bool_0 : bool_0))
    assert immutable_list_1 == ImmutableList.of(True)


# Generated at 2022-06-25 23:47:27.238203
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x : x == 1) == ImmutableList(is_empty = True)
    assert ImmutableList(1).filter(lambda x : x == 1) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x : x == 2) == ImmutableList(is_empty = True)
    assert ImmutableList(1, 2, 3).filter(lambda x : x == 2) == ImmutableList(2)
    assert ImmutableList(1, 2, 3).filter(lambda x : x == 3) == ImmutableList(3)
    assert ImmutableList(1, 2, 3).filter(lambda x : x == 4) == ImmutableList(is_empty = True)

# Generated at 2022-06-25 23:47:30.290186
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert (immutable_list_0 == immutable_list_1) == True


# Generated at 2022-06-25 23:47:39.230893
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 2, 4, 2, 6, 4, 8)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 0)
    immutable_list_2 = immutable_list_1.filter(lambda x: x > 0)
    assert immutable_list_2.reduce(lambda acc, x: acc + x, 0) == 17
    immutable_list_3 = immutable_list_1.filter(lambda x: x > 0)
    immutable_list_4 = immutable_list_3.filter(lambda x: x > 0)
    assert immutable_list_4.reduce(lambda acc, x: acc + x, 0) == 17
    immutable_list_5 = immutable_list_3.filter(lambda x: x > 0)
    immutable_list_6

# Generated at 2022-06-25 23:48:12.802352
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1)
    immutable_list_1 = immutable_list_0.filter((lambda a0: (a0 >= 0)))
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail is None
    assert immutable_list_1.is_empty is False
    immutable_list_2 = immutable_list_1.filter((lambda a0: (a0 <= 2)))
    immutable_list_3 = immutable_list_1.filter((lambda a0: not (a0 <= 2)))
    assert immutable_list_2.head == 1
    assert immutable_list_2.tail is None
    assert immutable_list_2.is_empty is False
    assert immutable_list_3.head is None
    assert immutable_list_3.tail is None
    assert immutable_

# Generated at 2022-06-25 23:48:22.314672
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test test case 0
    try:
        immutable_list_0 = ImmutableList()
        immutable_list_1 = immutable_list_0.find(lambda e: e > 4)
    except Exception:
        immutable_list_1 = None
    assert immutable_list_1 == None
    # Test test case 1
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.append(1)
    immutable_list_2 = immutable_list_1.append(2)
    immutable_list_3 = immutable_list_2.append(3)
    immutable_list_4 = immutable_list_3.append(4)
    immutable_list_5 = immutable_list_4.append(5)
    immutable_list_6 = immutable_list_5.append(6)
    immutable

# Generated at 2022-06-25 23:48:25.993473
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 1, 2, 3, 5, 8, 13, 21)
    immutable_list_1 = immutable_list_0.filter((lambda number: ( number % 2 )))
    assert (immutable_list_1 == ImmutableList.of(1, 5, 13, 21))


# Generated at 2022-06-25 23:48:35.466098
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    #
    # Given
    #
    # Create a new ImmutableList instance with some elements
    #       [1, 2, 3, 4, 5]
    #
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    # Create a new ImmutableList instance with some elements
    #       [2, 4, 6, 8]
    #
    immutable_list_0 = ImmutableList.of(2, 4, 6, 8)

    #
    # When
    #
    # Apply filter function to the new ImmutableList instance
    #       lambda x : x % 2 == 0
    result = immutable_list.filter(lambda x : x % 2 == 0)
    #
    # Then
    #
    # Assert that the filtered list equals to the new ImmutableList instance

# Generated at 2022-06-25 23:48:38.479405
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda x : False)
    assert immutable_list_1 is not None
    assert immutable_list_1.to_list() == []


# Generated at 2022-06-25 23:48:48.183997
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    Unit test for method find of class ImmutableList
    """
    #Mutated objects for testing
    mutable_tuple_0 = ('foo', 'bar')
    #MutableList for testing
    mutable_list_0 = ['foo', 'bar']
    #MutableSet for testing
    mutable_set_0 = set(mutable_list_0)
    #ImmutableList for testing
    immutable_list_0 = ImmutableList.of('foo', 'bar')

    #Mapper for ImmutableList<tuple>
    tuple_mapper = lambda x: (x, x)
    #Mapper for ImmutableList<list>
    list_mapper = lambda x: [x, x]
    #Mapper for ImmutableList<set>
    set_mapper = lambda x: {x, x}

# Generated at 2022-06-25 23:48:57.636400
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Check if not callable passed as fn argument exception is thrown
    try:
        ImmutableList.of(1, 2, 3, 4, 5).filter(3)
        assert False, 'Not callable exception'
    except ValueError:
        pass

    # Check if element passed by parameter is not empty list
    #  and return result of filter call is the same.
    immutable_list = ImmutableList.of(1, 2, 3)
    assert immutable_list.filter(lambda x: x == 2).to_list() == [2]

    # Check if element passed by parameter is empty list
    # and return result of filter call is empty list.
    immutable_list = ImmutableList.of(1, 2, 3)
    assert immutable_list.filter(lambda x: x == 4).to_list() == list()

    # Check

# Generated at 2022-06-25 23:49:03.349641
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of('some head', 'some tail')
    immutable_list_1 = ImmutableList.of('some head', 'some tail')
    immutable_list_2 = ImmutableList.of('some head', 'other tail')
    immutable_list_3 = ImmutableList.of('some head')
    immutable_list_4 = ImmutableList.of('some head', 'some other tail')
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_0 != immutable_list_2
    assert immutable_list_0 != immutable_list_3
    assert immutable_list_0 != immutable_list_4


# Generated at 2022-06-25 23:49:05.694918
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0 == ImmutableList()
    assert not immutable_list_0 == None


# Generated at 2022-06-25 23:49:16.254130
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = 7

    immutable_list_1 = ImmutableList()
    immutable_list_1.head = 5
    immutable_list_1.tail = immutable_list_0

    immutable_list_2 = ImmutableList()
    immutable_list_2.head = 4
    immutable_list_2.tail = immutable_list_1

    immutable_list_3 = ImmutableList()
    immutable_list_3.head = 3
    immutable_list_3.tail = immutable_list_2

    immutable_list_4 = ImmutableList()
    immutable_list_4.head = 2
    immutable_list_4.tail = immutable_list_3

    immutable_list_5 = ImmutableList()
    immutable_list_5.head = 1
   

# Generated at 2022-06-25 23:50:16.575912
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    # When
    immutable_list_0_filtered = immutable_list_0.filter(lambda element: element > 3)
    immutable_list_1_filtered = immutable_list_1.filter(lambda element: element > 3)
    # Then
    assert immutable_list_0_filtered.to_list() == [4, 5]
    assert immutable_list_1_filtered.to_list() == [4, 5]


# Generated at 2022-06-25 23:50:26.135459
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList().append(0)
    immutable_list_1 = immutable_list_0.filter(ImmutableList.empty)
    assert immutable_list_1.find(ImmutableList.empty) == 0
    immutable_list_2 = immutable_list_1.append(0)
    immutable_list_3 = immutable_list_0.filter(ImmutableList.of)
    assert immutable_list_3.find(ImmutableList.empty) == 0
    immutable_list_4 = immutable_list_1.append(0)
    immutable_list_5 = immutable_list_1.filter(ImmutableList.empty)
    immutable_list_6 = immutable_list_0.filter(ImmutableList.of)
    assert immutable_list_6.find(ImmutableList.empty) == 0
    immutable