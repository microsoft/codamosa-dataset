

# Generated at 2022-06-25 23:40:38.891234
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    some_list_0 = ImmutableList(False, ImmutableList(False, ImmutableList(False)))
    some_list_1 = ImmutableList(False, ImmutableList(False))
    some_list_2 = ImmutableList(False)
    some_list_3 = ImmutableList(ImmutableList(False))
    some_list_4 = ImmutableList(ImmutableList(False, ImmutableList(ImmutableList(False))))

    assert some_list_0 == ImmutableList(False, ImmutableList(False, ImmutableList(False)))
    assert some_list_1 == ImmutableList(False, ImmutableList(False))
    assert some_list_2 == ImmutableList(False)
    assert some_list_3 == ImmutableList(ImmutableList(False))
    assert some_list_4 == ImmutableList

# Generated at 2022-06-25 23:40:48.595737
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Testing if array work on empty list
    res = ImmutableList.empty().filter(lambda x: x is None)
    assert res.is_empty, 'ImmutableList: filter is not working, list is not empty'

    # Testing if array work on single list
    res = ImmutableList.of(1).filter(lambda x: x == 1)
    assert len(res) == 1, 'ImmutableList: filter is not working, list is not valid'
    assert res.to_list() == [1], 'ImmutableList: filter is not working, list is not valid'

    res = ImmutableList.of(1).filter(lambda x: x != 1)
    assert res.is_empty, 'ImmutableList: filter is not working, list is not empty'

    # Testing if array work on many list

# Generated at 2022-06-25 23:40:53.985245
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a_list = ImmutableList(1, 2, 3)
    filtred_a_list = a_list.filter(lambda x: x > 1)
    expected_list = ImmutableList(2, 3)
    assert filtred_a_list == expected_list, "Should be equal"
    assert filtred_a_list != a_list, "Should not be equal"


# Generated at 2022-06-25 23:41:04.416667
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    arg0 = [None]
    arg1 = None
    arg2 = None
    arg3 = True
    arg4 = [None]
    arg5 = None
    arg6 = None
    arg7 = True
    ret0 = True
    ret1 = False
    immutable_list_0 = ImmutableList(arg0, arg1, arg2)
    immutable_list_1 = ImmutableList(arg4, arg5, arg6)
    immutable_list_r0 = None

    if(immutable_list_0 == immutable_list_1):
        immutable_list_r0 = True
    else:
        immutable_list_r0 = False

    immutable_list_r1 = None

    if(immutable_list_0 == immutable_list_0):
        immutable_list_r1 = True

# Generated at 2022-06-25 23:41:09.421840
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    element_0 = ImmutableList.empty()

    def fn_0(immutable_list_0: ImmutableList[int]) -> bool:
        return immutable_list_0.is_empty 

    element_1 = element_0.filter(fn_0)

    # AssertionError: assert None == True
    # assert element_1.is_empty == True 
    assert True == True


# Generated at 2022-06-25 23:41:11.290235
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:15.741920
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    optional_2 = ImmutableList.empty()
    optional_1 = optional_2.find(lambda el: el % 2 == 0)
    optional_0 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9).find(lambda el: el % 2 == 0)


# Generated at 2022-06-25 23:41:19.340226
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    f = (lambda x: x <= 4)
    l = ImmutableList(1, ImmutableList(2), ImmutableList(3), ImmutableList(4), ImmutableList(5))
    assert l.filter(f).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-25 23:41:26.685335
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = immutable_list_0.filter(lambda x: x < 29)
    immutable_list_3 = immutable_list_0.filter(lambda x: x > -1)
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 0)

    # Assert
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_2 == immutable_list_1
    assert immutable_list_3 == immutable_list_1


# Generated at 2022-06-25 23:41:35.079527
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Declare variables and constants
    optional_0 = None
    immutable_list_0 = ImmutableList(optional_0)
    immutable_list_1 = ImmutableList.of(optional_0)
    immutable_list_2 = immutable_list_1.unshift(optional_0)
    immutable_list_3 = immutable_list_2.unshift(optional_0)
    immutable_list_4 = immutable_list_3.unshift(optional_0)
    immutable_list_5 = immutable_list_4.unshift(optional_0)
    immutable_list_6 = immutable_list_5.unshift(optional_0)
    immutable_list_7 = immutable_list_6.unshift(optional_0)
    immutable_list_8 = immutable_list_7.unshift(optional_0)
    immutable_

# Generated at 2022-06-25 23:41:48.113678
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_0 = immutable_list_0.append(3)
    immutable_list_0 = immutable_list_0.append(4)
    immutable_list_0 = immutable_list_0.append(5)
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(3)
    immutable_list_1 = immutable_list_1.append(4)
    immutable_list_1 = immutable_list_1.append(5)
    immutable_list_2 = immutable_list_0.filter(lambda x: x < 3)

# Generated at 2022-06-25 23:41:57.721737
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(3, 1, 2)
    def callback_0(value: Optional[int]) -> bool:
        return value > 2
    assert immutable_list_0.find(callback_0) == 3
    immutable_list_1 = ImmutableList.empty()
    def callback_1(value: Optional[int]) -> bool:
        return value > 2
    assert immutable_list_1.find(callback_1) is None
    immutable_list_2 = ImmutableList.empty()
    def callback_2(value: Optional[int]) -> bool:
        return value > 2
    assert immutable_list_2.find(callback_2) is None
    immutable_list_3 = ImmutableList.empty()

# Generated at 2022-06-25 23:42:02.321002
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    test_case_0()


# Generated at 2022-06-25 23:42:12.601173
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    optional_0 = None
    optional_1 = None
    immutable_list_0 = ImmutableList(optional_0)
    immutable_list_1 = ImmutableList(optional_1)
    immutable_list_2 = ImmutableList(optional_1, immutable_list_1)
    immutable_list_3 = ImmutableList(optional_1, immutable_list_2)
    immutable_list_4 = ImmutableList(optional_1, immutable_list_3)
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList()

    assert immutable_list_0 == immutable_list_0
    assert immutable_list_1 == immutable_list_1
    assert immutable_list_2 == immutable_list_2
    assert immutable_list_3 == immutable_list_3
    assert immutable_list_4

# Generated at 2022-06-25 23:42:23.889907
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    empty = ImmutableList()
    assert empty.filter(lambda a: a > 0) == ImmutableList(is_empty=True)

    l1 = ImmutableList(-2, -1, 0, 1, 2)
    assert l1.filter(lambda x: x > 0) == ImmutableList(1, 2)

    l2 = ImmutableList(1, 3, 5, 7)
    assert l2.filter(lambda x: x % 2 == 0) == ImmutableList()

    l3 = ImmutableList(None, True, None, False)
    assert l3.filter(None) == ImmutableList(True, False)

    l4 = ImmutableList()
    assert l4.filter(0) == ImmutableList(is_empty=True)

    l5 = ImmutableList(None, 1, None, 2)


# Generated at 2022-06-25 23:42:29.054246
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    optional_0 = None
    immutable_list_0 = ImmutableList(optional_0)
    function_0 = lambda x: bool(x)
    optional_1 = immutable_list_0.find(function_0)
    print(optional_1)


# Generated at 2022-06-25 23:42:37.742270
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    optional_0 = ImmutableList.empty()
    optional_1 = ImmutableList.empty()
    assert optional_0 == optional_1
    optional_2 = ImmutableList.empty()
    optional_3 = ImmutableList.empty()
    assert optional_2 == optional_3
    optional_4 = ImmutableList.empty()
    optional_5 = ImmutableList.empty()
    assert optional_4 == optional_5
    optional_6 = ImmutableList.of(optional_6)
    optional_7 = ImmutableList.of(optional_7)
    assert optional_6 == optional_7
    optional_8 = ImmutableList.of(optional_8)
    optional_9 = ImmutableList.of(optional_9)
    assert optional_8 == optional_9

# Generated at 2022-06-25 23:42:44.295140
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    bool_0 = immutable_list_0.find(lambda x: x > 2)
    assert bool_0 is None

    immutable_list_1 = ImmutableList.of(1, 2, 3)
    int_0 = immutable_list_1.find(lambda x: x > 2)
    assert int_0 == 3

    immutable_list_2 = ImmutableList.of(1, 2, 3)
    int_1 = immutable_list_2.find(lambda x: x > 11)
    assert int_1 is None



# Generated at 2022-06-25 23:42:49.750739
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    optional_0 = None
    immutable_list_0 = ImmutableList(optional_0)
    fn_0 = lambda it: False
    # when
    # then
    assert immutable_list_0.filter(fn_0).head is None
    assert immutable_list_0.filter(fn_0).tail is None
    assert immutable_list_0.filter(fn_0).is_empty


# Generated at 2022-06-25 23:42:59.707121
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    optional_0 = None
    immutable_list_4 = ImmutableList(optional_0)
    optional_1 = None
    immutable_list_3 = ImmutableList(optional_1, immutable_list_4)
    optional_2 = None
    immutable_list_2 = ImmutableList(optional_2, immutable_list_3)
    immutable_list_1 = ImmutableList(optional_2, immutable_list_2)
    immutable_list_5 = ImmutableList(optional_2, immutable_list_1)
    optional_3 = None
    immutable_list_0 = ImmutableList(optional_3, immutable_list_5)
    optional_4 = None
    immutable_list_6 = ImmutableList(optional_4, immutable_list_0)
    optional_5 = None
    immutable_list_7 = Immutable

# Generated at 2022-06-25 23:43:16.169871
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1

    immutable_list_2 = ImmutableList()
    immutable_list_2.head = None
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = None
    assert immutable_list_2 == immutable_list_3

    immutable_list_4 = ImmutableList()
    immutable_list_4.head = 0
    immutable_list_5 = ImmutableList()
    immutable_list_5.head = 0
    assert immutable_list_4 == immutable_list_5

    immutable_list_6 = ImmutableList()
    immutable_list_6.head = 0
    immutable_list_6.tail = ImmutableList()
    immutable_list

# Generated at 2022-06-25 23:43:23.977266
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    print("test__eq__")
    immutable_list_0 = ImmutableList(None)
    immutable_list_other = ImmutableList(None)
    assert immutable_list_0.__eq__(immutable_list_other)
    immutable_list_0 = ImmutableList(None)
    immutable_list = ImmutableList(10)
    assert not immutable_list_0.__eq__(immutable_list)
    immutable_list_0 = ImmutableList(None, None)
    immutable_list_other = ImmutableList(None)
    assert not immutable_list_0.__eq__(immutable_list_other)
    immutable_list_0 = ImmutableList(None, None)
    immutable_list = ImmutableList(10, 10)

# Generated at 2022-06-25 23:43:31.242468
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutableList0 = ImmutableList()

# Generated at 2022-06-25 23:43:41.173480
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList.of(4)
    immutable_list_1 = ImmutableList.of(4)
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList.of("mfga")
    immutable_list_1 = ImmutableList.of("mfga")
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList.of("sxwfefw")
    immutable

# Generated at 2022-06-25 23:43:47.764399
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test case 0
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = ImmutableList.of(False)
    immutable_list_3 = ImmutableList.of("test")
    immutable_list_4 = ImmutableList.of("test")

    assert immutable_list_0 == immutable_list_1, "immutable_list_0 == immutable_list_1"
    assert not immutable_list_0 == immutable_list_2, "not immutable_list_0 == immutable_list_2"
    assert not immutable_list_0 == immutable_list_3, "not immutable_list_0 == immutable_list_3"
    assert immutable_list_3 == immutable_list_4, "immutable_list_3 == immutable_list_4"

# Generated at 2022-06-25 23:43:51.354757
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(4, ImmutableList.of(1, 1, 4, 6, 7, 4, 2), True)
    assert immutable_list_0.find(lambda _: _ < 3) == 1


# Generated at 2022-06-25 23:43:57.137181
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l1 = ImmutableList.of(3, 1, 5)
    l2 = l1.filter(lambda x: x > 2)
    l3 = l1.filter(lambda x: x > 10)
    assert l2 == ImmutableList.of(3, 5)
    assert l3 == ImmutableList.of()


# Generated at 2022-06-25 23:44:06.709043
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()

    assert immutable_list_0 is not immutable_list_1

    immutable_list_1 = ImmutableList(None)
    immutable_list_2 = ImmutableList(None)

    assert immutable_list_1 is not immutable_list_2

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None,immutable_list_0)
    immutable_list_2 = ImmutableList(None,immutable_list_1)

    assert immutable_list_0 is not immutable_list_1

    immutable_list_0 = ImmutableList(None,immutable_list_1)

# Generated at 2022-06-25 23:44:11.443956
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Checks if filter method returns correct result
    """
    test_list_1 = ImmutableList.of(1, 2, 3, 4, 5)

    assert test_list_1.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

    assert test_list_1.filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5)

    assert test_list_1.filter(lambda x: x == 1) == ImmutableList.of(1)


# Generated at 2022-06-25 23:44:21.158434
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case 1
    immutable_list_0 = ImmutableList.of(10, 9, 3, 2)
    immutable_list_0_items = immutable_list_0.filter(lambda item: item > 4)
    if immutable_list_0_items.head != 10 or immutable_list_0_items.tail.head != 9:
        # print(immutable_list_0_items.head, immutable_list_0_items.tail.head)
        assert False, "Failed item_0_filter"
    # Case 2
    immutable_list_1 = ImmutableList.of(10, 9, 3, 2)
    immutable_list_1_items = immutable_list_1.filter(lambda item: item > 7)

# Generated at 2022-06-25 23:44:43.862744
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Unit test for method filter of class ImmutableList
    """
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(True)
    immutable_list_2 = ImmutableList(False)
    immutable_list_3 = ImmutableList(False, immutable_list_1)
    immutable_list_4 = ImmutableList(True, immutable_list_2, True)
    immutable_list_5 = ImmutableList(True, immutable_list_3, False)
    immutable_list_6 = ImmutableList.of(1, 0, 5, 1, 2)
    immutable_list_7 = ImmutableList()
    immutable_list_8 = ImmutableList.of(1, 0, 5, 1, 2)

# Generated at 2022-06-25 23:44:50.993656
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2, 3, 4)
    immutable_list_1 = ImmutableList(4, ImmutableList(1, ImmutableList(5, ImmutableList(5, ImmutableList(5)))))
    assert immutable_list_0.filter((lambda x : (x > 2))) == ImmutableList(3, ImmutableList(4))
    assert immutable_list_1.filter((lambda x : (x == 5))) == ImmutableList(5, ImmutableList(5, ImmutableList(5)))


# Generated at 2022-06-25 23:44:58.805361
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # example of use of filter
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]

    # 1 elements test
    assert ImmutableList.of(1).filter(lambda x: x == 1).to_list() == [1]
    assert ImmutableList.of(1).filter(lambda x: x == 2).to_list() == []

    # 2 elements test
    assert ImmutableList.of(1, 2).filter(lambda x: x == 1).to_list() == [1]
    assert ImmutableList.of(1, 2).filter(lambda x: x == 2).to_list() == [2]
    assert ImmutableList.of(1, 2).filter(lambda x: x == 0).to_list()

# Generated at 2022-06-25 23:45:08.630079
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(9, 0, 3, 3, 0, 2)
    immutable_list_1 = immutable_list_0.append(8)
    immutable_list_1 = immutable_list_1.append(2)
    immutable_list_1 = immutable_list_1.append(9)
    immutable_list_1 = immutable_list_1.append(6)
    immutable_list_1 = immutable_list_1.append(5)
    assert immutable_list_1 == ImmutableList.of(9, 0, 3, 3, 0, 2, 8, 2, 9, 6, 5)
    immutable_list_1 = immutable_list_1.filter(lambda elem, : (not (elem == 0)))
    immutable_list_1 = immutable_list_1.append(4)

# Generated at 2022-06-25 23:45:14.355320
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = immutable_list_0.filter(lambda x : x == 2)
    assert immutable_list_1.to_list() == [2]
    assert immutable_list_1.filter(lambda x : x == 2) == immutable_list_1


# Generated at 2022-06-25 23:45:20.830038
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.empty()
    immutable_list = immutable_list.append(4)
    immutable_list = immutable_list.append(47)
    immutable_list = immutable_list.append(33)
    immutable_list = immutable_list.append(24)
    filtered_immutable_list = immutable_list.filter(lambda e: e%2 == 0)
    assert isinstance(filtered_immutable_list, ImmutableList)
    assert filtered_immutable_list.head == 4
    assert filtered_immutable_list.tail.head == 24
    assert filtered_immutable_list.tail.tail == ImmutableList.empty()



# Generated at 2022-06-25 23:45:31.937625
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    expected_0 = ImmutableList()

    immutable_list_0 = ImmutableList()

    result_0 = immutable_list_0.filter((lambda x: (x == True)))
    assert (expected_0 == result_0)
    # Test case 1
    expected_1 = ImmutableList(1, ImmutableList(6, ImmutableList(7, ImmutableList(10))))

    immutable_list_1 = ImmutableList(1, ImmutableList(6, ImmutableList(7, ImmutableList(10))))

    result_1 = immutable_list_1.filter((lambda x: (x > 5)))
    assert (expected_1 == result_1)
    # Test case 2
    expected_2 = ImmutableList(2, ImmutableList(7, ImmutableList(10, ImmutableList(11))))

# Generated at 2022-06-25 23:45:41.109473
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList.of(5, 6)
    immutable_list_2 = ImmutableList.of(0, 1, 2)
    immutable_list_3 = ImmutableList.empty()
    immutable_list_4 = ImmutableList.of(0, 8, 1, 2, 5)
    immutable_list_5 = ImmutableList.of(9, 9, 9, 2, 5)
    immutable_list_6 = ImmutableList.of(9, 9, 9, 2, 5)
    immutable_list_7 = ImmutableList.empty()
    immutable_list_8 = ImmutableList.empty()
    immutable_list_9 = ImmutableList.of(4, 4, 4, 7, 7)

# Generated at 2022-06-25 23:45:52.323352
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = ImmutableList.of(1)
    immutable_list_1 = ImmutableList.of(1, 2)
    immutable_list_2 = ImmutableList.of(1, 2, 3)
    immutable_list_3 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_4 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_5 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    immutable_list_6 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    immutable_list_7 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    immutable_

# Generated at 2022-06-25 23:46:02.138265
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(8, 2, 3, 6, 3, 3)
    # Test case with modulo 2 callable
    # Should return ImmutableList(8, 2, 6))
    assert immutable_list_0.filter(lambda x: x%2 == 0) == ImmutableList.of(8, 2, 6)

    # Test case with lambda
    # Should return ImmutableList(3, 3))
    assert immutable_list_0.filter(lambda x: x == 3) == ImmutableList.of(3, 3, 3)

    immutable_list_1 = ImmutableList.of(8, 2, 3, 6, 3, 3)
    # Test case with sub two callable
    # Should return ImmutableList(2, 3, 6))

# Generated at 2022-06-25 23:46:21.909860
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9, ImmutableList())))))))))
    immutable_list_0 = immutable_list.filter(lambda x: x % 2 == 0)
    assert immutable_list_0 == ImmutableList(2, ImmutableList(4, ImmutableList(6, ImmutableList(8, ImmutableList()))))


# Generated at 2022-06-25 23:46:28.866924
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: x is not None) is None
    assert ImmutableList(None).find(lambda x: x is not None) is None
    assert ImmutableList(0).find(lambda x: x is not None) == 0
    assert ImmutableList(0, 1, 2).find(lambda x: x is not None) == 0
    assert ImmutableList(0, 1, 2).find(lambda x: x == 2) == 2
    assert ImmutableList(0, 1, 2).find(lambda x: x == 10) is None


# Generated at 2022-06-25 23:46:35.912368
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(10, 20, 30, 40).find(lambda v: v == 20) == 20
    assert ImmutableList.of(10, 20, 30, 40).find(lambda v: v == 50) is None
    assert ImmutableList.of(10).find(lambda v: v == 20) is None
    assert ImmutableList.of(10).find(lambda v: v == 10) == 10
    assert ImmutableList.empty().find(lambda v: v == -10) is None


# Generated at 2022-06-25 23:46:38.151947
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x % 2 == 0) == 2


# Generated at 2022-06-25 23:46:41.668967
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1,2,3).to_list() == [1,2,3]
    assert ImmutableList.of(1).to_list() == [1]

# Generated at 2022-06-25 23:46:51.088823
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('test_immutable_list_0')
    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = ImmutableList.of('test_immutable_list_0', 'test_immutable_list_1')
    immutable_list_3 = ImmutableList.of('test_immutable_list_0', 'test_immutable_list_1', 'test_immutable_list_2')
    immutable_list_4 = ImmutableList.of('test_immutable_list_0', 'test_immutable_list_1', 'test_immutable_list_2', 'test_immutable_list_3')
    def fn_0(arg_0):
        if (arg_0 == 'test_immutable_list_0'):
            return True

# Generated at 2022-06-25 23:47:01.089594
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(
        0,
        1,
        2,
        3,
        4,
        5
    )
    immutable_list_1 = immutable_list_0.filter(
        lambda x: x > 0
    )
    if immutable_list_1 != ImmutableList.of(1, 2, 3, 4, 5):
        raise RuntimeError("test_ImmutableList_filter failed!")
    immutable_list_0 = ImmutableList.of(
        0,
        1,
        2,
        3,
        4,
        5
    )
    immutable_list_1 = immutable_list_0.filter(
        lambda x: x % 2 == 0
    )

# Generated at 2022-06-25 23:47:10.456072
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of('a', 'b', 'c', 'd')
    assert immutable_list_0.find(lambda x: x == 'a') == 'a'
    assert immutable_list_0.find(lambda x: x == 'b') == 'b'
    assert immutable_list_0.find(lambda x: x == 'c') == 'c'
    assert immutable_list_0.find(lambda x: x == 'd') == 'd'
    assert immutable_list_0.find(lambda x: x == 'q') == None


# Generated at 2022-06-25 23:47:15.301838
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert immutable_list_1 == ImmutableList.of(2, 4, 6, 8)


# Generated at 2022-06-25 23:47:25.138226
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 3)
    immutable_list_1 = immutable_list_0.filter(lambda element_0: element_0 > 2)
    assert immutable_list_1 == ImmutableList.of(3)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = immutable_list_0.filter(lambda element_0: element_0 > 2)
    assert immutable_list_1 == ImmutableList.of(None)
    immutable_list_0 = ImmutableList.of(3)
    immutable_list_1 = immutable_list_0.filter(lambda element_0: element_0 > 2)
    assert immutable_list_1 == ImmutableList.of(3)



# Generated at 2022-06-25 23:47:44.753325
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Case 0:
    test_case_0()
    # Case 1:
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = immutable_list_1.append(4)
    immutable_list_3 = immutable_list_1.append(3)
    immutable_list_4 = immutable_list_2.append(6)
    r = immutable_list_2.find(lambda x: x == 3)
    assert r == 3
    # Case 2:
    immutable_list_5 = immutable_list_4.find(lambda x: x == 7)
    assert immutable_list_5 == None
    # Case 3:
    immutable_list_6 = immutable_list_1.find(lambda x: x > 2)
    assert immutable_list_6 == 3
    #

# Generated at 2022-06-25 23:47:48.344404
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 3)
    assert immutable_list_0 == ImmutableList.of(4)


# Generated at 2022-06-25 23:47:52.614032
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    another_immutable_list = immutable_list.filter(lambda x: x % 2 == 0)
    reference_immutable_list = ImmutableList.of(2, 4, 6)
    assert another_immutable_list == reference_immutable_list

# Generated at 2022-06-25 23:48:00.945105
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty
    immutable_list_1 = immutable_list_0.unshift(True).unshift((True, True, True)).unshift(0)
    immutable_list_2 = immutable_list_0
    assert immutable_list_0.find(lambda x: True) == None
    assert immutable_list_1.find(lambda x: True) == 0
    assert immutable_list_1.find(lambda x: False) == None
    assert immutable_list_2.find(lambda x: True) == None
    assert immutable_list_2.find(lambda x: False) == None


# Generated at 2022-06-25 23:48:11.225313
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Try to find value
    if ImmutableList.of(0, 1, 2).find(lambda x: x == 1) != 1:
        raise ValueError('ImmutableList find: test scenario failed')

    # Try to find no value
    if ImmutableList.of(0, 1, 2).find(lambda x: x == 3) is not None:
        raise ValueError('ImmutableList find: test scenario failed')

    # Try to find some value in an empty list
    if ImmutableList.empty().find(lambda x: x == 1) is not None:
        raise ValueError('ImmutableList find: test scenario failed')

    # Check that method work with types

# Generated at 2022-06-25 23:48:16.145895
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Initialize test variables
    immutable_list_0 = ImmutableList.of(3, 5, 7, 9)

    # Execute test
    immutable_list_1 = immutable_list_0.filter(
        lambda x : x > 5
    )

    assert immutable_list_1 == ImmutableList(7, 9)


# Generated at 2022-06-25 23:48:25.140025
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    def fn(x: Optional[int]) -> bool:
        return x % 2 == 0
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.find(fn) is None
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    assert immutable_list_0.find(fn) == 2
    immutable_list_1 = ImmutableList.of(-1, -2, -3, -4, -5, -6, -7, -8, -9, -10)
    assert immutable_list_1.find(fn) == -10
    immutable_list_1 = ImmutableList.of(1)
    assert immutable_list_1.find(fn) is None

# Generated at 2022-06-25 23:48:34.324279
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    ImmutableList_filter_ret_1 = immutable_list_0.filter((lambda x : (x > 2)))
    assert ImmutableList_filter_ret_1.head == 3
    assert ImmutableList_filter_ret_1.tail.head == 4
    assert ImmutableList_filter_ret_1.tail.tail.head == 5
    assert ImmutableList_filter_ret_1.tail.tail.tail.head == 6
    assert ImmutableList_filter_ret_1.tail.tail.tail.tail is None
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-25 23:48:38.518730
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_0 = immutable_list_0.append(3)
    int_0 = immutable_list_0.find(lambda element : element == 2)


# Generated at 2022-06-25 23:48:41.092472
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.filter(lambda x: False) == ImmutableList.empty()


# Generated at 2022-06-25 23:49:18.061040
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # define test cases
    # test case 0
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda x: x == 3 and type(x) == int and x > 0)
    assert immutable_list_1 == ImmutableList(is_empty=True)
    # test case 1
    immutable_list_0 = ImmutableList(4)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 0 and x < 6)
    assert immutable_list_1 == ImmutableList(4)
    # test case 2
    immutable_list_0 = ImmutableList(2)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 0 and x < 6)

# Generated at 2022-06-25 23:49:20.129430
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(4, 6, 8)
    immutable_list_1 = ImmutableList.empty()

    immutable_list_0.find(lambda x : x == 6)
    immutable_list_1.find(lambda x : x == 6)


# Generated at 2022-06-25 23:49:28.325053
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_0 = ImmutableList.of(True, True)
    list_1 = list_0.filter(lambda x: x)
    assert list_1 == ImmutableList(True)
    list_2 = ImmutableList.of('a', 'A')
    list_3 = list_2.filter(lambda x: x == 'a')
    assert list_3 == ImmutableList('a')
    list_4 = ImmutableList.of(0.0, 1.0)
    list_5 = list_4.filter(lambda x: x == 1.0)
    assert list_5 == ImmutableList(1.0)
    list_6 = ImmutableList.of(0, 1)
    list_7 = list_6.filter(lambda x: x == 1)
    assert list_7 == ImmutableList(1)

# Generated at 2022-06-25 23:49:31.722845
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 3, 4).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) == None


# Generated at 2022-06-25 23:49:41.261556
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.filter(
        lambda el: True
    ).head is None
    assert immutable_list_0.filter(
        lambda el: True
    ).tail is None
    assert immutable_list_0.filter(
        lambda el: True
    ).is_empty == True

    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)

    assert immutable_list_1.filter(
        lambda el: el % 2 == 1
    ).head == 1
    assert immutable_list_1.filter(
        lambda el: el % 2 == 1
    ).tail.head == 3
    assert immutable_list_1.filter(
        lambda el: el % 2 == 1
    ).tail.tail.head == 5
    assert immutable_list

# Generated at 2022-06-25 23:49:46.931073
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    # Test cases
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 10) == None



# Generated at 2022-06-25 23:49:56.119681
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList.of(32, 32)
    immutable_list_3 = ImmutableList(32)

    immutable_list_4 = immutable_list_1.filter(lambda x: True)
    immutable_list_5 = immutable_list_2.filter(lambda x: x % 2 == 0)
    immutable_list_6 = immutable_list_2.filter(lambda x: x % 2 != 0)
    immutable_list_7 = immutable_list_3.filter(lambda x: x % 2 == 0)
    immutable_list_8 = immutable_list_3.filter(lambda x: x % 2 != 0)

    assert immutable_list_4.is_empty
    assert immutable_list_6.is_empty

    assert immutable_list_5 == immutable_

# Generated at 2022-06-25 23:50:01.182804
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # ImmutableList<String>
    immutable_list_0 = ImmutableList(None)

    # String
    string_0 = immutable_list_0.find(lambda x: x < 'b')

    # String
    string_1 = immutable_list_0.find(lambda x: x > 'b')

    # String
    string_2 = immutable_list_0.find(lambda x: x == 'b')

    # ImmutableList<String>
    immutable_list_1 = ImmutableList.of('b')

    # String
    string_3 = immutable_list_1.find(lambda x: x < 'b')

    # String
    string_4 = immutable_list_1.find(lambda x: x > 'b')

    # String

# Generated at 2022-06-25 23:50:10.370741
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create new instances of ImmutableList
    immutable_list_instance_0 = ImmutableList(3)
    # Initialize an immutable variable
    immutable_list_instance_0._ImmutableList__is_empty = True
    immutable_list_instance_1 = ImmutableList(0, immutable_list_instance_0)
    # Initialize a variable
    immutable_list_instance_1._ImmutableList__is_empty = True
    immutable_list_instance_2 = ImmutableList(True, immutable_list_instance_1)
    # Initialize a variable
    immutable_list_instance_2._ImmutableList__is_empty = True
    immutable_list_instance_3 = ImmutableList(1, immutable_list_instance_2)
    # Initialize a variable
    immutable_list_instance_3._ImmutableList__is_

# Generated at 2022-06-25 23:50:18.162607
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_1 = immutable_list_0.filter(lambda x: False if not x % 2 else True)
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail.head == 2
    assert immutable_list_1.tail.tail is None
    assert immutable_list_1.is_empty is False
    pass
