

# Generated at 2022-06-25 23:40:32.506079
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:40:43.276939
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Inline inputs for this test case
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = immutable_list_0.append(1)
    immutable_list_2 = immutable_list_1.append(2)
    immutable_list_3 = immutable_list_2.append(3)
    immutable_list_4 = immutable_list_3.append(4)
    immutable_list_5 = immutable_list_4.append(5)
    immutable_list_6 = immutable_list_5.append(6)
    immutable_list_7 = immutable_list_6.append(7)
    immutable_list_8 = immutable_list_7.append(8)
    immutable_list_9 = immutable_list_8.append(9)

# Generated at 2022-06-25 23:40:46.564242
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    immutable_list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:40:49.180537
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)
    bool_0 = immutable_list_0.find(lambda x: (x > 3))


# Generated at 2022-06-25 23:40:52.142490
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()

    try:
        assert immutable_list_0.__eq__(1) == False
    except:
        raise AssertionError('Wrong answer')


# Generated at 2022-06-25 23:41:00.232564
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = [1, 2, 3, 4, 5, 6]
    immutable_list = ImmutableList.of(*test_list)
    test_list = [_ for _ in test_list if _ % 2 == 0]
    immutable_list_filtered = immutable_list.filter(lambda x: (x % 2 == 0))
    assert immutable_list_filtered.__str__() == str(test_list)


# Generated at 2022-06-25 23:41:05.681036
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList()
    bool_0 = immutable_list_0.find(test_find_test_0_0)
    assert test_find_test_0_0_assertion(bool_0)

    # Test case 1
    immutable_list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(5, ImmutableList(8)))))
    bool_1 = immutable_list_1.find(test_find_test_1_0)
    assert test_find_test_1_0_assertion(bool_1)

    # Test case 2
    immutable_list_2 = ImmutableList()
    bool_2 = immutable_list_2.find(test_find_test_2_0)
    assert test_find_

# Generated at 2022-06-25 23:41:06.993760
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0, 1, 2)
    item_0 = immutable_list_0.find(lambda x: x > 3)
    assert item_0 is None


# Generated at 2022-06-25 23:41:09.035326
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(1, 2)
    immutable_list_filter_0 = immutable_list.filter(lambda item: item < 0)
    immutable_list_filter_1 = immutable_list.filter(lambda item: item > 0)


# Generated at 2022-06-25 23:41:17.615838
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # variables
    immutable_list_0 = ImmutableList.of(42)
    immutable_list_1 = ImmutableList.of(42)
    any_0 = immutable_list_0.__eq__(immutable_list_1)
    assert True == any_0

    immutable_list_0 = ImmutableList.of(23)
    immutable_list_1 = ImmutableList.of(34)
    any_0 = immutable_list_0.__eq__(immutable_list_1)
    assert False == any_0

    immutable_list_0 = ImmutableList.of(42)
    immutable_list_1 = ImmutableList.of(42)
    immutable_list_2 = immutable_list_0 + immutable_list_1
    immutable_list_3 = ImmutableList.of(42, 42)


# Generated at 2022-06-25 23:41:30.601958
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    immutable_list_1 = immutable_list_0.filter(lambda x : x % 2 == 0)
    immutable_list_2 = immutable_list_1.filter(lambda x : x % 2 == 0)
    assert immutable_list_2 == ImmutableList.of(4, 8, 10), "Test #1 Failed"



# Generated at 2022-06-25 23:41:41.197954
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) == None

    assert ImmutableList(1, 2, 3).find(lambda x: x == 1) == 1

    assert ImmutableList(1, 2, 3).find(lambda x: x == 4) == None

    assert ImmutableList("hello", "world").find(lambda x: len(x) == 5) == "hello"

    assert ImmutableList("hello", "world").find(lambda x: True) == "hello"

    assert ImmutableList().find(lambda x: True) == None

    assert ImmutableList().find(lambda x: True) == None

    assert ImmutableList().find(lambda x: True) == None

    assert ImmutableList().find(lambda x: True) == None

    assert ImmutableList().find(lambda x: True) == None

    assert Immutable

# Generated at 2022-06-25 23:41:51.536036
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_0.__eq__(immutable_list_0)

    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = ImmutableList.empty()
    immutable_list_2.__eq__(immutable_list_1)

    immutable_list_3 = ImmutableList()
    immutable_list_3.__eq__(immutable_list_1)

    immutable_list_4 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_4.__eq__(immutable_list_4)

    immutable_list_5 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_5.__eq__(immutable_list_4)

    immutable_list

# Generated at 2022-06-25 23:41:59.565389
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print("test ImmutableList.find")
    # test data
    array_0 = [1, 2, 3, 4, 5]
    number_0 = 5
    fn_0 = lambda x: x > number_0
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = None
    immutable_list_0.tail = None
    immutable_list_0.is_empty = True
    number_1 = 5
    fn_1 = lambda x: x < number_1

# Generated at 2022-06-25 23:42:02.082734
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList((4 if (0 >= 1 and 2 != 0 and 2 == 4) else 2), ImmutableList())
    immutable_list_1 = ImmutableList(ImmutableList(), ImmutableList((4 if (0 >= 1 and 2 != 0 and 2 == 4) else 2)))
    assert (immutable_list_0 == immutable_list_1) == False


# Generated at 2022-06-25 23:42:10.114819
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_0 == immutable_list_1
    immutable_list_1 = ImmutableList(5.07, immutable_list_0)
    immutable_list_0 = ImmutableList()
    immutable_list_0 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:42:14.961114
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(True, None)
    immutable_list_1 = immutable_list_0.filter((lambda x: x))
    assert immutable_list_1 is not None and len(immutable_list_1) == 1, "ImmutableList.filter() failed"


# Generated at 2022-06-25 23:42:21.393730
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create a ImmutableList of three elements
    immutable_list_0 = ImmutableList.of(1, 2, 3)

    # Call the method filter of class ImmutableList with the ImmutableList of three elements, the function (a) -> a == 1
    # and the element 0 of class ImmutableList
    assert immutable_list_0.filter(lambda a: a == 1) == ImmutableList.of(1)


# Generated at 2022-06-25 23:42:32.734551
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    # test ImmutableList find (0)
    immutable_list_0 = ImmutableList()

    # Unit test for method find of class ImmutableList
    immutable_list_1 = ImmutableList(1)

    # Unit test for method find of class ImmutableList
    immutable_list_2 = ImmutableList(2)

    # Unit test for method find of class ImmutableList
    immutable_list_3 = ImmutableList(3)

    # Unit test for method find of class ImmutableList
    immutable_list_4 = ImmutableList(4)

    # Unit test for method find of class ImmutableList
    immutable_list_5 = ImmutableList(5)

    # Unit test for method find of class ImmutableList
    immutable_list_0 = ImmutableList()

    # Unit test for method find of class ImmutableList
    immutable_

# Generated at 2022-06-25 23:42:36.601651
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def fn(value):
        return value > 2
    immutable_list_0 = ImmutableList.of(1,2,3,4,5)
    immutable_list_0 = immutable_list_0.filter(fn)
    assert [3, 4, 5] == immutable_list_0.to_list()


# Generated at 2022-06-25 23:42:44.600164
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ImmutableList.find(ImmutableList.of('1', '2', '3'), lambda x: x == '2')
    ImmutableList.find(ImmutableList.of(1, 2, 3), lambda x: x == 2)

# Test for method __eq__ of class ImmutableList

# Generated at 2022-06-25 23:42:47.964757
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # prepare test data
    immutable_list_0 = ImmutableList()
    # run
    result = immutable_list_0.filter(lambda x: not bool(x))
    # assert
    assert result == ImmutableList(), "Test failed"


# Generated at 2022-06-25 23:42:56.888352
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Data preparation
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = 1
    immutable_list_0.tail = None
    immutable_list_0.is_empty = False
    #print("Test 1 output: {0}".format((immutable_list_0.tail is None)))
    #print("Test 2 output: {0}".format(immutable_list_0.map(lambda x: x*2)))

    # Result preparation
    result = immutable_list_0.find(lambda x: x == 1)

    # Asserts
    assert result == 1, "Should return true when there is a element with value 1"


# Generated at 2022-06-25 23:43:10.447907
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList.of(0, 1)
    immutable_list_2 = ImmutableList.of(0, 1, 2)
    immutable_list_3 = ImmutableList.of(0, 1, 2, 3)
    immutable_list_4 = ImmutableList.of(0, 1, 2, 3, 4)
    immutable_list_5 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    immutable_list_6 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6)
    immutable_list_7 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7)

# Generated at 2022-06-25 23:43:17.319602
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    ).filter(lambda val: val % 2 == 0) == ImmutableList.of(
        0, 2, 4, 6, 8, 10
    )

    assert ImmutableList.of(
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    ).filter(lambda val: val % 2 == 1) == ImmutableList.of(
        1, 3, 5, 7, 9
    )


# Generated at 2022-06-25 23:43:22.658945
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # check if filter works on empty list
    assert ImmutableList().filter(lambda x: True) == ImmutableList.empty()
    # check if filter works on list with two elements
    assert ImmutableList(2, ImmutableList(3)).filter(lambda x: x > 1) == ImmutableList(2, ImmutableList(3))
    # check if filter works on list with one element
    assert ImmutableList(2).filter(lambda x: x > 1) == ImmutableList(2)


# Generated at 2022-06-25 23:43:28.082566
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # 
    immutable_list_0 = ImmutableList()

    # 
    immutable_list_1 = ImmutableList()
    # Check equality
    assert immutable_list_0 == immutable_list_1
    # Check alias
    assert immutable_list_0 is immutable_list_1


# Generated at 2022-06-25 23:43:38.351311
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Empty list
    immutable_list_0 = ImmutableList()
    immutable_list_0_filtered = immutable_list_0.filter(lambda element: element > 1)
    assert immutable_list_0 == immutable_list_0_filtered

    # Non empty list
    immutable_list_1 = ImmutableList(2, ImmutableList(1, ImmutableList(3, ImmutableList(4, ImmutableList(6, ImmutableList(8, ImmutableList(9)))))))
    immutable_list_1_filtered = immutable_list_1.filter(lambda element: element > 1)
    assert immutable_list_1_filtered == ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(6, ImmutableList(8, ImmutableList(9))))))


# Generated at 2022-06-25 23:43:46.144083
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test cases
    immutable_list_0 = test_case_0()
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_3 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_4 = ImmutableList.of(1, 2, 3, 4, 5)
    # Test case 0
    x = integer_divide(4, 2)
    assert test_ImmutableList_filter(immutable_list_0, x) == immutable_list_0
    # Test case 1
    x_1 = integer_divide(2, 2)

# Generated at 2022-06-25 23:43:49.519489
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    expected = 6
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)

    actual = immutable_list_0.find(lambda x: x == 6)

    assert actual == expected


# Generated at 2022-06-25 23:43:57.748874
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list_0.filter(lambda x: x > 2).to_list() == [3, 4, 5]


# Generated at 2022-06-25 23:44:01.556029
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    if immutable_list_0 == ImmutableList():
        print(
            'Test case 0: PASSED'
        )
    else:
        print(
            'Test case 0: FAILED'
        )


# Generated at 2022-06-25 23:44:09.992084
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of("", "", "")
    immutable_list_2 = ImmutableList.of("", "")
    immutable_list_3 = ImmutableList.of("", "", "", "", "")
    immutable_list_4 = ImmutableList.of("", "", "", "", "", "", "")
    immutable_list_5 = ImmutableList.of("", "", "", "", "", "", "", "", "", "", "", "", "", "")
    immutable_list_6 = ImmutableList.of("", "", "", "")
    immutable_list_7 = ImmutableList.of("", "", "", "", "")

# Generated at 2022-06-25 23:44:13.277369
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    print(immutable_list_0.find(lambda n: n > 10))

if __name__ == '__main__':
    test_ImmutableList_find()

# Generated at 2022-06-25 23:44:17.197376
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = list_with_five_elements()
    function_0 = lambda x : x > 1
    result = immutable_list_0.find(function_0)
    assert result == 2


# Generated at 2022-06-25 23:44:19.897999
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None, None)
    assert(immutable_list_0 == immutable_list_1)



# Generated at 2022-06-25 23:44:30.042349
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList(None)
    list_0 = []
    immutable_list_0 = immutable_list_0.filter(lambda element: element in list_0)
    assert immutable_list_0 == ImmutableList(None)
    # Test case 1
    immutable_list_1 = ImmutableList(1)
    list_1 = [1]
    immutable_list_1 = immutable_list_1.filter(lambda element: element in list_1)
    assert immutable_list_1 == ImmutableList(1)
    # Test case 2
    immutable_list_2 = ImmutableList(0)
    list_2 = [1]
    immutable_list_2 = immutable_list_2.filter(lambda element: element in list_2)
    assert immutable_list_2 == Imm

# Generated at 2022-06-25 23:44:36.801290
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert (immutable_list_0 == immutable_list_1) == True

    immutable_list_2 = ImmutableList()
    immutable_list_2.head = 4
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = 4
    assert (immutable_list_2 == immutable_list_3) == True

    immutable_list_4 = ImmutableList()
    immutable_list_4.head = 3
    immutable_list_4.tail = ImmutableList()
    immutable_list_4.tail.head = 4
    immutable_list_5 = ImmutableList()
    immutable_list_5.head = 3
    immutable_list_5.tail = ImmutableList()
    immutable_list

# Generated at 2022-06-25 23:44:47.698610
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test 0 of find
    immutable_list_0 = ImmutableList.of(1, 2, 4000)
    boolean_0 = immutable_list_0.find(lambda a: a > 2000)
    assert boolean_0 == 4000
    # Test 1 of find
    immutable_list_0 = ImmutableList.of(1, 2, 4000)
    boolean_0 = immutable_list_0.find(lambda a: a > 4000)
    assert boolean_0 == None
    # Test 2 of find
    immutable_list_0 = ImmutableList.of(1, 2, 4000, 8)
    boolean_0 = immutable_list_0.find(lambda a: a > 1000)
    assert boolean_0 == 4000
    # Test 3 of find
    immutable_list_0 = ImmutableList.empty()
    boolean_0 = immutable_list

# Generated at 2022-06-25 23:44:53.199094
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test Case 1.0
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda x: x is not None)

    # Test Case 1.1
    immutable_list_2 = immutable_list_0.filter(lambda x: x is not None)

    # Test Case 1.2
    immutable_list_3 = immutable_list_1.filter(lambda x: x is not None)


# Generated at 2022-06-25 23:45:11.505319
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(7)
    immutable_list_2 = ImmutableList(7, immutable_list_1)
    immutable_list_3 = ImmutableList(7, immutable_list_2)
    immutable_list_4 = ImmutableList.of(7, immutable_list_3)
    immutable_list_5 = ImmutableList.of(7, immutable_list_4)
    immutable_list_6 = ImmutableList.of(2, 7, 4)
    immutable_list_7 = ImmutableList()
    immutable_list_8 = ImmutableList.of(7)
    immutable_list_9 = ImmutableList.of(3, 7)
    immutable_list_10 = ImmutableList.of(3, 7, 6)
    immutable_

# Generated at 2022-06-25 23:45:20.569759
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 1
    immutable_list_0 = ImmutableList.of('re', 'tenetur', 'ut', 'ea')
    immutable_list_0 = immutable_list_0.append('esse')
    immutable_list_0 = immutable_list_0.append('voluptate')
    immutable_list_0 = immutable_list_0.append('a')
    immutable_list_0 = immutable_list_0.append('voluptas')
    immutable_list_0 = immutable_list_0.append('qui')
    immutable_list_0 = immutable_list_0.append('culpa')
    immutable_list_0 = immutable_list_0.append('maiores')
    immutable_list_0 = immutable_list_0.append('id')
    immutable_list_0 = immutable_list_0.append

# Generated at 2022-06-25 23:45:31.567563
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(
        lambda x: x
    ) == ImmutableList.empty()

    assert ImmutableList.of(0, 1, 2, 3, 4, 5).filter(
        lambda x: x % 2 == 0
    ) == ImmutableList.of(0, 2, 4)

    assert ImmutableList.of(False, False, True, False, False).filter(
        lambda x: x
    ) == ImmutableList.of(True)


# Generated at 2022-06-25 23:45:40.834769
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    def f0():
        list_0 = ImmutableList.of(1, 2, 3, 4, 5)
        assert list_0.find(lambda v: v > 2) == 3
        assert list_0.find(lambda v: v > 8) is None

    def f1():
        list_1 = ImmutableList(1)
        assert list_1.find(lambda v: v > 0) == 1
        assert list_1.find(lambda v: v > 8) is None

    def f2():
        list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
        assert list_2.find(lambda v: v > 2) == 3
        assert list_2.find(lambda v: v > 8) is None

    f0()
    f1()
    f2()


# Generated at 2022-06-25 23:45:47.310851
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print("test_ImmutableList_find")
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 != 0) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.empty().find(lambda x: x % 2 == 0) == None


# Generated at 2022-06-25 23:45:54.837569
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1.5, None, 1.5)
    immutable_list_1 = ImmutableList(1.5)
    immutable_list_2 = ImmutableList(1, None, 1)
    immutable_list_0.filter((lambda x0: x0 > 2.7))
    immutable_list_1.filter((lambda x0: x0 > 1.5))
    immutable_list_2.filter((lambda x0: x0 > 0.6))


# Generated at 2022-06-25 23:46:03.293488
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(())
    immutable_list_0.filter(bool)
    immutable_list_0 = ImmutableList(None)
    immutable_list_0.filter(bool)
    immutable_list_0 = ImmutableList()
    immutable_list_0.filter(bool)
    immutable_list_0 = ImmutableList(())
    immutable_list_1 = immutable_list_0.filter(bool)
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = immutable_list_0.filter(bool)
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(bool)


# Generated at 2022-06-25 23:46:09.835944
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList(1, ImmutableList(2))
    assert immutable_list.find(lambda x: x == 2) == 2

    immutable_list = ImmutableList(2, ImmutableList(4,
                                  ImmutableList(6,
                                  ImmutableList(8))))
    assert immutable_list.find(lambda x: x == 8) == 8

    immutable_list = ImmutableList(1, ImmutableList(2,
                                  ImmutableList(3,
                                  ImmutableList(4,
                                  ImmutableList(5,
                                  ImmutableList(6,
                                  ImmutableList(7)))))))
    assert immutable_list.find(lambda x: x in (1, 2, 3, 4, 5, 6, 7)) == 1


# Generated at 2022-06-25 23:46:19.250620
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Initialization of test cases
    immutable_list_0 = ImmutableList.of(1, 1, 2, 3)
    immutable_list_1 = ImmutableList.of(1, 2, 1, 1)
    immutable_list_2 = ImmutableList.of(1, 1, 1, 1)
    immutable_list_3 = ImmutableList.of(1, 1, 1, 1, 1, 1, 1, 1)
    immutable_list_4 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList.of(0, 1, 2, 3)
    immutable_list_7 = ImmutableList.of(1, 1, 1, 1)

# Generated at 2022-06-25 23:46:28.642052
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList(True)
    immutable_list_3 = ImmutableList(True)
    assert immutable_list_2 == immutable_list_3
    immutable_list_4 = ImmutableList(True, immutable_list_3)
    immutable_list_5 = ImmutableList(True, immutable_list_3)
    assert immutable_list_4 == immutable_list_5
    immutable_list_6 = ImmutableList(True, immutable_list_5)
    immutable_list_7 = ImmutableList(True, immutable_list_5)
    assert immutable_list_6 == immutable_list_7

# Generated at 2022-06-25 23:47:10.936429
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()

    try:
        immutable_list_0.find(True)
        assert False
    except AttributeError:
        assert True



# Generated at 2022-06-25 23:47:13.631616
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case #0
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.find(lambda value : value == None) == None


# Generated at 2022-06-25 23:47:23.935817
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Tests for case 0
    immutable_list_0 = ImmutableList()
    result_find_0 = immutable_list_0.find(lambda x: x % 2 == 0)
    assert result_find_0 == None,\
        'Wrong result returned by method find.\nActual: {}\nExpected: {}'.\
        format(result_find_0, None)

    # Tests for case 1
    immutable_list_1 = ImmutableList.of(-2, 3, 2, 5, 2, -9, 20, -2)
    result_find_1 = immutable_list_1.find(lambda x: x % 2 == 1)

# Generated at 2022-06-25 23:47:28.393545
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None, ImmutableList(True), True)
    immutable_list_1 = ImmutableList(None, ImmutableList(True))
    if immutable_list_0.__eq__(immutable_list_1):
        raise RuntimeError


# Generated at 2022-06-25 23:47:36.841394
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = ';'
    immutable_list_0.tail = ImmutableList()
    immutable_list_0.tail.head = '|'
    immutable_list_0.tail.tail = ImmutableList()
    immutable_list_0.tail.tail.head = '='
    immutable_list_0 = immutable_list_0.tail.tail.tail.tail
    immutable_list_0.is_empty = True
    immutable_list_0 = immutable_list_0.filter(lambda c: c == ';')
    assert immutable_list_0.find(lambda c: c == ';') == ';'


# Generated at 2022-06-25 23:47:45.156340
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Init
    empty_list = ImmutableList()
    list_with_one_element = ImmutableList(10)
    list_with_one_element_and_none = ImmutableList(10, ImmutableList(None))
    list_with_two_element_and_none = ImmutableList(10, ImmutableList(11, ImmutableList(None)))
    list_with_two_element_and_another_one_equal_11 = ImmutableList(10, ImmutableList(11, ImmutableList(None)))
    list_with_two_element_and_another_one_equal_10 = ImmutableList(10, ImmutableList(11, ImmutableList(10)))

# Generated at 2022-06-25 23:47:56.169287
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1)
    immutable_list_1 = ImmutableList(2.7, immutable_list_0)
    immutable_list_2 = ImmutableList(1, immutable_list_1)
    immutable_list_3 = ImmutableList(5.5, immutable_list_2)
    immutable_list_4 = ImmutableList('a', immutable_list_3)
    immutable_list_5 = ImmutableList(2.2, immutable_list_4)
    immutable_list_6 = ImmutableList(None, immutable_list_5)
    immutable_list_7 = ImmutableList(4, immutable_list_6)
    immutable_list_8 = ImmutableList(3, immutable_list_7)
    immutable_list_9 = ImmutableList(6, immutable_list_8)

# Generated at 2022-06-25 23:48:03.144388
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # decleration of immutable_list_0
    immutable_list_0 = ImmutableList()
    # run method find with argument immutable_list_0
    result_0 = immutable_list_0.find(lambda arg_0: arg_0 > 5)
    # assert if result_0 equals None
    if result_0 == None:
        pass
    else:
        raise ValueError
    # decleration of immutable_list_1
    immutable_list_1 = ImmutableList(8)
    # run method find with argument immutable_list_1
    result_1 = immutable_list_1.find(lambda arg_1: arg_1 > 5)
    # assert if result_1 equals 8
    if result_1 == 8:
        pass
    else:
        raise ValueError
    # decleration of immutable_list_2

# Generated at 2022-06-25 23:48:12.279003
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of('a', 'b', 'c')
    immutable_list_1 = ImmutableList.of('d')
    immutable_list_2 = ImmutableList.of('e')
    immutable_list_3 = immutable_list_0 + immutable_list_1 + immutable_list_2
    assert immutable_list_3.find(lambda x: x == 'e') == 'e'
    assert immutable_list_3.find(lambda x: x == 'a') == 'a'
    assert immutable_list_3.find(lambda x: x == 'b') == 'b'
    assert immutable_list_3.find(lambda x: x == 'c') == 'c'
    assert immutable_list_3.find(lambda x: x == 'd') == 'd'
    assert immutable_list

# Generated at 2022-06-25 23:48:21.875239
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test case with one element in list
    immutable_list_0 = ImmutableList(1)
    immutable_list_1 = ImmutableList(1)
    # Python expression : immutable_list_0 == immutable_list_1
    assert_expression1 = (immutable_list_0 == immutable_list_1)
    # Python expression : True
    assert_expression2 = (True)
    # Check equality of tested expressions
    assert assert_expression1 == assert_expression2, 'Check if expression immutable_list_0 == immutable_list_1 equals to expression True'
    # Test case with two elements in list
    immutable_list_2 = ImmutableList(1, ImmutableList(2))
    immutable_list_3 = ImmutableList(1, ImmutableList(2))
    # Python expression : immutable_list_2 == immutable_list_

# Generated at 2022-06-25 23:49:01.871808
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()

    assert immutable_list_0 == immutable_list_0
    assert immutable_list_0 == ImmutableList(is_empty=True)

    immutable_list_1 = ImmutableList(1)

    assert immutable_list_1 == immutable_list_1
    assert immutable_list_1 == ImmutableList(1)

    immutable_list_2 = ImmutableList(1, ImmutableList(2))

    assert immutable_list_2 == immutable_list_2
    assert immutable_list_2 == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-25 23:49:11.966083
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6)))))).find(lambda x: x == 4) == 4
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6)))))).find(lambda x: x == 7) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6)))))).find(lambda x: x == 3) == 3

# Generated at 2022-06-25 23:49:15.703000
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_ImmutableList = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList.empty())))
    res = test_ImmutableList.find(lambda x: x > 2)
    expected = 3
    assert res == expected


# Generated at 2022-06-25 23:49:23.342449
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    list_0 = ImmutableList.empty()
    filter_fn_0 = lambda x: x
    filter_fn_1 = lambda x: x
    filter_fn_2 = lambda x: x
    filter_fn_3 = lambda x: x
    filter_fn_4 = lambda x: x
    filter_fn_5 = lambda x: x
    filter_fn_6 = lambda x: x
    filter_fn_7 = lambda x: x
    filter_fn_8 = lambda x: x
    filter_fn_9 = lambda x: x
    filter_fn_10 = lambda x: x
    filter_fn_11 = lambda x: x
    filter_fn_12 = lambda x: x
    filter_fn_13 = lambda x: x
    filter_fn_14 = lambda x: x
    filter_

# Generated at 2022-06-25 23:49:25.604224
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    
    

# Generated at 2022-06-25 23:49:35.730455
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    il0 = ImmutableList()
    assert il0.find(lambda x: x == 1) == None
    assert il0.find(lambda x: True) == None

    il1 = ImmutableList(1, il0)
    assert il1.find(lambda x: x == 1) == 1
    assert il1.find(lambda x: True) == 1

    il2 = ImmutableList(2, il1)
    assert il2.find(lambda x: x == 2) == 2
    assert il2.find(lambda x: True) == 2

    il3 = ImmutableList(3, il2)
    assert il3.find(lambda x: x == 3) == 3
    assert il3.find(lambda x: True) == 3


# Generated at 2022-06-25 23:49:43.287169
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    #
    #
    # array to test
    array_0 = [0, False, None, 0.0, 1]
    #
    #
    # Initialize empty list
    immutable_list_0 = ImmutableList.empty()

    #
    #
    # Adding with append
    immutable_list_0 = immutable_list_0.append(array_0[0])
    immutable_list_0 = immutable_list_0.append(array_0[1])
    immutable_list_0 = immutable_list_0.append(array_0[2])
    immutable_list_0 = immutable_list_0.append(array_0[3])
    immutable_list_0 = immutable_list_0.append(array_0[4])

    #
    #
    # Testing True case

# Generated at 2022-06-25 23:49:55.347813
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    # TEST CASE 0 : Find method on empty immutable list
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.find(lambda x: x == 0) == None, "Test case 0 failed"

    # TEST CASE 1 : Find method on list with one element
    immutable_list_1 = ImmutableList(1)
    # Find element that is in the immutable list
    assert immutable_list_1.find(lambda x: x == 1) == 1, "Test case 1 failed"
    # Find element that is not in the immutable list
    assert immutable_list_1.find(lambda x: x == 0) == None, "Test case 1 failed"

    # TEST CASE 2 : Find method on list with multiple elements
    immutable_list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    #

# Generated at 2022-06-25 23:50:08.753497
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_1)
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = 0
    immutable_list_2.is_empty = False
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = 0
    immutable_list_3.is_empty = False
    assert immutable_list_2.__eq__(immutable_list_3)
    immutable_list_4 = ImmutableList()
    immutable_list_4.head = 0
    immutable_list_4.is_empty = False
    immutable_list_5 = ImmutableList()
    immutable_list_5.head = 1
    immutable_list

# Generated at 2022-06-25 23:50:15.500342
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(is_empty=True)
    immutable_list_2 = ImmutableList(is_empty=False)
    assert (immutable_list_0 == immutable_list_1)
    assert not (immutable_list_0 == immutable_list_2)
    assert not (immutable_list_0 == None)
