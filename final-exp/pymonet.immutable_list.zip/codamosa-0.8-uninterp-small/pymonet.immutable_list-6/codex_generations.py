

# Generated at 2022-06-25 23:40:31.890609
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    callable_0 = None
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    immutable_list_1 = immutable_list_0.filter(callable_0)


# Generated at 2022-06-25 23:40:38.937339
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    try:
        callable_0 = function_0
        immutable_list_0 = ImmutableList.of(5, 6, 7, 8, 9)
        immutable_list_1 = immutable_list_0.filter(callable_0)
        assert immutable_list_1.head == 5
        assert immutable_list_1.tail.head == 7
        assert immutable_list_1.tail.tail.head == 9
        assert immutable_list_1.tail.tail.tail is None
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 23:40:48.624996
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Set up fixture
    callable_0 = None
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()

    assert immutable_list_0.find(callable_0) == None

    assert immutable_list_1.find(callable_0) == None

    assert immutable_list_2.find(callable_0) == 1

    assert immutable_list_3.find(callable_0) == 2

    assert immutable_list_4.find(callable_0) == 3

    assert immutable_list_5.find(callable_0) == None



# Generated at 2022-06-25 23:40:52.098906
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
  immutable_list_0 = ImmutableList(None, None)

  immutable_list_1 = immutable_list_0.filter(int)

  assert(immutable_list_1 == None)



# Generated at 2022-06-25 23:40:57.658545
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_0_0 = ImmutableList()
    immutable_list_0_1 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1_0 = ImmutableList()
    boolean_0 = immutable_list_0 == immutable_list_1
    boolean_1 = immutable_list_0_0 == immutable_list_0_1
    boolean_2 = immutable_list_1 == immutable_list_1_0
    assert boolean_0 == boolean_1 and boolean_1 == boolean_2


# Generated at 2022-06-25 23:41:00.009988
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None, None)
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:02.236280
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    x = ImmutableList.of(1, 2, 3, 4).filter(lambda x: x%2 == 0)
    y = ImmutableList.of(2, 4)

    assert x == y


# Generated at 2022-06-25 23:41:09.979275
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    callable_0 = None
    list_0 = ImmutableList(2, ImmutableList(4, ImmutableList(5, ImmutableList(5, ImmutableList(5, ImmutableList())))))

    # Act
    call_result_0 = list_0.filter(lambda n: n == 5)
    call_result_1 = list_0.filter(lambda n: n == 2)

    # Assert
    assert call_result_0 == ImmutableList(5, ImmutableList(5, ImmutableList(5, ImmutableList())))
    assert call_result_1 == ImmutableList(2, ImmutableList())


# Generated at 2022-06-25 23:41:19.102808
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # ImmutableList.find()
    assert ImmutableList.of(0, 1, 2).find(lambda x: x % 2 == 0) == 0
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 != 0) == 1
    assert ImmutableList.of(0, 1, 2).find(lambda x: x % 2 != 0) == 1
    assert ImmutableList.of(0, 1, 2).find(lambda x: x % 2 == 0) == 0
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2

# Generated at 2022-06-25 23:41:24.713839
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(('d', 'b'))
    immutable_list_0 = immutable_list_0.__add__(ImmutableList(('b', 'b')))
    immutable_list_0 = immutable_list_0.__add__(ImmutableList(('c', 'a')))
    callable_0 = immutable_list_0.find(lambda x : x[0] == 'b')


# Generated at 2022-06-25 23:41:35.809621
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.empty().filter(lambda x: x == 1) == ImmutableList.empty()



# Generated at 2022-06-25 23:41:44.072497
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    result = True
    for i in range(0, 100000):
        if i % 2 == 0:
            immutable_list_0 = ImmutableList(i)
            immutable_list_1 = immutable_list_0.filter(lambda x : x % 2 == 1)
            if immutable_list_1.is_empty != True:
                result = False
                break
        else:
            immutable_list_0 = ImmutableList(i)
            immutable_list_1 = immutable_list_0.filter(lambda x : x % 2 == 1)
            if immutable_list_1.is_empty != False or immutable_list_1.head != i:
                result = False
                break
    print(result)


# Generated at 2022-06-25 23:41:51.172707
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    Immutable_List_0 = ImmutableList.empty()
    Immutable_List_1 = ImmutableList.of(1, 2, 3, 4, 5)
    case_0 = ImmutableList()
    case_1 = Immutable_List_1

    # When
    case_0_result = case_0.filter(lambda x: x > 10)
    case_1_result = case_1.filter(lambda x: x > 3)

    # Then
    assert case_0_result == ImmutableList(is_empty=True)
    assert case_1_result == ImmutableList(4, ImmutableList(5))


# Generated at 2022-06-25 23:41:59.305336
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ImmutableList.empty()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()

# Generated at 2022-06-25 23:42:04.225357
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3)
    res = immutable_list_0.find(int)
    assert res == 0



# Generated at 2022-06-25 23:42:07.294568
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    try:
        test_case_0()
    except (TypeError, ValueError) as e:
        print(e)
    except:
        print('Unexpected exception!')
    else:
        print('Passed!')


# Generated at 2022-06-25 23:42:18.896214
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Initialize arguments
    init_arg_0 = {"head": None, "tail": None, "isEmpty": False}
    init_arg_1 = {"head": None, "tail": None, "isEmpty": True}
    init_arg_2 = {"head": None, "tail": init_arg_0, "isEmpty": False}
    init_arg_3 = {"head": None, "tail": init_arg_2, "isEmpty": False}
    init_arg_4 = {"head": None, "tail": init_arg_2, "isEmpty": False}
    init_arg_5 = {"head": init_arg_4, "tail": init_arg_3, "isEmpty": False}
    init_arg_6 = {"head": init_arg_5, "tail": None, "isEmpty": False}
   

# Generated at 2022-06-25 23:42:25.593516
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of("ima")
    immutable_list_1 = ImmutableList.of("ima", "a", "bmw")
    assert immutable_list_0.find(lambda c: c == "ima") == "ima"
    assert immutable_list_1.find(lambda c: c == "a") == "a"
    assert immutable_list_1.find(lambda c: c == "volvo") == None


# Generated at 2022-06-25 23:42:34.384869
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = ImmutableList.of('1', '1')
    immutable_list_3 = ImmutableList.of('1', '3')
    immutable_list_4 = ImmutableList.of('1', '1')
    assert immutable_list_2.filter(lambda x: x == '1') == immutable_list_3
    assert immutable_list_1.filter(lambda x: x == '1') == immutable_list_0
    assert immutable_list_2.filter(lambda x: x == '1') == immutable_list_4


# Generated at 2022-06-25 23:42:37.744337
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(True, True, True)
    assert immutable_list_0.find(lambda x: x) == True
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_1.find(lambda x: x) is None


# Generated at 2022-06-25 23:42:52.516205
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def filter_f(a: Optional[int]) -> bool:
        return bool(a % 2)

    immutable_list_0 = ImmutableList.of(1)
    immutable_list_1 = immutable_list_0
    immutable_list_0 = immutable_list_1.filter(filter_f)
    assert immutable_list_0 == ImmutableList.of(1)

    immutable_list_0 = ImmutableList.of(1, 2)
    immutable_list_1 = immutable_list_0
    immutable_list_0 = immutable_list_1.filter(filter_f)
    assert immutable_list_0 == ImmutableList.of(1)

    immutable_list_0 = ImmutableList.of(3, 2, 1, 2)
    immutable_list_1 = immutable_list_0
    immutable_list_

# Generated at 2022-06-25 23:43:00.657859
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_cases = [
        (
            [None, 1, 2, 3, 4, 5],
            lambda x: x == 2,
            [2]
        ),
        (
            [None, 1, 2, 3, 4, 5],
            lambda x: x % 2 == 1,
            [1, 3, 5]
        ),
        (
            [None, 1, 2, 3, 4, 5],
            lambda x: x > 6,
            []
        ),
    ]

    for case in test_cases:
        assert ImmutableList.of(*case[0]).filter(case[1]).to_list() == case[2]


# Generated at 2022-06-25 23:43:03.366281
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(42)
    assert immutable_list_0.find(lambda x: x == 42) == 42


# Generated at 2022-06-25 23:43:11.450105
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 != 0)
    immutable_list_2 = immutable_list_1.filter(lambda x: x > 1 and x % 2 != 0)
    assert immutable_list_0.filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3, 4)
    assert immutable_list_1 == ImmutableList.of(1, 3)
    assert immutable_list_2 == ImmutableList.of(3)


# Generated at 2022-06-25 23:43:20.691042
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of("ab", "cd", "e")
    assert immutable_list_0.filter(lambda x: x is not None).to_list() == ["ab", "cd", "e"]

    immutable_list_1 = ImmutableList.of("ab", "cd", "e")
    assert immutable_list_1.filter(lambda x: x is not None).to_list() == ["ab", "cd", "e"]

    immutable_list_2 = ImmutableList.of("ab", "cd", "e")
    assert immutable_list_2.filter(lambda x: x is not None).to_list() == ["ab", "cd", "e"]

    immutable_list_3 = ImmutableList.of("ab")

# Generated at 2022-06-25 23:43:32.466345
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(40, 5, '', 'C', '>', 'v', 2, 46, '', '', '', 30, 42, 42, 't', '', '', '', '', '', 'T', 'G', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'l', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')

# Generated at 2022-06-25 23:43:42.097604
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(None)
    Number.assert_equals(immutable_list_0.find(lambda x: x > 2), None)
    Number.assert_equals(immutable_list_0.find(lambda x: x == 2), None)
    immutable_list_1 = ImmutableList.of(None)
    immutable_list_1 = immutable_list_1.append(4)
    immutable_list_1 = immutable_list_1.append(2)
    immutable_list_1 = immutable_list_1.append(1)
    Number.assert_equals(immutable_list_1.find(lambda x: x > 2), 4)
    immutable_list_2 = ImmutableList()
    immutable_list_2 = immutable_list_2.append(2)
    immutable

# Generated at 2022-06-25 23:43:49.609791
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(85)
    immutable_list_1 = ImmutableList.of(939, 524)
    immutable_list_2 = ImmutableList.of(871, 871)
    immutable_list_expected_2 = ImmutableList.of(871, 871)
    immutable_list_3 = ImmutableList.of(40, 871)
    immutable_list_4 = ImmutableList.of(42, 42)
    immutable_list_expected_4 = ImmutableList.of(42, 42)
    immutable_list_5 = ImmutableList.of(871, 42)
    immutable_list_expected_5 = ImmutableList.of(42)
    immutable_list_6 = ImmutableList.of(939, 524)
    immutable_list_expected_

# Generated at 2022-06-25 23:43:55.831264
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1, ImmutableList(2))
    immutable_list_1 = ImmutableList()

    result_0 = immutable_list_0.find(lambda arg: arg % 2 == 1)
    result_1 = immutable_list_1.find(lambda arg: arg % 2 == 1)

    assert result_0 == 1
    assert result_1 == None


# Generated at 2022-06-25 23:44:00.542703
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 2)
    assert immutable_list_1.head == 3
    assert immutable_list_1.tail.head == 4


# Generated at 2022-06-25 23:44:12.119098
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """Test the ImmutableList against the use case below"""

    # Use case
    # filter(fn)
    # Returns new ImmutableList with only this elements that passed info argument returns True
    # @param fn: function to call with ImmutableList value
    # @type fn: Function(A) -> bool
    # @returns: ImmutableList[A]
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = immutable_list_0.filter((lambda immutable_list_element: immutable_list_element > 2))
    immutable_list_2 = immutable_list_1.map((lambda immutable_list_element: immutable_list_element + 1))
    expect_value = 3
    if (immutable_list_2.head != expect_value):
        raise AssertionError()


# Generated at 2022-06-25 23:44:17.031423
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 10) is None
    assert ImmutableList.empty().find(lambda x: x == 3) is None


# Generated at 2022-06-25 23:44:22.076839
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # assert immutable_list_0.filter(lambda x: True).to_list() == []
    # print(100)
    # assert immutable_list_0.filter(lambda x: False).to_list() == []
    assert ImmutableList(0).filter(lambda x: True).to_list() == [0]
    assert ImmutableList(0).filter(lambda x: False).to_list() == []



# Generated at 2022-06-25 23:44:26.013319
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('foo', 'bar', 'foobar')
    assert immutable_list_0.filter(lambda a: len(a) > 3).to_list() == ['foobar']



# Generated at 2022-06-25 23:44:34.624075
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # case 1: {ImmutableList.head: 4, ImmutableList.tail: {ImmutableList.head: 10, ImmutableList.tail: None } }
    immutable_list_0 = ImmutableList(4, ImmutableList(10))
    immutable_list_1 = immutable_list_0.filter((lambda value: 4 if value > 5 else 0))
    assert immutable_list_1.head == 4
    assert immutable_list_1.tail.head == 10
    assert immutable_list_1.tail.tail is None
    # case 2: {ImmutableList.head: 10, ImmutableList.tail: {ImmutableList.head: None, ImmutableList.tail: None } }
    immutable_list_2 = immutable_list_0.filter((lambda value: 10))
    assert immutable_list_2.head == 10
   

# Generated at 2022-06-25 23:44:44.772300
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 3)
    assert immutable_list_0 == ImmutableList(4, ImmutableList(5))

    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 3 and x < 5)
    assert immutable_list_0 == ImmutableList(4)

    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 5)
    assert immutable_list_0 == ImmutableList(is_empty=True)

# Generated at 2022-06-25 23:44:54.605294
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(True, False, True)
    immutable_list_2 = ImmutableList.of("test", 1, 2, 3)

    assert immutable_list_0.find() is None
    assert immutable_list_1.find() is None
    assert immutable_list_2.find() is None

    assert immutable_list_0.find(None) is None
    assert immutable_list_1.find(None) is None
    assert immutable_list_2.find(None) is None

    assert immutable_list_0.find(lambda x: True) is None
    assert immutable_list_1.find(lambda x: True) is None
    assert immutable_list_2.find(lambda x: True) is None

    assert immutable_list_0

# Generated at 2022-06-25 23:45:02.438846
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(True)
    immutable_list_1 = ImmutableList(False)
    immutable_list_2 = ImmutableList(None)
    immutable_list_3 = ImmutableList(True, immutable_list_1)
    immutable_list_4 = ImmutableList(None, immutable_list_3)
    immutable_list_5 = ImmutableList(True, immutable_list_4)
    immutable_list_6 = ImmutableList(False, immutable_list_5)
    immutable_list_7 = ImmutableList(False, immutable_list_6)
    immutable_list_8 = ImmutableList(True, immutable_list_7)

    func_0 = lambda x : x != True
    immutable_list_8.filter(func_0)


# Generated at 2022-06-25 23:45:12.887846
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(0)
    immutable_list_2 = ImmutableList(1)
    immutable_list_3 = ImmutableList(1, immutable_list_2)
    immutable_list_4 = ImmutableList(2, immutable_list_3)
    immutable_list_5 = ImmutableList(3, immutable_list_4)
    immutable_list_5.filter(lambda immutable_list_3: immutable_list_3)
    immutable_list_0.filter(lambda immutable_list_3: immutable_list_3)
    immutable_list_1.filter(lambda immutable_list_3: immutable_list_3)
    immutable_list_2.filter(lambda immutable_list_3: immutable_list_3)


# Generated at 2022-06-25 23:45:19.193277
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    list_1 = list_0.filter(lambda x: x % 2)
    list_2 = ImmutableList.empty()

    assert list_1 == ImmutableList.of(1, 3, 5)
    assert list_2 == ImmutableList()

    list_3 = ImmutableList.of(1, 2)
    list_4 = list_3.filter(None)

    assert list_3 == list_4


# Generated at 2022-06-25 23:45:33.345828
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1)
    assert list.find(lambda item: item == 1) == 1
    list = ImmutableList.of(2, 1)
    assert list.find(lambda item: item == 1) == 1
    list = ImmutableList.of(1, 2)
    assert list.find(lambda item: item == 2) == 2
    list = ImmutableList.of(1, 2)
    assert list.find(lambda item: item == 3) is None
    list = ImmutableList.of(1, 2)
    assert list.find(None) is None


# Generated at 2022-06-25 23:45:42.197348
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    fn = lambda x: x > 2
    immutable_list_0 = ImmutableList.of(4, 2, 1)
    result_0 = immutable_list_0.find(fn)
    assert result_0 == 4
    immutable_list_1 = ImmutableList.of(3, 2, 1)
    result_1 = immutable_list_1.find(fn)
    assert result_1 == 3
    immutable_list_2 = ImmutableList.of(3, 2, 0)
    result_2 = immutable_list_2.find(fn)
    assert result_2 is None
    immutable_list_3 = ImmutableList.of(2, 2, 2)
    result_3 = immutable_list_3.find(fn)
    assert result_3 is None

# Generated at 2022-06-25 23:45:51.113062
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    ImmutableList.of(immutable_list_0)
    immutable_list_2 = ImmutableList(1)
    ImmutableList.of(immutable_list_2)
    immutable_list_3 = ImmutableList(1, immutable_list_0)
    ImmutableList.of(immutable_list_2, immutable_list_2)
    # fn is lambda x: x.value != 10, should return 1
    assert immutable_list_3.find(lambda x: x != 10) == 1


# Generated at 2022-06-25 23:45:58.389801
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Case 0
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)

    if immutable_list_0.find(lambda x : x == 5):
        print("Sucess")
    else : 
        print("Fail")

    # Case 1
    immutable_list_1 = ImmutableList.of(10, 2, 3, 4, 5, 6)

    if not immutable_list_1.find(lambda x : x == 1):
        print("Sucess")
    else :
        print("Fail")



# Generated at 2022-06-25 23:46:03.599260
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = True
    immutable_list_0.tail = immutable_list_0
    immutable_list_0.is_empty = True
    immutable_list_1 = ImmutableList()
    immutable_list_1.head = 0
    immutable_list_1.tail = immutable_list_1
    immutable_list_1.is_empty = False
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = -1
    immutable_list_2.tail = immutable_list_0
    immutable_list_2.is_empty = False
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = 0
    immutable_list_3.tail = immutable_list_2

# Generated at 2022-06-25 23:46:07.987926
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None


# Generated at 2022-06-25 23:46:17.308685
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    def assert_find_result(expected_result, immutable_list, fn):
        test_ordered = immutable_list.find(fn)
        assert expected_result == test_ordered, f'Got {test_ordered}'

    # Test find without conditions
    immutable_list_0 = ImmutableList.empty()
    expected_result_0 = None
    fn_0 = lambda x: True
    assert_find_result(expected_result_0, immutable_list_0, fn_0)

    # Test find with condition
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    expected_result_1 = 1
    fn_1 = lambda x: x == 1
    assert_find_result(expected_result_1, immutable_list_1, fn_1)


# Generated at 2022-06-25 23:46:26.576197
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    immutable_list_0 = ImmutableList()
    immutable_list_0.head = ('5', )
    immutable_list_0.tail = None
    immutable_list_0.is_empty = False

    immutable_list_1 = ImmutableList()
    immutable_list_1.head = ('6', )
    immutable_list_1.tail = None
    immutable_list_1.is_empty = False

    immutable_list_2 = ImmutableList()
    immutable_list_2.head = ('7', )
    immutable_list_2.tail = None
    immutable_list_2.is_empty = False

    immutable_list_3 = ImmutableList()
    immutable_list_3.head = immutable_list_1
    immutable_list_3.tail = immutable_list_2

# Generated at 2022-06-25 23:46:30.127696
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1,2,3,4,5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1,2,3,4,5).find(lambda x: x == 6) is None


# Generated at 2022-06-25 23:46:37.506017
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.find(lambda x: True is False) == None
    assert immutable_list_0.find(lambda x: False is False) == None
    assert immutable_list_0.find((lambda x: None is None)) == None
    assert immutable_list_0.find(lambda x: None is None) == None
    assert immutable_list_0.find((lambda x: False is True)) == None
    # Unit test for method filter of class ImmutableList

# Generated at 2022-06-25 23:46:54.967076
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 7) is None
    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7).find(lambda x: x % 2 == 0) == 0
    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7).find(lambda x: x % 2 != 0) == 1
    assert ImmutableList.of(3, 3, 3, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 0, 1, 0).find(lambda x: x == 1) == 1

# Generated at 2022-06-25 23:47:06.537702
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList()
    int_0 = 0
    def lambda_0():
        return (immutable_list_0.find(lambda immutable_list_0: immutable_list_0 > int_0) == None)
    # Condition for test case 0
    assert lambda_0()

    # Test case 1
    immutable_list_1 = ImmutableList()
    int_1 = 100
    def lambda_1():
        return (immutable_list_1.find(lambda immutable_list_1: immutable_list_1 > int_1) == None)
    # Condition for test case 1
    assert lambda_1()

# Test in case 0
test_case_0()
# Test in case 1
test_ImmutableList_find()

print("Nice!")

# Generated at 2022-06-25 23:47:15.639428
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: x==3) == None
    assert ImmutableList().find(lambda x: x==1) == None
    assert ImmutableList(True).find(lambda x: x) == True
    assert ImmutableList(False).find(lambda x: x) == None
    assert ImmutableList(1).find(lambda x: x==1) == 1
    assert ImmutableList(3).find(lambda x: x==1) == None
    assert ImmutableList(1, 2, 3, 4).find(lambda x: x==3) == 3


# Generated at 2022-06-25 23:47:26.286512
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList('test')
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList.of(2, 3, 5, 7)
    immutable_list_3 = ImmutableList.of('test')
    immutable_list_4 = ImmutableList.of('test', 'string')
    immutable_list_5 = ImmutableList.of(10, 'test', 10.0)
    immutable_list_6 = ImmutableList.of('test', 10, 'string')

    assert immutable_list_0.find(lambda a: a == 'test') == 'test',\
        '[FAILED] test_ImmutableList_find :: test case 0'

# Generated at 2022-06-25 23:47:35.906317
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # test case 0
    assert ImmutableList().find(lambda x: x != 0) == None
    assert ImmutableList(1).find(lambda x: x != 0) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x != 0) == 1
    assert ImmutableList(0, ImmutableList(2)).find(lambda x: x != 0) == 2
    assert ImmutableList(0, ImmutableList(0)).find(lambda x: x != 0) == None
    assert ImmutableList(0, ImmutableList(1)).find(lambda x: x != 0) == 1
    assert ImmutableList(1, ImmutableList(0)).find(lambda x: x != 0) == 1
    assert ImmutableList(1, ImmutableList(1)).find(lambda x: x != 0) == 1

# Generated at 2022-06-25 23:47:41.781858
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test that method find works with ImmutableList when argument is function
    assert ImmutableList.of(1, 2, 3, 4, 6).find(lambda x: x == 4) == 4
    # Test that method find works with ImmutableList when argument is lambda
    assert ImmutableList.of(1, 2, 3, 4, 6).find(lambda x: x == 2) == 2
    # Test that method find works correctly with empty ImmutableList
    assert ImmutableList.empty().find(lambda x: x == 2) is None


# Generated at 2022-06-25 23:47:44.555421
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(12, 13)
    class_0 = immutable_list_0.find((lambda x: x > 12))
    assert type(class_0) == int
    assert class_0 == 13


# Generated at 2022-06-25 23:47:49.178780
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_ImmutableList = ImmutableList.of(11, 9, 8, 8, 5, 9, 6)

    assert test_ImmutableList.find(lambda x: x>80) == None
    assert test_ImmutableList.find(lambda x: x<1) == None
    assert test_ImmutableList.find(lambda x: x==5) == 5
    


# Generated at 2022-06-25 23:47:59.809624
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    test_case_0()

    # Test case 1
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert immutable_list_0.find(lambda x: x == 4) == None
    assert immutable_list_0.find(lambda x: x == 2) == 2
    assert immutable_list_0.find(lambda x: x == 1) == 1
    assert immutable_list_0.find(lambda x: x == 3) == 3

    # Test case 2
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert immutable_list_0.find(lambda x: x == 2) == 2
    assert immutable_list_0.find(lambda x: x == 4) == None
   

# Generated at 2022-06-25 23:48:10.684894
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1.head = '5'
    immutable_list_2 = ImmutableList()
    immutable_list_2.head = '5'
    immutable_list_2.tail = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_3.head = '10'
    immutable_list_3.tail = ImmutableList()
    immutable_list_3.tail.head = '5'
    immutable_list_4 = ImmutableList()
    immutable_list_4.head = '10'
    immutable_list_4.tail = ImmutableList()
    immutable_list_4.tail.head = '5'
    immutable_list_4.tail.tail = ImmutableList()

# Generated at 2022-06-25 23:48:29.257547
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(1, immutable_list_1)
    assert immutable_list_0.__len__() == 0
    assert immutable_list_1.__len__() == 1
    assert immutable_list_2.__len__() == 2


# Generated at 2022-06-25 23:48:33.341924
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = immutable_list_0 + immutable_list_1
    print('Expected:', 'ImmutableList[]')
    print('Received:', immutable_list_2)


# Generated at 2022-06-25 23:48:39.762447
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()

    immutable_list_1 = ImmutableList.of('foo', 'bar')

    immutable_list_2 = ImmutableList.of('foo', 'bar')

    assert immutable_list_0.filter(lambda x: x == 'foo') == ImmutableList.empty()

    assert immutable_list_1.filter(lambda x: x == 'foo') == ImmutableList.of('foo')

    assert immutable_list_2.filter(lambda x: x == 'foo') == ImmutableList.of('foo')


# Generated at 2022-06-25 23:48:49.220289
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = immutable_list_0.unshift('9fb5d')
    assert immutable_list_0.head == '9fb5d'
    immutable_list_0 = immutable_list_0.unshift('11qx')
    assert immutable_list_0.head == '11qx'
    immutable_list_0 = immutable_list_0.unshift('b8')
    assert immutable_list_0.head == 'b8'
    immutable_list_0 = immutable_list_0.unshift('15l')
    assert immutable_list_0.head == '15l'
    immutable_list_0 = immutable_list_0.unshift('5td5')
    assert immutable_list_0.head == '5td5'
    immutable

# Generated at 2022-06-25 23:48:51.290634
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList(10, ImmutableList(20, ImmutableList(30, ImmutableList(40))))
    print(immutable_list)


# Generated at 2022-06-25 23:48:56.546215
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Initialize object with Empty constructor
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.__len__() == 0, 'Test 0 failed'
    # Initialize object with constructor with params
    immutable_list_0 = ImmutableList('Test String')
    assert immutable_list_0.__len__() == 1, 'Test 1 failed'


# Generated at 2022-06-25 23:49:03.516900
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    immutable_list_0 = ImmutableList.of("", [], False, [], [], None, None, "", "", None, [], [], None, "", "", "", "", "", "", None, "", [], "")
    immutable_list_1 = immutable_list_0.append("")
    assert immutable_list_1 == ImmutableList.of("", [], False, [], [], None, None, "", "", None, [], [], None, "", "", "", "", "", "", None, "", [], "", "")
    immutable_list_1 = ImmutableList.of("", [], False, [], [], None, None, "", "", None, [], [], None, "", "", "", "", "", "", None, "", [], "").append("")

# Generated at 2022-06-25 23:49:13.874986
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(1)
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList(2)
    immutable_list_5 = ImmutableList(3)
    immutable_list_6 = ImmutableList(4, immutable_list_1)
    immutable_list_7 = ImmutableList(4, immutable_list_1)
    immutable_list_8 = ImmutableList(4, immutable_list_0)
    immutable_list_9 = ImmutableList(4, immutable_list_2)
    immutable_list_10 = ImmutableList(4, immutable_list_1)
    immutable_list_11 = ImmutableList(4, immutable_list_1)

# Generated at 2022-06-25 23:49:22.212850
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of('Lorem', 'ipsum', 'dolor', 'sit', 'amet')
    assert immutable_list_0.find(lambda x: True) == 'Lorem'
    assert immutable_list_0.find(lambda x: False) is None
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list_1.find(lambda x: x > 4) == 5
    assert immutable_list_1.find(lambda x: x > 3) == 4
    assert immutable_list_1.find(lambda x: x > 2) == 3
    assert immutable_list_1.find(lambda x: x > 1) == 2
    assert immutable_list_1.find(lambda x: x > 1) == 2
    assert immutable_

# Generated at 2022-06-25 23:49:24.047559
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    immutable_list_0 = ImmutableList()
    assert str(immutable_list_0) == 'ImmutableList[]'


# Generated at 2022-06-25 23:49:54.905251
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(2, ImmutableList(1))
    immutable_list_1 = ImmutableList(2, ImmutableList(1))
    assert immutable_list_0.__eq__(immutable_list_1) is True


# Generated at 2022-06-25 23:50:01.819592
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    expected = ImmutableList.of(1, 3)

    result = ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1)

    assert expected == result


# Generated at 2022-06-25 23:50:06.225532
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list_0 = ImmutableList(ImmutableList(), None, False)

    # Test case with a list of integers
    assert immutable_list_0.to_list() == [ImmutableList(), None]

    immutable_list_1 = ImmutableList()

    # Test case with a list of integers
    assert immutable_list_1.to_list() == []


# Generated at 2022-06-25 23:50:09.302443
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_1 = immutable_list_0.unshift(0)
    immutable_list_2 = immutable_list_1.unshift(100)
    assert(immutable_list_2.head == 100)
    immutable_list_3 = immutable_list_2.unshift(99)
    assert(immutable_list_3.head == 99)


# Generated at 2022-06-25 23:50:18.061428
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 2, 4, 6, 8)
    immutable_list_1 = immutable_list_0.filter(lambda x : x % 2 == 0)
    immutable_list_2 = immutable_list_0.filter(None)
    immutable_list_3 = immutable_list_0.filter(False)

    assert immutable_list_1.to_list() == [0, 2, 4, 6, 8]
    assert immutable_list_2.to_list() == [0, 2, 4, 6, 8]
    assert immutable_list_3.to_list() == [0, 2, 4, 6, 8]


# Generated at 2022-06-25 23:50:26.987992
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.__len__() == 0
    immutable_list_1 = ImmutableList(8)
    assert immutable_list_1.__len__() == 1
    immutable_list_2 = ImmutableList(7, immutable_list_1)
    assert immutable_list_2.__len__() == 2
    immutable_list_3 = ImmutableList(3, immutable_list_2)
    assert immutable_list_3.__len__() == 3
    immutable_list_4 = ImmutableList(6, immutable_list_3)
    assert immutable_list_4.__len__() == 4
    immutable_list_5 = ImmutableList(1, immutable_list_4)
    assert immutable_list_5.__len__() == 5
    immutable_