

# Generated at 2022-06-25 23:40:36.335541
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(1)
    immutable_list_1 = immutable_list_1.append(2)
    immutable_list_1 = immutable_list_1.append(3)

    def fn_1_arg(var_1: int) -> bool:
        return var_1 >= 2

    var_1 = immutable_list_1.filter(fn_1_arg)

    assert var_1.__str__() == 'ImmutableList[2, 3]'

# Generated at 2022-06-25 23:40:39.765060
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = ImmutableList(0)
    assert immutable_list_0.__eq__(immutable_list_1)



# Generated at 2022-06-25 23:40:48.828613
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_2 = immutable_list_2.filter(immutable_list_0.__eq__)
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_4 = immutable_list_4.filter(immutable_list_3.__eq__)
    immutable_list_5 = ImmutableList(immutable_list_1, immutable_list_4)
    immutable_list_5 = immutable_list_5.filter(immutable_list_1.__eq__)
    immutable_list_6 = ImmutableList(immutable_list_2, immutable_list_5)
    immutable_list_6 = immutable

# Generated at 2022-06-25 23:40:57.463333
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Generate a random ImmutableList
    immutable_list_0 = ImmutableList.of(10, 20, 30)
    immutable_list_1 = ImmutableList.of(10, 20, 30)
    # Check if the ImmutableList is equal to itself
    assert immutable_list_0.__eq__(immutable_list_0)
    # Check if the ImmutableList is equal to another ImmutableList object with the same content
    assert immutable_list_0.__eq__(immutable_list_1)
    # Check that an ImmutableList is not equal to a list
    assert not immutable_list_0.__eq__([10, 20, 30])


# Generated at 2022-06-25 23:41:02.593662
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(int, ImmutableList(str, ImmutableList(float, ImmutableList(object, ImmutableList(str)))))

    def fn_0(val_0: object) -> bool:
        return True

    immutable_list_1 = immutable_list_0.filter(fn_0)
    assert len(immutable_list_1.to_list()) == 5


# Generated at 2022-06-25 23:41:05.399409
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_0.__eq__(immutable_list_1)


# Generated at 2022-06-25 23:41:13.281829
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_0) == True
    immutable_list_1 = ImmutableList()
    assert immutable_list_1.__eq__(immutable_list_0) == True
    immutable_list_1 = ImmutableList.of("", 1)
    assert immutable_list_1.__eq__(immutable_list_0) == False
    immutable_list_2 = ImmutableList.of("", 1)
    assert immutable_list_2.__eq__(immutable_list_1) == True
    immutable_list_3 = ImmutableList.of("", "")
    assert immutable_list_3.__eq__(immutable_list_2) == False

# Generated at 2022-06-25 23:41:17.489139
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__(): 
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    var_0 = immutable_list_0.__eq__(immutable_list_1)
    var_1 = immutable_list_1.__eq__(immutable_list_0)

    return var_0 == var_1


# Generated at 2022-06-25 23:41:20.456610
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    logical_test = ImmutableList.of(1,2,3,4,5,6).find(lambda x: x % 2 == 0) == 2
    print('Test ImmutableList find method: ', logical_test)


# Generated at 2022-06-25 23:41:22.996424
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    if immutable_list_0.__eq__(immutable_list_1):
        pass



# Generated at 2022-06-25 23:41:31.694738
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    elem_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    actual_0 = elem_0.find(lambda x: x == 3)
    assert 3 == actual_0
    actual_1 = elem_0.find(lambda x: x > 3)
    assert None == actual_1


# Generated at 2022-06-25 23:41:41.236931
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(1)
    immutable_list_2 = ImmutableList.of(1, 2)

    assert(immutable_list_0.find(lambda _: False) is None)
    assert(immutable_list_0.find(lambda _: True) is None)
    assert(immutable_list_1.find(lambda _: False) is None)
    assert(immutable_list_1.find(lambda _: True) == 1)
    assert(immutable_list_2.find(lambda _: False) is None)
    assert(immutable_list_2.find(lambda _: True) == 1)
    assert(immutable_list_2.find(lambda x: x == 2) == 2)

# Unit test

# Generated at 2022-06-25 23:41:44.741935
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_list = ImmutableList.empty()
    assert empty_list.find(lambda x: x == 'test') == None
    list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_0.find(lambda x: x == 3) == 3
    assert list_0.find(lambda x: x == 8) == None


# Generated at 2022-06-25 23:41:50.101626
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(2, 3, 4, 5)
    assert immutable_list_0.find(lambda a: a > 5) == None
    assert immutable_list_0.find(lambda a: a >= 3) == 3
    assert immutable_list_0.find(lambda a: a < 0) == None
    assert immutable_list_0.find(lambda a: a == 4) == 4



# Generated at 2022-06-25 23:41:58.783103
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(None)
    immutable_list_0.find(lambda e: e)
    immutable_list_1 = ImmutableList(False)
    immutable_list_1.find(lambda e: e)
    immutable_list_2 = ImmutableList(1)
    immutable_list_2.find(lambda e: e)
    immutable_list_3 = ImmutableList(1)
    immutable_list_3.find(lambda e: e)
    immutable_list_4 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_4.find(lambda e: e)
    immutable_list_5 = ImmutableList.of(5)
    immutable_list_5.find(lambda e: e)

# Generated at 2022-06-25 23:42:05.234300
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    immutable_list_0 = ImmutableList.of(1)
    fn = lambda x: x == 2

    # Act
    result = immutable_list_0.find(fn)

    # Assert
    expected = 2
    assert expected == result


# Generated at 2022-06-25 23:42:13.641376
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test 1
    immutable_list_1 = ImmutableList.of("a", "b", "c")
    assert "b" == immutable_list_1.find(lambda x: x == "b")

    # Test 2
    immutable_list_2 = ImmutableList.of("a", "b", "c")
    assert "a" == immutable_list_2.find(lambda x: x == "a")

    # Test 3
    immutable_list_3 = ImmutableList.of("a", "b", "c")
    assert None == immutable_list_3.find(lambda x: x == "d")


# Generated at 2022-06-25 23:42:25.237965
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    Function test_find of class ImmutableList
    """
    immutable_list_0 = ImmutableList.of(1, 2, 3, 2, 4, 2)
    assert immutable_list_0.find(lambda x: x == 1) == 1
    assert immutable_list_0.find(lambda x: x == 2) == 2
    assert immutable_list_0.find(lambda x: x == 3) == 3
    assert immutable_list_0.find(lambda x: x == 4) == 4
    assert immutable_list_0.find(lambda x: x == 5) == None
    assert immutable_list_0.find(lambda x: x == 6) == None
    assert immutable_list_0.find(lambda x: x == 7) == None


# Generated at 2022-06-25 23:42:35.442079
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    for init_val in [
        '',
        'abc',
        'abcdefghijklmnopqrstuvwxyz',
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        '1234567890',
        '`~!@#$%^&*()-_=+[{]}\|;:\'",<.>/?',
    ]:
        # Initialize a ImmutableList instance
        immutable_list_0 = ImmutableList.of(*init_val)

        # Check if the ImmutableList instance is empty
        if len(immutable_list_0) == 0:
            # Initialize a bool instance
            bool_0 = True

            # Check if the bool instance is True
            if bool_0:
                # Initialize a bool instance
                bool_1 = True


# Generated at 2022-06-25 23:42:41.736822
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(1, ImmutableList(2))
    immutable_list_3 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    immutable_list_4 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert immutable_list_0.find(lambda x: x == None) == None, "Wrong value returned by find"
    assert immutable_list_1.find(lambda x: x == 1) == 1, "Wrong value returned by find"
    assert immutable_list_2.find(lambda x: x == 3) == None, "Wrong value returned by find"

# Generated at 2022-06-25 23:42:54.183195
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    def test_case_0():
        result = ImmutableList.empty().find(lambda x: False)
        assert result is None

    def test_case_1():
        result = ImmutableList.of(1).find(lambda x: False)
        assert result is None

    def test_case_2():
        result = ImmutableList.of(1).find(lambda x: True)
        assert result is 1

    def test_case_3():
        result = ImmutableList.of(1, 2).find(lambda x: False)
        assert result is None

    def test_case_4():
        result = ImmutableList.of(1, 2).find(lambda x: True)
        assert result is 1


# Generated at 2022-06-25 23:42:57.596839
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    obj = ImmutableList.of(0,1,2,3,4,5,6)
    expected = 2
    res = obj.find(lambda x: x==expected)
    assert res==expected


# Generated at 2022-06-25 23:43:01.697204
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1,2,3)
    immutable_list_1 = ImmutableList.of(1,2)

    actual = immutable_list_0.find(lambda x: True)
    expected = 1
    assert actual == expected

    actual = immutable_list_1.find(lambda x: True)
    expected = 1
    assert actual == expected


# Generated at 2022-06-25 23:43:11.880018
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList((-1))
    int_0 = immutable_list_0.find(lambda x: x > 0)
    assert int_0 == (-1)
    immutable_list_1 = ImmutableList((1), None, True)
    immutable_list_0 = immutable_list_1
    int_0 = immutable_list_0.find(lambda x: x < 0)
    assert int_0 == None
    immutable_list_0 = ImmutableList(None, (ImmutableList((1.0))))
    int_0 = immutable_list_0.find(lambda x: x < 0)
    assert int_0 == None
    immutable_list_0 = ImmutableList((1.0), (ImmutableList((2.0))))

# Generated at 2022-06-25 23:43:20.132847
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: x) == None, 'Test #0 failed'
    assert ImmutableList(1).find(lambda x: x) == 1, 'Test #1 failed'
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x % 2 == 0) == 2, 'Test #2 failed'
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x < 2) == 1, 'Test #3 failed'
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x < 1) == None, 'Test #4 failed'


# Generated at 2022-06-25 23:43:30.520741
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList(2)
    immutable_list_3 = ImmutableList(3)

    # Printing ImmutableList objects
    print(immutable_list_1)
    print(immutable_list_2)
    print(immutable_list_3)
    print()

    # Unit test
    assert(immutable_list_1.find(lambda x: x % 2 == 0) == None)
    assert(immutable_list_2.find(lambda x: x % 2 == 0) == 2)
    assert(immutable_list_3.find(lambda x: x % 2 == 0) == None)


# Generated at 2022-06-25 23:43:34.633062
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_ImmutableList = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_ImmutableList.find(lambda x: True) == 1
    assert test_ImmutableList.find(lambda x: False) is None


# Generated at 2022-06-25 23:43:43.640328
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0_find_0 = immutable_list_0.find(lambda value: value > 0)
    assert immutable_list_0_find_0 is None

    immutable_list_0 = ImmutableList()
    immutable_list_0_find_0 = immutable_list_0.find(lambda value: value == 0)
    assert immutable_list_0_find_0 is None

    immutable_list_0 = ImmutableList()
    immutable_list_0_find_0 = immutable_list_0.find(lambda value: value < 0)
    assert immutable_list_0_find_0 is None

    immutable_list_0 = ImmutableList(123)
    immutable_list_0_find_0 = immutable_list_0.find(lambda value: value > 0)

# Generated at 2022-06-25 23:43:48.420230
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(1, None, False)
    immutable_list_0.head = 1
    immutable_list_0.tail = None
    immutable_list_0.is_empty = False
    int_0 = immutable_list_0.find((lambda x: False if x == 1 else None))
    assert (isinstance(int_0, int))
    assert (int_0 == None)



# Generated at 2022-06-25 23:43:52.738024
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    fn = lambda x: x > 0
    result = ImmutableList.of(0, 1, 2, 3, 4).filter(fn).to_list()
    expected = [1,2,3,4]
    assert result == expected, "result: {}, expected: {}".format(result, expected)



# Generated at 2022-06-25 23:44:08.318744
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(True, 31, None, -1.399)
    assert immutable_list_0.filter(lambda x: type(x) == int).to_list() == [31, -1]
    immutable_list_1 = ImmutableList.of('')
    assert immutable_list_1.filter(lambda x: len(x) == 1).to_list() == []
    immutable_list_2 = ImmutableList.of('True', '')
    assert immutable_list_2.filter(lambda x: len(x) == 4).to_list() == ['True']
    immutable_list_3 = ImmutableList.of()
    assert immutable_list_3.filter(lambda x: len(x) == 1).to_list() == []

# Generated at 2022-06-25 23:44:09.942115
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    try:
        assert test_case_0() is None
    except:
        print('Constructor of class ImmutableList do not return None.')



# Generated at 2022-06-25 23:44:15.907935
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # test cases
    immutable_list_0 = ImmutableList()

    # Call the method with arguments
    result = immutable_list_0.unshift(1)
    assert result == ImmutableList(1)

    result = result.unshift(2)
    assert result == ImmutableList(2, immutable_list_0.unshift(1))


# Generated at 2022-06-25 23:44:25.760274
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 1) == None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 2) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 10) == None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 6) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 6) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 0) == None
    assert ImmutableList.of(1, 2, 3, 4, 5).find

# Generated at 2022-06-25 23:44:34.425657
# Unit test for method filter of class ImmutableList

# Generated at 2022-06-25 23:44:44.544417
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list_0 = ImmutableList(1)
    immutable_list_0_ = ImmutableList.of(1)
    assert immutable_list_0.__len__() == 1
    assert immutable_list_0.__len__() == immutable_list_0_.__len__()
    immutable_list_0 = ImmutableList(1, ImmutableList(2))
    immutable_list_0_ = ImmutableList.of(1, 2)
    assert immutable_list_0.__len__() == 2
    assert immutable_list_0.__len__() == immutable_list_0_.__len__()
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    immutable_list_0_ = ImmutableList.of(1, 2, 3)
    assert immutable_

# Generated at 2022-06-25 23:44:53.324125
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list_0 = ImmutableList.of(56)
    immutable_list_1 = immutable_list_0.unshift(40)
    assert immutable_list_1 == ImmutableList.of(40, 56)
    immutable_list_0 = ImmutableList.of(True)
    immutable_list_1 = immutable_list_0.unshift(True)
    assert immutable_list_1 == ImmutableList.of(True, True)
    immutable_list_0 = ImmutableList.of(56)
    immutable_list_1 = immutable_list_0.unshift(False)
    assert immutable_list_1 == ImmutableList.of(False, 56)
    



# Generated at 2022-06-25 23:45:00.122631
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Base test case
    print("Test case: 0")
    immutable_list_0 = ImmutableList(1, ImmutableList(2))
    
    # Base test case
    print("Test case: 1")
    immutable_list_1 = ImmutableList()
    
    # Base test case
    print("Test case: 2")

# Generated at 2022-06-25 23:45:10.212754
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Generated assertion
    test_case_0()
    # Test case #0
    immutable_list_0 = ImmutableList.of(ImmutableList.of(1), ImmutableList.of(2), ImmutableList.of(3))
    # Expected result
    expected_result_0 = ImmutableList.of(ImmutableList.of(1), ImmutableList.of(3))
    # Invoke method under test
    actual_result_0 = immutable_list_0.filter(lambda x: x.reduce(lambda _, y: y, ImmutableList(is_empty=True)) % 2)
    # Check assertion
    assert actual_result_0 == expected_result_0
    # Test case #1

# Generated at 2022-06-25 23:45:17.321553
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    immutable_list_0 = ImmutableList.of('abcd', 'efg', 'hijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', '0123456789')
    immutable_list_1 = immutable_list_0.__add__(ImmutableList.of('abcd', 'efg', 'hijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', '0123456789'))


# Generated at 2022-06-25 23:45:31.410935
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Test with ImmutableList
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert immutable_list_0.map(lambda x: x + 1) == ImmutableList(2, ImmutableList(3, ImmutableList(4)))

    # Test with empty ImmutableList
    immutable_list_1 = ImmutableList()
    assert immutable_list_1.map(lambda x: x + 1) == ImmutableList()


# Generated at 2022-06-25 23:45:40.716729
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Test case for ImmutableList
    immutable_list_0 = ImmutableList.of(1, 3, 4, 5)
    immutable_list_1 = ImmutableList.of(3, 5, 6, 7)
    immutable_list_2 = immutable_list_0.__add__(immutable_list_1)
    immutable_list_0 = ImmutableList.of(1, 3, 4, 5, 3, 5, 6, 7)
    assert immutable_list_2 == immutable_list_0
    # Test case for ImmutableList
    immutable_list_0 = ImmutableList.of(1, 3, 4, 5, 7, 9, 10)
    immutable_list_1 = ImmutableList.of(3, 5, 6, 7, 11, 13, 14)
    immutable_list_2 = immutable_list_0

# Generated at 2022-06-25 23:45:51.729473
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    immutable_list_0 = ImmutableList(None, None, True)
    immutable_list_0 = immutable_list_0.map(callable_0)
    assert immutable_list_0.is_empty

    immutable_list_1 = ImmutableList(None, immutable_list_0, False)
    immutable_list_1 = immutable_list_1.map(callable_1)
    assert immutable_list_1.head is not None
    assert immutable_list_1.is_empty == False
    assert immutable_list_1.tail.is_empty
    immutable_list_1 = immutable_list_1.map(callable_2)
    assert immutable_list_1.head is not None
    assert immutable_list_1.is_empty == False
    assert immutable_list_1.tail.is_empty
    


# Generated at 2022-06-25 23:45:55.316055
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Mock example
    mock_ImmutableList_to_list = ImmutableList.to_list
    def mocked_ImmutableList_to_list(self):
        return [self.head]
    ImmutableList.to_list = mocked_ImmutableList_to_list
    test_result = ImmutableList().to_list()
    assert test_result == []
    ImmutableList.to_list = mock_ImmutableList_to_list

    # Method to_list of class ImmutableList
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    test_result = immutable_list_0.to_list()
    assert test_result == [1, 2, 3]

    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    test_result = immutable_list

# Generated at 2022-06-25 23:46:04.600707
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    immutable_list_0 = ImmutableList()
    immutable_list_0.__add__(immutable_list_0)
    immutable_list_1 = ImmutableList(5)
    immutable_list_1.__add__(immutable_list_1)
    immutable_list_2 = ImmutableList(5, immutable_list_1)
    immutable_list_2.__add__(immutable_list_2)
    immutable_list_3 = ImmutableList(immutable_list_2, immutable_list_0)
    immutable_list_3.__add__(immutable_list_3)
    immutable_list_4 = ImmutableList(immutable_list_3, immutable_list_0)
    immutable_list_4.__add__(immutable_list_4)
    immutable_list_5 = Imm

# Generated at 2022-06-25 23:46:06.820798
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    test_list = ImmutableList.of(0, 0)

    if test_list.head == 0 and test_list.tail.head == 0 and test_list.tail.tail is None:
        print('pass')
    else:
        print('fail')


# Generated at 2022-06-25 23:46:12.632368
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = immutable_list_0.append(0)
    assert immutable_list_1 == [0], 'Wrong results for append'
    immutable_list_2 = immutable_list_1.append(1)
    assert immutable_list_2 == [0, 1], 'Wrong results for append'
    immutable_list_3 = immutable_list_2.append(2)
    assert immutable_list_3 == [0, 1, 2], 'Wrong results for append'


# Generated at 2022-06-25 23:46:22.161138
# Unit test for method __len__ of class ImmutableList

# Generated at 2022-06-25 23:46:32.074623
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Test case 0

    immutable_list_0 = ImmutableList()

    def fn_0(key_0, val_0):
        return key_0 + val_0
    start_with_0 = 0
    # function call
    result_0 = immutable_list_0.reduce(fn_0, start_with_0)
    # check
    assert result_0 == start_with_0
    # Test case 1

    immutable_list_1 = ImmutableList.of(0)

    def fn_1(key_1, val_1):
        return key_1 + val_1
    start_with_1 = 0
    # function call
    result_1 = immutable_list_1.reduce(fn_1, start_with_1)
    # check
    assert result_1 == 0
    # Test

# Generated at 2022-06-25 23:46:42.566275
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list_0 = ImmutableList()
    assert len(immutable_list_0) == 0
    immutable_list_1 = ImmutableList.of(69)
    assert len(immutable_list_1) == 1
    immutable_list_2 = ImmutableList.of(14, -6, -4, -83, -40, -67)
    assert len(immutable_list_2) == 6
    immutable_list_3 = ImmutableList.of(69, -67, 10, -55, -2)
    assert len(immutable_list_3) == 5
    immutable_list_4 = ImmutableList.of(12)
    assert len(immutable_list_4) == 1
    immutable_list_5 = ImmutableList()
    assert len(immutable_list_5) == 0
   

# Generated at 2022-06-25 23:46:56.850709
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    test_case_0()
    print("All testcases for constructor of class ImmutableList passed")


# Generated at 2022-06-25 23:47:08.790648
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    immutable_list_0 = ImmutableList(is_empty=True)
    assert immutable_list_0.__str__() == "ImmutableList[]"
    immutable_list_1 = ImmutableList(None)
    assert immutable_list_1.__str__() == "ImmutableList[None]"
    immutable_list_2 = ImmutableList(1, None)
    assert immutable_list_2.__str__() == "ImmutableList[1]"
    immutable_list_3 = ImmutableList(1, ImmutableList(1, None))
    assert immutable_list_3.__str__() == "ImmutableList[1, 1]"
    immutable_list_4 = ImmutableList(1, ImmutableList(2, None))
    assert immutable_list_4.__str__() == "ImmutableList[1, 2]"

# Generated at 2022-06-25 23:47:18.800284
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.unshift('')
    assert immutable_list_1.head == '' and immutable_list_1.tail == None and immutable_list_1.is_empty == False
    assert len(immutable_list_1) == 1
    immutable_list_2 = immutable_list_1.unshift('a')
    immutable_list_2.head == 'a' and immutable_list_2.tail.head == '' and immutable_list_2.tail.tail == None and immutable_list_2.tail.is_empty == False and immutable_list_2.is_empty == False
    assert len(immutable_list_2) == 2
    immutable_list_3 = ImmutableList.of(1, 2, 3)
    immutable_list

# Generated at 2022-06-25 23:47:26.455836
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.__len__() == 0
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_1.__len__() == 0
    immutable_list_2 = ImmutableList.of(1)
    assert immutable_list_2.__len__() == 1
    immutable_list_3 = ImmutableList.of(2, 3, 4)
    assert immutable_list_3.__len__() == 3


# Generated at 2022-06-25 23:47:36.075457
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list_0 = ImmutableList(3)
    immutable_list_1 = ImmutableList(1, immutable_list_0)
    immutable_list_2 = ImmutableList(1, immutable_list_1)
    immutable_list_0 = ImmutableList(2, immutable_list_2)
    immutable_list_0 = ImmutableList.of(3)
    immutable_list_1 = ImmutableList.of(1, 3)
    immutable_list_2 = ImmutableList.of(1, 1, 3)
    immutable_list_0 = ImmutableList.of(2, 1, 1, 3)
    immutable_list_0 = ImmutableList.of(2, 1, 1, 3)
    immutable_list_0 = immutable_list_0.append(1)
    assert immutable_list_0.to

# Generated at 2022-06-25 23:47:37.469230
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list_0.to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-25 23:47:42.304861
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Define parameters
    immutable_list_0 = ImmutableList()
    immutable_list_0.is_empty = False
    immutable_list_0.tail = None
    immutable_list_0.head = []
    # Define parameters
    immutable_list_1 = ImmutableList()
    immutable_list_1.is_empty = False
    immutable_list_1.tail = None
    immutable_list_1.head = []
    immutable_list_0.__eq__(immutable_list_1)
    # Prepare assert statements
    assert str(immutable_list_0) == 'ImmutableList[]'


# Generated at 2022-06-25 23:47:50.212502
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) is None
    assert ImmutableList(2).find(lambda x: True) == 2
    assert ImmutableList(2, ImmutableList(3, ImmutableList(4))).find(lambda x: True) == 2
    assert ImmutableList(2, ImmutableList(3, ImmutableList(4))).find(lambda x: x == 3) == 3
    assert ImmutableList(2, ImmutableList(3, ImmutableList(4))).find(lambda x: x == 4) == 4
    assert ImmutableList(2, ImmutableList(3, ImmutableList(4))).find(lambda x: x == 5) is None


# Generated at 2022-06-25 23:47:58.241661
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    print("test_ImmutableList")

    # blank_immutable_list = ImmutableList()
    immutable_list_0 = ImmutableList(3)

    print(immutable_list_0)
    print(immutable_list_0.head)
    print(immutable_list_0.tail)
    print(immutable_list_0.is_empty)

    assert immutable_list_0.head == 3
    assert immutable_list_0.tail is None
    assert immutable_list_0.is_empty is False


# Generated at 2022-06-25 23:48:04.138669
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    immutable_list_0 = ImmutableList(123, ImmutableList(456, ImmutableList(789, ImmutableList(None, ImmutableList(42, None, False), False), False), False), False)
    immutable_list_1 = ImmutableList(False, ImmutableList(False, ImmutableList(False, ImmutableList(False, ImmutableList(True, None, False), False), False), False), False)
    function_0 = lambda x : x % 2 == 1
    assert immutable_list_1 == immutable_list_0.map(function_0)
    immutable_list_2 = ImmutableList(True, ImmutableList(False, ImmutableList(True, ImmutableList(False, ImmutableList(True, None, False), False), False), False), False)
    function_1 = bool
    assert immutable_list_2

# Generated at 2022-06-25 23:48:37.504539
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0.filter((lambda null: (not (not null))) if (type(null) is not bool) else null)
    assert 2 == len(immutable_list_0)

    immutable_list_1 = ImmutableList.empty()
    immutable_list_1.filter((lambda x: (x == ('r'))) if (type(x) is str) else x)
    assert 1 == len(immutable_list_1)

    immutable_list_2 = ImmutableList.empty()
    immutable_list_2.filter(lambda x: x <= -4.0)
    assert 0 == len(immutable_list_2)

    immutable_list_3 = ImmutableList()

# Generated at 2022-06-25 23:48:46.031174
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    print("------ UNIT TESTING: ImmutableList ------")
    immutable_list_0 = ImmutableList()
    assert (immutable_list_0.head is None and immutable_list_0.tail is None and immutable_list_0.is_empty)
    immutable_list_1 = ImmutableList(1)
    assert (immutable_list_1.head == 1 and immutable_list_1.tail is None and not immutable_list_1.is_empty)
    immutable_list_1 = ImmutableList(1, 2, 3)
    assert (immutable_list_1.head == 1 and not immutable_list_1.tail is None and not immutable_list_1.is_empty)
    print("PASSED")


# Generated at 2022-06-25 23:48:55.940272
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(1,2,3)
    immutable_list_2 = ImmutableList.of(1,2)
    immutable_list_3 = ImmutableList(1,immutable_list_2)
    immutable_list_4 = ImmutableList(1,immutable_list_1)

    assert immutable_list_0.to_list() == []
    assert immutable_list_1.to_list() == [1,2,3]
    assert immutable_list_2.to_list() == [1,2]
    assert immutable_list_3.to_list() == [1,1,2]
    assert immutable_list_4.to_list() == [1,1,2,3]


# Generated at 2022-06-25 23:49:02.674905
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Prepare
    immutable_list_0 = ImmutableList.of(None, None, None)
    immutable_list_1 = ImmutableList.of("a", "b", "c")
    immutable_list_2 = ImmutableList.of("a", "b", "c")
    immutable_list_3 = ImmutableList.of("a", "b", "c")
    immutable_list_4 = ImmutableList.of("a", "b", "c")
    immutable_list_5 = ImmutableList.of("a", "b", "c")
    immutable_list_6 = ImmutableList.of("a", "b", "c")
    immutable_list_7 = ImmutableList.of("a", "b", "c")
    immutable_list_8 = ImmutableList.of("a", "b", "c")

# Generated at 2022-06-25 23:49:12.739277
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Test case 0
    immutable_list_0 = ImmutableList.of(15, 17, 27)
    immutable_list_0_reduce_fn_arg_0 = lambda immutable_list_0_reduce_arg_0, immutable_list_0_reduce_arg_1: immutable_list_0_reduce_arg_0 + immutable_list_0_reduce_arg_1
    immutable_list_0_reduce_arg_1 = 0
    immutable_list_0_reduce_ret_1 = immutable_list_0_reduce_fn_arg_0(immutable_list_0_reduce_arg_1, 15)

# Generated at 2022-06-25 23:49:21.541214
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Empty list
    immutable_list_0 = ImmutableList()
    # String representation of empty list
    immutable_list_repr_0 = "ImmutableList[]"
    # Check if __str__ of ImmutableList is equal to immutable_list_repr_0
    assert __str__(immutable_list_0) == immutable_list_repr_0
    immutable_list_1 = ImmutableList(2)
    immutable_list_repr_1 = "ImmutableList[2]"
    assert __str__(immutable_list_1) == immutable_list_repr_1
    immutable_list_2 = ImmutableList(2, ImmutableList(3))
    immutable_list_repr_2 = "ImmutableList[2, 3]"
    assert __str__(immutable_list_2) == immutable_

# Generated at 2022-06-25 23:49:30.003217
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():

    # Initializing a test object for method map
    immutable_list_0 = ImmutableList()

    # Defining the expected result
    expected_result = []

    # Running the test
    result = immutable_list_0.map(lambda x: x*x)

    # Comparing the result to the expected result
    assert expected_result == result.to_list()

    # Initializing a test object for method map
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    # Defining the expected result
    expected_result = [1, 4, 9]

    # Running the test
    result = immutable_list_0.map(lambda x: x*x)

    # Comparing the result to the expected result
    assert expected_result == result.to_list()



# Generated at 2022-06-25 23:49:39.040122
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list_0 = ImmutableList(86)
    int_0 = immutable_list_0.head
    int_1 = immutable_list_0.head
    immutable_list_1 = immutable_list_0.unshift(int_1)
    immutable_list_2 = immutable_list_1.unshift(int_0)
    int_2 = immutable_list_2.head
    immutable_list_3 = immutable_list_2.unshift(int_2)
    assert immutable_list_3.head == 86
    assert immutable_list_3.tail.head == 86
    assert immutable_list_3.tail.tail.head == 86


# Generated at 2022-06-25 23:49:50.579985
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.head == None
    assert immutable_list_0.tail == None
    assert immutable_list_0.is_empty == True

    immutable_list_1 = ImmutableList(1, immutable_list_0)
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail == immutable_list_0
    assert immutable_list_1.is_empty == False

    immutable_list_2 = ImmutableList(2, immutable_list_1)
    assert immutable_list_2.head == 2
    assert immutable_list_2.tail == immutable_list_1
    assert immutable_list_2.is_empty == False


# Generated at 2022-06-25 23:49:58.368313
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(42, immutable_list_0)
    immutable_list_2 = immutable_list_0.unshift(1)
    immutable_list_1.unshift(immutable_list_2.head)
    immutable_list_1.unshift(immutable_list_2.unshift(None).head)
    immutable_list_1.unshift(immutable_list_2.unshift('q').head)
    immutable_list_1.unshift(immutable_list_2.unshift([]).head)
    immutable_list_1.unshift(immutable_list_2.unshift((3, None)).head)