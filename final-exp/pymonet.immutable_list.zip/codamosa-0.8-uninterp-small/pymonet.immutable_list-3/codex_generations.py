

# Generated at 2022-06-25 23:40:34.247337
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1

    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    assert immutable_list_2 == immutable_list_3

    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()
    assert immutable_list_4 == immutable_list_5


# Generated at 2022-06-25 23:40:45.115555
# Unit test for method __eq__ of class ImmutableList

# Generated at 2022-06-25 23:40:54.170952
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(0).__eq__(ImmutableList(0)) == (True)
    assert ImmutableList(a).__eq__(ImmutableList(a)) == (True)
    assert ImmutableList(a, a).__eq__(ImmutableList(a, a)) == (True)
    assert ImmutableList(a, a, a).__eq__(ImmutableList(a, a, a)) == (True)
    assert ImmutableList(a, a, a, a).__eq__(ImmutableList(a, a, a, a)) == (True)
    assert ImmutableList(a, a, a, a, a).__eq__(ImmutableList(a, a, a, a, a)) == (True)
    assert ImmutableList(a, a, a, a, a, a).__eq__

# Generated at 2022-06-25 23:40:58.126123
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutablelist___eq__test0 = ImmutableList()
    immutablelist___eq__test1 = ImmutableList()
    assert immutablelist___eq__test0.__eq__(immutablelist___eq__test1) == True


# Generated at 2022-06-25 23:41:05.680938
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    immutable_list_1 = immutable_list_0.filter(immutable_list_0)
    assert (immutable_list_1 == ImmutableList.of(1, 2, 3, 4, 5, 6))

    immutable_list_2 = immutable_list_0.filter(immutable_list_1)
    assert (immutable_list_2 != ImmutableList.of(1, 2, 3, 4, 5, 6))

    immutable_list_3 = immutable_list_0.filter(immutable_list_2)
    assert (immutable_list_3 != ImmutableList.of(1, 2, 3, 4, 5, 6))


# Generated at 2022-06-25 23:41:07.330948
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    expected = True
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    actual = immutable_list_0.__eq__(immutable_list_1)
    print(str(expected == actual))


# Generated at 2022-06-25 23:41:14.858558
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    #
    # Declare MutableList values
    #

    var_0 = ImmutableList(
        1,
        ImmutableList(
            2,
            ImmutableList(
                3,
                ImmutableList(
                    4,
                    ImmutableList(
                        5,
                        None,
                        False
                    ),
                    False
                ),
                False
            ),
            False
        ),
        False
    )

    var_1 = ImmutableList(
        1,
        ImmutableList(
            2,
            ImmutableList(
                3,
                ImmutableList(
                    4,
                    ImmutableList(
                        5,
                        None,
                        False
                    ),
                    False
                ),
                False
            ),
            False
        ),
        False
    )

    #
    # Test for field

# Generated at 2022-06-25 23:41:21.216117
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    
    immutable_list_0 = ImmutableList()
    immutable_list_1 = None
    assert not immutable_list_0 == immutable_list_1
    
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(100)
    assert not immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:41:23.455540
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of([2, 3])
    var_0 = immutable_list_0.filter(immutable_list_0)


# Generated at 2022-06-25 23:41:32.694137
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(None)
    immutable_list_2 = ImmutableList.of('data')
    immutable_list_3 = ImmutableList.of(None, None, None)
    immutable_list_4 = ImmutableList.of('data', 'data', 'data')

    assert immutable_list_0.find(lambda item: item) is None
    assert immutable_list_1.find(lambda item: item) is None
    assert immutable_list_2.find(lambda item: item) == 'data'
    assert immutable_list_3.find(lambda item: item) is None
    assert immutable_list_4.find(lambda item: item) == 'data'

# Generated at 2022-06-25 23:41:42.630427
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    fn = lambda x: True

    assert ImmutableList.of(5, 2, 3).filter(fn) == ImmutableList.of(5, 2, 3)
    assert ImmutableList.of(5, 2, 3).filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList.of(5, 2, 3).filter(lambda x: x > 3) == ImmutableList.of(5)


# Generated at 2022-06-25 23:41:46.868006
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1, ImmutableList(5, ImmutableList(7, ImmutableList(10))))
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 5)
    print(immutable_list_0)
    print(immutable_list_1)



# Generated at 2022-06-25 23:41:55.978312
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create instance of ImmutableList
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8, None))))))))

    # Apply filter method to instance and save result to var_0
    var_0 = immutable_list_0.filter(lambda x: x < 4)

    # Test instance var_0 of class ImmutableList and compare with
    # immutable_list_1
    immutable_list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, None)))
    assert var_0 == immutable_list_1

# Generated at 2022-06-25 23:42:04.418922
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, None)))))
    assert test_list.find(lambda x: x > 3) == 4
    assert test_list.find(lambda x: x > 6) == None



# Generated at 2022-06-25 23:42:07.780297
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    var_1 = fn_add_1(immutable_list_0)
    var_2 = immutable_list_0.filter(var_1)
    var_3 = immutable_list_0.find(var_1)


# Generated at 2022-06-25 23:42:19.491438
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList()
    var_0 = immutable_list_0.find(immutable_list_0)
    # Test case 1
    immutable_list_0 = ImmutableList([])
    var_0 = immutable_list_0.find(immutable_list_0)
    # Test case 2
    immutable_list_0 = ImmutableList(["", "", "", "", "", "", "", "", "", "", "", "", "", "", ""], ImmutableList(["", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]))
    var_0 = immutable_list_0.find(immutable_list_0)
    # Test case 3
    immutable_list_0 = ImmutableList

# Generated at 2022-06-25 23:42:21.857636
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_passed = True
    test_case_0()
    if not test_passed:
        print('At least one test failed!')
        sys.exit(1)

# Generated at 2022-06-25 23:42:33.079966
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(3)
    var_0 = immutable_list_0.__eq__(ImmutableList((2, 3)))
    assert(var_0 == False)
    var_0 = immutable_list_0.__eq__(ImmutableList())
    assert(var_0 == False)
    immutable_list_1 = immutable_list_0.tail
    var_0 = immutable_list_1.__eq__(ImmutableList(()))
    assert(var_0 == True)
    var_0 = immutable_list_1.__eq__(ImmutableList(()))
    assert(var_0 == True)
    immutable_list_2 = ImmutableList(4)
    var_0 = immutable_list_2.__eq__(immutable_list_2)

# Generated at 2022-06-25 23:42:38.657673
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_success = [
        (ImmutableList(), None, ImmutableList()),
        (ImmutableList.of(1, 2, 3), lambda x: x % 2 == 1, ImmutableList.of(1, 3)),
        (ImmutableList.of('a', 'b', 'c', 'd'), lambda c: c in 'aeiou', ImmutableList.of('a'))
    ]

    for case in list_success:
        assert case[0].filter(case[1]) == case[2]


# Generated at 2022-06-25 23:42:41.697030
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_1 = immutable_list_0.filter(immutable_list_0)
    assert(immutable_list_1 == ImmutableList.of(2, 4))


# Generated at 2022-06-25 23:42:54.318487
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert (ImmutableList.of(2).filter(lambda x: x) == ImmutableList.of(2))
    assert (ImmutableList.of(0).filter(lambda x: x) == ImmutableList.empty())
    assert (ImmutableList.of(0, 2, 3, 5, 6).filter(lambda x: x == 0) == ImmutableList.of(0))
    assert (ImmutableList.of(0, 2, 3, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 6))
    assert (ImmutableList.of(0, 2, 3, 5, 6).filter(lambda x: x % 2 == 1) == ImmutableList.of(3, 5))

# Generated at 2022-06-25 23:43:02.651716
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.unshift(1)
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_0 = immutable_list_0.unshift(1)
    immutable_list_2 = ImmutableList()
    immutable_list_2 = immutable_list_2.unshift(2)
    immutable_list_2 = immutable_list_2.unshift(1)
    immutable_list_3 = ImmutableList()
    immutable_list_3 = immutable_list_3.unshift(2)
    immutable_list_3 = immutable_list_3.unshift(1)
    immutable_list_3 = immutable_list_3.unshift(2)
    immutable_list_4 = ImmutableList

# Generated at 2022-06-25 23:43:12.606690
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.filter(lambda x: False)
    assert immutable_list_0.to_list() == []
    # Test case 1
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.filter(lambda x: True)
    assert immutable_list_0.to_list() == []
    # Test case 2
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.filter(lambda x: False)
    assert immutable_list_0.to_list() == []
    # Test case 3
    immutable_list_0 = ImmutableList()

# Generated at 2022-06-25 23:43:21.711534
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    class_type_0 = immutable_list_0.find(lambda arg_0: arg_0)
    assert class_type_0 is None
    immutable_list_0 = ImmutableList(None)
    class_type_0 = immutable_list_0.find(lambda arg_0: arg_0)
    assert class_type_0 is None
    immutable_list_0 = ImmutableList.of(3.33693949759, 53.74795846628, 0.923255433836)
    class_type_0 = immutable_list_0.find(lambda arg_0: arg_0 == 53.74795846628)
    assert class_type_0 == 53.74795846628

# Generated at 2022-06-25 23:43:26.025214
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0.find(lambda x: x == 0) == 0
    assert immutable_list_1.find(lambda x: x == 0) == None


# Generated at 2022-06-25 23:43:31.517620
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_1 = immutable_list_0.filter(lambda x: x != 2)
    assert(immutable_list_1 == ImmutableList.of(1, 3, 4))


# Generated at 2022-06-25 23:43:41.348390
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(2, ImmutableList(3)).filter(lambda x: x > 2).to_list() == [3]
    assert ImmutableList(0, ImmutableList(2)).filter(lambda x: x > 0).to_list() == [2]
    assert ImmutableList(0, ImmutableList(2)).filter(lambda x: x > 2).to_list() == []
    assert ImmutableList(2, ImmutableList(3)).filter(lambda x: x > 0).to_list() == [2, 3]
    assert ImmutableList().filter(lambda x: x > 2).to_list() == []
    assert ImmutableList(2, ImmutableList(3)).filter(lambda x: x > 3).to_list() == []

# Generated at 2022-06-25 23:43:43.375185
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    int_0 = immutable_list_0.find(lambda x: True if x > 2 else False)
    assert int_0 == 3


# Generated at 2022-06-25 23:43:52.471472
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0_0 = ImmutableList(1)
    immutable_list_0_1 = ImmutableList(True)
    immutable_list_0_2 = ImmutableList("test")
    immutable_list_1 = ImmutableList.empty()
    immutable_list_1_0 = ImmutableList(1)
    immutable_list_1_1 = ImmutableList(True)
    immutable_list_1_2 = ImmutableList("test")
    immutable_list_0.tail = immutable_list_0_0
    immutable_list_0_0.tail = immutable_list_0_1
    immutable_list_0_1.tail = immutable_list_0_2
    immutable_list_1.tail = immutable_list_1_0
    immutable_

# Generated at 2022-06-25 23:44:03.618953
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(True, ImmutableList(3.141592653589793, ImmutableList(2.718281828459045, ImmutableList(-1))))
    immutable_list_0.find((lambda elem: elem > 2.718281828459045))
    immutable_list_0 = ImmutableList(True, ImmutableList(3.141592653589793, ImmutableList(2.718281828459045, ImmutableList(-1))))
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = ImmutableList.of(2.718281828459045, 3.141592653589793, 2.718281828459045, -1, True)

# Generated at 2022-06-25 23:44:19.854720
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(3, 5, 6, 7)
    immutable_list = immutable_list.filter(lambda x: x >= 5)
    assert immutable_list == ImmutableList.of(5, 6, 7)

    immutable_list = ImmutableList.of(4, 5, 6, 7)
    immutable_list = immutable_list.filter(lambda x: x <= 5)
    assert immutable_list == ImmutableList.of(4, 5)

    immutable_list = ImmutableList.of(-3, 5, 6, -7)
    immutable_list = immutable_list.filter(lambda x: x >= 5)
    assert immutable_list == ImmutableList.of(5, 6)

    immutable_list = ImmutableList.of(-4, 0, 6, -7)
    immutable_list = immutable_

# Generated at 2022-06-25 23:44:22.770058
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(3, ImmutableList(2))
    assert immutable_list_0.filter(lambda x: x % 2 == 0) == ImmutableList(2)


# Generated at 2022-06-25 23:44:27.685149
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(list_0, immutable_list_8)
    immutable_list_1 = immutable_list_0.filter(lambda value: value == 1)
    immutable_list_8 = immutable_list_0.filter(lambda value: value == 1)
    assert immutable_list_4 == immutable_list_0


# Generated at 2022-06-25 23:44:33.586569
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_0 = ImmutableList.of(3, 2, 3, 2, 3)
    list_1 = ImmutableList.of()

    def fn_0(x_0: int) -> bool:
        return x_0 > 2

    list_2 = list_0.filter(fn_0)
    assert [x_0 for x_0 in list_2] == [3, 3, 3]

    list_3 = list_1.filter(fn_0)
    assert list_3.is_empty



# Generated at 2022-06-25 23:44:38.509444
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()

    # Act
    result_0 = immutable_list_0 == immutable_list_1
    result_1 = immutable_list_1 == immutable_list_2

    # Assert
    assert result_0 == True
    assert result_1 == True


# Generated at 2022-06-25 23:44:48.402627
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Normal cases
    a = ImmutableList("hello", ImmutableList("world"))

    assert "hello" == a.find(lambda x: True)
    assert "hello" == a.find(lambda x: x == "hello")
    assert "world" == a.find(lambda x: x == "world")
    assert None == a.find(lambda x: False)

    # Edge cases
    a = ImmutableList("hello", ImmutableList("world"))

    assert "hello" == a.find(lambda x: x == "hello")
    assert "world" == a.find(lambda x: x == "world")
    assert None == a.find(lambda x: x == "goodbye")


# Generated at 2022-06-25 23:44:57.103095
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    )

    immutable_list_1 = immutable_list.filter(lambda x: x % 2 == 0)
    immutable_list_2 = immutable_list.filter(lambda x: x % 2 != 0)
    immutable_list_3 = immutable_list.filter(lambda x: x % 3 == 0)

    assert (immutable_list_1 == ImmutableList.of(2, 4, 6, 8, 10))
    assert (immutable_list_2 == ImmutableList.of(1, 3, 5, 7, 9))
    assert (immutable_list_3 == ImmutableList.of(3, 6, 9))

    immutable_list = ImmutableList.of()

    immutable_list

# Generated at 2022-06-25 23:45:06.707673
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Unit test for method find of class ImmutableList
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(None, None)
    immutable_list_2 = ImmutableList.of(True, False, False, True, False)
    immutable_list_3 = ImmutableList.of(True, False, False, True, False)
    immutable_list_4 = ImmutableList.of(True, False, False, True, False)
    immutable_list_5 = ImmutableList.of(True, False, False, True, False)

    assert immutable_list_0.find(lambda v: False is False) is None
    assert immutable_list_1.find(lambda v: True is False) is None
    assert immutable_list_2.find(lambda v: v is True) is True


# Generated at 2022-06-25 23:45:14.764480
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    assert ImmutableList().find(lambda x: x) is None
    assert ImmutableList.of(1).find(lambda x: x) == 1
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(2, 1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(2, 1, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(2, 1, 3).find(lambda x: x == 3) == 3


# Generated at 2022-06-25 23:45:21.844025
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(0)
    int_0 = immutable_list_0.find((lambda e: e > 0))
    assert int_0 == None
    immutable_list_1 = ImmutableList.of(0, 1, 2)
    int_1 = immutable_list_1.find((lambda e: e > 0))
    assert int_1 == 1
    immutable_list_2 = ImmutableList.of(0, 1, 2)
    int_2 = immutable_list_2.find((lambda e: e > 2))
    assert int_2 == None
    immutable_list_3 = ImmutableList(0)
    int_3 = immutable_list_3.find((lambda e: e > 1))
    assert int_3 == None

# Generated at 2022-06-25 23:45:42.268468
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # create empty immutable list
    immutable_list_0 = ImmutableList()
    assert immutable_list_0.filter(lambda x: x > 0) == ImmutableList(is_empty=True)

    # create new immutable list of numbers
    immutable_list_1 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9))))))))))
    assert immutable_list_1.filter(lambda x: x % 2 == 0) == ImmutableList(0, ImmutableList(2, ImmutableList(4, ImmutableList(6, ImmutableList(8)))))

# Generated at 2022-06-25 23:45:49.664554
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(3, 5, 7, 9)
    function_0 = lambda x: x % 2 == 0
    immutable_list_1 = immutable_list_0.filter(function_0)
    assert immutable_list_0.filter(function_0).to_list() == [5, 7, 9]
    assert immutable_list_1.to_list() == [5, 7, 9]


# Generated at 2022-06-25 23:45:59.681219
# Unit test for method find of class ImmutableList

# Generated at 2022-06-25 23:46:07.152551
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # arrange
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = immutable_list_0.append(4)
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(3)
    predicate_0 = lambda it: it <= 1
    # act
    immutable_list_1 = immutable_list_0.filter(predicate_0)
    # assert
    assert immutable_list_1 == ImmutableList(1, ImmutableList(1))


# Generated at 2022-06-25 23:46:15.400163
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    t_0 = ImmutableList(23)
    t_1 = ImmutableList(1, t_0)
    t_2 = ImmutableList(90, t_1)
    t_3 = ImmutableList(12, t_2)
    res_01 = t_3.find(lambda x: x == 90)

    t_0 = ImmutableList(is_empty=True)
    t_1 = ImmutableList(1, t_0)
    t_2 = ImmutableList(90, t_1)
    t_3 = ImmutableList(12, t_2)
    res_02 = t_3.find(lambda x: x == 90)

    assert res_01 == 90
    assert res_02 == 90


# Generated at 2022-06-25 23:46:20.120013
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Using ImmutableList of numbers
    immutableList = ImmutableList.of(1, 2, 3, 4, 5, 6)
    # Mapping ImmutableList
    immutableList_filtered = immutableList.filter(lambda x: x != 1)
    # Checking if ImmutableList is what we expect
    assert immutableList_filtered == ImmutableList.of(2, 3, 4, 5, 6)



# Generated at 2022-06-25 23:46:25.318552
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    expected_list_0 = ImmutableList(1, ImmutableList(2))
    method_list_0 = test_list_0.filter(lambda x: x < 3)
    if method_list_0 == expected_list_0:
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-25 23:46:34.709955
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given a list of numbers
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    immutable_list_0.find(lambda x: x % 2 == 0) == 2
    # Given a list of numbers
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    immutable_list_1.find(lambda x: x % 2 == 0) == 2
    # Given a list of numbers
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    immutable_list_2.find(lambda x: x % 2 == 0) == 2


# Generated at 2022-06-25 23:46:45.429351
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(24, 26, 7, 25, 23, 27, 22, 16, 25, 24, 10, 26)
    immutable_list_0_copy = ImmutableList(24, ImmutableList(26, ImmutableList(7, ImmutableList(25, ImmutableList(23, ImmutableList(27, ImmutableList(22, ImmutableList(16, ImmutableList(25, ImmutableList(24, ImmutableList(10, ImmutableList(26))))))))))))
    immutable_list_1 = ImmutableList(24, ImmutableList(7, ImmutableList(23, ImmutableList(22, ImmutableList(10, ImmutableList(2))))))

# Generated at 2022-06-25 23:46:52.353278
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 != 0).to_list() == [1, 3, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 5 == 0).to_list() == [5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 10 == 0).to_list() == []


# Generated at 2022-06-25 23:47:26.460719
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    integer_0 = immutable_list_0.find(__lambda_0)
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_1.append(0)
    integer_1 = immutable_list_1.find(__lambda_1)
    immutable_list_2 = ImmutableList()
    immutable_list_2 = immutable_list_2.append(0)
    immutable_list_2 = immutable_list_2.append(1)
    immutable_list_2 = immutable_list_2.append(2)
    integer_2 = immutable_list_2.find(__lambda_2)
    immutable_list_3 = ImmutableList()
    immutable_list_3 = immutable_list_3.append(0)
    immutable_list

# Generated at 2022-06-25 23:47:36.073728
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # ImmutableList to be passed to filter
    immutable_list_0 = ImmutableList()

    # If a lambda expression is passed to filter
    # it is used to filter the ImmutableList
    # The expression returns True for each element of the ImmutableList
    # for which the expression evaluates to True
    # For example, the expression lambda x: x > 5 is used to
    # create a new ImmutableList which contains elements
    # greater than 5

    # ImmutableList passed to filter
    immutable_list_1 = ImmutableList.of(1,2,3,4,5)

    # lambda expression which filters the ImmutableList
    # it is used to filter the ImmutableList
    # The expression returns True for each element of the ImmutableList
    # for which the expression evaluates to True
    check = lambda x: x % 2 == 0



# Generated at 2022-06-25 23:47:37.469610
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    func = lambda a : a > 5
    test = ImmutableList.of(2, 3, 4, 5, 6, 7)
    assert test.find(func) == 6


# Generated at 2022-06-25 23:47:39.179584
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
  

# Generated at 2022-06-25 23:47:44.679121
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    expected_0 = 5  # type: int
    actual_0 = None  # type: int
    # Act
    try:
        actual_0 = immutable_list_0.find(lambda x: x == 5)  # type: bool
    except Exception as e:  # pragma: no cover
        pass
    # Assert
    assert actual_0 == expected_0


# Generated at 2022-06-25 23:47:55.574528
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Initialize a new ImmutableList obj
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(12345)
    immutable_list_0 = immutable_list_0.append(12345)
    immutable_list_0 = immutable_list_0.append(1337)
    immutable_list_0 = immutable_list_0.append(12345)
    immutable_list_0 = immutable_list_0.append(0)
    immutable_list_0 = immutable_list_0.append(31337)
    immutable_list_0 = immutable_list_0.append(7331)
    immutable_list_0 = immutable_list_0.append(5)
    immutable_list_0 = immutable_list_0.append(12345)

    # The expected result of calling

# Generated at 2022-06-25 23:48:00.179437
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test 1
    # Method: find
    # Type: Happy path
    # Expected input:
    #     immutable_list_0 (ImmutableList.of(1))
    # Expected output:
    #     (1)

    immutable_list_0 = ImmutableList.of(1)
    assert immutable_list_0.find(lambda x: x == 1) == 1


# Generated at 2022-06-25 23:48:10.041401
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4) and \
        ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 4).is_empty and \
        ImmutableList.empty().filter(lambda x: x > 2) == ImmutableList.empty() and \
        ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > -1000) == \
        ImmutableList.of(1, 2, 3, 4) and \
        ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < -1000).is_empty


# Generated at 2022-06-25 23:48:12.462612
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ImmutableList_0 = ImmutableList()
    ImmutableList_1 = ImmutableList()


# Generated at 2022-06-25 23:48:16.435358
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(10, 20).find(lambda x: x == 10) == 10
    assert ImmutableList(10, 20).find(lambda x: x != 10) == 20
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 10) is None


# Generated at 2022-06-25 23:49:06.575880
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    input_list = ImmutableList.of(1, 2, 3)
    fn = lambda a: a > 1

    # Act
    output_list = input_list.filter(fn)

    # Assert
    assert output_list == ImmutableList.of(2, 3)


# Generated at 2022-06-25 23:49:15.000885
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(None)
    assert immutable_list_0.find(lambda x: x) is None

    immutable_list_0 = ImmutableList.of(True)
    assert immutable_list_0.find(lambda x: x)

    immutable_list_0 = ImmutableList.of(0, False)
    assert immutable_list_0.find(lambda x: x) is None

    immutable_list_0 = ImmutableList.of(None, None, None)
    assert immutable_list_0.find(lambda x: x) is None


# Generated at 2022-06-25 23:49:22.870704
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def eq(actual, expected):
        assert actual == expected, '\n expected: {}\n actual:   {}'.format(expected, actual)
    # Case 1
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4)
    lambda_0 = lambda x : x % 2 == 1
    expected_0 = ImmutableList.of(1, 3)
    actual_0 = immutable_list_0.filter(lambda_0)
    eq(actual_0, expected_0)

    # Case 2
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    lambda_1 = lambda x : x % 2 == 0
    expected_1 = ImmutableList.of(2, 4)

# Generated at 2022-06-25 23:49:29.104028
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """Test for method __eq__ of class ImmutableList."""
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_1.is_empty = True
    immutable_list_2 = ImmutableList(None)
    immutable_list_2.is_empty = True
    immutable_list_3 = ImmutableList()

    assert immutable_list_0 == immutable_list_1
    assert immutable_list_1 == immutable_list_2
    assert immutable_list_2 == immutable_list_3


# Generated at 2022-06-25 23:49:33.216370
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(11)
    immutable_list_0 = immutable_list_0.filter(lambda x:x == 11)
    assert immutable_list_0.find(lambda x: x == 11) == 11


# Generated at 2022-06-25 23:49:36.594786
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    immutable_list_0 = ImmutableList.of('0')
    
    def fn(x):
        return x == 'r'

    res = immutable_list_0.find(fn)

    assert res is None


# Generated at 2022-06-25 23:49:44.383496
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0)
    immutable_list_1 = ImmutableList.of(1, 1)
    immutable_list_2 = ImmutableList.of(2, 2, 2)
    immutable_list_3 = ImmutableList.of(3, 3, 3, 3)
    immutable_list_4 = ImmutableList.of(4, 4, 4, 4, 4)
    immutable_list_5 = ImmutableList.of(5, 5, 5, 5, 5, 5)
    immutable_list_6 = ImmutableList.of(6, 6, 6, 6, 6, 6, 6)
    immutable_list_7 = ImmutableList.of(7, 7, 7, 7, 7, 7, 7, 7)

# Generated at 2022-06-25 23:49:55.552043
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case 0
    immutable_list_0 = ImmutableList.of(8)
    assert immutable_list_0.filter(lambda x : x > 3) == ImmutableList.of(8)
    immutable_list_0 = ImmutableList.of(1)
    assert immutable_list_0.filter(lambda x : x > 3) == ImmutableList()
    immutable_list_0 = ImmutableList.of(8, 7)
    assert immutable_list_0.filter(lambda x : x > 3) == ImmutableList.of(8, 7)
    immutable_list_0 = ImmutableList.of(1, 7)
    assert immutable_list_0.filter(lambda x : x > 3) == ImmutableList.of(7)
    immutable_list_0 = ImmutableList.of(8, 2)

# Generated at 2022-06-25 23:50:08.758722
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList(is_empty=True)

    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)

    assert ImmutableList(1).filter(lambda x: False) == ImmutableList(is_empty=True)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x < 3) == ImmutableList(1, ImmutableList(2))

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 3) == ImmutableList(is_empty=True)


# Generated at 2022-06-25 23:50:18.658862
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_find = ImmutableList.of(1, 2, 3, 5, 1, 8, 3, 5, 9)
    func = lambda x: x == 1

    assert immutable_list_find.find(func) == 1

    immutable_list_find = ImmutableList.of(1, 2, 3, 5, 1, 8, 3, 5, 9)
    func = lambda x: x == 3

    assert immutable_list_find.find(func) == 3

    immutable_list_find = ImmutableList.of(1, 2, 3, 5, 1, 8, 3, 5, 9)
    func = lambda x: x == 5

    assert immutable_list_find.find(func) == 5
