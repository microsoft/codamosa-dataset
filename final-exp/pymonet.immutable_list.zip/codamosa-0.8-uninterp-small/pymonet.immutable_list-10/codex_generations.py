

# Generated at 2022-06-25 23:40:39.169593
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    # Case 1: Test with an empty ImmutableList, expecting to return True
    immutable_list_0 = ImmutableList()
    assert immutable_list_0 == ImmutableList()

    # Case 2: Test with a non-empty ImmutableList, expecting to return True
    immutable_list_1 = ImmutableList(1)
    assert immutable_list_1 == ImmutableList(1)

    # Case 3: Test with two different ImmutableLists, expecting to return False
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(2)
    assert not immutable_list_1 == immutable_list_2

    # Case 4: Test with an empty ImmutableList and a non-empty ImmutableList, expecting to return False
    immutable_list_0 = ImmutableList()

# Generated at 2022-06-25 23:40:48.770650
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(int)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = immutable_list_0.append(5)
    immutable_list_0 = immutable_list_0.append(10)
    immutable_list_0 = immutable_list_0.append(15)
    immutable_list_0 = immutable_list_0.append(20)
    immutable_list_0 = immutable_list_0.append(25)
    immutable_list_0 = immutable_list_0.append(30)
    immutable_list_1 = immutable_list_0.filter(int)
    immutable_list_0 = immutable_list_0.append(35)
    immutable_list_1 = immutable_list_

# Generated at 2022-06-25 23:40:58.836125
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList()
    assert_equal(immutable_list_0 == immutable_list_1, True)
    immutable_list_0 = ImmutableList(is_empty=False)
    immutable_list_1 = ImmutableList()
    assert_equal(immutable_list_0 == immutable_list_1, False)
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(is_empty=False)
    assert_equal(immutable_list_0 == immutable_list_1, False)
    immutable_list_0 = ImmutableList(is_empty=False)
    immutable_list_1 = ImmutableList(is_empty=True)
    assert_equal

# Generated at 2022-06-25 23:41:04.779001
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutableList_1 = ImmutableList(7)
    immutableList_2 = immutableList_1.filter(lambda x: x % 2 == 0)
    immutableList_3 = immutableList_2.filter(lambda x: x % 2 != 0)
    immutableList_4 = ImmutableList(7, ImmutableList(8)).filter(lambda x: x % 2 == 0)

    assert(immutableList_2.is_empty)
    assert(immutableList_3.is_empty)
    assert(immutableList_4 == ImmutableList(8))
    assert(immutableList_4.tail.is_empty)



# Generated at 2022-06-25 23:41:09.421200
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create first list
    immutable_list_0 = ImmutableList.of(-1, 0, 1, 2, 3, 4, 5)

    # Create second list
    immutable_list_1 = immutable_list_0.filter(lambda x: x >= 0)

    assert immutable_list_1 == ImmutableList.of(0, 1, 2, 3, 4, 5)


# Generated at 2022-06-25 23:41:11.913548
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0.head
    immutable_list_0.tail
    immutable_list_0.is_empty
    # Test for method find of class ImmutableList
    # Type error


# Generated at 2022-06-25 23:41:17.489850
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList()
    immutable_list = ImmutableList(11)
    immutable_list = ImmutableList(11, ImmutableList(4))
    immutable_list = ImmutableList(11, ImmutableList(4, ImmutableList(2)))
    immutable_list = ImmutableList(11, ImmutableList(4, ImmutableList(2, ImmutableList(2))))


# Generated at 2022-06-25 23:41:26.808875
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList(False, None)
    try:
        immutable_list_0.find()
    except:
        print('Exception: Test case 0: immutable_list_0.find()')

    # Test case 1
    immutable_list_1 = ImmutableList(False, None)
    try:
        immutable_list_1.find(1, 2)
    except:
        print('Exception: Test case 1: immutable_list_1.find(1, 2)')

    # Test case 2
    immutable_list_2 = ImmutableList(False, None)
    try:
        immutable_list_2.find(1)
    except:
        print('Exception: Test case 2: immutable_list_2.find(1)')

    # Test case 3
    immutable_list

# Generated at 2022-06-25 23:41:35.149962
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    class CallableTestClass:
        def __call__(self, n):
            return n > 0

    callableTestInstance = CallableTestClass()

    # Test case 1
    immutable_list_0 = ImmutableList.of(5)
    resultBool = (immutable_list_0.filter(callableTestInstance)).to_list() == [5]
    assert resultBool, "Test is failed"
    # Test case 2
    immutable_list_1 = ImmutableList.of(0, 2, 3)
    resultBool = (immutable_list_1.filter(callableTestInstance)).to_list() == [2, 3]
    assert resultBool, "Test is failed"
    # Test case 3
    immutable_list_2 = ImmutableList.of(-4, -5, -6)
    result

# Generated at 2022-06-25 23:41:44.593128
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(0, 1, 2)
    fn = lambda x: False if x == 1 else True
    assert immutable_list_0.find(fn) == 0

    immutable_list_1 = ImmutableList.of(0, 1, 2)
    fn = lambda x: False if x == 2 else True
    assert immutable_list_1.find(fn) == 0

    immutable_list_2 = ImmutableList.of(0, 1, 2)
    fn = lambda x: False if x == 3 else True
    assert immutable_list_2.find(fn) == 0

    immutable_list_3 = ImmutableList.of(0, 1, 2)
    fn = lambda x: False if x == 0 else True
    assert immutable_list_3.find(fn) == 1

    immutable_

# Generated at 2022-06-25 23:41:57.504936
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(int())
    immutable_list_0 = immutable_list_0.filter(lambda element_immutable_list_0, element_immutable_list_1 : int() >= 0)
    assert immutable_list_0 == ImmutableList(int())
    immutable_list_0 = ImmutableList.of(int())
    immutable_list_0 = immutable_list_0.filter(lambda element_immutable_list_0, element_immutable_list_1 : bool())
    assert immutable_list_0 == ImmutableList(int())
    immutable_list_1 = ImmutableList.of(tuple())
    immutable_list_1 = immutable_list_1.filter(lambda element_immutable_list_0, element_immutable_list_1 : bool())
    assert immutable_list_

# Generated at 2022-06-25 23:42:05.192585
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(2)
    immutable_list_1 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter((lambda x : (x < 2)))
    assert immutable_list_1 == ImmutableList(False)


# Generated at 2022-06-25 23:42:10.337283
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(None, ImmutableList(True, ImmutableList(0, ImmutableList(2, ImmutableList('a')))))
    immutable_list_1 = immutable_list_0.filter(lambda a: (a % 2) == 0)
    assert immutable_list_1.head == 0
    assert immutable_list_1.tail.head == 2


# Generated at 2022-06-25 23:42:13.872238
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    value_0 = ImmutableList.of(3, 6, 1, 8, 8, 9, 5).find(lambda x: x > 5)
    assert value_0 == 6


# Generated at 2022-06-25 23:42:25.437175
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(is_empty=True) == ImmutableList()
    assert ImmutableList() != ImmutableList(False, is_empty=True)
    assert ImmutableList(True, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList())))) == ImmutableList(True, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(is_empty=True)))))
    assert ImmutableList(True, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(is_empty=True))))) == ImmutableList(True, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList()))))

# Generated at 2022-06-25 23:42:31.401957
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1)
    assert immutable_list_0.filter(lambda element: element > 2).head is None, "Fail test_ImmutableList_filter"
    immutable_list_1 = ImmutableList.of(1)
    assert immutable_list_1.filter(lambda element: element > 0).head == 1, "Fail test_ImmutableList_filter"


# Generated at 2022-06-25 23:42:39.531662
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # ImmutableList.__eq__ -> bool

    immutable_list_0 = ImmutableList(ImmutableList())
    immutable_list_1 = ImmutableList()
    assert (immutable_list_0 == immutable_list_1) == True
    
    immutable_list_0 = ImmutableList(ImmutableList(ImmutableList(is_empty = True)))
    immutable_list_1 = ImmutableList(ImmutableList(is_empty = True))
    assert (immutable_list_0 == immutable_list_1) == True
    
    immutable_list_0 = ImmutableList(ImmutableList(is_empty = True), 1)

# Generated at 2022-06-25 23:42:48.699998
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Initialization
    immutable_list_0 = ImmutableList(True, None)

    # Method call
    # Result should be True
    assert immutable_list_0.find(lambda x: x) == True

    # Initialization
    immutable_list_0 = ImmutableList(False, None)

    # Method call
    # Result should be None
    # because there is not elements that satisfy the condition (x)
    assert immutable_list_0.find(lambda x: x) == None

    # Initialization
    immutable_list_0 = ImmutableList(True, ImmutableList(False, None))

    # Method call
    # Result should be True
    assert immutable_list_0.find(lambda x: x) == True

    # Initialization

# Generated at 2022-06-25 23:42:54.137817
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)

    result_0 = immutable_list_0 == immutable_list_1
    result_1 = immutable_list_1 == immutable_list_0

    assert result_0 == False
    assert result_1 == False


# Generated at 2022-06-25 23:42:58.596153
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList.of(1, 2)

    x = immutable_list_1.find(lambda x: x > 1)

    if x != 2:
        print('ImmutableList.find did not return expected result')
        exit(1)

test_ImmutableList_find()

# Generated at 2022-06-25 23:43:11.840610
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    check_ImmutableList_filter(
        ImmutableList(1, ImmutableList(2, ImmutableList(3))),
        lambda x: x > 1,
        ImmutableList(2, ImmutableList(3))
    )

    check_ImmutableList_filter(
        ImmutableList(1, ImmutableList(2, ImmutableList(3))),
        lambda x: x < 4,
        ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    )

    check_ImmutableList_filter(
        ImmutableList(1, ImmutableList(2, ImmutableList(3))),
        lambda x: x < 1,
        ImmutableList()
    )


# Generated at 2022-06-25 23:43:16.616469
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None, None)
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList(None, immutable_list_2)
    assert not immutable_list_2 == immutable_list_3


# Generated at 2022-06-25 23:43:24.218554
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    immutable_list_0 = ImmutableList()

    def ret_arg_predicate(a):
        return a

    # When
    immutable_list_1 = immutable_list_0.filter(ret_arg_predicate)

    # Then
    assert immutable_list_1.is_empty
    assert immutable_list_0 is not immutable_list_1

    # Given
    immutable_list_2 = ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9, ImmutableList(10))))))))

    def even_predicate(a):
        return a % 2 == 0

    # When
    immutable_list_3 = immutable_list_2.filter(even_predicate)

    # Then
   

# Generated at 2022-06-25 23:43:30.379353
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_0 = immutable_list_0.filter(lambda num: num % 2 == 0)
    assert len(immutable_list_0) == 2
    assert immutable_list_0.head == 2
    assert immutable_list_0.tail.head == 4



# Generated at 2022-06-25 23:43:35.567823
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 is not immutable_list_1
    immutable_list_1 = immutable_list_1.filter(None)
    immutable_list_0 = immutable_list_0.filter(None)
    assert immutable_list_0 is immutable_list_1


# Generated at 2022-06-25 23:43:44.375519
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = immutable_list_0.filter(lambda x: x)
    assert immutable_list_1 == ImmutableList(None)
    immutable_list_2 = ImmutableList(False)
    immutable_list_3 = immutable_list_2.filter(lambda x: not x)
    assert immutable_list_3 == ImmutableList(False)

    immutable_list_4 = ImmutableList(True)
    immutable_list_5 = immutable_list_4.filter(lambda x: not x)
    assert immutable_list_5 == ImmutableList(is_empty=True)
    immutable_list_6 = ImmutableList(0)
    immutable_list_7 = immutable_list_6.filter(lambda x: x)

# Generated at 2022-06-25 23:43:52.195193
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3)
    immutable_list_1 = ImmutableList.of(0, 1, 2, 3)
    immutable_list_2 = ImmutableList.of(1, 2, 3)
    immutable_list_3 = immutable_list_0.filter(
        lambda x : x < 3
        )
    immutable_list_4 = immutable_list_1.filter(
        lambda x : not (x < 4)
        )
    assert immutable_list_3 == immutable_list_2
    assert immutable_list_4 == immutable_list_0


# Generated at 2022-06-25 23:44:01.507311
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList(1, 2, 3, 4, 5)
    assert my_list.filter(lambda x: x>2) == ImmutableList(3, 4, 5)
    assert my_list.filter(lambda x: x<4) == ImmutableList(1, 2, 3)
    assert my_list.filter(lambda x: x%2 == 0) == ImmutableList(2, 4)
    assert my_list.filter(lambda x: x==3) == ImmutableList(3)
    assert my_list.filter(lambda x: x>10) == ImmutableList(is_empty=True)


# Generated at 2022-06-25 23:44:09.709891
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0.append(obj0)
    immutable_list_0.append(float0)
    immutable_list_0.append(obj1)
    immutable_list_0.append(obj2)
    immutable_list_0.append(bool0)
    immutable_list_0.append(float1)
    immutable_list_0.append(obj3)
    immutable_list_0.append(bool1)
    immutable_list_0.append(str0)
    immutable_list_0.append(int0)
    immutable_list_0.append(int1)
    immutable_list_0.append(str1)
    immutable_list_0.append(int2)


# Generated at 2022-06-25 23:44:20.156272
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(873094, 0, -1, 1, -1)
    result = immutable_list_0.filter(lambda x: x < 0)
    assert result == ImmutableList(-1, ImmutableList(-1))
    
    immutable_list_1 = ImmutableList.of(True)
    result = immutable_list_1.filter(lambda x: x)
    assert result == ImmutableList(True)
    
    immutable_list_2 = ImmutableList.of(False)
    result = immutable_list_2.filter(lambda x: x)
    assert result == ImmutableList(is_empty=True)
    
    immutable_list_3 = ImmutableList.of(True, True)
    result = immutable_list_3.filter(lambda x: x)

# Generated at 2022-06-25 23:44:32.093339
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter((lambda value: (value > -1)))
    assert immutable_list_1 == ImmutableList()

    immutable_list_2 = ImmutableList.of(0)
    immutable_list_3 = immutable_list_2.filter((lambda value: (value > -1)))
    assert immutable_list_3 == ImmutableList.of(0)

    immutable_list_4 = ImmutableList.of(0, 1, 2)
    immutable_list_5 = immutable_list_4.filter((lambda value: (value > -1)))
    assert immutable_list_5 == ImmutableList.of(0, 1, 2)


# Generated at 2022-06-25 23:44:37.486309
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2)
    immutable_list_1 = immutable_list_0.filter(lambda element: element > 0)
    immutable_list_2 = immutable_list_0.filter(lambda element: element > 2)
    immutable_list_3 = immutable_list_2.filter(lambda element: element < 0)
    assert immutable_list_1.tail is None
    assert immutable_list_1.head == 2
    assert immutable_list_3.is_empty


# Generated at 2022-06-25 23:44:45.131464
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(3, 4)
    immutable_list_1 = ImmutableList.empty()
    immutable_list_2 = immutable_list_0.filter(lambda x: x >= 3 and x <= 4)

    assert immutable_list_0 != immutable_list_1
    assert immutable_list_2 == ImmutableList.of(3, 4)
    assert immutable_list_2.filter(lambda x: x == 3) == ImmutableList.of(3)
    assert immutable_list_0 != immutable_list_2


# Generated at 2022-06-25 23:44:52.568587
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(True)
    immutable_list_0 = immutable_list_0.append(False)
    immutable_list_0 = immutable_list_0.append(True)
    immutable_list_0 = immutable_list_0.append(True)
    immutable_list_1 = immutable_list_0.filter(lambda arg0: arg0)
    assert immutable_list_1.to_list() == [True, True, True], "AssertionError"



# Generated at 2022-06-25 23:44:59.717080
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    mock_0 = ImmutableList.of(1, 2, 3)
    assert mock_0.filter(lambda _: False) == ImmutableList(is_empty=True)

    mock_1 = ImmutableList.of(1, 2, 3)
    assert mock_1.filter(lambda _: True) == ImmutableList.of(1, 2, 3)

    mock_2 = ImmutableList.of(1, 2, 3)
    assert mock_2.filter(lambda _: False) == ImmutableList.empty()

    mock_3 = ImmutableList.of(1, 2, 3)
    assert mock_3.filter(lambda _: True) == ImmutableList.of(1, 2, 3)

    mock_4 = ImmutableList.of(1, 2, 3)

# Generated at 2022-06-25 23:45:09.720042
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(2, ImmutableList(4, None))))
    immutable_list_2 = ImmutableList.empty()
    immutable_list_3 = immutable_list_1.filter(lambda x: x > 1)
    assert immutable_list_3.filter(lambda x: x > 2) == ImmutableList(2, ImmutableList(4))
    assert immutable_list_3 == ImmutableList(2, ImmutableList(2, ImmutableList(4)))
    assert immutable_list_2.filter(lambda x: x > 1) == ImmutableList.empty()

# Generated at 2022-06-25 23:45:15.699497
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    immutable_list_1 = immutable_list_0.filter((lambda x : (x < 9)))
    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8) == immutable_list_1


# Generated at 2022-06-25 23:45:21.029847
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7)
    immutable_list_1 = immutable_list_0.filter(lambda x: x > 3)
    immutable_list_2 = immutable_list_0.filter(lambda x: x < 0)
    assert immutable_list_0 != immutable_list_1
    assert immutable_list_1 == ImmutableList.of(4, 5, 6, 7)
    assert immutable_list_2 == ImmutableList.of()
    pass


# Generated at 2022-06-25 23:45:26.861575
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of('first', 2, 3)
    assert immutable_list_0.filter(lambda v: isinstance(v, str)).to_list() == ['first']
    assert immutable_list_0.filter(lambda v: isinstance(v, int)).to_list() == [2, 3]
    assert immutable_list_0.filter(lambda v: False).to_list() == []


# Generated at 2022-06-25 23:45:37.700096
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # generate `list` with elements
    list_0 = []
    for i in range(5):
        list_0.append(i)
    # transform it into `immutable_list`
    immutable_list_0 = ImmutableList.of(list_0)

    def pre_condition(number):
        return number > 2 or number < 2

    # collect all filtered elements into `list`
    result_list = []
    immutable_list = immutable_list_0
    while immutable_list.head is not None:
        if pre_condition(immutable_list.head):
            result_list.append(immutable_list.head)
        immutable_list = immutable_list.tail
    # transform all filtered elements into `immutable_list`
    result_immutable_list = ImmutableList.of(result_list)
   

# Generated at 2022-06-25 23:45:45.901458
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    v0 = ImmutableList(True)
    v1 = ImmutableList(True)

    assert v0.__eq__(v1)


# Generated at 2022-06-25 23:45:52.563072
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il_0 = ImmutableList(1, ImmutableList(2), 3, ImmutableList(4), 5)
    def filter_fn_0(el):
        if el % 2 == 0:
            return True
        return False
    il_1 = il_0.filter(filter_fn_0)
    assert il_1 == ImmutableList(2, ImmutableList(4))


# Generated at 2022-06-25 23:46:02.352814
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter(lambda param_0: True)
    immutable_list_2 = ImmutableList(True)
    immutable_list_1 = immutable_list_2.filter(lambda param_0: True)
    assert immutable_list_1 == ImmutableList(True)
    immutable_list_3 = ImmutableList(True, None)
    immutable_list_1 = immutable_list_3.filter(lambda param_0: False)
    assert immutable_list_1 == ImmutableList(is_empty=True)
    immutable_list_4 = ImmutableList(1, None)
    immutable_list_1 = immutable_list_4.filter(lambda param_0: True)
    assert immutable_list_1 == immutable_list_4



# Generated at 2022-06-25 23:46:07.770030
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    fn_0 = lambda num: num % 2 != 0

    result = immutable_list_0.filter(fn_0)
    assert result == ImmutableList.of(1, 3, 5)

    immutable_list_1 = ImmutableList.of(1)
    fn_1 = lambda num: num <= 0
    result = immutable_list_1.filter(fn_1)
    assert result == ImmutableList.of(1)


# Generated at 2022-06-25 23:46:16.982730
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    fn_ImmutableList_filter_0 = lambda x: x == 1
    fn_ImmutableList_filter_1 = lambda x: x > 1
    ImmutableList_filter_0 = ImmutableList.of(1, 2, 3)
    ImmutableList_filter_1 = ImmutableList.of(3, 4, 5)
    ImmutableList_filter_2 = ImmutableList.of(1, 2, 3)
    ImmutableList_filter_3 = ImmutableList.of(1)
    ImmutableList_filter_4 = ImmutableList.of(2)

    assert ImmutableList_filter_0.filter(fn_ImmutableList_filter_0).to_list() == [1]

# Generated at 2022-06-25 23:46:22.635420
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert(
        ImmutableList.of('dog', 'cat', 'bunny').filter(lambda x: len(x) == 3).to_list() ==
        ['dog', 'cat']
    )
    assert(ImmutableList.of(1, 2).filter(lambda x: x == 1).to_list() == [1])
    assert(ImmutableList.of('dog', 'cat').filter(lambda x: x == 'bunny').to_list() == [])


# Generated at 2022-06-25 23:46:26.434311
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    def fn_0(value_0: Optional[None]) -> bool:
        return value_0 is None
    immutable_list_1 = immutable_list_0.filter(fn_0)
    assert immutable_list_1 == immutable_list_0


# Generated at 2022-06-25 23:46:30.004987
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(5)
    immutable_list_1 = ImmutableList.of(5)
    immutable_list_2 = ImmutableList.of(5, 10)
    immutable_list_3 = ImmutableList.of(10)


# Generated at 2022-06-25 23:46:34.989644
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(True)
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList.of(17)
    immutable_list_4 = ImmutableList.of(True, False)
    immutable_list_5 = ImmutableList.of(3.141592, 3.141592)
    immutable_list_6 = ImmutableList.of(False, True)
    immutable_list_7 = ImmutableList.of(1, 3, 2)
    immutable_list_8 = ImmutableList.of(3.141592, 3.141592)
    immutable_list_9 = ImmutableList.of(4, 2, 1, 0)

# Generated at 2022-06-25 23:46:45.663802
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()

    immutable_list_1 = ImmutableList.of(1)

    immutable_list_2 = ImmutableList.of(2, 3)

    immutable_list_3 = ImmutableList.of(1, 2, 3)

    immutable_list_4 = ImmutableList.of(0, 1, 2, 3)

    immutable_list_5 = ImmutableList.of(0, 0, 1, 2, 3)

    immutable_list_6 = ImmutableList.of(0, 1, 0, 2, 3)

    immutable_list_7 = ImmutableList.of(0, 0, 1, 2, 3, 0, 0, 0)

    immutable_list_8 = ImmutableList.of(0, 0, 1, 2, 3, 0)


# Generated at 2022-06-25 23:47:00.903482
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    returned_list_0 = test_list_0.filter(lambda x: isinstance(x, int))
    expected_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    assert returned_list_0 == expected_list_0

    test_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    returned_list_1 = test_list_1.filter(lambda x: x % 2 == 0)
    expected_list_1 = ImmutableList.of(2, 4)
    assert returned_list_1 == expected_list_1

    test_list_2 = ImmutableList.of(1, 2, 3, 4, 5)
    returned_list_2

# Generated at 2022-06-25 23:47:11.756565
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(0, ImmutableList(False, ImmutableList(0.0, ImmutableList.empty())))
    assert immutable_list_0.__eq__(immutable_list_0) == True
    immutable_list_1 = ImmutableList(True, ImmutableList.empty())
    assert immutable_list_0.__eq__(immutable_list_1) == False
    immutable_list_2 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_2) == False
    immutable_list_3 = ImmutableList(True, ImmutableList(True, ImmutableList.empty()))
    assert immutable_list_1.__eq__(immutable_list_3) == True


# Generated at 2022-06-25 23:47:21.649162
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None, None)
    assert(immutable_list_0 == ImmutableList(None, None))
    immutable_list_1 = ImmutableList(None, None)
    assert(immutable_list_1 == ImmutableList(None, None))
    immutable_list_2 = ImmutableList(None, None)
    assert(immutable_list_2 == ImmutableList(None, None))
    assert(immutable_list_1 == immutable_list_0)
    assert(immutable_list_0 == immutable_list_0)
    assert(immutable_list_2 == immutable_list_1)
    immutable_list_3 = ImmutableList(None)
    assert(ImmutableList.of(None) == ImmutableList(None))

# Generated at 2022-06-25 23:47:26.158615
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
      # Setup
      immutable_list_0 = ImmutableList(1)
      fn = lambda x: x > 0
      # Exercise

      # Verify
      result = immutable_list_0.filter(fn) == ImmutableList(1)
      # Teardown


# Generated at 2022-06-25 23:47:35.790754
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 0)
    immutable_list_0 = immutable_list_0.filter(lambda element: element < 10)
    assert immutable_list_0.head == 0
    assert immutable_list_0.tail.head == 0
    assert immutable_list_0.tail.is_empty is False
    assert immutable_list_0.tail.tail is None
    assert immutable_list_0.is_empty is False
    immutable_list_1 = ImmutableList.of(10, 10)
    immutable_list_1 = immutable_list_1.filter(lambda element: element < 10)
    assert immutable_list_1.head == 10
    assert immutable_list_1.tail.head == 10
    assert immutable_list_1.tail.is_empty is False
    assert immutable_list

# Generated at 2022-06-25 23:47:39.820212
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1,2,3)
    assert a.filter(lambda x: x > 1) == ImmutableList.of(2,3)
    assert a.filter(lambda x: x > 0) == ImmutableList.of(1,2,3)
    assert a.filter(lambda x: x > 3) == ImmutableList.empty()


# Generated at 2022-06-25 23:47:48.746691
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Test filter method of ImmutableList class
    """

    # initialize a list of sample values
    sample = [
        ImmutableList(),
        ImmutableList(None),
        ImmutableList(1),
        ImmutableList('Hello'),
        ImmutableList(1, 2, 3),
        ImmutableList('H', 'e', 'l', 'l', 'o')
    ]

    # initialize a list of expected values
    expected = [
        True,
        True,
        False,
        False,
        False,
        False
    ]

    # initialize a list of actual values

# Generated at 2022-06-25 23:47:59.429617
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print("test_ImmutableList_filter")
    immutable_list_0 = ImmutableList()
    immutable_list_0.is_empty = True
    int_0 = 2
    int_1 = 3
    int_2 = 6
    int_3 = 7
    immutable_list_0.head = int_2
    immutable_list_0.tail = ImmutableList()
    immutable_list_0.tail.head = int_3
    immutable_list_0.tail.tail = ImmutableList()
    immutable_list_0.tail.tail.is_empty = True
    ImmutableList_instance_0 = ImmutableList()
    ImmutableList_instance_0.is_empty = True
    ImmutableList_instance_1 = ImmutableList()
    ImmutableList_instance_1.is_empty = True
   

# Generated at 2022-06-25 23:48:10.546926
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(1, ImmutableList(3, ImmutableList(4, ImmutableList(6, ImmutableList(1.0, ImmutableList(0.0, ImmutableList(1.0, ImmutableList())))))))
    immutable_list_1 = ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList())))
    immutable_list_2 = ImmutableList(2, ImmutableList(0, ImmutableList(2, ImmutableList(0, ImmutableList(0, ImmutableList(0, ImmutableList(0, ImmutableList(0, ImmutableList(0, ImmutableList())))))))))

# Generated at 2022-06-25 23:48:15.730728
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    immutable_list_list = [immutable_list_0, immutable_list_1]
    assert immutable_list_0.filter(lambda value: True if value == immutable_list_1 else False) == immutable_list_0


# Generated at 2022-06-25 23:48:31.057576
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.of(False)
    immutable_list_1 = ImmutableList.of(False)
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.of(True)
    assert not immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1

    immutable_list_0 = ImmutableList.of(True)
    immutable_list_1 = ImmutableList()


# Generated at 2022-06-25 23:48:40.519995
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3).filter(lambda x: x >= 2) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList.of(1).filter(lambda x: x >= 2) == ImmutableList(is_empty=True)
    assert ImmutableList.of(1,2).filter(lambda x: x >= 2) == ImmutableList(2)
    assert ImmutableList.of(1,2,3).filter(lambda x: x >= 2) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList.of(2).filter(lambda x: x >= 2) == ImmutableList(2)
    assert ImmutableList.of(1,2).filter(lambda x: x >= 2) == ImmutableList(2)

# Generated at 2022-06-25 23:48:43.473254
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList[int]()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(1)
    assert immutable_list_1.__eq__(immutable_list_2)


# Generated at 2022-06-25 23:48:46.922249
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(2, ImmutableList(1)) != ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-25 23:48:50.509571
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
	immutable_list_0 = ImmutableList()
	immutable_list_1 = ImmutableList()

	assert immutable_list_0.__eq__(immutable_list_1) == immutable_list_1.__eq__(immutable_list_0)


# Generated at 2022-06-25 23:48:59.842066
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    t0_0 = ImmutableList()
    t0_array_0 = []
    assert t0_0.filter(lambda e: e % 2 == 0) == ImmutableList(is_empty=True)
    t1_0 = ImmutableList(2)
    t1_array_0 = [2]
    assert t1_0.filter(lambda e: e % 2 == 0) == ImmutableList(2)
    t2_0 = ImmutableList(3)
    t2_array_0 = [3]
    assert t2_0.filter(lambda e: e % 2 == 0) == ImmutableList(is_empty=True)
    t3_0 = ImmutableList(2, ImmutableList(4))
    t3_array_0 = [2, 4]

# Generated at 2022-06-25 23:49:08.622719
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create a new instance of ImmutableList
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList()
    immutable_list_7 = ImmutableList()
    immutable_list_8 = ImmutableList()
    immutable_list_9 = ImmutableList()
    immutable_list_10 = ImmutableList()
    immutable_list_11 = ImmutableList()
    immutable_list_12 = ImmutableList()
    immutable_list_13 = ImmutableList()

    # Invoke method filter of class ImmutableList

# Generated at 2022-06-25 23:49:18.919240
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_0.head = "r"
    immutable_list_0.tail = immutable_list_1
    immutable_list_0.is_empty = False
    immutable_list_1.head = "n"
    immutable_list_1.tail = immutable_list_0
    immutable_list_1.is_empty = False
    immutable_list_0.head = "m"
    immutable_list_0.tail = immutable_list_0
    immutable_list_0.is_empty = False
    immutable_list_1.head = "t"
    immutable_list_1.tail = immutable_list_0
    immutable_list_1.is_empty = False

# Generated at 2022-06-25 23:49:21.542849
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # arrange
    immutable_list_0 = ImmutableList.of(8, 9, 10)

    # act
    test_result_0 = immutable_list_0.filter(lambda value: value % 2 == 1)

    # assert
    assert test_result_0 == ImmutableList.of(9)


# Generated at 2022-06-25 23:49:24.241061
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    array_0 = ImmutableList.of(1, 2, 3)
    def function_0(value):
        return value % 2 == 0
    
    assert array_0.filter(function_0).to_list() == [2]


# Generated at 2022-06-25 23:49:55.551656
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList.of(1, 2)
    assert immutable_list_1.filter(lambda x: x > 1) == ImmutableList.empty()
    # Test case 1
    immutable_list_2 = ImmutableList.empty()
    immutable_list_3 = immutable_list_2.filter(lambda x: x < 2)
    assert immutable_list_3 == ImmutableList.empty()
    # Test case 2
    immutable_list_4 = ImmutableList.of(2, 1)
    immutable_list_5 = immutable_list_4.filter(lambda x: x == 1)
    assert immutable_list_5 == ImmutableList(2)
    # Test case 3
    immutable_list_6 = ImmutableList.of(3, 2)
    immutable_list_7 = immutable_list_6

# Generated at 2022-06-25 23:50:06.904191
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create instance of ImmutableList
    immutable_list = ImmutableList()
    assert immutable_list.filter(lambda x: True) == ImmutableList()

    # Create instance of ImmutableList
    immutable_list = ImmutableList()
    assert immutable_list.filter(lambda x: False) == ImmutableList()

    # Create instance of ImmutableList
    immutable_list = ImmutableList()
    assert immutable_list.filter(lambda x: x>=0) == ImmutableList()

    # Create instance of ImmutableList
    immutable_list = ImmutableList()
    assert immutable_list.filter(lambda x: x<0) == ImmutableList()



# Generated at 2022-06-25 23:50:13.037425
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    map_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert map_list.filter(lambda a: a < 3).to_list() == [1, 2]
    assert map_list.filter(lambda a: a % 3 == 0).to_list() == [3]
    assert map_list.filter(lambda a: a % 0 == 1).to_list() == []


# Generated at 2022-06-25 23:50:23.566946
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    method = getattr(immutable_list_0, "filter", None)
    immutable_list_0 = immutable_list_0.filter(None)

    immutable_list_1 = ImmutableList()
    method = getattr(immutable_list_1, "filter", None)
    immutable_list_1 = immutable_list_1.filter(None)

    immutable_list_2 = ImmutableList()
    method = getattr(immutable_list_2, "filter", None)
    immutable_list_2 = immutable_list_2.filter(None)
