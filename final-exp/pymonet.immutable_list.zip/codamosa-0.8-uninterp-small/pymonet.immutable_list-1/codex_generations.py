

# Generated at 2022-06-25 23:40:34.550507
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    assert immutable_list_0 == immutable_list_0


# Generated at 2022-06-25 23:40:45.284594
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of([1, 2, 3], [3, 4, 5], [6, 7, 8, 9])
    immutable_list_1 = immutable_list_0.filter(lambda lst: len(lst) > 3)
    immutable_list_2 = immutable_list_1.filter(lambda lst: len(lst) > 3)
    assert immutable_list_2 == ImmutableList([6, 7, 8, 9], is_empty=False)
    immutable_list_3 = immutable_list_0.filter(lambda lst: len(lst) > 1)
    assert immutable_list_3 == ImmutableList([1, 2, 3], [3, 4, 5], is_empty=False)

# Generated at 2022-06-25 23:40:50.581145
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    m1 = ImmutableList.of(1, 2, 3)
    m2 = ImmutableList.of(4, 5, 6)
    m3 = ImmutableList.of(7, 8, 9)

    m_list = m1 + m2 + m3

    filtered_list = m_list.filter(lambda x: x > 5)

    expected = 6
    actual = filtered_list.to_list()[0]
    assert expected == actual



# Generated at 2022-06-25 23:40:52.520959
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(5, 10, 15).find(lambda x: x > 10) == 15


# Generated at 2022-06-25 23:40:58.125587
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert immutable_list.find(lambda x: x % 2 == 0) == 2


# Generated at 2022-06-25 23:41:02.245336
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(None)
    assert(immutable_list_0 == immutable_list_1)


# Generated at 2022-06-25 23:41:11.125465
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList(is_empty=True)
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList(False, immutable_list_0)
    immutable_list_3 = ImmutableList(False, immutable_list_1)
    assert immutable_list_2 == immutable_list_3
    immutable_list_4 = ImmutableList(False, immutable_list_3)
    immutable_list_5 = ImmutableList(False, immutable_list_2)
    assert immutable_list_4 == immutable_list_5
    immutable_list_6 = ImmutableList(False, immutable_list_5)
    immutable_list_7 = ImmutableList(False, immutable_list_4)
    assert immutable_list

# Generated at 2022-06-25 23:41:20.694176
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(1)
    immutable_list_0_copy = immutable_list_0
    expected_1 = True
    actual_1 = immutable_list_0 == immutable_list_0_copy
    print(actual_1)
    print(expected_1)
    assert actual_1 == expected_1
    
    empty = ImmutableList()
    expected_2 = False
    actual_2 = immutable_list_0 == empty
    print(actual_2)
    print(expected_2)
    assert actual_2 == expected_2
    
    immutable_list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    expected_3 = True
    actual_3 = immutable_list_1 == immutable_list_1
    print(actual_3)
    print

# Generated at 2022-06-25 23:41:22.569749
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1, ImmutableList(2)))


# Generated at 2022-06-25 23:41:32.586771
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(1)
    immutable_list_2 = ImmutableList.of(1)
    immutable_list_3 = ImmutableList(None)
    immutable_list_4 = ImmutableList(1)
    immutable_list_5 = ImmutableList(1)
    immutable_list_6 = ImmutableList(None)
    immutable_list_7 = ImmutableList(None)
    immutable_list_8 = ImmutableList.empty()
    immutable_list_9 = ImmutableList.empty()
    immutable_list_10 = ImmutableList.of(1, 2)
    immutable_list_11 = ImmutableList.of(1, 2)
    immutable_list_12 = ImmutableList.of(1, 2)
    immutable_

# Generated at 2022-06-25 23:41:45.162381
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    data = [
        [ImmutableList.of(), [1, 2, 3], lambda x: True, [None], ImmutableList.empty()],
        [ImmutableList.of(), [1, 2, 3], lambda x: True, [1, 2, 3], ImmutableList.of(1, 2, 3, None)],
        [ImmutableList.of(), [1, 2, 3], lambda x: x == 2, [2], ImmutableList.of(2)],
        [ImmutableList.of(), [1, 2, 3], lambda x: x < 3, [1, 2], ImmutableList.of(1, 2)],
        [ImmutableList.of(), [1, 2, 3], lambda x: x > 2, [3], ImmutableList.of(3)],
    ]


# Generated at 2022-06-25 23:41:54.495117
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0.head = 'dog'
    immutable_list_0.tail = None
    immutable_list_0.is_empty = False
    immutable_list_1 = ImmutableList()
    immutable_list_1.head = 'cat'
    immutable_list_1.tail = immutable_list_0
    immutable_list_1.is_empty = False
    test_case_0_0_0 = ImmutableList()
    test_case_0_0_0.head = 'pig'
    test_case_0_0_0.tail = immutable_list_1
    test_case_0_0_0.is_empty = False
    res = test_case_0_0_0.find(lambda x: x == 'dog')

    assert res

# Generated at 2022-06-25 23:41:57.927632
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Example from readme
    immutable_list_0 = ImmutableList([2,3,4])
    result = immutable_list_0.filter(lambda x: x > 2)
    assert result.head == 3
    assert result.tail.head == 4
    assert result.tail.tail is None


# Generated at 2022-06-25 23:42:11.191847
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    mutable_list = [1]
    immutable_list_0 = ImmutableList.of(mutable_list[0])
    fn = lambda x: x>2
    result = immutable_list_0.filter(fn)
    assert(isinstance(result, ImmutableList))
    assert(result.head is None)
    assert(result.tail is None)
    assert(result.is_empty)
    # Test case 1
    mutable_list = [1, 2]
    immutable_list_0 = ImmutableList.of(mutable_list[0], mutable_list[1])
    fn = lambda x: x>2
    result = immutable_list_0.filter(fn)
    expected = ImmutableList.empty()
    assert(isinstance(result, ImmutableList))

# Generated at 2022-06-25 23:42:22.905774
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(3, None, True)
    immutable_list_1 = ImmutableList(3, None, True)
    immutable_list_2 = ImmutableList.of(1)
    immutable_list_3 = ImmutableList.of(2, 3)
    immutable_list_4 = ImmutableList.of(2, 3)
    result = immutable_list_0.filter(lambda x : True)
    result_1 = immutable_list_1.filter(lambda x : False)
    result_2 = immutable_list_2.filter(lambda x : (x < 5))
    result_3 = immutable_list_3.filter(lambda x : (x > 5))
    result_4 = immutable_list_4.filter(lambda x : (x < 5))
    assert result_1 == ImmutableList

# Generated at 2022-06-25 23:42:31.738654
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(5, ImmutableList(10, ImmutableList(15, ImmutableList(20, ImmutableList(25)))))
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 20)
    assert(immutable_list_0.head == 25)
    assert(immutable_list_0.tail.head == None)
    assert(immutable_list_0.tail.tail == None)
    assert(immutable_list_0.tail.tail == None)
    assert(immutable_list_0.tail.tail == None)


# Generated at 2022-06-25 23:42:39.757386
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Pass
    immutable_list_0 = ImmutableList.of(4, 2, 3, 3)
    def fn_0(x_0):
        return x_0 % 2 == 0
    immutable_list_0 = immutable_list_0.filter(fn_0)
    assert isinstance(immutable_list_0, ImmutableList)
    assert immutable_list_0 != immutable_list_0
    assert immutable_list_0 == immutable_list_0
    assert immutable_list_0 != immutable_list_0
    assert immutable_list_0 == immutable_list_0
    assert immutable_list_0 != immutable_list_0
    assert immutable_list_0 == immutable_list_0
    assert immutable_list_0 != immutable_list_0
    assert immutable_list_0 == immutable_list_0
    assert immutable

# Generated at 2022-06-25 23:42:42.011601
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:42:47.154033
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) is None
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1,2,3,4).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1,2,3,4).find(lambda x: x == 5) is None


# Generated at 2022-06-25 23:42:57.511429
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(4, 4, 1, 5, 7, 1, 3, 3, 9, 9, 2, 1, 9, 9, 2, 5, 9, 1, 2)
    immutable_list_1 = immutable_list_0.append(8)
    immutable_list_2 = immutable_list_1.append(9)
    immutable_list_3 = immutable_list_2.append(7)
    immutable_list_4 = immutable_list_3.append(5)
    immutable_list_5 = immutable_list_4.append(6)
    immutable_list_6 = immutable_list_5.append(7)
    immutable_list_7 = immutable_list_6.append(5)
    immutable_list_8 = immutable_list_7.append(6)
    immutable_

# Generated at 2022-06-25 23:43:12.864003
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(None)
    immutable_list_0.is_empty = True

    if immutable_list_0.find(lambda x: False) is None:
        print("Test 0 passed")
    else:
        print("Test 0 failed")

    immutable_list_1 = ImmutableList(None, ImmutableList(None), False)

    if immutable_list_1.find(lambda x: False) is None:
        print("Test 1 passed")
    else:
        print("Test 1 failed")

    def t(x):
        return x == 2

    immutable_list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    if immutable_list_2.find(t) == 2:
        print("Test 2 passed")

# Generated at 2022-06-25 23:43:15.080410
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-25 23:43:21.114779
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.append(2)
    immutable_list_2 = immutable_list_1.append(3)
    immutable_list_3 = immutable_list_2.append(4)
    immutable_list_4 = immutable_list_3.append(5)
    immutable_list_5 = immutable_list_4.filter(lambda x: x % 2 == 0)
    assert [2, 4] == immutable_list_5.to_list()


# Generated at 2022-06-25 23:43:31.810913
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # AssertionError: ImmutableList(5, ImmutableList(10, ImmutableList(15, ImmutableList(20, ImmutableList(25, ImmutableList(30, ImmutableList())))))) != ImmutableList(10, ImmutableList(20, ImmutableList(30, ImmutableList())))
    out_0 = ImmutableList.of(5, 10, 15, 20, 25, 30)
    out_1 = out_0.filter(lambda v : v % 2 == 0)
    assert out_1 == ImmutableList.of(10, 20, 30)
    out_2 = out_0.filter(lambda v : v % 3 == 0)
    assert out_2 == ImmutableList.of(15, 30)


# Generated at 2022-06-25 23:43:41.594603
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = immutable_list_0.filter(lambda element: True if (element == 0) else False)
    assert immutable_list_1.is_empty
    immutable_list_2 = immutable_list_1.append(0)
    immutable_list_3 = immutable_list_2.append(1)
    immutable_list_4 = immutable_list_3.append(2)
    immutable_list_5 = immutable_list_4.filter(lambda element: True if (element == 0) else False)
    assert immutable_list_5.to_list() == [0]
    immutable_list_6 = immutable_list_4.filter(lambda element: True if (element == 1) else False)

# Generated at 2022-06-25 23:43:44.446359
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(4, ImmutableList(6))))
    result = immutable_list.filter(lambda x : x % 2 == 0)

    assert result.head == 2
    assert result.tail.head == 4
    assert result.tail.tail.head == 6

    assert result.tail.tail.tail.tail is None


# Generated at 2022-06-25 23:43:54.757855
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of('xy', 'Mar', 'sto', 'czwartek')
    assert immutable_list_0.find(lambda x: len(x) > 4) == 'czwartek'
    
    immutable_list_1 = ImmutableList.of("xy", "bir", "ab", "ki", "md", "kk", "iy", "ji")
    assert immutable_list_1.find(lambda x: len(x) > 4) == 'bir'
    
    immutable_list_2 = ImmutableList.of("xy", "ab", "ki", "md", "kk", "iy", "ji")
    assert immutable_list_2.find(lambda x: len(x) > 3) == 'ki'
    

# Generated at 2022-06-25 23:44:03.678397
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_LIST_0 = ImmutableList.of(3, 5, 7, 9, 11)
    test_FUNCTION_0 = lambda x: x % 2 == 1
    test_LIST_1 = test_LIST_0.filter(test_FUNCTION_0)

    test_assert(test_LIST_1.to_list(), [3, 5, 7, 9, 11])

    test_LIST_1 = ImmutableList.of(2, 4, 6, 8, 10)
    test_LIST_2 = test_LIST_1.filter(test_FUNCTION_0)

    test_assert(test_LIST_2.to_list(), [])


# Generated at 2022-06-25 23:44:09.931367
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    mutable_list_0 = [None]
    for i in range(0, 10):
        immutable_list_0 = immutable_list_0.append(i)
        mutable_list_0.append(i)
    immutable_list_1 = immutable_list_0.filter((lambda x : (x > 5)))
    mutable_list_1 = filter((lambda x : (x > 5)), mutable_list_0)
    assert((immutable_list_1.to_list() == mutable_list_1))


# Generated at 2022-06-25 23:44:20.446356
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)
    assert immutable_list_0.filter(lambda x: True) == immutable_list_0
    assert immutable_list_0.filter(lambda x: False) == ImmutableList.empty()
    assert immutable_list_0.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = ImmutableList.of(2, 3)
    assert immutable_list_1.filter(lambda x: x % 2 == 1) == immutable_list_2
    immutable_list_3 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    immutable_list_4 = Immutable

# Generated at 2022-06-25 23:44:40.619835
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_double = ImmutableList(1.0, ImmutableList(2.0, ImmutableList(3.0, ImmutableList(4.0))))
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert immutable_list_double.find(lambda x: x == 4) == 4
    assert immutable_list_double.find(lambda x: x == 1.0) == 1.0
    assert immutable_list_double.find(lambda x: x == 2.0) == 2.0
    assert immutable_list_double.find(lambda x: x == 0.0) == None
    assert immutable_list.find(lambda x: x == 3) == 3
    assert immutable_list.find(lambda x: x == 1) == 1

# Generated at 2022-06-25 23:44:47.079958
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610)
    immutable_list_1 = immutable_list_0.filter(lambda x : x % 2 == 1)
    assert immutable_list_1.to_list() == [1, 1, 3, 5, 13, 21, 55, 89, 233, 377]


# Generated at 2022-06-25 23:44:56.005782
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(is_empty=True)
    immutable_list_1 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    immutable_list_2 = ImmutableList(immutable_list_1, immutable_list_0)
    immutable_list_3 = ImmutableList(2, ImmutableList(3))
    immutable_list_4 = ImmutableList(immutable_list_2, immutable_list_3)
    immutable_list_5 = ImmutableList(immutable_list_1, immutable_list_3)
    immutable_list_6 = ImmutableList(immutable_list_3, immutable_list_2)
    immutable_list_7 = ImmutableList()

# Generated at 2022-06-25 23:45:05.038495
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create an object of ImmutableList with elements from 0 to 9
    immutable_list_0 = ImmutableList()
    for i in range(0, 10):
        immutable_list_0 = immutable_list_0.append(i)
    # Filter all element which are even
    immutable_list_1 = immutable_list_0.filter(lambda val: val % 2 == 0)
    # Filter all element which are odd
    immutable_list_2 = immutable_list_0.filter(lambda val: val % 2 == 1)
    assert(immutable_list_1.to_list() == [0, 2, 4, 6, 8])
    assert(immutable_list_2.to_list() == [1, 3, 5, 7, 9])
    # Filter all element greater than 5
    immutable_list_3 = immutable_list_

# Generated at 2022-06-25 23:45:14.595613
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    fn_0 = lambda x: x > 3
    fn_1 = lambda x: x < 3
    immutable_list_0 = ImmutableList(0)
    assert immutable_list_0.find(fn_0) == None
    assert immutable_list_0.find(fn_1) == 0
    immutable_list_1 = ImmutableList(10, immutable_list_0)
    immutable_list_2 = ImmutableList(5, immutable_list_1)
    immutable_list_3 = ImmutableList(7, immutable_list_2)
    assert immutable_list_3.find(fn_0) == 7
    assert immutable_list_3.find(fn_1) == 5


# Generated at 2022-06-25 23:45:20.378949
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = ImmutableList.of('1', '2', '3')
    immutable_list_2 = ImmutableList.of('1')
    result_0 = immutable_list_0.filter(lambda x: x % 2 == 0)
    result_1 = immutable_list_1.filter(lambda x: x % 2 == 0)
    result_2 = immutable_list_2.filter(lambda x: x % 2 == 0)
    assert result_0.head is None
    assert result_0.tail is None
    assert result_0.is_empty == True
    assert result_1.head == '2'
    assert result_1.tail.head == None
    assert result_1.tail.tail.head == None

# Generated at 2022-06-25 23:45:27.880405
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(285, 201, 612, 967, 100, 776, 964, 229, 233, 734, 561, 833, 775, 851, 647, 590, 814, 842, 820, 400, 103, 822, 834)
    immutable_list_0 = immutable_list_0.filter(lambda x : (x ** 2) <= 996)
    immutable_list_1 = ImmutableList.of(201, 229, 233, 103)
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:45:38.623570
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Test 0
    immutable_list_0 = ImmutableList.of(-5, 0, 2, 1, 1, -7, 6, -1, -7, 4)

    fn = lambda x: x > 3
    immutable_list_1 = immutable_list_0.filter(fn)

    expected = True
    actual = (immutable_list_1 == ImmutableList.of(4))
    assert actual == expected
    print('Test 0 - OK!')

    # Test 1
    immutable_list_0 = ImmutableList.of(6, 7)

    immutable_list_1 = immutable_list_0.filter(fn)

    expected = True
    actual = (immutable_list_1 == ImmutableList.of(6, 7))
    assert actual == expected
    print('Test 1 - OK!')

    # Test 2

# Generated at 2022-06-25 23:45:45.159404
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Code for creating expected ImmutableList
    # We expect that ImmutableList.head and ImmutableList.tail will be empty
    # And ImmutableList.is_empty will be True
    immutable_list_expected = ImmutableList(is_empty=True)

    # Code for creating actual ImmutableList
    # We expect that ImmutableList.head will be empty
    immutable_list_actual = ImmutableList(ImmutableList.of(1, 2, 3)).filter(lambda x: x <= 1)

    assert immutable_list_actual == immutable_list_expected



# Generated at 2022-06-25 23:45:54.132960
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Case 1: 
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list_1.find(lambda x: x == 2) == 2
    # Case 2: 
    immutable_list_2 = ImmutableList.empty()
    assert immutable_list_2.find(lambda x: x == 2) is None 
    # Case 3: 
    immutable_list_3 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list_3.find(lambda x: x == 100) is None 


# Generated at 2022-06-25 23:46:20.119615
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2, 3, 2, 3, 2)
    assert immutable_list_0.filter(lambda x: x == 2) == ImmutableList.of(2, 2, 2)


# Generated at 2022-06-25 23:46:26.177669
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test1 = ImmutableList.of(1)
    test2 = ImmutableList.of(2)
    test3 = ImmutableList.of(3)
    test4 = ImmutableList.of(4)
    test5 = ImmutableList.of(5)

    all = test1 + test2 + test3 + test4 + test5

    res = all.filter(lambda x: x % 2 == 0)

    assert res.to_list() == [2, 4]


# Generated at 2022-06-25 23:46:36.885359
# Unit test for method find of class ImmutableList

# Generated at 2022-06-25 23:46:39.184726
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    print(immutable_list_0 == immutable_list_1)


# Generated at 2022-06-25 23:46:49.195699
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    import random
    random.seed(1)
    def random_list(list_len=20, num_range=50, negative=True):
        import random
        random.seed(1)
        return [random.randint(num_range * (-1 if negative else 0), num_range) for _ in range(list_len)]

    immutable_list_0 = ImmutableList.of(*random_list())
    print(immutable_list_0)
    print(immutable_list_0.to_list())
    # immutable_list_0.find(lambda x : x == 23)
    # immutable_list_1 = ImmutableList.of(0, 1, 2, 3, 4)
    # print(immutable_list_0.filter(lambda i : True if i % 2 == 0 else False ))
    # immutable_list

# Generated at 2022-06-25 23:46:53.635726
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    # create instance of ImmutableList
    immutable_list_0 = ImmutableList()
    
    # create instance of ImmutableList
    immutable_list_1 = ImmutableList()
    
    # check if both instances are equal by checking if
    #  __eq__ is called on both instances
    assert immutable_list_0.__eq__(immutable_list_1) == immutable_list_0.__eq__(immutable_list_1)


# Generated at 2022-06-25 23:47:03.191572
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_values = [
        {
            'name': 'empty immutable list',
            'head': None,
            'tail': None,
            'fn': lambda x: x > 10,
            'expected': ImmutableList.empty()
        },
        {
            'name': 'immutable list of one element',
            'head': 5,
            'tail': None,
            'fn': lambda x: x > 10,
            'expected': ImmutableList.empty()
        },
        {
            'name': 'immutable list of three elements',
            'head': 5,
            'tail': ImmutableList(12, ImmutableList(18)),
            'fn': lambda x: x > 10,
            'expected': ImmutableList(12, ImmutableList(18))
        }
    ]


# Generated at 2022-06-25 23:47:17.859119
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = immutable_list_0.filter(lambda x : (x != None))
    assert immutable_list_1 == ImmutableList()
    immutable_list_0 = ImmutableList.of(1, 1, 1)
    immutable_list_1 = immutable_list_0.filter(lambda x : (x != None))
    assert immutable_list_1 == ImmutableList.of(1, 1, 1)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_1 = immutable_list_0.filter(lambda x : (x != None))
    assert immutable_list_1 == ImmutableList()
    immutable_list_0 = ImmutableList()

# Generated at 2022-06-25 23:47:24.770126
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 2, 3, 2, 4)

    # Testing method filter on ImmutableList
    immutable_list_1 = immutable_list_0.filter(lambda x: x == 2)
    assert len(immutable_list_1) == 3
    assert immutable_list_1.head == 2
    assert immutable_list_1.tail.head == 2
    assert immutable_list_1.tail.tail.head == 2


# Generated at 2022-06-25 23:47:35.093612
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList.empty())))
    immutable_list_1 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList.empty())))
    immutable_list_2 = ImmutableList(None, ImmutableList(1, ImmutableList(2, ImmutableList.empty())))
    immutable_list_3 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList.empty())))
    immutable_list_4 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList.empty())))
    immutable_list_5 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList.empty())))
   

# Generated at 2022-06-25 23:48:03.755266
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4)

    immutable_list_0_filter_arg_0 = lambda arg_0: arg_0 % 2 == 0
    immutable_list_0_filter_ret_0 = immutable_list_0.filter(immutable_list_0_filter_arg_0)
    immutable_list_0_filter_ret_1 = ImmutableList.of(2, 4)
    immutable_list_0_filter_ret_2 = immutable_list_0_filter_ret_0 == immutable_list_0_filter_ret_1
    # Test case 1
    immutable_list_1 = ImmutableList()

    immutable_list_1_filter_arg_0 = lambda arg_0: arg_0 % 2 == 0
    immutable_list_

# Generated at 2022-06-25 23:48:12.589483
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = ImmutableList(0, immutable_list_0)
    immutable_list_2 = ImmutableList(0, immutable_list_1)
    immutable_list_3 = ImmutableList(0, immutable_list_2)
    immutable_list_4 = ImmutableList(0, immutable_list_3)
    immutable_list_5 = ImmutableList(0, immutable_list_4)
    immutable_list_6 = ImmutableList(0, immutable_list_5)
    immutable_list_7 = ImmutableList(0, immutable_list_6)
    immutable_list_8 = ImmutableList(0, immutable_list_7)
    immutable_list_9 = ImmutableList(0, immutable_list_8)
    immutable_list_

# Generated at 2022-06-25 23:48:22.117516
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(None)
    fn_0 = lambda arg0: bool()
    bool_0 = immutable_list_0.filter(fn_0).is_empty
    assert bool_0

    immutable_list_1 = ImmutableList.of(True, False)
    assert immutable_list_1.filter(fn_0).is_empty

    immutable_list_2 = ImmutableList.of(False, True)
    assert not immutable_list_2.filter(fn_0).is_empty

    immutable_list_3 = ImmutableList.of(None, None)
    assert immutable_list_3.filter(fn_0).is_empty

    immutable_list_4 = ImmutableList.of(None, None, None)

# Generated at 2022-06-25 23:48:28.916011
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of("f", "e", "d", "c", "b", "a")
    immutable_list_1 = immutable_list_0.filter(lambda t: t == "f")
    assert immutable_list_1 == ImmutableList.of("f")
    immutable_list_1 = immutable_list_0.filter(lambda t: t == "a")
    assert immutable_list_1 == ImmutableList.of("a")
    immutable_list_1 = immutable_list_0.filter(lambda t: t == "w")
    assert immutable_list_1 == ImmutableList.empty()


# Generated at 2022-06-25 23:48:38.090160
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print("\nTest: ImmutableList Find")

    list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(1))))
    list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(1)))))
    list_3 = ImmutableList()

    print(list_0.find(lambda x: x % 2 == 0))
    print(list_1.find(lambda x: x % 2 == 0))
    print(list_2.find(lambda x: x % 2 == 0))
    print(list_3.find(lambda x: x % 2 == 0))

test_

# Generated at 2022-06-25 23:48:46.614664
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(2)
    immutable_list_0 = immutable_list_0.append(3)
    immutable_list_0 = immutable_list_0.append(4)
    immutable_list_0 = immutable_list_0.append(5)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 1)
    assert immutable_list_1.reduce(lambda x, y: x + y, 0) == 9
    assert immutable_list_1.to_list() == [1, 3, 5]


# Generated at 2022-06-25 23:48:51.813479
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_0 = immutable_list_0.filter(lambda x: x > 2)
    assert immutable_list_0.head == 3
    assert immutable_list_0.tail.head == 4
    assert immutable_list_0.tail.tail.head == 5
    assert immutable_list_0.tail.tail.tail == None


# Generated at 2022-06-25 23:48:55.507069
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList()
    new_list = test_list.filter(lambda x: x > 1)
    for x in new_list:
        assert x > 1


# Generated at 2022-06-25 23:49:02.780179
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case 0: ImmutableList is empty
    immutable_list_0 = ImmutableList()
    print("List before filter: {}".format(immutable_list_0))
    immutable_list_0_filter = immutable_list_0.filter(lambda x: x%2 == 0)
    print("List after filter: {}".format(immutable_list_0_filter))

    # Case 1: ImmutableList only has one element
    immutable_list_1 = ImmutableList(1)
    print("List before filter: {}".format(immutable_list_1))
    immutable_list_1_filter = immutable_list_1.filter(lambda x: x%2 == 0)
    print("List after filter: {}".format(immutable_list_1_filter))

    # Case 2: ImmutableList has multiple elements
    immutable_

# Generated at 2022-06-25 23:49:12.872276
# Unit test for method filter of class ImmutableList

# Generated at 2022-06-25 23:50:04.940932
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = ImmutableList.of(1, 2, 3)
    immutable_list_3 = ImmutableList.of(4)
    assert immutable_list_1.find(lambda x: x == 3) == 3
    assert immutable_list_1.filter(lambda x: x == 3) == immutable_list_2


# Generated at 2022-06-25 23:50:10.388621
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    test_inputs_0 = [
    ]

# Generated at 2022-06-25 23:50:15.543682
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    immutable_list_2 = immutable_list_1.filter(lambda e: e > 3)
    assert immutable_list_2 == ImmutableList.of(4, 5)


# Generated at 2022-06-25 23:50:25.588433
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_empty = ImmutableList.empty()
    list_one_element = ImmutableList(0)
    list_few_elements = ImmutableList.of(0, 1, 2)
    list_many_elements = ImmutableList.of(
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
        10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
        30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
        40, 41, 42, 43, 44, 45, 46, 47, 48, 49
    )

    assert list_empty.find(lambda x: x == 0) == None
    assert list_one_element