

# Generated at 2022-06-25 23:40:29.144814
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0.__eq__(immutable_list_1) == True
    immutable_list_2 = ImmutableList(1)
    immutable_list_3 = ImmutableList(1)
    assert immutable_list_2.__eq__(immutable_list_3) == True
    immutable_list_4 = ImmutableList(1, ImmutableList(2))
    immutable_list_5 = ImmutableList(1, ImmutableList(2))
    assert immutable_list_4.__eq__(immutable_list_5) == True



# Generated at 2022-06-25 23:40:39.110194
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(1, ImmutableList(2))
    immutable_list_3 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    immutable_list_4 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    immutable_list_5 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    assert immutable_list_0.find(lambda x: True) is None
    assert immutable_list_1.find(lambda x: x == 1) == 1

# Generated at 2022-06-25 23:40:48.224965
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(None)

    immutable_list_0 = immutable_list_0.append(1)
    immutable_list_0 = immutable_list_0.append(0)
    immutable_list_0 = immutable_list_0.append(3)
    immutable_list_0 = immutable_list_0.append(2)

    immutable_list_0 = immutable_list_0.filter(lambda x: x % 2 == 0)

    immutable_list_1 = immutable_list_1.append(0)
    immutable_list_1 = immutable_list_1.append(2)

    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:40:58.836381
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()

    # Test case 1
    immutable_list_1.head = None
    immutable_list_1.tail = None
    immutable_list_1.is_empty = True
    assert immutable_list_0 == immutable_list_1

    # Test case 2
    immutable_list_2 = ImmutableList.of(1)
    immutable_list_3 = ImmutableList.of(1)
    immutable_list_4 = immutable_list_2 + immutable_list_3
    immutable_list_5 = ImmutableList.of(1,1)
    assert immutable_list_4 == immutable_list_5

    # Test case 3
    immutable_list_6 = ImmutableList.of(1)

# Generated at 2022-06-25 23:41:06.380047
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    def fn(value: Optional[int]):
        return value == 1
    # When
    immutable_list_0: ImmutableList[int] = ImmutableList.of(2)
    immutable_list_1 = immutable_list_0.append(1)
    # Then
    assert(immutable_list_1.find(fn) is 1)
    assert(immutable_list_0.find(fn) is None)


# Generated at 2022-06-25 23:41:09.921454
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    result = immutable_list_0.find(lambda e : e == 3)
    assert result == 3

    immutable_list_1 = ImmutableList.of('Hello', 'World')
    result = immutable_list_1.find(lambda e : e == 'Hi')
    assert result is None

    immutable_list_2 = ImmutableList.empty()
    result = immutable_list_2.find(lambda e: e != None)
    assert result is None


# Generated at 2022-06-25 23:41:18.349526
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create new ImmutableList
    list0 = ImmutableList.of("A", "B", "C", "D")

    # Make new immutable list from filter
    list1 = list0.filter(lambda element: element == "A")
    list2 = list0.filter(lambda element: element == "D")
    list3 = list0.filter(lambda element: element == "Z")

    # Test is new list same as expected
    if list0 != ImmutableList.of("A", "B", "C", "D") or list1 != ImmutableList.of("A") or list2 != ImmutableList.of("D") or list3 != ImmutableList.empty():
        print("Test test_ImmutableList_filter failed")


# Generated at 2022-06-25 23:41:27.686621
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = immutable_list_0.append(9)
    immutable_list_1 = immutable_list_0.append(12)
    immutable_list_1 = immutable_list_1.append(12)
    immutable_list_1 = immutable_list_1.append(2)
    immutable_list_2 = immutable_list_1.append(-1)

    assert immutable_list_0.find(lambda x: x > 9) is None
    assert immutable_list_2.find(lambda x: x == 2) == 2
    assert immutable_list_1.find(lambda x: x > 9) == 12
    assert immutable_list_2.find(lambda x: x > 2) == 12

# Generated at 2022-06-25 23:41:35.581915
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    immutable_list_0 = ImmutableList(None)
    def fn_0(x):
        return x == None
    immutable_list_0 = immutable_list_0.filter(fn_0)
    assert immutable_list_0.head == None
    assert immutable_list_0.tail == None
    assert immutable_list_0.is_empty == False
    # Test case 1
    immutable_list_1 = ImmutableList(1)
    def fn_1(x):
        return x < 1
    immutable_list_1 = immutable_list_1.filter(fn_1)
    assert immutable_list_1.head == None
    assert immutable_list_1.tail == None
    assert immutable_list_1.is_empty == True
    # Test case 2

# Generated at 2022-06-25 23:41:44.863178
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = ImmutableList(None, immutable_list_0)
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList(1)
    immutable_list_4 = ImmutableList(False, immutable_list_3)
    immutable_list_5 = ImmutableList(None, immutable_list_4)
    immutable_list_6 = ImmutableList(1, immutable_list_3)
    immutable_list_7 = ImmutableList(0, immutable_list_6)
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = immutable_list_0.filter((lambda x : x is None))
    immutable_list_1 = ImmutableList.empty()
    immutable_list_1 = immutable

# Generated at 2022-06-25 23:41:57.685023
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_0 = immutable_list_0.unshift(3)
    immutable_list_0 = immutable_list_0.unshift(4)
    immutable_list_1 = immutable_list_1.unshift(2)
    immutable_list_1 = immutable_list_1.unshift(2)
    immutable_list_0 = immutable_list_0.append(immutable_list_1)
    immutable_list_0 = immutable_list_0.unshift(6)
    immutable_list_0 = immutable_list_0.unshift(3)
    immutable_list_0 = immutable_list_0.unshift(2)
    immutable_list_0 = immutable_list_0.unshift(6)


# Generated at 2022-06-25 23:42:08.474268
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_0 = immutable_list_0.append(True)
    immutable_list_0 = immutable_list_0.append(False)
    immutable_list_0 = immutable_list_0.append(True)
    immutable_list_0 = immutable_list_0.append(False)
    immutable_list_0 = immutable_list_0.append(False)
    boolean_0 = True
    boolean_1 = immutable_list_0.find((lambda boolean_0: boolean_0))
    assert boolean_0 == boolean_1
    boolean_0 = False
    boolean_1 = immutable_list_0.find((lambda boolean_0: not boolean_0))
    assert boolean_0 == boolean_1
    boolean_0 = True
    immutable_list_1 = Immutable

# Generated at 2022-06-25 23:42:18.792411
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList(0)
    immutable_list_1 = ImmutableList(0, immutable_list_0)
    immutable_list_2 = ImmutableList(0, immutable_list_1)
    immutable_list_3 = ImmutableList(0, immutable_list_2)
    immutable_list_4 = ImmutableList(0, immutable_list_3)
    immutable_list_5 = ImmutableList(0, immutable_list_4)
    immutable_list_6 = ImmutableList(0, immutable_list_5)
    immutable_list_7 = ImmutableList(0, immutable_list_6)
    number = immutable_list_7.find(lambda x : True)

# Generated at 2022-06-25 23:42:30.158266
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    assert (immutable_list_0.find(lambda x: True) == None)
    
    immutable_list_1 = ImmutableList.of(66)
    assert (immutable_list_1.find(lambda x: False) == None)
    assert (immutable_list_1.find(lambda x: True) == 66)
    
    immutable_list_2 = ImmutableList.of(97, 40, 42)
    assert (immutable_list_2.find(lambda x: False) == None)
    assert (immutable_list_2.find(lambda x: True) == 97)
    
    immutable_list_3 = ImmutableList.of(63, 33, 14, 30)

# Generated at 2022-06-25 23:42:34.301049
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    immutable_list_0 = ImmutableList()

    # Act
    actual_0 = immutable_list_0.find(lambda _ : True)
    actual_1 = immutable_list_0.find(lambda _ : False)
    # Assert
    assert actual_0 == None
    assert actual_1 == None



# Generated at 2022-06-25 23:42:39.783348
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1, 2, 3)
    immutable_list_1 = immutable_list_0.filter((lambda a0 : a0 < 3))
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail.head == 2
    assert immutable_list_1.tail.tail == None
    assert immutable_list_1.head == immutable_list_0.head
    assert immutable_list_1.tail != immutable_list_0.tail
    assert len(immutable_list_1) == 2


# Generated at 2022-06-25 23:42:43.411070
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutableList = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert immutableList.find(lambda x: x == 4) == 4
    assert immutableList.find(lambda x: x % 2 == 0) == 2



# Generated at 2022-06-25 23:42:46.101335
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Case 0
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:42:56.357936
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = immutable_list_0.filter((lambda element: element is None))
    assert immutable_list_1 == ImmutableList(is_empty=True)

    immutable_list_2 = ImmutableList(2)
    immutable_list_3 = immutable_list_2.filter((lambda element: element is None))
    assert immutable_list_3 == ImmutableList(is_empty=True)

    immutable_list_4 = ImmutableList(3)
    immutable_list_5 = immutable_list_4.filter((lambda element: element == 3))
    assert immutable_list_5 == ImmutableList(3)
    immutable_list_6 = immutable_list_4.filter((lambda element: element == 4))

# Generated at 2022-06-25 23:43:03.354698
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case #0
    immutable_list_0 = ImmutableList()
    function_1 = lambda value_1: value_1 > 5
    immutable_list_1 = immutable_list_0.filter(function_1)
    assert immutable_list_1.is_empty is True
    # Case #1
    immutable_list_2 = ImmutableList.of(3)
    function_2 = lambda value_1: value_1 < 5
    immutable_list_3 = immutable_list_2.filter(function_2)
    assert immutable_list_3.head == 3
    assert immutable_list_3.tail.is_empty is True
    assert immutable_list_3.is_empty is False
    # Case #2
    immutable_list_4 = ImmutableList.of(3)

# Generated at 2022-06-25 23:43:18.953227
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x > 3) == ImmutableList(is_empty=True)
    assert ImmutableList(4).filter(lambda x: x < 3) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList())).filter(lambda x: x < 3) == ImmutableList(1, ImmutableList(2, ImmutableList()))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList()))).filter(lambda x: x < 3) == ImmutableList(1, ImmutableList(2, ImmutableList()))

# Generated at 2022-06-25 23:43:21.879496
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2)
    immutable_list_1 = immutable_list_0.filter(lambda x : x > 0)
    assert immutable_list_1 == ImmutableList.of(2), "ImmutableList filter method test failed"



# Generated at 2022-06-25 23:43:29.577892
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # create new instance of ImmutableList
    immutable_list_0 = ImmutableList.of(True, False, True)

    # call method filter of immutable_list_0
    immutable_list_1 = immutable_list_0.filter(lambda x: not x)

    # call method filter of immutable_list_1
    immutable_list_2 = immutable_list_1.filter(lambda x: x)

    assert immutable_list_2 == ImmutableList.empty()


# Generated at 2022-06-25 23:43:39.699089
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList()

    immutable_list = immutable_list.append(1)
    immutable_list = immutable_list.append(2)
    immutable_list = immutable_list.append(3)
    immutable_list = immutable_list.append(4)
    immutable_list = immutable_list.append(5)
    immutable_list = immutable_list.append(6)
    immutable_list = immutable_list.append(7)
    immutable_list = immutable_list.append(8)

    immutable_list_1 = immutable_list.filter(lambda x: x % 2 == 0)

    assert immutable_list_1.head == 2
    assert immutable_list_1.tail.head == 4
    assert immutable_list_1.tail.tail.head == 6

# Generated at 2022-06-25 23:43:46.285399
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    Unit test for method find of class ImmutableList
    """
    # Test cases for method find
    immutable_list_0 = ImmutableList()
    immutable_list_0.append(immutable_list_0)
    immutable_list_0.append(immutable_list_0)
    immutable_list_0.append(immutable_list_0)
    immutable_list_0.append(immutable_list_0)
    immutable_list_0.append(immutable_list_0)
    immutable_list_0.append(immutable_list_0)

    assert immutable_list_0.find(lambda x: x == immutable_list_0) == immutable_list_0


# Generated at 2022-06-25 23:43:49.651765
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 3).to_list() == [4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 5).to_list() == []


# Generated at 2022-06-25 23:43:53.646282
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert immutable_list.find(lambda x: x > 2) == 3


# Generated at 2022-06-25 23:43:56.127207
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None)
    assert immutable_list_0 == immutable_list_0


# Generated at 2022-06-25 23:44:02.217631
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_0.head = 'fnjUuNbUiPoBfCwN'
    immutable_list_0.tail = immutable_list_1
    immutable_list_1.head = immutable_list_0
    assert immutable_list_0.__eq__(immutable_list_0)



# Generated at 2022-06-25 23:44:10.167670
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(0)
    immutable_list_1 = immutable_list.filter(lambda x: x == 0)
    if immutable_list_1 != ImmutableList.of(0):
        print("[FAIL]")
        return
    immutable_list_2 = immutable_list.filter(lambda x: x == 1)
    if immutable_list_2 != ImmutableList.empty():
        print("[FAIL]")
        return
    immutable_list_3 = ImmutableList.of(0, 2, 3, 2, 3).filter(lambda x: x == 2)
    if immutable_list_3 != ImmutableList.of(2, 2):
        print("[FAIL]")
        return
    print("[OK]")


# Generated at 2022-06-25 23:44:18.429410
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    
    assert immutable_list_0 == immutable_list_1


# Generated at 2022-06-25 23:44:28.648714
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    immutable_list_2 = ImmutableList()
    immutable_list_3 = ImmutableList()
    immutable_list_4 = ImmutableList()
    immutable_list_5 = ImmutableList()
    immutable_list_6 = ImmutableList()
    immutable_list_7 = ImmutableList()
    immutable_list_8 = ImmutableList()
    immutable_list_9 = ImmutableList()
    immutable_list_10 = ImmutableList()
    immutable_list_11 = ImmutableList()
    immutable_list_12 = ImmutableList()
    immutable_list_13 = ImmutableList()
    immutable_list_14 = ImmutableList()
    immutable_list_15 = ImmutableList()

# Generated at 2022-06-25 23:44:36.099248
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList()
    assert isinstance(immutable_list_0, ImmutableList) and immutable_list_0.__eq__(immutable_list_1), 'Test failed'
    immutable_list_2 = ImmutableList(0)
    immutable_list_3 = ImmutableList(0)
    assert isinstance(immutable_list_2, ImmutableList) and immutable_list_2.__eq__(immutable_list_3), 'Test failed'
    immutable_list_4 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    immutable_list_5 = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))

# Generated at 2022-06-25 23:44:45.037994
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.of(
        -1,
        1,
        -1,
        -1,
        1,
        1,
        -1
    )
    # Test case #0
    res = immutable_list_0.find(
        lambda v: v == 1
    )
    assert res == 1

    # Test case #1
    immutable_list_1 = ImmutableList.of(
        1,
        2,
        3,
        4,
        5
    )
    res = immutable_list_1.find(
        lambda v: v == 10
    )
    assert res is None


# Generated at 2022-06-25 23:44:50.120545
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6)
    bool_0 = immutable_list_0.filter(lambda x: x % 2)
    bool_1 = ImmutableList.of(1, 3, 5)
    assert bool_0 != bool_1


# Generated at 2022-06-25 23:44:55.997294
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(5)
    immutable_list_2 = ImmutableList(5, ImmutableList(3))
    immutable_list_3 = ImmutableList(None)
    try:
        immutable_list_0.filter(None) # TypeError: filter() missing 1 required positional argument: 'fn'
    except TypeError as e:
        assert type(e) == TypeError

    assert immutable_list_0.filter(lambda element: element < 4) == ImmutableList()
    assert immutable_list_0.filter(lambda element: element > 4) == ImmutableList()
    assert immutable_list_1.filter(lambda element: element < 4) == ImmutableList()
    assert immutable_list_1.filter(lambda element: element > 4) == ImmutableList

# Generated at 2022-06-25 23:45:05.038381
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ImmutableList.find(None, None)

    ImmutableList.find(ImmutableList.empty(), lambda x: True) == None

    ImmutableList.find(ImmutableList.of(1, 2, 3, 4, 5), lambda x: x == 1) == 1
    ImmutableList.find(ImmutableList.of(1, 2, 3, 4, 5), lambda x: x == 3) == 3
    ImmutableList.find(ImmutableList.of(1, 2, 3, 4, 5), lambda x: x == 5) == 5
    ImmutableList.find(ImmutableList.of(1, 2, 3, 4, 5), lambda x: x == 6) == None
    ImmutableList.find(ImmutableList.of(1, 2, 3, 4, 5), lambda x: x == "1") == None


# Generated at 2022-06-25 23:45:15.617480
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case 0:
    # Input:
    # ImmutableList(is_empty=True)
    # fn: lambda x: True
    # Expected:
    # ImmutableList(is_empty=True)
    immutable_list_0 = ImmutableList(is_empty=True)
    fn_0 = lambda x: True
    expected_0 = ImmutableList(is_empty=True)
    actual_0 = immutable_list_0.filter(fn_0)
    try:
        assert actual_0 == expected_0
        print("Test Case 0: Passed!")
    except AssertionError:
        print("Test Case 0: Failed!")
        print("Expected:")
        print(expected_0)
        print("Actual:")
        print(actual_0)
        print("")
        raise Assert

# Generated at 2022-06-25 23:45:22.250163
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_filter_0 = ImmutableList.of(1, 2, 3, 4).filter((lambda x: (x % 2) != 0))
    assert immutable_list_filter_0 == ImmutableList.of(1, 3)
    immutable_list_filter_1 = ImmutableList.of(1, 2, 3, 4, 5, 6).filter((lambda x: (x % 2) == 0))
    assert immutable_list_filter_1 == ImmutableList.of(2, 4, 6)
    immutable_list_filter_2 = ImmutableList.of(3, 9, 12, 4, 15, 6).filter((lambda x: (x % 3) == 0))
    assert immutable_list_filter_2 == ImmutableList.of(3, 12, 4, 6)


# Generated at 2022-06-25 23:45:24.505083
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print('Unit test for method filter of class ImmutableList')

    immutable_list_0 = ImmutableList()


# Generated at 2022-06-25 23:45:43.642504
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 0
    immutable_list_0 = ImmutableList()
    result = immutable_list_0.find(lambda x: x >= -8 and x <= 5)
    assert result == None, "Expected: None, but got: " + str(result)
    # Test case 1
    immutable_list_1 = ImmutableList(4)
    result = immutable_list_1.find(lambda x: x >= -8 and x <= 5)
    assert result == 4, "Expected: 4, but got: " + str(result)
    # Test case 2
    immutable_list_2 = ImmutableList(5, ImmutableList(-5, ImmutableList(-5)))
    result = immutable_list_2.find(lambda x: x >= -8 and x <= 5)

# Generated at 2022-06-25 23:45:55.269185
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList(ImmutableList())
    immutable_list_1 = ImmutableList(is_empty=True)
    immutable_list_2 = ImmutableList(is_empty=True)
    immutable_list_3 = ImmutableList(is_empty=True)
    immutable_list_4 = ImmutableList(is_empty=True)
    immutable_list_5 = ImmutableList(is_empty=True)
    immutable_list_6 = ImmutableList(is_empty=True)
    immutable_list_7 = ImmutableList(is_empty=True)
    immutable_list_8 = ImmutableList(is_empty=True)
    immutable_list_9 = ImmutableList(is_empty=True)
    immutable_list_10 = ImmutableList(is_empty=True)
    
   

# Generated at 2022-06-25 23:46:04.611266
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable_list_0 = ImmutableList(None)
    immutable_list_1 = ImmutableList()
    assert immutable_list_0 == immutable_list_1
    immutable_list_2 = ImmutableList(is_empty=True)
    immutable_list_3 = ImmutableList(is_empty=True)
    assert immutable_list_2 == immutable_list_3
    immutable_list_4 = ImmutableList(is_empty=True)
    assert immutable_list_2 == immutable_list_4
    immutable_list_5 = ImmutableList(is_empty=True)
    assert immutable_list_4 == immutable_list_5
    immutable_list_6 = ImmutableList(is_empty=True)
    assert immutable_list_5 == immutable_list_6

# Generated at 2022-06-25 23:46:07.556063
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ImmutableList.of(1,2,3,4,5,6).filter(lambda x: x % 2 == 0).to_list() == [2,4,6]
    ImmutableList.of(1,2,3,4,5,6).filter(lambda x: x % 2 == 1).to_list() == [1,3,5]


# Generated at 2022-06-25 23:46:16.693153
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # initialization of elements that will be used to test ImmutableList.filter
    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_3 = ImmutableList(is_empty=True)
    # list of pair that contains input [[ImmutableList.filter(immutable_list_1), ImmutableList.filter(immutable_list_2), ImmutableList.filter(immutable_list_3)] and output [ImmutableList(1, ImmutableList(3)), ImmutableList(1, ImmutableList(3)), ImmutableList(is_empty=True)]

# Generated at 2022-06-25 23:46:19.084039
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList()
    result = immutable_list_0.find(lambda x: x)
    assert result == None


# Generated at 2022-06-25 23:46:28.470734
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print("test case 1")
    """Tests of the method filter"""

    # Creation of the objects with which the methods will be tested
    immutable_list_0 = ImmutableList.of(1, 1, 2, 2, 3, 3)
    print("\t", immutable_list_0)
    immutable_list_1 = ImmutableList.of(2, 2, 3, 3)
    print("\t", immutable_list_1)
    immutable_list_2 = ImmutableList.of(1, 1)
    print("\t", immutable_list_2)
    immutable_list_3 = ImmutableList.of(1, 1, 2, 2, 3, 3)
    print("\t", immutable_list_3)

    # Tests of the method filter

# Generated at 2022-06-25 23:46:35.430230
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_1 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    immutable_list_2 = immutable_list_1.filter(lambda x: x % 2 == 0)
    immutable_list_3 = ImmutableList.of(0, 2, 4)
    if immutable_list_2 != immutable_list_3:
        dbg(immutable_list_2)
        dbg(immutable_list_3)
        return False
    return True

# Generated at 2022-06-25 23:46:46.106428
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_0 = ImmutableList.of(4, -1, 9, 5)
    assert test_0.find(lambda var0:var0 % 2 == 0) == 4

    test_1 = ImmutableList.of(7, 8, 8, -8, 6)
    assert test_1.find(lambda var1:var1 < 0) == -8

    test_2 = ImmutableList.of(1, 3, 4)
    assert test_2.find(lambda var2:var2 > 4) == None

    test_3 = ImmutableList.of(30, 3, -2)
    assert test_3.find(lambda var3:var3 > 0) == 30

    test_4 = ImmutableList.of(-27, -4, -4)

# Generated at 2022-06-25 23:46:50.790266
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    maybe_0 = ImmutableList()
    maybe_1 = ImmutableList()
    assert maybe_0 == maybe_1, f'test_ImmutableList___eq__: {maybe_0} == {maybe_1}'
    maybe_0 = ImmutableList.empty()
    maybe_1 = ImmutableList.empty()
    assert maybe_0 == maybe_1, f'test_ImmutableList___eq__: {maybe_0} == {maybe_1}'
    maybe_0 = ImmutableList.of(1)
    maybe_1 = ImmutableList.of(1.0)
    assert maybe_0 == maybe_1, f'test_ImmutableList___eq__: {maybe_0} == {maybe_1}'
    maybe_0 = ImmutableList.of(1, 2.0)

# Generated at 2022-06-25 23:47:33.920693
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Set up test variables
    test_list = ImmutableList()
    test_fn = lambda x: x>0
    expected = 0
    
    # Perform test
    result = test_list.find(test_fn)
    
    # Assert result
    assert(result == expected)


# Generated at 2022-06-25 23:47:39.160960
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    immutable_list_0 = immutable_list_0.append(True)
    immutable_list_1 = immutable_list_0.append(True)
    immutable_list_2 = immutable_list_1.append(True)
    immutable_list_1 = immutable_list_2.append(False)
    value = immutable_list_1.find((lambda item : item))
    print(value)


# Generated at 2022-06-25 23:47:47.900653
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Define immutable_list_0 for test
    immutable_list_0 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    # (1) immutable_list_0.filter(lambda x:x >= 2)
    assert immutable_list_0.filter(lambda x:x >= 2) == ImmutableList(2, ImmutableList(3))
    # (2) immutable_list_0.filter(lambda x:x >= 3)
    assert immutable_list_0.filter(lambda x:x >= 3) == ImmutableList(3)
    # (3) immutable_list_0.filter(lambda x:x == 1)
    assert immutable_list_0.filter(lambda x:x == 1) == ImmutableList(1)
    # (4) immutable_list_0.filter(lambda x:x

# Generated at 2022-06-25 23:47:58.702063
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList()
    immutable_list_1 = ImmutableList(1)
    immutable_list_2 = ImmutableList(1, immutable_list_1)
    immutable_list_3 = ImmutableList(1, immutable_list_2)
    immutable_list_4 = ImmutableList(1, immutable_list_3)
    immutable_list_5 = ImmutableList(1, immutable_list_4)
    immutable_list_6 = ImmutableList(1, immutable_list_5)
    immutable_list_7 = ImmutableList(1, immutable_list_6)
    immutable_list_8 = ImmutableList(1, immutable_list_7)
    immutable_list_9 = ImmutableList(1, immutable_list_8)

# Generated at 2022-06-25 23:48:10.152449
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case 0
    immutable_list_0 = ImmutableList()

    try:
        immutable_list_0_filtered = immutable_list_0.filter(lambda x: x == 1)
    except Exception:
        raise RuntimeError("Your program threw an exception: it's not allowed to call method filter on an empty list")

    if not isinstance(immutable_list_0_filtered, ImmutableList):
        raise RuntimeError("Your program didn't return an instance of the ImmutableList class")
    if not immutable_list_0_filtered.is_empty:
        raise RuntimeError("Your program didn't create an empty list")

    # Case 1
    immutable_list_1 = ImmutableList(2, immutable_list_0)


# Generated at 2022-06-25 23:48:14.655888
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(2, 3, 4, 5)
    immutable_list_1 = immutable_list_0.filter(lambda x: x % 2 == 0)
    assert immutable_list_1 == ImmutableList.of(2, 4)


# Generated at 2022-06-25 23:48:23.794249
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 0
    list0 = ImmutableList()
    def list0_filter(list0_el0):
        if list0_el0 == 1:
            return True

        return False

    assert ImmutableList() == list0.filter(list0_filter), "Incorrect test case 0 for filter."

    # Test case 1
    list1 = ImmutableList(1)
    def list1_filter(list1_el0):
        if list1_el0 == 2:
            return True

        return False

    assert ImmutableList() == list1.filter(list1_filter), "Incorrect test case 1 for filter."

    # Test case 2
    list2 = ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-25 23:48:32.560755
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test #1
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_2 = immutable_list_1.filter(lambda value: value % 2 == 0)
    immutable_list_3 = ImmutableList.of(2, 4)
    assert immutable_list_2 == immutable_list_3

    # Test #2
    immutable_list_4 = ImmutableList.of(1, 3, 5)
    immutable_list_5 = immutable_list_4.filter(lambda value: value % 2 == 0)
    immutable_list_6 = ImmutableList.empty()
    assert immutable_list_5 == immutable_list_6

    # Test #3
    immutable_list_7 = ImmutableList.of('lol')

# Generated at 2022-06-25 23:48:41.734868
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda a: True) == (ImmutableList.empty())
    assert ImmutableList.empty().filter(lambda a: False) == (ImmutableList.empty())
    assert ImmutableList.of(1).filter(lambda a: True) == (ImmutableList.of(1))
    assert ImmutableList.of(1).filter(lambda a: False) == (ImmutableList.empty())
    assert ImmutableList.of(1, 2, 3)\
        .filter(lambda a: a % 2 == 0)\
        == (ImmutableList.of(2))
    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda a: a % 2 == 0)\
        == (ImmutableList.of(2, 4))

# Generated at 2022-06-25 23:48:48.486741
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4, 5)

    if immutable_list_1.find(lambda x: x < 0):
        raise RuntimeError('UnitTests: failed')
    if immutable_list_1.find(lambda x: x == 3) != 3:
        raise RuntimeError('UnitTests: failed')
    if immutable_list_1.find(lambda x: x > 5):
        raise RuntimeError('UnitTests: failed')
    print('UnitTests: ok')


# Generated at 2022-06-25 23:49:43.082135
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    required_structure_0 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    required_structure_1 = ImmutableList.of(2, 4, 6)
    required_structure_1_0 = required_structure_0.filter(lambda x: x == 1)
    required_structure_1_1 = required_structure_1_0.append(1)
    required_structure_1_2 = required_structure_1_1.map(lambda x: x * 2)
    required_structure_1_3 = required_structure_1_2.filter(lambda x: x % 2 == 0)
    required_structure_1_4 = required_structure_1_2.filter(lambda x: x % 2 == 1)
    required_structure_1_5

# Generated at 2022-06-25 23:49:55.139037
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    assert immutable_list_0.filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5, 7, 9)
    immutable_list_1 = ImmutableList.of(None, 4, 6)
    assert immutable_list_1.filter(lambda x: x is None) == ImmutableList.of(None)
    immutable_list_2 = ImmutableList.of(4, 2, 0, 2, 5, 7, 9)
    assert immutable_list_2.filter(lambda x: x % 2 != 0) == ImmutableList.of(2, 5, 7, 9)

# Generated at 2022-06-25 23:50:05.716653
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_0 = ImmutableList.empty()
    assert immutable_list_0.find(lambda s: s.startswith('A')) is None
    immutable_list_1 = ImmutableList.of('Abcdef')
    assert immutable_list_1.find(lambda s: s.startswith('A')) == 'Abcdef'
    immutable_list_2 = ImmutableList.of('A', 'B')
    assert immutable_list_2.find(lambda s: s.startswith('A')) == 'A'


# Generated at 2022-06-25 23:50:10.575550
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list_0 = ImmutableList.of(1)
    fn_0 = (lambda x: x == 1)
    immutable_list_1 = immutable_list_0.filter(fn_0)
    assert immutable_list_1.head == 1
    assert immutable_list_1.tail is not None
    assert immutable_list_1.tail.tail is None
    immutable_list_2 = ImmutableList.of(1, 2, 3)
    fn_1 = (lambda x: x == 1)
    immutable_list_3 = immutable_list_2.filter(fn_1)
    assert immutable_list_3.head == 1
    assert immutable_list_3.tail is not None
    assert immutable_list_3.tail.head == 2
    assert immutable_list_3.tail.tail is not None

# Generated at 2022-06-25 23:50:19.203119
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 2) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: True) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: False) == ImmutableList.empty()