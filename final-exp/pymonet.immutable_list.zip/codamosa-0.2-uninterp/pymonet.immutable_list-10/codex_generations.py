

# Generated at 2022-06-18 01:27:43.202289
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.empty()) == 0



# Generated at 2022-06-18 01:27:45.815027
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-18 01:27:55.435790
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-18 01:28:00.095504
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of()) == 0
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-18 01:28:04.393555
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 10) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x > 10) == ImmutableList.empty()


# Generated at 2022-06-18 01:28:15.168249
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 10) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-18 01:28:21.545130
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1)

# Generated at 2022-06-18 01:28:25.174879
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    # When
    filtered = list_.filter(lambda x: x % 2 == 0)
    # Then
    assert filtered == ImmutableList.of(2, 4)


# Generated at 2022-06-18 01:28:32.046290
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.find(lambda x: x == 3) == 3
    assert list.find(lambda x: x == 6) is None
    assert list.find(lambda x: x == 1) == 1
    assert list.find(lambda x: x == 5) == 5


# Generated at 2022-06-18 01:28:40.480577
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:28:53.646340
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 0) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 10) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > -1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > -10) == 1

# Generated at 2022-06-18 01:29:04.974280
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:29:12.324745
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-18 01:29:22.297157
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:29:33.657551
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:29:39.498254
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 4) == ImmutableList.empty()


# Generated at 2022-06-18 01:29:49.017239
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -2) is None
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-18 01:29:59.655495
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 1) == ImmutableList.of(1)

# Generated at 2022-06-18 01:30:04.263815
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-18 01:30:12.506243
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:30:26.261126
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:30:34.410534
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:30:45.735111
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > -1) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > -2) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-18 01:30:53.396834
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 0) == ImmutableList.of(6)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 1) == ImmutableList.empty()


# Generated at 2022-06-18 01:31:02.895443
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:31:10.816600
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:31:21.518077
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 6) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x == 6) == ImmutableList.empty()


# Generated at 2022-06-18 01:31:24.981579
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.empty().find(lambda x: x == 6) is None


# Generated at 2022-06-18 01:31:35.288414
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:31:47.139381
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -2) is None
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-18 01:32:00.483103
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:32:11.592452
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:32:22.367044
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) != ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) != ImmutableList.of(1, 2, 3)

# Generated at 2022-06-18 01:32:28.042574
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 3) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 1) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find

# Generated at 2022-06-18 01:32:38.020063
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]

# Generated at 2022-06-18 01:32:48.182092
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -2) is None
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-18 01:32:53.571955
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:32:57.756593
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()

# Generated at 2022-06-18 01:33:06.133596
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == -2) is None
   

# Generated at 2022-06-18 01:33:16.838962
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 6) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 1) == ImmutableList.of(1)

# Generated at 2022-06-18 01:33:44.067448
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:33:54.538794
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:34:05.548694
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)

# Generated at 2022-06-18 01:34:15.326691
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > -1) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > -2) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-18 01:34:25.397970
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:36.816338
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 4) == ImmutableList.empty()

# Unit

# Generated at 2022-06-18 01:34:47.634101
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -2) is None
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-18 01:34:53.512134
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 2, 3)
    assert Imm

# Generated at 2022-06-18 01:35:03.204433
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:35:14.200302
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:36:00.436740
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:36:08.474136
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))

# Generated at 2022-06-18 01:36:18.788870
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-18 01:36:27.626263
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:36:32.051364
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 6) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x == 6) == ImmutableList.empty()


# Generated at 2022-06-18 01:36:38.621004
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.empty().find(lambda x: x == 3) is None


# Generated at 2022-06-18 01:36:47.578830
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 2) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 4) == ImmutableList.empty()
    assert Immutable

# Generated at 2022-06-18 01:36:56.253545
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:37:05.187576
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList

# Generated at 2022-06-18 01:37:14.072563
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 1) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 2) == ImmutableList(3)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 3) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 4) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 0) == Immutable