

# Generated at 2022-06-18 01:27:53.419001
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 0) == Immutable

# Generated at 2022-06-18 01:28:03.744669
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-18 01:28:15.209849
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 1)
    assert Imm

# Generated at 2022-06-18 01:28:23.883836
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, is_empty=True)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4, is_empty=True)
    assert ImmutableList.of(1, 2, 3) != Immutable

# Generated at 2022-06-18 01:28:33.015238
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 10) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-18 01:28:41.075206
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:28:52.044936
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 10) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x < 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:29:03.753067
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None

# Generated at 2022-06-18 01:29:11.498721
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:29:22.257925
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:29:39.605144
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 3 == 0) == ImmutableList.of(3, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 3 == 1) == ImmutableList.of(1, 4)

# Generated at 2022-06-18 01:29:46.790678
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:29:53.350256
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x > 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > -1) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-18 01:29:57.354195
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != Immutable

# Generated at 2022-06-18 01:30:00.961290
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.empty().find(lambda x: x == 6) is None


# Generated at 2022-06-18 01:30:11.326231
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-18 01:30:21.957726
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter

# Generated at 2022-06-18 01:30:32.420402
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList.empty()

# Generated at 2022-06-18 01:30:43.194301
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter

# Generated at 2022-06-18 01:30:52.707425
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 1)
    assert Imm

# Generated at 2022-06-18 01:31:15.939484
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 10) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:31:25.436531
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-18 01:31:35.737732
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 1)
    assert Imm

# Generated at 2022-06-18 01:31:47.273826
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:31:58.953514
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:32:06.339586
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5


# Generated at 2022-06-18 01:32:17.641368
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:32:27.512781
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter

# Generated at 2022-06-18 01:32:37.587438
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)


# Generated at 2022-06-18 01:32:47.804752
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:33:25.058178
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:33:34.189738
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)

# Generated at 2022-06-18 01:33:44.325064
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 1)
    assert Imm

# Generated at 2022-06-18 01:33:55.073509
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:06.110059
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:15.834989
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 0) == ImmutableList.of(6)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 0).filter(lambda x: x % 4 == 0) == ImmutableList.empty()

# Generated at 2022-06-18 01:34:26.062963
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 1)
    assert Imm

# Generated at 2022-06-18 01:34:33.902995
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 10) == ImmutableList.empty()


# Generated at 2022-06-18 01:34:43.475460
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:52.175389
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:36:17.959764
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:36:26.519088
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 2) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 10) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x == 10) == ImmutableList.empty()


# Generated at 2022-06-18 01:36:34.922385
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 1)
    assert Imm

# Generated at 2022-06-18 01:36:44.959569
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) != ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) != ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) != Imm

# Generated at 2022-06-18 01:36:54.515610
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter

# Generated at 2022-06-18 01:36:59.906502
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 10) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x < 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:37:10.619439
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-18 01:37:20.985988
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:37:31.372194
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:37:42.721944
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 0) == ImmutableList.of(6)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 3 == 0) == ImmutableList.empty()