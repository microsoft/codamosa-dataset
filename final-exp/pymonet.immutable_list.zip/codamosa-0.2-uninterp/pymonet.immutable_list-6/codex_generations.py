

# Generated at 2022-06-18 01:27:53.946279
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter

# Generated at 2022-06-18 01:28:05.313624
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:28:15.716718
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 2, 3)

# Generated at 2022-06-18 01:28:22.102549
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2), ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2), ImmutableList(3))

# Generated at 2022-06-18 01:28:26.411097
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None


# Generated at 2022-06-18 01:28:33.939712
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 3) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find

# Generated at 2022-06-18 01:28:41.547218
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:28:52.554987
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:29:04.231141
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 0) == ImmutableList.of(6)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 1) == ImmutableList.empty()

# Generated at 2022-06-18 01:29:11.848671
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 10) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:29:32.001937
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:29:40.440042
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:29:49.763321
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None

# Generated at 2022-06-18 01:30:00.419778
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -2) is None
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-18 01:30:11.008565
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:30:21.500936
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -2) is None
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-18 01:30:30.759716
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:30:41.466145
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:30:51.637597
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-18 01:31:01.219619
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:31:26.365205
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-18 01:31:36.645271
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)
   

# Generated at 2022-06-18 01:31:47.620703
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:31:59.075011
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:32:09.808954
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x == 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:32:20.911539
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == -1) is None

# Generated at 2022-06-18 01:32:31.371126
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:32:41.826459
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 2) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 4) == ImmutableList.empty()

# Generated at 2022-06-18 01:32:51.955770
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:33:01.720803
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 3 == 0) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 3 == 0).filter(lambda x: x % 4 == 0) == ImmutableList.empty()

# Generated at 2022-06-18 01:33:45.827094
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of

# Generated at 2022-06-18 01:33:56.295848
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:06.027985
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 6) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x == 6) == ImmutableList.empty()

# Generated at 2022-06-18 01:34:15.800692
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:26.008894
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:37.071746
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:34:47.852174
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 10) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 10) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 3) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 0) is None
    assert ImmutableList.empty().find(lambda x: x == 3) is None

# Generated at 2022-06-18 01:34:53.595042
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 0) == ImmutableList.of(6)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).filter(lambda x: x % 3 == 0) == ImmutableList.empty()

# Generated at 2022-06-18 01:35:03.277538
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1).filter(lambda x: x % 2 == 1) == Immutable

# Generated at 2022-06-18 01:35:14.264097
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:36:48.920209
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:36:55.556072
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-18 01:37:04.996254
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:37:13.923889
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:37:22.186977
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == -1) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None

# Generated at 2022-06-18 01:37:32.069018
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-18 01:37:43.380717
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 2) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 4) == ImmutableList.empty()
    assert Immutable