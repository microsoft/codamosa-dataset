

# Generated at 2022-06-12 04:58:55.830611
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    Li = ImmutableList.of(1, 2, 3)
    Li_filtered = Li.filter(lambda x: x > 1)

    assert Li_filtered == ImmutableList.of(2, 3)

# Generated at 2022-06-12 04:59:00.707102
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l_1 = ImmutableList.of(1, 2, 3)
    l_2 = ImmutableList.of(1, 2, 3)
    l_3 = ImmutableList.of(1, 2, 3, 4)

    assert l_1 == l_2
    assert l_1 != l_3



# Generated at 2022-06-12 04:59:09.982063
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Equals
    ImmutableList.of(None).__eq__(ImmutableList.of(None))
    ImmutableList.of(None).__eq__(ImmutableList(None))
    ImmutableList.of(None).__eq__(ImmutableList.of(None))
    ImmutableList.of(None, None).__eq__(ImmutableList(None, ImmutableList(None)))
    ImmutableList.of(1, 2, 3, 4, 5).__eq__(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))))


# Generated at 2022-06-12 04:59:15.458378
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(None, None, True) == ImmutableList(None, None, True)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(3)) == False


# Generated at 2022-06-12 04:59:19.912005
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 2).to_list() == [3]



# Generated at 2022-06-12 04:59:30.274659
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_1 = ImmutableList(1, ImmutableList(2), ImmutableList(3))
    assert list_1.find(lambda el: el == 2)  == 2
    assert list_1.find(lambda el: el > 2)  == 3
    assert list_1.find(lambda el: el < 0)  == None
    assert list_1.find(lambda el: el == 4)  == None
    assert list_1.find(lambda el: el == 1)  == 1
    assert (list_1 + ImmutableList(4)).find(lambda el: el == 4)  == 4


test_ImmutableList_find()
list_1 = ImmutableList(1, ImmutableList(2), ImmutableList(3))
print(list_1)
print(list_1.to_list())

# Generated at 2022-06-12 04:59:40.068899
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1, ImmutableList(2))) == True
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1)) == False
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(2, ImmutableList(1))) == False
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList()) == False
    assert ImmutableList(1).__eq__(ImmutableList(1)) == True
    assert ImmutableList(1).__eq__(ImmutableList(2)) == False
    assert ImmutableList(1).__eq__(ImmutableList()) == False
    assert ImmutableList().__eq__(ImmutableList()) == True
    assert Imm

# Generated at 2022-06-12 04:59:46.158644
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda item: item > 0) is None
    assert ImmutableList.of(1, 2).find(lambda item: item > 0) == 1
    assert ImmutableList.of(1, 2, 3, 4).find(lambda item: item > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda item: item > 6) is None

# Generated at 2022-06-12 04:59:49.651299
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    lst = ImmutableList.of(1, 2, 3, 4, 5, 6) 
    assert None == lst.find(lambda x: x == 0)
    assert 1 == lst.find(lambda x: x == 1)

# Generated at 2022-06-12 05:00:00.978385
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l = ImmutableList(1)
    assert l == l

    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))

    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(is_empty=True))) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-12 05:00:05.546365
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # method find was tested in test_ImmutableList_filter
    pass


# Generated at 2022-06-12 05:00:09.282356
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 1) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 3) == None

test_ImmutableList_find()

# Generated at 2022-06-12 05:00:20.667940
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList(is_empty=True).filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList(is_empty=True).filter(lambda x: False) == ImmutableList.empty()

    assert ImmutableList.of(0, 1, 2, 3, 4, 5).filter(lambda x: x < 4) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.of(0, 1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList()

# Generated at 2022-06-12 05:00:31.752492
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(
        'lorem',
        'ipsum',
        'dolor',
        'sit',
        'amet',
        'consectetur',
        'adipiscing',
        'elit',
    )

    assert list_.find(lambda x: x == 'ipsum') == 'ipsum'
    assert list_.find(lambda x: x == 'dolor') == 'dolor'
    assert list_.find(lambda x: x == 'sit') == 'sit'
    assert list_.find(lambda x: x == 'amet') == 'amet'
    assert list_.find(lambda x: x == 'consectetur') == 'consectetur'
    assert list_.find(lambda x: x == 'adipiscing') == 'adipiscing'

# Generated at 2022-06-12 05:00:35.624849
# Unit test for method find of class ImmutableList
def test_ImmutableList_find(): # pragma: no cover
    list_ = ImmutableList.of(
        1,
        2,
        3,
        4
    )

    assert list_.find(lambda x: x == 2) == 2
    assert list_.find(lambda x: x == 5) is None


# Generated at 2022-06-12 05:00:41.189029
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of('Ahmed', 'Mohamed', 'Ibrahim')
    new_il = il.filter(lambda n: n != 'Mohamed')

    assert isinstance(new_il, ImmutableList)
    assert str(new_il) == 'ImmutableList[Ahmed, Ibrahim]'

# Generated at 2022-06-12 05:00:50.038159
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_numbers = ImmutableList.of(1, 2, 3, 4)
    assert len(list_of_numbers.filter(lambda x: x % 2 == 0)) == 2

    list_of_numbers = ImmutableList.of(1, 2, 3, 4)
    assert len(list_of_numbers.filter(lambda x: x % 2 == 0).filter(lambda x: x == 2)) == 1

    list_of_numbers = ImmutableList.of(1, 2, 3, 4)
    assert list_of_numbers.filter(lambda x: x % 2 == 0).filter(lambda x: x == 2).find(lambda x: x == 2) == 2

# Generated at 2022-06-12 05:00:55.198040
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(4, 3, 2, 1, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 4) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None
    assert ImmutableList.empty().find(lambda x: x == 5) is None

# Generated at 2022-06-12 05:01:03.111907
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of('test').filter(lambda x: len(x) > 2) == ImmutableList.empty()
    assert ImmutableList.of('test').filter(lambda x: x == 'test') == ImmutableList.of('test')
    assert ImmutableList.empty().filter(lambda x: x == 'test') == ImmutableList.empty()



# Generated at 2022-06-12 05:01:13.623368
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda a: True) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda a: False) == ImmutableList.empty()
    assert ImmutableList.of(3, 4).filter(lambda a: a % 2 == 0) == ImmutableList.of(4)
    assert ImmutableList.of(10, 11).filter(lambda a: a % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda a: a % 2 != 0) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda a: a % 2 == 0) == ImmutableList.of(2)

# Generated at 2022-06-12 05:01:21.131830
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    numbers = ImmutableList.of(1, 2, 3, 4, 5)

    filtered_numbers = numbers.filter(lambda x: x > 3)

    assert ImmutableList.of(4, 5) == filtered_numbers
    assert ImmutableList.of(1, 2, 3) == numbers



# Generated at 2022-06-12 05:01:31.810130
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda a: a) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda a: a) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda a: a / 2) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: a) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: a / 2) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: a == 1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: a == 2)

# Generated at 2022-06-12 05:01:34.035773
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)

# Generated at 2022-06-12 05:01:41.890022
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    list_2 = ImmutableList.empty()
    list_3 = ImmutableList.of(1)
    assert list_1.find(lambda x: x == 3) == 3
    assert list_1.find(lambda x: x == 10) == None
    assert list_2.find(lambda x: x == 1) == None
    assert list_3.find(lambda x: x == 10) == None
    assert list_3.find(lambda x: x == 1) == 1


# Generated at 2022-06-12 05:01:45.054686
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 3, 5).find(lambda x: x % 2 == 0) == None


# Generated at 2022-06-12 05:01:46.648889
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda e: e == 1) == 1


# Generated at 2022-06-12 05:01:49.912814
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda item: item % 2 == 0) == ImmutableList.of(2, 4, 6)



# Generated at 2022-06-12 05:01:53.669551
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1,2,3,4,5).find(lambda x: x == 2) == 2
    assert ImmutableList.of().find(lambda x: x == 2) is None


# Generated at 2022-06-12 05:02:03.102639
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_1 = ImmutableList.of(10, 10, 20, 30)
    assert list_1.find(lambda x: x > 20) is None
    assert list_1.find(lambda x: x == 10) == 10
    assert list_1.find(lambda x: x == 20) == 20
    assert list_1.find(lambda x: x == 30) == 30

    list_2 = ImmutableList.of(10, 10, 20, 30)
    assert list_2.find(lambda x: x > 20) is None
    assert list_2.find(lambda x: x == 10) == 10
    assert list_2.find(lambda x: x == 20) == 20
    assert list_2.find(lambda x: x == 30) == 30



# Generated at 2022-06-12 05:02:05.992705
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    a = ImmutableList.of(1, 2, 3, 4)
    assert a.find(lambda x: not x % 2 == 0) == 1
    assert a.find(lambda x: x > 4) is None



# Generated at 2022-06-12 05:02:17.721037
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(4).find(lambda x: x == 4) == 4
    assert ImmutableList(5).find(lambda x: x == 4) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None



# Generated at 2022-06-12 05:02:21.658520
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1).filter(lambda x: x < 2) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x < 2) == ImmutableList(1)



# Generated at 2022-06-12 05:02:24.680808
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3, 4)
    assert l.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)



# Generated at 2022-06-12 05:02:29.557037
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda item: item % 2 == 0) == 2
    a = []
    assert ImmutableList.of(2, 3, 4).filter(lambda item: a.append(item)).find(lambda item: item == 2) == 2
    assert a == [2, 3, 4]

# Generated at 2022-06-12 05:02:33.743857
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)


# Generated at 2022-06-12 05:02:37.776479
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)



# Generated at 2022-06-12 05:02:41.880594
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.empty() == l1.filter(lambda x: x == 10)
    assert ImmutableList.of(1, 3, 5) == l1.filter(lambda x: x % 2)
    assert l1 == l1.filter(lambda _: True)

# Generated at 2022-06-12 05:02:46.399787
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Prepare
    f = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, is_empty=True)
    # Execute
    # Assert
    assert f.filter(lambda x: x % 2 == 0).is_empty == True


# Generated at 2022-06-12 05:02:50.144340
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x > 5) == 6
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x > 5) != 7

# Generated at 2022-06-12 05:02:59.839068
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of().filter(lambda x: True) == ImmutableList.of()
    assert ImmutableList.of(0).filter(lambda x: True) == ImmutableList.of(0)
    assert ImmutableList.of(0).filter(lambda x: False) == ImmutableList.of()
    assert ImmutableList.of(0, 1, 2).filter(lambda x: x > 1) == ImmutableList.of(2)
    assert ImmutableList.of(0, 1, 2).filter(lambda x: x == 0) == ImmutableList.of(0)
    assert ImmutableList.of(0, 1, 2).filter(lambda x: x < 1) == ImmutableList.of(0)
    assert ImmutableList.of(0, 1, 2).filter(lambda x: True) == ImmutableList

# Generated at 2022-06-12 05:03:26.121431
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None

    assert ImmutableList.of(4, 5, 6).find(lambda x: x == 10) == None

    assert ImmutableList.of(4, 5, 6).find(lambda x: x == 4) == 4



# Generated at 2022-06-12 05:03:35.868192
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3, 4, 5)
    b = a.filter(lambda x: x % 2 == 0)
    assert b == ImmutableList(2, 4)

    a = ImmutableList.of(1, 2, 3, 4, 5)
    b = a.filter(lambda x: x % 2 != 0)
    assert b == ImmutableList(1, 3, 5)

    a = ImmutableList.of(1, 2, 3, 4, 5)
    b = a.filter(lambda x: x % 2 == 0 and x % 3 == 0)
    assert b == ImmutableList()

    a = ImmutableList.of(1, 2, 3, 4, 5)
    b = a.filter(lambda x: x % 2 != 0 and x % 3 != 0)

# Generated at 2022-06-12 05:03:39.471343
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter(): # pragma: no cover
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 2).head == 2

# Generated at 2022-06-12 05:03:45.694466
# Unit test for method filter of class ImmutableList

# Generated at 2022-06-12 05:03:50.411357
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    expected_result = 'C'
    fn = lambda x: x == 'C'
    list = ImmutableList.of('A', 'B', 'C', 'D')
    # When
    result = list.find(fn)
    # Then
    assert expected_result == result

# Generated at 2022-06-12 05:04:00.648462
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test for filter
    #
    # fn: lambda x: x % 2 == 0
    # result: ImmutableList(2, ImmutableList(4, ImmutableList(6)))
    l = ImmutableList(
        1,
        ImmutableList(
            2,
            ImmutableList(
                3,
                ImmutableList(
                    4,
                    ImmutableList(
                        5,
                        ImmutableList(
                            6
                        )
                    )
                )
            )
        )
    )

    l_filtered = ImmutableList(
        2,
        ImmutableList(
            4,
            ImmutableList(
                6
            )
        )
    )

    assert l.filter(lambda x: x % 2 == 0) == l_filtered

    # Test for filter
    #
   

# Generated at 2022-06-12 05:04:04.809106
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    items = ImmutableList.of(1, 2, 3, 4, 5)

    # When
    found_item = items.find(lambda x: x > 4)

    # Then
    assert found_item is not None
    assert found_item == 5



# Generated at 2022-06-12 05:04:09.657497
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    list_2 = ImmutableList.of()

    # when
    result_1 = list_1.find(lambda value: value == 3)
    result_2 = list_2.find(lambda value: value == 1)

    # then
    assert result_1 == 3
    assert result_2 is None


# Generated at 2022-06-12 05:04:14.275588
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    nums = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    evens = nums.filter(lambda x: x % 2 == 0)
    assert ImmutableList(2, ImmutableList(4)) == evens

# Generated at 2022-06-12 05:04:16.536763
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    il = ImmutableList.of(1, 2, 3, 4)

    assert il.find(lambda x: x > 2) == 3

# Generated at 2022-06-12 05:04:55.858684
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(4, 1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(4, 1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(4, 1, 2, 3).find(lambda x: x == 3) == 3


# Generated at 2022-06-12 05:05:05.615755
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(2).filter(lambda x: x % 2 == 1) == ImmutableList.empty()

    assert ImmutableList.of(1, 2).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).filter(lambda x: x % 2 == 1) == ImmutableList.of(1)

    assert ImmutableList.of(1, 1, 2).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 1, 2).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 1)

    assert Imm

# Generated at 2022-06-12 05:05:08.306734
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda el: el >= 3) == ImmutableList(3, 4, 5)



# Generated at 2022-06-12 05:05:14.778481
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 100) is None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 1) == 1
    assert ImmutableList.empty().find(lambda x: x == 2) is None


# Generated at 2022-06-12 05:05:17.346984
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1,2,3,4).find(lambda x:x == 2) == 2
    assert ImmutableList.of(1,2,3,4).find(lambda x:x == 5) == None


# Generated at 2022-06-12 05:05:19.149195
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2


# Generated at 2022-06-12 05:05:22.192084
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(2, 3, 4).find(lambda x: x == 2)
    assert list_ == 2


# Generated at 2022-06-12 05:05:28.652385
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x == 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x == 0) == ImmutableList.empty()


# Generated at 2022-06-12 05:05:38.080835
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList([1, 2, 3]).filter(lambda x: x > 0) == ImmutableList([1, 2, 3])
    assert ImmutableList([1, 2, 3]).filter(lambda x: x > 1) == ImmutableList([2, 3])
    assert ImmutableList([1, 2, 3]).filter(lambda x: x > 2) == ImmutableList([3])
    assert ImmutableList([1, 2, 3]).filter(lambda x: x > 3) == ImmutableList([])
    assert ImmutableList().filter(lambda x: x > 3) == ImmutableList()


# Generated at 2022-06-12 05:05:42.486248
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    list_ = ImmutableList.of(1, 3, 5, 7, 9)

    # Act
    even = list_.filter(lambda x: x % 2 == 0)

    # Assert
    assert even == ImmutableList(2, ImmutableList(4, ImmutableList(6, ImmutableList(8, ImmutableList(is_empty=True)))))


# Generated at 2022-06-12 05:07:04.433318
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2 == 0) ==\
        ImmutableList(2)

    assert ImmutableList().filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)

    assert ImmutableList(3).filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)



# Generated at 2022-06-12 05:07:08.651312
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None


# Generated at 2022-06-12 05:07:10.974704
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    result = ImmutableList(1, ImmutableList(2), ImmutableList(3))\
        .filter(lambda x: x > 2)

    answer = ImmutableList(3)

    assert result == answer

# Generated at 2022-06-12 05:07:15.974403
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 4) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None
    assert ImmutableList.of().find(lambda x: x > 1) is None

# Generated at 2022-06-12 05:07:18.255924
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 5)

# Generated at 2022-06-12 05:07:22.286609
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert list_.filter(lambda x: x > 4).to_list() == [5, 6]
    assert list_.filter(lambda x: x < 1).to_list() == []



# Generated at 2022-06-12 05:07:28.666645
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Asserting of test
    assert ImmutableList().filter(lambda x: True) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)
    assert ImmutableList(1, 2).filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList(1, 2).filter(lambda x: True) == ImmutableList(1, 2)
    assert ImmutableList(1, 2).filter(lambda x: x % 2 == 0) == ImmutableList(2)

# Generated at 2022-06-12 05:07:31.419231
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    test_list = ImmutableList.of(1, 2, 3, 4)
    # Act
    result = test_list.find(lambda x: x == 3)

    # Assert
    assert result == 3


# Generated at 2022-06-12 05:07:40.459315
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 3 == 0) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 5 == 0) == ImmutableList.of()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 1 == 0) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % -1 == 0) == ImmutableList.of()
    assert ImmutableList.of().filter

# Generated at 2022-06-12 05:07:42.050557
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1).to_list() == [2, 3]