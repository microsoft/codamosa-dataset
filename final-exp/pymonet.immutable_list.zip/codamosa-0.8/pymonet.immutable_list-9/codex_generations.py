

# Generated at 2022-06-12 04:59:06.833585
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(1)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-12 04:59:10.549113
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    val = ImmutableList.of(1, 2, 3, 4, 5)

    # when
    filtered = val.filter(lambda x: x > 3)

    # then
    assert filtered == ImmutableList.of(4, 5)

# Generated at 2022-06-12 04:59:19.353734
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList() == ImmutableList(None, None, True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) == ImmutableList(1, None)
    assert ImmutableList(1) == ImmutableList(1, ImmutableList(None, None, True))
    assert ImmutableList(1) == ImmutableList(1, ImmutableList())
    assert not ImmutableList() == ImmutableList(1)
    assert not ImmutableList(1, ImmutableList()) == ImmutableList(1)
    assert not ImmutableList(1, ImmutableList()) == ImmutableList(2, ImmutableList())
    assert not ImmutableList(is_empty=True) == 5

test_ImmutableList

# Generated at 2022-06-12 04:59:29.873600
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 4) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() == ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == -100)

    assert ImmutableList.of('apple', 'banana', 'orange').filter(lambda x: x.startswith('a')) == ImmutableList.of('apple')

# Generated at 2022-06-12 04:59:33.700388
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1,2,3)
    assert list.find(lambda x: x == 1) is 1
    assert list.find(lambda x: x == 2) is 2
    assert list.find(lambda x: x == 3) is 3
    assert list.find(lambda x: x == 4) is None
# Unit tests for method reduce of class ImmutableList

# Immutable list is empty

# Generated at 2022-06-12 04:59:38.913205
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x < 3) == ImmutableList(1, ImmutableList(2))

test_ImmutableList_filter()

# Generated at 2022-06-12 04:59:46.872852
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    empty1 = ImmutableList.empty()
    empty2 = ImmutableList.empty()
    empty3 = ImmutableList.of('str', 1, True)

    assert empty1 == empty2
    assert empty1 != empty3

    list1 = ImmutableList.of('str', 1, True)
    list2 = ImmutableList.of('str', 1, True)
    list3 = ImmutableList.of('str', 1, True, list1)
    list4 = ImmutableList.of('str', 1, False)

    assert list1 == list2
    assert list1 != list3
    assert list1 != list4


# Generated at 2022-06-12 04:59:58.423931
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, ImmutableList.of(3, 4))
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, ImmutableList.of(2, ImmutableList.of(3, 4)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) \
        == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList.of(1, 2, 3, 4) != ImmutableList.of(1, 2, 3)


# Generated at 2022-06-12 05:00:01.294120
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList.of(5, 6, 8, 10)
    assert(list1.find(lambda element: element > 5) == 6)
    return True


# Generated at 2022-06-12 05:00:02.988549
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert isinstance(ImmutableList.of(5).find(lambda x: x == 5), int)

# Generated at 2022-06-12 05:00:18.364207
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList()
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList(1, 2).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1, 2).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, 2, 3).filter(lambda x: x == 1) == ImmutableList(1)

# Generated at 2022-06-12 05:00:23.606057
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    x = ImmutableList.of(1, 2, 3, 4)
    y = ImmutableList.of(1) + ImmutableList.of(2) + ImmutableList.of(3) + ImmutableList.of(4)
    z = ImmutableList.of(1, 2, 3, 4) + ImmutableList.empty()

    assert not x == 1
    assert x == y
    assert not x == ImmutableList.empty()
    assert x == z
    assert x.__eq__(y)
    assert not x.__eq__(ImmutableList.empty())
    assert x.__eq__(z)


# Generated at 2022-06-12 05:00:31.227306
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda i: i == 1) == 1
    assert ImmutableList.of(3, 7).find(lambda i: i == 7) == 7
    assert ImmutableList.of(3, 7, 5, 6).find(lambda i: i == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8).find(lambda i: i == 4) == 4
    assert ImmutableList.empty().find(lambda i: i == 1) is None

# Generated at 2022-06-12 05:00:42.864089
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    list1 = ImmutableList.of('one', 'two', 'three')
    list2 = ImmutableList.of('one', 'two', 'three')
    list3 = ImmutableList.of('one', 'two', 'four')
    list4 = ImmutableList.of('one', 'two')
    list5 = ImmutableList.of('one', 'two', 'three', 'four')
    list6 = ImmutableList.of()
    list7 = ImmutableList.of()
    list8 = ImmutableList.of('one')

    # Act
    result1 = list1.__eq__(list2)
    result2 = list1.__eq__(list3)
    result3 = list1.__eq__(list4)
    result4 = list1.__eq__(list5)


# Generated at 2022-06-12 05:00:52.360910
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    A = ImmutableList.of
    B = A()
    C = A(1)
    D = A(1, 2)
    E = A(1, 2, 3)
    F = A(1, 2, 3, 4)
    G = A(1, 2, 3, 4, 5)

    assert F == G
    assert E == F
    assert D == E
    assert C == D
    assert B == C
    assert B == ImmutableList.empty()
    assert C == ImmutableList.of(1)
    assert D == ImmutableList.of(1, 2)
    assert E == ImmutableList.of(1, 2, 3)
    assert F == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-12 05:00:58.661414
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3))
    assert (ImmutableList.of(1) == ImmutableList.of(1))
    assert not (ImmutableList.of(1) == ImmutableList.of(2))
    assert (ImmutableList.of() == ImmutableList.of())
    assert not (ImmutableList.of() == ImmutableList.of(1))



# Generated at 2022-06-12 05:01:01.499767
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda x: x%2 == 0)\
        .to_list() == [2, 4]

# Generated at 2022-06-12 05:01:03.640809
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1).to_list() == [1]



# Generated at 2022-06-12 05:01:07.971627
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda value: value == 1) == 1
    assert ImmutableList.of(1, 2).find(lambda value: value == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda value: value == 4) == None

# Generated at 2022-06-12 05:01:14.284730
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = list1.filter(lambda x: x % 2 == 0)
    list3 = list2.filter(lambda x: x == 2)

    assert list1 == ImmutableList.of(1, 2, 3, 4)
    assert list2 == ImmutableList.of(2, 4)
    assert list3 == ImmutableList.of(2)


# Generated at 2022-06-12 05:01:26.801161
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3)
    list = list.filter(lambda x: x < 3)
    assert list.head == 1
    assert list.tail.head == 2
    assert list.tail.tail is None


# Generated at 2022-06-12 05:01:36.092809
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList(3, 2, 1).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(3, 2, 1).filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList(3, 2, 1).filter(lambda x: True) == ImmutableList(3, 2, 1)
    assert ImmutableList(3, 2, 1).filter(lambda x: x > 3) == ImmutableList.empty()


# Generated at 2022-06-12 05:01:44.968764
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(None) == ImmutableList(None)
    assert ImmutableList(None, ImmutableList(None)) == ImmutableList(None, ImmutableList(None))
    assert ImmutableList(None, ImmutableList(None, ImmutableList(None))) == ImmutableList(None, ImmutableList(None, ImmutableList(None)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert not ImmutableList(1) == ImmutableList(2)

# Generated at 2022-06-12 05:01:47.167757
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(4, 2).filter(lambda x: x == 2) == ImmutableList.of(2)

# Generated at 2022-06-12 05:01:58.156652
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3)
    assert(list == list2)

    list = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 4)
    assert(list != list2)

    list = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 3, 3)
    assert(list != list2)

    list = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(2, 2, 3)
    assert(list != list2)

    list = ImmutableList.of(1, 2, 3)

# Generated at 2022-06-12 05:02:02.878947
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual = ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    expected = True

    assert actual == expected
    assert actual is expected

    actual = ImmutableList.of(1, 2, 3) == ImmutableList.of(2, 3, 4)
    expected = False

    assert actual == expected
    assert actual is expected


# Generated at 2022-06-12 05:02:05.780584
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    instance = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    other = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert(instance == other)



# Generated at 2022-06-12 05:02:15.637443
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(ImmutableList()) == True
    assert ImmutableList().__eq__(3) == False
    assert ImmutableList(5).__eq__(ImmutableList(5)) == True
    assert ImmutableList(5).__eq__(ImmutableList(9)) == False
    assert ImmutableList(5, ImmutableList(6)).__eq__(ImmutableList(5, ImmutableList(6))) == True
    assert ImmutableList(5, ImmutableList(6)).__eq__(ImmutableList(9, ImmutableList(6))) == False
    assert ImmutableList(5, ImmutableList(6)).__eq__(ImmutableList(5, ImmutableList(9))) == False

# Generated at 2022-06-12 05:02:19.777590
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    c1 = ImmutableList(1, ImmutableList.empty())
    c2 = ImmutableList(1, ImmutableList.empty())
    assert c1 == c2
    assert not c1 == "ImmutableList"



# Generated at 2022-06-12 05:02:23.713777
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l1 = ImmutableList.of(1, 2, 3, 4)

    assert l1.find(lambda x: x == 2) == 2
    assert l1.find(lambda x: x == 5) is None


# Generated at 2022-06-12 05:02:34.240581
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    filtered_list = list_.filter(lambda x: x % 2 == 0)
    assert filtered_list.to_list() == [2, 4]


# Generated at 2022-06-12 05:02:40.097239
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.find(lambda x: x == 3) == 3

    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.find(lambda x: x == 6) == None

test_ImmutableList_find()

# Generated at 2022-06-12 05:02:44.628159
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4)
    even_list = my_list.filter(lambda a: a % 2 == 0)
    expected_list = ImmutableList(2, ImmutableList(4))

    assert even_list == expected_list

# Generated at 2022-06-12 05:02:49.523338
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3).to_list() == [4, 5], 'ImmutableList: map fail'
    assert ImmutableList.empty().filter(lambda x: x > 3).to_list() == [], 'ImmutableList: map fail'
    assert ImmutableList.of(1, 2).filter(lambda x: x > 3).to_list() == [], 'ImmutableList: map fail'


# Generated at 2022-06-12 05:02:58.104496
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) \
       .filter(lambda x: x % 2 == 0) == ImmutableList(2)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) \
        .filter(lambda x: x % 2 == 1) == ImmutableList(1, ImmutableList(3))

    assert ImmutableList(False, ImmutableList(1, ImmutableList(2, ImmutableList(3)))).filter(lambda x: x) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-12 05:03:04.676635
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    data = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    data_filtered = data.filter(lambda a: a % 2 == 0)

    assert data_filtered == ImmutableList(2, ImmutableList(4))


# Generated at 2022-06-12 05:03:11.779888
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """ Unit test for method filter of class ImmutableList
    """
    case_1 = ImmutableList(2, ImmutableList(1, ImmutableList(3)))
    case_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert case_1.filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert case_2.filter(lambda x: x < 3) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-12 05:03:16.597697
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert list_.find(lambda x: x == 5) == 5
    assert list_.find(lambda x: x < 3) == 1
    assert list_.find(lambda x: x > 6) == None


# Generated at 2022-06-12 05:03:18.996130
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, 2, 3, 4).filter(lambda x: x > 2).to_list() == [3, 4]


# Generated at 2022-06-12 05:03:22.289718
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1, 2, 3)
    test_list = test_list.filter(lambda x: x % 2 == 0)
    assert test_list == ImmutableList.of(2)



# Generated at 2022-06-12 05:03:44.838393
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    before = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert before.filter(lambda x: x == 1) == ImmutableList(1)
    assert before.filter(lambda x: x == 2) == ImmutableList(2)
    assert before.filter(lambda x: x == 3) == ImmutableList(3)
    assert before.filter(lambda x: x == 4) == ImmutableList(4)
    assert before.filter(lambda x: x > 1) == ImmutableList(2, ImmutableList(3, ImmutableList(4)))
    assert before.filter(lambda x: x > 2) == ImmutableList(3, ImmutableList(4))
    assert before.filter(lambda x: x > 3) == ImmutableList(4)

# Generated at 2022-06-12 05:03:55.056575
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_with_two_elements = ImmutableList.of(1, 2)
    list_with_three_elements = ImmutableList.of(1, 2, 3)
    list_with_one_element = ImmutableList.of(1)
    empty_list = ImmutableList.empty()
    assert list_with_two_elements.find(lambda x: x % 2 == 0) == 2
    assert list_with_three_elements.find(lambda x: x % 2 == 0) == 2
    assert list_with_one_element.find(lambda x: x == 1) == 1
    assert empty_list.find(lambda x: x == 1) is None

# Generated at 2022-06-12 05:04:00.386101
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(
        1
    ).find(
        lambda x: x == 1
    ) == 1

    assert ImmutableList.of(
        1,
        2,
    ).find(
        lambda x: x == 3
    ) is None

    assert ImmutableList.of(
        1,
        2,
        3
    ).find(
        lambda x: x == 2
    ) == 2


# Generated at 2022-06-12 05:04:06.473216
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    source_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    filtered_list = source_list.filter(lambda x: x % 2 == 0)

    assert isinstance(filtered_list, ImmutableList)
    assert filtered_list.to_list() == [2, 4]


# Generated at 2022-06-12 05:04:09.900746
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3).filter(lambda x: x < 3) == ImmutableList.of(1,2)

# Generated at 2022-06-12 05:04:17.932241
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda a: a > 2) is None
    assert ImmutableList.of(1).find(lambda a: a > 2) is None
    assert ImmutableList.of(1, 2).find(lambda a: a > 2) is None
    assert ImmutableList.of(1, 2, 3).find(lambda a: a > 2) == 3
    assert ImmutableList.of(1, 2, 3, 3).find(lambda a: a > 2) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda a: a > 2) == 3

# Generated at 2022-06-12 05:04:23.066366
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    li = ImmutableList.of(1, 2, 3, 4)

    new_li = li.filter(lambda el: el > 3)

    assert new_li.head == 4
    assert new_li.tail.head is None
    assert new_li.tail.tail is None

test_ImmutableList_filter()

# Generated at 2022-06-12 05:04:30.506252
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_int = ImmutableList.of(1, 2, 3, 4, 5)
    list_int_odd = list_int.filter(lambda x: x % 2 == 1)
    list_int_even = list_int.filter(lambda x: x % 2 == 0)

    assert list_int_odd == ImmutableList.of(1, 3, 5)
    assert list_int_even == ImmutableList.of(2, 4)

    assert list_int_odd.tail.map(lambda x: x*2) == ImmutableList.of(2, 6, 10)
    assert list_int_even.tail.map(lambda x: x*2) == ImmutableList.of(4)



# Generated at 2022-06-12 05:04:33.418608
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList(1, ImmutableList(3))



# Generated at 2022-06-12 05:04:43.535033
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test case 1
    value_1 = ImmutableList.of(1, 2, 3, 4, 5)
    expected_1 = ImmutableList.of(5)
    actual_1 = value_1.filter(lambda i: i == 5)
    assert actual_1 == expected_1

    # Test case 2
    value_2 = ImmutableList.of(1, 2, 3, 4, 5)
    expected_2 = ImmutableList.of()
    actual_2 = value_2.filter(lambda i: i == 6)
    assert actual_2 == expected_2

    # Test case 3
    value_3 = ImmutableList.of(1, 2, 3, 4, 5)
    expected_3 = ImmutableList.of(2, 4)

# Generated at 2022-06-12 05:05:17.292691
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    result = my_list.filter(lambda x: x % 2 == 0)

    assert result.to_list() == [2, 4, 6, 8]


# Generated at 2022-06-12 05:05:28.587515
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    integer_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    string_list = ImmutableList.of('foo', 'bar', 'baz', 'qux')

    assert integer_list.filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6, 8, 10]
    assert string_list.filter(lambda x: len(x) == 3).to_list() == ['bar', 'baz']
    assert integer_list.filter(lambda x: x > 4).to_list() == [5, 6, 7, 8, 9, 10]
    assert string_list.filter(lambda x: x[0] == 'b').to_list() == ['bar', 'baz']

# Generated at 2022-06-12 05:05:32.808886
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]


# Generated at 2022-06-12 05:05:35.998945
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3


# Generated at 2022-06-12 05:05:38.796596
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(3, 4, 5, 6).find(lambda x: x == 5) == 5

# Generated at 2022-06-12 05:05:45.087808
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) is None
    assert ImmutableList(4).find(lambda x: True) == 4
    assert ImmutableList(4).find(lambda x: x == 2) is None
    assert ImmutableList(4, ImmutableList(5)).find(lambda x: True) == 4
    assert ImmutableList(4, ImmutableList(5)).find(lambda x: x == 5) == 5



# Generated at 2022-06-12 05:05:47.144253
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(5, 5, 6, 7, 8, 5, 2).filter(lambda x: x % 2 == 0) == ImmutableList.of(6, 8, 2)


# Generated at 2022-06-12 05:05:51.310736
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3)
    assert list.find(lambda x: x == 2) == 2

    list = ImmutableList.of(1, 2, 3)
    assert list.find(lambda x: x == 4) == None

test_ImmutableList_find()



# Generated at 2022-06-12 05:06:00.968443
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) == None, "Empty list must be None"
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).find(lambda x: x == 1) == 1, "Find 1"
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).find(lambda x: x == 5) == 5, "Find 5"
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).find(lambda x: x == 7) == 7, "Find 7"
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).find(lambda x: x == 8) == None, "Find 8"

# Generated at 2022-06-12 05:06:11.946016
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of().find(lambda x: x == 1) == None
    assert ImmutableList.of(1, 2, 3).append(4).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3).append(4).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).append

# Generated at 2022-06-12 05:06:48.614064
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert my_list.filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert my_list.filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]



# Generated at 2022-06-12 05:06:54.770045
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1, 2, 3, 4)
    assert test_list.filter(lambda x: x > 2) == ImmutableList.of(3, 4)
    assert test_list.filter(lambda x: x > 5) == ImmutableList()
    assert test_list.filter(lambda x: x < 0) == ImmutableList()



# Generated at 2022-06-12 05:06:58.314436
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    list = ImmutableList.of(1, 2, 3)

    # when
    filtered_list = list.filter(lambda x: x > 2)

    # then
    assert filtered_list == ImmutableList.of(3)



# Generated at 2022-06-12 05:07:01.429952
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: x > 4) == ImmutableList.of(5)

# Generated at 2022-06-12 05:07:05.172808
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    alist = ImmutableList.of(1, 2, 3, 7, 5)
    assert alist.filter(lambda x: x < 3).to_list() == [1, 2]
    assert alist.filter(lambda x: x > 3).to_list() == [7, 5]
    assert alist.filter(lambda x: x > 10).to_list() == []

# Generated at 2022-06-12 05:07:07.552557
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)


# Generated at 2022-06-12 05:07:10.387586
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of('a', 'b', 'c')

    list1_filtered = list1.filter(lambda x: x == 'c')

    assert list1_filtered.to_list() == ['c']


# Generated at 2022-06-12 05:07:14.235531
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9).filter(lambda x: x > 5).to_list() == [6,7,8,9]

test_ImmutableList_filter()

# Generated at 2022-06-12 05:07:19.029648
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(2,6,7,9,1).find(lambda x: x == 0) is None
    assert ImmutableList.of(2,6,7,9,1).find(lambda x: x == 6) == 6
    assert ImmutableList.of().find(lambda x: x == 0) is None
    assert ImmutableList.of(2).find(lambda x: x == 2) == 2


# Generated at 2022-06-12 05:07:26.176564
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) is None
    assert ImmutableList.empty().find(lambda x: x == 5) is None



# Generated at 2022-06-12 05:08:46.832967
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

# Generated at 2022-06-12 05:08:49.912893
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3, 4, 5)
    b = a.filter(lambda x: x%2 == 0)
    assert b == ImmutableList.of(2, 4)


# Generated at 2022-06-12 05:08:56.225689
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Create new empty ImmutableList
    assert ImmutableList().find(lambda x: True) == None

    # Create new ImmutableList with one element
    assert ImmutableList(5).find(lambda x: x == 5) == 5
    assert ImmutableList(5).find(lambda x: x == 4) == None

    # Create new ImmutableList with few elements
    assert ImmutableList(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList(1, 2, 3).find(lambda x: x == 4) == None

