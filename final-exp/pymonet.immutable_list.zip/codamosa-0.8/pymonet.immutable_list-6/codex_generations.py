

# Generated at 2022-06-12 04:59:04.657065
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty_list = ImmutableList.empty()
    another_empty_list = ImmutableList.empty()
    list_with_one = ImmutableList.of(1)
    list_with_two = ImmutableList.of(2)
    list_with_three = ImmutableList.of(3)
    list_with_two_and_one = ImmutableList.of(2, 1)

    assert empty_list == another_empty_list
    assert list_with_two == list_with_two
    assert list_with_three != list_with_one
    assert list_with_two_and_one != ImmutableList.of(1, 2)


# Generated at 2022-06-12 04:59:09.447311
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    second = ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__("123")
    assert first == True
    assert second == False

# Generated at 2022-06-12 04:59:13.244428
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    res = ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 3)
    exp = ImmutableList(1, ImmutableList(2))
    assert(res == exp)

# Generated at 2022-06-12 04:59:14.523067
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == [3, 4, 5]



# Generated at 2022-06-12 04:59:20.658562
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    import pytest
    from pytest import approx
    from typing import Optional, Callable, List
    
    def only_even_numbers(item: int) -> bool:
        return item % 2 == 0


# Generated at 2022-06-12 04:59:28.376772
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    # Act
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    result = test_list.filter(
        lambda x: x % 2 == 0)
    # Assert
    assert result.head == 2
    assert result.tail.head == 4
    assert result.tail.tail.head == 6
    assert result.tail.tail.tail.is_empty


# Generated at 2022-06-12 04:59:29.831812
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2


# Generated at 2022-06-12 04:59:33.453558
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    my_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert my_list.find(lambda x: x == 1) == 1
    assert my_list.find(lambda x: x == 3) == 3
    assert my_list.find(lambda x: x == 7) == None

test_ImmutableList_find()

# Generated at 2022-06-12 04:59:36.463241
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x%2 == 0) == ImmutableList.of(2, 4)
    
    

# Generated at 2022-06-12 04:59:38.619156
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    result = ImmutableList(1) == ImmutableList(1)
    expect = True
    assert result == expect


# Generated at 2022-06-12 04:59:49.206179
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    from lib import test_data

    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2,4)
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: x % 2 != 0) == ImmutableList.of(1,3,5)
    assert ImmutableList.of(1,2,3,4,5,6,7,8,9).filter(lambda x: x % 2 == 0).filter(lambda x: x % 3 == 0) == ImmutableList.of(6)
    assert ImmutableList.of(1).filter(lambda x: x % 2 != 0) == ImmutableList.of(1)

# Generated at 2022-06-12 05:00:00.904535
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    from random import randint

    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    
    big_random_list = [randint(1, 1000) for _ in range(100)]

    assert ImmutableList.of(*big_random_list).filter(is_odd) == \
        ImmutableList.of(*filter(is_odd, big_random_list))

    assert ImmutableList.of(*big_random_list).filter(is_even) == \
        ImmutableList.of(*filter(is_even, big_random_list))

    assert ImmutableList.of().filter(is_even).is_empty
    assert ImmutableList.of().filter(is_odd).is_empty


# Generated at 2022-06-12 05:00:06.583402
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 1) is None
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 1) == 1
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 2) == 2
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 3) is None


# Generated at 2022-06-12 05:00:15.574334
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test that method returns all items from
    # list that pass the filter function
    assert ImmutableList.empty().find(lambda x: x == 1) == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == '4') == None

# Generated at 2022-06-12 05:00:21.647326
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Test for ImmutableList.filter method
    """
    list1 = ImmutableList.of(1, 2, 3)
    list2 = list1.filter(lambda x: x == 1)

    assert len(list2) == 1
    assert list2.find(lambda x: x == 1) == 1
    assert list2.find(lambda x: x == 2) is None
    assert list2.find(lambda x: x == 3) is None


# Generated at 2022-06-12 05:00:26.781671
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    even = ImmutableList.of(2, 4, 6, 8)
    assert even.find(lambda i: i % 2 == 0) == 2

    none = ImmutableList.of(3, 5, 7)
    assert none.find(lambda i: i % 2 == 0) == None



# Generated at 2022-06-12 05:00:34.052894
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list_1 = ImmutableList.empty()
    assert immutable_list_1.find(lambda value: value is not None) is None
    assert immutable_list_1.find(lambda value: value is None) is None

    immutable_list_2 = ImmutableList.of(5, 1, 3)
    assert immutable_list_2.find(lambda value: value % 2 == 0) is None

    immutable_list_3 = ImmutableList.of(2, 3, 1, 5)
    assert immutable_list_3.find(lambda value: value > 1) == 2
    assert immutable_list_3.find(lambda value: value % 2 == 0) == 2

    immutable_list_4 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    assert immutable_list_

# Generated at 2022-06-12 05:00:44.258333
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1).find(lambda x: x == 2) == None
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) == None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) == None
    

# Generated at 2022-06-12 05:00:50.884447
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    import random

    list_size = random.randint(1, 10)
    test_list = ImmutableList.of(*range(list_size))
    new_list = test_list.filter(lambda x: x % 2 == 0)
    assert new_list == ImmutableList.of(*range(0, list_size, 2))

    test_list = ImmutableList.of(
        *[{'name': 'Mike', 'age': 17},
        {'name': 'John', 'age': 18},
        {'name': 'Kim', 'age': 17},
        {'name': 'Vasya', 'age': 18}
    ])

    new_list = test_list.filter(lambda x: x['age'] == 18)

# Generated at 2022-06-12 05:00:54.347372
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    
    def filter_func(a):
        return a % 2 == 0
    
    l = ImmutableList.of(1,2,3,4,5,6,7,8)
    fl = l.filter(filter_func)
    
    answer = [2, 4, 6, 8]
    assert answer == fl.to_list()

# Generated at 2022-06-12 05:01:04.038370
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    mlist = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    result = mlist.filter(lambda x: x % 2 == 0)
    assert result == ImmutableList.of(2, 4, 6, 8)


# Generated at 2022-06-12 05:01:14.213770
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    cases = [
        (
            ImmutableList.of(1, 2, 3, 4, 5),
            lambda x: x % 2 == 0,
            ImmutableList.of(2, 4)
        ),
        (
            ImmutableList.of(1, 2, 3, 4, 5),
            lambda x: x % 2 == 1,
            ImmutableList.of(1, 3, 5)
        ),
        (
            ImmutableList.of(1, 2, 3, 4, 5),
            lambda x: x > 3,
            ImmutableList.of(4, 5)
        )
    ]

    for case in cases:
        assert case[0].filter(case[1]) == case[2]

# Generated at 2022-06-12 05:01:17.798335
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)

    assert test_list.filter(lambda x: x % 2 == 0).to_list() == [2, 4]



# Generated at 2022-06-12 05:01:21.949335
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7)
    filtered_list = test_list.filter(
        lambda x: x % 2 == 0
    )

    assert filtered_list == ImmutableList.of(0, 2, 4, 6)

# Generated at 2022-06-12 05:01:31.043618
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == [2]
    assert ImmutableList.of(1, 2, 3).filter(lambda x: False) == []
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 0) == []
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 0 and x <= 5) == [1, 2, 3, 4, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: True) == [1, 2, 3, 4, 5]


# Generated at 2022-06-12 05:01:34.037424
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4)
    new_il = il.filter(lambda x: x > 2)

    assert new_il.to_list() == [3, 4]



# Generated at 2022-06-12 05:01:41.157881
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_with_head_none = ImmutableList(is_empty=True)
    list_with_tail_none = ImmutableList(10)
    list_with_two_elements = ImmutableList(100, ImmutableList(200))

    assert list_with_head_none.find(lambda x: True) is None
    assert list_with_tail_none.find(lambda x: True) == 10
    assert list_with_two_elements.find(lambda x: x > 100) == 200

# Generated at 2022-06-12 05:01:43.846344
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.find(lambda e: e == 5) == 5
    assert list.find(lambda e: e == -1) is None


# Generated at 2022-06-12 05:01:50.103277
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Create test ImmutableList
    list_ = ImmutableList.of(1, 2, 3)

    # Check if ImmutableList has correct values
    assert [1, 2, 3] == list_.to_list()

    # Check if ImmutableList.find() returns correct value
    assert 1 == list_.find(lambda v: v == 2)

    # Check if ImmutableList.find() returns None when there is no appropriate value
    assert list_.find(lambda v: v == 5) is None

# Generated at 2022-06-12 05:01:55.914218
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3)\
        .find(lambda x: x == 1) == 1

    assert ImmutableList.of(1, 2, 3)\
        .find(lambda x: x > 2) == 3

    assert ImmutableList.of(1, 2, 3)\
        .find(lambda x: x > 3) is None

# Generated at 2022-06-12 05:02:14.052199
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    numeric_list = ImmutableList.of(1, 2, 3, 4)

    assert numeric_list.find(lambda x: x > 2) == 3
    assert numeric_list.find(lambda x: x > 5) == None

    string_list = ImmutableList.of('a', 'b', 'c')

    assert string_list.find(lambda x: x == 'b') == 'b'
    assert string_list.find(lambda x: x == 'd') == None

# Generated at 2022-06-12 05:02:17.124658
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    assert list1.filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6, 8]



# Generated at 2022-06-12 05:02:20.762170
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4)

    assert list.find(lambda x : x == 2) == 2
    assert list.find(lambda x : x < 2) == 1
    assert list.find(lambda x : x > 4) == None


# Generated at 2022-06-12 05:02:25.389394
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    #given
    il = ImmutableList.of(1, 2, 3, 4, 5)
    fn = lambda x: x > 2

    #when
    result = il.filter(fn)

    #then
    assert result == ImmutableList.of(3, 4, 5)



# Generated at 2022-06-12 05:02:33.554580
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_len = 3
    test_list = [i for i in range(list_len)]
    # Test filter funcion without predicate
    assert len(ImmutableList.of(test_list[0], test_list[1], test_list[2]).filter(lambda x: True)) == list_len
    # Test filter function with predicate
    assert len(ImmutableList.of(test_list[0], test_list[1], test_list[2]).filter(lambda x: x == test_list[1])) == 1
    # Test filter on empty list
    assert len(ImmutableList.of().filter(lambda x: True)) == 0


# Generated at 2022-06-12 05:02:39.250900
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: True is None)
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 3, 5).find(lambda x: x % 2 == 0) is None


# Generated at 2022-06-12 05:02:46.838028
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_with_even_numbers = ImmutableList(1, ImmutableList(3, ImmutableList(7, ImmutableList(11))))

    list_with_odd_numbers = ImmutableList(2, ImmutableList(4, ImmutableList(14, ImmutableList(12))))

    returns_true = lambda x: x % 2 == 0

    assert list_with_even_numbers.filter(returns_true) == ImmutableList(is_empty=True)
    assert list_with_odd_numbers.filter(returns_true) == list_with_even_numbers

# Generated at 2022-06-12 05:02:51.052480
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x is None) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)


# Generated at 2022-06-12 05:02:56.703408
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3)
    
    assert list_.filter(lambda x: x == 1).to_list() == [1]
    assert list_.filter(lambda x: x > 1).to_list() == [2, 3]
    assert list_.filter(lambda x: x == -1).to_list() == []

# Generated at 2022-06-12 05:03:00.665455
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    foo = ImmutableList.of(1, 2, 3, 4, 5)
    assert foo.find(lambda x: x > 2) == 3


# Generated at 2022-06-12 05:03:33.045162
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10
    )

    assert list.filter(lambda a: a > 8).to_list() == [9, 10]
    assert list.to_list() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    empty_list = ImmutableList.empty()
    assert empty_list.filter(lambda a: a > 8).to_list() == []


# Generated at 2022-06-12 05:03:37.631340
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # should filter elements
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: True if x % 2 == 0 else False) == ImmutableList.of(2, 4)

    # should filter any elements
    assert ImmutableList.of(1, 2, 3).filter(lambda x: True if x % 2 == 0 else False) == ImmutableList.empty()
    
    # should do nothing if empty list
    assert ImmutableList.empty().filter(lambda x: True if x % 2 == 0 else False) == ImmutableList.empty()


test_ImmutableList_filter()

# Generated at 2022-06-12 05:03:40.635107
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    numbers = ImmutableList.of(1, 2, 3, 4, 5)
    even_numbers = numbers.filter(lambda x: x % 2 == 0)

    print(numbers)
    print(even_numbers)

test_ImmutableList_filter()


# Generated at 2022-06-12 05:03:43.483679
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    result_list = ImmutableList.of(1, 2, 3, 4, 5).filter(lambda it: it % 2 == 0)
    assert result_list == ImmutableList.of(2, 4)
    assert type(result_list) == ImmutableList

# Generated at 2022-06-12 05:03:48.681987
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 1) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.empty().find(lambda x: x == 4) is None


# Generated at 2022-06-12 05:03:51.459766
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert list.find(lambda x: x % 2 == 0) == 2

# Generated at 2022-06-12 05:03:56.354518
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Fixture
    list = ImmutableList.of(1, 2, 3)
    def finde(x):
        return x % 2 == 0

    assert list.find(finde) == 2
    assert ImmutableList.empty().find(finde) is None


# Generated at 2022-06-12 05:03:58.554342
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4)
    assert list.find(lambda x: x == 3) == 3



# Generated at 2022-06-12 05:04:05.517390
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Case 1
    elements = ImmutableList.empty()
    expected = None

    elements_found = elements.find(lambda e: True)

    assert(elements_found == expected)

    # Case 2
    elements = ImmutableList.of(1, 2, 3)
    expected = 1

    elements_found = elements.find(lambda e: e == 1)

    assert(elements_found == expected)


# Generated at 2022-06-12 05:04:16.937067
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list0 = ImmutableList.of()
    list1 = ImmutableList.of(5)
    list2 = ImmutableList.of(5, 4)
    list3 = ImmutableList.of(5, 4, 23)

    assert list0.find(lambda x: x < 3) is None
    assert list1.find(lambda x: x < 3) is None
    assert list1.find(lambda x: x == 5) == 5
    assert list2.find(lambda x: x < 3) is None
    assert list2.find(lambda x: x == 4) == 4
    assert list3.find(lambda x: x < 3) is None
    assert list3.find(lambda x: x == 4) == 4
    assert list3.find(lambda x: x == 23) == 23

# Generated at 2022-06-12 05:05:17.579078
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: (x % 2) == 0) == ImmutableList.empty()
    
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: (x % 2) == 0) == ImmutableList.of(2,4)
    
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: (x % 2) == 1) == ImmutableList.of(1,3,5)
    
    assert ImmutableList.of('a','b','c','d','e').filter(lambda x: x is 'b') == ImmutableList.of('b')
    

# Generated at 2022-06-12 05:05:23.378548
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 1) == 1


# Generated at 2022-06-12 05:05:30.771770
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x % 2 == 1) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x % 2 == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x % 3 == 0) == 3
    assert ImmutableList().find(lambda x: True) == None
    assert ImmutableList(1).find(lambda x: True) == 1
    assert ImmutableList().find(lambda x: False) == None
    assert ImmutableList(1).find(lambda x: False) == None


# Generated at 2022-06-12 05:05:34.252330
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3, 4)
    actual = a.filter(lambda x: x > 2).to_list()
    expected = [3, 4]

    assert actual == expected

# Generated at 2022-06-12 05:05:39.791096
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1,2,3,4).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1,2,3,4).find(lambda x: x == 10) is None
    assert ImmutableList.of().find(lambda x: x == 2) is None
    assert ImmutableList.empty().find(lambda x: x == 2) is None


# Generated at 2022-06-12 05:05:47.324386
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4, 5)

    def is_even(n):
        return n % 2 == 0

    assert il.filter(is_even) == ImmutableList.of(2, 4)

    il = ImmutableList.of(1, 2, 3, 4, 5)

    def is_empty_filter(n):
        return n is None

    assert il.filter(is_empty_filter) == ImmutableList.empty()


# Unit tests for method find of class ImmutableList

# Generated at 2022-06-12 05:05:54.046643
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()
# Unit testing environment
import unittest



# Generated at 2022-06-12 05:06:00.304911
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Prepare test data
    lst = ImmutableList.of(
        3, 4, 5, 6, 7, 8, 9, 10
    )

    # Execute method
    result = lst.filter(lambda e: e % 2 == 0)

    # Execute assertion
    assert result == ImmutableList.of(4, 6, 8, 10)

if __name__ == '__main__':
    test_ImmutableList_filter()
    print('All tests OK')

# %%

# Generated at 2022-06-12 05:06:04.221968
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # prepare
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    # action and assert
    assert test_list.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)



# Generated at 2022-06-12 05:06:14.037663
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda n: n % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of('a', 'b', 'c', 'd', 'e').filter(lambda a: len(a) == 1) == ImmutableList.of('a', 'b', 'c', 'd', 'e')
    assert ImmutableList.of('a', 'bb', 'c', 'ddd', 'e').filter(lambda a: len(a) > 1) == ImmutableList.of('bb', 'ddd')
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda n: n % 2 == 1) == ImmutableList.of(1, 3)

# Generated at 2022-06-12 05:08:20.979013
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 10) is None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x < 2) == 1
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x < 0) is None
    
    

# Generated at 2022-06-12 05:08:27.812280
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x > 0) is None
    assert ImmutableList(1).find(lambda x: x > 0) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x > 0) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x > 1) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) is None


# Generated at 2022-06-12 05:08:31.300169
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    array_input = [-1, 0, 1, 2, 3]
    expected = [0, 1, 2, 3]

    # Act
    actual = ImmutableList.of(*array_input).filter(lambda x: x >= 0)

    # Assert
    assert actual.to_list() == expected
test_ImmutableList_filter()



# Generated at 2022-06-12 05:08:36.173084
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda i: i == 3) is None
    assert ImmutableList(1).find(lambda i: i == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda i: i == 2) == 2
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).find(lambda i: i == 4) is None
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).find(lambda i: i == 3) == 3

# Generated at 2022-06-12 05:08:40.616842
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    lst = ImmutableList.of(1, 2, 3)
    assert lst.find(lambda x: x % 2 == 0) == 2
    assert lst.find(lambda x: x % 2 == 1) == 1
    assert lst.find(lambda x: x == -1) is None



# Generated at 2022-06-12 05:08:44.364166
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert list.find(lambda x: x % 2 == 0) == 2
    assert list.find(lambda x: x == 42) is None
    assert ImmutableList.empty().find(lambda x: x == 42) is None

# Generated at 2022-06-12 05:08:50.855062
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2 != 0) \
        == ImmutableList(1, ImmutableList(3))

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2 == 0) \
        == ImmutableList(2)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2 != 1) \
        == ImmutableList(2)
