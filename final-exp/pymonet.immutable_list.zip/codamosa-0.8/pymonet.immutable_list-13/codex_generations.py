

# Generated at 2022-06-12 04:59:03.411018
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) == None
    assert ImmutableList().find(lambda x: False) == None
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1).find(lambda x: x > 1) == None
    assert ImmutableList(1,2,3,4,5).find(lambda x: x == 4) == 4
    assert ImmutableList(1,2,3,4,5).find(lambda x: x > 5) == None


# Generated at 2022-06-12 04:59:06.433153
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(0, 1, 2, 3, 4)
    list2 = list1.filter(lambda x: x % 2 == 0)

    assert list2 == ImmutableList.of(0, 2, 4)


# Generated at 2022-06-12 04:59:09.008503
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(
        1, 2, 3, 4, 5, 6
    ).find(
        lambda x: x > 5
    ) == 6

# Generated at 2022-06-12 04:59:09.867528
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual = ImmutableList.of(1, 2, 3)
    assert actual == actual



# Generated at 2022-06-12 04:59:18.965414
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_data = ImmutableList.of(
        1, 5, 6, 8,
        ImmutableList.empty(),
        ImmutableList.of(1, 5, 9),
        ImmutableList.of(2, ImmutableList.of(7, 8), 5),
    )

    print('ImmutableList test data: ', test_data)

    assert test_data.find(lambda v: isinstance(v, ImmutableList)) == ImmutableList.empty()
    assert test_data.find(lambda v: v == 5) == 5
    assert test_data.find(lambda v: isinstance(v, ImmutableList) and v.find(lambda x: x == 9) == 9) == ImmutableList.of(1, 5, 9)

# Generated at 2022-06-12 04:59:27.579602
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    lst = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert lst == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert lst != ImmutableList(1, ImmutableList(3, ImmutableList(3)))

    assert lst != ImmutableList(1, ImmutableList(2))

    assert lst != ImmutableList(0, ImmutableList(2, ImmutableList(3)))

    assert lst != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-12 04:59:29.935485
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 2, 3)
    l2 = ImmutableList.of(1, 2, 3)
    l3 = ImmutableList.of(1, 2, 4)

    assert l1 == l2
    assert l2 != l3


# Generated at 2022-06-12 04:59:35.075428
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    Tests that two ImmutableLists are equal if they contains
    same elements

    :return: 
    """
    
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) == ImmutableList(1)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-12 04:59:37.634985
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]


# Generated at 2022-06-12 04:59:46.538147
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: True) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 4) == ImmutableList.of()


# Generated at 2022-06-12 04:59:58.990477
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual = ImmutableList() == ImmutableList()
    expected = True
    assert actual == expected

    actual = ImmutableList(is_empty=True) == ImmutableList(is_empty=True)
    expected = True
    assert actual == expected

    actual = ImmutableList(is_empty=True) == ImmutableList()
    expected = False
    assert actual == expected

# Generated at 2022-06-12 05:00:05.511530
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 2) == ImmutableList.of(1)

# Generated at 2022-06-12 05:00:08.752101
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1)



# Generated at 2022-06-12 05:00:20.205544
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # List of lists
    list_of_lists = ImmutableList(
        [1, 2, 3],
        ImmutableList(
            [4, 5, 6],
            ImmutableList(
                [7, 8, 9],
            )
        )
    )

    # list of None
    list_of_none = ImmutableList(
        None,
        ImmutableList(
            None,
            ImmutableList(
                None,
            )
        )
    )

    # asserting list of lists
    assert list_of_lists.filter(len) == ImmutableList(
        [1, 2, 3],
        ImmutableList(
            [4, 5, 6],
            ImmutableList(
                [7, 8, 9],
            )
        )
    )
    assert list_of_lists.filter

# Generated at 2022-06-12 05:00:22.654681
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)


# Generated at 2022-06-12 05:00:32.511529
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    class_ = ImmutableList
    assert (class_(1) == class_(1)) is True
    assert (class_(1) == class_(2)) is False
    assert (class_(1, class_(2)) == class_(1, class_(2))) is True
    assert (class_(1, class_(2)) == class_(1, class_(3))) is False
    assert (class_(1, class_(2)) == class_(1, class_(2, class_(3)))) is False
    assert (class_(1, class_(2, class_(3))) == class_(1, class_(2, class_(3)))) is True
    assert (class_(1, class_(2, class_(3))) == class_(1, class_(2, class_(4)))) is False
    assert (class_(1, class_(2)) == class_(1, class_(2), True)) is False
   

# Generated at 2022-06-12 05:00:43.871974
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    # test with two empty lists
    assert ImmutableList.empty() == ImmutableList.empty()

    # test with two empty lists and one not empty
    assert ImmutableList.empty() != ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.empty()

    # test two not empty lists
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)
    assert ImmutableList.of

# Generated at 2022-06-12 05:00:50.269789
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)).tail)


# Generated at 2022-06-12 05:00:59.159416
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    data = [1, 4, 6]

    result = ImmutableList.of(data[0], *data[1:]).filter(lambda x: x % 2 == 0)
    assert isinstance(result, ImmutableList)
    assert result.to_list() == [4, 6]
    assert result.head == 4
    assert result.tail.head == 6
    assert result.tail.tail is None

    result = ImmutableList.of(data[0], *data[1:]).filter(lambda x: True)
    assert isinstance(result, ImmutableList)
    assert result.to_list() == data

    result = ImmutableList.of(data[0], *data[1:]).filter(lambda x: False)
    assert isinstance(result, ImmutableList)
    assert result.head is None
    assert result.tail

# Generated at 2022-06-12 05:01:04.641377
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    list = ImmutableList(1, 2, 3, 4, 5, 6)

    assert list.filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]
    assert list.filter(lambda x: x > 5).to_list() == [6]
    assert list.filter(lambda x: x == 3).to_list() == [3]
    assert list.filter(lambda x: x == 7).to_list() == []


# Generated at 2022-06-12 05:01:14.388768
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda x: x < 3)\
        .to_list() == [1, 2]



# Generated at 2022-06-12 05:01:25.018004
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(5))))

# Generated at 2022-06-12 05:01:28.433287
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    my_list = ImmutableList.of(1, 2, 3, 4, 5)

    # When
    result = my_list.find(lambda x: x %2 == 0)

    # Then
    assert result == 2

# Generated at 2022-06-12 05:01:37.664921
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda a: a) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda a: a) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda a: a == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda a: a == 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda a: a == 4) is None
test_ImmutableList_find()


# Generated at 2022-06-12 05:01:41.444020
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4, 5, 6)
    result = il.filter(lambda x: x >= 3)

    assert result == ImmutableList.of(3, 4, 5, 6)


# Generated at 2022-06-12 05:01:50.653429
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2), False) == ImmutableList(1, ImmutableList(2), False)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)), False) == ImmutableList(1, ImmutableList(2, ImmutableList(3)), False)
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))

# Generated at 2022-06-12 05:02:01.492982
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_empty = ImmutableList.empty()
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(2)
    list3 = ImmutableList(3)

    assert list_empty == ImmutableList.empty(), "ImmutableList: __eq__ method doesn't work"
    assert list1 == ImmutableList.of(1), "ImmutableList: __eq__ method doesn't work"
    assert list2 == ImmutableList.of(2), "ImmutableList: __eq__ method doesn't work"
    assert list3 == ImmutableList(3), "ImmutableList: __eq__ method doesn't work"

    assert list_empty == ImmutableList.empty(), "ImmutableList: __eq__ method doesn't work"

# Generated at 2022-06-12 05:02:04.965619
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    list_ = ImmutableList.of(1, 2, 3, 4)
    # Act
    new_list = list_.filter(lambda x: x % 2 == 0)
    # Assert
    assert new_list == ImmutableList.of(2, 4)


# Generated at 2022-06-12 05:02:10.825397
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1).find(lambda x: x == 4) is None
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1


# Generated at 2022-06-12 05:02:15.299414
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3).filter(lambda x: x % 2 == 1) == ImmutableList.of(1,3)
    assert ImmutableList.of().filter(lambda x: True) == ImmutableList.empty()

test_ImmutableList_filter()

# Generated at 2022-06-12 05:02:33.484478
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()


# Generated at 2022-06-12 05:02:39.568020
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) == ImmutableList.of(1, 2) != ImmutableList.of(2, 3)

# Generated at 2022-06-12 05:02:48.848064
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)

    assert ImmutableList(1).filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: x % 2 != 0) == ImmutableList(1)

    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x % 2 != 0) == ImmutableList(1)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))
    assert Imm

# Generated at 2022-06-12 05:02:57.626936
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList())) == ImmutableList(1, ImmutableList(2, ImmutableList()))
    assert ImmutableList(1, ImmutableList()) == ImmutableList(1, ImmutableList())
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)

# Generated at 2022-06-12 05:03:03.681592
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual = ImmutableList(1, ImmutableList(3, ImmutableList(5, ImmutableList(7))), False)
    expected = ImmutableList(1, ImmutableList(3, ImmutableList(5, ImmutableList(7))), False)
    assert actual == expected

# Generated at 2022-06-12 05:03:09.419226
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5)



# Generated at 2022-06-12 05:03:17.123604
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)

    assert ImmutableList() == ImmutableList()
    assert ImmutableList() != ImmutableList(1)


# Generated at 2022-06-12 05:03:21.242063
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    ImmutableList_under_test = ImmutableList.of(1, 2, 3, 4)

    # Act
    result = ImmutableList_under_test.find(lambda x: x == 3)

    # Assert
    assert result == 3

# Generated at 2022-06-12 05:03:24.072818
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    tl = ImmutableList.of(1, 2, 3)
    ol = ImmutableList.of(1, 2, 3)

    assert tl == ol, "Two ImmutableLists with same elements should be equals"



# Generated at 2022-06-12 05:03:27.420995
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    fn = lambda item: item%2 == 0
    result = ImmutableList.of(1, 2, 3).find(fn)
    assert result == 2, "Should be equal"


# Generated at 2022-06-12 05:03:58.378394
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    second = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    third = ImmutableList(3, ImmutableList(2, ImmutableList(1)))

    assert first == second
    assert first != third



# Generated at 2022-06-12 05:04:07.322300
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (ImmutableList.of(1) == ImmutableList.of(1)) is True
    assert (ImmutableList.of(1) == ImmutableList.of(0)) is False
    assert (ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)) is True
    assert (ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2)) is False
    assert (ImmutableList.empty() == ImmutableList.empty()) is True
    assert (ImmutableList.empty() == ImmutableList.of(1)) is False


# Generated at 2022-06-12 05:04:12.512739
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-12 05:04:17.371209
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    assert (ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)) is True
    assert (ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3, 4)) is False
    assert (ImmutableList.of(1, 2, 3) == [1, 2, 3]) is False



# Generated at 2022-06-12 05:04:25.229870
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3).__eq__(ImmutableList.of(1, 2, 3))
    assert not ImmutableList.of(1, 2, 3).__eq__(ImmutableList.of(1, 2))
    assert not ImmutableList.of(1, 2, 3).__eq__(ImmutableList.of(2, 1, 3))
    assert not ImmutableList.of(1, 2, 3).__eq__(ImmutableList.of(1, 2, 3, 4))


# Generated at 2022-06-12 05:04:32.992897
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 2).to_list() == []
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 10 == 10).to_list() == []
    assert ImmutableList.of(-1, -2, -3, -4, -5).filter(lambda x: x % 2 == 0).to_list() == [-2, -4]


# Generated at 2022-06-12 05:04:43.358309
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(2, ImmutableList(1)) == ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2)) != None
    assert ImmutableList(1, ImmutableList(2)) != 1
    assert ImmutableList(1, ImmutableList(2)) != 'ImmutableList.of(1, 2)'
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList.empty()


# Generated at 2022-06-12 05:04:46.411265
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(8, 6, 5, 3, 4).filter(lambda x: x < 6) == ImmutableList.of(5, 3, 4)



# Generated at 2022-06-12 05:04:54.183270
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    b = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert a == b
    assert not a == ImmutableList()
    assert not a == ImmutableList(1)
    assert not a == ImmutableList.of(1, 2, 3)
    assert not a == ImmutableList.of(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-12 05:04:59.406678
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    fn = lambda x: x > 2
    assert ImmutableList.of(0, 1, 2, 3, 4).filter(fn) == ImmutableList.of(3, 4)
    assert ImmutableList.of(0, 1, 2, 3, 4).filter(fn) != ImmutableList.of(0, 1, 2, 3, 4)


# Generated at 2022-06-12 05:06:03.386691
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2).filter(lambda x: x > 10) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)

# Generated at 2022-06-12 05:06:07.838655
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda x: x % 2 == 0)\
        .to_list() == [2, 4]



# Generated at 2022-06-12 05:06:13.930576
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(
        ImmutableList(
            head=None,
            tail=None,
            is_empty=True
        )
    ), 'Should be equal'

    assert ImmutableList([1, 2]).__eq__(
        ImmutableList(
            head=1,
            tail=ImmutableList(
                head=2,
                tail=ImmutableList(
                    head=None,
                    tail=None,
                    is_empty=True
                ),
                is_empty=False
            ),
            is_empty=False
        )
    ), 'Should be equal'


# Generated at 2022-06-12 05:06:18.443473
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4, 5)

    assert list.find(lambda x: x % 2 == 0) == 2
    assert list.find(lambda x: x < 0) is None



# Generated at 2022-06-12 05:06:26.489693
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    immutable_list = ImmutableList.of(1, 23, 6, 5, -1, -10, 0, -234)

    # When
    filtered = immutable_list.filter(lambda d: d > 0)

    # Then
    assert filtered == ImmutableList.of(1, 23, 6, 5)

    # And
    assert immutable_list == ImmutableList.of(1, 23, 6, 5, -1, -10, 0, -234)


test_ImmutableList_filter()



# Generated at 2022-06-12 05:06:32.158665
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)

    assert my_list.filter(lambda x: x % 3 == 0) == ImmutableList.of(3, 6)
    assert my_list.filter(lambda x: x % 3 == 1) == ImmutableList.of(1, 4, 7)
    assert my_list.filter(lambda x: x % 3 == 2) == ImmutableList.of(2, 5, 8)

# Generated at 2022-06-12 05:06:36.048907
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    lst = ImmutableList.of(1, 2, 3, 4, 5)
    assert lst.find(lambda el: el == 4) == 4
    assert lst.find(lambda el: el == 11) is None


# Generated at 2022-06-12 05:06:40.522278
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)

    assert immutable_list.filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    # Unit test for method reduce of class ImmutableList

# Generated at 2022-06-12 05:06:43.135016
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)


# Generated at 2022-06-12 05:06:53.874751
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # __init__(head, tail)
    l = ImmutableList(1, ImmutableList(2))
    
    # True, False (head, tail)
    filter_1f = l.filter(lambda x: x>1)
    # False, True (head, tail)
    filter_1t = l.filter(lambda x: x<2)

    # False, False (head, tail)
    filter_1 = l.filter(lambda x: x != 1)
    # True, True (head, tail)
    filter_2 = l.filter(lambda x: x != 3)

    assert filter_1f.head is None
    assert filter_1f.tail.head == 2

    assert filter_1t.head == 1
    assert filter_1t.tail.head is None


# Generated at 2022-06-12 05:08:17.918839
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    to_be_filtered = ImmutableList.of(1, 2, 4, 4, 2, 5, 2, 1, 9)

    filtered = to_be_filtered.filter(lambda x: x != 2)

    expected = ImmutableList.of(1, 4, 4, 5, 1, 9)

    assert filtered == expected

# Generated at 2022-06-12 05:08:22.712562
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(10, 20, 30)
    result = list.find(lambda x: x >= 15)

    assert result == 20

    list = ImmutableList.of(10, 20, 30)
    result = list.find(lambda x: x > 30)

    assert result is None

    list = ImmutableList.empty()
    result = list.find(lambda x: True)

    assert result is None

# Generated at 2022-06-12 05:08:27.279325
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # arrange
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = list1.filter(lambda x: x % 2 == 0)

    # assert
    assert list2 == ImmutableList.of(2, 4)


# Generated at 2022-06-12 05:08:29.084964
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    empty = ImmutableList(None)
    assert empty.filter(lambda _: False) == ImmutableList(None)


# Generated at 2022-06-12 05:08:32.004541
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: x == 'x') is None
    assert ImmutableList(None).find(lambda x: x == 'x') is None
    assert ImmutableList(1).find(lambda x: x == 1) == 1



# Generated at 2022-06-12 05:08:40.543486
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: True) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x: False) == ImmutableList(is_empty=True)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: True) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: False) == ImmutableList(is_empty=True)

    # Unit test for method find of class ImmutableList
    assert ImmutableList().find(lambda x: True) is None

# Generated at 2022-06-12 05:08:49.335553
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 3) == ImmutableList(3)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 4) == ImmutableList.empty()

# Generated at 2022-06-12 05:08:55.723802
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    a_list = ImmutableList(1)
    b_list = ImmutableList(1, ImmutableList(2))
    c_list = ImmutableList(is_empty=True)

    assert a_list.find(lambda x: x==1) == 1
    assert a_list.find(lambda x: x==2) is None
    assert b_list.find(lambda x: x==2) == 2
    assert b_list.find(lambda x: x==3) is None
    assert c_list.find(lambda x: True) is None