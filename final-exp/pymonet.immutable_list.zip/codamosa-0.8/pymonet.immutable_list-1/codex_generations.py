

# Generated at 2022-06-12 04:59:05.077401
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList()
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-12 04:59:08.740083
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    b = ImmutableList.of(2, 3, 4)
    b = b.filter(lambda x: x>3)
    c = ImmutableList.of(4)
    assert(  b == c)


test_ImmutableList_filter()

# Generated at 2022-06-12 04:59:14.687190
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1,2,3) == ImmutableList.of(1,2,3)
    assert ImmutableList.of(1,2,3) != ImmutableList.of('1','2','3')
    assert ImmutableList.of(1,2,3) != ImmutableList.of(1,2,3,4)

# Generated at 2022-06-12 04:59:19.753455
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList(1)
    b = ImmutableList(1)
    c = ImmutableList(2)
    d = ImmutableList(1, ImmutableList(2))
    e = ImmutableList(1, ImmutableList(2))
    f = ImmutableList(2, ImmutableList(1))
    g = ImmutableList(1, ImmutableList(3))
    h = ImmutableList(1, ImmutableList(3))

    assert a == b
    assert not a == c
    assert not d == e
    assert not e == f
    assert h == g



# Generated at 2022-06-12 04:59:26.608067
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of('test').__eq__(ImmutableList.of('test')) == True
    assert ImmutableList.of('test').__eq__(ImmutableList.of('test1')) == False
    assert ImmutableList.empty().__eq__(ImmutableList.empty()) == True
    assert ImmutableList.empty().__eq__(ImmutableList.of('test')) == False
    assert ImmutableList.empty().__eq__('test') == False


# Generated at 2022-06-12 04:59:35.228582
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(3, -1, 5).find(lambda x: x > 0) == 3
    assert ImmutableList.of(3, -1, 5).find(lambda x: x > 1) == 3
    assert ImmutableList.of(3, -1, 5).find(lambda x: x > 2) == 3
    assert ImmutableList.empty().find(lambda x: x > 2) is None
    assert ImmutableList.of(3, -1, 5).find(lambda x: x > 3) == 5
    assert ImmutableList.of(3, -1, 5).find(lambda x: x > 4) == 5
    assert ImmutableList.of(3, -1, 5).find(lambda x: x > 5) is None

# Generated at 2022-06-12 04:59:43.779069
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)
    assert ImmutableList(2) == ImmutableList(2)
    assert not ImmutableList(3) == ImmutableList(is_empty=True)
    assert not ImmutableList(is_empty=True) == ImmutableList(2)
    assert not ImmutableList(2) == ImmutableList(3)
    assert ImmutableList(2) == ImmutableList(2, ImmutableList(is_empty=True))
    assert ImmutableList(2, ImmutableList(3)) == ImmutableList(2, ImmutableList(3))


# Generated at 2022-06-12 04:59:46.810097
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():  # pragma: no cover
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-12 04:59:55.640047
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1,2,3,4,5).filter(lambda _: True).to_list() == [1,2,3,4,5]
    assert ImmutableList.of(1,2,3,4,5).filter(lambda _: False).to_list() == []
    assert ImmutableList.of('1','2','3').filter(lambda x: x == '1').to_list() == ['1']


# Generated at 2022-06-12 05:00:04.788222
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    listt = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    listt2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    listt3 = ImmutableList(8, ImmutableList(2, ImmutableList(3)))
    listt4 = ImmutableList(1, ImmutableList(2, ImmutableList(6)))
    listt5 = ImmutableList(8, ImmutableList(2, ImmutableList(6)))
    assert listt == listt2
    assert listt != listt3
    assert listt != listt4
    assert listt != listt5
    
    

# Generated at 2022-06-12 05:00:20.206377
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of("some").find(lambda x: True) == "some"
    assert ImmutableList.of("some").find(lambda x: False) is None
    assert ImmutableList.empty().find(lambda x: True) is None
    assert ImmutableList.empty().find(lambda x: False) is None
    assert ImmutableList.of("some", "value").find(lambda x: x == "value") == "value"
    assert ImmutableList.of("some", "value").find(lambda x: x == "value2") is None
    
    


# Generated at 2022-06-12 05:00:29.573740
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    mapper = lambda x: x + 1
    test_cases = [
        {'args': ([1, 2, 3, 4], mapper), 'expected': [2, 3, 4, 5]},
        {'args': ([], mapper), 'expected': []},
    ]
    for test_case in test_cases:
        list_args = test_case['args']
        expected = test_case['expected']
        list_mapped = ImmutableList.of(*list_args[0]).map(list_args[1])
        assert list_mapped.to_list() == expected


# Generated at 2022-06-12 05:00:34.693012
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f')
    assert list.find(lambda el: el == 'f') == 'f'
    assert list.find(lambda el: el == 'z') is None
    assert ImmutableList.empty().find(lambda el: el == 'z') is None


# Generated at 2022-06-12 05:00:46.104615
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # array is empty
    res = ImmutableList()
    assert res.filter(lambda x: x == 2) == ImmutableList(is_empty=True)

    # array has only one element
    res = ImmutableList(2)
    assert res.filter(lambda x: x == 2) == ImmutableList(2)
    assert res.filter(lambda x: x == 1) == ImmutableList(is_empty=True)

    res = ImmutableList(
        1,
        ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))
    )
    expected = ImmutableList(
        2,
        ImmutableList(4)
    )
    assert res.filter(lambda x: x % 2 == 0) == expected


# Generated at 2022-06-12 05:00:49.663411
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 3).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3).to_list() == []


# Generated at 2022-06-12 05:00:55.821752
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(2))
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(is_empty=True) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)
    assert ImmutableList(is_empty=True) != ImmutableList(is_empty=False)


# Generated at 2022-06-12 05:01:04.495727
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 5, 8, 13, 21).filter(lambda n: n % 2 == 0).to_list() == [2, 8, 2]
    assert ImmutableList.of(1, 2, 3, 5, 8, 13, 21).filter(lambda n: n % 2 != 0).to_list() == [1, 3, 5, 13]
    assert ImmutableList.of(1, 2, 3, 5, 8, 13, 21).filter(lambda n: n > 10).to_list() == [13, 21]
    assert ImmutableList.of(1, 2, 3, 5, 8, 13, 21).filter(lambda n: n > 50).to_list() == []


# Generated at 2022-06-12 05:01:15.514817
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: 1 == 1) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0).filter(lambda x: x % 2 != 0) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == Immutable

# Generated at 2022-06-12 05:01:20.083020
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    pass
    """
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 9) is None
    """


# Generated at 2022-06-12 05:01:30.605864
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) == None
    assert ImmutableList.of('value').find(lambda x: x == 'value') == 'value'
    assert ImmutableList.of('value').find(lambda x: x == 'not value') == None

    assert ImmutableList.of('value', 'other value', 'value').find(lambda x: x == 'value') == 'value'
    assert ImmutableList.of('value', 'value', 'value').find(lambda x: x == 'value') == 'value'
    assert ImmutableList.of('other value', 'not value', 'value').find(lambda x: x == 'value') == 'value'
    assert ImmutableList.of('other value', 'not value', 'not value').find(lambda x: x == 'value') == None


# Unit test

# Generated at 2022-06-12 05:01:45.263315
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test with no elements in list
    no_elements_list = ImmutableList(is_empty=True)
    assert no_elements_list.filter(lambda t: t) == ImmutableList(is_empty=True)

    # Test with single element list
    single_element_list = ImmutableList(1)
    assert single_element_list.filter(lambda t: t) == ImmutableList(1)
    assert single_element_list.filter(lambda t: t == 0) == ImmutableList(is_empty=True)

    # Test with two elements list
    two_elements_list = ImmutableList(1, ImmutableList(2))
    assert two_elements_list.filter(lambda t: t) == ImmutableList(1, ImmutableList(2))
    assert two_elements_list.filter

# Generated at 2022-06-12 05:01:56.584267
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != 1
    assert ImmutableList.of(1, 2, 3) != []
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1, 2, 3)

# Generated at 2022-06-12 05:02:03.277915
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(1, 2, 3, 4)
    list_2 = ImmutableList.of(1, 2, 3, 4)
    list_3 = ImmutableList.of('one')
    empty_list_1 = ImmutableList.empty()
    empty_list_2 = ImmutableList.empty()

    assert list_1 == list_2
    assert empty_list_1 == empty_list_2
    assert list_1 != list_3
    assert empty_list_1 != list_3
    assert empty_list_1 != None
    assert list_1 != None

# Generated at 2022-06-12 05:02:07.691238
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert len(ImmutableList.of(1, 2, 3, 4, 5).filter(lambda n: n > 2)) == 3
    assert len(ImmutableList.of('A', 'B', 'C', 'D', 'E').filter(lambda s: s in ('B', 'C'))) == 2
    assert len(ImmutableList.of(True, False, True, False, True).filter(lambda b: b)) == 3


# Generated at 2022-06-12 05:02:12.408115
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Setup
    list = ImmutableList.of(1, 2, 3, 4, 5)

    # Exercise
    filtered_list = list.filter(lambda val: val % 2 == 0)

    # Verify
    assert filtered_list == ImmutableList.of(2, 4)
    assert list == ImmutableList.of(1, 2, 3, 4, 5)


# Generated at 2022-06-12 05:02:15.057533
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x > 4) == ImmutableList.of(5, 6)


# Generated at 2022-06-12 05:02:20.269724
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    given_instance = ImmutableList.of(1, 2, 3, 4, 5)

    assert given_instance.filter(lambda item: item % 2 == 0).to_list() == [2, 4], 'Given ImmutableList filter method must return new ImmutableList with only even numbers'


# Generated at 2022-06-12 05:02:23.029921
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-12 05:02:26.240931
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3)

# Generated at 2022-06-12 05:02:35.138875
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) != ImmutableList()
    assert ImmutableList(1) != ImmutableList(2)

# Generated at 2022-06-12 05:02:59.071146
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda x: x > 3) == ImmutableList.of(4, 5, 6, 7), 'should return new ImmutableList with elements that passed filter'
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda x: x > 7) == ImmutableList.empty(), 'should return empty ImmutableList when no elements passed filter'
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda x: x < 5)\
        == ImmutableList.of(1, 2, 3, 4), 'should return new ImmutableList with elements that passed filter'
    assert ImmutableList.of(1).filter(lambda x: x > 3) == ImmutableList.empty

# Generated at 2022-06-12 05:03:04.264186
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4)
    result = il.filter(lambda v: v % 2 == 0)
    assert len(result) == 2
    assert result.head == 2
    assert result.tail.head == 4



# Generated at 2022-06-12 05:03:10.563978
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(1, 2, 3, 4)
    list_2 = ImmutableList.of(1, 2, 3, 4)
    list_3 = ImmutableList.of(1, 2, 3)
    list_4 = ImmutableList.empty()

    assert list_1 == list_2
    assert not (list_1 == list_3)
    assert not (list_1 == list_4)


# Generated at 2022-06-12 05:03:14.376470
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert not ImmutableList.empty() == ImmutableList.of(1)
    
    

# Generated at 2022-06-12 05:03:17.654467
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList('a', ImmutableList('b', ImmutableList('c')))
    list2 = ImmutableList('a', ImmutableList('b', ImmutableList('c')))
    assert list1 == list2


# Generated at 2022-06-12 05:03:19.145181
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList(1)


# Generated at 2022-06-12 05:03:22.411168
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-12 05:03:29.540184
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test 1
    assert ImmutableList.of(1) == ImmutableList.of(1)

    # Test 2
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)

    # Test 3
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)

    # Test 4
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 2, 3)

# Generated at 2022-06-12 05:03:35.080297
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1).filter(lambda _: False) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda _: True) == ImmutableList.of(1)
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 2) == ImmutableList.of(1)


# Generated at 2022-06-12 05:03:38.601348
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3)

    def filter_fn(value):
        return value > 2

    assert a.filter(filter_fn) == ImmutableList.of(3)

# Generated at 2022-06-12 05:04:13.323592
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # empty list are equals
    empty_list_1 = ImmutableList.empty()
    empty_list_2 = ImmutableList.empty()
    assert (empty_list_1 == empty_list_2)

    # empty list isn't equals to non-empty list
    assert (empty_list_1 != ImmutableList.of(1))
    assert (empty_list_2 != ImmutableList.of(2))

    # non-empty lists are equals if they have equals elements in the same order
    assert (ImmutableList.of(1, 2) == ImmutableList.of(1, 2))

    # non-empty lists aren't equals if they have equals elements in different order
    assert (ImmutableList.of(1, 2) != ImmutableList.of(2, 1))

    # non-empty lists aren't equals if they have different

# Generated at 2022-06-12 05:04:17.058840
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_1 = ImmutableList.of(1, 2, 3)
    assert(not list_1.filter(lambda x: x == 4).is_empty)
    assert(list_1.filter(lambda x: x == 4).head == None)


# Generated at 2022-06-12 05:04:18.832440
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    my_list = ImmutableList.of(2, 5, 3, 1, 9)

    assert my_list.find(lambda x: x == 9) == 9
    assert my_list.find(lambda x: x == 10) is None



# Generated at 2022-06-12 05:04:23.890122
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2) == ImmutableList.of(1, 3)
    assert ImmutableList.of('a', 'Bb', 'Cc').filter(lambda x: x.isupper()) == ImmutableList.of('Bb', 'Cc')


# Generated at 2022-06-12 05:04:27.983924
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    value = ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x > 2)
    assert value == 3

    value = ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x > 4)
    assert value is None



# Generated at 2022-06-12 05:04:35.620584
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda e: e % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(2, 3).filter(lambda e: e % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).filter(lambda e: e % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1).filter(lambda e: e % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda e: e % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-12 05:04:44.108494
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    my_list = ImmutableList.of(1, 2, 3)
    new_list = my_list.filter(lambda n: n != 1)
    last_list = new_list.filter(lambda n: n != 2)
    filtered_list = last_list.filter(lambda n: n != 3)

    assert my_list != new_list
    assert my_list != filtered_list
    assert new_list != filtered_list

    # __str__
    assert str(ImmutableList.of(0)) == 'ImmutableList[0]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

    # append
    assert ImmutableList.empty().append(1) == ImmutableList(1, None, True)

# Generated at 2022-06-12 05:04:48.843728
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList.of(2, 3)
    list2 = ImmutableList.of(1)

    assert list1.find(lambda x: x == 3) == 3
    assert list2.find(lambda x: x == 1) == 1
    assert list2.find(lambda x: x == 2) == None

# Generated at 2022-06-12 05:04:54.932528
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList.empty())) == ImmutableList(1, ImmutableList(2, ImmutableList.empty()))
    assert ImmutableList(1, ImmutableList(2, ImmutableList.empty())) != ImmutableList(1)
    assert ImmutableList.empty() != None
    assert ImmutableList(2, None) != ImmutableList(2, ImmutableList.empty())


# Generated at 2022-06-12 05:05:05.108363
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test for empty ImmutableList
    assert ImmutableList().filter(lambda a: a) == ImmutableList()
    assert ImmutableList(is_empty=True).filter(lambda a: a) == ImmutableList(is_empty=True)
    # Test for one element
    assert ImmutableList(1).filter(lambda a: a) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda a: a == 1) == ImmutableList(1)
    assert ImmutableList(1).filter(
        lambda a: a == 2
    ) == ImmutableList(is_empty=True)
    # Test for two elements
    assert ImmutableList(1, 2).filter(lambda a: a == 2) == ImmutableList(2)

# Generated at 2022-06-12 05:06:13.510717
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of() == ImmutableList.of()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1) != ImmutableList.of()

    assert ImmutableList.of(
        1, 2, 3
    ) == ImmutableList.of(
        1, 2, 3
    )

    assert ImmutableList.of(
        1, 2, 3
    ) != ImmutableList.of(
        1, 2, 4
    )


# Generated at 2022-06-12 05:06:20.435343
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: True) ==\
        ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-12 05:06:23.380014
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-12 05:06:28.456323
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5)
    my_list = my_list.filter(lambda x: x % 2 == 0)
    assert my_list.head == 2
    assert my_list.tail.head == 4
    assert my_list.tail.tail is None

# Generated at 2022-06-12 05:06:32.244795
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    
    assert ImmutableList(1) == ImmutableList(1)
    
    assert ImmutableList(1) == ImmutableList(1, ImmutableList.empty())
    
    assert ImmutableList(1) == ImmutableList(1, ImmutableList(2), False)

# Generated at 2022-06-12 05:06:37.272686
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    inst1 = ImmutableList(1)
    inst2 = ImmutableList(1)
    assert inst1 == inst2

    inst3 = ImmutableList(1, ImmutableList(2))
    inst4 = ImmutableList(1, ImmutableList(2))
    assert inst3 == inst4

    assert inst1 != 1


# Generated at 2022-06-12 05:06:46.411690
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # empty list
    assert ImmutableList.empty().filter(lambda _: True) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda _: False) == ImmutableList.empty()

    # list with only one element
    assert ImmutableList(1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList(2).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(2).filter(lambda x: x % 2 == 1) == ImmutableList.empty()

    # list with two elements
    assert ImmutableList(1, ImmutableList(1)).filter(lambda x: x % 2 == 1) == ImmutableList(1, ImmutableList(1))

# Generated at 2022-06-12 05:06:52.670911
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    xs = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)

    assert xs.find(lambda x: x % 2 == 0) == 2
    assert xs.find(lambda x: x % 2 != 0) == 1
    assert xs.find(lambda x: x > 7) == None
    
    
test_ImmutableList_find()

# Generated at 2022-06-12 05:06:58.824274
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.find(lambda x: x == 3) == 3

    list_ = ImmutableList.of('asd', 'a', 'as')

# Generated at 2022-06-12 05:07:06.405928
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    two_three_four = ImmutableList.of(2, 3, 4)

    assert two_three_four.filter(lambda i: i % 2 == 1) == ImmutableList.of(3)
    assert two_three_four.filter(lambda i: i % 2 == 0) == ImmutableList.of(2, 4)

    assert two_three_four.filter(lambda i: i < 3) == ImmutableList.of(2)
    assert two_three_four.filter(lambda i: i > 2) == ImmutableList.of(3, 4)

    assert two_three_four.filter(lambda i: i > 4) == ImmutableList.empty()
    assert two_three_four.filter(lambda i: i < 0) == ImmutableList.empty()
