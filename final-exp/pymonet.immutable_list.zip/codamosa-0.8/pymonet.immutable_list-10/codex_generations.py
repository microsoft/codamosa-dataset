

# Generated at 2022-06-12 04:59:00.582955
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda f: f % 2 == 0) == ImmutableList.of(2, 4)


# Generated at 2022-06-12 04:59:06.341639
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    Unit test for method find of class ImmutableList
    """
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) == None
    assert ImmutableList.empty().find(lambda x: x == 1) == None


# Generated at 2022-06-12 04:59:16.552566
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    imm1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    imm2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    imm3 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(5))))
    imm4 = ImmutableList()
    imm5 = ImmutableList()
    imm6 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    assert imm1 == imm2
    assert imm2 == imm1
    assert imm3 != imm4
    assert imm4 == imm5
    assert imm1 != imm6


# Generated at 2022-06-12 04:59:28.293408
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(3, ImmutableList(3, ImmutableList(3, ImmutableList(3)))).filter(lambda a: a == 3) == ImmutableList(3, ImmutableList(3, ImmutableList(3, ImmutableList(3))))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(lambda a: a == 3) == ImmutableList(3)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(lambda a: a == 3) == ImmutableList(3)

# Generated at 2022-06-12 04:59:33.695421
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ilist = ImmutableList.of(1, 2, 3, 4, 5)
    result = ilist.filter(lambda x: x % 2 == 0)
    assert result.head == 2
    assert result.tail.head == 4
    assert result.tail.tail is None

    assert ilist.filter(lambda x: x == 3).head == 3
    assert ImmutableList.of(1, 3, 5).filter(lambda x: x > 1).head == 3
    assert ImmutableList.of(1, 3, 5).filter(lambda x: x > 10) is None


# Generated at 2022-06-12 04:59:37.013944
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(0, 1, 2, 3, 4)

    filtered = list_.filter(lambda a: a % 2 != 0)

    assert filtered == ImmutableList.of(1, 3)

# Generated at 2022-06-12 04:59:46.843491
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Prepare
    examples = [
        {
            "list": [1, 2, 3, 4, 5],
            "fn": lambda x: x % 3 == 0,
            "expected": 3
        },
        {
            "list": ["foo", "bar", 'buz', 'aab'],
            "fn": lambda x: 'aa' in x,
            "expected": 'aab'
        },
        {
            "list": [
                ImmutableList.of(1, 2, 3),
                ImmutableList.of(4, 5, 6),
                ImmutableList.of(7, 8, 9)
            ],
            "fn": lambda x: len(x) > 2,
            "expected": ImmutableList.of(1, 2, 3)
        },
    ]
    # Execute
    results

# Generated at 2022-06-12 04:59:58.424472
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_element = ImmutableList.of(1, 2, 3, 4)
    assert list_of_element.filter(lambda x: x == 1) == ImmutableList(1)
    assert list_of_element.filter(lambda x: x == 2) == ImmutableList(2)
    assert list_of_element.filter(lambda x: x == 3) == ImmutableList(3)
    assert list_of_element.filter(lambda x: x == 4) == ImmutableList(4)
    assert list_of_element.filter(lambda x: 0 < x < 4) == ImmutableList.of(1, 2, 3)
    assert list_of_element.filter(lambda x: 0 < x < 5) == ImmutableList.of(1, 2, 3, 4)
    assert list_of_element.filter

# Generated at 2022-06-12 05:00:03.122103
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    head = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    tail = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert head == tail
    assert len(head) == 3
    assert head.filter(lambda x: x > 1) == ImmutableList(2, ImmutableList(3))

# Generated at 2022-06-12 05:00:05.623204
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(4, 5, 2, 1, 2, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(4, 2, 4)



# Generated at 2022-06-12 05:00:22.449491
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # noinspection PyTypeChecker
    assert ImmutableList().__eq__(None) == False, "ImmutableList doesn't equal None"
    assert ImmutableList().__eq__(ImmutableList().__eq__(None)) == True, "ImmutableList doesn't equal another ImmutableList's result"

    assert ImmutableList(4).__eq__(4) == False, "ImmutableList with value doesn't equal the value"
    assert ImmutableList(4).__eq__(ImmutableList(4)) == True, "ImmutableList doesn't equal another ImmutableList with same value"
    assert ImmutableList(4).__eq__(ImmutableList(5)) == False, "ImmutableList with value doesn't equal another ImmutableList with different value"


# Generated at 2022-06-12 05:00:28.031008
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x % 3 == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 3 == 0) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x % 2 == 0) == 2

# Generated at 2022-06-12 05:00:31.847117
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) is None



# Generated at 2022-06-12 05:00:43.113271
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_type = ImmutableList[int]

    test_data = [
        {'first': list_type.empty(), 'second': list_type.empty(), 'result': True},
        {'first': list_type.of(1, 2, 3, 4, 5), 'second': list_type.of(1, 2, 3, 4, 5), 'result': True},
        {'first': list_type.of(3, 4, 5), 'second': list_type.of(1, 2), 'result': False},
        {'first': list_type.of(1, 2, 3, 4, 5), 'second': list_type.of(5, 4, 3, 2, 1), 'result': False},
    ]

    for test_case in test_data:
        assert test_case['first'] == test_case

# Generated at 2022-06-12 05:00:51.920789
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2).to_list() == [3, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1).to_list() == [1, 3]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 10).to_list() == []
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 0).to_list() == []


# Generated at 2022-06-12 05:00:56.376760
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3)
    c = ImmutableList.of(1, 2)
    assert a == b
    assert not a == c
    assert not a == None
    assert not a == 'a'


# Generated at 2022-06-12 05:01:00.063497
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList.of(1, 2, 3)
    second = ImmutableList.of(1, 2, 3)
    third = ImmutableList.of(1, 2, 4)
    assert first == second
    assert first != third


# Generated at 2022-06-12 05:01:04.038843
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-12 05:01:12.995101
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) != [1]
    assert ImmutableList.of(1) != None
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)

test_ImmutableList___eq__()

# Generated at 2022-06-12 05:01:21.086936
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(
        lambda x: x == 2
    ) == ImmutableList.of(2)

    assert ImmutableList.of(1, 2, 3).filter(
        lambda x: x > 1
    ) == ImmutableList.of(2, 3)

    assert ImmutableList.of(1, 2, 3).filter(
        lambda x: x < 1
    ) == ImmutableList.empty()


# Unit tests for method map of class ImmutableList

# Generated at 2022-06-12 05:01:33.805048
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    even_numbers = list.filter(lambda x: x % 2 == 0)

    assert even_numbers == ImmutableList.of(2, 4, 6, 8, 10)


# Generated at 2022-06-12 05:01:42.914206
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    list3 = ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8))))
    list4 = ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8))))

    assert list1 == list2
    assert list3 == list4
    assert not (list1 == list3)
    assert not (list2 == list4)

test_ImmutableList___eq__()

# Generated at 2022-06-12 05:01:49.641115
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList()) == ImmutableList(1)
    assert ImmutableList() == ImmutableList()


    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1, ImmutableList()) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList()) != ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-12 05:01:53.365862
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3)
    b = a.filter(lambda x: x > 1)
    c = ImmutableList.of(2, 3)

    assert b == c

# Generated at 2022-06-12 05:01:59.704505
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(10, ImmutableList.of(20, 30, 40)).find(lambda x: x > 25) == 30
    assert ImmutableList().find(lambda x: x > 10) is None
    assert ImmutableList(10, ImmutableList.of(20, 30, 40)).find(lambda x: x is None) is None
    assert ImmutableList.of("a", "b", "c").find(lambda x: True) == "a"

# Generated at 2022-06-12 05:02:02.574764
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    filtered_list = list_.filter(lambda x: x % 2 == 0)
    assert filtered_list == ImmutableList.of(2, 4)


# Generated at 2022-06-12 05:02:05.486378
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def filter_fn(x: int) -> bool:
        return x > 2
    assert [3, 4, 5] == ImmutableList.of(1, 2, 3, 4, 5).filter(filter_fn).to_list()



# Generated at 2022-06-12 05:02:12.319377
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.of(1, 2).filter(lambda x: True) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)



# Generated at 2022-06-12 05:02:17.217691
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    reset()
    assert_that(
        ImmutableList.empty().find(lambda x: True is False),
        none()
    )

    assert_that(
        ImmutableList.of(1, 2).find(lambda x: x == 2),
        equal_to(2)
    )

    assert_that(
        ImmutableList.of(1, 2).find(lambda x: x == 3),
        none()
    )

# Generated at 2022-06-12 05:02:20.389731
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3)
    assert (list_.find(lambda e: e == 2) == 2)
    assert (list_.find(lambda e: e == 5) == None)
    pass



# Generated at 2022-06-12 05:02:43.965108
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: True) is None
    assert ImmutableList(1).find(lambda x: True) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) is None
    assert ImmutableList(3, ImmutableList(2, ImmutableList(1))).find(lambda x: x == 1) == 1
    assert ImmutableList(3, ImmutableList(2, ImmutableList(1))).find(lambda x: x == 2) == 2

# Generated at 2022-06-12 05:02:47.486472
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x%2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.empty().filter(lambda x: x%2 == 0) == ImmutableList.empty()

# Generated at 2022-06-12 05:02:50.598963
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result = ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 3)
    expected = 3
    assert result == expected


# Generated at 2022-06-12 05:02:55.215270
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList() == ImmutableList(is_empty=True)



# Generated at 2022-06-12 05:02:58.213921
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    actual = ImmutableList.of(1, 2, 3, 4, 5).filter(lambda element: element % 2 == 0).to_list()
    expected = [2, 4]
    assert actual == expected

# Generated at 2022-06-12 05:03:02.890982
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]


# Generated at 2022-06-12 05:03:10.326886
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_test = ImmutableList.of(
        ImmutableList.of(0),
        ImmutableList.of(1, 2),
        ImmutableList.of(3, 4, 5),
        ImmutableList.of(6, 7, 8, 9)
    )
    assert list_test.find(lambda x: len(x) == 4) == ImmutableList.of(6, 7, 8, 9)
    assert list_test.find(lambda x: len(x) == 5) == None


# Generated at 2022-06-12 05:03:21.379453
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test start

    # Test for filter empty list
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.filter(lambda x: x == 1) == ImmutableList.of(1)
    assert list_.filter(lambda x: x == 2) == ImmutableList.of(2)
    assert list_.filter(lambda x: x == 3) == ImmutableList.of(3)
    
    # Test for filter non empty list
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_.filter(lambda x: x == 1) == ImmutableList.of(1)
    assert list_.filter(lambda x: x == 2) == ImmutableList.of(2)
    assert list_.filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-12 05:03:25.512532
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

# Generated at 2022-06-12 05:03:29.736443
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    sequence = ImmutableList.of(3, 4, 5, 6, 7)
    assert sequence.find(lambda x: x > 5) == 6
    assert sequence.find(lambda x: x > 100) is None

# Generated at 2022-06-12 05:04:07.678798
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # 1. Arrange
    unsorted_list = ImmutableList.of(3, 1, 4, 5, 9, 2, 8)
    # 2. Act
    filtered_list = unsorted_list.filter(lambda x: x % 2 == 0)
    # 3. Assert
    assert filtered_list == ImmutableList.of(4, 2, 8)

# Generated at 2022-06-12 05:04:15.105062
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))



# Generated at 2022-06-12 05:04:18.237824
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    fl = ImmutableList.of(1, 2, 3)

    assert fl.filter(lambda x: x < 3) == ImmutableList.of(1, 2)



# Generated at 2022-06-12 05:04:20.821330
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(2, 4, 6, 8, 10).filter(lambda v: v > 8).to_list() == [10]



# Generated at 2022-06-12 05:04:26.557772
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    given = ImmutableList.of(1, 2, 3, 4, 5, 6)
    expected = ImmutableList.of(2, 4, 6)

    found = given.filter(lambda a: a % 2 == 0)

    assert found == expected

    found = given.filter(lambda a: a > 4)
    assert found == ImmutableList.of(5, 6)


# Generated at 2022-06-12 05:04:33.226917
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    raw_list = [-1, 0, 4, 9, 16, 25, 36]
    list_of_numbers = ImmutableList.of(*raw_list)

    assert list_of_numbers.filter(lambda x: x > 0) == ImmutableList.of(*filter(lambda x: x > 0, raw_list))
    assert list_of_numbers.filter(lambda x: x < 0) == ImmutableList.of(*filter(lambda x: x < 0, raw_list))

# Generated at 2022-06-12 05:04:42.816835
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, is_empty=True).filter(lambda x: x == 1) == ImmutableList(is_empty=True)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 1) \
        == ImmutableList(1)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 3) \
        == ImmutableList(3)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 2 or x == 3) \
        == ImmutableList(2, ImmutableList(3))



# Generated at 2022-06-12 05:04:52.962550
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(
        1,
        2,
        3,
        4,
        5
    ).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(
        1,
        2,
        3,
        4,
        5
    ).find(lambda x: x % 2 == 1) == 1
    assert ImmutableList.of(
        1,
        2,
        3,
        4,
        5
    ).find(lambda x: x == 20) == None
    assert ImmutableList.of(
        1,
        2,
        3,
        4,
        5
    ).find(lambda x: x == 5) == 5


# Generated at 2022-06-12 05:04:56.582386
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_to_test = ImmutableList.of(0, 1, 2, 3, 4)
    list_after_filter = list_to_test.filter(lambda x: x > 2)

    assert list_after_filter == ImmutableList.of(3, 4)

# Generated at 2022-06-12 05:05:01.868246
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    li = ImmutableList.of(10, 20, 40)
    assert li.find(lambda v: v > 20) == 40
    assert li.find(lambda v: v < 10) is None
    # Test with empty list
    li = ImmutableList.empty()
    assert li.find(lambda v: v > 20) is None

# Generated at 2022-06-12 05:06:28.661540
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x == 1) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x: x == 2) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 3) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).filter(lambda x: x == 1) == Imm

# Generated at 2022-06-12 05:06:33.929631
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 4) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 4) == ImmutableList.of(5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 4) == ImmutableList.of(4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 1) == ImmutableList.of(1)

# Generated at 2022-06-12 05:06:44.902812
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Unit test for method filter of ImmutableList class
    """
    assert ImmutableList.empty().filter(lambda x: x is not None) == ImmutableList.empty()
    assert ImmutableList.of(1).filter(lambda x: x is not None) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).filter(lambda x: x is not 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).filter(lambda x: x is not 2) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).filter(lambda x: x is not 3) == ImmutableList.of(1, 2)

# Generated at 2022-06-12 05:06:54.400262
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9).filter(lambda x: x > 5) == ImmutableList.of(6, 7, 8, 9)


if __name__ == "__main__": # pragma: no cover
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-12 05:07:04.118774
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: True) == ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 5) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)

# Generated at 2022-06-12 05:07:05.732348
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x >= 2) == ImmutableList.of(2, 3)


# Generated at 2022-06-12 05:07:15.642229
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Should return ImmutableList with only elements that passed info argument returns True
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 2) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

# Generated at 2022-06-12 05:07:24.014204
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    expected = ImmutableList.of(1, 2)
    actual   = ImmutableList.of(0, 1, 2).filter(lambda x: x>0)
    assert expected == actual

    expected = ImmutableList.of(0, 1)
    actual   = ImmutableList.of(0, 1, 2).filter(lambda x: x<2)
    assert expected == actual

    expected = ImmutableList.of(0, 1, 2)
    actual   = ImmutableList.of(0, 1, 2).filter(lambda x: x is not None)
    assert expected == actual

    expected = ImmutableList.of()
    actual   = ImmutableList.of(0, 1, 2).filter(lambda x: False)
    assert expected == actual

    expected = ImmutableList.of()

# Generated at 2022-06-12 05:07:30.007859
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    case = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).filter(lambda x: x > 5)

    assert type(case) == ImmutableList
    assert case.filter(lambda x: x > 5).head == 6
    assert case.filter(lambda x: x > 5).tail.head == 7
    assert case.filter(lambda x: x > 5).tail.tail.tail.tail.head == 10
    assert str(case.filter(lambda x: x > 5)) == "ImmutableList[6, 7, 8, 9, 10]"


# Generated at 2022-06-12 05:07:34.201974
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert l.filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]

    assert l.filter(lambda x: x > 20).to_list() == []

    assert l.filter(lambda x: x == 1).to_list() == [1]