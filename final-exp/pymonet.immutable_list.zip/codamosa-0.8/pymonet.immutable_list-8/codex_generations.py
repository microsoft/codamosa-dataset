

# Generated at 2022-06-12 04:59:02.836447
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_immutable = ImmutableList.of(1, 2, 3, 4)
    list_immutable_r = ImmutableList.of(1, 2, 3, 4)
    list_immutable_not = ImmutableList.of(1, 2, 3, 4, 5)

    assert list_immutable == list_immutable_r
    assert list_immutable != list_immutable_not


# Generated at 2022-06-12 04:59:13.044441
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 1) == ImmutableList.empty().find(lambda x: x == 1), \
        "both of the data structures are empty so the predicate is never true and returns None"
    assert ImmutableList.of(1).find(lambda x: x == 1) == ImmutableList.of(1).find(lambda x: x == 1), \
        "both of the data structures contains the same value and the predicate returns true when the value equals 1 "
    assert ImmutableList.of(1).find(lambda x: x == 2) != ImmutableList.of(2).find(lambda x: x == 2), \
        "the first data struture contains the value 1 and the second structure contains the value 2, so the predicate returns true when the value equals 2"

# Generated at 2022-06-12 04:59:19.912783
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x < 5) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 4) == ImmutableList.empty()

# Generated at 2022-06-12 04:59:24.186020
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3)
    assert list.find(lambda x: x == 1) == 1
    assert list.find(lambda x: x == 2) == 2
    assert list.find(lambda x: x == 4) == None


# Generated at 2022-06-12 04:59:33.070916
# Unit test for method __eq__ of class ImmutableList

# Generated at 2022-06-12 04:59:39.688217
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # test for empty list
    assert ImmutableList.empty().find(lambda x: True) is None

    # test for list with one not matching element
    assert ImmutableList.of(1).find(lambda x: x < 0) is None

    # test for list with two matching element
    assert ImmutableList.of(1, 2).find(lambda x: x > 0) == 1

    # test for list with two matching element
    assert ImmutableList.of(1, 2).find(lambda x: x < 0) == 2



# Generated at 2022-06-12 04:59:45.184821
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)


# Generated at 2022-06-12 04:59:50.777267
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x % 2 == 0) is None
    assert ImmutableList.of(2, 4, 6).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 2, 4, 7).find(lambda x: x % 2 == 0) == 2



# Generated at 2022-06-12 05:00:01.620476
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1)
    l2 = ImmutableList.of('a', 'b', 'c')
    l3 = ImmutableList.of(1, 2, 3)
    e1 = ImmutableList.empty()
    e2 = ImmutableList.empty()
    assert l1.__eq__(l1) == True
    assert l2.__eq__(l2) == True
    assert l3.__eq__(l3) == True
    assert e1.__eq__(e1) == True
    assert e1.__eq__(e2) == True
    assert l3.__eq__(l2) == False
    assert 'a'.__eq__(1) == False


# Generated at 2022-06-12 05:00:04.628492
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    expected = ImmutableList.of(3, 5)

    assert immutable_list.filter(lambda x: x % 2 == 1) == expected



# Generated at 2022-06-12 05:00:21.680380
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3).to_list() == [4, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 5).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: True).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: False).to_list() == []

test_ImmutableList_filter()

# Generated at 2022-06-12 05:00:27.216351
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # given
    _ImmutableList = ImmutableList[int]

    # when
    list_1 = _ImmutableList(0, _ImmutableList(1))
    list_2 = _ImmutableList(0, _ImmutableList(1))

    # then
    assert list_1 == list_2


# Generated at 2022-06-12 05:00:32.360961
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: isinstance(x, bool)) == ImmutableList(is_empty=True)
    assert ImmutableList().filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)


# Generated at 2022-06-12 05:00:38.464851
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of('a', 'b', 'c')
    assert list.find(lambda e: e == 'a') == 'a'
    assert list.find(lambda e: e == 'b') == 'b'
    assert list.find(lambda e: e == 'z') is None
    assert list.find(lambda e: e == 'c') == 'c'


# Generated at 2022-06-12 05:00:43.575229
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList(1)
    b = ImmutableList(1)
    c = ImmutableList(2)
    d = ImmutableList(2, b)
    e = ImmutableList(1, ImmutableList(2))

    assert a == b
    assert d == b
    assert d != c
    assert a != e


# Generated at 2022-06-12 05:00:49.956374
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    number_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9)))))))))

    assert number_list.find(lambda number: number > 5) == 6
    assert number_list.find(lambda number: number % 2 == 0) == 2
    assert number_list.find(lambda number: number == 11) is None

# Generated at 2022-06-12 05:00:55.149847
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    maybe_list = ImmutableList(None)

    if maybe_list.find(lambda x: True) is not None:
        raise AssertionError('maybe is empty, but find returns None')

    maybe_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    if maybe_list.find(lambda x: x == 3) != 3:
        raise AssertionError('maybe is not None, but find returns None')

    if maybe_list.find(lambda x: x == 8) is not None:
        raise AssertionError('maybe is empty, but find returns None')


# Generated at 2022-06-12 05:00:56.724632
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)


# Generated at 2022-06-12 05:01:05.492907
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(3))

# Generated at 2022-06-12 05:01:12.588988
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of() == ImmutableList.of()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)

# Generated at 2022-06-12 05:01:27.639478
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    assert list1 == list2
    assert list1.head == list2.head
    assert list1.tail == list2.tail
    assert list1.is_empty == list2.is_empty


# Generated at 2022-06-12 05:01:37.008939
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda _: True) is None
    assert ImmutableList.empty().append(1).find(lambda _: True) == 1
    assert ImmutableList.empty().append(1).append(2).find(lambda _: True) == 1
    assert ImmutableList.empty().append(1).append(2).append(3).find(lambda x: x > 1) == 2
    assert ImmutableList.empty().append(1).append(2).append(3).find(lambda x: x > 3) is None
    assert ImmutableList.empty().append(1).append(2).append(3).find(lambda x: x > 0) == 1



# Generated at 2022-06-12 05:01:45.405338
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    empty_list = ImmutableList.of()

    assert empty_list.filter(lambda x: x == 1) == ImmutableList.empty()
    assert empty_list.filter(lambda x: x > 1) == ImmutableList.empty()

    list_of_numbers = ImmutableList.of(1, 2, 3, 4, 5)

    assert list_of_numbers.filter(lambda x: x == 1) == ImmutableList.of(1)
    assert list_of_numbers.filter(lambda x: x > 1) == ImmutableList.of(2, 3, 4, 5)
    assert list_of_numbers.filter(lambda x: x < 1) == ImmutableList.empty()

# Generated at 2022-06-12 05:01:49.727624
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_one  = ImmutableList(10)
    list_two  = ImmutableList(10)
    list_tree = ImmutableList(20)

    assert list_one == list_one
    assert not(list_one == list_tree)
    assert list_one == list_two


# Generated at 2022-06-12 05:02:00.708104
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test data
    test_value_1_1 = [1, 2, 3, 4, 5]
    test_value_1_2 = [1, 2, 3, 4, 5]
    test_value_2_1 = [1, 2, 3, 4, 5, 6]
    test_value_3_1 = [1, 2, 3, 4]
    test_value_4_1 = [2, 3, 4, 5]

    # Invoke the tested method
    obj_1_1 = ImmutableList(*test_value_1_1)
    obj_2_1 = ImmutableList(*test_value_2_1)
    obj_3_1 = ImmutableList(*test_value_3_1)
    obj_4_1 = ImmutableList(*test_value_4_1)
    obj_

# Generated at 2022-06-12 05:02:08.004637
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList(10).filter(lambda x: True) == ImmutableList(10)
    assert ImmutableList(10, ImmutableList(20, ImmutableList(30, ImmutableList.empty()))).filter(lambda x: True) == ImmutableList(10, ImmutableList(20, ImmutableList(30, ImmutableList.empty())))
    assert ImmutableList(10, ImmutableList(20, ImmutableList(30, ImmutableList.empty()))).filter(lambda x: False) == ImmutableList.empty()

# Generated at 2022-06-12 05:02:15.487608
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.empty()

    list2 = ImmutableList.empty()

    list3 = ImmutableList(1)

    list4 = ImmutableList(1)

    list5 = ImmutableList(2)

    list6 = ImmutableList(1, ImmutableList(1, ImmutableList(1)))

    list7 = ImmutableList(1, ImmutableList(1, ImmutableList(1)))

    assert list1 == list2

    assert list1 != list3

    assert list3 == list4

    assert list3 != list5

    assert list6 == list7

# Generated at 2022-06-12 05:02:19.775955
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-12 05:02:25.925261
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(-3))).filter(lambda x: x > 0) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(is_empty=True).filter(lambda x: x > 0) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: x > 0) == ImmutableList(1)


# Generated at 2022-06-12 05:02:31.010575
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(_is_one) == 1
    assert ImmutableList.of(2, 3).find(_is_one) is None
    assert ImmutableList.of(1).find(_is_one) == 1
    assert ImmutableList.of().find(_is_one) is None


# Generated at 2022-06-12 05:02:54.076911
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Given
    immutable_list_a = ImmutableList.of(1, 2, 3)
    immutable_list_b = ImmutableList.of(2, 3, 1)

    # When
    test_result = immutable_list_a.__eq__(immutable_list_b)

    # Then
    assert not test_result



# Generated at 2022-06-12 05:02:57.752695
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    filtered = l.filter(lambda x: x % 2)
    expected = ImmutableList.of(1, 3, 5)
    assert filtered == expected

# Generated at 2022-06-12 05:03:10.407492
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    instances = [
        ImmutableList.of(),
        ImmutableList.of(1, 2),
        ImmutableList.of(1, 2).filter(lambda x: x % 2 == 0)
    ]

# Generated at 2022-06-12 05:03:16.409420
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # setup
    a_list = ImmutableList.of(1, 2, 3)
    # assert
    assert a_list == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert a_list != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert a_list != ImmutableList.of('1', '2', '3')


# Generated at 2022-06-12 05:03:21.291265
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 2) == ImmutableList.of(1)

test_ImmutableList_filter()

# Generated at 2022-06-12 05:03:30.164689
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x > 2) == None, 'no element has to be returned when list is empty'
    assert ImmutableList.of(1).find(lambda x: x > 2) == None, 'no element has to be returned when no element pass filter'
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3, '3 has to be returned as first element that pass filter'
    assert ImmutableList.of(3, 2, 3).find(lambda x: x > 2) == 3, '3 has to be returned as first element that pass filter'
test_ImmutableList_find()

# Generated at 2022-06-12 05:03:37.410609
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    def dummy(): pass
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.empty() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))

# Generated at 2022-06-12 05:03:42.357677
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    elements = [1,2,3,4]
    list_of_elements = ImmutableList.of(*elements)

    assert list_of_elements.find(lambda x: x == 2) == 2
    assert list_of_elements.find(lambda x: x > 2) == 3
    assert list_of_elements.find(lambda x: x < 2) == 1
    assert list_of_elements.find(lambda x: x == 0) is None


# Generated at 2022-06-12 05:03:46.001585
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    a = ImmutableList.of(1, 2, 3, 4, 5)

    # When
    result = a.find(lambda x: x == 3)

    # Then
    assert result == 3


# Generated at 2022-06-12 05:03:57.896071
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(lambda x: x < 3) == \
        ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(lambda x: True) == \
        ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-12 05:04:42.699921
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4),\
        "ImmutableList.filter method error"
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 0) == ImmutableList.of(is_empty=True),\
        "ImmutableList.filter method error"
    assert ImmutableList.of("a", "b", "c", "d").filter(lambda x: x != "a") == ImmutableList.of("b", "c", "d"),\
        "ImmutableList.filter method error"


# Generated at 2022-06-12 05:04:49.350451
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    int_list = ImmutableList.of(1, 2, 3)
    assert int_list.find(lambda x: x == 3) == 3

    str_list = ImmutableList.of('a', 'b', 'c', 'd', 'e')
    assert str_list.find(lambda x: x in 'aeiou') == 'a'


    empty_list = ImmutableList.empty()
    assert empty_list.find(lambda x: x == True) == None

# Generated at 2022-06-12 05:04:55.083427
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    filtered_list = my_list.filter(lambda i: i % 2 == 0)
    assert(filtered_list.to_list() == [2, 4, 6, 8, 10])
    assert(my_list.to_list() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])


# Generated at 2022-06-12 05:05:05.206167
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)
    assert ImmutableList.of('a', 'b') == ImmutableList.of('a', 'b')
    assert ImmutableList.of('a') != ImmutableList.of(1)
    assert ImmutableList.of(1, 2) != ImmutableList.of('a', 'b')
    assert ImmutableList.of('a', 'b') != ImmutableList.of(1, 2)
    assert ImmutableList.of('a', 'b').filter(lambda x: x == 'b') == ImmutableList.of('b')
    assert Immutable

# Generated at 2022-06-12 05:05:07.807628
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_ = ImmutableList()
    assert list_ == ImmutableList(), "list_: {}".format(list_)



# Generated at 2022-06-12 05:05:14.969286
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    imm_list = ImmutableList.of('item1', 'item2', 'item3')
    assert imm_list == ImmutableList.of('item1', 'item2', 'item3')
    assert imm_list != ImmutableList.of('item1', 'item3')
    assert imm_list != ImmutableList.of('item1', 'item2', 'item3', 'item4')
    assert imm_list != ImmutableList.of('item1', 'item2', 'item2')


# Generated at 2022-06-12 05:05:19.134140
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1).filter(lambda x: x == 2) == ImmutableList(is_empty=True)
    assert ImmutableList.of(1, 2).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).filter(lambda x: x == 1) == ImmutableList.of(1)

# Generated at 2022-06-12 05:05:29.628514
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Arrange
    data1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    data2 = [0, 2, 5, 4, -1, 20, 38, -54, -10, 10]

    # Act
    list1 = ImmutableList.of(*data1)
    list2 = ImmutableList.of(*data2)
    list3 = ImmutableList.empty()

    # Assert
    assert list1.filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4, ImmutableList(6, ImmutableList(8, ImmutableList(10)))))
    assert list1.filter(lambda x: x < 5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-12 05:05:34.794204
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2), False) == ImmutableList(1, ImmutableList(2), False)
    assert not (ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2), False))
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)

# Generated at 2022-06-12 05:05:38.405591
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(
        lambda element: element > 2 
    ) == ImmutableList.of(3, 4, 5)


# Generated at 2022-06-12 05:07:01.893368
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x) == ImmutableList.empty()
    assert ImmutableList.of(5).filter(lambda x: x) == ImmutableList.of(5)
    assert ImmutableList.of(0).filter(lambda x: x) == ImmutableList()
    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(0, 2, 4, 6)
    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5)

# Generated at 2022-06-12 05:07:05.673707
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 2) == ImmutableList.of(1)
    assert ImmutableList.empty().filter(lambda x: x > 1) == ImmutableList.empty()

# Generated at 2022-06-12 05:07:09.328600
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    new_list = immutable_list.filter(lambda x: x > 3)
    assert new_list == ImmutableList(4, ImmutableList(5))
    
    

# Generated at 2022-06-12 05:07:13.335147
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_test = ImmutableList.of(1, 2, 3, 4, 5)
    list_test2 = list_test.filter(lambda x: x % 2 == 0)
    assert len(list_test2) == 2
    assert list_test2.to_list() == [2, 4]


# Generated at 2022-06-12 05:07:19.888341
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert [] == ImmutableList.empty().filter(lambda x: False).to_list()
    assert [] == ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 0).to_list()
    assert [1, 3, 5] == ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).to_list()
    assert [1, 2, 3, 4, 5] == ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 0).to_list()


# Generated at 2022-06-12 05:07:25.083907
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Set up test data
    m1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, None)))
    m2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, None)))

    # Test if two same instances of ImmutableList should be equal
    assert (m1 == m2) == True
    # Test if two different instances of ImmutableList should be equal
    assert (m1 == ImmutableList()) == False


# Generated at 2022-06-12 05:07:28.121982
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a1 = ImmutableList.of(0, 1, 2, 3)
    a2 = ImmutableList.of(0, 1, 2, 3)
    a3 = ImmutableList.of(0, 1, 2, 4)

    assert a1 == a2
    assert a1 != a3


# Generated at 2022-06-12 05:07:34.086330
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None
    assert ImmutableList.of(1).find(lambda x: x > 5) is None
    assert ImmutableList.of().find(lambda x: x > 5) is None

# Generated at 2022-06-12 05:07:37.278836
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda n: n == 1) is None
    assert ImmutableList(1).find(lambda n: n == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda n: n == 2) == 2

# Generated at 2022-06-12 05:07:41.562933
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))