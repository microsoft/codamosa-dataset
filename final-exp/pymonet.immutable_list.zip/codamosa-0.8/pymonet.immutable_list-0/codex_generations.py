

# Generated at 2022-06-12 04:59:02.339379
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_to_test = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_to_test.find(lambda x: x == 3) == 3
    assert list_to_test.find(lambda x: x == 6) is None


# Generated at 2022-06-12 04:59:07.178191
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Check that ImmutableList.filter() on empty ImmutableList return empty ImmutableList
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()

    # Check that ImmutableList.filter() return empty ImmutableList
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

    # Check that ImmutableList.filter() on empty ImmutableList return empty ImmutableList
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()


# Generated at 2022-06-12 04:59:11.347174
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList.of(1,2,3)
    second = ImmutableList.of(1,2,3)
    third = ImmutableList.of(1,2,3,4)

    assert(first == second)
    assert(first != third)
    assert(second == third)


# Generated at 2022-06-12 04:59:16.220094
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 0)
    l2 = ImmutableList.of(1, 0)
    l3 = ImmutableList.of(0, 1)

    assert l1 == l2
    assert l1 != l3
    assert l2 != l3


# Generated at 2022-06-12 04:59:19.911733
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x <= 3).to_list() == [1, 2, 3]


# Generated at 2022-06-12 04:59:23.119983
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList.empty()))) \
        .find(lambda x : x == 3) == 3

# Generated at 2022-06-12 04:59:31.647297
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) \
        == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList() != ImmutableList(is_empty=True)
    assert ImmutableList(3) != ImmutableList(4)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) \
        != ImmutableList(1, ImmutableList(2, ImmutableList(4)))



# Generated at 2022-06-12 04:59:38.789318
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    x = ImmutableList(4, ImmutableList(1, ImmutableList(6)))
    y = ImmutableList.empty()

    assert x.find(lambda x: x == 1) == 1
    assert y.find(lambda x: x == 5) is None
    assert y.find(lambda x: x == 5) == y.find(lambda x: x == 5)
    assert x.find(lambda x: x == 5) != y.find(lambda x: x == 5)

test_ImmutableList_find()
#Unit test for method reduce of class ImmutableList

# Generated at 2022-06-12 04:59:46.235628
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)

    assert ImmutableList() != ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)

test_ImmutableList___eq__()



# Generated at 2022-06-12 04:59:57.840568
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty() == ImmutableList.empty().filter(lambda e: e > 15)
    assert ImmutableList.of(3, 4, 5).to_list() == ImmutableList.of(3, 4, 5).filter(lambda e: e > 2).to_list()
    assert ImmutableList.of(3, 4, 5).to_list() == ImmutableList.of(3, 4, 5).filter(lambda e: e > 1).to_list()

    assert ImmutableList.of(3, 4, 5).to_list() != ImmutableList.of(3, 4, 5).filter(lambda e: e == 2).to_list()

# Generated at 2022-06-12 05:00:04.590207
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    m = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    # When
    n = m.filter(lambda i: i % 2 == 0)

    # Then
    assert n == ImmutableList(2)



# Generated at 2022-06-12 05:00:09.043353
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3)\
            .filter(lambda e: e > 1)\
            .to_list() == [2, 3]

    assert ImmutableList.of()\
            .filter(lambda e: e > 1)\
            .to_list() == []

    assert ImmutableList.of(1)\
            .filter(lambda e: e > 1)\
            .to_list() == []

# Generated at 2022-06-12 05:00:17.685877
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 'To be') == None
    assert ImmutableList.of(1, 'To be', 2, 'or not to be').find(lambda x: x == 'To be') == 'To be'
    assert ImmutableList.of(1, 'To be', 2, 'or not to be').find(lambda x: x == 'or not to be') == 'or not to be'
    assert ImmutableList.empty().find(lambda x: x == 'or not to be') == None



# Generated at 2022-06-12 05:00:24.102233
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(None, ImmutableList(None)) == ImmutableList(None, ImmutableList(None))
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) != ImmutableList(None)

# Generated at 2022-06-12 05:00:29.007274
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(1, 2, 3, 4)
    list_2 = ImmutableList.of(1, 2, 3, 4)
    assert list_1 == list_2, 'Expected two lists to be equal'



# Generated at 2022-06-12 05:00:37.587875
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    items = ImmutableList.of(
        {'id': 1, 'name': 'Foo'},
        {'id': 2, 'name': 'Bar'},
        {'id': 3, 'name': 'Baz'}
    )

    items_filtered = items.filter(lambda x: x['id'] == 2)

    assert len(items_filtered) == 1
    assert items_filtered[1]['name'] == 'Bar'

    items_filtered = items.filter(lambda x: x['id'] == 10)

    assert items_filtered.is_empty



# Generated at 2022-06-12 05:00:45.210534
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(0, 2, 4, 6, 10).filter(lambda n: n % 2 == 0) == ImmutableList.of(0, 2, 4, 6, 10)
    assert ImmutableList.of(1, 2, 4, 6, 5).filter(lambda n: n % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 3, 5).filter(lambda n: n % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-12 05:00:53.758080
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    one = ImmutableList.of(1)
    three = ImmutableList.of(3)
    five = ImmutableList.of(5)
    seven = ImmutableList.of(7)
    empty = ImmutableList.empty()

    assert one.filter(is_even) == empty
    assert three.filter(is_even) == empty
    assert five.filter(is_even) == empty
    assert seven.filter(is_even) == empty

    assert empty.filter(is_even) == empty

    assert one + three + five + seven == ImmutableList.of(1, 3, 5, 7)
    assert one + three + five + seven == ImmutableList(1, ImmutableList(3, ImmutableList(5, ImmutableList(7))))


# Generated at 2022-06-12 05:01:00.280400
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_ImmutableList = ImmutableList.of('some', 'list', 'of', 'string')
    empty_test_ImmutableList = ImmutableList.empty()
    assert test_ImmutableList.filter(lambda x: len(x) == 4).to_list() == ['some', 'list']
    assert test_ImmutableList.filter(lambda x: len(x) == 3).to_list() == ['of']
    assert empty_test_ImmutableList.filter(lambda x: x == 3).to_list() == []

# Generated at 2022-06-12 05:01:03.031874
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]


# Generated at 2022-06-12 05:01:17.396254
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return number % 2 != 0

    assert ImmutableList.of(1, 2, 3).filter(is_even).to_list() == [2]
    assert ImmutableList.of(1, 2, 3).filter(is_odd).to_list() == [1, 3]
    assert ImmutableList.of(1).filter(is_even).is_empty
    assert ImmutableList.empty().filter(is_even).is_empty


# Generated at 2022-06-12 05:01:20.831746
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1, 2, 3)
    acc = l.find(lambda x: x==1)
    assert acc == 1

    acc = l.find(lambda x: x==4)
    assert acc is None


# Generated at 2022-06-12 05:01:26.896108
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual = ImmutableList.of(1, 2, 3)
    expected = ImmutableList.of(1, 2, 3)
    assert actual == expected, 'Expected {}, actual {}'.format(expected, actual)

    actual = ImmutableList.of(1, 2, 3)
    expected = ImmutableList.of(1, 2, 3, 4)
    assert actual != expected, 'Expected {}, actual {}'.format(expected, actual)



# Generated at 2022-06-12 05:01:34.081517
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) == ImmutableList(1)

    assert not ImmutableList() == None
    assert not ImmutableList(1) == ImmutableList(2)
    assert not ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(3))
    assert not ImmutableList() == ImmutableList(1)


# Generated at 2022-06-12 05:01:43.907385
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    tests = [
        # [input_list, input_function, expected]
        [ImmutableList.of(1, 2, 3), lambda x: x > 2, ImmutableList.of(3)],
        [ImmutableList.of('a', 'b', 'c'), lambda x: x > 'b', ImmutableList.of('c')],
        [ImmutableList.of(1, 2, 3), lambda x: x < 2, ImmutableList.of(1)],
        [ImmutableList.of(1, 2, 3), lambda x: x > 3, ImmutableList.empty()],
        [ImmutableList.empty(), lambda x: x > 3, ImmutableList.empty()],
    ]

    for test in tests:
        input_list = test[0]
        input_function = test[1]
        expected

# Generated at 2022-06-12 05:01:49.824537
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-12 05:01:55.352470
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # arrange
    list_origin = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)

    # act
    list_filtered = list_origin.filter(lambda x: int(x) % 2 == 0)

    # assert
    assert list_filtered.to_list() == [2, 4, 6]

# Generated at 2022-06-12 05:02:02.811562
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a_list = ImmutableList.of(1, 2, 3, 4)
    another_list = ImmutableList.of(1, 2, 3, 4)
    assert a_list == another_list

    a_list = ImmutableList.of(1, 2, 3, 4)
    another_list = ImmutableList.of(1, 2, 3)
    assert a_list != another_list

    a_list = ImmutableList.of(1, 2, 3, 4)
    another_list = ImmutableList.of(1, 2, 3)
    assert a_list.__eq__(another_list) == False



# Generated at 2022-06-12 05:02:09.631095
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    elements = [1, 2, 3, 4, 5, 6]
    lst = ImmutableList.of(*elements)
    result = lst.filter(lambda x: x % 2 == 0)
    assert result == ImmutableList.of(2, 4, 6)
    elements = [1, 2, 3, 4, 5, 6]
    lst = ImmutableList.of(*elements)
    result = lst.filter(lambda x: x % 2 == 1)
    assert result == ImmutableList.of(1, 3, 5)
    elements = [1, 2, 3, 4, 5, 6]
    lst = ImmutableList.of(*elements)
    result = lst.filter(lambda x: x > 10)
    assert result == ImmutableList.empty()

# Generated at 2022-06-12 05:02:18.219011
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert not ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(5, ImmutableList(3)))
    assert not ImmutableList(1) == ImmutableList(5)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3, 4, 5, 6, 7)[:3]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == Imm

# Generated at 2022-06-12 05:02:41.985904
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert list1 == list2  # ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3))) result should be true

    list1 = ImmutableList(True)
    list2 = ImmutableList(False)

    assert list1 != list2  # ImmutableList(True) != ImmutableList(False) result should be true

    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

   

# Generated at 2022-06-12 05:02:49.553327
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Create instance of ImmutableList
    immutable_list = ImmutableList.of(1)
    # Check if first element is equal to 1
    assert immutable_list.find(lambda a: a == 1) == 1
    # Check if find return None
    assert immutable_list.find(lambda a: a == 2) is None
    # Check if first element is equal to 2
    assert ImmutableList.of(2, 1).find(lambda a: a == 2) == 2
    # Check if first element is equal to 2
    assert ImmutableList.of(2, 1).find(lambda a: a == 1) == 1

if __name__ == '__main__':
    test_ImmutableList_find()


# Generated at 2022-06-12 05:02:53.468070
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None

# Generated at 2022-06-12 05:02:59.456700
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) is None
    assert ImmutableList.of(2).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(3).find(lambda x: x % 2 == 0) is None
    assert ImmutableList.of(3, 4).find(lambda x: x % 2 == 0) == 4
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x % 2 == 0) == 2



# Generated at 2022-06-12 05:03:05.613419
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1,2,3,4,5,6,7,8)
    assert list_.filter(lambda item: item > 1).head == 2
    assert list_.filter(lambda item: item > 1).tail.head == 3
    assert list_.filter(lambda item: item > 1).tail.tail.head == 4

# Generated at 2022-06-12 05:03:09.701480
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None


# Generated at 2022-06-12 05:03:11.979639
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    Tests method __eq__ of class ImmutableList
    """
    lst = ImmutableList.of(1, 2, 3, 4)

    pass

# Generated at 2022-06-12 05:03:14.928693
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    result = ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert result



# Generated at 2022-06-12 05:03:23.954752
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x > 1) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 3) == ImmutableList.of(4)
    assert ImmutableList.of('a', 'b', 'c').filter(lambda x: x > 'a') == ImmutableList.of('b', 'c')
    assert ImmutableList.of('a', 'b', 'c').filter(lambda x: x < 'a') == ImmutableList.empty()



# Generated at 2022-06-12 05:03:28.286718
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(10, 15, 20, 25)

    assert l.find(lambda i: i > 10 and i < 20) == 15
    assert l.find(lambda i: i > 20 and i < 30) == 25



# Generated at 2022-06-12 05:04:02.513666
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == \
        ImmutableList.of(2)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x != 2) == \
        ImmutableList.of(1, 3)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) != \
        ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(1, 2, 3).append(4).filter(lambda x: x == 2) == \
        ImmutableList.of(2)

    assert ImmutableList.empty().filter(lambda x: x == 2) == \
        ImmutableList.empty()


# Generated at 2022-06-12 05:04:06.625416
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    assert my_list.filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6, 8]


# Generated at 2022-06-12 05:04:11.243617
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.empty() == ImmutableList.empty()


# Generated at 2022-06-12 05:04:16.775337
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(2) != ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 4)


# Generated at 2022-06-12 05:04:25.088878
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() != ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)



# Generated at 2022-06-12 05:04:30.808407
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    elements = ImmutableList.of('a', 'b', 'c', 'd', 'e')

    assert elements.find(lambda x: x == 'b') == 'b'
    assert elements.find(lambda x: x == 'z') is None



# Generated at 2022-06-12 05:04:36.531860
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda value: value) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda value: value == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda value: value == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda value: value == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda value: value == 4) == ImmutableList.of(4)

# Generated at 2022-06-12 05:04:43.459565
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test 1
    # arra = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    arra = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    # fn = lambda x: x % 2 == 0
    fn = lambda x: x if x % 2 == 0 else None

    # expected = [2, 4, 6, 8, 10]
    expected = ImmutableList.of(2, 4, 6, 8, 10)

    # actual = list(filter(fn, arra))
    actual = arra.filter(fn)

    assert actual == expected


# Generated at 2022-06-12 05:04:47.352591
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    value = ImmutableList(
        'first',
        ImmutableList(
            'second',
            ImmutableList('third')
        )
    ).find(lambda x: x == 'second')
    assert value == 'second'



# Generated at 2022-06-12 05:04:55.712227
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Given
    my_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    another_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    empty_list = ImmutableList.empty()
    another_empty_list = ImmutableList()
    # When
    result = my_list == another_list
    is_equal_empty_list = empty_list == another_empty_list
    is_not_equal_empty_list = empty_list == my_list
    # Then
    assert result == True
    assert is_equal_empty_list == True
    assert is_not_equal_empty_list == False

# Generated at 2022-06-12 05:06:09.429187
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 != 0).to_list() == [1, 3, 5]
    assert ImmutableList.of('a', 'b', 'c', 'd').filter(lambda x: x == 'a' or x == 'b').to_list() == ['a', 'b']


# Generated at 2022-06-12 05:06:13.930151
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)
    assert ImmutableList() != ImmutableList(1)

# Generated at 2022-06-12 05:06:19.687138
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3)\
        .filter(lambda it: it < 2)\
        .to_list() == [1]

    assert ImmutableList.of(2, 3, 4, 5)\
        .filter(lambda it: it % 2 == 0)\
        .to_list() == [2, 4]


# Generated at 2022-06-12 05:06:30.778716
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(4).__eq__(ImmutableList(4)) == True
    assert ImmutableList(3).__eq__(ImmutableList(4)) == False
    assert ImmutableList(7).__eq__(ImmutableList(7, ImmutableList(4))) == False
    assert ImmutableList(7, ImmutableList(4)).__eq__(ImmutableList(7, ImmutableList(4))) == True
    assert ImmutableList(7, ImmutableList(7)).__eq__(ImmutableList(7, ImmutableList(7))) == True
    assert ImmutableList(7, ImmutableList(7)).__eq__(ImmutableList(7, ImmutableList(8))) == False

# Generated at 2022-06-12 05:06:37.909517
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 2, 3)
    l2 = ImmutableList.of(1, 2, 3)
    l3 = ImmutableList.of(1, 2, 3)
    l4 = ImmutableList.of(1, 2, 4)

    assert l1 == l2
    assert not l1 == l3
    assert not l2 == l3
    assert not l3 == l4
    assert not l4 == l1
    assert not l4 == '123'

# Generated at 2022-06-12 05:06:40.911137
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-12 05:06:44.256876
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Given
    expected = ImmutableList.of('a', 'b', 'c')
    # When
    actual = ImmutableList.of('a', 'b', 'c')
    # Then
    assert actual == expected



# Generated at 2022-06-12 05:06:50.092903
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    sequence = ImmutableList.of(1, 2, 3, 4, 0, 5, 6, 7)

    # Act
    result = sequence.filter(lambda x: x % 2 == 0)

    # Assert
    assert result == ImmutableList.of(2, 4, 0, 6)

# Generated at 2022-06-12 05:06:53.145324
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, 2, 3) == ImmutableList(1, 2, 3)
    assert ImmutableList(1, 2, 3) != ImmutableList(1, 2)
    
    

# Generated at 2022-06-12 05:06:57.826933
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    second = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    third = ImmutableList(1, ImmutableList(3, ImmutableList(2)))

    assert first == second
    assert first != third


# Generated at 2022-06-12 05:08:18.018458
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert None == ImmutableList.empty().find(lambda x: x % 2 == 1)
    assert 1 == ImmutableList.of(1).find(lambda x: x % 2 == 1)
    assert None == ImmutableList.of(2).find(lambda x: x % 2 == 1)
    assert 2 == ImmutableList.of(1, 2).find(lambda x: x % 2 == 1)
    assert 3 == ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 1)
    assert 1 == ImmutableList.of(1, 2, 3).find(lambda x: x % 3 == 0)


# Generated at 2022-06-12 05:08:27.547496
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def is_number_even(number: int) -> bool:
        return number % 2 == 0

    assert ImmutableList.of(1).filter(is_number_even).to_list() == [], 'Incorrect filter of simple ImmutableList'
    assert ImmutableList.of(2).filter(is_number_even).to_list() == [2], 'Incorrect filter of simple ImmutableList'

    assert ImmutableList.of(1, 2, [3, 4]).filter(is_number_even).to_list() == [2], 'Incorrect filter of simple ImmutableList'
    assert ImmutableList.of(1, 2, 3, 4).filter(is_number_even).to_list() == [2, 4], 'Incorrect filter of simple ImmutableList'


# Generated at 2022-06-12 05:08:32.780179
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9) \
        .filter(lambda x: x % 2) \
        .to_list() == [1, 3, 5, 7, 9], 'Odd numbers filter'

    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9) \
        .filter(lambda x: not x % 2) \
        .to_list() == [2, 4, 6, 8], 'Even numbers filter'



# Generated at 2022-06-12 05:08:39.071267
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: True) is None
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1).find(lambda x: x == 2) is None
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) is None


# Generated at 2022-06-12 05:08:43.307091
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList(1, ImmutableList(2), ImmutableList(3))

    assert list.filter(lambda v: v == 1).to_list() == [1]
    assert list.filter(lambda v: v == 2).to_list() == [2]
    assert list.filter(lambda v: v == 3).to_list() == [3]

test_ImmutableList_filter()

# Generated at 2022-06-12 05:08:45.643154
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.of(1, 2, 3)
    assert immutable_list.find(lambda x: x == 3) == 3

# Generated at 2022-06-12 05:08:54.678437
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 3) == ImmutableList(3)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 5) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x > 2) == ImmutableList(3)
    assert ImmutableList