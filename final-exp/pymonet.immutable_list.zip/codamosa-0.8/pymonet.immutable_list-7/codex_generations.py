

# Generated at 2022-06-12 04:59:01.045404
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # GIVEN
    original_list = ImmutableList.of('R', 'M', 'B', 'L', 'M', 'Y', 'B')
    test_cases = [
        # test case
        (
            'returns new ImmutableList with only this elements that passed info argument returns True',
            original_list.filter(lambda x: x != 'M'),
            ImmutableList.of('R', 'B', 'L', 'B'),
        ),
    ]

    for test_case, actual, expected in test_cases:
        # WHEN
        test_case = 'WHEN {} THEN result should be {}'.format(
            test_case,
            expected
        )

        # THEN
        assert actual == expected, test_case

# Generated at 2022-06-12 04:59:04.340232
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # arrange
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3)
    c = ImmutableList.of(1, 2, 4)

    # assert
    assert a == b
    assert a != c


# Generated at 2022-06-12 04:59:05.524718
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (ImmutableList(1) == ImmutableList(1))

# Generated at 2022-06-12 04:59:12.055369
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3) != 1
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)


# Generated at 2022-06-12 04:59:20.227761
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList.empty()

    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x: False) == ImmutableList.empty()

    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: True) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: False) == ImmutableList.empty()

    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 1) == ImmutableList(1)

# Generated at 2022-06-12 04:59:25.438002
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty(), 'Should be equal'
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4), 'Should be equal'
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3), 'Should be equal'
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(3, 2, 1), 'Should be equal'



# Generated at 2022-06-12 04:59:32.975832
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Checks when no element is found
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 3) is None
    assert ImmutableList.empty().find(lambda x: x > 3) is None

    # Checks when element is found
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3

# Generated at 2022-06-12 04:59:36.601387
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()

# Generated at 2022-06-12 04:59:42.340562
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList()
    b = ImmutableList()

    assert a == b

    a = ImmutableList(1, 2, 3)
    b = ImmutableList(1, 2, 3)
    assert a == b

    a = ImmutableList(1, 2, 3)
    b = ImmutableList(1, 2)
    assert not a == b

    assert not a == None


# Generated at 2022-06-12 04:59:47.972373
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 1) == 1

# Generated at 2022-06-12 05:00:00.115698
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    array = ImmutableList.of(1, 2, 3, 4, 5, 6)

    assert array.filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5, 6)


# Generated at 2022-06-12 05:00:05.007709
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    l = l.filter(lambda x: x > 3)
    assert l.to_list() == [4, 5] 
# -*- coding: utf-8 -*-

from typing import TypeVar, Generic, Callable, Optional


T = TypeVar('T')
U = TypeVar('U')



# Generated at 2022-06-12 05:00:11.375535
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

    assert ImmutableList(1) != ImmutableList()
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-12 05:00:16.046768
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4)

    assert ImmutableList.of(1, 2, 3, 4) != ImmutableList.of(5, 6, 7, 8)


# Generated at 2022-06-12 05:00:22.347547
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    number_immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert number_immutable_list.filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))

    string_immutable_list = ImmutableList("Hello", ImmutableList("World", ImmutableList("ImmutableList")))
    assert string_immutable_list.filter(lambda x: x == "World") == ImmutableList("World")

# Generated at 2022-06-12 05:00:32.387488
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    _list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)

    def is_even(value: int) -> bool:
        return value % 2 == 0

    assert _list.filter(is_even).to_list() == [2, 4, 6]
    assert _list.filter(is_even) == ImmutableList(2, ImmutableList(4, ImmutableList(6)))

    def is_positive(value: int) -> bool:
        return value > 0

    assert _list.filter(is_positive).to_list() == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-12 05:00:42.427155
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_to_find = ImmutableList.of(1, 2, 3, 4, 5)
    
    assert list_to_find.find(lambda i: i == 1) == 1
    assert list_to_find.find(lambda i: i == 2) == 2
    assert list_to_find.find(lambda i: i == 3) == 3
    assert list_to_find.find(lambda i: i == 4) == 4
    assert list_to_find.find(lambda i: i == 5) == 5
    assert list_to_find.find(lambda i: i == 0) is None
    assert list_to_find.find(lambda i: i == 6) is None


# Generated at 2022-06-12 05:00:52.082719
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 1) == ImmutableList.of(2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 4) == ImmutableList.of(5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()

# Generated at 2022-06-12 05:00:58.618411
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 4) is None

    assert ImmutableList.of(3, 4, 6, 7)\
        .find(lambda x: x == 4)\
        == 4

    assert ImmutableList.of(3, 4, 6, 7)\
        .find(lambda x: x == 10)\
        == None

    assert ImmutableList.of(3, 4, 6, 7)\
        .find(lambda x: x != 4)\
        == 3

# Generated at 2022-06-12 05:01:01.007399
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(2, 3, 4, 5, 6).filter(lambda x: x > 4) == ImmutableList.of(5, 6)


# Generated at 2022-06-12 05:01:26.753483
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(0, 1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [0, 2, 4]
    assert ImmutableList.of(1).filter(lambda x: x % 2 == 0).to_list() == []
    assert ImmutableList.of(1, 2).filter(lambda x: x % 2 == 0).to_list() == [2]
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0).to_list() == [2]
    assert ImmutableList.of(0, 1, 2).filter(lambda x: x % 2 == 0).to_list() == [0, 2]
    assert ImmutableList.of(0).filter(lambda x: x % 2 == 0).to_list()

# Generated at 2022-06-12 05:01:32.764250
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    l2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    l3 = ImmutableList(1, ImmutableList(2, ImmutableList(4)))

    assert l1 == l1
    assert l1 == l2
    assert not l3 == l1



# Generated at 2022-06-12 05:01:37.057655
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of() == ImmutableList.empty()
    assert ImmutableList.of(
        1,
        2,
        3,
        4
    ).filter(lambda x: x % 2 == 0) == ImmutableList.of(
        2,
        4,
    )


# Generated at 2022-06-12 05:01:39.468086
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(3, 2, 1) == ImmutableList.of(3, 2, 1)

# Generated at 2022-06-12 05:01:45.486330
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x < 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3, lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).filter(lambda x: x < 3) == ImmutableList.of(2)

# Generated at 2022-06-12 05:01:48.211608
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert \
        ImmutableList.of(1, 2).find(lambda x: x > 1) == 2, \
        'Element 1 is larger than 1'

# Generated at 2022-06-12 05:01:57.321713
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    def test_equals_for_equal_lists():
        assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)

    def test_not_equals_for_different_elements_in_lists():
        assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)

    def test_not_equals_for_different_length_lists():
        assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)

"""
Unit test for method __add__ of class ImmutableList
"""

# Generated at 2022-06-12 05:02:04.933863
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2) != Immutable

# Generated at 2022-06-12 05:02:10.492729
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 3)
    assert ImmutableList.empty().append(1) == ImmutableList.empty().append(1)
    assert not ImmutableList.empty().append(1) == ImmutableList.empty()

# Generated at 2022-06-12 05:02:18.701635
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList()
    b = ImmutableList()
    assert a == b
    assert a == ImmutableList()
    assert ImmutableList() == b
    assert ImmutableList() == ImmutableList()

    a = ImmutableList(1)
    b = ImmutableList(1)
    assert a == b
    assert a == ImmutableList(1)
    assert ImmutableList(1) == b
    assert ImmutableList(1) == ImmutableList(1)

    a = ImmutableList(1, ImmutableList(2))
    b = ImmutableList(1, ImmutableList(2))
    assert a == b
    assert a == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == b

# Generated at 2022-06-12 05:02:57.873159
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Unit test for method filter of class ImmutableList
    """
    test_data = ImmutableList.of(1, 2, 3)
    result = test_data.filter(lambda x: x > 1)
    assert result == ImmutableList(2, ImmutableList(3))

    result = test_data.filter(lambda x: x > 100)
    assert result == ImmutableList(is_empty=True)


# Generated at 2022-06-12 05:03:02.964283
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result = ImmutableList.of(
        1, 2, 3, 4
    ).find(lambda x: x > 2)
    assert result == 3, 'ImmutableList find method expected to return 3 but got {}'.format(result)


# Generated at 2022-06-12 05:03:07.785027
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    lst = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    lst2 = lst.filter(lambda x: x > 3)
    assert lst2 == ImmutableList.of(4, 5, 6, 7)



# Generated at 2022-06-12 05:03:14.789025
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) != ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(1) != 1
    assert ImmutableList.of(1, 2, 3) != 1
    assert ImmutableList.empty() != 1
    assert ImmutableList.of(1) != 1


# Generated at 2022-06-12 05:03:21.548542
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    immutable1 = ImmutableList.of(1, 2, 3)
    immutable2 = ImmutableList.of(1, 2, 3)
    immutable3 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable1 == immutable2
    assert not immutable1 == immutable3
    assert not immutable1 == 1
    assert not immutable1 == 'ImmutableList'
    assert not immutable1 == True
    assert not immutable1 == None
test_ImmutableList___eq__()

# Generated at 2022-06-12 05:03:27.955127
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(None, ImmutableList(5, ImmutableList(6), False), False), False), False), False) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(None, ImmutableList(5, ImmutableList(6), False), False), False), False), False)

# Generated at 2022-06-12 05:03:34.291610
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(1, 2, 3)
    list_2 = ImmutableList.of(1, 2, 3)
    list_3 = ImmutableList.of(1, 2, 3, 4)
    list_4 = ImmutableList.of('a', 'b', 'c')

    assert list_1 == list_2
    assert not list_3 == list_2
    assert not list_1 == list_4


test_ImmutableList___eq__()

# Generated at 2022-06-12 05:03:42.846654
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() != ImmutableList.of(1)
    assert ImmutableList.empty() != []
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1) != 2
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 3)

# Generated at 2022-06-12 05:03:46.292302
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(11, 12, 13)
    list_2 = ImmutableList.of(11, 12, 13)
    assert list_1 == list_2



# Generated at 2022-06-12 05:03:54.619596
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList(1, ImmutableList(2), ImmutableList(3))
    list2 = list1.filter(lambda x : True if x > 1 else False)
    list3 = list1.filter(lambda x : True if x > 3 else False)
    list4 = list1.filter(lambda x : True if x < 1 else False)
    assert list2.to_list() == [2, 3]
    assert list3.is_empty == True
    assert list4.is_empty == True


# Generated at 2022-06-12 05:05:53.199228
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: True) == ImmutableList(is_empty=True)
    assert ImmutableList(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList(2)


# Generated at 2022-06-12 05:05:59.753069
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    
    assert ImmutableList.empty() != ''
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) != [1, 2]
    
    

# Generated at 2022-06-12 05:06:06.043674
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    a = ImmutableList(0)
    b = ImmutableList(1)
    c = ImmutableList(1)
    d = ImmutableList(0, ImmutableList(1), True)

    # Act
    result_1 = (a == b)
    result_2 = (b == c)
    result_3 = (d == d)

    # Assert
    assert result_1 == False
    assert result_2 == True
    assert result_3 == True


# Generated at 2022-06-12 05:06:08.596307
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x:True) is None
    assert ImmutableList.of(1).find(lambda x:False) is None
    assert ImmutableList.of(1,2).find(lambda x:True) == 1
    assert ImmutableList.of(1,2,3,4,5,6,7).find(lambda x: x>4) == 5


# Generated at 2022-06-12 05:06:10.677519
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    result = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    result = result.filter(lambda x: x % 3 == 0)
    assert result.to_list() == [0, 3, 6, 9]


# Generated at 2022-06-12 05:06:13.368642
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2), True) == ImmutableList(1, ImmutableList(2), True)

# Generated at 2022-06-12 05:06:18.392131
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    x = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    result = x.filter(lambda x: x % 2 == 0)

    assert result == ImmutableList.of(2, 4, 6)



# Generated at 2022-06-12 05:06:21.932588
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    b = a.filter(lambda x: x % 2 == 0)
    assert(b.to_list() == [2])

# Generated at 2022-06-12 05:06:27.425370
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()\
        and ImmutableList.of(1) == ImmutableList.of(1)\
        and ImmutableList.of(1, 2) == ImmutableList.of(1, 2), \
        "ImmutableList.__eq__() has returned unexpected result"

# Generated at 2022-06-12 05:06:31.050969
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_to_find = ImmutableList.of(1, 2, 3)

    assert list_to_find.find(lambda x: x == 2) == 2
    assert list_to_find.find(lambda x: x == 4) is None

