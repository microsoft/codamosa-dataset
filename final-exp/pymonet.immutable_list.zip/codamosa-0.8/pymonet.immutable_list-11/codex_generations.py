

# Generated at 2022-06-12 04:58:58.142195
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0)
    assert l.to_list() == [2]

# Generated at 2022-06-12 04:59:05.769730
# Unit test for method __eq__ of class ImmutableList

# Generated at 2022-06-12 04:59:09.497395
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None


# Generated at 2022-06-12 04:59:11.061579
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    # Act
    result = test_list.find(lambda x: x > 2)
    # Assert
    assert result == 3

# Generated at 2022-06-12 04:59:19.605940
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(ImmutableList()) == True
    assert ImmutableList(is_empty=True).__eq__(ImmutableList(is_empty=True)) == True
    assert ImmutableList(1).__eq__(ImmutableList(1)) == True
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == True
    assert ImmutableList().__eq__(ImmutableList(1)) == False
    assert ImmutableList().__eq__('ImmutableList') == False
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList(1, ImmutableList(2))) == False

# Generated at 2022-06-12 04:59:28.833924
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of() == ImmutableList.of()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)

    # None value
    assert ImmutableList.of() == ImmutableList.empty()



# Generated at 2022-06-12 04:59:30.313446
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    a = ImmutableList.empty()
    b = ImmutableList.empty()

    assert a == b

# Generated at 2022-06-12 04:59:36.824272
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3, 4) == False


# Generated at 2022-06-12 04:59:41.793133
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(1, 2, 3, 4)
    list_2 = ImmutableList.of(1, 2, 3, 4)
    list_3 = ImmutableList.of(2, 2, 3, 4)

    assert list_1 == list_2
    assert list_1 != list_3


# Generated at 2022-06-12 04:59:43.531444
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2

# Generated at 2022-06-12 04:59:51.344752
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(5, 4, 3, 2, 1).find(lambda x: x == 3) == 3
    assert ImmutableList.of(5, 4, 3, 2, 1).find(lambda x: x > 9) is None



# Generated at 2022-06-12 05:00:02.129832
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: True) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x != 1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x != 2) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x != 1 and x != 2) == ImmutableList(is_empty=True)



# Generated at 2022-06-12 05:00:06.655376
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Set up data before running a test
    lst = ImmutableList.of(1, 2, 3, 4, 5, 6)
    # Execute method to be tested
    filtered_lst = lst.filter(lambda elem: elem % 2 == 0)
    # Assert on results
    assert filtered_lst == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-12 05:00:11.223949
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None
    ImmutableList.of(1, 2, 3).find(lambda x: x == 'foo') == None
    ImmutableList.empty().find(lambda x: x == 'foo') == None

# Generated at 2022-06-12 05:00:17.518783
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    lst = ImmutableList.of(1, 2, 3)

    assert(lst.find(lambda x: x > 2) == 3)
    assert(lst.find(lambda x: x > 4) == None)
    assert(ImmutableList.empty().find(lambda x: x > 2) == None)

# Generated at 2022-06-12 05:00:20.529098
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) == None

# Generated at 2022-06-12 05:00:29.102943
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 1) == None
    assert ImmutableList.of(1,2,3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1,2,3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1,2,3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1,2,3).find(lambda x: x == 4) == None

# Generated at 2022-06-12 05:00:32.324560
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3, 4, 5)

    assert list.filter(lambda value: value % 2 == 0) == ImmutableList.of(2, 4)

# Generated at 2022-06-12 05:00:43.211072
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    #Test case 1
    list = ImmutableList.of(1, 2, 3, 4)
    new_list = list.filter((lambda x: x % 2 == 0))
    assert new_list.to_list() == [2, 4]

    #Test case 2
    list = ImmutableList.of(1, 2, 3, 4)
    new_list = list.filter((lambda x: x % 2 == 1))
    assert new_list.to_list() == [1, 3]

    #Test case 3
    list = ImmutableList.empty()
    new_list = list.filter((lambda x: x % 2 == 0))
    assert new_list.to_list() == []

    print("Passed test for method filter of class ImmutableList")


# Generated at 2022-06-12 05:00:49.707497
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)

    def is_even(el: int) -> bool:
        """
        Returns True if argument is an even number otherwise False

        :param el: number to check
        :type el: int
        :returns: bool
        """
        return el % 2 == 0

    assert my_list.filter(is_even) == ImmutableList.of(2, 4, 6, 8)

# Generated at 2022-06-12 05:01:02.620846
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    def is_even(n): return n % 2 == 0

    # Act
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    filtered_list = list_.filter(is_even)

    # Assert
    assert len(filtered_list) == 4
    assert filtered_list.find(is_even) == 2



# Generated at 2022-06-12 05:01:13.120177
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(0).find(lambda x,: x == 0) == 0
    assert ImmutableList.of(1, 2, 3).find(lambda x,: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x,: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x,: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x,: x > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x,: x < 2) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x,: x > 4) is None


# Generated at 2022-06-12 05:01:18.739909
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3, 4)
    filtered_list = list.filter(lambda el: el > 2)
    assert filtered_list == ImmutableList.of(3, 4)
    assert list == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-12 05:01:26.076192
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    empty_list = ImmutableList.empty()
    assert empty_list.filter(lambda x: x % 2 == 0) == ImmutableList.empty()

    list_to_filter = ImmutableList.of(1, 2, 3, 4)
    even_numbers_init_list = [2, 4]
    even_numbers_from_filter = list_to_filter.filter(lambda x: x % 2 == 0).to_list()
    assert even_numbers_init_list == even_numbers_from_filter

test_ImmutableList_filter()


# Generated at 2022-06-12 05:01:34.713279
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x).is_empty
    assert ImmutableList(1).filter(lambda x: x > 1).is_empty
    assert ImmutableList(1).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 2) == ImmutableList(3)
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 2) == ImmutableList(1)
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 3) == ImmutableList(1, 2)

# Generated at 2022-06-12 05:01:43.596574
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test case 1
    items = ImmutableList.of(5, 4, 3, 2, 1)
    assert items.find(lambda x: x > 3) == 4

    # Test case 2
    items = ImmutableList.of(5, 4, 3, 2, 1)
    assert items.find(lambda x: x > 4) == 5

    # Test case 3
    items = ImmutableList.of(5, 4, 3, 2, 1)
    assert items.find(lambda x: x > 5) is None

    # Test case 4
    items = ImmutableList.of(5, 4, 3, 2, 1)
    assert items.find(lambda x: x > 0) == 1

# Generated at 2022-06-12 05:01:46.791812
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def is_even(x):
        return x % 2 == 0

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(is_even).__eq__(ImmutableList(2, ImmutableList(4)))

# Generated at 2022-06-12 05:01:49.638989
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    maybe = ImmutableList.of('a', 'b', 'c')
    assert maybe.find(lambda x: x == 'b') == 'b'



# Generated at 2022-06-12 05:01:56.849304
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1).find(lambda x: x == 0) is None
    assert ImmutableList.empty().find(lambda x: False) is None



# Generated at 2022-06-12 05:01:58.124198
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 'x', 2, 34, 'ee')
    assert l.filter(lambda el: not isinstance(el, int)) == ImmutableList.of('x', 'ee')



# Generated at 2022-06-12 05:02:10.615196
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    my_immutable_list = ImmutableList.of("head", "tail")
    assert my_immutable_list.find(lambda x: x == 'head') == 'head'
    assert my_immutable_list.find(lambda x: x == 'tail') == 'tail'
    assert my_immutable_list.find(lambda x: x == 'not_exist') is None


# Generated at 2022-06-12 05:02:14.166308
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    source = ImmutableList.of(1, 2, 3, 4, 5)
    assert source.find(lambda value: value == 2) == 2
    assert source.find(lambda value: value == 7) is None



# Generated at 2022-06-12 05:02:18.636505
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case with empty list
    il = ImmutableList.empty()
    assert il.to_list() == []
    assert il == il.filter(lambda x: x > 1)

    # Case with elements
    il = ImmutableList.of(1, 2, 3, 4, 5)
    assert il.to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(2, 4) == il.filter(lambda x: x % 2 == 0)



# Generated at 2022-06-12 05:02:24.344364
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2).filter(lambda v: v > 1).to_list() == [2]
    assert ImmutableList.of(1, 2, 3).filter(lambda v: v > 2).to_list() == [3]
    assert ImmutableList.of(1, 2, 3).filter(lambda v: v > 3).to_list() == []



# Generated at 2022-06-12 05:02:32.523455
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 3) == 3 # pragma: no cover
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None
    assert ImmutableList(is_empty=True).find(lambda x: x == 4) is None # pragma: no cover
    assert ImmutableList().find(lambda x: x == 4) is None


# Generated at 2022-06-12 05:02:38.816020
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given:

    # When:
    lst = ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 3 == 0)

    # Then:
    assert lst.head == 3
    assert lst.tail.head == None
    assert lst.tail.tail == None
    assert not lst.is_empty

# Generated at 2022-06-12 05:02:45.872689
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    books = ImmutableList.of(
        {'title': 'Immutable', 'author': 'Somebody'},
        {'title': 'Maybe', 'author': 'Nobody'},
        {'title': 'Monad', 'author': 'Anybody'}
    )

    found = books.find(lambda book: book['author'] == 'Nobody')

    assert len(found) == 2
    assert found['title'] == 'Maybe'
    assert found['author'] == 'Nobody'



# Generated at 2022-06-12 05:02:51.789643
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    sut = ImmutableList.of(1, 2, 3, 4, 5)

    def positive(x):
        return x > 0

    result = sut.filter(positive)

    assert result == ImmutableList.of(1, 2, 3, 4, 5)

    def negative(x):
        return x < 0

    result = sut.filter(negative)

    assert result == ImmutableList.empty()



# Generated at 2022-06-12 05:02:57.091702
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f').find(lambda x: len(x) == 3) == 'f'

test_ImmutableList_find()

# Generated at 2022-06-12 05:03:05.271578
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert my_list.to_list() == [1, 2, 3, 4, 5, 6]
    assert my_list.filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]
    assert my_list.filter(lambda x: x % 2 != 0).to_list() == [1, 3, 5]


# Generated at 2022-06-12 05:03:23.566293
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1,2,3,4,5,6)
    list__ = list_.filter(lambda x: x > 3)
    assert list__ == ImmutableList.of(4, 5, 6)


test_ImmutableList_filter()


# Generated at 2022-06-12 05:03:31.628956
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1)
    assert list1.filter(lambda el: el % 2 == 0) == ImmutableList.empty()

    list2 = ImmutableList.of(1, 2, 3, 4)
    assert list2.filter(lambda el: el % 2 == 0) == ImmutableList.of(2, 4)

    list3 = ImmutableList.of(1, 2, 3, 4, 5)
    assert list3.filter(lambda el: el % 2 == 0) == ImmutableList.of(2, 4)


# Generated at 2022-06-12 05:03:38.006905
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # check if it finds element in list with one element
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1).find(lambda x: x == 2) is None

    # check if it finds element in list with multiple elements
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None

   

# Generated at 2022-06-12 05:03:42.498119
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_ints = ImmutableList.of(1,2,3,4,5,6)
    list_of_evens = list_of_ints.filter(lambda x: x % 2 == 0)

    assert list_of_evens.head == 2
    assert list_of_evens.tail.head == 4
    assert list_of_evens.tail.tail.head == 6
    assert not list_of_evens.tail.tail.tail


# Generated at 2022-06-12 05:03:45.439840
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x >= 3) == ImmutableList.of(3, 4, 5)



# Generated at 2022-06-12 05:03:50.145949
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    test_list = ImmutableList.of(1, 2, 3, 4, 5).filter(lambda s: s % 2 == 0)

    # Act
    result = test_list.to_list()

    # Assert
    assert result == [2, 4]


# Generated at 2022-06-12 05:03:57.499897
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    fn = lambda x: x % 2 == 0

    assert ImmutableList.of(1, 2, 3, 4, 5).filter(fn).to_list() == [2, 4]
    assert ImmutableList.of(2, 4, 6, 8, 10).filter(fn).to_list() == [2, 4, 6, 8, 10]
    assert ImmutableList.of(1, 3, 5, 7, 9).filter(fn).to_list() == []

# Generated at 2022-06-12 05:04:05.081790
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    first_immutable_list = ImmutableList.empty()
    second_immutable_list = ImmutableList.of(1)
    third_immutable_list = ImmutableList.of(1,2,3,4)

    assert first_immutable_list.find(lambda x: x == 1) == None
    assert second_immutable_list.find(lambda x: x == 1) == 1
    assert third_immutable_list.find(lambda x: x == 2) == 2

test_ImmutableList_find()

# Generated at 2022-06-12 05:04:09.367927
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).find(lambda x: x == 6) == 6
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).find(lambda x: x == 10) == None
    assert ImmutableList.empty().find(lambda x: x == 10) == None

# Generated at 2022-06-12 05:04:13.600936
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    filtered = l.filter(lambda x: x % 2 == 0)

    assert filtered.to_list() == [2, 4]

# Generated at 2022-06-12 05:04:44.323177
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda v: v % 2 == 0) == 2



# Generated at 2022-06-12 05:04:48.279711
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l1 = ImmutableList(1, ImmutableList(2, ImmutableList(42, ImmutableList(4))))
    l2 = l1.filter(lambda x: x > 2)
    assert l2 == ImmutableList(42, ImmutableList(4))

# Generated at 2022-06-12 05:04:51.347355
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def fn(i):
        return i % 2 == 0

    assert ImmutableList.of(1, 2, 3, 4).filter(fn).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(fn).is_empty is False


# Generated at 2022-06-12 05:04:55.044984
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda val: val % 2)\
        .to_list() == [1, 3]

test_ImmutableList_filter()

# Generated at 2022-06-12 05:04:59.032745
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6) \
        .filter(lambda x: x % 2 == 0) \
        .to_list() == [2, 4, 6]



# Generated at 2022-06-12 05:05:05.106437
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    is_even = lambda x: x % 2 == 0

    assert ImmutableList.of(1, 2, 3, 4).filter(is_even).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(is_even).to_list() != [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(is_even).to_list() != [2, 3]



# Generated at 2022-06-12 05:05:16.003785
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).filter(lambda x: x%2 == 1).to_list()
    assert [2, 4, 6] == ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x%2 == 0).to_list()
    assert [] == ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x%2 == 3).to_list() # empty list
    assert [1] == ImmutableList.of(1).filter(lambda x: x%2 == 1).to_list() # one element list
    assert [] == ImmutableList.of(2).filter(lambda x: x%2 == 1).to_list() # empty list with one element
    assert [3] == Immutable

# Generated at 2022-06-12 05:05:23.138079
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 'hello') is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 10) is None



# Generated at 2022-06-12 05:05:30.344541
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3, 4, 5)

    l1 = l.filter(lambda a: a % 2 != 0)
    assert l1 == ImmutableList.of(1, 3, 5)

    l2 = l.filter(lambda a: a % 2 == 0)
    assert l2 == ImmutableList.of(2, 4)
    
    l3 = l.filter(lambda a: a % 3 == 0)
    assert l3 == ImmutableList.of(3)
    
    l4 = l.filter(lambda a: a % 6 == 0)
    assert l4 == ImmutableList.empty()


# Generated at 2022-06-12 05:05:33.559255
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1, 2, 3, 4)

    assert l.find(lambda x: x == 4) == 4
    assert l.find(lambda x: x == 5) is None


# Generated at 2022-06-12 05:06:44.261350
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.find(lambda x: x > 2) == 3
    assert list_.find(lambda x: x < 1) is None


# Generated at 2022-06-12 05:06:51.290423
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 1).filter(lambda x: x == 1) == ImmutableList.of(1, 1)


# Generated at 2022-06-12 05:07:01.855924
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    
    assert ImmutableList.of(10, 20, 30).find(lambda x: x > 10) == 20
    assert ImmutableList.of(10, 20, 30, 4, 5, 6).find(lambda x: x > 10) == 20
    assert ImmutableList.of(10, 10, 20, 30, 4, 5, 6).find(lambda x: x > 10) == 20
    assert ImmutableList.of(10, 10, 20, 30, 4, 5, 6).find(lambda x: x > 20) == 30
    assert ImmutableList.of(10, 10, 20, 30, 40, 50, 60).find(lambda x: x > 40) == 50

    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 10) == None

# Generated at 2022-06-12 05:07:04.294896
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # arrange
    l = ImmutableList.of(10, 20, 30, 40)

    # act
    r = l.find(lambda x: x > 20)

    # assert
    assert r == 30

# Generated at 2022-06-12 05:07:10.317026
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result = ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x < 5)
    assert result is not None, 'ImmutableList.find must not return None'
    assert result == 1, 'ImmutableList.find must return first element that passed through predicate'

    result = ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x < 0)
    assert result is None, 'ImmutableList.find must return None when all elements not passed through predicate'

test_ImmutableList_find()


# Generated at 2022-06-12 05:07:19.503168
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1,2,4,5,7,8,9)
    assert a.filter(lambda x: x > 6).to_list() == [7,8,9]
    assert a.filter(lambda x: x % 2 == 0).to_list() == [2,4,8]
    assert a.filter(lambda x: x % 3 == 0).to_list() == []
    assert a.filter(lambda x: x > 10).to_list() == []
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-12 05:07:24.989529
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    Unit test for method find of class ImmutableList
    """
    list_1 = ImmutableList.of(
        1,
        2,
        4
    )

    assert list_1.find(lambda x: x == 1) == 1
    assert list_1.find(lambda x: x == 2) == 2
    assert list_1.find(lambda x: x == 4) == 4
    assert list_1.find(lambda x: x == 3) is None


# Generated at 2022-06-12 05:07:30.751409
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 4).to_list() == [4]
    assert ImmutableList.of().filter(lambda x: x % 2 == 0).to_list() == []
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 6).to_list() == []



# Generated at 2022-06-12 05:07:36.445057
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(is_empty=True).filter(lambda x: x) == ImmutableList(is_empty=True)
    assert ImmutableList(is_empty=True).filter(lambda x: True) == ImmutableList(is_empty=True)
    assert ImmutableList(0, ImmutableList(1)).filter(lambda x: x) == ImmutableList(1)
    assert ImmutableList(0, ImmutableList(1)).filter(lambda x: True) == ImmutableList(0, ImmutableList(1)) 

# Generated at 2022-06-12 05:07:44.845195
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]
    assert ImmutableList.of(1, 3, 5, 7).filter(lambda x: x % 2 == 0).to_list()