

# Generated at 2022-06-12 04:59:01.252332
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5)



# Generated at 2022-06-12 04:59:07.474417
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty_empty_eq = ImmutableList.empty() == ImmutableList.empty()
    empty_list_eq = ImmutableList.empty() == ImmutableList.of(1, 2, 3)
    list_empty_eq = ImmutableList.of(1, 2, 3) == ImmutableList.empty()
    list_list_eq = ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    list_not_eq_1 = ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2)
    list_not_eq_2 = ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 4)
    list_not_eq_3 = ImmutableList.of(1, 2, 3) == Imm

# Generated at 2022-06-12 04:59:09.251369
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 1) == ImmutableList.of(1, 1)


# Generated at 2022-06-12 04:59:13.455506
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    ints = ImmutableList.of(1, 2, 3, 4, 5)
    ints_ = ImmutableList.of(1, 2, 3, 4, 5)

    assert ints == ints_



# Generated at 2022-06-12 04:59:17.324319
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert(
        ImmutableList.of(1, 2, 3).reduce(lambda x, y: x+y, 0) == 6
    )
    assert(
        ImmutableList.empty().reduce(lambda x, y: x+y, 0) == 0
    )
test_ImmutableList_reduce()

# Generated at 2022-06-12 04:59:24.570358
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list3 = ImmutableList(1, ImmutableList(2, ImmutableList(4)))

    assert list1 is not list2
    assert list1.__eq__(None) is False
    assert list1.__eq__(list2) is True
    assert list1.__eq__(list3) is False


# Generated at 2022-06-12 04:59:26.249253
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-12 04:59:29.729560
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, x: a + x, 0) == 6
    assert ImmutableList.empty().reduce(lambda a, x: a + x, 0) == 0
test_ImmutableList_reduce()

# Generated at 2022-06-12 04:59:31.790786
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda v: v % 2 == 0).to_list() == [2, 4]

# Generated at 2022-06-12 04:59:35.279113
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1) != ImmutableList.of(1, 2)


# Generated at 2022-06-12 04:59:48.147965
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(5,2,1,3) == ImmutableList(5,ImmutableList(2,ImmutableList(1,ImmutableList(3))))
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList.of(5,2,1,3).filter(lambda x: x>1) == ImmutableList.of(5,2,3)
    assert ImmutableList.of(5,2,1,3).filter(lambda x: x<1) == ImmutableList.empty()
    assert ImmutableList.of(5,2,1,3).filter(lambda x: x>3) == ImmutableList.of(5)

# Generated at 2022-06-12 04:59:50.918920
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of("Hello", "World", "!")
    assert list_.find(lambda x : x == "!") == "!"



# Generated at 2022-06-12 04:59:57.176752
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))

    assert test_list.filter(lambda x: x%2 == 0) == ImmutableList(2, ImmutableList(4, ImmutableList(6)))

test_ImmutableList_filter()

# Generated at 2022-06-12 05:00:06.619995
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    from pytest import raises
    from hypothesis import given
    from hypothesis.strategies import integers

    # New empty list
    assert ImmutableList.empty().filter(
        lambda x: x % 2 == 0
    ).to_list() == []

    # Sadly I can't test `==` object as it's not hashable,
    # so I will test it using fractions.

# Generated at 2022-06-12 05:00:10.476977
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(
        lambda x: x > 2
    ) == ImmutableList.of(3, 4)

    assert ImmutableList.of(1, 2, 3, 4).filter(
        lambda x: x > 5
    ) == ImmutableList.empty()


# Generated at 2022-06-12 05:00:21.428902
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(0, 1, 2, 3, 4, 5)

    even = lambda x: x % 2 == 0

    list = list.filter(even)
    assert list.head == 0
    assert list.tail.head == 2
    assert list.tail.tail.head == 4

    assert list.find(even) == 0

    list = list.filter(even)
    assert list.head == 0
    assert list.tail.head == 2
    assert list.tail.tail.head == 4

    list = list.map(lambda x: x + 2)

    assert list.head == 2
    assert list.tail.head == 4
    assert list.tail.tail.head == 6

    list = list.map(lambda x: x + 2)

    assert list.head == 4

# Generated at 2022-06-12 05:00:29.702686
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_list = ImmutableList.empty()
    list_without_match = empty_list.append(1).append(2).append(3)
    list_with_match = list_without_match.append(4).append(5).append(6)

    assert empty_list.find(lambda a: a > 1) is None
    assert list_without_match.find(lambda a: a > 1) is None
    assert list_with_match.find(lambda a: a > 1) == 2

test_ImmutableList_find()

# Generated at 2022-06-12 05:00:35.248616
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    items = ImmutableList.of(0, 1, 2, 3)

    assert items.find(lambda it: it == 0) == 0
    assert items.find(lambda it: it == 1) == 1
    assert items.find(lambda it: it == 2) == 2
    assert items.find(lambda it: it == 3) == 3
    assert items.find(lambda it: it == 4) is None



# Generated at 2022-06-12 05:00:42.380662
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    res = test_list.find(lambda x: x > 2)
    assert(res == 3)
    res = test_list.find(lambda x: x > 100)
    assert(res == None)
    res = test_list.find(lambda x: x < 0)
    assert(res == None)


# Generated at 2022-06-12 05:00:52.034525
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Empty list
    assert ImmutableList.empty().find(lambda x: True) is None
    # One element and not found
    assert ImmutableList.of('a').find(lambda x: x == 'b') is None
    # One element and found
    assert ImmutableList.of('a').find(lambda x: x == 'a') == 'a'
    # Many elements and not found
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'd') is None
    # Many elements and multiple found
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: True) == 'a'
    # Many elements and multiple found

# Generated at 2022-06-12 05:01:03.457352
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    ).filter(lambda i: i % 2 == 0).to_list() == [2, 4, 6, 8, 10]

# Generated at 2022-06-12 05:01:09.608819
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None

# Generated at 2022-06-12 05:01:16.103292
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(4, 5, 6).find(lambda x: x % 2 == 0) is not None
    assert ImmutableList.of(4, 5, 6).find(lambda x: x % 2 == 0) == 4
    assert ImmutableList.of(4, 5, 6).find(lambda x: x % 2 == 0) != 5
    assert ImmutableList.empty().find(lambda x: x % 2 == 0) is None



# Generated at 2022-06-12 05:01:18.690713
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6)

    assert list_.find(lambda x: x % 2 == 0) == 2


# Generated at 2022-06-12 05:01:20.609552
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList([1, 2, 3, 4]).find(lambda x: x == 3) == 3


# Generated at 2022-06-12 05:01:31.233097
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # example 1
    x = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert x.filter(lambda item: item > 2).to_list() == [3, 4]

    # example 2
    y = ImmutableList(3, ImmutableList(5, ImmutableList(7, ImmutableList(8, ImmutableList(9, ImmutableList(10))))))

    assert y.filter(lambda item: item > 7).to_list() == [8, 9, 10]

    # example 3
    assert x.filter(lambda item: item == 2).to_list() == [2]

    # example 4
    assert x.filter(lambda item: item == 5).to_list() == []

    # example 5

# Generated at 2022-06-12 05:01:41.850100
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    lst = ImmutableList.of(1, 2, 3, 4, 5)

    assert lst.filter(lambda item: item % 2 == 0).to_list() == [2, 4]
    assert lst.filter(lambda item: item % 2 == 1).to_list() == [1, 3, 5]
    assert lst.filter(lambda item: item % 2 == 1).head == 1
    assert lst.filter(lambda item: item % 2 == 1).tail.head == 3
    assert lst.filter(lambda item: item % 2 == 1).tail.tail.head == 5
    assert lst.filter(lambda item: item % 2 == 1).tail.tail.tail is None
    assert ImmutableList.empty().filter(lambda item: item % 2 == 1).is_empty is True


# Generated at 2022-06-12 05:01:45.013014
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3,4,5,6,7,8,9,10).filter(lambda x: x % 2 == 0) == \
           ImmutableList.of(2,4,6,8,10)


# Generated at 2022-06-12 05:01:52.716358
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Test for ImmutableList, method filter
    """
    assert ImmutableList().filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList(1, 2, 3).filter(lambda x: True) == ImmutableList(1, 2, 3)
    assert ImmutableList(1, 2, 3).filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList(1, 2, 3).filter(lambda x: x == 3) == ImmutableList(3)

# Generated at 2022-06-12 05:02:02.470553
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x > 0) == ImmutableList({}, True)
    assert ImmutableList(1).filter(lambda x: x > 0) == ImmutableList(1)
    assert ImmutableList(0).filter(lambda x: x > 0) == ImmutableList({}, True)
    assert ImmutableList(
        2, ImmutableList(3, ImmutableList(4))
    ).filter(lambda x: x > 2) == ImmutableList(
        3, ImmutableList(4)
    )
    assert ImmutableList(1, ImmutableList(2, ImmutableList(4, ImmutableList(5)))).filter(
        lambda x: x % 2 == 0
    ) == ImmutableList(2, ImmutableList(4))

# Generated at 2022-06-12 05:02:19.176425
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda x: x > 5) == ImmutableList.of(6, 7)

# Generated at 2022-06-12 05:02:24.918084
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    maybe_a = ImmutableList.of('A')
    maybe_b = ImmutableList.of('A', 'B')

    assert None is maybe_a.find(lambda x: x == 'C')
    assert 'A' == maybe_a.find(lambda x: x == 'A')
    assert 'B' == maybe_b.find(lambda x: x == 'B')



# Generated at 2022-06-12 05:02:28.932700
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0).to_list() == []


# Generated at 2022-06-12 05:02:32.731610
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    result = ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda i: i % 2 == 0)
    expected_result = ImmutableList.of(2, 4)
    assert result == expected_result, 'wrong result in ImmutableList.filter'

# Generated at 2022-06-12 05:02:37.161926
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList(1, ImmutableList(2, ImmutableList(3)), False)

    result = list.find(lambda x: x == 2)

    assert result == 2


# Generated at 2022-06-12 05:02:40.944945
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(0, 1, 2, 3, 4, 5)
    assert list.find(lambda x: x % 2 == 1) == 1
    assert list.find(lambda x: x % 2 == 0) == 0

test_ImmutableList_find()

# Generated at 2022-06-12 05:02:49.610211
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ([2, 3, 4] == ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0).to_list()), 'Should return new ImmutableList with only this elements that passed info argument returns True'
    assert ([1, 2, 3, 4] == ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 5).to_list()), 'Should return new ImmutableList with only this elements that passed info argument returns True'
    assert ([] == ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 5).to_list()), 'Should return new ImmutableList with only this elements that passed info argument returns True'

# Generated at 2022-06-12 05:02:54.022355
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of('first', 'second', 'third')
    filtered_list = test_list.filter(lambda x: x.startswith('f'))

    assert filtered_list == ImmutableList.of('first', 'second')

# Generated at 2022-06-12 05:03:01.799628
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda i: i == 1) == 1
    assert ImmutableList.of(1, 2).find(lambda i: i == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda i: i == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda i: i == 5) == 5
    assert ImmutableList.of(2, 3, 4, 5).find(lambda i: i == 1) is None
    assert ImmutableList.of(2, 3, 4, 5).find(lambda i: i == 6) is None
    assert ImmutableList.of(2, 3, 4, 5).find(lambda i: i > 3) == 4

# Generated at 2022-06-12 05:03:04.570593
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3


# Generated at 2022-06-12 05:03:42.298579
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3)
    assert test_list.find(lambda x: x == 1) == 1, 'test_ImmutableList_find fail'
    assert test_list.find(lambda x: x == 2) == 2, 'test_ImmutableList_find fail'
    assert test_list.find(lambda x: x == 3) == 3, 'test_ImmutableList_find fail'
    assert test_list.find(lambda x: x == 4) == None, 'test_ImmutableList_find fail'

# Generated at 2022-06-12 05:03:48.682509
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(3, ImmutableList(4, ImmutableList(5))).find(lambda x: x > 4) == 5
    assert ImmutableList(3, ImmutableList(4, ImmutableList(5))).find(lambda x: x > 6) == None
    assert ImmutableList(3, ImmutableList(4, ImmutableList(5))).find(lambda x: x > 3) == 4


# Generated at 2022-06-12 05:03:54.958250
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # ARRANGE & ACT
    list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    result = list.filter(lambda x: x % 2 == 0)

    # ASSERT
    assert isinstance(result, ImmutableList)
    assert result == ImmutableList.of(2, 4, 6, 8)
    assert len(result) == 4


# Generated at 2022-06-12 05:04:00.945962
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # test 1
    assert ImmutableList.empty().filter(lambda e: True) == ImmutableList.empty()
    # test 2
    assert ImmutableList.of(1, 10, 12, 13).filter(lambda e: e % 2 == 0) == ImmutableList.of(10, 12)
    # test 3
    assert ImmutableList.of(-2, -2, -2, -2).filter(lambda e: e >= 0) == ImmutableList.empty()
# tests
test_ImmutableList_filter()

# Generated at 2022-06-12 05:04:06.433439
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    x = [1, 2, 3, 4, 5]
    y = ImmutableList.of(x[0], *x[1:])

    assert y.find(lambda elem: elem > 3) == 4
    assert y.find(lambda elem: elem < 0) is None
    assert y.find(lambda elem: elem == 100) is None


# Generated at 2022-06-12 05:04:17.861074
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():  # pragma: no cover
    l_0 = ImmutableList(0)
    l_0_0 = ImmutableList(0, l_0)
    l_0_1 = ImmutableList(1, l_0_0)

    l_11 = ImmutableList(1, ImmutableList(1), l_0_0)

    l_11_11 = ImmutableList(1, l_11, l_0_0)

    l_1_2_3 = ImmutableList.of(1, 2, 3, 4)

    assert l_0.find(lambda x: x) == 0

    assert l_0_1.find(lambda x: x) == 1
    assert l_0_1.find(lambda x: x % 2) == 1


# Generated at 2022-06-12 05:04:23.015057
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)


# Generated at 2022-06-12 05:04:27.222316
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    i_list = ImmutableList.of(2, 3, 4, 5)

    assert i_list.find(lambda x: x % 2 == 0) == 2
    assert i_list.find(lambda x: x > 30) is None
    assert i_list.find(lambda x: x == 4) == 4

# Generated at 2022-06-12 05:04:36.582922
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test if empty list is returned on filter empty ImmutableList
    assert ImmutableList().filter(lambda x: x) == ImmutableList.empty()

    # Test if empty list is returned on filter ImmutableList if all elements
    # in list returns False
    assert ImmutableList.of(0, 0, 0).filter(lambda x: x) == ImmutableList.empty()

    # Test if filter ImmutableList with all elements that returns True
    # returns list with all elements
    assert ImmutableList.of(0, 1, 2).filter(lambda x: x) == ImmutableList.of(1, 2)

    # Test if filter ImmutableList with all elements that returns True
    # returns list with all elements

# Generated at 2022-06-12 05:04:42.119081
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of().filter(lambda x: x) == ImmutableList.of()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x <= 4) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-12 05:06:11.353100
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert isinstance(ImmutableList.empty(), ImmutableList)
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-12 05:06:15.054551
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda element: element > 1) == 2

    assert ImmutableList.of(1, 2, 3).find(lambda element: element > 5) is None


# Generated at 2022-06-12 05:06:26.734924
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Assert that returns empty list when list empty and condition is not met
    assert ImmutableList.empty().filter(lambda x: x == 1) == ImmutableList.empty()

    # Assert that returns empty list when list empty and condition is met
    assert ImmutableList.empty().filter(lambda x: x == 1) == ImmutableList(is_empty=True)

    # Assert that returns list with all elements starting with 'H'
    assert ImmutableList.of('Hello', 'Holi', 'Hola', 'Ciao').filter(
        lambda x: x[0] == 'H'
    ) == ImmutableList.of('Hello', 'Holi', 'Hola')

    # Assert that returns list with elements equals 1

# Generated at 2022-06-12 05:06:31.609154
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-12 05:06:41.694402
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(4, 5, 9, 10, 2).filter(lambda x: x > 5) == ImmutableList.of(9, 10)
    assert ImmutableList.of(5, 5, 9, 10, 2).filter(lambda x: x > 5) == ImmutableList.of(9, 10)
    assert ImmutableList.of(0, 5, 9, 10, 2).filter(lambda x: x > 5) == ImmutableList.of(9, 10)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x > 5) == ImmutableList.empty()

# Generated at 2022-06-12 05:06:44.861808
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 100) == None


# Generated at 2022-06-12 05:06:56.330173
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(0).filter(lambda e: 0 > e) == ImmutableList.empty()
    assert ImmutableList.of(0).filter(lambda e: 0 < e) == ImmutableList.empty()
    assert ImmutableList.of(0).filter(lambda e: 0 == e) == ImmutableList.of(0)
    assert ImmutableList.of(-1, 0, 1).filter(lambda e: 0 > e) == ImmutableList.of(-1)
    assert ImmutableList.of(-1, 0, 1).filter(lambda e: 0 < e) == ImmutableList.of(1)
    assert ImmutableList.of(-1, 0, 1).filter(lambda e: 0 == e) == ImmutableList.of(0)


# Generated at 2022-06-12 05:07:01.816768
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_filtered = ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2)

    assert list_filtered == ImmutableList(1, ImmutableList(3))
    assert len(list_filtered) == 2
    assert list_filtered.to_list() == [1, 3]

test_ImmutableList_filter()

# Generated at 2022-06-12 05:07:05.418641
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    list = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7)
    filter_fn = lambda x: x % 2 == 1


    # When
    filtered = list.filter(filter_fn)

    # Then
    assert filtered == ImmutableList.of(1, 3, 5, 7)



# Generated at 2022-06-12 05:07:09.015836
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(5, ImmutableList(7, ImmutableList(10, ImmutableList(15)))).filter(lambda x: x % 2 == 0) == \
        ImmutableList(10, ImmutableList(is_empty=True))

