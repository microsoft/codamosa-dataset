

# Generated at 2022-06-12 04:59:13.263042
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 2, 3)
    assert Imm

# Generated at 2022-06-12 04:59:19.541136
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(2) != ImmutableList.of(3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)



# Generated at 2022-06-12 04:59:23.583804
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = ImmutableList.of(2, 4)
    assert list1.filter(lambda x: x % 2 == 0) == list2

# Generated at 2022-06-12 04:59:25.920106
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]



# Generated at 2022-06-12 04:59:29.561029
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1,2,3,4,5).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1,2,3,4,5).find(lambda x: x < 0) == None


# Generated at 2022-06-12 04:59:35.031974
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) != ImmutableList()
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
test_ImmutableList___eq__()

# Generated at 2022-06-12 04:59:43.484666
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: False) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: True) == 1


# Generated at 2022-06-12 04:59:47.594584
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    actual = ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda x: x > 2)\
        .to_list()

    assert actual == [3, 4, 5]



# Generated at 2022-06-12 04:59:49.882060
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual = ImmutableList(1) == ImmutableList(1)
    expected = True
    assert actual == expected


# Generated at 2022-06-12 05:00:01.621636
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    print('Testing method "__eq__" of class "ImmutableList"')
    # Test cases
    test_cases = [
        {
            'name': 'Test case 1',
            'inputs': [
                [1, 2, 3, 4],
                [1, 2, 3, 4]
            ],
            'output': [
                True
            ]
        },
        {
            'name': 'Test case 2',
            'inputs': [
                [1, 2, 3, 4],
                [5, 6, 7, 8]
            ],
            'output': [
                False
            ]
        }
    ]

    # Run test cases
    passing_test_cases = run_test_cases(ImmutableList.__eq__, test_cases)

# Generated at 2022-06-12 05:00:17.574919
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    lst = ImmutableList.of(1)
    other = ImmutableList.of(1)
    assert lst == other
    assert lst is not other
    assert lst.__eq__(other)

# Generated at 2022-06-12 05:00:23.928811
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert_equal(
        ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list(),
        [2, 4]
    )
    assert_equal(
        ImmutableList.empty().filter(lambda x: x % 2 == 0).to_list(),
        []
    )
    assert_equal(
        ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).to_list(),
        [1, 3, 5]
    )
    assert_equal(
        ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x >= 3).to_list(),
        [3, 4, 5]
    )

# Generated at 2022-06-12 05:00:33.184274
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(2, 3, 4, 5, 7).filter(lambda a: a % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(2).filter(lambda a: a % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(2).filter(lambda a: a % 2 == 1) == ImmutableList.empty()
    assert ImmutableList.of(2, 3, 4).filter(lambda a: a % 2 == 0).filter(lambda a: a % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(2, 3, 4, 5).filter(lambda a: a % 2 == 0) + ImmutableList.of(6) == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-12 05:00:44.792701
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    expected_1 = ImmutableList('d', ImmutableList('a', ImmutableList('o')))
    expected_2 = ImmutableList('d', ImmutableList('a', ImmutableList('o')))
    expected_3 = ImmutableList('d', ImmutableList('a', ImmutableList('o')))
    
    assert expected_1 == expected_2
    assert expected_2 == expected_3
    assert expected_1 == expected_3
    assert expected_1 == expected_1
    assert expected_2 == expected_2
    assert expected_3 == expected_3
    
    assert expected_1 != ImmutableList()
    assert expected_2 != ImmutableList()
    assert expected_3 != ImmutableList()
    assert ImmutableList() != expected_1
    assert ImmutableList() != expected_2
    assert ImmutableList

# Generated at 2022-06-12 05:00:53.573863
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 3 == 0) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 6) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()

# Generated at 2022-06-12 05:01:01.053203
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    even = lambda x: x % 2 == 0
    odd = lambda x: x % 2 != 0

    assert ImmutableList.of(1, 2, 3).filter(even) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(odd) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3, 4).filter(even) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(odd) == ImmutableList.of(1, 3)



# Generated at 2022-06-12 05:01:06.913035
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1) + ImmutableList.of(2) + ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1) + ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1, 2, 3)

# Generated at 2022-06-12 05:01:10.940045
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    value = ImmutableList([1, 2, -4, 9]).filter(lambda x: x > 0)
    assert len(value) == 3
    assert [1, 2, 9] == value.to_list()
    assert not value.is_empty

# Generated at 2022-06-12 05:01:19.054674
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # When compare list with empty, should be False
    assert ImmutableList() != ImmutableList.empty()
    # When compare list with list, should be True
    assert ImmutableList() == ImmutableList()
    # When compare list with other list, should be True
    assert ImmutableList() == ImmutableList.of(1)
    # When compare list with other list, should be False
    assert ImmutableList() != ImmutableList.of(1)
    # When compare list with other list, should be True
    assert ImmutableList.of(1) == ImmutableList.of(1)
    # When compare list with other list, should be False
    assert ImmutableList.of(1) != ImmutableList.of(2)
    
    


# Generated at 2022-06-12 05:01:27.902482
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(4))) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-12 05:01:46.064020
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    Test verifies 1) __eq__ returns True for two ImmutableLists if they are equal
                    2) __eq__ returns False for two ImmutableLists if they are not equal
    """
    # 1) __eq__ returns True for two ImmutableLists if they are equal
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    # 2) __eq__ returns False for two ImmutableLists if they are not equal
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 1)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 1)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)

# Generated at 2022-06-12 05:01:57.365783
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda a: True) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda a: True) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda a: False) == ImmutableList.empty()

    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: True) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: False) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: a == 1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda a: a == 2) == ImmutableList(2)
    assert Immutable

# Generated at 2022-06-12 05:02:00.322937
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list_.filter(lambda x: x >= 2) == ImmutableList(2, ImmutableList(3))


# Generated at 2022-06-12 05:02:02.434604
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)



# Generated at 2022-06-12 05:02:04.737265
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]

# Generated at 2022-06-12 05:02:07.630016
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    my_immutable_list = ImmutableList.of(3, 5, 3, 4, 5, 5, 9, 11)

    # when
    first_five = my_immutable_list.find(lambda x: x == 5)

    # then
    assert first_five == 5

# Generated at 2022-06-12 05:02:09.545021
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda val: val % 2 == 0) == ImmutableList.of(2)

# Generated at 2022-06-12 05:02:12.638036
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    actual = ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3)
    expected = ImmutableList.of(4, 5)
    assert actual == expected

# Generated at 2022-06-12 05:02:18.296960
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # given
    expected_result = True
    head_list = ImmutableList.of(1, 2)
    tail_list = ImmutableList.of(3, 4)
    tail_list.head = head_list
    immutable_list = ImmutableList(head_list, tail_list, True)
    other_immutable_list = ImmutableList(head_list, tail_list, True)

    # when
    result = immutable_list.__eq__(other_immutable_list)

    # then
    assert result == expected_result


# Generated at 2022-06-12 05:02:25.436379
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 1, 3)
    assert ImmutableList.of(1, 2, 3) != [1, 2, 3]
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(2)
    assert ImmutableList.empty() != list()


# Generated at 2022-06-12 05:02:57.236798
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3) == 'ImmutableList'

# Generated at 2022-06-12 05:03:09.962484
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Case 1
    actual_result = ImmutableList() == ImmutableList()
    expected_result = True
    assert expected_result == actual_result

    # Case 2
    actual_result = ImmutableList() == ImmutableList(1)
    expected_result = False
    assert expected_result == actual_result

    # Case 3
    actual_result = ImmutableList(1) == ImmutableList(1)
    expected_result = True
    assert expected_result == actual_result

    # Case 4
    actual_result = ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    expected_result = True
    assert expected_result == actual_result

    # Case 5

# Generated at 2022-06-12 05:03:17.315476
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_list.find(lambda t: t == 1) == 1
    assert test_list.find(lambda t: t == 2) == 2
    assert test_list.find(lambda t: t == 3) == 3
    assert test_list.find(lambda t: t == 4) == 4
    assert test_list.find(lambda t: t == 5) == 5
    assert test_list.find(lambda t: t == 6) is None


# Generated at 2022-06-12 05:03:27.108757
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x == 0) == ImmutableList.empty()

    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert immutable_list.filter(lambda x: x == 1) == ImmutableList(1)
    assert immutable_list.filter(lambda x: x == 3) == ImmutableList(3)
    assert immutable_list.filter(lambda x: x == 5) == ImmutableList.empty()
    assert immutable_list.filter(lambda x: x % 2 == 1) == ImmutableList(1, ImmutableList(3))
    assert immutable_list.filter(lambda x: x % 2 == 0) == ImmutableList(2)


# Generated at 2022-06-12 05:03:36.120693
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList() != ImmutableList(is_empty=True)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2), ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-12 05:03:43.530694
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty(), "ImmutableList.__eq__: empty equal empty"
    assert ImmutableList.of(2) == ImmutableList.of(2), "ImmutableList.__eq__: equal with 1 value"
    assert ImmutableList.of(2,3) == ImmutableList.of(2,3), "ImmutableList.__eq__: equal with 2 vals"
    assert ImmutableList.of(2,3,5) == ImmutableList.of(2,3,5), "ImmutableList.__eq__: equal with 3 vals"
    assert ImmutableList.of(2,3,5) == ImmutableList.of(2,3,5,6), "ImmutableList.__eq__: not equal with 4 and 3 vals"

# Generated at 2022-06-12 05:03:49.655569
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    mock_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    def even(x: int) -> bool:
        return x % 2 == 0

    # when
    filtered_list = mock_list.filter(even)

    # then
    assert filtered_list == ImmutableList(2, 4, 6)



# Generated at 2022-06-12 05:04:00.274231
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(2)))
    assert ImmutableList

# Generated at 2022-06-12 05:04:04.298067
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    l1 = ImmutableList.empty()
    l2 = ImmutableList.empty()

    # Act
    res = l1.__eq__(l2)

    # Assert
    assert res == True


# Generated at 2022-06-12 05:04:13.069393
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(3).filter(lambda el: True) == ImmutableList(3)
    assert ImmutableList(5).filter(lambda el: False) == ImmutableList.empty()
    assert ImmutableList(4).filter(lambda el: el < 5) == ImmutableList(4)
    assert ImmutableList(4).filter(lambda el: el > 5) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda el: el < 4) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda el: el > 4) == ImmutableList.of(5, 6, 7)

# Generated at 2022-06-12 05:05:08.457365
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x == 3) == ImmutableList(is_empty=True)
    assert ImmutableList(3).filter(lambda x: x == 3) == ImmutableList(3)
    assert ImmutableList(3, ImmutableList(4)).filter(lambda x: x == 4) == ImmutableList(4)
    assert ImmutableList(3, ImmutableList(4)).filter(lambda x: x == 3) == ImmutableList(3)


# Generated at 2022-06-12 05:05:14.582964
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda item: item == 1) is None
    assert ImmutableList(1).find(lambda item: item == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda item: item == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda item: item == 2) == 2


# Generated at 2022-06-12 05:05:20.452853
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda x: x == 1)\
        .to_list() == [1]

    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda x: x == 4)\
        .to_list() == [4]

    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda x: x % 3 == 0)\
        .to_list() == [3]

    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda x: x > 2)\
        .to_list() == [3, 4]

    assert ImmutableList.empty().filter(lambda x: True).to_list() == []
test_ImmutableList_filter()

# Unit test

# Generated at 2022-06-12 05:05:27.512581
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 2, 3, 4)
    l2 = ImmutableList.of(1, 2, 3, 4)
    l3 = ImmutableList.of(1, 2, 3, 5)
    assert l1 is not l2
    assert l1 is not l3
    assert l1 == l2
    assert l1 != l3
    
test_ImmutableList___eq__()


# Generated at 2022-06-12 05:05:30.992864
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8).filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6, 8]


# Generated at 2022-06-12 05:05:34.069776
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    fst_list = ImmutableList.of(1, 2, 3)
    snd_list = ImmutableList.of(1, 2, 3)

    assert fst_list == snd_list



# Generated at 2022-06-12 05:05:37.717051
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5)


# Generated at 2022-06-12 05:05:48.137448
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    list2 = ImmutableList.of(2, 3, 4)
    list3 = ImmutableList.of(1)
    list4 = ImmutableList.of(5, 4, 3, 2, 1)
    list5 = ImmutableList.of(7, 6, 5, 4)
    list6 = ImmutableList.empty()

    assert list1.filter(lambda z: z % 2 == 0) == list2
    assert list1.filter(lambda z: z <= 1) == list3
    assert list1.filter(lambda z: z > 2) == list4
    assert list1.filter(lambda z: z < 6) == list5

# Generated at 2022-06-12 05:05:55.024942
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: not x % 2) == ImmutableList.of(2)
    assert ImmutableList.empty().filter(lambda x: not x % 2) == ImmutableList.empty()


# Generated at 2022-06-12 05:06:02.519971
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(None, None) == ImmutableList()
    assert ImmutableList(None, None, is_empty=True) == ImmutableList()
    assert ImmutableList() == ImmutableList(None, None, is_empty=True)
    assert ImmutableList(None, None) == ImmutableList(None, None, is_empty=True)
    assert ImmutableList(7) == ImmutableList(7, None, is_empty=False)
    assert ImmutableList(7, ImmutableList(10, ImmutableList(11, ImmutableList(None, None)))) == ImmutableList(7, ImmutableList(10, ImmutableList(11, ImmutableList(None, None))))
    assert ImmutableList() != ImmutableList(None, None, is_empty=False)

# Generated at 2022-06-12 05:07:50.944512
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'b') == 'b'
    assert not ImmutableList.of(1, 2, 3).find(lambda x: x == 6)
    assert not ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'd')
    assert not ImmutableList.empty().find(lambda x: x == 6)

# Generated at 2022-06-12 05:07:54.302129
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 10) is None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9).find(lambda x: x%2 == 0) == 2



# Generated at 2022-06-12 05:08:00.563266
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    # test 1
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert list1.find(lambda x: x % 2 == 0) == 2

    # test 2
    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert list2.find(lambda x: x % 2 != 0) == 1

    # test 3
    list3 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert list3.find(lambda x: x > 0) == 1

    # test 4
    list4 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-12 05:08:03.743325
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def positive(num: int) -> bool:
        return num > 0

    assert ImmutableList.of(1, 2, 3, -1, -2, -3).filter(positive) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3, -1, -2, -3).filter(positive).to_list() == [1, 2, 3]


# Generated at 2022-06-12 05:08:07.531280
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(15, 10, 20, 25, 30).find(lambda x: x > 18) == 20
    assert ImmutableList.of(15, 10, 20, 25, 30).find(lambda x: x is 30) == 30
    assert ImmutableList.of(15).find(lambda x: x is 15) == 15
    assert ImmutableList.of(15).find(lambda x: x is 10) is None



# Generated at 2022-06-12 05:08:13.518771
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(2, 4).find(lambda x: x > 3) == 4
    assert ImmutableList.of(2, 2, 2, 2, 2).find(lambda x: x > 3) is None
    assert ImmutableList.empty().find(lambda x: x > 3) is None
    assert ImmutableList.of(2, 2, 2, 2, 3).find(lambda x: x > 3) == 3

if __name__ == '__main__':  # pragma: no cover
    test_ImmutableList_find()
    print('All tests passed!')

# Generated at 2022-06-12 05:08:20.318681
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    list_example = ImmutableList(1, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6)))))
    list_result_correct = ImmutableList(1, ImmutableList(3, ImmutableList(5)))

    list_result_1 = list_example.filter(lambda x: x % 2 == 1)
    list_result_2 = list_example.filter(lambda x: x % 2 != 0)

    assert list_result_1 == list_result_2
    assert list_result_1 == list_result_correct



# Generated at 2022-06-12 05:08:22.565137
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.empty().filter(lambda x: x > 2) == ImmutableList.empty()


# Generated at 2022-06-12 05:08:27.371133
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    result_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) \
        .filter(lambda x: x % 2 == 0) \
        .to_list()

    assert [2, 4, 6, 8, 10] == result_list


# Generated at 2022-06-12 05:08:30.002424
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    data = ImmutableList.of(1, 2, 3, 4, 5, 6)

    result = data.filter(lambda x: x % 2 == 0)

    assert result == ImmutableList.of(2, 4, 6)

