

# Generated at 2022-06-12 04:59:00.340103
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(5, ImmutableList.empty()) == ImmutableList(5, ImmutableList.empty())
    assert ImmutableList(5, ImmutableList.empty()) != 5
    assert ImmutableList(5, ImmutableList(6, ImmutableList.empty())) != ImmutableList(6, ImmutableList.empty())


# Generated at 2022-06-12 04:59:02.914093
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    First unit test for ImmutableList class.
    """

    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-12 04:59:06.114874
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    assert ImmutableList.of('test', 'test2')\
           == ImmutableList.of('test', 'test2')

    assert ImmutableList.of('test', 'test2')\
           != ImmutableList.of('test', 'test3')


# Generated at 2022-06-12 04:59:16.660720
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    import unittest

    class ImmutableList___eq__Test(unittest.TestCase):
        def test_ImmutableList___eq__(self):
            self.assertEqual(
                ImmutableList.of(1),
                ImmutableList(1),
                'Should be equal'
            )

            self.assertEqual(
                ImmutableList.empty(),
                ImmutableList(is_empty=True),
                'Should be equal'
            )

            self.assertEqual(
                ImmutableList.of(1),
                ImmutableList(1, ImmutableList.empty()),
                'Should be equal'
            )

            self.assertEqual(
                ImmutableList.of(1, 2),
                ImmutableList(1, ImmutableList(2)),
                'Should be equal'
            )



# Generated at 2022-06-12 04:59:19.911304
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_one = ImmutableList.of(1)

    list_two = ImmutableList(1)

    assert list_one == list_two


# Generated at 2022-06-12 04:59:25.622475
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    lst = ImmutableList(1)
    lst.tail = ImmutableList(2)
    lst.tail.tail = ImmutableList(3)
    assert lst == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList() == ImmutableList()



# Generated at 2022-06-12 04:59:31.684197
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = ImmutableList.of(2, 3, 4)
    list3 = ImmutableList.empty()

    assert list1.filter(lambda x: x % 2 == 0) == list2
    assert list1.filter(lambda x: x > 5) == list3


# Generated at 2022-06-12 04:59:42.027496
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(10, 20, 30, 40).find(is_smaller_or_equal(20)) == 10
    assert ImmutableList.of(10, 15, 20, 30).find(is_between(10, 30)) == 15
    assert ImmutableList.of(10, 15, 20, 30).find(is_between(15, 30)) == 20
    assert ImmutableList.of(10, 15, 20, 30).find(is_between(10, 20)) == 15
    assert ImmutableList.of(10, 15, 20, 30).find(lambda x: x > 100) is None
    assert ImmutableList.of(20, 30).find(is_between(10, 30)) == 20
    assert ImmutableList.of(20).find(is_between(10, 30)) == 20

# Unit test

# Generated at 2022-06-12 04:59:46.514114
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    list_of_numbers = ImmutableList.of(1, 2, 3, 4, 5)
    # when
    result = list_of_numbers.filter(lambda x: x % 2 == 0)
    # then
    assert isinstance(result, ImmutableList)
    assert result.to_list() == [2, 4]

# Generated at 2022-06-12 04:59:55.734752
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    test_list = ImmutableList.of(1, 'test', '2')
    test_case_1 = 2
    test_case_2 = 'test'
    test_case_3 = 'not in list'

    # when
    result_1 = test_list.find(lambda x: x == test_case_1)
    result_2 = test_list.find(lambda x: x == test_case_2)
    result_3 = test_list.find(lambda x: x == test_case_3)

    # then
    assert result_1 is None
    assert result_2 == 'test'
    assert result_3 is None

# Generated at 2022-06-12 05:00:06.656094
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, None) == ImmutableList.of(1, None)
    assert ImmutableList.of(1, ImmutableList.of(2, ImmutableList.of(3))) == ImmutableList.of(1, ImmutableList.of(2, ImmutableList.of(3)))

    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, ImmutableList.of(2)) != ImmutableList.of(1, ImmutableList.of(3))

# Generated at 2022-06-12 05:00:08.636125
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1,2,3)
    res = l.find(lambda x: x > 2)
    assert res == 3

# Generated at 2022-06-12 05:00:15.152552
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2).to_list() == [3, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 2).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == 2).to_list() == [2]



# Generated at 2022-06-12 05:00:19.330070
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(
        1,
        2,
        3,
        4,
        5
    )

    result = list.find(
        lambda x: x == 3
    )

    assert result == 3



# Generated at 2022-06-12 05:00:25.215173
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(3, 1)


# Generated at 2022-06-12 05:00:30.309544
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-12 05:00:32.795528
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-12 05:00:42.138509
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    empty_list = ImmutableList.empty()
    list_with_one_element = ImmutableList.of(1)
    list_with_elements = ImmutableList.of(0, 1, 2)

    # When
    result_1 = empty_list.find(lambda x: x == 0)
    result_2 = list_with_one_element.find(lambda x: x == 1)
    result_3 = list_with_elements.find(lambda x: x == 2)

    # Then
    assert result_1 is None
    assert result_2 == 1
    assert result_3 == 2



# Generated at 2022-06-12 05:00:47.343963
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of('go', 'fast')
    list2 = list1.filter(lambda e: e != 'go')
    assert list1.head == 'go'
    assert list1.tail.head == 'fast'
    assert list2.head == 'fast'
    assert list2.tail.head is None
test_ImmutableList_filter()

# Generated at 2022-06-12 05:00:54.113109
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3), \
        'ImmutableList.filter(lambda x: x > 2) should return ImmutableList(3)'

    assert ImmutableList.of(1, 2).filter(lambda x: x > 2) == ImmutableList.empty(), \
        'ImmutableList.filter(lambda x: x > 2) should return ImmutableList.empty()'

    assert ImmutableList.empty().filter(RUNTIME_ERROR) == ImmutableList.empty(), \
        'ImmutableList.filter(RUNTIME_ERROR) should not return error'



# Generated at 2022-06-12 05:01:03.111868
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a1 = ImmutableList(1, ImmutableList(2))
    a2 = ImmutableList(1, ImmutableList(2))
    assert a1 == a2
    a1 = ImmutableList(1, ImmutableList(2), is_empty=True)
    a2 = ImmutableList(1, ImmutableList(2), is_empty=True)
    assert a1 == a2



# Generated at 2022-06-12 05:01:06.088353
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert l.filter(lambda x: x > 1).to_list() == [2, 3]



# Generated at 2022-06-12 05:01:09.765563
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    data = [1, 2, 3]
    assert ImmutableList.of(*data).find(lambda x: x == 2) == 2
    assert ImmutableList.of(*data).find(lambda x: x == 4) is None



# Generated at 2022-06-12 05:01:14.926392
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    xs = ImmutableList.of(
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9
    )

    # When
    result = xs.filter(lambda x: x > 5)

    expected = ImmutableList.of(
        6, 7, 8, 9
    )

    # Then
    assert result == expected

# Generated at 2022-06-12 05:01:19.025206
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    m_list = ImmutableList.of(1)
    assert m_list == ImmutableList.of(1)

    m_list_second = ImmutableList.of(1, 2)
    assert m_list_second != ImmutableList.of(1)


# Generated at 2022-06-12 05:01:29.820821
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) == None
    assert ImmutableList().find(lambda x: False) == None
    assert ImmutableList(1).find(lambda x: True) == 1
    assert ImmutableList(1).find(lambda x: False) == None
    assert ImmutableList(1).find(lambda x: x == 2) == None
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1, 2, 3, 4).find(lambda x: x == 1) == 1
    assert ImmutableList(1, 2, 3, 4).find(lambda x: x == 2) == 2
    assert ImmutableList(1, 2, 3, 4).find(lambda x: x == 3) == 3

# Generated at 2022-06-12 05:01:32.812110
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3)
    list = list.filter(lambda x: x == 2)
    assert list == ImmutableList.of(2)


# Generated at 2022-06-12 05:01:42.438004
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    odd = lambda x: x % 2 == 1
    two_times_odd = lambda x: x % 2 == 1 and x % 4 == 2

    arr = ImmutableList.of(1,2,3,4,5,6)
    arr = arr.append(arr)
    arr = arr.append(arr)
    arr = arr.append(arr)
    arr = arr.append(arr)

    assert arr.find(odd) == 5
    assert arr.find(two_times_odd) == 2

    assert arr.after_find(odd) == ImmutableList.of(1,2,4,6)
    assert arr.after_find(odd) == ImmutableList.of(1,2,4,6)

# Generated at 2022-06-12 05:01:47.787292
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)


# Generated at 2022-06-12 05:01:53.507036
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1) != 1
    assert ImmutableList.of(1) != ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList.empty()


# Generated at 2022-06-12 05:02:02.433841
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList()
    b = ImmutableList()
    c = ImmutableList(False)
    assert a == b and b == a
    assert not (a == c and b == c)

# Generated at 2022-06-12 05:02:04.699788
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.empty()


# Generated at 2022-06-12 05:02:10.432883
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test with empty list
    il_empty = ImmutableList()
    il_empty_empty = il_empty.filter(lambda x: x % 2 == 0)
    il_empty_empty_ref = ImmutableList(is_empty=True)
    assert il_empty_empty == il_empty_empty_ref

    # Test with one element in list
    il_one = ImmutableList(1)
    il_one_empty = il_one.filter(lambda x: x % 2 == 0)
    il_one_empty_ref = ImmutableList(is_empty=True)
    assert il_one_empty == il_one_empty_ref

    il_one_one = il_one.filter(lambda x: x == 1)
    il_one_one_ref = ImmutableList(1)
    assert il_one_

# Generated at 2022-06-12 05:02:18.681269
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert ImmutableList.of(1, 2, 3) != ImmutableList(1, ImmutableList(2, ImmutableList(None)))
    assert ImmutableList.of(1, 2, 3) != ImmutableList(1)
    assert ImmutableList.of(1, 2, 3) != ImmutableList()
    assert ImmutableList.empty() == ImmutableList(is_empty=True)

# Generated at 2022-06-12 05:02:24.777685
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    m = ImmutableList.of(1, 2, 3)
    assert m.find(lambda x: x == 2) == 2
    assert m.find(lambda x: x == 20) is None

    n = ImmutableList.of('a', 'aa', 'aaa')
    assert n.find(lambda x: len(x) == 2) == 'aa'
    assert n.find(lambda x: len(x) == 22) is None



# Generated at 2022-06-12 05:02:34.446577
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(ImmutableList(is_empty=True))
    assert ImmutableList().__eq__(ImmutableList())
    assert ImmutableList(is_empty=True).__eq__(ImmutableList())
    assert ImmutableList(is_empty=True).__eq__(ImmutableList(is_empty=True))
    assert not ImmutableList().__eq__(1)
    assert not ImmutableList().__eq__(None)
    assert not ImmutableList().__eq__([1])
    assert not ImmutableList().__eq__({'a': 1})
    assert not ImmutableList().__eq__((1, 2))
    assert not ImmutableList().__eq__(ImmutableList(1))
    assert ImmutableList(1).__eq__(ImmutableList(1))
    assert Imm

# Generated at 2022-06-12 05:02:43.310000
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, ImmutableList.of(2)) == ImmutableList.of(1, ImmutableList.of(2))
    assert ImmutableList.of() == ImmutableList.empty()
    assert ImmutableList.of() == ImmutableList.of()
    assert ImmutableList.of(1) != ImmutableList.empty()
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(3, 4)

# Generated at 2022-06-12 05:02:49.277635
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1,2,3,4,5)

    assert list_.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert list_.filter(lambda x: x == 5) == ImmutableList.of(5)
    assert list_.filter(lambda x: x == 100) == ImmutableList.empty()

    assert list_(1, 2, 3, 4, 5).filter(lambda x: x == 10) == ImmutableList.empty()


test_ImmutableList_filter()

 

# Generated at 2022-06-12 05:02:58.503175
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    If a number is divisible by 3 this test will pass.
    """

    @pytest.fixture
    def list_of_numbers():   # pylint: disable=missing-docstring
        return ImmutableList(5) + ImmutableList.of(2, 6, 3)

    def test_filter(list_of_numbers):  # pylint: disable=redefined-outer-name,missing-docstring
        result = list_of_numbers.filter(lambda n: n % 3 == 0)

        assert result == ImmutableList(6, ImmutableList(3))
        assert result.to_list() == [6, 3]

# Generated at 2022-06-12 05:03:02.213368
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-12 05:03:18.251907
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list0 = ImmutableList()
    assert list0.filter(lambda a: True) == ImmutableList()

    list1 = ImmutableList.of(0)
    assert list1.filter(lambda a: True) == ImmutableList.of(0)
    assert list1.filter(lambda a: False) == ImmutableList.of(None)

    list2 = ImmutableList.of(0, 1)
    assert list2.filter(lambda a: True) == ImmutableList.of(0, 1)
    assert list2.filter(lambda a: False) == ImmutableList.of(None, None)
    assert list2.filter(lambda a: a) == ImmutableList.of(1)
    assert list2.filter(lambda a: not a) == ImmutableList.of(0)

    list3 = ImmutableList

# Generated at 2022-06-12 05:03:22.046820
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3)
    
    assert list_.find(lambda x: x == 3) is 3
    assert list_.find(lambda x: x == 4) is None

test_ImmutableList_find()

# Generated at 2022-06-12 05:03:25.512791
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3)
    c = ImmutableList.of(1, 100, 3)

    assert a == b
    assert a != c

# Generated at 2022-06-12 05:03:32.907323
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_1 = ImmutableList.of(1, 2, 3, 4)
    list_2 = ImmutableList.of(1, 3)
    list_3 = ImmutableList.of(3)
    list_4 = ImmutableList.empty()

    assert list_1.filter(lambda i: i % 2) == list_2
    assert list_1.filter(lambda i: i == 3) == list_3
    assert list_1.filter(lambda _: False) == list_4



# Generated at 2022-06-12 05:03:34.719986
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(_ > 0) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-12 05:03:38.879726
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_maybe = ImmutableList.of(1, 2, 3)
    val = list_maybe.find(lambda x: x > 3)
    assert val is None

    val = list_maybe.find(lambda x: x == 2)
    assert val == 2


# Generated at 2022-06-12 05:03:42.845631
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-12 05:03:46.292627
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4, 5)
    assert il.filter(lambda x: x > 3).to_list() == [4, 5]


# Generated at 2022-06-12 05:03:53.021227
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x > 0) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 3) is None
    assert ImmutableList.empty().find(lambda x: x > 3) is None



# Generated at 2022-06-12 05:03:59.641299
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_data = ImmutableList.of(
        {'name': 'foo', 'age': 10},
        {'name': 'bar', 'age': 15},
        {'name': 'baz', 'age': 20}
    )

    assert test_data.find(lambda x: x.get('name') == 'bar') == {'name': 'bar', 'age': 15}
    assert test_data.find(lambda x: x.get('name') == 'qux') is None


# Generated at 2022-06-12 05:04:21.580212
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():    
    # test case 1
    # given an ImmutableList with 3 elements:
    # [1,2,3]
    # and a function that is checking if element is odd or not

    # assert result list has 2 elements
    # and both elements that are in the list are odd
    assert ImmutableList.of(1,2,3).filter(lambda x:x%2!=0) == ImmutableList.of(1,3)

    # test case 2
    # given an ImmutableList with 3 elements:
    # ['a', 'b', 'c']
    # and a function that is checking if element is not 'c'

    # assert result list has 2 elements
    # and both elements that are in the list are 'a', and 'b'

# Generated at 2022-06-12 05:04:24.529256
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of(1, 2, 3, 4)
    b = ImmutableList.of(1, 2, 3, 4)
    assert a == b



# Generated at 2022-06-12 05:04:32.299596
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(2, 3, 4).find(lambda x: x == 2) == 2
    assert ImmutableList.of(2, 3, 4).find(lambda x: x == 4) == 4
    assert ImmutableList.of(2, 3, 4).find(lambda x: x == 5) is None

if __name__ == '__main__':
    test_ImmutableList_find()
    print(' ... OK')

# Generated at 2022-06-12 05:04:37.186217
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x : x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).filter(lambda x : x > 2) == ImmutableList.empty()



# Generated at 2022-06-12 05:04:41.059114
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    even_list = test_list.filter(lambda x: x % 2 == 0)
    assert even_list == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-12 05:04:47.402158
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    test_list: ImmutableList[int] = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(5))))
    # when
    found: Optional[int] = test_list.find(lambda x: x > 3)
    # then
    assert found == 5, 'element of value 5 should be the first found'


# Generated at 2022-06-12 05:04:54.607979
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda x: True) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: True) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 2) == ImmutableList(2)


# Generated at 2022-06-12 05:05:00.704608
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    mapper = lambda x: x + 1 if isinstance(x, int) else x
    mapper2 = lambda x: x + 2 if isinstance(x, int) else x
    mapper3 = lambda x: x + 3 if isinstance(x, int) else x
    print(ImmutableList.of('test', 1, 2, 3).map(mapper).map(mapper2).map(mapper3))


# Generated at 2022-06-12 05:05:07.522245
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test for find method of ImmutableList class,
    # where list is empty
    if ImmutableList.empty().find(lambda x: x == 'a') is None:
        print('[+] Test ImmutableList find method passed')
    else:
        print('[-] Test ImmutableList find method failed')


    # Test for find method of ImmutableList class,
    # where list contains one element
    list = ImmutableList.of(1)

    if list.find(lambda x: x == 1) == 1:
        print('[+] Test ImmutableList find method passed')
    else:
        print('[-] Test ImmutableList find method failed')


    # Test for find method of ImmutableList class,
    # where list contains two elements
    list = ImmutableList.of(1, 2)


# Generated at 2022-06-12 05:05:16.295548
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    expected_result = ImmutableList(1, ImmutableList(2))
    
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x is not None) == expected_result
    assert ImmutableList.of(1, 2).filter(lambda x: x is not None) == expected_result
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5)


# Generated at 2022-06-12 05:05:55.369392
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 1) == 2
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 4) == None



# Generated at 2022-06-12 05:05:59.134027
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = list1.filter(lambda x: x % 2 == 0)
    list3 = ImmutableList.of(2, 4)
    assert list2 == list3



# Generated at 2022-06-12 05:06:09.569392
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test if filter returns expected value
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2
    # Test if filter returns expected value
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 1) == 1
    # Test if filter returns expected value
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0 and x > 3) is None
    # Test if filter returns expected value
    assert ImmutableList.of('a', 'aa', 'aaa').find(lambda x: len(x) > 1) == 'aa'

# Unit tests for method reduce of class ImmutableList

# Generated at 2022-06-12 05:06:16.274489
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # test if filter works fine with empty list
    assert ImmutableList.of().filter(lambda x: x) == ImmutableList.empty()

    # test if filter works fine for one element lists
    assert ImmutableList.of(4).filter(lambda x: x > 2) == ImmutableList.of(4)

    # test if filter works fine for several elements
    assert ImmutableList.of(4, 5, 6, 7, 8).filter(lambda x: x % 2 == 0) == ImmutableList.of(4, 6, 8)

# Generated at 2022-06-12 05:06:20.692284
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    filter_fn = lambda x: x % 2 == 0
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    filtered = immutable_list.filter(filter_fn)
    assert filtered == ImmutableList.of(2, 4, 6)



# Generated at 2022-06-12 05:06:24.234363
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2) == ImmutableList.of(1, 3, 5)


# Generated at 2022-06-12 05:06:30.741647
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ul = ImmutableList.of(1, 2, 3)
    assert (ul.find(lambda x: x > 2)) == 3
    assert (ul.find(lambda x: x > 4)) == None

    ul = ImmutableList.empty()
    assert (ul.find(lambda x: x > 2)) == None

    ul = ImmutableList.of(1)
    assert (ul.find(lambda x: x > 0)) == 1
    assert (ul.find(lambda x: x > 2)) == None



# Generated at 2022-06-12 05:06:40.223951
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test with int values
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    is_div_by_three = lambda a: a % 3 == 0
    assert immutable_list.filter(is_div_by_three).to_list() == [3]

    # Test with string values
    immutable_list = ImmutableList.of('Ivan', 'Petr', 'Alex', 'Natasha', 'Igor')
    name_start_with_A = lambda a: a[0] == 'A'
    assert immutable_list.filter(name_start_with_A).to_list() == ['Alex']

# Generated at 2022-06-12 05:06:46.528287
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x) == ImmutableList.empty()
    assert ImmutableList(0).filter(lambda x: x) == ImmutableList.empty()

    assert ImmutableList(1).filter(lambda x: x) == ImmutableList(1)

    assert ImmutableList(1, 2).filter(lambda x: x) == ImmutableList(1, 2)
    assert ImmutableList(1, 2).filter(lambda x: x > 1) == ImmutableList(2)

    assert ImmutableList(1, 0, 3).filter(lambda x: x) == ImmutableList(1, 3)

# Generated at 2022-06-12 05:06:51.610898
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Preparations
    x = ImmutableList.of(1, 2, 3, 4, 5)

    # Action
    y = x.find(lambda x: x%2 == 0)

    # Assertions
    assert y == 2, 'ImmutableList find method failed.'


# Generated at 2022-06-12 05:08:10.652522
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)

    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)


# Generated at 2022-06-12 05:08:12.884499
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of('foo', 'bar', 'baz', 'qux').filter(lambda x: x != 'bar' and x != 'baz') == ImmutableList.of('foo', 'qux')


# Generated at 2022-06-12 05:08:15.038879
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    if ImmutableList(1) != ImmutableList(1, ImmutableList(2)):
        print('test_ImmutableList___eq__ has failed')


# Generated at 2022-06-12 05:08:19.775589
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda a: a) is None
    assert ImmutableList.of(0).find(lambda a: a == 1) is None
    assert ImmutableList.of(1).find(lambda a: a == 1) == 1
    assert ImmutableList.of(1,5,5,5).find(lambda a: a == 5) == 5

# Generated at 2022-06-12 05:08:28.061734
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test for correct arguments
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'a') == 'a'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'c') == 'c'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'b') == 'b'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'd') is None
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'z') is None
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 1) is None

# Generated at 2022-06-12 05:08:30.757339
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    int_list = ImmutableList.of(1, 2, 3, 4, 7, 8)
    assert int_list.find(lambda x: x > 2) == 3
    assert int_list.find(lambda x: x > 8) is None


# Generated at 2022-06-12 05:08:32.813604
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == \
        ImmutableList.of(3)


# Generated at 2022-06-12 05:08:41.614359
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    list1 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    list2 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    assert list1 == list2
    assert len(list1) == len(list2)

    assert list1.to_list() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list2.to_list() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    list3 = list1.filter(lambda x: x % 2 == 1)
    list4 = list2.filter(lambda x: x % 2 == 1)

    assert list3 == list

# Generated at 2022-06-12 05:08:47.094086
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    filter_fn = lambda val: val > 2
    input_data = ImmutableList.of(1, 2, 3, 4, 5)
    actual = input_data.filter(filter_fn)
    expected = ImmutableList.of(3, 4, 5)
    assert expected == actual, f"ImmutableList.filter was not working properly.\nInput: {input_data}\nExpected: {expected}\nActual: {actual}"

test_ImmutableList_filter()

# Generated at 2022-06-12 05:08:50.495092
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    imList = ImmutableList.of(1, 2, 3, 4)
    expected = ImmutableList.of(1, 3)

    actual = imList.filter(lambda elem: elem % 2 == 1)

    assert actual == expected

