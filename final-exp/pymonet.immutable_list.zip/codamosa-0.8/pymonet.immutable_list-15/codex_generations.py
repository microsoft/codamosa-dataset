

# Generated at 2022-06-12 04:58:59.989795
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)

# Generated at 2022-06-12 04:59:02.873754
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    array = ImmutableList.of('a', 'b', 'c', 'd')
    assert array.find(lambda x: x == 'b') == 'b'
    assert array.find(lambda x: x == 'x') is None


# Generated at 2022-06-12 04:59:08.793535
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1,2,3,4,5) == ImmutableList.of(1,2,3,4,5)
    assert ImmutableList.of(1,2,3,4,5) != ImmutableList.of(1,2,3,4,6)
    assert ImmutableList.of(1) != ImmutableList.of(1,2,3,4,6)
    assert ImmutableList.of(1) != ImmutableList.of(1,2)


# Generated at 2022-06-12 04:59:18.377363
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    def _test_find(elements: list, fn: Callable[[int], bool], expected_result: int):
        result = ImmutableList.of(*elements).find(fn)
        if result != expected_result:  # pragma: no cover
            print('ERROR: '
                  + 'given elements: {elements}, '
                  + 'given function: {fn}, '
                  + 'result is: {result}, '
                  + 'expected_result: {expected_result}'
                  .format(elements=elements,
                          fn=fn,
                          result=result,
                          expected_result=expected_result))

    _test_find([], lambda x: x % 2 == 0, None)
    _test_find([1, 2, 3], lambda x: x % 2 == 0, 2)
    _test_

# Generated at 2022-06-12 04:59:26.288759
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    from unittest import TestCase, main

    class MyTestCase(TestCase):
        def test_find_one(self):
            self.assertEqual(ImmutableList(8).find(lambda x: x == 8), 8)

        def test_find_many(self):
            self.assertEqual(ImmutableList(8, ImmutableList(9)).find(lambda x: x == 9), 9)

        def test_find_none(self):
            self.assertIsNone(ImmutableList(8, ImmutableList(9)).find(lambda x: x == 10))

    main()


# Generated at 2022-06-12 04:59:30.285175
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    some_data: ImmutableList[str] = ImmutableList.of('1', 'Hello!', 'Lorem Ipsum', 'World', '!!!')
    find_result: Optional[str] = some_data.find(lambda x: x == 'Hello!')
    assert type(find_result) == str
    assert find_result == 'Hello!'

# Generated at 2022-06-12 04:59:36.778194
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x > 0) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).filter(lambda x: x >= 1) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).filter(lambda x: x >= 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).filter(lambda x: x >= 3) == ImmutableList.empty()


# Generated at 2022-06-12 04:59:41.743242
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 2, 3, 4, 5)
    l2 = ImmutableList.of(1, 2, 3, 4, 5)
    l3 = ImmutableList.of(1, 2, 5, 4, 5)

    assert l1 == l2
    assert l1 != l3


# Generated at 2022-06-12 04:59:46.303863
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList()
    assert ImmutableList(1) != None
    assert ImmutableList(1) != ImmutableList(2)

# Generated at 2022-06-12 04:59:57.536066
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (ImmutableList() == ImmutableList()) == True
    assert (ImmutableList(1) == ImmutableList(1)) == True
    assert (ImmutableList(1, 2) == ImmutableList(1, 2)) == True
    assert (ImmutableList(1, 2) == ImmutableList(2, 1)) == False
    assert (ImmutableList(1) == ImmutableList()) == False
    assert (ImmutableList(1) == ImmutableList(1, 1)) == False
    assert (ImmutableList() == ImmutableList(1)) == False
    assert (ImmutableList(1, 2) == ImmutableList(1, 3)) == False
    assert (ImmutableList(1, 2) == ImmutableList(2, 3)) == False


# Generated at 2022-06-12 05:00:05.207589
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)


# Generated at 2022-06-12 05:00:08.677985
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    xs = ImmutableList.of(1)
    ys = ImmutableList.of(1)
    zs = ImmutableList.of(2)

    # Act
    result_1 = xs == ys
    result_2 = xs == zs

    # Assert
    assert result_1
    assert not result_2


# Generated at 2022-06-12 05:00:11.455978
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4, 5)
    assert il.filter(lambda x: x > 3) == ImmutableList.of(4, 5)



# Generated at 2022-06-12 05:00:22.023557
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(2, ImmutableList(1)) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList() != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))

# Generated at 2022-06-12 05:00:32.199742
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: True) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()


test_ImmutableList_filter()

# Generated at 2022-06-12 05:00:43.526010
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList.of(2, 3) == ImmutableList.of(2, 3)
    assert ImmutableList(3, ImmutableList(2)) == ImmutableList(3, ImmutableList(2))
    assert not ImmutableList.of(2, 3) == ImmutableList.of(2, 4)
    assert not ImmutableList() == ImmutableList.of(2)
    assert not ImmutableList.of() == ImmutableList.of(2)
    assert not ImmutableList.empty() == ImmutableList.of(2)
    assert ImmutableList.empty() == ImmutableList.empty()

# Generated at 2022-06-12 05:00:52.788244
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x < 1) is None
    assert ImmutableList.empty().find(lambda x: x < 1) is None
    assert ImmutableList.of(1).find(lambda x: x < 1) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
   

# Generated at 2022-06-12 05:01:00.365809
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None
    assert ImmutableList(None, ImmutableList(2, ImmutableList(3))).find(lambda x: x is None) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x is None) is None


# Generated at 2022-06-12 05:01:05.591808
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    int_list = ImmutableList[int].of(1, 2, 3, 4, 5)
    even_num_list = int_list.filter(lambda elem: elem % 2 == 0)
    odd_num_list = int_list.filter(lambda elem: elem % 2 != 0)

    assert even_num_list == ImmutableList(2, ImmutableList(4))
    assert odd_num_list == ImmutableList(1, ImmutableList(3, ImmutableList(5)))


# Generated at 2022-06-12 05:01:09.914475
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-12 05:01:25.644201
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2) + ImmutableList.of(3)
    assert ImmutableList.empty() != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)

# Generated at 2022-06-12 05:01:31.234133
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert a.filter(lambda x: x > 5).to_list() == [6, 7]
    assert a.filter(lambda x: x < 5).to_list() == [1, 2, 3, 4]


test_ImmutableList_filter()

# Generated at 2022-06-12 05:01:37.956414
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x) == ImmutableList.empty(), 'Filter is not empty'

    assert ImmutableList(6, ImmutableList(2), ImmutableList(4)).filter(lambda x: x % 2) == ImmutableList(6), "Filter is not working"

    assert ImmutableList(6, ImmutableList(2), ImmutableList(4)).filter(lambda x: x % 2) != ImmutableList(2), "Filter is not working"


# Generated at 2022-06-12 05:01:41.727921
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None



# Generated at 2022-06-12 05:01:44.219164
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    a = ImmutableList.of(1, 2, 3)

    # When
    x = a.find(lambda x: x < 3)

    # Then
    assert x == 1

# Generated at 2022-06-12 05:01:47.878603
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    il = ImmutableList.of(1, 2, 3, 4, 5)

    # When
    result = il.filter(lambda x: x % 2 == 0)

    # Then
    assert result == ImmutableList.of(2, 4)



# Generated at 2022-06-12 05:01:53.963272
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1) != ImmutableList.empty()

# Generated at 2022-06-12 05:02:01.330772
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of()
    assert ImmutableList.of() == ImmutableList.of()


test_ImmutableList___eq__()


# Generated at 2022-06-12 05:02:03.513389
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():    
    i1 = ImmutableList.of(1,2,3)
    i2 = ImmutableList.of(1,2,3)
    assert i1 == i2
        

# Generated at 2022-06-12 05:02:07.130786
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4, 5) == ImmutableList.of(1, 2, 3, 4, 5)



# Generated at 2022-06-12 05:02:27.625246
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    test_cases = [
        (
            ImmutableList.of(1),
            ImmutableList.of(1),
            True
        ),
        (
            ImmutableList.of(1, 2, 3),
            ImmutableList.of(1, 2, 3),
            True
        ),
        (
            ImmutableList.of(-12),
            ImmutableList.of(-12, 1),
            False
        ),
        (
            ImmutableList.of(),
            ImmutableList.of(),
            True
        ),
        (
            ImmutableList.of(0),
            ImmutableList.empty(),
            False
        )
    ]

    for case, expected in test_cases:
        assert case == expected, "invalid value of ImmutableList.__eq__()"


# Generated at 2022-06-12 05:02:32.116198
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1, 2, 3, 4)
    assert l.find(lambda x: x == 3) == 3, 'find should return element that match the filter'
    assert l.find(lambda x: x == 999) is None, 'find should return None if no element was found'


# Generated at 2022-06-12 05:02:42.202755
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda el: el > 2) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.empty().filter(lambda el: el > 2) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda el: el > 2) \
        == ImmutableList.of(1, 2, 3, 4, 5).filter(lambda el: el > 2)
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).to_list()

    assert type(ImmutableList.of(1, 2, 3, 4, 5).filter(lambda el: el > 2)) == type(ImmutableList.of(3, 4, 5))

# Generated at 2022-06-12 05:02:49.178241
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(ImmutableList()) == True
    assert ImmutableList().__eq__(ImmutableList(1)) == False
    assert ImmutableList(1).__eq__(ImmutableList(1)) == True
    assert ImmutableList(1).__eq__(ImmutableList(2)) == False
    assert ImmutableList(1).__eq__(ImmutableList(2, 3)) == False
    assert ImmutableList(1, 2).__eq__(ImmutableList(1, 2)) == True
    assert ImmutableList(1, 2).__eq__(ImmutableList(1, 3)) == False


# Generated at 2022-06-12 05:02:54.842427
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3)
    c = ImmutableList.of(1, 2, 3, 4)
    assert a == a
    assert a == b
    assert a == c
    assert not a == ImmutableList.of(1, 2, 4)


# Generated at 2022-06-12 05:03:01.560689
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Unit test for method filter of class ImmutableList

    """
    l = ImmutableList(10, ImmutableList(9, ImmutableList(4, ImmutableList(3, ImmutableList(2, ImmutableList(1, ImmutableList()))))))

    def function(x):
        return x < 5
    
    assert l.filter(function).to_list() == [4, 3, 2, 1] and l == ImmutableList(10, ImmutableList(9, ImmutableList(4, ImmutableList(3, ImmutableList(2, ImmutableList(1, ImmutableList()))))))
    
if __name__ == '__main__':
    test_ImmutableList_filter()

# Generated at 2022-06-12 05:03:07.185752
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    lst_a = ImmutableList.of(1, 2, 3)
    lst_b = ImmutableList.of(2, 3, 1)
    assert lst_a == lst_a
    assert lst_b == lst_b
    assert not lst_a == lst_b


# Generated at 2022-06-12 05:03:13.180993
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-12 05:03:17.238029
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(None, ImmutableList.empty())
    assert ImmutableList() == ImmutableList(None, ImmutableList(None, ImmutableList.empty()))
    
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    
    assert ImmutableList.of(4, 3) != ImmutableList.of(3, 4)
    assert ImmutableList.of(3, 4) != ImmutableList.of(3, 4, 5)

# Generated at 2022-06-12 05:03:22.370951
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda n: n % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda n: n % 2 == 1) == ImmutableList.of(1, 3, 5)



# Generated at 2022-06-12 05:03:37.851835
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    case = [
        {
            'in': ([1, 2, 3, 4], lambda x: x > 2),
            'out': [3, 4]
        },
        {
            'in': ([1, 2, 3, 4], lambda x: x < 3),
            'out': [1, 2]
        }
    ]
    for i in case:
        result = ImmutableList.of(*i['in'][0]).filter(i['in'][1]).to_list()
        assert result == i['out'],\
            f"ImmutableList.filter({i['in']}) == {result}, should be {i['out']}"


# Generated at 2022-06-12 05:03:42.149336
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    assert ImmutableList.of(True).filter(lambda x: not x).is_empty == True
    assert ImmutableList.of(False).filter(lambda x: not x).head == True
    assert ImmutableList.of(True, False).filter(lambda x: not x).head == False
    assert ImmutableList.of(True, True).filter(lambda x: not x).is_empty == True
    
test_ImmutableList_filter()

# Generated at 2022-06-12 05:03:47.369845
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    list_items = [1, 2, 3]
    list = ImmutableList.of(*list_items)

    for i in range(4):
        # when
        result = list.find(lambda x: x == i)

        if i in list_items:
            # then
            assert result == i
        else:
            assert result is None

# Generated at 2022-06-12 05:03:52.914897
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    immutable = ImmutableList.of(1, 2, 3, 4, 5)

    # Act
    filtered = immutable.filter(lambda x: x % 2 == 0)

    # Assert
    assert(filtered == ImmutableList.of(2, 4))


# Generated at 2022-06-12 05:03:55.575162
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3).to_list() == [4, 5]

# Generated at 2022-06-12 05:03:59.451463
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    l = ImmutableList.of(1, 2, 3, 4)

    # Act
    result = l.filter(lambda x: x % 2 == 0)

    # Assert
    assert [2, 4] == result.to_list()



# Generated at 2022-06-12 05:04:06.829361
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == 4) == ImmutableList.of(4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == 5) == ImmutableList.empty()


# Generated at 2022-06-12 05:04:16.839595
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    maybe = ImmutableList(
        {'id': 1, 'name': 'Bartosz'},
        ImmutableList({'id': 2, 'name': 'Jan'})
    )

    assert maybe.find(lambda x: x['name'] == 'Bartosz') == {'id': 1, 'name': 'Bartosz'}
    assert maybe.find(lambda x: x['name'] == 'Jan') == {'id': 2, 'name': 'Jan'}
    assert maybe.find(lambda x: x['name'] == 'Piotr') == None

test_ImmutableList_find()

# Generated at 2022-06-12 05:04:27.950081
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # check for empty ImmutableList
    assert ImmutableList.empty().find(lambda x: x > 5) is None

    # check for finding element
    assert ImmutableList.of(1, 2, 5, 7).find(lambda x: x == 7) == 7
    assert ImmutableList.of(1, 2, 5, 7).find(lambda x: x == 100) is None
    assert ImmutableList.of(1, 2, 5, 7).find(lambda x: x > 5) == 7

    # check for finding element on the begin
    assert ImmutableList.of(7, 2, 5, 7).find(lambda x: x == 7) == 7
    assert ImmutableList.of(7, 2, 5, 7).find(lambda x: x > 5) == 7

    # check for finding element on the end
    assert Imm

# Generated at 2022-06-12 05:04:37.442831
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda x: x != 1) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).filter(lambda x: x == 0) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).filter(lambda x: x == 3) == ImmutableList(3)

# Generated at 2022-06-12 05:05:04.728531
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_to_find = ImmutableList(5, ImmutableList(3, ImmutableList(16)))

    head_value = 1
    last_value = 16

    assert list_to_find.find(lambda x: x == head_value) == head_value
    assert list_to_find.find(lambda x: x == last_value) == last_value
    assert list_to_find.find(lambda x: x == 0) == None

if __name__ == '__main__':
    test_ImmutableList_find()

# Generated at 2022-06-12 05:05:08.902617
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    print("Testing ImmutableList.find")
    l = ImmutableList.of(2)
    l = l.append(3)
    l = l.append(4)

    assert l.find(lambda x: x > 2) == 3

# Generated at 2022-06-12 05:05:17.247594
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.of(2, 3, 4).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(2, 3, 4).filter(lambda x: x < 3) == ImmutableList.of(2)
    assert ImmutableList.of(2, 3, 4).filter(lambda x: x > 3) == ImmutableList.of(4)
    assert ImmutableList.of('a', 'b', 'c').filter(lambda x: x != 'b') == ImmutableList.of('a', 'c')

# Generated at 2022-06-12 05:05:25.215783
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 'a') is None

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None


# Generated at 2022-06-12 05:05:29.173191
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    xs = ImmutableList(1, ImmutableList(
        2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    assert xs.filter(lambda x: x % 2 == 0) == ImmutableList(
        2, ImmutableList(4))



# Generated at 2022-06-12 05:05:38.757068
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList([1, 2, 3]).filter(lambda x: x > 1) == ImmutableList([2, 3])
    assert ImmutableList([1, 2, 3]).filter(lambda x: x < 1) == ImmutableList([])
    assert ImmutableList([1, 2, 3]).filter(lambda x: True) == ImmutableList([1, 2, 3])
    assert ImmutableList([1, 2, 3]).filter(lambda x: False) == ImmutableList([])
    assert ImmutableList([]).filter(lambda x: True) == ImmutableList([])
    assert ImmutableList([]).filter(lambda x: False) == ImmutableList([])

# Generated at 2022-06-12 05:05:48.731265
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList(4)

    assert list_.filter(lambda x: x % 2 != 0) == ImmutableList()
    assert list_.filter(lambda x: x % 2 == 0) == ImmutableList(4)

    list_ = ImmutableList(5, ImmutableList(5, ImmutableList(5)))

    assert list_.filter(lambda x: x % 2 != 0) == list_
    assert list_.filter(lambda x: x % 2 == 0) == ImmutableList()

    list_ = ImmutableList(5, ImmutableList(6, ImmutableList(7)))

    assert list_.filter(lambda x: x % 2 == 0) == ImmutableList(6)
    assert list_.filter(lambda x: x % 2 != 0) == ImmutableList(5, ImmutableList(7))



# Generated at 2022-06-12 05:05:52.810913
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)
    
    

# Generated at 2022-06-12 05:06:01.605351
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert None == ImmutableList.empty().find(lambda _: False)
    assert None == ImmutableList.empty().find(lambda _: True)

    assert None == ImmutableList.of(1).find(lambda x: x > 1)
    assert None == ImmutableList.of(1).find(lambda x: x < 1)
    assert 1 == ImmutableList.of(1).find(lambda x: x == 1)
    
    assert None == ImmutableList.of(1, 2, 3).find(lambda x: x > 3)
    assert None == ImmutableList.of(1, 2, 3).find(lambda x: x < 1)
    assert 2 == ImmutableList.of(1, 2, 3).find(lambda x: x > 1 and x <3)

# Generated at 2022-06-12 05:06:08.302204
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda _: False) is None
    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9).find(lambda x: x == 10) is None
    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9).find(lambda x: x == 5) == 5


# Generated at 2022-06-12 05:06:57.785926
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: True) == None
    assert ImmutableList.of(0).find(lambda x: True) == 0
    assert ImmutableList.of(1, 2).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2).find(lambda x: x == 3) == None
    assert ImmutableList.of(1, 2).find(lambda x: x > 1) == 2
    assert ImmutableList.of(1, 2).find(lambda x: x < 2) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 1) == 2
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-12 05:07:03.219800
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1,2,3,4,5)
    l2 = l.filter(lambda v: v % 2 == 0)
    assert l2.to_list() == [2,4]
    assert l2.filter(lambda v: v % 2 == 0) == ImmutableList(2, ImmutableList(4))

test_ImmutableList_filter()

# Generated at 2022-06-12 05:07:06.830190
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda v: True) == None
    assert ImmutableList.of(1).find(lambda v: True) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda v: v == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda v: v == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda v: v > 3) == None

# Generated at 2022-06-12 05:07:16.643080
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    test_head = 'head'
    test_middle_element = 'middle'
    test_tail = 'tail'
    list_to_find: ImmutableList[str] = ImmutableList(
        test_head,
        ImmutableList(
            test_middle_element,
            ImmutableList(test_tail)
        )
    )

    # Act
    found_head: Optional[str] = list_to_find.find(lambda x: x == test_head)
    found_middle_element: Optional[str] = list_to_find.find(lambda x: x == test_middle_element)
    found_tail: Optional[str] = list_to_find.find(lambda x: x == test_tail)

    # Assert
    assert found_head == test_head
    assert found

# Generated at 2022-06-12 05:07:24.773277
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Given
    case_1 = ImmutableList([1, 2, 3])
    case_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    case_3 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(None))))
    case_4 = ImmutableList()

    # When
    case_1_filtered_not_none = case_1.filter(lambda x: x is not None)
    case_2_filtered_not_none = case_2.filter(lambda x: x is not None)
    case_3_filtered_not_none = case_3.filter(lambda x: x is not None)
    case_4_filtered_not_none = case_4.filter(lambda x: x is not None)

    # Then

# Generated at 2022-06-12 05:07:28.821758
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda c: c > 2) == None
    assert ImmutableList.of(1, 2, 3).find(lambda c: c > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda c: c > 2) != 4
    assert ImmutableList.of(1, 2, 3).find(lambda c: c > 3) == None


# Generated at 2022-06-12 05:07:31.681346
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    names = ImmutableList.of('Adrian', 'Adrian', 'Ania', 'Tomasz')

    names_new = names.filter(lambda name: name == 'Adrian')

    assert names_new == ImmutableList.of('Adrian', 'Adrian')


# Generated at 2022-06-12 05:07:36.293069
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert len(
        ImmutableList.of('a', 'b', 'c')
            .filter(lambda x: x == 'b')
    ) == 1

    assert ImmutableList.of('a', 'b', 'c', 'c', 'b')\
        .filter(lambda x: x == 'b') \
        .to_list() == ['b', 'b']


# Generated at 2022-06-12 05:07:41.493959
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutableList = ImmutableList.of(1, 2, 3, -1, 0, 2, 3)
    is_positive = lambda x: x > 0
    filtered_immutableList = immutableList.filter(is_positive)
    assert len(immutableList) == 7
    assert len(filtered_immutableList) == 3
    assert list(filtered_immutableList.to_list()) == [1, 2, 3]

# Generated at 2022-06-12 05:07:44.579298
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    mlist = ImmutableList.of(1, 2, 3, 4, 5)
    actual = mlist.filter(lambda x: x % 2 == 0).to_list()
    expected = [2, 4]
    assert actual == expected
    
test_ImmutableList_filter()
