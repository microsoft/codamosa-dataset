

# Generated at 2022-06-12 04:59:02.422155
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Test case for test_ImmutableList_filter method
    """
    list_of_even_numbers = ImmutableList[int].of(0, 2, 4, 6, 8, 10).filter(lambda i: i % 2 == 0)
    assert list_of_even_numbers == ImmutableList[int].of(0, 2, 4, 6, 8, 10)

# Generated at 2022-06-12 04:59:06.281165
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert list1.filter(lambda x: x < 4) == ImmutableList.of(1, 2, 3)
    assert list1.filter(lambda x: x < 1) == ImmutableList.empty()
    assert list1.filter(lambda x: x < 10) == list1
    assert list1.filter(lambda x: x < -10) == ImmutableList.empty()

# Generated at 2022-06-12 04:59:08.399014
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list = ImmutableList.of(1, 2, 3)
    assert list == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-12 04:59:11.347330
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda i: i%2 == 0)\
        .to_list() == [2, 4]


# Generated at 2022-06-12 04:59:15.577646
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList(1)

    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-12 04:59:25.931003
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_a = ImmutableList(1)
    list_b = ImmutableList(1)
    list_c = ImmutableList(2)
    list_d = ImmutableList(1, ImmutableList(2))
    list_e = ImmutableList(1, ImmutableList(2))
    list_f = ImmutableList(1, ImmutableList(3))
    assert list_a == list_a
    assert list_a == list_b
    assert list_a != list_c
    assert list_a != list_d
    assert list_d == list_e
    assert list_d != list_f



# Generated at 2022-06-12 04:59:34.709986
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result_1 = ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    result_2 = ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 0) is None
    result_3 = ImmutableList.empty().find(lambda x: x > 3) is None
    result_4 = ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None
    result_5 = ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > -1) == 1
    result_6 = ImmutableList.of(5, 4, 3, 2, 1).find(lambda x: x > 1) == 5


# Generated at 2022-06-12 04:59:42.164401
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1).to_list() == [2, 3]
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 4).to_list() == []
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 3).to_list() == [3]
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 2).to_list() == [1]


# Generated at 2022-06-12 04:59:45.422342
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(2)
    list2 = ImmutableList(2)
    assert list1 == list1
    assert list1 == list2
    assert list1 == 2
    assert 2 == list1

# Generated at 2022-06-12 04:59:49.509235
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(2, 3, 4, 5).find(lambda x: x > 2) == 3


# Generated at 2022-06-12 05:00:01.294278
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    il = ImmutableList.of(1, 1, 2, 3, 5, 8)

    assert il.find(lambda el: el == 1) == 1
    assert il.find(lambda el: el == 10) is None
    assert il.find(lambda el: el > 3) == 5


# Generated at 2022-06-12 05:00:04.306588
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4)
    assert test_list.find(lambda x: x > 2) == 3
    assert test_list.find(lambda x: x > 10) is None


# Generated at 2022-06-12 05:00:05.574047
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, 2, 3) == ImmutableList(1, 2, 3)



# Generated at 2022-06-12 05:00:08.552555
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 5) is None


# Generated at 2022-06-12 05:00:20.014425
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Setup:
    # Empty immutable list
    immutable_list = ImmutableList.empty()

    # Act:
    # Filter out element that is not divisible by 2
    result = immutable_list.filter(lambda x: x % 2 == 0)

    # Assert:
    # Result is type of ImmutableList
    assert isinstance(result, ImmutableList)
    # Result is an empty ImmutableList
    assert result.is_empty
    assert len(result) == 0

    # Setup:
    # Immutable list with two elements
    immutable_list = ImmutableList(2, ImmutableList(4))

    # Act:
    # Filter out element that is not divisible by 2
    result = immutable_list.filter(lambda x: x % 2 == 0)

    # Assert:
    # Result is type of ImmutableList

# Generated at 2022-06-12 05:00:26.732160
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(2, ImmutableList(3)) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList(2, ImmutableList(3)) != ImmutableList(2, ImmutableList(4))
    assert ImmutableList(2, ImmutableList(3)) != ImmutableList(2)
    assert ImmutableList(is_empty=True) != ImmutableList(2)



# Generated at 2022-06-12 05:00:34.031809
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList.empty()
    assert (ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3))
    assert (ImmutableList.of(1, 2, 3) == ImmutableList.of(2, 2, 3))
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(3, 2, 1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(2, 1, 3)
   

# Generated at 2022-06-12 05:00:45.799179
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1, ImmutableList(), True) == ImmutableList(1, ImmutableList(), True)
    assert not ImmutableList(1) == ImmutableList(2)
    assert not ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(3))

# Generated at 2022-06-12 05:00:49.747721
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-12 05:00:53.335104
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # __eq__ should return True if values of ImmutableList instances are equial

    # given
    list1 = ImmutableList(1, ImmutableList(2))
    list2 = ImmutableList(1, ImmutableList(2))
    # when
    result1 = list1 == list2
    # then
    assert result1 == True



# Generated at 2022-06-12 05:01:14.031753
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x > 0) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 7) is None
    assert ImmutableList.of().find(lambda x: x > 0) is None

# Generated at 2022-06-12 05:01:24.481381
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first_list = ImmutableList(1)
    second_list = ImmutableList(1)
    third_list = ImmutableList(2)
    fourth_list = ImmutableList.empty()
    fifth_list = ImmutableList.empty()

    assert first_list.__eq__(second_list), 'Method __eq__ should return True when two lists are equal'
    assert not third_list.__eq__(first_list), 'Method __eq__ should return False when two lists are different'
    assert not fourth_list.__eq__(fifth_list), 'Method __eq__ should return False when two lists are empty'
    assert fourth_list.__eq__(fourth_list), 'Method __eq__ should return True when list is equal to itself'


# Generated at 2022-06-12 05:01:27.420314
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_to_search = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert list_to_search.find(lambda x: x > 3) == 4



# Generated at 2022-06-12 05:01:33.471321
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    main_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    equal_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    not_equal_list = ImmutableList(1, ImmutableList(2, ImmutableList(4)))

    assert main_list == equal_list
    assert main_list != not_equal_list


# Generated at 2022-06-12 05:01:37.393071
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    x1 = ImmutableList.of(2, 3, 4, 5, 6)
    y1 = ImmutableList.of(2, 4, 6)
    assert x1.filter(lambda x: x % 2 == 0) == y1
    
    
    

# Generated at 2022-06-12 05:01:40.814782
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l = ImmutableList(56).append(457)
    l2 = ImmutableList(56).append(457)
    assert l == l2, "Objects are equal"


# Generated at 2022-06-12 05:01:44.904086
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(0, 1, 2).find(lambda x: x == 1) == 1
    assert ImmutableList.of(0, 1, 2).find(lambda x: x == 2) == 2
    assert ImmutableList.of(0, 1, 2).find(lambda x: x == 3) is None
    assert ImmutableList.empty().find(lambda x: x == 1) is None


# Generated at 2022-06-12 05:01:48.261788
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4)
    filtered_list = list_.filter(lambda x: x % 2 == 0)
    assert filtered_list == ImmutableList.of(2, 4)



# Generated at 2022-06-12 05:01:55.352428
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, None) != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList()
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList.of(1, 2)


# Generated at 2022-06-12 05:02:01.330002
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    # When
    result = immutable_list.filter(lambda x: x > 2)
    # Then
    assert result == ImmutableList.of(3, 4, 5)
    assert result != ImmutableList.of(1, 2, 3)
    assert isinstance(result, ImmutableList)
    assert isinstance(result, ImmutableList)



# Generated at 2022-06-12 05:02:24.968019
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(4, 7, 2).find(lambda item: item > 6) == 7
    assert ImmutableList.of(4, 7, 2).find(lambda item: item > 5) == 7
    assert ImmutableList.of(4, 7, 2).find(lambda item: item > 9) is None
    assert ImmutableList.of().find(lambda item: item > 9) is None
    assert ImmutableList.of(4, 7, 2).find(lambda item: item > 4) == 7

test_ImmutableList_find()

# Generated at 2022-06-12 05:02:34.586622
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Test should return empty ImmutableList
    empty_list = ImmutableList.empty()
    assert empty_list.filter(lambda x: x == 2) == ImmutableList.empty()

    # Test should return ImmutableList with only one element
    list_with_one_element = ImmutableList.of(1)
    assert list_with_one_element.filter(lambda x: x == 1) == ImmutableList.of(1)

    # Test should return ImmutableList with only two elements
    list_of_elements = ImmutableList.of(1, 2, 3, 4, 5)
    filtered_list_of_elements = list_of_elements.filter(lambda x: x > 2)
    assert filtered_list_of_elements == ImmutableList.of(3, 4, 5)

    # Test should return

# Generated at 2022-06-12 05:02:43.329602
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x == 7) == ImmutableList.empty()

    assert ImmutableList(1).filter(lambda x: x == 7) == ImmutableList.empty()

    assert ImmutableList.of(1).filter(lambda x: x == 7) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 7) == ImmutableList.empty()

    assert ImmutableList.of(1, 7, 3, 47).filter(lambda x: x == 7) == ImmutableList.of(7)

    assert ImmutableList.of(1, 7).filter(lambda x: x == 7) == ImmutableList.of(7)

    assert ImmutableList.of(7, 7).filter(lambda x: x == 7) == ImmutableList

# Generated at 2022-06-12 05:02:48.444264
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    # Act
    new_list = test_list.append(6).filter(lambda el: el > 3)
    
    # Assert
    assert new_list == ImmutableList.of(4, 5, 6)
    assert test_list == ImmutableList.of(1, 2, 3, 4, 5)
    

# Generated at 2022-06-12 05:02:54.499887
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 2, 3)
    l2 = ImmutableList.of(2, 3, 4)
    l3 = ImmutableList.of(1, 2, 3)
    assert l1.__eq__(l2) == False
    assert l1.__eq__(l3) == True
test_ImmutableList___eq__()

# Generated at 2022-06-12 05:02:57.752739
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3)
    result = list.filter(lambda _: True)
    assert result == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-12 05:03:05.074332
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    source_list = ImmutableList.of(1, 2, 3, 4, 5)
    filtered_list = source_list.filter(lambda x: x % 2 == 0)

    for x in filtered_list.to_list():
        assert x % 2 == 0

    assert (filtered_list + ImmutableList(6, 7, 8)).to_list() == [6, 8, 10]



# Generated at 2022-06-12 05:03:10.246790
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    def filterer(value):
        return value > 2

    # Act
    filtered_list = ImmutableList.of(1, 2, 3, 4, 5).filter(filterer)
    # Assert
    assert filtered_list == ImmutableList.of(3, 4, 5)


# Generated at 2022-06-12 05:03:15.369336
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    filtered = list_.filter(lambda x: x < 3)
    assert len(filtered) == 2
    assert filtered.head == 1
    assert filtered.tail.head == 2
    assert filtered.tail.tail is None

# Generated at 2022-06-12 05:03:22.086237
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) is None
    assert ImmutableList.of(1).find(lambda x: x) == 1
    assert ImmutableList.of(1, 2).append(3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2).append(3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2).append(3).find(lambda x: x == 3) == 3



# Generated at 2022-06-12 05:04:01.769607
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # test empty list
    assert ImmutableList.empty().\
        filter(lambda v: v/2 == 1) == ImmutableList.empty()

    # test with element
    assert ImmutableList.of(2, 3, 1).\
        filter(lambda v: v/2 == 1) == ImmutableList.of(2)

    # test with more than one elements
    assert ImmutableList.of(2, 4, 6).\
        filter(lambda v: v/2 == 1) == ImmutableList.empty()

    # test with one element
    assert ImmutableList.of(2).\
        filter(lambda v: v/2 == 1) == ImmutableList.of(2)


# Generated at 2022-06-12 05:04:09.313031
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList(2, ImmutableList(1, ImmutableList(3, ImmutableList(0, ImmutableList(7)))))
    assert test_list.filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(0))
    assert test_list.filter(lambda x: x % 2 == 1) == ImmutableList(is_empty=True)
    assert test_list.filter(lambda x: True) == test_list
    assert test_list.filter(lambda x: False) == ImmutableList(is_empty=True)


# Generated at 2022-06-12 05:04:14.428892
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3)\
        .filter(lambda x: x > 2)\
        == ImmutableList.of(3)

    assert ImmutableList.of(1, 2, 3)\
        .filter(lambda x: x > 5)\
        == ImmutableList.empty()



# Generated at 2022-06-12 05:04:18.784491
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(0, 1, 2, 3, 4).filter(lambda x: x % 2) == ImmutableList.of(1, 3)

    assert ImmutableList.of().filter(lambda x: True) == ImmutableList.empty()
    
    assert ImmutableList.of(0).filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList.of().filter(lambda x: False) == ImmutableList.empty()

# Generated at 2022-06-12 05:04:28.641810
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_empty_result = ImmutableList.empty().filter(lambda n: n % 2 == 0)
    assert list_empty_result.is_empty, 'Wrong filter result'

    list_empty_result = ImmutableList.of(1).filter(lambda n: n % 2 == 0)
    assert list_empty_result.is_empty, 'Wrong filter result'

    list_single_result = ImmutableList.of(2).filter(lambda n: n % 2 == 0)
    assert not list_single_result.is_empty, 'Wrong filter result'

    list_result = ImmutableList.of(1, 2, 3, 4).filter(lambda n: n % 2 == 0)
    assert list_result.to_list() == [2, 4], 'Wrong filter result'


# Generated at 2022-06-12 05:04:34.929441
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: True).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: False).to_list() == []


# Generated at 2022-06-12 05:04:40.722980
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    origin_list = ImmutableList.of('a', 'b', 'c', 'd')
    fn = lambda x: x in {'a', 'b', 'c'}

    # When
    result = origin_list.filter(fn)

    # Then
    expected = ImmutableList.of('a', 'b', 'c')

    assert result == expected


# Generated at 2022-06-12 05:04:44.865989
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    IL = ImmutableList.of
    assert IL(1, 2, 3).filter(lambda x: x % 2 == 1) == IL(1, 3)

# Generated at 2022-06-12 05:04:51.134245
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: True) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: False) == ImmutableList.empty()

# Generated at 2022-06-12 05:04:55.859863
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)

    assert immutable_list.find(lambda x: x > 0) == 1
    assert immutable_list.find(lambda x: x > 6) == 7
    assert immutable_list.find(lambda x: x > 10) is None


# Generated at 2022-06-12 05:06:14.218994
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Base case: example from slide
    assert ImmutableList.of(2, 3, 4).find(lambda x: x % 2 == 0) == 2
    # For check the tailing
    assert ImmutableList.of(3, 4, 2).find(lambda x: x % 2 == 0) == 2
    # For check the leading
    assert ImmutableList.of(2, 3, 2).find(lambda x: x % 2 == 0) == 2
    # Example with one element
    assert ImmutableList.of(1).find(lambda x: x % 2 == 0) == None
    # Example with empty List
    assert ImmutableList.empty().find(lambda x: x % 2 == 0) == None
test_ImmutableList_find()

# Generated at 2022-06-12 05:06:26.295438
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_1 = ImmutableList.of(2, 5, 8)
    list_2 = ImmutableList.of(2, 3)
    list_3 = ImmutableList.of(5, 8)
    list_4 = ImmutableList.of(3)
    list_5 = ImmutableList.of(5, 8, 11)
    list_6 = ImmutableList.of(2, 3, 5, 8)
    list_7 = ImmutableList.of(3, 5, 8, 11)
    list_8 = ImmutableList.of(2, 3, 5, 8, 11)
    list_9 = ImmutableList.of(2, 5, 8, 11)

    assert list_1.filter(lambda item: item % 2 == 0) == list_6

# Generated at 2022-06-12 05:06:32.274149
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Unit test for ImmutableList.filter
    """
    list_a = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_a.filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5)
    assert list_a.filter(lambda x: False) == ImmutableList.empty()
    assert list_a.filter(lambda x: True) == list_a
    assert list_a.filter(lambda x: x is 3) == ImmutableList.of(3)

# Generated at 2022-06-12 05:06:40.323218
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Lists
    l1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert l1.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

    # Empty list
    assert l1.filter(lambda x: x == 0) == ImmutableList.empty()

    # list with one element
    l2 = ImmutableList.of(1)
    assert l2.filter(lambda x: x == 1) == ImmutableList.of(1)


# Generated at 2022-06-12 05:06:44.425151
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of('one', 'two', 'three').find(
        lambda x: x == 'two'
    ) == 'two'
    assert ImmutableList.of('one', 'two', 'three').find(
        lambda x: x == 'four'
    ) == None


# Generated at 2022-06-12 05:06:51.996546
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(2, 4, 6, 8).filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6, 8]
    assert ImmutableList.of(1, 3, 5, 7).filter(lambda x: x % 2 == 0).to_list() == []


# Generated at 2022-06-12 05:06:55.236340
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    values = ImmutableList.of(1, 2, 3, 4, 5)\
            .filter(lambda x: x % 2 == 0)
    assert values == ImmutableList.of(2, 4)



# Generated at 2022-06-12 05:07:00.473437
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    assert ImmutableList.of(1, 2, 3, 4, 5, 6)\
        .filter(lambda number: number > 3)\
        .to_list() == [4, 5, 6]

    assert ImmutableList.of(1)\
        .filter(lambda number: number > 3)\
        .to_list() == []


# Generated at 2022-06-12 05:07:04.588100
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 2) is None
    assert ImmutableList(3, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 2) == 2
    assert ImmutableList(3, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 10) is None

# Generated at 2022-06-12 05:07:08.541206
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)

    def filter_range_3_5(val):
        return 3 <= val <= 5

    result = test_list.filter(filter_range_3_5)

    assert result == ImmutableList.of(3, 4, 5)