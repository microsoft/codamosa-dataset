

# Generated at 2022-06-12 04:59:05.564970
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of('value1') == ImmutableList.of('value1')
    assert ImmutableList.of('value1', 'value2', 'value3') == ImmutableList.of('value1', 'value2', 'value3')
    assert ImmutableList.of('value1', 'value2') != ImmutableList.of('value2', 'value1')
    assert ImmutableList.of('value1', 'value2') != 'ImmutableList'



# Generated at 2022-06-12 04:59:11.232280
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty_list = ImmutableList.empty()

    # empty list
    assert empty_list == ImmutableList()
    assert empty_list == ImmutableList.empty()

    # non empty list
    assert ImmutableList(3) == ImmutableList(3)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-12 04:59:14.816364
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

# Generated at 2022-06-12 04:59:24.529152
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    t = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    result = t.filter(lambda x: x % 2 == 0)
    assert result == ImmutableList.of(2, 4, 6)

    t = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    result = t.filter(lambda x: x % 2 == 1)
    assert result == ImmutableList.of(1, 3, 5, 7)

    t = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    result = t.filter(lambda x: x % 2 == 1).filter(lambda x: x > 3)
    assert result == ImmutableList.of(5, 7)


# Generated at 2022-06-12 04:59:33.311438
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(3) == ImmutableList(3)
    assert ImmutableList(3, ImmutableList(3)) == ImmutableList(3, ImmutableList(3))
    assert ImmutableList(3, ImmutableList(3)).__eq__(None) is False
    assert ImmutableList(3, ImmutableList(3)).__eq__('string') is False
    assert ImmutableList.empty().__eq__(1) is False
    assert ImmutableList(3, ImmutableList(3)).__eq__(2) is False
    assert ImmutableList(3, ImmutableList(3)).__eq__(ImmutableList(3, ImmutableList(3, ImmutableList(3)))) is False
    assert ImmutableList(3, ImmutableList(2))

# Generated at 2022-06-12 04:59:37.823391
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1) != ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-12 04:59:42.773204
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    b = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    c = ImmutableList(1, ImmutableList(4, ImmutableList(5)))
    assert a == b
    assert b == c

# Generated at 2022-06-12 04:59:46.549097
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(5, 3, 2)
    list_2 = ImmutableList.of(5, 3, 2)

    assert list_1 == list_2

    assert not (list_1 == ImmutableList.of(2, 3, 4))



# Generated at 2022-06-12 04:59:52.215874
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l1 = ImmutableList.of(1, 2, 3, 4)
    assert l1.filter(lambda x: x > 2).to_list() == [3, 4]

    l2 = ImmutableList.of(1, 2, 3, 4, 5)
    assert l2.filter(lambda x: x < 4).to_list() == [1, 2, 3]


# Generated at 2022-06-12 04:59:58.749804
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = ImmutableList.of(1, 2, 3, 4)
    list3 = ImmutableList.of(1, 2, 3)

    assert list1 == list2
    assert not list1 == list3
    assert list1 == list1
    assert not list1 == 1
    assert not list1 == None

# Generated at 2022-06-12 05:00:19.070976
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    assert ImmutableList.empty().filter(lambda x: x == x) == ImmutableList.empty()
    assert ImmutableList.of(1).filter(lambda x: x == x) == ImmutableList.of(1)
    assert ImmutableList.of(5).map(lambda x: x * x).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(3).map(lambda x: x * x).filter(lambda x: x % 2 == 1) == ImmutableList.of(9)


"""
ImmutableList.of(1, 2, 3, 4, 5)
    .map(lambda x: x * x)
    .filter(lambda x: x % 2 == 1)
    .reduce(lambda acc, e: acc + e, 0)
"""
# Unit

# Generated at 2022-06-12 05:00:30.658156
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # test with numbers
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2

    # test with strings
    assert ImmutableList.of('one', 'two', 'three', 'four', 'five').find(lambda x: len(x) > 4) == 'three'
    assert ImmutableList.of('one', 'two', 'three', 'four', 'five').find(lambda x: x[0] == 't') == 'two'

    # test with None
    assert ImmutableList.of(None, 'two', 3, True, 5).find(lambda x: x is None) is None
    assert ImmutableList.of

# Generated at 2022-06-12 05:00:42.331780
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList()\
        .filter(lambda el: el > 3)\
        .to_list() == ImmutableList().to_list()

    assert ImmutableList.of(1)\
        .filter(lambda el: el > 3)\
        .to_list() == ImmutableList().to_list()

    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda el: el > 3)\
        .to_list() == ImmutableList.of(4).to_list()

    assert ImmutableList.of(1, 2, 3, 4)\
        .filter(lambda el: el > 0)\
        .to_list() == ImmutableList.of(1, 2, 3, 4).to_list()



# Generated at 2022-06-12 05:00:51.031569
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda val: val == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda val: val == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda val: val == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda val: val > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda val: val > 3) == ImmutableList.empty()


# Generated at 2022-06-12 05:00:56.109494
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, -1).find(lambda n: n < 0) == -1
    assert ImmutableList.of(1, 2, -1).find(lambda n: n > 0) == 1
    assert ImmutableList.of(1, 2, None).find(lambda n: n == None) == None
    assert ImmutableList.empty().find(lambda n: False) == None


# Generated at 2022-06-12 05:01:01.304628
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    head = 1
    permutation = [2, 3, 4, 5, 6, 7, 8, 9, head]
    tail = ImmutableList.of(*permutation)
    list_with_tail = ImmutableList(head, tail)

    # When
    result = list_with_tail.find(lambda x: x == head)

    # Then
    assert 1 == result


# Generated at 2022-06-12 05:01:07.464823
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Example of how filter method works
    assert ImmutableList.of(1, 2, 5, 10, 45, 10).filter(lambda x: x > 5) == ImmutableList.of(10, 45, 10)
    assert ImmutableList.of(2, 35, 7, 10, 45, 10).filter(lambda x: x >= 10) == ImmutableList.of(35, 10, 45, 10)
    assert ImmutableList.of(1, 2, 5, 10, 45, 10).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 10, 10)

    # Empty list
    assert ImmutableList.empty().filter(lambda x: x > 5) == ImmutableList.empty()
    # List with one element

# Generated at 2022-06-12 05:01:14.176250
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def fn(el):
        return el > 1

    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.filter(fn) == ImmutableList.of(2, 3, 4)

    list_ = ImmutableList.of()
    assert list_.filter(fn) == ImmutableList.of()

    list_ = ImmutableList.of(1)
    assert list_.filter(fn) == ImmutableList.empty()


# Generated at 2022-06-12 05:01:20.654446
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2)

    def is_two(x):
        return x % 2 == 0

    assert list_.find(is_two) == 2

    list_ = ImmutableList.of(1, 3)

    assert list_.find(is_two) is None

    list_ = ImmutableList.of(1)

    assert list_.find(is_two) is None



# Generated at 2022-06-12 05:01:30.412312
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x>2) == ImmutableList.empty()

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)))\
        .filter(lambda x: x > 0)\
        .to_list()\
        == [1,2,3]

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)))\
        .filter(lambda x: x > 1)\
        .to_list()\
        == [2,3]

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)))\
        .filter(lambda x: x > 5)\
        .to_list()\
        == []

# Generated at 2022-06-12 05:01:47.223093
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(11, ImmutableList(22, ImmutableList(33))).find(lambda x: x > 20) == 22
    assert ImmutableList(11, ImmutableList(22, ImmutableList(33))).find(lambda x: x > 30) == 33
    assert ImmutableList(11, ImmutableList(22, ImmutableList(33))).find(lambda x: x > 40) == None
test_ImmutableList_find()

# Generated at 2022-06-12 05:01:53.366156
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 2) == 2, 'Test failed'
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) is None, 'Test failed'
    assert ImmutableList.empty().find(lambda x: x == 5) is None, 'Test failed'
    
    

# Generated at 2022-06-12 05:02:01.808140
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1).filter(lambda x: x == 2) == ImmutableList()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x not in [2, 3]) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x not in [1, 2, 3]) == ImmutableList()



# Generated at 2022-06-12 05:02:04.699878
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1, 2, 3, 4)
    l = l.filter(lambda val: val > 2)
    assert l.to_list() == [3, 4], "ImmutableList filter return wrong result"



# Generated at 2022-06-12 05:02:07.836904
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    lst = ImmutableList.of('a', 'b', 'c')

    def f(letter: str) -> bool:
        return letter != 'b'

    filtered = lst.filter(f)

    expected = ImmutableList.of('a', 'c')

    assert filtered == expected, 'result should be empty list'

# Generated at 2022-06-12 05:02:13.393804
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    container = ImmutableList.of(1, 2, 3, 4)
    new_container = container.filter(lambda x: x % 2 == 0)
    assert new_container == ImmutableList.of(2, 4)

    empty_container = ImmutableList.of()
    new_empty_container = empty_container.filter(lambda x: x % 2 == 0)
    assert new_empty_container == ImmutableList.of()



# Generated at 2022-06-12 05:02:16.409084
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)

    result = list_.filter(lambda x: x if x > 2 else None)
    assert result == ImmutableList.of(3, 4, 5)


# Generated at 2022-06-12 05:02:26.797069
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test with filtering simple list
    list_to_test = ImmutableList[int](0, ImmutableList[int](1, ImmutableList[int](2, ImmutableList[int](3, ImmutableList[int](4)))))
    assert list_to_test.filter(lambda x: x % 2 == 0).to_list() == [0, 2, 4]
    # Test with filtering empty list
    list_to_test = ImmutableList[int](is_empty=True)
    assert list_to_test.filter(lambda x: x % 2 == 0).to_list() == []
    # Test with filtering one element list
    list_to_test = ImmutableList[int](0)
    assert list_to_test.filter(lambda x: x % 2 == 0).to_list() == [0]


# Unit

# Generated at 2022-06-12 05:02:31.584325
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    list_of_numbers = ImmutableList.of(1, 2, 3)
    # when
    result = list_of_numbers.filter(lambda x: x % 2 == 0)
    # then
    assert result == ImmutableList.of(2)

# Generated at 2022-06-12 05:02:38.573760
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert list.filter(lambda x: x == 5) == ImmutableList.of(5)
    assert list.filter(lambda x: x == 1) == ImmutableList.of(1)
    assert list.filter(lambda x: x == 10) == ImmutableList.empty()


# Generated at 2022-06-12 05:02:53.408697
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert \
       ImmutableList.of(1, 2, 3, 4)\
            .filter(lambda v: v % 2 == 0)\
            .to_list() == [2, 4]



# Generated at 2022-06-12 05:03:01.285526
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    empty_list = ImmutableList.empty()
    list_with_number = ImmutableList.of(1)
    list_with_strings = ImmutableList.of('string', 'string1', 'string1')

    # Act
    empty_result = empty_list.find(lambda value: value == 1)
    result_from_list_with_number = list_with_number.find(lambda value: value == 1)
    result_from_list_with_strings = list_with_strings.find(lambda value: value == 'string1')

    # Assert
    assert empty_result is None
    assert result_from_list_with_number == 1
    assert result_from_list_with_strings == 'string1'


# Generated at 2022-06-12 05:03:09.963393
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5.5).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5.5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5.5).find(lambda x: x == 5.5) == 5.5
    assert ImmutableList.of(1, 2, 3, 4, 5.5).find(lambda x: x == 5.6) is None


# Generated at 2022-06-12 05:03:13.532141
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1,2,3)
    new_list = list_.filter(lambda x: x > 2)
    assert new_list.to_list() == [3]
    

# Generated at 2022-06-12 05:03:16.642637
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_numbers = ImmutableList.of(1, 2, 3, 4, 5)
    odd_numbers_list = list_of_numbers.filter(lambda element: element % 2 == 1)
    assert odd_numbers_list.head == 1
    assert odd_numbers_list.tail.head == 3
    assert odd_numbers_list.tail.tail.head == 5
    assert odd_numbers_list.tail.tail.tail is None



# Generated at 2022-06-12 05:03:23.799859
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    xs = ImmutableList.of(1, 2, 3)
    x = xs.find(lambda item: item == 3)
    assert x == 3, x
    x = xs.find(lambda item: item == 0)
    assert x is None, x
    x = xs.find(lambda item: item > 2)
    assert x == 3, x
    x = xs.find(lambda item: item > 3)
    assert x is None, x
    x = ImmutableList.empty().find(lambda item: True)
    assert x is None, x



# Generated at 2022-06-12 05:03:28.445195
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda i: i == 1) == 1
    assert ImmutableList(1, ImmutableList(3)).find(lambda i: i == 2) is None


# Generated at 2022-06-12 05:03:32.997585
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    first_list = ImmutableList.of(1, 2, 3, 4, 5)
    second_list = first_list.filter(lambda x: x > 4)

    assert second_list == ImmutableList(5)
    assert first_list == ImmutableList(1, 2, 3, 4, 5)


# Generated at 2022-06-12 05:03:36.354080
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    def filter_fn(x):
        return x % 2 == 0

    # When
    filter_result = list.filter(filter_fn)

    # Then
    assert filter_result == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-12 05:03:40.343992
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    res = a.filter(lambda x: x % 2 == 0)
    assert res == ImmutableList(2)
    assert a == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-12 05:04:12.874703
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda item: True) == ImmutableList.empty(), \
        'ImmutableList: filter method empty list'

    assert ImmutableList.of(1, 2, 3).filter(lambda item: True) == ImmutableList.of(1, 2, 3), \
        'ImmutableList: filter method should not filter anything of list with all elements'

    assert ImmutableList.of(1, 2, 3).filter(lambda item: False) == ImmutableList.empty(), \
        'ImmutableList: filter method should filter everything of list with all elements'

    assert ImmutableList.of(1, 2, 3).filter(lambda item: item == 2) == ImmutableList.of(2), \
        'ImmutableList: filter method should filter everything of list with all elements'

# Generated at 2022-06-12 05:04:14.875921
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList([100, 200, 300]).find(lambda x: x % 2 == 0) == 200

# Generated at 2022-06-12 05:04:19.838994
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ll = ImmutableList.of('a', 'b', 'c', 'd')
    assert ll.find(lambda x: x == 'a') == 'a'
    assert ll.find(lambda x: x == 'd') == 'd'
    assert ll.find(lambda x: x == 'e') is None


# Generated at 2022-06-12 05:04:23.694258
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of('a', 'b', 'c')
    new_il = il.filter(lambda x: x == 'a')
    assert ImmutableList.of('a') == new_il



# Generated at 2022-06-12 05:04:27.427340
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ =  ImmutableList.of(1, 2, 3, 10, 15)

    filter_fn = lambda n: n % 2 == 0

    expected = ImmutableList.of(2, 10)
    actual_value = list_.filter(filter_fn)

    assert actual_value == expected

# Generated at 2022-06-12 05:04:36.480521
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(
        lambda x: x == 1
    ) == ImmutableList.of(1)

    assert ImmutableList.of(1).filter(
            lambda x: x == 2
        ) == ImmutableList.empty()

    assert ImmutableList.of(1).filter(
            lambda x: x == 2
        ) == ImmutableList.of(2)

    assert ImmutableList.of(1).filter(
            lambda x: x == 2
        ) == ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(1, 2, 3, 4, 5).filter(
            lambda x: x % 2 == 0
        ) == ImmutableList.of(2, 4)



# Generated at 2022-06-12 05:04:39.643334
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3)
    filtered = list_.filter(lambda x: x > 2)

    assert filtered == ImmutableList.of(3)



# Generated at 2022-06-12 05:04:43.614072
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_.filter(lambda x: x % 2 == 0).to_list() == [2, 4]



# Generated at 2022-06-12 05:04:48.704056
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 8) is None
    assert ImmutableList.empty().find(lambda x: x == 8) is None

# Generated at 2022-06-12 05:04:53.694927
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def even(n: int) -> bool:
        return n % 2 == 0

    list_of_numbers = ImmutableList.of(1, 3, 4, 6, 10, 13)
    expected_evens = [4, 6, 10]
    assert list_of_numbers.filter(even).to_list() == expected_evens, "Wrong result of filter method"



# Generated at 2022-06-12 05:05:47.602018
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    result = test_list.find(lambda x: x > 2)

    assert result == 3, "test_ImmutableList_find is not working"

# Generated at 2022-06-12 05:05:57.715391
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 3).to_list() == [4]
    assert ImmutableList.empty().filter(lambda x: x == 1).to_list() == []
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == 1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 0).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 10).to_list() == []


# Generated at 2022-06-12 05:06:01.683847
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_.find(lambda x: x > 4) == 5
    assert list_.find(lambda x: x == 3) == 3
    assert list_.find(lambda x: x < 4) == 1
    assert list_.find(lambda x: x < 0) is None
    assert ImmutableList.empty().find(lambda x: x < 4) is None


# Generated at 2022-06-12 05:06:05.687083
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 2) == 2

    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 7) == None

    assert ImmutableList.empty().find(lambda x: False) == None

# Generated at 2022-06-12 05:06:10.129854
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    actual = ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0)
    expected = ImmutableList.of(2, 4)
    assert actual == expected

# Generated at 2022-06-12 05:06:12.746077
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    words = ImmutableList.of('the', 'cat', 'in', 'the', 'hat', 'sat')

    assert words.find(lambda x: x == 'cat') == 'cat'
    assert words.find(lambda x: x == 'dog') is None


# Generated at 2022-06-12 05:06:20.340921
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 2) is None
    assert ImmutableList(1).find(lambda x: x == 2) is None
    assert ImmutableList(1).find(lambda x: x == 1) is 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) is 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) is None


# Generated at 2022-06-12 05:06:31.214143
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    lst = ImmutableList.of(2, 3, 4, 5, 6)
    filtered_lst = lst.filter(lambda x: x > 3)
    #assert filtered_lst == ImmutableList.of(4, 5, 6)

    filtered_lst2 = lst.filter(lambda x: x > 10)
    assert filtered_lst2 == ImmutableList.empty()

    lst2 = ImmutableList.of(3, 4, 7, 8, 1)
    filtered_lst3 = lst2.filter(lambda x: x % 2 == 0)
    #assert filtered_lst3 == ImmutableList.of(4, 8)
    assert isinstance(filtered_lst3, ImmutableList)


# Generated at 2022-06-12 05:06:42.464876
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == 123) is None
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == -123) is None
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == 0) is None

# Generated at 2022-06-12 05:06:46.383760
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda x: x > 3) == ImmutableList.of(4, 5)

    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda x: x > 5) == ImmutableList.empty()



# Generated at 2022-06-12 05:08:55.557780
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    a = ImmutableList(1)
    b = ImmutableList(2)
    c = ImmutableList(3)
    d = ImmutableList(4)
    actual = a.__add__(b).__add__(c).__add__(d).find(lambda x: x % 2 == 0) # change when refactoring this code
    expected = 2 # change when refactoring this code
    return repr(actual) == repr(expected) # change when refactoring this code
