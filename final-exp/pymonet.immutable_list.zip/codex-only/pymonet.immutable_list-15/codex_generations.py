

# Generated at 2022-06-24 00:07:00.753084
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_array = ImmutableList.of(1, 2, 3)
    second_array = ImmutableList.of(4, 5, 6)
    expected_array = ImmutableList.of(1, 2, 3, 4, 5, 6)
    actual_array = first_array + second_array
    assert expected_array == actual_array


# Generated at 2022-06-24 00:07:04.863702
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.empty().to_list() == []

# Generated at 2022-06-24 00:07:06.864813
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert str(list) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:07:10.858337
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2).map(lambda x: x+1) == ImmutableList(2, ImmutableList(3))


# Generated at 2022-06-24 00:07:14.116213
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList.of(1, 2, 3, 4)
    assert a.reduce(lambda acc, x: acc + x, 0) == 10


# Generated at 2022-06-24 00:07:16.298705
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    new_list = ImmutableList.of(1, 2, 3)

    assert len(new_list) == 3


# Generated at 2022-06-24 00:07:23.973247
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    def mapper(num) -> int:
        return num * num

    assert ImmutableList.of(1).map(mapper) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).map(mapper) == ImmutableList.of(1, 4)
    assert ImmutableList.of(1, 2, 3).map(mapper) == ImmutableList.of(1, 4, 9)
    assert ImmutableList.empty().map(mapper) == ImmutableList.empty()
# Unit tests for method filter of class ImmutableList

# Generated at 2022-06-24 00:07:29.259098
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: x) is None
    assert ImmutableList(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList(1, 2, 3).find(lambda x: x == 4) == None



# Generated at 2022-06-24 00:07:34.150534
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    testData = ImmutableList.of(1, 2, 3, 4)
    testDataFiltered = testData.filter(lambda i: i >= 3)
    assert isinstance(testDataFiltered, ImmutableList)
    assert testDataFiltered == ImmutableList(3, ImmutableList(4))
    assert testDataFiltered.to_list() == [3, 4]
    assert testDataFiltered.to_list() == [x for x in [1, 2, 3, 4] if x >= 3]


# Generated at 2022-06-24 00:07:39.458944
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.empty().__str__() == 'ImmutableList[]'

    assert ImmutableList(8).__str__() == 'ImmutableList[8]'

    assert ImmutableList('quack', ImmutableList('bark', ImmutableList('shriek', ImmutableList('moo')))).__str__() == 'ImmutableList[quack, bark, shriek, moo]'


# Generated at 2022-06-24 00:07:45.337075
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Case 1
    assert ImmutableList.of("a").to_list() == ["a"]
    # Case 2
    assert ImmutableList.of("a", "b", "c", "d").to_list() == ["a", "b", "c", "d"]
    # Case 3
    assert ImmutableList.of("a", "b", "c", "d", "e", "f").to_list() == ["a", "b", "c", "d", "e", "f"]



# Generated at 2022-06-24 00:07:48.633942
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.empty().unshift(1)
    r = ImmutableList.of(1)
    assert l == r

    l = ImmutableList.of(1, 2, 3).unshift(10)
    r = ImmutableList.of(10, 1, 2, 3)
    assert l == r


# Generated at 2022-06-24 00:07:51.954483
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]

# Generated at 2022-06-24 00:07:54.517580
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 2)
    l2 = ImmutableList.of(1, 2)

    assert l1 == l2



# Generated at 2022-06-24 00:07:59.044750
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 0) == 6
    assert ImmutableList.of('1', '2', '3').reduce(lambda a, b: a + b, '') == '123'
    assert ImmutableList.empty().reduce(lambda a, b: a + b, '') == ''



# Generated at 2022-06-24 00:08:02.997795
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    arg = [0, 1, 2, 3]

    assert isinstance(ImmutableList.of(*arg), ImmutableList)


# Generated at 2022-06-24 00:08:06.561114
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 2) == 2
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 3) is None


# Generated at 2022-06-24 00:08:14.849681
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4).unshift(5) == ImmutableList.of(5, 1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).unshift(6) == ImmutableList.of(6, 1, 2, 3, 4, 5)




# Generated at 2022-06-24 00:08:23.301890
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    
    assert ImmutableList(1) != ImmutableList(1, ImmutableList(2))

    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))

    assert ImmutableList(1) == ImmutableList(1)

    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))

# Generated at 2022-06-24 00:08:25.606597
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    result = ImmutableList.of(1, 2, 3)

    assert str(result) == 'ImmutableList[1, 2, 3]'



# Generated at 2022-06-24 00:08:32.326061
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Given
    initial_list = ImmutableList(1, ImmutableList(2), False)
    expected_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    # When
    actual_list = initial_list.append(3)
    # Then
    assert actual_list == expected_list
    
    # Given
    initial_list = ImmutableList(is_empty=True)
    expected_list = ImmutableList(1)
    # When
    actual_list = initial_list.append(1)
    # Then
    assert actual_list == expected_list

# Generated at 2022-06-24 00:08:34.677585
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:08:45.993794
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    lst = ImmutableList()
    lst_mapped = lst.map(lambda x: x * x)
    assert lst_mapped.head is None and lst_mapped.tail is None  # True

    lst = ImmutableList(2.0)
    lst_mapped = lst.map(lambda x: x ** 2)
    assert lst_mapped.head == 4.0 and lst_mapped.tail is None  # True

    lst = ImmutableList.of(-1, 0, 1, 2)
    lst_mapped = lst.map(lambda x: x ** 2)
    assert \
        lst_mapped.head == 1 and\
        lst_mapped.tail.head == 0 and\
        lst_mapped.tail.tail.head == 1

# Generated at 2022-06-24 00:08:51.777214
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    instance_1 = ImmutableList.of(4)
    instance_2 = ImmutableList.of(4)
    instance_3 = ImmutableList.of(3)
    instance_4 = ImmutableList.empty()
    instance_5 = ImmutableList.empty()
    instance_6 = ImmutableList.of(4, 2, 5)
    instance_7 = ImmutableList.of(4, 2, 5)
    instance_8 = ImmutableList.of(4, 5)

    assert instance_1 == instance_2
    assert instance_1 != instance_3
    assert instance_4 == instance_5
    assert instance_6 == instance_7
    assert instance_6 != instance_8


# Generated at 2022-06-24 00:08:59.224336
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5, 6)
    assert ImmutableList.of(-5, -4, -3, -2, -1).map(lambda x: x + 5) == ImmutableList.of(0, 1, 2, 3, 4)
    assert ImmutableList.empty().map(lambda x: x + 1) == ImmutableList.empty()


# Generated at 2022-06-24 00:09:05.909214
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3, 'ImmutableList: length should be 3 when 3 items provided'
    assert len(ImmutableList.of(1)) == 1, 'ImmutableList: length should be 1 when only one item provided'
    assert len(ImmutableList.of()) == 0, 'ImmutableList: length should be 0 when no items provided'

# Generated at 2022-06-24 00:09:08.737284
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3).append(0) == ImmutableList.of(1, 2, 3, 0)



# Generated at 2022-06-24 00:09:16.510742
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList('a').__str__() == 'ImmutableList[a]'
    assert ImmutableList('a', 'b').__str__() == 'ImmutableList[a, b]'
    assert ImmutableList('a', 'b', 'c').__str__() == 'ImmutableList[a, b, c]'
    assert ImmutableList('a', 'b', 'c', 'd').__str__() == 'ImmutableList[a, b, c, d]'


# Generated at 2022-06-24 00:09:25.854981
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of('a', 'b', 'c').map(lambda x: x.upper()) == ImmutableList.of('A', 'B', 'C')
    assert type(ImmutableList.of('a', 'b', 'c').map(lambda x: x.upper())) == ImmutableList
    assert len(ImmutableList.of('a', 'b', 'c').map(lambda x: x.upper())) == 3

    assert len(ImmutableList.of(1, 2, 3, 4).map(lambda x: x * 2)) == 4
    assert ImmutableList.empty().map(lambda x: x.upper()) == ImmutableList.empty()



# Generated at 2022-06-24 00:09:29.695623
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    non_empty_list = ImmutableList.of('a')
    new_list = non_empty_list.append('b')
    assert new_list.to_list() == ['a', 'b']
    assert non_empty_list.to_list() == ['a']


# Generated at 2022-06-24 00:09:32.979315
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of('a', 'b', 'c').filter(lambda x: x == 'a') == ImmutableList.of('a')
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

# Generated at 2022-06-24 00:09:36.707587
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(0)) == 'ImmutableList[0]'
    assert str(ImmutableList(0, ImmutableList(1))) == 'ImmutableList[0, 1]'
    assert str(ImmutableList(is_empty=True)) == 'ImmutableList[]'


# Generated at 2022-06-24 00:09:44.738548
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Case where we create new ImmutableList with element 1 filtered by lambda expression
    # and result we compare with empty ImmutableList
    assert ImmutableList.of(1).filter(lambda x: x == 0) == ImmutableList.empty()

    # Case where we create new ImmutableList with 2 elements where 1 is filtered
    # and result we compare with empty ImmutableList
    assert ImmutableList.of(0, 1).filter(lambda x: x == 0) == ImmutableList.empty()

    # Case where we create new ImmutableList with 2 elements where 1 is filtered
    # and result we compare with new ImmutableList with element 1 only
    assert ImmutableList.of(0, 1).filter(lambda x: x > 0) == ImmutableList.of(1)

    # Case where we create new ImmutableList with 3 elements where 1 is filtered


# Generated at 2022-06-24 00:09:52.398707
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1).reduce(lambda acc, el: acc + el, 0) == 1
    assert ImmutableList.of(1,2,3,4).reduce(lambda acc, el: acc + el, 0) == 10
    assert ImmutableList.of(1,2,3,4).reduce(lambda acc, el: acc * el, 1) == 24

test_ImmutableList_reduce()

# Generated at 2022-06-24 00:09:58.075443
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2), is_empty=True)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 4


# Generated at 2022-06-24 00:10:05.504783
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)  # positive
    assert ImmutableList.empty().unshift(0) == ImmutableList.of(0)  # positive
    assert ImmutableList.empty().unshift(10) != ImmutableList.empty()  # negative
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)  # positive
    assert ImmutableList.of(1, 2, 3).unshift(0) != ImmutableList.of(1, 2, 0, 3)  # negative


# Generated at 2022-06-24 00:10:08.410171
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    maybe = ImmutableList.of(1, 2, 3)
    assert "ImmutableList[1, 2, 3]" == maybe.__str__()


# Generated at 2022-06-24 00:10:11.556571
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    mlist = ImmutableList.of(1, 2, 3, 4, 5)

    acc = mlist.reduce(lambda acc, val: acc + val, 0)

    assert acc == 15


# Generated at 2022-06-24 00:10:16.412545
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]

    assert ImmutableList.of(1, 2, 3, 4).to_list() == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).to_list()


# Generated at 2022-06-24 00:10:19.668211
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():  # pragma: no cover
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:10:22.978797
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list1 = ImmutableList.of(1, 2, 3)
    assert list1.to_list() == [1, 2, 3]

    list2 = list1.to_list()
    assert list2 == [1, 2, 3]

# Generated at 2022-06-24 00:10:27.169458
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(None, 1, None, 2, 3).to_list() == [None, 1, None, 2, 3]

# Generated at 2022-06-24 00:10:31.795755
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5, 6)
    assert ImmutableList.of().map(lambda x: x + 1) == ImmutableList.of()
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).map(lambda x: x + 1) == ImmutableList.of(2,3)


# Generated at 2022-06-24 00:10:32.350707
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    pass

# Generated at 2022-06-24 00:10:38.254063
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    l = ImmutableList.of(1, 2, 3, 4)
    # When
    result = l.to_list()
    # Then
    assert result == [1, 2, 3, 4]


# Generated at 2022-06-24 00:10:43.365203
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x%2==0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x>=3) == ImmutableList.of(3, 4)
    assert ImmutableList.empty().filter(lambda x: x>=3) == ImmutableList.empty()

test_ImmutableList_filter()

# Generated at 2022-06-24 00:10:45.502751
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Test with normal list
    assert(ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, el: acc + el, 0) == 15)

    # Test with empty list
    assert(ImmutableList.empty().reduce(lambda acc, el: acc + el, 0) == 0)

# Generated at 2022-06-24 00:10:48.861697
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    ImmutableList.of(2, 3, 4, 5, 6).reduce(lambda a, b: a + b, 0) == 20
    ImmutableList.of(2, 2, 2, 2, 2).reduce(lambda a, b: a + b, 0) == 10
    ImmutableList.of(2, 3, 4, 5, 6).reduce(lambda a, b: a * b, 1) == 720

# Generated at 2022-06-24 00:10:51.486990
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1, ImmutableList.empty())
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2, ImmutableList.empty()))

test_ImmutableList()

# Generated at 2022-06-24 00:11:03.715416
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of('a', 'b', 'c')
    assert list.find(lambda item: item == 'b') == 'b', 'Should return value that return True from argument function'
    assert list.find(lambda item: item == 'c') == 'c', 'Should return value that return True from argument function'
    assert list.find(lambda item: item != 'c') != 'c', 'Should return value that return True from argument function'
    assert list.find(lambda item: item == 'e') is None, 'Should return None'
    assert list.find(lambda item: item == 'a') == 'a', 'Should return value that return True from argument function'
    assert list.find(lambda item: item == '') is None, 'Should return None'

# Generated at 2022-06-24 00:11:15.425929
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_for_test = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_for_test.reduce(lambda x, y: x + y, 0) == 15
    assert list_for_test.reduce(lambda x, y: x - y, 0) == -15
    assert list_for_test.reduce(lambda x, y: x*y, 1) == 120
    assert list_for_test.reduce(lambda x, y: x//y, 100) == 0
    assert list_for_test.reduce(lambda x, y: x**y, 2) == 1073741824
    assert list_for_test.reduce(lambda x, y: (x-y)/2, 10) == 1.25


# Generated at 2022-06-24 00:11:19.999399
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1).head == 1
    assert ImmutableList('s').head == 's'
    assert ImmutableList(is_empty=True).is_empty


# Generated at 2022-06-24 00:11:23.855345
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    test_ImmutableList = ImmutableList.of('test_ImmutableList', 'test_ImmutableList_two')

    assert str(test_ImmutableList) == "ImmutableList['test_ImmutableList', 'test_ImmutableList_two']"


# Generated at 2022-06-24 00:11:29.960140
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():   
    assert ImmutableList.of(1,2,3).map(lambda x: x+1) == ImmutableList.of(2,3,4)
    assert ImmutableList.empty().map(lambda x: x+1) == ImmutableList.empty()
    assert ImmutableList.of(1).map(lambda x: x+1) == ImmutableList.of(2)


# Generated at 2022-06-24 00:11:37.268847
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList[]' == str(ImmutableList())
    assert 'ImmutableList[1]' == str(ImmutableList(1))
    assert 'ImmutableList[1, 2]' == str(ImmutableList(1, ImmutableList(2)))
    assert 'ImmutableList[1, 2, 3]' == str(ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    assert 'ImmutableList[1, 2, 3, 4]' == str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))))


# Generated at 2022-06-24 00:11:45.638671
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x * y, 1) == 24
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x + y, 0) == 10
    assert ImmutableList.of(4, 3, 2, 1).reduce(lambda x, y: x - y, 0) == 0
    assert ImmutableList.empty().reduce(lambda x, y: x - y, 0) == 0
test_ImmutableList_reduce()

# Generated at 2022-06-24 00:11:54.216439
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x > 1) == ImmutableList.of(False, True, True)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 3) == ImmutableList.of(3, 6, 9)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x // 2) == ImmutableList.of(0, 1, 1)


# Generated at 2022-06-24 00:11:57.628410
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList.of(1, 2, 3, 4)
    expected_result = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert immutable_list == expected_result

# Generated at 2022-06-24 00:12:00.149187
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert test_list.to_list() == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-24 00:12:03.628081
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Arrange
    list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    expected = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(10))))

    # Act
    result = list.append(10)

    # Assert
    assert result == expected



# Generated at 2022-06-24 00:12:08.042393
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    sample_list = ImmutableList.of(1,2,3,4,5)
    mapped_sample_list = sample_list.map(lambda x: x*x)
    assert mapped_sample_list.to_list() == [1, 4, 9, 16, 25]
    assert sample_list.to_list() == [1,2,3,4,5]


# Generated at 2022-06-24 00:12:12.256586
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    a = ImmutableList.of(1)
    b = a.append(2)
    assert len(a) == 1
    assert a == ImmutableList(1)

    assert len(b) == 2
    assert b == ImmutableList(1, 2)


# Generated at 2022-06-24 00:12:15.901453
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Prepare
    test_immutable_list_1 = ImmutableList.of(1, 2, 3)

    # Assert
    assert test_immutable_list_1.unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:12:19.319015
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1, 2, 3)
    new_list = list_.append(4)
    assert new_list == ImmutableList.of(1, 2, 3, 4)
    assert list_ == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:12:25.427484
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(2)
    appended_list = list_.append(3)
    assert appended_list == ImmutableList(2, ImmutableList(3))
    assert appended_list.to_list() == [2, 3]
    assert list_ == ImmutableList(2)
    assert list_.to_list() == [2]


# Generated at 2022-06-24 00:12:28.717687
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of()) == 0


# Unit tests of class ImmutableList

# Generated at 2022-06-24 00:12:32.158262
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))


# Generated at 2022-06-24 00:12:38.219885
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x * y, 1) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x % y, 2) == 0
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x % y, 5) == 1

# Generated at 2022-06-24 00:12:40.576228
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert (
        ImmutableList.of('Nero', 'Julius', 'Cesar').filter(lambda value: value[0].upper() == 'J')
        == ImmutableList.of('Julius')
    )



# Generated at 2022-06-24 00:12:44.656136
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList.of(4, 2, 1)
    assert l.reduce(lambda acc, val: acc + val, 0) == 7

    assert l.reduce(lambda acc, val: acc + val, 3) == 10

    assert l.reduce(lambda acc, val: acc + val, -3) == 7

# Generated at 2022-06-24 00:12:48.011389
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():

    assert len(ImmutableList.of('foo')) == 1
    assert len(ImmutableList.of(1, 3, 6, 4)) == 4
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:12:51.205615
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1, 2, 3)) == 3
# Unit tests for method __str__ of class ImmutableList

# Generated at 2022-06-24 00:12:54.649520
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:13:05.409390
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    case1 = ImmutableList.of(1,2,3,4,5,6)
    assert case1.find(lambda x: x == 1) == 1
    assert case1.find(lambda x: x > 5) == 6
    assert case1.find(lambda x: x == 13) == None

    case2 = ImmutableList.of(None, None, None)
    assert case2.find(lambda x: x == 1) == None
    assert case2.find(lambda x: x > 5) == None
    assert case2.find(lambda x: x == 13) == None
    assert case2.find(lambda x: x == None) == None

    case3 = ImmutableList.of('hello', 'world')
    assert case3.find(lambda x: x == 1) == None

# Generated at 2022-06-24 00:13:11.152350
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Define expected result
    expected_result = "ImmutableList[1, 2, 3, 4]"
    
    # Make test
    _list = ImmutableList.of(1, 2, 3, 4)
    result = str(_list)

    # Assert expected result
    assert expected_result == result


# Generated at 2022-06-24 00:13:15.117043
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList(2)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList(2, 3, 4)

# Generated at 2022-06-24 00:13:19.652486
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list1 = ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:13:24.586413
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of('a', 'b', 'c')) == 3


# Generated at 2022-06-24 00:13:31.800313
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    from hamcrest import assert_that, equal_to

    assert_that(ImmutableList.empty() == ImmutableList.empty(), equal_to(True))
    assert_that(ImmutableList(1) == ImmutableList(1), equal_to(True))
    assert_that(ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2)), equal_to(True))
    assert_that(ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3), equal_to(True))

    
    assert_that(ImmutableList.empty() == ImmutableList(1), equal_to(False))
    assert_that(ImmutableList(1) == ImmutableList(2), equal_to(False))

# Generated at 2022-06-24 00:13:39.408765
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    '''
    This test check class ImmutableList method find
    '''
    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_equals(x):
        return x == 0

    assert ImmutableList.of(1, 2, -1).find(is_positive) == 1
    assert ImmutableList.of(1, 2, -1).find(is_negative) == -1
    assert ImmutableList.of(1, 2, -1).find(is_equals) == None
    assert ImmutableList.of(1, 2, -1, 0).find(is_equals) == 0



# Generated at 2022-06-24 00:13:43.939948
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2), is_empty=False)) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(is_empty=True)) == 'ImmutableList[]'



# Generated at 2022-06-24 00:13:51.977417
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(2, 3, 4).reduce(lambda acc, x: acc + x, 1) == 10
    assert ImmutableList.of(2, 3, 2).reduce(lambda acc, x: acc * x, 1) == 12
    assert ImmutableList.of(2).reduce(lambda acc, x: acc * x, 1) == 2
    assert ImmutableList.of(1).reduce(lambda acc, x: acc ** x, 4) == 4
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc ** x, 4) == 262144


# Generated at 2022-06-24 00:13:59.655899
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of('a', 'b', 'c').append('d') == ImmutableList.of('a', 'b', 'c', 'd')
    assert ImmutableList.of('a', 'b', 'c').append(True) == ImmutableList.of('a', 'b', 'c', True)


# Generated at 2022-06-24 00:14:02.320554
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    lst = ImmutableList.of(1, 2, 3, 4, 5)
    assert lst.reduce(lambda acc, el: acc * el, 1) == 120



# Generated at 2022-06-24 00:14:09.137185
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(0, 1, 2, 3)) == 'ImmutableList[0, 1, 2, 3]'
    assert str(ImmutableList.of('test')) == "ImmutableList['test']"
    assert str(ImmutableList.empty()) == 'ImmutableList[]'


# Generated at 2022-06-24 00:14:16.064232
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    def add(a, b):
        return a + b

    assert ImmutableList.empty().reduce(add, 2) == 2
    assert ImmutableList.of(1).reduce(add, 2) == 3
    assert ImmutableList.of(1, 2).reduce(add, 3) == 6
    assert ImmutableList.of(1, 2, 3).reduce(add, 4) == 10


# Generated at 2022-06-24 00:14:20.181133
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Arrange
    list = ImmutableList.of(1, 2, 3)

    # Act
    result = len(list)

    # Assert
    assert result == 3, "Expected len(list) = 3, but got {}".format(result)



# Generated at 2022-06-24 00:14:23.673000
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))) == 5

# Generated at 2022-06-24 00:14:29.515107
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList([1, 2, 3]).reduce(lambda acc, item: acc + item, 0) == 6

# Generated at 2022-06-24 00:14:32.361144
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    li = ImmutableList.of('a', 'b', 'c')
    result = li.filter(lambda x: x != 'b')
    assert result.to_list() == ['a', 'c']

# Generated at 2022-06-24 00:14:39.227685
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of('foo') + ImmutableList.of('bar') == ImmutableList('foo', ImmutableList('bar'))
    assert ImmutableList.of('foo', 'bar') + ImmutableList.of('baz') == ImmutableList('foo', ImmutableList('bar', ImmutableList('baz')))


# Generated at 2022-06-24 00:14:45.265215
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2))) == "ImmutableList[1, 2]"
    assert str(ImmutableList(1)) == "ImmutableList[1]"
    assert str(ImmutableList(is_empty=True)) == "ImmutableList[]"

# Generated at 2022-06-24 00:14:50.767590
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: y, 1) == 1

    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6

    assert ImmutableList.of(1, None, 2, 3).reduce(lambda x, y: x + y, 0) == 6

    assert ImmutableList.of(1, None, 2, 3).reduce(lambda x, y: x + y, 10) == 16


# Generated at 2022-06-24 00:14:55.533817
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList[int](None, None, True) == ImmutableList[int](is_empty=True)
    assert ImmutableList.of("a", "b", "c").__str__() == "ImmutableList['a', 'b', 'c']"
    print("test_ImmutableList___str__ - success")


# Generated at 2022-06-24 00:14:59.001645
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_1 = ImmutableList.of(1, 2)
    list_2 = ImmutableList.of(2, 3)
    assert list_1.append(3) == list_2


# Generated at 2022-06-24 00:15:03.655676
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    string_list = ImmutableList.of('foo', 'bar', 'baz')
    assert string_list.find(lambda p: p == 'bar') == 'bar'


# Generated at 2022-06-24 00:15:12.499057
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # test_of
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    # test_empty
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    # test_add
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-24 00:15:22.372902
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(ImmutableList.empty())
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1) != ImmutableList()
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:15:31.952163
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # arrange
    input_1 = ImmutableList.empty()
    input_2 = ImmutableList.empty()

    input_3 = ImmutableList(1, ImmutableList(2))
    input_4 = ImmutableList(1, ImmutableList(2))

    # act
    result_1 = input_1.__eq__(input_2)
    result_2 = input_1.__eq__(input_3)
    result_3 = input_3.__eq__(input_4)

    # assert
    assert result_1 is True
    assert result_2 is False
    assert result_3 is True


# Generated at 2022-06-24 00:15:34.992993
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1)
    new_list = list_.append(2)
    assert list_ != new_list
    assert list_.to_list() == [1]
    assert new_list.to_list() == [1, 2]


# Generated at 2022-06-24 00:15:40.980634
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    x = ImmutableList.of(1, 2, 3, 4)  # 1 -> 2 -> 3 -> 4 -> None
    f = lambda x: x == 3

    # when
    y = x.find(f)

    # then
    assert y == 3

# Generated at 2022-06-24 00:15:44.500003
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == "ImmutableList[]"
    assert str(ImmutableList(1)) == "ImmutableList[1]"
    assert str(ImmutableList(1, ImmutableList(2))) == "ImmutableList[1, 2]"



# Generated at 2022-06-24 00:15:46.799858
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)



# Generated at 2022-06-24 00:15:50.480643
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.empty().to_list() == []


# Generated at 2022-06-24 00:15:55.771506
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.empty()
    test_result = list.unshift(1)
    expected_result = ImmutableList.of(1)
    print(test_result)
    print(expected_result)
    assert test_result == expected_result
    print('test for method unshift is passed')

# Generated at 2022-06-24 00:16:03.549985
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    my_list = ImmutableList()

    it(my_list.append(2)).should.equal(ImmutableList.of(2))
    it(my_list.append(2).append(3)).should.equal(ImmutableList.of(2, 3))
    it(my_list.append(2).append(3).append(4)).should.equal(ImmutableList.of(2, 3, 4))
    it(my_list.append(2).append(3).append(4).append(5)).should.equal(ImmutableList.of(2, 3, 4, 5))
    it(my_list.append(2).append(3).append(4).append(5).append(6)).should.equal(ImmutableList.of(2, 3, 4, 5, 6))

# Generated at 2022-06-24 00:16:06.740785
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1,2,3).filter(lambda x: x > 0) == ImmutableList.of(1,2,3)
    assert ImmutableList.of(1,2,3).filter(lambda x: x < 0) == ImmutableList.empty()


# Generated at 2022-06-24 00:16:12.074337
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_empty = ImmutableList.empty()
    assert str(list_empty) == 'ImmutableList[]'

    list_not_empty = ImmutableList.of(1)
    assert str(list_not_empty) == 'ImmutableList[1]'

    list_not_empty = ImmutableList.of(1, 2, 4)
    assert str(list_not_empty) == 'ImmutableList[1, 2, 4]'



# Generated at 2022-06-24 00:16:21.016523
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # test find in empty list
    assert ImmutableList.empty().find(lambda x: x > 5) is None
    # test find in empty list
    assert ImmutableList.empty().find(lambda x: x > 5) == ImmutableList.empty()
    # test find in one element list
    assert ImmutableList(10).find(lambda x: x == 10) == 10
    # test find in one element list
    assert ImmutableList(10).find(lambda x: x == 10) == ImmutableList(10)
    # test find in list
    assert ImmutableList(10, ImmutableList(20)).find(lambda x: x == 10) == 10
    # test find in list
    assert ImmutableList(10, ImmutableList(20)).find(lambda x: x == 10) == ImmutableList(10)
    # test find

# Generated at 2022-06-24 00:16:26.458348
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # given
    init_list = ImmutableList.of(1, 2, 3)

    # when
    new_list = init_list.append(4)

    # then
    assert new_list == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:16:32.614024
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first = ImmutableList.of(34, 23, 1)
    second = ImmutableList.of(13, 0)
    assert first + second == ImmutableList.of(34, 23, 1, 13, 0)
    assert second + first == ImmutableList.of(13, 0, 34, 23, 1)


# Generated at 2022-06-24 00:16:34.885511
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList()) == 0


# Generated at 2022-06-24 00:16:42.601696
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    a = ImmutableList.of(1, 2, 3)
    assert len(a) == 3

    b = ImmutableList.of(1)
    assert len(b) == 1

    c = ImmutableList.of(1, ImmutableList.of(2, ImmutableList.of(3)))
    assert len(c) == 3

    d = ImmutableList.of()
    assert len(d) == 0



# Generated at 2022-06-24 00:16:46.433233
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-24 00:16:55.061856
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(3,4,5).find(lambda x : x >= 3) == 3

    assert ImmutableList.of(1,2,3,4,5,6).find(lambda x: x > 4) == 5

    assert ImmutableList.of(1,2,3,4,5,6).find(lambda x: x > 6) is None

    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x > 'd') is None
