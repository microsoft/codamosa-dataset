

# Generated at 2022-06-24 00:06:54.360371
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # check for empty ImmutableList
    assert ImmutableList.empty() == ImmutableList.empty()

    # check for one element ImmutableList
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)

    # check for two elements ImmutableList
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(2, 1) != ImmutableList.of(1, 2)

    # check for three elements ImmutableList
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 1, 3)



# Generated at 2022-06-24 00:06:58.352982
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:07:01.361542
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:07:05.318871
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    result = ImmutableList.of(10, 20, 30).reduce(lambda acc, x: acc + x, 0)
    assert result == 60, 'should accumulate sum of all elements'

# Generated at 2022-06-24 00:07:12.644818
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4).unshift(0) == ImmutableList.of(0, 1, 2, 3, 4)



# Generated at 2022-06-24 00:07:18.444533
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Test on empty ImmutableList
    assert ImmutableList.empty().__len__() == 0
    
    # Test on ImmutableList with head element only
    assert ImmutableList.of(1).__len__() == 1
    
    # Test on ImmutableList with elements other then head
    assert ImmutableList.of(1, 2, 3).__len__() == 3



# Generated at 2022-06-24 00:07:24.070100
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():

    def inner_test(x):
        y = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
        z = ImmutableList(4, ImmutableList(5, ImmutableList(6)))
        assert x == y + z

    inner_test(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6)))))))


# Generated at 2022-06-24 00:07:36.788750
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList() != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(1))
    assert Imm

# Generated at 2022-06-24 00:07:41.507571
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    m1 = ImmutableList.of(1)
    m2 = ImmutableList.of(2)
    result = m1 + m2
    assert isinstance(result, ImmutableList)
    assert result == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-24 00:07:45.413568
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():  # pragma: no cover
    res = (
        ImmutableList(1) == ImmutableList(1)
    )

    expec = True
    
    assert res == expec



# Generated at 2022-06-24 00:07:49.231062
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__(): # pragma: no cover
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))


# Generated at 2022-06-24 00:07:51.616651
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == "ImmutableList[1, 2, 3]"


# Generated at 2022-06-24 00:07:58.605843
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList()
    assert (l.reduce(lambda x, y: x + y, 0) == 0)

    l = ImmutableList.of(1)
    assert (l.reduce(lambda x, y: x + y, 0) == 1)

    l = ImmutableList.of(1, 2, 3, 4)
    assert (l.reduce(lambda x, y: x + y, 0) == 10)

    l = ImmutableList.of(2, 3, 4)
    assert (l.reduce(lambda x, y: x * y, 1) == 24)



# Generated at 2022-06-24 00:08:03.803066
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).to_list() == [1, 2, 3, 4, 5, 6]
    assert ImmutableList.of(1).to_list() == [1]

# Generated at 2022-06-24 00:08:13.009219
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList()
    assert ImmutableList(is_empty=True).filter(lambda x: True) == ImmutableList(is_empty=True)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1).filter(lambda x: x < 3) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 0) == ImmutableList(is_empty=True)
    assert ImmutableList.of(1, 2, 3).filter

# Generated at 2022-06-24 00:08:16.157916
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(3)) == 1
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3



# Generated at 2022-06-24 00:08:18.204182
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3


# Generated at 2022-06-24 00:08:21.590484
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-24 00:08:25.742663
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

# Generated at 2022-06-24 00:08:28.341112
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    result = ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list()
    assert result == [1, 2, 3]

# Generated at 2022-06-24 00:08:31.757852
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    empty = ImmutableList()
    assert len(empty) == 0

    one = ImmutableList(1)
    assert len(one) == 1

    two = ImmutableList(1, empty)
    assert len(two) == 2


# Unit tests for method append of class ImmutableList

# Generated at 2022-06-24 00:08:34.536039
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    ls = ImmutableList.of(1)
    ls = ls.append(2)

    assert ls == ImmutableList.of(1, 2)


# Generated at 2022-06-24 00:08:37.699087
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    a = ImmutableList(1)
    b = ImmutableList(1)
    c = ImmutableList(2)
    d = ImmutableList(3, a)
    e = ImmutableList(3, b)
    f = ImmutableList(2, a)

    assert a == b
    assert a != c
    assert d == e
    assert d != f


# Tests for method ImmutableList.of

# Generated at 2022-06-24 00:08:47.875261
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Constructor without arguments
    assert ImmutableList(is_empty=True) == ImmutableList()
    # Constructor with one argument
    assert ImmutableList(head=1, is_empty=False) == ImmutableList(1)
    # Constructor with two arguments
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, 2)
    # Constructor with many arguments
    assert ImmutableList(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList("a", "b", "c") == ImmutableList("a", ImmutableList("b", ImmutableList("c")))


# Generated at 2022-06-24 00:08:59.272622
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty()

    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x * 2) \
        == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(None).map(lambda x: x) \
        == ImmutableList(None)
    assert ImmutableList('test').map(lambda x: x.upper()) \
        == ImmutableList('TEST')

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x * 2) \
        == ImmutableList(2, ImmutableList(4, ImmutableList(6)))

# Generated at 2022-06-24 00:09:04.136615
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    filtered = list_.filter(lambda x: x > 3)
    expected = ImmutableList.of(4, 5)

    assert filtered == expected

# Generated at 2022-06-24 00:09:07.664397
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_list.reduce(lambda acc, x: acc + x, 0) == 15
    assert test_list.reduce(lambda acc, x: acc * x, 1) == 120



# Generated at 2022-06-24 00:09:17.667992
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    from uuid import uuid4

    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    filtered = list_.filter(lambda x: x % 2 == 0)

    for x in [2, 4]:
        assert x in filtered.to_list()
    for x in [1, 3, 5]:
        assert x not in filtered.to_list()

    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    filtered = list_.filter(lambda x: x > 5)

    assert len(filtered) == 0

    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    filtered = list_.filter(lambda x: x <= 5 and x > 4)

    assert len(filtered) == 1
    assert filtered.to_list()[0]

# Generated at 2022-06-24 00:09:23.260301
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list1 = ImmutableList.empty()
    list2 = list1.append(1)
    list3 = list2.append(2)
    list4 = list3.append(3)
    assert list4 != list3
    assert list3 != list2
    assert list2 != list1
    assert list4 == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:09:28.669235
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # test with empty list
    list1 = ImmutableList.empty()
    list2 = ImmutableList.of(1)
    list3 = ImmutableList.of(2)

    result = list1 + list2 + list3

    assert len(result) == 2
    assert result == ImmutableList.of(1, 2)
    assert result.head == 1
    assert result.tail == ImmutableList.of(2)


# Generated at 2022-06-24 00:09:37.950346
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Scenario 1: Empty list
    # Given
    empty_list = ImmutableList.empty()
    fn = lambda acc, value: acc + value
    acc = 5

    # When
    res = empty_list.reduce(fn, acc)

    # Then
    assert res == acc
    
    # Scenario 2: List with one element
    # Given
    list_ = ImmutableList.of(2)
    fn = lambda acc, value: acc * value
    acc = 5

    # When
    res = list_.reduce(fn, acc)

    # Then
    assert res == acc * 2
    
    # Scenario 3: List with multiple elements
    # Given
    list_ = ImmutableList.of(1, 2, 3, 4)
    fn = lambda acc, value: acc * value
    acc = 2

# Generated at 2022-06-24 00:09:42.785113
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l0 = ImmutableList.of(1, 2, 3, 4, 5)
    r0 = l0.reduce(lambda acc, x: acc + x, 0)
    assert r0 == 15
    l1 = ImmutableList.of("test", "test_two")
    r1 = l1.reduce(lambda acc, x: acc + x, "")
    assert r1 == "testtest_two"

# Generated at 2022-06-24 00:09:51.464240
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():

    list = ImmutableList(1)
    list2 = ImmutableList(2)

    expected_result = ImmutableList(1, ImmutableList(2))
    result = list.__add__(list2)

    assert result == expected_result
    assert result is not list
    assert result is not list2
    assert result != list
    assert result != list2
    assert isinstance(result, ImmutableList)
    assert isinstance(result, list.__class__)
    assert result.head == 1
    assert result.tail == ImmutableList(2)
    assert result.tail.head == 2
    assert result.tail.is_empty is False
    assert result.tail.tail is None
    assert result.is_empty is False
    assert result.to_list() == [1, 2]



# Generated at 2022-06-24 00:09:57.721733
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Arrange
    def fn(a, b):
        return a + b
    ilist = ImmutableList.of(1, 2, 3, 4)
    acc = 0

    # Act
    result = ilist.reduce(fn, acc)

    # Assert
    assert result == 10


test_ImmutableList_reduce()



# Generated at 2022-06-24 00:10:01.099837
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList.of(1, 2, 3)

    def f(acc, x):
        return acc + x

    assert l.reduce(f, 0) == 6

    assert l.reduce(f, 1) == 7



# Generated at 2022-06-24 00:10:04.228492
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.empty() + ImmutableList.of(1) == ImmutableList(1)


# Generated at 2022-06-24 00:10:05.700960
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:10:08.578132
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(2, 3, 4).map(lambda x: x + 1) == ImmutableList(3, 4, 5)


# Generated at 2022-06-24 00:10:18.787127
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1,2,3,4,5)
    assert test_list == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    filtered = test_list.filter(lambda x: x == 3)
    assert filtered == ImmutableList(3)
    filtered = test_list.filter(lambda x: x < 3)
    assert filtered == ImmutableList(1, ImmutableList(2))
    filtered = test_list.filter(lambda x: x > 3)
    assert filtered == ImmutableList(4, ImmutableList(5))
    filtered = test_list.filter(lambda x: x > 5)
    assert filtered == ImmutableList(is_empty=True)



# Generated at 2022-06-24 00:10:28.228329
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList().map(lambda x: x) == ImmutableList.empty()
    assert ImmutableList(3).map(lambda x: x) == ImmutableList(3)
    assert ImmutableList(3, ImmutableList(4)).map(lambda x: x) == ImmutableList(3, ImmutableList(4))
    assert ImmutableList(3, ImmutableList(4, ImmutableList(5))).map(lambda x: x) == ImmutableList(3, ImmutableList(4, ImmutableList(5)))
    assert ImmutableList(3, ImmutableList(4, ImmutableList(5))).map(lambda x: x * 2) == ImmutableList(6, ImmutableList(8, ImmutableList(10)))
    assert ImmutableList(3, ImmutableList(4, ImmutableList(5))).map

# Generated at 2022-06-24 00:10:38.808238
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList()))).filter(lambda x: x % 2 == 0).to_list() == [2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList()))).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList().filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)
    assert ImmutableList(2).filter(lambda x: x % 2 == 0) == ImmutableList(2)


# Generated at 2022-06-24 00:10:42.263101
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
  a = ImmutableList.of(1, 2, 3)
  b = ImmutableList.of(1, 2, 3)
  c = ImmutableList.of(1, 2, 4)

  assert a == b
  assert not a == c

# Generated at 2022-06-24 00:10:49.717352
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1, None) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, None)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, None))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList().to_list() == []
    assert ImmutableList(is_empty=True).to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
   

# Generated at 2022-06-24 00:10:58.202907
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x is not None) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.empty().find(lambda x: x is not None) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None


# Pytest for method reduce of class ImmutableList

# Generated at 2022-06-24 00:11:07.262712
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Test for positive integers
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, x: acc+x, 0) == 15
    # Test for negative integers
    assert ImmutableList.of(-1, -2, -3, -4, -5).reduce(lambda acc, x: acc+x, 0) == -15
    # Test for positive real numbers
    assert ImmutableList.of(1.0, 2.0, 3.0, 4.0, 5.0).reduce(lambda acc, x: acc+x, 0) == 15.0
    # Test for negative real numbers

# Generated at 2022-06-24 00:11:17.468020
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():  # pragma: no cover
    assert ImmutableList.empty().find(lambda x: False) is None
    assert ImmutableList.empty().find(lambda x: True) is None

    assert ImmutableList.of(1).find(lambda x: x == 2) is None
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1

    assert ImmutableList.of(1, 2).find(lambda x: x == 2) is 2
    assert ImmutableList.of(1, 2).find(lambda x: x == 1) is 1
    assert ImmutableList.of(1, 2).find(lambda x: x == 3) is None



# Generated at 2022-06-24 00:11:22.909357
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(None, None)) == 'ImmutableList[None]'
    assert str(ImmutableList(1, None)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'

# Generated at 2022-06-24 00:11:26.207616
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(5)) == 'ImmutableList[5]'
    assert str(ImmutableList(5, ImmutableList(6, ImmutableList(7)), True)) == 'ImmutableList[5, 6, 7]'


# Generated at 2022-06-24 00:11:29.300952
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).unshift(1) == ImmutableList.of(1, 1)



# Generated at 2022-06-24 00:11:35.013243
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list1 = ImmutableList(1)
    
    assert len(list1) == 1
    
    list2 = ImmutableList.of(1, 2)
    
    assert len(list2) == 2
    
    list3 = ImmutableList.of(1, 2, 3, 4)
    
    assert len(list3) == 4

# Generated at 2022-06-24 00:11:46.263413
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList.empty(), "empty ImmutableList should be equal to empty ImmutableList"
    assert ImmutableList() == ImmutableList(), "empty ImmutableList should be equal to empty ImmutableList"
    assert ImmutableList().head is None, "head of empty ImmutableList should be None"
    assert ImmutableList().tail is None, "tail of empty ImmutableList should be None"
    assert ImmutableList(1) == ImmutableList(1), "ImmutableList with one element should be equal to ImmutableList with same element"
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3))), "ImmutableList with three elements should be equal to ImmutableList with same elements"

# Generated at 2022-06-24 00:11:52.557539
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x ** 2).to_list() == [1, 4, 9, 16]
    assert ImmutableList.empty().to_list() == []

# Generated at 2022-06-24 00:11:56.888369
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3
    assert len(ImmutableList()) == 0

    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3



# Generated at 2022-06-24 00:12:01.363325
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList()
    assert a.reduce(lambda x, y: x + y, 0) == 0

    b = ImmutableList(1)
    assert b.reduce(lambda x, y: x + y, 0) == 1

    c = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert c.reduce(lambda x, y: x + y, 0) == 6

# Generated at 2022-06-24 00:12:05.835823
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of().unshift(1).to_list() == [1]
    assert ImmutableList.of(2).unshift(1).to_list() == [1, 2]
    assert ImmutableList.of(2, 3, 4, 5).unshift(1).to_list() == [1, 2, 3, 4, 5]



# Generated at 2022-06-24 00:12:13.805527
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    value = ImmutableList.of(1)
    value2 = ImmutableList.of(2, 3, 4)

    try:
        value + 1
    except ValueError as e:
        assert e.args[0] == 'ImmutableList: you can not add any other instace than ImmutableList'
    else:
        assert False

    assert value + value2 == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:12:16.189930
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1)\
        .map(lambda x: x + 10)\
        .reduce(lambda acc, x: acc + x, 0) == 11

# Generated at 2022-06-24 00:12:17.757467
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3)
    assert [1, 2, 3] == list_.to_list()


# Generated at 2022-06-24 00:12:21.199505
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:12:26.254721
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(1, 2, 3, 4)
    assert 4 == list2.reduce(lambda a, b: a + b, 0)
    assert 1 == list1.reduce(lambda a, b: a + b, 0)
    assert 0 == ImmutableList.empty().reduce(lambda a, b: a + b, 0)


# Generated at 2022-06-24 00:12:31.829267
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:12:37.168283
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 0) == 0
    assert ImmutableList.of(3).reduce(lambda x, y: x + y, 0) == 3
    assert ImmutableList.of(0, 1, 2).reduce(lambda x, y: x + y, 0) == 3
    assert ImmutableList.of(0, 1, 2).reduce(lambda x, y: x + y, 1) == 4


# Generated at 2022-06-24 00:12:39.977884
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_filter = ImmutableList.of(1, 2, 3, 4, 5, 6)
    new_list = list_filter.filter(lambda x: x % 2 != 0)
    assert new_list == ImmutableList.of(1, 3, 5)



# Generated at 2022-06-24 00:12:42.874104
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    m1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    m2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert m1 == m2
    


# Generated at 2022-06-24 00:12:47.068943
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:12:54.269958
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert not ImmutableList(1, ImmutableList(3)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-24 00:12:59.813095
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_to_map = ImmutableList.of(1, 2, 3)
    mapped_list = list_to_map.map(lambda x: x + 1)

    assert mapped_list.head == 2
    assert mapped_list.tail.head == 3
    assert mapped_list.tail.tail.head == 4

# Generated at 2022-06-24 00:13:00.750030
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(4).append(100) == ImmutableList.of(4, 100)


# Generated at 2022-06-24 00:13:05.124859
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda v: v * 2) == ImmutableList.of(2, 4, 6, 8)
    assert ImmutableList.empty().map(lambda v: v * 2) == ImmutableList.empty()


# Generated at 2022-06-24 00:13:16.583627
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    
    # test different cases with different types of data and different cases of 
    #  empty and nonempty lists

    res = ImmutableList.of(1,2,3).reduce(lambda a, b: a + b, 5)
    assert res == 11

    res = ImmutableList.of(1,2,3).reduce(lambda a, b: a - b, 5)
    assert res == -5

    res = ImmutableList.of(1,2,3).reduce(lambda a, b: a * b, 5)
    assert res == 30

    res = ImmutableList.empty().reduce(lambda a, b: a - b, 5)
    assert res == 5

    res = ImmutableList.empty().reduce(lambda a, b: a * b, 5)
    assert res == 5


# Generated at 2022-06-24 00:13:20.424304
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ilist = ImmutableList.of(1, 2, 3, 4, 5)
    rlist = ilist.filter(lambda x: x > 2)

    assert(rlist == ImmutableList.of(3, 4, 5))


# Generated at 2022-06-24 00:13:26.692984
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l1 = ImmutableList()
    l1 = l1.append('0')
    l1 = l1.append('1')
    l1 = l1.append('2')
    l2 = ImmutableList()
    l2 = l2.unshift('2')
    l2 = l2.unshift('1')
    l2 = l2.unshift('0')
    assert l1 == l2


# Generated at 2022-06-24 00:13:33.257389
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # empty list case
    assert ImmutableList.empty().to_list() == []

    # list with one element case
    assert ImmutableList.of(1).to_list() == [1]

    # list with more than one element case
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:13:41.250414
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList().__eq__(None) == False

# Generated at 2022-06-24 00:13:45.232655
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Arrange
    immutable_list = ImmutableList.of(1, 2, 3)

    # Act
    actual = immutable_list.to_list()
    expected = [1, 2, 3]

    # Assert
    assert expected == actual


# Generated at 2022-06-24 00:13:49.098333
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert test_list.append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-24 00:13:50.445825
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_ = ImmutableList.of(1, 2, 3)
    assert str(list_) == "ImmutableList[1, 2, 3]"


# Generated at 2022-06-24 00:13:53.480188
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    some_list = ImmutableList.of(6, 2, 3, 4, 5)
    assert len(some_list) == 5
    assert some_list.to_list() == [6, 2, 3, 4, 5]


# Generated at 2022-06-24 00:13:59.357240
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).to_list() == [1, 2, 3, 4]




# Generated at 2022-06-24 00:14:02.025435
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.of(1, 2, 3, 4).__str__() == 'ImmutableList[1, 2, 3, 4]'



# Generated at 2022-06-24 00:14:07.888310
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # create immutable list by of method
    list = ImmutableList.of(1, 1, 2, 3)
    # unshift new elements to immutable list
    new_list = list.unshift(3)
    new_list = new_list.unshift(2)
    new_list = new_list.unshift(1)
    assert new_list.to_list() == [1, 2, 3, 1, 1, 2, 3]

# Generated at 2022-06-24 00:14:19.769954
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert(ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2)))
    assert(ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2, ImmutableList.empty())))
    assert(ImmutableList.of(1, 2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    assert(ImmutableList.of(1, 2).unshift(3) == ImmutableList(3, ImmutableList(1, ImmutableList(2))))
    assert(ImmutableList.of(1, 2).map(lambda x: x * 2) == ImmutableList(2, ImmutableList(4)))

# Generated at 2022-06-24 00:14:26.374502
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create some test data
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]

    # Create empty list
    list = ImmutableList.empty()

    # Filter only odd numbers
    for i in data:
        list = list.append(i)
        
    # Filter only odd numbers
    list = list.filter(lambda x: x % 2 == 1)
    
    # Check-out if list is correct
    assert list.to_list() == [1, 3, 5, 7, 9, 11, 13]

    # Filter only even numbers
    list = list.filter(lambda x: x % 2 == 0)

    # Check-out if list is empty
    assert len(list) == 0


# Generated at 2022-06-24 00:14:30.377467
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l1 = ImmutableList.of('a', 'b', 'c')
    l2 = ImmutableList.of('d', 'e', 'f')
    assert l1 + l2 == ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f')



# Generated at 2022-06-24 00:14:36.711203
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # assert(ImmutableList.empty().find(lambda x: True) == None)
    assert(ImmutableList(1).find(lambda x: x == 1) == 1)
    assert(ImmutableList(1, ImmutableList(2)).find(lambda x: x == 1) == 1)
    assert(ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2)
    assert(ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) == None)

    print("test_ImmutableList_find finished.")



# Generated at 2022-06-24 00:14:41.595825
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2).to_list() == [2, 1]
    assert ImmutableList.of(1, 2, 3).unshift(4).to_list() == [4, 1, 2, 3]


# Generated at 2022-06-24 00:14:44.444901
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    instance = ImmutableList(1, ImmutableList(2), False)
    result = instance.__len__()
    assert result == 2


# Generated at 2022-06-24 00:14:50.733329
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # given
    xs = ImmutableList.of(1, 2, 3)
    ys = ImmutableList.of(1, 2, 3)
    zs = ImmutableList.of(1, 2, 4)

    # when
    result_of_comparing_xs_and_ys = (xs == ys)
    result_of_comparing_xs_and_zs = (xs == zs)

    # then
    assert result_of_comparing_xs_and_ys
    assert not result_of_comparing_xs_and_zs



# Generated at 2022-06-24 00:14:53.259771
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-24 00:14:56.444125
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(4)) == 1
    assert len(ImmutableList.of(4, 1, 2, 3, 5, 6)) == 6
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:15:00.554520
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    test_List1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    test_List2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert test_List1 == test_List2


# Generated at 2022-06-24 00:15:07.484117
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    empty1 = ImmutableList.empty()
    empty2 = ImmutableList.empty()
    assert empty1 == empty2
    assert empty1 == ImmutableList()

    list1 = ImmutableList(2, ImmutableList(3))
    list2 = ImmutableList(2, ImmutableList(3))
    assert list1 == list2
    assert list1 == ImmutableList(2, ImmutableList(3))

    list3 = ImmutableList(2, ImmutableList(3, ImmutableList(4)))
    assert list3 != list2



# Generated at 2022-06-24 00:15:10.973413
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2

# Generated at 2022-06-24 00:15:18.836626
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(5)) == 'ImmutableList[5]'
    assert str(ImmutableList(5, ImmutableList(6))) == 'ImmutableList[5, 6]'
    assert str(ImmutableList(5, ImmutableList(6, ImmutableList(7)))) == 'ImmutableList[5, 6, 7]'
    assert str(ImmutableList(is_empty=True)) == 'ImmutableList[]'
    assert str(ImmutableList(5, imm_list)) == 'ImmutableList[5, 6, 7]'

# Generated at 2022-06-24 00:15:21.064881
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert [1, 2, 3] == ImmutableList(1, ImmutableList(2)).append(3).to_list()


# Generated at 2022-06-24 00:15:29.749467
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).to_list() == [1, 2, 3]
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3, ImmutableList(4, ImmutableList(5)))).to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-24 00:15:32.770118
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # assert ImmutableList.empty().unshift(12) != ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).unshift(5) == ImmutableList.of(5, 1, 2, 3)

# Generated at 2022-06-24 00:15:37.811485
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # arrange
    list_a = ImmutableList.of(1, 2, 3)
    list_b = ImmutableList.of(4, 5, 6)

    # act
    list_c = list_a + list_b

    # assert
    assert isinstance(list_c, ImmutableList)
    assert list_c.to_list() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-24 00:15:46.943066
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l1 = ImmutableList.of(1, 2, 3)
    l2 = ImmutableList.of(4, 5, 6)
    l3 = l1 + l2

    assert(l3.head == 1)
    assert(l3.tail.head == 2)
    assert(l3.tail.tail.head == 3)
    assert(l3.tail.tail.tail.head == 4)
    assert(l3.tail.tail.tail.tail.head == 5)
    assert(l3.tail.tail.tail.tail.tail.head == 6)
    assert(l3.tail.tail.tail.tail.tail.tail is None)



# Generated at 2022-06-24 00:15:52.797213
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:15:57.172303
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    @dataclass
    class Person:
        name: str
        age: int
    jim = Person('Jim', 37)
    jeff = Person('Jeff', 43)
    jake = Person('Jake', 15)

    l = ImmutableList.of(jim, jeff, jake)

    # when
    result = l.find(lambda p: p.name == 'Jeff')

    # then
    assert result == jeff

# Generated at 2022-06-24 00:15:59.436463
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(0, 1, 2, 3, 4).filter(lambda x: x % 2) == ImmutableList(1, 3)


# Generated at 2022-06-24 00:16:04.361594
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    fn = lambda x: x * x

    # Act
    result = test_list.map(fn)
    
    # Assert
    assert(result == ImmutableList.of(1, 4, 9, 16, 25))

# Generated at 2022-06-24 00:16:07.829263
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    input_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert input_list.unshift(0).to_list() == [0, 1, 2, 3, 4, 5]


# Generated at 2022-06-24 00:16:11.149283
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3


# Generated at 2022-06-24 00:16:17.821468
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.of(1,2,3).unshift(0) == ImmutableList(0, 1, 2, 3)
    assert ImmutableList.of(1,2,3).append(4) == ImmutableList(1, 2, 3, 4)
    assert ImmutableList.of(1,2,3).append(4).append(5) == ImmutableList(1, 2, 3, 4, 5)


# Generated at 2022-06-24 00:16:28.125845
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    empty_list = ImmutableList.empty()
    one_el = ImmutableList(1)
    two_el = ImmutableList(1, ImmutableList(2))

    assert empty_list.append(1) == one_el
    assert empty_list.append(2) == ImmutableList(2)
    assert one_el.append(1) == ImmutableList(1, ImmutableList(1))
    assert one_el.append(2) == ImmutableList(1, ImmutableList(2))
    assert two_el.append(1) == ImmutableList(1, ImmutableList(2, ImmutableList(1)))
    assert two_el.append(2) == ImmutableList(1, ImmutableList(2, ImmutableList(2)))



# Generated at 2022-06-24 00:16:31.871137
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    print('testing ImmutableList.unshift()...', end='')
    lst = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert lst.unshift(4) == ImmutableList(4, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    assert lst.unshift(5).unshift(6) == ImmutableList(6, ImmutableList(5, ImmutableList(1, ImmutableList(2, ImmutableList(3)))))
    print('done')


# Generated at 2022-06-24 00:16:34.546425
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3)

    assert list_.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:16:40.782664
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert not ImmutableList(
        1,
        ImmutableList(2)
    ) == ImmutableList(
        1,
        ImmutableList(3)
    )
    assert not ImmutableList(
        1,
        ImmutableList(2)
    ) == ImmutableList(
        2,
        ImmutableList(3)
    )
    assert not ImmutableList(
        1,
        ImmutableList(2)
    ) == ImmutableList(
        1,
        ImmutableList(3, ImmutableList(4))
    )

# Generated at 2022-06-24 00:16:49.259802
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # method should return: 5
    print(ImmutableList.of(1,2,2,2).reduce(lambda acc, val: acc + val, 0))
    # method should return: 5
    print(ImmutableList.of(1,2,2,2).reduce(lambda acc, val: acc * val, 1))
    # method should return: 10
    print(ImmutableList.of(1,2,2,2).reduce(lambda acc, val: acc + val, 2))
test_ImmutableList_reduce()

