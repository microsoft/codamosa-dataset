

# Generated at 2022-06-24 00:07:04.041443
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    from copy import copy
    l1 = ImmutableList.empty()
    l2 = l1.append(2)
    l3 = l2.append(3)
    l4 = l3.append(5)

    assert l1 != l2
    assert l2 != l3
    assert l3 != l4

    assert l1.to_list() == []
    assert l2.to_list() == [2]
    assert l3.to_list() == [2, 3]
    assert l4.to_list() == [2, 3, 5]

    l2 = ImmutableList.of(1)
    l3 = l2.append(3)

    assert l2 != l3
    assert l3.to_list() == [1, 3]
    assert l2.to_list() == [1]

# Generated at 2022-06-24 00:07:07.810418
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    string = 'ImmutableList{}'

    assert string.format([]) == str(ImmutableList.empty())
    assert string.format([1]) == str(ImmutableList.of(1))
    assert string.format([1, 2, 3]) == str(ImmutableList.of(1, 2, 3))



# Generated at 2022-06-24 00:07:14.420665
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x < 100) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 100) is None


# Generated at 2022-06-24 00:07:19.421876
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2)).find(lambda e: e == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda e: e == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda e: e == 3) == None

# Generated at 2022-06-24 00:07:21.668565
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    l = ImmutableList.of(1, 2, 3, 4)
    assert l.to_list() == [1, 2, 3, 4]



# Generated at 2022-06-24 00:07:25.847426
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    test_input = ImmutableList.of(1, 2, 3, 4)
    expected = ImmutableList.of(2, 4)

    # Act
    actual = test_input.filter(lambda x: x % 2 == 0)

    # Assert
    assert actual == expected


# Generated at 2022-06-24 00:07:29.636971
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of(1, 2, 3)
    l1 = ImmutableList.empty()

    assert l.unshift(0) == [0, 1, 2, 3]
    assert l.unshift(4) == [4, 1, 2, 3]
    assert l1.unshift(0) == [0]


# Generated at 2022-06-24 00:07:35.483874
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of("some-value")) == 1
    assert len(ImmutableList.of("some-value").to_list()) == 1
    assert len(ImmutableList.of("some-value", "another-one").to_list()) == 2
    assert len(ImmutableList.of("some-value", "another-one").append("third-value").to_list()) == 3
    assert len(ImmutableList.of("some-value").unshift("another-one").to_list()) == 2
    assert len(ImmutableList.of("some-value", "some-value").to_list()) == 2
    assert len(ImmutableList.of("some-value", "some-value").map(lambda value: value).to_list()) == 2
    assert len

# Generated at 2022-06-24 00:07:41.123340
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list1 = ImmutableList.empty().append(10)
    list2 = ImmutableList.of(10, 20)
    list3 = ImmutableList.of(10, 20, 30)

    assert list1.to_list() == [10]
    assert list2.to_list() == [10, 20]
    assert list3.to_list() == [10, 20, 30]


# Generated at 2022-06-24 00:07:49.285300
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    first = ImmutableList(1)
    second = ImmutableList(2)
    third = ImmutableList(3)
    fourth = ImmutableList(4)
    fifth = ImmutableList(5)
    empty_list = ImmutableList(is_empty=True)

    assert first.__str__() == '[1]'
    assert second.__str__() == '[2]'
    assert third.__str__() == '[3]'
    assert fourth.__str__() == '[4]'
    assert fifth.__str__() == '[5]'

    assert empty_list.__str__() == '[]'

    assert ImmutableList.of(1).__str__() == '[1]'
    assert ImmutableList.of(1, 2).__str__() == '[1, 2]'

# Generated at 2022-06-24 00:07:52.011781
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 9, 4, 1).filter(lambda x: x > 1) == ImmutableList(2, 3, 9, 4)

# Generated at 2022-06-24 00:07:53.701595
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)

# Generated at 2022-06-24 00:07:56.941092
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    actual = ImmutableList.of(1, 2, 3, 4, 5)\
        .map(lambda x: x + 1)

    expected = ImmutableList.of(2, 3, 4, 5, 6)

    assert actual == expected



# Generated at 2022-06-24 00:08:02.225293
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    numbers = ImmutableList.of(1, 2, 3)
    assert numbers.reduce(lambda acc, x: acc + x, 0) == 6
    assert numbers.reduce(lambda acc, x: acc + x, 1) == 7

# Generated at 2022-06-24 00:08:06.079607
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == "ImmutableList[]"
    assert str(ImmutableList(1)) == "ImmutableList[1]"
    assert str(ImmutableList(1, ImmutableList(2))) == "ImmutableList[1, 2]"


# Generated at 2022-06-24 00:08:08.863383
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)



# Generated at 2022-06-24 00:08:15.787393
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * x) == ImmutableList.of(1, 4, 9)
    assert ImmutableList.of(1, 2).map(lambda x: x * x) == ImmutableList.of(1, 4)
    assert ImmutableList.of(1, 2).map(lambda x: x * x).map(lambda x: x * x) == ImmutableList.of(1, 16)
    assert ImmutableList.of(1, 2).map(lambda x: x + 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of("a", "b").map(lambda x: x + "b") == ImmutableList.of("ab", "bb")

# Generated at 2022-06-24 00:08:20.434294
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    x = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    y = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))))
    assert x.unshift(0) == y
test_ImmutableList_unshift()

# Generated at 2022-06-24 00:08:23.016593
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)

# Generated at 2022-06-24 00:08:30.170152
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    tests = {
        "empty": {
            "function": lambda: ImmutableList.empty(),
            "length": 0
        },
        "single": {
            "function": lambda: ImmutableList.of(1),
            "length": 1
        },
        "multiple": {
            "function": lambda: ImmutableList.of(1, 2, 3, 4),
            "length": 4
        }
    }

    for test_name, test in tests.items():
        list_instance = test["function"]()
        length = test["length"]
        assert length == len(list_instance), "In test: {} expected {} but got {}".format(test_name, length, len(list_instance))


# Generated at 2022-06-24 00:08:33.773400
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 1).to_list() == [2]
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1).to_list() == [2, 3, 4]
    assert ImmutableList.empty().map(lambda x: x + 1).to_list() == []


# Generated at 2022-06-24 00:08:36.607182
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(2, ImmutableList(1), True)) == 'ImmutableList[2, 1]'


# Generated at 2022-06-24 00:08:46.168290
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4) \
        .filter(lambda x: x % 2) \
        .to_list() == [1, 3]

    assert ImmutableList.of(1, 2, 3, 4) \
        .filter(lambda x: True) \
        .to_list() == [1, 2, 3, 4]

    assert ImmutableList.of(1, 2, 3, 4) \
        .filter(lambda x: False).to_list() == []

    assert ImmutableList() \
        .filter(lambda x: x % 2) \
        .to_list() == []



# Generated at 2022-06-24 00:08:52.382508
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def is_even(x): return x % 2 == 0

    assert ImmutableList(1).filter(is_even).is_empty == True
    assert ImmutableList(2).filter(is_even).to_list() == [2]
    assert ImmutableList(1, 2).filter(is_even).to_list() == [2]
    assert ImmutableList(2, 1).filter(is_even).to_list() == [2]
    assert ImmutableList(1, 2, 3).filter(is_even).to_list() == [2]
    assert ImmutableList(1, 3, 2).filter(is_even).to_list() == [2]
    assert ImmutableList(2, 3, 1).filter(is_even).to_list() == [2]

# Generated at 2022-06-24 00:08:56.521211
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list = ImmutableList.of(1, 2, 3).unshift(10)
    assert immutable_list == ImmutableList.of(10, 1, 2, 3)


# Generated at 2022-06-24 00:08:58.913379
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():  # pragma: no cover
    from operator import add
    assert ImmutableList.of(1, 2, 3).reduce(add, 0) == 6



# Generated at 2022-06-24 00:09:02.651638
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1,2,3).to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:09:10.564308
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    The test checksthat method find returns expected
    result with given data.
    """

    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of().find(lambda x: True) == None
    assert ImmutableList.of(6).find(lambda x: x % 2 == 0) == 6
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None


# Generated at 2022-06-24 00:09:13.434217
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)

    assert list_.unshift(0) == ImmutableList.of(0, 1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:09:18.258053
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList(0, 1, 2, 3)



# Generated at 2022-06-24 00:09:21.289035
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert [1, 2] == ImmutableList.of(1, 2).to_list()
    assert [] == ImmutableList.of().to_list()


# Generated at 2022-06-24 00:09:27.576400
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test when both instances are empty
    assert ImmutableList().__eq__(ImmutableList()) == True

    # Test when first instance is empty and second is not
    assert ImmutableList().__eq__(ImmutableList(1)) == False

    # Test when first instance is not empty and second is empty
    assert ImmutableList(1).__eq__(ImmutableList()) == False

    # Test when both have same values
    assert ImmutableList(1).__eq__(ImmutableList(1)) == True

    # Test when have different values
    assert ImmutableList(1).__eq__(ImmutableList(2)) == False


# Generated at 2022-06-24 00:09:29.858245
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list = ImmutableList.of(1, 2, 3)
    assert list.__str__() == "ImmutableList[1, 2, 3]"


# Generated at 2022-06-24 00:09:38.769546
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    def __add__Impl(l: ImmutableList[int], add: ImmutableList[int]) -> ImmutableList[int]:
        return l.__add__(add)

    assert __add__Impl(
        ImmutableList(1), 
        ImmutableList(2)
    ) == ImmutableList(1, ImmutableList(2))

    assert __add__Impl(
        ImmutableList(1, ImmutableList(2)), 
        ImmutableList(3)
    ) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:09:43.010984
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    empty_list = ImmutableList.empty()
    unary_list = ImmutableList.of(1)
    triary_list = ImmutableList.of(1, 2, 3)
    assert len(empty_list) == 0
    assert len(unary_list) == 1
    assert len(triary_list) == 3


# Generated at 2022-06-24 00:09:47.734701
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)



# Generated at 2022-06-24 00:09:58.088185
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    
    # first test
    immutable_list_01 = ImmutableList(
        head=1,
        tail=ImmutableList(
            head=2,
            tail=ImmutableList(
                head=3,
                tail=None
            )
        )
    )
    
    immutable_list_02 = ImmutableList(
        head=1,
        tail=ImmutableList(
            head=2,
            tail=ImmutableList(
                head=3,
                tail=None
            )
        )
    )
    
    assert immutable_list_01 == immutable_list_02

    # second test

# Generated at 2022-06-24 00:10:06.191315
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # set up
    list1 = ImmutableList.of(2, 3, 4, 5)
    list2 = ImmutableList.of(5, 4, 3, 2)
    list3 = ImmutableList.empty()
    # act
    result11 = list1.map(lambda value: value)
    result12 = list1.map(lambda value: value * 2)
    result13 = list1.map(lambda value: value - 1)
    result21 = list2.map(lambda value: value)
    result22 = list2.map(lambda value: value * 2)
    result23 = list2.map(lambda value: value - 1)
    result31 = list3.map(lambda value: value)
    result32 = list3.map(lambda value: value * 2)

# Generated at 2022-06-24 00:10:12.694065
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x+1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x+1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1).map(lambda x: x**2) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x**2) == ImmutableList.of(1, 4, 9)

# Generated at 2022-06-24 00:10:15.423193
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.empty()
    l2 = ImmutableList.empty()

    assert l1 == l2
    assert not l1 != l2



# Generated at 2022-06-24 00:10:17.233797
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)



# Generated at 2022-06-24 00:10:25.470265
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of('a', 'b')) == 'ImmutableList[a, b]'
    assert str(ImmutableList.of('a', 'b', 'c')) == 'ImmutableList[a, b, c]'
    assert str(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 'ImmutableList[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]'



# Generated at 2022-06-24 00:10:30.975304
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Assert true
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)) == ImmutableList(1, ImmutableList(2), ImmutableList(3))

    # Assert false
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)) != ImmutableList(3, ImmutableList(2), ImmutableList(1))



# Generated at 2022-06-24 00:10:36.715794
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3, 4) + ImmutableList.of(5, 6, 7) == ImmutableList.of(1, 2, 3, 4, 5, 6, 7)


# Generated at 2022-06-24 00:10:40.554121
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    data = [
        [ImmutableList.of(1, 2, 3, 4, 5, 6), 6],
    ]

    for d in data:
        actual = len(d[0])
        expected = d[1]

        assert actual == expected



# Generated at 2022-06-24 00:10:47.216898
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Given
    a = ImmutableList.of(1, 2, 3, 4, 5, 6)
    # When
    res = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    # Then
    assert a == res, "Should be True"



# Generated at 2022-06-24 00:10:49.029373
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert [1, 2, 3] == immutable_list.to_list()


# Generated at 2022-06-24 00:10:54.051114
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    def add_five_func(val):
        return val + 5

    test_list = ImmutableList.of(1, 2, 3, 4)

    # Act
    test_list = test_list.map(add_five_func)

    # Assert
    assert test_list == ImmutableList.of(6, 7, 8, 9)


# Generated at 2022-06-24 00:10:59.889834
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 2) == ImmutableList.of(3, 4, 5)

# Generated at 2022-06-24 00:11:07.065035
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    Unit test for method __eq__ of class ImmutableList
    """

    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3), False), False) == ImmutableList(1, ImmutableList(2, ImmutableList(3), False), False)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3), False), False) == ImmutableList(1, ImmutableList(2, ImmutableList(3)), False)
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList.empty() == ImmutableList.empty().append(0)

# Generated at 2022-06-24 00:11:14.519044
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).to_list() == [1, 2, 3, 4]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList().to_list() == []

# Generated at 2022-06-24 00:11:20.521129
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3

# Generated at 2022-06-24 00:11:25.985231
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    assert ImmutableList().to_list() == []
    assert ImmutableList.empty().to_list() == []


# Generated at 2022-06-24 00:11:30.421650
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList()) == 'ImmutableList[]'

# Generated at 2022-06-24 00:11:36.092576
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x > 0) == 1
    assert ImmutableList.of(1).find(lambda x: x < 0) == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) == None

test_ImmutableList_find()

# Generated at 2022-06-24 00:11:40.728643
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    a = ImmutableList.of(1, 2, 3, 4)
    assert a.find(lambda x: x == 2) == 2
    assert a.find(lambda x: x == 5) is None



# Generated at 2022-06-24 00:11:45.170198
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList(1).__str__() == 'ImmutableList[1]'
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__str__() == 'ImmutableList[1, 2, 3]'
    assert ImmutableList().__str__() == 'ImmutableList[None]'



# Generated at 2022-06-24 00:11:49.987158
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    fmap = ImmutableList.of(1, 2, 3, 4, 5)

    assert fmap.find(lambda x: x == 1) == 1
    assert fmap.find(lambda x: x > 2) == 3
    assert fmap.find(lambda x: x == 20) == None

test_ImmutableList_find()

# Generated at 2022-06-24 00:11:53.362389
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList().unshift(3) == ImmutableList(3)
    assert ImmutableList(1).unshift(0) == ImmutableList(0, ImmutableList(1))


# Generated at 2022-06-24 00:12:00.038782
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_one = ImmutableList()
    list_two = ImmutableList.of(1)
    list_three = ImmutableList.of(1, 2, 3)
    list_four = ImmutableList.of(1, 2, 3, 4)

    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4).unshift(4) == ImmutableList.of(4, 1, 2, 3, 4)



# Generated at 2022-06-24 00:12:03.377500
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4, 5)) == 'ImmutableList'+str([1, 2, 3, 4, 5])
    assert str(ImmutableList()) == 'ImmutableList'+str([])


# Generated at 2022-06-24 00:12:07.390126
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Given
    fn = lambda x, y: x+y
    given_list = list(range(1, 11))
    expected_result = sum(given_list)

    # When
    result = ImmutableList.of(*given_list).reduce(fn, 0)

    # Then
    assert result == expected_result

# Generated at 2022-06-24 00:12:12.746867
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:12:17.670956
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift('1') == ImmutableList('1')
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:12:28.971809
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l_of_elements = ImmutableList.of(1, 2, 3)
    l_of_elements2 = ImmutableList.of(4, 5, 6)
    res = l_of_elements + l_of_elements2
    assert res.head == 1
    assert res.tail.head == 2
    assert res.tail.tail.head == 3
    assert res.tail.tail.tail.head == 4
    assert res.tail.tail.tail.tail.head == 5
    assert res.tail.tail.tail.tail.tail.head == 6
    assert res.tail.tail.tail.tail.tail.tail.head is None
    assert res.tail.tail.tail.tail.tail.tail.tail is None

# Generated at 2022-06-24 00:12:37.360982
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3).head == 1
    assert ImmutableList.of(1, 2, 3).tail == ImmutableList(2, ImmutableList(3))



# Generated at 2022-06-24 00:12:46.765065
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(0, ImmutableList(0)).filter(lambda e: e == 0).to_list() == [0, 0]
    assert ImmutableList(0, ImmutableList(1)).filter(lambda e: e == 0).to_list() == [0]
    assert ImmutableList(0, ImmutableList(1)).filter(lambda e: e == 1).to_list() == [1]
    assert ImmutableList(2, ImmutableList(1)).filter(lambda e: e == 1).to_list() == [1]
    assert ImmutableList(0, ImmutableList(1)).filter(lambda e: e == 2).to_list() == []
    assert ImmutableList(0, ImmutableList(0)).filter(lambda e: e > 0).to_list() == []

# Generated at 2022-06-24 00:12:50.427504
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4, 5)) == 'ImmutableList[1, 2, 3, 4, 5]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'



# Generated at 2022-06-24 00:12:59.322238
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList.of(2, 3, 4), False)
    list2 = ImmutableList(1, ImmutableList.of(2, 3, 4), False)
    list3 = ImmutableList(1, ImmutableList.of(2, 3, 4), True)
    list4 = ImmutableList.empty()
    list5 = ImmutableList.empty()

    assert list1 == list2
    assert not list1 == list3
    assert not list3 == list4
    assert list4 == list5


# Generated at 2022-06-24 00:13:05.070772
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda a, b: a + b, 0) == 0
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 1) == 7



# Generated at 2022-06-24 00:13:15.761816
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(0, 1, 2, 3, 4) \
        .filter(lambda x: x % 2) == ImmutableList.of(1, 3)

    assert ImmutableList.of(0, 1, 2, 3, 4) \
        .filter(lambda x: x == 2) == ImmutableList.of(2)

    assert ImmutableList.of(0, 1, 2, 3, 4) \
        .filter(lambda x: True) == ImmutableList.of(0, 1, 2, 3, 4)

    assert ImmutableList.of(0, 1, 2, 3, 4) \
        .filter(lambda x: False) == ImmutableList(is_empty=True)



# Generated at 2022-06-24 00:13:21.342132
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2), False)) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(False, ImmutableList(2), False)) == 'ImmutableList[False, 2]'
    assert str(ImmutableList(False, ImmutableList(None), False)) == 'ImmutableList[False, None]'


# Generated at 2022-06-24 00:13:30.300403
# Unit test for method filter of class ImmutableList

# Generated at 2022-06-24 00:13:34.401095
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    l = l.map(lambda x: x * 2)
    assert l == ImmutableList.of(2, 4, 6, 8, 10)

# Generated at 2022-06-24 00:13:38.644477
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test = ImmutableList.of(1, 2, 3, 4)
    assert test.find(lambda x: x == 3) == 3
    assert test.find(lambda x: x % 2 == 0) == 2
    assert test.find(lambda x: x > 3) is None


# Generated at 2022-06-24 00:13:46.892993
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    cases = [
        (ImmutableList.of(1, 2), ImmutableList.of(3, 4), ImmutableList.of(1, 2, 3, 4)),
        (ImmutableList.of(1, 2), ImmutableList.empty(), ImmutableList.of(1, 2)),
        (ImmutableList.empty(), ImmutableList.of(1, 2), ImmutableList.of(1, 2)),
    ]

    for (first, second, expected) in cases:
        assert first + second == expected


# Generated at 2022-06-24 00:13:50.534940
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # given
    immutable_list = ImmutableList.of(1, 2, 3)
    reducer = lambda acc, v: acc + v
    # when
    result = immutable_list.reduce(reducer, 0)
    # then
    assert result == 6

# Generated at 2022-06-24 00:13:53.245655
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of('a', 'b').to_list() == ['a', 'b']
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]



# Generated at 2022-06-24 00:13:57.392375
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x + 1) == ImmutableList.empty()
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5)


# Generated at 2022-06-24 00:14:00.479672
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).find(lambda x: x == 1) == 1

# Generated at 2022-06-24 00:14:11.318190
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (ImmutableList.empty() == ImmutableList.empty()) is True
    assert (ImmutableList.empty() == ImmutableList(1)) is False
    assert (ImmutableList(1) == ImmutableList(1)) is True
    assert (ImmutableList(1) == ImmutableList(2)) is False
    assert (
        ImmutableList(1) + ImmutableList(2)
        ==
        ImmutableList(1) + ImmutableList(2)
    ) is True
    assert (
        ImmutableList(1) + ImmutableList(2)
        ==
        ImmutableList(1) + ImmutableList(3)
    ) is False
    assert (
        ImmutableList(1, ImmutableList(2))
        ==
        ImmutableList(1, ImmutableList(3))
    ) is False

# Generated at 2022-06-24 00:14:21.408627
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1 or x == 2) \
            == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 4) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) \
            == ImmutableList.of(2)
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()

# Generated at 2022-06-24 00:14:25.732072
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    first_maybe = ImmutableList(10)
    second_maybe = ImmutableList(10)

    # Act
    result = first_maybe == second_maybe

    # Assert
    assert result



# Generated at 2022-06-24 00:14:30.783307
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():

    immutable_list_1 = ImmutableList.of(1, 2, 3)
    immutable_list_2 = ImmutableList.of(4, 5, 6)

    immutable_list = immutable_list_1 + immutable_list_2

    assert immutable_list.to_list() == [1, 2, 3, 4, 5, 6]

    assert len(immutable_list) == 6



# Generated at 2022-06-24 00:14:37.031385
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test equality of empty lists with empty lists
    assert \
        ImmutableList.empty() == ImmutableList.empty()

    # Test equality of lists with lists
    assert \
        ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)

    # Test equality of lists with lists
    assert \
        ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    # Test equality lists with not lists
    assert \
        ImmutableList.of(1, 2, 3) != None


# Generated at 2022-06-24 00:14:44.908616
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x, y: x + y, 0) == 15, 'sum of list'
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x, y: x * y, 1) == 120, 'factorial of list'
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x, y: x / y, 1) == 0.008333333333333333, 'division for list'


# Generated at 2022-06-24 00:14:50.175499
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:14:59.978459
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda x, y: x + y, 0) == ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda x, y: x * y, 1) == 6
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda x, y: x * y, 0) == 0
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda x, y: x - y, 0) == -6
    assert ImmutableList().reduce(lambda x, y: x + y, 0) == 0

# Generated at 2022-06-24 00:15:07.658389
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a * b, 1) == 6
    assert ImmutableList.of(3, 2, 1, 9, 1).reduce(lambda a, b: a * b if b % 2 == 1 else a, 1) == 27
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a * b if b % 2 == 1 else a, 100) == 300

test_ImmutableList_reduce()

# Generated at 2022-06-24 00:15:13.221917
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, is_empty=True) == ImmutableList(1, is_empty=True)
    assert ImmutableList(1, is_empty=True) != ImmutableList(1)
    assert ImmutableList(1) == ImmutableList(1, is_empty=True)
    assert ImmutableList(1, is_empty=True) == ImmutableList(1)


# Generated at 2022-06-24 00:15:21.633649
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1) != ImmutableList(2)
    assert ImmutableList.of(2) != ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1).append(2)
    assert not ImmutableList(1, ImmutableList(2), False) == ImmutableList(1, ImmutableList(2), True)
    assert not ImmutableList(1, ImmutableList(2), True) == ImmutableList(1, ImmutableList(3), True)

# Generated at 2022-06-24 00:15:26.495459
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.empty().find(lambda x: x == 1) is None


# Generated at 2022-06-24 00:15:32.199799
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # empty, single, normal case
    assert ImmutableList().reduce(lambda acc, val: acc + val, 0) == 0
    assert ImmutableList(1).reduce(lambda acc, val: acc + val, 0) == 1
    assert ImmutableList(1, 2, 3).reduce(lambda acc, val: acc + val, 0) == 6

# Generated at 2022-06-24 00:15:36.068124
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-24 00:15:43.818516
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    cases = [
        ((ImmutableList(1, ImmutableList(2)), ImmutableList(1, ImmutableList(2))), True),
        ((ImmutableList(1, ImmutableList(2)), ImmutableList(1, ImmutableList(1))), False),
        ((ImmutableList(1, ImmutableList(2)), ImmutableList(2, ImmutableList(2))), False),
    ]

    for case in cases:
        assert case[0][0] == case[0][1] == case[1]

# Generated at 2022-06-24 00:15:49.225709
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    @test
    def should_return_new_ImmutableList_with_new_element_on_the_end_of_previous_one():
        first_list = ImmutableList.of(1, 2, 3)
        second_list = first_list.append(4)
        assert isinstance(second_list, ImmutableList)
        assert len(second_list) == len(first_list) + 1
        assert str(second_list) == 'ImmutableList[1, 2, 3, 4]'


# Generated at 2022-06-24 00:15:55.069060
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1)


# Generated at 2022-06-24 00:16:00.547325
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1) == ImmutableList(1, None)
    assert ImmutableList.of(1).append(2) == ImmutableList(1, ImmutableList(2, None))
    assert ImmutableList.of(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.empty().append(1) == ImmutableList(1)

# Generated at 2022-06-24 00:16:10.210284
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList.of(1, 2)
    assert ImmutableList.empty() == ImmutableList(is_empty=True)

    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))
    assert ImmutableList(is_empty=True) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2)) != None



# Generated at 2022-06-24 00:16:13.405205
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(0)) == 1

    assert len(ImmutableList(0, ImmutableList(1))) == 2

    assert len(ImmutableList()) == 0

# Generated at 2022-06-24 00:16:16.859958
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1)\
        .unshift(2)\
        .unshift(3) == ImmutableList.of(3, 2, 1)



# Generated at 2022-06-24 00:16:21.327133
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = list1.filter(lambda x: x % 2 == 0)
    list_expected = ImmutableList.of(2, 4)
    assert list2 == list_expected
    assert list1 == list1.filter(lambda x: True)
    assert ImmutableList() == list1.filter(lambda x: False)



# Generated at 2022-06-24 00:16:24.626965
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'



# Generated at 2022-06-24 00:16:30.864403
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() + ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.empty() == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-24 00:16:33.438302
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(0, 1, 2).map(lambda x: x * 2) == \
        ImmutableList.of(0, 2, 4)



# Generated at 2022-06-24 00:16:40.049778
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    arr = ImmutableList.of(1, 2, 3, 4, 5, 6)

    assert arr.filter(lambda x: x % 2 == 0).head == 2
    assert arr.filter(lambda x: x % 2 == 0).tail.head == 4
    assert arr.filter(lambda x: x % 2 == 0).tail.tail.head == 6
    assert arr.filter(lambda x: x % 2 == 0).tail.tail.tail.is_empty


# Generated at 2022-06-24 00:16:41.038976
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(None)) == 1
    assert len(ImmutableList.of(1,2,3)) == 3


# Generated at 2022-06-24 00:16:44.313688
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1, 2, 3)  # type: ImmutableList[int]
    list_ = list_.append(4)

    assert list_.to_list() == [1, 2, 3, 4]



# Generated at 2022-06-24 00:16:48.784678
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.to_list() == [1, 2, 3, 4]


# Generated at 2022-06-24 00:16:58.454620
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1).__add__(ImmutableList.of(2)) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1).__add__(ImmutableList.of(2, 3)) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).__add__(ImmutableList.of(4, 5)) == ImmutableList.of(1, 2, 3, 4, 5)

    assert ImmutableList.of(1).__add__(ImmutableList.empty()) == ImmutableList.of(1)

    assert ImmutableList.empty().__add__(ImmutableList.empty()) == ImmutableList.empty()

    with raises(ValueError):
        ImmutableList.empty().__add__(1)

# Unit