

# Generated at 2022-06-24 00:06:58.397527
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(1) == ImmutableList.of(1, 1)



# Generated at 2022-06-24 00:07:05.395755
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6, 8)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x.upper()) == ImmutableList.of('1'.upper(), '2'.upper(), '3'.upper())
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x ** 0.5) == ImmutableList.of(1**0.5, 2**0.5, 3**0.5, 4**0.5)
    assert ImmutableList.empty().map(lambda x: x * 2) == ImmutableList.empty()

# Generated at 2022-06-24 00:07:08.853829
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    def mapper(a: Optional[int]) -> str:
        return str(a)

    assert ImmutableList.of(1, 2, 3).map(mapper) == ImmutableList.of('1', '2', '3')

# Generated at 2022-06-24 00:07:15.233712
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1,2)
    assert ImmutableList.of(1,2,3) + ImmutableList.of(4,5,6) == ImmutableList.of(1,2,3,4,5,6)
    assert ImmutableList.of(1,2) + ImmutableList.of(3,4,5) == ImmutableList.of(1,2,3,4,5)


# Generated at 2022-06-24 00:07:18.334383
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    test = ImmutableList.of(1, 2, 3, 4, 5)
    assert test.reduce(lambda x, y: x + y, 0) == 15


# Generated at 2022-06-24 00:07:20.902217
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list = ImmutableList.of(1, 3, 8, 11)
    assert immutable_list.to_list() == [1, 3, 8, 11]

# Generated at 2022-06-24 00:07:25.457236
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    il1 = ImmutableList()
    assert il1.map(lambda x: x*2) == ImmutableList.empty()

    il2 = ImmutableList.of(1, 2, 3)
    assert il2.map(lambda x: x*2) == ImmutableList.of(2, 4, 6)



# Generated at 2022-06-24 00:07:34.760927
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(2) == ImmutableList.of(2).map(lambda x: x)
    assert ImmutableList.empty() == ImmutableList.empty().map(lambda x: x)
    assert ImmutableList.of(4) == ImmutableList.of(2).map(lambda x: x*2)
    assert ImmutableList.of(8, 0) == ImmutableList.of(4, -4).map(lambda x: x*2)
    assert ImmutableList.of(2, 3, 4) == ImmutableList.of(1, 2, 3).map(lambda x: x + 1)



# Generated at 2022-06-24 00:07:45.019341
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Arrange
    x = ImmutableList(1, ImmutableList(2), is_empty=False)
    y = ImmutableList(2, x)
    z = ImmutableList(3, y)

    #Act
    #Assert
    assert x == ImmutableList(1, ImmutableList(2), is_empty=False)
    assert z == ImmutableList(3, ImmutableList(2, ImmutableList(1, ImmutableList(2), is_empty=False)))
    assert z.append(4) == ImmutableList(3, ImmutableList(2, ImmutableList(1, ImmutableList(2, ImmutableList(4)))))



# Generated at 2022-06-24 00:07:48.519269
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of('a', 'b', 'c').to_list() == ['a', 'b', 'c']

# Generated at 2022-06-24 00:07:52.727121
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Arrange
    # Create new ImmutableList of three elements
    list_1 = ImmutableList.of(1, 2, 3)
    # Act
    # Convert ImmutableList to list
    result = list_1.to_list()
    # Assert
    # Test if result is equal to expected value
    assert result == [1, 2, 3]



# Generated at 2022-06-24 00:07:54.870047
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:07:59.323378
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_ = ImmutableList()
    assert 0 == len(list_)

    list_ = ImmutableList(1)
    assert 1 == len(list_)

    list_ = ImmutableList(1, ImmutableList(2))
    assert 2 == len(list_)

    list_ = ImmutableList.of(1, 2, 3)
    assert 3 == len(list_)

# Generated at 2022-06-24 00:08:04.780567
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    """
    Tests if ImmutableList unshift method returns ImmutableList with new element
    on the begin of list
    """
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:08:08.338035
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # First case (empty list + list)
    list_one = ImmutableList()
    list_two = ImmutableList.of(1, 2, 3)
    assert (list_one.__add__(list_two) == list_two)

    # Second case (list + empty list)
    list_one = ImmutableList.of(1, 2, 3)
    list_two = ImmutableList()
    assert (list_one.__add__(list_two) == list_one)

    # Third case
    list_one = ImmutableList.of(1, 2, 3)
    list_two = ImmutableList.of(4, 5, 6)
    assert (list_one.__add__(list_two) == ImmutableList.of(1, 2, 3, 4, 5, 6))


# Unit

# Generated at 2022-06-24 00:08:11.934438
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList(1)

    list2 = list1.unshift(0)

    assert list2 == ImmutableList(0, list1)



# Generated at 2022-06-24 00:08:14.513155
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == "ImmutableList[1, 2, 3]"



# Generated at 2022-06-24 00:08:16.862378
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:08:23.822759
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, 2, 3) == ImmutableList(1, 2, 3)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList(is_empty=True) == ImmutableList.empty()


# Generated at 2022-06-24 00:08:28.980953
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(2, ImmutableList(1, ImmutableList.empty())).to_list() == [2, 1]
    assert ImmutableList(4, ImmutableList(3, ImmutableList(2, ImmutableList(1, ImmutableList.empty())))).to_list() == [4, 3, 2, 1]

# Generated at 2022-06-24 00:08:31.325399
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList\
        .of(1, 2, 3)\
        .filter(lambda x: x == 2)\
        == ImmutableList.of(2)



# Generated at 2022-06-24 00:08:34.582797
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(5)) == 1
    assert len(ImmutableList.of(5, 5, 5, 5)) == 4

# Generated at 2022-06-24 00:08:43.620479
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty()
    assert ImmutableList(1).map(lambda x: x) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x) == ImmutableList(1, ImmutableList(2))

    assert ImmutableList(1).map(lambda x: x + 1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x + 1) == ImmutableList(2, ImmutableList(3))



# Generated at 2022-06-24 00:08:47.134272
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList()) == 'ImmutableList[]'


# Generated at 2022-06-24 00:08:57.633310
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    listA = ImmutableList(10, ImmutableList(20))
    listB = ImmutableList(30, ImmutableList(40))

    result = listA.__add__(listB)

    assert len(result) == 4
    assert result.head == 10
    assert isinstance(result.tail, ImmutableList)
    assert result.tail.head == 20
    assert isinstance(result.tail.tail, ImmutableList)
    assert result.tail.tail.head == 30
    assert isinstance(result.tail.tail.tail, ImmutableList)
    assert result.tail.tail.tail.head == 40
    assert result.tail.tail.tail.tail is None


# Generated at 2022-06-24 00:09:04.301165
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    instances = [1, 2]
    assert ImmutableList.of(*instances).reduce(lambda acc, item: acc + item, 0) == 3
    assert ImmutableList.of(*instances).reduce(lambda acc, item: acc * item, 1) == 2


# Generated at 2022-06-24 00:09:09.052292
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: True) is None
    assert ImmutableList(1).find(lambda x: x == 2) is None
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList(1, 2, 23, 4, 5).find(lambda x: x == 23) == 23

# Generated at 2022-06-24 00:09:16.182458
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, val: acc + val, 0) == 6
    assert ImmutableList.of(2, 3).reduce(lambda acc, val: acc * val, 1) == 6
    assert ImmutableList.empty().reduce(lambda acc, val: acc * val, 1) == 1


# Generated at 2022-06-24 00:09:26.393865
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of() == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of() + ImmutableList.of() == ImmutableList.of()

# Generated at 2022-06-24 00:09:28.145573
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList[1]' == ImmutableList(1).__str__()


# Generated at 2022-06-24 00:09:31.216580
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    l = ImmutableList.of(1, 2, 3)
    l_ = l.map(lambda x: x * 2)

    assert(l_ == ImmutableList.of(2, 4, 6))



# Generated at 2022-06-24 00:09:36.298257
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1, ImmutableList(2), is_empty=False)) == 2
    assert len(ImmutableList("1", ImmutableList("2", ImmutableList("3"), is_empty=False), is_empty=False)) == 3
    assert len(ImmutableList("1", ImmutableList("2", ImmutableList("3", ImmutableList("4"), is_empty=False), is_empty=False), is_empty=False)) == 4

# Generated at 2022-06-24 00:09:40.310023
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Arrange
    # Act
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = list1.unshift(0)

    # Assert
    assert list1 == ImmutableList.of(1, 2, 3, 4)
    assert list2 == ImmutableList.of(0, 1, 2, 3, 4)

# Generated at 2022-06-24 00:09:43.588412
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]

# Generated at 2022-06-24 00:09:52.097521
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    empty_list = ImmutableList.empty()
    assert empty_list.append(1) == ImmutableList.of(1)

    single_el_list = ImmutableList.of(1)
    assert single_el_list.append(2) == ImmutableList.of(1, 2)

    more_el_list = ImmutableList.of(1, 2)
    assert more_el_list.append(3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:09:53.863681
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'


# Generated at 2022-06-24 00:09:59.603821
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Given
    start_list = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

    # When
    ilist = ImmutableList.of(*start_list)

    # Then
    assert ilist.to_list() == start_list
    assert len(ilist) == len(start_list)



# Generated at 2022-06-24 00:10:01.000471
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(3).to_list() == [1, 3]


# Generated at 2022-06-24 00:10:07.397577
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    
    assert list_.reduce(lambda x, y: x + y, 0) == 10
    assert list_.reduce(lambda x, y: x ** y, 2) == 16

    assert ImmutableList(1, ImmutableList(2)).reduce(lambda acc, element: acc * element, 1) == 2


# Generated at 2022-06-24 00:10:12.222007
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:10:21.991046
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 1) == 7
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, -1) == 5
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x * y, 1) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x * y, 2) == 12
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x * y, 0) == 0


# Generated at 2022-06-24 00:10:26.225130
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x % 2) == ImmutableList.of(1, 0, 1)

# Generated at 2022-06-24 00:10:33.011479
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = ImmutableList.empty()

    # Act
    list1_result = list1.map(lambda x: x * 2)
    list2_result = list2.map(lambda x: x * 2)

    # Assert
    assert ImmutableList.of(2, 4, 6, 8) == list1_result
    assert ImmutableList.empty() == list2_result

# Generated at 2022-06-24 00:10:38.566123
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list = ImmutableList.of(1, 2, 3)
    assert list.append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-24 00:10:42.084745
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(2) != ImmutableList.of(1)
    assert ImmutableList.of(1) != None

# Generated at 2022-06-24 00:10:45.995445
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    expected = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    result = ImmutableList.empty().unshift(3).unshift(2).unshift(1)

    assert result == expected


# Generated at 2022-06-24 00:10:51.443219
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    il_instance = ImmutableList.of(1, 2)

    # Find with no match
    il_empty = ImmutableList.of(1).find(lambda x: x > 1)
    assert il_empty is None

    # Find with match
    il_match = il_instance.find(lambda x: x > 1)
    assert il_match == 2


# Generated at 2022-06-24 00:11:01.175715
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1).append(1).append(2) == ImmutableList.of(1, 1, 2)
    assert ImmutableList.of(1).append(2).append(1) == ImmutableList.of(1, 2, 1)
    assert ImmutableList.of(1).append(3).append(3).append(3) == ImmutableList.of(1, 3, 3, 3)
    
    

# Generated at 2022-06-24 00:11:06.460572
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list = ImmutableList.empty()
    assert len(list) == 0

    list = ImmutableList.of('a')
    assert len(list) == 1

    list = ImmutableList.of('a', 'b')
    assert len(list) == 2

    list = ImmutableList.of('a', 'b', 'c')
    assert len(list) == 3

    list = ImmutableList.of('a', 'b', 'c', 'd')
    assert len(list) == 4


# Generated at 2022-06-24 00:11:10.751544
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    ImmutableList.empty()
    assert len(ImmutableList.empty()) == 0

    assert len(ImmutableList.of(0)) == 1

    assert len(ImmutableList.of(0, 1, 2)) == 3

# Generated at 2022-06-24 00:11:15.675449
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = ImmutableList.of(5, 6, 7, 8)
    actual = list1 + list2
    expected = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)

    assert actual == expected

# Generated at 2022-06-24 00:11:20.217942
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    imp_list = ImmutableList.of(1, 2, 3, 4)

    assert imp_list.to_list() == [1, 2, 3, 4]


# Generated at 2022-06-24 00:11:25.409932
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Set of data for testing
    test_input_list = ImmutableList.of(1, 2, 3, 4)
    function_list = [lambda x: x < 2, lambda x: x == 1, lambda x: x == 5]
    test_result_list = [None, 1, None]

    # Loop to check if function returns correct result
    for i, test_input in enumerate(test_input_list.to_list()):
        result = test_input_list.find(function_list[i])
        assert result == test_result_list[i]



# Generated at 2022-06-24 00:11:32.410902
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    list_a = ImmutableList.of(1, 2, 3, 4, 5)
    list_b = ImmutableList.empty()
    # When
    result_a = list_a.find(lambda x: x == 4)
    result_b = list_b.find(lambda x: x == 2)
    # Then
    assert result_a == 4
    assert result_b is None


# Generated at 2022-06-24 00:11:38.506875
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert (len(ImmutableList.empty()) == 0)
    assert (len(ImmutableList(1, None)) == 1)
    assert (len(ImmutableList(1, ImmutableList(2, ImmutableList(3, None)))) == 3)
    
    
test_ImmutableList___len__()

# Generated at 2022-06-24 00:11:43.494485
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Arrange
    item = 1
    cls = ImmutableList.empty()

    # Act
    result = cls.unshift(item)

    # Assert
    assert type(result) is ImmutableList
    assert len(result) == 1
    assert result.head is item
    assert result.tail is None


# Generated at 2022-06-24 00:11:49.262423
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.of(1, 2, 3)
    assert immutable_list.find(lambda x: x > 4) is None
    assert immutable_list.find(lambda x: x > 3) is None
    assert immutable_list.find(lambda x: x > 2) == 3

# Generated at 2022-06-24 00:11:53.492166
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'



# Generated at 2022-06-24 00:11:56.511377
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    l = ImmutableList.of(1, 2, 3, 4, 5, 6)

    # When
    result = l.find(lambda x: x > 3)

    # Then
    assert result == 4


# Generated at 2022-06-24 00:12:03.385811
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList().is_empty
    assert ImmutableList(1).head == 1
    assert not ImmutableList(1).tail.is_empty
    assert ImmutableList(1, ImmutableList(2)).head == 1
    assert ImmutableList(1, ImmutableList(2)).tail.head == 2
    assert ImmutableList.of(1).head == 1
    assert ImmutableList.of(1, 2).head == 1
    assert ImmutableList.of(1, 2).tail.head == 2
    assert ImmutableList.empty().is_empty
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).head == 1


# Generated at 2022-06-24 00:12:06.003347
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual = ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert actual == True



# Generated at 2022-06-24 00:12:12.315521
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ilist = ImmutableList.of(1, 2, 3, 4)
    assert ilist.find(lambda x: x == 2) == 2
    assert ilist.find(lambda x: x == 5) is None
    assert ImmutableList(is_empty=True).find(lambda x: x == 5) is None
    assert ImmutableList().find(lambda x: x == 5) is None


# Generated at 2022-06-24 00:12:20.701038
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(ImmutableList.of(1), ImmutableList.of(2)).to_list() == [ImmutableList.of(1), ImmutableList.of(2)]
    assert ImmutableList.of(ImmutableList.of(ImmutableList.of(1)), ImmutableList.of(ImmutableList.of(2))).to_list() == [ImmutableList.of(ImmutableList.of(1)), ImmutableList.of(ImmutableList.of(2))]


# Generated at 2022-06-24 00:12:24.845045
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # GIVEN
    A = ImmutableList.of(1, 2, 3, 4, 5)

    # WHEN
    result = A.find(lambda x: x == 3)

    # THEN
    assert 3 == result


# Generated at 2022-06-24 00:12:28.938253
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    #  Given
    numbers_list = ImmutableList(1, ImmutableList(2))

    def accumulator(acc, num):
        return num + acc
    # When
    result = numbers_list.reduce(accumulator, 0)

    # Then
    assert result == 3


# Generated at 2022-06-24 00:12:32.087950
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    list_ = ImmutableList.of(1, 2)

    # When
    # Then
    assert list_.to_list() == [1, 2]


# Generated at 2022-06-24 00:12:40.724212
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """ Unit test for method filter of class ImmutableList"""
    elements = [int(10*random()) for i in range(10)]
    lst = ImmutableList.of(*elements)
    filtered = lst.filter(lambda x: x % 2 == 1)
    lst2 = lst.append(int(10*random()))
    lst3 = lst.filter(lambda x: x % 2 == 1).append(int(10*random()))
    for element in lst.to_list():
        assert element in elements
    for element in filtered.to_list():
        assert element in elements
        assert element % 2 == 1
    for element in lst2.to_list():
        assert element in elements
    for element in lst3.to_list():
        assert element in elements
        assert element % 2 == 1

# Generated at 2022-06-24 00:12:46.896497
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) == None

test_ImmutableList_find()

# Generated at 2022-06-24 00:12:51.896055
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    test_ImmutableList = ImmutableList.of(1, 2, 3)
    new_ImmutableList = ImmutableList.of(4, 5, 6)
    # test_ImmutableList = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    # new_ImmutableList = ImmutableList(4, ImmutableList(5, ImmutableList(6)))

    assert test_ImmutableList + new_ImmutableList == ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-24 00:12:58.886552
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .reduce(lambda acc, val: acc + val, 0) == 15

    assert ImmutableList.of(10, 20, 30, 40, 50)\
        .reduce(lambda acc, val: acc + val, 0) == 150
    print('All test cases passed!')

# test_ImmutableList_reduce()

# Generated at 2022-06-24 00:13:02.899036
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_instance = ImmutableList.of(1, 2, 3)
    list_instance = list_instance.append(4)

    assert list_instance.to_list() == [1, 2, 3, 4]


# Generated at 2022-06-24 00:13:12.165756
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 2) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 3) == ImmutableList.of(3)

# Generated at 2022-06-24 00:13:15.929135
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert(
        ImmutableList([1, 2, 3]).map(lambda x: x * 2) ==
        ImmutableList([2, 4, 6])
    )


# Generated at 2022-06-24 00:13:26.956561
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'a') == 'a'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'b') == 'b'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'c') == 'c'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'd') is None
    assert ImmutableList.of('a').find(lambda x: x == 'a') == 'a'
    assert ImmutableList.of('a').find(lambda x: x == 'b') is None
    assert ImmutableList.empty().find(lambda x: x == 'a') is None


# Generated at 2022-06-24 00:13:30.796091
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList.of(1, 2, 3)
    list_result = list1.find(lambda x: x == 2)

    assert list_result == 2, 'Should return 2'

# Generated at 2022-06-24 00:13:37.458267
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3, 4, 5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert ImmutableList.empty() == ImmutableList(is_empty=True)


# Generated at 2022-06-24 00:13:45.419079
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(2, 3, 4, 5).append(6) == ImmutableList.of(2, 3, 4, 5, 6)
    assert ImmutableList(2, ImmutableList(3)).append(4) == ImmutableList(2, ImmutableList(3, ImmutableList(4)))
    assert ImmutableList(10, ImmutableList(20, ImmutableList(30))).append(40) == ImmutableList(10, ImmutableList(20, ImmutableList(30, ImmutableList(40))))


# Generated at 2022-06-24 00:13:48.914464
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    my_list = ImmutableList.of(1, 2, 3, 4)

    def add(x: int, y: int) -> int:
        return x + y

    assert my_list.reduce(add, 0) == 10

# Generated at 2022-06-24 00:13:53.849562
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3, 4)
    c = ImmutableList.of(1)
    d = ImmutableList.of()
    
    assert len(a) == 3
    assert len(b) == 4
    assert len(c) == 1
    assert len(d) == 0

# Generated at 2022-06-24 00:13:56.843489
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list = ImmutableList.of(1)
    assert immutable_list.to_list() == [1]

    immutable_list = ImmutableList.of(1, 2, 3)
    assert immutable_list.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:14:03.062894
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    my_list = ImmutableList.of(1, 2, 3, 4)
    expected_list = ImmutableList.of(2, 4, 6, 8)


    # Act
    actual_list = my_list.map(lambda x: x*2)

    # Assert
    assert actual_list == expected_list


# Generated at 2022-06-24 00:14:06.499789
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    actual = ImmutableList.of('a').__len__()
    expected = 1

    assert actual == expected

    actual = ImmutableList.of('a', 'b').__len__()
    expected = 2

    assert actual == expected


# Generated at 2022-06-24 00:14:09.758556
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6, 8, 10)

# Generated at 2022-06-24 00:14:21.442528
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    from unittest import TestCase

    class MapTestCase(TestCase):
        def test_empty_list(self):
            self.assertEqual(
                ImmutableList(is_empty=True).map(lambda x: x + 1),
                ImmutableList(is_empty=True),
            )

        def test_one_element_list(self):
            self.assertEqual(
                ImmutableList(1).map(lambda x: x + 1),
                ImmutableList(2),
            )

        def test_two_elements_list(self):
            self.assertEqual(
                ImmutableList(1, ImmutableList(2)).map(lambda x: x + 1),
                ImmutableList(2, ImmutableList(3)),
            )

    MapTestCase('test_empty_list').test_empty

# Generated at 2022-06-24 00:14:27.393380
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    input_list = [1, 2, 3]
    a = ImmutableList.of(input_list[0], input_list[1], input_list[2])
    b = ImmutableList.of(input_list[0], input_list[1], input_list[2])
    c = ImmutableList.of(input_list[0], input_list[1])
    assert a == b

    assert a != c


# Generated at 2022-06-24 00:14:32.688812
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    l = ImmutableList.of(1)
    assert len(l) == 1

    l = ImmutableList.of(1, 2, 3)
    assert len(l) == 3

    l = ImmutableList.of(1, 2, 3, 4)
    assert len(l) == 4

    l = ImmutableList.of(1, 2, 3, 4, 5)
    assert len(l) == 5



# Generated at 2022-06-24 00:14:39.674529
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(3, 2, 1)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 3, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(3, 2, 1) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty

# Generated at 2022-06-24 00:14:42.170944
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(2).append(3) == ImmutableList.of(2, 3)
    assert ImmutableList.of(2, 3).append(6) == ImmutableList.of(2, 3, 6)


# Generated at 2022-06-24 00:14:48.562782
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1)
    l2 = ImmutableList.of(1)
    l3 = ImmutableList.of(1, 2, 3)
    l4 = ImmutableList.of(2)
    l5 = ImmutableList.of(1, 2, 4)

    assert l1 == l2
    assert not l1 == l3
    assert not l1 == l4
    assert not l3 == l5

# Generated at 2022-06-24 00:14:58.238888
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    result = ImmutableList.of(0, 0, 0)
    assert len(result.append(0)) == 4
    assert result.append(0).to_list() == [0, 0, 0, 0]
    assert result.append('a').to_list() == [0, 0, 0, 'a']
    assert result.append(1).to_list() == [0, 0, 0, 1]
    result = ImmutableList.empty()
    assert result.append(1).to_list() == [1]
    result = ImmutableList.of('a')
    assert result.append(1).to_list() == ['a', 1]
    assert result.append(1).append(1).to_list() == ['a', 1, 1]

# Generated at 2022-06-24 00:15:08.482161
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.of(10, 20, 30)
    list2 = list1.unshift(100)
    list3 = list2.unshift(1000)
    assert list1.head == 10
    assert list1.tail.head == 20
    assert list1.tail.tail.head == 30
    assert list1.tail.tail.tail is None
    assert list2.head == 100
    assert list2.tail.head == 10
    assert list2.tail.tail.head == 20
    assert list2.tail.tail.tail.head == 30
    assert list2.tail.tail.tail.tail is None
    assert list3.head == 1000
    assert list3.tail.head == 100
    assert list3.tail.tail.head == 10
    assert list3.tail.tail.tail.head == 20

# Generated at 2022-06-24 00:15:14.142507
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    initial_list = ImmutableList.of(1, 2, 3, 4, 5)
    filtered_list = initial_list.filter(lambda x: x > 3)
    assert filtered_list == ImmutableList.of(4, 5)

    filtered_list = initial_list.filter(lambda x: x < 3)
    assert filtered_list == ImmutableList.of(1, 2)

    assert initial_list == ImmutableList.of(1, 2, 3, 4, 5)
    assert filtered_list == ImmutableList.of(1, 2)



# Generated at 2022-06-24 00:15:16.468208
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of().to_list() == []


# Generated at 2022-06-24 00:15:27.553294
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # testing of method ImmutableList.of() -> ImmutableList[T]
    #
    # Example of use of method ImmutableList.of() -> ImmutableList[T]
    # >>> ImmutableList.of('1', '2', '3', '4', '5')
    # ImmutableList['1', '2', '3', '4', '5']
    #
    
    def fake_test_fn_01():
        assert ImmutableList.of('1', '2', '3', '4', '5') == ImmutableList('1', ImmutableList('2', ImmutableList('3', ImmutableList('4', ImmutableList('5'))))), "ImmutableList.of(1, 2, 3, 4, 5) - error."
    #
    # Unit test
    #
    #
    #
    fake

# Generated at 2022-06-24 00:15:34.309202
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) ==\
        ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) !=\
        ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-24 00:15:38.933583
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1).filter(lambda x: x > 1) == ImmutableList.empty()
    assert ImmutableList.of(1).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)


# Generated at 2022-06-24 00:15:42.509181
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1, 2, 3, 4)
    assert(l.find(lambda x: x == 3) == 3)
    assert(l.find(lambda x: x == 13) == None)
    
    

# Generated at 2022-06-24 00:15:46.215618
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    lst = ImmutableList.of(1, 2, 3)
    mapped_lst = lst.map(lambda x: x * x)

    assert mapped_lst == ImmutableList.of(1, 4, 9)

# Generated at 2022-06-24 00:15:48.710338
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list = ImmutableList.of(1, 2, 4)
    list2 = ImmutableList.of(1, 2, 4)

    assert list == list2



# Generated at 2022-06-24 00:15:56.130812
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    f = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    s = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert (f + s) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(1, ImmutableList(2, ImmutableList(3))))))

test_ImmutableList___add__()


# Generated at 2022-06-24 00:15:58.942569
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_one = ImmutableList.empty()
    list_two = ImmutableList.empty()

    assert list_one == list_one
    assert list_one == list_two


# Generated at 2022-06-24 00:16:02.847151
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    example = ImmutableList.of(1, 2, 3, 4, 5)
    example2 = ImmutableList.of(1, 2, 3, 4, 5)
    example3 = ImmutableList.of(1, 2, 3, 4)

    assert example == example2
    assert example3 != example2
    assert example3 != example
    assert ImmutableList.empty() == ImmutableList.empty()


# Generated at 2022-06-24 00:16:10.084653
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    def fn(acc, element):
        return acc + element

    assert ImmutableList().reduce(fn, 0) == 0
    assert ImmutableList(1).reduce(fn, 0) == 1
    assert ImmutableList(1, ImmutableList(1)).reduce(fn, 0) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(fn, 0) == 6
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(fn, 1) == 7



# Generated at 2022-06-24 00:16:11.319685
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(5) == ImmutableList(5)



# Generated at 2022-06-24 00:16:20.536492
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # test failed
    assert ImmutableList().map(lambda a: a ** 2) == ImmutableList()

    # test failed
    assert ImmutableList(5).map(lambda a: a ** 2) == ImmutableList(25)
    assert ImmutableList(5).map(lambda a: a ** 2) != ImmutableList(-1)

    # test passed
    assert ImmutableList(5).map(lambda a: a ** 2) == ImmutableList.of(25)
    assert ImmutableList(5).map(lambda a: a ** 2) != ImmutableList.of(-1)

    # test passed
    assert ImmutableList.of(1, 2, 3, 4).map(lambda a: a ** 2) == ImmutableList.of(1, 4, 9, 16)

# Generated at 2022-06-24 00:16:29.400613
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList.of(1)
    assert(list1.find(lambda x: x) == 1)
    assert(list1.find(lambda x: not x) == None)

    list2 = ImmutableList.of(1, 2, 3)
    assert(list2.find(lambda x: x == 2) == 2)
    assert(list2.find(lambda x: x == 0) == None)
    
test_ImmutableList_find()

# Generated at 2022-06-24 00:16:36.163144
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of() + ImmutableList.of() == ImmutableList.of()
    assert ImmutableList.of(1) + ImmutableList.of() == ImmutableList.of(1)
    assert ImmutableList.of() + ImmutableList.of(1) == ImmutableList.of(1)


# Generated at 2022-06-24 00:16:42.398918
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x * x) == ImmutableList.of(1, 4, 9, 16)
    assert ImmutableList.empty().map(lambda x: x * x) == ImmutableList.empty()
    
    

# Generated at 2022-06-24 00:16:43.737205
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    pass
    # TODO: write test case
    
    

# Generated at 2022-06-24 00:16:47.268601
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    l = ImmutableList(10, ImmutableList(2, ImmutableList(9, ImmutableList(21))))

    # When
    result = l.filter(lambda x: x >= 5)

    # Then
    assert result == ImmutableList(10, ImmutableList(9, ImmutableList(21)))

# Generated at 2022-06-24 00:16:56.480799
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_imm_1 = ImmutableList(1)
    list_imm_2 = ImmutableList(1, ImmutableList(2))
    list_imm_3 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_imm_4 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert list_imm_1.append(2) == ImmutableList(1, ImmutableList(2))
    assert list_imm_2.append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list_imm_3.append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))