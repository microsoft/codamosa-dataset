

# Generated at 2022-06-24 00:06:54.336613
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ilist = ImmutableList.of('head', 1, 2, 3, 4, 5, 6, 'tail')

    result = ilist.filter(lambda element: element % 2 == 0)
    assert result == ImmutableList.of(2, 4, 6)
    


# Generated at 2022-06-24 00:07:03.456506
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: True) is None
    assert ImmutableList.empty().find(lambda x: False) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x < 2) == 1
    
    

# Generated at 2022-06-24 00:07:07.517388
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList().append(1) == ImmutableList(1)
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:07:12.171820
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # When/Then
    assert len(ImmutableList(None)) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6)) == 6

# Generated at 2022-06-24 00:07:22.477354
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Assert ImmutableList() + ImmutableList() == ImmutableList()
    assert ImmutableList().__add__(ImmutableList()) == ImmutableList()

    # Assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1,2)
    assert ImmutableList(1).__add__(ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

    # Assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)).__add__(ImmutableList(3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    # Assert ImmutableList(1) + ImmutableList

# Generated at 2022-06-24 00:07:27.082818
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    list_arg = ImmutableList.of(1, 2, 3)
    expected = ImmutableList.of(1, 3)
    # Act
    actual = list_arg.filter(lambda x: x % 2 == 1)
    # Assert
    assert expected == actual


# Generated at 2022-06-24 00:07:32.811994
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList() != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) != ImmutableList(2)



# Generated at 2022-06-24 00:07:35.966020
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Using the of method
    list_of_a = ImmutableList.of('a')
    assert 'a' == list_of_a.find(lambda x: x == 'a')


# Generated at 2022-06-24 00:07:38.415037
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)


# Generated at 2022-06-24 00:07:42.734635
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0).to_list() == [0, 1]
    assert ImmutableList.of(1, 2, 3).unshift(0).to_list() == [0, 1, 2, 3]


# Generated at 2022-06-24 00:07:46.367789
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))) == ImmutableList(0, ImmutableList(1, ImmutableList(2)))
    assert ImmutableList() == ImmutableList(is_empty=True)

# Generated at 2022-06-24 00:07:48.822766
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))


# Generated at 2022-06-24 00:07:52.061903
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    my_list = ImmutableList.of(1, 2, 3, 4)
    assert my_list.to_list() == [1, 2, 3, 4]

from typing import Generic

from aioresponses import aioresponses



# Generated at 2022-06-24 00:07:55.726366
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(1)
    list3 = ImmutableList.of(2)
    assert list1 == list2
    assert list1 == list1
    assert (list1 == list3) is False

# Generated at 2022-06-24 00:07:58.836760
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:08:10.541268
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(2) == ImmutableList.of(2, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(2) == ImmutableList.of(2, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4).unshift(2) == ImmutableList.of(2, 1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).unshift(2) == ImmutableList.of(2, 1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:08:16.991675
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_to_test = ImmutableList.of(3, 2, 1)
    assert list_to_test.reduce(lambda acc, x: acc + x, 0) == 6

    assert ImmutableList.of(1).reduce(lambda acc, x: acc + x, 0) == 1
    assert ImmutableList.empty().reduce(lambda acc, x: acc + x, 0) == 0


# Generated at 2022-06-24 00:08:26.520903
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2), True) == ImmutableList(1, ImmutableList(2), True)

    assert not ImmutableList(1, ImmutableList(2)) == ImmutableList(1)
    assert not ImmutableList(1, ImmutableList(2)) == ImmutableList(2)
    assert not ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(3))
    assert not ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2), True)



# Generated at 2022-06-24 00:08:29.645297
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    input = ImmutableList.of(1, 2, 3)
    expected = ImmutableList(2, ImmutableList(3, ImmutableList(4)))

    assert input.map(lambda x: x + 1) == expected


# Generated at 2022-06-24 00:08:31.424186
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList('value1') + ImmutableList('value2') == ImmutableList('value1', ImmutableList('value2'))

# Generated at 2022-06-24 00:08:39.971830
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    func = lambda x: x
    assert ImmutableList.of(1, 2, 3).append(4).map(func) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1).append(4).map(func) == ImmutableList.of(1, 4)
    assert ImmutableList.of(1, 2).append(2).map(func) == ImmutableList.of(1, 2, 2)
    assert ImmutableList.of(1, 2).append(3).map(func) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:08:42.853685
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    for element in [2, 3, 4]:
        assert ImmutableList.of(element) == ImmutableList(element)



# Generated at 2022-06-24 00:08:46.977927
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 4

# Generated at 2022-06-24 00:08:49.653611
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, None)))) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:08:53.984199
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    value = ImmutableList.of(3, 4, 5).map(lambda x: x ** x)
    expected = ImmutableList.of(27, 256, 3125)

    assert value == expected


# Generated at 2022-06-24 00:08:57.905887
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    il = ImmutableList.of(1,2,3)
    il_append = il.append(4)

    assert len(il_append) == 4
    assert il_append.to_list() == [1,2,3,4]

# Generated at 2022-06-24 00:09:08.547508
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():

    # Test empty list
    assert ImmutableList.empty().reduce(lambda a, b: a + b, 0) == 0

    # Test list with one element
    assert ImmutableList.of(1).reduce(lambda a, b: a + b, 0) == 1

    # Test list with many elements
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 0) == 6

    # Test list with many elements more complex
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, ImmutableList.of(4, 5, 6))\
        == ImmutableList.of(11, 12, 13)



# Generated at 2022-06-24 00:09:14.385162
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list = ImmutableList.of(1)
    assert list.head == 1
    assert list.tail == None
    
    list = ImmutableList.of(1, 2, 3)
    assert list.head == 1
    assert list.tail.to_list() == [2, 3]
    
    
    list = ImmutableList.empty()
    assert list.head == None
    assert list.tail == None
    assert list.is_empty == True
 

# Generated at 2022-06-24 00:09:23.400236
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1).filter(lambda x: x == 3) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 5) == ImmutableList.empty()
    


# Generated at 2022-06-24 00:09:31.673797
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    tree = ImmutableList.of(1, 2, 3, 4)
    assert tree.find(lambda x: x >= 3) == 3
    assert tree.find(lambda x: x >= 5) == None

    tree2 = ImmutableList.of(1, 2, 3, 4)
    tree3 = ImmutableList.empty().unshift(1).unshift(2).unshift(3).unshift(4)
    assert tree2.find(lambda x: x >= 3) == 3
    assert tree2.find(lambda x: x >= 4) == 3
    assert tree2.find(lambda x: x == 5) is None
    assert tree3.find(lambda x: x >= 3) == 3
    assert tree3.find(lambda x: x >= 4) == 3
    assert tree3.find(lambda x: x == 5)

# Generated at 2022-06-24 00:09:37.622191
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.of(1).__str__() == 'ImmutableList[1]'
    assert ImmutableList.of(1, 2).__str__() == 'ImmutableList[1, 2]'
    assert ImmutableList.of(1, 2, 3).__str__() == 'ImmutableList[1, 2, 3]'
    assert ImmutableList.of(1, 2, 3, 4).__str__() == 'ImmutableList[1, 2, 3, 4]'


# Generated at 2022-06-24 00:09:40.742288
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(5, 5, 5).reduce(lambda x, y: x * y, 1) == 125

# Generated at 2022-06-24 00:09:46.127855
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    empty_list = ImmutableList.empty()

    assert len(ImmutableList.of(1, 2, 3) + empty_list) == 3
    assert len(empty_list + ImmutableList.of(1, 2, 3)) == 3

    assert ImmutableList.of(1, 2, 3) + empty_list == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-24 00:09:53.960790
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList.of(1)
    list_2 = ImmutableList.of(2)
    list_3 = ImmutableList.of(3)

    assert list_1 + list_2 == ImmutableList.of(1, 2)
    assert list_1 + list_2 + list_3 == ImmutableList.of(1, 2, 3)
    assert list_3 + list_2 + list_1 == ImmutableList.of(3, 2, 1)



# Generated at 2022-06-24 00:09:57.768681
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(
        1, 2, 3, 4
    ).map(lambda x: x + 1) == ImmutableList.of(
        2, 3, 4, 5
    )


# Generated at 2022-06-24 00:10:01.406170
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list = ImmutableList(4, ImmutableList(1, ImmutableList(3)))

    assert list.head == 4
    assert list.tail.head == 1

    empty_list = ImmutableList()
    assert empty_list.is_empty == True


# Unit tests for method of of class ImmutableList

# Generated at 2022-06-24 00:10:07.130087
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3, 4).unshift(0) == ImmutableList.of(0, 1, 2, 3, 4)



# Generated at 2022-06-24 00:10:10.711925
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(2)
    list3 = ImmutableList.of(3)
    list4 = ImmutableList.of(4)

    list5 = list1 + list2 + list3 + list4

    assert isinstance(list5, ImmutableList)
    assert list5.head == 1
    assert list5.tail.head == 2
    assert list5.tail.tail.head == 3
    assert list5.tail.tail.tail.head == 4
    assert list5.tail.tail.tail.tail is None

    list6 = list1 + list2

    assert isinstance(list6, ImmutableList)
    assert list6.head == 1
    assert list6.tail.head == 2
    assert list6.tail.tail is None

   

# Generated at 2022-06-24 00:10:17.129863
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce(): # pragma: no cover
    list_from_10_to_1 = ImmutableList.of(10, 9, 8, 7, 6, 5, 4, 3, 2, 1)
    sum_from_10_to_1 = list_from_10_to_1.reduce(lambda acc, _: acc + 1, 0)

    assert sum_from_10_to_1 == 10, \
        'ImmutableList.reduce should return 10, because there are 10 elements in list'

# Generated at 2022-06-24 00:10:20.312441
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)


# Generated at 2022-06-24 00:10:22.988489
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__str__() == 'ImmutableList[1, 2, 3]'

test_ImmutableList___str__()

# Generated at 2022-06-24 00:10:31.386321
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: True) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: False) == ImmutableList.of()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x <= 2) == ImmutableList.of(1, 2)

test_ImmutableList_filter()

# Generated at 2022-06-24 00:10:35.939856
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(1)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(4))) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) != ImmutableList(None)
    assert ImmutableList() != ImmutableList(None)


# Generated at 2022-06-24 00:10:37.526294
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list1 = ImmutableList.of(2, 3)
    list2 = ImmutableList.of(2, 3)
    assert str(list1) == str(list2)



# Generated at 2022-06-24 00:10:42.151566
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList('a')) == 'ImmutableList[a]'
    assert str(ImmutableList(1, 2)) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:10:45.219926
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of('Hello').append('world') == ImmutableList.of('Hello', 'world')


# Generated at 2022-06-24 00:10:51.254919
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x > 4) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x < 3) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x < 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x % 2 != 0) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x % 2 == 0) == 2
   

# Generated at 2022-06-24 00:11:00.816508
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.empty() == ImmutableList.empty()

    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) != ImmutableList.empty()

    # TODO: add checks for comparing with lists and something else


# Generated at 2022-06-24 00:11:05.654475
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1) != 'ImmutableList'
    assert ImmutableList() != 1
    assert ImmutableList() != None



# Generated at 2022-06-24 00:11:10.279037
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3,4,5).reduce(lambda a, b: a+b, 0) == 15
    assert ImmutableList.of(1,2,3,4,5).reduce(lambda a, b: a*b, 1) == 120

# Generated at 2022-06-24 00:11:17.556978
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of('value').find(lambda x: x == 'value') == 'value'
    assert ImmutableList.of('value').find(lambda x: x != 'value') is None
    assert ImmutableList.empty().find(lambda x: x is not None) is None
    assert ImmutableList.of('value', 'value2', 'value3').find(
        lambda x: x in ['value', 'value4']
    ) == 'value'


# Generated at 2022-06-24 00:11:18.719811
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_ = ImmutableList.of('a', 'b', 'c')
    assert str(list_) == 'ImmutableList[a, b, c]'


# Generated at 2022-06-24 00:11:25.002302
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)


test_ImmutableList_append()


# Generated at 2022-06-24 00:11:29.625983
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Prepare
    list_one = ImmutableList.of(1)
    list_two = ImmutableList.of(2)

    # Execute
    result = list_one.__add__(list_two)

    # Assert
    assert result.__eq__(ImmutableList.of(1, 2)) is True



# Generated at 2022-06-24 00:11:40.025332
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2).append(3).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1).append(2).append(3).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1).map(lambda x: x * 2) == ImmutableList.of(2)

    assert ImmutableList.empty().map(lambda x: x * 2) == ImmutableList.empty()
    assert ImmutableList.of(1).append(ImmutableList.empty()).map(lambda x: x * 2)

# Generated at 2022-06-24 00:11:48.341785
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    actual_list_of_len_0 = ImmutableList.empty()
    expected_list_of_len_0 = 0
    assert actual_list_of_len_0.__len__() == expected_list_of_len_0

    actual_list_of_len_1 = ImmutableList.of(1)
    expected_list_of_len_1 = 1
    assert actual_list_of_len_1.__len__() == expected_list_of_len_1

    actual_list_of_len_2 = ImmutableList.of(1, 2)
    expected_list_of_len_2 = 2
    assert actual_list_of_len_2.__len__() == expected_list_of_len_2

# Generated at 2022-06-24 00:11:52.394901
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    il = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert il.unshift(5).to_list() == [5, 1, 2, 3, 4]

# Generated at 2022-06-24 00:12:02.170248
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list1 = ImmutableList.of(1, 2, 5, 6, 7)
    list2 = ImmutableList.of(1, "asd", True, 22.3)
    list3 = ImmutableList.of(False, 5)
    list4 = ImmutableList.of(None)

    assert list1 == ImmutableList(1, ImmutableList(2, ImmutableList(5, ImmutableList(6, ImmutableList(7)))))
    assert list2 == ImmutableList(1, ImmutableList("asd", ImmutableList(True, ImmutableList(22.3))))
    assert list3 == ImmutableList(False, ImmutableList(5))
    assert list4 == ImmutableList(None)



# Generated at 2022-06-24 00:12:08.119407
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # empty
    assert ImmutableList().head is None
    assert ImmutableList().tail is None
    assert ImmutableList().is_empty is False

    # is_empty
    assert ImmutableList(is_empty=True).head is None
    assert ImmutableList(is_empty=True).tail is None
    assert ImmutableList(is_empty=True).is_empty is True

    # one element
    assert ImmutableList(33, None, is_empty=True).head is None
    assert ImmutableList(33, None, is_empty=True).tail is None
    assert ImmutableList(33, None, is_empty=True).is_empty is True

    # two elements
    assert ImmutableList(33, ImmutableList(44, None, is_empty=True)).head == 33

# Generated at 2022-06-24 00:12:11.952749
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    ls = ImmutableList.of(1, 2, 3, 4)
    lsf = ls.filter(lambda a: a % 2 == 0)

    assert lsf == ImmutableList.of(2, 4)

# Generated at 2022-06-24 00:12:18.660350
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty = ImmutableList.empty()
    assert empty.find(lambda x: True is False) is None

    test = ImmutableList.of(1)
    assert test.find(lambda x: x == 1) == 1
    assert test.find(lambda x: x == 2) is None

    test = ImmutableList.of(1, 2, 3, 4)
    assert test.find(lambda x: x == 3) == 3
    assert test.find(lambda x: x == 5) is None
    assert test.find(lambda x: x < 0) is None
    

# Generated at 2022-06-24 00:12:30.465657
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList().append(2) == ImmutableList(2, is_empty=False)
    assert ImmutableList().append(2).append(3) == ImmutableList(2, ImmutableList(3, is_empty=False))
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2, is_empty=False))
    assert ImmutableList().append(2).append(3) == ImmutableList(2, ImmutableList(3, is_empty=False))
    assert ImmutableList().append(2).append(3).append(4) == ImmutableList(2, ImmutableList(3, ImmutableList(4, is_empty=False)))

# Generated at 2022-06-24 00:12:34.293150
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3, 4, 5)
    b = a.filter(lambda x: x % 2 == 0)
    assert b.to_list() == [2, 4]
    a = ImmutableList.of(1)
    b = a.filter(lambda x: x == 2)
    assert b.is_empty

# Generated at 2022-06-24 00:12:39.783717
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x * 2).to_list() == [2, 4, 6, 8, 10]



# Generated at 2022-06-24 00:12:46.982459
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList.of(1).tail is None
    assert ImmutableList.of(1, 2).tail == ImmutableList.of(2)
    assert ImmutableList.empty() == ImmutableList(is_empty=True)

# Generated at 2022-06-24 00:12:52.745451
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(
        lambda x: True
    ) == ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(1, 2, 3).filter(
        lambda x: x > 2
    ) == ImmutableList.of(3)

    assert ImmutableList.of(1, 2, 3).filter(
        lambda x: x < 2
    ) == ImmutableList.of(1)

    assert ImmutableList.of(1, 2, 3).filter(
        lambda x: False
    ) == ImmutableList.empty()

    print('ImmutableList: Method filter was successfully tested')


# Generated at 2022-06-24 00:12:56.260442
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of('first', 'second', 'third')
    second_list = ImmutableList.empty().append('first').append('second').append('third')

    assert first_list.__add__(second_list) == ImmutableList.of('first', 'second', 'third', 'first', 'second', 'third')
    assert first_list.__add__(ImmutableList(1)) != ImmutableList.of('first', 'second', 'third', 'first', 'second', 'third')



# Generated at 2022-06-24 00:13:01.165237
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'


# Generated at 2022-06-24 00:13:06.905316
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList.of(1,2,3)
    l1 = l.filter(lambda x: x > 1)
    l2 = l1.filter(lambda x: x < 4)
    assert l2 == ImmutableList.of(2,3)

test_ImmutableList_filter()


# Generated at 2022-06-24 00:13:15.700074
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    seq = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert seq == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert seq != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert seq != ImmutableList(1, ImmutableList(2))
    assert seq != ImmutableList(1, ImmutableList(2), ImmutableList(3))
    assert seq != ImmutableList(1, ImmutableList(2), ImmutableList(3), ImmutableList(4))

# Generated at 2022-06-24 00:13:23.169609
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(2) == ImmutableList(2)
    assert ImmutableList(2, 3) == ImmutableList(2, 3)
    assert ImmutableList(1, 2).to_list() == [1, 2]
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-24 00:13:31.604841
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    list1 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    list2 = ImmutableList.of(1, 2, 3, 4)
    list3 = ImmutableList.of(2, 3, 4, 5)
    list4 = ImmutableList.of(1, 2, 3, 4)
    list5 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    list6 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    list7 = ImmutableList.of(15,25,35,45,55,65)
    # When
    result1 = list1.find(lambda item: item == 3)
    result2 = list2.find(lambda item: item == 1)
    result3 = list3.find

# Generated at 2022-06-24 00:13:35.910682
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 4) is None

test_ImmutableList_find()


# Generated at 2022-06-24 00:13:41.013597
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == "ImmutableList[1]"
    assert str(ImmutableList(1, ImmutableList(2))) == "ImmutableList[1, 2]"
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == "ImmutableList[1, 2, 3]"


# Generated at 2022-06-24 00:13:43.834893
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list = ImmutableList.of(1, 2, 3)

    assert str(list) == 'ImmutableList[1, 2, 3]'
#


# Generated at 2022-06-24 00:13:47.351003
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    xs = ImmutableList(0)
    ys = xs.append(1).append(2).append(3)
    assert ys.to_list() == [0, 1, 2, 3]


# Generated at 2022-06-24 00:13:56.308220
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) + ImmutableList.of() == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) + ImmutableList.of() == ImmutableList.of(1, 2)

# Generated at 2022-06-24 00:14:01.738990
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    array = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert array.map(lambda x: x * 2).to_list() == [2, 4, 6]
    assert array.map(lambda x: x).to_list() == array.to_list()
    assert array.map(lambda x: 0).to_list() == [0, 0, 0]

    array = ImmutableList()
    assert array.map(lambda x: x * 2).to_list() == []
    assert array.map(lambda x: x).to_list() == array.to_list()
    assert array.map(lambda x: 0).to_list() == []


# Generated at 2022-06-24 00:14:03.604959
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]

# Generated at 2022-06-24 00:14:14.889406
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList())))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList()

# Generated at 2022-06-24 00:14:20.027213
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.empty().unshift(0) == ImmutableList.of(0)

# Generated at 2022-06-24 00:14:28.589016
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of().reduce(lambda prev, next: ''.join([prev, next]), '') == ''
    assert ImmutableList.of('a').reduce(lambda prev, next: ''.join([prev, next]), '') == 'a'
    assert ImmutableList.of('a', 'b').reduce(lambda prev, next: ''.join([prev, next]), '') == 'ab'
    assert ImmutableList.of('a', 'b', 'c').reduce(lambda prev, next: ''.join([prev, next]), '') == 'abc'
    assert ImmutableList.of('a', 'b', 'c', 'd').reduce(lambda prev, next: ''.join([prev, next]), '') == 'abcd'
    assert ImmutableList.of(1, 2, 3, 4, 5).red

# Generated at 2022-06-24 00:14:31.415073
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:14:36.668923
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # result_1 = ImmutableList.of(1, 2, 1, 3, 2, 1).find(lambda a: a == 3)
    # assert result_1 == 3

    result_2 = ImmutableList.of(1, 2, 1, 3, 2, 1).find(lambda a: a == 3)
    assert result_2 == 3

    result_3 = ImmutableList.of(1, 2, 1, 3, 2, 1).find(lambda a: a == 4)
    assert result_3 is None


# Generated at 2022-06-24 00:14:42.658867
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'

test_ImmutableList___str__()

# Generated at 2022-06-24 00:14:51.489254
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None
    assert ImmutableList(is_empty=True).find(lambda x: x == 1) is None

test_ImmutableList_find()

# Generated at 2022-06-24 00:14:56.825759
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Arrange
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(4, 5, 6)
    expected = ImmutableList.of(1, 2, 3, 4, 5, 6)

    # Act
    result = list1 + list2

    # Assert
    assert expected == result

# Generated at 2022-06-24 00:15:04.715488
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(3).reduce(lambda a, b: a + b, 2) == 5
    assert ImmutableList.of(3).reduce(lambda a, b: a + b, 0) == 3
    assert ImmutableList.of().reduce(lambda a, b: a + b, 2) == 2

    simple_list = ImmutableList.of(1, 3, 5)

    assert simple_list.reduce(lambda a, b: a + b, 0) == 9
    assert simple_list.reduce(lambda a, b: a + b, 2) == 11


# Generated at 2022-06-24 00:15:11.751094
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # test for empty list
    il1 = ImmutableList()
    il2 = ImmutableList()

    assert ImmutableList.empty() == il1 + il2

    # test for a single element list
    il1 = ImmutableList(1)
    il2 = ImmutableList(2)

    assert ImmutableList.of(1, 2) == il1 + il2

    il1 = ImmutableList(1, ImmutableList(2), False)
    il2 = ImmutableList(3, ImmutableList(4), False)

    assert ImmutableList.of(1, 2, 3, 4) == il1 + il2


# Generated at 2022-06-24 00:15:17.596197
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of("foo") + ImmutableList.of("bar")

    assert a == ImmutableList.of("foo", "bar")
    assert a != ImmutableList.of("bar", "foo")


# Generated at 2022-06-24 00:15:22.091115
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1).to_list() == [1]
    assert ImmutableList(1).append(2).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2)).append(3).to_list() == [1, 2, 3]

# Generated at 2022-06-24 00:15:31.018166
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList(is_empty=True)
    assert ImmutableList(1).map(lambda x: x) == ImmutableList(1)
    assert ImmutableList(1).map(lambda x: x * 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x * 2) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(1).map(lambda x: str(x)) == ImmutableList("1")

# Generated at 2022-06-24 00:15:39.867344
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    numbers = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert numbers.find(lambda x: x == 1) == 1
    assert numbers.find(lambda x: x == 2) == 2
    assert numbers.find(lambda x: x == 3) == 3
    assert numbers.find(lambda x: x == 4) == 4
    assert numbers.find(lambda x: x == 5) == 5
    assert numbers.find(lambda x: x == 6) is None
    assert numbers.find(lambda x: x == 0) is None



# Generated at 2022-06-24 00:15:44.226451
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    lst = ImmutableList.of(1, 2, 3, 4)
    mapper = lambda x: x + 1

    # Act
    result = lst.map(mapper)

    # Assert
    assert result == ImmutableList.of(2, 3, 4, 5)


# Generated at 2022-06-24 00:15:46.202012
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3).reduce(lambda acc, x: acc + x, 0) == 6

# Generated at 2022-06-24 00:15:53.576581
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # assert that ImmutableList.find works correctly with
    #     - 1 element
    #     - 4 elements
    #     - 8 elements
    #     - no elements
    #     - filter returns all elements
    #     - filter returns no elements

    list_9 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    assert list_9.find(lambda x: x == 9) == 9

    assert list_9.find(lambda x: x > 5) == 6

    assert list_9.find(lambda x: x < 5) == 1

    assert list_9.find(lambda x: x == 10) is None

    assert ImmutableList.empty().find(lambda x: x == 10) is None



# Generated at 2022-06-24 00:15:56.654641
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x*2 > 3) == 2
    assert ImmutableList(is_empty=True).find(lambda x: x*2 > 3) is None


# Generated at 2022-06-24 00:15:59.288874
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # {1,2,3,4,5}
    _list = ImmutableList.of(1, 2, 3, 4, 5)

    assert _list.find(lambda x: True) == 1
    assert _list.find(lambda x: x == 2) == 2
    assert _list.find(lambda x: x == 6) is None



# Generated at 2022-06-24 00:16:02.644919
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    assert(len(list_) == 5)

    list_ = ImmutableList.of(5)
    assert(len(list_) == 1)

    list_ = ImmutableList.empty()
    assert(len(list_) == 0)


# Generated at 2022-06-24 00:16:10.597054
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # test if function raise exception when is add other type than ImmutableList
    with pytest.raises(ValueError):
        ImmutableList.of(1).__add__(0)

    # test if function returns the same objects if tail is None
    assert ImmutableList.of(1).__add__(ImmutableList.of(2)) == ImmutableList.of(1, 2)

    # test if function returns the same objects if tail is empty array
    assert ImmutableList.of(1, 2).__add__(ImmutableList.of(3, 4)).__eq__(ImmutableList.of(1, 2, 3, 4))


# Generated at 2022-06-24 00:16:14.774484
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():

    # Arrange
    items = ImmutableList.of(1, 2, 3, 4, 5)

    # Act
    result = str(items)

    # Assert
    assert result == 'ImmutableList[1, 2, 3, 4, 5]'



# Generated at 2022-06-24 00:16:19.019557
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1).filter(lambda x: x > 10) == ImmutableList(is_empty=True)
    assert ImmutableList(1).filter(lambda x: x < 10) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).filter(lambda x: x > 1) == ImmutableList(2, ImmutableList(3))


# Generated at 2022-06-24 00:16:24.582286
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Arrange
    xs = ImmutableList.of(3, 4, 5, 6)
    expected = xs.reduce(lambda x, y: x + y, 0)

    # Act
    result = 18

    # Assert
    assert expected == result

# Generated at 2022-06-24 00:16:29.092504
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    original = ImmutableList.of(1, 2, 3)
    result = original.unshift(0)

    assert result == ImmutableList.of(0, 1, 2, 3)
    assert result is not original



# Generated at 2022-06-24 00:16:36.950067
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3)
    assert isinstance(list_, ImmutableList)
    assert len(list_) == 3
    assert list_.to_list() == [1, 2, 3]

    filtered_list = list_.filter(lambda x: x > 2)
    assert isinstance(filtered_list, ImmutableList)
    assert len(filtered_list) == 1
    assert filtered_list.to_list() == [3]

    filtered_list = list_.filter(lambda x: x > 3)
    assert isinstance(filtered_list, ImmutableList)
    assert len(filtered_list) == 0
    assert filtered_list.to_list() == []



# Generated at 2022-06-24 00:16:45.423559
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) is 1
    assert ImmutableList.of(2, 3, 4).find(lambda x: x % 2 == 1) == 3

    assert ImmutableList.of(2, 4, 6).find(lambda x: x % 2 == 1) is None
    assert ImmutableList.of(2, 4, 6).find(lambda x: x <= 0) is None
    assert ImmutableList.of().find(lambda x: x <= 0) is None


# Generated at 2022-06-24 00:16:47.977609
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2) == ImmutableList.empty().unshift(1).unshift(2)
    assert ImmutableList.of(2, 3, 4) == ImmutableList.of(2, 3).unshift(4)

# Generated at 2022-06-24 00:16:52.499913
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(2, 5).unshift(1) == ImmutableList.of(1, 2, 5)
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
