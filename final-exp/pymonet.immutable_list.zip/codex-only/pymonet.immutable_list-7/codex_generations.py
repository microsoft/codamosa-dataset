

# Generated at 2022-06-24 00:07:04.042643
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 'a', 'b') == ImmutableList.of(1, 'a', 'b')
    assert not ImmutableList.of(1, 'a', 'b') == ImmutableList.of(1, 'a', '2')
    assert not ImmutableList.of(1, 'a', 'b') == ImmutableList.of(1, 'b', 'b')
    assert not ImmutableList.of(1, 'a', 'b') == ImmutableList.of(2, 'a', 'b')
    assert ImmutableList.empty() == ImmutableList.empty()
    assert not ImmutableList.empty() == ImmutableList.of(1)


# Generated at 2022-06-24 00:07:06.864720
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l1 = ImmutableList(1, ImmutableList(2))
    assert l1.append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-24 00:07:14.688761
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    from hypothesis import given
    from hypothesis.strategies import integers

    # Test for empty list
    assert (ImmutableList.empty() == ImmutableList.empty()) == True

    @given(head=integers(), tail=integers())
    def _(head, tail):
        assert ImmutableList(head, ImmutableList(tail)) == ImmutableList(head, ImmutableList(tail))

    @given(head=integers(), tail=integers())
    def _(head, tail):
        assert ImmutableList(head, ImmutableList(tail)) != ImmutableList(tail, ImmutableList(head))


# Generated at 2022-06-24 00:07:18.943147
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.empty() == ImmutableList(is_empty=True)


# Generated at 2022-06-24 00:07:22.918885
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList(
        "second",
        ImmutableList(
            "third",
            ImmutableList("fourth")
        )
    )
    actual = test_list.filter(lambda x: x == "second")
    expected = ImmutableList("second")
    assert expected == actual



# Generated at 2022-06-24 00:07:26.011838
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(10)) == 'ImmutableList{[10]}'
    assert str(ImmutableList(10).append(20)) == 'ImmutableList{[10, 20]}'



# Generated at 2022-06-24 00:07:36.060995
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1).filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)
    assert ImmutableList(2).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList(1, 3)
    assert ImmutableList(1, 2, 3, 4, 6).filter(lambda x: x % 2 == 1) == ImmutableList(1, 3)


# Generated at 2022-06-24 00:07:40.949813
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2)
    list2 = ImmutableList.of(1, 2)
    list3 = ImmutableList.of(1, 3)

    assert list1 == list2
    assert not list1 == list3
    assert not list2 == list3



# Generated at 2022-06-24 00:07:46.290926
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    # assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    # assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:07:49.471952
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # expect is a new list with incremented values
    expect = ImmutableList.of(1, 2, 3, 4)
    # actual is a new list with every value incremented in function
    actual = ImmutableList.of(0, 1, 2, 3).map(lambda x: x + 1)
    assert actual == expect, "ImmutableList not correctly mapped"
test_ImmutableList_map()

# Generated at 2022-06-24 00:07:56.516608
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Test case data
    head = 1
    tail = [2, 3]
    expected = [1, 2, 3]

    # Unit under test
    immutable_list = ImmutableList.of(head, *tail)

    assert immutable_list.head == head
    assert immutable_list.tail.head == tail[0]
    assert immutable_list.tail.tail.head == tail[1]
    assert immutable_list.tail.tail.tail is None
    assert immutable_list.to_list() == expected



# Generated at 2022-06-24 00:08:02.669520
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    nums = ImmutableList.of(1, 2, 3)
    nums_mapped_to_pows = nums.map(lambda x: x**2)

    assert nums_mapped_to_pows == ImmutableList.of(1, 4, 9)


# Generated at 2022-06-24 00:08:05.304026
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3
    

# Generated at 2022-06-24 00:08:11.761008
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

# Generated at 2022-06-24 00:08:14.816305
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    immutable_list = ImmutableList.of(1,2,3)
    assert immutable_list.reduce(lambda x, y: x + y, 0) == 6

# Generated at 2022-06-24 00:08:19.795314
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.of(1,2,3)
    new_list = list.unshift(0)

    assert new_list.head == 0
    assert new_list.tail == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert new_list.to_list() == list.to_list()

# Generated at 2022-06-24 00:08:24.451754
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.to_list() == [1, 2, 3]

    list_ = ImmutableList.of(1, 2, 3)
    assert list_.to_list() == [1, 2, 3]

    list_ = ImmutableList.empty()
    assert list_.to_list() == []



# Generated at 2022-06-24 00:08:31.684193
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    imm_list = ImmutableList.empty()
    element = 'foo'

    # When
    result = imm_list.find(lambda x: x == element)

    # Then
    assert result is None

    # Given
    imm_list = ImmutableList(element)

    # When
    result = imm_list.find(lambda x: x == element)

    # Then
    assert result == element

    # Given
    imm_list = ImmutableList('bar', ImmutableList(element))

    # When
    result = imm_list.find(lambda x: x == element)

    # Then
    assert result == element

# Generated at 2022-06-24 00:08:35.915517
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(2) == ImmutableList(2)
    assert ImmutableList(2) != ImmutableList(3)
    assert ImmutableList(2, ImmutableList(3), is_empty=False) == ImmutableList(2, ImmutableList(3), is_empty=False)



# Generated at 2022-06-24 00:08:47.134722
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).to_list() == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-24 00:08:50.379734
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    alist = ImmutableList.of(3).append(1).append(2)
    assert alist == ImmutableList(3, ImmutableList(1, ImmutableList(2)))


# Generated at 2022-06-24 00:08:58.549016
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    lists = (
        (ImmutableList.empty(), ImmutableList.empty()),
        (ImmutableList.empty(), ImmutableList(0)),
        (ImmutableList(0), ImmutableList.empty()),
        (ImmutableList(1, 2, 3), ImmutableList(4, 5, 6)),
    )

    for list1, list2 in lists:
        assert list1 + list2 == ImmutableList(
            *list1.to_list() + list2.to_list()
        )


# Generated at 2022-06-24 00:09:03.717937
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    numbers = ImmutableList.of(1, 2, 3, 4)
    assert numbers.find(lambda x: x == 3) == 3
    assert numbers.find(lambda x: x == 10) is None


# Generated at 2022-06-24 00:09:11.819549
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, -3, 5).filter( lambda x: x > 0 ) == ImmutableList.of(1, 5)
    assert ImmutableList.of(1, -3, 5).filter( lambda x: x > 1 ) == ImmutableList.of(5)
    assert ImmutableList.of(1, -3).filter( lambda x: x > 1 ) == ImmutableList.empty()
    assert ImmutableList.of(1, -3).filter( lambda x: x > -3 ) == ImmutableList.of(1)
    assert ImmutableList.of(1, -3).filter( lambda x: x < -3 ) == ImmutableList.empty()
# Test for method reduce of class ImmutableList

# Generated at 2022-06-24 00:09:13.930151
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1, ImmutableList(2), True) == ImmutableList.empty().append(1).append(2)



# Generated at 2022-06-24 00:09:18.505679
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    head = ImmutableList(1)
    tail = ImmutableList(2, ImmutableList(3))

    target = head+tail

    assert target.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:09:24.565478
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():  # pragma: no cover
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList('value')) == "ImmutableList['value']"
    assert str(ImmutableList.of('value', 'other', 'another')) == "ImmutableList['value', 'other', 'another']"
    assert str(ImmutableList('value', ImmutableList('other', ImmutableList('another')))) == "ImmutableList['value', 'other', 'another']"



# Generated at 2022-06-24 00:09:29.494723
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    import random

    for n in range(10):
        random_items = [
            random.randint(1, 1000) for _ in range(n)
        ]
        assert str(ImmutableList.of(*random_items)) == 'ImmutableList{}'.format(random_items)

    assert str(ImmutableList(is_empty=True)) == 'ImmutableList{}'


# Generated at 2022-06-24 00:09:38.129090
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, 2) == ImmutableList(1, 2)
    assert ImmutableList(1, 2, 3) == ImmutableList(1, 2, 3)
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList(1, 2, 3, 4) == ImmutableList(1, 2, 3, 4)
    assert ImmutableList(1, 2, 3, 4, 5) == ImmutableList(1, 2, 3, 4, 5)
    assert ImmutableList(1, 2, 3, 4, 5, 6) == ImmutableList(1, 2, 3, 4, 5, 6)

test_ImmutableList___eq__()

# Generated at 2022-06-24 00:09:39.947098
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]

# Generated at 2022-06-24 00:09:45.570176
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Test empty list
    assert str(ImmutableList.of()) == 'ImmutableList[]'
    # Test list with one element
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    # Test list with many elements
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
# Test case for method __eq__ of class ImmutableList

# Generated at 2022-06-24 00:09:51.621648
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    immutable_list = ImmutableList.of(1)
    immutable_list_two = ImmutableList.of(2, 3)
    immutable_list_single = ImmutableList.of(1, 2)

    assert immutable_list + immutable_list_two == immutable_list_single


# Generated at 2022-06-24 00:09:54.256950
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    example_list = ImmutableList(1).unshift(2).unshift(3).unshift(4)
    assert example_list == ImmutableList(4, ImmutableList(3, ImmutableList(2, ImmutableList(1))))


# Generated at 2022-06-24 00:10:04.687010
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty_list = ImmutableList.empty()
    empty_list2 = ImmutableList(is_empty=True)
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(1)
    list3 = ImmutableList.of(1, 2, 3)
    list4 = ImmutableList.of(1, 2, 3)
    list5 = ImmutableList.of(1, 2, 3, 4)
    list6 = ImmutableList.of(1, 2, 3, 4)

    print('Testing method ImmutableList.__eq__')
    assert empty_list == empty_list2
    assert list1 == list2
    assert list3 == list4
    assert list5 == list6

    assert empty_list != list1
    assert list1 != list3
    assert list3 != list

# Generated at 2022-06-24 00:10:11.408846
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    one_two_three = ImmutableList.of(1, 2, 3)
    assert one_two_three.find(lambda x: x == 1) == 1
    assert one_two_three.find(lambda x: x == 2) == 2
    assert one_two_three.find(lambda x: x == 3) == 3
    assert one_two_three.find(lambda x: x == 4) is None
    assert one_two_three.find(lambda x: x == 0) is None

test_ImmutableList_find()


# Generated at 2022-06-24 00:10:20.352448
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # test 1
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(
        lambda acc, x: acc + x,
        0
    ) == 15

    # test 2
    assert ImmutableList.empty().reduce(
        lambda acc, x: acc + x,
        0
    ) == 0

    # test 3
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(
        lambda acc, x: acc + x,
        10
    ) == 25

    # test 4
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(
        int.__mul__,
        1
    ) == 120

# Generated at 2022-06-24 00:10:23.845510
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_ = ImmutableList.of(1, 2, 3)
    result_list = list_.unshift(0)
    target_list = ImmutableList.of(0, 1, 2, 3)
    assert result_list == target_list


# Generated at 2022-06-24 00:10:32.429619
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).unshift(0) == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).unshift(0).unshift(-1) == ImmutableList(-1, ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3)))))
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3).unshift(0).unshift(-1) == Immutable

# Generated at 2022-06-24 00:10:43.728546
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # arrange
    ml1 = ImmutableList.of(0, 1, 2, 3, 4, 5)
    ml2 = ImmutableList.of(5, 4, 3, 2, 1)
    ml3 = ImmutableList.of(1, 1, 1, 1)
    # action
    mll1 = ml1.reduce(lambda acc, item: acc + item, 0)
    mll2 = ml2.reduce(lambda acc, item: acc + item, 0)
    mll3 = ml3.reduce(lambda acc, item: acc * item, 1)
    # assert
    assert mll1 == 15
    assert mll2 == 15
    assert mll3 == 1


if __name__ == '__main__':  # pragma: no cover
    test_ImmutableList_reduce()

# Generated at 2022-06-24 00:10:46.077861
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.empty() != ImmutableList.of(1, 2)

# Generated at 2022-06-24 00:10:50.981669
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    obj = ImmutableList.of(
        'some',
        'crazy',
        'stuff',
        'is',
        'here'
    )

    assert obj.find(lambda x: x == 'crazy') == 'crazy'
    assert obj.find(lambda x: x == 'not') == None



# Generated at 2022-06-24 00:11:02.631603
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    from unittest import TestCase
    from unittest.mock import Mock

    test_cases = [
        # test_case format: [ ImmutableList, expected_output ]
        [ ImmutableList(), 'ImmutableList[]' ],
        [ ImmutableList.of(1, 2, 3, 4), 'ImmutableList[1, 2, 3, 4]' ],
        [ ImmutableList(1), 'ImmutableList[1]' ],
        [ ImmutableList(None), 'ImmutableList[None]' ],
        [ ImmutableList(Mock()), 'ImmutableList[<Mock id="4351619264">]' ],
    ]

    for test_case in test_cases:
        output = Mock()
        test_case[0].__str__ = Mock(return_value=output)

# Generated at 2022-06-24 00:11:05.876504
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).to_list() 
    assert [1] == ImmutableList.of(1).to_list()
    assert ImmutableList.empty().to_list() == []

# Generated at 2022-06-24 00:11:13.960165
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Empty list
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty()

    # Single element list
    assert ImmutableList.of(1).map(lambda x: 'a'+str(x)) == ImmutableList.of('a1')

    # Some elements list
    assert ImmutableList.of(1,2,3).map(lambda x: x+1) == ImmutableList.of(2,3,4)


# Generated at 2022-06-24 00:11:22.197886
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (
        ImmutableList.empty() == ImmutableList.empty()
    )

    assert (
        ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    )

    assert (
        ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    )

    assert (
        ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 5)
    )

# Generated at 2022-06-24 00:11:33.471108
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1, ImmutableList()) == ImmutableList(1, ImmutableList())
    assert ImmutableList(1, ImmutableList(1, ImmutableList())) == ImmutableList(1, ImmutableList(1, ImmutableList()))
    assert ImmutableList(1, None) == ImmutableList(1, None)
    assert ImmutableList(1, ImmutableList(1, None)) == ImmutableList(1, ImmutableList(1, None))
    assert ImmutableList(1, ImmutableList(2, None)) == ImmutableList(1, ImmutableList(2, None))
    assert ImmutableList(1, ImmutableList(2, ImmutableList())) == ImmutableList(1, ImmutableList(2, ImmutableList()))
    assert Imm

# Generated at 2022-06-24 00:11:35.673033
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList[1, 2, 3]' == str(
        ImmutableList.of(1, 2, 3)
    )


# Generated at 2022-06-24 00:11:39.292745
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4)) == 'ImmutableList[1, 2, 3, 4]'

# Generated at 2022-06-24 00:11:41.674748
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:11:47.630602
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.empty().find(lambda x: x == 1) is None


# Generated at 2022-06-24 00:11:53.992299
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    empty = ImmutableList.empty()
    single = ImmutableList(1)
    multiple = ImmutableList.of(2, 3, 4)

    assert empty.unshift(1) == ImmutableList.of(1)
    assert single.unshift(1) == ImmutableList.of(1, 1)
    assert multiple.unshift(1) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:12:00.349633
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != "ImmutableList(1, 2, 3)"

# Generated at 2022-06-24 00:12:02.189052
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:12:08.561784
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1,2,3) + ImmutableList.of(4,5,6) == ImmutableList.of(1,2,3,4,5,6)
    assert ImmutableList.of(1,2,3) + ImmutableList.empty() == ImmutableList.of(1,2,3)
    assert ImmutableList.empty() + ImmutableList.of(1,2,3) == ImmutableList.of(1,2,3)
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()


# Generated at 2022-06-24 00:12:15.946118
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(5).append(5) == ImmutableList.of(5, 5)
    assert ImmutableList.of(1, 2, 3).append(5) == ImmutableList.of(1, 2, 3, 5)
    assert ImmutableList.of(1, 2, 3, 5) == ImmutableList.of(1, 2, 3).append(5)
    assert ImmutableList.of(1, 2, 3, 5) == ImmutableList.of(1, 2).append(3).append(5)


# Generated at 2022-06-24 00:12:19.284124
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    data = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert data.append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert data.append(4) != data


# Generated at 2022-06-24 00:12:30.633154
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1, ImmutableList(is_empty=True))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(is_empty=True)))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(is_empty=True))))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(is_empty=True)))) != ImmutableList(1, ImmutableList(2, ImmutableList(4, ImmutableList(is_empty=True))))
    assert ImmutableList(1,2,3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:12:34.495227
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList.of(1, 2, 3, 4)
    l2 = ImmutableList.of(1, 2, 3, 4)
    l3 = ImmutableList.of(1, 2, 3, 5)

    assert l1 == l1
    assert l1 == l2
    assert l1 != l3
    assert l2 != l3


# Generated at 2022-06-24 00:12:40.020911
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # test ImmutableList with no elements
    assert len(ImmutableList.empty()) == 0
    
    # test ImmutableList with one element
    assert len(ImmutableList.of(1)) == 1
    
    # test ImmutableList with two element
    assert len(ImmutableList.of(1, 2)) == 2
    
    # test ImmutableList with many elements
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)) == 9

# Generated at 2022-06-24 00:12:49.490043
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(10) == ImmutableList(10)
    assert ImmutableList(10, ImmutableList(20)) == ImmutableList(10, ImmutableList(20))
    assert ImmutableList(10, ImmutableList(20), is_empty=True) == ImmutableList(10, ImmutableList(20), is_empty=True)
    assert ImmutableList(10, ImmutableList(20, ImmutableList(30), is_empty=True), is_empty=True) == ImmutableList(10, ImmutableList(20, ImmutableList(30), is_empty=True), is_empty=True)
    assert ImmutableList().to_list() == []
    assert ImmutableList(10).to_list() == [10]

# Generated at 2022-06-24 00:12:57.369938
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(3, 2, 1)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != None


# Generated at 2022-06-24 00:13:00.893520
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of().append('head') == ImmutableList('head')
    assert ImmutableList.of('head').append('tail') == ImmutableList('head', ImmutableList('tail'))



# Generated at 2022-06-24 00:13:04.436783
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    numbers = ImmutableList.of(1, 2, 3, 4, 5)
    result = numbers.reduce(lambda acc, value: acc + value, 0)
    assert result == 15

# Generated at 2022-06-24 00:13:10.837662
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    items = [1, 2, 3, 4, 5, 6]
    immutable_list = ImmutableList.of(items[0], *items[1:])

    # When
    result = immutable_list.filter(lambda x: x > 3)

    # Then
    assert result == ImmutableList(4, ImmutableList(5, ImmutableList(6)))


# Generated at 2022-06-24 00:13:18.676826
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    immutable_list = ImmutableList.of(
        'Demo 1',
        'Demo 2',
        'Demo 3',
        'Demo 4',
        'Demo 5'
    )
    expected = ImmutableList.of(
        'Demo 2',
        'Demo 4'
    )

    # when
    actual = immutable_list.filter(lambda x: x.find('Demo') == 2)

    # then
    assert expected == actual

# Generated at 2022-06-24 00:13:25.698673
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    xs = ImmutableList.empty()
    ys = xs.unshift(1)
    assert ys.to_list() == [1]
    assert xs.to_list() == []

    xs = ImmutableList.of(1, 2, 3, 4)
    ys = xs.unshift(-1)
    assert ys.to_list() == [-1, 1, 2, 3, 4]
    assert xs.to_list() == [1, 2, 3, 4]

# Generated at 2022-06-24 00:13:32.673956
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # assert ImmutableList.of(42).to_list() == [42], 'ImmutableList.of(42).to_list() == [42]'
    assert ImmutableList.of(42, 13).to_list() == [42, 13], 'ImmutableList.of(42, 13).to_list() == [42, 13]'
    assert ImmutableList().to_list() == [], 'ImmutableList().to_list() == []'
    assert ImmutableList.of(42, 13).map(lambda x: x * 2).to_list() == [84, 26], 'ImmutableList.of(42, 13).map(lambda x: x * 2).to_list() == [84, 26]'

# Generated at 2022-06-24 00:13:39.168914
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    result = ImmutableList.of(1, 2, 3)
    assert str(result) == 'ImmutableList[1, 2, 3]'

    result = ImmutableList.of(1)
    assert str(result) == 'ImmutableList[1]'

    result = ImmutableList.of()
    assert str(result) == 'ImmutableList[]'



# Generated at 2022-06-24 00:13:43.686700
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    first_unshift = ImmutableList(1, ImmutableList(2), False).unshift(3)
    assert first_unshift.to_list() == [3, 1, 2], 'unshift of empty list'


# Generated at 2022-06-24 00:13:49.362198
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda element: element == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda element: element == 6) is None
    assert ImmutableList.of(5, 4, 3, 2, 1).find(lambda element: element % 2 == 0) == 4

# Generated at 2022-06-24 00:13:57.008983
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test that ImmutableList is equal to ImmutableList has the same elements
    expected_result = True
    actual_result = ImmutableList(1, ImmutableList(2, ImmutableList(3)))\
                        == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert expected_result == actual_result

    # Test that ImmutableList is not equal to ImmutableList has not the same elements
    expected_result = False
    actual_result = ImmutableList(1, ImmutableList(2, ImmutableList(3)))\
                        == ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert expected_result == actual_result


# Generated at 2022-06-24 00:14:01.528135
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    li = ImmutableList.of(1, 2, 3, 4, 5)
    assert li.to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList().to_list() == []

# Generated at 2022-06-24 00:14:03.804410
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:14:15.163487
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList().append(1) == ImmutableList.of(1)
    assert ImmutableList(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList().append('a') == ImmutableList.of('a')
    assert ImmutableList('a').append('b') == ImmutableList.of('a', 'b')
    assert ImmutableList('a', 'b').append('c') == ImmutableList.of('a', 'b', 'c')
    assert ImmutableList().append(['a']) == ImmutableList.of(['a'])

# Generated at 2022-06-24 00:14:18.647966
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
test_ImmutableList_filter()

# Generated at 2022-06-24 00:14:22.084540
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    actual_result = ImmutableList.of(1, 2, 3).append(4)
    expected_result = ImmutableList.of(1, 2, 3, 4)
    assert actual_result == expected_result

# Generated at 2022-06-24 00:14:27.082208
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    ilist = ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x*2)
    assert ilist.head == 2
    assert ilist.tail.head == 4
    assert ilist.tail.tail.head == 6
    assert ilist.tail.tail.tail.tail.tail.head == 10


# Generated at 2022-06-24 00:14:32.199371
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # you can use this function as a test case for `ImmutableList` class constructor
    # Please don't add other asserts to this function
    # your implementation should pass this test
    # you can write more test cases below
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-24 00:14:35.831895
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)


# Unit test of method to_list

# Generated at 2022-06-24 00:14:39.476578
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    empty = ImmutableList.empty()
    one_element = ImmutableList.of(5)
    few_elements = ImmutableList.of(1, 2, 3, 4)

    assert str(empty) == 'ImmutableList[]'
    assert str(one_element) == 'ImmutableList[5]'
    assert str(few_elements) == 'ImmutableList[1, 2, 3, 4]'


# Generated at 2022-06-24 00:14:49.032660
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    empty_mutable_list = ImmutableList()
    empty_mutable_list_none = ImmutableList(None, None, False)
    single_mutable_list = ImmutableList(1)
    multiple_mutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert empty_mutable_list == empty_mutable_list_none
    assert single_mutable_list == ImmutableList(1, None, False)
    assert multiple_mutable_list == ImmutableList(1, ImmutableList(2, ImmutableList(3, None, False)), False)
    print('ImmutableList constructor is ok')


# Generated at 2022-06-24 00:14:53.118736
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    def reduce_func(acc: int, element: int) -> int:
        return acc + element
    
    a = ImmutableList.of(1, 2, 3)
    b = a.reduce(reduce_func, 0)
    assert b == 6

# Generated at 2022-06-24 00:15:00.222299
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3), \
        "ImmutableList.__eq__(ImmutableList) failure"

    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2), \
        "ImmutableList.__eq__(ImmutableList) failure"

    assert ImmutableList.of(1, 2, 3) != None, \
        "ImmutableList.__eq__(None) failure"

# Generated at 2022-06-24 00:15:03.391799
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list1 = ImmutableList(1, 2)
    list2 = ImmutableList.of(1, 2, 2, 4)

    assert len(list1) == 2
    assert len(list2) == 4



# Generated at 2022-06-24 00:15:06.248706
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    actual = ImmutableList.of(1, 2, 3).append(4)
    expected = ImmutableList.of(1, 2, 3, 4)

    assert actual == expected


# Generated at 2022-06-24 00:15:09.233559
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .find(lambda x: x % 2 == 0) == 2


# Generated at 2022-06-24 00:15:13.426018
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    """
    Test for the unshift method of class ImmutableList
    """
    assert ImmutableList.of(1).unshift(2) == ImmutableList(2, ImmutableList(1, None))
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, None))))

# Generated at 2022-06-24 00:15:17.597910
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList(1, None).unshift(2).unshift(3)
    assert l.to_list() == [3, 2, 1]

test_ImmutableList_unshift()

# Generated at 2022-06-24 00:15:22.080389
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    data = ImmutableList.of(1, 2, 3)
    result = data.find(lambda x: x > 1)
    assert result == 2

    data = ImmutableList.of(1, 2, 3)
    result = data.find(lambda x: x > 3)
    assert result is None

# Generated at 2022-06-24 00:15:29.902627
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # x = ImmutableList(10, ImmutableList(20, ImmutableList(30)))
    # assert x == ImmutableList.of(1,2,3)
    assert ImmutableList.of(1,2,3) == ImmutableList.of(1,2,3)
    assert ImmutableList.of(1,2,3) + ImmutableList.of(4,5) == ImmutableList.of(1,2,3,4,5)



# Generated at 2022-06-24 00:15:30.855105
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    pass



# Generated at 2022-06-24 00:15:33.720671
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    expected = [1, 2, 3, 4, 5] # result
    actual = ImmutableList.of(1, 2, 3, 4, 5) #store the test results in a variable
    assert expected == actual.to_list() # compare expected to actual


test_ImmutableList()

# Generated at 2022-06-24 00:15:36.800955
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list = ImmutableList.of(1, 2, 3)
    assert immutable_list.unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:15:41.524114
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    expected = ImmutableList.of(1, 2, 4, 5, 7)
    list_to_test = ImmutableList.of(1, 2, 4, 5, 7)
    assert expected == list_to_test


# Generated at 2022-06-24 00:15:45.457258
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(3, 2, 1).to_list() == [3, 2, 1]
    assert ImmutableList.of('a', 'b', 'c').to_list() == ['a', 'b', 'c']

# Generated at 2022-06-24 00:15:48.535730
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    data = ['a', 'b', 'c', 'd']

    list_origin = ImmutableList.of(data[0], *data[1:])
    list_upper = ImmutableList.of(*map(lambda x: x.upper(), data))

    list_map = list_origin.map(lambda x: x.upper())

    assert list_map == list_upper


# Generated at 2022-06-24 00:15:53.109528
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5)


# Generated at 2022-06-24 00:15:59.800404
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list0 = ImmutableList.of(2, 3, 4)
    assert list0.find(lambda x: x == 4) == 4
    assert list0.find(lambda x: x == 2) == 2
    assert list0.find(lambda x: x == 8) is None

    list1 = ImmutableList.empty()
    assert list1.find(lambda x: x == 4) is None

    list2 = ImmutableList.of(None, 4, 5)
    assert list2.find(lambda x: x == 4) is None
test_ImmutableList_find()

# Generated at 2022-06-24 00:16:01.514566
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) == ImmutableList.of(1) + ImmutableList.of(2)


# Generated at 2022-06-24 00:16:07.254560
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]

    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3, 4, 5) == ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: True)

# Generated at 2022-06-24 00:16:11.320929
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Arrange/Act
    list1 = ImmutableList.of(1, 2, 3)
    list2 = list1.append(4)

    # Assert
    assert list1 == ImmutableList.of(1, 2, 3)
    assert list2 == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-24 00:16:16.981038
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda n: n > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda n: n > 9) == None
    assert ImmutableList.of(1, 2, 3).find(lambda n: n == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda n: n > 0) == 1


# Generated at 2022-06-24 00:16:23.598875
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x > 1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).filter(lambda x: x % 2 == 0).filter(lambda x: x > 1) == ImmutableList(4)

# Generated at 2022-06-24 00:16:30.503891
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_a = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_a.to_list() == [1, 2, 3, 4, 5]
    assert isinstance(list_a, ImmutableList)

    list_b = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert list_b.to_list() == [1, 2, 3, 4, 5]
    assert isinstance(list_b, ImmutableList)

# Generated at 2022-06-24 00:16:32.650175
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.of(1, 2, 3, 4, 5).__str__() == 'ImmutableList[1, 2, 3, 4, 5]'


# Generated at 2022-06-24 00:16:34.018115
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList([1, 2]).append(3) == ImmutableList([1, 2, 3])

# Generated at 2022-06-24 00:16:37.656868
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert ImmutableList.empty().__len__() == 0
    assert ImmutableList.of(1, 2, 3).__len__() == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__len__() == 3


# Generated at 2022-06-24 00:16:45.348143
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    """
    Method returns list with ImmutableList elements

    :returns: list
    """
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(True).to_list() == [True]
    assert ImmutableList.empty().to_list() == []

    

# Generated at 2022-06-24 00:16:53.289185
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # arrange
    new_list = ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))
    assert new_list == ImmutableList.of(4, 5)
    # act
    new_list = new_list.unshift(3)
    # assert
    assert new_list == ImmutableList.of(3, 4, 5)
    assert ImmutableList(1).unshift(2) == ImmutableList(2, ImmutableList(1))