

# Generated at 2022-06-24 00:07:00.919349
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert str(ImmutableList.of('a', 'b', 'c').unshift('d')) == 'ImmutableList[\'d\', \'a\', \'b\', \'c\']'


# Generated at 2022-06-24 00:07:03.204420
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(head=4) == ImmutableList(4)

# Generated at 2022-06-24 00:07:08.433249
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_data = ImmutableList.of(1, 2, 3, 4, 5)
    # if we change filter or map method, new tests will broke
    assert test_data.find(lambda x: x > 1) == 2
    assert test_data.find(lambda x: x > 1) != 1
    assert test_data.find(lambda x: x > 10) == None
    assert test_data.find(lambda x: x > 10) != 1


# Generated at 2022-06-24 00:07:11.404211
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.of(1).__str__() == 'ImmutableList[1]'
    assert ImmutableList.of(1, 2).__str__() == 'ImmutableList[1, 2]'


# Generated at 2022-06-24 00:07:14.576264
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Given
    list = ImmutableList.of(1, 2, 3)

    # When
    list = list.unshift(0)

    # Then
    assert list == ImmutableList.of(0, 1, 2, 3)



# Generated at 2022-06-24 00:07:18.392286
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    list = list.filter(lambda x: x >= 4)
    assert list == ImmutableList(4, ImmutableList(5))

# Generated at 2022-06-24 00:07:22.743803
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-24 00:07:26.996781
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    lst1 = ImmutableList.of(1, 2, 3)
    lst2 = ImmutableList.of(4, 5)
    assert lst1.__add__(lst2) == ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:07:28.677503
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert str(ImmutableList.of(1).unshift(0)) == 'ImmutableList[0, 1]'


# Generated at 2022-06-24 00:07:36.608507
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3, 2)
    assert ImmutableList.empty() == ImmutableList.empty()


# Generated at 2022-06-24 00:07:40.729400
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    il = ImmutableList(1)

    assert isinstance(il, ImmutableList)
    assert il.head == 1
    assert il.tail is None
    assert il.is_empty is False


# Generated at 2022-06-24 00:07:44.144924
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list = ImmutableList.of(1,2,3)
    assert list.append(4).to_list() == [1,2,3,4]
    assert list.to_list() == [1,2,3]

# Generated at 2022-06-24 00:07:48.909180
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():

    my_list = ImmutableList.empty().append(1)
    assert my_list == ImmutableList(1)
    my_list = ImmutableList.empty().append(1).append(2)
    assert my_list == ImmutableList(1, ImmutableList(2))
    my_list = ImmutableList.empty().append(1).append(2).append(3)
    assert my_list == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:07:52.977365
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of()) == 0
    assert len(ImmutableList.of(3)) == 1
    assert len(ImmutableList.of(3, 'a')) == 2
    assert len(ImmutableList.of(3, 'a', True)) == 3


# Generated at 2022-06-24 00:07:55.854483
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    A = ImmutableList.of(1, 2, 3)
    B = A.append(4)

    assert B == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:07:58.080327
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_foo = ImmutableList.of(1, 2, 3)
    expected = [1, 2, 3]

    assert list_foo.to_list() == expected

# Generated at 2022-06-24 00:08:06.029694
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    alist = ImmutableList.of(1, 2, 3, 4)
    alist2 = ImmutableList.of(4, 5, 6, 7)

    assert alist.find(lambda x: x == 3) == 3
    assert alist.find(lambda x: x > 3) == 4
    assert alist2.find(lambda x: x == 4) == 4
    assert alist.find(lambda x: x < 3) == 1


# Generated at 2022-06-24 00:08:13.614083
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList([1, 2, 3]).unshift(4) == ImmutableList([4, 1, 2, 3])
    assert ImmutableList([1, 2, 3]).unshift([4, 5, 6]) == ImmutableList([[4, 5, 6], 1, 2, 3])
    assert ImmutableList([1, 2, 3]).unshift(ImmutableList([[4, 5, 6], 1, 2, 3])) == ImmutableList([[4, 5, 6], 1, 2, 3, 1, 2, 3])
    assert ImmutableList([1, 2, 3]).unshift(13) == ImmutableList([13, 1, 2, 3])

# Generated at 2022-06-24 00:08:21.420604
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    cases = [
        # data, expected, fn
        (([1,2,3,4,5], [2,4], lambda x: x % 2 == 0)),
        (([1,2,3,4,5], [5], lambda x: x == 5)),
        (([1,2,3,4,5], [], lambda x: x == 6)),
    ]

    for args, expected, fn in cases:
        actual = ImmutableList.of(*args[0]).filter(fn).to_list()
        assert actual == expected



# Generated at 2022-06-24 00:08:28.720000
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(is_empty=True) == ImmutableList()
    assert ImmutableList(is_empty=True) != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(is_empty=True)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(2) != ImmutableList(1)


# Generated at 2022-06-24 00:08:30.252745
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of('foo')) == 'ImmutableList[foo]'



# Generated at 2022-06-24 00:08:36.528879
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:08:42.626018
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Arrange
    expected = ImmutableList.of(1, 2, 3, 4, 5)
    actual = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    # Act
    # Assert
    assert expected == actual



# Generated at 2022-06-24 00:08:51.328395
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3,4,5,6,7,8,9).filter(lambda x: x < 4) == ImmutableList.of(1,2,3)
    assert ImmutableList.of(4,5,6,7,8,9).filter(lambda x: x < 4) == ImmutableList(is_empty=True)
    assert ImmutableList.of(1,2,3).filter(lambda x: x < 4) == ImmutableList.of(1,2,3)
    assert ImmutableList.of(1,2,3,4,5,6,7,8,9).filter(lambda x: True) == ImmutableList.of(1,2,3,4,5,6,7,8,9)

# Generated at 2022-06-24 00:08:55.998403
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)
    assert ImmutableList(1).unshift(4) == ImmutableList(4, 1)


# Generated at 2022-06-24 00:08:59.711936
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList.of(1, 2, 3)
    list_2 = ImmutableList.of(4, 5, 6)
    assert (list_1 + list_2) == ImmutableList.of(1, 2, 3, 4, 5, 6, )


# Generated at 2022-06-24 00:09:05.289816
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    searched_value = 5
    expected_return_value = searched_value

    # When
    result = ImmutableList.of(1, 2, 3, 4, searched_value, 6, 7) \
        .find(lambda value: value == searched_value)

    # Then
    assert expected_return_value == result


# Generated at 2022-06-24 00:09:07.454342
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList.of(2).unshift(1) == ImmutableList(1, 2)
    assert ImmutableList.of(3, 1).unshift(1) == ImmutableList(1, 3, 1)

# Generated at 2022-06-24 00:09:15.826535
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(3, 4, 5).find(lambda x: x == 4) == 4
    assert ImmutableList.of(3, 4, 5).find(lambda x: x == 2) is None
    assert ImmutableList.of(3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(3).find(lambda x: x == 2) is None
    assert ImmutableList.of().find(lambda x: x == 2) is None


# Generated at 2022-06-24 00:09:21.744746
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).append(4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1).append(3).append(2).to_list() == [1, 3, 2]



# Generated at 2022-06-24 00:09:28.828877
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(None, ImmutableList.empty()) == ImmutableList(None)
    assert ImmutableList(1, ImmutableList.empty()) == ImmutableList(1)
    assert ImmutableList(1, 2, 3) == ImmutableList(1, 2, 3)

    assert ImmutableList.empty() != ImmutableList(2)
    assert ImmutableList(None, ImmutableList.empty()) != ImmutableList.empty()
    assert ImmutableList(1, ImmutableList.empty()) != ImmutableList(2, ImmutableList.empty())
    assert ImmutableList(1, 2, 3) != ImmutableList(7, 2, 3)


# Generated at 2022-06-24 00:09:32.411225
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.empty().to_list() == []



# Generated at 2022-06-24 00:09:35.263519
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    actual = ImmutableList.of(1, 2, 3)
    expected = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert actual == expected



# Generated at 2022-06-24 00:09:37.465469
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4)\
        .reduce(lambda acc, item: acc + item, 0) == 10


# Generated at 2022-06-24 00:09:39.052500
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():  # pragma: no cover
    assert str(ImmutableList()) == 'ImmutableList{}'



# Generated at 2022-06-24 00:09:40.913139
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:09:51.745305
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3).reduce(lambda a, b: a * b, 1) == 6 
    assert ImmutableList.of(3,3,3).reduce(lambda a, b: a * b, 1) == 27
    assert ImmutableList.of(10,20,30).reduce(lambda a, b: a + b, 0) == 60
    assert ImmutableList.of(1,1,1,1).reduce(lambda a, b: a + b, 0) == 4
    assert ImmutableList.of(1,2,3).reduce(lambda a, b: a + b, 2) == 8 
test_ImmutableList_reduce()

# Generated at 2022-06-24 00:09:59.696452
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x > 0) == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 0) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 1) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 3) == None

# Generated at 2022-06-24 00:10:03.271927
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    element_to_find = 1
    elements = [2, 3, 4]
    # When
    result = ImmutableList.of(*elements).find(lambda x: x == element_to_find)
    # Then
    assert result is None, 'Method find of ImmutableList class found element that shouldn\'t be found'



# Generated at 2022-06-24 00:10:09.177944
# Unit test for constructor of class ImmutableList
def test_ImmutableList():

    assert str(ImmutableList.of(1, 2, 3, 4)) == 'ImmutableList[1, 2, 3, 4]'

    assert str(ImmutableList.of(0)) == 'ImmutableList[0]'

    assert str(ImmutableList.empty()) == 'ImmutableList[]'

# Generated at 2022-06-24 00:10:12.016863
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert list_.reduce(lambda a, b: a + b, 0) == 28

# Generated at 2022-06-24 00:10:17.176910
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    maybe = ImmutableList.of(1,2,3)
    assert maybe.filter(lambda x: True) == ImmutableList.of(1,2,3)
    assert maybe.filter(lambda x: x > 2) == ImmutableList.of(3)
    assert maybe.filter(lambda x: False) == ImmutableList.empty()


# Generated at 2022-06-24 00:10:26.398632
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    test_list_a = ImmutableList.of(1, 2, 3)
    test_list_b = ImmutableList.of(1, 2, None)
    test_list_c = ImmutableList.empty()
    test_list_d = ImmutableList.of(None)

    assert test_list_a.to_list() == [1, 2, 3], "test_list_a is incorrect"
    assert test_list_b.to_list() == [1, 2, None], "test_list_b is incorrect"
    assert test_list_c.to_list() == [], "test_list_c is incorrect"
    assert test_list_d.to_list() == [None], "test_list_d is incorrect"


# Generated at 2022-06-24 00:10:32.204872
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_one = ImmutableList.of(1,2,3)
    list_two = ImmutableList.of(4,5,6,7,8)
    assert list_one + list_two == ImmutableList.of(1,2,3,4,5,6,7,8)


# Generated at 2022-06-24 00:10:38.121787
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3


# Generated at 2022-06-24 00:10:45.256483
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2), True) == ImmutableList(1, ImmutableList(2), True)
    assert ImmutableList(1, ImmutableList(2), True) == ImmutableList.of(1, 2)
    assert ImmutableList(1, ImmutableList(2), True) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList.of(1, 2)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(is_empty=True) == ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList(is_empty=True)


# Generated at 2022-06-24 00:10:47.681169
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList(3).unshift(2) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList(3).unshift(2).unshift(1) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:10:52.442986
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc + x, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc + x, 1) == 7
    assert ImmutableList.of(1).reduce(lambda acc, x: acc + x, 0) == 1
    assert ImmutableList.of(1).reduce(lambda acc, x: acc + x, 1) == 2
    assert ImmutableList.empty().reduce(lambda acc, x: acc + x, 0) == 0
    assert ImmutableList.empty().reduce(lambda acc, x: acc + x, 1) == 1

# Generated at 2022-06-24 00:10:57.144463
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.empty().find(lambda x: x == 2) is None



# Generated at 2022-06-24 00:11:02.474082
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ml = ImmutableList.of(1, 2, 3, 4)
    assert ml.find(lambda x: x == 2) == 2
    assert ml.find(lambda x: x == 3) == 3
    assert ml.find(lambda x: x == 5) is None



# Generated at 2022-06-24 00:11:04.903548
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    value = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert str(value) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:11:08.565656
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    elements = [1, 2, 3, None]
    list_1 = ImmutableList.of(*elements)
    list_2 = ImmutableList.of(*elements)

    assert list_1 == list_2


# Generated at 2022-06-24 00:11:15.917171
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    fn = lambda x: x + 1
    assert ImmutableList(1)\
        .map(fn)\
        .to_list() == [2]
    assert ImmutableList(1, ImmutableList(2))\
        .map(fn)\
        .to_list() == [2, 3]
    assert ImmutableList(2, ImmutableList(1, ImmutableList(3)))\
        .map(fn)\
        .to_list() == [3, 2, 4]

# Generated at 2022-06-24 00:11:26.122078
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x < 2) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 3) is None
    assert ImmutableList.of(1, 2, 3, 1).find(lambda x: x < 2) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3).find

# Generated at 2022-06-24 00:11:30.631883
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_one = ImmutableList.of(1, 2, 3, 4)
    assert list_one.find(lambda x: x == 1) == 1
    assert list_one.find(lambda x: x == 2) == 2
    assert list_one.find(lambda x: x == 5) == None


# Generated at 2022-06-24 00:11:35.247251
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList(1, ImmutableList(1))) # 1 -> 1 -> 1 -> null
    list2 = ImmutableList(1, ImmutableList(1, ImmutableList(1))) # 1 -> 1 -> 1 -> null
    assert list1 == list2



# Generated at 2022-06-24 00:11:42.967228
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)



# Generated at 2022-06-24 00:11:54.941436
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3).append(4)) == 4
    assert len(ImmutableList.of(1, 2, 3).unshift(0)) == 4
    assert len(ImmutableList.of(1, 2, 3).map(lambda x: x)) == 3
    assert len(ImmutableList.of(1, 2, 3).filter(lambda x: True)) == 3
    assert len(ImmutableList.of(1, 2, 3).filter(lambda x: False)) == 0
    assert len(ImmutableList.of(1, 2, 3).find(lambda x: x == 2)) == 3
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-24 00:12:03.011396
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty()
    assert ImmutableList.of(1).map(lambda x: x) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).map(lambda x: x) == ImmutableList.of(1, 2)

    assert ImmutableList.empty().map(lambda x: x + 1) == ImmutableList.empty()
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).map(lambda x: x + 1) == ImmutableList.of(2, 3)

# Generated at 2022-06-24 00:12:08.881427
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    sample = ImmutableList.of(1, 2, 3, 4)
    expected1 = [1, 2, 3, 4]
    actual1 = sample.to_list()

    assert expected1 == actual1

    sample = sample.unshift(0)
    expected2 = [0, 1, 2, 3, 4]
    actual2 = sample.to_list()

    assert expected2 == actual2

    sample = ImmutableList.of(1)
    expected3 = [1]
    actual3 = sample.to_list()

    assert expected3 == actual3

# Generated at 2022-06-24 00:12:13.756023
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(4, 5, 6)
    list3 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert list1.__add__(list2) == list3



# Generated at 2022-06-24 00:12:16.151221
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:12:21.945964
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(4, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-24 00:12:26.552303
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    to_filter = ImmutableList(2, ImmutableList(4, ImmutableList(6)))

    filtered = to_filter.filter(lambda x: x > 3)

    assert filtered == ImmutableList(4, ImmutableList(6))

# Generated at 2022-06-24 00:12:33.439821
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 'a') == None
    assert ImmutableList.of('a').find(lambda x: x == 'a') == 'a'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'b') == 'b'
    assert ImmutableList.of('a', 'b', 'c').find(lambda x: x == 'd') == None


# Generated at 2022-06-24 00:12:39.077991
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4, 5)
    assert il.filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert il.filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]
    assert il.filter(lambda x: x % 3 == 0).to_list() == [3]
    assert il.filter(lambda x: x % 6 == 0).to_list() == []


# Generated at 2022-06-24 00:12:48.299610
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_ = ImmutableList()
    assert len(list_) == 0
    list_ = ImmutableList(1)
    assert len(list_) == 1
    list_ = ImmutableList(1, ImmutableList(2))
    assert len(list_) == 2
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert len(list_) == 3
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert len(list_) == 4
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert len(list_) == 5

# Generated at 2022-06-24 00:12:59.552417
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda a, x: a+x, 0) == 15
    assert ImmutableList.empty().reduce(lambda a, x: a+x, 0) == 0
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda a, x: a*x, 1) == 120
    assert ImmutableList.of(2, 3, 4, 5).reduce(lambda a, x: a*x, 1) == 120
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda a, x: a*x, 2) == 240
test_ImmutableList_reduce()


# Generated at 2022-06-24 00:13:05.340380
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda accumulator, value: accumulator + value, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda accumulator, value: accumulator + value, 10) == 16
    assert ImmutableList.empty().reduce(lambda accumulator, value: accumulator + value, 10) == 10

# Generated at 2022-06-24 00:13:09.226721
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    actual = str(ImmutableList.of(1, 2, 3, 4, 5))
    expected = 'ImmutableList[1, 2, 3, 4, 5]'
    assert actual == expected


# Generated at 2022-06-24 00:13:14.670165
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_of_numbers = ImmutableList.of(1, 2, 3, 4)
    expected = 10
    reduced = list_of_numbers.reduce(lambda x, y: x + y, 0)
    if reduced != expected:
        assert False, \
            f'expected the value {expected} but got {reduced}' 
    assert True
    

# Generated at 2022-06-24 00:13:18.865187
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """ Test ImmutableList.filter() method """
    a = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    def fn(x):
        return x % 2 == 0

    assert a.filter(fn) == ImmutableList.of(2, 4, 6, 8, 10)

# Generated at 2022-06-24 00:13:23.179284
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():  # pragma: no cover
    assert ImmutableList.of(1) + ImmutableList.of(2, 3, 4) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-24 00:13:23.908246
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:13:30.845911
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_items = [
        ImmutableList(1, ImmutableList(2, ImmutableList(3))),
        ImmutableList(4, ImmutableList(5, ImmutableList(6))),
        ImmutableList(7, ImmutableList(8, ImmutableList(9)))
    ]

    check_value = test_items[0].find(lambda x: x%2 == 0)
    assert check_value == 2

    check_value = test_items[1].find(lambda x: x%2 == 0)
    assert check_value == 4

    check_value = test_items[2].find(lambda x: x%2 == 0)
    assert check_value == 8


# Generated at 2022-06-24 00:13:38.016392
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # should return sum of elements
    def reducer(acc, element):
        return acc + element

    assert ImmutableList.of(10, 20, 30).reduce(reducer, 0) == 60
    assert ImmutableList.empty().reduce(reducer, 0) == 0
    assert ImmutableList.of(10).reduce(reducer, 0) == 10
    assert ImmutableList.of(10).reduce(reducer, 10) == 20
    assert ImmutableList.of(10).reduce(reducer, 40) == 50


# Generated at 2022-06-24 00:13:41.157865
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda acc, el: acc + el, 0) == 10

# Generated at 2022-06-24 00:13:44.186721
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_ = ImmutableList.of(1, 2, 3)
    assert str(list_) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:13:48.025249
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    test_list = ImmutableList.of(1, 2, 3, 4)
    unshifted_list = test_list.unshift(1)
    assert unshifted_list == ImmutableList.of(1, 1, 2, 3, 4)



# Generated at 2022-06-24 00:13:53.069899
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2).__eq__(ImmutableList.of(1, 2)) is True
    assert ImmutableList.of(1, 2).__eq__([1, 2]) is False
    assert ImmutableList.empty().__eq__(ImmutableList.empty()) is True
    assert ImmutableList.empty().__eq__(ImmutableList.of(1)) is False


# Generated at 2022-06-24 00:13:57.318463
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    immutableList = ImmutableList.of(1, 2, 3, 4, 5)
    result = immutableList.reduce((lambda a, b: a + b), 0)
    assert result == 15

# Generated at 2022-06-24 00:14:06.265375
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_ = ImmutableList.empty()
    unshifted = list_.unshift(4)

    assert unshifted.head == 4
    assert unshifted.tail is None
    assert len(unshifted) == 1

    list_ = ImmutableList.empty()
    unshifted = list_.unshift(4).unshift(3).unshift(2).unshift(1)

    assert unshifted.head == 1
    assert unshifted.tail.head == 2
    assert unshifted.tail.tail.tail.tail is None
    assert len(unshifted) == 4


# Generated at 2022-06-24 00:14:11.098508
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList.of(1,2)
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3, ImmutableList(4)) == ImmutableList.of(1,2,3,4)

# Generated at 2022-06-24 00:14:16.197560
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    xs = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert xs.reduce(lambda x, y: x + y, 0) == 6

test_ImmutableList_reduce()

# Generated at 2022-06-24 00:14:23.443844
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_: ImmutableList[float] = ImmutableList(1.11, ImmutableList(2.22, ImmutableList(3.33)))
    other_list: ImmutableList[float] = ImmutableList(10.1, ImmutableList(20.2))
    expected_list = ImmutableList(1.11, ImmutableList(2.22, ImmutableList(3.33, ImmutableList(10.1, ImmutableList(20.2)))))
    assert list_ + other_list == expected_list


# Generated at 2022-06-24 00:14:26.660838
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-24 00:14:28.818168
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-24 00:14:32.648793
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    source_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    mapped_list = source_list.map(lambda x: x ** 2)

    assert mapped_list == ImmutableList(1, ImmutableList(4, ImmutableList(9)))


# Generated at 2022-06-24 00:14:39.651561
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():

    # Cases for filter method
    @contextmanager
    def test_cases():
        yield ImmutableList.of(1, 3, 5, 7).filter(lambda x: x > 4), ImmutableList.of(5, 7)
        yield ImmutableList.of(1, 1, 1).filter(lambda x: x > 0), ImmutableList.of(1, 1, 1)
        yield ImmutableList.of().filter(lambda x: x > 0), ImmutableList.of()
        yield ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 0), ImmutableList.empty()

    # Test all cases
    for case in test_cases():
        assert_equals = case[0], case[1]

# Run all unit test
test_ImmutableList_filter()

# Generated at 2022-06-24 00:14:45.976348
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:14:49.811260
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    il1 = ImmutableList.of(1, 2, 3, 4)

    assert il1.map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5)
    assert il1.map(lambda x: x * 2) == ImmutableList.of(2, 4, 6, 8)


# Generated at 2022-06-24 00:14:59.800464
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    test_case = [
        [
            'Test case 1: Unshift of empty list',
            ImmutableList.empty(),
            42,
            ImmutableList(42),
        ],
        [
            'Test case 2: Unshift of empty list',
            ImmutableList(1, ImmutableList(2, ImmutableList(3))),
            5,
            ImmutableList(5, ImmutableList(1, ImmutableList(2, ImmutableList(3)))),
        ]
    ]
    print('Testing method unshift of class ImmutableList')
    for case in test_case:
        print('\tCase: ', case[0])
        assert case[1].unshift(case[2]) == case[3]


# Generated at 2022-06-24 00:15:07.870475
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    function = lambda x: x + 1

    assert ImmutableList.of(0).map(function).to_list() == [1]
    assert ImmutableList.of(0, 1).map(function).to_list() == [1, 2]
    assert ImmutableList.of(0, 1, 2, 3, 4).map(function).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(0, 1, 2, 3, 4).map(function).map(function).to_list() == [2, 3, 4, 5, 6]
    assert ImmutableList.empty().map(function).to_list() == []

# Generated at 2022-06-24 00:15:10.450775
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.empty().filter(lambda x: x > 1) == ImmutableList.empty()

# Generated at 2022-06-24 00:15:12.091145
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1,2, 3, 4).map(lambda x: x*2).to_list() == [2, 4, 6, 8]


# Generated at 2022-06-24 00:15:16.847665
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert(immutable_list.reduce(lambda acc, current: acc + current, 0) == 15)


# Generated at 2022-06-24 00:15:22.144975
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l1 = ImmutableList.empty()
    l2 = ImmutableList.of(1, 2, 3, 4, 5)
    l3 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    even1 = l2.filter(lambda x: x % 2 == 0)
    even2 = l3.filter(lambda x: x % 2 == 0)

    assert l1 == ImmutableList.empty()
    assert l2 == ImmutableList.of(1, 2, 3, 4, 5)
    assert l3 == ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert even1 == ImmutableList.of(2, 4)
    assert even2 == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-24 00:15:26.591265
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    new_list = list_.append(4)
    assert new_list == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-24 00:15:31.910104
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(2) == ImmutableList(2)
    
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    


# Generated at 2022-06-24 00:15:33.725038
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:15:36.569912
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():

    il = ImmutableList.of(1, 2, 3, 4, 5)

    res = il.reduce(lambda acc, el: acc + el, 0)

    assert res == 15

# Generated at 2022-06-24 00:15:41.484899
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3)

    result = list_.to_list()

    assert result == [1, 2, 3]


# Generated at 2022-06-24 00:15:44.689022
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    data = ImmutableList.of(1, 2, 3, 4, 5, 6)
    mapped = data.filter(lambda x: x > 2)

    assert ImmutableList.of(3, 4, 5, 6) == mapped


# Generated at 2022-06-24 00:15:48.320496
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2), ImmutableList(3))) == 3
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3


# Generated at 2022-06-24 00:15:55.558310
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.of(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))



# Generated at 2022-06-24 00:16:02.789175
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList().is_empty is True
    assert str(ImmutableList(5)) == "ImmutableList[5]"
    assert ImmutableList(5) == ImmutableList(5)
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList.of(5) == ImmutableList(5)
    assert ImmutableList.of(5).is_empty is False
    assert ImmutableList.of(5, 6) == ImmutableList(5, ImmutableList(6))
    assert ImmutableList.of(5, 6, 5, 4) == ImmutableList(5, ImmutableList(6, ImmutableList(5, ImmutableList(4))))


# Generated at 2022-06-24 00:16:07.590670
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5
    assert len(ImmutableList.of(1, 2, 3, 4, 5).append(6)) == 6



# Generated at 2022-06-24 00:16:17.138871
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    result = ImmutableList.of(2, 3, 4)
    assert isinstance(result, ImmutableList)
    assert result == ImmutableList(2, ImmutableList(3, ImmutableList(4,)))
    result = ImmutableList.of(1, 1, 2)
    assert isinstance(result, ImmutableList)
    assert result == ImmutableList(1, ImmutableList(1, ImmutableList(2,)))
    result = ImmutableList.empty()
    assert isinstance(result, ImmutableList)
    assert result == ImmutableList(is_empty=True)
    result = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    assert isinstance(result, ImmutableList)
    assert result == Imm

# Generated at 2022-06-24 00:16:18.605076
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList().append(2) == ImmutableList.of(2)


# Generated at 2022-06-24 00:16:21.001073
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-24 00:16:28.401528
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    test_object = ImmutableList.of(1)
    assert len(test_object) == 1

    test_object = ImmutableList.of(1, 2, 3)
    assert len(test_object) == 3

    test_object = ImmutableList.empty()
    assert len(test_object) == 0


# Generated at 2022-06-24 00:16:36.140822
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list_1 = ImmutableList(3)
    assert list_1.head == 3
    assert list_1.tail is None
    assert list_1.is_empty is False
    assert str(list_1) == "ImmutableList[3]"

    list_2 = ImmutableList(3, list_1)
    assert list_2.head == 3
    assert list_2.tail == list_1
    assert list_2.is_empty is False
    assert str(list_2) == "ImmutableList[3, 3]"

    list_3 = ImmutableList.of(2, 1, 0)
    assert list_3.head == 2
    assert list_3.tail.head == 1
    assert list_3.tail.tail.head == 0
    assert list_3.tail.tail.tail is None
   

# Generated at 2022-06-24 00:16:45.534740
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.of(1,2,3,4,5).__str__() == 'ImmutableList[1, 2, 3, 4, 5]'
    assert ImmutableList.of('a', 'b', 'c').__str__() == 'ImmutableList[a, b, c]'
    assert ImmutableList.of(1,2,3,4,5).__str__() == 'ImmutableList[1, 2, 3, 4, 5]'
    assert ImmutableList.of(True, False, True).__str__() == 'ImmutableList[True, False, True]'


# Generated at 2022-06-24 00:16:49.506924
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(4, 5) + ImmutableList.of(6, 7) \
        == ImmutableList.of(4, 5, 6, 7)



# Generated at 2022-06-24 00:16:52.271971
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of('a', 'b', 'c') + ImmutableList.of('d') == ImmutableList.of('a', 'b', 'c', 'd')

# Generated at 2022-06-24 00:16:55.717133
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1, is_empty=False)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2, is_empty=False))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, is_empty=False)))


# Generated at 2022-06-24 00:16:57.750530
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3, ImmutableList(4, ImmutableList(5))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

# Generated at 2022-06-24 00:17:00.941940
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    input_value_1 = [1,2,3,4,5,6,7]
    expected_value_1 = 5

    assert(ImmutableList.of(*input_value_1).find(lambda x: x > 5) == expected_value_1)
