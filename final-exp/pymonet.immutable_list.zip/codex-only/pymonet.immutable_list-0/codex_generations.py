

# Generated at 2022-06-24 00:06:53.361173
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_one = ImmutableList.of(1, 2, 3)
    list_two = ImmutableList.of(2, 4, 6)

    actual = list_one.map(lambda x: x*2)
    assert list_two == actual

# Generated at 2022-06-24 00:06:58.631623
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:07:04.965598
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list3 = ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    list4 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert list1 == list1
    assert list1 == list2
    assert list1 != list3
    assert list1 != list4
test_ImmutableList___eq__()

# Generated at 2022-06-24 00:07:07.613747
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_data = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert len(list_data) == 4


# Generated at 2022-06-24 00:07:14.184138
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(4) == ImmutableList(4)
    assert ImmutableList(5).append(5) == ImmutableList(5, ImmutableList(5))
    assert ImmutableList("asd").append("asd") == ImmutableList("asd", ImmutableList("asd"))
    assert ImmutableList("asd", ImmutableList("asd")).append("asd") == ImmutableList("asd", ImmutableList("asd", ImmutableList("asd")))

# Generated at 2022-06-24 00:07:24.668000
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    with pytest.raises(ValueError):
        empty = ImmutableList.empty()
        empty.filter(lambda f: True)

    empty = ImmutableList.empty()
    filtered_empty = empty.filter(lambda o: o == 1)
    assert filtered_empty.is_empty
    assert filtered_empty.to_list() == []

    list = ImmutableList.of(1,2,3,4)
    filtered_list = list.filter(lambda o: o == 1)
    assert not filtered_list.is_empty
    assert filtered_list.to_list() == [1]

    filtered_list = list.filter(lambda o: o == 457)
    assert filtered_list.is_empty
    assert filtered_list.to_list() == []


# Generated at 2022-06-24 00:07:32.306419
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: True) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x>2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x is None) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x<0) is None


# Generated at 2022-06-24 00:07:35.453070
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of('a', 'b') == ImmutableList.of('a', 'b')


# Generated at 2022-06-24 00:07:39.813492
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    x = ImmutableList.of(1, 2, 3)

    assert x.append(4).head == 1
    assert x.append(4).tail.head == 2
    assert x.append(4).tail.tail.head == 3
    assert x.append(4).tail.tail.tail.head == 4



# Generated at 2022-06-24 00:07:43.080450
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(One(), Two())) == 'ImmutableList[One, Two]'





# Generated at 2022-06-24 00:07:49.416872
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    items1 = ImmutableList.of(1, 2, 3)
    items2 = ImmutableList.of(1, 2, 3)
    items3 = ImmutableList.of(1, 2, 3)
    items4 = ImmutableList.of(1, 2, 3)

    items1 = items1.find(lambda x: x == 2)
    items2 = items2.find(lambda x: x == 3)
    items3 = items3.find(lambda x: x == 4)
    items4 = items4.find(lambda x: x == 1)

    assert items1 == 2
    assert items2 == 3
    assert items3 == None
    assert items4 == 1


# Generated at 2022-06-24 00:07:58.937323
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)), False) != ImmutableList(1, ImmutableList(2, ImmutableList(3)), True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)), False) != ImmutableList(1, ImmutableList(2, ImmutableList(4)), False)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)), False) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)), False) != ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)), False) != ImmutableList.empty()

# Generated at 2022-06-24 00:08:09.577120
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_of_elements = ImmutableList.of(1)

    assert list_of_elements.find(lambda value: value == 1) == 1
    assert list_of_elements.find(lambda value: value == 2) is None

    list_of_elements = ImmutableList.of(1, 2, 3)

    assert list_of_elements.find(lambda value: value == 1) == 1
    assert list_of_elements.find(lambda value: value == 2) == 2
    assert list_of_elements.find(lambda value: value == 3) == 3
    assert list_of_elements.find(lambda value: value == 4) is None


# Generated at 2022-06-24 00:08:13.247167
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    test_list = ImmutableList.of(1, 2, 3)
    assert str(test_list) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:08:18.214618
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l = ImmutableList.empty()

    l = l.append(1)
    l = l.append(2)
    l = l.append(3)

    assert l.head == 1
    assert l.tail.head == 2
    assert l.tail.tail.head == 3
    assert l.tail.tail.tail is None


# Generated at 2022-06-24 00:08:21.240606
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList.of(1, 2, 3)
    second = ImmutableList.of(1, 2, 3)

    assert first == second
    

# Generated at 2022-06-24 00:08:24.802142
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    """
    Test method __str__ of class ImmutableList
    """
    tmp = ImmutableList(1, 2, 3)
    assert str(tmp) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'

# Generated at 2022-06-24 00:08:29.150511
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1,2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty().append(10) == ImmutableList.of(10)



# Generated at 2022-06-24 00:08:32.694941
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_ = ImmutableList.of(True, "foo", 2.3, 2)
    assert len(list_) == 4

    list_ = ImmutableList.of(True)
    assert len(list_) == 1

    list_ = ImmutableList.empty()
    assert len(list_) == 0


# Generated at 2022-06-24 00:08:35.866232
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(3) == ImmutableList(3)
    assert ImmutableList(1).unshift(3) == ImmutableList(3, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2)).unshift(3) == ImmutableList(3, ImmutableList(1, ImmutableList(2)))

# Generated at 2022-06-24 00:08:43.080450
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list = ImmutableList.of('a', 'b', 'c')
    new_list = list.append('d')

    assert new_list.head == 'a'
    assert new_list.tail.head == 'b'
    assert new_list.tail.tail.head == 'c'
    assert new_list.tail.tail.tail.head == 'd'
    assert new_list.tail.tail.tail.tail is None


# Generated at 2022-06-24 00:08:51.917403
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Try to instantiate empty list
    empty_list = ImmutableList.empty()

    # Verify that length of the list is 0
    assert len(empty_list) == 0

    # Try to initialize new ImmutableList instance
    my_list = ImmutableList.of(1, 2, 3, 4)

    # Verify that length of the list is 4
    assert len(my_list) == 4

    # Verify that list is not empty
    assert not my_list.is_empty

    # Verify that list contains elements
    assert [1, 2, 3, 4] == my_list.to_list()

    # Try to access first element of the list
    assert 1 == my_list.head

    # Try to access tail of the list
    assert ImmutableList.of(2, 3, 4) == my_list.tail

    #

# Generated at 2022-06-24 00:09:01.643719
# Unit test for constructor of class ImmutableList

# Generated at 2022-06-24 00:09:04.856519
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    imm_list = ImmutableList.of(1, 2, 3)
    filtered = imm_list.filter(lambda x: x == 2)
    assert filtered == ImmutableList(2)



# Generated at 2022-06-24 00:09:13.854944
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Case 1 of 2
    fn_tests = [
        (ImmutableList.of(2, 3, 4), ImmutableList.of(1, 2), ImmutableList.of(2, 3, 4, 1, 2)),
    ]

    for test in fn_tests:
        # Arrange
        prev_list, to_add_list, expected_list = test

        # Act
        actual_list = prev_list + to_add_list

        # Assert
        assert prev_list == test[0]
        assert to_add_list == test[1]
        assert expected_list == actual_list

    # Case 2 of 2

# Generated at 2022-06-24 00:09:15.936652
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:09:20.847751
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.empty()
    new_list = l.unshift(3)

    assert isinstance(new_list, ImmutableList)
    assert new_list.head == 3
    assert new_list.tail == ImmutableList.empty()



# Generated at 2022-06-24 00:09:24.300774
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Given
    a = ImmutableList.of(2,3,4,5)

    # When
    b = a.map(lambda x : x * x)

    # Then
    print(b)
    assert b == ImmutableList.of(4,9,16,25)


# Generated at 2022-06-24 00:09:27.677940
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList()) == 'ImmutableList[]'

test_ImmutableList___str__()

# Generated at 2022-06-24 00:09:30.295753
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4


# Generated at 2022-06-24 00:09:32.746937
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    some_list = ImmutableList.of('a', 'b', 'c')
    assert some_list.find(lambda el: el == 'b') == 'b'

# Generated at 2022-06-24 00:09:34.532650
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4


# Generated at 2022-06-24 00:09:36.790196
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList([1,2,3]).map(lambda x: x**2) == ImmutableList([1,4,9])
    
    

# Generated at 2022-06-24 00:09:43.627402
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(5) == ImmutableList(5, None)
    assert ImmutableList.of(5, 6) == ImmutableList(5, ImmutableList(6, None))
    assert ImmutableList.of(5, 6, 7) == ImmutableList(5, ImmutableList(6, ImmutableList(7, None)))
    assert ImmutableList.of(5, 6, 7, 2) == ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(2, None))))
    assert ImmutableList.empty() == ImmutableList(is_empty=True)



# Generated at 2022-06-24 00:09:47.355564
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Given
    maybe = ImmutableList.of(2, 8, 3, 4, 1, 5)
    def summator(a,b):
        return a + b

    # When
    result = maybe.reduce(summator, 0)

    # Then
    assert result == 23

# Generated at 2022-06-24 00:09:52.318235
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(5, 7)
    list2 = ImmutableList(5, ImmutableList(7))

    assert(list1 == list2) == True



# Generated at 2022-06-24 00:10:01.178505
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    from nose.tools import assert_true, assert_false

    assert_true(ImmutableList.of(1) == ImmutableList.of(1))
    assert_false(ImmutableList.of(1, 2) == ImmutableList.of(1, 2, 3))
    assert_false(ImmutableList.of(3, 4, 5) == ImmutableList.of(1, 2, 3))
    assert_false(ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2))
    assert_false(ImmutableList.of(1, 2, 3) == ImmutableList.of(2, 3, 4))

# Generated at 2022-06-24 00:10:04.686817
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1, 2, 3, 4)
    list_ = list_.append(5)
    assert list_ == ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:10:06.750341
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList.of(1, 2)


# Generated at 2022-06-24 00:10:14.176400
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert(ImmutableList() == ImmutableList(is_empty=True))
    assert(ImmutableList(1) == ImmutableList(1))
    assert(ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2)))
    assert(ImmutableList() != ImmutableList(1))
    assert(ImmutableList(1) != ImmutableList(2))
    assert(ImmutableList(ImmutableList(1)) != ImmutableList(1))
    assert(ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3)))
    assert(ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2), is_empty=True))

# Generated at 2022-06-24 00:10:18.284850
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_ = ImmutableList.of(1, 2, 3)
    list_2 = ImmutableList.of(7)
    list_3 = ImmutableList.empty()

    assert len(list_) == 3
    assert len(list_2) == 1
    assert len(list_3) == 0

# Generated at 2022-06-24 00:10:23.120519
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3).reduce(lambda x,y: x+y, 0) == 6
    assert ImmutableList.of(4,4,4,4).reduce(lambda x,y: x*y, 1) == 256
    assert ImmutableList.of(1,2,3,4,5).reduce(lambda x,y: x*y, 1) == 120

# Generated at 2022-06-24 00:10:27.249570
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3, 4)) == 'ImmutableList[1, 2, 3, 4]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'

# Generated at 2022-06-24 00:10:34.427871
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.of(1, 2, 3, 4)
    first_element = immutable_list.find(lambda x: x == 1)
    assert first_element == 1

    second_element = immutable_list.find(lambda x: x == 2)
    assert second_element == 2

    third_element = immutable_list.find(lambda x: x == 3)
    assert third_element == 3

    fourth_element = immutable_list.find(lambda x: x == 4)
    assert fourth_element == 4

    empty_list = ImmutableList.empty()
    empty_list_element = empty_list.find(lambda x: x)
    assert empty_list_element is None

    map_empty_list = ImmutableList.empty().map(lambda x: x)

# Generated at 2022-06-24 00:10:42.831328
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    """
    Unit tests for method reduce of class ImmutableList
    """
    assert ImmutableList.of(1, 2).reduce(lambda acc, i: acc + i, 0) == 3
    assert ImmutableList.of('a', 'b').reduce(lambda acc, i: acc + i, '') == 'ab'
    assert ImmutableList.of('a', 'b').reduce(lambda acc, i: acc + i, 'c') == 'cab'
    assert ImmutableList.of('a', 'b').reduce(lambda acc, i: acc + i, '') == 'ab'


# Generated at 2022-06-24 00:10:46.854986
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .map(lambda x: x * 2) \
        == ImmutableList(2, ImmutableList(4, ImmutableList(6, ImmutableList(8, ImmutableList(10)))))

# Generated at 2022-06-24 00:10:50.946494
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.empty()
    assert list1.unshift('a').unshift('b').to_list() == ['b', 'a']
    assert list1.to_list() == []


# Generated at 2022-06-24 00:10:58.989020
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l1 = ImmutableList(3, ImmutableList(2))
    l2 = l1.unshift(0)
    assert l2.to_list() == [0, 3, 2]

    l1 = ImmutableList(3, ImmutableList(2))
    l2 = l1.unshift(0).unshift(-12).unshift(-3)
    assert l2.to_list() == [-3, -12, 0, 3, 2]


# Generated at 2022-06-24 00:11:04.912074
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """Test for method find of class ImmutableList"""
    assert ImmutableList.empty().find(lambda el: True) is None
    assert ImmutableList.empty().find(lambda el: False) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda el: el == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda el: el == 4) is None


# Generated at 2022-06-24 00:11:07.091530
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:11:10.037583
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList.of(1)
    assert test_list.append(2) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-24 00:11:14.369237
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList(2, ImmutableList(4))
    assert l.unshift(1) == ImmutableList(1, ImmutableList(2, ImmutableList(4)))


# Generated at 2022-06-24 00:11:17.109756
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3



# Generated at 2022-06-24 00:11:20.472722
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList.of(1)
    assert test_list.append(2).to_list() == [1,2]


# Generated at 2022-06-24 00:11:32.105116
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList(1).unshift(3) == ImmutableList(3, ImmutableList(1))
    assert ImmutableList(None).unshift(3) == ImmutableList(3, ImmutableList(None))
    assert ImmutableList(1).unshift(None) == ImmutableList(None, ImmutableList(1))
    assert ImmutableList(None).unshift(None) == ImmutableList(None, ImmutableList(None))

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).unshift(4) == ImmutableList(4, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    assert ImmutableList(1, ImmutableList(None)).unshift(None) == ImmutableList(None, ImmutableList(1, ImmutableList(None)))


# Generated at 2022-06-24 00:11:40.518032
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == [], 'ImmutableList.to_list() should return empty list'
    assert ImmutableList(3).to_list() == [3], 'ImmutableList.to_list() should return list with one element'
    assert ImmutableList(3, ImmutableList(5)).to_list() == [3, 5], 'ImmutableList.to_list() should return list with two elements'


# Generated at 2022-06-24 00:11:44.446751
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # arrange
    target_obj = ImmutableList.empty()
    other_obj = ImmutableList.empty()
    expected_result = ImmutableList.empty()
    # act
    actual_result = target_obj + other_obj
    # assert
    assert expected_result == actual_result


# Generated at 2022-06-24 00:11:49.196205
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    """
    If Maybe is empty return new empty Maybe, in other case
    takes mapper function and returns result of mapper.

    :param mapper: function to call with Maybe.value
    :type mapper: Function(A) -> Maybe[B]
    :returns: Maybe[B | None]
    """
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-24 00:11:52.220786
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    immutable_list = ImmutableList.of(1, 2, 3)
    assert immutable_list.filter(lambda x: x == 1).to_list() == [1]


# Generated at 2022-06-24 00:11:57.083201
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(2).append(3) == ImmutableList.of(2, 3)
    assert ImmutableList(2, ImmutableList(3)).append(4) == ImmutableList.of(2, 3, 4)
    assert ImmutableList().append(2) == ImmutableList.of(2)


# Generated at 2022-06-24 00:12:04.557528
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    lst = ImmutableList.of(1,2,3)
    assert len(lst) == 3

    lst = ImmutableList.of(1,2)
    assert len(lst) == 2

    lst = ImmutableList.of(1)
    assert len(lst) == 1

    lst = ImmutableList.of()
    assert len(lst) == 0

# Generated at 2022-06-24 00:12:07.354843
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_ = ImmutableList.of(1, 2, 3)
    new_list = list_.unshift(4)
    assert new_list == ImmutableList.of(4, 1, 2, 3)


# Generated at 2022-06-24 00:12:11.238397
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty = ImmutableList.empty()
    empty2 = ImmutableList.empty()

    assert empty == empty2

    list1 = ImmutableList(5)
    list2 = ImmutableList(7)

    assert list1 != list2
    assert list1 == ImmutableList(5)

    list1 = ImmutableList(5, ImmutableList(8))
    list2 = ImmutableList(5, ImmutableList(7))

    assert list1 != list2
    assert list1 == ImmutableList(5, ImmutableList(8))

    assert empty != list1
    assert list1 != empty


# Generated at 2022-06-24 00:12:13.660186
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(0, 2, 4).append(5).to_list() == [0, 2, 4, 5]


# Generated at 2022-06-24 00:12:16.069692
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Create a test object
    int_list = ImmutableList(10)
    # Run the test
    assert len(int_list) == 1


# Generated at 2022-06-24 00:12:23.889016
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # GIVEN
    elements = [1, 3, 5, 7, 9]

    # WHEN
    immutable_list = ImmutableList(*elements)
    # results = []
    # for _ in elements:
    #     results.append(mapper())

    # THEN
    expected_results = [2, 4, 6, 8, 10]
    mapper = lambda x: x + 1
    mapped_list = immutable_list.map(mapper)
    assert expected_results == mapped_list.to_list()



# Generated at 2022-06-24 00:12:32.366308
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda a: a % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda a: a % 2 == 0).to_list() == [2, 4, 6]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda a: a > 4).to_list() == [5]
    assert ImmutableList.of(3, 4, 5, 6).filter(lambda a: a < 4).to_list() == []
    assert ImmutableList.of(10).filter(lambda a: a > 4).to_list() == [10]

# Generated at 2022-06-24 00:12:34.899717
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:12:38.180180
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1,2,3).map(lambda x: x*2) == ImmutableList.of(2,4,6)
    assert ImmutableList.empty().map(lambda x: x*2) == ImmutableList.empty()

# Generated at 2022-06-24 00:12:41.261548
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.of('test')
    list2 = list1.unshift('new_element')
    assert list1.head == 'test'
    assert list2.head == 'new_element'
    assert list2.tail.head == 'test'
    assert list2.tail.tail is None


# Generated at 2022-06-24 00:12:50.279577
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty()
    assert ImmutableList(1).map(lambda x: x + 1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x + 1) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x + 1) == ImmutableList(2, ImmutableList(3, ImmutableList(4)))

# Generated at 2022-06-24 00:12:59.207214
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list = ImmutableList.empty().unshift(5).unshift(10)

    assert immutable_list.head == 10
    assert immutable_list.tail != None
    assert immutable_list.tail.head == 5
    assert immutable_list.tail.tail != None
    assert immutable_list.tail.tail.is_empty == True

    immutable_list = ImmutableList.of(2, 3, 4)
    immutable_list = immutable_list.unshift(1)

    assert immutable_list.to_list() == [1, 2, 3, 4]

# Generated at 2022-06-24 00:13:11.370947
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList())))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList()))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(3, ImmutableList(2)))

# Generated at 2022-06-24 00:13:16.822395
# Unit test for constructor of class ImmutableList
def test_ImmutableList():  # pragma: no cover
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList().is_empty
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-24 00:13:20.264612
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-24 00:13:29.811687
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3
    assert len(ImmutableList().append(1)) == 1
    assert len(ImmutableList().append(1).append(2)) == 2
    assert len(ImmutableList().append(1).append(2).append(3)) == 3
    assert len(ImmutableList().unshift(1)) == 1
    assert len(ImmutableList().unshift(1).unshift(2)) == 2
    assert len(ImmutableList().unshift(1).unshift(2).unshift(3)) == 3
    assert len(ImmutableList().of(1, 2, 3)) == 3

# Unit

# Generated at 2022-06-24 00:13:31.697182
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty() == ImmutableList.empty().append(1)



# Generated at 2022-06-24 00:13:34.552954
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'



# Generated at 2022-06-24 00:13:41.990545
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    Test if two ImmutableLists are equal or not
    """
    empty_list = ImmutableList.empty()
    none_list = ImmutableList(is_empty=True)
    empty_list_2 = ImmutableList(is_empty=True)

    none_list_2 = ImmutableList(is_empty=True)

    list1 = ImmutableList(1)
    list2 = ImmutableList(2)

    list1_2 = ImmutableList(1)
    list3 = ImmutableList(3)
    list4 = ImmutableList(4)

    list5 = ImmutableList(5)
    list6 = ImmutableList(6)
    list7 = ImmutableList(7)

    list8 = ImmutableList(8)
    list9 = ImmutableList(9)

# Generated at 2022-06-24 00:13:45.419367
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    lst = ImmutableList.of(1, 2, 3, 4)
    mapped = lst.map(lambda x: x * 2)
    assert mapped == ImmutableList.of(2, 4, 6, 8)


# Generated at 2022-06-24 00:13:53.665880
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 1) is None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 7) is None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x > 3) == 4


# Generated at 2022-06-24 00:13:56.414232
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    list = ImmutableList.of(1, 2, 3, 4, 5)

    # When
    result = list.find(lambda x: x > 3)

    # Then
    assert result == 4



# Generated at 2022-06-24 00:13:59.967706
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list = ImmutableList(4, ImmutableList(3))
    assert str(list) == 'ImmutableList[4, 3]'



# Generated at 2022-06-24 00:14:10.523766
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Empty ImmutableList
    a = ImmutableList.empty()
    assert a.head is None
    assert a.tail is None
    assert a.is_empty
    assert len(a) == 0
    assert str(a) == 'ImmutableList[]'

    # Two elements ImmutableList
    b = ImmutableList.of(1, 2)
    assert b.head == 1
    assert b.tail.head == 2
    assert b.tail.tail is None
    assert not b.is_empty
    assert len(b) == 2
    assert str(b) == 'ImmutableList[1, 2]'

    # Three elements ImmutableList
    c = ImmutableList.of(1, 2, 3)
    assert c.head == 1
    assert c.tail.head == 2

# Generated at 2022-06-24 00:14:16.128665
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    list_ = ImmutableList.of('a', 'b', 'c')
    # When
    result = list_.to_list()
    # Then
    assert result == ['a', 'b', 'c']


# Generated at 2022-06-24 00:14:24.548765
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    from pytest import raises
    from .ImmutableList import ImmutableList

    with raises(TypeError):
        ImmutableList.__str__(None)

    assert ImmutableList.__str__(ImmutableList()) == 'ImmutableList[]'
    assert ImmutableList.__str__(ImmutableList(1)) == 'ImmutableList[1]'
    assert ImmutableList.__str__(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'



# Generated at 2022-06-24 00:14:30.042411
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_a = ImmutableList.of(1, 2, 3)
    list_b = ImmutableList.of(4, 5)

    assert len(list_a) == 3
    assert len(list_b) == 2


# Generated at 2022-06-24 00:14:35.242277
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    ImmutableList: check if ImmutableList instances are equal
    """
    elements = [i for i in range(5)]

    assert ImmutableList.of(*elements) == ImmutableList.of(*elements)
    assert ImmutableList.of(*elements) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1)


# Generated at 2022-06-24 00:14:41.597710
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Given
    immutable_list = ImmutableList.of(1, 2, 3, 4)
    immutable_list_two = ImmutableList.of(5, 6, 7)
    expected_result = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)

    # When
    result = immutable_list.__add__(immutable_list_two)

    # Then
    assert result == expected_result


# Generated at 2022-06-24 00:14:43.407862
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3


# Generated at 2022-06-24 00:14:50.535545
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    empty = ImmutableList.empty()
    assert empty + empty == ImmutableList(is_empty=True)

    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:14:52.637835
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5



# Generated at 2022-06-24 00:14:56.624220
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(is_empty=True).to_list() == []
    assert ImmutableList(2, ImmutableList(1, ImmutableList(is_empty=True))).to_list() == [2, 1]
    assert ImmutableList(2).to_list() == [2]


# Generated at 2022-06-24 00:15:06.731700
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x**2) == ImmutableList.of(1, 4, 9, 16)

    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x**2) \
        == ImmutableList.of(1, 4, 9, 16, 25)

    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x**2).map(lambda x: x+1) \
        == ImmutableList.of(2, 5, 10, 17, 26)

    assert ImmutableList.of(1).map(lambda x: x**2) == ImmutableList.of(1)


# Generated at 2022-06-24 00:15:10.851994
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_a = ImmutableList.of(1, 2, 3)
    list_b = list_a.append(4)

    assert list_b == ImmutableList.of(1, 2, 3, 4), 'Append 4 to list with 1, 2, 3 should give 1, 2, 3, 4'
    assert list_a != list_b, 'Original list should not be mutated and should be != list_a != list_b'


# Generated at 2022-06-24 00:15:12.264824
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:15:14.362096
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x : x % 2 == 0).to_list() == [2,4]
    
    

# Generated at 2022-06-24 00:15:23.850103
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).to_list() == [1, 2, 3, 4]

if __name__ == '__main__':
    test_ImmutableList_to_list()

# Generated at 2022-06-24 00:15:34.321257
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).tail.tail.tail.tail.to_list() == [5]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) == ImmutableList.of(1, 2, 3, 4, 5)

    assert ImmutableList(is_empty=True) == ImmutableList.empty()

    assert ImmutableList.of(1).head == 1

# Generated at 2022-06-24 00:15:40.022317
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-24 00:15:43.608748
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    initial_list = ImmutableList.of(1, 2, 3, 4)
    actual = initial_list.filter(lambda x: x % 2 == 0)
    expected = ImmutableList.of(2, 4)
    assert actual == expected



# Generated at 2022-06-24 00:15:46.361281
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_test = ImmutableList.of(1, 2, 3)

    result = str(list_test)

    assert result == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:15:48.760463
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 2) == ImmutableList.of(3, 4, 5, 6)



# Generated at 2022-06-24 00:15:54.442482
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Assert
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    
test_ImmutableList()

# Generated at 2022-06-24 00:15:56.441908
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:16:00.198730
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 4

# Generated at 2022-06-24 00:16:09.876090
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert (
        ImmutableList.empty() + ImmutableList.empty() ==
        ImmutableList()
    ), 'ImmutableList: failed to add two empty lists'

    assert (
        ImmutableList(1) + ImmutableList(1) ==
        ImmutableList(1, ImmutableList(1))
    ), 'ImmutableList: failed to add two lists with one element'

    assert (
        ImmutableList(2, ImmutableList(1, ImmutableList(1))) + ImmutableList(10, ImmutableList(11)) ==
        ImmutableList(2, ImmutableList(1, ImmutableList(1, ImmutableList(10, ImmutableList(11)))))
    ), 'ImmutableList: failed to add two lists with different elements'


# Generated at 2022-06-24 00:16:12.405696
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    # Act
    # Assert
    assert ImmutableList(3, ImmutableList(4)).find(lambda x: x == 4) == 4

# Generated at 2022-06-24 00:16:18.722045
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(
        ImmutableList.of('1')
    ) == 1

    assert len(
        ImmutableList.of('1', '2', '3', '4')
    ) == 4

    assert len(
        ImmutableList.empty()
    ) == 0

# Generated at 2022-06-24 00:16:25.338645
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    first_value = 'first_value'
    second_value = 'second_value'
    list_ = ImmutableList(first_value)
    list_ = list_.unshift(second_value)
    assert list_.head == second_value
    assert isinstance(list_.tail, ImmutableList)
    assert list_.tail.head == first_value
    assert list_.tail.tail is None



# Generated at 2022-06-24 00:16:28.992539
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list = ImmutableList.of(1, 2, 3)
    assert list.to_list() == [1, 2, 3]

# Generated at 2022-06-24 00:16:32.540314
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(3).map(lambda x: x * 2) == ImmutableList.of(6)

    assert ImmutableList.of(0, 1, 2, 3).map(lambda x: x * 2) == ImmutableList.of(0, 2, 4, 6)


# Generated at 2022-06-24 00:16:36.336009
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    ints = ImmutableList.of(1, 2, 3)
    assert isinstance(ints, ImmutableList) is True
    assert ints.head == 1
    assert ints.tail.head == 2
    assert ints.tail.tail.head == 3
    assert ints.tail.tail.tail is None

# Generated at 2022-06-24 00:16:38.796046
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.of(1, 2, 3).__str__() == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:16:46.155620
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    test_method(
        method_name=ImmutableList.unshift,
        test_cases=[
            {
                'n': 0,
                'arguments': [1],
                'expected_value': ImmutableList.of(1),
            },
            {
                'n': 1,
                'arguments': [2],
                'expected_value': ImmutableList.of(2, 1),
            },
        ]
    )


# Generated at 2022-06-24 00:16:54.301182
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda value, acc: acc + value, 0) == 10
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda value, acc: acc - value, 10) == 0
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda value, acc: acc * value, 1) == 24
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda value, acc: acc // value, 48) == 2