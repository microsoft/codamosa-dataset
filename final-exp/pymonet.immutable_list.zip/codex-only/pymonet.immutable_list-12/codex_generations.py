

# Generated at 2022-06-24 00:06:53.783182
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList.of(1, 1, 1)) == 3
    assert len(ImmutableList.of(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)) == 16

# Generated at 2022-06-24 00:06:57.696881
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:07:04.865055
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6)
    even = lambda x: x % 2 == 0
    assert list_.filter(even).to_list() == [2, 4, 6]
    assert list_.filter(None).to_list() == []

test_ImmutableList_filter()

# Generated at 2022-06-24 00:07:11.447760
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Test for method filter of class ImmutableList. Checking filtering
    of list with even and odd numbers with custom function.

    :returns: None
    :raises: AssertionError
    """
    def filter_function(x):
        return x%2 == 0

    li = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    lii = li.filter(filter_function)

    assert lii.to_list() == [2, 4, 6]


# Generated at 2022-06-24 00:07:14.227538
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    a = ImmutableList.of(1, 2, 3, 4, 5)
    assert [1, 2, 3, 4, 5] == a.to_list()


# Generated at 2022-06-24 00:07:17.074851
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-24 00:07:27.473519
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test 1
    my_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert my_list.filter(lambda element: True).to_list() == [1, 2, 3]

    # Test 2
    assert my_list.filter(lambda element: element > 2).to_list() == [3]

    # Test 3
    assert my_list.filter(lambda element: element > 3).to_list() == []

    # Test 4
    assert my_list.filter(lambda element: element > 0).to_list() == [1, 2, 3]

    # Test 5
    assert my_list.filter(lambda element: element > -10).to_list() == [1, 2, 3]

    # Test 6
    assert my_list.filter(lambda element: element < 0).to

# Generated at 2022-06-24 00:07:31.055707
# Unit test for constructor of class ImmutableList
def test_ImmutableList(): # pragma: no cover
    ImmutableList.of(1, 2, 3)
    ImmutableList.of(1)
    ImmutableList.empty()



# Generated at 2022-06-24 00:07:33.380424
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert [1,2,3,4] == ImmutableList.of(2,3,4).unshift(1).to_list()


# Generated at 2022-06-24 00:07:36.878201
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(6)) == 1
    assert len(ImmutableList.of(6, 7, 8)) == 3
    assert len(ImmutableList(is_empty=True)) == 0


# Generated at 2022-06-24 00:07:47.194959
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)

    assert test_list.find(lambda x: x == 1) == 1
    assert test_list.find(lambda x: x == 5) == 5
    assert test_list.find(lambda x: x == 3) == 3
    assert test_list.find(lambda x: x == 9) is None
    assert test_list.find(lambda x: x < 0) is None

    empty_test_list = ImmutableList.empty()

    assert empty_test_list.find(lambda x: x == 1) is None
    assert empty_test_list.find(lambda x: x > 1) is None
    assert empty_test_list.find(lambda x: x < 0) is None


# Generated at 2022-06-24 00:07:55.685075
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.of(1).append(3) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4).append(5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).append(6) == ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-24 00:08:00.351932
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3).append(4).append(5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1).append(2).map(lambda x: x * 2) == ImmutableList.of(2, 4)


# Generated at 2022-06-24 00:08:09.225314
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)

    assert ImmutableList.empty().append(10) == ImmutableList.of(10)
    assert ImmutableList.empty().append(10).append(20) == ImmutableList.of(10, 20)


# Generated at 2022-06-24 00:08:21.326170
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of('a', 'b', 'c').append('d') == ImmutableList.of('a', 'b', 'c', 'd')
    assert ImmutableList.of('a', 'b', 'c').append('d').append('e').append('f') == ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f')
    assert ImmutableList.empty().append('a') == ImmutableList.of('a')
    assert ImmutableList.empty().append('a').append('b') == ImmutableList.of('a', 'b')
    assert ImmutableList.empty().append('a').append('b').append('c') == ImmutableList.of('a', 'b', 'c')

# Generated at 2022-06-24 00:08:24.871092
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of('one', 'two', 'three')
    list2 = ImmutableList.of('four', 'five', 'six')
    assert list1 + list2 == ImmutableList.of('one', 'two', 'three', 'four', 'five', 'six')

# Generated at 2022-06-24 00:08:27.875515
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(None) == ImmutableList(None)
    assert ImmutableList(None, ImmutableList(None)) == ImmutableList(None, ImmutableList(None))



# Generated at 2022-06-24 00:08:30.104387
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1).to_list() == [1]



# Generated at 2022-06-24 00:08:35.049667
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of('test')) == 1
    assert len(ImmutableList.of('test1', 'test2')) == 2
    assert len(ImmutableList.of('test1', 'test2', 'test3')) == 3


# Generated at 2022-06-24 00:08:41.060921
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1).map(lambda x: x + 1) == ImmutableList.of(3, 4, 5)


# Generated at 2022-06-24 00:08:43.534031
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:08:48.578332
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, '3').__eq__(
        ImmutableList.of(1, 2, '3')
    ) is True

    assert ImmutableList.of(1, 2, '3').__eq__(
        ImmutableList.of(1, 2, 4)
    ) is False

    assert ImmutableList.of().__eq__(
        ImmutableList.of()
    ) is True

# Generated at 2022-06-24 00:08:55.772941
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(0, 1, 2, 3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(0, 1).filter(lambda x: x > 1) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x > 1) == ImmutableList.empty()
test_ImmutableList_filter()

# Generated at 2022-06-24 00:08:59.527745
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_numbers = ImmutableList.of(2, 3, 5, 7, 11, 13)
    filtered_list = list_of_numbers.filter(
        lambda x: x > 5
    )
    assert filtered_list == ImmutableList.of(7, 11, 13)


# Generated at 2022-06-24 00:09:03.459965
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda n: n + 2).to_list() == [3, 4, 5]



# Generated at 2022-06-24 00:09:04.754488
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'


# Generated at 2022-06-24 00:09:12.286562
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) \
        .__eq__(ImmutableList.of(1)) == True

    assert ImmutableList.of(1, 2) \
        .__eq__(ImmutableList.of(1, 2)) == True

    assert ImmutableList.of(2, 3) \
        .__eq__(ImmutableList.of(1, 2)) == False

    assert ImmutableList.of(2, 3) \
        .__eq__(ImmutableList.of(1)) == False

    assert ImmutableList.of(2, 3) \
        .__eq__(ImmutableList.of('test', 1)) == False

# Generated at 2022-06-24 00:09:18.743055
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).to_list()
    assert [] == ImmutableList.empty().to_list()
    assert [1,2,3] == ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list()

test_ImmutableList_to_list()

# Generated at 2022-06-24 00:09:25.203733
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    first_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    second_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    first_empty_list = ImmutableList()
    second_empty_list = ImmutableList()

    # Act
    first_test = first_list == second_list
    second_test = first_empty_list == second_empty_list

    # Assert
    assert first_test is True
    assert second_test is True

# Generated at 2022-06-24 00:09:29.023715
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[None]'
    assert str(ImmutableList(42)) == 'ImmutableList[42]'
    assert str(ImmutableList(42, 44, 3)) == 'ImmutableList[42, 44, 3]'

# Generated at 2022-06-24 00:09:32.414525
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    def predicate(elem: int) -> bool:
        return elem > 2

    assert ImmutableList.of(1, 2, 3, 4).find(predicate) == 3
    # test for case when element does not exist
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 4) is None



# Generated at 2022-06-24 00:09:34.937485
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    actual_result = ImmutableList(1, ImmutableList(2, ImmutableList(3))).__eq__(ImmutableList(1, ImmutableList(2, ImmutableList(3))))

    assert(actual_result == True)


# Generated at 2022-06-24 00:09:41.246616
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1)\
        .map(lambda x: x + 1)\
        .to_list() == [2]

    assert ImmutableList.of(1,2,3,4,5)\
        .map(lambda x: x + 1)\
        .to_list() == [2,3,4,5,6]

    assert ImmutableList.of(1)\
        .map(lambda x: x + 1)\
        .append(2)\
        .map(lambda x: x * 3)\
        .to_list() == [6,6]


# Generated at 2022-06-24 00:09:45.522176
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert immutable_list.head == 1
    assert immutable_list.tail.head == 2
    assert immutable_list.tail.tail.head == 3
    assert immutable_list.tail.tail.tail is None

# Generated at 2022-06-24 00:09:48.459800
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of([1, 2, 3, 4, 5])) == 5
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5


# Generated at 2022-06-24 00:09:57.660571
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda a: a > 1) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3, 4).filter(lambda a: a > 1) == ImmutableList.of(2, 3, 4)

    assert ImmutableList.of(
        ImmutableList.of(1, 2, 3, 4),
        ImmutableList.of(5, 6, 7, 8)
    ).filter(lambda inner_list: inner_list.find(lambda v: v > 6) is not None) == \
    ImmutableList.of(
        ImmutableList.of(5, 6, 7, 8)
    )



# Generated at 2022-06-24 00:10:01.072703
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    test_value = ImmutableList.of(1, 2, 3)
    result = test_value.map(lambda x: x ** 2)

    expected_result = ImmutableList.of(1, 4, 9)

    assert result == expected_result


# Generated at 2022-06-24 00:10:07.427799
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    import pytest
    from ast import literal_eval


# Generated at 2022-06-24 00:10:11.808731
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList.of(1, 2, 3)
    expected_list = ImmutableList.of(1, 2, 3, 4)

    assert test_list.append(4) == expected_list


# Generated at 2022-06-24 00:10:16.646673
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList(0)
    b = ImmutableList(2)
    c = ImmutableList(0)
    print("Test: ImmutableList.__eq__")
    assert a == c, "Test failed"
    assert a != b, "Test failed"
    print("The test passed")
    return 0


# Generated at 2022-06-24 00:10:26.270576
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    """
    Runs tests for method to_list of class ImmutableList
    """
    # Creating a empty Immutable List instance
    mb_none = ImmutableList.empty()
    # Calling to_list method on that Immutable List instance
    assert mb_none.to_list() == []

    # Creating a Immutable List instance
    mb_one = ImmutableList(10)
    # Calling to_list method on that Immutable List instance
    assert mb_one.to_list() == [10]

    # Creating a Immutable List instance
    mb_many = ImmutableList.of(10, 20, 30)
    # Calling to_list method on that Immutable List instance
    assert mb_many.to_list() == [10, 20, 30]

    # Creating a Immutable List instance
    mb_many

# Generated at 2022-06-24 00:10:30.116098
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList()
    assert ImmutableList() != ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-24 00:10:32.578068
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    test_list = ImmutableList.of(1, 2, 3) \
        .map(lambda a: a*a)
    expected_list = ImmutableList.of(1, 4, 9)
    assert test_list == expected_list

# Generated at 2022-06-24 00:10:36.081147
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    arr1 = ImmutableList(1)
    arr2 = ImmutableList(1)
    arr3 = ImmutableList(1, ImmutableList(2))
    arr4 = ImmutableList(2, ImmutableList(1))
    arr5 = ImmutableList(1, ImmutableList(2))

    assert arr1 != 1
    assert not (arr1 == 1)
    assert arr1 == arr2
    assert arr3 == arr5
    assert arr3 != arr4
    assert arr5 != arr4


# Generated at 2022-06-24 00:10:41.353211
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Case with case1 with empty list
    assert len(ImmutableList.empty()) == 0

    # Case with case1 with several elements
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3

    # Case with one element
    assert len(ImmutableList(1)) == 1

    # Case with no elements
    assert len(ImmutableList()) == 0



# Generated at 2022-06-24 00:10:52.257435
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList(1, ImmutableList.of(2, 3)) == ImmutableList(1, ImmutableList.of(2, 3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList().empty() == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 3)
    assert ImmutableList.of

# Generated at 2022-06-24 00:11:02.024454
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    my_list = ImmutableList.of(2, 3, 4, 5)
    new_list = my_list.unshift(1)

    assert(
        new_list ==
        ImmutableList.of(1, 2, 3, 4, 5)
    )

    new_new_list = new_list.unshift(0)

    assert(
        new_new_list ==
        ImmutableList.of(0, 1, 2, 3, 4, 5)
    )

    assert(
        my_list ==
        ImmutableList.of(2, 3, 4, 5)
    )


# Generated at 2022-06-24 00:11:05.906148
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # given
    empty_list = ImmutableList.empty()
    list_of_elements = ImmutableList.of(1, 2, 3, 4)

    # then
    assert isinstance(empty_list, ImmutableList) == True
    assert isinstance(list_of_elements, ImmutableList) == True

# Generated at 2022-06-24 00:11:10.259799
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of('a', 'b', 'c').to_list() == ['a', 'b', 'c']
    assert ImmutableList.of('a').to_list() == ['a']



# Generated at 2022-06-24 00:11:14.247637
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda x, y: x + y, 0) == 6


# Generated at 2022-06-24 00:11:25.984939
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1) + ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2) + ImmutableList.of(3, 4)
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3) + ImmutableList.of(4)
    assert ImmutableList.of(1, 2, 3, 4, 5) == ImmutableList.of(1, 2, 3, 4) + ImmutableList.of(5)
    assert ImmutableList.of(1) == ImmutableList.of(1) + ImmutableList.of()
    assert ImmutableList.of(1, 2) == ImmutableList

# Generated at 2022-06-24 00:11:33.761889
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(3) == ImmutableList(3) == ImmutableList.of(3)
    assert ImmutableList.of(1).unshift(3) == ImmutableList.of(3, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(3) == ImmutableList.of(3, 1, 2, 3)

# Generated at 2022-06-24 00:11:39.784053
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:11:42.917340
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():  # pragma: no cover
    list_to_test = ImmutableList.of(1, 2, 3)
    assert list_to_test.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:11:55.252015
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Arrange
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list2 = ImmutableList(4, ImmutableList(5))
    actual = list1 + list2

    # Assert
    assert actual == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert actual.to_list() == [1, 2, 3, 4, 5]

    # Arrange
    list1 = ImmutableList()
    list2 = ImmutableList(4, ImmutableList(5))
    actual = list1 + list2

    # Assert
    assert actual == ImmutableList(4, ImmutableList(5))
    assert actual.to_list() == [4, 5]

    # Arrange
   

# Generated at 2022-06-24 00:12:02.633905
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList(1)
    assert a.reduce(lambda x,y: x+y, 0) == 1

    b = ImmutableList(1, ImmutableList(2))
    assert b.reduce(lambda x,y: x+y, 0) == 3

    c = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert c.reduce(lambda x,y: x+y, 0) == 6

    d = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert d.reduce(lambda x,y: x+y, 0) == 10

# Generated at 2022-06-24 00:12:05.665452
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-24 00:12:17.763873
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, x: acc + x, 0) == 15, \
        "Something went wrong with method reduce()"
    
    assert ImmutableList.of(1).reduce(lambda acc, x: acc + x, 0) == 1, \
        "Something went wrong with method reduce() for ImmutableList with 1 element"
    
    assert ImmutableList.of(5.5, 4.5, 3.5, 2.5, 1.5).reduce(lambda acc, x: acc + x, 0) == 17.5, \
        "Something went wrong with method reduce() for ImmutableList with float elements"
    

# Generated at 2022-06-24 00:12:23.519538
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.empty().append('some')) == "ImmutableList['some']"
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:12:32.566412
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    expected_result = [1, 2, 3]
    list1 = ImmutableList(1, ImmutableList(2), False)
    list2 = ImmutableList(ImmutableList(3), ImmutableList(2), False)
    list3 = ImmutableList(ImmutableList(3), ImmutableList(2), True)
    list4 = ImmutableList(1, True)
    list5 = ImmutableList(ImmutableList(3), True)
    list6 = ImmutableList(ImmutableList(3), False)

    assert list1 + list2 == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list2 + list1 == ImmutableList(ImmutableList(3), ImmutableList(2, ImmutableList(1)))

# Generated at 2022-06-24 00:12:36.092350
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) ==\
           ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:12:43.498730
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, None)).__eq__(ImmutableList(1, ImmutableList(2, None)))
    assert ImmutableList(1).__eq__(ImmutableList(1))
    assert ImmutableList(False).__eq__(ImmutableList(False))
    assert ImmutableList(1).__eq__(ImmutableList(2)) is False
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1)) is False
    assert ImmutableList.empty().__eq__(ImmutableList(1)) is False
    assert ImmutableList.empty().__eq__(ImmutableList.empty())

# Generated at 2022-06-24 00:12:48.884630
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1,2)
    list_2 = list_.append(3)
    list_3 = list_.append(4)

    assert list_ == ImmutableList.of(1,2)
    assert list_2 == ImmutableList.of(1,2,3)
    assert list_3 == ImmutableList.of(1,2,4)


# Generated at 2022-06-24 00:13:00.391982
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(4).unshift(5).to_list() == [5, 4, 1, 2, 3]
    assert ImmutableList.of(1).unshift(2).unshift(3).to_list() == [3, 2, 1]
    assert ImmutableList.empty().unshift(3).unshift(2).to_list() == [2, 3]
    assert ImmutableList.of(1).unshift(2).unshift(3).unshift(4).to_list() == [4, 3, 2, 1]
    assert ImmutableList.empty().unshift(3).unshift(5).unshift(1).to_list() == [1, 5, 3]


# Generated at 2022-06-24 00:13:12.033145
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]'
    assert str(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)) == \
        'ImmutableList[1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert str(
        ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9).filter(lambda x: x % 2 == 0)
    ) == 'ImmutableList[2, 4, 6, 8]'


# Generated at 2022-06-24 00:13:15.998179
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    def _run(*args):
        items = list(args)
        return ImmutableList.of(*items).append(10)

    assert _run() == ImmutableList.of(10)
    assert _run(1) == ImmutableList.of(1, 10)
    assert _run(1, 2, 3) == ImmutableList.of(1, 2, 3, 10)

# Generated at 2022-06-24 00:13:19.410500
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-24 00:13:26.956522
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    """
    Test if addition method will return new instance of ImmutableList class
    """    
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2) + ImmutableList.empty() == ImmutableList.of(1, 2)
    assert ImmutableList.empty() + ImmutableList.of(3, 4) == ImmutableList.of(3, 4)


# Generated at 2022-06-24 00:13:37.268897
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

    assert ImmutableList.of(1, 2).filter(lambda x: False) == ImmutableList.empty()

    assert ImmutableList.of(1, 2).filter(lambda x: True) == ImmutableList.of(1, 2)

    assert ImmutableList.of(1, 2).filter(lambda x: x == 1) == ImmutableList.of(1)

    assert ImmutableList.of(1, 2).filter(lambda x: x == 2) == ImmutableList.of(2)

    assert ImmutableList.empty().filter(lambda x: x) == ImmutableList.empty()


# Generated at 2022-06-24 00:13:42.785639
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)) == 10
    assert len(ImmutableList.empty()) == 0



# Generated at 2022-06-24 00:13:47.934610
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(5)) == "ImmutableList[5]"
    assert str(ImmutableList.of(1, 2, 3)) == "ImmutableList[1, 2, 3]"
    assert str(ImmutableList()) == "ImmutableList[]"
    assert str(ImmutableList.empty()) == "ImmutableList[]"


# Generated at 2022-06-24 00:13:51.265817
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    imm_list = ImmutableList.of(1, 2, 3, 4)
    assert imm_list.find(lambda x: x % 2 == 0) == 2
    assert imm_list.find(lambda x: x == 5) == None

# Generated at 2022-06-24 00:13:56.957859
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3



# Generated at 2022-06-24 00:14:04.311446
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    with pytest.raises(ValueError):
        ImmutableList.empty().to_list()

    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of('a', 'b', 'c', 'd').to_list() == ['a', 'b', 'c', 'd']


# Generated at 2022-06-24 00:14:08.162076
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3, 4)
    filtered_list = il.filter(lambda x: x > 2)

    assert [3, 4] == filtered_list.to_list()



# Generated at 2022-06-24 00:14:11.432338
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    lst = ImmutableList(1)
    assert lst.head == 1
    assert len(lst) == 1
    assert lst.tail is None


# Generated at 2022-06-24 00:14:15.776045
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    l1 = ImmutableList(1)
    assert l1 == ImmutableList(1)
    assert l1.to_list() == [1]

    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-24 00:14:22.320548
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of('Elephant', 'Dogs', 'Cats', 'Deer')

    if l.find(lambda s: s == 'Cats') != 'Cats':
        raise AssertionError('Found wrong element!')


# Generated at 2022-06-24 00:14:26.209226
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:14:29.488524
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    start_list = ImmutableList.of(1, 2, 3)
    end_list = ImmutableList.of(1, 2, 3, 4)

    assert start_list + ImmutableList(4) == end_list



# Generated at 2022-06-24 00:14:34.163613
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    lst_1  = ImmutableList(1, ImmutableList(2))
    lst_2  = ImmutableList(3, ImmutableList(4))
    lst_3  = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) 
    res    = lst_1 + lst_2
    
    assert res == lst_3


# Generated at 2022-06-24 00:14:35.906513
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2


# Generated at 2022-06-24 00:14:42.830162
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(2, ImmutableList(1)) == ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(is_empty=True) + ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-24 00:14:47.039167
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:14:50.952982
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList.of('a', 'b', 'c')
    list_2 = ImmutableList.of('d', 'e', 'f')
    list_3 = ImmutableList.of('d', 'e', 'f', 'a', 'b', 'c')

    assert list_1 + list_2 == list_3


# Generated at 2022-06-24 00:14:55.982329
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of(1, 2, 3)
    second_list = ImmutableList.of(4, 5, 6)

    z = first_list + second_list

    assert first_list == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert second_list == ImmutableList(4, ImmutableList(5, ImmutableList(6)))
    assert z == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))


# Generated at 2022-06-24 00:15:00.858030
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList(1, ImmutableList.of(2, 3), False)
    second_list = ImmutableList(4, ImmutableList.of(5, 6), False)
    expected = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert expected == first_list + second_list


# Generated at 2022-06-24 00:15:05.589651
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    empty_list = ImmutableList.empty()

    list_3_elements = ImmutableList.of(1, 2, 3, 4)

    assert empty_list.reduce(lambda x, y: x + y, 0) == 0

    assert list_3_elements.reduce(lambda x, y: x + y, 0) == 10

# Generated at 2022-06-24 00:15:09.326016
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(2) == ImmutableList(2)
    assert ImmutableList(2).to_list() == [2]
    assert ImmutableList(2, ImmutableList(3)).to_list() == [2, 3]


# Generated at 2022-06-24 00:15:10.689252
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    tested = ImmutableList.of(1, 2, 3, 4)
    assert tested.unshift(0) == ImmutableList(0, 1, 2, 3, 4)



# Generated at 2022-06-24 00:15:16.888194
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():

    assert ImmutableList.of(1).map(lambda x: x*2).to_list() == [2]

    assert ImmutableList.of(1, 2).map(lambda x: x*2).to_list() == [2, 4]

    assert ImmutableList.of(1, 2, 3).map(lambda x: x*2).to_list() == [2, 4, 6]

    assert ImmutableList.of(1, 2, 3).map(lambda x: x*2).to_list() == [2, 4, 6]

    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x*2).to_list() == [2, 4, 6, 8, 10]



# Generated at 2022-06-24 00:15:28.761711
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # case 1
    list1 = ImmutableList.empty()
    list2 = list1.map(inc)
    assert list2.head == None
    assert list2.tail == None
    assert list2.is_empty == True

    # case 2
    list1 = ImmutableList.of(1)
    list2 = list1.map(inc)
    assert list2.head == 2
    assert list2.tail == None
    assert list2.is_empty == False

    # case 3
    list1 = ImmutableList.of(1, 2, 3)
    list2 = list1.map(inc)
    assert list2.head == 2
    assert list2.tail.head == 3
    assert list2.tail.tail.head == 4
    assert list2.is_empty == False



# Generated at 2022-06-24 00:15:35.385401
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list1 = ImmutableList.of(1)
    assert len(list1) == 1

    list2 = ImmutableList.of(1, 2, 3)
    assert len(list2) == 3

import pytest


# Generated at 2022-06-24 00:15:37.902391
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList(1, ImmutableList(2)).__str__() == 'ImmutableList[1, 2]'\
        and ImmutableList(1).__str__() == 'ImmutableList[1]'



# Generated at 2022-06-24 00:15:43.057814
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'

    test_list = ImmutableList.of(1)
    assert str(test_list) == 'ImmutableList[1]'

    assert str(test_list.unshift(2)) == 'ImmutableList[2, 1]'



# Generated at 2022-06-24 00:15:45.204930
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    il = ImmutableList.of(1, 2, 3)
    assert il == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:15:46.492628
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1,2,3,4,5,6,7,8)) == 8

# Generated at 2022-06-24 00:15:48.205447
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList(1, ImmutableList(2)) \
        .map(lambda x: x+1)\
        .to_list() == [2, 3]


# Generated at 2022-06-24 00:15:52.841123
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    from nose.tools import assert_equal

    assert_equal(str(ImmutableList.of(10, 11, 12)), 'ImmutableList[10, 11, 12]')


# Generated at 2022-06-24 00:16:01.692084
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    from typing import Callable

    def is_odd(x: int) -> bool:
        return x % 2 == 0

    l = ImmutableList.of(1, 2, 3, 4, 5)

    assert l.find(is_odd) == 2

    l = l.append(6)

    assert l.find(is_odd) == 2

    l = l.unshift(0)

    assert l.find(is_odd) == 0

    l = ImmutableList.of(0)

    assert l.find(is_odd) == 0

    l = l.append(1)

    assert l.find(is_odd) == 0

    l = ImmutableList.of(1)

    assert l.find(is_odd) is None

    l = ImmutableList.of()


# Generated at 2022-06-24 00:16:08.891919
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of('a', 'b', 'c')
    list_2 = ImmutableList.of('a', 'b', 'c')
    assert list_1 == list_2
    
    list_1 = ImmutableList.of('a')
    list_2 = ImmutableList.of('a', 'b')
    assert list_1 is not list_2

    list_1 = ImmutableList.of('a')
    list_2 = ImmutableList.empty()
    assert list_1 is not list_2


# Generated at 2022-06-24 00:16:12.017348
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    il1 = ImmutableList.of(5, 7)
    il2 = ImmutableList.of(9, 11)
    assert il1 + il2 == ImmutableList.of(5, 7, 9, 11)


# Generated at 2022-06-24 00:16:20.955609
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of('test') + ImmutableList.of('1', '2', '3') == ImmutableList.of('test', '1', '2', '3')
    assert ImmutableList.of('test', '1', '2') + ImmutableList.empty() == ImmutableList.of('test', '1', '2')
    assert ImmutableList.empty() + ImmutableList.of('test', '1', '2') == ImmutableList.of('test', '1', '2')
    assert ImmutableList.of('test', '1', '2') + ImmutableList.of('3') == ImmutableList.of('test', '1', '2', '3')

# Generated at 2022-06-24 00:16:26.458372
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    """
    Checking if ImmutableList instances will pass the test.

    """
    list_1 = ImmutableList(1, ImmutableList(2))
    list_2 = ImmutableList(1, ImmutableList(2))
    assert list_1 == list_2


# Generated at 2022-06-24 00:16:33.704836
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Given
    immutable_list = ImmutableList(1, ImmutableList(2))

    # When
    new_immutable_list = immutable_list.append(3)

    # Then
    assert immutable_list != new_immutable_list, 'ImmutableList: append should return new ImmutableList'

    assert [1, 2, 3] == new_immutable_list.to_list(), 'ImmutableList: append should add element to the end of list'


# Generated at 2022-06-24 00:16:45.119103
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    def is_even(el: int) -> bool:
        return el % 2 == 0

    def double(el: int) -> int:
        return el * 2

    def multiply_by_number(number: int) -> Callable[[int], int]:
        return lambda el: el * number

    assert ImmutableList.empty().map(is_even).to_list() == []
    assert ImmutableList.of(1, 2, 3, 4, 5).map(is_even).to_list() == [False, True, False, True, False]
    assert ImmutableList.of(1, 2, 3, 4, 5).map(double).to_list() == [2, 4, 6, 8, 10]

# Generated at 2022-06-24 00:16:55.422594
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    test_cases = [
        (ImmutableList(), ImmutableList(), True),
        (ImmutableList(1), ImmutableList(1), True),
        (ImmutableList(1, ImmutableList(2)), ImmutableList(1, ImmutableList(2)), True),
        (ImmutableList(1, ImmutableList(1)), ImmutableList(1, ImmutableList(2)), False),
        (ImmutableList(), ImmutableList(1), False),
    ]

    for test_case in test_cases:
        assert test_case[0].__eq__(test_case[1]) == test_case[2], \
            '__eq__ method of class ImmutableList doesn\'t work correct'

