

# Generated at 2022-06-24 00:06:52.124025
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert ImmutableList.of(1).__len__() == 1
    assert ImmutableList.of(1, 2, 3).__len__() == 3
    assert ImmutableList.of().__len__() == 0

# Generated at 2022-06-24 00:06:56.673977
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Test cases
    class TestCase(TestCaseBase):
        def __init__(self, immutable_list_: ImmutableList[int], expected_result: int):
            self.immutable_list_ = immutable_list_
            self.expected_result = expected_result

    test_cases = [
        TestCase(ImmutableList.of(1), 1),
        TestCase(ImmutableList.of(), 0),
        TestCase(ImmutableList.empty(), 0),
        TestCase(ImmutableList.of(1, 2, 3), 3),
        TestCase(ImmutableList.of('1', '2', '3', '4'), 4),
    ]

    for test_case in test_cases:
        result = len(test_case.immutable_list_)

# Generated at 2022-06-24 00:07:05.441921
# Unit test for constructor of class ImmutableList

# Generated at 2022-06-24 00:07:10.462988
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l = ImmutableList.of(1)
    l = l.append(2)
    l = l.append(3)
    l = l.append(4)
    l = l.append(5)
    result = l.to_list()
    expected_result = [1, 2, 3, 4, 5]
    assert result == expected_result


# Generated at 2022-06-24 00:07:14.866214
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Arrange
    head = 'head'
    tail = ImmutableList.of('head1', 'head2')
    append_value = 'append_value'

    # Act
    result = tail.unshift(append_value)

    # Assert
    assert result == ImmutableList(append_value, tail)



# Generated at 2022-06-24 00:07:25.382325
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    from hypothesis import given, assume

    list_of_ints = ImmutableList.of(1, 2, 3, 4, 5)
    list_of_strigns = ImmutableList.of('a', 'b', 'c', 'd', 'e')
    list_of_chars = ImmutableList.of('x', 'y', 'z', 'r', 'd')

    @given(integers(), integers(), integers(), integers(), integers())
    def test_list_of_ints(a, b, c, d, e):
        assume(a != 5)
        assume(b != 5)
        assume(c != 5)
        assume(d != 5)
        assume(e != 5)

        list_ = ImmutableList.of(a, b, c, d, e)

# Generated at 2022-06-24 00:07:33.529138
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1)) == 1, 'ImmutableList with one element must return 1 in __len__'
    assert len(ImmutableList()) == 0, 'Empty ImmutableList must return 0 in __len__'
    assert len(ImmutableList(1, ImmutableList(2))) == 2, 'ImmutableList with two element must return 2 in __len__'
    assert len(ImmutableList('a', ImmutableList('b', ImmutableList('c')))) == 3, 'ImmutableList must return 3 in __len__'


# Generated at 2022-06-24 00:07:37.637564
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    mutable_list = ImmutableList(1)
    for i in range(1, 100):
        mutable_list = mutable_list.append(i)
    expected_list = ImmutableList.of(*range(100))
    assert expected_list == mutable_list



# Generated at 2022-06-24 00:07:47.665703
# Unit test for method find of class ImmutableList

# Generated at 2022-06-24 00:07:52.916351
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList(10)
    list_2 = ImmutableList(20)
    assert list_1 + list_2 == ImmutableList.of(10, 20) == ImmutableList(10, ImmutableList(20))
    assert ImmutableList.of(10, 20) + ImmutableList.of(30, 40) == ImmutableList.of(10, 20, 30, 40)


# Generated at 2022-06-24 00:07:57.503839
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(
        ImmutableList.of(1)
    ) == 1

    assert len(
        ImmutableList.of(1, 2)
    ) == 2

    assert len(
        ImmutableList.of(1, 2, 3)
    ) == 3

    assert len(
        ImmutableList.empty()
    ) == 0



# Generated at 2022-06-24 00:08:02.814705
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of()) == 0
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:08:12.176577
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    reducer_add = lambda acc, curr: acc + curr
    reducer_sub = lambda acc, curr: acc - curr
    reducer_mul = lambda acc, curr: acc * curr

    assert ImmutableList().reduce(reducer_add, 0) == 0
    assert ImmutableList(1).reduce(reducer_add, 0) == 1
    assert ImmutableList(2).reduce(reducer_sub, 0) == 2
    assert ImmutableList(0).reduce(reducer_sub, 0) == 0
    assert ImmutableList(1).reduce(reducer_mul, 0) == 0
    assert ImmutableList(1, 2, 3).reduce(reducer_mul, 1) == 6

# Generated at 2022-06-24 00:08:23.333880
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    _sum = lambda acc, val: acc + val
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(_sum) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).map(_sum) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList().append(1).tail == ImmutableList(1)
    assert ImmutableList().unshift(1).head

# Generated at 2022-06-24 00:08:25.229254
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.empty()) == 0



# Generated at 2022-06-24 00:08:32.628592
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test 1
    test_list1 = ImmutableList.of(1, 2, 3, 4)
    result = test_list1.find(lambda x: x % 2 == 0)
    assert result == 2

    # Test 2
    test_list2 = ImmutableList.of(1, 2, 3, 4)
    result = test_list2.find(lambda x: x > 5)
    assert result is None

    # Test 3
    test_list3 = ImmutableList.of(1, 2, 3, 4)
    result = test_list3.find(lambda x: True)
    assert result == 1
test_ImmutableList_find()

# Generated at 2022-06-24 00:08:34.898110
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList.empty().to_list() == []

# Generated at 2022-06-24 00:08:46.166613
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a_list = ImmutableList.of(1, 2, 3)
    assert a_list == a_list
    assert a_list == ImmutableList.of(1, 2, 3)
    assert a_list == ImmutableList.of(1, 2, 3)

    assert a_list != ImmutableList.of(1, 2)
    assert a_list != ImmutableList.of(1, 2, 3, 4)
    assert a_list != ImmutableList.of(7, 2, 3)
    assert a_list != ImmutableList.of(1, 7, 3)
    assert a_list != ImmutableList.of(1, 2, 7)
    assert a_list != ImmutableList.of(7, 7, 7)

    assert ImmutableList.empty() == ImmutableList.empty()
    assert Imm

# Generated at 2022-06-24 00:08:55.666640
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList(1)

    expected_value = 1
    value = list_.find(lambda x: x == 1)
    assert value == expected_value

    expected_value = None
    value = list_.find(lambda x: x == 2)
    assert value == expected_value

    list_ = ImmutableList.of(1, 2, 3, 4)

    expected_value = 3
    value = list_.find(lambda x: x == 3)
    assert value == expected_value

    expected_value = None
    value = list_.find(lambda x: x == 5)
    assert value == expected_value

# Generated at 2022-06-24 00:09:02.794206
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(1,2,3,4).reduce(lambda x, y: x * y, 1) == 24
    assert ImmutableList.of(0,1,2,3).reduce(lambda x, y: y if x == 0 else x, 0) == 0
    assert ImmutableList.of(1,2,3,4).reduce(lambda x, y: x if x >= y else y, 1) == 4
    assert ImmutableList.of(1,2,3,4).reduce(lambda x, y : x if x <= y else y, 1) == 1

test_ImmutableList_reduce()


# Generated at 2022-06-24 00:09:11.363905
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList(1, 2, 3, 4) + ImmutableList.empty() == ImmutableList(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.empty().append(1).append(2).append(3).append(4)

test_ImmutableList_append()


# Generated at 2022-06-24 00:09:14.197918
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0).to_list() == [0, 1, 2, 3], "Should be ImmutableList([0, 1, 2, 3])"



# Generated at 2022-06-24 00:09:18.460479
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(4,3,2).to_list() == [4,3,2]
    assert ImmutableList() == ImmutableList.empty()



# Generated at 2022-06-24 00:09:23.337628
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    lst = ImmutableList.of(1, 2)
    new = lst.append(3)
    assert new != lst
    assert new.to_list() == [1, 2, 3]
    assert lst.to_list() == [1, 2]
    assert len(lst) == 2
    assert len(new) == 3


# Generated at 2022-06-24 00:09:28.398289
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    ImmutableList = ImmutableList

    l1 = ImmutableList.of(1, 2, 3)
    assert l1.to_list() == [1, 2, 3]

    l2 = ImmutableList.of('1', '2', '3')
    assert l2.to_list() == ['1', '2', '3']

test_ImmutableList_to_list()

# Generated at 2022-06-24 00:09:31.963422
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    some_list = ImmutableList.of(1, 2, 3, 4)

    result = some_list.append(5)

    assert tuple(result.to_list()) == (1, 2, 3, 4, 5)
    

test_ImmutableList_append()

# Generated at 2022-06-24 00:09:33.340447
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list = ImmutableList.of(1, 2, 3)

    assert len(list) == 3


# Generated at 2022-06-24 00:09:38.888906
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_list.head == 1
    assert test_list.tail.head == 2
    assert test_list.tail.tail.head == 3
    assert test_list.tail.tail.tail.head == 4
    assert test_list.tail.tail.tail.tail.head == 5
    assert test_list.tail.tail.tail.tail.tail is None
    assert test_list.is_empty is False



# Generated at 2022-06-24 00:09:48.598560
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda a, b: a + b, 0) == 0
    assert ImmutableList.empty().reduce(lambda a, b: a, 1) == 1
    assert ImmutableList.of(1).reduce(lambda a, b: a + b, 0) == 1
    assert ImmutableList.of(1).reduce(lambda a, b: a, 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda a, b: a + b, 0) == 1 + 2 + 3 + 4 + 5
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda a, b: a * b, 1) == 1 * 2 * 3 * 4 * 5

# Generated at 2022-06-24 00:09:54.324068
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    a = ImmutableList.of('A', 'B', 'C')
    b = a.append('D')

    assert b.head == 'A'
    assert b.tail.head == 'B'
    assert b.tail.tail.head == 'C'
    assert b.tail.tail.tail.head == 'D'


# Generated at 2022-06-24 00:09:57.063478
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(1, 2, 3)

    assert list_.reduce(lambda acc, item: acc + item, 0) == 6


# Generated at 2022-06-24 00:10:04.142121
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Test empty list
    assert ImmutableList.empty().find(lambda x: x == 1) is None
    # Test list with one element
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    # Test list with more than one element
    assert ImmutableList.of(1, 0, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 0, 2, 3).find(lambda x: x == 0) == 0



# Generated at 2022-06-24 00:10:10.209778
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    mlist = ImmutableList.of(a, b, c, d, e)

    # when
    new_list = mlist.filter(lambda x: x > 3)

    # then
    assert new_list == ImmutableList.of(d, e)


# Generated at 2022-06-24 00:10:14.667084
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 2) == ImmutableList(2) 
    assert ImmutableList().filter(lambda x: x == 2) == ImmutableList(is_empty=True) 


# Generated at 2022-06-24 00:10:19.890853
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)
    assert ImmutableList.of(1, 2).unshift(3).unshift(4) == ImmutableList.of(4, 3, 1, 2)


# Generated at 2022-06-24 00:10:25.113265
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of('a').to_list() == ['a']
    assert ImmutableList.of('a', 'b', 'c').to_list() == ['a', 'b', 'c']



# Generated at 2022-06-24 00:10:28.186788
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    fn = lambda x: x > 3
    i = ImmutableList.of(1, 2, 3, 4, 5)
    i = i.filter(fn)

    assert i == ImmutableList.of(4, 5)


# Generated at 2022-06-24 00:10:33.043477
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(
        1, 2, 3
    ).filter(lambda x: x > 1) == ImmutableList.of(2, 3)

    assert ImmutableList.of(1).filter(lambda x: x > 1) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()

    assert ImmutableList.empty().filter(lambda x: x > 1) == ImmutableList.empty()



# Generated at 2022-06-24 00:10:41.797708
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    array = ImmutableList.of(1, 2, 3, 4, 5)

    # Act
    first_element = array.find(lambda x: x == 1)
    last_element = array.find(lambda x: x == 5)
    even_element = array.find(lambda x: x % 2 == 0)
    odd_element = array.find(lambda x: x % 2 != 0)

    # Assert
    assert first_element == 1
    assert last_element == 5
    assert even_element == 2
    assert odd_element == 1


# Generated at 2022-06-24 00:10:46.655389
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(is_empty=True)) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 4


# Generated at 2022-06-24 00:10:52.520939
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    """
    Method to_list should return list with members of ImmutableList
    """
    # creating ImmutableList
    list = ImmutableList()
    list = list.append(1)
    l = ImmutableList.of(2,3)
    list2 = list.append(2).append(3)
    assert list2.to_list() == [1,2,3]
    assert l.to_list() == [2,3]

# Generated at 2022-06-24 00:10:55.199732
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList.of(1, 2, 3, 4)
    assert l.reduce(lambda a, b: a + b, 0) == 10


# Generated at 2022-06-24 00:11:03.920282
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    ImmutableList().__eq__(ImmutableList())
    ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1, ImmutableList(2)))
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList() != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList()


# Generated at 2022-06-24 00:11:15.709938
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    l1 = ImmutableList.of(5, 4, 3, 2, 1)
    acc = l.reduce(lambda a, b: a + b, 0)
    acc1 = l.reduce(lambda a, b: a - b, 0)
    acc2 = l1.reduce(lambda a, b: a + b, 0)
    acc3 = l1.reduce(lambda a, b: a - b, 0)
    assert acc == sum([1, 2, 3, 4, 5])
    assert acc1 == sum([-1, -2, -3, -4, -5])
    assert acc2 == sum([1, 2, 3, 4, 5])

# Generated at 2022-06-24 00:11:23.899160
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)


# Generated at 2022-06-24 00:11:29.338085
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    """
    Unit test for method unshift of class ImmutableList
    """
    input_element = 1
    empty_list = ImmutableList.empty()
    single_element_list = ImmutableList(input_element)
    three_elements_list = ImmutableList.of(input_element, 2, 3)

    assert empty_list.unshift(input_element) == ImmutableList(input_element)
    assert single_element_list.unshift(input_element) == ImmutableList(input_element, single_element_list)
    assert three_elements_list.unshift(input_element) == ImmutableList(input_element, three_elements_list)

# Generated at 2022-06-24 00:11:33.113405
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list = ImmutableList.of('hello', 'world')
    assert immutable_list.to_list() == ['hello', 'world']


# Generated at 2022-06-24 00:11:34.852587
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'

# Generated at 2022-06-24 00:11:45.773775
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    stateful_function = lambda i: i + 1
    normal_function = lambda i: i

    result = ImmutableList.of(1, 2, 3).map(stateful_function)

    assert result.to_list() == [2, 3, 4]
    assert result.head == 2
    assert result.tail.head == 3
    assert result.tail.tail.head == 4
    assert result.tail.tail.tail is None

    result = ImmutableList.of(1, 2, 3).map(normal_function)

    assert result.to_list() == [1, 2, 3]
    assert result.head == 1
    assert result.tail.head == 2
    assert result.tail.tail.head == 3
    assert result.tail.tail.tail is None


# Generated at 2022-06-24 00:11:52.436603
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Test with three elements (1, 2, 3)
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, element: acc + element, 0) == 6

    # Test with one element (1)
    assert ImmutableList.of(1).reduce(lambda acc, element: acc + element, 0) == 1

    # Test with empty list
    assert ImmutableList.empty().reduce(lambda acc, element: acc + element, 0) == 0

# Generated at 2022-06-24 00:11:57.353694
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Generating argument and expected result
    list_one = ImmutableList.of(1, 2, 3)
    list_two = ImmutableList.of(4, 5, 6)

    list_result = ImmutableList.of(1, 2, 3, 4, 5, 6)

    # Test of add method of ImmutableList
    assert (list_one + list_two) == list_result

# Generated at 2022-06-24 00:11:59.569450
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    actual = str(ImmutableList.of(9, 8, 7, 6, 5, 4, 3, 2, 1))
    expected = 'ImmutableList[9, 8, 7, 6, 5, 4, 3, 2, 1]'

    assert actual == expected



# Generated at 2022-06-24 00:12:01.052683
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6

# Generated at 2022-06-24 00:12:02.424400
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(1))) == 'ImmutableList[1, 1]'

# Generated at 2022-06-24 00:12:09.825554
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x+1) == ImmutableList.of(2)
    assert ImmutableList.of(1,2,3).map(lambda x: x+1) == ImmutableList.of(2,3,4)
    assert ImmutableList.of(3).map(lambda x: x+1).map(lambda x: x*x) == ImmutableList.of(16)
    assert ImmutableList.of(3, -1).map(lambda x: x+1).map(lambda x: x*x) == ImmutableList.of(16, 0)
    assert ImmutableList.of(3, -1, 100).map(lambda x: x+1).map(lambda x: x*x) == ImmutableList.of(16, 0, 10000)


# Generated at 2022-06-24 00:12:15.046323
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # arrange
    expected = 'b'
    actual = None
    my_list = ImmutableList.of('a', 'b', 'c')
    # act
    actual = my_list.find(lambda x: x == 'b')
    # assert
    assert expected == actual, f'expected: {expected}, actual: {actual}'

# Generated at 2022-06-24 00:12:22.512713
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    example_list1 = ImmutableList.of(1, 2, 3)
    example_list2 = ImmutableList.of(4, 5, 6)
    assert example_list1.__add__(example_list2) == ImmutableList.of(1,2,3,4,5,6)
    assert ImmutableList.empty().__add__(example_list1) == example_list1
    assert example_list1.__add__(ImmutableList.empty()) == example_list1
    assert ImmutableList.empty().__add__(ImmutableList.empty()) == ImmutableList.empty()


# Generated at 2022-06-24 00:12:26.552451
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1)
    new_list = list_.append(2)
    expected_list = ImmutableList.of(1, 2)
    assert new_list == expected_list

# Generated at 2022-06-24 00:12:37.884590
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList(2).append(1).unshift(3)) == 'ImmutableList[3, 2, 1]'
    assert str(ImmutableList.of(1).map(lambda x: x * x)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1).filter(lambda x: x > 0)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1).find(lambda x: x > 0)) == '1'

# Generated at 2022-06-24 00:12:39.667421
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6

# Generated at 2022-06-24 00:12:47.885982
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_a = ImmutableList.of(1, 2)
    list_b = ImmutableList.of(3, 4)
    list_c = ImmutableList.of(5, 6)
    list_d = ImmutableList.of(7, 8)

    addition1 = list_a.append(list_b)
    addition2 = list_c.append(list_d)

    result = addition1.append(addition2)

    assert result == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8))))))))


# Generated at 2022-06-24 00:12:52.743494
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty()
    assert ImmutableList(1).map(lambda x: x) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-24 00:12:57.066067
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    func = lambda x: x + 1
    assert ImmutableList.of(1, 2, 3).map(func) == ImmutableList.of(2, 3, 4)

# Generated at 2022-06-24 00:13:02.259018
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1).find(lambda x: x > 2) is None
    assert ImmutableList.empty().find(lambda x: x > 2) is None

# Generated at 2022-06-24 00:13:07.873026
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0

    assert len(ImmutableList.empty()) == 0

    assert len(ImmutableList(1)) == 1

    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3

    assert len(ImmutableList.of(1, 2, 3)) == 3


# Generated at 2022-06-24 00:13:11.099913
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    empty_list = ImmutableList.empty()
    assert empty_list.to_list() == []

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1).to_list() == [1]


# Generated at 2022-06-24 00:13:16.967665
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert not ImmutableList.of(1, 2, 3) == ImmutableList.of(3, 2, 1)
    assert not ImmutableList.of(1, 2, 3) == ImmutableList.of(3, 2)
    assert ImmutableList.empty() == ImmutableList.empty()

# Generated at 2022-06-24 00:13:22.982974
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    filtered_list = ImmutableList.of(1, 2, 3, 4, 5)
    filtered_list = filtered_list.filter(lambda x: x % 2 == 0)
    assert filtered_list == ImmutableList.of(2, 4)

    filtered_list = filtered_list.filter(lambda x: x == 3)
    assert filtered_list == ImmutableList.empty()


# Generated at 2022-06-24 00:13:27.257226
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    test_list = ImmutableList(1, ImmutableList(2))
    expected = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    current = test_list + ImmutableList(3)
    assert current == expected
test_ImmutableList___add__()


# Generated at 2022-06-24 00:13:34.204384
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    b = ImmutableList.of(1, 2, 3)
    assert str(a) == 'ImmutableList[1, 2, 3]'
    assert str(b) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'



# Generated at 2022-06-24 00:13:38.126330
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1, 2, 3, 4)

    def find_number_bigger_then_2(x):
        return x > 2

    assert l.find(find_number_bigger_then_2) == 3

# Generated at 2022-06-24 00:13:42.628244
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of('a').to_list() == ['a']
    assert ImmutableList.of('a', 'b', 'c', 'd').to_list() == ['a', 'b', 'c', 'd']


# Generated at 2022-06-24 00:13:45.982946
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    my_list1 = ImmutableList(1)
    my_list2 = ImmutableList(2)

    assert my_list1 + my_list2 == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-24 00:13:49.147364
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():  # pragma: no cover
    data = ImmutableList(1, ImmutableList(2))

    assert data.find(lambda x: x == 1) == 1
    assert data.find(lambda x: x == 3) is None



# Generated at 2022-06-24 00:13:51.672251
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(None) == ImmutableList(is_empty=True)
    actual: ImmutableList[int] = ImmutableList(1)
    assert actual == ImmutableList(1, None)
    assert ImmutableList(1, ImmutableList.of(2, 3, 4)) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:13:59.223625
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_one = ImmutableList(None, None)
    list_two = ImmutableList(1, ImmutableList(2))
    list_three = ImmutableList(None, ImmutableList(1, ImmutableList(2, ImmutableList(3))))

    assert len(list_one) == 0
    assert len(list_two) == 2
    assert len(list_three) == 4

# Generated at 2022-06-24 00:14:09.747601
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4).filter(
        lambda single_element: single_element > 3
    )

    assert ImmutableList.of(1, 2, 3, 4).filter(
        lambda single_element: single_element > 3
    ) == ImmutableList.of(4)

    assert ImmutableList.of(1, 2, 3, 4).filter(
        lambda single_element: single_element > 0
    ) == ImmutableList.of(1, 2, 3, 4)

    assert ImmutableList.of(1, 2, 3, 4).filter(
        lambda single_element: single_element > 100
    ) == ImmutableList.empty()

    assert ImmutableList.of('a', 'b', 'c').filter

# Generated at 2022-06-24 00:14:17.671294
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).to_list() == [1, 2, 3, 4]

# Generated at 2022-06-24 00:14:24.269311
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 0) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9).filter(lambda x: x > 5) == ImmutableList.of(6, 7, 8, 9)

# Generated at 2022-06-24 00:14:30.803442
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Given
    list_objects = ImmutableList.of(
        {'name': 'first'},
        {'name': 'second'},
        {'name': 'third'}
    )

    # When
    result = list_objects.find(lambda e: e.get('name') == 'second')

    # Then
    assert result == {'name': 'second'}


# Generated at 2022-06-24 00:14:35.572300
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 1, 2).reduce(lambda x,y: x + y, 0) == 4


# Generated at 2022-06-24 00:14:37.521505
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    xs = ImmutableList.of(1, 2, 3)
    assert xs.append(4).to_list() == [1, 2, 3, 4]



# Generated at 2022-06-24 00:14:45.432985
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l1 = ImmutableList.of("aa", "bb")
    l2 = ImmutableList.of("cc", "dd")
    l3 = l1 + l2
    assert l3.to_list() == ["aa", "bb", "cc", "dd"]

test_ImmutableList___add__()

# Generated at 2022-06-24 00:14:49.578202
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert str(ImmutableList.empty().unshift(100)) == 'ImmutableList[100]'
    assert str(ImmutableList.of(1, 2, 3).unshift(100)) == 'ImmutableList[100, 1, 2, 3]'

test_ImmutableList_unshift()


# Generated at 2022-06-24 00:14:56.861397
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    first_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    second_list = ImmutableList(4, ImmutableList(5, ImmutableList(6)))
    third_list = ImmutableList(7, ImmutableList(8, ImmutableList(9)))

    # When
    result = first_list + second_list + third_list

    # Then
    assert result.to_list() == [1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-24 00:15:01.032744
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list1 = ImmutableList.of(2, 3, 4)
    assert list1.reduce(lambda acc, n: acc + n, 0) == 9


# Generated at 2022-06-24 00:15:09.275384
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) + ImmutableList(2, ImmutableList(3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3, ImmutableList(4)) == ImmutableList(
        1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))
    )



# Generated at 2022-06-24 00:15:13.765427
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.empty() == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()



# Generated at 2022-06-24 00:15:18.262755
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2).to_list() == [2, 1]
    assert ImmutableList.of(1, 2, 3).unshift(4).to_list() == [4, 1, 2, 3]


# Generated at 2022-06-24 00:15:25.786907
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(
        lambda acc, val: acc + val, 
        0,
    ) == 0

    assert ImmutableList.of(
        1
    ).reduce(
        lambda acc, val: acc + val, 
        0,
    ) == 1

    assert ImmutableList.of(
        1, 2, 3, 4
    ).reduce(
        lambda acc, val: acc + val, 
        0,
    ) == 10



# Generated at 2022-06-24 00:15:33.532070
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).filter(lambda x: x % 2 == 0) == ImmutableList(0, ImmutableList(2))
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).filter(lambda x: x < 0) == ImmutableList(is_empty=True)
    assert ImmutableList(0, ImmutableList(1, ImmutableList(2))).filter(lambda x: x > 0) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-24 00:15:39.115121
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert None == ImmutableList.empty().reduce(lambda a, b: a + b, 0)
    assert 9 == ImmutableList.of(1,2,3,3).reduce(lambda a, b: b + a, 0)
    assert 3 == ImmutableList.of(1,2,3,3).reduce(lambda a, b: b + a, 0)
    assert [1, 2, 3] == ImmutableList.of(1,2,3,3,4).filter(lambda n: n < 4).reduce(lambda acc, n: acc + [n], [])



# Generated at 2022-06-24 00:15:42.086817
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_ = ImmutableList.of(
        1,
        2,
        3,
        4,
        5
    )
    assert len(list_) == 5


# Generated at 2022-06-24 00:15:49.870530
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_ints = ImmutableList.of(1, 2, 3, 4)
    list_of_even = list_of_ints.filter(lambda x: x % 2 == 0)
    assert list_of_even == ImmutableList(2, 4), 'List of even'

    list_of_odd = list_of_ints.filter(lambda x: x % 2)
    assert list_of_odd == ImmutableList(1, 3), 'List of odd'

    list_of_numbers = list_of_odd.filter(lambda x: x >= 1)
    assert list_of_numbers == ImmutableList(1, 3), 'List of numbers'

    list_of_strings = ImmutableList.of('1', '2', '3', '4')
    list_of_digits = list_of_strings

# Generated at 2022-06-24 00:15:54.078706
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    test_list = ImmutableList.of(1, 2, 3)
    assert test_list.to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:16:02.525104
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList('asd') == ImmutableList('asd')
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList('a')) == ImmutableList(1, ImmutableList('a'))
    assert ImmutableList(1, ImmutableList('a')) != ImmutableList(1, ImmutableList('b'))
    assert ImmutableList(1, ImmutableList('a')) != ImmutableList(2, ImmutableList('a'))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList('asd') != ImmutableList('asf')

# Generated at 2022-06-24 00:16:11.149372
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_1 = ImmutableList(1)
    list_2 = ImmutableList(1, ImmutableList(2))
    list_3 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_4 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert str(list_1) == 'ImmutableList[1]'
    assert str(list_2) == 'ImmutableList[1, 2]'
    assert str(list_3) == 'ImmutableList[1, 2, 3]'
    assert str(list_4) == 'ImmutableList[1, 2, 3, 4]'


# Generated at 2022-06-24 00:16:16.276867
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(2, 3, 4, 5, 6, 7)
    result_list = test_list.filter(lambda x: x % 2 == 0)
    expected_list = ImmutableList.of(2, 4, 6)
    assert(result_list == expected_list)

test_ImmutableList_filter()

# Generated at 2022-06-24 00:16:18.909593
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-24 00:16:24.625590
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 5 == 0) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 5 == 3) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: (x + 3) % 5 == 0) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: (x + 3) % 5 == 4) is None

# Generated at 2022-06-24 00:16:29.874913
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    """
    Test validation of method reduce of class ImmutableList

    :returns: Assertion error if method works wrong
    """
    immutable_list = ImmutableList.of(1, 2, 3, 4)
    reduce_result = immutable_list.reduce(lambda acc, cur: acc + cur, 0)

    assert reduce_result == 10

# Generated at 2022-06-24 00:16:32.354529
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert list_.to_list() == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-24 00:16:36.892023
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    """
    Unit test for constructor of class ImmutableList
    """
    list1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert list1.head == 1
    assert list1.tail.head == 2
    assert list1.tail.tail.head == 3
    assert list1.tail.tail.tail is None

# Generated at 2022-06-24 00:16:43.656270
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1, 2)
    list2 = ImmutableList.of(3)
    list3 = list1 + list2

    assert list3.head == 1
    assert list3.tail.head == 2
    assert list3.tail.tail.head == 3
    assert list3.tail.tail.tail is None

# Generated at 2022-06-24 00:16:48.753222
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Should return new ImmutableList with emptied tail
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))

    # Should return concatenated lists
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    # Should not return new instance of IsEmptyError
    assert ImmutableList(is_empty=True).append(2) != ImmutableList(is_empty=True)



# Generated at 2022-06-24 00:16:58.414569
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    a = ImmutableList.of('Foo')
    b = ImmutableList('Foo')
    assert a == b

    c = ImmutableList.of('Foo', 'Bar')
    d = ImmutableList('Foo', ImmutableList('Bar'))
    assert c == d

    e = ImmutableList.of('Foo', 'Bar', 'Baz')
    f = ImmutableList('Foo', ImmutableList('Bar', ImmutableList('Baz')))
    assert e == f

    assert ImmutableList.empty() == ImmutableList()

    assert ImmutableList('Foo').head == 'Foo'
    assert ImmutableList('Foo').tail == ImmutableList()
    assert ImmutableList('Foo').is_empty == False
    assert ImmutableList().head == None
    assert ImmutableList().tail