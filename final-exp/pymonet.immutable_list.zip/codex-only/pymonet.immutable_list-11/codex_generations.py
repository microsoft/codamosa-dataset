

# Generated at 2022-06-24 00:06:55.303347
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of('a').unshift('b') == ImmutableList.of('b', 'a')
    assert ImmutableList.of('a', 'c').unshift('b') == ImmutableList.of('b', 'a', 'c')
    assert ImmutableList.of('a', 'c', 'd').unshift('b') == ImmutableList.of('b', 'a', 'c', 'd')
    assert ImmutableList.of('a', 'c', 'd', 'e').unshift('b') == ImmutableList.of('b', 'a', 'c', 'd', 'e')


# Generated at 2022-06-24 00:07:01.441095
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1).reduce(lambda x, y: x + y, 0) == 1
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 1) == 7

# Generated at 2022-06-24 00:07:08.584878
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert(ImmutableList.empty().map(lambda x: x) == ImmutableList(is_empty=True))
    assert(ImmutableList(1).map(lambda x: x) == ImmutableList(1))
    assert(ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x) == ImmutableList.of(1, 2, 3))
    assert(ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4))



# Generated at 2022-06-24 00:07:11.598793
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_1 = ImmutableList.of(1, 2, 3)
    assert str(list_1) == "ImmutableList{}".format(list_1.to_list())

# Generated at 2022-06-24 00:07:15.882263
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Given
    list = ImmutableList.of(1, 2, 3, 4, 5)

    # When
    sum = list.reduce(lambda acc: lambda curr: acc + curr, 0)
    mul = list.reduce(lambda acc: lambda curr: acc * curr, 1)

    # Than
    assert sum == 15
    assert mul == 120

test_ImmutableList_reduce()

# Generated at 2022-06-24 00:07:20.408218
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_a = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_b = list_a.unshift(4)
    assert ImmutableList(4, ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == list_b

# Generated at 2022-06-24 00:07:25.631715
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 7) == None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x > 3) == 4

    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x > 3).find(lambda x: x == 4) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x > 3).find

# Generated at 2022-06-24 00:07:30.844813
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x + y, 0) == 10
    assert ImmutableList.of('a', 'b', 'c', 'd').reduce(lambda x, y: x + y, 'z') == 'zbcd'



# Generated at 2022-06-24 00:07:32.752936
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList.of(1, 2, 3, 4)
    assert l.reduce(lambda acc, x: acc + x, 0) == 10
    assert l.reduce(lambda acc, x: acc * x, 1) == 24


# Generated at 2022-06-24 00:07:44.673848
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Input data for tests
    data = {
        'empty_list': ImmutableList.empty(),
        'list_with_one_element': ImmutableList(10),
        'list_with_three_elements': ImmutableList.of(10, 20, 30),
        'list_with_six_elements': ImmutableList.of(10, 20, 30, 40, 50, 60),
        'non_ImmutableList_object': {'key': 'value'}
    }

    # Expected data for tests
    expected = {
        'empty_list': 0,
        'list_with_one_element': 1,
        'list_with_three_elements': 3,
        'list_with_six_elements': 6,
        'non_ImmutableList_object': False
    }

    # Test

# Generated at 2022-06-24 00:07:48.658442
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4)

    assert test_list.find(lambda x: False) is None
    assert test_list.find(lambda x: True) == 1
    assert test_list.find(lambda x: x % 2 == 0) == 2
    assert test_list.find(lambda x: x % 2 == 1) == 1

# Generated at 2022-06-24 00:07:51.944415
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list1 = ImmutableList.of(1, 2, 3)
    assert list1.__str__() == 'ImmutableList[1, 2, 3]'

    list2 = ImmutableList.empty()
    assert list2.__str__() == 'ImmutableList[]'

# Generated at 2022-06-24 00:07:55.231753
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 3).find(lambda x: x % 2 == 0) == None

# Generated at 2022-06-24 00:07:58.754019
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(4, 5, 6)
    c = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert a.__add__(b) == c


# Generated at 2022-06-24 00:08:10.505914
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()

    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(3, ImmutableList(4, ImmutableList(5)))


# Generated at 2022-06-24 00:08:16.152129
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1).to_list() == [1]
    assert ImmutableList(1).append(2).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2)).append(3).to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:08:21.466137
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x == 4) == ImmutableList(is_empty=True)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3, 5, 7)



# Generated at 2022-06-24 00:08:23.823308
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(5)) == 'ImmutableList[5]'
    assert str(ImmutableList(5).append(6)) == 'ImmutableList[5, 6]'



# Generated at 2022-06-24 00:08:28.296912
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)

# Generated at 2022-06-24 00:08:31.720377
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    one_to_ten = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    assert one_to_ten.reduce(lambda a, b: a + b, 0) == 55
    # Unit test for method reduce of class ImmutableList

# Generated at 2022-06-24 00:08:34.861517
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    result = test_list.find(lambda x: x % 2 == 0)
    assert result == 2



# Generated at 2022-06-24 00:08:36.439260
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(2, 3, 4, 5, 6).filter(lambda x: x > 3).to_list() == [4, 5, 6]


# Generated at 2022-06-24 00:08:39.174889
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList(1, 2, 3, 4, 5).find(lambda x: x > 2) == 3
    assert ImmutableList(1, 2, 3, 4, 5).find(lambda x: x == 6) is None


# Generated at 2022-06-24 00:08:41.956528
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(42, 34, 56).to_list() == [42, 34, 56]



# Generated at 2022-06-24 00:08:48.063946
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # should create an empty list
    assert ImmutableList.empty() == ImmutableList.empty()

    # should create an immutable list with one element
    assert ImmutableList.of(1) == ImmutableList(1)

    # should create an immutable list with multiple elements
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-24 00:08:55.521176
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Create a new instance of ImmutableList with given values
    list = ImmutableList.of(1, 2, 3)
    # Accumulator function
    def accumulate(acc, el):
        return acc + el
    # Call reduce method of ImmutableList and pass accumulator function and initial value
    reduced = list.reduce(accumulate, 0)
    # Check if the result equals to the expected result
    assert(reduced == 6)

# Generated at 2022-06-24 00:08:59.680231
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(2, ImmutableList(5)).to_list() == [2, 5]
    assert ImmutableList(3, ImmutableList(1, ImmutableList(4))).to_list() == [3, 1, 4]

# Generated at 2022-06-24 00:09:05.278250
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert ImmutableList().__len__() == 0
    assert ImmutableList(1).__len__() == 1
    assert ImmutableList(1, ImmutableList(2)).__len__() == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__len__() == 3



# Generated at 2022-06-24 00:09:07.309187
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    print('Test if map function works properly')
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list.map(lambda element : element * 2).to_list() == [2, 4, 6, 8, 10], 'Map method is not working properly'
    print('Test is OK')


# Generated at 2022-06-24 00:09:10.775137
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
# Run tests
test_ImmutableList()

# Generated at 2022-06-24 00:09:13.318124
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_first = ImmutableList.of(1)
    assert list_first + list_first == ImmutableList.of(1, 1)



# Generated at 2022-06-24 00:09:22.567453
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # check if class has method __add__
    assert hasattr(ImmutableList, '__add__')

    # check if method returns instance of ImmutableList
    assert type(ImmutableList(1).__add__(ImmutableList(1))) == ImmutableList 

    # check sum with empty ImmutableList
    assert ImmutableList(1).__add__(ImmutableList.empty()) == ImmutableList(1, ImmutableList.empty())

    # check sum with not empty ImmutableList 
    assert ImmutableList(1).__add__(ImmutableList(2, ImmutableList.empty())) == ImmutableList(1, ImmutableList(2, ImmutableList.empty()))

# Generated at 2022-06-24 00:09:27.611333
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1).head == 1
    assert ImmutableList(1).tail is None
    assert ImmutableList(1, ImmutableList(2)).tail.head == 2
    assert ImmutableList(1, ImmutableList(2)).tail.tail is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).tail.tail.head == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).tail.tail.tail is None

# Generated at 2022-06-24 00:09:31.211146
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    fn = lambda x: x

    assert ImmutableList.of(1).__len__() == 1
    assert ImmutableList.of(1, 6, 9).__len__() == 3
    assert ImmutableList.of(1, 6, 'a').__len__() == 3



# Generated at 2022-06-24 00:09:39.380354
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    int_list = ImmutableList.of(3, 4, 5, 6)
    int_list = int_list.filter(lambda x: x > 4)
    expected = ImmutableList(5, ImmutableList(6))
    assert int_list == expected
    assert int_list.filter(lambda x: x > 4) == expected
    assert int_list.filter(lambda x: x > 4) == expected
    assert int_list.filter(lambda x: x > 4) == expected
    assert int_list.filter(lambda x: x > 4) == expected
    assert int_list.filter(lambda x: x > 4) == expected
    assert int_list.filter(lambda x: x > 4) == expected


# Generated at 2022-06-24 00:09:44.035383
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList.of(1).unshift(2) == ImmutableList(2, ImmutableList(1))
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList(3, ImmutableList(1, ImmutableList(2)))



# Generated at 2022-06-24 00:09:50.062110
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == "ImmutableList[1, 2, 3]"
    assert str(ImmutableList.of(1, 2, 3, 4, 5)) == "ImmutableList[1, 2, 3, 4, 5]"
    assert str(ImmutableList.empty()) == "ImmutableList[]"

# Generated at 2022-06-24 00:09:55.929427
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    assert ImmutableList.of(7, 8, 9).find(lambda x: x == 8) == 8

    assert ImmutableList.of(7, 8, 9).find(lambda x: x == 12) is None


# Generated at 2022-06-24 00:10:00.785346
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList.of(1, 2, 3, 4, 5)
    assert a.reduce(lambda acc, x: acc + x, 0) == 15

# Generated at 2022-06-24 00:10:06.869099
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    # Act
    list_empty = ImmutableList.empty()
    list_with_one_element = ImmutableList.of(1)
    list_with_elements = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    # Assert
    assert list_empty.filter(lambda x: x == 1) == ImmutableList.empty()
    assert list_with_one_element.filter(lambda x: x == 1) == ImmutableList.of(1)
    assert list_with_elements.filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6, 8, 10)
test_ImmutableList_filter()

# Generated at 2022-06-24 00:10:14.214529
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) + ImmutableList.empty() == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.empty() == Immutable

# Generated at 2022-06-24 00:10:21.533230
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(10).append(20).tail.head == 20
    assert ImmutableList.empty().append(10).append(20).tail.tail is None
    assert ImmutableList.of(1, 2, 3).append(4).append(5).tail.head == 5
    assert ImmutableList.of(1, 2, 3).append(4).append(5).tail.tail.head == 4
    assert ImmutableList.of(1, 2, 3).append(4).append(5).append(6).tail.tail.tail.tail.tail.head == 1


# Generated at 2022-06-24 00:10:26.784822
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    method should return new ImmutableList with elements
    that passed info argument returns True
    """
    # Given
    lst = ImmutableList.of(1, 2, 3, 4, 5, 6)

    # When
    result = lst.filter(lambda x: x > 2)
    
    # Then
    assert result == ImmutableList.of(3, 4, 5, 6)




# Generated at 2022-06-24 00:10:30.581506
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Given
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(4, 5, 6)
    expected = ImmutableList.of(1, 2, 3, 4, 5, 6)

    # When
    actual = a + b

    # Then
    assert actual == expected


# Generated at 2022-06-24 00:10:42.322965
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Assert result equals to expected
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 5) == ImmutableList.of(5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 3) == ImmutableList.of(4, 5)

# Generated at 2022-06-24 00:10:45.780722
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1, 2, 3)
    assert l.find(lambda x: x == 2) == 2
    assert l.find(lambda x: x == 0) is None


# Generated at 2022-06-24 00:10:49.820566
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 1)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1)

# Generated at 2022-06-24 00:10:52.509025
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, v: acc+v, 0) == 6

# Generated at 2022-06-24 00:10:55.150544
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_list.reduce(lambda acc, x: x + acc, 0) == 15

# Generated at 2022-06-24 00:10:59.792715
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert [1, 2, 3] == immutable_list.to_list()



# Generated at 2022-06-24 00:11:02.137680
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    assert ImmutableList.of(1).unshift(0) == ImmutableList(0, ImmutableList(1))
    assert ImmutableList.of().unshift(0) == ImmutableList(0)


# Generated at 2022-06-24 00:11:04.592184
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    a = ImmutableList.of(1,2,3,4,5)
    assert(a.to_list() == [1,2,3,4,5])


# Generated at 2022-06-24 00:11:07.908710
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    myList = ImmutableList.of(1, 2, 3, 4)
    assert myList.find(lambda x: x == 3) == 3 
    assert myList.find(lambda x: x == 5) is None

# Generated at 2022-06-24 00:11:09.985321
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6

# Generated at 2022-06-24 00:11:13.730322
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    t = ImmutableList.of(1, 2, 3, 4, 5)
    assert len(t) == 5

# Generated at 2022-06-24 00:11:21.298676
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6), True), True), True), True), True) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))


# Generated at 2022-06-24 00:11:23.640079
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]

# Generated at 2022-06-24 00:11:29.402309
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList(1, ImmutableList(2))
    b = ImmutableList(2, ImmutableList(1))
    c = ImmutableList(1, ImmutableList(2))
    assert a != b
    assert a == c


# Generated at 2022-06-24 00:11:39.922425
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_case_success = [
        {
            'input': {
                'func': lambda a: a == 1,
                'list': ImmutableList(1, ImmutableList(2, ImmutableList(3)))
            },
            'expected': 1
        },
    ]

    test_case_failure = [
        {
            'input': {
                'func': lambda a: a,
                'list': ImmutableList(1, ImmutableList(2, ImmutableList(3)))
            },
            'expected': None
        },
        {
            'input': {
                'func': lambda a: a == 4,
                'list': ImmutableList(1, ImmutableList(2, ImmutableList(3)))
            },
            'expected': None
        },
    ]


# Generated at 2022-06-24 00:11:48.496325
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)).unshift(0) == ImmutableList(0, ImmutableList(1, ImmutableList(2)))
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x + 1) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 2) == ImmutableList(2)

# Generated at 2022-06-24 00:11:52.518543
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-24 00:12:01.053327
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.empty().unshift(2).unshift(1) == ImmutableList.of(1, 2)
    assert ImmutableList.empty().unshift(3).unshift(2).unshift(1) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty().unshift(4).unshift(3).unshift(2).unshift(1) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.empty().unshift(5).unshift(4).unshift(3).unshift(2).unshift(1) == ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:12:08.953128
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList(None, None, True)
    assert ImmutableList(1) == ImmutableList(1, None)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, None))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, None)))
    
    assert ImmutableList.empty() != ImmutableList(1, None)
    assert ImmutableList(1) != ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, None))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, None))) != ImmutableList(1, ImmutableList(4, ImmutableList(3, None)))
#

# Generated at 2022-06-24 00:12:18.930300
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    f1_list = ImmutableList.of('f1')
    f2_list = ImmutableList.of('f2')
    f1f2_list = ImmutableList.of('f1', 'f2')
    f2f1_list = ImmutableList.of('f2', 'f1')
    f3f2f1_list = ImmutableList.of('f3', 'f2', 'f1')
    empty_list = ImmutableList.empty()
    # ImmutableLists with same elements should be equal
    assert f1_list == ImmutableList.of('f1')
    assert f1f2_list == ImmutableList.of('f1', 'f2')
    assert f2f1_list == ImmutableList.of('f2', 'f1')
    assert f3f2f

# Generated at 2022-06-24 00:12:27.585161
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    a = ImmutableList(1)
    b = a.append(2) # append new item
    c = b.append(3) # append new item
    assert b == ImmutableList(1, ImmutableList(2))
    assert c == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert b is not a
    assert c is not b
    assert c is not a
    
test_ImmutableList_append()

# Generated at 2022-06-24 00:12:32.375329
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    test_list = ImmutableList.of(2, 3, 4)
    assert (test_list + ImmutableList.of(5, 6, 7)).to_list() == [2, 3, 4, 5, 6, 7]


# Generated at 2022-06-24 00:12:33.940321
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)


# Generated at 2022-06-24 00:12:39.606007
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    test_immutable_list = ImmutableList.of(1, 2, 3)
    assert str(test_immutable_list) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:12:44.697315
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Given
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    expected_immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    # When
    new_immutable_list = immutable_list.append(4)

    # Then
    assert expected_immutable_list == new_immutable_list



# Generated at 2022-06-24 00:12:49.001459
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(2, 3, 4).reduce(lambda a, x: a + x, 0) == 9

    assert ImmutableList.of(2, 3, 4).reduce(lambda a, x: a + x, 1) == 10


test_ImmutableList_reduce()

# Generated at 2022-06-24 00:12:54.031875
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList(1, ImmutableList(2), )
    b = ImmutableList(3, ImmutableList(4))
    result = a + b
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) == result



# Generated at 2022-06-24 00:12:59.739607
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) + ImmutableList.empty() == ImmutableList(1)



# Generated at 2022-06-24 00:13:02.955136
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    new_list = ImmutableList(1).append(2)
    
    assert ImmutableList(1, ImmutableList(2)) == new_list


# Generated at 2022-06-24 00:13:07.841097
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)



# Generated at 2022-06-24 00:13:11.316431
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    sequence = ImmutableList.of(1, 2, 3, 4)
    assert sequence.find(lambda x: x == 3) == 3
    assert sequence.find(lambda x: x == 5) is None



# Generated at 2022-06-24 00:13:14.070699
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_a = ImmutableList.of(1, 2, 3)
    assert list_a.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:13:17.634529
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    """
    Test base constructor
    """
    immut_list = ImmutableList()
    assert immut_list.head is None
    assert immut_list.tail is None
    assert immut_list.is_empty is False



# Generated at 2022-06-24 00:13:26.237329
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty1 = ImmutableList.empty()
    empty2 = ImmutableList.empty()
    assert empty1 == empty2
    assert empty2 == empty1

    lst = ImmutableList.of(1, 2, 3)

    assert (lst == lst) == True

    assert lst == ImmutableList.of(1, 2, 3) == True

    assert (lst == ImmutableList.of(1, 2, 4)) == False
    assert (lst == ImmutableList.of(1, 3, 3)) == False
    assert (lst == ImmutableList.of(0, 1, 2, 3)) == False


# Generated at 2022-06-24 00:13:31.135093
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Test 1
    immutable_list1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list1.__len__() == len(immutable_list1.to_list())

    # Test 2
    immutable_list2 = ImmutableList.of(1, 2, 3, 4, 5)
    assert not immutable_list2.__len__() == 0

    # Test 3
    immutable_list3 = ImmutableList.empty()
    assert immutable_list3.__len__() == 0


# Generated at 2022-06-24 00:13:37.626949
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)) == 8
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 10
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-24 00:13:45.957592
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():    # pragma: no cover
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of()) == 'ImmutableList[]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1) + ImmutableList.of(2)) == 'ImmutableList[1, 2]'



# Generated at 2022-06-24 00:13:52.488020
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x > 3) == ImmutableList.empty()

    assert ImmutableList(
        1,
        ImmutableList(
            2,
            ImmutableList(
                3,
                ImmutableList(
                    4,
                    ImmutableList(
                        5
                    )
                )
            )
        )
    ).filter(lambda x: x > 3) == ImmutableList(
        4,
        ImmutableList(
            5
        )
    )


# Generated at 2022-06-24 00:13:55.805124
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 2)) == 'ImmutableList[1, 2, 2]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of()) == 'ImmutableList[]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'


# Generated at 2022-06-24 00:14:04.362597
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    t1 = ImmutableList.of(*[0, 1, 2, 3, 4])
    t2 = ImmutableList.of(5)
    t3 = ImmutableList.empty()

    t4 = t1.append(5)
    t5 = t2.append(5)
    t6 = t3.append(5)

    assert t4.to_list() == [0, 1, 2, 3, 4, 5]
    assert t5.to_list() == [5, 5]
    assert t6.to_list() == [5]


# Generated at 2022-06-24 00:14:11.606321
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    sample = ImmutableList.of(1, 2, 4, 5)
    assert sample.head == 1
    assert sample.tail.head == 2
    assert sample.tail.tail.head == 4
    assert sample.tail.tail.tail.head == 5
    assert sample.tail.tail.tail.tail is None
    assert sample.to_list() == [1, 2, 4, 5]
    assert sample == ImmutableList(1, ImmutableList(2, ImmutableList(4, ImmutableList(5))))


# Generated at 2022-06-24 00:14:17.443282
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == str([1])
    assert str(ImmutableList(1, ImmutableList(2))) == str([1,2])
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))) == str([1,2,3,4,5])

# Generated at 2022-06-24 00:14:20.995915
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(head=10, tail=ImmutableList(head=20, tail=ImmutableList(head=30, tail=ImmutableList(head=40))))) == "[10, 20, 30, 40]"

# Generated at 2022-06-24 00:14:30.307715
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Test for function filter on class ImmutableList
    """
    assert ImmutableList.of().filter(lambda x: True) == ImmutableList.of()
    assert ImmutableList.of(1).filter(lambda x: True) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).filter(lambda x: True) == ImmutableList.of(1, 2)
    assert ImmutableList.of().filter(lambda x: False) == ImmutableList.of()
    assert ImmutableList.of(1).filter(lambda x: False) == ImmutableList.of()
    assert ImmutableList.of(1, 2).filter(lambda x: False) == ImmutableList.of()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == Immutable

# Generated at 2022-06-24 00:14:35.166176
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    data = ImmutableList.empty().append(1).append(2).append(3).append(4)

    assert data.find(lambda x: x == 2) == 2
    assert data.find(lambda x: x == 9) is None
    assert data.find(lambda x: x == 1) == 1
    assert data.find(lambda x: x == 4) == 4
    assert data.find(lambda x: x == 7) is None

# Generated at 2022-06-24 00:14:40.478950
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # arrange
    list_input = ImmutableList(1, ImmutableList(2))
    exp_output = ImmutableList(1, ImmutableList(4))

    # act
    out = list_input.map(lambda x: x * 2)

    # assert
    assert(out == exp_output)

# Generated at 2022-06-24 00:14:43.951728
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(1, 2, 3)
    acc = list_.reduce(lambda acc, element: acc + element, 0)
    assert acc == 6



# Generated at 2022-06-24 00:14:52.103067
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_to_map = ImmutableList.of(1, 4, 6, 8)
    assert list_to_map.map(lambda x: x + 1) == ImmutableList.of(2, 5, 7, 9)
    assert list_to_map.map(lambda x: x * x) == ImmutableList.of(1, 16, 36, 64)
    assert list_to_map.map(lambda x: x ** 3) == ImmutableList.of(1, 64, 216, 512)
    assert list_to_map.map(lambda x: x + 2) == ImmutableList.of(3, 6, 8, 10)
    assert list_to_map.map(lambda x: x + 3) == ImmutableList.of(4, 7, 9, 11)

# Generated at 2022-06-24 00:14:54.202404
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:15:00.944414
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_list = ImmutableList.empty()
    assert empty_list.find(lambda x: x is not None) is None

    list1 = ImmutableList(5)
    assert list1.find(lambda x: x is not None) is 5

    list2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list2.find(lambda x: x == 4) is None
    assert list2.find(lambda x: x == 2) is 2



# Generated at 2022-06-24 00:15:04.568938
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(3)) == 'ImmutableList[3]'
    assert str(ImmutableList(3, ImmutableList(4))) == 'ImmutableList[3, 4]'

# Generated at 2022-06-24 00:15:07.752348
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    actual = ImmutableList.of(1,2,3) + ImmutableList.of(4,5,6)
    expected = ImmutableList.of(1,2,3,4,5,6)
    assert actual == expected



# Generated at 2022-06-24 00:15:09.855545
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList.of(2, 3)
    second = ImmutableList.of(2, 3)

    assert first == second

    assert first != ImmutableList.of(3, 2)



# Generated at 2022-06-24 00:15:18.305852
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1) + ImmutableList.of(2) + ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) != 1


# Generated at 2022-06-24 00:15:30.357919
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(1, ImmutableList()) == ImmutableList(1, ImmutableList())
    assert ImmutableList(1, ImmutableList()) != ImmutableList(1)
    assert ImmutableList(1, ImmutableList()) != ImmutableList()
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-24 00:15:37.498382
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    lst = ImmutableList.of(1, 2, 3, 4)
    assert lst.to_list() == [1, 2, 3, 4]

    assert lst.tail.tail.tail.to_list() == [4]
    assert lst.find(lambda x: x == 1) == 1
    assert lst.find(lambda x: x == 5) is None

    assert lst.reduce(lambda acc, x: acc + x, 0) == 10
    assert lst.filter(lambda x: x > 2).to_list() == [3, 4]
    assert lst.map(lambda x: x + 1).to_list() == [2, 3, 4, 5]
    assert lst.append(5).to_list() == [1, 2, 3, 4, 5]
    assert lst

# Generated at 2022-06-24 00:15:48.766213
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__(): # pragma: no cover
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) + ImmutableList.empty() == ImmutableList.of(1)
    assert ImmutableList.empty() + ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + Immutable

# Generated at 2022-06-24 00:15:55.503982
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(1) == ImmutableList.of(1, 1)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.empty().append(4) == ImmutableList.of(4)


# Generated at 2022-06-24 00:15:58.357969
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)


# Generated at 2022-06-24 00:16:08.560904
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():  # pragma: no cover
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 2).to_list() == [2, 4, 6]
    assert ImmutableList.of(1, 2).map(lambda x: x * 2).to_list() == [2, 4]
    assert ImmutableList.of(1).map(lambda x: x * 2).to_list() == [2]
    assert ImmutableList.empty().map(lambda x: x * 2).to_list() == []
    assert ImmutableList.of(3, 5, 6).map(lambda x: x * 2).to_list() == [6, 10, 12]



# Generated at 2022-06-24 00:16:12.526575
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList.of(1, 2, 3, 4)
    new_element = 5
    expected_result = ImmutableList.of(1, 2, 3, 4, 5)

    result = test_list.append(new_element)

    assert expected_result == result



# Generated at 2022-06-24 00:16:18.992047
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f', 'g')
    filter_list = list_.filter(lambda letter: letter > 'c')

    assert filter_list == ImmutableList.of('d', 'e', 'f', 'g')



# Generated at 2022-06-24 00:16:28.206813
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 2) == ImmutableList.of(3)

    assert ImmutableList.of(1).map(lambda x: x + 2).map(lambda x: x + 2) \
        == ImmutableList.of(3).map(lambda x: x + 2)

    assert ImmutableList.of(1, 2, 3) \
        .map(lambda x: x + 2) \
        .map(lambda x: x * 2) == ImmutableList.of(6, 8, 10)


# Generated at 2022-06-24 00:16:31.791720
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert(str(ImmutableList.of(20)) == 'ImmutableList[20]')
    assert(str(ImmutableList.of(20, 'Hello')) == 'ImmutableList[20, Hello]')
    assert(str(ImmutableList.of(20, 'Hello', 'world')) == 'ImmutableList[20, Hello, world]')
test_ImmutableList___str__()


# Generated at 2022-06-24 00:16:36.214452
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(4).__eq__(ImmutableList(4))
    assert ImmutableList(4).__eq__(ImmutableList(4, ImmutableList(5, ImmutableList(6))))
    assert ImmutableList(4) == 4
    assert ImmutableList(4, ImmutableList(5, ImmutableList(6))) == ImmutableList(4, ImmutableList(5, ImmutableList(6)))
    assert ImmutableList(4, ImmutableList(5, ImmutableList(6))) == 5

# Generated at 2022-06-24 00:16:44.627081
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # prepare
    data = [1, 2, 3]
    expected_result = 'ImmutableList[1, 2, 3]'

    # run
    result = ImmutableList.of(1, 2, 3).__str__()

    # assert
    assert(expected_result == result)

    # run
    result = ImmutableList.of(1, 2, 3).to_list()

    # assert
    assert(data == result)

test_ImmutableList___str__()

# Generated at 2022-06-24 00:16:50.070001
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    test_value = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    expected_value = 'ImmutableList[1, 2, 3]'
    assert str(test_value) == expected_value


# Generated at 2022-06-24 00:16:53.415433
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # setup
    def sum_elements(a, b):
        return a + b

    # execute
    result = ImmutableList.empty().reduce(sum_elements, 0)

    # assert
    assert result == 0