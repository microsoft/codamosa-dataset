

# Generated at 2022-06-24 00:07:04.321024
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    l1 = ImmutableList(1)
    assert(l1.head == 1)
    assert(l1.tail == None)
    l2 = ImmutableList(2, l1)
    assert(l2.head == 2)
    assert(l2.tail.head == 1)
    assert(l2.tail.tail == None)
    assert(l2.tail.is_empty == False)
    l3 = ImmutableList(3, l2)
    assert(l3.head == 3)
    assert(l3.tail.head == 2)
    assert(l3.tail.tail.head == 1)
    assert(l3.tail.tail.tail == None)
    assert(l3.tail.tail.is_empty == False)
    assert(l3.tail.is_empty == False)


# Generated at 2022-06-24 00:07:11.686987
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(0, 1, 2).find(lambda x: x == 1) == 1
    assert ImmutableList.of(0, 1, 2).find(lambda x: x == 2) == 2
    assert ImmutableList.of(0, 1, 2).find(lambda x: x == 3) is None
    assert ImmutableList.of(0, 1, 2).find(lambda x: x == 4) is None
    assert ImmutableList.empty().find(lambda x: x == 4) is None


# Generated at 2022-06-24 00:07:17.998216
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(4, ImmutableList(5, ImmutableList(6)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList() != ImmutableList(1)

# Unit

# Generated at 2022-06-24 00:07:23.682827
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    '''
    Unit test for method __eq__ of class ImmutableList
    '''
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = ImmutableList.of(1, 2, 3, 4, 5)
    list3 = ImmutableList.of(1, 2, 3, 4, 5)
    result = list1 == list2
    
    assert result == True



# Generated at 2022-06-24 00:07:32.167451
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_a = ImmutableList(1, ImmutableList(2))
    list_b = ImmutableList.of(1, 2)
    list_c = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_d = ImmutableList.of(1, 2, 3)

    assert list_a + ImmutableList(3) == list_c
    assert list_b.append(3) == list_c
    assert list_b + ImmutableList.of(3) == list_c
    assert list_a + ImmutableList.of(3) == list_c
    assert list_a.append(3) == list_c
    assert list_b + ImmutableList(3) == list_c

    assert list_c + ImmutableList(4) == list_d
    assert list_

# Generated at 2022-06-24 00:07:43.297201
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.find(lambda x: x > 2) == 3

    list_ = ImmutableList.of('a', 'b', 'c')
    assert list_.find(lambda x: x == 'c') == 'c'

    list_ = ImmutableList.of('a', 'b', 'c')
    assert list_.find(lambda x: x == 'd') is None

    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.find(lambda x: x > 4) is None

    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.find(lambda x: x < 0) is None

    list_ = ImmutableList.of(1)

# Generated at 2022-06-24 00:07:48.267009
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:07:52.977599
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of(1, 2)
    list_2 = ImmutableList.of(1, 2)
    list_3 = ImmutableList.of(2, 3)

    assert list_1 == list_2, 'ImmutableList__eq__: equality test'
    assert list_1 != list_3, 'ImmutableList__eq__: not equality test'


# Generated at 2022-06-24 00:07:55.458753
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList(1).append(2)
    result = ImmutableList(1, ImmutableList(2))
    assert test_list == result

# Generated at 2022-06-24 00:08:02.588996
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Test for ImmutableList without parameter
    ImmutableList().to_list() == []
    # Test for ImmutableList with parameter
    ImmutableList(5).to_list() == [5]
    # Test for ImmutableList with parameters
    ImmutableList(5, ImmutableList(6)).to_list() == [5, 6]
    # Test for ImmutableList with parameters
    ImmutableList(5, ImmutableList(6, ImmutableList(7))).to_list() == [5, 6, 7]
    # Test for ImmutableList with parameters
    ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8)))).to_list() == [5, 6, 7, 8]
    # Test for ImmutableList with parameters

# Generated at 2022-06-24 00:08:04.459197
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list = ImmutableList.of(3, 1, 2)
    assert len(list) == 3


# Generated at 2022-06-24 00:08:11.962898
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    test_list = ImmutableList()

    assert 0 == len(test_list)

    test_list = ImmutableList('test')
    assert 1 == len(test_list)

    test_list = ImmutableList(1, ImmutableList(2))
    assert 2 == len(test_list)
    assert 1 == len(test_list.tail)
    assert isinstance(test_list.tail, ImmutableList)
    
    test_list = ImmutableList.of(1, 2, 3)
    assert 3 == len(test_list)
    assert 2 == len(test_list.tail)
    

# Generated at 2022-06-24 00:08:21.633922
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list_of_num = ImmutableList.of(1, 2, 3)
    list_of_str = ImmutableList.of('apple', 'orange', 'banana', 'melon')
    empty_list = ImmutableList.empty()

    assert list_of_num.to_list() == [1, 2, 3]
    assert list_of_num.head == 1
    assert list_of_num.tail is not None
    assert list_of_str.tail is not None
    assert list_of_str.head == 'apple'
    assert list_of_str.is_empty is False
    assert empty_list.is_empty is True

# Generated at 2022-06-24 00:08:28.299459
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Empty list
    assert ImmutableList.empty().reduce(lambda acc: acc, '') == ''

    # One element in list
    assert ImmutableList.of('abc').reduce(lambda acc,a: '{acc}{a}'.format(
        acc=acc,
        a=a
    ), '') == 'abc'

    # Many elements in list
    assert ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f').reduce(lambda acc,a: '{acc}{a}'.format(
        acc=acc,
        a=a
    ), '') == 'abcdef'

# Generated at 2022-06-24 00:08:33.042111
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(1))



# Generated at 2022-06-24 00:08:36.760879
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    source = ImmutableList(1, ImmutableList(2), ImmutableList(3))
    expected = ImmutableList(2, ImmutableList(4), ImmutableList(6))
    result = source.map(lambda x: x * 2)
    assert result == expected


# Generated at 2022-06-24 00:08:43.401325
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList(1).unshift(2) == ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2)).unshift(3) == ImmutableList(3, ImmutableList(1, ImmutableList(2)))


# Generated at 2022-06-24 00:08:47.570935
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Arrange
    def add(a, b): return a + b

    # Act
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    result = immutable_list.reduce(add, 0)
    expected = 15
    # Assert
    assert result == expected


# Generated at 2022-06-24 00:08:55.946089
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList(1, ImmutableList(2))
    list2 = ImmutableList(1, ImmutableList(2))
    list3 = ImmutableList(2, ImmutableList(1))
    list4 = ImmutableList(None)
    list5 = ImmutableList(None)

    assert list1 == list1
    assert list1 == list2
    assert list1 != list3
    assert list4 == list4
    assert list4 == list5
    assert list4 != list2
    

# Generated at 2022-06-24 00:09:00.215625
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    immutable_list = ImmutableList.of(0)
    immutable_list = immutable_list.append(1)

    assert immutable_list == ImmutableList(0, ImmutableList(1))

    immutable_list = immutable_list.append(2)

    assert immutable_list == ImmutableList(0, ImmutableList(1, ImmutableList(2)))


# Generated at 2022-06-24 00:09:04.095927
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList[1, 2, 3]' == str(ImmutableList.of(1, 2, 3))
    assert 'ImmutableList[]' == str(ImmutableList.empty())


# Generated at 2022-06-24 00:09:07.310011
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2), True)) == 'ImmutableList[1, 2]'


# Generated at 2022-06-24 00:09:14.919085
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    il = ImmutableList.of(1)
    assert(il.to_list() == [1])
    il = ImmutableList.of(1,2,3,4)
    assert(il.to_list() == [1,2,3,4])
    il = ImmutableList.empty()
    assert(il.to_list() == [])

# Generated at 2022-06-24 00:09:21.539806
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.empty()

    list1_reduced = list1.reduce(lambda a, b: a + b, 0)
    list2_reduced = list2.reduce(lambda a, b: a + b, 0)

    assert list1_reduced == 6
    assert list2_reduced == 0

# Generated at 2022-06-24 00:09:23.231809
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:09:26.146369
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(4, 5, 6)
    assert (list1 + list2) == ImmutableList.of(1, 2, 3, 4, 5, 6)



# Generated at 2022-06-24 00:09:28.987275
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of('test', 'fdsf')) == 2
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-24 00:09:32.174941
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    data = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert data.append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))



# Generated at 2022-06-24 00:09:40.479389
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 0) == 0
    assert ImmutableList.of(5).reduce(lambda x, y: x + y, 0) == 5
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x + y, 0) == 10
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x + y, 10) == 20
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x * y, 1) == 24
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x * y, 10) == 240

test_ImmutableList_reduce()

# Unit test

# Generated at 2022-06-24 00:09:44.989300
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x % 3 == 0) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 10) is None



# Generated at 2022-06-24 00:09:47.458276
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    ImmutableList.of(3, 2, 1).map(lambda x: x*2) == ImmutableList.of(6, 4, 2)
    

# Generated at 2022-06-24 00:09:54.708708
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():  # pragma: no cover
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList(1).unshift(2) == ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).unshift(4) \
        == ImmutableList(4, ImmutableList(1, ImmutableList(2), ImmutableList(3)))

# Generated at 2022-06-24 00:09:59.006409
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3)
    list3 = ImmutableList.of(4, 5, 6)

    assert list1 == list2
    assert list1 != list3


# Generated at 2022-06-24 00:10:02.526643
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList.of('1', '2', '3')
    list_2 = ImmutableList.of('1', '2', '3')
    list_3 = ImmutableList.empty()

    assert list_1 == list_2
    assert list_1 != list_3



# Generated at 2022-06-24 00:10:08.160914
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 5, 8).filter(
        lambda x: x % 2 == 0
    ) == ImmutableList.of(2, 8)

# Generated at 2022-06-24 00:10:14.516761
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    empty_list = ImmutableList.empty()
    one_element_list = ImmutableList(1)
    many_elements_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert empty_list.to_list() == []
    assert one_element_list.to_list() == [1]
    assert many_elements_list.to_list() == [1, 2, 3]

# Generated at 2022-06-24 00:10:19.292921
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'

# Generated at 2022-06-24 00:10:28.309831
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__(): # pragma: no cover
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 'ImmutableList[1, 2, 3, 4]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))) == 'ImmutableList[1, 2, 3, 4, 5]'


# Generated at 2022-06-24 00:10:38.309984
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def is_even(n):
        return n % 2 == 0

    assert ImmutableList.of(
        1, 2, 3, 4, 5
    ).filter(is_even).to_list() == [2, 4]

    assert ImmutableList.of(
        1, 3, 5, 7, 9
    ).filter(is_even).to_list() == []

    assert ImmutableList.of(
        2, 4, 6, 8, 10
    ).filter(is_even).to_list() == [2, 4, 6, 8, 10]

    assert ImmutableList.empty().filter(is_even).to_list() == []



# Generated at 2022-06-24 00:10:45.123130
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of(1, 2, 3, 4)
    second_list = ImmutableList.of(5, 6, 7, 8)
    result = first_list + second_list
    assert result.to_list() == [1, 2, 3, 4, 5, 6, 7, 8]


# Generated at 2022-06-24 00:10:46.858186
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4, 5)) == "ImmutableList[1, 2, 3, 4, 5]"


# Generated at 2022-06-24 00:10:52.956537
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():

    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList('a')) == 'ImmutableList[a]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList('a', ImmutableList('b', ImmutableList('c')))) == 'ImmutableList[a, b, c]'
    assert str(ImmutableList(is_empty=True)) == 'ImmutableList[]'



# Generated at 2022-06-24 00:10:58.727774
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) is 3

test_ImmutableList_find()


# Generated at 2022-06-24 00:11:03.389134
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(123) == ImmutableList(123) 

    list_1 = ImmutableList.of(1)
    list_2 = list_1.unshift(2)
    list_3 = ImmutableList(2, list_1)

    assert list_2 == list_3



# Generated at 2022-06-24 00:11:15.675787
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    empty_list = ImmutableList()
    assert empty_list.is_empty

    list = ImmutableList(4)
    assert not list.is_empty

    list2 = ImmutableList(4, ImmutableList(5))
    list3 = ImmutableList(5, ImmutableList(5))
    assert len(list2) == 2
    assert list2 + list3 == ImmutableList(4, ImmutableList(5, ImmutableList(5, ImmutableList(5))))

    assert ImmutableList(1) + ImmutableList(2) == \
        ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-24 00:11:25.239568
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert a.map(lambda x: x + x) == ImmutableList(2, ImmutableList(4, ImmutableList(6)))
    assert a.map(lambda x: x ** 2) == ImmutableList(1, ImmutableList(4, ImmutableList(9)))
    assert a.map(lambda x: str(x) + "BB") == ImmutableList("1BB", ImmutableList("2BB", ImmutableList("3BB")))

# Pass all the test cases
test_ImmutableList_map()

# Generated at 2022-06-24 00:11:28.138373
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    result = ImmutableList.of(2, 3, 4).reduce(lambda x, y: x + y, 0)
    assert result == 9

test_ImmutableList_reduce()

# Generated at 2022-06-24 00:11:34.237986
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    immutabl_list = ImmutableList.of(1, 2, 3, 4, 5)

    def mapper(element):
        return element * element

    assert immutabl_list.map(mapper).to_list() == [1, 4, 9, 16, 25], 'ImmutableList map method should return new ImmutableList with mapped elements'

# Generated at 2022-06-24 00:11:41.606246
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_A = ImmutableList.of(1, 2, 3)
    assert list_A.find(lambda x: x == 1) == 1
    assert list_A.find(lambda x: x == 2) == 2
    assert list_A.find(lambda x: x == 3) == 3
    assert list_A.find(lambda x: x == 4) is None
    assert list_A.find(lambda x: x == 5) is None

# Generated at 2022-06-24 00:11:47.845023
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(ImmutableList(4)))
    assert ImmutableList(1) == ImmutableList(1)

# Generated at 2022-06-24 00:11:52.310096
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Define test_ImmutableList_reduce test case
    numbers = ImmutableList.of(1, 2, 3)
    # Define expected value
    expected = 6
    assert numbers.reduce(lambda acc, x: acc + x, 0) == expected

# Generated at 2022-06-24 00:11:55.830351
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList.of(1, 2, 3)

    assert isinstance(immutable_list, ImmutableList) is True


# Generated at 2022-06-24 00:12:00.701857
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList()) == ImmutableList(1, ImmutableList())
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).tail == ImmutableList(2)


# Generated at 2022-06-24 00:12:03.725130
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    original_list = ImmutableList.of(1, 2, 3)
    new_list = original_list.append(4)
    assert new_list == ImmutableList.of(1, 2, 3, 4)
    assert original_list == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:12:07.052987
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    from hypothesis import given
    from hypothesis.strategies import text

    @given(text())
    def test(value):
        assert ImmutableList(value).append(value) == ImmutableList(value, ImmutableList(value))

    test()

# Generated at 2022-06-24 00:12:09.169872
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    lst = ImmutableList.empty()
    lst = lst.append('D')
    assert lst.to_list() == ['D']
    lst = lst.append('C')
    assert lst.to_list() == ['D', 'C']
    lst = lst.append('B')
    assert lst.to_list() == ['D', 'C', 'B']


# Generated at 2022-06-24 00:12:19.068819
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(4, 5, 6)
    expected = a + b
    assert expected == ImmutableList.of(1, 2, 3, 4, 5, 6) and a == ImmutableList.of(1, 2, 3) and b == ImmutableList.of(4, 5, 6)
    assert not(expected == ImmutableList.of(1, 2, 3, 4, 5)) and not(expected == ImmutableList.of(1, 2))
    assert not(expected == ImmutableList.of(1, 2, 3, 4, 6)) and not(expected == ImmutableList.of(1, 2, 3, 4, 5, 5))

# Generated at 2022-06-24 00:12:25.186670
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList(5).unshift(6) == ImmutableList(6, ImmutableList(5))\
        , 'ImmutableList: unshift_method should return new ImmutableList with argument value on the begin of list and other list elements after it'


# Generated at 2022-06-24 00:12:28.230956
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l = ImmutableList.of(1, 2, 3, 4)
    assert l + ImmutableList(5) == ImmutableList(1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:12:36.373984
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    myList = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert myList.find(lambda x: x==1) == 1
    assert myList.find(lambda x: x > 1) == 2
    assert myList.find(lambda x: x<4) == 1
    assert myList.find(lambda x: x==4) == 4
    assert myList.find(lambda x: x==5) is None
    assert ImmutableList().find(lambda x: x==1) is None

# Generated at 2022-06-24 00:12:39.628518
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0, 'Should have length of 0'
    assert len(ImmutableList(1)) == 1, 'Should have length of 1'
    assert len(ImmutableList(1, ImmutableList(2))) == 2, 'Should have length of 2'

# Generated at 2022-06-24 00:12:49.117137
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # init new empty ImmutableList instance
    empty_ImmutableList = test_ImmutableList_empty_init()
    # init new ImmutableList instance with value inside
    ImmutableList_with_value = test_ImmutableList_init()
    # init new ImmutableList instance with value inside and tail
    ImmutableList_with_value_and_tail = test_ImmutableList_init_with_tail()
    # init new ImmutableList instance with value inside, tail and __add__
    ImmutableList_with_value_tail_add = test_ImmutableList_init_with_tail_add()

    assert empty_ImmutableList.to_list() == []
    assert ImmutableList_with_value.to_list() == [1]

# Generated at 2022-06-24 00:12:56.408501
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of('a', 'b', 'c').to_list() == ['a', 'b', 'c']

# Generated at 2022-06-24 00:12:59.954301
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of('a').append('b') == ImmutableList.of('a', 'b')
    assert ImmutableList.of('a', 'b').append('c') == ImmutableList.of('a', 'b', 'c')


# Generated at 2022-06-24 00:13:03.637202
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2).append(3).append(4) == ImmutableList.of(1, 2, 3, 4)


test_ImmutableList_append()

# Generated at 2022-06-24 00:13:11.030495
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x * x) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).map(lambda x: x + x) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * x) == ImmutableList.of(1, 4, 9)


# Generated at 2022-06-24 00:13:16.059319
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.empty()
    new_list = list.unshift(1)
    assert new_list == ImmutableList(1)

test_ImmutableList_unshift()



# Generated at 2022-06-24 00:13:20.322425
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(4).to_list() == [4, 1, 2, 3]
    assert ImmutableList.of(1).unshift(4).to_list() == [4, 1]


# Generated at 2022-06-24 00:13:24.682828
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    with pytest.raises(TypeError):
        ImmutableList()

    assert ImmutableList('test')
    assert ImmutableList(is_empty=True)
    assert ImmutableList(1)
    assert ImmutableList('test', ImmutableList('test'))


# Generated at 2022-06-24 00:13:29.463934
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Prepare
    list_of_numbers: ImmutableList[int] = ImmutableList.of(1, 2, 3, 4, 5)

    # Execute
    doubled_list: ImmutableList[int] = list_of_numbers.map(lambda number: number * 2)

    # Verify

    # Teardown
    assert doubled_list == ImmutableList.of(2, 4, 6, 8, 10)


# Generated at 2022-06-24 00:13:34.805804
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1) == ImmutableList().append(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1).append(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1).append(2).append(3)



# Generated at 2022-06-24 00:13:41.921411
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    test_cases = [
        {
            'name': 'valid-one-elements-list',
            'args': [1],
            'expected_len': 1,
        },
        {
            'name': 'valid-two-elements-list',
            'args': [1, 4],
            'expected_len': 2,
        },
        {
            'name': 'valid-empty-list',
            'args': [],
            'expected_len': 0,
        },
    ]

    for test_case in test_cases:
        imm_list = ImmutableList.of(*test_case['args'])
        assert len(imm_list) == test_case['expected_len'], '%s failed' % (test_case['name'])



# Generated at 2022-06-24 00:13:46.486101
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3, 4)) == 'ImmutableList[1, 2, 3, 4]'



# Generated at 2022-06-24 00:13:48.546118
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:13:53.849851
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of(1, 2, 3)
    second_list = ImmutableList.of(4)
    result = first_list.__add__(second_list)
    expected_result = ImmutableList.of(1, 2, 3, 4)
    if result != expected_result:
        raise AssertionError('test_ImmutableList___add__ failed')

test_ImmutableList___add__()

# Generated at 2022-06-24 00:13:57.376874
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)).filter(lambda x: x < 3).to_list() == [1, 2]

test_ImmutableList_filter()


# Generated at 2022-06-24 00:14:01.275117
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    """
    Test unshift method of ImmutableList class
    """
    list_ = ImmutableList().unshift(1)
    assert list_.to_list() == [1]



# Generated at 2022-06-24 00:14:04.725135
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(5) == ImmutableList(5)
    assert ImmutableList(1, ImmutableList(2)).append(5) == ImmutableList(1, ImmutableList(2, ImmutableList(5)))


# Generated at 2022-06-24 00:14:12.951447
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    empty = ImmutableList.empty()
    assert empty.to_list() == []

    head = ImmutableList('0')
    assert head.to_list() == ['0']

    head_tail = ImmutableList('0', ImmutableList('1'))
    assert head_tail.to_list() == ['0', '1']

    head_tail_tail = ImmutableList('0', ImmutableList('1', ImmutableList('2')))
    assert head_tail_tail.to_list() == ['0', '1', '2']



# Generated at 2022-06-24 00:14:16.535164
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(10, 12, 14, 16, 18)
    result = list_.reduce(lambda acc, v: acc + v, 0)
    assert result == 70



# Generated at 2022-06-24 00:14:19.769209
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.of(1, 2, 3)
    
    assert list.unshift(0) == ImmutableList.of(0, 1, 2, 3)


# Generated at 2022-06-24 00:14:25.137649
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x < 2) == 1
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x > 4) is None
    assert ImmutableList.empty().find(lambda x: x > 4) is None

# Generated at 2022-06-24 00:14:30.227042
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    empty_list = ImmutableList.empty()
    assert str(empty_list) == 'ImmutableList[]'

    list_ = ImmutableList.of(1, 2, 3)
    assert str(list_) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:14:33.172467
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]

# Generated at 2022-06-24 00:14:40.003057
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda i: i + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 1).map(lambda i: i + 1) == ImmutableList.of(2, 2)
    assert ImmutableList.empty().map(lambda i: i + 1) == ImmutableList.empty()


# Generated at 2022-06-24 00:14:50.365717
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    with pytest.raises(ValueError):  # what we expect
        print(ImmutableList.of(1, 2, 3) + 1)  # 1 + 1
    assert ImmutableList.of(1).unshift(2, 3) == ImmutableList.of(2, 1, 3)  # 3 1
    assert ImmutableList.of(1).unshift([1, 2]) == ImmutableList.of([1, 2], 1)
    assert ImmutableList.of(1).unshift(ImmutableList.of(1, 2)) == ImmutableList.of(ImmutableList.of(1, 2), 1)
    assert ImmutableList.empty().unshift(ImmutableList.of(1, 2)) == ImmutableList.of(ImmutableList.of(1, 2))


# Generated at 2022-06-24 00:15:00.859347
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)

    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)

    assert ImmutableList.of(1) == ImmutableList.of(1)

    assert ImmutableList.empty() == ImmutableList.empty()

    assert ImmutableList.empty().append(1) == ImmutableList.empty().append(1)

    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(1).unshift(2)

    assert ImmutableList.empty() != ImmutableList.empty().append(1)

    assert ImmutableList.empty() != ImmutableList.of(1)

    assert ImmutableList.of(1) != ImmutableList.of(2)

    assert Imm

# Generated at 2022-06-24 00:15:04.483417
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda acc, value: acc + value, 0) == 10

    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda acc, value: acc * value, 1) == 24


# Generated at 2022-06-24 00:15:08.988299
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    lst = ImmutableList.of(1, 2, 3)
    lst = lst.map(lambda x: x*2)
    assert lst.to_list() == [2, 4, 6]
    lst = ImmutableList.empty().map(lambda x: x*2)
    assert lst.to_list() == []


# Generated at 2022-06-24 00:15:16.153887
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda a, b: a * b, 1) == 120
    assert ImmutableList.of(6, 7, 8, 9, 10).reduce(lambda a, b: a + b, 0) == 40
    assert ImmutableList.of(1, -2, 3, -4, 5).reduce(lambda a, b: a + b, 0) == 3
    assert ImmutableList.of('a', 2, 3, -4, 5).reduce(lambda a, b: str(a) + str(b), '') == 'a23-45'
    assert ImmutableList.of(1, 2, 3, -4, 5).reduce(lambda a, b: a - b, 0) == -13

# Generated at 2022-06-24 00:15:24.329873
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    test_array_empty = ImmutableList(is_empty=True)
    test_array_one = ImmutableList('One')
    test_array_many = ImmutableList.of(1, 2, 3)
    
    
    assert test_array_empty.unshift(1) == ImmutableList.of(1)
    assert test_array_one.unshift(1) == ImmutableList.of(1, 'One')
    assert test_array_many.unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:15:29.611923
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Arrange
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    # Act
    result = str(list_)
    # Assert
    assert result == 'ImmutableList[1, 2, 3, 4]'



# Generated at 2022-06-24 00:15:34.565814
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    test_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
    assert test_list.find(lambda value: value == 10) == None
    assert test_list.find(lambda value: value == 7) == 7
    assert test_list.find(lambda value: value < 10) == 1
    assert test_list.find(lambda value: value > 10) == None



# Generated at 2022-06-24 00:15:37.050190
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3,4,5).filter(lambda x: x > 2) == ImmutableList.of(3,4,5)


# Generated at 2022-06-24 00:15:48.048517
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Unit test for filter method of ImmutableList class.

    Assertions:
        - ImmutableList.filter should return new ImmutableList with only
          this elements that passes info fn returns True
    """
    xs = ImmutableList.of(1, 2, 3, 4, 5)
    # test filter with even numbers
    assert xs.filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    # test filter with odd numbers
    assert xs.filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]
    # test filter with 2
    assert xs.filter(lambda x: x == 2).to_list() == [2]
    # test filter with 7
    assert xs.filter(lambda x: x == 7).to_list()

# Generated at 2022-06-24 00:15:49.405156
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1)) == 1

# Generated at 2022-06-24 00:15:58.226552
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).to_list() == [1, 2, 3, 4, 5, 6]
    assert ImmutableList.of(1, [1, 2], None, { 'a': 1 }).to_list() == [1, [1, 2], None, { 'a': 1 }]
    
    

# Generated at 2022-06-24 00:16:09.577320
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Create new instance of class ImmutableList
    list1 = ImmutableList()
    list2 = ImmutableList(1)
    list3 = ImmutableList(1, ImmutableList(2))

    # Check elements before adding new
    assert list1.to_list() == []
    assert list2.to_list() == [1]
    assert list3.to_list() == [1, 2]

    # Add new element on the begin of list
    list1 = list1.unshift(1)
    list2 = list2.unshift(2)
    list3 = list3.unshift(3)

    # Check elements after adding new
    assert list1.to_list() == [1]
    assert list2.to_list() == [2, 1]

# Generated at 2022-06-24 00:16:13.442780
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    empty_list = ImmutableList.empty()
    result = empty_list.unshift(1)
    expected_result = ImmutableList.of(1)

    assert result == expected_result, 'Test unshift on empty list failed'



# Generated at 2022-06-24 00:16:15.655951
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    test_list = ImmutableList.of(4, 5, 6, 7)

    assert test_list.to_list() == [4,5,6,7]

# Generated at 2022-06-24 00:16:18.024399
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)

test_ImmutableList___eq__()



# Generated at 2022-06-24 00:16:19.344581
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list1 = ImmutableList.of(1, 2, 3)
    assert str(list1) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:16:24.583242
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    il = ImmutableList.of(1, 2, 3)

    assert il.reduce(lambda acc, x: acc + x, 0) == 6
    assert il.reduce(lambda acc, x: acc * x, 1) == 6

# Generated at 2022-06-24 00:16:31.430703
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert len(immutable_list) == 5
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert len(immutable_list) == 7
    immutable_list = ImmutableList()
    assert len(immutable_list) == 0
    immutable_list = ImmutableList.of(1)
    assert len(immutable_list) == 1
test_ImmutableList___len__()



# Generated at 2022-06-24 00:16:37.348926
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Given
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    # When
    new_list = list_.map(lambda x: x ** 2)
    # Then
    assert new_list == ImmutableList(1, ImmutableList(4, ImmutableList(9)))
    assert list_.to_list() == [1,2,3]
    assert new_list.to_list() == [1,4,9]


# Generated at 2022-06-24 00:16:42.206951
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.of(1, 2, 3)
    assert list.unshift(0) == ImmutableList.of(0, 1, 2, 3)
    


# Generated at 2022-06-24 00:16:46.988028
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: x + y, "") == ""
    assert ImmutableList.of("1", "2", "3", "4").reduce(lambda x, y: x + y, "") == "1234"
    assert ImmutableList.of("1", "2", "3", "4").reduce(lambda x, y: x + y, "0") == "01234"



# Generated at 2022-06-24 00:16:54.538456
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of() == ImmutableList(is_empty=True)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))