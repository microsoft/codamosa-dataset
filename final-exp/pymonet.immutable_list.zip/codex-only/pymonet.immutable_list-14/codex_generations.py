

# Generated at 2022-06-24 00:07:02.310819
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    l0 = ImmutableList.empty()
    assert len(l0) == 0

    l1 = ImmutableList(12)
    assert len(l1) == 1

    l2 = ImmutableList(12, ImmutableList(10))
    assert len(l2) == 2

    l3 = ImmutableList(12, ImmutableList(10, ImmutableList(123)))
    assert len(l3) == 3

# Generated at 2022-06-24 00:07:12.041984
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1,2,3) + ImmutableList.of(4,5,6) == ImmutableList.of(1,2,3,4,5,6)
    assert ImmutableList.of(1,2,3) + ImmutableList.of(4,5,6) == ImmutableList.of(1,2,3,4,5,6)
    assert ImmutableList.empty() + ImmutableList.of(1,2,3) == ImmutableList.of(1,2,3)
    assert ImmutableList.of(1,2,3) + ImmutableList.empty() == ImmutableList.of(1,2,3)


# Generated at 2022-06-24 00:07:14.554781
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda a, b: a + b, 0) == 15


# Generated at 2022-06-24 00:07:25.058235
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(2)
    result = list1 + list2
    assert result.head == 1
    assert result.tail.head == 2
    assert result.tail.tail is None

    list3 = ImmutableList.of(3, 4, 5, 6)
    result = result + list3
    assert result.head == 1
    assert result.tail.head == 2
    assert result.tail.tail.head == 3
    assert result.tail.tail.tail.head == 4
    assert result.tail.tail.tail.tail.head == 5
    assert result.tail.tail.tail.tail.tail.head == 6
    assert result.tail.tail.tail.tail.tail.tail is None

    list4 = ImmutableList(7)
    result

# Generated at 2022-06-24 00:07:32.296239
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of(1, 2)
    second_list = ImmutableList.of(3, 4, 5)
    assert first_list + second_list == ImmutableList.of(1, 2, 3, 4, 5)
    assert first_list + second_list != ImmutableList.of(1, 2)

    with pytest.raises(ValueError):
        first_list + 'abc'


# Generated at 2022-06-24 00:07:37.317843
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():

    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(10)) == 'ImmutableList[10]'
    assert str(ImmutableList(10, ImmutableList(20))) == 'ImmutableList[10, 20]'

    assert str(ImmutableList.of(10, 20, 30)) == 'ImmutableList[10, 20, 30]'

# Generated at 2022-06-24 00:07:39.866042
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3

# Generated at 2022-06-24 00:07:43.407098
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList(is_empty=True)) == 'ImmutableList[]'

# Generated at 2022-06-24 00:07:46.726624
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda num: num + 1) == ImmutableList.of(2, 3, 4)



# Generated at 2022-06-24 00:07:50.625847
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1) + ImmutableList.of(2, 3, 4) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:07:57.506229
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Test 1
    l1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    l2 = l1.unshift(0)

    assert l2 == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    
    # Test 2
    l2 = l2.unshift(-1)

    assert l2 == ImmutableList(-1, ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3)))))

test_ImmutableList_unshift()

# Generated at 2022-06-24 00:08:06.337753
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x, "test") == "test"
    assert ImmutableList.of().reduce(lambda x, y: x, "test") == "test"
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, "test") == "test1"



# Generated at 2022-06-24 00:08:10.802491
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(is_empty=True) == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1, is_empty=True)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:08:14.774373
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    imm_list = ImmutableList.of(1, 2, 3)
    assert imm_list.unshift(100).to_list() == [100, 1, 2, 3]

# Generated at 2022-06-24 00:08:25.003505
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Test with empty list
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()

    # Test with list of strings
    test_list = ImmutableList.of('test1', 'test2', 'test3')
    result_list = ImmutableList.of('test1', 'test3')
    assert test_list.filter(lambda x: x != 'test2') == result_list

    # Test with list of numbers
    test_list = ImmutableList.of(1, 2, 3)
    result_list = ImmutableList.of(2)
    assert test_list.filter(lambda x: x % 2 == 0) == result_list

    # Test with list of bools
    test_list = ImmutableList.of(True, False, True)
    result_list

# Generated at 2022-06-24 00:08:29.067363
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1,2).to_list() == [1,2]
    assert ImmutableList.of(1,2,3).to_list() == [1,2,3]

# Generated at 2022-06-24 00:08:33.041957
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_list = ImmutableList.empty()
    list_of_strings = ImmutableList.of(1, 2, 3, 4, 5)
    assert empty_list.find(lambda x: x == 1) is None
    assert list_of_strings.find(lambda x: x == 1) == 1



# Generated at 2022-06-24 00:08:38.607145
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    """
    Method executes a reducer function on each element
    of the array, resulting in a single output value.

    :param fn: function to call with ImmutableList value
    :type fn: Function(A, B) -> A
    :returns: A
    """
    # Setup
    source: ImmutableList[int] = ImmutableList.of(2, 3, 5, 7, 11)

    # Exercise
    actual: ImmutableList[int] = source.map(lambda x: x * 2)

    # Verify
    expected = ImmutableList.of(4, 6, 10, 14, 22)
    assert actual == expected

    # Cleanup - none necessary

# Execute the unit tests
test_ImmutableList_map()

# Generated at 2022-06-24 00:08:45.811041
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(10) == ImmutableList.of(10)
    assert ImmutableList.empty().append(10).append(10) == ImmutableList.of(10, 10)
    assert ImmutableList.of(10).append(10) == ImmutableList.of(10, 10)
    assert ImmutableList.of(10).append(11).append(12) == ImmutableList.of(10, 11, 12)

# Generated at 2022-06-24 00:08:48.866888
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    a = ImmutableList()

    b = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    assert len(a) == 0
    assert len(b) == 5



# Generated at 2022-06-24 00:08:53.984318
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-24 00:08:57.151957
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1,2,3]
    assert ImmutableList.of(1).to_list() == [1]


# Generated at 2022-06-24 00:08:59.415606
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:09:04.137522
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    result = ImmutableList.of(1, 2, 3, 4).map(lambda x: x*x)
    assert result == ImmutableList.of(1, 4, 9, 16)
    
test_ImmutableList_map()



# Generated at 2022-06-24 00:09:07.370085
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_empty = ImmutableList.empty()
    assert len(list_empty) == 0

    list_one_element = ImmutableList.of(1)
    assert len(list_one_element) == 1

    list_many_elements = ImmutableList.of(4, 5, 6, 7)
    assert len(list_many_elements) == 4

    list_added_elements = ImmutableList.of(4, 5).__add__(ImmutableList.of(6, 7))
    assert len(list_added_elements) == 4

# Generated at 2022-06-24 00:09:15.155750
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list = ImmutableList.of(1, 2, 3, 4)
    assert list.head == 1
    assert list.tail.head == 2
    assert list.tail.tail.head == 3
    assert len(list) == 4
    assert list == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList(is_empty=True) == ImmutableList.empty()

# Generated at 2022-06-24 00:09:25.403134
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = [1, 2, 3, 4, 5]

    # third element from list_ should be in head
    # rest of elements should be in tail
    third_element = list_[2]
    remaining_elements = list_[:2] + list_[3:]

    assert (
        ImmutableList(
            third_element,
            ImmutableList(remaining_elements[0], ImmutableList(remaining_elements[1], ImmutableList(remaining_elements[2], ImmutableList(remaining_elements[3], None))))
        ).to_list()
        == list_
    )

    # second element from list_ should be in head
    # rest of elements should be in tail
    second_element = list_[1]
    remaining_elements = list_[:1] + list_

# Generated at 2022-06-24 00:09:29.962440
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert len(ImmutableList.of(1, 2, 3).filter(lambda x: x > 1)) == 2
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1)[0] == 2
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 1)[1] == 3


# Generated at 2022-06-24 00:09:33.568093
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5


# Generated at 2022-06-24 00:09:40.139041
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: True) == ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(1, 2, 3).filter(lambda x: False) == ImmutableList.empty()

    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()

    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList.empty()


test_ImmutableList_filter()

# Generated at 2022-06-24 00:09:41.783526
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    a = ImmutableList()
    assert a.head is None
    assert a.tail is None


# Generated at 2022-06-24 00:09:49.743853
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_append = ImmutableList.of('a', 'b', 'c').append('d')
    assert list_append == ImmutableList.of('a', 'b', 'c', 'd')
    assert list_append is not ImmutableList.of('a', 'b', 'c', 'd')

    list_append = ImmutableList.empty().append('d')
    assert list_append == ImmutableList.of('d')


# Generated at 2022-06-24 00:09:53.373042
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    maybe = ImmutableList.of(1, 2, 3)
    assert maybe.find(lambda x: x == 2) == 2
    assert maybe.find(lambda x: x == 4) is None


# Generated at 2022-06-24 00:09:58.918522
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3).append(4) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-24 00:10:03.312964
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    l1 = ImmutableList.of(1, 2, 3)
    l2 = l1.map(lambda x: x * 2)
    l3 = l1.map(lambda x: x * 2)
    assert l2 == ImmutableList.of(2, 4, 6)
    assert l2 != l1
    assert l2 == l3
    assert l1 != l3


# Generated at 2022-06-24 00:10:10.098310
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # arrange
    original_list = ImmutableList.of(1, 2, 3)
    concat_list = ImmutableList.of(4, 5, 6)
    expected_list = ImmutableList.of(1, 2, 3, 4, 5, 6)

    # act
    result_list = original_list + concat_list

    # assert
    assert expected_list == result_list


# Generated at 2022-06-24 00:10:15.727453
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda a, b: a * b, 1) == 24
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda a, b: a + b, 0) == 10
    assert ImmutableList.of().reduce(lambda a, b: a * b, 1) == 1



# Generated at 2022-06-24 00:10:17.404833
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_instance = ImmutableList.of(1, 2, 3)
    assert list_instance.append(10) == ImmutableList.of(1, 2, 3, 10)

# Generated at 2022-06-24 00:10:22.032805
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a_immutable_list = ImmutableList.of(1, 2, 3)

    new_immutable_list = a_immutable_list.filter(lambda x: x > 1)

    assert new_immutable_list == ImmutableList.of(2, 3)


# Generated at 2022-06-24 00:10:31.686871
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: None) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .filter(lambda x: x < 3) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .filter(lambda x: x > 3) == ImmutableList(4, ImmutableList(5))
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x == 3) == Imm

# Generated at 2022-06-24 00:10:38.640227
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    lst = ImmutableList(23, ImmutableList(3, ImmutableList(45)))

    # When
    filtered_list = lst.filter(lambda x: isinstance(x, int) and x > 3)

    # Then
    assert filtered_list == ImmutableList(23, ImmutableList(45))

# Generated at 2022-06-24 00:10:42.693025
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    list_ = ImmutableList.of(0, 1, 2, 3, 4, 5)
    # Act
    even_list = list_.filter(lambda x: x % 2 == 0)
    # Assert
    assert even_list == ImmutableList.of(0, 2, 4)


# Generated at 2022-06-24 00:10:45.823315
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2



# Generated at 2022-06-24 00:10:48.718136
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == \
        ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))



# Generated at 2022-06-24 00:10:52.157348
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    array = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    result = array.filter(
        lambda x: x > 2
    )

    assert isinstance(result, ImmutableList)
    assert result is not array
    assert array == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert result == ImmutableList(3, ImmutableList(4))


# Generated at 2022-06-24 00:11:04.109156
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # create immutable list with a single element
    immutable_list = ImmutableList(1)

    assert 1 == immutable_list.head
    assert None is immutable_list.tail
    assert [] == immutable_list.to_list()

    # create immutable list with two elements
    immutable_list = ImmutableList(1, ImmutableList(2))

    assert 1 == immutable_list.head
    assert ImmutableList(2) == immutable_list.tail
    assert [1, 2] == immutable_list.to_list()

    # create immutable list with 3 elements
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert 1 == immutable_list.head
    assert ImmutableList(2, ImmutableList(3)) == immutable_list.tail
    assert [1, 2, 3] == immutable

# Generated at 2022-06-24 00:11:12.286757
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1).append(3) == ImmutableList(1, ImmutableList(3))
    assert ImmutableList.of(1).append(3).append(4) == \
            ImmutableList(1, ImmutableList(3, ImmutableList(4)))


# Generated at 2022-06-24 00:11:19.392537
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList(2, ImmutableList(3), False)
    assert immutable_list.head == 2
    assert immutable_list.tail.head == 3
    assert immutable_list.tail.tail is None
    assert immutable_list.tail.is_empty is False
    assert immutable_list.is_empty is False



# Generated at 2022-06-24 00:11:24.595937
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)).append(3) != ImmutableList(3, ImmutableList(2, ImmutableList(1)))


# Generated at 2022-06-24 00:11:28.250868
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2) != [1, 2]
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)



# Generated at 2022-06-24 00:11:33.341959
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # 1. Given
    mapper = lambda element: element > 4

    # 2. When
    result = ImmutableList.of(1, 2, 3, 4, 5).find(mapper)

    # 3. Then
    assert result == 5



# Generated at 2022-06-24 00:11:36.888944
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(2, 3) == ImmutableList.of(1).unshift(2).unshift(3)

    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)

# Generated at 2022-06-24 00:11:42.033754
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    result = (
        ImmutableList.of(1,2,3,4)
        .append(5)
    )

    expected_result = [1,2,3,4,5]

    assert result.to_list() == expected_result



# Generated at 2022-06-24 00:11:44.019783
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)

# Generated at 2022-06-24 00:11:49.783429
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    )

    filtered_list = list_.filter(
        lambda x: x % 2 == 0
    )

    assert filtered_list == ImmutableList.of(2, 4, 6, 8, 10)


# Generated at 2022-06-24 00:11:52.351176
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda acc, x: acc + x, 0) == 10




# Generated at 2022-06-24 00:11:56.126073
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'

# Generated at 2022-06-24 00:12:01.285904
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    i_list = ImmutableList.of(0, 1, 2)
    assert(len(i_list) == 3)

    i_list = ImmutableList.of(0, 1, 2)
    assert(len(i_list) == 3)

    i_list = ImmutableList.of(0)
    assert(len(i_list) == 1)

    i_list = ImmutableList.empty()
    assert(len(i_list) == 0)



# Generated at 2022-06-24 00:12:03.884700
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    mapper = lambda x: x ** 2
    list_mapper = ImmutableList.of(mapper)

    assert list_mapper.head(2) == 4


test_ImmutableList_append()

# Generated at 2022-06-24 00:12:06.276205
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).append(4) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-24 00:12:15.001540
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x * x) == ImmutableList.of(1, 4, 9, 16)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x % 2 == 0) == ImmutableList.of(False, True, False, True)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: -x) == ImmutableList.of(-1, -2, -3, -4)


# Generated at 2022-06-24 00:12:24.492632
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList(1).map(lambda x: x + 1) == ImmutableList(2)
    assert ImmutableList(
        1,
        ImmutableList(3)
    ).map(lambda x: x + 1) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(
        1,
        ImmutableList(3, ImmutableList(4))
    ).map(lambda x: x + 1) == ImmutableList(2, ImmutableList(4, ImmutableList(5)))
    assert ImmutableList(5).map(lambda x: x + 1) == ImmutableList(6)
    assert ImmutableList(1).map(lambda x: x ** 2) == ImmutableList(1)

# Generated at 2022-06-24 00:12:33.016413
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList()
    assert ImmutableList.empty().is_empty == True

    assert ImmutableList.of('a') == ImmutableList('a')
    assert ImmutableList.of('a').is_empty == False
    assert ImmutableList.of('a').head == 'a'
    assert ImmutableList.of('a').tail.is_empty == True

    assert ImmutableList.of('a', 'b') == ImmutableList('a', ImmutableList('b'))
    assert ImmutableList.of('a', 'b').is_empty == False
    assert ImmutableList.of('a', 'b').head == 'a'
    assert ImmutableList.of('a', 'b').tail.head == 'b'

    assert ImmutableList.of('a', 'b', 'c')

# Generated at 2022-06-24 00:12:36.576313
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Arrange
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    # Act
    res = a.reduce(lambda a, b: a + b, 0)

    # Assert
    assert res == 15

# Generated at 2022-06-24 00:12:45.871611
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    for i in range(50):
        assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 10
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 10
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)) == 11
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of()) == 0
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-24 00:12:51.291481
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_il = ImmutableList.of(1, 2, 3, 4)
    second_il = ImmutableList.of(5, 6)
    result_il = first_il + second_il
    assert len(result_il) == 6
    assert result_il.to_list() == [1, 2, 3, 4, 5, 6]
    assert first_il.to_list() == [1, 2, 3, 4]
    assert second_il.to_list() == [5, 6]


# Generated at 2022-06-24 00:13:01.296542
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)).__eq__(
        ImmutableList(1, ImmutableList(2))
    ) == True
    assert ImmutableList(1, ImmutableList(2)).__eq__(
        ImmutableList(1, ImmutableList(2))
    ) == True
    assert ImmutableList().__eq__(
        ImmutableList()
    ) == True
    assert ImmutableList(1, ImmutableList(2)).__eq__(
        ImmutableList(2, ImmutableList(1))
    ) == False
    assert ImmutableList(1).__eq__(
        ImmutableList()
    ) == False
    assert ImmutableList().__eq__(
        ImmutableList(1)
    ) == False

# Generated at 2022-06-24 00:13:03.940415
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1,  2, 3, 4).find(
            lambda x: x == 3
        ) == 3


# Generated at 2022-06-24 00:13:08.256253
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []

    assert ImmutableList(10).to_list() == [10]

    assert ImmutableList(10, ImmutableList(20)).to_list() == [10, 20]

# Generated at 2022-06-24 00:13:12.568116
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_list.reduce(lambda acc, value: acc + value, 0) == 15
    assert test_list.reduce(lambda acc, value: acc * value, 1) == 120

# Generated at 2022-06-24 00:13:21.627018
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) == ImmutableList.empty().__add__(ImmutableList.of(1))
    assert ImmutableList.of(1, 2) == ImmutableList.of(1).__add__(ImmutableList.of(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2).__add__(ImmutableList.of(3))
    assert ImmutableList.of(1, 2, 3) == ImmutableList.empty().__add__(ImmutableList.of(1, 2, 3))
    assert ImmutableList.of(1, 2, 3) == ImmutableList.empty().__add__(ImmutableList.of(1, 2)).__add__(ImmutableList.of(3))

# Generated at 2022-06-24 00:13:29.496990
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4).unshift(0) == ImmutableList.of(0, 1, 2, 3, 4)
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)


# Generated at 2022-06-24 00:13:32.144469
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(
        lambda acc, curr: acc + curr, 0
    ) == 15

# Generated at 2022-06-24 00:13:38.229188
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-24 00:13:42.676442
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList())))) == 3

# Generated at 2022-06-24 00:13:47.475980
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1,2,3,4,5)) == 'ImmutableList[1, 2, 3, 4, 5]'



# Generated at 2022-06-24 00:13:56.413226
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1) \
        .reduce(lambda acc, x: acc + x, 0) \
        == 1

    assert ImmutableList.of(1, 2) \
        .reduce(lambda acc, x: acc + x, 0) \
        == 3

    assert ImmutableList.of(1, 2, 3) \
        .reduce(lambda acc, x: acc + x, 0) \
        == 6

    assert ImmutableList.of(1, 2, 3, 4) \
        .reduce(lambda acc, x: acc + x, 0) \
        == 10

    assert ImmutableList.of(1, 2, 3, 4, 5) \
        .reduce(lambda acc, x: acc + x, 0) \
        == 15


# Generated at 2022-06-24 00:14:07.926914
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = ImmutableList.of(1)
    list3 = ImmutableList.of(1)
    list4 = ImmutableList.of(1, 2, 3, 4, 5, 6)

    def is_greater_than1(x):
        return x > 1

    assert list1.filter(is_greater_than1) == ImmutableList.of(2, 3, 4, 5)
    assert list2.filter(is_greater_than1) == ImmutableList.empty()
    assert list3.filter(is_greater_than1).filter(is_greater_than1) == ImmutableList.empty()

# Generated at 2022-06-24 00:14:19.821844
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1).to_list() == [1, 3]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.of('a', 'aa', 'b', 'bb', 'c', 'cc').filter(lambda x: len(x) == 1).to_list()

# Generated at 2022-06-24 00:14:21.380265
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'



# Generated at 2022-06-24 00:14:26.026837
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(5)) == 1
    assert len(ImmutableList.of(5, 10)) == 2
    assert len(ImmutableList.of(5, 10, 15)) == 3
    assert len(ImmutableList.empty()) == 0



# Generated at 2022-06-24 00:14:27.725705
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4

# Generated at 2022-06-24 00:14:36.426390
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    immutable_list = ImmutableList.of(None)
    assert immutable_list.find(lambda v: v == None) == None

    immutable_list = ImmutableList.of(None, 1, 2)
    assert immutable_list.find(lambda v: v == 1) == 1
    assert immutable_list.find(lambda v: v == 2) == 2
    assert immutable_list.find(lambda v: v == None) == None
    assert immutable_list.find(lambda v: v == 99) == None

    immutable_list = ImmutableList.of(None, 1, 2, 99)
    assert immutable_list.find(lambda v: v == 1) == 1
    assert immutable_list.find(lambda v: v == 2) == 2
    assert immutable_list.find(lambda v: v == 99) == 99
    assert immutable

# Generated at 2022-06-24 00:14:41.596004
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList(1)
    assert immutable_list.head == 1
    assert immutable_list.tail is None
    assert immutable_list.is_empty is False
    assert immutable_list == ImmutableList(1)
    assert immutable_list != ImmutableList(2)



# Generated at 2022-06-24 00:14:47.042821
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():  # pragma: no cover
    l = ImmutableList.of(0)
    assert l.unshift(1) == ImmutableList.of(1, 0)

    l = ImmutableList.of(1, 2, 3, 4, 5)
    assert l.unshift(0) == ImmutableList.of(0, 1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:14:48.782689
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)



# Generated at 2022-06-24 00:14:51.545691
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    result = ImmutableList.of(2, 3, 4, 5)

    assert result.reduce(lambda acc, elem: acc + elem, 0) == 14

# Generated at 2022-06-24 00:14:58.719638
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = list1.map(lambda x: x * 2)
    assert list1 != list2
    assert list2.head == 2
    assert list2.tail.head == 4
    assert list2.tail.tail.head == 6
    assert list2.tail.tail.tail.head == 8
    assert list2.tail.tail.tail.tail.head == 10
    assert list2.tail.tail.tail.tail.tail is None


# Generated at 2022-06-24 00:15:03.817083
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.of(1, 2, 3)
    list = list.unshift(0)
    assert list.to_list() == [0, 1, 2, 3]


# Generated at 2022-06-24 00:15:08.062361
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    numbers = ImmutableList.of(1, 2, 3)
    numbers_cloned = numbers.unshift(4)
    numbers_modified = numbers_cloned.unshift(5)
    assert numbers.to_list() == [1, 2, 3]
    assert numbers_cloned.to_list() == [4, 1, 2, 3]
    assert numbers_modified.to_list() == [5, 4, 1, 2, 3]

# Generated at 2022-06-24 00:15:10.252015
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    a = ImmutableList.of(1, 2, 3, 4, 5)
    find = a.find(lambda x: x == 3)
    assert find == 3



# Generated at 2022-06-24 00:15:14.209472
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    l1 = ImmutableList.empty()
    assert l1.__len__() == 0

    l1 = ImmutableList(1)
    assert l1.__len__() == 1

    l1 = ImmutableList(1, ImmutableList(2), ImmutableList(3, ImmutableList(4), ImmutableList.empty()))
    assert l1.__len__() == 4

# Generated at 2022-06-24 00:15:21.158625
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) + ImmutableList(2, ImmutableList(3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:15:29.420729
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift('head').to_list() == ['head']

    list_ = ImmutableList.of('head').unshift('new_element')
    assert len(list_) == 2 and list_.to_list() == ['new_element', 'head']

    list_ = ImmutableList.of('head', 'tail').unshift('new_element')
    assert len(list_) == 3 and list_.to_list() == ['new_element', 'head', 'tail']

# Generated at 2022-06-24 00:15:32.525724
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    filtered_list = list_.filter(lambda x: x > 3)
    assert filtered_list == ImmutableList.of(4, 5)

# Generated at 2022-06-24 00:15:35.671256
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    lst = ImmutableList.of(1, 2, 3)
    new_lst = lst.unshift(4)
    assert isinstance(new_lst, ImmutableList)
    assert new_lst == ImmutableList.of(4, 1, 2, 3)

# Generated at 2022-06-24 00:15:40.953293
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert(ImmutableList(10, ImmutableList(20, ImmutableList(30))).reduce(lambda x,y: x+y,0) == 60)
    assert(ImmutableList(10, ImmutableList(20, ImmutableList(30))).reduce(lambda x,y: x+y,3) == 63)
    assert(ImmutableList().reduce(lambda x,y: x+y,0) == 0)
    assert(ImmutableList().reduce(lambda x,y: x+y,2) == 2)
    assert(ImmutableList(1).reduce(lambda x,y: x+y,3) == 4)
    assert(ImmutableList(1).reduce(lambda x,y: x+y,0) == 1)


# Generated at 2022-06-24 00:15:49.224035
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList(
        1,
        ImmutableList(2, ImmutableList(3))
    )
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).append(4) == ImmutableList(
        1,
        ImmutableList(2, ImmutableList(3, ImmutableList(4)))
    )

# Generated at 2022-06-24 00:15:53.594254
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:15:56.822378
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Tests for case if list is empty
    assert len(ImmutableList.empty()) == 0
    # Tests for case if list has one element
    assert len(ImmutableList(1)) == 1
    # Tests for case if list has two elements
    assert len(ImmutableList(2, ImmutableList(1))) == 2
    # Tests for case if list has three elements
    assert len(ImmutableList(3, ImmutableList(2, ImmutableList(1)))) == 3



# Generated at 2022-06-24 00:16:04.060077
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    """
    if this list is empty should return other in case
    when both lists are empty should return self
    """
    # If method self.is_empty isn't defined
    # will raise exception because of we didn't define 
    # __add__ method for False
    # If we'll not return other in case
    # when self.is_empty will be False
    # we'll get infinite recursion in case
    # our list is empty
    assert ImmutableList.empty() == ImmutableList.empty() + ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1) + ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2), ImmutableList.empty()) == ImmutableList.of(1, 2) + Imm

# Generated at 2022-06-24 00:16:06.727582
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert str(list) == 'ImmutableList[1, 2, 3, 4, 5]'

# Generated at 2022-06-24 00:16:11.895340
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l1 = ImmutableList.of(1, 2, 3, 4)
    l2 = ImmutableList.of(5, 6, 7, 8)
    l3 = l1.__add__(l2)

    assert l3 == ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)

# Generated at 2022-06-24 00:16:14.849761
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    test_list = ImmutableList(1, ImmutableList(2))
    assert test_list.unshift(0).to_list() == [0, 1, 2]



# Generated at 2022-06-24 00:16:16.662839
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:16:18.983471
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    maybe = ImmutableList.of(1, 2, 3, 4)

    assert len(maybe) == 4
    assert maybe.to_list() == [1, 2, 3, 4]



# Generated at 2022-06-24 00:16:27.989675
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).to_list() == [1, 2, 3, 4]

# Generated at 2022-06-24 00:16:33.300298
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert not ImmutableList.of(3) == ImmutableList()
    assert ImmutableList.of(3) == ImmutableList.of(3)
    assert not ImmutableList.of(3) == ImmutableList.of(3, 4)
    assert ImmutableList.of(3, 4) == ImmutableList.of(3, 4)

# Generated at 2022-06-24 00:16:45.031271
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x ** 2) == ImmutableList.of(1, 4, 9)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x - 1) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6, 8)

# Generated at 2022-06-24 00:16:50.442541
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # arrange
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3, 4)

    # act & assert
    assert list1.append(4) == list2


# Generated at 2022-06-24 00:16:56.214069
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_1 = ImmutableList()
    assert len(list_1) == 0
    assert list_1.__len__() == 0

    list_1 = ImmutableList(1)
    assert len(list_1) == 1
    assert list_1.__len__() == 1

    list_2 = ImmutableList(2, ImmutableList(3))
    assert len(list_2) == 2
    assert list_2.__len__() == 2



# Generated at 2022-06-24 00:16:59.941448
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(2, 3)

    assert list1.unshift(2) == ImmutableList.of(2, 1)
    assert list2.unshift(3) == ImmutableList.of(3, 2, 3)
