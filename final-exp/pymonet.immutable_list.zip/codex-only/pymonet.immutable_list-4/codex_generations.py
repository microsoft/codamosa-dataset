

# Generated at 2022-06-24 00:06:49.466015
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-24 00:06:54.360023
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    m1 = ImmutableList.of(1)
    m2 = ImmutableList(2)
    md1 = m1 + m2
    md2 = m2 + m1
    assert m1 != m2
    assert md1 != md2
    assert m1 == ImmutableList(1)
    assert m2 == ImmutableList(2)
    assert md1 == ImmutableList(1, 2)
    assert md2 == ImmutableList(2, 1)
    assert m1 != md1
    assert m2 != md2



# Generated at 2022-06-24 00:07:01.518923
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Arrange
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(4, 5, 6)
    list3 = ImmutableList.of(7, 8, 9)

    # Action
    result = list1 + list2 + list3

    # Assert
    assert result == ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-24 00:07:07.318715
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    test_acc: ImmutableList[float] = ImmutableList.of(1.34, 2.57, 4.64, 7.9, 0.09)
    # test for addition
    assert test_acc.reduce(lambda acc, item: acc + item, 0) == 16.53
    # test for multiplication
    assert test_acc.reduce(lambda acc, item: acc * item, 1) == 166.98



# Generated at 2022-06-24 00:07:09.632889
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList([1,2,3])) == 'ImmutableList[1, 2, 3]' # pragma: no cover


# Generated at 2022-06-24 00:07:20.056141
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    numbers = ImmutableList.of(1, 2, 3)
    assert numbers.filter(lambda x: x % 2 == 0).to_list() == [2]

    numbers = ImmutableList.of(1, 2)
    assert numbers.filter(lambda x: True).to_list() == [1, 2]

    numbers = ImmutableList.of(1, 2)
    assert numbers.filter(lambda x: False).to_list() == []
    assert len(numbers.filter(lambda x: False)) == 0

    numbers = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert numbers.filter(lambda x: x % 2 == 0).to_list() == [2, 4, 6]

    assert len(numbers.filter(lambda x: x % 2 == 0)) == 3

   

# Generated at 2022-06-24 00:07:25.706874
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    elements_list = [1, 2, 3, 4]
    elements_tuple = (1, 2, 3, 4)
    elements_str = '1234'
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList.of(*elements_list) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(*elements_tuple) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(*elements_str) == ImmutableList.of('1', '2', '3', '4')


# Generated at 2022-06-24 00:07:32.324644
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList().append(1) == ImmutableList(1)
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).append(5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

# Generated at 2022-06-24 00:07:42.257055
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList(1)
    list_2 = ImmutableList(2)
    new_list_1 = list_1 + list_2
    new_list_2 = list_2 + list_1

    # __add__ method
    assert new_list_2.head == list_2.head
    assert new_list_2.tail.head == list_1.head
    assert new_list_2.tail.tail is None
    # __add__ method
    assert new_list_1.head == list_1.head
    assert new_list_1.tail.head == list_2.head
    assert new_list_1.tail.tail is None


# Generated at 2022-06-24 00:07:46.764775
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    expected = True

    actual = (ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3))

    assert actual == expected, "expected " + str(expected) + " but got " + str(actual)



# Generated at 2022-06-24 00:07:52.854321
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(0).map(lambda x: x + 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).map(lambda x: x + 2) == ImmutableList.of(3, 4)



# Generated at 2022-06-24 00:08:00.833122
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList.of('element')
    assert immutable_list.head == 'element'
    assert immutable_list.tail == ImmutableList(is_empty=True)

    immutable_list = ImmutableList()
    assert immutable_list.head is None
    assert immutable_list.tail is None
    assert immutable_list.is_empty is True

    immutable_list = ImmutableList.of('element', 'another_element')
    assert immutable_list.head == 'element'
    assert immutable_list.tail.head == 'another_element'
    assert immutable_list.tail.tail == ImmutableList(is_empty=True)

    immutable_list = ImmutableList(head=False, tail=ImmutableList(
        head=True, tail=ImmutableList(is_empty=True)))

# Generated at 2022-06-24 00:08:03.408811
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'



# Generated at 2022-06-24 00:08:09.489213
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 0) == 0
    assert ImmutableList.of(1).reduce(lambda x, y: x + y, 0) == 1
    assert ImmutableList.of(1).reduce(lambda x, y: x + y, 0) == 1
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6



# Generated at 2022-06-24 00:08:14.363783
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    """
    Test for len()
    """
    assert len(ImmutableList.of(10, 20, 30)) == 3
    assert len(ImmutableList.of(10)) == 1
    assert len(ImmutableList.empty()) == 0



# Generated at 2022-06-24 00:08:23.551498
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) + ImmutableList.of(5) == ImmutableList.of(1, 2, 3, 4, 5)


# Generated at 2022-06-24 00:08:32.395899
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6)) == 6
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7)) == 7
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)) == 8

# Generated at 2022-06-24 00:08:35.524468
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(2, 3, 4)) == 'ImmutableList[2, 3, 4]'

# Generated at 2022-06-24 00:08:37.935597
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)

# Unit tests for method append of class ImmutableList

# Generated at 2022-06-24 00:08:43.836907
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) + ImmutableList.of(1, 2) == ImmutableList.of(1, 2, 1, 2)


# Generated at 2022-06-24 00:08:49.949296
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # GIVEN
    list_1 = ImmutableList.of(4, 5, 6)
    list_2 = ImmutableList.of(4, 5, 6)
    list_3 = ImmutableList.of(4, 5, 8)

    # WHEN
    actual = list_1 == list_2
    expected = True
    actual_2 = list_1 == list_3
    expected_2 = False

    # THEN
    assert actual == expected, 'ImmutableList not passed equality check'
    assert actual_2 == expected_2, 'ImmutableList passed equality check'



# Generated at 2022-06-24 00:08:56.282867
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    obj = ImmutableList()
    assert str(obj) == 'ImmutableList[]'

    obj = ImmutableList.of(1)
    assert str(obj) == 'ImmutableList[1]'

    obj = ImmutableList.of(1,2,3)
    assert str(obj) == 'ImmutableList[1, 2, 3]'



# Generated at 2022-06-24 00:09:00.440914
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    """
    Test class ImmutableList constructor
    """
    assert ImmutableList(is_empty=True) == ImmutableList.empty(), "Checking constructor for empty list"
    assert ImmutableList(2, ImmutableList(4, ImmutableList(1))) == ImmutableList.of(2, 4, 1), "Checking constructor of class ImmutableList"

# Generated at 2022-06-24 00:09:02.466595
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_test = ImmutableList.of('test')

    assert list_test.find(lambda x: x == 'test') == 'test'
    assert list_test.find(lambda x: x == 'test1') is None


# Generated at 2022-06-24 00:09:05.582894
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2

# Generated at 2022-06-24 00:09:09.354389
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_one = ImmutableList.of(1, 2, 3)
    list_two = ImmutableList.of(1, 2, 3)
    list_three = ImmutableList.of(4, 5, 6)
    assert list_one == list_two
    assert list_two == list_one
    assert list_one != list_three
    assert list_two != list_three
    assert list_three != list_one
    assert list_three != list_two


# Generated at 2022-06-24 00:09:20.669010
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_of_elements_for_test = [
        (
            ImmutableList.of(1),
            [1]
        ),
        (
            ImmutableList.of(1, 2, 3),
            [1, 2, 3]
        ),
        (
            ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6),
            [1, 2, 3, 4, 5, 6]
        ),
        (
            ImmutableList.of(1) + ImmutableList.of(4, 5, 6),
            [1, 4, 5, 6]
        ),
        (
            ImmutableList.of(1, 2, 3) + ImmutableList.empty(),
            [1, 2, 3]
        ),
    ]


# Generated at 2022-06-24 00:09:25.314759
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(0)) == 1
    assert len(ImmutableList(0, ImmutableList(1))) == 2
    assert len(ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))) == 4
    assert len(ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))))) == 5

# Generated at 2022-06-24 00:09:29.536880
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(3, ImmutableList(1, ImmutableList(2))) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList() == ImmutableList()


# Generated at 2022-06-24 00:09:33.737397
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    case_1 = ImmutableList.of(1).reduce(lambda x, y: x + y, 0)
    assert case_1 == 1

    case_2 = ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0)
    assert case_2 == 6

    case_3 = ImmutableList.of(1, 2, 3).reduce(lambda x, y: x * y, 2)
    assert case_3 == 12

# Generated at 2022-06-24 00:09:42.433037
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda elem: elem > 3) == ImmutableList.of(4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda elem: elem == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda elem: elem == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda elem: elem == 5) == ImmutableList.of(5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda elem: elem == 5) == ImmutableList.of(5)



# Generated at 2022-06-24 00:09:45.831593
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.append(4).to_list() == [1, 2, 3, 4]
    assert list_.append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-24 00:09:47.283872
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(2, 5, 10).to_list() == [2, 5, 10]

# Generated at 2022-06-24 00:09:52.273976
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.of(1).append(2) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-24 00:09:56.599539
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_things = ImmutableList([1, 2, 3, 4, 5])
    assert list_of_things.filter(lambda x: x % 2 == 0).to_list() == [2, 4], 'ImmutableList.filter: incorrect result'
    assert list_of_things.filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5], 'ImmutableList.filter: incorrect result'

# Generated at 2022-06-24 00:09:59.307908
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    values = ImmutableList.of(3, 2, 1)
    expected = ImmutableList.of(3, 2, 1, 42)
    actual = values.append(42)
    assert actual == expected



# Generated at 2022-06-24 00:10:02.058511
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list1 = ImmutableList.of(1, 2, 3, 4, 5)
    list2 = ImmutableList.empty()
    assert len(list1) == 5
    assert len(list2) == 0

# Generated at 2022-06-24 00:10:08.409853
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():

    # checks the len of the empty list
    assert len(ImmutableList.of()) == 0

    # checks the len of the non empty list
    assert len(ImmutableList.of("first", "second")) == 2


# Generated at 2022-06-24 00:10:18.422047
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() != [1, 2, 3, 4, 5, 6]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() != [1, 2, 3]
    assert ImmutableList.of('1', '2', '3', '4', '5').to_list() != [1, 2, 3, 4, 5]


# Generated at 2022-06-24 00:10:22.554291
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList.of(1, 2, 3, 4, 5, 1).filter(lambda x: x % 2 == 0)
    b = ImmutableList.of(2, 4)
    assert a == b, "test of method filter of class ImmutableList"
    print('test_ImmutableList_filter is passed')



# Generated at 2022-06-24 00:10:29.722670
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3) + ImmutableList(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))


# Generated at 2022-06-24 00:10:32.983768
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(3, 2, 1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:10:44.034772
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    empty_imm_list = ImmutableList.empty()
    assert len(empty_imm_list) == 0
    assert empty_imm_list == ImmutableList()

    imm_list = ImmutableList(100)
    assert len(imm_list) == 1
    assert imm_list.head == 100
    assert imm_list.tail is None
    assert imm_list == ImmutableList(100)

    imm_list = ImmutableList(100, ImmutableList(200))
    assert len(imm_list) == 2
    assert imm_list.head == 100
    assert len(imm_list.tail) == 1
    assert imm_list.tail.head == 200
    assert imm_list.tail.tail is None
    assert imm_list == ImmutableList(100, ImmutableList(200))

# Unit tests for constructor of class

# Generated at 2022-06-24 00:10:46.803835
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    original = ImmutableList.empty()
    extended = original.append(1)
    assert extended == ImmutableList.of(1)
    assert original == ImmutableList.empty()
    extended = original.append(1).append(2).append(3)
    assert extended == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:10:52.501208
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    print("Testing method reduce of class ImmutableList")

    # Case 1. Case with empty list
    empty = ImmutableList.empty()
    result = empty.reduce(lambda acc, x: acc + x, 1)
    assert result == 1, "Test failed, case with empty list"

    # Case 2. Case with one element in list
    list_with_one_element = ImmutableList.of(1)
    result = list_with_one_element.reduce(lambda acc, x: acc + x, 1)
    assert result == 2, "Test failed, case with one element"

    # Case 3. Case with many elements in list
    list_with_many_elements = ImmutableList.of(1, 2, 3, 4, 5)

# Generated at 2022-06-24 00:10:56.347163
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Given
    m1 = ImmutableList.of(2)
    m2 = ImmutableList.of(3)

    # Then
    assert (m1 + m2).to_list() == [2, 3]



# Generated at 2022-06-24 00:11:05.513037
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 5) == None
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 4) == 4
    assert ImmutableList.empty().find(lambda x: x == 4) == None

# Generated at 2022-06-24 00:11:08.841056
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-24 00:11:13.169101
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-24 00:11:24.933884
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    _list = ImmutableList.of(1, 2, 3, 4, 5)

    # Case with even predicate
    filtered_list = _list.filter(lambda x: x % 2 == 0)
    assert len(filtered_list) == 2
    assert filtered_list.head == 2
    assert filtered_list.tail.head == 4
    assert filtered_list.tail.tail.is_empty

    # Case with odd predicate
    filtered_list = _list.filter(lambda x: x % 2 == 1)
    assert len(filtered_list) == 3
    assert filtered_list.head == 1
    assert filtered_list.tail.head == 3
    assert filtered_list.tail.tail.head == 5
    assert filtered_list.tail.tail.tail.is_empty

    # Case with None predicate

# Generated at 2022-06-24 00:11:28.716198
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)) == 8

test_ImmutableList___len__()

# Generated at 2022-06-24 00:11:35.723099
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList().head is None
    assert ImmutableList().tail is None
    assert ImmutableList(1).head == 1
    assert ImmutableList(1).tail is None
    assert ImmutableList(1, ImmutableList(2)).head == 1
    assert ImmutableList(1, ImmutableList(2)).tail.head == 2
    assert ImmutableList(1, ImmutableList(2)).tail.tail is None
    assert ImmutableList(1, ImmutableList(2)).tail.head == 2



# Generated at 2022-06-24 00:11:42.719845
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3)
    list1.append(4)
    list2.unshift(4)
    assert list1.to_list() == [1, 2, 3, 4]
    assert list2.to_list() == [4, 1, 2, 3]


# Generated at 2022-06-24 00:11:47.431597
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1) + ImmutableList.of(2, 3)


# Generated at 2022-06-24 00:11:55.638662
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:11:58.894584
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) is not None
    assert ImmutableList.of(1).find(lambda x: x == 2) is None
    assert ImmutableList.empty().find(lambda x: x == 2) is None


# Generated at 2022-06-24 00:12:02.990766
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    empty_list = ImmutableList.empty()
    assert empty_list.to_list() == []

    one_element_list = ImmutableList.of(1)
    assert one_element_list.to_list() == [1]

    multiple_elements_list = ImmutableList.of(1, 2, 3, 4)
    assert multiple_elements_list.to_list() == [1, 2, 3, 4]

# Generated at 2022-06-24 00:12:06.936120
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    """
    Unit test for method append of class Maybe
    """
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1).append(2).append(3) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-24 00:12:12.358271
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(2)) == 'ImmutableList[2]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
test_ImmutableList___str__()

# Generated at 2022-06-24 00:12:17.673142
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    second_list = ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8))))

    assert first_list + second_list == first_list.__add__(second_list)


# Generated at 2022-06-24 00:12:23.001410
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    assert l.to_list() == [1, 2, 3, 4, 5]
    assert l.tail.to_list() == [2, 3, 4, 5]



# Generated at 2022-06-24 00:12:30.536532
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList' in str(ImmutableList())
    assert 'ImmutableList{}' == str(ImmutableList(is_empty=True))
    assert 'ImmutableList{[]}' == str(ImmutableList())
    assert 'ImmutableList{[1]}' == str(ImmutableList(1))
    assert 'ImmutableList{[1, 2]}' == str(ImmutableList(1, ImmutableList(2)))
    assert 'ImmutableList{[1, 2, 3]}' == str(ImmutableList(1, ImmutableList(2, ImmutableList(3))))



# Generated at 2022-06-24 00:12:33.312601
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # arrange
    fn = lambda x: x % 2 == 0

    # act
    input_data = ImmutableList.of(1, 2, 3, 4, 5)

    # assert
    assert input_data.filter(fn) == ImmutableList.of(2, 4)

# Generated at 2022-06-24 00:12:41.946469
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list1 = ImmutableList(head=1, is_empty=False)
    list2 = ImmutableList(head=2, tail=list1, is_empty=False)

    list3 = ImmutableList.of(3,4,5,6,7,8,9)

    assert list1.head == 1
    assert list2.head == 2
    assert list1.tail == list1
    assert list2.tail == list1
    assert len(list1) == 1
    assert len(list2) == 2
    assert list2.append(10) == ImmutableList.of(2, 1, 10)
    assert list2.unshift(10) == ImmutableList.of(10, 2, 1)

# Generated at 2022-06-24 00:12:46.964545
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    i_list1 = ImmutableList.of(1, 2, 3, 4)
    i_list2 = ImmutableList.of(1, 2, 3, 4)

    assert i_list1 == i_list2


test_ImmutableList___eq__()



# Generated at 2022-06-24 00:12:51.124744
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert(ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2).to_list()
            == [3, 4])
    assert(ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 2).to_list()
            == [1])
    assert(ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 0).to_list()
            == [])
    assert(ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 0).to_list()
            == [1, 2, 3, 4])


test_ImmutableList_filter()

# Generated at 2022-06-24 00:12:57.906962
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of(1, 2, 3, 4)
    b = ImmutableList.of(5, 6)

    assert a + b == ImmutableList.of(1, 2, 3, 4, 5, 6)
    # __add__ should not modify the existing instances
    assert a == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-24 00:13:00.769134
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result = ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 3)
    assert result == 3

    result = ImmutableList.of(1, 2, 3, 4).find(lambda x: x == 10)
    assert result is None


# Generated at 2022-06-24 00:13:03.829918
# Unit test for constructor of class ImmutableList
def test_ImmutableList():  # pragma: no cover
    list = ImmutableList()
    assert not list.head
    assert not list.tail
    assert list.is_empty


# Generated at 2022-06-24 00:13:08.708677
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    result_list = ImmutableList.of(1,2,3).unshift(0)
    assert result_list == ImmutableList.of(0,1,2,3)

# Generated at 2022-06-24 00:13:12.991754
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    int_list = ImmutableList.of(1, 2, 3)
    new_list = int_list.unshift(0)
    assert new_list == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))

# Generated at 2022-06-24 00:13:16.862981
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_a = ImmutableList.of(1, 2, 3)
    list_b = list_a.append(4)
    list_c = list_b.unshift(5)
    list_d = list_a.unshift(5)

    assert list_a.to_list() == [1, 2, 3]
    assert list_b.to_list() == [1, 2, 3, 4]
    assert list_c.to_list() == [5, 1, 2, 3, 4]
    assert list_d.to_list() == [5, 1, 2, 3]



# Generated at 2022-06-24 00:13:22.575303
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(3) == ImmutableList(
        1, ImmutableList(3)
    )

    assert ImmutableList(1, ImmutableList(2, ImmutableList(4))) \
        .append(7) == ImmutableList(
            1, ImmutableList(2, ImmutableList(4, ImmutableList(7)))
        )



# Generated at 2022-06-24 00:13:25.735099
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-24 00:13:27.745845
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    a = ImmutableList()
    assert str(a) == 'ImmutableList[]', 'Unexpected value of ImmutableList.__str__'

# Generated at 2022-06-24 00:13:38.115366
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    """
    Tests for method map of class ImmutableList
    """

    # Test 1
    list1 = ImmutableList.of(1)
    another_list = list1.map(lambda x: x + 1)
    assert another_list == ImmutableList.of(2)

    # Test 2
    list2 = ImmutableList.of(1, 2, 3, 4)
    another_list2 = list2.map(lambda x: x + 1)
    assert another_list2 == ImmutableList.of(2, 3, 4, 5)

    # Test 3
    list3 = ImmutableList.of()
    another_list3 = list3.map(lambda x: x + 1)
    assert another_list3 == ImmutableList.empty()

    # Test 4
    list4 = ImmutableList.empty()
   

# Generated at 2022-06-24 00:13:39.562405
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList().__str__() == 'ImmutableList[]'


# Generated at 2022-06-24 00:13:50.292870
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # GIVEN
    empty_list = ImmutableList()
    single_list = ImmutableList.of(1)
    populated_list = ImmutableList.of(1, 2, 3, 4)

    # THEN
    assert empty_list.head is None
    assert single_list.head == 1
    assert populated_list.head == 1
    assert populated_list.tail.head == 2
    assert populated_list.tail.tail.head == 3
    assert populated_list.tail.tail.tail.head == 4
    assert populated_list.tail.tail.tail.tail.head is None
    assert populated_list.tail.tail.tail.tail.tail is None



# Generated at 2022-06-24 00:13:53.038835
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2


# Generated at 2022-06-24 00:13:56.705571
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1) + ImmutableList.of(4, 5) == ImmutableList.of(1, 4, 5)

# Generated at 2022-06-24 00:14:01.028934
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of('a', 'b', 'c')) == 'ImmutableList[a, b, c]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'


# Generated at 2022-06-24 00:14:06.709318
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    new_list = ImmutableList.empty()

    assert new_list == ImmutableList.empty()
    assert new_list == ImmutableList(is_empty=True)
    assert new_list.head is None
    assert new_list.tail is None

    new_list = ImmutableList.of(1)

    assert new_list == ImmutableList(1)
    assert new_list.head == 1
    assert new_list.tail is None

    new_list = ImmutableList.of(1, 2, 3)

    assert new_list == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert new_list.head == 1
    assert new_list.tail == ImmutableList(2, ImmutableList(3))


# Generated at 2022-06-24 00:14:09.529144
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of('1') + ImmutableList.of('2') == ImmutableList.of('1', '2')
    assert ImmutableList.of('1', '2', '3') + ImmutableList.of('4', '5') == ImmutableList.of('1', '2', '3', '4', '5')


# Generated at 2022-06-24 00:14:13.654722
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5


# Generated at 2022-06-24 00:14:16.815059
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    expect(ImmutableList.of(1, 2, 3).append(4)).to_equal(ImmutableList.of(1, 2, 3, 4))


# Generated at 2022-06-24 00:14:21.643621
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList().to_list() == []

test_ImmutableList_to_list()

# Generated at 2022-06-24 00:14:25.428922
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift(): 
    # Arrange
    tested = ImmutableList.of(4, 5)
    expected = ImmutableList.of(3, 4, 5)

    # Act
    result = tested.unshift(3)

    # Assert
    assert result == expected

# Generated at 2022-06-24 00:14:28.913841
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_ = ImmutableList.of(1, 2, 3, 4)
    new_list = list_.map(lambda el: el * 2)
    assert new_list == ImmutableList.of(2, 4, 6, 8)
    
    
    

# Generated at 2022-06-24 00:14:32.730661
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_a = ImmutableList.of(3, 5, 2)
    list_b = list_a.unshift(1)
    assert list_a == ImmutableList.of(3, 5, 2)
    assert list_b == ImmutableList.of(1, 3, 5, 2)


# Generated at 2022-06-24 00:14:37.987537
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    lst = ImmutableList.empty()
    lst = lst.unshift(5)
    lst = lst.unshift(7)
    lst = lst.unshift(9)
    lst = lst.unshift(11)
    assert lst.head == 11
    assert lst.tail.head == 9
    assert lst.tail.tail.head == 7
    assert lst.tail.tail.tail.head == 5
    assert lst.tail.tail.tail.tail.is_empty == True

# Generated at 2022-06-24 00:14:47.254162
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 'ImmutableList[1, 2, 3, 4]'
    assert str(ImmutableList(5)) == 'ImmutableList[5]'
    assert str(ImmutableList(is_empty=True)) == 'ImmutableList[]'



# Generated at 2022-06-24 00:14:51.556677
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1,2,3).filter(lambda x:x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1,2,3).filter(lambda x:x == 4) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x:x) == ImmutableList.empty()


# Generated at 2022-06-24 00:15:01.640658
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    li = ImmutableList.of(1,2,3,4,5)
    assert li.reduce(lambda x, y: x + y, 0) == 15

    li = ImmutableList.of(1, 2, 3, 4, 5)
    assert li.reduce(lambda x, y: x - y, 0) == -15

    li = ImmutableList.of('h')
    assert li.reduce(lambda x, y: x+ y, '') == 'h'

    li = ImmutableList.of('h')
    assert li.reduce(lambda x, y: x + y, 'e') == 'eh'

    li = ImmutableList.of('h', 'e', 'l', 'l', 'o')

# Generated at 2022-06-24 00:15:05.297306
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None


# Generated at 2022-06-24 00:15:13.651563
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    
    # assert correct work of reduce when fn defines in this place
    assert ImmutableList.of(5, 6, 7).reduce(lambda x, y: x+y, 0) == 18

    # assert correct work of reduce when fn is defined in another function
    def fn(x,y):
        return x+y

    assert ImmutableList.of(1, 2, 2).reduce(fn, 0) == 5

    # assert correct work of reduce when function fn has own arguments
    assert ImmutableList.of(1, 2, 2).reduce(fn, 10) == 17

    # assert correct work of reduce when function fn has own arguments
    assert ImmutableList.of(3, 2, 1).reduce(lambda x, y: x-y, 10) == 6
    
    # assert correct work of reduce when list is empty
   

# Generated at 2022-06-24 00:15:19.508565
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list_with_filtering_function = lambda x: x > 2

    assert ImmutableList.of(1, 2, 3, 4).filter(test_list_with_filtering_function).to_list(
    ) == [3, 4]

    assert ImmutableList().filter(test_list_with_filtering_function).to_list(
    ) == []

# Generated at 2022-06-24 00:15:24.442707
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_one = ImmutableList.of('first')
    list_two = ImmutableList.of('second')
    list_three = ImmutableList.of('third')

    new_list = list_one.append('new_element')

    assert new_list == ImmutableList.of('first', 'new_element')
    assert new_list != list_one
    assert new_list != list_two
    assert new_list != list_three



# Generated at 2022-06-24 00:15:34.702883
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) + ImmutableList.empty() == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3, ImmutableList(4)) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList(1) + ImmutableList(3, ImmutableList(4)) == ImmutableList(1, ImmutableList(3, ImmutableList(4)))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList

# Generated at 2022-06-24 00:15:40.857797
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # arrange
    numbers = ImmutableList.of(1, 2, 3, 4, 5)
    small_numbers = ImmutableList.of(1, 2, 3)
    even_numbers = ImmutableList.of(2, 4)
    numbers_with_even_numbers = ImmutableList.of(1, 2, 3, 4)

    # act and assert
    assert numbers.find(lambda x: x > 3) == 4
    assert numbers.find(lambda x: x < 1) is None
    assert small_numbers.find(lambda x: x > 3) is None
    assert even_numbers.find(lambda x: x % 2 == 0) == 2
    assert numbers_with_even_numbers.find(lambda x: x % 2 == 0) == 2

# Generated at 2022-06-24 00:15:49.145825
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    xs = ImmutableList.of(1, 2, 3)

    assert xs.reduce(lambda a, b: a + b, 0) == 6
    assert xs.reduce(lambda a, b: a * b, 1) == 6

    assert xs.reduce(lambda a, b: a + b, 10) == 16
    assert xs.reduce(lambda a, b: a * b, 2) == 12
test_ImmutableList_reduce()
if __name__ == "__main__":
    # Unit test for method to_list of class ImmutableList
    def test_ImmutableList_to_list():
        xs = ImmutableList.of(1, 2, 3)

        assert isinstance(xs.to_list(), list)

# Generated at 2022-06-24 00:15:57.646205
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: True) is None
    assert ImmutableList.of('a').find(lambda x: True) == 'a'
    assert ImmutableList.of('a').find(lambda x: False) is None
    assert ImmutableList.of('a', 'b', 'c', 'd').find(lambda x: x == 'c') == 'c'
    assert ImmutableList.of('a', 'b', 'c', 'd').find(lambda x: x == 'dd') is None


# Generated at 2022-06-24 00:16:04.188445
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:16:14.433313
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1) == ImmutableList.of(1).map(lambda x: x)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2).map(lambda x: x)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3).map(lambda x: x)
    assert ImmutableList.empty() == ImmutableList.empty().map(lambda x: x)

    assert ImmutableList.of(2) == ImmutableList.of(1).map(lambda x: x + 1)
    assert ImmutableList.of(2, 3) == ImmutableList.of(1, 2).map(lambda x: x + 1)

# Generated at 2022-06-24 00:16:21.265425
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift('some_value') == ImmutableList.of('some_value')
    assert ImmutableList.of(1,2,3).unshift(0) == ImmutableList.of(0,1,2,3)
    assert ImmutableList.of(1,2,3).unshift(0).unshift(-1) == ImmutableList.of(-1,0,1,2,3)

# Generated at 2022-06-24 00:16:28.104649
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Unit tests for method append of class ImmutableList

# Generated at 2022-06-24 00:16:31.417373
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(head=False, tail=None, is_empty=False) == ImmutableList(
        head=False, tail=None, is_empty=False)
    assert ImmutableList(True).tail is None
    assert ImmutableList(None).head is None
    assert ImmutableList(is_empty=None)
    assert ImmutableList(is_empty=True).is_empty is True
    assert not ImmutableList(is_empty=False).is_empty

# Generated at 2022-06-24 00:16:37.527979
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(2)
    list3 = ImmutableList.of(1, 2, 3)
    list4 = ImmutableList.of(1, 2, 3, 4)
    list5 = ImmutableList.of(4, 2, 5)
    list6 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    
    assert list3.filter(lambda x: x >= 2) == list6.filter(lambda x: x >= 2)
    assert list2.filter(lambda _: False) == list5.filter(lambda _: False)
    assert list2.filter(lambda _: True) == list5.filter(lambda _: True)
    assert list4.filter(lambda x: x >= 3) == list6.filter

# Generated at 2022-06-24 00:16:44.582048
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 5) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.of(1).find(lambda x: True) == 1
    assert ImmutableList.empty().find(lambda x: True) is None


# Generated at 2022-06-24 00:16:47.112429
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    test_object = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert test_object.to_list() == [1, 2, 3]
test_ImmutableList_to_list()