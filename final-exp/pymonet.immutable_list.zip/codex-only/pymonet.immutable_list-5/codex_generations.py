

# Generated at 2022-06-24 00:07:01.161811
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    m_list = ImmutableList(2, None, False)

    if m_list.find(lambda x: x == 2) == 2:
        print('test_ImmutableList_find: pass')

    else:
        print('test_ImmutableList_find: fail')


# Generated at 2022-06-24 00:07:05.876062
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x * 3) == ImmutableList.empty()
    assert ImmutableList.of(3, 2, 1).map(lambda x: x * 3) == ImmutableList.of(9, 6, 3)



# Generated at 2022-06-24 00:07:08.903415
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2


# Generated at 2022-06-24 00:07:10.374043
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.of(1)
    list = list.unshift(2)

    assert list == ImmutableList.of(2, 1)


# Generated at 2022-06-24 00:07:20.812777
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList()
    assert ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).append(4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3).unshift(4).to_list() == [4, 1, 2, 3]

# Generated at 2022-06-24 00:07:24.565778
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    result = ImmutableList.of(1, 2, 3).unshift(4)
    assert isinstance(result, ImmutableList)
    assert result == ImmutableList(4, ImmutableList(1, ImmutableList(2, ImmutableList(3))))

# Generated at 2022-06-24 00:07:32.711666
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # GIVEN
    immutable_list_1 = ImmutableList.of(1,2,3)
    immutable_list_2 = ImmutableList.of(4,5)

    # WHEN
    result = immutable_list_1 + immutable_list_2

    # THEN
    assert result is not immutable_list_1
    assert result is not immutable_list_2
    assert result.to_list() == [1,2,3,4,5]

# Generated at 2022-06-24 00:07:36.647677
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    sample_list = ImmutableList.of(1, 2, 3, 4, 5)

    result = sample_list.reduce(lambda x, y: x + y, 0)

    assert result == 15

test_ImmutableList_reduce()

# Generated at 2022-06-24 00:07:41.431316
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # ____
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.empty()) == 0
    # ____
    # ____
    pass

# Generated at 2022-06-24 00:07:46.535689
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(2) == ImmutableList(2)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1).append(2).to_list() == [1, 2]


# Generated at 2022-06-24 00:07:51.281334
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-24 00:07:59.962143
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3) == \
        ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)

    assert ImmutableList.of(2, 3).unshift(1) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1).unshift(2).unshift(3) == ImmutableList.of(3, 2, 1)

    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)

# Generated at 2022-06-24 00:08:07.347417
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3)
    c = ImmutableList.of(1, 2, 3)
    d = ImmutableList.of(2, 3)
    e = ImmutableList.of(1, 2, 4)

    assert a == b
    assert b == c
    assert c == a

    assert not (a == d)
    assert not (a == e)


# Generated at 2022-06-24 00:08:10.428895
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    xs = ImmutableList.of(1, 2, 3)
    ys = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert xs == ys


# Generated at 2022-06-24 00:08:18.715626
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList()
    list_2 = ImmutableList()
    assert list_1 == list_2
    list_1 = ImmutableList(1)
    list_2 = ImmutableList(1)
    assert list_1 == list_2
    list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list_1 == list_2
    

# Generated at 2022-06-24 00:08:23.016705
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of(1, 2, 3)
    second_list = ImmutableList.of(4, 5, 6)
    result = first_list + second_list
    assert result == ImmutableList.of(1, 2, 3, 4, 5, 6)



# Generated at 2022-06-24 00:08:31.832035
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3, 4) + ImmutableList.of(5, 6) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    assert ImmutableList.of(1, 2, 3, 4) + ImmutableList.of(5, 6, 7) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7)))))))
    assert ImmutableList.of(1, 2, 3, 4) + ImmutableList.of(5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
   

# Generated at 2022-06-24 00:08:33.161659
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) != ImmutableList(2)

# Generated at 2022-06-24 00:08:44.802247
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    def _test_ImmutableList_append(immutable_list: ImmutableList, new_element: int, expected_list: list):
        result = immutable_list.append(new_element)

        assert isinstance(result, ImmutableList), 'returns instance of ImmutableList'
        assert len(result) == len(expected_list), 'returns immutable list with right length'
        assert result.to_list() == expected_list, 'returns immutable with right elements'
        assert result.tail == immutable_list, 'returns immutable with right tail'
        assert result.head == new_element, 'returns immutable with right head'


# Generated at 2022-06-24 00:08:49.406309
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(2, 3).unshift(1) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(3, 4, 5).unshift(2) == ImmutableList.of(2, 3, 4, 5)

test_ImmutableList_unshift()

# Generated at 2022-06-24 00:08:57.774347
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    def is_odd(x):
        return x % 2 != 0

    list_under_test = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert list_under_test.find(is_odd) == 1

    list_under_test = ImmutableList.of(2, 4, 6)
    assert list_under_test.find(is_odd) is None

    list_under_test = ImmutableList.of()
    assert list_under_test.find(is_odd) is None


# Generated at 2022-06-24 00:09:09.458611
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list_empty = ImmutableList.empty()
    list_one_element = ImmutableList.of(1)
    list_two_elements = ImmutableList.of(1, 2)

    assert list_empty.head == None    
    assert list_empty.tail == None
    assert list_empty.is_empty == True

    assert list_one_element.head == 1
    assert list_one_element.tail == None
    assert list_one_element.is_empty == False
    assert list_one_element.to_list() == [1]

    assert list_two_elements.head == 1
    assert list_two_elements.tail.head == 2
    assert list_two_elements.tail.tail == None
    assert list_two_elements.is_empty == False
    assert list_two_

# Generated at 2022-06-24 00:09:14.046604
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3).to_list() != [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3).to_list() != [1, 2]


# Generated at 2022-06-24 00:09:20.630877
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    items = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(3, ImmutableList(4, ImmutableList(5))))))
    assert items.filter(lambda number: number % 2 == 0) == ImmutableList(2, ImmutableList(4))
    assert items.filter(lambda number: number > 100) == ImmutableList(is_empty=True)


# Generated at 2022-06-24 00:09:25.277357
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(0)) == 1
    assert len(ImmutableList(0, ImmutableList(1))) == 2
    assert len(ImmutableList(0, ImmutableList(1, ImmutableList(2)))) == 3
    assert len(ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))) == 4

# Generated at 2022-06-24 00:09:29.101933
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    """
    Test is checking if method __str__ will return string
    """
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]'


# Generated at 2022-06-24 00:09:31.836427
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    fn = lambda x: x + 1
    result = ImmutableList.of(1, 2, 3) \
        .map(fn)
    assert ImmutableList.of(2, 3, 4) == result

# Generated at 2022-06-24 00:09:34.398578
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of('test', 'test 2', 'test 3').map(len) == ImmutableList.of(4, 8, 9)


# Generated at 2022-06-24 00:09:39.129007
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # test empty list
    assert len(ImmutableList.empty()) == 0
    # test list of list
    assert len(ImmutableList.of([1, 2, 3])) == 1
    # test list of 2 elements
    assert len(ImmutableList.of(3, 4)) == 2
    # test list of 4 elements
    assert len(ImmutableList.of(2, 3, 4, 5)) == 4


# Generated at 2022-06-24 00:09:49.232202
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print("Test 1: ", end='')
    expected = ImmutableList.of(2)
    actual = ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0)
    assert actual == expected
    print("Passed")

    print("Test 2: ", end='')
    expected = ImmutableList.of(2)
    actual = ImmutableList.empty().append(2).\
        append(3).\
        filter(lambda x: x % 2 == 0)
    assert actual == expected
    print("Passed")

    print("Test 3: ", end='')
    expected = ImmutableList()
    actual = ImmutableList.of(1, 3, 5).filter(lambda x: x % 2 == 0)
    assert actual == expected
    print("Passed")

# Generated at 2022-06-24 00:09:52.368790
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-24 00:10:01.472914
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    """
    Unit test for method unshift of class ImmutableList
    """
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(2, 3, 4).unshift(1) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(3, 4).unshift(2).unshift(1) == ImmutableList.of(1, 2, 3, 4)
    assert (
        ImmutableList.of(4).unshift(3).unshift(2).unshift(1) ==
        ImmutableList.of(1, 2, 3, 4)
    )


# Generated at 2022-06-24 00:10:09.478565
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of('a')) == 'ImmutableList[\'a\']'
    assert str(ImmutableList.of('a', 'b', 'c')) == 'ImmutableList[\'a\', \'b\', \'c\']'


# Generated at 2022-06-24 00:10:19.195037
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1).filter(lambda x: x != 1) == ImmutableList.of()
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of().filter(lambda x: x == 1) == ImmutableList.of()



# Generated at 2022-06-24 00:10:24.302593
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    A = ImmutableList.of(1, 2)
    B = A.append(3)

    assert A.to_list() == [1, 2]
    assert B.to_list() == [1, 2, 3]
    assert A.head == 1
    assert A.tail.head == 2

test_ImmutableList_append()

# Generated at 2022-06-24 00:10:27.209671
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert a == b


# Generated at 2022-06-24 00:10:33.746711
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l1 = ImmutableList.of(1, 2, 3)
    l2 = l1.filter(lambda x: x % 2 == 0)

    assert l2.head == 2
    assert l2.tail.head == None
    assert l2.tail.tail == None
    assert l2.tail == ImmutableList.of()

    l1 = ImmutableList.of(1, 2, 3)
    l2 = l1.filter(lambda x: x % 2 == 1)

    assert l2.head == 1
    assert l2.tail.head == 3
    assert l2.tail.tail == None
    assert l2.tail == ImmutableList.of(3)


# Generated at 2022-06-24 00:10:39.180698
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    _list = ImmutableList.of(1, 2, 3)
    assert _list.reduce(lambda x, y: x + y, 0) == 6

# Generated at 2022-06-24 00:10:42.424844
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList.of(1,2,3) + ImmutableList(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-24 00:10:47.095308
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList.of(1,2,3,4,5)
    assert list1.find(lambda x: x == 3) == 3
    assert list1.find(lambda x: x == 10) is None

    list2 = ImmutableList.empty()
    assert list2.find(lambda x: x == 3) is None
    
    

# Generated at 2022-06-24 00:10:48.918678
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.empty().to_list() == []



# Generated at 2022-06-24 00:10:51.118954
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList[]' == str(ImmutableList.empty())
    assert 'ImmutableList[1]' == str(ImmutableList(1))
    assert 'ImmutableList[1, 2, 3]' == str(ImmutableList.of(1, 2, 3))


# Generated at 2022-06-24 00:10:54.109965
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    array = ImmutableList.of(1, 2, 3, 4, 5)
    assert array.to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-24 00:10:59.230988
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    input = ImmutableList.of(1, 2, 3)
    expected_output = 'ImmutableList[1, 2, 3]'
    output = input.__str__()

    assert output == expected_output


# Generated at 2022-06-24 00:11:02.024002
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(0, 1, 2, 3).unshift(-1) == ImmutableList.of(-1, 0, 1, 2, 3)


test_ImmutableList_unshift()

# Generated at 2022-06-24 00:11:08.939220
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    import pytest
    def test_constructor_empty_list():
        i_list = ImmutableList()

        assert i_list.head is None
        assert i_list.tail is None
        assert i_list.is_empty == True

    def test_constructor_non_empty_list():
        i_list = ImmutableList(1)

        assert i_list.head == 1
        assert i_list.tail is None
        assert i_list.is_empty == False

    def test_constructor_not_empty_list_with_tail():
        list_tail = ImmutableList(2)
        i_list = ImmutableList(1, list_tail)

        assert i_list.head == 1
        assert i_list.tail == list_tail
        assert i_list.is_empty == False


# Generated at 2022-06-24 00:11:12.901905
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc + x, 0) == 6

# Generated at 2022-06-24 00:11:18.718559
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-24 00:11:25.023546
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    print('Test map:')
    print()
    list = ImmutableList.of(1, 2, 3, 4, 5)
    print('Current list: {}'.format(list))

    expected = ImmutableList.of(1, 4, 9, 16, 25)
    result = list.map(lambda x: x**2)
    print('Result of list.map(lambda x: x**2): {}'.format(result))
    print('Expected result: {}'.format(expected))

    assert result == expected


# Generated at 2022-06-24 00:11:28.286967
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l = ImmutableList.of(1, 2, 3)
    l = l.append(4)
    assert len(l) == 4
    assert l == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-24 00:11:33.720388
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # arrange
    test_list = ImmutableList.of(1, 2, 3, 4)
    # act
    mapped = test_list.map(lambda x: x*x)
    # assert
    assert mapped.to_list() == [1, 4, 9, 16]



# Generated at 2022-06-24 00:11:44.408614
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    data = [
        (
            ImmutableList.empty(),
            (lambda x: x == True),
            None
        ),
        (
            ImmutableList(
                'fnord'
            ),
            (lambda x: x == 'fnord'),
            'fnord'
        ),
        (
            ImmutableList(
                'fnord',
                ImmutableList(
                    'baz',
                    ImmutableList(
                        'bar',
                        ImmutableList(
                            'baz'
                        )
                    )
                )
            ),
            (lambda x: x == 'baz'),
            'baz'
        )
    ]
    for list_ in data:
        assert list_[2] == list_[0].find(list_[1])

# Generated at 2022-06-24 00:11:49.166878
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1)\
        .reduce(lambda acc, x: x, None) == 1
    assert ImmutableList.of(1, 2, 3)\
        .reduce(lambda acc, x: x, None) == 1
    assert ImmutableList.of(1, 2, 3)\
        .reduce(lambda acc, x: acc + x, 0) == 6

    assert ImmutableList.empty()\
        .reduce(lambda acc, x: x, 1) == 1



# Generated at 2022-06-24 00:11:54.784465
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]



# Generated at 2022-06-24 00:12:00.149130
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    empty_list = ImmutableList.empty()
    assert isinstance(empty_list, ImmutableList)
    assert str(empty_list) == 'ImmutableList[]'

    list_with_elements = ImmutableList.of(1, 2, 3, 4, 5)
    assert isinstance(list_with_elements, ImmutableList)
    assert str(list_with_elements) == 'ImmutableList[1, 2, 3, 4, 5]'


# Generated at 2022-06-24 00:12:04.503272
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # given
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(2, 3, 4)
    list3 = ImmutableList.empty()

    # when
    len_1 = len(list1)
    len_2 = len(list2)
    len_3 = len(list3)

    # then
    assert len_1 == 3
    assert len_2 == 3
    assert len_3 == 0


# Generated at 2022-06-24 00:12:07.355891
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda acc, element: acc + element, 0) == 0
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, element: acc + element, 0) == 15

# Generated at 2022-06-24 00:12:10.109934
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:12:13.851217
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'

# Generated at 2022-06-24 00:12:22.292218
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) == Immutable

# Generated at 2022-06-24 00:12:25.137364
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]'

# Generated at 2022-06-24 00:12:32.049451
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    test_data = [
        ([1, 2, 3, 4], 2, [1, 2, 3, 4, 5]),
        ([4, 5, 6], 8, [4, 5, 6, 8]),
        ([1, 2, 3, 4], None, [1, 2, 3, 4])
    ]

    def test_fn(test_input, expected_result):
        result = ImmutableList.of(*test_input[0]).unshift(test_input[1])
        assert result.to_list() == test_input[2]
    
    for pair in test_data:
        test_fn(pair, pair[2])


# Generated at 2022-06-24 00:12:35.020643
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:12:39.858217
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2) == ImmutableList.of(1, 3)
    assert ImmutableList.of(10, 11, 12).filter(lambda x: x % 2) == ImmutableList.of(11)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2) != ImmutableList.of(1, 2)



# Generated at 2022-06-24 00:12:44.613811
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    a = ImmutableList.of(1, 2)
    b = ImmutableList.of(1, 2)
    c = ImmutableList.of(1, 2, 3)

    assert a == b
    assert a != c
    assert len(a) == 2
    assert a.head == 1
    assert a.tail.head == 2
    assert a.tail.tail is None


# Generated at 2022-06-24 00:12:49.244350
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of().to_list() == []
    assert ImmutableList.empty().to_list() == []



# Generated at 2022-06-24 00:12:52.647811
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    words = ImmutableList.of('one', 'two', 'three')
    assert(str(words.append('four')) == 'ImmutableList[one, two, three, four]')

# Generated at 2022-06-24 00:13:01.166428
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    List = ImmutableList
    MList = List.of(1)
    assert List.of(1) == MList
    assert MList.head == 1
    assert MList.tail is None
    MList = List.of(1, 2, 3, 4)
    assert MList.tail.tail.tail.tail.tail is None
    assert MList.head == 1
    assert MList.tail.head == 2
    assert MList.tail.tail.head == 3
    assert MList.tail.tail.tail.head == 4

test_ImmutableList()

# Generated at 2022-06-24 00:13:11.929555
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of().append(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4).append(
        5).append(6).append(7) == ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert ImmutableList.of(1, 2, 3, 4).append(
        5).append(6).append(7).append(8).append(9).append(10) == ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)



# Generated at 2022-06-24 00:13:16.534075
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():

    # Given
    immutable_lst = ImmutableList.of(1, 2, 3)
    expected = [1,2, 3]

    # When
    result = immutable_lst.to_list()

    # Then
    assert result == expected
    assert immutable_lst.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:13:21.390601
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    mList = ImmutableList(
        ImmutableList(1, ImmutableList(2), False),
        ImmutableList(3, ImmutableList(4), False),
        False
    )
    assert len(mList) == 4, "test_ImmutableList___len__() failed"



# Generated at 2022-06-24 00:13:27.666059
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Test 1
    assert ImmutableList(1) == ImmutableList(1) == ImmutableList.of(1)
    # Test 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3)
    # Test 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-24 00:13:32.045433
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Given empty list with no elements
    # When
    empty_list = ImmutableList.empty()
    # Then
    assert empty_list.head is None
    assert empty_list.tail is None
    assert empty_list.is_empty is True


# Generated at 2022-06-24 00:13:34.941260
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(4).to_list() == [4, 1, 2, 3]



# Generated at 2022-06-24 00:13:37.339811
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    instance = ImmutableList.of(1, 2, 3)

    assert instance.unshift(0) == ImmutableList.of(0, 1, 2, 3)


# Generated at 2022-06-24 00:13:39.747842
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4, 5)) == "ImmutableList[1, 2, 3, 4, 5]"


# Generated at 2022-06-24 00:13:48.780741
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present']
    expected = ['spray', 'exuberant', 'present']
    # When
    actual = ImmutableList.of(*words).filter(lambda word: len(word) > 6)
    # Then
    assert all(ac == ex for ac, ex in zip(actual.to_list(), expected)), \
        "Expected {} got {}".format(expected, actual.to_list())


# Generated at 2022-06-24 00:13:51.353903
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Given
    target = ImmutableList.of(1)

    # When
    result = len(target)

    # Then
    assert result == 1



# Generated at 2022-06-24 00:13:54.889031
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = ImmutableList.empty()

    assert list1.reduce(lambda x, y: x + y, 0) == 10
    assert list2.reduce(lambda x, y: x + y, 0) == 0

# Generated at 2022-06-24 00:14:00.531010
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList(1)
    list2 = list_.append(2)
    list3 = list2.append(3)

    assert list_ == ImmutableList(1)
    assert list2 == ImmutableList(1, ImmutableList(2))
    assert list3 == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-24 00:14:04.814945
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(3)) == 'ImmutableList[3]'
    assert str(ImmutableList.of(3, 4, 5)) == 'ImmutableList[3, 4, 5]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'


# Generated at 2022-06-24 00:14:09.965145
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, ImmutableList.of(2, 3), 4, 5)) == 'ImmutableList[1, ImmutableList[2, 3], 4, 5]'
    assert str(ImmutableList.empty()) == 'ImmutableList[None]'


# Generated at 2022-06-24 00:14:17.974679
# Unit test for constructor of class ImmutableList
def test_ImmutableList():  # pragma: no cover
    l = ImmutableList(1)
    assert l.head == 1
    assert l.tail is None

    l = ImmutableList(1, ImmutableList(2))
    assert l.head == 1
    assert l.tail.head == 2

    l = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert l.head == 1
    assert l.tail.head == 2
    assert l.tail.tail.head == 3
    assert l.tail.tail.tail is None



# Generated at 2022-06-24 00:14:25.579780
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    list1 = ImmutableList.empty()
    list2 = ImmutableList.of(1)
    list3 = ImmutableList.of(1, 2, 3)
    # Then
    assert(list1.to_list() == [])
    assert(list2.to_list() == [1])
    assert(list3.to_list() == [1, 2, 3])


# Generated at 2022-06-24 00:14:29.813968
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x:x) == ImmutableList.empty()
    assert ImmutableList.of(0,1,2,3,4).map(lambda x:x * x) == ImmutableList.of(0,1,4,9,16)

# Generated at 2022-06-24 00:14:32.864212
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3).to_list() != [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4).to_list() != [1, 2, 3]


# Generated at 2022-06-24 00:14:41.995777
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).append(4).append(5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

# Unit test

# Generated at 2022-06-24 00:14:46.777673
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    lst = ImmutableList.of(3, 1, 2)
    new_list = lst.filter(lambda x: x > 1)
    assert new_list.head == 3
    assert new_list.tail.head == 2
    assert new_list.tail.tail is None


# Generated at 2022-06-24 00:14:52.676826
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    l1 = ImmutableList.of(1)
    l2 = ImmutableList(1)

    assert l1 == l2
    assert l1.head == 1
    assert l1.tail is None
    assert isinstance(l1, ImmutableList)
    
    
l1 = ImmutableList.of(1)
assert l1.head == 1
assert l1.tail is None

l2 = ImmutableList.of(1, 2, 3)
assert l2.head == 1
assert l2.head.tail == 2
assert l2.head.tail.tail == 3
assert l2.head.tail.tail.tail is None

# Generated at 2022-06-24 00:14:54.061418
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-24 00:14:56.945233
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]' # 1
    assert str(ImmutableList.empty()) == 'ImmutableList[]' # 2
    

# Generated at 2022-06-24 00:15:05.117494
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 8) is None
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).find(lambda x: x == 6) == 6
    assert ImmutableList.empty().find(lambda x: x == 8) is None

# Generated at 2022-06-24 00:15:11.196175
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert_that(
        ImmutableList.of(1, 2, 3).unshift(4),
        contains(4, 1, 2, 3)
    )

# Generated at 2022-06-24 00:15:17.571911
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    """
    Unit test for method append of class ImmutableList
    """
    test_il = ImmutableList.of('1', '2')

    result = test_il.append('3')

    assert isinstance(result, ImmutableList)
    assert result.to_list() == ['1', '2', '3']


# Generated at 2022-06-24 00:15:20.180092
# Unit test for method map of class ImmutableList
def test_ImmutableList_map(): # pragma: no cover
    nums = ImmutableList.of(1, 2, 3).map(lambda x: x * 2)
    assert nums == ImmutableList.of(2, 4, 6), 'ImmutableList.map does not work'



# Generated at 2022-06-24 00:15:23.900866
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert list_.reduce(lambda acc, item: acc + item, 0) == 10



# Generated at 2022-06-24 00:15:25.468764
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList == type(ImmutableList())


# Generated at 2022-06-24 00:15:30.975682
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of('A', 'B', 'C')) == 'ImmutableList[A, B, C]'


# Generated at 2022-06-24 00:15:33.575041
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():   
    list_one = ImmutableList.of(1, 2, 3, 4)

    assert list_one.unshift(0) == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))))


# Generated at 2022-06-24 00:15:38.694966
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.empty().append(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1).append(1).append(2) == ImmutableList(1, ImmutableList(1, ImmutableList(2)))
    assert ImmutableList(1).append(1).append(2) == ImmutableList(1, ImmutableList(1, ImmutableList(2)))
    assert ImmutableList(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

test_ImmutableList_append()

# Generated at 2022-06-24 00:15:47.610424
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList('#', ImmutableList('#')) == ImmutableList('#', ImmutableList('#'))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) != 1

# Generated at 2022-06-24 00:15:58.903440
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList(
        head='head_value',
        tail=ImmutableList(
            head='tail_value',
            tail=ImmutableList.empty()
        )
    )
    second_list = ImmutableList(
        head='second_head_value',
        tail=ImmutableList(
            head='second_tail_value',
            tail=ImmutableList.empty()
        )
    )
    assert first_list + second_list == ImmutableList(
        head='head_value', 
        tail=ImmutableList(
            head='tail_value', 
            tail=ImmutableList(
                head='second_head_value', 
                tail=ImmutableList.of('second_tail_value')
                )
            )
        )



# Generated at 2022-06-24 00:16:04.637517
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == "ImmutableList[1]"
    assert str(ImmutableList([1, 2, 3])) == "ImmutableList[[1, 2, 3]]"
    assert str(ImmutableList(None)) == "ImmutableList[None]"
    assert str(ImmutableList()) == "ImmutableList[]"


# Generated at 2022-06-24 00:16:08.997224
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    empty_list = ImmutableList.empty()
    assert empty_list.head == None
    assert empty_list.is_empty == True
    list_one_element = ImmutableList(1)
    assert list_one_element.head == 1
    assert list_one_element.tail == None
    assert list_one_element.is_empty == False
    list_two_elements = ImmutableList(1, ImmutableList(2))
    assert list_two_elements.head == 1
    assert list_two_elements.tail == ImmutableList(2)
    assert list_two_elements.is_empty == False

# Generated at 2022-06-24 00:16:11.279230
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(3, 4, 5).map(lambda x: x + 1) == ImmutableList.of(4, 5, 6)

# Generated at 2022-06-24 00:16:19.373435
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5) \
        .filter(lambda x: x > 1) \
        == ImmutableList.of(2, 3, 4, 5)

    assert ImmutableList.of(1, 2, 3, 4, 5) \
        .filter(lambda x: x > 1) \
        != ImmutableList.of(3, 4, 5)

    assert ImmutableList.of(1, 2, 3, 4, 5) \
        .filter(lambda x: x > 1) \
        != ImmutableList.of(2, 3, 4, 5, 6)

    assert ImmutableList.empty() == ImmutableList.empty()

# Generated at 2022-06-24 00:16:24.880828
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)


# Generated at 2022-06-24 00:16:29.370482
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    input = ImmutableList.of(1, 2, 3)
    expected = ImmutableList.of(1, 2, 3, 4)

    test_input = input.append(4)

    assert test_input == expected

# Generated at 2022-06-24 00:16:34.719783
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of('a')
    assert l.unshift('b') == ImmutableList.of('b', 'a'), \
        'while calling unshift on ImmutableList function, expected ImmutableList[\'b\', \'a\']'

    l = ImmutableList.of('a', 'b')
    assert l.unshift('c') == ImmutableList.of('c', 'a', 'b'), \
        'while calling unshift on ImmutableList function, expected ImmutableList[\'c\', \'a\', \'b\']'


# Generated at 2022-06-24 00:16:43.142806
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():  # pragma: no cover
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 != 0) == ImmutableList.of(1, 3, 5)
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()

# Generated at 2022-06-24 00:16:48.672895
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    empty_list = ImmutableList.empty()

    list1 = ImmutableList(12)
    list2 = list1.append(14)
    list3 = list2.append(13)
    list4 = list3.append(16)
    list5 = list4.append(0)
    list6 = list5.append(0)
    list7 = list6.append(0)

    assert list7 == ImmutableList(12, ImmutableList(14, ImmutableList(13, ImmutableList(16, ImmutableList(0, ImmutableList(0, ImmutableList(0)))))))


# Generated at 2022-06-24 00:16:55.328263
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_0 = ImmutableList()
    list_1 = ImmutableList(5)
    list_2 = list_1 + list_0
    list_3 = list_0 + list_1
    list_4 = ImmutableList(10) + ImmutableList(20)

    assert list_2.head == 5
    assert list_2.tail is None

    assert list_3.head == 5
    assert list_3.tail is None

    assert list_4.head == 10
    assert list_4.tail.head == 20


# Generated at 2022-06-24 00:16:59.441390
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    test_list = ImmutableList.of(5, 3, 4, 10, 9, 8)
    fn = lambda x: x > 5
    # When
    result = test_list.filter(fn)
    # Then
    assert result == ImmutableList.of(10, 9, 8)
