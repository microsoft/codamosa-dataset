

# Generated at 2022-06-24 00:07:02.233527
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    test_list = ImmutableList.empty()

    assert test_list == ImmutableList()

    test_list = test_list.unshift(3)

    assert test_list == ImmutableList(3)

    test_list = test_list.unshift(2)

    assert test_list == ImmutableList(2, ImmutableList(3))

    test_list = test_list.unshift(1)

    assert test_list == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:07:06.689847
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(5) == ImmutableList(5)
    assert ImmutableList(5, ImmutableList(10), False) == ImmutableList(5, ImmutableList(10), False)
    assert ImmutableList() != None
    assert ImmutableList(1) != 1



# Generated at 2022-06-24 00:07:14.092223
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1,2,3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of("1", 2, 3).map(lambda x: x + 1) == ImmutableList.of("11", 3, 4)
    assert ImmutableList.of("1", 2, "3").map(lambda x: x + 1) == ImmutableList.of("11", 3, "31")
    assert ImmutableList.of().map(lambda x: x + 1) == ImmutableList.of()

# Generated at 2022-06-24 00:07:24.566202
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3).append(4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3).append(4).head == 1
    assert ImmutableList.of(1, 2, 3).append(4).tail.head == 2
    assert ImmutableList.of(1, 2, 3).append(4).tail.tail.head == 3
    assert ImmutableList.of(1, 2, 3).append(4).tail.tail.tail.head == 4
    assert ImmutableList.of(1, 2, 3).append(4).tail.tail.tail.tail is None


# Unit test

# Generated at 2022-06-24 00:07:28.918208
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1,2)) == 2
    assert len(ImmutableList.of(1,2,3)) == 3


# Generated at 2022-06-24 00:07:34.461938
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5
    assert len(ImmutableList.of()) == 0
    assert len(ImmutableList(1).unshift(2).append(3)) == 3



# Generated at 2022-06-24 00:07:38.899398
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList(head=1) == ImmutableList(1)
    assert ImmutableList(head=1, tail=ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-24 00:07:45.987270
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList(1, ImmutableList(2))
    b = ImmutableList(3, ImmutableList(4))

    c = a + b

    assert c.head == 1
    assert c.tail.head == 2
    assert c.tail.tail.head == 3
    assert c.tail.tail.tail.head == 4
    assert c.tail.tail.tail.tail is None



# Generated at 2022-06-24 00:07:48.206185
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

test_ImmutableList_filter()

# Generated at 2022-06-24 00:07:51.711342
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    print('Unit test for __str__ of class ImmutableList')
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    print('OK!')


# Generated at 2022-06-24 00:07:59.523107
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert list_.append(4).append(5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert list_ == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list_.append(1) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(1))))

test_ImmutableList_append()

# Generated at 2022-06-24 00:08:09.004119
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of(1, 2, 3, 4)
    b = ImmutableList.of(1, 2, 3, 4)

    assert (a == b) is True

    a = ImmutableList.of(1, 2, 3, 4)
    b = ImmutableList.of(2, 3, 4, 5)

    assert (a == b) is False

    a = ImmutableList.of(1, 2, 3, 4)
    b = ImmutableList.of(1, 2, 3, 4, 5)

    assert (a == b) is False

# Generated at 2022-06-24 00:08:13.966227
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    xs = ImmutableList.of('1')
    xs2 = ImmutableList.of('2', '3')

    assert xs == ImmutableList('1')
    assert xs2 == ImmutableList('2', ImmutableList('3'))


# Generated at 2022-06-24 00:08:18.117728
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(11) == ImmutableList(11)

    assert ImmutableList.of(1, 2, 3).append(11) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(11))))

# Generated at 2022-06-24 00:08:21.540444
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).reduce(lambda acc, item: acc + item, 0) == 10

# Generated at 2022-06-24 00:08:29.905018
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # TEST 1
    my_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert my_list == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert my_list.to_list() == [1, 2, 3, 4, 5]
    assert str(my_list) == 'ImmutableList[1, 2, 3, 4, 5]'
    
    # TEST 2
    my_another_list = ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9))))
    assert my_another_list == ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9))))

# Generated at 2022-06-24 00:08:33.042114
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    left = ImmutableList(1, ImmutableList(2))
    right = ImmutableList(1, ImmutableList(2))
    assert left.__eq__(right)



# Generated at 2022-06-24 00:08:37.504902
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty().append(1) == ImmutableList.of(1)


# Generated at 2022-06-24 00:08:43.410743
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(3, 2, 1)


# Generated at 2022-06-24 00:08:45.293535
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList(1).__str__() == "ImmutableList[1]"
    assert ImmutableList(1, ImmutableList(2)).__str__() == "ImmutableList[1, 2]"



# Generated at 2022-06-24 00:08:48.506877
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:08:51.327994
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l = ImmutableList.of(4)
    l = l.append(8)
    
    assert l == ImmutableList.of(4, 8)



# Generated at 2022-06-24 00:09:01.346761
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    from io import StringIO
    import sys
    from unittest.mock import patch

    expected = ['1', '1', '1', '1']
    capturedOutput = StringIO()
    with patch('sys.stdout', new=capturedOutput):
        sys.stdout.write(str(ImmutableList.of(1, 1, 1, 1).filter(lambda x: x > 0).to_list()) + '\n')
        sys.stdout.write(str(ImmutableList.of(1, 1, 1, 1).filter(lambda x: x < 1).to_list()) + '\n')
        sys.stdout.write(str(ImmutableList.of(1, 1, 1, 1).filter(lambda x: x == 1).to_list()) + '\n')

# Generated at 2022-06-24 00:09:03.453550
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)

# Generated at 2022-06-24 00:09:05.187115
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of('A').append('B') == ImmutableList.of('A', 'B')

    assert ImmutableList.of('A', 'B').append('C') == ImmutableList.of('A', 'B', 'C')



# Generated at 2022-06-24 00:09:10.564785
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList[int].empty().__str__() == 'ImmutableList[]'
    assert ImmutableList(1).__str__() == 'ImmutableList[1]'
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).__str__() == 'ImmutableList[1, 2, 3]'
    assert ImmutableList.of(1, 2, 3).__str__() == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:09:15.936096
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x,y: x+y, 3) == 18
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x,y: x+y, 0) == 15
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x,y: x*y, 1) == 120

# Generated at 2022-06-24 00:09:23.961502
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5
    assert len(ImmutableList.of(1, 2, 3, 4, 5).append(6)) == 6
    assert len(ImmutableList.of(1, 2, 3, 4, 5).append(6)) == 6
    assert len(ImmutableList.of(1, 2, 3, 4, 5).unshift(0)) == 6


test_ImmutableList___len__()

# Generated at 2022-06-24 00:09:30.585254
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(ImmutableList()) == True
    assert ImmutableList(1).__eq__(ImmutableList()) == False
    assert ImmutableList(1).__eq__(ImmutableList(2)) == False
    assert ImmutableList(1).__eq__(ImmutableList(1)) == True
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1, ImmutableList(2))) == True
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1, ImmutableList(3))) == False

# Generated at 2022-06-24 00:09:37.309964
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x == 3) == ImmutableList(3)
    assert ImmutableList().filter(lambda x: x == 1) == ImmutableList()



# Generated at 2022-06-24 00:09:45.321594
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    new_list = ImmutableList.of(1, 2, 3)
    assert new_list.__add__(new_list) == ImmutableList(1, ImmutableList(2, ImmutableList(3,
            ImmutableList(1, ImmutableList(2, ImmutableList(3))))))
    new_list = ImmutableList.of(1, 2, 3)
    assert new_list.__add__(ImmutableList.of(1, 2, 3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3,
            ImmutableList(1, ImmutableList(2, ImmutableList(3))))))
    with raises(ValueError):
        new_list = ImmutableList.of(1, 2, 3)
        assert new_list.__add__(1) == 1

# Unit test

# Generated at 2022-06-24 00:09:50.897386
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    lst = ImmutableList(1, ImmutableList(2))
    lst2 = ImmutableList(3, ImmutableList(4))
    lst = lst + lst2
    assert lst.to_list() == [1, 2, 3, 4]

# Generated at 2022-06-24 00:09:56.012355
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_instance = ImmutableList.of(1, 2, 3)
    assert len(list_instance) == 3

    empty_list = ImmutableList.empty()
    assert len(empty_list) == 0


# Generated at 2022-06-24 00:10:03.805822
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # given
    lst = ImmutableList.of(10, 20, 30)
    
    # when
    new_lst = lst.append(40)

    # then
    assert len(new_lst) == len(lst) + 1
    assert new_lst.head == 10
    assert new_lst.tail.head == 20
    assert new_lst.tail.tail.head == 30
    assert new_lst.tail.tail.tail.head == 40


# Generated at 2022-06-24 00:10:11.607589
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2).to_list() == [2, 1]
    assert ImmutableList.of(1).unshift(2).unshift(3).unshift(4).to_list() == [4, 3, 2, 1]
    assert ImmutableList.of(1).unshift(2).unshift(3).unshift(4).unshift(5).to_list() == [5, 4, 3, 2, 1]
    assert ImmutableList.empty().unshift(1).to_list() == [1]

# Generated at 2022-06-24 00:10:16.972177
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l1 = ImmutableList(1)
    l2 = ImmutableList(2, l1)
    l3 = ImmutableList(3, l2)

    l4 = l3.append(4)
    assertion_result = l4 == ImmutableList(3, ImmutableList(2, ImmutableList(1, ImmutableList(4))))
    assert assertion_result, 'ImmutableList: append method does not work properly'



# Generated at 2022-06-24 00:10:25.123524
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).to_list() == [1, 2, 3, 4]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList().to_list() == []
    assert ImmutableList(None).to_list() == [None]
   

# Generated at 2022-06-24 00:10:30.909231
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():

    l1 = ImmutableList.of(1, 2, 3)
    l2 = ImmutableList.of(4)
    l3 = ImmutableList.of(5)

    assert l1.__add__(l2) == ImmutableList.of(1, 2, 3, 4)

    assert l1.__add__(l3) == ImmutableList.of(1, 2, 3, 5)

    assert l1.__add__(l1) == ImmutableList.of(1, 2, 3, 1, 2, 3)

    assert l1.__add__(ImmutableList.empty()) == ImmutableList.of(1, 2, 3)

    assert ImmutableList.empty().__add__(l1) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-24 00:10:38.166321
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    my_list = ImmutableList(1, ImmutableList(2))
    new_list = my_list.append(3)

    assert new_list != my_list
    assert my_list == ImmutableList(1, ImmutableList(2))
    assert new_list == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-24 00:10:40.472179
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:10:43.673842
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_of_nums = ImmutableList.of(1, 2, 3)
    list_of_strings = list_of_nums.map(str)
    expected_list_of_strings = ImmutableList.of('1', '2', '3')
    assert list_of_strings == expected_list_of_strings


# Generated at 2022-06-24 00:10:45.731221
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(1)
    list3 = ImmutableList.of(2)

    assert list1 == list2
    assert list1 != list3
    assert list1 != 1

# Generated at 2022-06-24 00:10:47.232388
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)



# Generated at 2022-06-24 00:10:53.992004
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(10, 20, 30).find(lambda x: x == 20) == 20
    assert ImmutableList.of(10, 20, 30).find(lambda x: x == 13) is None
    assert ImmutableList.of(10, 20, 30).find(lambda x: x == 30) == 30
    assert ImmutableList.of(10, 20, 30).find(lambda x: x == None) is None

# Generated at 2022-06-24 00:10:57.862680
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'


# Generated at 2022-06-24 00:11:02.219912
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    non_empty_list = ImmutableList.of(1, 2, 3)
    assert len(non_empty_list) == 3
    empty_list = ImmutableList()
    assert len(empty_list) == 0

# Generated at 2022-06-24 00:11:05.814892
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1, is_empty=False)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, is_empty=False))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-24 00:11:11.540668
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(3) == ImmutableList(3)
    assert ImmutableList.of(3, 4, 5) == ImmutableList(3, ImmutableList(4, ImmutableList(5)))
    assert ImmutableList.empty() == ImmutableList(is_empty=True)


# Generated at 2022-06-24 00:11:15.697949
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert str(list_) == "ImmutableList{[1, 2, 3]}"


# Generated at 2022-06-24 00:11:22.878582
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert isinstance(ImmutableList.of(1, 2), ImmutableList)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

test_ImmutableList_append()

# Generated at 2022-06-24 00:11:26.776778
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList[1, 2, 3, 4]' == str(ImmutableList.of(1, 2, 3, 4))
    assert 'ImmutableList[]' == str(ImmutableList.of())
    assert 'ImmutableList[1]' == str(ImmutableList.of(1))

# Generated at 2022-06-24 00:11:33.250656
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_empty = ImmutableList.empty()
    list_of_1 = ImmutableList.of(1)
    list_of_3 = ImmutableList.of(1, '2', 3)

    assert len(list_empty) == 0
    assert len(list_of_1) == 1
    assert len(list_of_3) == 3


# Generated at 2022-06-24 00:11:35.528572
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-24 00:11:39.987513
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of()) == 0


# Generated at 2022-06-24 00:11:45.587281
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    empty = ImmutableList()
    assert empty.to_list() == []

    one_elem = ImmutableList(1)
    assert one_elem.to_list() == [1]

    four_elem = ImmutableList(1, ImmutableList(2, ImmutableList(4, ImmutableList(5))))
    assert four_elem.to_list() == [1, 2, 4, 5]


# Generated at 2022-06-24 00:11:53.491759
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    array = ImmutableList()
    assert array.to_list() == []
    assert array.is_empty == True
    array = ImmutableList(1)
    assert array.to_list() == [1]
    assert array.is_empty == False
    array = ImmutableList(1, ImmutableList(2))
    assert array.to_list() == [1,2]
    array = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert array.to_list() == [1,2,3,4]


# Generated at 2022-06-24 00:12:02.035900
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 0) == 0
    assert ImmutableList.of(5).reduce(lambda x, y: x + y, 0) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x, y: x + y, 0) == 15
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x, y: x + y, 10) == 25
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x, y: x * y, 1) == 120
    assert ImmutableList.of(-1, -2, -3, 0).reduce(lambda x, y: x + y, 0) == -6

# Generated at 2022-06-24 00:12:06.343473
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(3).map(lambda x: 0) == ImmutableList.of(0)
    assert ImmutableList.of(3, 4).map(lambda x: 0) == ImmutableList.of(0, 0)


# Generated at 2022-06-24 00:12:13.518656
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    a_list = ImmutableList.of(1, 2, 3)

    assert a_list.head == 1
    assert a_list.tail.head == 2
    assert a_list.tail.tail.head == 3
    assert a_list.tail.tail.tail is None
    assert len(a_list) == 3
    assert a_list.to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:12:17.725241
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    class TestFirstInstance:
        assert ImmutableList(1) == ImmutableList(1)

    class TestSecondInstance:
        assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

test_ImmutableList()

# Generated at 2022-06-24 00:12:21.954210
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList.of(1, 2, 3, 4)
    result = a.reduce(lambda acc, x: acc + x, 0)
    expected = 10
    assert result == expected


# Generated at 2022-06-24 00:12:27.974731
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3, 4, 5)

    expected = ImmutableList.of(2)
    result = list.filter(lambda x: x == 2)

    assert result == expected

    expected = ImmutableList.of(2, 4)
    result = list.filter(lambda x: x % 2 == 0)

    assert result == expected


# Generated at 2022-06-24 00:12:37.769438
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    test_values = [
        ('test string', None),
        ('test string 2', 'test string'), 
        ('test string 3', 'test string 2'),
        ('test string 4', 'test string 3'),
        ('test string 5', 'test string 4')
    ]

    def concat_with_acc(acc, value):
        return f'{acc} {value}'

    from_py_list = ImmutableList.of(*[value[0] for value in test_values])

    expected_result = [concat_with_acc(value[1], value[0]) for value in test_values]

    actual_result = from_py_list.reduce(concat_with_acc, ' ')

    assert actual_result == expected_result

# Generated at 2022-06-24 00:12:40.022776
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # simple elements are added in the end of list
    assert ImmutableList.of("a", "b", "c").unshift("d") == ImmutableList("d", ImmutableList("a", ImmutableList("b", ImmutableList("c"))))

    # empty ImmutableList isn't affected by unshifting
    assert ImmutableList.empty().unshift("a") == ImmutableList.empty()

    

# Generated at 2022-06-24 00:12:42.913567
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    array1 = ImmutableList.of(1)
    array2 = array1.append(2)

    assert array1 == ImmutableList.of(1)
    assert array2 == ImmutableList.of(1, 2)



# Generated at 2022-06-24 00:12:45.473386
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList(1, ImmutableList(2))

    assert list_.append(3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-24 00:12:51.495610
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    empty_list = ImmutableList.empty()
    list_a = ImmutableList.of('a', 'b', 'c')
    list_b = ImmutableList.of('d', 'e', 'f')

    assert list_a + empty_list == ImmutableList.of('a', 'b', 'c')
    assert empty_list + list_a == ImmutableList.of('a', 'b', 'c')
    assert list_a + list_b == ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f')


# Generated at 2022-06-24 00:12:58.216516
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    empty_list = ImmutableList()
    assert len(empty_list) == 0

    single_element_list = ImmutableList(1)
    assert len(single_element_list) == 1

    list_with_many_elements = ImmutableList.of(1, 2, 3, 4, 5)
    assert len(list_with_many_elements) == 5

# Generated at 2022-06-24 00:13:03.063798
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    l = ImmutableList.of(1, 2, 3, 4, 5)

    # Act
    l2 = l.filter(lambda x: x < 4)

    # Assert
    assert l2 == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-24 00:13:14.769881
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    empty_list = ImmutableList.empty()
    actual = empty_list.filter(lambda x: x % 2 == 0)
    expected = ImmutableList.empty()
    assert actual == expected

    one_element_list = ImmutableList.of(1)
    actual = one_element_list.filter(lambda x: x % 2 == 0)
    expected = ImmutableList.empty()
    assert actual == expected

    greater_than_zero = ImmutableList.of(1, 2, 3, 4, 5, 6)
    actual = greater_than_zero.filter(lambda x: x % 2 == 0)
    expected = ImmutableList.of(2, 4, 6)
    assert actual == expected

    mixed_list = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    actual

# Generated at 2022-06-24 00:13:19.308524
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(4, 5, 6)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:13:29.238507
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() == ImmutableList.empty().__add__(ImmutableList.empty())
    assert ImmutableList.empty() != ImmutableList.empty().__add__(ImmutableList.of(1))
    assert ImmutableList.of(1) == ImmutableList.empty().__add__(ImmutableList.of(1))
    assert ImmutableList.of(1) == ImmutableList.of(1).__add__(ImmutableList.empty())
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2).__add__(ImmutableList.of(3))
    assert ImmutableList.of(1) != ImmutableList.of(1, 2).__add__(ImmutableList.of(3))

# Generated at 2022-06-24 00:13:31.944347
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(4, 6, 8, 10, 12).reduce(
        lambda acc, x: acc + x, 0
    ) == 40

# Generated at 2022-06-24 00:13:34.843463
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    immutable_list = ImmutableList()
    immutable_list.head
    assert immutable_list == ImmutableList(None)

# Generated at 2022-06-24 00:13:44.147505
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.empty() == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() + ImmutableList.of(4, 5) == ImmutableList.of(4, 5)
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(10) + ImmutableList.of(20) == ImmutableList.of(10, 20)

# Generated at 2022-06-24 00:13:47.980212
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assertequal(ImmutableList.empty(), ImmutableList(is_empty=True))
    assertequal(ImmutableList(1, ImmutableList(2, ImmutableList.empty())),
                ImmutableList.of(1, 2))



# Generated at 2022-06-24 00:13:54.968131
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:13:56.607612
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-24 00:14:00.979348
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert(ImmutableList(4, ImmutableList(5, ImmutableList(6))).filter(lambda x: x < 6) == ImmutableList(4, ImmutableList(5)))

# Generated at 2022-06-24 00:14:07.638571
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    lst = ImmutableList.empty()
    assert lst.to_list() == []
    lst = ImmutableList(5)
    assert lst.to_list() == [5]
    lst = ImmutableList(5, ImmutableList(2))
    assert lst.to_list() == [5, 2]
    lst = ImmutableList(5, ImmutableList(2, ImmutableList(10)))
    assert lst.to_list() == [5, 2, 10]

# Generated at 2022-06-24 00:14:18.710176
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_list = ImmutableList.empty()

    assert empty_list.find(lambda _: True) == None

    one_element = ImmutableList.of(3)
    assert one_element.find(lambda x: x == 3) == 3
    assert one_element.find(lambda x: x == 5) == None

    three_elements = ImmutableList.of(1, 2, 3)
    assert three_elements.find(lambda x: x == 1) == 1
    assert three_elements.find(lambda x: x == 2) == 2
    assert three_elements.find(lambda x: x == 3) == 3
    assert three_elements.find(lambda x: x == 5) == None


# Generated at 2022-06-24 00:14:26.797796
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x ** 2) == ImmutableList.of(1, 4, 9, 16, 25)
    assert ImmutableList(is_empty=True).map(lambda x: x ** 2) == ImmutableList(is_empty=True)
    assert ImmutableList.of('a', 'b', 'c', 'd').map(lambda x: x.upper()) == ImmutableList.of('A', 'B', 'C', 'D')



# Generated at 2022-06-24 00:14:30.153371
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    l1 = ImmutableList(7)
    assert len(l1) == 1
    l2 = l1.append(8)
    assert len(l1) == 1
    assert len(l2) == 2

# Generated at 2022-06-24 00:14:33.131682
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert ImmutableList(1, 2, is_empty=True).__len__() == 0
    assert ImmutableList(1, 2).__len__() == 2
    assert ImmutableList(1).__len__() == 1



# Generated at 2022-06-24 00:14:39.919850
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Assert function
    def assert_function(test_input, expected_result):
        assert test_input == expected_result

    # Test input for test_ImmutableList_unshift
    test_ImmutableList_unshift_input = (
        ImmutableList(1).append(2).append(3).append(4).unshift(5),
        ImmutableList.of(5, 1, 2, 3, 4)
    )

    # Expected results to test_ImmutableList_unshift
    expected_results_test_ImmutableList_unshift = test_ImmutableList_unshift_input[1]
    # Print results of test_ImmutableList_unshift
    print("test_ImmutableList_unshift input: " +
          str(test_ImmutableList_unshift_input))

# Generated at 2022-06-24 00:14:44.580188
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    items = ImmutableList.of(1, 2, 3, 4, 5)
    items = items.map(lambda item: item + 1)

    assert items == ImmutableList.of(2, 3, 4, 5, 6)


# Generated at 2022-06-24 00:14:47.087589
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # arrange
    items = [1, 2, 3, 4, 5]
    items_list = ImmutableList.of(*items)
    mapper = lambda x: x ** 2
    expected = ImmutableList.of(1, 4, 9, 16, 25)

    # act
    result = items_list.map(mapper)

    # assert
    assert expected == result



# Generated at 2022-06-24 00:14:56.209878
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty()\
        .unshift(3)\
        .to_list() == [3]

    assert ImmutableList.empty()\
        .unshift(9)\
        .unshift(4)\
        .unshift(1)\
        .to_list() == [1, 4, 9]

    assert ImmutableList.empty()\
        .unshift(9)\
        .unshift(4)\
        .unshift(1)\
        .to_list() == [1, 4, 9]

    assert ImmutableList\
        .of(1, 2, 3)\
        .unshift(9)\
        .unshift(4)\
        .unshift(1)\
        .to_list() == [1, 4, 9, 1, 2, 3]


# Generated at 2022-06-24 00:15:01.421044
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Arrange
    first_list = ImmutableList.of(1, 2, 3)
    second_list = ImmutableList.of(4, 5, 6)

    # Act
    result = first_list + second_list

    # Assert
    assert result == ImmutableList.of(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-24 00:15:06.955819
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    data = [1,2,3,4,5]
    assert ImmutableList.of(1,2,3,4,5).map(lambda x: x*2) == ImmutableList.of(2,4,6,8,10)
    assert ImmutableList.of(1,2,3,4,5).map(lambda x: x*2).to_list() == [2,4,6,8,10]



# Generated at 2022-06-24 00:15:12.337976
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(3) == ImmutableList(3)
    assert ImmutableList(3, ImmutableList(4)) == ImmutableList(3, ImmutableList(4))

    assert ImmutableList() != ImmutableList(1)
    assert ImmutableList(3) != ImmutableList(5)
    assert ImmutableList(3, ImmutableList(4)) != ImmutableList(5, ImmutableList(4, ImmutableList(5)))


# Generated at 2022-06-24 00:15:16.436776
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3).reduce(lambda acc, val : acc + val, 0) == 6


# Generated at 2022-06-24 00:15:18.622055
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of("a", "b", "c").find(lambda el: el == "b") == "b"



# Generated at 2022-06-24 00:15:21.727277
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda acc, item: acc + [item], []) == []
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, item: acc + [item], []) == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, item: acc + item, 0) == 6



# Generated at 2022-06-24 00:15:29.467703
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    l1 = ImmutableList.of(1, 2, 3, 4, 5)
    assert l1.map(lambda x: x ** 2).to_list() == [1, 4, 9, 16, 25]
    l2 = ImmutableList.of('a', 'b', 'c', 'd', 'e')
    assert l2.map(lambda el: el.upper()).to_list() == ['A', 'B', 'C', 'D', 'E']

# Generated at 2022-06-24 00:15:32.193687
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(5) == ImmutableList.of(5)
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2) 

# Generated at 2022-06-24 00:15:36.116642
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    target = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    fn = lambda x: x + 2
    assert target.map(fn) == ImmutableList(3, ImmutableList(4, ImmutableList(5)))
    fn = lambda x: x * 2
    assert target.map(fn) == ImmutableList(2, ImmutableList(4, ImmutableList(6)))


# Generated at 2022-06-24 00:15:46.792039
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # ImmutableList is empty
    _l = ImmutableList()
    assert _l.head is None
    assert _l.tail is None
    assert _l.is_empty is True
    assert _l == ImmutableList(is_empty=True)

    # ImmutableList is instance of ImmutableList class
    _l = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert _l.head == 1
    assert _l.tail.head == 2
    assert _l.tail.tail.head == 3
    assert _l.tail.tail.tail is None
    assert _l. tail.tail is not None


# Generated at 2022-06-24 00:15:51.092193
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of('hello').map(lambda x: x + ', world') == ['hello, world']
    assert ImmutableList.of(1,2,3).map(lambda x: x+1) == [2,3,4]
    assert ImmutableList.of('hello', 1).map(lambda x: x) == ['hello', 1]
    assert ImmutableList.of('hello', 'world').map(lambda x: x) == ['hello', 'world']
    assert ImmutableList.empty().map(lambda x: x+1) == []


# Generated at 2022-06-24 00:15:54.032643
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-24 00:16:02.257713
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x < 3) is None
    assert ImmutableList.of(1).find(lambda x: x < 3) is 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x < 3) is 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x <= 2) is 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x <= 3) is 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) is 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) is 3


test_ImmutableList_find()

# Generated at 2022-06-24 00:16:08.139496
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) == None
    assert ImmutableList.of(1, 2).find(lambda x: x) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 4) == 5
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 10) == None



# Generated at 2022-06-24 00:16:12.356635
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(1, 2, 3, 4)
    print('Start test of ImmutableList.reduce method')
    assert list_.reduce(lambda x, y: x + y, 0) == 10
    print('Method reduce is ok')


if __name__ == '__main__':
    test_ImmutableList_reduce()

# Generated at 2022-06-24 00:16:15.539253
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of('a', 'b', 'c').map(lambda x: x.upper()) == ImmutableList.of('A', 'B', 'C')


test_ImmutableList_map()

# Generated at 2022-06-24 00:16:18.496921
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-24 00:16:20.985293
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-24 00:16:25.171163
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of("a", "b", "c").append("d") == ImmutableList("a", ImmutableList("b", ImmutableList("c", ImmutableList("d"))))


# Generated at 2022-06-24 00:16:32.966214
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(5) == ImmutableList(5)
    assert ImmutableList(5, None) == ImmutableList(5)
    assert ImmutableList(5, ImmutableList(10, ImmutableList(15))) == ImmutableList(5, ImmutableList(10, ImmutableList(15)))
    assert ImmutableList(5, ImmutableList(10, ImmutableList(15))) != ImmutableList(5, ImmutableList(10, ImmutableList(13)))


# Generated at 2022-06-24 00:16:39.043520
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) + ImmutableList(2, ImmutableList(3)) == ImmutableList(
        1, ImmutableList(2, ImmutableList(3))
    )
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(
        1, ImmutableList(2, ImmutableList(3))
    )


# Generated at 2022-06-24 00:16:41.467578
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    pass

# Generated at 2022-06-24 00:16:45.310113
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = list1.filter(lambda x: x % 2 == 0)
    assert list2 == ImmutableList.of(2, 4)
    assert list1 == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-24 00:16:53.288179
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    with pytest.raises(TypeError) as e_info:
        ImmutableList()

    # We can use `...` to prevent writing out of long array
    assert ImmutableList.of(1, 2, 3, 4, 5, 6) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    assert ImmutableList.empty() == ImmutableList(is_empty=True)



# Generated at 2022-06-24 00:16:58.373774
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first_list = ImmutableList.of('a', 'b', 'c', 'd')
    second_list = ImmutableList.of('a', 'b', 'c', 'd')
    third_list = ImmutableList.of('a', 'b', 'c', 'd', 'e')
    assert first_list == second_list
    assert first_list != third_list

