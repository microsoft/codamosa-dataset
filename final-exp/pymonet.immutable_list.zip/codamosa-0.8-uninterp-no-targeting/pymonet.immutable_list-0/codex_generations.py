

# Generated at 2022-06-21 19:07:44.173291
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    empty = ImmutableList.empty()
    list = ImmutableList.of(1)
    list = ImmutableList.of(1, 2)
    list = ImmutableList.of(1, 2, 3)
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 19:07:48.135154
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    This function tests if method find returns
    correct value if list elements found.
    """
    my_list = ImmutableList.of(1, 2, 3, 4).find(lambda e: e == 3)
    assert my_list == 3



# Generated at 2022-06-21 19:07:52.714472
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_ = ImmutableList.of(1, 2, 3)
    another_list = ImmutableList.of(4, 5, 6)
    expected_list = ImmutableList.of(1, 2, 3, 4, 5, 6)

    assert list_ + another_list == expected_list

test_ImmutableList___add__()

# Generated at 2022-06-21 19:07:57.689080
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    result = l.find(lambda x: x == 2)
    assert result == 2
    result = l.find(lambda x: x == 3)
    assert result == 3
    result = l.find(lambda x: x == 6)
    assert result == None
    assert ImmutableList.empty().find(lambda x: True) == None

test_ImmutableList_find()

# Generated at 2022-06-21 19:08:02.424896
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)
    assert ImmutableList(3) != ImmutableList(is_empty=True)
    assert ImmutableList(3) != ImmutableList(3, ImmutableList(3))


# Generated at 2022-06-21 19:08:11.035453
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 2) == ImmutableList.of(1)



# Generated at 2022-06-21 19:08:17.249341
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.empty() == ImmutableList.of(1, 2)
    assert ImmutableList.empty() + ImmutableList.of(1, 2) == ImmutableList.of(1, 2)

# Generated at 2022-06-21 19:08:20.652497
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # given
    list = ImmutableList.of(1, 6, 7)
    expected = ImmutableList.of(3, 1, 6, 7)
    
    # when
    result = list.unshift(3)

    # then
    assert expected == result


# Generated at 2022-06-21 19:08:28.928909
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    a = ImmutableList()
    b = ImmutableList.of('a', 'b', 'c')
    c = ImmutableList.of(0, 1, 2)
    assert a.map(lambda v: v + 1) == ImmutableList.empty()
    assert b.map(lambda v: v + '1') == ImmutableList.of('a1', 'b1', 'c1')
    assert c.map(lambda v: v + 1) == ImmutableList.of(1, 2, 3)
    assert c.map(lambda v: v + b[1]) == ImmutableList.of('a', 'b2', 'c')

# Generated at 2022-06-21 19:08:34.982577
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    empty_list = ImmutableList.empty()
    one_element_list = ImmutableList.of(1)
    multiple_elements_list = ImmutableList.of(1, 2, 3)
    
    assert len(empty_list) == 0
    assert len(one_element_list) == 1
    assert len(multiple_elements_list) == 3
test_ImmutableList___len__()

# Generated at 2022-06-21 19:08:49.507178
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    """
    >>> l = ImmutableList.of(1, 2, 3)
    >>> l_map = l.map(lambda x: x + 1)
    >>> l == ImmutableList.of(1, 2, 3)
    True
    >>> l_map == ImmutableList.of(2, 3, 4)
    True
    """



# Generated at 2022-06-21 19:09:01.686787
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Test first reduce
    fn_1 = lambda prev, curr: prev + curr
    list_1 = ImmutableList.of(1, 2, 3, 4)
    result_1 = list_1.reduce(fn_1, 0)
    assert result_1 == 10

    # Test second reduce
    fn_2 = lambda prev, curr: prev * curr
    list_2 = ImmutableList.of(1, 2, 3, 4)
    result_2 = list_2.reduce(fn_2, 1)
    assert result_2 == 24

    # Test third reduce
    fn_3 = lambda prev, curr: prev - curr
    list_3 = ImmutableList.of(1, 2, 3, 4)
    result_3 = list_3.reduce(fn_3, 10)


# Generated at 2022-06-21 19:09:12.424907
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Define function for "filter" method
    fn = lambda x: x % 2 == 0

    # Constructor for list
    list_ = lambda *elements: ImmutableList.of(*elements)

    # Define lists
    list_1 = ImmutableList.empty()
    list_2 = list_(1)
    list_3 = list_(1, 2, 3)
    list_4 = list_(1, 2, 3, 4, 5, 6)
    list_5 = list_(2, 4, 6)
    list_6 = list_(1, 3, 5)

    # Test is False for empty list
    assert list_1.filter(fn) == list_1

    # Test is False for single-element list
    assert list_2.filter(fn) == list_1

    # Test is False for list with 3 elements

# Generated at 2022-06-21 19:09:19.423692
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0,1)
    assert ImmutableList.of(1,2,3).unshift(0) == ImmutableList.of(0,1,2,3)
    assert ImmutableList.of(1,2,3,4).unshift(0) == ImmutableList.of(0,1,2,3,4)



# Generated at 2022-06-21 19:09:26.779526
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Arrange
    value1 = 'a'
    value2 = 'b'
    value3 = 'c'
    value4 = 'd'

    list1 = ImmutableList(value1, ImmutableList(value2))
    list2 = ImmutableList(value3, ImmutableList(value4))

    expected = ImmutableList(
        value1,
        ImmutableList(
            value2,
            ImmutableList(
                value3,
                ImmutableList(
                    value4,
                )
            )
        )
    )

    # Act
    actual = list1 + list2

    # Assert
    assert expected == actual


# Generated at 2022-06-21 19:09:35.506257
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1, None, False) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-21 19:09:38.855496
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    from ImmutableList import ImmutableList
    expected = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    reality = ImmutableList(1, ImmutableList(2)).__add__(ImmutableList(3))
    assert expected.__eq__(reality) is True


# Generated at 2022-06-21 19:09:40.277370
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    result = ImmutableList.empty().append('a')

    assert ImmutableList.of('a') == result



# Generated at 2022-06-21 19:09:48.559586
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6, 8)
    assert ImmutableList.of('a', 'b', 'c').map(lambda x: x + x) == ImmutableList.of('aa', 'bb', 'cc')

# Generated at 2022-06-21 19:09:55.485234
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-21 19:10:06.559568
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 1, 2, 12).map(lambda x: x * x) == ImmutableList(1, 4, 9, 1, 4, 144)

# Generated at 2022-06-21 19:10:08.397339
# Unit test for method reduce of class ImmutableList

# Generated at 2022-06-21 19:10:12.228685
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of('a', 'b', 'c').to_list() == ['a', 'b', 'c']


# Generated at 2022-06-21 19:10:16.212804
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1,2)) == 2
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-21 19:10:23.565026
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x >= 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x >= 100) == None
    assert ImmutableList(None).find(lambda x: x > 1) == None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(None, ImmutableList(5)))).find(lambda x: x > 5) == None
    assert ImmutableList().find(lambda x: x > 5) == None


# Generated at 2022-06-21 19:10:33.106394
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2, 3).unshift(4).unshift(5) == ImmutableList.of(5, 4, 1, 2, 3)
    assert ImmutableList.of(4, 5).unshift(3) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.of(1).unshift(1) == ImmutableList.of(1, 1)
    assert ImmutableList.of(1).unshift(1).unshift(1) != ImmutableList.of(1, 1, 1)


# Generated at 2022-06-21 19:10:39.109121
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []

    assert ImmutableList.of('foo').to_list() == ['foo']

    assert ImmutableList.of('foo', 'bar').to_list() == ['foo', 'bar']

    assert ImmutableList.of('foo', 'bar', 'baz').to_list() == ['foo', 'bar', 'baz']

    assert ImmutableList.of('foo', 'bar', 'baz', 'qaz').to_list() == ['foo', 'bar', 'baz', 'qaz']



# Generated at 2022-06-21 19:10:43.451292
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    my_list = ImmutableList.of(1, 2)
    my_new_list = my_list.unshift(0)
    assert_equal(my_new_list.to_list(), [0, 1, 2])


# Generated at 2022-06-21 19:10:46.049432
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3

test_ImmutableList___len__()

# Generated at 2022-06-21 19:10:48.361824
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.to_list() == [1, 2, 3]

# Generated at 2022-06-21 19:11:11.724888
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    l = ImmutableList.of(1, 2, 3, 4)
    l_map = l.map(lambda x: x + 1)
    assert l_map == ImmutableList.of(2, 3, 4, 5), 'Map method should return new ImmutableList instance'
    assert l == ImmutableList.of(1, 2, 3, 4), 'Map method should not mutate instance of ImmutableList'
    assert l_map.tail.tail.tail == ImmutableList.of(5), 'Map method should return new ImmutableList instance'

# Generated at 2022-06-21 19:11:17.564047
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Given
    immutable_list = ImmutableList.of(1, 2, 3)
    # When
    new_list = immutable_list.unshift(0)
    # That
    assert new_list == ImmutableList.of(0, 1, 2, 3)
    assert immutable_list == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-21 19:11:23.225745
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    """
    Test that checks the result of add method
    of ImmutableList data structure.
    """
    # GIVEN
    list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    list_2 = ImmutableList.of(6, 7, 8, 9, 10)

    # WHEN
    result = list_1 + list_2

    # THEN
    assert isinstance(result, ImmutableList)
    assert len(result) == 10
    assert result.to_list() == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-21 19:11:27.312697
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.empty().unshift(42) == ImmutableList.of(42)

# Generated at 2022-06-21 19:11:32.780764
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.empty()
    assert ImmutableList.of(1, 2) != [1, 2]


# Generated at 2022-06-21 19:11:38.329004
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    test_object = ImmutableList.of(1, 2, 3)
    expected_object = 'ImmutableList(1, 2, 3)'

    assert str(test_object) == expected_object, 'Expected {} but got {}'.format(expected_object, str(test_object))



# Generated at 2022-06-21 19:11:43.628857
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of().to_list() == []


# Generated at 2022-06-21 19:11:45.848126
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]



# Generated at 2022-06-21 19:11:49.046072
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList(2).unshift(1) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-21 19:11:53.414577
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]



# Generated at 2022-06-21 19:12:31.282819
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    print("[+] test_ImmutableList_append")
    list = ImmutableList.of(1,2,3).append(4)
    assert list.to_list() == [1,2,3,4]


# Generated at 2022-06-21 19:12:42.852701
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(0) == ImmutableList(0)
    assert ImmutableList(1).unshift(0) == ImmutableList(0, ImmutableList(1))
    assert ImmutableList(1).unshift(0).unshift(-1) == ImmutableList(-1, ImmutableList(0, ImmutableList(1)))
    assert ImmutableList.of(1).unshift(0) == ImmutableList(0, ImmutableList(1))
    assert ImmutableList.of(1).unshift(0).unshift(-1) == ImmutableList(-1, ImmutableList(0, ImmutableList(1)))


# Generated at 2022-06-21 19:12:46.842221
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.empty()) == 0

# Generated at 2022-06-21 19:12:49.093441
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(2, 3, 4, 5).find(lambda x: x < 3) == 2



# Generated at 2022-06-21 19:12:51.930201
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2).append(3).to_list() == [1, 2, 3]



# Generated at 2022-06-21 19:12:55.097196
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:12:58.139259
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(4, 5, 6)
    assert a + b == ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-21 19:13:00.624220
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x*2) == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-21 19:13:04.826798
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, i: acc + i, 0) == 6
    assert ImmutableList.of('a', 'b', 'c').reduce(lambda acc, i: acc + i, 'list:') == 'list:abc'

# Generated at 2022-06-21 19:13:13.080355
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert str(ImmutableList.of(1).__add__(ImmutableList.of(2))) == \
        "ImmutableList[1, 2]"

    assert str(ImmutableList.of(1, 2).__add__(ImmutableList.of(3, 4))) == \
        "ImmutableList[1, 2, 3, 4]"

    try:
        ImmutableList.of(1).__add__(1)
    except ValueError:
        pass
    else:
        assert False, "ImmutableList: you can not add any other instace than ImmutableList"



# Generated at 2022-06-21 19:14:47.467555
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.empty().unshift(3).unshift(2).unshift(1)
    list2 = ImmutableList.empty().unshift(4).unshift(5).unshift(6)
    list3 = ImmutableList.empty().unshift(7).unshift(8).unshift(9)
    list4 = ImmutableList.empty().unshift(3).unshift(2).unshift(1).unshift(4).unshift(5).unshift(6)
    list5 = list1.unshift(4).unshift(5).unshift(6)

    assert list1.to_list() == [1, 2, 3]
    assert list2.to_list() == [6, 5, 4]

# Generated at 2022-06-21 19:14:50.872362
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list = ImmutableList.of(1, 2)
    expected = ImmutableList.of('a', 1, 2)
    result = immutable_list.unshift('a')

    assert result == expected

# Generated at 2022-06-21 19:14:52.436946
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert __str__(ImmutableList(5)) == 'ImmutableList[5]'



# Generated at 2022-06-21 19:14:59.050783
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():  # pragma: no cover
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(2).find(lambda x: x == 1) == None

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None

    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x < 0) == None

    assert ImmutableList.empty().find(lambda x: x == 1) == None
    assert ImmutableList.empty().find(lambda x: x == False) == None


# Unit test

# Generated at 2022-06-21 19:15:00.400346
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    expected = 'ImmutableList[1, 2, 3]'
    actual = ImmutableList.of(1, 2, 3).__str__()

    assert expected == actual

# Generated at 2022-06-21 19:15:03.527531
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift("a") == ImmutableList("a")
    assert ImmutableList("b").unshift("a") == ImmutableList("a", "b")
    assert ImmutableList("b", "c").unshift("a") == ImmutableList("a", "b", "c")

# Generated at 2022-06-21 19:15:15.531329
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3)
    list3 = ImmutableList.of(3, 2, 1)
    assert list1 == list1
    assert list1 == list2
    assert list1 != list3
    assert list1 == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list1 != ImmutableList(1, ImmutableList(2, ImmutableList(4)))
    assert list1 != ImmutableList(1)
    assert list1 != ImmutableList(1, ImmutableList(2))
    assert list1 != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-21 19:15:20.215596
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Given
    list_ = ImmutableList.of(1, 2, 3, 4)

    # When
    result = list_.map(lambda x: x**2)

    # Then
    assert result == ImmutableList.of(1, 4, 9, 16)


# Generated at 2022-06-21 19:15:29.557392
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_2 = ImmutableList(4, ImmutableList(5, ImmutableList(6)))
    list_3 = ImmutableList(7, ImmutableList(8, ImmutableList(9)))

    assert list_1 + list_2 == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    assert list_1.__add__(list_3) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(7, ImmutableList(8, ImmutableList(9))))))


# Generated at 2022-06-21 19:15:36.482690
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList([1, 2, 3, 4]).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList([]).filter(lambda x: x % 2 == 0).to_list() == []
    assert ImmutableList(1).filter(lambda x: x % 2 == 0).to_list() == []
    assert ImmutableList(2).filter(lambda x: x % 2 == 0).to_list() == [2]
