

# Generated at 2022-06-21 19:07:32.109412
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))



# Generated at 2022-06-21 19:07:38.283061
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    assert ImmutableList().to_list() == []



# Generated at 2022-06-21 19:07:50.044483
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    m_list = ImmutableList.of(1, 2, 3)
    assert m_list.reduce(lambda a, x: a + x, 0) == 6

    m_list = ImmutableList.of(2, 3, 4)
    assert m_list.reduce(lambda a, x: a * x, 1) == 24

    m_list = ImmutableList.of("a", "b", "c")
    assert m_list.reduce(lambda a, x: a + x, "") == "abc"

    m_list = ImmutableList.of("a", "b", "c")
    assert m_list.reduce(lambda a, x: x + a, "") == "cba"

    assert ImmutableList.empty().reduce(lambda a, x: a + x, 6) == 6

   

# Generated at 2022-06-21 19:08:01.052287
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).to_list() == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 19:08:05.087521
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1).append(1) == ImmutableList(1, ImmutableList(1))
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).append(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(1, ImmutableList(2, ImmutableList(3))))))


# Generated at 2022-06-21 19:08:13.041105
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList.empty()))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList.empty()))))) == 4

# Generated at 2022-06-21 19:08:20.611507
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.empty() + ImmutableList.of(4) == ImmutableList.of(4)

# Generated at 2022-06-21 19:08:31.475747
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # preparation
    list_length = randint(1, 100)
    item_1 = randint(1, 10)
    item_2 = randint(1, 10)
    item_3 = randint(1, 10)
    expected = 0
    # action
    actual = ImmutableList.empty().__len__()
    # assert
    assert actual == expected
    # action
    actual = ImmutableList.of(item_1).__len__()
    expected = 1
    # assert
    assert actual == expected
    # action
    actual = ImmutableList.of(item_1, item_2).__len__()
    expected = 2
    # assert
    assert actual == expected
    # action
    actual = ImmutableList.of(item_1, item_2, item_3).__len__()
    expected

# Generated at 2022-06-21 19:08:34.926680
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    result = ImmutableList.of(1, 2, 3, 4, 5)
    assert [1, 2, 3, 4, 5] == result.to_list(), 'Result: {}'.format(result.to_list())


# Generated at 2022-06-21 19:08:39.281202
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    
    # empty list
    assert len(ImmutableList.empty()) == 0

    # just one element list
    assert len(ImmutableList.of(1)) == 1

    # few elements list
    assert len(ImmutableList.of(1, 2, 3)) == 3
    
    


# Generated at 2022-06-21 19:08:50.985302
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]



# Generated at 2022-06-21 19:08:56.342665
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(head=6, tail=ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))), is_empty=False), is_empty=False) == ImmutableList.of(6, 1, 2, 3, 4)




# Generated at 2022-06-21 19:09:03.789310
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(3).to_list() == [3]
    assert ImmutableList.of(3, 4).to_list() == [3, 4]
    assert ImmutableList.of(3, 4, 5).to_list() == [3, 4, 5]
    assert ImmutableList.of(3, 4, 5, 6, 7).to_list() == [3, 4, 5, 6, 7]
    assert ImmutableList.empty().to_list() == []



# Generated at 2022-06-21 19:09:10.780517
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x > 3) == 4
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 1, 2, 3, 4, 4, 2, 1).find(lambda x: x > 5) is None
    assert ImmutableList.empty().find(lambda x: x > 3) is None


# Generated at 2022-06-21 19:09:14.115937
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # given
    head = 10
    tail_head = 20
    tail = ImmutableList(tail_head)
    immutable_list = ImmutableList(head, tail)

    # when
    list_length = len(immutable_list)

    # then
    assert(list_length == 2)

# Generated at 2022-06-21 19:09:22.898653
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(head=1, tail=None).__eq__(ImmutableList(head=1, tail=None))
    assert not ImmutableList(head=1, tail=None).__eq__(ImmutableList(head=2, tail=None))
    assert not ImmutableList(head=1, tail=None).__eq__(ImmutableList(head=1, tail=ImmutableList(head=1, tail=None)))
    assert not ImmutableList(head=1, tail=None).__eq__(None)


ImmutableList.__eq__ = test_ImmutableList___eq__


# Generated at 2022-06-21 19:09:24.155156
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:09:26.623684
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4).find(lambda e: e == 3)
    assert list == 3



# Generated at 2022-06-21 19:09:32.465900
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    a = ImmutableList(1)
    assert (len(a) == 1)

    b = ImmutableList(1, ImmutableList(2))
    assert (len(b) == 2)

    c = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert (len(c) == 5)

# Generated at 2022-06-21 19:09:36.935066
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(0, 1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(0,2)
    assert ImmutableList.of(0, 1, 2, 3).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)


# Generated at 2022-06-21 19:09:53.249093
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 5) is None

    assert ImmutableList(1).find(lambda x: x > 0) == 1
    assert ImmutableList(1).find(lambda x: x > 1) is None

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None


# Generated at 2022-06-21 19:10:01.758045
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1).reduce(lambda acc, x: x + acc, 0) == 1
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda acc, x: x + acc, 0) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda acc, x: x + acc, 0) == 6
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).reduce(lambda acc, x: x + acc, 0) == 10
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))).reduce(
        lambda acc, x: x + acc, 0) == 15



# Generated at 2022-06-21 19:10:03.384862
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
  # Tested method
  ImmutableList()
  # Assertion
  assert True


# Generated at 2022-06-21 19:10:10.586042
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(2, 3, 1)
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3) != 1
    assert ImmutableList.of(1, 2, 3) != [1, 2, 3]
    assert ImmutableList.of(1, 2, 3) != [1, 2, 3]
    assert ImmutableList.of(1, 2, 3) != None

# Generated at 2022-06-21 19:10:18.562052
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    listA = ImmutableList.of(10, 20, 30)

    # When
    result = listA.to_list()

    # Then
    expect(result) == [10, 20, 30]

    # Given
    listB = ImmutableList.of(10, 20, 30).append(40)

    # When
    result = listB.to_list()

    # Then
    expect(result) == [10, 20, 30, 40]

# Generated at 2022-06-21 19:10:26.914340
# Unit test for method __add__ of class ImmutableList

# Generated at 2022-06-21 19:10:29.907845
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5)


# Generated at 2022-06-21 19:10:38.469616
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    """
    Test case verifies that method __len__ returns proper length of ImmutableList
    """
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of('a')) == 1
    assert len(ImmutableList.of('a', 'b')) == 2
    assert len(ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f', 'g')) == 7
    assert len(ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k')) == 11

# Generated at 2022-06-21 19:10:49.925124
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Arrange
    element_1 = 4
    element_2 = 5
    element_3 = 6

    # Act
    immutable_list_1 = ImmutableList.of(element_1)
    immutable_list_2 = ImmutableList.of(element_2)
    immutable_list_1_and_2 = immutable_list_1 + immutable_list_2
    immutable_list_3 = ImmutableList.of(element_3)
    immutable_list_1_2_3 = immutable_list_1_and_2 + immutable_list_3

    # Assert
    assert immutable_list_1.to_list() == [element_1]
    assert immutable_list_2.to_list() == [element_2]
    assert immutable_list_3.to_list() == [element_3]
    assert immutable

# Generated at 2022-06-21 19:10:51.533834
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    test_input = ImmutableList.of(1, 2, 3, 4)

    assert test_input.map(lambda x: x ** 2).to_list() == [1, 4, 9, 16]



# Generated at 2022-06-21 19:11:10.581309
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list = ImmutableList.of(1, 2, 3, 4)
    mapped = list.map(lambda x: x * 2)
    assert mapped == ImmutableList.of(2, 4, 6, 8)

# Generated at 2022-06-21 19:11:17.612789
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3)))\
        == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList()\
        == ImmutableList(is_empty=True)

    assert ImmutableList()\
        != ImmutableList(1)

    assert ImmutableList()\
        != ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-21 19:11:19.905732
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    lst = ImmutableList(1)
    assert lst.head == 1
    assert lst.tail is None
    assert lst.is_empty == False

# Generated at 2022-06-21 19:11:24.146856
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    result = ImmutableList.of(1, 2, 3, 4).reduce(lambda a, b: a + b, 0)
    assert result == 10
    assert ImmutableList.empty().reduce(lambda a, b: a + b, 0) == 0


# Generated at 2022-06-21 19:11:33.140935
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList()\
            .append(1)\
            .append(2)\
            .append(3)\
            .append(4)\
            .find(lambda x: x > 2) == 3
    
    assert ImmutableList()\
            .append(1)\
            .append(2)\
            .append(3)\
            .append(4)\
            .find(lambda x: x > 4) == None
    
    assert ImmutableList()\
            .append(1)\
            .append(2)\
            .append(3)\
            .append(4)\
            .append(5)\
            .find(lambda x: x > 4) == 5


# Generated at 2022-06-21 19:11:35.104862
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList.of(1, 2, 3, 4)
    assert a.reduce(lambda x, y: x + y, 0) == 10


# Generated at 2022-06-21 19:11:37.518509
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    )
    assert list_.reduce(lambda acc, value: acc + value, 0) == 55

# Generated at 2022-06-21 19:11:43.243366
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) \
        == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4) \
        == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-21 19:11:49.191867
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Arrange
    # SetUp
    # Act
    # Assert
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 4


# Generated at 2022-06-21 19:11:51.365638
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-21 19:12:56.335590
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .to_list() == [1, 2, 3, 4, 5]

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .to_list() == ImmutableList.of(1, 2, 3, 4, 5).to_list()

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .to_list() == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .to_list()


# Generated at 2022-06-21 19:13:06.272258
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    l = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert l.filter(lambda x: x % 3 == 0) == ImmutableList(3, ImmutableList(6))
    assert l.filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4, ImmutableList(6)))
    assert l.filter(lambda x: x % 7 == 0) == ImmutableList(is_empty=True)
    assert l.filter(lambda x: x % 11 == 0) == ImmutableList(is_empty=True)
    assert l.filter(lambda x: x % 1 == 0) == l

# Generated at 2022-06-21 19:13:10.353114
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of().to_list() == []


# Generated at 2022-06-21 19:13:13.750232
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_of_ints = ImmutableList.of(1, 2, 3, 4)
    res = list_of_ints.reduce(lambda x, y: x*y, 1)

    assert res == 24


# Generated at 2022-06-21 19:13:23.234076
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6, 8, 10)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of().filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()



# Generated at 2022-06-21 19:13:24.839001
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList()



# Generated at 2022-06-21 19:13:35.682500
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: True) == ImmutableList(is_empty=True)
    assert ImmutableList(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList(2, 4, 6)
    assert ImmutableList(1, 2, 3, 4, 5, 6).filter(lambda x: False) == ImmutableList(is_empty=True)
    assert ImmutableList(1, 2, 3, 4, 5, 6).filter(lambda x: True) == ImmutableList(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-21 19:13:40.674748
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of('1', '2', '3')
    assert l.unshift('0') == ImmutableList.of('0', '1', '2', '3')
    assert l == ImmutableList.of('1', '2', '3')  # input is immutable
    assert l.unshift('-1').unshift('-2') == ImmutableList.of('-2', '-1', '0', '1', '2', '3')


# Generated at 2022-06-21 19:13:47.076508
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 100) is None

if __name__ == '__main__':
    test_ImmutableList_find()

# Generated at 2022-06-21 19:13:58.998780
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty_IL = ImmutableList()
    assert empty_IL.__eq__(ImmutableList()) == True, 'ImmutableList: __eq__ method returns wrong result'

    IL_1 = ImmutableList(1)
    assert IL_1.__eq__(ImmutableList(1)) == True, 'ImmutableList: __eq__ method returns wrong result'

    IL_2 = ImmutableList(1, ImmutableList(2))
    assert IL_2.__eq__(ImmutableList(1, ImmutableList(2))) == True, 'ImmutableList: __eq__ method returns wrong result'

    IL_1_not_IL_2 = ImmutableList(1)

# Generated at 2022-06-21 19:16:06.030102
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x) == ImmutableList.empty(), 'ImmutableList.map() method should return empty ImmutableList after trying to map empty ImmutableList'
    assert ImmutableList(1).map(lambda x: x * 2) == ImmutableList(2), 'ImmutableList.map() method should return new ImmutableList with values mapped with argument function'
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x * 2) == ImmutableList(2, ImmutableList(4, ImmutableList(6))), 'ImmutableList.map() method should return new ImmutableList with values mapped with argument function'

# Generated at 2022-06-21 19:16:11.730974
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    result = ImmutableList.of(1, 2, 3)
    result = result.unshift(0)
    expected_result = ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))

    assert result == expected_result, f'Expected {expected_result} but got {result}'



# Generated at 2022-06-21 19:16:13.044409
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    from pytest import raises

    with raises(TypeError):
        ImmutableList.empty().filter(lambda x: x)

# Generated at 2022-06-21 19:16:15.155710
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(4, 5)
    assert (list1 + list2 == ImmutableList.of(1, 2, 3, 4, 5))


# Generated at 2022-06-21 19:16:20.810745
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1) + ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2) + ImmutableList.of(3)
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)

    with pytest.raises(ValueError):
        assert ImmutableList.of(1) + 1
        assert ImmutableList.of(1) + {}
        assert ImmutableList.of(1) + []
        assert ImmutableList.of(1) + ImmutableMap.of('one', 1)


# Generated at 2022-06-21 19:16:30.577173
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x in (1, 3)) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x in (1, 3)) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x in (1, 3)).filter(lambda x: x == 1) == ImmutableList.of(1)
    
test_ImmutableList_filter()

# Generated at 2022-06-21 19:16:34.019733
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)

    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 10) == ImmutableList.empty()


# Generated at 2022-06-21 19:16:37.151724
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 3) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 20) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x == 1) == ImmutableList.of(1)

# Generated at 2022-06-21 19:16:41.021863
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    second = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert first == second



# Generated at 2022-06-21 19:16:45.607600
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_int = ImmutableList(1, ImmutableList(2))
    list_str = ImmutableList("1", ImmutableList("2"))
    assert str(list_int) == str([1, 2])
    assert str(list_str) == str(["1", "2"])
