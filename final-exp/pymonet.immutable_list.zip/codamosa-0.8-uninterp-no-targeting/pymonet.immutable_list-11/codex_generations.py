

# Generated at 2022-06-21 19:07:35.503914
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    list_ = ImmutableList.empty()
    # When
    result = list_.to_list()
    # Then
    assert result == []



# Generated at 2022-06-21 19:07:44.121243
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(2) != ImmutableList(1)
    assert ImmutableList(2) != ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))



# Generated at 2022-06-21 19:07:49.706399
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Given
    items = [1, 2, 3, 4, 5]
    items2 = ['1', '2', '3', '4', '5']
    # When
    filtered = ImmutableList.of(*items).map(str)

    # Then
    assert filtered == ImmutableList(*items2)


# Generated at 2022-06-21 19:07:52.841685
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    input_list = ImmutableList.of(1,2,3,4,5)
    # when
    input_list.filter


# Generated at 2022-06-21 19:07:55.246598
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3

# Generated at 2022-06-21 19:08:00.399264
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    """
    Method check reduce method of ImmutableList class
    """
    assert ImmutableList.of(2, 3, 4, 5, 6).reduce(lambda x, y: x + y, 0) == 20
    assert ImmutableList.of(2, 3, 4, 5, 6).reduce(lambda x, y: x * y, 1) == 720

# Generated at 2022-06-21 19:08:08.171232
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x+1) == ImmutableList()
    assert ImmutableList(1).map(lambda x: x+1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3, ImmutableList(4))).map(lambda x: x+1) == ImmutableList(2, ImmutableList(3), ImmutableList(4, ImmutableList(5)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).map(lambda x: x+1) == ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))

# Generated at 2022-06-21 19:08:12.441027
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list = ImmutableList.of(1, 2, 3)
    new_list = list.append(4)
    assert new_list.to_list() == [1, 2, 3, 4]


# Generated at 2022-06-21 19:08:16.105737
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    il = ImmutableList.of(1, 2, 3)

    new_list = il.map(lambda x: x + 1)

    assert new_list == ImmutableList.of(2, 3, 4)



# Generated at 2022-06-21 19:08:20.565773
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert len(ImmutableList.of(1, 2, 3, 4).map(lambda x: x + x)) == 4
    assert ImmutableList.of(1, 2, 3, 4).to_list() == ImmutableList.of(1, 2, 3, 4).map(lambda x: x).to_list()


# Generated at 2022-06-21 19:08:33.755120
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) + ImmutableList(5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))



# Generated at 2022-06-21 19:08:39.579179
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    il = ImmutableList.of(
        (1, 1),
        (1, 2),
        (1, 3),
        (2, 1)
    )
    assert il.find(lambda x: x[0] == 1) == (1, 1)
    assert il.find(lambda x: x[0] == 2) == (2, 1)
    assert il.find(lambda x: x[0] == 3) is None



# Generated at 2022-06-21 19:08:47.814146
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # inputs
    fn = lambda acc, x: acc + x

    # outputs
    expected_reduced_1 = 6
    expected_reduced_2 = 11
    expected_reduced_3 = 2
    expected_reduced_4 = []

    # start test suite
    test_suite = TestSuite()

    # create test case
    test_case_1 = TestCase(
        name='when [1, 2, 3] and fn(acc, x): acc + x',
        input=ImmutableList.of(1, 2, 3),
        output=expected_reduced_1,
        method_to_run=lambda: ImmutableList.of(1, 2, 3).reduce(fn, 0)
    )

# Generated at 2022-06-21 19:09:00.519324
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).head == 1
    assert ImmutableList(1, ImmutableList(2)).tail == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).is_empty == False
    assert ImmutableList(is_empty=True).is_empty == True
    assert ImmutableList(is_empty=True).head is None
    assert ImmutableList(is_empty=True).tail is None
    assert ImmutableList(1, ImmutableList(2)).tail.head == 2
    assert ImmutableList(1, ImmutableList(2)).tail.tail == ImmutableList.empty()

# Generated at 2022-06-21 19:09:04.163808
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Arrange
    list = ImmutableList.of(4, 3, 2, 1)
    # Act
    result = list.reduce(lambda acc, el: acc + el, 0)
    # Assert
    assert result == 10

# Generated at 2022-06-21 19:09:06.009314
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 'a', 4)) == 4



# Generated at 2022-06-21 19:09:09.512811
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    il = ImmutableList.of('a', 'b')
    new_il = il.unshift('c')

    assert new_il == ImmutableList.of('c', 'a', 'b')

# Generated at 2022-06-21 19:09:11.137900
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))


ImmutableList.__name__ = 'ImmutableList'

# Generated at 2022-06-21 19:09:16.920616
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() \
        .__add__(ImmutableList(1, ImmutableList(2))) \
        == ImmutableList(1, ImmutableList(2))

    assert ImmutableList.of(1, 2, 3) \
        .__add__(ImmutableList(4, ImmutableList(5))) \
        == ImmutableList.of(1, 2, 3, 4, 5)

    assert ImmutableList.of(1, 2, 3) \
        .__add__(ImmutableList.of(4, 5)) \
        == ImmutableList.of(1, 2, 3, 4, 5)

    assert ImmutableList.empty().__add__(ImmutableList.empty()) == ImmutableList.empty()



# Generated at 2022-06-21 19:09:23.058338
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    m = ImmutableList.of(1, 2, 3)
    assert m.find(lambda x: x == 2) == 2
    assert m.find(lambda x: x == 4) is None
    assert ImmutableList.empty().find(lambda x: x == 2) is None
    assert ImmutableList.empty().find(lambda x: x == None) is None

# Generated at 2022-06-21 19:09:47.614022
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    """
    Test case for method __str__ of class ImmutableList
    """
    list_1 = ImmutableList.of(1, 2, 3)
    assert str(list_1) == 'ImmutableList[1, 2, 3]'

    list_2 = ImmutableList.of(1, 2, 3, None, 0)
    assert str(list_2) == 'ImmutableList[1, 2, 3, None, 0]'

    list_3 = ImmutableList.empty()
    assert str(list_3) == 'ImmutableList[]'
    return True

# Generated at 2022-06-21 19:09:52.953932
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert ImmutableList.of(1, 2, 3).__len__() == 3
    assert ImmutableList.of(1, 2, 3, 4).__len__() == 4
    assert ImmutableList.of('a', 'b', 'c').__len__() == 3

# Generated at 2022-06-21 19:09:59.761343
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1).to_list() == [1]

    lst = ImmutableList.of(1)
    assert lst.unshift(0).to_list() == [0, 1]

    lst = ImmutableList.of(1, 2, 3)
    assert lst.unshift(0).to_list() == [0, 1, 2, 3]

    lst = ImmutableList.of(1, 2, 3)
    assert lst.unshift('a').to_list() == ['a', 1, 2, 3]



# Generated at 2022-06-21 19:10:02.753087
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    xs = ImmutableList.empty()
    assert len(xs) == 0

    xs = ImmutableList(1)
    assert len(xs) == 1

    xs = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert len(xs) == 3



# Generated at 2022-06-21 19:10:07.862911
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(0).reduce(lambda acc, x: acc + x, 0) == 0
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda acc, x: acc + x, 0) == 6
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda acc, x: acc + x, 1) == 7
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda acc, x: acc * x, 1) == 6
    assert ImmutableList(3, ImmutableList(2, ImmutableList(1))).reduce(lambda acc, x: acc * x, 2) == 12

# Generated at 2022-06-21 19:10:13.141551
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList.of(0)
    new_list = test_list.append(1)
    assert test_list == ImmutableList.of(0)
    assert new_list == ImmutableList.of(0, 1)



# Generated at 2022-06-21 19:10:18.259598
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    original = ImmutableList(1, ImmutableList(2))
    expected = ImmutableList(0, ImmutableList(1, ImmutableList(2)))

    assert original.unshift(0) == expected
    assert original == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-21 19:10:25.344787
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(2).find(lambda x: x == 2) == 2
    assert ImmutableList(2, ImmutableList(3, ImmutableList(4))).tail.head == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 0) is None
    assert ImmutableList().find(lambda x: x == 0) is None
    assert ImmutableList(1).find(lambda x: x > 10) is None


# Generated at 2022-06-21 19:10:31.098982
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    test_list = ImmutableList(1)
    empty_list = ImmutableList.empty()
    assert test_list.append(2).to_list() == [1, 2]
    assert test_list.append(2) == ImmutableList(1, ImmutableList(2))
    assert empty_list.append(2).to_list() == [2]

# Generated at 2022-06-21 19:10:38.669612
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    """
    Test case for method find of ImmutableList
    """
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda e: e % 3 == 0) == 3
    assert ImmutableList.of(1, 3, 5, 7, 9).find(lambda e: e % 2 == 0) is None
    assert ImmutableList.of(3, 6, 9, 12, 15).find(lambda e: e % 3 == 0) == 3
    assert ImmutableList.of(3, 6, 9, 12, 15).find(lambda e: e % 4 == 0) == 12

# Generated at 2022-06-21 19:11:18.003866
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList().unshift(1) == ImmutableList(T(1))
    assert ImmutableList(2).unshift(1) == ImmutableList(T(1), T(2))
    assert ImmutableList(2, 3).unshift(1) == ImmutableList(T(1), T(2), T(3))

# Generated at 2022-06-21 19:11:29.732578
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # given
    a = ImmutableList(1)
    b = ImmutableList(1)
    c = ImmutableList(2)
    d = ImmutableList.of(1, 2)
    e = ImmutableList.of(1, 2)
    f = ImmutableList.of(1, 3)
    g = ImmutableList.of(2, 3)
    h = ImmutableList.of(1, 2, 3)
    i = ImmutableList.of(1, 3, 3)
    j = ImmutableList.of(1, 2, 3)
    k = ImmutableList.of(1, 2, 3, 4)

    # expect
    assert a == b, "ImmutableList(1) =/= ImmutableList(1)"


# Generated at 2022-06-21 19:11:32.696279
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list = ImmutableList.of(1, 2, 3)
    expected = ImmutableList.of(4, 1, 2, 3)

    assert (expected == list + ImmutableList.of(4))

# Generated at 2022-06-21 19:11:35.000379
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_instance = ImmutableList.of('value1')
    list_instance = list_instance.append('value2')
    assert list_instance == ImmutableList.of('value1', 'value2')

# Generated at 2022-06-21 19:11:39.687749
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1).head == 1
    assert ImmutableList(1, tail=ImmutableList(tail=None)).head == 1
    assert ImmutableList(1, tail=ImmutableList(2, tail=ImmutableList(3, tail=None))).head == 1
    assert ImmutableList(1, tail=ImmutableList(2, tail=ImmutableList(3, tail=None))).tail.head == 2
    assert ImmutableList(1, tail=ImmutableList(2, tail=ImmutableList(3, tail=None))).tail.tail.head == 3


# Generated at 2022-06-21 19:11:50.240473
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    print('Running', __name__, ':', test_ImmutableList___eq__.__name__)

    # Test 1
    # empty list
    assert ImmutableList.empty() == ImmutableList.empty()
    # empty list with some elements
    assert ImmutableList.empty() != ImmutableList.of(1, 2)
    # Test 2
    # list with some elements == this list with same elements
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    # Test 3
    # list with some elements == this list with same elements but different constructor
    assert ImmutableList.of(1, ImmutableList.of(2, ImmutableList.of(3))) == ImmutableList.of(1, 2, 3)
    # list with some elements != this list with same elements

# Generated at 2022-06-21 19:11:56.241097
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)

    assert ImmutableList.empty() == ImmutableList.empty()
    assert not ImmutableList.of(1) != ImmutableList.of(1)


# Generated at 2022-06-21 19:12:02.272057
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    my_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert my_list.reduce(lambda first, second: first + second, 0) == 21
    assert my_list.reduce(lambda first, second: first * second, 1) == 720



# Generated at 2022-06-21 19:12:05.507561
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
   list_ = ImmutableList.of(1, 2, 3, 4, 5)
   assert list_.reduce(lambda acc, el: el + acc, 0) == 15



# Generated at 2022-06-21 19:12:11.172765
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.empty().append(1).append(2).append(3)
    assert l.find(lambda x: x%2 == 0) == 2
    assert l.find(lambda x: x%2 == 1) == 1
    assert l.find(lambda x: x%2 == 1) == 1
    assert l.find(lambda x: x > 3) == None
    assert l.find(lambda x: x == None) == None
    assert l.find(None) == None



# Generated at 2022-06-21 19:13:28.354038
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    l = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert l.head == 1
    assert l.tail == ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))

    assert ImmutableList.of(1, 2, 3, 4, 5) == l



# Generated at 2022-06-21 19:13:35.163865
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1).__add__(ImmutableList.of(2)) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).__add__(ImmutableList.of(3)) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).__add__(ImmutableList.of(4)) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-21 19:13:39.959629
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 0) is None


# Generated at 2022-06-21 19:13:43.164429
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_ = ImmutableList.of(1)
    assert(list_.__str__() == "ImmutableList[1]")
    assert(str(list_) == "ImmutableList[1]")



# Generated at 2022-06-21 19:13:50.517247
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    array = ImmutableList.of(1)
    new_array = array.map(lambda x: x + 1)

    expected_array = ImmutableList.of(2)
    assert new_array == expected_array

    array = ImmutableList.of(1, 2, 3, 4)
    new_array = array.map(lambda x: x + 1)

    expected_array = ImmutableList.of(2, 3, 4, 5)
    assert new_array == expected_array

# Generated at 2022-06-21 19:13:57.134465
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda i: i + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).map(lambda i: i + 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).map(lambda i: i + 1) == ImmutableList.of(2, 3, 4)


# Generated at 2022-06-21 19:13:59.637478
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:14:03.105795
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    a = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert a.filter(lambda x: x == 2) == ImmutableList(2)
    assert a.filter(lambda x: x == 5) == ImmutableList(is_empty=True)


# Generated at 2022-06-21 19:14:05.499116
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]
    

# Generated at 2022-06-21 19:14:10.103610
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_A = ImmutableList.of(1, 2, 3)
    list_B = ImmutableList.of(4, 5, 6)
    assert (
        list__add___22590845(list_A, list_B) ==
        ImmutableList.of(1, 2, 3, 4, 5, 6)
    )



# Generated at 2022-06-21 19:15:26.241733
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    test_list = ImmutableList.of(1, 2, 3)
    assert test_list.map(lambda x: x+1) == ImmutableList.of(2, 3, 4)



# Generated at 2022-06-21 19:15:31.424200
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList{}'
    assert str(ImmutableList(1)) == 'ImmutableList{1}'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList{1, 2}'



# Generated at 2022-06-21 19:15:34.459886
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 2) == ImmutableList(2, 4, 6)



# Generated at 2022-06-21 19:15:38.421532
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l = ImmutableList(1, ImmutableList(2))
    r = ImmutableList(3, ImmutableList(4))
    assert l + r == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert l == ImmutableList(1, ImmutableList(2))
    assert r == ImmutableList(3, ImmutableList(4))


# Generated at 2022-06-21 19:15:43.332182
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(1) == ImmutableList(1, ImmutableList(1))
    assert ImmutableList(1) + ImmutableList(1, ImmutableList(1)) == ImmutableList(1, ImmutableList(1, ImmutableList(1)))


# Generated at 2022-06-21 19:15:46.607219
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_of_numbers = ImmutableList.of(1, 2, 3, 4)
    expected_result = ImmutableList.of(1, 4, 9, 16)
    assert list_of_numbers.map(lambda x: x**2) == expected_result

# Generated at 2022-06-21 19:15:48.497582
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).to_list()


# Generated at 2022-06-21 19:15:49.894675
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3


# Generated at 2022-06-21 19:15:55.338707
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # arrange
    list_ = ImmutableList.of(1, 2, 3, 4)
    # act
    result = list_.unshift(0)
    # assert
    assert result == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))))


# Generated at 2022-06-21 19:16:01.958487
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    il = ImmutableList()
    assert il.to_list() == []

    il = ImmutableList(1)
    assert il.to_list() == [1]

    il = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert il.to_list() == [1,2,3]

    il = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert il.to_list() == [1,2,3]
