

# Generated at 2022-06-21 19:07:36.123359
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    data = ImmutableList.of(1, 2, 3, 4, 5)
    # acc + fn(acc, ImmutableList element)
    reduced = data.reduce(lambda acc, element: acc + element, 0)
    assert reduced == 15


# Generated at 2022-06-21 19:07:40.313586
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert isinstance(ImmutableList.of(1, 2, 3, 4, 5).__len__(), int)
    assert ImmutableList.of(1, 2, 3, 4, 5).__len__() == 5


# Generated at 2022-06-21 19:07:48.847221
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    example_list = ImmutableList.of(True, False, False, True)
    last_list = ImmutableList(True)

    assert example_list.filter(lambda v: v) == ImmutableList(True, ImmutableList(True))
    assert example_list.filter(lambda v: not v) == ImmutableList(False, ImmutableList(False))
    assert last_list.filter(lambda v: v) == last_list
    assert last_list.filter(lambda v: not v) == ImmutableList(is_empty=True)


# Generated at 2022-06-21 19:07:53.257108
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    lst = ImmutableList.empty()
    lst = lst.unshift(3)
    lst = lst.unshift(2)
    lst = lst.unshift(1)
    assert lst.to_list() == [1, 2, 3]

test_ImmutableList_unshift()   

# Generated at 2022-06-21 19:07:57.026806
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift('aaa').to_list() == ['aaa']
    assert ImmutableList.of(1, 2, 3).unshift('aaa').to_list() == ['aaa', 1, 2, 3]
    assert ImmutableList.of(1).unshift('aaa').to_list() == ['aaa', 1]



# Generated at 2022-06-21 19:08:01.685223
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    def square(a: int) -> int:
        return a**2

    assert ImmutableList().map(square) == ImmutableList()
    assert ImmutableList(1).map(square) == ImmutableList(1)
    assert ImmutableList(1, 2, 3).map(square) == ImmutableList(1, 4, 9)


# Generated at 2022-06-21 19:08:06.469389
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]'
    assert str(ImmutableList.of(1, 2, 3, 4, 5)) == 'ImmutableList[1, 2, 3, 4, 5]'



# Generated at 2022-06-21 19:08:13.457041
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    cl = ImmutableList.of(2, 3, 4)
    cl2 = cl.unshift(1)
    cl3 = cl2.unshift(0)
    assert cl3 == ImmutableList.of(0, 1, 2, 3, 4)
test_ImmutableList_unshift()


# Generated at 2022-06-21 19:08:19.542459
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    test_cases = [
        {
            "input": [1, 2, 3],
            "output": [2, 3, 4]
        },
        {
            "input": [2],
            "output": [3]
        },
        {
            "input": [],
            "output": []
        },
    ]

    for index, test_case in enumerate(test_cases):
        assert ImmutableList.of(*test_case["input"]).map(lambda x: x+1).to_list() == test_case['output'], 'method map of class ImmutableList does not work correctly on test case {}'.format(index+1)


# Generated at 2022-06-21 19:08:23.036319
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    empty_list = ImmutableList()
    not_empty_list = ImmutableList.of('a', 'b', 'c')
    assert empty_list.to_list() == []
    assert not_empty_list.to_list() == ['a', 'b', 'c']

# Generated at 2022-06-21 19:08:29.211843
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1,2,3,4,5)

    assert list_.find(lambda x: x == 4) == 4

# Generated at 2022-06-21 19:08:34.842709
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    """
    This test is for ImmutableList class. It covers case when
    you will call reduce method with one argument in ImmutableList
    """
    test_ImmutableList = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_ImmutableList.reduce(lambda x, y: x + y, 0) == 15

# Generated at 2022-06-21 19:08:42.121133
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    expected = [1, 2, 3]

    # Empty list
    assert ImmutableList().to_list() == []

    # List with only one element
    assert ImmutableList(1).to_list() == [1]

    # List with many elements
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == expected
    assert ImmutableList.of(1, 2, 3).to_list() == expected

    # Empty List 
    assert ImmutableList().to_list() == []


test_ImmutableList()

# Generated at 2022-06-21 19:08:48.288237
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() + ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.empty() == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)

test_ImmutableList___add__()

# Generated at 2022-06-21 19:08:53.377840
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(1))) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3

# Generated at 2022-06-21 19:08:59.953229
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    il1 = ImmutableList.of(1, 2, 3)
    il2 = il1.unshift(4)
    assert il2 == ImmutableList.of(4, 1, 2, 3)
    il3 = il2.unshift(5)
    assert il3 == ImmutableList.of(5, 4, 1, 2, 3)



# Generated at 2022-06-21 19:09:03.959840
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList[]' == str(ImmutableList.empty())
    assert 'ImmutableList[foo]' == str(ImmutableList('foo'))
    assert 'ImmutableList[foo, bar]' == str(ImmutableList('foo', ImmutableList('bar')))



# Generated at 2022-06-21 19:09:10.558935
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 4, -1, 6, -4, -8, 4)
    assert list.filter(lambda a: a > 0) == ImmutableList.of(1, 4, 6, 4)

    list = ImmutableList.of(1, 4, -1, 6, -4, -8, 4)
    assert list.filter(lambda a: a < 0) == ImmutableList.of(-1, -4, -8)


# Generated at 2022-06-21 19:09:13.672868
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3, 4).append(5) == ImmutableList.of(1, 2, 3, 4, 5)



# Generated at 2022-06-21 19:09:16.173400
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList.of(1, 2, 3)

    assert(l.reduce(lambda x, y: x * y, 1) == 6)


# Generated at 2022-06-21 19:09:25.023621
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'


# Generated at 2022-06-21 19:09:30.268070
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list1 = ImmutableList.of('h', 'e', 'l', 'l', 'o')
    result = list1.map(lambda x: x + ' ' + x)
    assert result == ImmutableList.of('h h', 'e e', 'l l', 'l l', 'o o')


# Generated at 2022-06-21 19:09:36.244561
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList()) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1) + ImmutableList(2, ImmutableList(3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:09:38.604212
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2).find(lambda x: x == 3) == None


# Generated at 2022-06-21 19:09:44.744652
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Given
    value = 'test'
    list_1 = ImmutableList(value)
    list_2 = ImmutableList(value)
    # When
    result_1 = list_1 == list_2
    result_2 = list_1 == None
    # Then
    assert result_1 == True
    assert result_2 == False


# Generated at 2022-06-21 19:09:49.816346
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    lst = ImmutableList.of(1, 2, 3)
    new_lst = lst.__add__(ImmutableList.of(4, 5, 6))

    assert new_lst.to_list() == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-21 19:09:57.289235
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    imm_lst_1 = ImmutableList.of(1, 2, 3, 4)
    imm_lst_2 = ImmutableList.of(5, 6, 7, 8)
    imm_lst_3 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    imm_lst_4 = ImmutableList.of(1, 2, 3, 4)
    assert imm_lst_1 + imm_lst_2 == imm_lst_3
    assert imm_lst_1 + imm_lst_2 == imm_lst_4.append(5).append(6).append(7).append(8)

# Generated at 2022-06-21 19:10:03.652112
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList()
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).head == 1
    assert ImmutableList.of(1, 2, 3).tail.head == 2
    assert ImmutableList.of(1, 2, 3).tail.tail.head == 3


# Generated at 2022-06-21 19:10:07.024368
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    obj = ImmutableList(None, ImmutableList('A', ImmutableList(1, ImmutableList(True))))

    result = obj.filter(lambda x: isinstance(x, str))

    assert result.head == 'A'
    assert result.tail == ImmutableList(empty=True)



# Generated at 2022-06-21 19:10:08.936533
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList.of(1, 2 , 3, 4, 5)
    assert a.reduce(lambda acc, x: acc + x, 0) == 15

# Generated at 2022-06-21 19:10:20.516960
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    l = l.unshift(0)
    assert l == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))))



# Generated at 2022-06-21 19:10:28.078486
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList([1, 2, 3, 4, 5]).reduce(lambda acc, x: acc + x**2, 0) == 55
    assert ImmutableList([1, 2, 3]).reduce(lambda acc, x: acc - x, 0) == -6
    assert ImmutableList([1, 2, 3]).reduce(lambda acc, x: acc * x, 1) == 6
    assert ImmutableList([1, 2, 3, 4, 5]).reduce(lambda acc, x: acc / x, 120) == 2
    assert ImmutableList(['A', 'B', 'C']).reduce(lambda acc, x: acc + x, '') == 'ABC'
    assert ImmutableList(['A', 'B', 'C']).reduce(lambda acc, x: acc + x[0], '') == 'ABC'


# Generated at 2022-06-21 19:10:33.747438
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.of('a').__str__() == 'ImmutableList[a]'
    assert ImmutableList.of('a', 'b', 'c').__str__() == 'ImmutableList[a, b, c]'
    assert ImmutableList.empty().__str__() == 'ImmutableList[]'



# Generated at 2022-06-21 19:10:37.597087
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:10:44.639796
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    empty = ImmutableList()

    assert empty == empty
    assert not (empty != empty)
    assert not (ImmutableList(1) == empty)
    assert ImmutableList(1) != empty

    assert ImmutableList(1, empty) == ImmutableList(1, empty)
    assert ImmutableList(1, empty) != ImmutableList(1)
    assert ImmutableList(1, empty) != ImmutableList(2, empty)



# Generated at 2022-06-21 19:10:53.100740
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 0) == 0
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 15) == 15
    assert ImmutableList.of(1).reduce(lambda x, y: x + y, 0) == 1
    assert ImmutableList.of(1).reduce(lambda x, y: x + y, 2) == 3
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x + y, 0) == 10
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x + y, 5) == 15

# Generated at 2022-06-21 19:11:01.462480
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1) + ImmutableList.of() == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 4, 5, 6)
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()

test_ImmutableList___add__()

# Generated at 2022-06-21 19:11:06.415795
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(2).append(5) == ImmutableList(2, ImmutableList(5))

    assert ImmutableList.of(2, 5).append(6) == ImmutableList(2, ImmutableList(5, ImmutableList(6)))



# Generated at 2022-06-21 19:11:13.617047
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l1 = ImmutableList.of(3)
    l2 = l1.append(5)
    assert l2 == ImmutableList.of(3, 5)

    l1 = ImmutableList.of(3, 5)
    l2 = l1.append(7)
    assert l2 == ImmutableList.of(3, 5, 7)

    assert l1 == ImmutableList.of(3, 5)

    l1 = ImmutableList.empty()
    l2 = l1.append(12)
    assert l1 == ImmutableList.empty()
    assert l2 == ImmutableList.of(12)



# Generated at 2022-06-21 19:11:22.668157
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5), \
        'Filter should return list of element that pass predicate'

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty(), \
        'Filter should return empty list if is no elements that pass predicate'

    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty(), \
        'Filter should return empty list if is no elements that pass predicate'


# Generated at 2022-06-21 19:11:41.019168
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # () -> Boolean
    lst = ImmutableList(1)
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0
    assert lst.filter(is_even).to_list() == []
    assert lst.filter(is_odd).to_list() == [1]
    lst = ImmutableList.of(1, 2, 3, 4)
    assert lst.filter(is_even).to_list() == [2, 4]
    assert lst.filter(is_odd).to_list() == [1, 3]
    


# Generated at 2022-06-21 19:11:45.663178
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of(1, 2, 3)
    second_list = ImmutableList.of(4, 5, 6)
    third_list = first_list.__add__(second_list)
    assert third_list.to_list() == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 19:11:55.263835
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list_1 = ImmutableList(1, None, False)
    list_2 = ImmutableList(2, list_1, False)
    list_3 = ImmutableList(3, list_2, False)
    list_4 = ImmutableList(4, list_3, False)
    assert list_4.to_list() == [4, 3, 2, 1]
    assert list_4.head == 4
    list_5 = ImmutableList.empty()
    assert list_5.head is None
    assert list_5.tail is None
    assert list_5.is_empty is True
    assert list_5.to_list() == []



# Generated at 2022-06-21 19:11:57.265465
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_ = ImmutableList.of(1, 2, 3, 4)
    assert str(list_) == 'ImmutableList[1, 2, 3, 4]'

# Generated at 2022-06-21 19:12:02.518349
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3).reduce(lambda acc, x: acc + x, 0) == 6
    assert ImmutableList.of('a', 'b', 'c').reduce(lambda acc, x: acc + x, '') == 'abc'

# Generated at 2022-06-21 19:12:06.414143
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)


# Generated at 2022-06-21 19:12:07.938083
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)


# Generated at 2022-06-21 19:12:18.918585
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6)) == 6
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7)) == 7
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)) == 8
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)) == 9
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 10
   

# Generated at 2022-06-21 19:12:23.782242
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_a = ImmutableList.of('a', 'b', 'c', 'd')
    list_b = ImmutableList.of('a', 'b', 'c', 'd')

    assert list_a == list_b

    list_a = ImmutableList.of('a', 'b', 'c', 'd')
    list_b = ImmutableList.of('a', 'b', 'c', 'e')

    assert list_a != list_b

    list_a = ImmutableList.of('a', 'b', 'c', 'd')
    list_b = ImmutableList.empty()

    assert list_a != list_b

    list_a = ImmutableList.empty()
    list_b = ImmutableList.empty()

    assert list_a == list_b


# Generated at 2022-06-21 19:12:26.906712
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:13:13.790591
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3

# Generated at 2022-06-21 19:13:15.128824
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    il = ImmutableList.of('a', 'b', 'c')
    assert len(il) == 3

# Generated at 2022-06-21 19:13:23.537802
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-21 19:13:25.971575
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-21 19:13:31.501071
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList().to_list() == []


# Generated at 2022-06-21 19:13:35.478924
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(1))) == 2
    assert len(ImmutableList(1, ImmutableList(1, ImmutableList(1)))) == 3



# Generated at 2022-06-21 19:13:41.532663
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == "ImmutableList[1, 2, 3]"
    assert str(ImmutableList(1, ImmutableList(is_empty=True))) == "ImmutableList[1]"
    assert str(ImmutableList(is_empty=True)) == "ImmutableList[]"
    assert ImmutableList(1, ImmutableList(is_empty=True)) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-21 19:13:43.747119
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
# test_ImmutableList()

# Generated at 2022-06-21 19:13:47.820244
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # 1. Given
    list = ImmutableList.of(1, 2, 3)
    # 2. When
    list = list.unshift(0)
    # 3. Then
    assert list.to_list() == [0, 1, 2, 3]



# Generated at 2022-06-21 19:13:55.938482
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    result = ImmutableList.empty()
    expected = ImmutableList.empty()

    assert result == expected

    result = ImmutableList.of(1).map(lambda x: x * 2)
    expected = ImmutableList.of(2)

    assert result == expected

    result = ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x * 3)
    expected = ImmutableList.of(3, 6, 9, 12, 15)

    assert result == expected


# Generated at 2022-06-21 19:14:42.073132
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of(1, 2, 3)
    l = l.unshift(0)
    assert l.to_list() == [0, 1, 2, 3]


# Generated at 2022-06-21 19:14:48.502467
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 1) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 2) == ImmutableList.empty()


# Generated at 2022-06-21 19:14:52.197275
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(2, ImmutableList(3))) == str([2, 3])
    assert str(ImmutableList(ImmutableList(2, ImmutableList(3)))) == str([2, 3])

# Generated at 2022-06-21 19:14:55.219463
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6)
    new_list = list_.filter(lambda x: x % 2 == 0)
    assert new_list == ImmutableList.of(2, 4, 6), 'Filter not working'



# Generated at 2022-06-21 19:15:00.843467
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-21 19:15:04.387075
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list0: ImmutableList[int] = ImmutableList.of(1, 2, 3, 4, 5)
    list1: ImmutableList[int] = ImmutableList.of(6, 7, 8, 9, 0)
    assert list0 + list1 == ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)

# Generated at 2022-06-21 19:15:11.837263
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3, 1, 2, 3)
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2) != ImmutableList.of(2, 1)



# Generated at 2022-06-21 19:15:18.887440
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x >= 2 and x <= 4) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None

    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x >= 2 and x <= 3) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x >= 4 and x <= 5) == 4

    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x >= 5 and x <= 4) is None



# Generated at 2022-06-21 19:15:25.235465
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    il = ImmutableList(1)
    assert il.to_list() == [1]

    il = ImmutableList(1, ImmutableList(2))
    assert il.to_list() == [1, 2]

    il = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert il.to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:15:36.593772
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    empty_list = ImmutableList.empty()
    assert len(empty_list) == 0
    assert empty_list.unshift(1).head == 1
    list_with_head = ImmutableList.of(2)
    assert len(list_with_head) == 1
    assert list_with_head.unshift(1).head == 1
    assert list_with_head.unshift(1).tail.head == 2
    assert list_with_head.unshift(1).tail.tail is None
    list_with_elements = ImmutableList.of(1, 2, 3, 4)
    assert len(list_with_elements) == 4
    assert list_with_elements.unshift(0).head == 0
    assert list_with_elements.unshift(0).tail.head == 1

# Generated at 2022-06-21 19:17:06.364613
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList.empty().to_list() == []

# Generated at 2022-06-21 19:17:08.173273
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():

    result = ImmutableList.of(1).unshift(2)

    assert ImmutableList.of(2, 1) == result


# Generated at 2022-06-21 19:17:13.239945
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList().head is None
    assert ImmutableList().tail is None
    assert ImmutableList().is_empty is True
    assert ImmutableList('foo').head == 'foo'
    assert ImmutableList('foo').tail is None
    assert ImmutableList('foo').is_empty is False
    assert ImmutableList('foo', ImmutableList('bar')).head == 'foo'
    assert ImmutableList('foo', ImmutableList('bar')).tail == ImmutableList('bar')
    assert ImmutableList('foo', ImmutableList('bar')).is_empty is False


# Generated at 2022-06-21 19:17:14.570841
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    il = ImmutableList.of(2, 3, 4)
    assert il.to_list() == [2, 3, 4]


# Generated at 2022-06-21 19:17:18.620995
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList.empty() + ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) + ImmutableList(2, ImmutableList(3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-21 19:17:20.064989
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append('Alice').to_list() == ['Alice']
    assert ImmutableList.of('Alice').append('Bob').to_list() == ['Alice', 'Bob']


# Generated at 2022-06-21 19:17:23.220376
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    l1 = ImmutableList(1)
    l2 = ImmutableList(2, l1)

    assert l1 == ImmutableList(1)
    assert l2 == ImmutableList(2, ImmutableList(1))
    assert l1.to_list() == [1]
    assert l2.to_list() == [2, 1]
    assert len(l1) == 1
    assert len(l2) == 2


# Generated at 2022-06-21 19:17:28.968592
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    cases = [
        (
            ImmutableList.of(1, 2, 3),
            [1, 2, 3],
        ),
        (
            ImmutableList.of(),
            [],
        ),
    ]

    for case in cases:
        yield _test_ImmutableList, case[0], case[1]

