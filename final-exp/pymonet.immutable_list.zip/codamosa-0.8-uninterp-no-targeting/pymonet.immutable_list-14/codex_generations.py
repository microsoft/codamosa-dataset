

# Generated at 2022-06-21 19:07:40.702762
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list = ImmutableList.of(1)
    assert(len(list) == 1)
    assert(list.to_list() == [1])

    list = list.append(2)
    assert(len(list) == 2)
    assert(list.to_list() == [1, 2])

    list = list.append(3)
    assert(len(list) == 3)
    assert(list.to_list() == [1, 2, 3])


# Generated at 2022-06-21 19:07:42.921973
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2).unshift(3).to_list() == [3, 1, 2]


# Generated at 2022-06-21 19:07:46.234370
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_.__str__() == 'ImmutableList[1, 2, 3]'



# Generated at 2022-06-21 19:07:52.447441
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l1 = ImmutableList()
    l2 = l1.append('a')
    assert l2 == ImmutableList('a')
    l2 = l2.append('b')
    assert l2 == ImmutableList('a', ImmutableList('b'))
    l2 = l2.append('c')
    assert l2 == ImmutableList('a', ImmutableList('b', ImmutableList('c')))


# Generated at 2022-06-21 19:07:55.966483
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    l = ImmutableList.of('a', 'b', 'c')
    assert l.find(lambda x: x == 'c') == 'c'



# Generated at 2022-06-21 19:08:02.157553
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    l = ImmutableList.of(1, 2, 3, 4, 5)
    l2 = ImmutableList.of(6, 7, 8, 9)

    assert l.reduce(lambda x, y: x + y, 0) == 15
    assert l2.reduce(lambda x, y: x + y, 0) == 34
    assert l.reduce(lambda x, y: x*y, 1) == 120
    assert l2.reduce(lambda x, y: x*y, 1) == 30240

# Generated at 2022-06-21 19:08:12.428525
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []

    assert ImmutableList.of(1).to_list() == [1]

    assert ImmutableList.of(1, 2).to_list() == [1, 2]

    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-21 19:08:18.746873
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list = ImmutableList.empty()
    assert list.head is None
    assert list.tail is None
    assert list.is_empty is True

    list = ImmutableList.of(1)
    assert list.head == 1
    assert list.tail is None
    assert list.is_empty is False

    list = ImmutableList.of(1, 2, 3)
    assert list.head == 1
    assert list.tail.head == 2
    assert list.tail.tail.head == 3
    assert list.tail.tail.tail is None
    assert list.is_empty is False
# Unit tests for __eq__ method of class ImmutableList

# Generated at 2022-06-21 19:08:21.024623
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x%2 == 0).to_list() == [2, 4]



# Generated at 2022-06-21 19:08:23.100071
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)
    
    

# Generated at 2022-06-21 19:08:40.395859
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda _: False) is None
    assert ImmutableList.empty().find(lambda _: True) is None
    
    assert ImmutableList(3).find(lambda _: False) is None
    assert ImmutableList(3).find(lambda _: True) == 3
    
    is_less_than_10 = lambda num: num < 10
    assert ImmutableList(11).find(is_less_than_10) is None
    assert ImmutableList(6).find(is_less_than_10) == 6
    
    assert ImmutableList(2, ImmutableList(5)).find(is_less_than_10) == 2
    assert ImmutableList(5, ImmutableList(2)).find(is_less_than_10) == 5

# Generated at 2022-06-21 19:08:48.373282
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a * b, 1) == 6
    assert ImmutableList.of('p', 'y', 't', 'h', 'o', 'n').reduce(lambda a, b: a + b, '') == 'python'
    assert ImmutableList.empty().reduce(lambda a, b: a + b, 0) == 0
    assert ImmutableList.of(1, 2).reduce(lambda a, b: a + b, 0) == 3
    assert ImmutableList.of(1.5, 2).reduce(lambda a, b: a + b, 0) == 3.5

# Generated at 2022-06-21 19:08:51.958303
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    l = ImmutableList(1, ImmutableList(2), ImmutableList(3))
    assert [1, 2, 3] == l.to_list()


# Generated at 2022-06-21 19:08:58.647904
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    source = ImmutableList.of(1, 2, 3, 4)
    target = source.map(lambda x: x * 2)

    expected = ImmutableList.of(2, 4, 6, 8)

    assert target == expected

    target = ImmutableList.empty().map(lambda x: x + 1)
    expected = ImmutableList.empty()

    assert target == expected

# Generated at 2022-06-21 19:09:05.356444
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # given
    list_1 = ImmutableList.of(1, 2, 3, 4, 5)
    list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    # then
    assert list_1.to_list() == [1, 2, 3, 4, 5]
    assert list_2.to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 19:09:13.965894
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    lst = ImmutableList.of(1, 2, 3, 4)
    lst2 = ImmutableList.of(5, 6, 7, 8)

    assert lst + lst2 == ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    assert lst2 + lst == ImmutableList.of(5, 6, 7, 8, 1, 2, 3, 4)

    try:
        lst + 'foo'

        assert False, "ImmutableList adds string!"
    except ValueError:
        pass

    try:
        'foo' + lst

        assert False, "ImmutableList adds string!"
    except ValueError:
        pass



# Generated at 2022-06-21 19:09:19.768518
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(16).to_list() == [16]
    assert ImmutableList.of(22, 90, 11, 845).to_list() == [22, 90, 11, 845]
    assert ImmutableList.of(10, 104, 11, 845).to_list() == [10, 104, 11, 845]

# Generated at 2022-06-21 19:09:27.172064
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda a, b: a + b, 0) == 3
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda a, b: a + b, 1) == 4
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda a, b: b + a, 2) == 5
    assert ImmutableList(1).reduce(lambda a, b: a + b, 0) == 1
    assert ImmutableList(1).reduce(lambda a, b: a + b, 1) == 2
    assert ImmutableList(1).reduce(lambda a, b: b + a, 2) == 3

# Generated at 2022-06-21 19:09:32.134407
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1, 2, 3)
    assert list_ == ImmutableList.of(1, 2, 3)
    assert list_.append(4) == ImmutableList.of(1, 2, 3, 4)
    assert list_ == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-21 19:09:36.001666
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    l = ImmutableList(1)
    print('printing arg:')
    print(l.head)
    assert l.head == 1
    assert l.tail == None
    assert l.is_empty == False

test_ImmutableList()


# Generated at 2022-06-21 19:09:52.366055
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of('a', 'b', 'c')) == 3



# Generated at 2022-06-21 19:10:01.066530
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 3) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 4) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 5) is None
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x == 6) is None
   

# Generated at 2022-06-21 19:10:04.853386
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Empty list
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1,2)) == 2
    assert len(ImmutableList.of(1,2,3)) == 3
    
    


# Generated at 2022-06-21 19:10:08.157643
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():

    assert ImmutableList.of(1,2,3,4,5).reduce(lambda x,y : x*y ,1) == 120

    assert ImmutableList.of('qwerty').reduce(lambda x,y: x+y,'') == 'qwerty'


# Generated at 2022-06-21 19:10:15.705151
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    initial_list = ImmutableList.of(2)

    assert initial_list.append(3) == ImmutableList.of(2, 3)
    assert initial_list.append(4) == ImmutableList.of(2, 4)
    assert initial_list.append(3).append(4) == ImmutableList.of(2, 3, 4)


# Generated at 2022-06-21 19:10:18.059136
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:10:21.003965
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(2, 3, 4, 5)\
        .filter(lambda x: x != 4)\
        .to_list() == [2, 3, 5]


# Generated at 2022-06-21 19:10:23.237575
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda a: a > 3).to_list() == [4, 5, 6]



# Generated at 2022-06-21 19:10:29.651450
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    tester = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    tester2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(0)))))
    tester3 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(2))))))
    assert tester.find(lambda x: x == 4) == 4
    assert tester.find(lambda x: x == 5) == 5
    assert tester.find(lambda x: x == 2) == 2
    assert tester.find(lambda x: x == 15) is None
    assert tester2.find(lambda x: x == 0)

# Generated at 2022-06-21 19:10:34.167239
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l = ImmutableList.of('X', 'Y', 'Z')
    l2 = l.append('A')
    assert l2 == ImmutableList.of('X', 'Y', 'Z', 'A')


# Generated at 2022-06-21 19:11:08.643457
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    lst1 = ImmutableList.of(1, 2)
    lst2 = lst1.unshift(3)
    assert lst2 == ImmutableList(3, ImmutableList(1, ImmutableList(2)))
    lst3 = lst2.unshift(4)
    assert lst3 == ImmutableList(4, ImmutableList(3, ImmutableList(1, ImmutableList(2))))
    assert lst1 == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-21 19:11:12.713635
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5) == None
    assert ImmutableList.empty().find(lambda x: x == 2) == None
    
    

# Generated at 2022-06-21 19:11:20.520137
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x > 0) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda x: x > 0) == ImmutableList(1)
    assert ImmutableList(1, 2).filter(lambda x: x > 0) == ImmutableList(1, 2)
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 1) == ImmutableList(2, 3)
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()


# Generated at 2022-06-21 19:11:25.321474
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]'


# Generated at 2022-06-21 19:11:34.571636
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x % 2 == 0) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))).filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7))))))).filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4, ImmutableList(6)))
    assert ImmutableList().filter(lambda x: x % 2 == 0) == ImmutableList(is_empty=True)
# Unit

# Generated at 2022-06-21 19:11:43.047809
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(True, False, 1, 'a').to_list() == [True, False, 1, 'a']
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8).to_list() == [1, 2, 3, 4, 5, 6, 7, 8]


# Generated at 2022-06-21 19:11:48.214627
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    emptyList = ImmutableList.empty()
    assert len(emptyList) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 4

# Generated at 2022-06-21 19:11:50.808953
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    sl = ImmutableList.of(1, 2, 3)
    res = sl.reduce(lambda x, y: x + y, 0)
    assert res == 6



# Generated at 2022-06-21 19:11:57.951377
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) + ImmutableList.empty() == ImmutableList(1)
    assert ImmutableList.empty() + ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-21 19:12:01.342614
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(2, 3, 4, 5).map(lambda x: x + 1).to_list() == [3, 4, 5, 6]


# Generated at 2022-06-21 19:13:04.648411
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(3, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


# Generated at 2022-06-21 19:13:10.079762
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    il1 = ImmutableList.of(1, 2, 3, 4, 5)
    il2 = ImmutableList.of(6, 7, 8, 9, 10)
    il3 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    assert il1 + il2 == il3



# Generated at 2022-06-21 19:13:16.007254
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of(1, 2, 3, 4)
    l1 = l.unshift(0)
    assert l1.head == 0
    assert l1.tail.head == 1
    assert l1.tail.tail.head == 2
    assert l1.tail.tail.tail.head == 3
    assert l1.tail.tail.tail.tail.head == 4
    assert l1.tail.tail.tail.tail.tail is None
    assert len(l1) == 5



# Generated at 2022-06-21 19:13:17.922256
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1,2,3).to_list() == [1,2,3]
    assert ImmutableList.of(1).to_list() == [1]


# Generated at 2022-06-21 19:13:23.355290
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Empty list
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(None)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

    # List of size 1
    assert len(ImmutableList.of(1)) == 1

    # List of size more than 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-21 19:13:26.122983
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    values = ImmutableList.of(1, 2, 3)
    assert values.reduce(lambda a, b: a + b, 0) == 6
    
    

# Generated at 2022-06-21 19:13:30.593565
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of()) == 0
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-21 19:13:39.199853
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    def is_positive(elem: int) -> bool:
        return elem > 0

    assert ImmutableList.of(1, 2, 3).filter(is_positive) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(0, -1, -2).filter(is_positive) == ImmutableList.empty()
    assert ImmutableList.empty().filter(is_positive) == ImmutableList.empty()
    assert ImmutableList.of(1, 0, -1, 2, -2).filter(is_positive) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 0, -1, 2, -2).filter(is_positive).is_empty is False



# Generated at 2022-06-21 19:13:45.598312
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda x: x > 1).is_empty
    assert ImmutableList(1, 2, 3).filter(lambda x: x > 1) == ImmutableList(2, 3)
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 3) == ImmutableList(1, 2)
    assert ImmutableList(1, 2, 3).filter(lambda x: x < 0).is_empty

# Generated at 2022-06-21 19:13:53.258180
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda value: value * 2) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(None, 1).map(lambda value: value * 2) == ImmutableList.of(2, 2)
    assert ImmutableList.of(1).map(lambda value: value * 2) == ImmutableList.of(2)
    assert ImmutableList.of().map(lambda value: value * 2) == ImmutableList(is_empty=True)



# Generated at 2022-06-21 19:15:55.144429
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    def check_ImmutableList___eq__(actual, expected):
        assert actual == expected, 'Expected ImmutableList::__eq__({}) to be {}, but got {}'.format(actual, expected, actual.__eq__(expected))

    check_ImmutableList___eq__(ImmutableList.of(3), ImmutableList.of(3))
    check_ImmutableList___eq__(ImmutableList.of(1, 2, 3), ImmutableList.of(1, 2, 3))
    check_ImmutableList___eq__(ImmutableList.of(1, 2, 3), ImmutableList.of(1, 2, 4))
    check_ImmutableList___eq__(ImmutableList.of(1, 2, 3), ImmutableList.empty())

# Generated at 2022-06-21 19:16:04.277086
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l1 = ImmutableList(1)
    l2 = ImmutableList(2)

    assert l1 + l2 == ImmutableList(1, ImmutableList(2))

    assert l2 + l1 == ImmutableList(2, ImmutableList(1))

    l3 = ImmutableList(3, ImmutableList(4))

    assert l1 + l2 + l3 == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

    assert l3 + l2 + l1 == ImmutableList(3, ImmutableList(4, ImmutableList(2, ImmutableList(1))))

    with pytest.raises(ValueError) as excinfo:
        l1 + 1

# Generated at 2022-06-21 19:16:07.101279
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Arrange
    # Act
    # Assert
    assert str(ImmutableList(1,2,3)) == "ImmutableList{1, 2, 3}"

# Generated at 2022-06-21 19:16:12.727312
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: not x) == ImmutableList.empty()

    assert ImmutableList.of(1,2,3).filter(lambda x: x < 3) == ImmutableList.of(1, 2)

    assert ImmutableList.of(1,2,3).filter(lambda x: x > 3) == ImmutableList.empty()


# Generated at 2022-06-21 19:16:18.470056
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Function test_ImmutableList_filter verifies behaviour
    of filter method of ImmutableList class

    :returns: boolean of success
    """
    maybe_list = ImmutableList.of(1, 2, 3, 4)
    filter_fn = lambda x: x % 2 == 0

    assert maybe_list.filter(filter_fn) == ImmutableList.of(2, 4)
    assert maybe_list.filter(filter_fn).to_list() == [2, 4]

# Generated at 2022-06-21 19:16:24.363057
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # given
    list_one = ImmutableList.of(1, 2, 3)
    list_two = ImmutableList.of(4, 5, 6)
    # execute
    output = list_one + list_two
    # expect
    assert output == ImmutableList.of(1, 2, 3, 4, 5, 6)



# Generated at 2022-06-21 19:16:31.141849
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 0) == 0
    assert ImmutableList.of(1).reduce(lambda x, y: x + y, 0) == 1
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 1) == 1
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 1) == 7

# Generated at 2022-06-21 19:16:32.996833
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'



# Generated at 2022-06-21 19:16:34.736684
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda x, y: x + y, 0) == 10

# Generated at 2022-06-21 19:16:38.386298
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(3)) == 1
    assert len(ImmutableList.of(3, 4, 5)) == 3
    assert len(ImmutableList.of()) == 0
