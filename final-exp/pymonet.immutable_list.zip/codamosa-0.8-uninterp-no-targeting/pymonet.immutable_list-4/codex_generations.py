

# Generated at 2022-06-21 19:07:38.728112
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    original_list = ImmutableList.of(1, 2, 2, 3, 2)
    output = str(original_list)
    expected_output = 'ImmutableList[1, 2, 2, 3, 2]'

    assert output == expected_output


# Generated at 2022-06-21 19:07:48.985435
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    test_cases = [
        (
            [],
            0
        ),
        (
            [1],
            1
        ),
        (
            [1, 2, 3],
            3
        ),
        (
            [1, 2, 3, 4],
            4
        )
    ]

    for test_case, expected_result in test_cases:
        instance = ImmutableList.of(*test_case)
        result = len(instance)

        assert result == expected_result,\
            'test_ImmutableList___len__({}): expected "{}", got "{}"'.format(test_case, expected_result, result)

# Generated at 2022-06-21 19:07:53.049773
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    empty_list = ImmutableList.empty()
    test_list = ImmutableList(1)

    assert empty_list.unshift(1) == ImmutableList(1)
    assert test_list.unshift(2) == ImmutableList(2, ImmutableList(1))


# Generated at 2022-06-21 19:07:55.938792
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    a = ImmutableList(1, ImmutableList(2))
    assert a.append(3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-21 19:07:58.273986
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3).to_list() == [1, 2, 3]



# Generated at 2022-06-21 19:08:02.340735
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of('a', 1, 2).to_list() == ['a', 1, 2]


# Generated at 2022-06-21 19:08:09.236580
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]



# Generated at 2022-06-21 19:08:11.797386
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    x = ImmutableList.of(1, 2, 3)
    assert len(x) == 3


# Generated at 2022-06-21 19:08:12.591157
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)



# Generated at 2022-06-21 19:08:15.151764
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Arrange
    l = ImmutableList.of(1, 2, 3)

    # Assert
    assert l.to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:08:27.622076
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # type: () -> None
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:08:37.906348
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    empty_list = ImmutableList.empty()
    assert empty_list.reduce(lambda x, y: x + y, 0) == 0

    list_with_one_element = ImmutableList(1)
    assert list_with_one_element.reduce(lambda x, y: x + y, 0) == 1

    list_with_two_elements = ImmutableList.of(1, 2)
    assert list_with_two_elements.reduce(lambda x, y: x + y, 0) == 3

    list_with_three_elements = ImmutableList.of(1, 2, 3)
    assert list_with_three_elements.reduce(lambda x, y: x + y, 0) == 6


# Generated at 2022-06-21 19:08:42.496976
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of(1, 2, 3)

    l1 = l.unshift(0)

    assert l1 == ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    assert l == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-21 19:08:47.097563
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Given
    first_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    second_list = ImmutableList(4, ImmutableList(5))

    # When
    actual = first_list + second_list

    # Then
    assert actual == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))



# Generated at 2022-06-21 19:08:51.500813
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(5, 2, 5).unshift(10) == ImmutableList.of(10, 5, 2, 5)
    assert ImmutableList(None).unshift(10) == ImmutableList.of(10)

# Generated at 2022-06-21 19:08:56.700440
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList.empty().__str__() == 'ImmutableList[]'
    assert ImmutableList.of(1).__str__() == 'ImmutableList[1]'
    assert ImmutableList.of(1, 2, 3).__str__() == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:09:06.210369
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList().__eq__(ImmutableList()), 'Two empty ImmutableList should be equal'
    assert not ImmutableList().__eq__(ImmutableList(True)), 'ImmutableList with and without value should not be equal'
    assert ImmutableList(1).__eq__(ImmutableList(1)), 'Two ImmutableList of different types should be equal'
    assert not ImmutableList(1).__eq__(ImmutableList(2)), 'Two ImmutableList of different values should not be equal'
    assert not ImmutableList(True).__eq__(ImmutableList(False)), 'Two ImmutableList of different types and values should not be equal'



# Generated at 2022-06-21 19:09:13.148382
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.of(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-21 19:09:16.811527
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert 'ImmutableList{}' == str(ImmutableList())
    assert 'ImmutableList{5}' == str(ImmutableList(5))
    assert 'ImmutableList{5, 1}' == str(ImmutableList(5, ImmutableList(1)))


# Generated at 2022-06-21 19:09:20.702654
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    expected = [1, 2, 3]
    actual = ImmutableList.of(1, 2, 3).to_list()
    assert actual == expected


# Generated at 2022-06-21 19:09:32.232001
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1,2,3)) == 3
    assert len(ImmutableList.of("hello", "world")) == 2
    assert len(ImmutableList.of("hello", "world", "!")) == 3


# Generated at 2022-06-21 19:09:37.052727
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-21 19:09:39.795620
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_ = ImmutableList(1, ImmutableList(2))
    assert list_ == ImmutableList(1, ImmutableList(2))
    assert list_ != ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:09:44.092592
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    il = ImmutableList.of(1, 2, 3)
    assert len(il) == 3

    il = ImmutableList.empty()
    assert len(il) == 0



# Generated at 2022-06-21 19:09:52.362018
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2), False)) == 'ImmutableList{[1, 2]}'
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList{[1, 2]}'
    assert str(ImmutableList(1, ImmutableList.of(2))) == 'ImmutableList{[1, 2]}'
    assert str(ImmutableList.empty()) == 'ImmutableList{[]}'

# Unit tests for class ImmutableList

# Generated at 2022-06-21 19:09:57.707985
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Create ImmutableList and filter it to get odds
    # assert that result equals expected value
    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) \
        .filter(lambda x: x % 2 != 0).to_list() == [1, 3, 5, 7, 9]



# Generated at 2022-06-21 19:10:03.709398
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    """
    Test method __add__ of class ImmutableList
    """
    l1 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    l2 = ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8))))
    l3 = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, 
                                            ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8))))))))
    assert l1 + l2 == l3
    assert l3 == l1 + l2
    
    

# Generated at 2022-06-21 19:10:06.163342
# Unit test for constructor of class ImmutableList
def test_ImmutableList(): # pragma: no cover
    x = ImmutableList.of(1, 2)

    assert x.tail is not None
    assert x.head == 1
    assert x.tail.head == 2



# Generated at 2022-06-21 19:10:09.474228
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)

# Generated at 2022-06-21 19:10:21.727132
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList.empty() == ImmutableList()
    assert ImmutableList.of(1).reduce(lambda a, b: a + b, 0) == 1
    assert ImmutableList.of(1).append(2).to_list() == [1, 2]
    assert ImmutableList.of(1).unshift(2).to_list() == [2, 1]
    assert ImmutableList.of(1).filter(lambda _: True).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda _: True).to_list() == [1, 2, 3, 4]
   

# Generated at 2022-06-21 19:10:48.841825
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x * y, 1) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x - y, 0) == -6
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x - y, 5) == 3
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x / y, 6) == 2

# Generated at 2022-06-21 19:10:50.470882
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of('first').append('second').to_list() == ['first', 'second']



# Generated at 2022-06-21 19:10:53.749505
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter(): # pragma: no cover
    l = ImmutableList.of(1, 2, 4, 5, 6)
    assert l.filter(lambda x: x < 5) == ImmutableList.of(1, 2, 4)
    assert l.filter(lambda x: x == 3) == ImmutableList.empty()



# Generated at 2022-06-21 19:10:56.845388
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 10) == ImmutableList.of(11, 12, 13, 14)


# Generated at 2022-06-21 19:11:07.925207
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) + ImmutableList(4, ImmutableList(5)) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert ImmutableList(1) + ImmutableList(2, ImmutableList(3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:11:11.031576
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]


# Generated at 2022-06-21 19:11:18.621248
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList(1).find(lambda x: x == 1) == 1
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 2) == 2
    assert ImmutableList(1, ImmutableList(2)).find(lambda x: x == 3) is None
    assert ImmutableList(1, ImmutableList(1)).find(lambda x: x == 1) == 1
    assert ImmutableList().find(lambda x: x == 1) is None


# Generated at 2022-06-21 19:11:30.337007
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Given
    list1 = ImmutableList(1, ImmutableList(0), is_empty=False)
    list2 = ImmutableList(2, ImmutableList(1), is_empty=False)
    list_with_empty = ImmutableList(1, ImmutableList(0), is_empty=True)
    list3 = ImmutableList(11, ImmutableList(10), is_empty=False)
    # When add method is used with list1 and list2
    result = list1 + list2
    # Then result should be equal list3
    assert result == list3

    # When add method is used with list1 and list_with_empty
    result = list1 + list_with_empty
    # Then result should be equal list1
    assert result == list1

    # When add method is used with list_with_empty and

# Generated at 2022-06-21 19:11:33.452828
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    def add_one(x):
        return x + 1

    assert ImmutableList.of(1, 2, 3, 4).map(add_one) == ImmutableList.of(2, 3, 4, 5)

# Generated at 2022-06-21 19:11:36.511106
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Given
    arg = [1, 2, 3, 4, 5]
    def fn(acc, el):
        return acc + el

    # When
    actual = ImmutableList.of(*arg).reduce(fn, 0)

    # Then
    assert actual == sum(arg)


# Generated at 2022-06-21 19:12:06.414719
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4)) == 'ImmutableList[1, 2, 3, 4]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'

# Generated at 2022-06-21 19:12:11.049741
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == []
    assert ImmutableList('a').to_list() == ['a']
    assert ImmutableList('a', ImmutableList('b')).to_list() == ['a', 'b']
    assert ImmutableList('a', ImmutableList('b', ImmutableList('c'))).to_list() == ['a', 'b', 'c']


# Generated at 2022-06-21 19:12:14.284242
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 4, 5)) == '[1, 4, 5]'

# Generated at 2022-06-21 19:12:22.965789
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList.empty()

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: True) \
        == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: False) \
        == ImmutableList.empty()
    
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2) \
        == ImmutableList(1, ImmutableList(3))


# Generated at 2022-06-21 19:12:26.309914
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # arrange
    list = ImmutableList.of(1, 2, 3)
    # action
    result = list.find(lambda x: x == 2)
    # assert
    assert result == 2


# Generated at 2022-06-21 19:12:29.578946
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3)\
        .map(lambda n: n**2)\
        .to_list() == [1, 4, 9]

    

# Generated at 2022-06-21 19:12:32.173008
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList.of(1, 2)) == 2

# Generated at 2022-06-21 19:12:34.657969
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:12:41.108592
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == "ImmutableList[]"
    assert str(ImmutableList(5)) == "ImmutableList[5]"
    assert str(ImmutableList(5, ImmutableList(10))) == "ImmutableList[5, 10]"
    assert str(ImmutableList(5, ImmutableList(10, ImmutableList(100)))) == "ImmutableList[5, 10, 100]"


# Generated at 2022-06-21 19:12:47.543141
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    initial_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    result_empty_list = ImmutableList(is_empty=True)

    assert initial_list.map(lambda x: x + 1).to_list() == [2, 3, 4]

    assert result_empty_list.map(lambda x: x + 1).to_list() == []


# Generated at 2022-06-21 19:13:40.962632
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    lst = ImmutableList.of(1, 2, 3)
    assert lst.reduce(lambda acc, x: acc + x, 0) == 6

# Generated at 2022-06-21 19:13:47.651323
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    
    expected = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList(1) + ImmutableList(2, ImmutableList(3)) == expected
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == expected
    assert ImmutableList(1) + ImmutableList(2) + ImmutableList(3) == expected


test_ImmutableList___add__()

# Generated at 2022-06-21 19:13:54.601519
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]' # ImmutableList.empty()
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]' # ImmutableList.of(1)
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]' # ImmutableList.of(1, 2, 3)

# Generated at 2022-06-21 19:13:58.274522
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(4, 5, 6)
    assert list1.__add__(list2) == ImmutableList.of(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-21 19:14:01.695979
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # given
    input_list = ImmutableList.of(1, 2, 3, 4)
    expected_list = [1, 2, 3, 4]

    # when
    result = input_list.to_list()

    # then
    assert result == expected_list



# Generated at 2022-06-21 19:14:06.659851
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x < 4) == ImmutableList.empty()
    assert ImmutableList.of(3, 4, 5).filter(lambda x: x < 4) == ImmutableList.of(3)
    assert ImmutableList.of(3, 4, 5).filter(lambda x: x > 4) == ImmutableList.of(5)

# Generated at 2022-06-21 19:14:08.160656
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:14:10.276130
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # No elements
    assert len(ImmutableList.empty()) == 0

    # One element
    assert len(ImmutableList.of(2)) == 1

    # More elements
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6)) == 6

# Generated at 2022-06-21 19:14:17.258117
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l = ImmutableList.of(1, 2, 3)
    l2 = l.append(7)

    assert l != l2, 'Should not be the same instance'
    assert l != l2.append(10), 'Should not be the same instance'

    assert l2.to_list() == [1, 2, 3, 7], 'Should not be the same instance'



# Generated at 2022-06-21 19:14:25.842836
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # test 1: function map should return new instance of ImmutableList
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x + 1) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    # test 2: function map should return new ImmutableList with same number of elements
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x + 1)) == len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3
    # test 3: function map should return new ImmutableList with elements mapped into result of argument called with each element of ImmutableList

# Generated at 2022-06-21 19:16:18.922484
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    def assert_to_list(immutable_list, expected_result):
        assert immutable_list.to_list() == expected_result

    assert_to_list(ImmutableList.empty(), [])
    assert_to_list(ImmutableList.of(1), [1])
    assert_to_list(ImmutableList.of(1, 2), [1, 2])
    assert_to_list(ImmutableList.of(1, 2, 3), [1, 2, 3])



# Generated at 2022-06-21 19:16:22.669405
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    first = ImmutableList(1)
    second = first.append(2)

    assert first == ImmutableList(1)
    assert second == ImmutableList(1, ImmutableList(2))
    assert first is not second


test_ImmutableList_append()



# Generated at 2022-06-21 19:16:27.450115
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    immutable_list = ImmutableList.of(1)
    applied_list = immutable_list.append(2)
    expected_list = ImmutableList.of(1, 2)
    assert expected_list == applied_list

test_ImmutableList_append()



# Generated at 2022-06-21 19:16:31.100666
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = list1.unshift(10)
    list3 = ImmutableList.of(10, 1, 2, 3)
    assert list2 == list3

test_ImmutableList_unshift()

# Generated at 2022-06-21 19:16:35.392655
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    il = ImmutableList.of(1, 2, 3)
    il2 = il.map(lambda x: x + 1)
    assert il2 == ImmutableList.of(2, 3, 4)

    il1 = ImmutableList.of(1)
    il3 = il1.map(lambda x: x + 1)
    assert il3 == ImmutableList.of(2)



# Generated at 2022-06-21 19:16:43.121029
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1).append(1) == ImmutableList.of(1, 1)
    assert ImmutableList().append(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3).append(4).append(5) == ImmutableList.of(1, 2, 3, 4, 5)



# Generated at 2022-06-21 19:16:46.648156
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # when
    list1 = ImmutableList.of(1, 2)
    list2 = list1.map(lambda x: x + 1)

    # then
    assert list2 == ImmutableList(2, 3)


# Generated at 2022-06-21 19:16:50.171339
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_.map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5, 6)


# Generated at 2022-06-21 19:16:51.908230
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    ImmutableList().__str__()

test_ImmutableList___str__()

# Generated at 2022-06-21 19:16:57.975514
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of('a') == ImmutableList('a')
    assert ImmutableList.of('a', 'b') == ImmutableList('a', ImmutableList('b'))
    assert ImmutableList.of('a', 'b', 'c') == ImmutableList('a', ImmutableList('b', ImmutableList('c')))
    assert ImmutableList.of('a', 'b', 'c', 'd') == ImmutableList('a', ImmutableList('b', ImmutableList('c', ImmutableList('d'))))

    assert ImmutableList('a').__len__() == 1
    assert ImmutableList('a', ImmutableList('b')).__len__() == 2
    assert ImmutableList('a', ImmutableList('b', ImmutableList('c'))).__len__() == 3
    assert Immutable