

# Generated at 2022-06-21 19:07:37.576787
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2 == 0).to_list() == [2]


# Generated at 2022-06-21 19:07:44.121865
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda item: item % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda item: item % 2 == 0) != ImmutableList.of(3, 4)
    assert ImmutableList.empty().filter(lambda item: item % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-21 19:07:54.761675
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    immutable_list = ImmutableList.empty()
    assert immutable_list.find(lambda v: True) is None, 'ImmutableList find empty type'

    immutable_list = ImmutableList.of('first', 'second', 'third')
    assert immutable_list.find(lambda v: v == 'second') == 'second', 'ImmutableList find'
    assert immutable_list.find(lambda v: v == 'second_') is None, 'ImmutableList find empty type'
    assert immutable_list.find(lambda v: True) == 'first', 'ImmutableList find last element'
    assert immutable_list.find(lambda v: False) is None, 'ImmutableList is not immutable'



# Generated at 2022-06-21 19:08:00.554042
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = ImmutableList.of(1, 2, 3, 4)
    list3 = ImmutableList.of(4, 3, 2, 1)

    assert list1 == list2
    assert list2 == list1
    assert list1 != list3
    assert list2 != list3
    assert list3 != list1
    assert list3 != list2


# Generated at 2022-06-21 19:08:08.273258
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    """
    Unit test for method __str__ of class ImmutableList
    """
    assert str(ImmutableList()) == "ImmutableList[]"
    assert str(ImmutableList(1, ImmutableList(2))) == "ImmutableList[1, 2]"
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == "ImmutableList[1, 2, 3]"
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == "ImmutableList[1, 2, 3, 4]"
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))) == "ImmutableList[1, 2, 3, 4, 5]"

# Generated at 2022-06-21 19:08:17.952189
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    t1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    t2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert t1 == t2
    assert t1 is not t2

    t3 = ImmutableList(1, ImmutableList(2, ImmutableList(2)))
    assert t1 != t3
    assert t1 is not t3

    assert t5 != [1, 2, 3]

    assert ImmutableList() == ImmutableList.empty()
    assert not ImmutableList() == ImmutableList.of(1)


# Generated at 2022-06-21 19:08:23.788695
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list1 = ImmutableList.empty()
    list2 = ImmutableList.of(1)
    list3 = ImmutableList.of(1,2,3,4,5)

    assert list1.map(lambda x: x * 2) == ImmutableList.empty()
    assert list2.map(lambda x: x * 2) == ImmutableList.of(2)
    assert list3.map(lambda x: x * 2) == ImmutableList.of(2, 4, 6, 8, 10)



# Generated at 2022-06-21 19:08:34.038091
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3) != ImmutableList(1)
    assert ImmutableList.of(1, 2) != ImmutableList(1, ImmutableList.empty())
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(4)))



# Generated at 2022-06-21 19:08:44.265876
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)

    assert ImmutableList(1) != ImmutableList(is_empty=True)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1)

    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]

# Generated at 2022-06-21 19:08:48.279380
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list = ImmutableList.empty()
    list = list.append(1)
    list = list.append(2)
    list = list.append(3)
    list = list.append(4)

    assert len(list) == 4



# Generated at 2022-06-21 19:09:01.977741
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    GIVEN ImmutableList filled with integers
    WHEN filter method is called with argument 0
    THEN ImmutableList with elements that are different than 0 should be returned
    """
    list1 = [1, 2, 3, 4, 0, 2, 3, 0, 4, 5, 6]
    list2 = [1, 2, 3, 4, 2, 3, 4, 5, 6]
    assert ImmutableList.of(*list1).filter(lambda x: x == 0) == ImmutableList.of(*list2)


# Generated at 2022-06-21 19:09:08.614096
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert(
        ImmutableList.empty().filter(lambda value: True) == ImmutableList.empty()
    )

    assert(
        ImmutableList.empty().filter(lambda value: False) == ImmutableList.empty()
    )

    assert(
        ImmutableList.of(1, 2, 3, 4).filter(lambda value: value > 2) == ImmutableList.of(3, 4)
    )


# Generated at 2022-06-21 19:09:11.990896
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    element_1 = ImmutableList.of(1)
    assert str(element_1) == 'ImmutableList[1]'

    element_2 = ImmutableList.of(1, 2)
    assert str(element_2) == 'ImmutableList[1, 2]'



# Generated at 2022-06-21 19:09:18.981817
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 1, 2, 3).map(lambda x: x+1) == ImmutableList.of(2, 2, 3, 4)
    assert ImmutableList.empty().map(lambda x: x+1) == ImmutableList.empty()
    assert ImmutableList.of(1).map(lambda x: x+1) == ImmutableList.of(2)


# Generated at 2022-06-21 19:09:22.256473
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Arrange
    expected = 4
    list = ImmutableList.of(0, 1, 2, 3)

    # Act
    actual = len(list)

    # Assert
    assert actual == expected

# Generated at 2022-06-21 19:09:28.770765
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(is_empty=True) is not None
    assert ImmutableList(is_empty=False) is not None
    assert ImmutableList(is_empty=True).head is None
    assert ImmutableList(is_empty=True).tail is None
    assert ImmutableList(is_empty=True).is_empty is True
    
    assert ImmutableList(is_empty=False).head is None
    assert ImmutableList(is_empty=False).tail is None
    assert ImmutableList(is_empty=False).is_empty is False
    
    assert ImmutableList(1).head == 1
    assert ImmutableList(1).tail is None
    assert ImmutableList(1).is_empty is False
    
    assert ImmutableList(1, ImmutableList(2), False).head == 1
    assert Imm

# Generated at 2022-06-21 19:09:32.417928
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    vector = ImmutableList.of(1,2,3,4,5)
    vector = vector.filter(lambda x: True if x % 2 == 0 else False)
    assert vector.to_list() == [2,4]

# Generated at 2022-06-21 19:09:35.185967
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6

test_ImmutableList_reduce()

# Generated at 2022-06-21 19:09:38.309822
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # Arrange
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3, 4)

    # Act

    # Assert
    assert a.append(4) == b


# Generated at 2022-06-21 19:09:43.754000
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-21 19:09:53.423942
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    immutable_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert immutable_list.to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:10:01.892331
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() + ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.empty() == ImmutableList.of(1)
    assert ImmutableList.empty() + ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.of(1) == ImmutableList.of(1, 1)
    assert ImmutableList.of(1) + "a" == "aa"


# Generated at 2022-06-21 19:10:05.991737
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x is not None) == ImmutableList.empty()

    assert ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9) \
        .filter(lambda x: x % 2 == 0) == ImmutableList.of(0, 2, 4, 6, 8)

    assert ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 0) \
        .filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6, 8, 0)


# Generated at 2022-06-21 19:10:08.333044
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    """
    Testing ImmutableList method unshift
    """
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)


# Generated at 2022-06-21 19:10:21.143877
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_of_4_int = ImmutableList.of(1, 2, 3, 4)
    list_of_3_int = ImmutableList.of(2, 3, 4)
    list_of_4_strings = ImmutableList.of("a", "b", "c", "d")
    list_of_3_strings = ImmutableList.of("b", "c", "d")

    result_1 = list_of_4_int.append(5)
    result_2 = list_of_3_int.append(5)
    result_3 = list_of_4_strings.append("e")
    result_4 = list_of_3_strings.append("e")

    expected_1 = [1, 2, 3, 4, 5]

# Generated at 2022-06-21 19:10:28.449745
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of('1', '2', 'A', True, 10) + ImmutableList.of('K', 'G') == ImmutableList.of('1', '2', 'A', True, 10, 'K', 'G')
    assert ImmutableList.of('1', '2', 'A', True, 10) + ImmutableList.of('K') == ImmutableList.of('1', '2', 'A', True, 10, 'K')
    assert ImmutableList.of('1', '2', 'A', True, 10) + ImmutableList.of('7', '8', '9') == ImmutableList.of('1', '2', 'A', True, 10, '7', '8', '9')
    assert ImmutableList.of('A', True, 10) + ImmutableList.empty() == ImmutableList

# Generated at 2022-06-21 19:10:34.074007
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1, ImmutableList(is_empty=True))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2, ImmutableList(is_empty=True)))


# Generated at 2022-06-21 19:10:35.806873
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = list1.append(4)

    assert list2 == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-21 19:10:37.956977
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1).__add__(ImmutableList(2)) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-21 19:10:49.714875
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    def empty_result(
            no_value,
            true_value,
            false_value
    ):
        return ImmutableList(
            no_value,
            ImmutableList(
                true_value,
                ImmutableList(
                    false_value
                )
            )
        ).find(lambda x: x) is None

    def find_result(
            no_value,
            true_value,
            false_value
    ):
        return ImmutableList(
            no_value,
            ImmutableList(
                true_value,
                ImmutableList(
                    false_value
                )
            )
        ).find(lambda x: x) == true_value

    assert True is empty_result(
        None,
        None,
        None
    )


# Generated at 2022-06-21 19:10:58.501479
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == \
            ImmutableList.of(2, 4)

# Generated at 2022-06-21 19:11:03.312806
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()


# Generated at 2022-06-21 19:11:08.789980
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given
    is_even = lambda el: el % 2 == 0

    # When
    result = ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(is_even)

    # Then
    assert ImmutableList.of(2, 4) == result


# Generated at 2022-06-21 19:11:11.985196
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_of_ints = ImmutableList.of(1, 2, 3, 4)
    assert list_of_ints.append(5) == ImmutableList.of(1, 2, 3, 4, 5)



# Generated at 2022-06-21 19:11:17.711953
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:11:21.416977
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 6) is None
    assert ImmutableList.empty().find(lambda x: x == 1) is None



# Generated at 2022-06-21 19:11:27.222114
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty().is_empty == True, "Empty list should be empty"
    assert ImmutableList() == ImmutableList.empty(), "Empty list should be empty"
    assert ImmutableList(is_empty=True) == ImmutableList.empty(), "Empty list should be empty"
    assert ImmutableList(1) == ImmutableList(1, None)
    assert ImmutableList(1, ImmutableList(2, None)) == ImmutableList(1, ImmutableList(2, None))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, None))) == \
        ImmutableList(1, ImmutableList(2, ImmutableList(3, None)))
    assert ImmutableList.of(1) == ImmutableList(1, None)

# Generated at 2022-06-21 19:11:33.936592
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert not (ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(4, ImmutableList(3))))
    assert not (ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.empty())
    assert ImmutableList.empty() == ImmutableList.empty()

test_ImmutableList___eq__()

# Generated at 2022-06-21 19:11:36.961863
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_example = ImmutableList.of('test', 'test1', 'test2')

    assert len(list_example) == 3

# Generated at 2022-06-21 19:11:41.114698
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(5, ImmutableList(4, ImmutableList(3))) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.empty() == ImmutableList(is_empty=True)



# Generated at 2022-06-21 19:11:49.094421
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_ = ImmutableList(1, ImmutableList(2))

    list_1 = list_.map(lambda x: x + 2)

    assert list_1 == ImmutableList(3, ImmutableList(4))



# Generated at 2022-06-21 19:11:53.991751
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    assert ImmutableList.empty().filter(lambda x: x % 2 == 0).is_empty


# Generated at 2022-06-21 19:11:56.807415
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    numbers = ImmutableList.of(3,2,1)
    answer = numbers.reduce(lambda x, y: x * y, 1)
    assert answer == 6 # expected 6

# Generated at 2022-06-21 19:12:05.670786
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1, ImmutableList(is_empty=True))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(is_empty=True))) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-21 19:12:08.258717
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    input = ImmutableList.of(1, 2, 3, 4)
    output = ImmutableList.of(1, 2, 3, 4, 5)
    assert input.append(5) == output


# Generated at 2022-06-21 19:12:10.543963
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list = ImmutableList.of(1, 2, 3)
    assert list.reduce(lambda x, y: x + y, 0) == 6


# Generated at 2022-06-21 19:12:20.949799
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1) + ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)


# Generated at 2022-06-21 19:12:23.116650
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_one = ImmutableList.of(1, 2, 3)
    list_two = ImmutableList.of(1, 2, 3)
    list_three = ImmutableList.of(1, 2, 4)

    assert list_one == list_two
    assert list_one != list_three


# Generated at 2022-06-21 19:12:26.672589
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-21 19:12:33.987782
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    lst = ImmutableList.of(1, 2, 3)
    assert lst.find(lambda x: x == 1) == 1
    assert lst.find(lambda x: x == 2) == 2
    assert lst.find(lambda x: x == 3) == 3
    assert lst.find(lambda x: x == 5) is None

    lst = ImmutableList.empty()
    assert lst.find(lambda x: x == 1) is None

test_ImmutableList_find()

# Generated at 2022-06-21 19:12:43.941441
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # arrange
    expected = 'ImmutableList[1, 2]'
    # act
    actual = ImmutableList.of(1, 2).__str__()
    # assert
    assert actual == expected


# Generated at 2022-06-21 19:12:47.016634
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    print(ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x%2==0))

# Generated at 2022-06-21 19:12:50.993617
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list = ImmutableList.of(1,2,3)
    list1 = list.append(5)

    assert len(list1) == 4
    assert list1.to_list() == [1,2,3,5]


# Generated at 2022-06-21 19:12:55.716762
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(2, 3, 5).find(lambda x: x > 3) == 5
    assert ImmutableList.of(2, 3, 5).find(lambda x: x > 6) == None
    assert ImmutableList.empty().find(lambda x: True) == None


# Generated at 2022-06-21 19:13:00.377279
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(2, ImmutableList(1)).to_list() == [2, 1]
    assert ImmutableList(3, ImmutableList(2, ImmutableList(1))).to_list() == [3, 2, 1]


# Generated at 2022-06-21 19:13:04.212891
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    value = ImmutableList.empty()
    assert len(value) == 0
    value = ImmutableList.of(10)
    assert len(value) == 1
    value = ImmutableList.of(10, 20, 30)
    assert len(value) == 3



# Generated at 2022-06-21 19:13:12.488540
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Case 1
    actual = ImmutableList(1, ImmutableList(2), False) == ImmutableList(1, ImmutableList(2), False)
    expected = True
    assert actual == expected
    # Case 2
    actual = ImmutableList(1, ImmutableList(2), False) == ImmutableList(5, ImmutableList(2), False)
    expected = False
    assert actual == expected
    # Case 3
    actual = ImmutableList(1, ImmutableList(2), False) == ImmutableList(1)
    expected = False
    assert actual == expected


# Generated at 2022-06-21 19:13:16.769517
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_0 = ImmutableList.of(1)
    list_1 = ImmutableList.of(1)

    list_0_add = list_0 + list_1

    list_0_add_expected = ImmutableList.of(1, 1)

    assert list_0_add == list_0_add_expected, 'ImmutableList + should create a new ImmutableList with added element'


# Generated at 2022-06-21 19:13:23.863425
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():  # noqa; pylint: disable=missing-function-docstring
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) != ImmutableList.of(4, 5, 6)



# Generated at 2022-06-21 19:13:28.003045
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList().is_empty == True
    assert ImmutableList(3).head == 3
    assert ImmutableList(3).tail == None
    assert ImmutableList(3).is_empty == False


# Generated at 2022-06-21 19:13:38.069786
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    input_list = 'hello', 'world', 'i', 'am', 'list'
    immutable_list = ImmutableList.of(*input_list)
    assert input_list == immutable_list.to_list(), 'immutable_list.to_list() not return list'


# Generated at 2022-06-21 19:13:40.397197
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    t = ImmutableList([10])
    assert t == ImmutableList([10])
    assert t != ImmutableList([11])
    assert t != ImmutableList([10, 11])



# Generated at 2022-06-21 19:13:46.779447
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():

    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 2) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 10) == None


# Generated at 2022-06-21 19:13:51.931894
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Given
    expected_immutable_list = ImmutableList.of(1, 2, 3)

    # When
    actual_immutable_list = ImmutableList.of(1, 2, 3)

    # Then
    assert actual_immutable_list == expected_immutable_list

test_ImmutableList()



# Generated at 2022-06-21 19:13:58.153017
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList(1, 2, 3)
    list2 = ImmutableList(4, 5, 6)
    list1.__add__(list2) == ImmutableList(1, 2, 3, 4, 5, 6)

    try:
        list1.__add__('some value')
    except ValueError:
        assert True
        return True
    except:
        assert False, 'Unexpected exception'

    assert False

# Generated at 2022-06-21 19:14:05.899901
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_a = ImmutableList.of(1,2,3)
    list_b = ImmutableList.of(1,2,3)
    list_c = ImmutableList.of(1,2,3,4)
    list_d = ImmutableList.of(1,2,3,4)
    list_e = ImmutableList.of(1,2,3,4,5)

    assert list_a.append(4) == list_c
    assert list_d.append(5) == list_e
    assert list_b.append(4).append(5) == list_c.append(4)
    assert list_a.append(4).append(5) == list_e
    assert list_a == list_b
    assert list_b.append(4) == list_d
    assert list

# Generated at 2022-06-21 19:14:09.465689
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).to_list()
    assert [] == ImmutableList().to_list()
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).append(4).to_list()
    assert [4, 1, 2, 3] == ImmutableList.of(1, 2, 3).unshift(4).to_list()


# Generated at 2022-06-21 19:14:12.225126
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)



# Generated at 2022-06-21 19:14:17.488498
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-21 19:14:20.713820
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, None) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))


# Generated at 2022-06-21 19:14:41.530399
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:14:43.955735
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-21 19:14:54.026551
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) is None
    assert ImmutableList.of(123).find(lambda x: x) == 123
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2.5) is None

# Generated at 2022-06-21 19:14:58.157927
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(2) == ImmutableList.of(2, 1, 2)



# Generated at 2022-06-21 19:15:00.305035
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    obj = ImmutableList.of(1,2,3,4)
    assert obj.to_list() == [1,2,3,4]


# Generated at 2022-06-21 19:15:02.665764
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    my_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert my_list.reduce(lambda x, y: x + y, 0) == 15

# Generated at 2022-06-21 19:15:06.117803
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l = ImmutableList.of(1, 2)

    assert (l + ImmutableList.of(3)).to_list() == [1, 2, 3]

# Generated at 2022-06-21 19:15:09.423561
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list = ImmutableList(1, ImmutableList(2), False)
    list_found = ImmutableList.of(1, 2)
    assert list == list_found
test_ImmutableList()

# Generated at 2022-06-21 19:15:13.593530
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    x = ImmutableList.of(1, 2, 3)
    y = ImmutableList.of(4, 5, 6)

    assert x + y == ImmutableList.of(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-21 19:15:17.010927
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) == None
    assert ImmutableList.empty().find(lambda x: x == 4) == None



# Generated at 2022-06-21 19:15:53.570627
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList(1)
    assert ImmutableList.empty() == ImmutableList.of()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(2)
    assert ImmutableList(1,ImmutableList(2, ImmutableList(3))) == ImmutableList(1,ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1,ImmutableList(2, ImmutableList(3))) != ImmutableList(3,ImmutableList(2, ImmutableList(1)))

# Generated at 2022-06-21 19:16:03.525704
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty().__add__(ImmutableList.empty()) == ImmutableList.empty()
    assert ImmutableList.empty().__add__(ImmutableList.of(1, 2, 3)) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).__add__(ImmutableList.empty()) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).__add__(ImmutableList.of(4, 5, 6)) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1).__add__(ImmutableList.of(2, 3, 4)) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList

# Generated at 2022-06-21 19:16:06.502582
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of(1, 2)


# Generated at 2022-06-21 19:16:15.751811
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of(1, 2, 3).append(4)) == 'ImmutableList[1, 2, 3, 4]'
    assert str(ImmutableList.of(1, 2, 3).append(4).unshift(0)) == 'ImmutableList[0, 1, 2, 3, 4]'
    assert str(ImmutableList.of(1, 2, 3).unshift(0).unshift(-1)) == 'ImmutableList[-1, 0, 1, 2, 3]'


# Generated at 2022-06-21 19:16:19.030615
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.empty().to_list() == []



# Generated at 2022-06-21 19:16:22.758295
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3)
    result = list1 == list2

    assert result == True, 'ImmutableList: method __eq__ does not work correctly.'


# Generated at 2022-06-21 19:16:25.848020
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-21 19:16:28.832844
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    result = ImmutableList.of(1).append(2)

    assert isinstance(result, ImmutableList)
    assert result == ImmutableList.of(1, 2)


# Generated at 2022-06-21 19:16:36.767291
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # test 1
    assert ImmutableList.of(1, 2, 3, 4, 5)\
        .filter(lambda x: x % 2 == 0)\
        .to_list() == [2, 4]

    # test 2
    assert ImmutableList.of("foo", "bar", "baz", "buzz")\
        .filter(lambda x: x[0] == "b")\
        .to_list() == ["bar", "baz", "buzz"]

    # test 3
    assert ImmutableList.of("foo", "bar", "baz", "buzz")\
        .filter(lambda x: x[0] == "a")\
        .to_list() == []


    # test 4
    assert ImmutableList.of("foo", "bar", "baz", "buzz", "b")

# Generated at 2022-06-21 19:16:39.566457
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
	test_list = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
	assert test_list.to_list() == [1, 2, 3]
