

# Generated at 2022-06-21 19:07:44.173289
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    alist = ImmutableList.of(1, 2, 3)
    another_alist = ImmutableList.of(4, 5, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6) == alist.__add__(another_alist)


# Generated at 2022-06-21 19:07:50.991596
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ptr = ImmutableList.of(3, 4, 5, 10)
    ptr = ptr.append(3)
    ptr = ptr.append(2)
    ptr = ptr.unshift(1)
    assert [1, 3, 4, 5, 10, 3, 2] == ptr.to_list()

    # when
    result = ptr.find(lambda x: x == 10)

    # then
    assert result == 10


# Generated at 2022-06-21 19:07:59.956960
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))) \
        .filter(lambda x: x % 2 != 0) == ImmutableList(1, ImmutableList(3, ImmutableList(5)))
    assert ImmutableList().filter(lambda x: x) is ImmutableList.empty()

# Generated at 2022-06-21 19:08:03.013271
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]


# Generated at 2022-06-21 19:08:14.171263
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert (
        ImmutableList.of(1, 2, 3).filter(lambda elem: elem > 1)
        == ImmutableList.of(2, 3)
    )
    assert (
        ImmutableList.of(1, 2, 3).filter(lambda elem: elem == 2)
        == ImmutableList.of(2)
    )
    assert (
        ImmutableList.of(1, 2, 3).filter(lambda elem: elem < 1)
        == ImmutableList.empty()
    )



# Generated at 2022-06-21 19:08:19.181632
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 3, 5, 7).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)



# Generated at 2022-06-21 19:08:23.947225
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # create instance of class ImmutableList
    list1 = ImmutableList.of(1, 2, 3)

    # create new instance by calling unshift method and passing element
    list2 = list1.unshift(0)

    # check if the result is correct
    assert list1 == ImmutableList.of(1, 2, 3)
    assert list2 == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-21 19:08:35.480745
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.empty() + ImmutableList.of(4, 5, 6) == ImmutableList.of(4, 5, 6)
    assert ImmutableList.of(4, 5, 6) + ImmutableList.empty() == ImmutableList.of(4, 5, 6)

    # assert ImmutableList.of(4, 5, 6) + ImmutableList.of(4, 5, 6)
    # == ImmutableList.of(4, 5, 6, 4, 5, 6)

    # with pytest.raises(ValueError):
    #     ImmutableList.of(1, 2, 3) + 2


# Unit test

# Generated at 2022-06-21 19:08:45.535490
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Preparing test tools
    count = 0
    def filter_fn(value):
        nonlocal count
        count += 1
        return value < 4

    # Simple check reducer
    def reducer_fn(acc, value):
        return acc + value

    # Sample data
    sample_data = ImmutableList.of(1,2,3,4,5,6,7)

    # Calculating result
    result = sample_data.filter(filter_fn)

    # Checking result
    assert count == 7
    assert result.to_list() == [1,2,3]
    assert result.reduce(reducer_fn, 0) == 6
    assert sample_data.to_list() == [1,2,3,4,5,6,7]
test_ImmutableList_filter()

# Generated at 2022-06-21 19:08:57.753408
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of('string', 1, 'other string') == ImmutableList.of('string', 1, 'other string')
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList('string') == ImmutableList('string')
    
    assert ImmutableList.of('string', 1, 'other string') != ImmutableList.of('string', 1, 'other string', 'other string2')
    assert ImmutableList.empty() != ImmutableList('string')
    assert ImmutableList('string') != ImmutableList.empty()
    
    assert ImmutableList.of('string', 1, 'other string') != ImmutableList('string')
    assert ImmutableList.empty() != ImmutableList.empty()
    assert ImmutableList('string') != ImmutableList.of('string')
    

# Generated at 2022-06-21 19:09:13.588260
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Arrange
    l1 = ImmutableList.of(1, 2, 3, 4)
    l3 = ImmutableList.empty()

    # Act
    l1_len = len(l1)
    l3_len = len(l3)

    # Assert
    assert l1_len == 4
    assert l3_len == 0


# Generated at 2022-06-21 19:09:18.639407
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(2) == ImmutableList(2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-21 19:09:22.676026
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)



# Generated at 2022-06-21 19:09:27.121897
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList(1).map(lambda x: x * 2) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x * 2) == ImmutableList(2, ImmutableList(4))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).map(lambda x: x * 2) == ImmutableList(2, ImmutableList(4, ImmutableList(6)))

# Generated at 2022-06-21 19:09:31.271932
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1) ) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3


# Generated at 2022-06-21 19:09:38.993648
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_a = ImmutableList.of(1)
    list_b = list_a.append(2)
    list_c = list_b.append(3)
    list_d = list_a + list_c

    assert list_d.head == 1
    assert list_d.tail.head == 2
    assert list_d.tail.tail.head == 3

    assert list_d == ImmutableList.of(1, 2, 3)

    assert list_a + list_a == ImmutableList.of(1, 1)
    assert list_a + list_b + list_c != ImmutableList.of(1, 2, 3)


# Generated at 2022-06-21 19:09:41.929532
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    x = ImmutableList()
    assert isinstance(x, ImmutableList)



# Generated at 2022-06-21 19:09:45.547371
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(is_empty=True).to_list() == []



# Generated at 2022-06-21 19:09:50.548521
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    l = ImmutableList.of(1, 2, 3, 4)
    expected = ImmutableList.of(2, 3, 4, 5)

    assert l.map(lambda x: x + 1) == expected


# Generated at 2022-06-21 19:09:54.692484
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)
    assert ImmutableList.of(1).filter(lambda x: x > 2) == ImmutableList.of()



# Generated at 2022-06-21 19:10:26.348367
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    '''
    Test case can be run with:
    python3 -m unittest TestImmutableList.py
    '''
    import unittest

    class ImmutableListTest(unittest.TestCase):

        def setUp(self):
            pass

        def test_constructor(self):
            self.assertEqual(
                ImmutableList(1, ImmutableList(2, ImmutableList(3))),
                ImmutableList.of(1, 2, 3)
            )

            self.assertEqual(
                ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))),
                ImmutableList.of(1, 2, 3, 4, 5)
            )


# Generated at 2022-06-21 19:10:28.921631
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x > 10) == ImmutableList.empty()

# Generated at 2022-06-21 19:10:37.450616
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(
        1
    ) == ImmutableList.of(1)

    assert ImmutableList.of(
        2
    ).unshift(
        1
    ) == ImmutableList.of(1, 2)

    assert ImmutableList.of(
        2, 3
    ).unshift(
        1
    ) == ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(
        2, 3, 4
    ).unshift(
        1
    ) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-21 19:10:49.150971
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Test with empty ImmutableList
    m = ImmutableList()
    assert m == ImmutableList(is_empty=True)
    assert m == ImmutableList()
    # Test with one element ImmutableList
    m = ImmutableList(1)
    assert m == ImmutableList(1)
    assert m.__eq__(1) is False
    # Test with 2 element ImmutableList
    m = ImmutableList(1, ImmutableList(2))
    assert m == ImmutableList(1, ImmutableList(2))
    assert m.__eq__(ImmutableList(2, ImmutableList(1))) is False
    assert m.__eq__(ImmutableList(1, ImmutableList(3))) is False
    assert m.__eq__(ImmutableList(1, ImmutableList())) is False
    assert m

# Generated at 2022-06-21 19:10:54.674827
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(0, ImmutableList(1, ImmutableList(2)))) == 'ImmutableList[0, 1, 2]'
    assert str(ImmutableList(0, ImmutableList(1, ImmutableList(2, ImmutableList(3))))) == 'ImmutableList[0, 1, 2, 3]'


# Generated at 2022-06-21 19:10:57.367319
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x == 2) is None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x > 5) is None


# Generated at 2022-06-21 19:11:07.658267
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert len(ImmutableList.of(1, 2, 3) + ImmutableList.of(1, 2, 3)) == 6
    assert len(ImmutableList.of(1, 2, 3) + ImmutableList.of(1, 2, 3) + ImmutableList.of(1, 2, 3) + ImmutableList.of(1, 2, 3)) == 12
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, None))))))



# Generated at 2022-06-21 19:11:15.066659
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5)
    assert ImmutableList.of().map(lambda x: x + 1) == ImmutableList.of()
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: str(x)) == ImmutableList.of('1', '2', '3', '4')
    assert ImmutableList.of('1', '2', '3', '4').map(lambda x: int(x)) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-21 19:11:17.449525
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    a = ImmutableList.of(1, 2)
    assert a.to_list() == [1, 2]

# Generated at 2022-06-21 19:11:24.366607
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x%2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 3, 4).filter(lambda x: x%2 == 0) == ImmutableList.of(2, 4)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x%2 == 1) == ImmutableList.of(1, 3)
    assert ImmutableList.of(1).filter(lambda x: x%2 == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1).filter(lambda x: x%2 == 0) == ImmutableList.empty()

# Generated at 2022-06-21 19:11:41.700334
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1).reduce(lambda a, b: a + b, 0) == 1
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda a, b: a + b, 0) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda a, b: a + b, 0) == 6

    assert ImmutableList(1).reduce(lambda a, b: a * b, 1) == 1
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda a, b: a * b, 1) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda a, b: a * b, 1) == 6


# Generated at 2022-06-21 19:11:47.764451
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList(
        1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))



# Generated at 2022-06-21 19:11:55.540601
# Unit test for constructor of class ImmutableList
def test_ImmutableList():

    # Test initialization of empty list
    assert ImmutableList(is_empty=True) == ImmutableList.empty()

    # Assert creating instance of class with one argument
    assert ImmutableList(42).to_list() == [42]

    # Assert creating instance of class with few arguments
    assert ImmutableList.of(31, 666).to_list() == [31, 666]

    # Assert creating instance of class ImmutableList from python list
    assert ImmutableList.of(*(range(100)))
# Test for method ImmutableList.append

# Generated at 2022-06-21 19:12:02.222489
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_2 = list_1.append(4)

    assert list_1.to_list() == [1, 2, 3]
    assert list_2.to_list() == [1, 2, 3, 4]


# Generated at 2022-06-21 19:12:06.165667
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(0) == ImmutableList(0)
    assert ImmutableList.of(0, 1).append(2) == ImmutableList(0, ImmutableList(1, ImmutableList(2)))


# Generated at 2022-06-21 19:12:15.309407
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 1) == ImmutableList.of(1, 1)
    assert ImmutableList.of(1, 1) != ImmutableList.of(1)
    assert ImmutableList.of(1, 1, 1) == ImmutableList.of(1, 1, 1)
    assert ImmutableList.of(1, 1, 1) != ImmutableList.of(1, 1)
    assert ImmutableList.of(1, 1, 1) != ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList.empty()


# Generated at 2022-06-21 19:12:23.329651
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(2).filter(lambda i: i == 2) == ImmutableList(2)
    assert ImmutableList(
        2,
        ImmutableList(4))\
        .filter(lambda i: i != 2) == ImmutableList(4)

    assert ImmutableList(
        2,
        ImmutableList(3, ImmutableList(4, ImmutableList(5))))\
        .filter(lambda i: i % 2 == 0) == ImmutableList(2, ImmutableList(4))
    
    assert ImmutableList(
        2,
        ImmutableList(3, ImmutableList(4, ImmutableList(5))))\
        .filter(lambda i: i % 2 == 1) == ImmutableList(3, ImmutableList(5))


# Generated at 2022-06-21 19:12:34.652203
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Test casting str list to int list
    assert ImmutableList.of(1, 2, 3).map(int) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1.0, 2.0, 3.0).map(lambda x: int(x)) == ImmutableList.of(1, 2, 3)

    # Test casting str list to float list
    assert ImmutableList.of(1, 2, 3).map(float) == ImmutableList.of(1.0, 2.0, 3.0)
    assert ImmutableList.of(1.0, 2.0, 3.0).map(lambda x: float(x)) == ImmutableList.of(1.0, 2.0, 3.0)

    # Test casting list to list of strs

# Generated at 2022-06-21 19:12:38.701223
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.__str__() == 'ImmutableList[1, 2, 3, 4, 5]'



# Generated at 2022-06-21 19:12:43.888631
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_ints = ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8)

    actual = list_of_ints.filter(lambda x: True if x % 2 == 0 else False)

    expected = ImmutableList.of(0, 2, 4, 6, 8)

    assert actual == expected



# Generated at 2022-06-21 19:13:02.461558
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    xs = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert xs.reduce(lambda x, y: x + y, 0) == 6
    assert xs.reduce(lambda x, y: x + y, 1) == 7

    # check if works with empty list
    empty = ImmutableList.empty()
    assert empty.reduce(lambda x, y: x + y, 0) == 0
    assert empty.reduce(lambda x, y: x + y, 1) == 1


# Generated at 2022-06-21 19:13:13.510243
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Testing filter method of ImmutableList class
    """
    def positive(x: int) -> bool:
        return x % 2 == 0

    def negative(x: int) -> bool:
        return not positive(x)

    def is_5(x: int) -> bool:
        return x == 5

    empty = ImmutableList.empty()
    assert empty.filter(positive) == empty
    assert empty.filter(negative) == empty
    assert empty.filter(is_5) == empty

    simple_list = ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert simple_list.filter(positive) == ImmutableList.of(2, 4, 6)
    assert simple_list.filter(negative) == ImmutableList.of(1, 3, 5)

# Generated at 2022-06-21 19:13:16.999381
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x + 2) == ImmutableList()
    assert ImmutableList(1).map(lambda x: x + 2) == ImmutableList(1)
    assert ImmutableList(1, 2, 3).map(lambda x: x + 2) == ImmutableList(3, 4, 5)



# Generated at 2022-06-21 19:13:18.551496
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3, 4).unshift(0) == ImmutableList.of(0, 1, 2, 3, 4)
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)

# Generated at 2022-06-21 19:13:23.288536
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:13:34.324758
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    """
    Function that construct some instances of ImmutableList
    and compare them with expected ImmutableList

    :returns: nothing
    """
    print('should construct ImmutableList with elements')
    actual = ImmutableList.of(1, 2, 3)
    expected1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert actual == expected1
    expected2 = ImmutableList(1, ImmutableList(2, ImmutableList(3, is_empty=False)))
    assert actual == expected2
    print('should construct empty ImmutableList')
    actual = ImmutableList.empty()
    expected = ImmutableList(is_empty=True)
    assert actual == expected


# Unit tests for instance method append

# Generated at 2022-06-21 19:13:39.372129
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of("a", "b", "c").to_list() == ["a", "b", "c"]
    assert ImmutableList.of("a", "b", "c", 1, 2, 3).to_list() == ["a", "b", "c", 1, 2, 3]


# Generated at 2022-06-21 19:13:43.862232
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():

    # Arrange
    immutable_list_1 = ImmutableList.of(1, 2, 3, 4)
    immutable_list_2 = ImmutableList.of(5, 6, 7)

    # Act
    result = immutable_list_1 + immutable_list_2

    # Assert
    assert result == ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert result != ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert isinstance(result, ImmutableList)

    try:
        result_2 = immutable_list_1 + 2
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-21 19:13:47.066836
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(1) == ImmutableList.of(1, 1)
    assert ImmutableList.of(1, 2, 3).unshift(1) == ImmutableList.of(1, 1, 2, 3)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)



# Generated at 2022-06-21 19:13:53.669860
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList.of(1)

    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)

    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-21 19:14:25.749494
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2).__add__(ImmutableList.of(3, 4)) == ImmutableList.of(1, 2, 3, 4)
    
    assert ImmutableList.of(1, 2).__add__(ImmutableList.of(3)) == ImmutableList.of(1, 2, 3)
    
    assert ImmutableList.of(1, 2).__add__(ImmutableList.of(3).__add__(ImmutableList.of(4))) == ImmutableList.of(1, 2, 3, 4)
    
    assert ImmutableList.of(1, 2).__add__(ImmutableList.empty()) == ImmutableList.of(1, 2)
    
    assert ImmutableList.empty().__add__(ImmutableList.of(1, 2)) == Immutable

# Generated at 2022-06-21 19:14:32.144797
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    empty_list = ImmutableList.empty()
    assert len(empty_list) == 0

    list_with_one_element = ImmutableList(1)
    assert len(list_with_one_element) == 1

    list_with_five_elements = ImmutableList.of(1, 2, 3, 4, 5)
    assert len(list_with_five_elements) == 5

test_ImmutableList___len__()


# Generated at 2022-06-21 19:14:34.726634
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1).head == 1
    assert ImmutableList(1).tail is None
    assert ImmutableList(1, ImmutableList()).head == 1
    assert ImmutableList(1, ImmutableList()).tail.head is None
    assert ImmutableList(1, ImmutableList(2)).tail.head == 2


# Generated at 2022-06-21 19:14:36.298717
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    il = ImmutableList.of(1, 2, 3)
    filtered = il.filter(lambda x: x % 2 == 0)
    assert filtered == ImmutableList.of(2)

# Generated at 2022-06-21 19:14:41.231779
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.empty().to_list() == []


# Generated at 2022-06-21 19:14:50.985902
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4)

    assert ImmutableList.of(2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

    assert ImmutableList.of(1, 3).filter(lambda x: x % 2 == 0) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

    assert ImmutableList.empty().filter(lambda x: x % 2 == 0) == ImmutableList.empty()

# Generated at 2022-06-21 19:14:56.132361
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.empty() != ImmutableList(1)
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))

# Generated at 2022-06-21 19:15:03.997482
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, 2) == ImmutableList(1, 2)
    assert ImmutableList(1, 2, 3) == ImmutableList(1, 2, 3)
    assert ImmutableList(1, 2, 3, 4) == ImmutableList(1, 2, 3, 4)
    assert ImmutableList(1, 2, 3, 4, 5) == ImmutableList(1, 2, 3, 4, 5)

    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1, 2) != ImmutableList(2, 3)
    assert ImmutableList(1, 2, 3) != ImmutableList(2, 3, 4)

# Generated at 2022-06-21 19:15:08.995116
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Arrange
    print('test_ImmutableList')
    expected_result = [1, 2, 3, 4]

    # Act
    actual_result = ImmutableList.of(1, 2, 3, 4).to_list()

    # Assert
    assert expected_result == actual_result

# Generated at 2022-06-21 19:15:12.292905
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    actual = ImmutableList(1).append(2)
    expected = ImmutableList(1, ImmutableList(2))
    assert actual == expected



# Generated at 2022-06-21 19:16:11.806438
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 2) == ImmutableList.of(1)

    assert ImmutableList.empty().filter(lambda x: x < 2) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 4) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 4) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-21 19:16:14.156742
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0

    assert len(ImmutableList.of('test')) == 1
    assert len(ImmutableList.of('test', '123')) == 2
    assert len(ImmutableList.of('test', '123', 'booooooomb')) == 3


# Generated at 2022-06-21 19:16:19.536984
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    """
    :returns: None
    """
    lst = ImmutableList.of(1)
    assert len(lst) == 1, 'ImmutableList: lenght of ImmutableList should be 1'

    lst = ImmutableList.of(1, 2, 3)
    assert len(lst) == 3, 'ImmutableList: lenght of ImmutableList should be 3'

    lst = ImmutableList.of()
    assert len(lst) == 0, 'ImmutableList: lenght of ImmutableList should be 0'


test_ImmutableList___len__()



# Generated at 2022-06-21 19:16:24.999724
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(4, 2, 5, 3).find(lambda x: x == 4) == 4
    assert ImmutableList.of(4, 2, 5, 3, 4).find(lambda x: x == 4) == 4
    assert ImmutableList.of().find(lambda x: x == 4) is None

# Generated at 2022-06-21 19:16:28.302614
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_ = ImmutableList.of(1, 2, 3)
    list_ = list_.map(lambda x: x ** 2)

    expected = ImmutableList.of(1, 4, 9)
    assert list_ == expected

# Generated at 2022-06-21 19:16:36.413682
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert (ImmutableList(1, ImmutableList(2))) == ImmutableList(1, ImmutableList(2))
    assert (ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))

# Generated at 2022-06-21 19:16:42.381355
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of(1, ImmutableList.of(2, 3), 4)) == 'ImmutableList[1, ImmutableList[2, 3], 4]'



# Generated at 2022-06-21 19:16:52.252710
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty().__add__(ImmutableList.of(1, 2, 3)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).__add__(ImmutableList.empty()) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).__add__(ImmutableList.of(4, 5, 6)) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))
    assert ImmutableList.empty().__add__(ImmutableList.empty()) == ImmutableList(is_empty=True)

# Generated at 2022-06-21 19:16:54.934799
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList() == ImmutableList()

# Generated at 2022-06-21 19:16:59.321664
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1).append(2).to_list() == [1, 2]
    assert ImmutableList.empty().append(1).to_list() == [1]
