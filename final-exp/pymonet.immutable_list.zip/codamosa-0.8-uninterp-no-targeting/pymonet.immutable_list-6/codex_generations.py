

# Generated at 2022-06-21 19:07:41.487814
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4)
    assert list.find(lambda x: x < 3) == 1
    assert list.find(lambda x: x > 3) == 4
    assert list.find(lambda x: x == 3) == 3



# Generated at 2022-06-21 19:07:45.987915
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 10

# Generated at 2022-06-21 19:07:55.127747
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert list(ImmutableList(1).map(lambda v: v + 1)) == [2]
    assert list(ImmutableList(1, ImmutableList(2)).map(lambda v: v * 2)) == [2, 4]
    assert list(ImmutableList(1, ImmutableList(2)).map(lambda v: [])) == []
    assert list(ImmutableList(1, ImmutableList(2)).map(lambda v: [v])) == [[1], [2]]
    assert list(ImmutableList(1, ImmutableList(2)).map(lambda v: int(str(v) + '1'))) == [11, 21]



# Generated at 2022-06-21 19:07:58.639182
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_1 = ImmutableList.of('a', 'b', 'c')

    assert list_1.append('d') == ImmutableList.of('a', 'b', 'c', 'd')



# Generated at 2022-06-21 19:08:00.384921
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(is_empty=True))))


# Generated at 2022-06-21 19:08:05.741374
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    my_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert my_list.find(lambda x: x == 0) is None
    assert my_list.find(lambda x: x == 2) == 2
    assert my_list.find(lambda x: x == 5) == 5
    assert my_list.find(lambda x: x > 5) is None
    assert my_list.find(lambda x: x < 1) is None


# Generated at 2022-06-21 19:08:14.762284
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_to_filter = ImmutableList.of(1, 2, 3, 4, 5)

    assert list_to_filter.filter(
        lambda x: x % 2 == 0
    ).to_list() == [2, 4]

    assert list_to_filter.filter(
        lambda x: x == 3
    ).to_list() == [3]

    assert list_to_filter.filter(
        lambda x: x == 11
    ).to_list() == []


# Generated at 2022-06-21 19:08:24.669674
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(4, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(5, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2, ImmutableList(6)))

# Generated at 2022-06-21 19:08:28.840828
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1).append(2)) == 'ImmutableList[1, 2]'
# Method `append` test for class ImmutableList

# Generated at 2022-06-21 19:08:33.439506
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    a = ImmutableList.of(1, 2)
    b = a.unshift(0)
    
    assert a.to_list() == [1, 2]
    assert b.to_list() == [0, 1, 2]



# Generated at 2022-06-21 19:08:45.280698
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

# Generated at 2022-06-21 19:08:51.397570
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_of_ints = ImmutableList.of(1, 2, 3, 4, 5, 6)
    list_of_strings = ImmutableList.of('a', 'b', 'c')

    assert list_of_ints.find(lambda a: a > 3) == 4
    assert list_of_strings.find(lambda a: a == 'a') == 'a'
    


# Generated at 2022-06-21 19:08:58.498199
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.of(2, 3, 1).filter(lambda x: x != 2) == ImmutableList.of(3, 1)
    assert ImmutableList.empty().filter(lambda x: x != 1) == ImmutableList.empty()

# Generated at 2022-06-21 19:09:04.010625
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda _: 1) == ImmutableList(is_empty=True)
    assert ImmutableList(1).map(lambda x: x + 1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x + 1) == ImmutableList(2, ImmutableList(3))

# Generated at 2022-06-21 19:09:10.239365
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1) + ImmutableList.of(1) == ImmutableList.of(1, 1)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)

# Generated at 2022-06-21 19:09:14.237063
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3) == ImmutableList(
        1,
        ImmutableList(
            2,
            ImmutableList(
                3,
                None
            )
        )
    )

    assert ImmutableList.empty() == ImmutableList(is_empty=True)

test_ImmutableList()

# Generated at 2022-06-21 19:09:17.817607
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of('a')) == "ImmutableList['a']"
    assert str(ImmutableList.of(1, 2, 3)) == "ImmutableList[1, 2, 3]"

# Generated at 2022-06-21 19:09:20.146448
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda _: True) == ImmutableList.empty()



# Generated at 2022-06-21 19:09:22.896329
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(5, ImmutableList(2, ImmutableList(3)))) == 3

# Generated at 2022-06-21 19:09:25.060522
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert immutable_list.reduce(lambda x, y: x + y, 0) == 15

# Generated at 2022-06-21 19:09:44.913024
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    lst = ImmutableList.of('a')
    assert lst.to_list() == ['a']

    lst = ImmutableList.of('a', 'b')
    assert lst.to_list() == ['a', 'b']

    lst = ImmutableList.empty()
    assert lst.to_list() == []

# Generated at 2022-06-21 19:09:52.709343
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(2, 3, 4).map(lambda x: x + 1) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.empty().map(lambda x: x + 1) == ImmutableList.empty()
    assert ImmutableList.of('a', 'b', 'c').map(lambda x: x.upper()) == ImmutableList.of('A', 'B', 'C')



# Generated at 2022-06-21 19:09:55.485185
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    list_ = ImmutableList(1)

    # When
    result = list_.to_list()

    # Then
    assert result == [1]


# Generated at 2022-06-21 19:10:00.413661
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    test_cases = [{
        'length': 0,
        'values': []
    }, {
        'length': 1,
        'values': [1]
    }, {
        'length': 3,
        'values': [1, 2, 3]
    }]

    for test_case in test_cases:
        assert len(ImmutableList.of(*test_case['values'])) == test_case['length']

# Generated at 2022-06-21 19:10:03.023267
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList().map(lambda x: x + 1) == ImmutableList(is_empty=True)
    assert ImmutableList(1, 2, 3).map(lambda x: x + 1) == ImmutableList(2, 3, 4)


# Generated at 2022-06-21 19:10:08.803922
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(4).__add__(ImmutableList(5)) == ImmutableList(4, ImmutableList(5))
    assert ImmutableList(4).__add__(ImmutableList(5, ImmutableList(3))) == ImmutableList(4, ImmutableList(5, ImmutableList(3)))
    assert ImmutableList(4, ImmutableList(3)).__add__(ImmutableList(5, ImmutableList(4))) == ImmutableList(4, ImmutableList(3, ImmutableList(5, ImmutableList(4))))

# Generated at 2022-06-21 19:10:16.828512
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_0 = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_0.to_list() == [1, 2, 3, 4, 5]

    list_1 = ImmutableList.of(1)
    assert list_1.to_list() == [1]

    list_2 = ImmutableList.empty()
    assert list_2.to_list() == []

# Generated at 2022-06-21 19:10:21.838466
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList(1, is_empty=False)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList.of(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:10:24.048766
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    expected = ImmutableList('a', ImmutableList('b', ImmutableList('c')))
    actual = ImmutableList('a', ImmutableList('b')).__add__(ImmutableList('c'))
    assert actual == expected



# Generated at 2022-06-21 19:10:30.595129
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2).filter(lambda x: x == 2) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).filter(lambda x: x == 1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2).filter(lambda x: x == 3) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: x == 3) == ImmutableList.empty()


# Generated at 2022-06-21 19:11:09.074502
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == "ImmutableList[]"
    assert str(ImmutableList.of(1)) == "ImmutableList[1]"
    assert str(ImmutableList.of(1, 2)) == "ImmutableList[1, 2]"


# Generated at 2022-06-21 19:11:12.407864
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    il = ImmutableList.of(1, 2, 3)
    il2 = il.append(4)
    assert (il + ImmutableList(4)) == il2 
    assert il2.tail.tail.tail.tail.head == 4


# Generated at 2022-06-21 19:11:19.630332
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3) != None
    assert ImmutableList.of(1, 2, 3) != 123
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() != ImmutableList.of(1, 2, 3)



# Generated at 2022-06-21 19:11:23.427139
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list = ImmutableList.of(1, 2, 3)
    assert len(list) == 3

    empty_list = ImmutableList.empty()
    assert len(empty_list) == 0



# Generated at 2022-06-21 19:11:33.719921
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(2, ImmutableList(1)).filter(lambda x: x != 1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x != 1) == ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)).filter(lambda x: x != 2) == ImmutableList(1)
    assert ImmutableList(2, ImmutableList(1, ImmutableList(2))).filter(lambda x: x != 2) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))).filter(lambda x: x % 2 == 0) == ImmutableList(2, ImmutableList(4))

# Generated at 2022-06-21 19:11:37.319893
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Given
    list1 = ImmutableList.of("value1", "value2")
    list2 = ImmutableList.of("value3", "value4")

    # When
    list3 = list1 + list2

    # Then
    assert list3 == ImmutableList.of("value1", "value2", "value3", "value4")


# Generated at 2022-06-21 19:11:44.720624
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 5) == ImmutableList.of(5, 10, 15)
    assert ImmutableList.of('A', 'B', 'C').map(lambda x: x.lower()) == ImmutableList.of('a', 'b', 'c')



# Generated at 2022-06-21 19:11:46.099377
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    l = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert l.to_list() == [1, 2, 3]

# Generated at 2022-06-21 19:11:49.704659
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]



# Generated at 2022-06-21 19:11:54.818632
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    def fn(x: int) -> int:
        return x + 1

    lst = ImmutableList.of(1, 2, 3, 4)

    assert lst.map(fn) == ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))

# Generated at 2022-06-21 19:13:06.899596
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:13:10.218326
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))



# Generated at 2022-06-21 19:13:14.268761
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)

test_ImmutableList_unshift()

# Generated at 2022-06-21 19:13:18.681629
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():  # pragma: no cover
    test_list = ImmutableList.of(2, 3, 4)
    mapped_list = test_list.map(lambda a: a * 2)
    assert mapped_list.__eq__(ImmutableList.of(4, 6, 8))

# Generated at 2022-06-21 19:13:24.303912
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc + x, 0) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc * x, 1) == 6
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc + x, 10) == 16
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc + x, "") == "123"

# Generated at 2022-06-21 19:13:29.009324
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)

    list_filtered = list_.filter(lambda num: num % 2 == 0)

    assert list_filtered == ImmutableList.of(2, 4)



# Generated at 2022-06-21 19:13:39.118974
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x*x) == ImmutableList.of(1), 'map should transform element of list'
    assert ImmutableList.of(1,2,3).map(lambda x: x*x) == ImmutableList.of(1,4,9), 'map should transform all elements of list'
    assert ImmutableList.of(1,2,3).map(lambda x: x).map(lambda x: x+1) == ImmutableList.of(2,3,4), 'map should transform all elements of list'

# Generated at 2022-06-21 19:13:46.376998
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(3, 4).unshift(2) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(5, 6, 7).unshift(4) == ImmutableList.of(4, 5, 6, 7)
    assert ImmutableList.empty().unshift(5) == ImmutableList.of(5)



# Generated at 2022-06-21 19:13:55.982392
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    sample_1 = ImmutableList(None)

    assert sample_1.map(lambda x: 2 + x) == ImmutableList(None)
    assert sample_1.map(lambda x: x + 2) == ImmutableList(None)

    sample_2 = ImmutableList(0)

    assert sample_2.map(lambda x: 2 + x) == ImmutableList(2)
    assert sample_2.map(lambda x: x + 2) == ImmutableList(2)

    sample_3 = ImmutableList.of(0, 1, 2)

    assert sample_3.map(lambda x: x * 2) == ImmutableList(0, 2, 4)
    assert sample_3.map(lambda x: x + 2) == ImmutableList(2, 3, 4)

# Generated at 2022-06-21 19:14:00.463309
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList.of(1).unshift(2) == ImmutableList(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList(3, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList(4, 1, 2, 3)


# Generated at 2022-06-21 19:16:34.887579
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1).reduce(lambda acc, value: acc + value, 0) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda acc, value: acc + value, 0) == 6
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda acc, value: acc + value, 1) == 7
# unit test for method of class ImmutableList

# Generated at 2022-06-21 19:16:36.724599
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda acc, x: acc + x, 0) == 6

test_ImmutableList_reduce()

# Generated at 2022-06-21 19:16:38.803917
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]



# Generated at 2022-06-21 19:16:43.167409
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # GIVEN
    list = ImmutableList.of(1, 2, 3, 4, 5)

    # WHEN
    result = list.reduce(lambda acc, x: acc + x, 0)

    # THEN
    assert result == 15



# Generated at 2022-06-21 19:16:47.387669
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList().is_empty
    assert ImmutableList('head').head == 'head'
    assert ImmutableList('head', ImmutableList('tail')).tail.head == 'tail'
    assert ImmutableList().is_empty
    assert ImmutableList(is_empty=True).is_empty


# Generated at 2022-06-21 19:16:55.384897
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Initialise object
    obj = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6, ImmutableList(7, ImmutableList(8, ImmutableList(9, ImmutableList(10))))))))))
    
    # Call method filter of object
    res = obj.filter(lambda x: x % 2 == 0)

    # Assert that res equals expected value
    assert res == ImmutableList(2, ImmutableList(4, ImmutableList(6, ImmutableList(8, ImmutableList(10)))))
    
    # Return assertion
    return "test_ImmutableList_filter -> ok"


# Generated at 2022-06-21 19:16:59.761746
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList('a')) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3

# Generated at 2022-06-21 19:17:03.735850
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(2).append(3) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList.of(2).append(3).append(4) == ImmutableList(2, ImmutableList(3, ImmutableList(4)))


# Generated at 2022-06-21 19:17:09.801529
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList(1).reduce(lambda a, b: a + b, 0) == 1
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda a, b: a + b, 0) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda a, b: a + b, 0) == 6
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))).reduce(lambda a, b: a + b, 0) == 10

# Generated at 2022-06-21 19:17:12.289151
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2).to_list() == [2, 1]
    assert ImmutableList.of(1, 2, 3).unshift(0).to_list() == [0, 1, 2, 3]