

# Generated at 2022-06-21 19:07:44.617513
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # empty list is equal to empty list
    assert ImmutableList.empty() == ImmutableList.empty()

    # list is not equal to any other instance
    assert not ImmutableList.empty() == ImmutableList(1)

    # empty list is not equal with not empty list
    assert not ImmutableList.empty() == ImmutableList(1)

    # no empty list is not equal with empty list
    assert not ImmutableList(1) == ImmutableList.empty()

    # empty list is not equal with not empty list
    assert not ImmutableList() == ImmutableList(1)

    # not empty list is not equal with empty list
    assert not ImmutableList(1) == ImmutableList()

    # list is equal to itself

# Generated at 2022-06-21 19:07:47.492358
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    actual = ImmutableList.of(1, 2, 3)
    expected = "ImmutableList[1, 2, 3]"
    assert actual.__str__() == expected


# Generated at 2022-06-21 19:07:50.401745
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_instance = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_instance.filter(lambda x: x > 4).to_list() == [5]


# Generated at 2022-06-21 19:08:01.212721
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(2)

    assert list1.unshift(2) == list2.unshift(1)

    list3 = ImmutableList.of(1, 2, 3, 4)
    list4 = ImmutableList.of(9, 10, 11, 12)

    assert list3.unshift(0) == ImmutableList.of(0, 1, 2, 3, 4)
    assert list3.unshift(0, 12, 13) == ImmutableList.of(0, 12, 13, 1, 2, 3, 4)
    assert list3.unshift(0, *list4.to_list()) == ImmutableList.of(0, 9, 10, 11, 12, 1, 2, 3, 4)

    list5 = ImmutableList

# Generated at 2022-06-21 19:08:04.749374
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    from hamcrest import equal_to, assert_that
    assert_that(
        ImmutableList.of(1, 2, 3).append(10),
        equal_to(ImmutableList.of(1, 2, 3, 10))
    )



# Generated at 2022-06-21 19:08:17.044951
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList().filter(lambda el: True) == ImmutableList().filter(lambda el: True)
    assert ImmutableList.of(1, 2, 3).filter(lambda el: True) == ImmutableList.of(1, 2, 3).filter(lambda el: True)
    assert ImmutableList.of(1, 2, 3).filter(lambda el: el > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda el: el > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda el: el > 1).filter(lambda el: el > 2) == ImmutableList.of(3)

# Generated at 2022-06-21 19:08:18.175502
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert [1, 2, 3] == ImmutableList.of(1, 2, 3).to_list()

# Generated at 2022-06-21 19:08:20.481834
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-21 19:08:31.343891
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)
    
    assert ImmutableList.of(1, 2, 3).map(lambda x: x ** 2) == ImmutableList.of(1, 4, 9)
    
    assert ImmutableList.of(1, 2, 3).filter

# Generated at 2022-06-21 19:08:34.801485
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    instance = ImmutableList([1, 2])
    expected_instance = ImmutableList(
        is_empty=False,
        head=[1, 2],
        tail=None
    )
    assert instance == expected_instance


# Generated at 2022-06-21 19:08:45.810553
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    empty_list = ImmutableList.empty()
    list_of_one_element = ImmutableList(1)
    list_of_many_elements = ImmutableList.of(1, 2, 3, 4)

    assert empty_list.find(lambda e: e == 1) is None
    assert list_of_one_element.find(lambda e: e == 1) == 1
    assert list_of_one_element.find(lambda e: e == 0) is None
    assert list_of_many_elements.find(lambda e: e == 3) == 3
    assert list_of_many_elements.find(lambda e: e == 5) is None


# Example of how to use it (ps: it's not unit test)
if __name__ == '__main__':  # pragma: no cover
    some

# Generated at 2022-06-21 19:08:48.933707
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(1, 2, 3)

    assert a == b
    assert a is not b


# Generated at 2022-06-21 19:09:01.304572
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList()
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList.empty() != ImmutableList(1)
    assert ImmutableList.empty() != ImmutableList(1, ImmutableList.empty())
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList.empty()) == ImmutableList(1, ImmutableList())
    assert ImmutableList(1, ImmutableList.empty()) == ImmutableList(1, ImmutableList(is_empty=True))
    assert ImmutableList(1, ImmutableList(2, ImmutableList.empty())) == ImmutableList(1, ImmutableList(2))


# Generated at 2022-06-21 19:09:11.878984
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(4, 7, 10).find(lambda x: x == 4) == 4
    assert ImmutableList.of(4, 7, 10).find(lambda x: x == 7) == 7
    assert ImmutableList.of(4, 7, 10).find(lambda x: x == 10) == 10
    assert ImmutableList.of(4, 7, 10).find(lambda x: x == 3) is None
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 1) == 1
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2

# Generated at 2022-06-21 19:09:17.181714
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():

    test_list = ImmutableList.of()

    assert len(test_list) == 0

    test_list = ImmutableList.of(1)

    assert len(test_list) == 1

    test_list = ImmutableList.of(1, 2, 3)

    assert len(test_list) == 3

# Generated at 2022-06-21 19:09:21.434701
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList.of(None, 1, 2, 3)

    def find_is_none(x): return x is None

    assert list1.find(find_is_none) == None

# Generated at 2022-06-21 19:09:24.534173
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)

# Generated at 2022-06-21 19:09:27.400608
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    result = ImmutableList(1, ImmutableList(2)).__str__()
    assert result == "ImmutableList[1, 2]"



# Generated at 2022-06-21 19:09:35.277501
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda x: x > 1) == ImmutableList.empty()
    assert ImmutableList.of(1).append(2).filter(lambda x: x > 1) == ImmutableList.of(2)
    assert ImmutableList.of(1).append(2).append(3).filter(lambda x: x > 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1).append(1).append(3).filter(lambda x: x > 1) == ImmutableList.of(3)



# Generated at 2022-06-21 19:09:36.859464
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-21 19:09:42.813867
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda a: a < 2) == 1

# Generated at 2022-06-21 19:09:45.189665
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(5) == ImmutableList(5)
    assert ImmutableList(5) != ImmutableList(6)
    assert ImmutableList(5).head == 5
    assert ImmutableList(5).tail is None


# Generated at 2022-06-21 19:09:49.641197
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1) + ImmutableList(2)) == 2
    

test_ImmutableList___len__()

# Generated at 2022-06-21 19:09:58.257951
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert (ImmutableList.of(1) + ImmutableList.of(2)).to_list() == [1,2]
    assert (ImmutableList.of(1,2) + ImmutableList.of(3)).to_list() == [1,2,3]
    assert (ImmutableList.of(1,2) + ImmutableList.empty()).to_list() == [1,2]
    assert (ImmutableList.empty() + ImmutableList.empty()).to_list() == []
    assert (ImmutableList.empty() + ImmutableList.of(2)).to_list() == [2]

# Generated at 2022-06-21 19:10:00.632644
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    source_list = ImmutableList.of(1, 2, 3)
    result = source_list.reduce(lambda acc, x: acc + x, 0)
    assert result == 6



# Generated at 2022-06-21 19:10:05.738239
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-21 19:10:07.788057
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)

# Generated at 2022-06-21 19:10:12.969707
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list_one = ImmutableList.of(1)
    list_two = ImmutableList.of(1, 2)

    assert str(list_one) == 'ImmutableList[1]'
    assert str(list_two) == 'ImmutableList[1, 2]'


# Generated at 2022-06-21 19:10:21.220825
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1, 2)
    list2 = ImmutableList.of(3, 4, 5)

    new_list = list1 + list2

    assert new_list.head == 1
    assert new_list.tail.head == 2
    assert new_list.tail.tail.head == 3
    assert new_list.tail.tail.tail.head == 4
    assert new_list.tail.tail.tail.tail.head == 5
    assert new_list.tail.tail.tail.tail.tail == ImmutableList.empty()


# Generated at 2022-06-21 19:10:23.441386
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2) == ImmutableList.of(1, 3)


# Generated at 2022-06-21 19:10:33.156923
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    test_list = ImmutableList.of(1, 2, 3)

    assert str(test_list) == 'ImmutableList[1, 2, 3]'



# Generated at 2022-06-21 19:10:35.444686
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]



# Generated at 2022-06-21 19:10:37.875726
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1,2,3,4,5)) == 5

    assert len(ImmutableList.empty()) == 0

    assert len(ImmutableList.of(1)) == 1

# Generated at 2022-06-21 19:10:43.345692
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # given
    list_ = ImmutableList.of(1, 2, 3, 4)
    # when
    filtered = list_.filter(lambda e: True if e % 2 == 0 else False)
    # then
    assert filtered == ImmutableList.of(2, 4)


# Generated at 2022-06-21 19:10:48.406264
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]

    assert ImmutableList.of(4, 3, 2, 1).to_list() == [4, 3, 2, 1]

    assert ImmutableList.empty().to_list() == []
    
    

# Generated at 2022-06-21 19:10:52.300810
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(0)) == 'ImmutableList[0]'
    assert str(ImmutableList(0, None, False)) == 'ImmutableList[0]'
    assert str(ImmutableList(0, ImmutableList.of(1, 2, 3))) == 'ImmutableList[0, 1, 2, 3]'


# Generated at 2022-06-21 19:11:03.857307
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # create test case data
    immut1 = ImmutableList.of(1)
    immut2 = ImmutableList.of(2)
    immut_empty1 = ImmutableList.empty()
    immut_empty2 = ImmutableList.empty()
    data = [
        [immut1, ImmutableList.of(1), True],
        [immut1, ImmutableList.of(2), False],
        [immut2, ImmutableList.of(2), True],
        [immut1, immut2, False],
        [immut_empty1, immut_empty1, True],
        [immut_empty1, immut_empty2, True],
        [immut_empty1, immut1, False],
        [immut1, immut_empty1, False],
    ]



# Generated at 2022-06-21 19:11:08.424645
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1,2,3).unshift(0) == ImmutableList.of(0,1,2,3)
    assert ImmutableList.empty().unshift(0) == ImmutableList.empty()


# Generated at 2022-06-21 19:11:10.746393
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list = ImmutableList.of(1, 1, 2, 3)

    assert len(immutable_list) == 4



# Generated at 2022-06-21 19:11:18.228710
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    l2 = ImmutableList(4, ImmutableList(5, ImmutableList(6)))

    # __add__ method return new ImmutableList with elements from previous ones
    assert l1 + l2 == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))



# Generated at 2022-06-21 19:11:38.284822
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    with describe('ImmutableList.reduce'):
        with context('when called with empty list'):
            with it('returns accumulator value'):
                ImmutableList.empty().reduce(lambda x, y: x + y, 5).should.be.equal(5)

        with context('when called with only one element in list'):
            with it('returns accumulator value'):
                ImmutableList.of(1).reduce(lambda x, y: x + y, 5).should.be.equal(6)

        with context('when called with multiple elements in list'):
            with it('calling reduce with lambda function'):
                ImmutableList.of(1, 2, 3, 4, 5, 6).reduce(lambda x, y: x + y, 0).should.be.equal(21)


# Generated at 2022-06-21 19:11:45.227261
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    a = ImmutableList.of('a', 'b', 'c', 'd')
    b = ImmutableList.of('a')
    c = ImmutableList.of('b', 'c', 'd')

    assert a == ImmutableList('a', ImmutableList('b', ImmutableList('c', ImmutableList('d'))))
    assert b == ImmutableList('a')
    assert c == ImmutableList('b', ImmutableList('c', ImmutableList('d')))



# Generated at 2022-06-21 19:11:48.802820
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    new_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert [i + 1 for i in range(5)] == (new_list.map(lambda i: i + 1))



# Generated at 2022-06-21 19:11:52.537454
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    empty_list = ImmutableList.empty()
    assert len(empty_list) == 0
    assert empty_list.head == None
    assert empty_list.tail == None
    assert empty_list.is_empty == True



# Generated at 2022-06-21 19:11:56.724316
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    first_list = ImmutableList.of(1, 2, 3)
    second_list = ImmutableList.of(4, 5, 6)
    result = first_list + second_list
    assert result == ImmutableList.of(1,2, 3, 4, 5, 6)


# Generated at 2022-06-21 19:12:00.183176
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(3).append(4) == ImmutableList(3, ImmutableList(4))


# Generated at 2022-06-21 19:12:07.124785
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_1 = ImmutableList()
    list_2 = ImmutableList(2)
    list_3 = ImmutableList(2, 3)

    list_1 = list_1.append(1)
    list_2 = list_2.append(3)
    list_3 = list_3.append(4)

    assert list_1 == ImmutableList(1)
    assert list_2 == ImmutableList(2, 3)
    assert list_3 == ImmutableList(2, 3, 4)

# Generated at 2022-06-21 19:12:09.384559
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x % 2 == 0) == 2, "Test for find failed"


# Generated at 2022-06-21 19:12:11.782420
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    maybe = ImmutableList.of(1, 2)
    assert maybe.unshift(3) == ImmutableList.of(3, 1, 2)


# Generated at 2022-06-21 19:12:22.170381
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.of(1).append(1) == ImmutableList(1, ImmutableList.of(1))
    assert ImmutableList.of(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-21 19:12:52.313662
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    simple_list = ImmutableList.of(1, 2)
    assert simple_list.append(3) == ImmutableList.of(1, 2, 3)
    assert simple_list == ImmutableList.of(1, 2)


# Generated at 2022-06-21 19:12:58.322335
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, 2) != '1, 2'
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2, ImmutableList(1))


# Generated at 2022-06-21 19:13:05.145796
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda z, x: z + x, 0) == 0
    assert ImmutableList.of(1).reduce(lambda z, x: z + x, 0) == 1
    assert ImmutableList.of(1, 2).reduce(lambda z, x: z + x, 0) == 3
    assert ImmutableList.of(1, 2, 3).reduce(lambda z, x: z + x, 0) == 6
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda z, x: z + x, 0) == 10
    assert ImmutableList.of(1, 2, 3, 4).reduce(lambda z, x: z * x, 1) == 24

# Generated at 2022-06-21 19:13:11.204796
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(2).map(lambda x: x + 2) == ImmutableList.of(4)
    assert ImmutableList.of(2, 3).map(lambda x: x + 2) == ImmutableList.of(4, 5)
    assert ImmutableList.of(2, 3, 4).map(lambda x: x + 2) == ImmutableList.of(4, 5, 6)


# Generated at 2022-06-21 19:13:14.469844
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    expected_output = 'ImmutableList([1, 2, 3, 4, 5])'
    actual_output = str(ImmutableList.of(1, 2, 3, 4, 5))
    assert expected_output == actual_output


# Generated at 2022-06-21 19:13:16.471042
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1,2,3,4)
    assert list_.find(lambda x: x > 2) == 3

# Generated at 2022-06-21 19:13:20.252532
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-21 19:13:23.658153
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    l1 = ImmutableList(1)
    l2 = ImmutableList(2)
    l3 = ImmutableList(1)

    assert l1 == l3
    assert l1 != l2
    assert l1 != 1
    assert l1.__eq__(1) is False



# Generated at 2022-06-21 19:13:28.150054
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    fn = lambda x: x
    list_of_nums = ImmutableList.of(1, 2, 3, 4, 2, 3, 4)
    list_of_strings = ImmutableList.of('a', 'b', 'c')


# Generated at 2022-06-21 19:13:32.757802
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.empty().map(lambda x: x + 1) == ImmutableList.empty()

# Generated at 2022-06-21 19:14:47.349690
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'
    assert str(ImmutableList.of('a', 'b', 'c')) == 'ImmutableList[a, b, c]'
    assert str(ImmutableList.of('a')) == 'ImmutableList[a]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'


# Generated at 2022-06-21 19:14:54.953179
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3).__add__(ImmutableList.of(4, 5, 6)) == ImmutableList.of(1, 2, 3, 4, 5, 6)

    assert ImmutableList.of(3, 4, 5).__add__(ImmutableList.empty()) == ImmutableList.of(3, 4, 5)

    assert ImmutableList.empty().__add__(ImmutableList.of(3, 4, 5)) == ImmutableList.of(3, 4, 5)

    assert ImmutableList.empty().__add__(ImmutableList.empty()) == ImmutableList.empty()

# Generated at 2022-06-21 19:15:00.401558
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 19:15:02.449665
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(0, 1, 2)) == 'ImmutableList[0, 1, 2]'
    assert str(ImmutableList.of('abc')) == 'ImmutableList[abc]'

# Generated at 2022-06-21 19:15:14.403657
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, None, False)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, 2)
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList(1, ImmutableList(2, ImmutableList(3)))


test_

# Generated at 2022-06-21 19:15:18.307573
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList\
        .of(1, 2, 3, 4, 5)\
        .filter(lambda x: x > 2) == ImmutableList\
        .of(3, 4, 5)

    assert ImmutableList\
        .of(1, 2, 3, 4, 5)\
        .filter(lambda x: x > 5) == ImmutableList.empty()



# Generated at 2022-06-21 19:15:20.943548
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2).append(3) == [1, 2, 3]
    assert ImmutableList.empty().append(3) == [3]


# Generated at 2022-06-21 19:15:25.568836
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(10).append(5) == ImmutableList(10, ImmutableList(5))

    assert ImmutableList(10, ImmutableList(5)).append(3) == ImmutableList(10, ImmutableList(5, ImmutableList(3)))


# Generated at 2022-06-21 19:15:29.638067
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    expected = ImmutableList.of(1, 2, 3)
    result = ImmutableList.empty().unshift(3).unshift(2).unshift(1)

    assert(result == expected)

# Generated at 2022-06-21 19:15:37.075603
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Success scenario
    assert ImmutableList.of(1, 1, 2, 3) == ImmutableList(1, ImmutableList(1, ImmutableList(2, ImmutableList(3))))
    # Failure scenario
    #assert ImmutableList.of(1, 1, 2, 3) == ImmutableList(1, ImmutableList(1, ImmutableList(2, ImmutableList(4))))
    #assert ImmutableList.of(1, 1, 2, 3) == ImmutableList(1, ImmutableList(1, ImmutableList(3, ImmutableList(3))))
