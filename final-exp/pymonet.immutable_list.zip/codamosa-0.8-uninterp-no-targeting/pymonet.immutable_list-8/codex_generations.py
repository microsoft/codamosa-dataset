

# Generated at 2022-06-21 19:07:43.968514
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    empty_list = ImmutableList(is_empty=True)

    assert empty_list.head is None
    assert empty_list.tail is None
    assert empty_list.is_empty is True
    assert isinstance(empty_list, ImmutableList)
    assert ImmutableList.of(1).head == 1
    assert ImmutableList.of(1, 2).tail.head == 2
    assert empty_list.to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]

if __name__ == '__main__':
    test_ImmutableList()

# Generated at 2022-06-21 19:07:52.303364
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    lst = ImmutableList.of(1,2,3,4,5)
    assert(lst.find(lambda x: x == 2) == 2)
    assert(lst.find(lambda x: x == 10) is None)
    assert(lst.find(lambda x: x == 1) == 1)
    assert(lst.find(lambda x: x == 5) == 5)
    assert(lst.find(lambda x: x > 3) == 4)
    assert(lst.find(lambda x: x > 6) is None)


# Generated at 2022-06-21 19:07:57.181857
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Test for empty list
    assert str(ImmutableList()) == 'ImmutableList[]'
    
    # Test for list with one element
    assert str(ImmutableList.of(1)) == 'ImmutableList[1]'

    # Test for list with two elements
    assert str(ImmutableList.of(1, 2)) == 'ImmutableList[1, 2]'

# Generated at 2022-06-21 19:08:02.669305
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert 0 == len(ImmutableList.empty())
    assert 1 == len(ImmutableList.of(1))
    assert 2 == len(ImmutableList.of(1, 2))
    assert 3 == len(ImmutableList.of(1, 2, 3))
    assert 4 == len(ImmutableList.of(1, 2, 3, 4))
    assert 5 == len(ImmutableList.of(1, 2, 3, 4, 5))


# Generated at 2022-06-21 19:08:16.858316
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x + 1) == ImmutableList.empty()
    assert ImmutableList.of(1).map(lambda x: x + 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5).map(lambda x: x * 10) == ImmutableList.of(10, 20, 30, 40, 50)

# Generated at 2022-06-21 19:08:24.076178
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    my_list = ImmutableList.of(1)
    assert my_list == my_list
    my_list_2 = ImmutableList(1)
    assert my_list == my_list_2
    my_list_3 = ImmutableList()
    assert my_list != my_list_3
    my_list_4 = ImmutableList(1)
    assert my_list == my_list_4
    my_list_5 = ImmutableList.of(1, 2, 3)
    my_list_6 = ImmutableList.of(1, 2, 3)
    assert my_list_5 == my_list_6


# Generated at 2022-06-21 19:08:28.334711
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1, 2, 3).unshift(0) == ImmutableList.of(0, 1, 2, 3)
    assert ImmutableList.empty().unshift(0) == ImmutableList.of(0)


# Generated at 2022-06-21 19:08:30.769244
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    obj = ImmutableList(1)
    assert obj.reduce(lambda acc, x: acc + x, 0) == 1

# Generated at 2022-06-21 19:08:33.525452
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x,y: x/y, 10) == 0.008333333333333333


# Generated at 2022-06-21 19:08:43.389898
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of() == ImmutableList.of()
    assert ImmutableList.of() != ImmutableList.of(1)
    assert ImmutableList.of(1) != ImmutableList.of()
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1) != ImmutableList(2)
    assert ImmutableList.of(1) != ImmutableList(head=1, tail=ImmutableList(head=1), is_empty=True)



# Generated at 2022-06-21 19:08:53.159758
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    result = ImmutableList.of(1, 2) + ImmutableList.of(3, 4)
    assert result == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-21 19:09:05.067487
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList().append(1).append(2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList().append(1).append(2).append(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList().append(1).append(2).append(3) \
           + ImmutableList().append(4).append(5).append(6) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(6))))))

# Generated at 2022-06-21 19:09:08.260599
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    mylist = ImmutableList.of(1, 2, 3)
    actual = mylist.reduce(lambda x, y: x + y, 0)
    assert actual == 6

# Generated at 2022-06-21 19:09:11.681948
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(1).unshift(0).unshift(-1) == ImmutableList.of(-1, 0, 1)
    
    

# Generated at 2022-06-21 19:09:13.001547
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1,2,3)) == 3

# Generated at 2022-06-21 19:09:16.000047
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1, 2, 3)

    result = test_list.filter(lambda x: x != 2)

    assert result == ImmutableList.of(1, 3)


# Generated at 2022-06-21 19:09:19.523160
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    it = ImmutableList.of(1, 2, 3)

    assert it.map(lambda x: x + 1).to_list() == [2, 3, 4]


# Generated at 2022-06-21 19:09:22.721772
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of()) == 'ImmutableList[None]'
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'

# Generated at 2022-06-21 19:09:24.339431
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)

# Generated at 2022-06-21 19:09:32.944917
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    print('\n##########################################################################\n')
    print('Test reduce method of ImmutableList \n')
    print('##########################################################################\n')
    immutable_list = ImmutableList.of(1, 2, 4, 6, 8, 9)

# Generated at 2022-06-21 19:09:52.411687
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    """ Test case for method reduce of class ImmutableList """
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, next: acc + next, 0) == 15
    assert ImmutableList.empty().reduce(lambda acc, next: acc + next, 0) == 0

# Generated at 2022-06-21 19:09:56.121624
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert(len(ImmutableList.of(1)) == 1)
    assert(len(ImmutableList.of(1, 2)) == 2)
    assert(len(ImmutableList.of(1, 2, 3)) == 3)
    assert(len(ImmutableList.empty()) == 0)



# Generated at 2022-06-21 19:09:58.217012
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:10:01.449836
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    immutable_list_one = ImmutableList.of(1, 2, 3)
    assert(len(immutable_list_one) == 3)

    immutable_list_two = ImmutableList.of(1, ImmutableList.empty())
    assert(len(immutable_list_one) == 2)


# Generated at 2022-06-21 19:10:05.416697
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    value = ImmutableList.of(1, 2, 3, 4, 5, 6)
    value_found = value.find(lambda x: x == 3)
    value_not_found = value.find(lambda x: x == 10)

    assert value_found == 3
    assert value_not_found is None



# Generated at 2022-06-21 19:10:07.788562
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(4)) == 'ImmutableList[4]'
    assert str(ImmutableList(4, ImmutableList(5))) == 'ImmutableList[4, 5]'

# Generated at 2022-06-21 19:10:11.899701
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)

    result = list_.reduce(lambda acc, n: n + acc, 0)

    assert result == 15



# Generated at 2022-06-21 19:10:19.315290
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_ = ImmutableList.of(1, 2, 3, 4, 5)
    assert list_.reduce(lambda acc, x: acc + x, 0) == 15

    list_ = ImmutableList.of('h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd')
    assert list_.reduce(lambda acc, x: acc + x, '') == 'helloworld'


# Generated at 2022-06-21 19:10:24.969073
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    is_equal = ImmutableList.of(1, 2, 3).__len__() == 3
    print('OK' if is_equal else 'FAIL')
    is_equal = ImmutableList.of('A', 'B', 1, 2, 3, 'C', 'D').__len__() == 7
    print('OK' if is_equal else 'FAIL')
    is_equal = ImmutableList.empty().__len__() == 0
    print('OK' if is_equal else 'FAIL')


# Generated at 2022-06-21 19:10:28.743089
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    __expected = ImmutableList(0, ImmutableList(1, ImmutableList(2)))
    __result = ImmutableList(0, ImmutableList(1)) + ImmutableList(2)
    assert __expected == __result


# Generated at 2022-06-21 19:11:06.207776
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    print('\t Running test_ImmutableList___eq__')
    # arrange
    arr_1 = ImmutableList.of(1, 2, 3)
    arr_2 = ImmutableList.of(1, 2, 3)
    arr_3 = ImmutableList.of(3, 2, 1)
    # act
    is_equal_1 = arr_1 == arr_2
    is_equal_2 = arr_2 == arr_3
    # assert
    assert is_equal_1 is True, 'arr_1 should be equal to arr_2'
    assert is_equal_2 is False, 'arr_2 should not be equal to arr_3'
    print('\tEnd of test test_ImmutableList___eq__\n')


# Generated at 2022-06-21 19:11:10.102271
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(10)) == 1
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(10, 20, 30, 40)) == 4
    return


# Generated at 2022-06-21 19:11:16.530080
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(2, ImmutableList(4))) == 'ImmutableList[2, 4]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(is_empty=True)) == 'ImmutableList[]'
    assert str(ImmutableList()) == 'ImmutableList[]'

# Generated at 2022-06-21 19:11:19.384790
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_ = ImmutableList.of(1, 2, 3)
    list_ = list_.append(4)
    assert list_ == ImmutableList.of(1, 2, 3, 4)



# Generated at 2022-06-21 19:11:23.701322
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert ImmutableList(1).__str__() == 'ImmutableList[1]'
    assert ImmutableList(None, ImmutableList(1)).__str__() == 'ImmutableList[None, 1]'
    
    

# Generated at 2022-06-21 19:11:28.132228
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Setup
    l1 = ImmutableList.of(1)
    l2 = ImmutableList.of(2)

    # Exercise
    result = l1 + l2

    # Verify
    assert result == ImmutableList.of(1, 2)


# Generated at 2022-06-21 19:11:34.136958
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list_of_ints = ImmutableList(1, 2, 3, 4, 5)
    assert len(list_of_ints) == 5

    list_of_ints2 = ImmutableList(1, 2)
    assert len(list_of_ints2) == 2

    list_of_ints3 = ImmutableList(1)
    assert len(list_of_ints3) == 1

    list_of_ints4 = ImmutableList()
    assert len(list_of_ints4) == 0


# Generated at 2022-06-21 19:11:45.711051
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of() + ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.of() == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.of(2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)

# Generated at 2022-06-21 19:11:50.094466
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3, 4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert [1, 2, 3, 4, 5] == ImmutableList.of(1, 2, 3, 4, 5).to_list()

# Generated at 2022-06-21 19:11:54.186086
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list = ImmutableList.of(1, 2, 3)
    assert list.to_list() == [1, 2, 3]
    assert ImmutableList.empty().to_list() == []


# Generated at 2022-06-21 19:12:53.415618
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert(ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4))
    assert(ImmutableList.of(1, 2, 3).append(4).append(5) == ImmutableList.of(1, 2, 3, 4, 5))
    assert(ImmutableList.of(1, 2, 3).append(4).append(5).append(6) == ImmutableList.of(1, 2, 3, 4, 5, 6))

# Generated at 2022-06-21 19:13:03.166032
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda el: True) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda el: False) == ImmutableList.empty()
    assert ImmutableList(1).filter(lambda el: True) == ImmutableList(1)
    assert ImmutableList(1).filter(lambda el: False) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)).filter(lambda el: True) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)).filter(lambda el: False) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)).filter(lambda el: el == 1) == ImmutableList(1)

# Generated at 2022-06-21 19:13:09.978164
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    with pytest.raises(ValueError):
        ImmutableList.of(1, 2, 3).map(lambda x: x * 2, None)

    assert ImmutableList.of().map(lambda x: x * 2) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-21 19:13:18.134651
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (ImmutableList.empty() == ImmutableList.empty()) == True
    assert (ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == True
    assert (ImmutableList(1, ImmutableList(2, ImmutableList(4))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == False
    assert (ImmutableList(1) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == False
    assert (ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1)) == False

# Generated at 2022-06-21 19:13:21.374466
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(10) == ImmutableList.of(10)
    assert ImmutableList.of(10, 20, 30).unshift(5) == ImmutableList.of(5, 10, 20, 30)


# Generated at 2022-06-21 19:13:25.402299
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList.of(1)

    assert ImmutableList.of(2, 3).append(1) == ImmutableList.of(2, 3, 1)

# Generated at 2022-06-21 19:13:29.620497
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_instance = ImmutableList.of('one', 'two', 'three')
    filtered_list = list_instance.filter(lambda element: element == 'one')

    assert filtered_list == ImmutableList.of('one')



# Generated at 2022-06-21 19:13:39.603091
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():

    assert ImmutableList.of(1).__add__(ImmutableList.of(2)) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).__add__(ImmutableList.of(3)) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2).__add__(ImmutableList.of(3, 4)) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4).__add__(ImmutableList.of(5, 6, 7, 8)) == ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)

    assert ImmutableList.of(1).__add__(ImmutableList.of(2, 3)) == Immutable

# Generated at 2022-06-21 19:13:46.831371
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) == ImmutableList(
            1,
            ImmutableList(2, ImmutableList(3, ImmutableList(4)))
        ).filter(lambda x: x < 3)

    assert ImmutableList(4) == ImmutableList(
            1,
            ImmutableList(2, ImmutableList(3, ImmutableList(4)))
        ).filter(lambda x: x > 3)




# Generated at 2022-06-21 19:13:56.008866
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    fruit = ImmutableList.of('Apple')
    vegetable = ImmutableList.of('Tomato')
    print('\x1b[0;32m', 'In test unshift: ', end='')
    print("Is `fruit` ImmutableList?", type(fruit) is ImmutableList,
          '\nIs `vegetable` ImmutableList?', type(vegetable) is ImmutableList)
    print("\nFruit", fruit)
    print("\nVegetable", vegetable)
    grocery = fruit.unshift(vegetable.head)
    print("\nNew grocery list: ", grocery)
    print("\nLength of grocery list: ", len(grocery))
    print('\x1b[0m')


# Generated at 2022-06-21 19:14:52.242328
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:14:56.190636
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1).to_list() == [1]
    assert ImmutableList.of(1).unshift(2).to_list() == [2, 1]
    assert ImmutableList.of(1, 2, 3, 4).unshift('s').to_list() == ['s', 1, 2, 3, 4]


# Generated at 2022-06-21 19:15:03.301726
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    cases = [
        (
            ImmutableList.empty(),
            lambda x: x + 1,
            ImmutableList.empty()
        ),
        (
            ImmutableList.of(1, 2, 3, 4),
            lambda x: x + 1,
            ImmutableList.of(2, 3, 4, 5)
        ),
        (
            ImmutableList.of(1, 2, 3, 4),
            lambda x: x * 2,
            ImmutableList.of(2, 4, 6, 8)
        ),
    ]

    for params, mapper, expected_result in cases:
        result = params.map(mapper)
        assert result == expected_result

# Generated at 2022-06-21 19:15:07.022947
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    filtered = ImmutableList.of(1, 2, 3).find(lambda x: x == 2)
    assert filtered == 2

test_ImmutableList_find()

# Generated at 2022-06-21 19:15:10.766881
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of('a', 'b', 'c') + ImmutableList.of('d', 'e', 'f') == ImmutableList.of('a', 'b', 'c', 'd', 'e', 'f')

# Generated at 2022-06-21 19:15:15.037281
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_to_test = [1, 2, 3, 4, 5]
    list_reduce = ImmutableList.of(*list_to_test).reduce(lambda acc, el: acc + el, 0)
    assert list_reduce == 15
    return True


# Generated at 2022-06-21 19:15:25.912070
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1, None)
    l = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == l
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(3, ImmutableList(2)))
    assert str(l) == 'ImmutableList[1, 2, 3]'
    assert l.is_empty == False
    with pytest.raises(ValueError):
        assert ImmutableList() == None


# Generated at 2022-06-21 19:15:28.350729
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(5)) == 1
    assert len(ImmutableList.of(5, 3)) == 2

# Generated at 2022-06-21 19:15:31.880282
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    ilm = ImmutableList.of(1, 2, 3, 3, 3)
    ilm2 = ImmutableList.of(3, 3, 3, 2, 1)
    assert ilm.reduce(lambda a, b: b + a, 0) == 12
    assert ilm2.reduce(lambda a, b: b + a, 0) == 12

test_ImmutableList_reduce()

# Generated at 2022-06-21 19:15:39.823122
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x > 2) is None
    assert ImmutableList.empty().find(lambda x: x < 2) is None

    assert ImmutableList(2).find(lambda x: x > 2) is None
    assert ImmutableList(2).find(lambda x: x < 2) is None
    assert ImmutableList(2).find(lambda x: x == 2) == 2

    assert ImmutableList(0, 2).find(lambda x: x > 2) is None
    assert ImmutableList(0, 2).find(lambda x: x < 2) is 0
    assert ImmutableList(0, 2).find(lambda x: x % 2 == 0) == 0
    assert ImmutableList(0, 2, 4, 6).find(lambda x: x % 2 == 0) == 0
    assert Imm