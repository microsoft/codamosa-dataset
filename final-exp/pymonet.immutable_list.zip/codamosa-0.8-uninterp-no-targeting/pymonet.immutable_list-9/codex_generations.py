

# Generated at 2022-06-21 19:07:39.518833
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:07:49.533908
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given
    empty_list = ImmutableList.empty()
    list_with_one_element = ImmutableList(1)
    list_with_multiple_elements = ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    # when
    no_element = empty_list.find(lambda x: True)
    one_element = list_with_one_element.find(lambda x: x == 1)
    multiple_elements = list_with_multiple_elements.find(lambda x: x == 1)

    # then
    assert no_element is None
    assert one_element == 1
    assert multiple_elements == 1



# Generated at 2022-06-21 19:07:52.552583
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:07:56.589795
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4)
    assert list.find(lambda x: x > 2) == 3
    assert list.find(lambda x: x == 1) == 1
    assert list.find(lambda x: x == 10) is None


# Generated at 2022-06-21 19:08:01.565871
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    immutable_list = ImmutableList.of(1)
    immutable_list = immutable_list.append(2)
    immutable_list = immutable_list.append(3)
    immutable_list = immutable_list.append(4)
    immutable_list = immutable_list.append(5)
    assert immutable_list == ImmutableList.of(1, 2, 3, 4, 5)


# Generated at 2022-06-21 19:08:08.762969
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # let list = ImmutableList.of(value)
    # list.map(fn) => return ImmutableList(fn(value))
    list = ImmutableList.of(1)
    head = list.map(lambda x: x + 1)

    assert head.head == 2
    assert head.tail is None

    
    # let list = ImmutableList.of(value1, value2, value3)
    # list.map(fn) => return ImmutableList(fn(value1), fn(value2), fn(value3))
    list = ImmutableList.of(1, 2, 3)
    
    head = list.map(lambda x: x + 1)
    assert head.head.head == 2
    assert head.head.tail.head == 3
    assert head.head.tail.tail.head == 4
   

# Generated at 2022-06-21 19:08:16.736434
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    test_data = [
        (
            ImmutableList.of(1, 2, 3),
            ImmutableList.of(1, 2, 3)
        ),
        (
            ImmutableList.empty(),
            ImmutableList.empty()
        )
    ]

    for test_case in test_data:
        computed_value = test_case[0].__str__()
        expected_value = test_case[1]
        assert computed_value == expected_value


# Generated at 2022-06-21 19:08:18.666870
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    result = ImmutableList.of(1, 2, 3).__len__()
    assert result == 3


# Generated at 2022-06-21 19:08:21.620890
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_to_append = ImmutableList.of(1, 2, 3)
    new_list = list_to_append.append(4)
    assert new_list == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-21 19:08:31.478292
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    xs = ImmutableList.of('a', 'b', 'c', 'd')
    assert xs.find(lambda x: x == 'a') == 'a'
    assert xs.find(lambda x: x == 'b') == 'b'
    assert xs.find(lambda x: x == 'c') == 'c'
    assert xs.find(lambda x: x == 'd') == 'd'
    assert xs.find(lambda x: x == 'e') is None
    assert xs.find(lambda x: True) == 'a'
    assert ImmutableList.empty().find(lambda x: True is None)
test_ImmutableList_find()


# Generated at 2022-06-21 19:08:40.124685
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3


# Generated at 2022-06-21 19:08:44.710966
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # GIVEN
    immutable_list = ImmutableList.of(1, 2, 3, 4, 5)
    def double(element):
        return element * 2

    # WHEN
    result = immutable_list.map(double)

    # THEN
    assert result == ImmutableList.of(2, 4, 6, 8, 10)


# Generated at 2022-06-21 19:08:50.559223
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    my_list = ImmutableList.of(4, 5, 6, 7).filter(lambda value: value % 2 == 0)
    assert my_list.to_list() == [4, 6]

    my_list = ImmutableList.empty().filter(lambda value: value % 2 == 0)
    assert my_list.to_list() == []


# Generated at 2022-06-21 19:08:55.429439
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList(None).to_list() == [None]
    assert ImmutableList(1, ImmutableList(2, ImmutableList.empty())).to_list() == [1, 2]


# Generated at 2022-06-21 19:08:58.797274
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5



# Generated at 2022-06-21 19:09:09.971096
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList([1, 2, 3]).filter(lambda i: i >= 2) == ImmutableList([2, 3])
    assert ImmutableList([1, 2, 3]).filter(lambda i: i <= 1) == ImmutableList([1])
    assert ImmutableList([1, 2, 3]).filter(lambda i: i == 4) == ImmutableList(is_empty=True)

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda i: i >= 2) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda i: i <= 1) == ImmutableList(1)

# Generated at 2022-06-21 19:09:13.288281
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(None)) == 1
    assert len(ImmutableList.empty()) == 0



# Generated at 2022-06-21 19:09:19.522695
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Arrange
    l1 = ImmutableList(1)
    l2 = ImmutableList(2)
    l3 = ImmutableList(3, l2)

    # Act
    l3_copy = l3.__add__(l1)

    # Assert
    assert l3_copy == ImmutableList(3, ImmutableList(2, l1)), 'should be equal'



# Generated at 2022-06-21 19:09:27.588874
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(2)
    list3 = ImmutableList.of(3)
    list1_equal = ImmutableList.of(1)
    list_concatenated = ImmutableList.of(1, 2, 3)

    assert list1 + list2 + list3 == list_concatenated
    assert list1 + list2 == ImmutableList.of(1, 2)
    assert list1 + list2 == list2 + list1
    assert list1 + list1_equal == list1
    assert list1_equal + list1 == list1

    assert list1.append(2) == list1 + list2
    assert list1.append(2).append(3) == list1_equal + list2 + list3
    assert list1.append

# Generated at 2022-06-21 19:09:30.638646
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_1 = ImmutableList.of(1, 2, 3)
    assert list_1.reduce(lambda acc, elem: acc + elem, 0) == 6

# Generated at 2022-06-21 19:09:44.981226
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList(4).unshift(5) == ImmutableList(5, ImmutableList(4))
    assert ImmutableList(3, ImmutableList(4)).unshift(5) == ImmutableList(5, ImmutableList(3, ImmutableList(4)))

# Generated at 2022-06-21 19:09:49.757823
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_of_args = ImmutableList.of(1, 2)
    multiplication = list_of_args.map(lambda x : x * 2)
    list_of_multiplication = ImmutableList.of(2, 4)
    assert multiplication == list_of_multiplication

# Generated at 2022-06-21 19:09:53.831160
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList('a', ImmutableList('b'))) == 'ImmutableList[\'a\', \'b\']'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList('a')) == 'ImmutableList[\'a\']'


# Generated at 2022-06-21 19:10:02.196177
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Testing for None
    assert None == ImmutableList().find(lambda x: True)

    # Testing for empty ImmutableList
    assert None == ImmutableList().find(lambda x: True)

    # Testing for single element in ImmutableList
    assert 42 == ImmutableList.of(42).find(lambda x: True)
    assert None == ImmutableList.of(42).find(lambda x: False)

    # Testing for many elements in ImmutableList
    assert 42 == ImmutableList.of(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 42, 43, 44).find(lambda x: x == 42)

# Generated at 2022-06-21 19:10:09.922928
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of('a', 'b', 'c', 'd', 'e').reduce(lambda acc, head: acc + head, 'x') == 'xabcde'
    assert ImmutableList.empty().reduce(lambda acc, head: acc + head, 'x') == 'x'
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, head: acc + head, 0) == 15
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, head: head * acc, 1) == 120

# Unit tests for method reduce of class ImmutableList
test_ImmutableList_reduce()



# Generated at 2022-06-21 19:10:15.751428
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2, 3).unshift(5) == ImmutableList.of(5, 1, 2, 3)


# Generated at 2022-06-21 19:10:18.914509
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(
        'Hello',
        'from',
        'immutable',
        'world'
    ).find(lambda x: len(x) > 7) == 'immutable'


# Generated at 2022-06-21 19:10:22.357699
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list_of_numbers = ImmutableList.of(1, 2, 3)
    result = list_of_numbers.reduce(lambda x, y: x + y, 0)

    assert result == 6, "result should be 6"


# Generated at 2022-06-21 19:10:25.414128
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3)
    list3 = ImmutableList.of(4, 5, 6)

    assert list1 == list2
    assert list1 != list3

# Generated at 2022-06-21 19:10:33.104685
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList()))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList())))) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:10:57.591931
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(4)) == 1
    assert len(ImmutableList(4).append(5)) == 2
    assert len(ImmutableList(4).append(5).append(6)) == 3
    assert len(ImmutableList(4).append(5).append(6).append(7)) == 4
    assert len(ImmutableList(4).append(5).append(6).append(7).append(8)) == 5
    assert len(ImmutableList(4).append(5).append(6).append(7).append(8).append(9)) == 6
    assert len(ImmutableList(4).append(5).append(6).append(7).append(8).append(9).append(10)) == 7

# Generated at 2022-06-21 19:11:02.382014
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    array = ImmutableList.of(
        1,
        2,
        3
    )
    mapped_array = array.map(lambda el: el * 2)
    assert mapped_array == ImmutableList.of(
        2,
        4,
        6
    )

# Generated at 2022-06-21 19:11:04.821255
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    res = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert len(res) == 3



# Generated at 2022-06-21 19:11:08.028478
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0) == 2


# Generated at 2022-06-21 19:11:12.808763
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Given
    first_element = 1
    second_element = 2
    third_element = 3
    list_instance = ImmutableList(first_element, ImmutableList(second_element, ImmutableList(third_element)))

    # When
    result = list_instance.to_list()

    # Then
    expected = [1, 2, 3]
    assert expected == result

# Generated at 2022-06-21 19:11:19.009026
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) != ImmutableList.of(1, 2, 4)
    assert ImmutableList.empty().find(lambda el: el > 5) is None
    assert ImmutableList.of(1, 2, 3).find(lambda el: el > 2) == 3


# Generated at 2022-06-21 19:11:22.580253
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    lst = ImmutableList.of(1, 2, 3, 4)

    assert lst.to_list() == [1, 2, 3, 4]


# Generated at 2022-06-21 19:11:26.393235
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty() 
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) != ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-21 19:11:32.575125
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-21 19:11:37.387693
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(2) == ImmutableList(2)
    assert ImmutableList.of(2, 3) == ImmutableList(2, ImmutableList(3))
    assert ImmutableList.of(2, 3, 4) == ImmutableList(2, ImmutableList(3, ImmutableList(4)))
    assert ImmutableList.of(2, 3, 4, 5) == ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))


# Generated at 2022-06-21 19:12:16.565354
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    my_list = ImmutableList.of('a')
    assert my_list.head == 'a'

    my_list = ImmutableList.of('a', 'b', 'c')
    assert my_list.head == 'a'
    assert my_list.tail.head == 'b'
    assert my_list.tail.tail.head == 'c'
    assert my_list.tail.tail.tail is None



# Generated at 2022-06-21 19:12:20.801646
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list = ImmutableList.empty()
    assert list.append(2).to_list() == [2]
    assert list.append(2).append(3).to_list() == [2, 3]
    assert list.append(2).append(3).append(4).to_list() == [2, 3, 4]

test_ImmutableList_append()


# Generated at 2022-06-21 19:12:23.525080
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list = ImmutableList.of(1, 2, 3)
    assert list == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    list = ImmutableList.of(1)
    assert list == ImmutableList(1)

    list = ImmutableList.empty()
    assert list == ImmutableList()


test_ImmutableList___eq__()

# Generated at 2022-06-21 19:12:34.663436
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # given
    items = [1, 2, 3, 4, 5]
    sum_reducer = lambda acc, item: acc + item
    multiply_reducer = lambda acc, item: acc * item

    # when
    result_sum = sum(items)
    result_multiply = reduce(
        lambda acc, item: acc * item,
        items,
        1
    )

    # then
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(sum_reducer, 0) == result_sum
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(multiply_reducer, 1) == result_multiply
    assert ImmutableList.of().reduce(sum_reducer, 0) == 0
    assert ImmutableList.of().reduce

# Generated at 2022-06-21 19:12:37.879718
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(
        1, 2, 3, 4
    ).find(lambda el: el > 2) == 3

# Generated at 2022-06-21 19:12:42.528597
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    first_list = ImmutableList.of(1)
    second_list = ImmutableList.of(1)
    third_list = ImmutableList.of(2)

    assert first_list == second_list
    assert second_list == first_list
    assert first_list != third_list
    assert third_list != first_list

# Generated at 2022-06-21 19:12:50.756682
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    l1 = ImmutableList.of('a', 'b', 'c')
    l2 = ImmutableList.of('d', 'e')
    
    assert l1 + l2 == ImmutableList.of('a', 'b', 'c', 'd', 'e')
    assert ImmutableList.empty() + l2 == l2
    assert l1 + ImmutableList.empty() == l1
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()



# Generated at 2022-06-21 19:12:58.426646
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Test empty list
    empty_list = ImmutableList.empty()
    assert empty_list.map(lambda x: x + 1) == []

    # Test list with one element
    second_list = ImmutableList.of(5)
    assert second_list.map(lambda x: x + 1) == [6]

    # Test list with some elements
    first_list = ImmutableList.of(1, 2, 3, 4)
    assert first_list.map(lambda x: x + 1) == [2, 3, 4, 5]


# Generated at 2022-06-21 19:13:01.749699
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of(7, 2, 5, 9)
    b = ImmutableList.of(5, 4)
    assert a + b == ImmutableList.of(7, 2, 5, 9, 5, 4)

# Generated at 2022-06-21 19:13:12.770409
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList(1).append('a') == ImmutableList(1, ImmutableList('a'))
    assert ImmutableList.of('a').append('b') == ImmutableList('a', ImmutableList('b'))
    assert ImmutableList.of('a').append('b').append('c') == ImmutableList('a', ImmutableList('b', ImmutableList('c')))
    assert ImmutableList.of(1,2,3,4).append(5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))

    assert ImmutableList(1).append('a') != ImmutableList.of(1,1)
    assert ImmutableList.of('a').append('b') != ImmutableList.of('a', 2)
   

# Generated at 2022-06-21 19:14:25.589750
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list = ImmutableList.of("a", "b", "c")
    assert len(list) == 3
    list = ImmutableList.empty()
    assert len(list) == 0

# Generated at 2022-06-21 19:14:28.417962
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4)) == 'ImmutableList[1, 2, 3, 4]'

# Generated at 2022-06-21 19:14:30.883880
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert [] == ImmutableList.empty().to_list()
    assert [1, 2] == ImmutableList.of(1, 2).to_list()



# Generated at 2022-06-21 19:14:33.038959
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(3, 5).reduce(lambda x, y: x + y, 0) == 8



# Generated at 2022-06-21 19:14:38.364546
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2).reduce(lambda x, y: x + y, 0) == 3
    assert ImmutableList.of(1, 2).reduce(lambda x, y: x - y, 0) == -3
    assert ImmutableList.of(1, 2).reduce(lambda x, y: x * y, 0) == 0
    assert ImmutableList.of(1, 2).reduce(lambda x, y: x * y, 1) == 2
    assert ImmutableList.empty().reduce(lambda x, y: x * y, 3) == 3


# Generated at 2022-06-21 19:14:47.934688
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1,1,1))=="ImmutableList[1, 1, 1]"
    assert str(ImmutableList(1, ImmutableList(2))) == "ImmutableList[1, 2]"
    assert str(ImmutableList.of(1))=="ImmutableList[1]"
    assert str(ImmutableList())=="ImmutableList[]"
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == "ImmutableList[1, 2, 3]"
    assert str(ImmutableList(is_empty=True))=="ImmutableList[]"
    assert ImmutableList().__str__()=="ImmutableList[]"

# Generated at 2022-06-21 19:14:56.730650
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list_1 = ImmutableList(1)
    list_2 = ImmutableList(2)
    list_3 = ImmutableList(3)

    assert list_1.head == 1
    assert list_2.head == 2
    assert list_3.head == 3
    assert list_1.tail is None
    assert list_2.tail is None
    assert list_3.tail is None

    assert ImmutableList.of(1) == list_1
    assert ImmutableList.of(1, 2) == ImmutableList(1, list_2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, list_3))

    empty_list = ImmutableList.empty()
    assert isinstance(empty_list, ImmutableList)

# Generated at 2022-06-21 19:15:02.010371
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    a = ImmutableList.of('a')
    b = ImmutableList.of('a')
    c = ImmutableList.of('b')
    d = ImmutableList.of('a', 'b')
    e = ImmutableList.of('b', 'a')
    
    assert a == b
    assert a != c
    assert d != e
    assert a != 1
    assert b != 2
    assert c != 3
    assert d != 4
    assert e != 5

# Generated at 2022-06-21 19:15:05.916822
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert 1 == list.find(lambda x: x == 1)
    assert None == list.find(lambda x: x == 0)


# Generated at 2022-06-21 19:15:11.532133
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert (ImmutableList(5) == ImmutableList(5)) is True
    assert (ImmutableList(5) == ImmutableList(4)) is False
    assert (ImmutableList(5) == None) is False
    assert (ImmutableList(5) == ImmutableList(5, ImmutableList(4))) is False


# Generated at 2022-06-21 19:16:27.279401
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():

    assert (
        ImmutableList.of(1).append(2)
        == ImmutableList.of(1, 2)
    )

    assert (
        ImmutableList.of(1, 2).append(3)
        == ImmutableList.of(1, 2, 3)
    )

    assert (
        ImmutableList.of(1, 2, 3).append(4)
        == ImmutableList.of(1, 2, 3, 4)
    )

    assert (ImmutableList.empty().append(2)
        == ImmutableList.of(2)
    )


# Generated at 2022-06-21 19:16:30.290667
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    my_list = ImmutableList.of(1)
    new_list = my_list.unshift(2)
    assert 2 == new_list.head
    assert new_list.tail == my_list
    return True

# Generated at 2022-06-21 19:16:36.086851
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    print("Test case: ImmutableList map method")
    print("\tCase 1: ImmutableList with one element")
    print("\tExpected: 2")
    print("\tResult: ", ImmutableList.of(1).map(lambda x: x + 1))

    print("\tCase 2: ImmutableList with many elements")
    print("\tExpected: [2, 3, 4, 5]")
    print("\tResult: ", ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 1))



# Generated at 2022-06-21 19:16:38.934286
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x % 2 == 0) == 2
    assert ImmutableList.of(1, 2, 3, 4).find(lambda x: x % 2 == 1) == 1
    assert isinstance(ImmutableList.empty(), ImmutableList)
    assert ImmutableList.empty().find(lambda x: x % 2 == 0) is None


# Generated at 2022-06-21 19:16:42.934126
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))
    assert ImmutableList() == ImmutableList(True)

# Generated at 2022-06-21 19:16:50.924520
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).map(lambda x: x + 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5)


# Generated at 2022-06-21 19:16:55.245413
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    result = 'ImmutableList[]'
    assert str(ImmutableList.empty()) == result
    
    
    result = 'ImmutableList[str]'
    assert str(ImmutableList.empty().append('str')) == result
    
    
    result = 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.of(1, 2, 3)) == result
    


# Generated at 2022-06-21 19:16:58.568554
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # given
    immutable_list = ImmutableList.of('test', 'value')

    # when
    result = str(immutable_list)

    # then
    assert result == 'ImmutableList[test, value]'



# Generated at 2022-06-21 19:17:00.438001
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1, ImmutableList(2), False)) == 'ImmutableList[1, 2]'


# Generated at 2022-06-21 19:17:05.099082
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    x = ImmutableList.of(1, 1, 1)
    y = ImmutableList.of(2, 2, 2)
    r = x + y
    assert r == ImmutableList(1, ImmutableList(1, ImmutableList(1, ImmutableList(2, ImmutableList(2, ImmutableList(2))))))
