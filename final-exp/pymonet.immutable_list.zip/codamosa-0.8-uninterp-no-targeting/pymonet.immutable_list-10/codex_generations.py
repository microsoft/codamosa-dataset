

# Generated at 2022-06-21 19:07:35.606699
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)



# Generated at 2022-06-21 19:07:42.977599
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    empty_list = ImmutableList.empty()
    one_element_list = ImmutableList(1)
    two_elements_list = ImmutableList.of(1, 2)

    assert (empty_list.unshift(1)) == ImmutableList.of(1)
    assert (one_element_list.unshift(2)) == ImmutableList.of(2, 1)
    assert (two_elements_list.unshift(3)) == ImmutableList.of(3, 1, 2)


# Generated at 2022-06-21 19:07:46.283265
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of('lorem', 'ipsum', 'dolor') == ImmutableList.empty().append('lorem').append('ipsum').append('dolor')

# Generated at 2022-06-21 19:07:51.271320
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Empty ImmutableList
    a = ImmutableList.empty()
    assert str(a) == 'ImmutableList{}'

    # Not empty ImmutableList
    b = ImmutableList.of(1, 2, 3)
    assert str(b) == 'ImmutableList{[1, 2, 3]}'


# Generated at 2022-06-21 19:07:59.228485
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    testcases = [
        [1, 2, 3, 4],
        [0],
        [],
        [5, 4, 3, 2, 1],
        [0, 0, 0, 0, 0, 0, 0],
        [False, True, True, False, True],
    ]
    for testcase in testcases:
        t = ImmutableList.of(*testcase)
        assert (t.map(lambda x: x * x).to_list()) == list(map(lambda x: x * x, testcase))


# Generated at 2022-06-21 19:08:05.299930
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    items1 = [1, 2, 3]
    head1 = 1
    tail1 = ImmutableList.of(2, 3)
    is_empty1 = False
    o1 = ImmutableList(head1, tail1, is_empty1)

    items2 = [1, 2, 3]
    head2 = 1
    tail2 = ImmutableList.of(2, 3)
    is_empty2 = False
    o2 = ImmutableList(head2, tail2, is_empty2)

    assert o1 == o2


# Generated at 2022-06-21 19:08:10.605041
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    

# Generated at 2022-06-21 19:08:18.996684
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    xs = ImmutableList(100, ImmutableList(200), ImmutableList(300, ImmutableList(400), ImmutableList(500)))
    ys = xs.filter(lambda x: x % 2 == 0)
    assert ys == ImmutableList(100, ImmutableList(200, ImmutableList(300))), 'Test case 1'

    xs = ImmutableList(100, ImmutableList(200), ImmutableList(300, ImmutableList(400), ImmutableList(500)))
    ys = xs.filter(lambda x: x % 2 != 0)
    assert ys == ImmutableList(200, ImmutableList(300, ImmutableList(400))), 'Test case 2'


# Generated at 2022-06-21 19:08:22.254173
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(2, 3, 4).find(lambda x: x == 3) == 3
    assert ImmutableList.of(2, 3, 4).find(lambda x: x == 5) is None

test_ImmutableList_find()

# Generated at 2022-06-21 19:08:24.305475
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    im_lst = ImmutableList.of(1, 2, 3)
    assert im_lst == ImmutableList(1, ImmutableList(2, ImmutableList(3)))


# Generated at 2022-06-21 19:08:39.897793
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_of_numbers = ImmutableList.of(1,2,3,4,5)

    assert list_of_numbers.to_list() == [1,2,3,4,5]

# Generated at 2022-06-21 19:08:42.544950
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    a = ImmutableList.of(1, 2, 3)
    assert a.unshift('a').to_list() == ['a', 1, 2, 3]

# Generated at 2022-06-21 19:08:45.893668
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert list.reduce(lambda x, y: x + y, 0) == 15
    assert list.reduce(lambda x, y: x + y, 5) == 20

# Generated at 2022-06-21 19:08:58.178222
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # empty list
    list_object = ImmutableList.empty()
    assert list_object.filter(lambda x: True) == ImmutableList.empty()

    # no passing to filter
    list_object = ImmutableList.of(1, 2, 2, 3)
    assert list_object.filter(lambda x: x == 4) == ImmutableList.empty()

    # passing to filter
    list_object = ImmutableList.of(1, 2, 2, 3)
    assert list_object.filter(lambda x: x == 2) == ImmutableList.of(2, 2)

    # passing to filter
    list_object = ImmutableList.of(1, 2, 2, 3)
    assert list_object.filter(lambda x: x == 1) == ImmutableList.of(1)

    # passing to filter
   

# Generated at 2022-06-21 19:09:00.333396
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3

# Generated at 2022-06-21 19:09:11.077591
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)
    assert ImmutableList.of(1, 2) + ImmutableList(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList.of(1, 2)
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() + ImmutableList(1) == ImmutableList(1)

# Generated at 2022-06-21 19:09:15.132655
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list = ImmutableList.of(1, 2, 3)
    test = list.map(lambda x: x * 2)

    assert test.length == 3
    assert test == ImmutableList.of(2, 4, 6)


# Generated at 2022-06-21 19:09:20.146311
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():

    assert ImmutableList.of(1,2,3,4).map(lambda x: x + 2) == \
        ImmutableList.of(3,4,5,6)
    assert ImmutableList.empty().map(lambda x: x + 2) == \
        ImmutableList.empty()

# Generated at 2022-06-21 19:09:27.767686
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x + 1).is_empty
    assert ImmutableList.of(1)\
        .map(lambda x: x + 1).head == 2

    assert ImmutableList.of(1, 2, 3)\
        .map(lambda x: x + 1).head == 2
    assert ImmutableList.of(1, 2, 3)\
        .map(lambda x: x + 1).tail.head == 3
    assert ImmutableList.of(1, 2, 3)\
        .map(lambda x: x + 1).tail.tail.head == 4

    assert ImmutableList.of(1, 2, 3)\
        .map(lambda x: x * 10).head == 10

# Generated at 2022-06-21 19:09:35.598682
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    sample = ImmutableList.of(
        1, 2, 3, 4, 5
    )

    result = sample.filter(lambda x: x == 2)
    assert len(result) == 1
    assert result.head == 2

    result = sample.filter(lambda x: x == 6)
    assert len(result) == 0

    result = sample.filter(lambda x: x > 2)
    assert len(result) == 3

    result = sample.filter(lambda x: x < 2)
    assert len(result) == 1
    assert result.head == 1


# Generated at 2022-06-21 19:10:02.328472
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Arrange
    # Act
    # Assert
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 2) == ImmutableList.of(3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x > 5) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5).filter(lambda x: x < 2) == ImmutableList.of(1)


# Generated at 2022-06-21 19:10:03.894961
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(2, 3).to_list() == [2, 3]


# Generated at 2022-06-21 19:10:05.695346
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert {1, 2}.__eq__(set(ImmutableList.of(1, 2).to_list()))


# Generated at 2022-06-21 19:10:11.861989
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList.of(1, 2, 3, 4)
    list2 = ImmutableList.of(2, 3, 4, 5)
    list3 = list1.filter(lambda x: x % 2 == 0)
    list4 = list2.filter(lambda x: x % 2 == 0)

    assert list1.find(lambda x: x == 5) == None
    assert list1.find(lambda x: x == 3) == 3
    assert list1.find(lambda x: x % 2 == 0) == 2
    assert list2.find(lambda x: x == 6) == None
    assert list2.find(lambda x: x == 4) == 4
    assert list2.find(lambda x: x % 2 == 0) == 2
    assert list3.find(lambda x: x == 8) == None


# Generated at 2022-06-21 19:10:17.629107
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1, 2, 3).append(4)) == 'ImmutableList[1, 2, 3, 4]'

# Generated at 2022-06-21 19:10:22.985066
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 3
    assert len(ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))) == 4


# Generated at 2022-06-21 19:10:29.524142
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    @pytest.fixture
    def mapper():
        return lambda a: a > 5

    @pytest.fixture
    def list_instance():
        return ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)

    def test_filter(list_instance, mapper):
        res_list = list_instance.filter(mapper)
        assert res_list == ImmutableList.of(6, 7, 8, 9)

    def test_filter_empty(list_instance, mapper):
        res_list = list_instance.filter(lambda a: a > 10)
        assert res_list == ImmutableList.empty()

    def test_filter_last(list_instance, mapper):
        res_list = list_instance.filter(lambda a: a > 8)
       

# Generated at 2022-06-21 19:10:33.255264
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2), ImmutableList(3)) == ImmutableList(1, ImmutableList(2), ImmutableList(3))


# Generated at 2022-06-21 19:10:36.889371
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda acc, x: acc + x, 0) == 0
    assert ImmutableList.of(
        10,
        5,
        15,
        5
    ).reduce(lambda acc, x: acc + x, 0) == 35

# Generated at 2022-06-21 19:10:45.796086
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert(list_.find(lambda val: val == 1) == 1)
    assert(list_.find(lambda val: val == 2) == 2)
    assert(list_.find(lambda val: val == 4) == 4)
    assert(list_.find(lambda val: val == 5) == 5)
    assert(list_.find(lambda val: val == 6) is None)


# Generated at 2022-06-21 19:11:28.913589
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3, 4, 5)) == 'ImmutableList[1, 2, 3, 4, 5]'


# Generated at 2022-06-21 19:11:37.252793
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(2, 3, 4) + ImmutableList(5, ImmutableList(6)) == ImmutableList.of(2, 3, 4, 5, 6)
    assert ImmutableList.of(2, 3, 4, 5) + ImmutableList(6) == ImmutableList.of(2, 3, 4, 5, 6)
    assert ImmutableList.of(2, 3, 4) + ImmutableList.of(5, 6) == ImmutableList.of(2, 3, 4, 5, 6)
    assert ImmutableList(2) + ImmutableList(3) + ImmutableList(4) + ImmutableList(5) + ImmutableList(6) \
        == ImmutableList.of(2, 3, 4, 5, 6)

# Generated at 2022-06-21 19:11:41.448783
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-21 19:11:51.727379
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of().__eq__(ImmutableList.of()) is True, 'ImmutableList.__eq__() is failed'
    assert ImmutableList.of(1).__eq__(ImmutableList.of(1)) is True, 'ImmutableList.__eq__() is failed'
    assert ImmutableList.of(1, 2).__eq__(ImmutableList.of(1, 2)) is True, 'ImmutableList.__eq__() is failed'
    assert ImmutableList.of(2).__eq__(ImmutableList.of(1)) is False, 'ImmutableList.__eq__() is failed'
    assert ImmutableList.of(2, 2).__eq__(ImmutableList.of(1, 1)) is False, 'ImmutableList.__eq__() is failed'
    assert ImmutableList

# Generated at 2022-06-21 19:11:56.241360
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    values = ImmutableList([1, 2, "3"])
    assert isinstance(values, ImmutableList)
    assert values.head == [1, 2, "3"]
    assert values.tail == None
    assert values.is_empty == False


# Generated at 2022-06-21 19:12:04.540903
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(2, 3, 4, 5) == ImmutableList.of(1).unshift(2).unshift(3).unshift(4).unshift(5), \
        'Expected ImmutableList.of(2, 3, 4, 5) == ImmutableList.of(1).unshift(2).unshift(3).unshift(4).unshift(5) to be true'


# Generated at 2022-06-21 19:12:06.536274
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert isinstance(ImmutableList(1), ImmutableList)
    assert ImmutableList(1).head == 1


# Generated at 2022-06-21 19:12:16.742504
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.empty().map(lambda x: x + 1) == ImmutableList.empty()
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)

    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4, 5)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 2) == ImmutableList.of(3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3, 4).map(lambda x: x + 3) == ImmutableList.of(4, 5, 6, 7)



# Generated at 2022-06-21 19:12:24.338440
# Unit test for method __add__ of class ImmutableList

# Generated at 2022-06-21 19:12:26.769917
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-21 19:13:48.550132
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    input_list = ImmutableList.of(1, 2, 3)
    result = input_list.find(lambda x: x > 2)
    assert(isinstance(result, int))
    assert(result == 3)
    result = input_list.find(lambda x: x < 0)
    assert(result == None)


# Generated at 2022-06-21 19:13:55.685318
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList(10)) == 1

    assert len(ImmutableList.of(10, 11, 12, 13, 14)) == 5
    assert len(ImmutableList.of(10, 11, 12, 13, 14).unshift(15)) == 6

    assert len(ImmutableList.of(10, 11, 12, 13, 14).append(15)) == 6

# Generated at 2022-06-21 19:13:59.712011
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(is_empty=True) == ImmutableList()
    assert ImmutableList(1) != ImmutableList()
    assert ImmutableList(1) != ImmutableList(2)
    assert ImmutableList(1) == ImmutableList(1)


# Generated at 2022-06-21 19:14:02.574542
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Arrange
    lst = ImmutableList.of(1, 2, 3)
    # Action
    result = lst.to_list()
    # Assert
    assert result == [1, 2, 3]



# Generated at 2022-06-21 19:14:05.081189
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3).tail.to_list() == [2, 3]


# Generated at 2022-06-21 19:14:08.592995
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list1 = ImmutableList.of(1, 2, 3)
    list2 = ImmutableList.of(1, 2, 3)
    list3 = ImmutableList.of(1, 2, 3, 4)
    list4 = ImmutableList.of(1, 2, 10)

    assert list1 == list2
    assert list1 != list3
    assert list3 != list4


# Generated at 2022-06-21 19:14:14.428384
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    a = ImmutableList.of(1)
    assert a.__len__() == 1

    a = ImmutableList.of(1, 2, 3)
    assert a.__len__() == 3

    a = ImmutableList.empty()
    assert a.__len__() == 0

test_ImmutableList___len__()

# Generated at 2022-06-21 19:14:23.405912
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    list_1 = ImmutableList.of(1, 2)
    list_2 = list_1.append(3)

    assert len(list_1) == 2
    assert list_1 == ImmutableList.of(1, 2)
    assert not list_1 == ImmutableList.of(1, 2, 3)

    assert len(list_2) == 3
    assert list_2 == ImmutableList.of(1, 2, 3)
    assert not list_2 == ImmutableList.of(1, 2)

    assert list_2.head == 1
    assert list_2.tail == ImmutableList.of(2, 3)


# Generated at 2022-06-21 19:14:27.562181
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    """
    Function test if ImmutableList method __str__ return proper str value
    """
    assert ImmutableList.of(1, 2, 3, 4).__str__() == 'ImmutableList[1, 2, 3, 4]'



# Generated at 2022-06-21 19:14:35.203742
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of(1,2,3)
    b = ImmutableList.of(4,5,6)
    c = a + b
    assert c.head == 1
    assert c.tail.head == 2
    assert c.tail.tail.head == 3
    assert c.tail.tail.tail.head == 4
    assert c.tail.tail.tail.tail.head == 5
    assert c.tail.tail.tail.tail.tail.head == 6
    assert c.tail.tail.tail.tail.tail.tail is None
    assert c.tail.tail.tail.tail.tail.tail is None

