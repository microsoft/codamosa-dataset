

# Generated at 2022-06-21 19:07:33.730003
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():

    def add_five(value: int) -> int:
        return value + 5

    assert ImmutableList.empty().map(add_five) == ImmutableList.empty()
    assert ImmutableList(2).map(add_five) == ImmutableList(7)
    assert ImmutableList(2, ImmutableList(3)).map(add_five) == ImmutableList(7, ImmutableList(8))
    assert ImmutableList(2, ImmutableList(3, ImmutableList(4))).map(add_five) \
        == ImmutableList(7, ImmutableList(8, ImmutableList(9)))



# Generated at 2022-06-21 19:07:45.732328
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList().find(lambda x: x == 1) is None
    assert ImmutableList(is_empty=True).find(lambda x: x == 1) is None

    assert ImmutableList(1).find(lambda x: x > 1) is None
    assert ImmutableList(1).find(lambda x: x == 1) == 1

    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x > 1) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x > 2) == 3
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).find(lambda x: x > 3) is None


# Generated at 2022-06-21 19:07:49.589755
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # given
    immutable_list = ImmutableList.of(1, 2, 3)
    # when
    l = immutable_list.to_list()
    # then
    assert l == [1, 2, 3]

# Generated at 2022-06-21 19:07:52.129066
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)


# Generated at 2022-06-21 19:07:58.096742
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1, ImmutableList(2)).__eq__(1) == False
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1, ImmutableList(None))) == False


# Generated at 2022-06-21 19:08:01.043803
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    new_list = ImmutableList(4, ImmutableList(5)).unshift(1)
    
    assert new_list.head == 1
    assert new_list.tail == ImmutableList(4, ImmutableList(5))

# Generated at 2022-06-21 19:08:04.901452
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():  # pragma: no cover
    assert ImmutableList.of(1).__eq__(ImmutableList.of(1))
    assert not ImmutableList.of(1).__eq__(ImmutableList.of(2))
    assert not ImmutableList.of(1, 2).__eq__(None)

# Generated at 2022-06-21 19:08:13.829726
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 2) == ImmutableList.of(3, 4)

    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 3) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x < 0) == ImmutableList.empty()
    

# Generated at 2022-06-21 19:08:18.435634
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert(ImmutableList.of(1, 2, 3).reduce(lambda acc, a: acc + a, 0) == 6)
    assert(ImmutableList.of(1, 2, 3).reduce(lambda acc, a: acc * a, 1) == 6)
    assert(ImmutableList.of(1, 2, 3).reduce(lambda acc, a: acc - a, 3) == -3)
test_ImmutableList_reduce()



# Generated at 2022-06-21 19:08:20.738268
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList() == ImmutableList(is_empty=True)
    assert ImmutableList(1) == ImmutableList(1, is_empty=False)



# Generated at 2022-06-21 19:08:33.217475
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.of(1, 2, 3, 4, 5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList() == ImmutableList(is_empty=True)



# Generated at 2022-06-21 19:08:35.561758
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    ilist = ImmutableList.of(1, 2)
    assert ilist.append(3).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:08:45.609812
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    # Test 1
    list1 = ImmutableList.of(1,2,3,4,5)
    assert list1.reduce(lambda acc, x: acc + x, 0) == 15
    
    # Test 2
    list2 = ImmutableList.of('a','b','c')
    assert list2.reduce(lambda acc, x: acc + x, 'z') == 'zabc'
    
    # Test 3
    list3 = ImmutableList.of(1, 2, 3, 4, 5)
    assert list3.reduce(lambda acc, x: acc * x, 1) == 120
    
    # Test 4
    list4 = ImmutableList.of(1, 2, 3, 4, 5)
    assert list4.reduce(lambda acc, x: acc * x, 0) == 0
    

# Generated at 2022-06-21 19:08:57.862175
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.empty().find(lambda x: x) is None
    assert ImmutableList(is_empty=True).find(lambda x: x) is None
    assert ImmutableList(42).find(lambda x: x) == 42
    assert ImmutableList('42').find(lambda x: x) == '42'
    assert ImmutableList(42, ImmutableList(43)).find(lambda x: x) == 42
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))).find(lambda x: x) == 1
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5))))).find(lambda x: x%2 == 0) == 2

# Generated at 2022-06-21 19:09:01.163467
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    expected = ImmutableList(10, ImmutableList(20, ImmutableList(30)))
    result = ImmutableList.of(10, 20).append(30)

    assert result == expected

# Generated at 2022-06-21 19:09:02.801220
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == "ImmutableList[]"



# Generated at 2022-06-21 19:09:05.070960
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'



# Generated at 2022-06-21 19:09:12.313500
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    """
    Checks if filter method of ImmutableList class works properly
    """
    assert ImmutableList.empty().filter(lambda x: x > 100) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x < 3) == ImmutableList.of(1, 2)



# Generated at 2022-06-21 19:09:19.768751
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2)  == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 5)  == None
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 3)  == 3
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 1)  == 1


# Generated at 2022-06-21 19:09:24.688568
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList(1)
    assert ImmutableList(1).unshift(2) == ImmutableList(2, ImmutableList(1))
    assert ImmutableList(1).unshift(2).unshift(3) == ImmutableList(3, ImmutableList(2, ImmutableList(1)))


# Generated at 2022-06-21 19:09:37.437725
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: True) == ImmutableList.empty()
    assert ImmutableList.empty().filter(lambda x: False) == ImmutableList.empty()
    assert ImmutableList.of(1).filter(lambda x: x % 2 == 0) == ImmutableList.empty()
    assert ImmutableList.of(1, 2).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)

# Generated at 2022-06-21 19:09:41.559267
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    empty = ImmutableList.empty()
    not_empty = ImmutableList.of(1, 2, 3)

    assert empty + empty == ImmutableList.empty()
    assert empty + not_empty == ImmutableList.of(1, 2, 3)
    assert not_empty + empty == ImmutableList.of(1, 2, 3)
    assert not_empty + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)


# Generated at 2022-06-21 19:09:43.925664
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-21 19:09:45.797837
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2

test_ImmutableList_find()

# Generated at 2022-06-21 19:09:52.362384
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list1 = ImmutableList(1, ImmutableList(2), ImmutableList(3))
    assert str(list1) == 'ImmutableList[1, 2, 3]'

    list_empty = ImmutableList(is_empty=True)
    assert str(list_empty) == 'ImmutableList[]'

# Generated at 2022-06-21 19:09:54.333753
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)



# Generated at 2022-06-21 19:10:03.434981
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x == 1) == ImmutableList.of(True, False, False)
    assert ImmutableList.of(5).map(lambda x: x ** 2) == ImmutableList.of(25)
    assert ImmutableList.of(5).map(lambda x: x ** 2) == ImmutableList(25)
    assert ImmutableList.empty().map(lambda x: x ** 2) == ImmutableList.empty()



# Generated at 2022-06-21 19:10:08.050001
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList()
    assert ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(3, 4).head == 3
    assert ImmutableList.of(3, 4).tail.head == 4
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]



# Generated at 2022-06-21 19:10:13.083504
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Create ImmutableList instance
    instance = ImmutableList.of(1, 2, 3)
    # Call method
    assert instance.map(lambda x: x*x) == ImmutableList.of(1, 4, 9)


# Generated at 2022-06-21 19:10:22.268482
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList.empty() == ImmutableList(None, None, is_empty=True)

test_ImmutableList()


# Generated at 2022-06-21 19:10:30.317963
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(2, 5, 3)) == "ImmutableList[2, 5, 3]"



# Generated at 2022-06-21 19:10:35.984958
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(1).to_list() == [1]
    assert ImmutableList(1, ImmutableList(2)).to_list() == [1, 2]
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:10:40.581762
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList()) == 'ImmutableList[]'
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:10:48.495890
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list_ = ImmutableList.of(1, 2, 3, 4)

    assert list_.find(lambda element: element == 3) == 3
    assert list_.find(lambda element: element == 10) is None

    unordered_list = ImmutableList.of(1, 2, 3, 4).unshift(5).append(6)

    assert unordered_list.find(lambda element: element == 3) == 3
    assert unordered_list.find(lambda element: element == 10) is None


# Generated at 2022-06-21 19:10:52.247200
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    # Given
    elements = ['value1', 'value2', 'value3']
    # When
    list_of_elements = ImmutableList.of(elements[0], *elements[1:])

    elements_plus_one = ['value_plus_one'] + elements
    list_of_elements_plus_one = ImmutableList \
                                .of(*elements_plus_one)
    # Then
    assert list_of_elements_plus_one == list_of_elements.unshift('value_plus_one')



# Generated at 2022-06-21 19:10:55.031680
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of('a', 'b', 'c', 'd').to_list() == ['a', 'b', 'c', 'd']
    assert ImmutableList.empty().to_list() == []

# Generated at 2022-06-21 19:10:59.938302
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    def add_one(x):
        return x + 1
    assert ImmutableList.of(1, 2, 3).map(add_one).to_list() == [2, 3, 4]
    assert ImmutableList.empty().map(add_one).to_list() == []

# Unit tests for method append of class ImmutableList

# Generated at 2022-06-21 19:11:11.907836
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1).filter(lambda value: value == 1) == ImmutableList.of(1), 'ImmutableList.filter() test failed'

    lst = ImmutableList.of(1, 2, 3, 4, 5)
    assert lst.filter(lambda value: value % 2 == 0).to_list() == [2, 4], 'ImmutableList.filter() test failed'
    assert lst.filter(lambda value: value % 2 == 0).to_list() == [2, 4], 'ImmutableList.filter() test failed'

    assert lst.filter(lambda value: value > 3).to_list() == [4, 5], 'ImmutableList.filter() test failed'

# Generated at 2022-06-21 19:11:16.778335
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    a = ImmutableList.of(1, 2, 3)
    b = ImmutableList.of(4, 5, 6)

    c = a.__add__(b)

    assert c.to_list() == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 19:11:28.625725
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(5) == ImmutableList(5)
    assert ImmutableList(5) + ImmutableList(3) == ImmutableList(5, ImmutableList(3))
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2, 3, 4, 5) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5)))))
    assert ImmutableList.of(1, 2, 3, 4, 5) + ImmutableList(7) == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(5, ImmutableList(7))))))

# Generated at 2022-06-21 19:11:44.256651
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    l = ImmutableList.of(1, 2, 3)
    l2 = l.unshift(0)
    expected_l2 = ImmutableList.of(0, 1, 2, 3)
    assert l2 == expected_l2


# Generated at 2022-06-21 19:11:49.438242
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    list = ImmutableList.empty()
    assert len(list) == 0

    list = ImmutableList.of(1)
    assert len(list) == 1

    list = ImmutableList.of(1, 2)
    assert len(list) == 2

    list = ImmutableList.of(1, 2, 3)
    assert len(list) == 3

# Generated at 2022-06-21 19:11:54.612462
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():

    a = ImmutableList.of(1, 2)
    b = ImmutableList.of(1, 2)

    assert a == b
    assert a is not b
    assert not a ==  ImmutableList.of(1, 2, 3)
    assert not a ==  ImmutableList.empty()


# Generated at 2022-06-21 19:11:56.437059
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    instance = ImmutableList()
    assert instance == ImmutableList(is_empty=True)



# Generated at 2022-06-21 19:12:00.836521
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4)))) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-21 19:12:06.375026
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # arrange
    list1 = ImmutableList.of("element1", "element2", "element3")
    list2 = ImmutableList.of("element1", "element2", "element3")
    list3 = ImmutableList.of("element1", "element2")

    # assert
    assert list1 == list2
    assert not (list1 == list3)


# Generated at 2022-06-21 19:12:09.642932
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    imm_list = ImmutableList(head=0, tail=ImmutableList(1))

    imm_list_mapped = imm_list.map(lambda x: x + 1)
    assert imm_list_mapped == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-21 19:12:16.780211
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # given list and function that find first even number
    elements = [1, 2, 3, 4, 5]
    def find_even(element):
        return element % 2 == 0

    # when ImmutableList is created from elements
    list_of_elements = ImmutableList.of(*elements)

    # then ImmutableList.find returns first even number
    assert list_of_elements.find(find_even) == 2


# Generated at 2022-06-21 19:12:17.695331
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    pass



# Generated at 2022-06-21 19:12:22.797391
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    list_ = ImmutableList.of(1)
    assert list_.to_list() == [1]
    list_ = ImmutableList.empty()
    assert list_.to_list() == []
    list_ = ImmutableList.of(1, 2)
    assert list_.to_list() == [1, 2]
    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.to_list() == [1, 2, 3, 4]

# Generated at 2022-06-21 19:12:38.869540
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-21 19:12:47.331142
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert '__len__' in dir(ImmutableList)
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1).append(1)) == 2
    assert len(ImmutableList(1).append(1).append(1)) == 3
    assert len(ImmutableList.of(1, 1, 1)) == 3
    assert len(ImmutableList.of(1, 1, 1, 1, 1, 1, 1)) == 7
    assert len(ImmutableList()) == 0
    assert len(ImmutableList.empty()) == 0


# Generated at 2022-06-21 19:12:51.677421
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_ = ImmutableList.of('')
    new_list = list_.unshift('element')

    assert len(new_list) == 2
    assert new_list.head == 'element'
    assert new_list.tail.head == ''



# Generated at 2022-06-21 19:12:56.295701
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    expected = ImmutableList.of(2, 4, 6, 8)
    original = ImmutableList.of(2, 3, 4, 5)

    # Act
    result = original.map(lambda x: x * 2)

    # Assert
    assert expected == result


# Generated at 2022-06-21 19:12:59.633879
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    list = ImmutableList.of(1, 2, 3, 4, 5)

    # Act
    actual = list.find(lambda x: x > 2)

    # Assert
    assert(actual == 3)

# Generated at 2022-06-21 19:13:02.998947
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    il = ImmutableList.of(1, 2, 3) + ImmutableList.of(1, 2, 3)
    print(f'{il}')
    assert il == ImmutableList.of(1, 2, 3, 1, 2, 3)
    assert len(il) == 6

# Generated at 2022-06-21 19:13:07.099397
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-21 19:13:11.533445
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 4) is None
    assert ImmutableList.empty().find(lambda x: False) is None

# Generated at 2022-06-21 19:13:14.112410
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    # Create first immutable list
    # Create second immutable list
    # Test adding ImmutableList
    # Test adding anything that is no ImmutableList
    assert False


# Generated at 2022-06-21 19:13:20.236844
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # these are some examples of assertions
    assert ImmutableList().filter(lambda x: True).is_empty
    assert isinstance(ImmutableList.of(0).filter(lambda x: True), ImmutableList)
    assert ImmutableList.of(0).filter(lambda x: True).head == 0
    assert len(ImmutableList.of(0).filter(lambda x: True)) == 1

    assert ImmutableList().filter(lambda x: False).is_empty
    assert isinstance(ImmutableList.of(0).filter(lambda x: False), ImmutableList)
    assert ImmutableList.of(0).filter(lambda x: False).is_empty

    assert ImmutableList.of(0, 1, -1).filter(lambda x: x > 0).to_list() == [0, 1]
    assert ImmutableList.of

# Generated at 2022-06-21 19:13:49.113237
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 5, 10).reduce(
        lambda acc, current: acc + current,
        0,
    ) == 16

    assert ImmutableList.of('a', 'b', 'c').reduce(
        lambda acc, current: acc + current,
        '',
    ) == 'abc'

# Generated at 2022-06-21 19:13:56.277282
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    my_list = ImmutableList()
    assert len(my_list) == 0, 'len of empty list should be zero'

    my_list = ImmutableList.of(1)
    assert len(my_list) == 1, 'len of list with single element should be one'

    my_list = ImmutableList.of(2, 3, 4)
    assert len(my_list) == 3, 'len of list with multiple element should be 3'


# Generated at 2022-06-21 19:14:01.546079
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    def test_append():
        assert(
            ImmutableList.of(1, 2, 3).append(4) == ImmutableList.of(1, 2, 3, 4))
        assert(
            ImmutableList.of(1).append(2) == ImmutableList.of(1, 2))
        assert(
            ImmutableList.of(1).append('a') == ImmutableList.of(1, 'a'))
        assert(
            ImmutableList.empty().append(1) == ImmutableList.of(1))

    test_append()


# Generated at 2022-06-21 19:14:08.593834
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    empty_list = ImmutableList.empty()

    assert ImmutableList(1, ImmutableList(2)) == ImmutableList.of(1, 2)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList.of(1, 2, 3)
    assert ImmutableList(1) + empty_list == ImmutableList.of(1)
    assert ImmutableList.empty() + empty_list == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList(3) + ImmutableList(1, ImmutableList(2)) == ImmutableList.of(3, 1, 2)

# Generated at 2022-06-21 19:14:14.056902
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of().to_list() == []


# Generated at 2022-06-21 19:14:20.339536
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1, 2) == ImmutableList.of(1).append(2)
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1).append(2).append(3)
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1).append(2).append(3).append(4)

# Generated at 2022-06-21 19:14:27.190954
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x % 2 == 0) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2, 3, 4, 5, 6).filter(lambda x: x % 2 == 0) == ImmutableList.of(2, 4, 6)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 3) == ImmutableList.empty()
    assert ImmutableList.of(1, 2, 3, 4).filter(lambda x: x > 3) == ImmutableList.of(4)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 10) == ImmutableList.empty()

# Generated at 2022-06-21 19:14:29.902056
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList(1, ImmutableList(2)).__eq__(ImmutableList(1, ImmutableList(2)))


# Generated at 2022-06-21 19:14:37.823140
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list1 = ImmutableList.of(1)
    list2 = ImmutableList.of(1, 2)
    list3 = ImmutableList.of(1, 2, 3)
    list4 = ImmutableList.of(1, 2, 3, 4)
    list5 = ImmutableList.of(1, 2, 3, 4, 5)
    list6 = ImmutableList.of(1, 2, 3, 4, 5, 6)
    list7 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    list8 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)
    list9 = ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-21 19:14:47.338062
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of(1, 2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList.of(1, 2) != ImmutableList.of(0, 2)
    assert ImmutableList.of(1, 2) != ImmutableList.empty()
    assert ImmutableList.of(1, 2) != ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) != ImmutableList.of(1)


# Generated at 2022-06-21 19:15:41.304879
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 0) == 6

# Generated at 2022-06-21 19:15:46.982981
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList(2).map(lambda e: e + 1) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).map(lambda e: e + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of(1, 2, 3).map(lambda e: e + 1).map(lambda e: e + 1) == ImmutableList.of(3, 4, 5)



# Generated at 2022-06-21 19:15:50.416771
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) != ImmutableList.empty()


# Generated at 2022-06-21 19:15:55.241111
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList.of(1, 2, 3)
    list_2 = ImmutableList.of(4, 5, 6)
    list_3 = list_1 + list_2

    assert list_3.to_list() == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 19:16:00.871352
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():

    assert ImmutableList.empty().to_list() == []
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 19:16:02.731514
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:16:07.224094
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    l = ImmutableList.of(1, 2, 3)
    l_mapped = l.map(lambda v: v * 2)
    assert l_mapped == ImmutableList.of(2, 4, 6)



# Generated at 2022-06-21 19:16:14.546454
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5

# Generated at 2022-06-21 19:16:16.414566
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    mlist = ImmutableList.of(1, 2, 3)
    mlist.map(lambda x: x**2)



# Generated at 2022-06-21 19:16:22.149259
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # arrange
    ImmutableListExample = ImmutableList.of(1,2,3,4,5,6,7,8,9)

    # act
    filteringResult = ImmutableListExample.filter(lambda x: x % 2 == 0)

    # assert
    assert filteringResult == ImmutableList.of(2,4,6,8)
