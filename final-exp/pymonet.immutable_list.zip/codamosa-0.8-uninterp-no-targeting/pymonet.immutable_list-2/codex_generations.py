

# Generated at 2022-06-21 19:07:36.562056
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4


# Generated at 2022-06-21 19:07:41.141175
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1) == ImmutableList(1)
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

test_ImmutableList___eq__()

# Generated at 2022-06-21 19:07:45.573210
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList(is_empty=True) == ImmutableList(is_empty=True)

# Generated at 2022-06-21 19:07:50.451478
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Arrange
    expected = False
    not_expected = True
    new_list = ImmutableList.of(1, 2, 3)
    not_list = "asd"

    # Act
    actual = new_list == not_list

    # Assert
    assert actual == expected
    assert actual != not_expected

# Generated at 2022-06-21 19:07:58.640746
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList() == ImmutableList()
    assert ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert ImmutableList(1) != ImmutableList()
    assert ImmutableList(1) != ImmutableList(2)



# Generated at 2022-06-21 19:08:01.895806
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    list_1 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    list_2 = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert list_1 == list_2
    assert not list_1 == ImmutableList(1, ImmutableList(2, ImmutableList(4)))

# Generated at 2022-06-21 19:08:08.273585
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():

    first_list = ImmutableList()
    second_list = ImmutableList.of(2)
    third_list = ImmutableList.of(1, 2, 3, 4)

    extra_element = 6

    first_list = first_list.append(extra_element)
    second_list = second_list.append(extra_element)
    third_list = third_list.append(extra_element)

    assert first_list.to_list() == [extra_element]
    assert second_list.to_list() == [2, extra_element]
    assert third_list.to_list() == [1, 2, 3, 4, extra_element]

# Generated at 2022-06-21 19:08:14.224350
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of('str')) == 1
    assert len(ImmutableList.of(1,2,3,4)) == 4
    assert len(ImmutableList.of('1','2','3','4','5','6','7')) == 7
    assert len(ImmutableList()) == 0
    assert len(ImmutableList('a', ImmutableList(2))) == 2

# Generated at 2022-06-21 19:08:22.565920
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.empty() == ImmutableList.empty()
    assert ImmutableList.of('abc') == ImmutableList.of('abc')
    assert ImmutableList.of('one', 'two', 'three') == ImmutableList.of('one', 'two', 'three')
    assert ImmutableList.of('one', 'two', 'three') != ImmutableList.of('one', 'two')
    assert ImmutableList.of('one', 'two', 'three') != ImmutableList.of('one', 'two', 'three', 'four')
    assert ImmutableList.of('one', 'two', 'three') != 7

# Generated at 2022-06-21 19:08:24.962777
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(100)) == 'ImmutableList[100]'
    assert str(ImmutableList.of(100, 90, 1)) == 'ImmutableList[100, 90, 1]'

# Generated at 2022-06-21 19:08:33.331807
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_ = ImmutableList.of(1, 2, 3)
    new_list = list_.map(lambda s: s * 2)
    assert new_list == ImmutableList.of(2, 4, 6)

# Generated at 2022-06-21 19:08:39.534499
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, ImmutableList(2))

    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))

    assert ImmutableList() + ImmutableList(1) == ImmutableList(1)

    assert ImmutableList(2) + ImmutableList() == ImmutableList(2)


# Generated at 2022-06-21 19:08:44.179444
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list = ImmutableList.of(1, 2, 3, 4, 5)
    assert len(list) == 5

    even_list = list.filter(lambda n: n%2 == 0)

    assert len(even_list) == 2
    assert ImmutableList.of(2, 4) == even_list



# Generated at 2022-06-21 19:08:47.327024
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 19:09:00.179222
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    empty_list = ImmutableList()
    single_element_list = ImmutableList(1)
    two_elements_list = ImmutableList(1, ImmutableList(2))
    multi_elements_list = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(1)))))
    multi_elements_list_with_empty = ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4, ImmutableList(1, ImmutableList(None))))))
    is_empty_check = lambda i: bool(i)

    assert empty_list.filter(is_empty_check) == ImmutableList(is_empty=True), 'Empty List'
    assert single_element_list.filter(is_empty_check) == single_

# Generated at 2022-06-21 19:09:04.966468
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 2, 3).find(lambda element: element == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda element: element == 3) == 3
    assert ImmutableList.of(1, 2, 3).find(lambda element: element == 4) == None


# Generated at 2022-06-21 19:09:11.402502
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # Test if inicialization of empty list works
    assert ImmutableList.empty() == ImmutableList(is_empty=True)

    # Test if inicialization of not empty list works
    assert ImmutableList.of(1) == ImmutableList(1)

    # Test if inicialization of not empty list works
    assert ImmutableList.of(1, 2, 3) == ImmutableList(1, ImmutableList(2, ImmutableList(3)))



# Generated at 2022-06-21 19:09:15.256173
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    list = ImmutableList.of(1, 10, 100, 1000)

    list_reduced = list.reduce(lambda acc, value: acc + value, 0)
    assert list_reduced == 1111

# Generated at 2022-06-21 19:09:25.778613
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6)) == 6
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7)) == 7
    assert len(ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8)) == 8

# Generated at 2022-06-21 19:09:30.883937
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    list_ = ImmutableList.of(1, 2, 3)

    assert list_.map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)
    assert list_.map(lambda x: x ** 2) == ImmutableList.of(1, 4, 9)

# Generated at 2022-06-21 19:09:40.852160
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    # test that constructor works
    l0 = ImmutableList()
    assert l0.head is None
    assert l0.tail is None
    assert l0.is_empty is True

    l1 = ImmutableList(1)
    assert l1.head == 1
    assert l1.tail is None
    assert l1.is_empty is False

    l2 = ImmutableList(2, l1)
    assert l2.head == 2
    assert l2.tail == l1
    assert l2.is_empty is False


# Generated at 2022-06-21 19:09:46.711339
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    # Arrange
    input = ImmutableList(10, ImmutableList(20, ImmutableList(30)))
    assert len(input) == 3

    input = ImmutableList(10, ImmutableList(20, ImmutableList.empty()))
    assert len(input) == 2

    input = ImmutableList(10)
    assert len(input) == 1

    input = ImmutableList.empty()
    assert len(input) == 0


# Generated at 2022-06-21 19:09:55.404073
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList()
    assert ImmutableList.empty() + ImmutableList(1) == ImmutableList(1)
    assert ImmutableList(1) + ImmutableList(2) == ImmutableList(1, 2)
    assert ImmutableList(1, 2) + ImmutableList(3) == ImmutableList(1, 2, 3)
    assert ImmutableList(1, 2) + ImmutableList(3, 4) == ImmutableList(1, 2, 3, 4)


# Generated at 2022-06-21 19:10:00.028388
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of('a').append('b') == ImmutableList.of('a', 'b')
    assert ImmutableList.of('a', 'b').append('c') == ImmutableList.of('a', 'b', 'c')
    assert ImmutableList.of(3, 3, 3).append(3) == ImmutableList.of(3, 3, 3, 3)

# Generated at 2022-06-21 19:10:05.164775
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert ImmutableList.of(1).__len__() == 1
    assert ImmutableList.of(1, 2, 3).__len__() == 3
    assert ImmutableList.of(1, 2, 3, 4, 5).__len__() == 5
    assert ImmutableList.of().__len__() == 0
    assert ImmutableList.empty().__len__() == 0


# Generated at 2022-06-21 19:10:07.252235
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    list1 = ImmutableList(1, ImmutableList(2),)
    result = list1.find(lambda x: x > 1)
    assert result == 2

# Generated at 2022-06-21 19:10:12.639072
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    # Given an empty list
    test_list = ImmutableList.empty()

    # When you call filter method with argument that returns True
    # then empty list should be returned
    assert test_list.filter(lambda x: True).to_list() == []

    # When you call filter method with argument that returns False
    # then empty list should be returned
    assert test_list.filter(lambda x: False).to_list() == []

    # Given a list with one element
    test_list = ImmutableList.of(1)

    # When you call filter method with argument that returns True
    # then list should be returned
    assert test_list.filter(lambda x: True).to_list() == [1]

    # When you call filter method with argument that returns False
    # then empty list should be returned

# Generated at 2022-06-21 19:10:23.279783
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2).to_list() == [2]
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2).__str__() == 'ImmutableList[2]'
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2).__len__() == 1
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2).__eq__(ImmutableList.of(2))
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x == 2).__add__(ImmutableList.of(2)) == ImmutableList.of(2)

# Generated at 2022-06-21 19:10:29.672999
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of() + ImmutableList.of(2) == ImmutableList.of(2)
    assert ImmutableList.of(1) + ImmutableList.of() == ImmutableList.of(1)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList

# Generated at 2022-06-21 19:10:34.222993
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList(3).to_list() == [3]
    assert ImmutableList(1, ImmutableList(2)) == [1, 2]
    assert ImmutableList() == []

test_ImmutableList_to_list()

# Generated at 2022-06-21 19:10:45.898533
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    def add_one(value):
        return value + 1

    # Act
    result = ImmutableList.of(1, 2, 3).map(add_one)

    # Assert
    expected_result = ImmutableList.of(2, 3, 4)
    assert result == expected_result



# Generated at 2022-06-21 19:10:49.673166
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.empty().reduce(lambda x, y: x + y, 0) == 0

test_ImmutableList_reduce()

# Generated at 2022-06-21 19:10:53.356852
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList().append(4) == ImmutableList(4)
    assert ImmutableList(1).append(4) == ImmutableList(1, ImmutableList(4))
    assert ImmutableList(1, ImmutableList(2)).append(4) == ImmutableList(1, ImmutableList(2, ImmutableList(4)))

# Generated at 2022-06-21 19:10:54.995483
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda x, y: x + y, 0) == 15

# Generated at 2022-06-21 19:10:58.083328
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4) == ImmutableList.of(1, 2, 3, 4)


# Generated at 2022-06-21 19:11:01.510123
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_ = ImmutableList.of(1, 2, 3, 4)
    assert list_.unshift(0) == ImmutableList.of(0, 1, 2, 3, 4)



# Generated at 2022-06-21 19:11:04.871548
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    # Arrange
    actual = ImmutableList.of(1,2,3).to_list()
    expected = [1, 2, 3]

    # Assert
    assert actual == expected



# Generated at 2022-06-21 19:11:13.618999
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    list_of_three = ImmutableList.of(1, 2, 3, 4)
    assert list_of_three.filter(lambda x: x % 2 == 0).to_list() == [2, 4]
    
    list_of_three = ImmutableList.of(1, 2, 3, 4)
    assert list_of_three.filter(lambda x: x % 2 == 1).to_list() == [1, 3]
    
    list_of_three = ImmutableList.of(1, 2, 3, 4)
    assert list_of_three.filter(lambda x: x % 2 == 3).to_list() == []

test_ImmutableList_filter()

# Generated at 2022-06-21 19:11:16.726459
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    il = ImmutableList.of(1, 2, 3, 4)

    assert il.to_list() == [1, 2, 3, 4]



# Generated at 2022-06-21 19:11:21.025881
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():  # pragma: no cover
    list_1 = ImmutableList.of(1, 2, 3, 4)
    list_2 = ImmutableList.of(1, 2, 3, 4)
    list_3 = ImmutableList.of(1, 2, 3, 5)

    assert list_1 == list_2
    assert list_1 != list_3


# Generated at 2022-06-21 19:11:41.802995
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    """
    Test case for method ImmutableList.__add__ of class ImmutableList
    """
    first_list = ImmutableList.of(1, 2, 3)
    second_list = ImmutableList.of(4, 5)
    result_list = first_list + second_list
    assert result_list == first_list.__add__(second_list)
    assert result_list == ImmutableList.of(1, 2, 3, 4, 5)
    assert result_list != ImmutableList.of(1, 2, 3, 4, 5, 6)


# Generated at 2022-06-21 19:11:48.215177
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    result = ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 == 0)
    assert result == 2
    result = ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x % 2 != 0)
    assert result == 1
    result = ImmutableList.of(1, 2, 3, 4, 5).find(lambda x: x == 0)
    assert result is None

# Generated at 2022-06-21 19:11:57.803219
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.empty() + ImmutableList.of(1) == ImmutableList.of(1)
    assert ImmutableList.of(1) + ImmutableList.empty() == ImmutableList.of(1)
    assert ImmutableList.empty() + ImmutableList.empty() == ImmutableList.empty()



# Generated at 2022-06-21 19:12:01.342257
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    new_list = ImmutableList.of(1, 2)
    assert new_list.filter(lambda x: x==2) == ImmutableList.of(2)



# Generated at 2022-06-21 19:12:11.212974
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    list_with_value = ImmutableList(0)
    assert list_with_value == ImmutableList(0)
    assert list_with_value.head == 0
    assert list_with_value.tail == None
    assert list_with_value.is_empty == False
    assert list_with_value.to_list() == [0]
    assert list_with_value.map(lambda x: x ** 2) == ImmutableList(0)
    assert list_with_value.filter(lambda x: x == 0) == ImmutableList(0)
    assert list_with_value.filter(lambda x: x == 1) == ImmutableList(is_empty=True)
    assert list_with_value.find(lambda x: x == 0) == 0

    empty_list = ImmutableList(is_empty=True)


# Generated at 2022-06-21 19:12:15.725087
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    # Setup
    expected = 'ImmutableList[1, 2]'
    actual = ImmutableList.of(1, 2).__str__()

    # Assertion
    assert actual == expected



# Generated at 2022-06-21 19:12:21.383976
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # case where ImmutableList is empty
    assert ImmutableList().map(lambda x: 2 * x).to_list() == []

    # case where ImmutableList has two elements
    assert ImmutableList(10).map(lambda x: 2 * x).to_list() == [20]

    # case where ImmutableList has two nested elements
    assert ImmutableList(10, ImmutableList(20)).map(lambda x: 2 * x).to_list() == [20, 40]



# Generated at 2022-06-21 19:12:24.433800
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList(1) + ImmutableList(2) == \
        ImmutableList(1, ImmutableList(2))
    assert ImmutableList(1, ImmutableList(2)) + ImmutableList(3, ImmutableList(4)) == \
        ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))


if __name__ == '__main__':
    test_ImmutableList___add__()
    print('All tests passed')

# Generated at 2022-06-21 19:12:31.627854
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) + ImmutableList.of(4) == ImmutableList.of(1, 2, 3, 4)

# Generated at 2022-06-21 19:12:38.356765
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1, 2, 3).find(lambda x: x == 10) is None
    assert ImmutableList.empty().find(lambda x: x == 10) is None


# Generated at 2022-06-21 19:13:05.964037
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    a = ImmutableList.of(1, 2, 4)

    # Act
    result = a.find(lambda x : x == 2)

    # Assert
    assert result == 2


# Generated at 2022-06-21 19:13:12.902988
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(2, 3).map(lambda x: x * x) == ImmutableList.of(4, 9)
    assert ImmutableList.of(2).map(lambda x: x * x) == ImmutableList.of(4)
    assert ImmutableList.of(2).map(lambda x: x) == ImmutableList.of(2)
    assert ImmutableList.of(2, 3).map(lambda x: x) == ImmutableList.of(2, 3)

# Generated at 2022-06-21 19:13:22.591002
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList.of(1, 2)
    assert ImmutableList(is_empty=True) == ImmutableList.empty()
    assert ImmutableList(1, ImmutableList(2)).append(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList(1, ImmutableList(2)).unshift(0) == ImmutableList.of(0, 1, 2)
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x * 2) == ImmutableList.of(2, 4)
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).filter(lambda x: x % 2) == ImmutableList.of(1, 3)

# Generated at 2022-06-21 19:13:29.224260
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1,2,3,4).reduce(lambda acc,elem:acc*elem,1)==24
    assert ImmutableList.empty().reduce(lambda acc,elem:acc*elem,1)==1
    assert ImmutableList.of(1,2,3,4).reduce(lambda acc,elem:acc*elem,2)==48
#Testy funkcji filter

# Generated at 2022-06-21 19:13:35.971901
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list = ImmutableList.of(1, 2)
    assert immutable_list.unshift(0) == ImmutableList.of(0, 1, 2)

    immutable_list = ImmutableList.of(1)
    assert immutable_list.unshift(0) == ImmutableList.of(0, 1)

    immutable_list = ImmutableList.empty()
    assert immutable_list.unshift(0) == ImmutableList.of(0)


# Generated at 2022-06-21 19:13:39.206463
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3, 4).append(5).to_list() == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 19:13:42.889237
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    l = ImmutableList.of(1, 2, 3)
    l2 = l.append(4)
    assert l2 == ImmutableList(1, ImmutableList(2, ImmutableList(3, ImmutableList(4))))

# Generated at 2022-06-21 19:13:47.778609
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    x = ImmutableList.of(1, 2, 3)
    assert x.unshift(4) == ImmutableList.of(4, 1, 2, 3), "Should not mutate previous ImmutableList"
    assert x == ImmutableList.of(1, 2, 3), "Should not mutate previous ImmutableList"


# Generated at 2022-06-21 19:13:59.111330
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) != ImmutableList.of(1, 2, 3, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) != ImmutableList.of(1, 2, 3, 4, 5, 7)



# Generated at 2022-06-21 19:14:07.908189
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) == ImmutableList.of(1, 2, 3, 4, 5, 6)
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5, 6) + ImmutableList.of(7, 8, 9) == ImmutableList.of(1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-21 19:15:07.460518
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1).reduce(lambda a, b: a + b, 0) == 1
    assert ImmutableList.of(1, 2).reduce(lambda a, b: a + b, 0) == 3
    assert ImmutableList.of(1, 2, 3).reduce(lambda a, b: a + b, 0) == 6

# Generated at 2022-06-21 19:15:11.733784
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift('a') == ImmutableList('a')
    assert ImmutableList.of(1, 2, 3).unshift('a') == ImmutableList('a', 1, 2, 3)



# Generated at 2022-06-21 19:15:15.765316
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1,2,3).find(lambda x: x == 2) == 2
    assert ImmutableList.of(1,2,3).find(lambda x: x == 4) == None
    assert ImmutableList.empty().find(lambda x: x == 3) == None

# Generated at 2022-06-21 19:15:25.531166
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1) + ImmutableList.of(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1) + ImmutableList.of(2, 3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2) + ImmutableList.of(3, 4) == ImmutableList.of(1, 2, 3, 4)

test_ImmutableList___add__()

# Generated at 2022-06-21 19:15:36.021272
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(2).unshift(1) == ImmutableList.of(1, 2)
    assert ImmutableList.of(3, 4).unshift(1) == ImmutableList.of(1, 3, 4)
    assert ImmutableList.of(3, 4).unshift(1).unshift(2) == ImmutableList.of(2, 1, 3, 4)
    assert ImmutableList.of(3, 4).unshift(1).unshift(2).unshift(3) == ImmutableList.of(3, 2, 1, 3, 4)


# Generated at 2022-06-21 19:15:39.515376
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    immutable_list = ImmutableList.of(1, 2, 3)
    immutable_list = immutable_list.unshift(0)
    assert immutable_list == ImmutableList.of(0, 1, 2, 3)

# Generated at 2022-06-21 19:15:45.712316
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(4) == ImmutableList(4)

    assert ImmutableList(2).unshift(4) == ImmutableList(4, ImmutableList(2))

    assert ImmutableList(2, ImmutableList(10, ImmutableList(15, ImmutableList.empty()))).unshift(4) ==\
        ImmutableList(4, ImmutableList(2, ImmutableList(10, ImmutableList(15, ImmutableList.empty()))))



# Generated at 2022-06-21 19:15:52.914687
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, 2)) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(1, 2, 3)) == 'ImmutableList[1, 2, 3]'
    assert str(ImmutableList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 'ImmutableList[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]'
    assert str(ImmutableList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) == 'ImmutableList[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]'



# Generated at 2022-06-21 19:16:02.037868
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(1, 2).to_list() == [1, 2]
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]
    assert ImmutableList.of(1, 2, 3, 4).to_list() == [1, 2, 3, 4]
    assert ImmutableList.of(1, 2, 3, 4, 5).to_list() == [1, 2, 3, 4, 5]
    assert ImmutableList.empty().to_list() == []


# Generated at 2022-06-21 19:16:05.644732
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    list1 = ImmutableList.of(1,2,3,4)
    assert str(list1) == 'ImmutableList[1, 2, 3, 4]'