

# Generated at 2022-06-21 19:07:32.442617
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1).to_list() == [1]
    assert ImmutableList.of(2, 1).to_list() == [2, 1]
    assert ImmutableList.of(3, 2, 1).to_list() == [3, 2, 1]


# Generated at 2022-06-21 19:07:37.187244
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3).reduce(lambda x, y: x + y, 0) == 6
    assert ImmutableList.of('a', 'b', 'c').reduce(lambda x, y: x + y, '') == 'abc'



# Generated at 2022-06-21 19:07:41.341135
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)



# Generated at 2022-06-21 19:07:44.021355
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3, 4).map(lambda i: i*i) == ImmutableList.of(1, 4, 9, 16)


# Generated at 2022-06-21 19:07:49.958295
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    cases = [
        (ImmutableList(1, ImmutableList(2, ImmutableList(3))), [1, 2, 3]),
        (ImmutableList(), [])
    ]

    for case in cases:
        assert case[0].to_list() == case[1]


if __name__ == '__main__':
    test_ImmutableList()

# Generated at 2022-06-21 19:07:54.791937
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    # Arrange
    list_ = ImmutableList.of(1, 2, 3, 4, 5, 6)

    # Act
    result = list_.find(lambda x: x % 2 == 0)

    # Assert
    assert result == 2



# Generated at 2022-06-21 19:08:00.927599
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList.of(1, 2, 3, 4, 5)
    b = a.reduce(lambda acc, c: acc + c, 0)

    # assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, c: acc + c, 0) == 15
    assert b == 15
    assert ImmutableList.empty().reduce(lambda acc, c: acc + c, 0) == 0


# Generated at 2022-06-21 19:08:07.126656
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list_1 = ImmutableList.of(1, 2, 3, 4)
    list_2 = ImmutableList.of(4, 5, 6, 7)
    result = list_1 + list_2
    assert result == ImmutableList.of(1, 2, 3, 4, 4, 5, 6, 7)
    assert result == ImmutableList.of(1, 2, 3, 4) + ImmutableList.of(4, 5, 6, 7)
    assert result == ImmutableList.of(1, 2, 3, 4) + ImmutableList.of(4, 5, 6, 7)

# Generated at 2022-06-21 19:08:14.213205
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    res = ImmutableList(1).to_list()
    assert res == [1]

    res = ImmutableList.empty().to_list()
    assert res == []

    res = ImmutableList(1, ImmutableList(2, ImmutableList(3))).to_list()
    assert res == [1, 2, 3]
    return True

# Generated at 2022-06-21 19:08:18.172031
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of('first').__eq__(ImmutableList.of('first'))
    assert not ImmutableList.of('first').__eq__(ImmutableList.of('second'))


# Generated at 2022-06-21 19:08:23.405319
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList(1)) == 1
    assert len(ImmutableList(1, ImmutableList(2))) == 2

# Generated at 2022-06-21 19:08:25.810845
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of('foo', 'bar')) == 'ImmutableList[foo, bar]'

# Generated at 2022-06-21 19:08:36.720505
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    l = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    assert(l.head == 1)
    assert(l.tail.head == 2)
    assert(l.tail.tail.head == 3)
    assert(l.tail.tail.tail is None)
    assert(l.tail.tail.is_empty == False)

    l = ImmutableList()
    assert(l.head is None)
    assert(l.tail is None)
    assert(l.is_empty == True)

    l = ImmutableList(1)
    assert(l.head == 1)
    assert(l.tail is None)
    assert(l.is_empty == False)

    l = ImmutableList(is_empty=True)
    assert(l.head is None)

# Generated at 2022-06-21 19:08:39.533564
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    a = ImmutableList(1, ImmutableList(2), ImmutableList(3)).reduce(lambda x,y:x + y, 0)
    assert a == 1 + 2 + 3

# Generated at 2022-06-21 19:08:43.610786
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)
    assert ImmutableList.of(1, 2, 3).unshift(4) == ImmutableList.of(4, 1, 2, 3)


# Generated at 2022-06-21 19:08:45.996694
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
test_ImmutableList_map()

# Generated at 2022-06-21 19:08:48.281621
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1, 1, 2, 3, 5,  8, 13)) == 7

# Generated at 2022-06-21 19:08:52.056812
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.empty()) == 'ImmutableList[]'
    assert str(ImmutableList.of(1,2,4)) == 'ImmutableList[1, 2, 4]'

# Generated at 2022-06-21 19:08:57.246640
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    test_list = ImmutableList.of(1, 2, 3, 4, 5)
    assert test_list.filter(lambda x: x % 2 == 1).to_list() == [1, 3, 5], 'ImmutableList.filter filter even elements'
    

test_ImmutableList_filter()

# Generated at 2022-06-21 19:09:06.313669
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    test1 = ImmutableList()
    assert test1.is_empty == True
    assert test1.head == None
    assert test1.tail == None
    test2 = ImmutableList(1)
    assert test2.is_empty == False
    assert test2.head == 1
    assert test2.tail == None
    test3 = ImmutableList(1, ImmutableList(2), False)
    assert test3.is_empty == False
    assert test3.head == 1
    assert test3.tail.head == 2
    assert test3.tail.tail == None
    assert test3.tail.is_empty == False


# Generated at 2022-06-21 19:09:14.750661
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1).find(lambda x: False) is None



# Generated at 2022-06-21 19:09:25.350690
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    import random
    import unittest
    from collections import deque
    from functools import reduce

    # Random number list
    rand_list = [random.randint(0, 100) for x in range(random.randint(1, 100))]
    # Test number list
    test_list = [random.randint(0, 100) for x in range(random.randint(1, 100))]

    # Makes a function for reduce
    def fn(acc: deque, x: int) -> deque:
        return acc + deque([x])

    # Makes a immutable list of random list
    imm_list = reduce(fn, rand_list, ImmutableList)

    # Makes a immutable list of test list
    test_imm_list = reduce(fn, test_list, ImmutableList)

    # Case of empty list

# Generated at 2022-06-21 19:09:28.489958
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(3) == ImmutableList.of(3, 1)


# Generated at 2022-06-21 19:09:33.405320
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    assert ImmutableList.empty().append(1) == ImmutableList(1)
    assert ImmutableList.of(1).append(2) == ImmutableList.of(1, 2)
    assert ImmutableList.of(1, 2).append(3) == ImmutableList.of(1, 2, 3)


# Generated at 2022-06-21 19:09:36.324870
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert ImmutableList.of(1, 2, 3) + ImmutableList.of(4, 5) == ImmutableList.of(1, 2, 3, 4, 5)


# Generated at 2022-06-21 19:09:42.842327
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    def to_string(x):
        return str(x)
    
    list_one = ImmutableList.of("one")
    list_one_two = ImmutableList.of("one", "two", "three")
    
    assert list_one == ImmutableList("one")
    assert list_one_two == ImmutableList("one", ImmutableList("two", ImmutableList("three")))
    
    assert "one" == list_one.head
    assert None == list_one.tail
    
    assert "one" == list_one_two.head
    assert "two" == list_one_two.tail.head
    assert "three" == list_one_two.tail.tail.head

    assert len(list_one) == 1
    assert len(list_one_two) == 3


# Generated at 2022-06-21 19:09:44.952815
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    # when
    result = ImmutableList.of(1).append(2).to_list()

    # then
    assert result == [1, 2]
    assert len(result) == 2

# Generated at 2022-06-21 19:09:48.069029
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1).to_list() == [2, 3, 4]


# Generated at 2022-06-21 19:09:58.947964
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    # Create args
    v0 = ImmutableList.empty()
    v1 = ImmutableList.empty()
    # Call function
    v2 = v0.__eq__(v1)
    # Check assertions
    assert isinstance(v2, bool)
    assert v2
    # Create args
    v0 = ImmutableList.of(0)
    v1 = ImmutableList.of(1)
    # Call function
    v2 = v0.__eq__(v1)
    # Check assertions
    assert isinstance(v2, bool)
    assert not v2
    # Create args
    v0 = ImmutableList.of(0)
    v1 = ImmutableList.of(0)
    # Call function
    v2 = v0.__eq__(v1)
    # Check assertions

# Generated at 2022-06-21 19:10:03.487147
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.empty().unshift(1) == ImmutableList.of(1)
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)

# Generated at 2022-06-21 19:10:21.838028
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    assert ImmutableList.of(1, 3, 5, 7, 9).find(lambda x: x == 7) == 7
    assert ImmutableList.of(1).find(lambda x: x == 1) == 1
    assert ImmutableList.empty().find(lambda x: x == 1) == None


# Generated at 2022-06-21 19:10:24.971043
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(4) == ImmutableList.of(4)
    assert ImmutableList.of(4, 5) == ImmutableList.of(4, 5)
    assert ImmutableList.of(4, 5) != ImmutableList.of(4)

# Generated at 2022-06-21 19:10:26.816833
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2).to_list() == [2, 1], 'ImmutableList failed in unshift'


# Generated at 2022-06-21 19:10:38.046204
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    from unittest import TestCase

    class ImmutableListTest(TestCase):
        def setUp(self):
            self.immutable_list = ImmutableList.of(1, 2, 3, 4, 5)

        def test_init(self):
            self.assertEqual(
                self.immutable_list.to_list(),
                [1, 2, 3, 4, 5],
                'ImmutableList constructor got wrong arguments'
            )

        def test_add(self):
            test_list2 = ImmutableList.of(6, 7, 8)

            self.assertEqual(
                (self.immutable_list + test_list2).to_list(),
                [1, 2, 3, 4, 5, 6, 7, 8],
                'ImmutableList add method got wrong arguments'
            )



# Generated at 2022-06-21 19:10:44.252865
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    def add(x: int, y: int) -> int:
        return x + y

    assert ImmutableList.of(1).reduce(add, 0) is 1
    assert ImmutableList.empty().reduce(add, 0) is 0
    assert ImmutableList.of(1, 2, 3).reduce(add, 0) is 6



# Generated at 2022-06-21 19:10:47.247937
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3)\
        .map(lambda x: x + 1)\
        .to_list() == [2, 3, 4]



# Generated at 2022-06-21 19:10:52.967701
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, x: acc + x, 0) == 15
    assert ImmutableList.of(1, 2, 3, 4, 5).reduce(lambda acc, x: acc * x, 1) == 120
    assert ImmutableList.empty().reduce(lambda acc, x: acc + x, 0) == 0
    assert ImmutableList.empty().reduce(lambda acc, x: acc * x, 1) == 1

# Generated at 2022-06-21 19:10:58.906333
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    int_list = ImmutableList.of(1, 2, 3)
    float_list = ImmutableList.of(1.1, 2.2, 3.3)

    assert int_list.map(lambda x: x * 2) == ImmutableList.of(2, 4, 6)
    assert float_list.map(lambda x: x * 2) == ImmutableList.of(2.2, 4.4, 6.6)



# Generated at 2022-06-21 19:11:01.612830
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    assert ImmutableList.of(1, 2, 3).to_list() == [1, 2, 3]



# Generated at 2022-06-21 19:11:04.007986
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList.of(1, 2, 3)) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:11:33.529431
# Unit test for method find of class ImmutableList
def test_ImmutableList_find():
    ilist = ImmutableList.of(1, 2, 3, 4, 5, 6, 7)
    assert ilist.find(lambda x: x == 6) == 6
    assert ilist.find(lambda x: x > 8) is None



# Generated at 2022-06-21 19:11:38.991049
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list_ = ImmutableList.of(3)

    list2_ = list_.unshift(5)

    assert list2_.to_list() == [5, 3]

    list3_ = list2_.unshift(7)

    assert list3_.to_list() == [7, 5, 3]


# Generated at 2022-06-21 19:11:44.032779
# Unit test for method __str__ of class ImmutableList
def test_ImmutableList___str__():
    assert str(ImmutableList(1)) == 'ImmutableList[1]'
    assert str(ImmutableList(1, ImmutableList(2))) == 'ImmutableList[1, 2]'
    assert str(ImmutableList(1, ImmutableList(2, ImmutableList(3)))) == 'ImmutableList[1, 2, 3]'


# Generated at 2022-06-21 19:11:48.409052
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    assert ImmutableList.empty() == ImmutableList(is_empty=True)
    assert ImmutableList(1, ImmutableList(2)) == ImmutableList.of(1, 2)
    assert ImmutableList('A', 'B') == ImmutableList.of('A', 'B')


# Generated at 2022-06-21 19:11:52.536898
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    my_list = ImmutableList.of(1, 2, 3, 4)
    my_mapped_list = my_list.map(lambda x: x + 10)

    assert [11, 12, 13, 14] == my_mapped_list.to_list()


# Generated at 2022-06-21 19:11:59.681821
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    from nose.tools import assert_equal

    lst = ImmutableList()
    assert_equal(lst.empty(), ImmutableList())
    assert_equal(lst.reduce(lambda x, y: x + y, 0), 0)

    lst = ImmutableList.of(1)
    assert_equal(lst.reduce(lambda x, y: x + y, 0), 1)

    lst = ImmutableList.of(1, 2, 3)
    assert_equal(lst.reduce(lambda x, y: x + y, 0), 6)



# Generated at 2022-06-21 19:12:09.812903
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    lst = ImmutableList.of(1, 2, 3)
    res = lst.filter(lambda x: x % 2 == 0)
    print(res)
    assert res == ImmutableList.of(2)

    lst = ImmutableList.of(1, 2, 3)
    res = lst.filter(lambda x: x % 2 == 1)
    print(res)
    assert res == ImmutableList.of(1, 3)

    lst = ImmutableList.of(1, 2, 3)
    res = lst.filter(lambda x: x % 2 == 1)
    print(res)
    assert res == ImmutableList.of(1, 3)

    lst = ImmutableList.of(1, 2, 3)

# Generated at 2022-06-21 19:12:15.678833
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(0) == ImmutableList.of(0, 1)
    assert ImmutableList.of(1, 2).unshift(0) == ImmutableList.of(0, 1, 2)
    assert ImmutableList.empty().unshift(0) == ImmutableList.of(0)


# Generated at 2022-06-21 19:12:22.266342
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    assert ImmutableList.of(1, 2, 3, 4) == ImmutableList.of(1, 2, 3, 4)

    assert ImmutableList.of(1, 2, 3, 4) != ImmutableList.of(1, 2, 3, 5)

    assert ImmutableList.of(1, 2, 3, 4) != ImmutableList.of(1, 2, 3)

    assert ImmutableList.of(1, 2, 3, 4) != ImmutableList.of(1, 2, 4, 3)

    assert ImmutableList.empty() == ImmutableList.empty()



# Generated at 2022-06-21 19:12:24.197880
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    list1 = ImmutableList(1)
    list2 = ImmutableList(2)
    assert (list1 + list2) == ImmutableList(1, ImmutableList(2))

# Generated at 2022-06-21 19:13:18.437450
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    list = ImmutableList.of(1, 2, 3)
    assert list.unshift(42).to_list() == [42, 1, 2, 3]


# Generated at 2022-06-21 19:13:23.233818
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    # Arrange
    list_ = ImmutableList(["first", "second", "third", "fourth"])

    # Act
    result = list_.map(lambda x: x + " element")

    # Assert
    expected = ImmutableList(["first element", "second element", "third element", "fourth element"])
    assert result == expected, "Expected {}, got {}".format(expected, result)


# Generated at 2022-06-21 19:13:34.247306
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    def add(x, y):
        return x + y

    assert ImmutableList.empty().reduce(add, 0) == 0
    assert ImmutableList.of(1).reduce(add, 0) == 1
    assert ImmutableList.of(1, 2, 3, 4).reduce(add, 0) == 10

    
    def concat(string, item):
        return string + str(item)

    assert ImmutableList.empty().reduce(concat, '') == ''
    assert ImmutableList.of(1).reduce(concat, '') == '1'
    assert ImmutableList.of(1, 2, 3, 4).reduce(concat, '0') == '01234'


# Generated at 2022-06-21 19:13:38.402630
# Unit test for method __eq__ of class ImmutableList
def test_ImmutableList___eq__():
    x = ImmutableList.of(1, 2, 3)
    y = ImmutableList.of(1, 2, 3)
    z = ImmutableList.of(4, 5, 6)
    assert (x == y) is True
    assert (x == z) is False
    assert (y == z) is False


# Generated at 2022-06-21 19:13:42.034648
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    assert ImmutableList.of(1).unshift(2) == ImmutableList.of(2, 1)
    assert ImmutableList.of(1, 2).unshift(3) == ImmutableList.of(3, 1, 2)

# Generated at 2022-06-21 19:13:47.074193
# Unit test for method append of class ImmutableList
def test_ImmutableList_append():
    lst = ImmutableList()
    lst_1 = lst.append(1)
    lst_1_2 = lst.append(2)

    assert lst == ImmutableList()
    assert lst_1 == ImmutableList(1)
    assert lst_1_2 == ImmutableList(2)


# Generated at 2022-06-21 19:13:58.995284
# Unit test for constructor of class ImmutableList
def test_ImmutableList():
    print('> test_ImmutableList')

    myList = ImmutableList(1, ImmutableList(2, ImmutableList(3)))
    print(myList)
    myList = myList.append(4)
    print(myList)
    myList = myList.unshift(-1)
    print(myList)
    myList = myList.map(lambda x: x + 1)
    print(myList)
    myList = myList.map(lambda x: x * 2)
    print(myList)
    myList = myList.filter(lambda x: x % 2 == 0)
    print(myList)
    myList = myList.find(lambda x: x == 10)
    print(myList)
    myList = myList.find(lambda x: x == 20)

# Generated at 2022-06-21 19:14:00.946488
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    obj = ImmutableList.of(1, 2, 3)
    assert isinstance(obj, ImmutableList)
    res = obj.reduce(lambda a, b: a + b, 0)
    assert res == 6

# Generated at 2022-06-21 19:14:03.899194
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList(1, ImmutableList(2)).map(lambda x: x ** 2) == ImmutableList(1, ImmutableList(4))
    assert ImmutableList.empty().map(lambda x: x ** 2) == ImmutableList.empty()

# Generated at 2022-06-21 19:14:07.567844
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.of(1)) == 1
    assert len(ImmutableList.of(1, 2)) == 2
    assert len(ImmutableList.of(1, 2, 3)) == 3
    assert len(ImmutableList.of(1, 2, 3, 4)) == 4
    assert len(ImmutableList.of(1, 2, 3, 4, 5)) == 5



# Generated at 2022-06-21 19:16:14.077266
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)
    assert ImmutableList.of('1', 2, 3).map(lambda x: type(x)) == ImmutableList.of(str, int, int)




# Generated at 2022-06-21 19:16:19.101741
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    assert ImmutableList.empty().filter(lambda x: x < 10) == ImmutableList.empty()

    assert ImmutableList.of(1, 2, 3).filter(lambda x: x < 10) == ImmutableList.of(1, 2, 3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 2) == ImmutableList.of(3)
    assert ImmutableList.of(1, 2, 3).filter(lambda x: x > 10) == ImmutableList.empty()



# Generated at 2022-06-21 19:16:24.632999
# Unit test for method to_list of class ImmutableList
def test_ImmutableList_to_list():
    
    obj = ImmutableList.of(1, 2, 3)
    obj2 = ImmutableList.of(1).append(2).append(3)
    
    assert obj.to_list() == [1, 2, 3]
    assert obj2.to_list() == [1, 2, 3]


# Generated at 2022-06-21 19:16:33.669584
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    assert ImmutableList.empty().reduce(lambda acc, _: acc + 1, 0) == 0
    assert ImmutableList(1).reduce(lambda acc, _: acc + 1, 0) == 1
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda acc, _: acc + 1, 0) == 2
    assert ImmutableList(1, ImmutableList(2, ImmutableList(3))).reduce(lambda acc, _: acc + 1, 0) == 3

    assert ImmutableList(1).reduce(lambda acc, x: acc + x, 0) == 1
    assert ImmutableList(1, ImmutableList(2)).reduce(lambda acc, x: acc + x, 0) == 3

# Generated at 2022-06-21 19:16:38.379824
# Unit test for method unshift of class ImmutableList
def test_ImmutableList_unshift():
    empty_list = ImmutableList.empty()
    new_list = ImmutableList.of(1, 2, 3)
    new_new_list = new_list.unshift(0)
    assert new_new_list.to_list() == [0, 1, 2, 3]
    new_new_new_list = new_new_list.unshift(-1)
    assert new_new_new_list == ImmutableList.of(-1, 0, 1, 2, 3)
    assert new_new_new_list.tail != new_new_list
    assert new_new_new_list.tail.tail != new_list
    assert new_new_new_list.tail.tail.tail == empty_list

# Generated at 2022-06-21 19:16:43.031668
# Unit test for method filter of class ImmutableList
def test_ImmutableList_filter():
    elements = [1, 2, 3, 4]
    il = ImmutableList.of(elements[0], *elements[1:])
    filtered = il.filter(lambda x: x % 2 == 0)
    assert filtered == ImmutableList.of(2, 4)


# Generated at 2022-06-21 19:16:46.203172
# Unit test for method __len__ of class ImmutableList
def test_ImmutableList___len__():
    assert len(ImmutableList.empty()) == 0
    assert len(ImmutableList.of(5)) == 1
    assert len(ImmutableList.of(1, 2, 3)) == 3

# Generated at 2022-06-21 19:16:51.948928
# Unit test for method map of class ImmutableList
def test_ImmutableList_map():
    assert ImmutableList.of(1).map(lambda x: x + 1) == ImmutableList.of(2)
    assert ImmutableList.of(1, 2).map(lambda x: x + 1) == ImmutableList.of(2, 3)
    assert ImmutableList.of(1, 2, 3).map(lambda x: x + 1) == ImmutableList.of(2, 3, 4)



# Generated at 2022-06-21 19:16:54.427517
# Unit test for method reduce of class ImmutableList
def test_ImmutableList_reduce():
    param = ImmutableList.of(1, 2, 3)

    expected = 6
    actual = param.reduce(lambda x, y: x + y, 0)

    assert actual == expected

# Generated at 2022-06-21 19:16:58.408640
# Unit test for method __add__ of class ImmutableList
def test_ImmutableList___add__():
    assert (ImmutableList(0, ImmutableList(1, ImmutableList(2))) == ImmutableList.of(0, 1, 2))
    assert (ImmutableList(0, ImmutableList(1, ImmutableList(2))) == ImmutableList.of(0, 1, 2))
