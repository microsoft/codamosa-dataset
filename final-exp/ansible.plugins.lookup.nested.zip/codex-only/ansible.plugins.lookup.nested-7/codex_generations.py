

# Generated at 2022-06-23 11:49:35.444306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_lines = [b'$ANSIBLE_VAULT;1.1;AES256']
    key = b'0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'
    vault = VaultLib([key])
    vaultsecret = VaultSecret(vault_lines, None, None, key, None)
    vault.secrets[None] = vaultsecret

    lookup_module = LookupModule(loader=None, templar=None)

    vault_lookup_plugin_terms = ['@vault.yml']
    vault_terms = lookup_module._lookup_variables

# Generated at 2022-06-23 11:49:36.812220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert(a != None)


# Generated at 2022-06-23 11:49:39.689482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """test_nested_lookup_module.test_constructor()
    """
    lo = LookupModule()
    assert lo._loader == None
    assert lo._templar == None

# Generated at 2022-06-23 11:49:45.391417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [['a', 'b'], ['c', 'd', 'e']]
    result = lookup_module.run(terms)
    assert result == [['a', 'c'], ['a', 'd'], ['a', 'e'], ['b', 'c'], ['b', 'd'], ['b', 'e']]

# Generated at 2022-06-23 11:49:53.373312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # this is a quick unit test for method run of class LookupModule.
    args = [
        ['alice', 'bob'],
        ['clientdb', 'employeedb', 'providerdb']
    ]
    expected_result = [
        ['alice', 'clientdb'],
        ['alice', 'employeedb'],
        ['alice', 'providerdb'],
        ['bob', 'clientdb'],
        ['bob', 'employeedb'],
        ['bob', 'providerdb']
    ]
    result = LookupModule().run(args, None)
    assert result == expected_result


# Generated at 2022-06-23 11:49:54.528631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:50:06.716544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # A source that contains a list of lists
    # This is the core of the nested lookup
    source = [ ['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'] ]

    # The terms parameter is the list which contains the above source
    terms = [source]

    # No variables to use in testing
    variables = None

    # Create a LookupModule object
    lookup_obj = LookupModule()

    # Create a list of users that have access to multiple databases
    user_db_access = lookup_obj.run(terms, variables)

    # Check that the list that is returned is the same as the expected list

# Generated at 2022-06-23 11:50:10.060900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    assert LookupModule(None,{})



# Generated at 2022-06-23 11:50:19.552979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init lookupModule with list of path to Ansible config file
    lookup_plugin = LookupModule([])

    # Setting a variable 'users' in variable 'variable'
    variable = {
        'users': ['john', 'jack']
    }
    # Build result for the following terms:
    # [
    #   [
    #     'users',
    #     [
    #       'clientdb',
    #       'employeedb',
    #       'providerdb',
    #     ],
    #   ],
    # ]

# Generated at 2022-06-23 11:50:25.515029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pickle
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    lu = LookupModule()

    # Method run should return one result when input is one list
    assert lu.run(["first","second","third"]) == \
    [["first"], ["second"], ["third"]], \
    "Method run returns one result when input is one list"

    # Method run should return one result when input is one list
    assert lu.run([["first", "second"], ["third"]]) == \
    [["first", "third"], ["second", "third"]], \
    "Method run returns one result when input is one list"

    # Method run should return one result when input is one list

# Generated at 2022-06-23 11:50:27.453818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not hasattr(LookupModule, '_lookup_variables')



# Generated at 2022-06-23 11:50:30.451163
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [ ['key1', 'key2'], ['value1', 'value2', 'value3'] ]
    lm = LookupModule()
    result = lm.run(terms)
    assert terms == result

# Generated at 2022-06-23 11:50:32.117777
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:50:33.726022
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()

    assert module is not None



# Generated at 2022-06-23 11:50:44.539256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Returns the following list:

    [["x1", "x2", "x3"], ["x1", "x2", "x4"], ["x1", "x2", "x5"], ["x1", "x3", "x4"], ["x1", "x3", "x5"], ["x1", "x4", "x5"], ["x2", "x3", "x4"], ["x2", "x3", "x5"], ["x2", "x4", "x5"], ["x3", "x4", "x5"]]

    """
    list1 = ["x1", "x2", "x3", "x4", "x5"]
    list2 = ["x1", "x2", "x3", "x4", "x5"]

# Generated at 2022-06-23 11:50:51.461899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = [{'alice': ['clientdb', 'employeedb', 'providerdb']}, {'bob': ['clientdb', 'employeedb', 'providerdb']}]
    lookup_plugin = LookupModule()
    actual = lookup_plugin.run([['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']], templar=None, loader=None)
    assert results == actual


# Generated at 2022-06-23 11:50:59.806649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['./test/inventory'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 11:51:00.804227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:51:02.605677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:51:04.746123
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Unit test fro run method of class LookupModule

# Generated at 2022-06-23 11:51:16.146507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ##########################################################################################
    #
    # Tested class : LookupModule
    # Tested method : run    
    # Also tested : LookupBase.run
    #
    ##########################################################################################

    # 1. Initialization
    my_lookup = LookupModule()
    # 2. Testing
    # 2.1. load_contents_if_required is not changed in test mode because it is set to false by default
    assert my_lookup.load_contents_if_required == False
    # 2.2. run is tested with null parameter
    raw_result_nested_1 = my_lookup.run([])
    assert raw_result_nested_1 == []
    # 2.3. run is tested with one parameter

# Generated at 2022-06-23 11:51:20.079854
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    test_lookup.run()
    test_lookup.__class__
    assert test_lookup is not None
    test_lookup.run([])
    test_lookup.run([[]])

# Generated at 2022-06-23 11:51:21.923434
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupModule))

# Generated at 2022-06-23 11:51:23.331084
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = lookup_loader.get('nested')
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:51:24.427614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lup = LookupModule()
    assert lup is not None


# Generated at 2022-06-23 11:51:29.766199
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    lookup_plugin_args = dict(format='RFC',  tz='UTC')
    params = dict(variables=dict(), search_path=None, convert_data=False, config=dict())
    res = lookup_module.run([],
                            variables=dict(
                                ansible_env_path='/usr/bin:/bin',
                                ansible_env_python='/usr/bin/python',
                                ansible_env_vars={'PATH': '/usr/bin:/bin'}),
                            **params)

# Generated at 2022-06-23 11:51:34.863226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)
    assert hasattr(lm, 'run')
    assert hasattr(lm, '_combine')
    assert hasattr(lm, '_flatten')

# Generated at 2022-06-23 11:51:37.278530
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:51:45.960710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method LookupModule.run
    """
    terms = [
            [ 1, 2, 3 ],
            [ 'a', 'b', 'c' ]
    ]
    test_obj = LookupModule()
    assert [ [1,'a'], [1,'b'], [1,'c'], [2,'a'], [2,'b'], [2,'c'], [3,'a'], [3,'b'], [3,'c'] ] == test_obj.run(terms, None)


# Generated at 2022-06-23 11:51:54.339781
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("running test_LookupModule_run")

    class TestTemplar():
        def __init__(self):
            self.test_list = []
        def template(self, a):
            self.test_list.append(a)
            return a

    class TestLoader():
        def __init__(self):
            self.test_list = []
        def load(self, a, b, c):
            self.test_list.append(a)
            return a

    class TestVariables():
        def __init__(self):
            self.test_list = []
            self.resp = []
            self.resp.append("term1")
            self.resp.append("term2")
        def get(self, a, b):
            self.test_list.append(a)
            return self.resp

# Generated at 2022-06-23 11:51:55.233689
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("In test_LookupModule")
    assert True

# Generated at 2022-06-23 11:52:06.238472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup.nested import LookupModule
    from ansible.utils.listify import listify_lookup_plugin_terms

    my_list = [ [u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb'] ]
    # my_list = [ ['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'] ]
    # my_list = [ AnsibleUnicode(value='alice'), AnsibleUnicode(value='bob'), AnsibleUnicode(value='clientdb'), AnsibleUnicode(value='employeedb'), AnsibleUnicode(value='providerdb') ]
    # my_list =

# Generated at 2022-06-23 11:52:15.690636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setUp
    import sys
    import os
    import __main__ as main

    main.GS_LOOKUP_PLUGINS = os.path.join(os.path.dirname(__file__), '..', '..', 'lookup_plugins')
    sys.path.insert(0, main.GS_LOOKUP_PLUGINS)

    from nested import LookupModule

    test_cases = [
        {
        'terms': [[1, 2], [3, 4]],
        'expected_result': [[1, 3], [1, 4], [2, 3], [2, 4]],
        'description' : 'Two lists of two elements each',
        },
    ]

    lk = LookupModule()

# Generated at 2022-06-23 11:52:16.185418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:52:22.985008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(["{{ item[0] }}", ["alice", "bob"]])
    assert result == [[u'alice'], [u'bob']]
    result = LookupModule().run([["alice", "bob"], ["foo", "bar"]])
    assert result == [[u'alice', u'foo'], [u'alice', u'bar'], [u'bob', u'foo'], [u'bob', u'bar']]

# Generated at 2022-06-23 11:52:23.633153
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:52:31.047140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]
    assert lookup_module.run([[1], [4, 5, 6], [7, 8]]) == [[1, 4, 7], [1, 4, 8], [1, 5, 7], [1, 5, 8], [1, 6, 7], [1, 6, 8]]

# Generated at 2022-06-23 11:52:32.472439
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:52:41.761142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test case for method run of class LookupModule
    '''
    lookup = LookupModule()
    lookup._templar = MockTemplar()
    lookup._loader = MockLoader()
    with pytest.raises(AnsibleError) as exec_info:
        lookup.run(terms=[], variables=None, **{})
    assert "with_nested requires at least one element" in exec_info.value.__str__()

    # Case 1: First level list returns a flat list
    lookup = LookupModule()
    lookup._templar = MockTemplar()
    lookup._loader = MockLoader()
    result = lookup.run(terms=[[1, 2, 3], [4, 5, 6]], variables=None, **{})

# Generated at 2022-06-23 11:52:47.244949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()

    return_value = t.run(terms=[[1, 2], ["a", "b", "c"]], variables=None, **{})

    assert(return_value == [[1, 'a'], [1, 'b'], [1, 'c'], [2, 'a'], [2, 'b'], [2, 'c']])

# Generated at 2022-06-23 11:52:51.708905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    result = test_object.run([['username1', 'username2', 'username3'], ['groupname1', 'groupname2', 'groupname3']], [])
    assert len(result) == 9
    assert ['username1', 'groupname1'] in result
    assert ['username2', 'groupname2'] in result
    assert ['username3', 'groupname3'] in result


# Generated at 2022-06-23 11:52:56.452803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule._combine = lambda x,y:x
    LookupModule._flatten = lambda x:x
    input_list = [["a","b","c"],["1","2","3"],["x","y","z"]]
    lu_module = LookupModule()
    assert lu_module.run(input_list) == input_list

# Generated at 2022-06-23 11:52:58.497511
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-23 11:53:06.855001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    lookup_module = LookupModule()

    # Test for lookup with correct arguments
    terms = [
        [
            "{{ansible_user}}",
            "{{ansible_host}}"
        ],
        [
            "root",
            "localhost"
        ]
    ]
    try:
        result = lookup_module.run(terms, variables=None)
        assert type(terms) == list
        assert result == [['root', 'localhost']]
    except Exception as e:
        raise e

    # Test for lookup with incorrect arguments
    terms = [
        [], [], []
    ]

# Generated at 2022-06-23 11:53:13.234018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for normal case
    lookup = LookupModule()
    term = ['a','b','c']
    result = lookup.run(term)
    assert result == [['a', 'b', 'c']]
    term = []
    # test for empty case
    try:
        lookup.run(term)
    except AnsibleError as e:
        assert e.message == "with_nested requires at least one element in the nested list"

# Generated at 2022-06-23 11:53:14.977635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 11:53:17.566771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [[["a", "b"], ["c"]], ["d"]]
    my_result = LookupModule().run(my_list)
    my_assertion = [['a', 'd'], ['b', 'd'], ['c', 'd']]
    assert my_result == my_assertion, "results do not match"


# Generated at 2022-06-23 11:53:19.166455
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:53:20.484540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:53:27.410887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = [['alice','bob'],
             ['clientdb','employeedb','providerdb']]

    result = lookup.run(terms)
    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'],
                      ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

# Generated at 2022-06-23 11:53:36.484516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with empty parameters
    try:
        result = lookup_module.run([], {})
        assert False, 'empty parameters'
    except AnsibleError as e:
        assert 'with_nested requires at least one element in the nested list' == e.args[0]
    # Test with a single set of lists
    result = lookup_module.run([['a', 'b', 'c'], ['1', '2']], {})
    assert result == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2'], ['c', '1'], ['c', '2']]
    # Test with a single list
    result = lookup_module.run([['a', 'b', 'c']], {})

# Generated at 2022-06-23 11:53:38.916898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = [["foo", "bar"], ["baz"]]
    l = LookupModule()
    l.run(t)

# Generated at 2022-06-23 11:53:40.982036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Constructor test for class LookupModule")
    LookupModule()


# Generated at 2022-06-23 11:53:52.381129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # A test lookup plugin.
    lm = LookupModule()

    # A simple test.
    terms = [["a", "b"], ["c", "d"]]
    x = lm.run(terms, variables=None, **{})
    assert x == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]

    # A test with defined variables.
    my_variables = {
        'a': ['b', 'c'],
        'd': 'e'
    }
    terms = [["b", "c"], ["{{d}}"]]
    x = lm.run(terms, variables=my_variables, **{})

# Generated at 2022-06-23 11:53:53.257315
# Unit test for constructor of class LookupModule
def test_LookupModule():
    p=LookupModule()


# Generated at 2022-06-23 11:53:55.357416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj._templar is not None
    assert obj._loader is not None

# Generated at 2022-06-23 11:54:01.241410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()
    # Setup the class with a database to run the tests against
    test_class.set_options({}) # this should be the same options as the one in the plugin
    terms = [
        [ 'employee', 'client', 'provider' ],
        [ '1000', '2000', '3000' ],
    ]
    results = [
        [ 'employee1000', 'client1000', 'provider1000' ],
        [ 'employee2000', 'client2000', 'provider2000' ],
        [ 'employee3000', 'client3000', 'provider3000' ],
    ]
    assert test_class.run(terms, variables=None) == results


# Generated at 2022-06-23 11:54:02.355001
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert True

# Generated at 2022-06-23 11:54:03.332904
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 11:54:04.524180
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert instance is not None

# Generated at 2022-06-23 11:54:09.229796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = ["{{outer1}}", "{{outer2}}"]
    terms = (args, dict())

    l = LookupModule()
    l._combine = lambda a, b: [a]
    l._flatten = lambda a: a
    l._lookup_variables = lambda a, b: a

    r = l.run(*terms)
    assert r == args

# Generated at 2022-06-23 11:54:13.848510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DummyModule(object):
        def __init__(self):
            self.params = {}
    C = LookupModule(DummyModule())
    assert C


# Unit tests for method LookupModule._combine

# Generated at 2022-06-23 11:54:14.858212
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:54:16.240640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# helper function

# Generated at 2022-06-23 11:54:25.000117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [["root"], ["host1", "host2"]]
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == [["root", "host1"], ["root", "host2"]]

    # test_2
    terms = [[], ["root"], ["host1", "host2"]]
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == [["root", "host1"], ["root", "host2"]]

    # test_3
    terms = [["root", "host2"], ["host1", "host2"]]
    lookup_module = LookupModule()
    result = lookup_module.run(terms)

# Generated at 2022-06-23 11:54:34.796772
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dummy = LookupModule()
    assert dummy.run([]) == []
    assert dummy.run([[], []]) == []
    assert dummy.run([[], ['a', 'b']]) == [['a'], ['b']]
    assert dummy.run([['a', 'b'], ['1', '2']]) == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2']]

# Generated at 2022-06-23 11:54:36.026743
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()


# Generated at 2022-06-23 11:54:38.130238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert("lookup_module" == type(lookup_module).__module__)

# Generated at 2022-06-23 11:54:47.323111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a instance of class LookupModule
    lookup = LookupModule()
    assert lookup.run(
        [
            {
                "with_nested": [
                    [
                        "alice",
                        "bob"
                    ],
                    [
                        "clientdb",
                        "employeedb",
                        "providerdb"
                    ]
                ]
            }
        ]
    ) == [["alice", 'clientdb'], ["alice", 'employeedb'], ["alice", 'providerdb'], ["bob", 'clientdb'], ["bob", 'employeedb'], ["bob", 'providerdb']]


# Generated at 2022-06-23 11:54:48.738129
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-23 11:54:51.402490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 11:55:01.969992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()

    class MockMixedTemplar(object):
        def __init__(self):
            self._data = {}

        def _add_data(self, new_data):
            self._data.update(new_data)

        def template(self, data):
            return data

        def environment_definition(self):
            return None

    class MockMixedLoader():
        def __init__(self):
            self._templar = MockMixedTemplar()

        def get_basedir(self, variables):
            return "/some/path"

    class MockPlayContext():
        def __init__(self):
            self._loader = MockMixedLoader()

        def set_loader(self, l):
            self._loader = l


# Generated at 2022-06-23 11:55:13.827256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __main__
    setattr(__main__, '__file__', '/path/to/main.py')
    import json
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        '_raw': dict(type='list', elements='raw', required=True),
    })
    #
    # Test case #1
    #
    lookup_module = LookupModule()
    lookup_module.set_loader(module._shared_loader_obj)
    #
    # case #1 1
    lookup_module._templar = template = module._shared_loader_obj.get_basedir() + "/templates"
    terms = [
        'alice',
        'bob'
    ]
    variables = dict()

# Generated at 2022-06-23 11:55:15.438363
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:55:22.189772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    results = l.run([
        [ 'alice', 'bob' ],
        [ 'clientdb', 'employeedb', 'providerdb' ],
    ])
    assert results == [
        ['alice', 'clientdb'],
        ['alice', 'employeedb'],
        ['alice', 'providerdb'],
        ['bob', 'clientdb'],
        ['bob', 'employeedb'],
        ['bob', 'providerdb']
    ]



# Generated at 2022-06-23 11:55:29.687227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(terms=[]) == AnsibleError("with_nested requires at least one element in the nested list")
    assert LookupModule.run(terms=[[1, 2, 3], [4, 5, 6]]) == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]]

# Generated at 2022-06-23 11:55:40.829997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms = []
    result = lu.run(terms)
    assert result == []
    terms = [["a","b","c"]]
    result = lu.run(terms)
    assert result == [["a"], ["b"], ["c"]]
    terms = [["a","b","c"],[1,2,3]]
    result = lu.run(terms)
    assert result == [[1, "a"], [2, "b"], [3, "c"]]
    terms = [["a","b","c"],[1,2], ["d","e"]]
    result = lu.run(terms)

# Generated at 2022-06-23 11:55:43.313420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:55:46.252640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    ansible.plugins.lookup.nested.LookupModule
    '''
    lookup_obj = LookupModule()
    assert lookup_obj is not None


# Generated at 2022-06-23 11:55:56.412386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert [['d', 'e'], ['d', 'f'], ['c', 'e'], ['c', 'f']] == lookup_module.run([['c', 'd'], ['e', 'f']])
    assert [['d', 'e'], ['d', 'f'], ['c', 'e'], ['c', 'f']] == lookup_module.run([['{{ c }}', '{{ d }}'], ['e', 'f']])
    assert [['d', 'e'], ['d', 'f'], ['c', 'e'], ['c', 'f']] == lookup_module.run([['{{ c }}', '{{ d }}'], ['{{ e }}', '{{ f }}']])



# Generated at 2022-06-23 11:56:03.844327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Execute LookupModule.run successfully and validate that
    # the list of lists that it returns matches expectations.
    terms1 = [ [2, 3, 4], [5, 6] ]
    terms2 = [ [2, 3], [5, 6] ]
    terms3 = [ [2, 3, 4], [5, 6, 7] ]
    expected1 = [ [2, 5], [2, 6], [3, 5], [3, 6], [4, 5], [4, 6] ]
    expected2 = [ [2, 5], [2, 6], [3, 5], [3, 6] ]
    expected3 = [ [2, 5], [2, 6], [2, 7], [3, 5], [3, 6], [3, 7], [4, 5], [4, 6], [4, 7] ]

# Generated at 2022-06-23 11:56:10.436582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_nested_list1 = [['clientdb', 'employeedb', 'providerdb'], [ 'alice', 'bob']]
    result = LookupModule().run(input_nested_list1,[])
    desired_result = [['alice','clientdb'],['alice','employeedb'],['alice','providerdb'],['bob','clientdb'],['bob','employeedb'],['bob','providerdb']]
    assert result == desired_result, "Failed LookupModule method"


# Generated at 2022-06-23 11:56:14.439365
# Unit test for constructor of class LookupModule
def test_LookupModule(): # test_LookupModule
    import ansible.plugins.lookup.nested
    lookup = ansible.plugins.lookup.nested.LookupModule()
    assert lookup != None


# Generated at 2022-06-23 11:56:16.190242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Unit Test of method '_lookup_variables'

# Generated at 2022-06-23 11:56:26.941721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    terms = [
        ["alice", "bob"],
        ["clientdb", "employeedb", "providerdb"],
        ["low", "up"],
    ]
    result = lookup_module.run(terms)

# Generated at 2022-06-23 11:56:29.316460
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)



# Generated at 2022-06-23 11:56:31.924753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing constructor')
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Unit test: nothing to assert, just to maintain 100% coverage.

# Generated at 2022-06-23 11:56:34.293509
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    test_LookupModule: unit test for constructor
    """
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:56:36.061938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # Test the constructor
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:56:37.727529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 11:56:44.656644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None, **dict())
    terms = [ ['a','b','c'], [1,2,3]]
    variables = None
    kwargs = None
    assert lookup_module.run(terms, variables=None, **kwargs) == [['a', 1], ['a', 2], ['a', 3], ['b', 1], ['b', 2], ['b', 3], ['c', 1], ['c', 2], ['c', 3]]


# Generated at 2022-06-23 11:56:48.659058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    res = lookup.run([[1,2],[3,4],[5,6]])
    assert res == [[1, 3, 5], [1, 3, 6], [1, 4, 5], [1, 4, 6], [2, 3, 5], [2, 3, 6], [2, 4, 5], [2, 4, 6]]



# Generated at 2022-06-23 11:56:54.694945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1 - Input is correct and output value is correct
    terms = [
        [
            ["term1", "term2", "term3"],
            ["term4", "term5", "term6"],
            ["term7", "term8", "term9"]
        ],
        ["term10", "term11", "term12"],
        ["term13", "term14", "term15"]
    ]


# Generated at 2022-06-23 11:57:00.989775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l=LookupModule()
    l._templar = None
    l._loader = None
    l._list=[]
    l.run([[1, 2], [3, 4]])
    l.run([[1, 2], [3, 4], ['a', 'b']])
    l.run([[1, 2], [3, 4], ['a', 'b'], ['x', 'y']])

# Generated at 2022-06-23 11:57:02.261834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:57:03.839297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert(l is not None)


# Generated at 2022-06-23 11:57:14.306047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with the (currently) only case of use, the mysql_user module
    user_names = ['alice', 'bob']
    user_dbs = ['clientdb', 'employeedb', 'providerdb']
    user_privs = [':ALL']
    # Data for test
    my_terms = [user_names, user_dbs, user_privs]
    my_vars = {}
    # Object to be tested
    my_lookup = LookupModule()
    my_result = my_lookup.run(terms=my_terms, variables=my_vars)
    # Expected result

# Generated at 2022-06-23 11:57:15.737708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 11:57:16.687304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    k = LookupModule()
    assert k is not None

# Generated at 2022-06-23 11:57:26.325351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a class object of class LookupModule
    lookup_obj = LookupModule()

    # terms will be a list of lists
    terms = [['a', 'b'], ['c', 'd', 'e'], ['f']]

    # test the run method of the object
    result = lookup_obj.run(terms)

    # check the output of the lookup obj
    correct_result = [['a', 'c', 'f'], ['a', 'd', 'f'], ['a', 'e', 'f'], ['b', 'c', 'f'], ['b', 'd', 'f'], ['b', 'e', 'f']]
    assert result == correct_result

# Generated at 2022-06-23 11:57:34.396863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.nested import LookupModule

    vars_obj = {}

    nested_obj = LookupModule()

    terms = [["APPLE","BANANA","PAPAYA"],["  1  ","  2  ","  3  "]]
    result = nested_obj.run(terms=terms, variables=vars_obj)

    assert result == [["APPLE","  1  "], ["APPLE","  2  "], ["APPLE","  3  "], \
        ["BANANA","  1  "], ["BANANA","  2  "], ["BANANA","  3  "], \
        ["PAPAYA","  1  "], ["PAPAYA","  2  "], ["PAPAYA","  3  "]]

    # Test using an inline lookup

# Generated at 2022-06-23 11:57:43.605968
# Unit test for constructor of class LookupModule
def test_LookupModule():
    items = ['a','b','c']
    nested_item = [items]
    assert LookupModule._combine(nested_item[0], ['1','2','3']) == [['a', '1'], ['b', '1'], ['c', '1'], ['a', '2'], ['b', '2'], ['c', '2'], ['a', '3'], ['b', '3'], ['c', '3']]

# Generated at 2022-06-23 11:57:54.498369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule.
    #
    # Test case 1
    terms = [
        [1, 2],
        [3, 4]
    ]
    expected = [
        [1, 3],
        [1, 4],
        [2, 3],
        [2, 4]
    ]
    from ansible.plugins.lookup import LookupModule
    lookup = LookupModule()
    assert expected == lookup.run(terms)

    # Test case 2
    terms = [
        [1, 2],
        [3, 4],
        [5, 6]
    ]

# Generated at 2022-06-23 11:57:55.861418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_module = LookupModule()
    assert test_lookup_module


# Generated at 2022-06-23 11:58:01.406320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_class = LookupModule()
    terms = '{{lookup_term}}'
    terms = lookup_class._lookup_variables(terms, {})
    assert terms.run(terms, {}, lookup_class) == [['alice'], ['bob', 'mary']]

# Generated at 2022-06-23 11:58:07.986675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LoaderMock(object):
        def __init__(self):
            pass
        def get_basedir(self, host):
            return "/home/me"
        def path_dwim(self, basedir, given):
            return basedir + "/" + given

    class VarManagerMock(object):
        def get_vars(self, loader, play, host, task, include_priors=True):
            return {}

    class RunnerMock(object):
        def __init__(self):
            self.loader = LoaderMock()
            self.var_manager = VarManagerMock()

    my_runner = RunnerMock()

    lookup = LookupModule()

# Generated at 2022-06-23 11:58:09.406401
# Unit test for constructor of class LookupModule
def test_LookupModule():
     test_obj = LookupModule()
     assert test_obj is not None

# Generated at 2022-06-23 11:58:10.053534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:58:13.115117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lm = LookupModule()
    assert lm is not None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:58:23.138908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    assert my_lookup.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [1, 5], [1, 6],
                                                        [2, 4], [2, 5], [2, 6],
                                                        [3, 4], [3, 5], [3, 6]]

# Generated at 2022-06-23 11:58:27.865163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = AnsibleModule()
    test.prefix = ""
    test.module = ""
    test.name = ""
    test.args = []
    assert LookupModule.run(test, [], {}) is None, 'Testing run(): Nothing to test'


# Generated at 2022-06-23 11:58:30.360832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 11:58:30.922334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()



# Generated at 2022-06-23 11:58:37.632491
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class AnsibleModule(): 
        def __init__(self,text):
            self.text=text

    l = LookupModule()
    l._templar = AnsibleModule('{{ hostvars[inventory_hostname]["ansible_" + ethtool_interfaces[0] + "_ipv4"]["address"] }}')
    l._loader = AnsibleModule('{{ hostvars[inventory_hostname]["ansible_" + ethtool_interfaces[0] + "_ipv4"]["address"] }}')
    assert l.run([['1','2'],['a','b']], {}) == [['1a', '1b'], ['2a', '2b']]

# Generated at 2022-06-23 11:58:44.495096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #This test is not a real unit test as it needs a real inventory file.
    #  It is shipped here because it helps to develop the lookup plugin
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list="localhost")
    variable_manager.set_inventory(inventory)

    #playbook = Playbook.load("testcase.yaml", variable_manager=variable_manager, loader=loader)
    #play = playbook.get_plays()[0]
    #tasks = play.get_tasks()


# Generated at 2022-06-23 11:58:46.243168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Implement unit test for LookupModule.run()
    pass


# Generated at 2022-06-23 11:58:56.589261
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Options(object):
        def __init__(self):
            self.verbosity = 0

    class Play(object):
        def __init__(self):
            self.basedir = ""
            self.name = ""
            self.vars = {}
            self.options = Options()

    class MockTemplar(object):
        def template(self, data):
            return data

    class MockLoader(object):
        def get_basedir(self):
            return "/tmp/ansible"


    def mock_get_vars(self, play, host):
        return {}

    # Mockito for Host
    host = Mock()
    when(host).get_vars().thenReturn(None)
    when(host).get_name().thenReturn("localhost")

    # Mockito for Task
    task = Mock()


# Generated at 2022-06-23 11:58:57.590667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # look = LookupModule()
    # look.run([[1,2,3],[4,5,6]])
    # look.run([])
    pass



# Generated at 2022-06-23 11:59:00.000964
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-23 11:59:01.018551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule == LookupModule



# Generated at 2022-06-23 11:59:01.922796
# Unit test for constructor of class LookupModule
def test_LookupModule():
    do_nothing = None


# Generated at 2022-06-23 11:59:08.942309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [['alice', 'bob'], ['mail', 'phone', 'address']]
    obj = LookupModule()
    result = [['alice', 'mail'], ['alice', 'phone'], ['alice', 'address'],
              ['bob', 'mail'], ['bob', 'phone'], ['bob', 'address']]
    assert obj.run(args) == result

# Generated at 2022-06-23 11:59:09.463524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:59:10.893699
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms=[1,2], variables='dummy')

# Generated at 2022-06-23 11:59:18.254304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the class and create some test input data
    lookup_obj = LookupModule()
    terms = [
        [{"a": [1, 2, 3]}, {"b": [1, 2, 3]}],
        [{1: "a"}, {2: "b"}, {3: "c"}],
        [{"alpha": "ALPHA"}, {"beta": "BETA"}]
    ]

    # Execute the code to be tested
    result = lookup_obj.run(terms, variables={})

    # Verify the result

# Generated at 2022-06-23 11:59:20.481490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 11:59:21.813379
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_plugin = LookupModule()
  assert lookup_plugin



# Generated at 2022-06-23 11:59:30.855721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    result = lookup_module.run([[1,2,3],[4,5,6]], [], [], [], [])
    assert result == [[1,4],[1,5],[1,6],[2,4],[2,5],[2,6],[3,4],[3,5],[3,6]]

    result = lookup_module.run([[1,2,3],[4,5]], [], [], [], [])
    assert result == [[1,4],[1,5],[2,4],[2,5],[3,4],[3,5]]

    result = lookup_module.run([[1,2],[4,5],[7,8]], [], [], [], [])