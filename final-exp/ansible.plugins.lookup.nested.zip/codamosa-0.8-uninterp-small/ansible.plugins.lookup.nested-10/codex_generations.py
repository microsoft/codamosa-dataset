

# Generated at 2022-06-25 10:53:40.206965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    array_0 = []
    dict_1 = {}
    dict_1['y'] = array_0
    dict_1['x'] = array_0
    array_1 = [dict_1]
    dict_2 = {}
    dict_2['y'] = array_1
    dict_2['x'] = array_1
    array_2 = [dict_2]
    dict_3 = {}
    dict_3['y'] = array_1
    dict_3['x'] = array_2
    array_3 = [dict_3]
    dict_4 = {}
    dict_4['y'] = array_0
    dict_4['x'] = array_3
    array_4 = [dict_4]


# Generated at 2022-06-25 10:53:44.476833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    with pytest.raises(AnsibleError) as error:
        lookup_module_0.run(terms_0)
    assert 'with_nested requires at least one element in the nested list' in str(error)

# Generated at 2022-06-25 10:53:47.999962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = lookup_module_0.run([])

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:53:55.539673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._combine = mock.Mock(side_effect=lambda a, b: [(a[0], b[0]), (a[0], b[1])])
    lookup_module_0._flatten = mock.Mock(side_effect=lambda x: x)

    results = lookup_module_0.run(terms=['a', 'b', 'c'], inject={}, variables={})
    assert results == [('a', 'b'), ('a', 'c')]

# Generated at 2022-06-25 10:53:59.274546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [0,1,2]
    terms = [my_list]
    lookup_module_1 = LookupModule()
    assert lookup_module_1._combine(my_list, my_list) == [[0, 0], [1, 1], [2, 2]]


# Generated at 2022-06-25 10:54:08.700860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # self._templar has type Templar
    # self._loader has type DataLoader
    # terms is type list
    # variables is type dict

    # The next two unit tests should cause an exception to be raised
    terms_0 = []
    variables_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(terms_0, variables_0)
    try:
        lookup_module_0.run(terms_0, variables_0)
        assert(False)
    except AnsibleError:
        pass
    else:
        assert(False)

    terms_0 = []
    variables_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 10:54:15.179224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    # loop of with_items for the lookup module
    for item_0 in lookup_module_0.run(**dict_0):
        pass

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:54:24.152575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_1 = []

    # Call method run of lookup_module_0
    result = lookup_module_0.run(terms_1)

    # AssertionError: One of the nested variables was undefined. The error was: 'ansible.vars.unsafe_proxy.AnsibleUnsafeText' object has no attribute 'has_key'
    assert type(result) == list


# Generated at 2022-06-25 10:54:32.469535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_1 = {
        'run': LookupModule.run,
    }
    lookup_module_1 = LookupModule(**dict_1)

    dict_2 = {
        'require_one_of': [
            'run',
        ],
        '_templar': object(),
        'run': LookupModule.run,
        'get_basedir': object(),
    }
    lookup_module_2 = LookupModule(**dict_2)
    lookup_options_1 = {}
    terms_1 = [
        [
            'a',
        ],
        [
            '1',
            '2',
            '3',
        ],
    ]
    list_0 = lookup_module_2.run(terms_1, lookup_options_1)


# Generated at 2022-06-25 10:54:34.884993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)

    terms = {}
    variables = {}
    kwargs = {}

    lookup_module_0.run(**dict_0)
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:54:42.756340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = None
    result = lookup_module_0.run(terms, variables)
    assert result == [], "No test case provided"


# Generated at 2022-06-25 10:54:47.010678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run([['a'], ['b', 'c'], ['d', 'e', 'f']], None)
    assert result == [['a', 'b', 'd'], ['a', 'b', 'e'], ['a', 'b', 'f'], ['a', 'c', 'd'], ['a', 'c', 'e'], ['a', 'c', 'f']]

# Generated at 2022-06-25 10:54:48.243681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 10:54:57.901541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([[1], [2, 3], [4, 5, 6]])
    assert result == [[1, 2, 4], [1, 2, 5], [1, 2, 6], [1, 3, 4], [1, 3, 5], [1, 3, 6]]
    assert result[0][0] == 1
    assert result[0][1] == 2
    assert result[0][2] == 4
    assert result[1][0] == 1
    assert result[1][1] == 2
    assert result[1][2] == 5
    assert result[2][0] == 1
    assert result[2][1] == 2
    assert result[2][2] == 6
    assert result[3][0] == 1

# Generated at 2022-06-25 10:55:08.256124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    twolists = [['foo', 'bar'], ['ham', 'eggs']]
    from unittest.mock import patch
    from ansible.module_utils.parsing.convert_bool import boolean
    kwargs = {'playbook_dir': '/playbook/dir'}
    def __getitem__(name):
        return kwargs[name]

    with patch.object(LookupModule,'run',return_value=twolists,autospec=True) as mock_method:
        mock_method.configure_mock(**kwargs)
        mock_method.__getitem__ = __getitem__
        result = mock_method(LookupModule,'run',twolists,kwargs)
        assert result == twolists
        def side_effect(self,arg):
            return arg


# Generated at 2022-06-25 10:55:11.665918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('foo', dict())


# Generated at 2022-06-25 10:55:18.225261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['v0'],['v1'],['v2']]
    lookup_module_0 = LookupModule()
    try:
        result = lookup_module_0.run(terms)
        result = lookup_module_0.run(terms)
        result = lookup_module_0.run(terms)
    except Exception as e:
        print(e)

    assert result == [['v0','v1','v2']]
    assert 1 == 1


# Generated at 2022-06-25 10:55:28.291888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # One Nested list
    lookup_module_0 = LookupModule()
    terms_0 = [ ['apples', 'oranges']]
    assert lookup_module_0.run(terms_0) == [
        ['apples'],
        ['oranges'],
    ]

    # Two nested lists
    lookup_module_1 = LookupModule()
    terms_1 = [ ['apples', 'oranges'], [1,2] ]
    assert lookup_module_1.run(terms_1) == [
        ['apples', 1],
        ['apples', 2],
        ['oranges', 1],
        ['oranges', 2],
    ]

    # Three nested lists
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:55:30.031987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()


# Generated at 2022-06-25 10:55:36.029298
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 0
    print("Test case 0")
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[u'a', u'b'], [u'c', u'd']]) == [[u'a', u'c'], [u'a', u'd'], [u'b', u'c'], [u'b', u'd']]


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:55:47.913795
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with 2 input lists.
    terms_0 = [["a", "b"], ["1", "2"]]
    variables_0 = {}
    expected_0 = [["a1", "a2"], ["b1", "b2"]]
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == expected_0

    # Test with 2 input lists again.
    terms_1 = [["1", "2"], ["a", "b"]]
    variables_1 = {}
    expected_1 = [["1a", "2a"], ["1b", "2b"]]
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(terms_1, variables_1)


# Generated at 2022-06-25 10:55:49.703113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([['dados']], {}) == [['dados']]


# Generated at 2022-06-25 10:55:54.169666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [ ]
    dict_0 = dict()
    str_0 = lookup_module_0.run(list_0, dict_0)
    # assert UndefinedError is raised
    try:
        str_0 = lookup_module_0.run(list_0, dict_0)
    except UndefinedError as e:
        pass
    else:
        raise RuntimeError from e


# Generated at 2022-06-25 10:55:59.685001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    assert lookup_module_0._lookup_variables(terms_0, variables_0) == []

    terms_1 = [[1, 2, 3]]
    assert lookup_module_0._lookup_variables(terms_1, variables_0) == terms_1

    terms_2 = [[1, 2, 3], [4, 5, 6]]
    assert lookup_module_0._lookup_variables(terms_2, variables_0) == terms_2

    terms_3 = [1, 2, 3]
    assert lookup_module_0._lookup_variables(terms_3, variables_0) == terms_3

    terms_4 = [1]
    assert lookup_module_0._lookup_vari

# Generated at 2022-06-25 10:56:09.383060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_module_0.run(['0', '1'])

    lookup_module_0.run([['1', '2'], ['3', '4']]) == [['1', '3'], ['1', '4'], ['2', '3'], ['2', '4']]

    lookup_module_0.run([['0', '1'], ['2', '3', '4']]) == [['0', '2'], ['0', '3'], ['0', '4'], ['1', '2'], ['1', '3'], ['1', '4']]


# Generated at 2022-06-25 10:56:16.192723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'], variables=None)
    print(result)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:56:19.916274
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    my_vars = {}
    y = ['ClientDB', 'EmployeeDB', 'ProviderDB']
    x = ['Alice', 'Bob']
    z = [x, y]

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(z, variables=my_vars) == [['Alice', 'ClientDB'], ['Alice', 'EmployeeDB'], ['Alice', 'ProviderDB'], ['Bob', 'ClientDB'], ['Bob', 'EmployeeDB'], ['Bob', 'ProviderDB']]



# Generated at 2022-06-25 10:56:22.983220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run([], {})
    except Exception as e:
        print("Exception occured: " + str(e))
# End of unit test for method run of class LookupModule


# Generated at 2022-06-25 10:56:32.233849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            [
                'a'
            ],
            [
                'b'
            ]
        ],
        [
            [
                'c'
            ],
            [
                'd'
            ]
        ]
    ]

    variables = {}

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables) == [
        [
            'a',
            'c'
        ],
        [
            'a',
            'd'
        ],
        [
            'b',
            'c'
        ],
        [
            'b',
            'd'
        ]
    ]

# Generated at 2022-06-25 10:56:40.055143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    yaml0 = """foo:
  - baz:
    - one
    - two
  - bar:
     - three
     - four
"""
    data0 = {'_raw': yaml0}
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(None, data0)
    assert result == [['foo', 'baz', 'one'], ['foo', 'baz', 'two'], ['foo', 'bar', 'three'], ['foo', 'bar', 'four']]


# Generated at 2022-06-25 10:56:44.247232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    res = lookup_module_0.run(terms_0, variables_0)
    assert res is None


# Generated at 2022-06-25 10:56:48.098171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:56:53.740595
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [["Alice", "Bob"], ["Client", "Employee", "Provider"]]
    result = [["Alice", "Client"], ["Alice", "Employee"], ["Alice", "Provider"], ["Bob", "Client"], ["Bob", "Employee"], ["Bob", "Provider"]]

    lookup_module_0 = LookupModule()
    assert result == lookup_module_0.run(terms)


# Generated at 2022-06-25 10:57:01.290132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = [['a1', 'a2'], ['b1', 'b2']]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=a)
    assert result == [['a1', 'a2', 'b1'], ['a1', 'a2', 'b2']]

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:57:05.410101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_result_0 = None
    lookup_module_0 = LookupModule()
    test_result_0 = lookup_module_0.run([['one', 'two'], ['three', 'four']], dict())

    assert test_result_0 == [["one", "three"], ["one", "four"], ["two", "three"], ["two", "four"]]


# Generated at 2022-06-25 10:57:10.251270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Ensure an assertion error is raised when an attempt is made to instantiate an instance of LookupModule
    # with no parameters
    try:
        lookup_module_0.run()
    except (AnsibleError, TypeError) as exception_0:
        assert exception_0 == AnsibleError('with_nested requires at least one element in the nested list')

# Generated at 2022-06-25 10:57:14.448257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_1.run({'foo': 'bar'})
    with pytest.raises(AnsibleUndefinedVariable):
       lookup_module_3.run()

# Generated at 2022-06-25 10:57:20.686684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms=terms_0)
    assert result_0 == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]



# Generated at 2022-06-25 10:57:25.052984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [{'a': '1', 'b': '2'}]
    result = lookup_module_0.run(terms)
    assert result == []


# Generated at 2022-06-25 10:57:31.173234
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input parameters
    terms = [
        [
            "alice", "bob"
        ],
        [
            "clientdb", "employeedb", "providerdb"
        ]
    ]
    variables = None

    # Expected return value
    expected_result = [
        [
            "alice", "clientdb"
        ],
        [
            "alice", "employeedb"
        ],
        [
            "alice", "providerdb"
        ],
        [
            "bob", "clientdb"
        ],
        [
            "bob", "employeedb"
        ],
        [
            "bob", "providerdb"
        ]
    ]

    # Run method under test
    lookup_module_class_instance = LookupModule()

# Generated at 2022-06-25 10:57:41.320664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [["alice", "bob"], ["clientdb", "employeedb", "providerdb"]]
    result_1 = lookup_module_1.run(terms_1, variables={"users": [["alice", "bob", "charlie", "doug"]]})

# Generated at 2022-06-25 10:57:42.863144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = [[]]
    lookup_module_1.run(terms_2)


# Generated at 2022-06-25 10:57:46.082655
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # This test requires manual intervention

    # Print statements for debugging purposes
    # print("Input list is: [ ['1'], ['2', '3'] ]"
    # print("Required output is: [ ['1', '2'], ['1', '3'] ]")

# Generated at 2022-06-25 10:57:56.319470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [(u'foo', u'{example}/files/foo.txt'), (u'bar', u'{example}/files/bar.txt')]
    # Test case with type UNDEFINED
    data_0 = {}
    result_0 = lookup_module_0.run(terms_0, data_0)
    assert result_0[0] == u'foo'
    # Test case with type DICT
    data_1 = {}
    result_1 = lookup_module_0.run(terms_0, data_1)
    assert result_1[1] == u'bar'
    # Test case with type TUPLE
    data_2 = {}
    result_2 = lookup_module_0.run(terms_0, data_2)
   

# Generated at 2022-06-25 10:57:59.699727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test an empty list
    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = None
    run_result_1 = lookup_module_1.run(terms_1, variables_1)
    assert run_result_1 == []


# Generated at 2022-06-25 10:58:05.642833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	sample_input = [
		[1, 2, 3],
		[4, 5, 6],
		[7, 8, 9]
	]

# Generated at 2022-06-25 10:58:14.197305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0_0 = [
        {
            'name': 'a',
            'value': 'b'
        },
        {
            'name': 'c',
            'value': 'd'
        }
    ]
    term_0_1 = [
        {
            'name': 'e',
            'value': 'f'
        },
        {
            'name': 'g',
            'value': 'h'
        }
    ]
    result_0 = lookup_module_0.run(terms=[term_0_0, term_0_1], variables=None, **{})
    assert result_0 == [{'name': 'a', 'value': 'b'}, {'name': 'c', 'value': 'd'}]

# Unit

# Generated at 2022-06-25 10:58:22.532018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []

# Generated at 2022-06-25 10:58:32.756486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Testing:
    #   with_nested:
    #     - [ 'alice', 'bob' ]
    #     - [ 'clientdb', 'employeedb', 'providerdb' ]
    my_list = [
        [ 'alice', 'bob' ],
        [ 'clientdb', 'employeedb', 'providerdb' ]
    ]
    my_list.reverse()
    result = []
    if len(my_list) == 0:
        raise AnsibleError("with_nested requires at least one element in the nested list")
    result = my_list.pop()
    while len(my_list) > 0:
        result2 = lookup_module._combine(result, my_list.pop())
        result = result2

# Generated at 2022-06-25 10:58:42.245851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    expected_0 = []
    actual_0 = lookup_module_0.run(terms_0)
    assert actual_0 == expected_0
    terms_1 = []
    expected_1 = []
    actual_1 = lookup_module_0.run(terms_1)
    assert actual_1 == expected_1
    terms_2 = []
    expected_2 = []
    actual_2 = lookup_module_0.run(terms_2)
    assert actual_2 == expected_2
    terms_3 = []
    expected_3 = []
    actual_3 = lookup_module_0.run(terms_3)
    assert actual_3 == expected_3
    terms_4 = []
    expected_4 = []

# Generated at 2022-06-25 10:58:47.566622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    result = lookup_module_0.run(terms_0)
    assert result == []


# Generated at 2022-06-25 10:58:54.762909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = None
    kwargs = {}
    result = lookup_module_0.run(terms, variables=variables, **kwargs)
    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]


# Generated at 2022-06-25 10:59:02.636496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[['foo', 'bar', 'baz'], ['foo', 'bar', 'xyzzy'], ['foo', 'xyzzy', 'baz'], ['xyzzy', 'bar', 'baz']], [['foo', 'bar', 'baz'], ['foo', 'bar', 'xyzzy'], ['foo', 'xyzzy', 'baz'], ['xyzzy', 'bar', 'baz']], [['foo', 'bar', 'baz'], ['foo', 'bar', 'xyzzy'], ['foo', 'xyzzy', 'baz'], ['xyzzy', 'bar', 'baz']]]
    var_0 = {}
    var_1 = {'var_1': 'foo', 'var_0': 'bar'}

    # Test of LookupModule._

# Generated at 2022-06-25 10:59:08.623835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_list_0 = None
    variables_dict_0 = None
    kwargs_dict_0 = dict()
    result = lookup_module_0.run(terms_list_0, variables_dict_0, **kwargs_dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:59:12.533717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo', 'bar']
    try:
        result = lookup_module_0.run(terms_0)
        assert (result == list([['foo', 'bar']]))
        assert (not result == ['foo', 'bar'])
    except AnsibleError as e:
        assert (False)


# Generated at 2022-06-25 10:59:16.180682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # fixture 1
    term1 = "term1"
    term2 = "term2"
    variables0 = None
    lookup_module_0.run([term1, term2], variables0)



# Generated at 2022-06-25 10:59:21.725426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=[['a', 'b', 'c'], ['1', '2']])
    assert result == [['a'], ['b'], ['c']], result
    result = lookup_module_0.run(terms=[['a', 'b'], ['1', '2'], ['one', 'two']])
    assert result == [['a', '1', 'one'], ['b', '1', 'one'], ['a', '2', 'one'], ['b', '2', 'one'], ['a', '1', 'two'], ['b', '1', 'two'], ['a', '2', 'two'], ['b', '2', 'two']], result

# Generated at 2022-06-25 10:59:28.188979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  print("Test run of method run of class LookupModule", file=sys.stderr)
  lookup_module_0 = LookupModule()
  try:
      result = lookup_module_0.run(["foobar"])
  except Exception as e:
      print("Error with run: %s" % e, file=sys.stderr)
  try:
      result = lookup_module_0.run(["foobar"], {"foobar"})
  except Exception as e:
      print("Error with run: %s" % e, file=sys.stderr)
  try:
      result = lookup_module_0.run(["foobar"], {"foobar": "foobar"})
  except Exception as e:
      print("Error with run: %s" % e, file=sys.stderr)

# Generated at 2022-06-25 10:59:35.582176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=["[[ansible_default_ipv4.ip]]"], variables={"ansible_default_ipv4": {"ip": "172.31.38.1"}})
    assert result[0] == "172.31.38.1"


# Generated at 2022-06-25 10:59:38.946833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert [["alice", "clientdb"], ["alice", "employeedb"], ["alice", "providerdb"], ["bob", "clientdb"], ["bob", "employeedb"], ["bob", "providerdb"]] == lookup_module_1.run([[["alice", "bob"], ["clientdb", "employeedb", "providerdb"]]])

# Generated at 2022-06-25 10:59:43.238937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = ["good", "very good"]
    y = ["hello", "world"]
    z = [x, y]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(z)
    assert result == [['good', 'hello'], ['good', 'world'], ['very good', 'hello'], ['very good', 'world']]

# Generated at 2022-06-25 10:59:48.531539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_module_0.run(terms=['[1,2,3]'], variables=None)
    assert result[0] == '[1,2,3]'


# Generated at 2022-06-25 10:59:54.209196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._loader.get_basedir = lambda x: '/tmp/ansible_wj3qxr'

    test_data={}
    test_data['terms'] = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]

# Generated at 2022-06-25 11:00:00.367899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    args_0 = {
    }
    kwargs_0 = {
    }
    try:
        assert lookup_module_0.run(terms_0, **kwargs_0) == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']], "LookupModule:run returned wrong result."
    except AssertionError as e:
        print(e, file=sys.stderr)
        assert False

# Generated at 2022-06-25 11:00:09.818209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [
        [ 'alice', 'bob' ],
        [ 'clientdb', 'employeedb', 'providerdb' ]
    ]
    expected = [
        [ 'alice', 'clientdb' ],
        [ 'alice', 'employeedb' ],
        [ 'alice', 'providerdb' ],
        [ 'bob', 'clientdb' ],
        [ 'bob', 'employeedb' ],
        [ 'bob', 'providerdb' ]
    ]
    result = lookup_module_1.run(terms)
    assert result == expected


# Generated at 2022-06-25 11:00:14.378739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([[1], [2], [3]])



# Generated at 2022-06-25 11:00:19.072123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms_0 = None
  variables_0 = None
  lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:00:21.284997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = set()
    lookup_module_0._templar = set()
    lookup_module_0.run(set(), set())

# Generated at 2022-06-25 11:00:28.363728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=[[['a', 'b']], [['1', '2', '3']]], variables={})
    assert [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3']] == result
    result = lookup_module.run(terms=[[['a', 'b']], [['1', '2', '3']], [['A']]], variables={})
    assert [['a', '1', 'A'], ['a', '2', 'A'], ['a', '3', 'A'], ['b', '1', 'A'], ['b', '2', 'A'], ['b', '3', 'A']] == result


# Generated at 2022-06-25 11:00:30.122875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([['a'], ['b', 'c']]) == [['a', 'b'], ['a', 'c']]


# Generated at 2022-06-25 11:00:43.811456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = ['a', 'b', 'c', 'd']
    assert lookup_module_0.run(my_list_0) == [['a'], ['b'], ['c'], ['d']]
    my_list_1 = ['a', 'b', 'c']
    assert lookup_module_0.run(my_list_1) == [['a', 'b'], ['a', 'c'], ['b', 'c']]
    my_list_3 = []
    my_list_2 = ['a']
    my_list_3.append(my_list_2)
    my_list_2 = ['b']
    my_list_3.append(my_list_2)
    my_list_2 = ['c']
   

# Generated at 2022-06-25 11:00:50.603611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args = [
        [
            [
                u'alice',
                u'bob',
            ],
            [
                u'clientdb',
                u'employeedb',
                u'providerdb',
            ],
            [
                u'READ',
                u'UPDATE',
            ],
        ],
        None
    ]

# Generated at 2022-06-25 11:00:55.141710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.run(terms=[['key0', 'key1', 'key2'], [1, 2, 3], ['a', 'b', 'c']])

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:01:04.202379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule().run
    assert lookup_module_run([], dict()) == []
    assert lookup_module_run([[1, 2, 3], [4, 5, 6]], dict()) == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]]

# Generated at 2022-06-25 11:01:07.371805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = []
    my_list.append([1, 2])
    my_list.append(['a', 'b'])
    terms = my_list

    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables=None)

    assert result[0] == [1, 'a']
    assert result[1] == [1, 'b']
    assert result[2] == [2, 'a']
    assert result[3] == [2, 'b']

# Generated at 2022-06-25 11:01:17.522424
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    data = make_data()
    lookup_module = LookupModule()

    assert data['test_LookupModule_run']['test_0'] == lookup_module.run(data['test_LookupModule_run']['test_0']['terms'], variables=data['test_LookupModule_run']['test_0']['variables'])
    assert data['test_LookupModule_run']['test_1'] == lookup_module.run(data['test_LookupModule_run']['test_1']['terms'], variables=data['test_LookupModule_run']['test_1']['variables'])

# Generated at 2022-06-25 11:01:24.969240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = [ [1, 2], ['a', 'b', 'c'] ]
    results = []
    results.append({ "name": "a", "options": 1})
    results.append({ "name": "b", "options": 1})
    results.append({ "name": "c", "options": 1})
    results.append({ "name": "a", "options": 2})
    results.append({ "name": "b", "options": 2})
    results.append({ "name": "c", "options": 2})
    #TODO: I don't know how to test the templating aspect of the lookup module here...
    assert lookup_module_0.run(x) == results


# Generated at 2022-06-25 11:01:29.590295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_0.run(["foo", "bar", "baz"], {})
    lookup_module_1.run([[1], [2], [3]], {})
    lookup_module_2.run([1, 2, 3], {})
    lookup_module_3.run([[1, 2], [3, 4], [5, 6, 7]], {})

# Generated at 2022-06-25 11:01:33.532689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['alice', 'bob'], ['clientdb']]
    lookup_module_run_0 = LookupModule()
    assert lookup_module_run_0.run(terms) == [['alice', 'clientdb'], ['bob', 'clientdb']]


# Generated at 2022-06-25 11:01:36.543669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb'
        ]
    ]
    lookup_module.run(terms)


# Generated at 2022-06-25 11:01:40.395384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run_LookupModule_run_0()
    test_run_LookupModule_run_1()
    test_run_LookupModule_run_2()


# Generated at 2022-06-25 11:01:40.815561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:01:45.512439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arguments = [
        {
            'terms': [
                [
                    'a',
                    'b',
                    'c'
                ],
                [
                    'p',
                    'q'
                ],
                [
                    1,
                    2
                ]
            ]
        }
    ]

# Generated at 2022-06-25 11:01:48.752517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert (lookup_module.run([(('alice', 'bob'), ('clientdb', 'employeedb', 'providerdb'))], []) == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']])

# Generated at 2022-06-25 11:01:55.660216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initializing the class object
    lookup_module_0 = LookupModule()
    # declaring variable input
    input = [['nested', 'variables']]
    # List with all return values expected to be returned
    expected_value = [['nested', 'variables']]
    # declaring variable result to be returned by test method
    result = lookup_module_0.run([input])
    # asserting result with expected value
    assert result == expected_value


# Generated at 2022-06-25 11:01:59.787035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:02:01.590011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['foo', 'bar']) == [['foo'], ['bar']]


# Generated at 2022-06-25 11:02:08.547074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_list_1 = [
        "{{ a }}",
        [
            "{{ b }}",
            "{{ c }}"
        ],
    ]
    variables_1 = {}
    variables_1['a'] = '@items'
    variables_1['b'] = '0'
    variables_1['c'] = '1'
    result_1 = lookup_module_1.run(terms=my_list_1, variables=variables_1)
    del lookup_module_1
    return result_1


# Generated at 2022-06-25 11:02:18.709947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["[ 'alice', 'bob' ]", "[ 'clientdb', 'employeedb', 'providerdb' ]"]
    lookup_module.run(terms, None)
    ret = lookup_module.run(terms, None)
    assert ret == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']], "Return must be [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']], got %s"

# Generated at 2022-06-25 11:02:23.862974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate LookupModule object
    lookup_module_obj = LookupModule()

    # Invoke method run
    result = lookup_module_obj.run([['val1', 'val2'], ['val3', 'val4', 'val5']], {})

    # Check invocation result
    assert result == [['val1', 'val3'], ['val1', 'val4'], ['val1', 'val5'], ['val2', 'val3'], ['val2', 'val4'], ['val2', 'val5']]


# Generated at 2022-06-25 11:02:26.203089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run()

# Generated at 2022-06-25 11:02:30.605187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    var_0 = lookup_run({})
    terms = ['foo', 'bar']
    var = lookup_module_0.run(terms, {})
    if not var.is_err:
        raise RuntimeError("test_LookupModule_run:\n" + lookup_module_0.run(terms, {}).unwrap())
    var = lookup_module_0.run()
    if not var.is_err:
        raise RuntimeError("test_LookupModule_run:\n" + lookup_module_0.run().unwrap())
    var = lookup_module_0.run([], {})
    if not var.is_err:
        raise RuntimeError("test_LookupModule_run:\n" + lookup_module_0.run([], {}).unwrap())



# Generated at 2022-06-25 11:02:39.753928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print( "\nIn test_LookupModule_run" )
    print( "Looking up with_nested" )
    dict_0 = {
        "lookup_type": "nested",
        "lookup_terms": [
            ['a1', 'b1'],
            ['a2', 'b2']
        ]
    }
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(dict_0["lookup_terms"])
    print( "var_0: %s" % var_0 )
    assert var_0 == [["a1", "a2"], ["b1", "b2"]]


# Generated at 2022-06-25 11:02:44.106087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = re.compile('(^$)')
    var_1 = re.compile('^(?=.)([+-]?([0-9]*)(\.([0-9]+))?)$')
    var_2 = lookup_run(dict_0)
    var_3 = ['.']
    var_4 = var_1.match(dict_0)

# Generated at 2022-06-25 11:02:50.704081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager


    # Build mock objects
    #mock_loader = MagicMock()
    mock_loader = DataLoader()
    mock_variable_manager = VariableManager()
    mock_inventory_manager = InventoryManager()
    mock_play = Play()
    mock_options = basic.AnsibleOptions()

    lookup_module_0 = LookupModule(mock_loader)

# Generated at 2022-06-25 11:02:58.725458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"CMD_TEST_ROOT": "/home/ntc/sandbox/ansible/tests", "CMD_TEST_PATH": "/home/ntc/sandbox/ansible/tests/lib/ansible/plugins/test/unit/modules", "HOME": "/home/ntc"}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(["foo", "bar", "bing", "bam"], dict_0)
    assert var_0 == [['foo', 'bar'], ['foo', 'bing'], ['foo', 'bam'], ['bar', 'bing'], ['bar', 'bam'], ['bing', 'bam']]

# Generated at 2022-06-25 11:03:01.594656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule(1, 2)
    lookup_instance.run(1, 2)
    test_case_0()


# Generated at 2022-06-25 11:03:05.245733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    terms_0 = {}
    variables_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:03:07.607493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = []
    var_1 = lookup_module_0.run(var_0, dict_0)

# Generated at 2022-06-25 11:03:11.264379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'vars': {'/etc/hosts': {'hosts': [['127.0.0.1'], ['127.0.1.1', 'foo']]}, 'all': {}}}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:03:18.426032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:03:26.206368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

# Generated at 2022-06-25 11:03:27.946632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_1 = {}
    lookup_module_1 = LookupModule(dict_1)
    assert lookup_module_1.run() is None
