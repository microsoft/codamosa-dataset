

# Generated at 2022-06-25 10:53:38.172239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = []
    variables_3 = {}
    kwargs_4 = {}
    try:
        result_6 = lookup_module_1.run(terms_2, variables_3, **kwargs_4)
    except AnsibleError as e_5:
        assert e_5.message == 'with_nested requires at least one element in the nested list'
    else:
        assert result_6 == [], "Expected '%s', but got '%s'" % ([], result_6)


# Generated at 2022-06-25 10:53:41.772047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_terms_0 = {}
    var_variables_0 = {}
    result = lookup_module_0.run(var_terms_0, var_variables_0, )
    assert isinstance(result, list)
    assert len(result) == 0


# Generated at 2022-06-25 10:53:47.235583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
# A canned test to check if the function will run
# def test_case_1():
#     lookup_module_0 = LookupModule()
#     result = lookup_module_0.run(["stuff"])
#     if [] == result:
#         assert True
#     else:
#         assert False
#
# # Unit test for method run of class LookupModule
# def test_LookupModule_run():
#     lookup_module_0 = LookupModule()
#     result = lookup_module_0.run(["stuff"])
#     if [] == result:
#         assert True
#     else:
#         assert False


# A canned test to check if the function will run

# Generated at 2022-06-25 10:53:57.179414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run([[1, 2, 3], [10, 20], [100, 200, 300]])
    assert x == [[1, 10, 100], [1, 10, 200], [1, 10, 300], [1, 20, 100], [1, 20, 200], [1, 20, 300], [2, 10, 100], [2, 10, 200], [2, 10, 300], [2, 20, 100], [2, 20, 200], [2, 20, 300], [3, 10, 100], [3, 10, 200], [3, 10, 300], [3, 20, 100], [3, 20, 200], [3, 20, 300]]


# Generated at 2022-06-25 10:54:05.769269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [['foo'], ['bar'], ['baz']]
    variables_1 = {}
    lookup_module_1._templar.set_available_variables(variables_1)
    result_1 = lookup_module_1.run(terms_1, variables_1)
    assert result_1 == [['foo', 'bar', 'baz']]

# test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:54:12.579517
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:54:19.731483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [['alice','bob'], ['clientdb','employeedb','providerdb']]
    actual = lookup_module.run(terms)
    expected = [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    assert actual == expected

# Generated at 2022-06-25 10:54:27.487229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {}
    terms = [["a", "b"], ["1", "2"]]
    result = lookup_module.run(terms, variables)
    assert result == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2']]

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:54:29.220060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([[]], []) # should return empty list


# Generated at 2022-06-25 10:54:37.842432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    empty_list = []
    assert LookupModule().run([empty_list]) == []
    assert LookupModule().run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]
    assert LookupModule().run([[1, 2], [3, 4], [5, 6]]) == [[1, 3, 5], [1, 3, 6], [1, 4, 5], [1, 4, 6], [2, 3, 5], [2, 3, 6], [2, 4, 5], [2, 4, 6]]

# Generated at 2022-06-25 10:54:45.399708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['bob'], ['db1.mycompany.com', 'db2.mycompany.com']]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables=None, **{})
    assert result == [['bob', 'db1.mycompany.com'], ['bob', 'db2.mycompany.com']]
    assert result == [['bob', 'db1.mycompany.com'], ['bob', 'db2.mycompany.com']]


# Generated at 2022-06-25 10:54:50.919722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Input parameters
    terms = [
      [
        "alice"
      ],
      [
        "clientdb",
        "employeedb",
        "providerdb"
      ]
    ]
    variables = None
    kwargs = {}

    # Expected value
    result = [
      [
        "alice",
        "clientdb"
      ],
      [
        "alice",
        "employeedb"
      ],
      [
        "alice",
        "providerdb"
      ]
    ]

    # Return value
    retval = lookup_module.run(terms, variables=variables, **kwargs)

    # Check return value
    assert retval == result


# Generated at 2022-06-25 10:54:58.038633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.run = lambda terms, variables='test': 'test'
    lookup_module_2 = LookupModule()
    lookup_module_2.run = lambda terms, variables='test': 'test'
    lookup_module_2.run = lambda terms, variables='test': 'test'
    assert lookup_module_1.run == lookup_module_2.run
    lookup_module_3 = LookupModule()
    lookup_module_3.run = lambda terms, variables='test': 'test'
    lookup_module_3.run = lambda terms, variables='test': 'test'
    lookup_module_3.run = lambda terms, variables='test': 'test'

# Generated at 2022-06-25 10:55:05.207931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [["a", "b", "c"], [1, 2, 3]]
    expected_result = [['a', 'b', 'c', 1], ['a', 'b', 'c', 2], ['a', 'b', 'c', 3]]
    actual_result = lookup_module_0.run(my_list)
    assert expected_result == actual_result

# Generated at 2022-06-25 10:55:13.934422
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    # Testing method run of class LookupModule
    terms_0 = [[['clientdb', 'employeedb', 'providerdb'], ['alice', 'bob']], [], []]
    variables_0 = {}
    kwargs_0 = {}

    # Testing for correct return values
    # Testing for correct exception thrown
    try:
        result_0_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except:
        assert True
    else:
        assert False  # opm testing

    # Testing for incorrect return values
    # Testing for incorrect exception thrown

# Generated at 2022-06-25 10:55:22.560179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # from ansible.module_utils.my_ansible_test_module import *
    my_lookup_module = LookupModule()
    terms = [[[1, 2], [3, 4], [5, 6]], [[7, 8], [9, 10], [11, 12]]]
    result = my_lookup_module.run(terms)
    assert result == [[1, 2, 7, 8], [1, 2, 9, 10], [1, 2, 11, 12], [3, 4, 7, 8], [3, 4, 9, 10], [3, 4, 11, 12], [5, 6, 7, 8], [5, 6, 9, 10], [5, 6, 11, 12]]

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_

# Generated at 2022-06-25 10:55:26.817766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}

    lookup_module_test_0 = LookupModule()
    results = []
    try:
        results = lookup_module_test_0.run(terms, variables)
    except Exception as e:
        print(e)
    assert 'with_nested requires at least one element in the nested list' in str(e)


# Generated at 2022-06-25 10:55:28.330790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []

# Generated at 2022-06-25 10:55:30.398246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list_terms = []
    assert lookup_module.run(list_terms) == []


# Generated at 2022-06-25 10:55:35.037936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}

    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert isinstance(result, list)
    assert result == []



# Generated at 2022-06-25 10:55:40.762780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_list_2 = [["a", "b"], ["c", "d"]]
    my_list_1 = None
    try:
        lookup_module_1.run(my_list_2, my_list_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 10:55:44.967196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Subtest Of test_case_0')
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]]
    print('Subtest Of test_case_0 Finished...')
    print('TestCase Finished...')


# Generated at 2022-06-25 10:55:54.030737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_0 = [["bob", "jeff", "susie"], ["jimbo"], ["alice", "sally"]]
    result = lookup_module_0.run(test_0, kwargs={})
    assert result == [['alice', 'sally', 'jimbo'], ['alice', 'sally', 'bob'], ['alice', 'sally', 'jeff'], ['alice', 'sally', 'susie'], ['jimbo', 'bob'], ['jimbo', 'jeff'], ['jimbo', 'susie']]


# Generated at 2022-06-25 10:55:56.725988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['no-delegate']]
    variables_0 = {}
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == [['no-delegate']], result


# Generated at 2022-06-25 10:56:03.074000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([[['a']], [['b', 'c']]]) == [['a', 'b'], ['a', 'c']]
    assert lookup_module.run([[['a']], [['b', 'c'], ['d', 'e']]]) == [['a', 'b', 'd'], ['a', 'b', 'e'], ['a', 'c', 'd'], ['a', 'c', 'e']]

# Generated at 2022-06-25 10:56:12.607840
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # The following test case uses a module (LookupModule) that is
    # not a part of ansible.
    # It is copied from Ansible's library (ansible/lib/ansible/utils/listify.py)

    # testcase_0
    my_list = []
    result = lookup_module_0.run(my_list, [])
    # should return:
    # [[]]

    # testcase_1
    my_list = [
        [
            'a'
        ],
        [
            'b',
            'c'
        ],
        [
            'd'
        ],
        [
            'e',
            'f',
            'g'
        ]
    ]
    result = lookup_module_0.run(my_list, [])
    # should return:
    #

# Generated at 2022-06-25 10:56:22.243226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = [ [ ['a'], ['b'], ['c'] ] ]

    # tests for method run of class LookupModule
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(a) == [['a', 'b', 'c']], 'Test LookupModule with test #0 failed'

    # tests for method run of class LookupModule
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[ ['a'], ['b', 'c'] ]]) == [ ['a', 'b', 'c'] ], 'Test LookupModule with test #1 failed'

    # tests for method run of class LookupModule
    lookup_module_0 = LookupModule()
    assert True, 'Test LookupModule with test #2 failed'

    # tests for method run of class Look

# Generated at 2022-06-25 10:56:32.480893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    assert not hasattr(test_LookupModule_run, '_test_case_1_result')
    test_LookupModule_run._test_case_1_result = None
    def _ansible_template(template, variables=dict(), **kwargs):
        """
        A version of ansible.template.templar.Template.template method that returns plain strings.
        """
        templar = Templar(loader=None, variables=variables)
        temp_vars = templar._available_variables

# Generated at 2022-06-25 10:56:37.392811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert False

    lookup_module_0.run(terms, variables=None, **kwargs)
    assert False

# Generated at 2022-06-25 10:56:42.791745
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    dict = {}
    dict['terms'] = ['', '', '']
    dict['variables'] = {}
    dict['fail_on_undefined'] = False
    dict['wantlist'] = True

    try:
        lookup_module_0.run(**dict)
        assert False
    except AnsibleError as e:
        assert True

    dict['terms'] = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    dict['variables'] = {}
    dict['fail_on_undefined'] = False
    dict['wantlist'] = True

    try:
        lookup_module_0.run(**dict)
        assert True
    except AnsibleError as e:
        assert False

# Generated at 2022-06-25 10:56:54.547418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing an instance of class LookupModule
    lookup_module_1 = LookupModule()
    # case that needs to be tested
    terms_1_1 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    result_1_1 = lookup_module_1.run(terms_1_1)
    expected_result_1_1 = [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    assert result_1_1 == expected_result_1_1

    # case that needs to be tested

# Generated at 2022-06-25 10:56:57.273335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['1']) == [[1]]

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:57:01.706823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == []


# Generated at 2022-06-25 10:57:02.621683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:57:12.146470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = [
        [
            [
                'alice',
                'bob'
            ],
            [
                'clientdb',
                'employeedb',
                'providerdb'
            ]
        ]
    ]
    expected = [
        [
            'alice',
            'clientdb'
        ],
        [
            'alice',
            'employeedb'
        ],
        [
            'alice',
            'providerdb'
        ],
        [
            'bob',
            'clientdb'
        ],
        [
            'bob',
            'employeedb'
        ],
        [
            'bob',
            'providerdb'
        ]
    ]

# Generated at 2022-06-25 10:57:21.136835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["- name: here, 'users' contains the above list of employees\n  mysql_user:\n    name: \"{{ item[0] }}\"\n    priv: \"{{ item[1] }}.*:ALL\"\n    append_privs: yes\n    password: \"foo\"\n  with_nested:\n    - \"{{ users }}\"\n    - [ 'clientdb', 'employeedb', 'providerdb' ]"]
    variables = {"users": ["alice", "bob"]}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 10:57:25.147110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms_1 = "foo"
    variables_1 = {"foo":
                    {u'a': 1,
                     u'b': 2,
                     u'c': 3}
                  }

    value_1 = lookup_module_1.run(terms_1, variables_1)
    assert value_1 == [{u'a': 1, u'b': 2, u'c': 3}]


# Generated at 2022-06-25 10:57:29.155850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([['a', 'b'], ['c', 'd'], [1, 2]])
    assert result == [['a', 'c', 1], ['a', 'c', 2], ['a', 'd', 1], ['a', 'd', 2], ['b', 'c', 1], ['b', 'c', 2], ['b', 'd', 1], ['b', 'd', 2]]



# Generated at 2022-06-25 10:57:37.131365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ ['alice', 'bob'], ['clientdb', 'employeedb'] ]
    result = lookup_module.run(terms)
    assert result == [
        ['alice', 'clientdb'],
        ['alice', 'employeedb'],
        ['bob', 'clientdb'],
        ['bob', 'employeedb']
    ]


# Generated at 2022-06-25 10:57:41.240235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:57:45.709505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters for the module:
    #   terms=[]
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)



# Generated at 2022-06-25 10:57:48.652792
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:57:56.019683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = None
    for method_name in dir(LookupModule):
        if method_name.startswith('test_'):
            continue
        # the method to test
        test_method = getattr(LookupModule, method_name)
        custom_vars = {}

        # expected results
        expected_result = lookup_run(test_method, var_0)

        # actual result
        actual_result = lookup_run(test_method)

        # check if actual and expected results are equal
        assert expected_result == actual_result

# Generated at 2022-06-25 10:58:01.364331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    input_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    assert var_0 == [lookup_module_0]
    var_1 = lookup_run([])
    assert var_1 == []

# Generated at 2022-06-25 10:58:04.637996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 10:58:09.796576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [None, None]
    terms_0 = lookup_module_0._lookup_variables(var_0)
    var_1 = [terms_0, None]
    var_2 = [var_1]
    result = lookup_module_0.run(var_2)
    print(result)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:58:20.905200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '{terraria_dict}'
    var_0 = lookup_plugin_terms(str_0)
    lookup_module_0.run(var_0)
    var_1 = lookup_plugin_terms('{terraria_dict}')
    lookup_module_0.run(var_1)
    list_0 = ['{terraria_dict}']
    lookup_module_0.run(list_0)
    list_1 = ['{terraria_dict}']
    lookup_module_0.run(list_1)

if __name__ == '__main__':
    str_0 = '{terraria_dict}'
    var_0 = lookup_plugin_terms(str_0)

# Generated at 2022-06-25 10:58:29.831033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = [lookup_module]
    var = lookup_run(list)
    assert var == [
      [
        'dave',
        'clientdb'
      ],
      [
        'dave',
        'employeedb'
      ],
      [
        'dave',
        'providerdb'
      ],
      [
        'bob',
        'clientdb'
      ],
      [
        'bob',
        'employeedb'
      ],
      [
        'bob',
        'providerdb'
      ]
    ]


# Generated at 2022-06-25 10:58:34.086267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure all parameters are defined
    list_0 = [LookupModule()]
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 10:58:35.447791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 10:58:42.553222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 0
    lookup_module_0 = LookupModule()
    terms_0 = [lookup_module_0]
    variables_0 = {'foo': '2'}
    kwargs_0 = {'bar': '3'}

    with pytest.raises(AnsibleError):
        result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 10:58:47.461328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert_equal(lookup_module_0.run(['foo'], None), 'foo')


# Generated at 2022-06-25 10:58:49.367447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run()

# Generated at 2022-06-25 10:58:54.987367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    var_1 = lookup_module_0.run(terms=list_0, variables=var_0)
    assert var_1 == '', var_1


# Generated at 2022-06-25 10:58:56.997479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    # Expect test to fail
    #assert var_0 == ,


# Generated at 2022-06-25 10:58:59.679222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None]
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == []



# Generated at 2022-06-25 10:59:03.882959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1]
    # Test with a non-empty input list
    list_1 = [lookup_module_1]
    var_1 = lookup_run(list_1)
    assert var_1 == []
    # Test with an empty input list
    list_2 = [lookup_module_1]
    var_2 = lookup_run(list_2)
    assert var_2 == []

# Generated at 2022-06-25 10:59:09.386747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(var_0 == expected_0)

# Testing for desired functionality
expected_0 = [
    ['alice', 'clientdb'],
    ['alice', 'employeedb'],
    ['alice', 'providerdb'],
    ['bob', 'clientdb'],
    ['bob', 'employeedb'],
    ['bob', 'providerdb']]

# Generated at 2022-06-25 10:59:11.100394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=None, variables=None)


# Generated at 2022-06-25 10:59:17.378457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [lookup_module_1]
    var_1 = lookup_module_1.run(terms_1)
    assert (var_1 == lookup_module_1)



# Generated at 2022-06-25 10:59:23.539163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [['1', '2'], ['3', '4']]
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == [['1', '3'], ['2', '4']]


# Generated at 2022-06-25 10:59:25.942662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    assert var_0 == ['subsys_init_'], "Incorrect elements in var_0"

# Generated at 2022-06-25 10:59:29.121472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['']
    var_0 = LookupModule()
    var_0._lookup_variables()
    var_1 = var_0.run()

if __name__ == "__main__":
    # Unit test for method run of class LookupModule
    test_LookupModule_run()

    # Unit test for method test_case_0
    # test_case_0()

# Generated at 2022-06-25 10:59:32.201922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:59:34.962687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'foo'
    dict_0 = {'foo': 'bar'}
    list_0 = [lookup_module_0, str_0, dict_0]
    var_0 = lookup_run(list_0)


# Generated at 2022-06-25 10:59:41.460789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # To keep track of the Mocking of the call to self._templar.template
    count = 0
    # Mocking of self._templar.template
    def template_mock(x):
        nonlocal count
        count = count + 1
        if count == 1:
            return [
                [
                    'one', 'two', 'three'
                ],
                [
                    'some', 'more', 'lists'
                ]
            ]
        elif count == 2:
            return [
                [
                    1, 2, 3, 4, 5
                ],
                [
                    1, 2, 3
                ]
            ]

# Generated at 2022-06-25 10:59:42.926730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    list_2 = [lookup_module_2]
    var_0 = lookup_run(list_2)
    print(var_0)


# Generated at 2022-06-25 10:59:48.810542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1]
    var_1 = lookup_run(list_1)
    assert len(var_1) == 2

# Generated at 2022-06-25 10:59:52.059698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = test_case_0() # Output of method "test_case_0"
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == set(['b', 'c', 'a'])
    assert var_0 != set(['b', 'c', 'a'])

# Generated at 2022-06-25 11:00:01.527022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    list_0 = [0]
    lookup_module_0._flatten(list_0)
    terms_0.append(list_0)
    var_0 = [0]
    list_1 = [lookup_module_0]
    var_1 = lookup_run(list_1)
    list_2 = [lookup_module_0]
    var_2 = lookup_run(list_2)
    list_3 = [lookup_module_0]
    var_3 = lookup_run(list_3)
    list_4 = [lookup_module_0]
    var_4 = lookup_run(list_4)

# Generated at 2022-06-25 11:00:08.076742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = LookupModule.run(lookup_module_0, list_0)


# Generated at 2022-06-25 11:00:11.829842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    list_1 = []
    dict_1 = {}
    dict_0['terms'] = list_1
    dict_0['variables'] = dict_1
    list_0.append(dict_0)
    var_0 = lookup_run(list_0)


# Generated at 2022-06-25 11:00:13.183303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 11:00:18.216748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main("-r a", __file__)

# Generated at 2022-06-25 11:00:22.118342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_1 = lookup_run(list_0)
    assert result == [(1, 2, 3, 4, 5), (1, 2, 3, 4, 6), (1, 2, 3, 5, 6), (1, 2, 4, 5, 6), (1, 3, 4, 5, 6)]

# Generated at 2022-06-25 11:00:29.059804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    test_0 = [[u'a0'], [u'c0', u'c1']]
    test_1 = [[u'a0', u'b1'], [u'c0', u'c1']]
    test_2 = [[u'a0'], [u'c0']]
    test_3 = [[u'a0', 'a1b0', 'a1b1'], ['c0c0', 'c0c1']]
    test_4 = [[u'a0a0', u'a0a1', u'a0a2'], [u'b1b0', u'b1b1']]
   

# Generated at 2022-06-25 11:00:33.623537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(["{{","ansible_eth0", "ansible_eth1", "ansible_eth2","}}"])
    res = lookup_module_0.run(["{{","ansible_eth0", "ansible_eth1", "ansible_eth2","}}"]) == var_0
    assert res
    var_1 = lookup_run(["{{","ansible_eth0", "ansible_eth1", "ansible_eth2","}}"],"{{","ansible_eth0", "ansible_eth1", "ansible_eth2","}}")

# Generated at 2022-06-25 11:00:36.277986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    result_0 = lookup_module_0.run(list_0)
    assert result_0



# Generated at 2022-06-25 11:00:39.631330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert True
    assert lookup_module_1.run([], [])



# Generated at 2022-06-25 11:00:40.978944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule.run, types.MethodType)


# Generated at 2022-06-25 11:00:55.329671
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #
    # Test 1: empty lists
    #
    list_1 = []
    variables = None
    lookup_module_1 = LookupModule()
    result = lookup_run(list_1, variables)
    assert result == []
    #
    # Test 2: only 1 list
    #
    list_2 = [['user_1', 'user_2', 'user_3']]
    variables = None
    lookup_module_2 = LookupModule()
    result = lookup_run(list_2, variables)
    assert result == [['user_1'], ['user_2'], ['user_3']]
    #
    # Test 3: 2 lists
    #

# Generated at 2022-06-25 11:01:00.415863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)

    assert var_0 == []



# Generated at 2022-06-25 11:01:05.591755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['a', 'b', 'c']
    var_1 = ['d', 'e', 'f']
    var_2 = ['g', 'h', 'i']
    list_0 = [var_0, var_1, var_2]
    var_3 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 11:01:07.998165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    assert var_0 == None


# Generated at 2022-06-25 11:01:15.770274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [lookup_module_0]
    var_1.reverse()
    result = []
    result = var_1.pop()
    while len(var_1) > 0:
        result = combine(result, var_1.pop())
    new_result = []
    for x in result:
        new_result.append(lookup_module_0._flatten(x))
    print(len(new_result))
    assert len(new_result) == 1
    

# Generated at 2022-06-25 11:01:19.938527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    result = lookup_module_0.run(terms_0)

"""
lookup_module_0 = LookupModule()
list_0 = [lookup_module_0]
var_0 = lookup_run(list_0)
"""

# Generated at 2022-06-25 11:01:23.033846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    list_1 = []
    build_variables_0 = BuildVariables()
    build_variables_0.update(dict_0)
    dict_0 = {}
    dict_1 = {}
    dict_0.update(dict_1)
    var_0 = lookup_module_0.run(list_1, build_variables_0, **dict_0)



# Generated at 2022-06-25 11:01:30.055954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    # list of variables, e.g. ['a','b','c','d']
    var_0 = lookup_run(list_0)
    assert var_0 == "nested"

# Generated at 2022-06-25 11:01:38.498125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    var_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 11:01:44.298493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    items = [["apples", "bananas", "carrots"], [1, 2, 3], ["red", "green", "yellow"]]
    lookup_module = LookupModule()
    params = {'terms': items}
    results = lookup_module.run(**params)
    assert len(results) == 9
    assert results[0] == ['apples', 1, 'red']
    assert results[1] == ['apples', 2, 'green']
    assert results[2] == ['apples', 3, 'yellow']
    assert results[3] == ['bananas', 1, 'red']
    assert results[4] == ['bananas', 2, 'green']
    assert results[5] == ['bananas', 3, 'yellow']
    assert results[6] == ['carrots', 1, 'red']

# Generated at 2022-06-25 11:01:56.459682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    try:
        lookup_module_0 = LookupModule()
        list_0 = [lookup_module_0]
        var_0 = lookup_module_0.run(list_0)
        if var_0 != 'PASSED':
            raise Exception("Failed Test: LookupModule_run")
    except Exception:
        print("Exception: LookupModule_run")
        raise Exception


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:02:02.138935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ["A", "B"]
    var_1 = ["a", "b"]
    var_2 = ["1", "2"]
    test_var = [var_0, var_1, var_2]
    lookup_module_0 = LookupModule()
    lookup_module_0.run(test_var)

# Generated at 2022-06-25 11:02:04.791533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    var_1 = lookup_module_1.run(list)
    var_2 = lookup_module_2.run(list)
    var_3 = lookup_module_3.run(list)


# Generated at 2022-06-25 11:02:06.563247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == [['1', '1'], ['2', '2']]


# Generated at 2022-06-25 11:02:10.854734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 11:02:17.341845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = [([1, 2, 3],), {'variables': None}]
    if True:
        lookup_module_0 = LookupModule()
        list_0 = [lookup_module_0]
        var_0 = lookup_run(list_0)
        var_1 = lookup_module_0.run(*args_0[0], **args_0[1])
        assert var_1 is None


# Generated at 2022-06-25 11:02:24.694874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the original module used print statements...
    import sys
    backup = sys.stdout
    backup2 = sys.stderr

    # ...but we will use a dummy object
    class Dummy(object):
        def write(self, str):
            pass

    sys.stdout = Dummy()
    sys.stderr = Dummy()

    lookup_module = LookupModule()
    list = ['one', 'two', 'three']
    nested_list = ['one', 'two', 'three']
    # the original module called the ansible-specific function `lookup_run`
    result = lookup_module.run(nested_list, isinstance(nested_list, list))
    assert result == [list], result

    # the original module uses print statements, so restore the std streams
    sys.stdout = backup
   

# Generated at 2022-06-25 11:02:32.646229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms=0)
    assert result_0 == 0
    result_1 = lookup_module_0.run(terms=1)
    assert result_1 == 1
    result_2 = lookup_module_0.run(terms=2)
    assert result_2 == 2
    result_3 = lookup_module_0.run(terms=3)
    assert result_3 == 3
    result_4 = lookup_module_0.run(terms=4)
    assert result_4 == 4
    result_5 = lookup_module_0.run(terms=5)
    assert result_5 == 5
    result_6 = lookup_module_0.run(terms=6)
    assert result_6 == 6

# Generated at 2022-06-25 11:02:36.870327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['lookup_module_0']
    var_0 = lookup_run(list_0)


# Generated at 2022-06-25 11:02:44.083274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    var_0 = lookup_run(list_0)
    var_1 = lookup_run(list_0)
    var_2 = lookup_run(list_0)
    var_3 = lookup_run(list_0)
    var_4 = lookup_run(list_0)
    var_5 = lookup_run(list_0)


# Generated at 2022-06-25 11:02:58.610730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[[2, 3],[4, 5],[6, 7],[8, 9],[10, 11],[12, 13],[14, 15],[16, 17],[18, 19],[20, 21]]]
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == [[[4, 10, 16, 22, 28, 34, 40, 46, 52, 58], [5, 11, 17, 23, 29, 35, 41, 47, 53, 59]]]


# Generated at 2022-06-25 11:03:04.792150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_1]
    arg_0 = lookup_run(list_0)
    # Assert statements
    if not lookup_module_0:
        print('is false')
    if not lookup_module_1:
        print('is false')
    # Raise error if test fails
    raise AssertionError


# Generated at 2022-06-25 11:03:09.263840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_module = LookupModule()
    var = lookup_module._lookup_variables(['a', 'b'], {'a': 'b'})
    list_0 = [var]
    var_0 = lookup_module.run(list_0)



# Generated at 2022-06-25 11:03:12.955973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["alice", "bob"], ["clientdb", "employeedb", "providerdb"]]
    var_1 = dict()
    var_1['vars'] = dict()
    var_1['vars']['vars'] = dict()
    var_2 = lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 11:03:22.591350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the fucntion with render_dict as the parameter
    render_dict = dict()
    render_dict[u'a'] = u'b'
    render_dict[u'hostvars'] = dict()
    render_dict[u'hostvars'][u'ip-10-0-0-1'] = dict()
    render_dict[u'hostvars'][u'ip-10-0-0-1'][u'node_hostname'] = u'foo'
    render_dict[u'hostvars'][u'ip-10-0-0-2'] = dict()
    render_dict[u'hostvars'][u'ip-10-0-0-2'][u'node_hostname'] = u'bar'

# Generated at 2022-06-25 11:03:26.196799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule_instance()
    terms_0 = []
    variables_0 = [LookupModule_instance()]
    var_0 = lookup_module_0.run(terms_0,variables_0)
    test_0 = isinstance(var_0,list)
    test_1 = isinstance(var_0,AnsibleError)
    test_2 = isinstance(var_0,AnsibleUndefinedVariable)
    assert test_0 and test_2

# Generated at 2022-06-25 11:03:27.922512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:03:30.459131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = lookup_module_0
    result = lookup_module_0.run(terms_0)

if __name__ == '__main__':
    test_LookupModule_run()