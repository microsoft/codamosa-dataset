

# Generated at 2022-06-25 10:53:37.416168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.listify
    lookup_module_1 = LookupModule()
    list_1 = ['alice', 'bob']
    list_2 = ['clientdb', 'employeedb', 'providerdb']
    list_3 = [list_1, list_2]
    list_vars_0 = dict()
    # Test the return type of method run for this class
    assert(isinstance(lookup_module_1.run(list_3, list_vars_0), ansible.utils.listify.listify))

# Generated at 2022-06-25 10:53:44.247617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_vars = {}
    my_terms = [["a", "b", "c"], [1, 2, 3]]
    my_result = lookup_module_1.run(my_terms, my_vars)
    assert my_result == [['a', 1], ['a', 2], ['a', 3], ['b', 1], ['b', 2], ['b', 3], ['c', 1], ['c', 2], ['c', 3]]


# Generated at 2022-06-25 10:53:49.255539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([['a', 'b'], ['1', '2', '3']])
    expected = [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3']]
    assert result == expected


# Generated at 2022-06-25 10:53:52.784316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    my_list = [
    'EXAMPLES',
    'DESCRIPTION'
    ]
    lookup_module_0.run(my_list)


# Generated at 2022-06-25 10:53:55.606270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:54:03.490356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure the function throws an error when no lists are given
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[], variables={})
    except AnsibleError as e:
        assert e.message == 'with_nested requires at least one element in the nested list'
    except Exception as e:
        assert False, 'AnsibleError not raised when with_nested called with no lists'

    # Make sure that with_nested will throw an error if a variable used in nested
    # play is undefined
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:54:11.055803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Argument spec is (self, terms, variables, **kwargs):
    assert lookup_module_0.run([["A","B"],["1","2"]]) == [["A","1"],["A","2"],["B","1"],["B","2"]]
    assert lookup_module_0.run([["A","B"],["1","2"],["C","D"]]) == [["A","1","C"],["A","1","D"],["A","2","C"],["A","2","D"],["B","1","C"],["B","1","D"],["B","2","C"],["B","2","D"]]
    assert lookup_module_0.run([["A","B"],[]]) == [["A"],["B"]]

# Generated at 2022-06-25 10:54:20.710875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs = {}
    lookup_module_0 = LookupModule()
    terms_1 = [['a', 'b'], ['c', 'd']]
    variables = {}
    returned_0 = lookup_module_0.run(terms_1, variables, **kwargs)
    assert returned_0 == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]

    terms_2 = [["a", "b"], ["c", "d"], ["e", "f"]]
    variables = {}
    returned_1 = lookup_module_0.run(terms_2, variables, **kwargs)

# Generated at 2022-06-25 10:54:31.141664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest
    lookup_module_0 = LookupModule()
    terms_dict = dict()
    terms_dict['_terms'] = ['ansible_eth0.ipv4.address']
    terms = terms_dict['_terms']
    variables_dict = dict()
    variables_dict['ansible_eth0'] = dict()
    variables_dict['ansible_eth0']['ipv4'] = dict()
    variables_dict['ansible_eth0']['ipv4']['address'] = '1.2.3.4'
    variables = variables_dict
    assert isinstance(lookup_module_0.run(terms, variables), list) is True


# Generated at 2022-06-25 10:54:35.556813
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    assert lookup_module_1.run(['a', 'b']) == [['a', 'a'], ['a', 'b'], ['b', 'a'], ['b', 'b']]

    with pytest.raises(AnsibleUndefinedVariable):
        assert lookup_module_1.run([[]])

# Generated at 2022-06-25 10:54:42.069278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    assert lookup_module_0.run(terms_0) == []


# Generated at 2022-06-25 10:54:50.861914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    a = lookup_module.run([['alpha']], ['alpha'])
    assert a == [['alpha']]
    b = lookup_module.run([['alpha', 'beta'], ['1', '2', '3']], [['alpha', 'beta'], ['1', '2', '3']])
    assert b == [['alpha', '1'], ['alpha', '2'], ['alpha', '3'], ['beta', '1'], ['beta', '2'], ['beta', '3']]
    c = lookup_module.run([[['alpha', 'beta'], ['1', '2', '3']], [4, 5]], [[['alpha', 'beta'], ['1', '2', '3']], [4, 5]])

# Generated at 2022-06-25 10:54:53.370409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_of_str = ['a', 'b', 'c']
    lookup_module_0 = LookupModule()
    result = lookup_module_0._combine(list_of_str, list_of_str)
    assert result == [['a', 'a'], ['b', 'b'], ['c', 'c']]


# Generated at 2022-06-25 10:55:01.391058
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # *************************************************************
  # ***************** TEST CASE 1 ********************************
  print("\n\n\n")
  print("*************  TEST CASE 1 *************")
  print("\n")
  lookup_module_1 = LookupModule()
  # data1 = [ [ ['a','b'], ['c','d'] ], [ ['e','f'], ['g','h'] ] ]
  data1 = [ ['a','b'], ['e','f'] ]
  data2 = [ ['c','d'], ['g','h'] ]
  data3 = [ ['i','j'], ['k','l'] ]
  terms_1 = [data1,data2,data3]
  # results = lookup_module_1.run(terms_1, None)

# Generated at 2022-06-25 10:55:04.582780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {}
    assert lookup_module_0.run(terms_0) == []


# Generated at 2022-06-25 10:55:09.282365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[], ['foo', 'bar']]) == [['foo', 'bar']]

# Generated at 2022-06-25 10:55:15.791214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ ['a', 'b'], ['c', 'd'], ['e', 'f'], ['g', 'h'] ]
    variables = {}
    lookup_module_0 = LookupModule()
    print(lookup_module_0.run(terms=terms, variables=variables))


# Generated at 2022-06-25 10:55:19.595020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # It's not clear how to create a useful test case for the Ansible code here.
  # The code returns a list of lists, and this unit test simply checks that the output is a list.
  lookup_module = LookupModule()
  terms = [
    [ "foo", "bar" ],
    [ "one", "two", "three" ]
  ]
  result = lookup_module.run(terms)
  assert isinstance(result, list)

# Generated at 2022-06-25 10:55:28.636741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()

  # @todo: Add a test for the run method of LookupModule.include_role
  # @body: The test should check if the method returns the proper value, without throwing an exception.
  # @body: Ideally, the test should check the return value for all possible inputs of the method.

  # @todo: Add a test for the run method of LookupModule.run
  # @body: The test should check if the method returns the proper value, without throwing an exception.
  # @body: Ideally, the test should check the return value for all possible inputs of the method.

  # @todo: Add a test for the run method of LookupModule._combine
  # @body: The test should check if the method returns the proper value, without throwing an exception.
  # @body: Ideally, the test

# Generated at 2022-06-25 10:55:32.287238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    myterms = [['a', 'b', 'c', 'd'], ['1', '2', '3', '4']]
    result = lookup_module_0.run(myterms)
    assert len(result) == 16


# Generated at 2022-06-25 10:55:39.549201
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Make a new instance of our lookup module
    lookup_module_0 = LookupModule()

    # Set args for the test case
    args_0 = [
        [
            [
                "a",
                "b"
            ],
            [
                "1",
                "2"
            ]
        ]
    ]

    # Call the run function, pass in our args
    result_0 = lookup_module_0.run(args_0)

    # Runs a single test case in test_case_0
    assert(result_0 == [
        ["a", "1"],
        ["b", "1"],
        ["a", "2"],
        ["b", "2"]
    ])


# Generated at 2022-06-25 10:55:48.414971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_case = [
        [
            [
                'alice',
                'bob'
            ],
            [
                'clientdb',
                'employeedb',
                'providerdb'
            ]
        ],
        {
            '_ansible_check_mode': False,
            '_ansible_debug': False,
            '_ansible_diff': False,
            '_ansible_no_log': False,
            'ansible_play_batch': None,
            'ansible_play_hosts': [
                'localhost'
            ]
        }
    ]
    result = lookup_module.run(
        terms=test_case[0],
        variables=test_case[1])

# Generated at 2022-06-25 10:55:56.905332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_vars = {
    'l1': ['alice', 'bob']
    , 'l2': ['client', 'employee']
    , 'l3': ['a', 'b', 'c']
    }

    my_test_terms = "(l1, l2, l3)"

    #
    # test what happens when you have nothing
    #
    my_test_terms = ""
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(my_test_terms, variables=my_vars)
        assert False
    except AnsibleError:
        assert True
    except Exception as e:
        print(e)
        assert False
    #
    # test what happens when you have 1 item
    #
    my_test_terms = "(l1)"
   

# Generated at 2022-06-25 10:56:05.172811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar.environment.loader = None


# Generated at 2022-06-25 10:56:12.348814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['foo', 'bar', 'baz']
    variables_1 = {'foo': 'eins', 'bar': 'zwei', 'zwei': 'drei', 'baz': 'vier'}
    assert lookup_module_1.run(terms_1, variables_1) == [['eins', 'zwei', 'vier'], ['eins', 'drei', 'vier']]

# Generated at 2022-06-25 10:56:22.206593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    user_list = [ 'alice', 'bob' ]
    pass_list = [ 'clientdb', 'employeedb', 'providerdb' ]
    db_list = [ 'db1', 'db2' ]
    list_of_lists = []
    #list_of_lists.append(user_list)
    #list_of_lists.append(pass_list)
    #list_of_lists.append(db_list)
    list_of_lists.append([1,2,3])
    list_of_lists.append(['a','b','c'])
    list_of_lists.append(['x','y','z'])
    #list_of_lists.append([user_list, pass_list, db_list])
    lookup_module_1 = LookupModule()
    results_1

# Generated at 2022-06-25 10:56:32.122281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['foo', ['bar', 'baz']]) == [['foo', 'bar'], ['foo', 'baz']]
    assert lookup_module.run(['foo', 'bar', 'baz']) == [['foo', 'bar', 'baz']]
    assert lookup_module.run([['foo', 'bar'], 'baz']) == [['foo', 'baz'], ['bar', 'baz']]
    assert lookup_module.run([['foo', 'bar'], ['baz', 'baz2']]) == [['foo', 'baz'], ['foo', 'baz2'], ['bar', 'baz'], ['bar', 'baz2']]


# Generated at 2022-06-25 10:56:40.486723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    # This test will pass
    terms = [ [ 'alice', 'bob' ], [ 'clientdb', 'employeedb', 'providerdb' ] ]

    lookup_module = LookupModule()
    result = lookup_module.run(terms)

    assert result == [ ['alice', 'clientdb'],
                       ['alice', 'employeedb'],
                       ['alice', 'providerdb'],
                       ['bob', 'clientdb'],
                       ['bob', 'employeedb'],
                       ['bob', 'providerdb'],
                     ]


# Generated at 2022-06-25 10:56:48.004216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [['']]
    kwargs_1 = {'variables': {}}
    assert_equal(lookup_module_0.run(terms_1, **kwargs_1), [[]])

    lookup_module_1 = LookupModule()
    terms_2 = [['a']]
    kwargs_2 = {'variables': {}}
    assert_equal(lookup_module_1.run(terms_2, **kwargs_2), [['a']])

    lookup_module_2 = LookupModule()
    terms_3 = [['a']]
    kwargs_3 = {'variables': {}}

# Generated at 2022-06-25 10:56:51.902958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    lookup_module_0.run([[[0, 1], [2, 3]], [[4], [5, 6]]], [{"foo": "bar"}])


# Generated at 2022-06-25 10:57:00.824059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_arguments = [
        [
            [
                'paul'
            ],
            [
                'yusuf'
            ],
            [
                'george'
            ],
            [
                'john'
            ]
        ],
        [
            [
                'harrison'
            ],
            [
                'starr'
            ]
        ]
    ]
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = mock.MagicMock()
    lookup_module_0._loader = mock.MagicMock()
    lookup_module_0.run(input_arguments)

# Generated at 2022-06-25 10:57:03.944701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    result = lookup_instance.run( terms = [ "one", "two" ] )
    # Check if result contains the expected value
    assert result == [ [ "one", "two" ] ]


# Generated at 2022-06-25 10:57:13.591674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = [
        'a',
        'b',
        'c'
    ]
    my_list_1 = [
        '1',
        '2',
        '3'
    ]
    my_list_2 = [
        'i',
        'ii',
        'iii',
        'iv'
    ]
    my_list_3 = [
        {
            'a': 'x'
        }
    ]
    my_list_4 = [
        'Nested',
        'vars',
        'test'
    ]

# Generated at 2022-06-25 10:57:15.395607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

test_case_0()
# End of test_case_0


# Generated at 2022-06-25 10:57:19.783210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    terms = [ [ 'a', 'b', 'c' ], [ 1, 2 ] ]
    variables = { }
    assert lookup_module_run.run(terms, variables) == [ ['a', 1], ['a', 2], ['b', 1], ['b', 2], ['c', 1], ['c', 2] ]


# Generated at 2022-06-25 10:57:28.733366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [["alice", "bob"], ["clientdb", "employeedb", "providerdb"]]
    variables_0 = dict()
    result = LookupModule().run(terms_0, variables_0, **{'undefined_var': 'foo'})
    assert result == [["alice","clientdb"], ["alice","employeedb"], ["alice","providerdb"],
                      ["bob","clientdb"], ["bob","employeedb"], ["bob","providerdb"]]

    terms_1 = [["alice", "bob"], ["clientdb", "employeedb", "providerdb", "admin"],
               ["SELECT", "UPDATE", "DELETE"]]
    variables_1 = dict()

# Generated at 2022-06-25 10:57:30.844807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["[{'item': 'value'}]"], [None])
    lookup_module_0.run([[{'item': 'value'}]], [None])



# Generated at 2022-06-25 10:57:37.791691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiation the object
    lookup_module = LookupModule()
    # Input
    terms = [ 'alice', 'bob' ]
    variables = None 
    kwargs = None
    # Expect result
    result = [ 'alice', 'bob' ]
    # Execute method
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == result


# Generated at 2022-06-25 10:57:42.575485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [['a', 'b', 'c'], ['d', 'e'], ['f', 'g']]
    result = lookup_module_0.run(terms)
    assert len(result) == 12
    assert result[0] == ['a', 'd', 'f']
    assert result[11] == ['c', 'e', 'g']


# Generated at 2022-06-25 10:57:47.337559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Test case with undefined input
    result_case_1 = lookup_module_1.run('foo')
    assert result_case_1 == 'foo'
    # Test case with empty input
    result_case_2 = lookup_module_1.run('')
    assert result_case_2 == ''
    # Test case with empty string input
    result_case_3 = lookup_module_1.run(' ')
    assert result_case_3 == ' '
    # Test case with valid input
    result_case_4 = lookup_module_1.run('foo')
    assert result_case_4 == 'foo'


# Generated at 2022-06-25 10:57:58.816169
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0._templar = Mock()
    lookup_module_0._loader = Mock()
    lookup_module_0._lookup_variables = Mock()
    lookup_module_0._lookup_variables.return_value = [ ['a', 'b', 'c'], ['1', '2', '3'], ['I', 'II', 'III'], ['do', 're', 'mi'] ]


# Generated at 2022-06-25 10:58:05.048464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import StringIO
    import unittest
    output = StringIO.StringIO()
    temp = sys.stderr
    sys.stdout = output
    sys.stderr = output
    try:
        test_case_0()
    finally:
        sys.stderr = temp
    assert re.match("^Traceback (most recent call last):\n  File \".*ansible/plugins/lookup/nested.py\", line \d+, in run\n    raise AnsibleError\(\"with_nested requires at least one element in the nested list\"\)", output.getvalue(), re.M)


if __name__ == '__main__':
    try:
        test_LookupModule_run()
    finally:
        pass

# Generated at 2022-06-25 10:58:11.856202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"params": "qDw", "tags": "Ls"}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0 = lookup_module_0.run()
    var_0 = lookup_module_0.run()

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:58:16.575758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)




# Generated at 2022-06-25 10:58:17.281435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert func_0() == None


# Generated at 2022-06-25 10:58:23.643095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms_0 = ["!factory default"]
  dict_0 = {}
  lookup_module_0 = LookupModule(terms_0, dict_0)
  var_0 = lookup_module_0.run(terms_0, dict_0)
  assert var_0 == [['!factory', 'default']]
  assert var_0[0] == ['!factory', 'default']
  assert len(var_0) == 1
  assert len(var_0[0]) == 2
  terms_1 = ['1', '2']
  dict_1 = {}
  lookup_module_1 = LookupModule(terms_1, dict_1)
  var_1 = lookup_module_1.run(terms_1, dict_1)
  assert var_1[0] == ['1']
  assert var_1

# Generated at 2022-06-25 10:58:34.368154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"foo": [1, 2, 3, 4, 5], "bar": [10, 20, 30, 40, 50]}
    lookup_module_0 = LookupModule(dict_0)
    result = lookup_module_0.run(["bar", "foo"])
    if isinstance(([['bar', 'foo'], ['bar', 'foo'], ['bar', 'foo'], ['bar', 'foo'], ['bar', 'foo']]), (list, type(result))) != True:
        raise Exception("Returned value from run() should be of type list")

    if result != [['bar', 'foo'], ['bar', 'foo'], ['bar', 'foo'], ['bar', 'foo'], ['bar', 'foo']]:
        raise Exception("Incorrect return value from run()")


# Generated at 2022-06-25 10:58:36.014565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    var_0 = lookup_run()



# Generated at 2022-06-25 10:58:40.694185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = []
    var_0 = lookup_module_0.run(list_0)
    # assert 'var_0' (line 35)


# Generated at 2022-06-25 10:58:44.101293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)

# Local Variables:
# compile-command: "pytest -s -v test_k8s_lookup.py"
# End:

# Generated at 2022-06-25 10:58:49.701599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run()
    return


# Generated at 2022-06-25 10:58:51.402592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    assert lookup_module_0.run(["foo", "bar"]) == []


# Generated at 2022-06-25 10:58:53.964204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'lookup_loader': '',
        'lookup_basedir': '',
        'lookup_templar': '',
        'lookup_context': '',
    }
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run('')

# Generated at 2022-06-25 10:58:58.910183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)

# Generated at 2022-06-25 10:59:01.209452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)


# Generated at 2022-06-25 10:59:06.911676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"item": 0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(dict_0)


# Generated at 2022-06-25 10:59:09.219621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'foo': 'bar', 'inventory_hostname': 'testhost', 'omit': 'omit'}
    lookup_module_0 = LookupModule(dict_0)
    result_0 = lookup_module_0.run(['baz'], dict_0)


# Generated at 2022-06-25 10:59:16.771359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule('root')
    var_0.run('undefined', 'undefined')
    var_1 = LookupModule('root')
    var_1.run('undefined', 'undefined')
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_run_0 = lookup_module_0.run(dict_1, dict_2)
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    lookup_module_1 = LookupModule(dict_3)
    lookup_run_1 = lookup_module_1.run(dict_4, dict_5)

# Generated at 2022-06-25 10:59:19.352492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_1 = {'a': "{{x}},{{y}}"}
    lookup_module_1 = LookupModule(dict_1)
    assert lookup_module_1.run(dict_1) == [('a', 'b'), ('a', 'c')]


# Generated at 2022-06-25 10:59:24.939009
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declare variables and constants
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    result = lookup_module_0.run(['foo', ['baz', 'bar']], variables={'foo': 'foo', 'baz': 'baz'})
    assert result == [['foo', 'baz'], ['foo', 'bar']]

# Generated at 2022-06-25 10:59:33.821370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'debug': False,
        'scope': 'one two three',
    }
    lookup_module_2 = LookupModule(dict_0)
    var_1, var_2, var_3, var_4 = lookup_run(dict_0)
    assert (var_1 == [
        ['a', 'b', 'c'],
        ['a', 'b', 'd'],
        ['a', 'b', 'e'],
        ]), ''
    assert (var_2 == ['a', 'b', 'c']), ''
    assert (var_3 == ['a', 'b', 'd']), ''
    assert (var_4 == ['a', 'b', 'e']), ''


# Generated at 2022-06-25 10:59:36.786665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = frozenset(["a", "b"])
    variables_0 = {}
    var_0 = lookup_module_0.run(terms_0, variables_0, **dict_0)
    assert var_0 == [['a', 'b']]


# Generated at 2022-06-25 10:59:38.077026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        '_terms': [[]]
    }
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(dict_0)


# Generated at 2022-06-25 10:59:43.022241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 0


# Generated at 2022-06-25 10:59:49.744827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [["hello", "world"], ["nice", "to meet you"]]
    var_3 = lookup_run(var_1, lookup_module_0)
    assert var_3 == [['hello', 'nice'], ['world', 'to meet you']]

# Generated at 2022-06-25 11:00:01.382399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'undefined_variable': 'defined_variable',
        'defined_variable': 'defined_value',
    }
    lookup_module_0 = LookupModule(dict_0)
    var_1 = [
        'undefined_variable',
        'defined_variable',
    ]
    var_0 = lookup_module_0._lookup_variables(var_1, dict_0)
    var_2 = [
        'defined_variable',
        'undefined_variable',
    ]
    var_3 = lookup_module_0._lookup_variables(var_2, dict_0)

# Generated at 2022-06-25 11:00:11.829741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'item': 'item',
        'terms': None,
        'templar': None,
        'loader': None,
        'variables': ['variables'],
        'result2': None,
        'self': LookupModule(dict_0),
        'my_list': None,
        'x': 'x',
        'result': ['result'],
        'new_result': None,
    }
    lookup_module_0 = LookupModule(dict_0)
    # Run tested method
    result_0 = lookup_module_0.run(dict_0['terms'], dict_0['variables'])
    # Check for method attributes
    assert check_attributes(result_0, dict_0)
    # Check for method body

# Generated at 2022-06-25 11:00:15.300438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_2 = {}
    lookup_module_2 = LookupModule(dict_2)
    str_3 = lookup_module_0.run(dict_2)
    assert str_3 == None


# Generated at 2022-06-25 11:00:21.598098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup for test
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    variables_0 = []
    # Test execution
    try:
        lookup_module_0.run(terms_0, variables_0)
    except AnsibleError as err:
        assert(err.message == "with_nested requires at least one element in the nested list")


# Generated at 2022-06-25 11:00:25.642583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Declare the variable var_0
    var_0 = None
    # Get the value of variable 'inventory_hostname'
    var_0 = inventory_hostname
    # Call function run for class LookupModule with argument list my_list and with keyword arguments 
    # returns a list composed of lists pairing the elements of the input lists
    print(LookupModule.run(var_0))


# Generated at 2022-06-25 11:00:30.753861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:00:33.839788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule().run(['[[1,2]]', '[[3,4]]'])) == 4
    assert len(LookupModule().run([['[1,2]', '3'], ['[', '3,4]']])) == 2

# Generated at 2022-06-25 11:00:45.025321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)
    # Try a legal set of terms
    terms = [
        [ 'alice', 'bob' ],
        [ 'clientdb', 'employeedb', 'providerdb' ]
    ]
    
    expected = [
        ['alice', 'clientdb'],
        ['alice', 'employeedb'],
        ['alice', 'providerdb'],
        ['bob', 'clientdb'],
        ['bob', 'employeedb'],
        ['bob', 'providerdb']
    ]

    # A one-liner to turn it into a list of lists

# Generated at 2022-06-25 11:00:55.407030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _dict = {}
    _dict_0 = {}
    _dict_1 = {}
    _dict_0['var_0'] = _dict_1
    _dict_2 = {}
    _dict_0['var_1'] = _dict_2
    _dict_2['var_2'] = _dict_1

    _dict_0['var_3'] = _dict_1
    _dict_3 = {}
    _dict_0['var_2'] = _dict_3
    _dict_3['var_0'] = _dict_1

    _dict_0['var_4'] = _dict_1
    _dict_4 = {}
    _dict_0['var_4'] = _dict_4
    _dict_4['var_2'] = _dict_1


# Generated at 2022-06-25 11:00:56.628753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_1 = {}
    lookup_module_1 = LookupModule(dict_1)
    var_1 = lookup_module_1.run()


# Generated at 2022-06-25 11:00:58.347882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)

# Generated at 2022-06-25 11:01:03.564067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'x': 'z',
        'y': 'z'
    }
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(None, dict_0, dict_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 1
    assert len(var_0[0]) == 1
    assert var_0[0][0] == dict_0


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:01:08.368519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_1 = {'a': ['a1', 'a2'], 'b': ['b1', 'b2']}
    lookup_module_1 = LookupModule(dict_1)
    var_1 = lookup_run(dict_1)
    assert '[a1, b1]' in var_1
    assert '[a1, b2]' in var_1
    assert '[a2, b1]' in var_1
    assert '[a2, b2]' in var_1
    assert 'a' not in var_1
    assert 'b' not in var_1
    assert 'a1' not in var_1
    assert 'a2' not in var_1
    assert 'b1' not in var_1
    assert 'b2' not in var_1

# Generated at 2022-06-25 11:01:17.593458
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_0 = {
        'dict_1': {
            'foo': 'bar',
        },
        'list_0': [
            'baz',
            'pi',
        ],
        'list_1': [
            'lemon pie',
            'lemon custard pie',
            'lemon meringue pie',
        ],
        'list_2': [
            'test',
            '0',
        ],
        'str_0': 'hi',
        'str_1': 'noob',
    }

    lookup_module_0 = LookupModule(dict_0)

# Generated at 2022-06-25 11:01:21.286059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)
    if not  equals(var_0,None):
        print("Failed")


# Generated at 2022-06-25 11:01:26.373911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)



# Generated at 2022-06-25 11:01:31.919600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'data_0': [
            [
                'list_0',
                'list_1'
            ],
            ['list_2']
        ],
        'variable_0': 'list_0'
    }
    lookup_module_0 = LookupModule(dict_0)
    str_0 = test_run(dict_0)
    assert str_0 == 'list_0', 'incorrect value for str_0'


# Generated at 2022-06-25 11:01:39.304364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)

    # AssertionError: expected {'failed': True, 'msg': 'with_nested requires at least one element in the nested list'} but got [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    # assert dict_0['msg'] == 'with_nested requires at least one element in the nested list'

    # AssertionError: expected {'failed': True, 'msg': 'with_nested requires at least one element in the nested list'} but got [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    # assert dict_0['failed'] == True

    #

# Generated at 2022-06-25 11:01:40.692217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run()

# Generated at 2022-06-25 11:01:42.959363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = ['a', 'b']
    variables_0 = dict_0
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == [['a', 'b']]


# Generated at 2022-06-25 11:01:45.282711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = _test_LookupModule__combine(run, 0)


# Generated at 2022-06-25 11:01:50.292187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dummy_0 = ['dummy', 'dummy', 'dummy']
    dummy_1 = ['dummy', 'dummy', 'dummy']
    dummy_2 = ['dummy', 'dummy', 'dummy']
    dummy_3 = ['dummy', 'dummy', 'dummy']
    dummy_4 = ['dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy']
    dummy_5 = ['dummy', 'dummy', 'dummy']
    dummy_6 = ['dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy']

# Generated at 2022-06-25 11:01:52.173017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)

# Generated at 2022-06-25 11:01:56.005384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)


# Generated at 2022-06-25 11:02:05.221452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run for the following i/o combinations
    # 1. (['a', 'b', 'c'], [1, 2, 3])
    # 2. (['a', 'b', 'c'], [1, 2, [3, 4, 5]])
    # 3. (['a', 'b', 'c'], [[100, 200], [300, 400]])
    # 4. (['a', 'b', 'c'], [[100, [300, 400]], [200, [300, [400]]]]
    # 5. (['a', 'b', 'c'], ['a', 'b', 'c'])

    # Set up parameters of input for test scenario 1
    l0 = ['a', 'b', 'c']
    l1 = [1,2,3]

# Generated at 2022-06-25 11:02:15.970457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms = [
      [
        'alice',
        'bob'
      ],
      [
        'clientdb',
        'employeedb',
        'providerdb'
      ]
    ]
    dict_1 = {}
    lookup_module_0.run(terms, dict_1)


# Generated at 2022-06-25 11:02:18.323456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_1 = {}
    lookup_module_1 = LookupModule(dict_1)
    var_1 = lookup_module_1.run(dict_1, dict_1, dict_1)


# Generated at 2022-06-25 11:02:25.443958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance_0 = LookupModule()
    dict_0 = {}
    assertion_failure_0 = 0
    try:
        lookup_instance_0.run(dict_0)
        assertion_failure_0 = 1
    except AnsibleError as exception_instance_0:
        if exception_instance_0._ansible_context['exception_type'] == 'AnsibleError':
            # Exception was raised as expected
            pass
        else:
            assertion_failure_0 = 1
    if assertion_failure_0:
        raise AssertionError('AssertionError')
    dict_1 = {}
    dict_1[0] = {}
    dict_1[1] = {}
    dict_1[2] = {}
    dict_2 = {}
    dict_2[0] = {}
   

# Generated at 2022-06-25 11:02:33.196291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['terms'] = dict_1 = dict()
    dict_1['Var_0'] = list_0 = list()
    list_0.append(str_0)
    list_0.append(dict_2 = dict())
    dict_2['Var_1'] = list_1 = list()
    list_1.append(str_1)
    list_1.append(str_2)
    dict_1['Var_2'] = list_2 = list()
    list_2.append(str_3)
    list_2.append(dict_3 = dict())
    dict_3['Var_3'] = list_3 = list()
    list_3.append(str_4)
    list_3.append(str_5)
    dict_0['variables']

# Generated at 2022-06-25 11:02:34.813636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    assert isinstance(lookup_module_0.run(), list), 'Incorrect type returned'

# Generated at 2022-06-25 11:02:40.562350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check for correct exception
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    try:
        var_0 = lookup_module_0.run(dict_0)
    except AnsibleError:
        var_0 = True
    assert var_0 == True


# Generated at 2022-06-25 11:02:42.638283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 11:02:48.139343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = ['test', 'test']
    var_0 = lookup_module_0.run(terms_0, dict_0)
    assert var_0 == [(['test'], 'test')]
    dict_1 = dict()
    lookup_module_1 = LookupModule(dict_1)
    terms_1 = ['test', 'test', 'test']
    var_1 = lookup_module_1.run(terms_1, dict_1)
    assert var_1 == [(['test'], 'test', 'test')]


# Generated at 2022-06-25 11:02:55.357016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('testing run')
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    test_var_0 = [["", ""], ["", ""]]
    var_0 = lookup_module_0.run(terms=test_var_0)
    assert var_0  # TODO: fix this assert


# Generated at 2022-06-25 11:02:58.576885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule(dict())
  assert lookup_module.run([], dict()) == None


# Generated at 2022-06-25 11:03:09.959126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_num = 0
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)
    assert var_0 == []
    test_case_num += 1
    dict_0 = {'0': '0', '1': '1', '3': '3'}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)
    assert var_0 == [{'0': '0', '1': '1', '3': '3'}]
    test_case_num += 1
    dict_0 = {'1': '1', '2': '2', '3': '3'}
    lookup_module_0 = LookupModule(dict_0)


# Generated at 2022-06-25 11:03:15.971457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'2': [1, 2, 3, 4]}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run([[1, 2, 3, 4], ['2']])
    assert var_0[0] == [2, 3, 4]
    assert var_0[1] == [1, 2, 3]
    assert var_0[2] == [1, 1, 2]
    assert var_0[3] == [1, 1, 1]
    var_1 = lookup_module_0.run([[1, 2, 3, 4], ['2'], ['a']])
    assert len(var_1) == 1
    assert var_1[0] == [1, 1]


# Generated at 2022-06-25 11:03:19.146930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'str'
    var_1 = LookupModule.run(terms)


# Generated at 2022-06-25 11:03:22.862485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arg_0 = []
    arg_1 = {}
    obj_0 = LookupModule(arg_0)
    ret_0 = obj_0.run(arg_1)
    pass



# Generated at 2022-06-25 11:03:24.130970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(dict_0)

# Generated at 2022-06-25 11:03:29.074982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"lookup_file": "file/path"}
    lookup_module_0 = LookupModule(dict_0)


if __name__ == '__main__':
    test_LookupModule_run()