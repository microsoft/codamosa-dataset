

# Generated at 2022-06-25 10:53:35.943246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [['a'], ['b', 'c']]
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_1.run(terms)
    assert excinfo.value.message == 'with_nested requires at least one element in the nested list'



# Generated at 2022-06-25 10:53:38.255011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = list()
    result = lookup_module_0.run(terms)
    assert len(result) == 0


# Generated at 2022-06-25 10:53:41.566556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    obj = lookup_module_obj.run(["[1, 2]", "['a', 'b']"], None)
    obj = lookup_module_obj.run(["[1, 2]", "['a', 'b']"], None)



# Generated at 2022-06-25 10:53:46.220325
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up test case
    lookup_module_1 = LookupModule()

    # Call run method
    result_1 = lookup_module_1.run([[['a1', 'a2'], ['b1', 'b2']], [['c1', 'c2']]])

    # Check
    assert result_1 == [ ['a1', 'a2', 'c1', 'c2'], ['a1', 'a2', 'c1', 'c2'], ['b1', 'b2', 'c1', 'c2'], ['b1', 'b2', 'c1', 'c2'] ]

# Generated at 2022-06-25 10:53:52.940588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]
    assert lookup_module_1.run([[1, 2], [3, 4], [5, 6]]) == [[1, 3, 5], [1, 3, 6], [1, 4, 5], [1, 4, 6], [2, 3, 5], [2, 3, 6], [2, 4, 5], [2, 4, 6]]


# Generated at 2022-06-25 10:53:56.762534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = "loader"
    lookup_module_0._templar = "templar"
    terms_0 = []
    variables_0 = "variables"
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == []



# Generated at 2022-06-25 10:54:03.984352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['foo', 'bar'], 'baz']
    variables_0 = {'foo': 'bar'}
    actual_result_0 = lookup_module_0.run(terms_0, variables_0)

    assert actual_result_0 == ['foobaz', 'barbaz']

# Generated at 2022-06-25 10:54:11.822489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Exercise 0
    # Exercise 0
    terms_0 = [
        [
            [
                1,
                2
            ],
            [
                3
            ]
        ],
        [
            [
                5,
                6
            ]
        ]
    ]

    # Exercise 0
    # Exercise 0
    variables_0 = {
        "key1": "value1",
        "key2": 2
    }

    # Exercise 0
    # Exercise 0
    actual_result_0 = lookup_module_0.run(terms_0, variables_0)

    # Verification 0
    # Verification 0

# Generated at 2022-06-25 10:54:21.682200
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for supplied argc == 0 (zero)
    lookup_module_1 = LookupModule()
    lookup_module_1.run([])

# Generated at 2022-06-25 10:54:31.211421
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0_list = ["{% for item in ['clientdb', 'employeedb', 'providerdb'] %} {% if loop.index == 1 %} {{ item }} {% else %}{{ item }}{{ ',' if not loop.last }} {% endif %}{% endfor %}"]
    terms_1_list = []
    terms_2_list = []

    terms_0 = lookup_module_0._lookup_variables(terms_0_list, None)

    terms_1 = lookup_module_0._lookup_variables(terms_1_list, None)

    terms_2 = lookup_module_0._lookup_variables(terms_2_list, None)


# Generated at 2022-06-25 10:54:35.448070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [["a"],["1","2"]]
    variables = None
    kwargs = {}
    result = lookup_module_1.run(terms_1, variables, **kwargs)
    assert result == ["a", ["a", "1"]]


# Generated at 2022-06-25 10:54:42.262423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    my_list = []
    lookup_module_run_3 = lookup_module_2.run(my_list)
    assert isinstance(lookup_module_run_3, list)
    assert lookup_module_run_3 == []
    my_list = []
    lookup_module_run_5 = lookup_module_2.run(my_list)
    assert isinstance(lookup_module_run_5, list)
    assert lookup_module_run_5 == []
    my_list = []
    lookup_module_run_7 = lookup_module_2.run(my_list)
    assert isinstance(lookup_module_run_7, list)
    assert lookup_module_run_7 == []

# Generated at 2022-06-25 10:54:49.105477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [['alice, bob'], ['clientdb, employeedb, providerdb']]
    variables_0 = {}
    kwargs_0 = {
        'loader': 'loader',
        'fail_on_undefined': True,
        'templar': 'templar',
    }
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result == [
        ['alice, clientdb'],
        ['alice, employeedb'],
        ['alice, providerdb'],
        ['bob, clientdb'],
        ['bob, employeedb'],
        ['bob, providerdb'],
    ]


# Generated at 2022-06-25 10:55:00.749523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test for method run of class LookupModule on input ['[[1, 2, 3], [4, 5, 6]]', {'env': {'ANSIBLE_OPTS': '-vvv'}}]
    result_0 = lookup_module_0.run(["[[1,2,3], [4,5,6]]"], )
    assert result_0 == [[1, 2, 3, 4, 5, 6]]
    # Test for method run of class LookupModule on input ['[[1, 2, 3], [4, 5, 6]]', {'env': {'ANSIBLE_OPTS': '-vvv'}}]
    result_1 = lookup_module_0.run(["[[1,2,3], [4,5,6]]"], )

# Generated at 2022-06-25 10:55:05.386961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_list = [['a', 'b'], [1, 2]]
    lookup_module = LookupModule()
    assert [['a', 1], ['a', 2], ['b', 1], ['b', 2]] == lookup_module.run(test_list, variables=None, **{})

# Generated at 2022-06-25 10:55:07.494261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(["a","b"],["c","d"])
    assert result == [["a","c"],["a","d"],["b","c"],["b","d"]]

# Generated at 2022-06-25 10:55:17.512210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(["https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/plugins/lookup/nested.py"]) == [["https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/plugins/lookup/nested.py"]]
    assert lookup_module_1.run([["https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/plugins/lookup/nested.py"]]) == [["https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/plugins/lookup/nested.py"]]

# Generated at 2022-06-25 10:55:20.212128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_0()


# Generated at 2022-06-25 10:55:23.079755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True
    # lookup_module_0 = LookupModule()
    # assert lookup_module_0.run(terms, variables=None, **kwargs) == "nothing"


# Generated at 2022-06-25 10:55:24.312876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([]) == []


# Generated at 2022-06-25 10:55:31.486784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = None
    var_3 = [var_2]
    # returns the map between elements of the two lists
    var_4 = lookup_module_0.run(var_3, var_2)
    assert var_4 == [2, 3, 5, 7, 11, 13]

# Generated at 2022-06-25 10:55:33.352653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(test_case_0())
# Main function for testing

# Generated at 2022-06-25 10:55:38.250938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)



# Generated at 2022-06-25 10:55:47.936405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = []
    var_1 = lookup_module_0.run(my_list)
    #assert var_1 == "foo"


if __name__ == "__main__":
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.listify import listify_lookup_plugin_terms

    module = AnsibleModule(
        argument_spec={
            '_raw': dict(required=True),
        },
    )

    lookup_plugin = LookupModule()

    try:
        result = lookup_plugin.run(module.params['_raw'], variables=dict())
    except AnsibleError as e:
        module.fail_json(msg=str(e))


# Generated at 2022-06-25 10:55:57.404364
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test setup
    terms = [['Alice', 'Bob'], ['Alice'], ['Bob']]
    lookup_module = LookupModule()

    # Unit test execution
    result = lookup_module.run(terms, [])

    # Unit test assertion
    assert result == [['Alice', 'Alice'], ['Alice', 'Bob'], ['Bob', 'Alice'], ['Bob', 'Bob']]


    # Unit test setup
    terms = [['Alice', 'Bob'], ['Alice'], ('Bob',)]
    lookup_module = LookupModule()

    # Unit test execution
    result = lookup_module.run(terms, [])

    # Unit test assertion
    assert result == [['Alice', 'Alice'], ['Alice', 'Bob'], ['Bob', 'Alice'], ['Bob', 'Bob']]

    # Unit test setup


# Generated at 2022-06-25 10:55:59.375639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate class
    lookup_module = LookupModule()

    # Call method
    lookup_run(lookup_module)


# Generated at 2022-06-25 10:56:07.096511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   data = {'terms': [1, 2, 3], 'variables': None, 'kwargs': {}}
   l = LookupModule()
   l.run(data['terms'], data['variables'], **data['kwargs'])
   assert isinstance(l, LookupModule)
   assert (isinstance(data, dict))
   assert (isinstance(data['terms'], (list, tuple)))
   assert (isinstance(data['variables'], dict))



# Generated at 2022-06-25 10:56:09.939356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:56:18.069076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = [["alice", "bob"], ["clientdb", "employeedb", "providerdb"]]
    lookup_module_1 = LookupModule()
    var_3 = lookup_module_1.run(var_2)
    #assert len(var_3) == 6
    assert var_3 == [["alice", "clientdb"], ["alice", "employeedb"], ["alice", "providerdb"], ["bob", "clientdb"], ["bob", "employeedb"], ["bob", "providerdb"]]


# Generated at 2022-06-25 10:56:20.467868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:56:25.454362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_1 = [lookup_module_1, lookup_module_2]
    var_2 = lookup_module_0.run(var_1)

# Generated at 2022-06-25 10:56:26.683252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()
    lookup_module.run()


# Generated at 2022-06-25 10:56:37.680898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['Alice', 'Bob', 'Carol', 'Dave']
    var_1 = ['1', '2', '3']
    var_2 = ['A', 'B', 'C']
    var_3 = ['i', 'ii', 'iii']
    var_4 = ['do', 're', 'mi']
    var_5 = ['alpha', 'beta', 'gamma']
    var_6 = ['al', 'be', 'go']
    var_7 = ['first', 'second', 'third']
    var_8 = [var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7]
    var_9 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 10:56:42.516702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_0 = []
    var_0.append(lookup_module_0)
    var_0.append(lookup_module_1)
    var_0.append(lookup_module_2)
    var_0.reverse()
    var_1 = lookup_module_0.run(var_0)
    if (var_1 == True):
        print("Unit test for method run of class LookupModule: PASS")
    else:
        print("Unit test for method run of class LookupModule: FAIL")


# Generated at 2022-06-25 10:56:46.758574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [lookup_module_0]
    var_2 = {}
    var_0 = lookup_run(var_1, var_2)
    # Call start with valid parameter!
    assert var_0 == []
    # Call start with valid parameter!
    assert var_0 == []
    # Call start with valid parameter!
    assert var_0 == []
    # Call start with valid parameter!
    assert var_0 == []



# Generated at 2022-06-25 10:56:50.585208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_8 = ['list1', 'list2']
    var_11 = [var_8]
    var_21 = lookup_run(var_11)
    assert isinstance(var_21, list) == True

# Generated at 2022-06-25 10:56:59.975758
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialization of LookupModule object
    lookup_run = LookupModule()

    var_0 = [lookup_run, lookup_run]
    var_1 = lookup_run.run(var_0)

    # Verify expected behavior
    assert var_1 == []

    var_0 = [lookup_run, lookup_run]
    var_1 = lookup_run.run(var_0)

    # Verify expected behavior
    assert var_1 == [lookup_run, lookup_run]

    var_0 = [lookup_run, lookup_run]
    var_1 = lookup_run.run(var_0)

    # Verify expected behavior
    assert var_1 == []

    var_0 = [lookup_run, lookup_run]
    var_1 = lookup_run.run(var_0)



# Generated at 2022-06-25 10:57:03.833190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_6 = metadata  # noqa F841
    lookup_module_4 = LookupModule()
    terms = [1, 2, 3, 4]
    var_5 = lookup_module_4.run(terms)
    assert isinstance(var_5, object)


# Generated at 2022-06-25 10:57:09.550517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = [['a', 'b', 'c'], ['X', 'Y', 'Z']]
    lookup_module_0 = LookupModule()
    var_3 = lookup_module_0.run(var_2)
    assert var_3 == [('a', 'X'), ('a', 'Y'), ('a', 'Z'), ('b', 'X'), ('b', 'Y'), ('b', 'Z'), ('c', 'X'), ('c', 'Y'), ('c', 'Z')]


# Generated at 2022-06-25 10:57:17.470794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule().run(['a', 'b'])) == 2
    assert LookupModule().run(['a', 'b'])[0] == ['a']
    assert LookupModule().run(['a', 'b'])[1] == ['b']
    assert len(LookupModule().run(['a', 'b'], [True, False])) == 2
    assert LookupModule().run(['a', 'b'], [True, False])[0] == ['a']
    assert LookupModule().run(['a', 'b'], [True, False])[1] == ['b']



# Generated at 2022-06-25 10:57:26.296940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_1 = lookup_module._flatten(["foo", "bar", "baz"])
    var_2 = lookup_module._combine(["1", "2", "3"], ["4", "5", "6"])
    var_3 = lookup_module._combine(["1", "2", "3"], ["4", "5", "6", "7", "8", "9"])
    var_4 = lookup_module._lookup_variables(["foo"], "bar")

# Generated at 2022-06-25 10:57:37.130523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert 'UNIT_TEST_FAILED' == lookup_module_0.run([])
    assert 'UNIT_TEST_FAILED' == lookup_module_0.run([], [])
    assert 'UNIT_TEST_FAILED' == lookup_module_0.run([], [], {})
    assert 'UNIT_TEST_FAILED' == lookup_module_0.run([], {}, {})
    assert 'UNIT_TEST_FAILED' == lookup_module_0.run([{}, {}], {}, {})
    assert 'UNIT_TEST_FAILED' == lookup_module_0.run([{}, {}], {}, {'term': 1, 'k' : 18})

# Generated at 2022-06-25 10:57:45.403739
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0._templar = lookup_module_1
    lookup_module_0._loader = lookup_module_1
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_0._loader = lookup_module_3
    lookup_module_0._loader = lookup_module_2
    lookup_module_0._loader = lookup_module_1
    lookup_module_0._loader = lookup_module_3
    lookup_module_0._loader = lookup_module_3
    lookup_module_1._loader = lookup_module_3
    var_4 = [lookup_module_0, lookup_module_0]

# Generated at 2022-06-25 10:57:56.108732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0
    var_1 = [lookup_module_0, lookup_module_0]
    var_2 = lookup_module_0
    var_3 = [lookup_module_0, lookup_module_0]
    var_4 = lookup_module_0
    var_5 = [lookup_module_0, lookup_module_0]
    var_6 = lookup_module_0
    var_7 = [lookup_module_0, lookup_module_0]
    var_8 = lookup_module_0
    var_9 = [lookup_module_0, lookup_module_0]
    var_10 = lookup_module_0
    var_11 = [lookup_module_0, lookup_module_0]
   

# Generated at 2022-06-25 10:57:57.113550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    result = lookupModule.run(terms, variables, **kwargs)
    assert result == expected


# Generated at 2022-06-25 10:58:00.746298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert 1
  # We could test the argument types and / or expected exception types here.
  # We would need to monkey-patch LookupBase.lookup() to supply a dummy
  # environment.


# Generated at 2022-06-25 10:58:06.124487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:58:08.312856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 10:58:10.202368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:58:21.304429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Implicit pattern of this test case
    var_1 = ['foo', 'bar']
    # Implicit pattern of this test case
    var_2 = ['baz']
    var_3 = [var_2]
    var_4 = [var_2]
    # Explicit templating of this test case
    var_5 = [var_1, var_3]
    # Explicit templating of this test case
    var_6 = []
    # Explicit pattern of this test case
    var_7 = ['foo', 'bar']
    var_8 = {'var_7': var_7}
    # Explicit pattern of this test case
    var_9 = ['foo', 'bar']
    var_10 = ['baz']
    var_11 = [var_10]
    # Explicit pattern of this test case
    var_

# Generated at 2022-06-25 10:58:31.025911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0

    if False:

        # Call method run
        var_0.run(None)
    else:
        pass

    # Call method run
    var_1 = lookup_module_0.run([str()], None)
    # Verify the result
    assert var_1 == None, "Verify test case result of calling LookupModule.run."


# Generated at 2022-06-25 10:58:39.823736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([["a_list", "of_strings"], [1, 2, 3]])
    assert len(result) == 6
    assert result[0] == ["a_list", 1]
    assert result[1] == ["a_list", 2]
    assert result[2] == ["a_list", 3]
    assert result[3] == ["of_strings", 1]
    assert result[4] == ["of_strings", 2]
    assert result[5] == ["of_strings", 3]


# Generated at 2022-06-25 10:58:41.910582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_3 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 10:58:48.480154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_1 = [
        [
            'a', [
                'a', 'b']]]
    x = LookupModule.run(
        "a", test_case_1, fail_on_undefined=True, loader=None, templar=None)


# Generated at 2022-06-25 10:58:55.332191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with a valid number of parameters
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)

    # Test where there is an error
    var_0 = []
    try:
        var_1 = lookup_run(var_0)
    except Exception as e:
        pass

# Generated at 2022-06-25 10:58:57.734945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = []
    results.append([['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']])
    return results


# Generated at 2022-06-25 10:59:01.093120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    test_case_0(lookup_module_0)
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:59:10.431883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._lookup_variables = MagicMock()
    lookup_module._lookup_variables.return_value = ["foo"]
    lookup_module._templar = MagicMock()
    lookup_module._templar.template = MagicMock()
    lookup_module._templar.template.return_value = ["foo"]
    lookup_module.run(["foo"], ["foo"])
    assert "foo" == lookup_module.run(["foo"], ["foo"])[0]

# Generated at 2022-06-25 10:59:15.892491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = [lookup_module_1, lookup_module_1]
    # Call method run of class LookupModule shipped in module __main__
    inputs = [var_0]
    res = lookup_run(*inputs)

    assert(res == [])

if __name__ == '__main__':
    # Unit test for method run of class LookupModule
    test_LookupModule_run()
    print("Test finished successfully")
    exit(0)

# Generated at 2022-06-25 10:59:17.856960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = LookupModule()
    assert var_1.run([]) == [], """This test should assert that run returns a list"""

# Unit tests for class LookupModule

# Generated at 2022-06-25 10:59:23.370064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [['ansible'], ['galaxy', 'github', 'docs']]
    var_0 = LookupModule()
    var_1 = var_0.run(terms_0)
    assert (var_1 == [['ansible', 'galaxy'], ['ansible', 'github'], ['ansible', 'docs']]), "Expected value: '[]' Actual value: '%s'" % var_1


# Generated at 2022-06-25 10:59:28.846959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)
    assert var_1 == var_0


# Generated at 2022-06-25 10:59:33.749858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(None, None, None, None)


# Generated at 2022-06-25 10:59:37.457651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:59:39.690582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = []
    vars.append(['a','b','c'])
    vars.append(['x','y','z'])
    mylookup = LookupModule()
    result = mylookup.run(terms=vars)
    print(result)

# Generated at 2022-06-25 10:59:50.499873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Case 1:
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)
    assert type(var_1) == list, "var_1 should be of type list"
    for x in var_1:
        assert type(x) == list, "x should be of type list"
        assert len(x) == 2, "len(x) should be 2"
        assert type(x[0]) == tuple, "x[0] should be of type tuple"
        assert x[1] == lookup_module_0, "x[1] should be the same object as lookup_module_0"

    # Case 2:
    var_2 = [lookup_module_0, lookup_module_0]

# Generated at 2022-06-25 10:59:53.906052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert type(test_case_0()) == list


# Generated at 2022-06-25 10:59:59.744501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)
    assert (var_1 == "tests/unit")
    var_2 = [lookup_module_0, lookup_module_0]
    var_3 = lookup_run(var_2)
    assert (var_3 == "tests/unit")


# Generated at 2022-06-25 11:00:05.410172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    lookup_module_0.run(var_0, None, **'kwargs')

# Standard YAML document.
# There is a single sequence of strings.

# Generated at 2022-06-25 11:00:11.164859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = [
    ["alice", "bob"],
    ["clientdb", "employeedb", "providerdb"]
  ]
  var_1 = LookupModule()
  var_2 = var_1.run(var_0)
  assert var_2 == [
    ["alice", "clientdb"],
    ["alice", "employeedb"],
    ["alice", "providerdb"],
    ["bob", "clientdb"],
    ["bob", "employeedb"],
    ["bob", "providerdb"]
  ]

  var_0 = [
    ["alice", "bob"],
    ["clientdb", "employeedb", "providerdb"],
    ["create", "select", "update"]
  ]
  var_2 = var_1.run(var_0)

# Generated at 2022-06-25 11:00:18.517376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = None
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run(var_0, var_1)
    assert len(var_2) == 1


# Generated at 2022-06-25 11:00:23.249599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  var = [lookup_module, lookup_module]
  lookup_module.run(var)


# Generated at 2022-06-25 11:00:29.542306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = None
    var_2 = {}
    var_3 = lookup_module_0.run(var_0, var_1, var_2)
    print("Type of var_3: %s" % (type(var_3)))
    print("Value of var_3: %s" % (var_3))
    var_3 = lookup_module_0.run()
    print("Type of var_3: %s" % (type(var_3)))
    print("Value of var_3: %s" % (var_3))

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:00:33.802373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  r = lookup.run([[1,2,3], [4], [5,6]], {}, {})
  assert r == [[1, 4, 5], [1, 4, 6], [2, 4, 5], [2, 4, 6], [3, 4, 5], [3, 4, 6]], "Incorrect result"

# Generated at 2022-06-25 11:00:40.322928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [[1, 2], [3, 4]]
    var_1 = [[5, 6], [7, 8]]
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run(var_1, var_0, **{"undefined": None})
    assert var_2 == [[7, 8], [5, 6], [3, 4], [1, 2]]

# Generated at 2022-06-25 11:00:47.746882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run_terms = [
        [],
        [['foo', 'bar']],
        [['1'], ['2', '3']],
        [['baz'], ['qux', 'quux']]
    ]

    run_variables = None

    with pytest.raises(AnsibleError):
        lookup_run(run_terms, run_variables)

    run_terms = [['foo', 'bar']]

    run_expected = [
        ['foo'],
        ['bar']
    ]

    run_result = lookup_run(run_terms, run_variables)

    assert run_result == run_expected


# Generated at 2022-06-25 11:00:52.668323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_10 = [['users', 'instance1']]
    var_11 = "One of the nested variables was undefined. The error was: 'users' is undefined"
    var_12 = LookupModule()
    var_13 = [var_12]
    var_14 = [var_10, var_13]
    var_15 = lookup_run(var_14)
    var_16 = var_15
    compare_vars(var_16, var_11)


# Generated at 2022-06-25 11:00:58.265811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = ["", "", "", "", "", "", "", "", "", ""]
    result = lookup_module.run(var_0)


# Base function for test cases against all methods of LookupModule Class

# Generated at 2022-06-25 11:01:00.997119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:01:11.646496
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:01:19.644056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_2 = [lookup_module_0, lookup_module_0]
    lookup_module_1 = LookupModule()
    var_3 = [lookup_module_1, lookup_module_1]
    var_4 = lookup_module_run(var_2,var_3)


# Generated at 2022-06-25 11:01:25.679859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)
    assert not var_1
    lookup_module_0 = LookupModule()
    var_2 = [lookup_module_0, lookup_module_0]
    var_3 = lookup_run(var_2)
    assert not var_3
    lookup_module_0 = LookupModule()
    var_4 = [lookup_module_0, lookup_module_0]
    var_5 = lookup_run(var_4)
    assert not var_5


# Generated at 2022-06-25 11:01:26.694935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Unit test for method run of class LookupModule")
    lookup_module = LookupModule()
    lookup_module.run([])


# Generated at 2022-06-25 11:01:32.123178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = [lookup_module_1, lookup_module_0]
    lookup_module_2 = LookupModule()
    var_1 = [lookup_module_0, lookup_module_2]
    var_2 = [var_0, var_1]
    var_3 = lookup_module_0.run(var_2)



# Generated at 2022-06-25 11:01:40.701378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [
        [
            ['resume_task_0'],
            ['resume_task_1']
        ],
        [
            ['resume_task_2'],
            ['resume_task_3']
        ]
    ]
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    var_2 = [
        ['resume_task_0', 'resume_task_2'],
        ['resume_task_1', 'resume_task_2'],
        ['resume_task_0', 'resume_task_3'],
        ['resume_task_1', 'resume_task_3']
    ]
    assert var_1 == var_2


# Generated at 2022-06-25 11:01:42.699123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)
    assert var_1 == None


# Generated at 2022-06-25 11:01:47.572904
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = ["param_0", "param_1"]
    var_0 = lookup_module_0.run(terms_0)

    var_1 = lookup_module_0.run(terms_0, variables="param_2")

    var_2 = lookup_module_0.run(terms_0, **"param_3")


# Generated at 2022-06-25 11:01:50.743229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)
    assert var_1 is None

# Generated at 2022-06-25 11:02:01.181098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = [None, None, None]
    var_2 = terms_0[:]
    var_2.reverse()
    result_0 = []
    if len(var_2) == 0:
        raise AnsibleError("with_nested requires at least one element in the nested list")
    result_0 = var_2.pop()
    while len(var_2) > 0:
        result_1 = lookup_module_1._combine(result_0, var_2.pop())
        result_0 = result_1
    var_3 = []
    for x_0 in result_0:
        var_3.append(lookup_module_1._flatten(x_0))

# Generated at 2022-06-25 11:02:06.494101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup Test
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    # Exercise
    var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:02:18.574811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_1 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    try:
        var_1 = lookup_module._lookup_variables(var_1)
    except:
        # must not throw exception
        assert 1==0, "lookup_module._lookup_variables threw an exception"
    var_2 = lookup_module.run(var_1)
    #var_2 must be [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    assert 1==0
    #assert var_2 == [['alice',

# Generated at 2022-06-25 11:02:25.224545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [["a", "b", "c"], ["A", "B"], ["1", "2", "3", "4"]]
    var_2 = LookupModule()
    var_3 = var_2.run(var_1)

# Generated at 2022-06-25 11:02:32.589366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First test case
    lookup_module_0 = LookupModule()
    var_0 = [[], []]
    var_1 = lookup_run(var_0)
    assert var_1 == [''], 'First test case'

    # Second test case
    lookup_module_1 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 == [], 'Second test case'

    # Third test case
    lookup_module_2 = LookupModule()
    var_0 = [['foo'], ['bar'], ['baz']]
    var_1 = lookup_run(var_0)
    assert var_1 == [], 'Third test case'


# Generated at 2022-06-25 11:02:36.573915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_lookup_module = LookupModule()
    var_lookup_module.run(terms=0)


# Generated at 2022-06-25 11:02:41.238979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    lookup_run(var_0)

# Generated at 2022-06-25 11:02:51.088786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [1, 2, 3, 4]
    var_2 = "dummy"
    var_3 = [var_1, var_1]
    var_4 = [var_3]
    var_5 = [var_4, var_4]
    var_6 = [var_5, var_5]
    var_7 = [var_6, var_6]
    var_8 = [var_7, var_7]
    var_9 = [var_8, var_8]
    var_10 = [var_9, var_9]
    var_11 = [var_10, var_10]
    var_12 = [var_11, var_11]
    var_13 = [var_12, var_12]

# Generated at 2022-06-25 11:02:58.652149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    var_2 = var_0.run(var_1, )
    print(var_2)
    assert var_2 == {
        "_list": [
            [1, 4],
            [1, 5],
            [1, 6],
            [2, 4],
            [2, 5],
            [2, 6],
            [3, 4],
            [3, 5],
            [3, 6]
        ]
    }


# Generated at 2022-06-25 11:03:05.937303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from test.units.plugins.lookup.test_nested import get_lookup_plugin_0
    from ansible.errors import AnsibleError
    lookup_module = get_lookup_plugin_0()
    lookup_module_0 = lookup_module
    var_0 = [lookup_module_0, lookup_module_0]
    # Raise exception if any of the arguments are not provided
    with pytest.raises(AnsibleError) as exc_info:
        lookup_module.run(var_0)
    assert exc_info.type == AnsibleError
    assert exc_info.value.args[0] == "with_nested requires at least one element in the nested list"

# Generated at 2022-06-25 11:03:09.263568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arg0 = [0, 1, 2]
    arg1 = {0: 0, 1: 1, 2: 2}
    arg2 = {}
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_run(var_0)



# Generated at 2022-06-25 11:03:14.629143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # <No inline test for run of class LookupModule>
    var_2 = lookup_module_1


if __name__ == "__main__":
   #Test code goes here.
   #lookup_module = LookupModule()
   #print("lookup_module = %s" % lookup_module)
   #print("lookup_module.run = %s" % lookup_module.run)
   #var = [lookup_module, lookup_module]
   #print("lookup_run(var) = %s" % lookup_run(var))
   test_case_0()

# Generated at 2022-06-25 11:03:24.482607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [[[u'alicesmith', u'bobsmith', u'joesmith'], [u'bobskeys', u'joeskeys'], ['password1', 'password2', 'password3']], [[u'alice.smith@example.com', u'bob.smith@example.com', u'joe.smith@example.com']]]
    var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:03:28.329853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_0.run('foo')


# Generated at 2022-06-25 11:03:36.825410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with empty list
    var_1 = []
    var_0 = lookup_module_0.run(var_1)
    assert var_0 == [[]]

    # Test with 2 lists
    var_1 = [[1, 2], [3, 4]]
    var_0 = lookup_module_0.run(var_1)
    assert var_0 == [[1, 3], [1, 4], [2, 3], [2, 4]]

    # Test with 3 lists
    var_1 = [[1, 2], [3, 4], [5, 6]]
    var_0 = lookup_module_0.run(var_1)