

# Generated at 2022-06-25 10:53:39.693780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    value_0 = []
    value_1 = []
    dict_0 = {}
    int_0 = -1440805599
    str_0 = '\x7f\x95\xe5\xbd\xfa\x7f\xe4\x9f\xe4\x95'
    int_1 = 1154277345
    list_0 = [str_0, int_1]
    list_1 = [int_0, list_0]
    dict_0 = {'terms': list_1, 'terms_0': value_1}
    lookup_module_0 = LookupModule(**dict_0)
    value_2 = lookup_module_0.run(value_0)
    value_3 = -1745385616
    value_1.append(value_3)
    value_

# Generated at 2022-06-25 10:53:43.443223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '6`5XUF*f'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(**dict_0)


# Generated at 2022-06-25 10:53:52.561351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # each of the returned items is a list
    # the params must be a list of one element
    # the element must be a list of lists
    lookup_module_0 = LookupModule()
    # 0 - no nested lists
    result = lookup_module_0.run([])
    assert result == []
    # 1
    result = lookup_module_0.run([[1, 2]])
    assert result == [[1, 2]]
    # 2
    result = lookup_module_0.run([[1], [2]])
    assert result == [[1, 2]]
    # 3
    result = lookup_module_0.run([[1, 2], [3]])
    assert result == [[1, 3], [2, 3]]
    # 3

# Generated at 2022-06-25 10:54:01.215547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    dict_0['_templar'] = True
    dict_0['_loader'] = True
    dict_0['_basedir'] = True
    dict_0['_environment'] = True
    dict_0['run_adds_general_failures'] = True
    terms_0 = list()
    variables_0 = None
    a0 = {'lookups': True}
    args_0 = a0
    kwargs_0 = dict()
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert getattr(result_0, '__class__').__name__ == 'list'

# Generated at 2022-06-25 10:54:10.772543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ']PjK(`E=nBk&b[7}'
    str_1 = 'y0gYjK*V`F/z=w7V'
    str_2 = 'L-l\nx9^FyS(Q|'
    str_3 = 'z%!Zu@L-P[^BvmJo'
    str_4 = '\n;|7Vuwg,Z{7nqUo'
    dict_0 = {str_4: str_2, str_1: str_0, str_3: str_2, str_0: str_3}
    list_0 = [str_3, str_1, str_4]
    dict_1 = {str_1: list_0, str_0: str_0}
   

# Generated at 2022-06-25 10:54:20.367911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['_loader'] = None
    dict_0['_templar'] = None
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = list()
    dict_1 = dict()
    dict_1.__setitem__('file', 'nested.py')
    dict_1.__setitem__('module', '_yaml')
    dict_1.__setitem__('searchpath', None)
    dict_1.__setitem__('_original_file', 'nested.py')
    dict_1.__setitem__('_original_module', '_yaml')
    dict_1.__setitem__('_loose_loader', None)
    dict_1.__setitem__('_strict_loader', None)


# Generated at 2022-06-25 10:54:31.141050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    str_0 = 'tN{=R)\'>Ie[r'
    dict_0[str_0] = str_0
    lookup_module_0 = LookupModule(**dict_0)
    terms = ["vpc2"]
    dict_1 = dict()
    str_1 = '6YeW8J{~?6U|:6f'
    dict_1[str_1] = str_1
    dict_2 = dict()
    dict_2[str_0] = lookup_module_0
    dict_2[str_1] = dict_1
    value_0 = lookup_module_0.run(terms=terms, variables=dict_2)
    assert value_0 == [['vpc2']]


# Generated at 2022-06-25 10:54:36.578572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # required arguments
  str_0 = 'U1Z|(a0$'
  str_1 = '=y23'
  #Test case 0
  dict_0 = {str_0: [str_1]}
  lookup_module_0 = LookupModule(**dict_0)
  lookup_module_0.run(**dict_0)


if __name__ == '__main__':
  test_LookupModule_run()
  test_case_0()

# Generated at 2022-06-25 10:54:38.680300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(('my_list', ))

# Generated at 2022-06-25 10:54:48.587260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ne*L-8o|:0oX9!>v1'
    dict_0 = None
    dict_1 = {str_0: dict_0}
    lookup_module_0 = LookupModule(**dict_1)
    list_0 = [list_0]
    str_1 = 'X3$m;mjK}Y'
    dict_2 = {str_1: str_0}
    dict_3 = {str_1: dict_2}
    dict_4 = {str_0: dict_3}
    lookup_module_1 = LookupModule(**dict_4)
    dict_5 = None
    dict_6 = {str_0: dict_5}
    lookup_module_2 = LookupModule(**dict_6)

# Generated at 2022-06-25 10:55:00.773597
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    # Unit test for run - [u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb']
    args = (u'alice', u'bob'), ([u'clientdb', u'employeedb', u'providerdb'])
    ret0 = lookup_module_0.run(*args)
    assert isinstance(ret0, list)

    # Unit test for run - [u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb'], [u'bob'], [u'clientdb', u'employeedb', u'providerdb']

# Generated at 2022-06-25 10:55:03.895360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data_to_test = [['a', 'b'], ['c', 'd']]
    lookup_module = LookupModule()
    result = lookup_module.run(data_to_test)
    assert result == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]

# Generated at 2022-06-25 10:55:13.712517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    t = [[['alice', 'bob']], [['clientdb', 'employeedb', 'providerdb']]]

    assert lookup_module_1.run(t) == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

    t = [[['alice', 'bob']], [['clientdb', 'employeedb', 'providerdb']], [['intranet', 'website']]]

# Generated at 2022-06-25 10:55:22.472947
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    test_run_1 = lookup_module_1.run([{'output': '/tmp/output-1.txt', 'myvar': 'my_var'}, {'input': '/tmp/input-1.txt', 'my_var': None}, {'input': '/tmp/input-2.txt'}])
    assert test_run_1 == [
        {'output': '/tmp/output-1.txt', 'myvar': 'my_var', 'input': '/tmp/input-1.txt'},
        {'output': '/tmp/output-1.txt', 'myvar': 'my_var', 'input': '/tmp/input-2.txt'}
    ]


# Generated at 2022-06-25 10:55:26.410778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    input_terms = [
        [
            [1, 2],
            [
                3,
                4
            ]
        ],
        [5, 6]
    ]
    lookup_module_0.run(terms=input_terms)


# Generated at 2022-06-25 10:55:33.906526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:55:36.526204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-25 10:55:38.480770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = []
    variables = {}
    assert lookup_module_1.run(terms, variables) == [[]]


# Generated at 2022-06-25 10:55:45.504643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = list([u'[1, 2, 3]', u'[4, 5, 6]'])
    result_0 = lookup_module_0.run(terms=terms_0)
    result_1 = lookup_module_0.run(terms=terms_0, variables=None)
    assert result_0 == [u'[1, 4]', u'[1, 5]', u'[1, 6]', u'[2, 4]', u'[2, 5]', u'[2, 6]', u'[3, 4]', u'[3, 5]', u'[3, 6]']

# Generated at 2022-06-25 10:55:46.866789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[], variables=None) == []


# Generated at 2022-06-25 10:55:56.947538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ]

    result = lookup.run(terms)


# Generated at 2022-06-25 10:56:07.755230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_module_0 = LookupModule()
    # Get a jinja2.runtime.Context object
    var_0 = jinja2.runtime.Context.get_default_locals()
    # Get a jinja2.environment.Environment object
    var_1 = jinja2.environment.Environment()
    # Create a function call jinja2.environment.Environment.getitem()
    var_2 = jinja2.environment.Environment.getitem(var_1, u'debug')
    # Register jinja2.environment.Environment.getitem() in var_0

# Generated at 2022-06-25 10:56:18.301056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    empty_list = []
    error_msg = "with_nested requires at least one element in the nested list"

    # Case: no list given, AnsibleError should be raised
    try:
        lookup_module.run(empty_list)
    except AnsibleError as err:
        assert error_msg == str(err)

    # Case: one list given, should return one list with one element
    var1 = ['test']
    result1 = lookup_module.run(var1)
    assert result1 == [['test']]

    # Case: two lists given, should return a valid list
    var2 = ['test', ['test1', 'test2']]
    result2 = lookup_module.run(var2)

# Generated at 2022-06-25 10:56:26.074887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_2 = [['a', 'b', 'c'], ['1', '2', '3'], ['alpha', 'beta', 'gamma']]
    var_3 = lookup_module_0.run(var_2, dict())

# Generated at 2022-06-25 10:56:37.168786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LOOKUP_MODULE = LookupModule()
    params_0 = []
    result = LOOKUP_MODULE.run(params_0)
    assert result == []
    params_1 = [[0, 1, 2], ['a', 'b', 'c']]
    result = LOOKUP_MODULE.run(params_1)
    assert result == [[0, 'a'], [1, 'a'], [2, 'a']]
    params_2 = [[0, 1, 2], ['a', 'b', 'c'], ['x', 'y', 'z']]
    result = LOOKUP_MODULE.run(params_2)
    assert result == [[0, 'a', 'x'], [1, 'a', 'x'], [2, 'a', 'x']]

# Generated at 2022-06-25 10:56:43.970786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # fixture
    var_0 = [
        [
            "first"
        ], [
            "one", "two"
        ]
    ]

    # test case
    lookup_module = LookupModule()
    var_1 = lookup_module.run(var_0)

    assert var_1 == \
        [
            [
                'first', 'one'
            ], [
                'first', 'two'
            ]
        ]

# Generated at 2022-06-25 10:56:53.046601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    var_2 = [["alice", "bob"], ["clientdb", "employeedb", "providerdb"]]
    var_3 = lookup_run(var_2, lookup_module_2)
    assert var_3 == [["alice", "clientdb"], ["bob", "clientdb"], ["alice", "employeedb"], ["bob", "employeedb"], ["alice", "providerdb"], ["bob", "providerdb"]]


# Generated at 2022-06-25 10:56:57.228706
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set an empty list of terms
    terms = []

    # Set variables for the test
    variables = {}

    # Create a LookupModule object
    lookup_module_0 = LookupModule()

    # Perform the lookup
    results = lookup_module_0.run(terms, variables)

    # Test the results
    assert results == []

# Generated at 2022-06-25 10:57:02.141763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    lookup_module_0 = LookupModule()
    var_0 = [["7"], [0, 1, 2, 3, 4, 5, 6]]
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == [["7", 0], ["7", 1], ["7", 2], ["7", 3], ["7", 4], ["7", 5], ["7", 6]]


# Generated at 2022-06-25 10:57:04.639632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
    assert (var_1 == [[]])


# Generated at 2022-06-25 10:57:08.776397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)


# Generated at 2022-06-25 10:57:13.908759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["a", "b"], ["x", "y"]]
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == [['a', 'x'], ['a', 'y'], ['b', 'x'], ['b', 'y']]



# Generated at 2022-06-25 10:57:22.408756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Mock AnsibleModule object
    #
    class AnsibleModule_mock():

        class params():

            class basic():
                ansible_facts = {}
                ansible_check_mode = False
                ansible_diff_mode = False

        basic = basic()

        _params = basic

    #
    # Mock Ansible lookup module
    #
    class LookupModule_mock():

        def __init__(self, module):
            self.module = module
            self.params = module._params

        def run(self, terms, variables=None, **kwargs):
            # Unit test code that tests the return of run()
            return terms

    # Mock the default class AnsibleModule
    AnsibleModule = AnsibleModule_mock

    # Instantiate the ansible module and run the unit test
    AnsibleModule

# Generated at 2022-06-25 10:57:25.996618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test case 0
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module)
    assert var_1[0] == "alice"
    assert var_1[1] == "bob"


# Generated at 2022-06-25 10:57:29.614510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = lookup_run([[['a','b','c'],['1','2','3']]], lookup_module)
    assert terms == [['a','1'],['a','2'],['a','3'],['b','1'],['b','2'],['b','3'],['c','1'],['c','2'],['c','3']]

# Generated at 2022-06-25 10:57:31.196033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModu

# Generated at 2022-06-25 10:57:32.418816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)



# Generated at 2022-06-25 10:57:41.279957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
    var_2 = [(['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'])]
    var_3 = lookup_run(var_2, lookup_module_0)
    var_4 = [(['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'])]
    var_5 = lookup_run(var_4, lookup_module_0)
    var_6 = [(['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'])]
    var_7 = lookup_run(var_6, lookup_module_0)
    var_8

# Generated at 2022-06-25 10:57:44.031754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = [['a'], ['b'], ['c']]
    var_3 = None
    var_4 = lookup_run(var_2, lookup_module_1, var_3)

# Generated at 2022-06-25 10:57:55.985111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == []
    var_0 = [['a', 'b'], ['1', '2']]
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == [['a1', 'a2'], ['b1', 'b2']]
    var_0 = [['a', 'b'], ['1', '2', '3']]
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == [['a1', 'a2', 'a3'], ['b1', 'b2', 'b3']]

# Generated at 2022-06-25 10:58:01.710265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    assert x.run(None, None, None) == []
    assert x.run([], None, None) == []
    assert x.run([1, 2, 3], None, None) == [[1, 2, 3]]


# Generated at 2022-06-25 10:58:07.386306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = list([list([u'alice', u'bob']), list([u'clientdb', u'employeedb', u'providerdb'])])
    var_1 = LookupModule()
    var_2 = var_1.run(var_0)


# Generated at 2022-06-25 10:58:13.555911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        [
            'a'
        ],
        [
            'b',
            'c'
        ],
        [
            'd',
            'e',
            'f'
        ]
    ]
    var_1 = lookup_run(var_0, lookup_module_0)

# Generated at 2022-06-25 10:58:22.135225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        'alice',
        'bob',
    ]
    var_1 = [
        'clientdb',
        'employeedb',
        'providerdb',
    ]
    var_2 = [
        var_0,
        var_1,
    ]
    var_3 = lookup_run(var_2, lookup_module_0)

# Generated at 2022-06-25 10:58:29.850378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[['ansible', 'nested'], ['list', 'lookup']], ['plugin']]
    lookup_plugin_0 = LookupModule()
    var_0 = lookup_plugin_0.run(terms)
    print(var_0)
    print("")
    print("expected:")
    print("[['ansible_nested_list_lookup_plugin'], ['ansible_nested_list_lookup_plugin'], ['ansible_nested_list_lookup_plugin'], ['ansible_nested_list_lookup_plugin']]")
    print("")
    print("")
    print("")

# Generated at 2022-06-25 10:58:41.634477
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Testing the run method of class LookupModule
    #variables = dict(hostvars=dict(localhost=dict(ansible_ssh_host="localhost", ansible_ssh_port=22, ansible_ssh_user="admin")))
    #kwargs = dict(loader=self._loader, templar=self._templar, variables=variables)
    #lookup_module_0 = LookupModule(**kwargs)
    #var__raw = dict(a=dict(one=["one", "two"]), b=dict(two=["three", "four"]))
    #var_0 = dict(a=dict(one=["one", "two"]), b=dict(two=["three", "four"]))
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:58:48.448207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_2 = []
    var_2.append("item")
    var_1 = lookup_run(var_2, lookup_module_0)
    assert isinstance(var_1, list)
    assert var_1 == [["item"]]


# Generated at 2022-06-25 10:58:56.232561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    failed = False
    failed_cases = []

    try:
        test_case_0()
        test_case_0_run()
    except:
        failed = True
        failed_cases.append(test_case_0)

    return failed, failed_cases
if __name__ == '__main__':
    failed, failed_cases = test_LookupModule_run()
    if failed:
        print("Test Failed")
        for x in failed_cases:
            print(x)
    else:
        print("Test Succeeded")

# Generated at 2022-06-25 10:58:59.812849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == []


# Generated at 2022-06-25 10:59:01.396603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)

# Generated at 2022-06-25 10:59:16.958033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TEST CASES
    from unittest import TestCase
    from ansible.errors import AnsibleError
    # test case with 0 elements in the nested list
    with TestCase.assertRaises(TestCase, AnsibleError):
        var = []
        lookup_module_0 = LookupModule()
        lookup_module_0.run(var)
    # test case with 1 element in the nested list
    var = [["a1", "b1", "c1"]]
    lookup_module_0 = LookupModule()
    res_1 = lookup_module_0.run(var)
    TestCase.assertEqual(TestCase, res_1, [["a1"], ["b1"], ["c1"]])
    # test case with 2 element in the nested list

# Generated at 2022-06-25 10:59:22.424212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)

# Generated at 2022-06-25 10:59:28.737862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == []
    var_2 = ['bob', 'alice', 'barney']
    var_3 = ['clientdb', 'employeedb', 'providerdb']
    var_4 = [var_2, var_3]
    var_5 = lookup_run(var_4, lookup_module_0)
    assert ['alice', 'clientdb'] in var_5
    assert ['bob', 'employeedb'] in var_5
    assert ['barney', 'providerdb'] in var_5
    var_6 = [var_3, var_2]

# Generated at 2022-06-25 10:59:34.618446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = [var_0]
    var_2 = lookup_module_0.run(var_1)
    assert var_2 == None


# Generated at 2022-06-25 10:59:38.141177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ["foo", "bar"]
    var_1 = ["baz", "bam"]
    var_2 = [['foo', 'baz'], ['foo', 'bam'], ['bar', 'baz'], ['bar', 'bam']]
    lookup_module_0 = LookupModule()
    var_3 = lookup_module_0.run(var_0, var_1)
    assert var_3 == var_2


# Generated at 2022-06-25 10:59:40.526428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No Error
    lookup_module_0 = LookupModule()
    var_0 = [['roddy', 'doug', 'bob'], ['app1', 'app2', 'app3']]
    var_1 = lookup_run(var_0, lookup_module_0)


# Generated at 2022-06-25 10:59:42.709079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_0.append(['a', 'b'])
    var_0.append(['c'])
    var_0.append(['d'])
    var_1 = lookup_run(var_0, lookup_module_0)



# Generated at 2022-06-25 10:59:53.126123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_plugin_args = {'_terms': [
        "['foo', 'bar']",
        "['baz', 'bam']"
    ]}
    lookup_result = lookup_module.run(lookup_plugin_args['_terms'], None, **lookup_plugin_args)
    assert isinstance(lookup_result, list)
    assert lookup_result == [
        ['foo', 'baz'],
        ['foo', 'bam'],
        ['bar', 'baz'],
        ['bar', 'bam']
    ]
    lookup_plugin_args = {'_terms': [
        "['foo', 'bar']",
        "['baz', 'bam']",
        "['yo', 'ya']"
    ]}
    lookup_

# Generated at 2022-06-25 10:59:59.964786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]


# Generated at 2022-06-25 11:00:06.390640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [""]
    # TODO: need to provide a templar/variables args to pass unit test
    var_1 = lookup_run(var_0, lookup_module_0, templar=None, variables=None)


# Generated at 2022-06-25 11:00:19.864392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [1, 2, 3, 4, 5]
    var_1 = lookup_run(var_0, lookup_module_0)
    print(var_1)
    assert var_1 == 0 or var_1 == 1


# Generated at 2022-06-25 11:00:27.176656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
      [
        'alice',
        'bob'
      ],
      [
        'clientdb',
        'employeedb',
        'providerdb'
      ]
    ]
    var_1 = lookup_run(var_0, lookup_module_0)

# Generated at 2022-06-25 11:00:32.618593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = [
            [
                [
                    "a",
                    "b",
                    "c"
                ]
            ],
            [
                [
                    "d",
                    "e",
                    "f"
                ]
            ]
        ]
    var_1 = lookup_run(var, lookup_module)

# Generated at 2022-06-25 11:00:34.867444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)


# Generated at 2022-06-25 11:00:38.921791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = []
  var_1 = [var_0]
  var_2 = lookup_run(var_1, lookup_module_0)


# Generated at 2022-06-25 11:00:41.755846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == []



# Generated at 2022-06-25 11:00:49.774316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.play

    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources='localhost,')
    variable_manager = ansible.vars.manager.VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "myPlay",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{var_0}}')))
        ]
    )

# Generated at 2022-06-25 11:00:54.728298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = [["F", "b"], ["a", "B"]]
    var_3 = lookup_run(var_2, lookup_module_1)


# Generated at 2022-06-25 11:00:56.805752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)


# Generated at 2022-06-25 11:00:57.666694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])


# Generated at 2022-06-25 11:01:10.266869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = None
    var_2 = lookup_run(var_0, lookup_module_0, var_1)
    print(var_2)
    # LookupModule.run() and throw exception if fail_on_undefined is True and a variable is not defined
    var_2 = lookup_run(var_0, lookup_module_0, var_1)
    print(var_2)


# Generated at 2022-06-25 11:01:13.798232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [[['a', 'b'], ['1', '2']], [1, 2]]
    var_1 = lookup_module_0.run(var_0, variables=None)
    return var_1


# Generated at 2022-06-25 11:01:16.402740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)

    assert var_1 == None

if __name__ == "__main__":
    import sys
    import json
    obj = json.loads(sys.argv[1])
    lookup_module_0 = LookupModule()
    var_0 = obj
    var_1 = lookup_run(var_0, lookup_module_0)
    print(json.dumps(var_1))

# Generated at 2022-06-25 11:01:21.796211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    var_0 = [['a', 'b']]
    var_1 = ['c', 'd']
    var_2 = lookup_mod.run(var_0, var_1)
    assert(var_2 == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']], "test_LookupModule_run_0")

# Generated at 2022-06-25 11:01:27.681319
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    def capture_stdout():
        import sys
        import contextlib
        old_out, sys.stdout = sys.stdout, StringIO()
        sys.stdout.buffer = sys.stdout
        yield sys.stdout
        sys.stdout = old_out

    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader()
    lookup_module._templar = Templar(loader=lookup_module._loader)
    lookup_module.set_options({'_raw': True})
    terms = ['foo', 'bar', 'baz']
    args = [terms, 'a']

# Generated at 2022-06-25 11:01:38.032795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [
        [
            [
                'x',
                'y',
                'z'
            ],
            [
                'foo',
                'bar',
                'baz'
            ],
            [
                '1',
                '2',
                '3'
            ]
        ]
    ]
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:01:45.454904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            {
                'foo': [
                    'bar',
                ],
            },
            {
                'bar': 'baz',
            },
        ],
        {
            'baz': [
                'bar',
                'foo',
            ],
        },
    ]
    variables_0 = {}
    var_0 = lookup_module_0.run(terms_0, variables_0)
    # var_0 should now contain the following data structure:
    # [
    #     [
    #         {
    #             'bar': 'baz',
    #         },
    #         'bar',
    #     ],
    #     [
    #         {
    #             'bar': 'baz',
    #         },

# Generated at 2022-06-25 11:01:46.154719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:01:52.501891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run_0 = [["foo", "bar"], ["baz", "bing", "moo"]]
    run_1 = LookupModule()
    run_2 = run_1.run(run_0, None)
    assert run_2 == [['foo', 'baz'], ['foo', 'bing'], ['foo', 'moo'], ['bar', 'baz'], ['bar', 'bing'], ['bar', 'moo']]

# Generated at 2022-06-25 11:01:56.583860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 == []


# Generated at 2022-06-25 11:02:12.945785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = [['ciao'], ['bob']]
    var_3 = lookup_run(var_2, lookup_module_1)
    var_3_0 = [["ciao", "bob"]]
    assert var_3 == var_3_0
    var_4 = [['ciao']]
    var_5 = lookup_run(var_4, lookup_module_1)
    var_5_0 = [["ciao"]]
    assert var_5 == var_5_0
    var_6 = [['1', '2'], ['3', '4']]
    var_7 = lookup_run(var_6, lookup_module_1)

# Generated at 2022-06-25 11:02:18.500928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = ['alice', 'bob']
    var_3 = ['clientdb', 'employeedb', 'providerdb']
    var_4 = []
    var_4.append(var_2)
    var_4.append(var_3)
    var_4.reverse()
    var_5 = lookup_module_1.run(var_4)
    assert len(var_5) == 6


# Generated at 2022-06-25 11:02:24.438481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(term_0, None)
    test_var_0 = [
        ['alice', 'clientdb'],
        ['alice', 'employeedb'],
        ['alice', 'providerdb'],
        ['bob', 'clientdb'],
        ['bob', 'employeedb'],
        ['bob', 'providerdb']
    ]
    assert var_0 == test_var_0

# Generated at 2022-06-25 11:02:32.219700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_0['test'] = ["test"]
    var_0['test2'] = ["test2"]
    var_0['test3'] = ["test3"]
    var_1 = []
    var_1.append("{{ test }}")
    var_1.append("{{ test2 }}")
    var_1.append("{{ test3 }}")
    var_2 = lookup_module_0._lookup_variables(var_1, var_0)
    var_3 = []
    var_3.append(["test"])
    var_3.append(["test2"])
    var_3.append(["test3"])
    assert var_2 == var_3

# Generated at 2022-06-25 11:02:36.026973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = [['alice'], ['bob'], ['clientdb', 'employeedb', 'providerdb']]
    result_0 = lookup_module_1.run(var_2)
    assert result_0 == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]


# Generated at 2022-06-25 11:02:44.287281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = []
    var_3 = lookup_run(var_2, lookup_module_1)
    var_4 = [["Hello","This","Is","A","Test"],["One","Two","Three"]]
    var_5 = lookup_run(var_4, lookup_module_1)
    var_6 = [["Hello","This","Is","A","Test"],["One","Two","Three","Four"]]
    var_7 = lookup_run(var_6, lookup_module_1)

# Generated at 2022-06-25 11:02:46.113614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        assert_equal(test_case_0())
    except:
        print("Assertion failed - test_case_0")
        raise


# Generated at 2022-06-25 11:02:50.347156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = [['book1'], ['book2'], ['book3']]
    var_1 = lookup_run(var_0, lookup_module_0)
    var_2 = [['book1', 'book2', 'book3']]

    assert var_1 == var_2


# Generated at 2022-06-25 11:02:52.230006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [["foo"], ["bar"]]
    var_1 = LookupModule()
    var_2 = var_1.run(var_0)
    assert var_2 == [["foo", "bar"]]


# Generated at 2022-06-25 11:02:57.476857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    var = ["['a','b']", "['c','d']"]
    assert lookup.run(var) == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]



# Generated at 2022-06-25 11:03:10.400803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [["ansible"]]
    var_0 = [terms_0]
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == [['a', 'n', 's', 'i', 'b', 'l', 'e']], "list produced was not ['a', 'n', 's', 'i', 'b', 'l', 'e'], instead got %s" % str(var_1)


# Generated at 2022-06-25 11:03:16.170391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = [
        [
            'a',
            'b'
        ],
        [
            '1',
            '2'
        ]
    ]
    var_1 = [
        [
            'a',
            'b'
        ],
        [
            '1',
            '2'
        ],
        [
            'x',
            'y'
        ]
    ]
    var_2 = lookup_run(var_0, lookup_module)
    #assert var_2 == [
    #    [
    #        'a',
    #        '1'
    #    ],
    #    [
    #        'a',
    #        '2'
    #    ],
    #    [
    #        'b',
    #

# Generated at 2022-06-25 11:03:21.967429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
    assert var_1 is not None 

test_LookupModule_run()


# Generated at 2022-06-25 11:03:23.497365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = []
    result = lookup_module.run(var)
    assert result == lookup_run(var, lookup_module)


# Generated at 2022-06-25 11:03:28.765377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0, lookup_module_0)
