

# Generated at 2022-06-25 10:53:39.694411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    my_dict_0 = dict()
    my_dict_0['foo'] = 'bar'
    my_dict_0['baz'] = 'qux'
    my_list_0 = [
        'foo',
        'bar',
        'baz',
        'qux',
        'corge',
        'grault',
    ]
    my_dict_1 = dict()
    my_dict_1['ascending'] = True
    my_dict_1['type'] = 'natural'
    answer = lookup_module_0.run(
        terms=my_list_0,
        variables=my_dict_0,
        **my_dict_1)

# Generated at 2022-06-25 10:53:42.855497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case 0
    assert(lookup_module_0.run() == None)


# Generated at 2022-06-25 10:53:51.926089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([]) == []
    assert lookup_module_

# Generated at 2022-06-25 10:54:01.615489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")

    # Run method run() of class LookupModule with a valid nested list.

# Generated at 2022-06-25 10:54:03.910146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(['foo'])
    l.run(['foo', 'foo'])

# Generated at 2022-06-25 10:54:10.885873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['foo', 'bar'], {}, {}, [], [])
    try:
        result = lookup_module.run(['foo'], {}, {}, [], [])
    except AnsibleError:
        pass
    else:
        raise Exception("LookupModule.run should raise AnsibleError")
    result = lookup_module.run(['foo', 'bar'], {}, {}, [], [])
    try:
        result = lookup_module.run([0, 'bar'], {}, {}, [], [])
    except AnsibleError:
        pass
    else:
        raise Exception("LookupModule.run should raise AnsibleError")


# Generated at 2022-06-25 10:54:20.520162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(None) == []
    lookup_module_1.run([[1, 2, 3]], {})
    lookup_module_1.run([[1, 2, 3], ['a']], {})
    lookup_module_1.run([[1, 2, 3], ['a'], ['b']], {})
    lookup_module_1.run([[1, 2, 3], ['a'], ['b', 'c']], {})
    lookup_module_1.run([[1, 2, 3, 4, 5], ['a'], ['b', 'c']], {})
    lookup_module_1.run([[1, 2, 3, 4, 5], ['a', 'b'], ['c', 'd']], {})
   

# Generated at 2022-06-25 10:54:27.680900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_run_args_1 = [{
        'name': 'client',
        'priv': 'client.*:ALL',
        'password': 'foo'
    }, {
        'name': 'client',
        'priv': 'client.*:ALL',
        'password': 'foo'
    }]
    test_run_kwargs_1 = {
    }
    test_run_result_1 = lookup_module_1.run(test_run_args_1, **test_run_kwargs_1)



# Generated at 2022-06-25 10:54:35.059624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    lookup_module_0._flatten = Mock()
    lookup_module_0._flatten.return_value = 23
    lookup_module_0._combine = Mock()
    lookup_module_0._combine.return_value = ['w5Y=', '3Zo=']
    lookup_module_0._templar = Mock()

# Generated at 2022-06-25 10:54:42.238989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing LookupModule_run...", end="")
    lookup_module_run_0 = LookupModule()
    terms_0 = [['[1, 2, 3]'], ['[\'a\', \'b\', \'c\']']]

# Generated at 2022-06-25 10:54:49.483162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run(None, None)
    assert x == []


# Generated at 2022-06-25 10:55:00.773172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit: Success test case
    # Input Parameters:
    # terms: [['a', 'b', 'c'], ['1', '2', '3']]
    # Expected Return Value: [('a', '1'), ('a', '2'), ('a', '3'), ('b', '1'), ('b', '2'), ('b', '3'), ('c', '1'), ('c', '2'), ('c', '3')]
    terms = [['a', 'b', 'c'], ['1', '2', '3']]
    assert LookupModule().run(terms) == [('a', '1'), ('a', '2'), ('a', '3'), ('b', '1'), ('b', '2'), ('b', '3'), ('c', '1'), ('c', '2'), ('c', '3')]

    #

# Generated at 2022-06-25 10:55:05.670831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [
        [
            'alice', 'bob'
        ],
        [
            'clientdb', 'employeedb', 'providerdb'
        ]
    ]
    lookup_module_obj = LookupModule()
    lookup_module_obj.run(my_list)


# Generated at 2022-06-25 10:55:09.630111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ["{{ foo }}", "{{ bar }}"]
    lookup_module_0.run(terms_1, variables=None)


# Generated at 2022-06-25 10:55:16.938454
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Two lists of different lengths
    lookup_module_0 = LookupModule()
    list_0 = [["a", "b"], "c"]
    dict_0 = {'key_0': 'value_0', 'key_1': 'value_1'}
    result = lookup_module_0.run(list_0, dict_0)
    assert result == ["a", "b", "c"], result


# Generated at 2022-06-25 10:55:23.814440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    params = [([['a','b','c'], ['1','2','3','4']]),([['a','b','c'], ['1','2','3','4']])]
    terms = params[0]
    variables = params[1]
    result = lookup_module_0.run(terms, variables)
    print("result1: " + str(result))


# Generated at 2022-06-25 10:55:27.676328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module_0.run([])
    with pytest.raises(AnsibleError):
        lookup_module_0.run([], hostvars={})
# FIXME: need to test with a templar


# Generated at 2022-06-25 10:55:31.669482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # testcase: lookup_module_0.run([[['a'], ['b', 'c']]], dict())
    assert lookup_module_0.run([[['a'], ['b', 'c']]], dict()) == [['a', 'b'], ['a', 'c']]

# Generated at 2022-06-25 10:55:33.781953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run.run([])


# Generated at 2022-06-25 10:55:39.951888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_cases_0 = list()
    test_case_0 = dict()
    test_case_0['terms'] = list()

    # Test case 0a
    test_case_0 = dict()
    test_case_0['terms'] = list()
    test_case_0['expected_results'] = list()
    test_cases_0.append(test_case_0)

    # Test case 0b
    test_case_0 = dict()
    test_case_0['terms'] = [list()]
    test_case_0['expected_results'] = list()
    test_cases_0.append(test_case_0)

    # Test case 0c
    test_case_0 = dict()
    test_case_0['terms'] = [list()] * 2

# Generated at 2022-06-25 10:55:45.580481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    result = lookup_module_0.run(terms)
    assert result == []



# Generated at 2022-06-25 10:55:46.342301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:55:55.763341
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 0
    lookup_module_0 = LookupModule()
    terms_0 = [['album_1', 'album_2'], ['track_1_1', 'track_1_2'], ['track_2_1', 'track_2_2']]
    variables_0 = None
    result_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 10:56:01.444648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run([])
        assert False
    except AnsibleError as e:
        assert e.args[0] == "with_nested requires at least one element in the nested list"


# Generated at 2022-06-25 10:56:05.700865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], {}) is None, 'LookupModule.run() returned None instead of fail'

# Generated at 2022-06-25 10:56:10.600832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    arguments = [
        [
            [
                'term0'
            ], [
                'term1'
            ]
        ]
    ]
    arguments[0] = lookup_module_1._lookup_variables(arguments[0], dict())
    returned_value_0 = lookup_module_1.run(*arguments)
    assert isinstance(returned_value_0, list)
    returned_value_1 = lookup_module_1.run([
        [
            'term0'
        ], [
            'term1'
        ]
    ])
    assert returned_value_1 == returned_value_0

# Generated at 2022-06-25 10:56:15.399092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([["foo"], ["bar"]], {"foo": "bar"}) == [["foo", "bar"]], "Should return [['foo', 'bar']]"


# Generated at 2022-06-25 10:56:20.140223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    argument_0 = [[[{'name': 'alice'}, {'name': 'bob'}], [{'name': 'clientdb'}, {'name': 'employeedb'}, {'name': 'providerdb'}]]]
    argument_1 = None
    kwargs_0 = {}
    ret_0_0 = lookup_module_0.run(argument_0, argument_1, **kwargs_0)
    assert ret_0_0 is None
# - end of test case test_LookupModule_run (1 of 1)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:56:23.790951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = DummyTemplar()
    lookup_module_1._loader = DummyLoader()
    lookup_module_1.run(['a','b','c','d','e','f','g','h','i','j'])


# Generated at 2022-06-25 10:56:29.165556
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test AnsibleUndefinedVariable exception
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(["{{ undefined_var }}"])
        assert False, "AnsibleUndefinedVariable exception should have been raised"
    except AnsibleUndefinedVariable:
        pass

    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([["a", "b"], ["c", "d"]], variables={})
    assert result == [[u'a', u'c'], [u'a', u'd'], [u'b', u'c'], [u'b', u'd']], result

# Generated at 2022-06-25 10:56:37.810898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = [set_0]
    var_0 = lookup_run(terms_0)
    var_1 = lookup_run(terms_0)


# Generated at 2022-06-25 10:56:41.520247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = LookupModule()
    terms_1 = LookupModule()
    terms_2 = lookup_run(terms_1)



# Generated at 2022-06-25 10:56:44.111680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:56:48.098073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	pass



# Generated at 2022-06-25 10:56:50.659340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)


# Generated at 2022-06-25 10:57:00.083813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Check the handling of an empty list
    #
    my_list = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(my_list)
    assert len(var_0) == 0
    #
    # Check the handling of a list with one element
    #
    my_list = [["a", "b", "c"]]
    var_0 = lookup_run(my_list)
    assert len(var_0) == 3
    assert var_0[0] == ["a"]
    assert var_0[1] == ["b"]
    assert var_0[2] == ["c"]
    #
    # Check the handling of a list with multiple elements
    #

# Generated at 2022-06-25 10:57:09.136693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate the LookupModule class
    lookup_module_0 = LookupModule()
    # Add "test", "var", and "foo" to the lookup_module_0 object’s var_0 set
    set_0 = lookup_module_0.var_0
    # Add "test", "var", and "foo" to the lookup_module_0 object’s var_0 set
    set_0.add("test")
    # Add "test", "var", and "foo" to the lookup_module_0 object’s var_0 set
    set_0.add("var")
    # Add "test", "var", and "foo" to the lookup_module_0 object’s var_0 set
    set_0.add("foo")
    # Run the run() method on the lookup_module_0 object


# Generated at 2022-06-25 10:57:19.089904
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case with empty term
    set_0 = ()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)

    # Test case with non-empty term
    set_1 = (['', '', '', '', ''])
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(set_1)

    # Test case with empty term
    set_2 = ()
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run(set_2)

    # Test case with non-empty term
    set_3 = (['', '', '', '', ''])
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 10:57:28.189688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()

    # Unit: 'with_nested_0'
    set_0.add(0)
    var_0 = lookup_run(set_0)

    # Unit: 'with_nested_1'
    set_0.add(1)
    var_0 = lookup_run(set_0)

    # Unit: 'with_nested_2'
    set_0.add(2)
    var_0 = lookup_run(set_0)

    # Unit: 'with_nested_3'
    set_0.add(3)
    var_0 = lookup_run(set_0)

    # Unit: 'with_nested_4'
    set_0.add(4)
    var_0 = lookup_run

# Generated at 2022-06-25 10:57:29.710239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list_0 = []
    lookup_module_0 = LookupModule(my_list_0)
    lookup_module_0.run([], {})


# Generated at 2022-06-25 10:57:36.954148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    str_0 = 'foo'
    str_1 = lookup_module_0.run(set_0)
    assert str_0 == str_1


# Generated at 2022-06-25 10:57:40.389647
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    set_0 = set()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(set_0)

    set_1 = set()
    lookup_module_1 = LookupModule()
    lookup_module_1.run(set_1)

# Generated at 2022-06-25 10:57:42.183336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    return var_0

# Generated at 2022-06-25 10:57:48.872654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = [set_0]
    variables_0 = {}
    # run test
    #if len(my_list) == 0:
     #   raise AnsibleError("with_nested requires at least one element in the nested list")
    try:
        lookup_module_0.run(terms_0, variables_0)
        assert False
    except:
        pass
    set_1 = set()
    lookup_module_1 = LookupModule()
    terms_1 = [set_0]
    variables_1 = {}
    # run test
    #result = my_list.pop()
    #while len(my_list) > 0:
    #    result2 = self._combine(result, my_list.pop())


# Generated at 2022-06-25 10:57:52.986813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    terms_0 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, set_0)


# Generated at 2022-06-25 10:57:54.880061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)

# Generated at 2022-06-25 10:58:00.024394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)



# Generated at 2022-06-25 10:58:05.846945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = list([ list(['foo', 'bar']) ])
    var_1 = lookup_module_0.run(var_0)
    assert len(var_1) == 2
    assert var_1[0][0] == 'foo'
    assert var_1[0][1] == 'bar'
    assert var_1[1][0] == 'bar'
    assert var_1[1][1] == 'foo'
    var_2 = list([ list(['foo', 'bar']), list(['bing', 'foo']) ])
    var_3 = lookup_module_0.run(var_2)
    assert len(var_3) == 4
    assert var_3[0][0] == 'foo'

# Generated at 2022-06-25 10:58:11.083805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["", "", "", ""]
    expected = ["", ""]
    lookup_module_0 = LookupModule()
    actual = lookup_module_0.run(terms)
    assert actual == expected


# Generated at 2022-06-25 10:58:16.778850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([''])
    assert isinstance(var_0, list)
    assert var_0 == []



# Generated at 2022-06-25 10:58:26.860731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(set_0)) == 0
    set_1 = set()
    set_1.add(1)
    set_1.add(2)
    set_1.add(3)
    set_2 = set()
    set_2.add(4)
    set_2.add(5)
    assert len(lookup_module_0.run([set_1, set_2])) == 6
    assert len(lookup_module_0.run([[1, 2, 3], [4, 5, 6]])) == 9

# Generated at 2022-06-25 10:58:30.594850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_1 = set()
    set_2 = set()
    # Run test
    lookup_module_0.run(set_1, set_2)



# Generated at 2022-06-25 10:58:34.440268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    provider_0 = set([])
    var_0 = LookupModule()
    terms = set()
    variables = set()
    var_0.run(terms, variables)


# Generated at 2022-06-25 10:58:35.804567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run()


# Generated at 2022-06-25 10:58:40.486420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'])
    assert result_1 == None
    assert result_1 is not None


# Generated at 2022-06-25 10:58:43.127832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    vars_0 = dict()
    dict_0 = dict()
    str_0 = lookup_module_0.map_exec(set_0, vars_0, dict_0)
    assert str_0 is not None


# Generated at 2022-06-25 10:58:47.777695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set_0
    var_1 = lookup_module_0.run(var_0)
    assert var_1 is None

test_case_0()

# Generated at 2022-06-25 10:58:53.794695
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0._lookup_variables(set_0, set_0)
    var_1 = lookup_module_0.run(set_0, set_0)


# Generated at 2022-06-25 10:58:58.844068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:59:01.127274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    terms = set_0
    lookup_module_0.run(terms)


# Generated at 2022-06-25 10:59:06.749717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)


test_case_0()

# Generated at 2022-06-25 10:59:07.834717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_0 = LookupModule()
    assert class_0.run() != None



# Generated at 2022-06-25 10:59:11.009378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms_0 = {'1': 1, '2': 2, '3': 3}
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(terms_0)


# Generated at 2022-06-25 10:59:19.788708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    var_1 = lookup_module_0._flatten(var_0)
    var_2 = lookup_module_0._combine(var_1, var_0)
    terms_0 = None
    variables_0 = None
    var_3 = lookup_module_0.run(terms_0, variables_0)
    var_4 = lookup_module_0._lookup_variables(var_3, var_0)
    var_5 = lookup_module_0.run(var_4, var_0)

# Unit tests for class LookupModule

# Generated at 2022-06-25 10:59:23.437123
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setting up values
    # Create an instance of LookupModule
    lookup_module_0 = LookupModule()

    # Setting up parameters
    terms_0 = [[]]
    variables_0 = {}

    # Calling method
    result_0 = lookup_module_0.run(terms_0, variables=variables_0)

    # Validating results
    assert result_0 == [[]]


# Generated at 2022-06-25 10:59:27.616145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:59:37.920375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test a simple combo of two lists
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)
    assert var_0 == set_0
    # Test many combo of many lists
    set_1 = set()
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(set_1)
    assert var_1 == set_1
    # Test if any combo of many lists is empty
    set_2 = set()
    lookup_module_2 = LookupModule()
    with pytest.raises(AnsibleError):
        var_2 = lookup_module_2.run(set_2)
    # Test if any combo of many lists is empty
    set_3 = set()


# Generated at 2022-06-25 10:59:44.762488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_0.run(None, None)

# Generated at 2022-06-25 10:59:46.290506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:59:48.440414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = set()
    var_2 = lookup_module_1.run(var_1)

# Generated at 2022-06-25 10:59:56.679402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        set_0 = lookup_run(set_1)
    except AnsibleError as e:
        if "with_nested requires at least one element in the nested list" in str(e):
            pass
        else:
            fail("AnsibleError not raised for invalid test term")


# Generated at 2022-06-25 10:59:59.518053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 11:00:04.861549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule
    lookup_module_0 = LookupModule()
    # Test method run of class LookupModule
    # Create input variables
    var_0 = None
    lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:00:07.868588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    assert var_0 == set_0



# Generated at 2022-06-25 11:00:13.947993
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # type_0 is a c_int of value -10
    type_0 = -10
    # type_1 is a c_int of value -100
    type_1 = -100
    # type_2 is a c_int of value -10
    type_2 = -10
    # type_3 is a c_int of value 0
    type_3 = 0
    # type_4 is a c_int of value 1
    type_4 = 1
    # type_5 is a c_int of value 2
    type_5 = 2

    # Instantiate the object
    lookup_module_object = LookupModule()

    # Call methods here
    my_list = [ type_0 ]
    variables = None
    kwargs = {}
    lookup_module_object.run(my_list, variables, **kwargs)

# Generated at 2022-06-25 11:00:18.440102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(set_0)


# Generated at 2022-06-25 11:00:20.651379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = set()
    lookup_module_0.run(terms_0, set_0)


# Generated at 2022-06-25 11:00:22.796034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    args_0 = list(set_0)
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(args_0)


# Generated at 2022-06-25 11:00:29.627184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    lookup_module_1.run(test_case_1)

test_case_1 = set()
for s in [
    [
        {
            "hello": "world",
            "msg": "Hello world!",
            "other_variable": "this is something else",
            "random": [
                "a",
                "b",
                "c"
            ]
        }
    ],
    [
        {
            "hello": "world",
            "msg": "Hello world!",
            "other_variable": "this is something else",
            "random": [
                "a",
                "b",
                "c"
            ]
        }
    ]
]:
    test_case_1.add(s)


# Generated at 2022-06-25 11:00:30.942891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run()
  return


# Generated at 2022-06-25 11:00:33.585211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-25 11:00:38.123782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 =  lookup_run(var_0)
    assert var_1 == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]


# Generated at 2022-06-25 11:00:40.979682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [""]

# Generated at 2022-06-25 11:00:45.025418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = {'a': 'a'}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:00:55.407116
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    f = open("test_LookupModule_run.txt", "w")

    test_list = ['test']
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(test_list, test=True)

    assert len(result_0) > 0
    assert isinstance(result_0, list)

    test_list = ['test', 'test']
    lookup_module_0 = LookupModule()
    result_1 = lookup_module_0.run(test_list, test=True)
    assert len(result_1) > 0
    assert isinstance(result_1, list)

    test_list = [['test', 'test'], ['test', 'test']]
    lookup_module_0 = LookupModule()
    result_2 = lookup_module_0.run

# Generated at 2022-06-25 11:00:57.456017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    assert var_0 == "None"



# Generated at 2022-06-25 11:01:04.415736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = list_()
    variables = dict()
    kwargs = dict()

    lookup_module_0 = LookupModule()

    # Call method run with a first argument of type list
    try:
        lookup_run(terms, variables, kwargs)
    except Exception as e:
        print(e)

    # Call method run with a first argument of type dict
    try:
        lookup_module_0.run(terms, variables, kwargs)
    except Exception as e:
        print(e)

    # Call method run with a second argument of type dict
    try:
        lookup_module_0.run(terms, variables, kwargs)
    except Exception as e:
        print(e)

    # Call method run with a third argument of type dict

# Generated at 2022-06-25 11:01:04.973150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: implement
    assert False

# Generated at 2022-06-25 11:01:05.802254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []



# Generated at 2022-06-25 11:01:08.551354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    set_0 = set()
    var_0 = lookup_module_0.run(set_0, module_vars=None)

# Generated at 2022-06-25 11:01:14.811098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError) as pytest_wrapped_e:
        lookup_module_0.run('E')
    assert pytest_wrapped_e.type == AnsibleError
    assert str(pytest_wrapped_e.value) == "'E' was not found in lookup: [u'e']"

# Generated at 2022-06-25 11:01:16.482564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_1 = set()
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(set_1)

# Generated at 2022-06-25 11:01:20.687074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    assertion_failed = False
    try:
        lookup_module_0.run(set_0)
    except AnsibleError:
        assertion_failed = True
    assert assertion_failed == False


# Generated at 2022-06-25 11:01:24.258165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    var_2 = set_0.add("1")
    var_3 = set_0.add("2")
    var_4 = set_0.add("3")
    var_1 = set_0.add("4")
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)

# Generated at 2022-06-25 11:01:26.738696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    var_0 = lookup_run(set_0)
    assert var_0.shape == tuple([0, 0])
    assert var_0.size == 0
    assert var_0.ndim == 2


# Generated at 2022-06-25 11:01:33.813002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [("/etc/ansible/hosts", "file"), ("/etc/ansible/roles", "directory")]
    var_1 = lookup_module_0.run(var_0)
    assert len(var_1) == (var_0[0] * var_0[1])
    var_2 = [("/etc/ansible/ansible.cfg", "file")]
    var_3 = lookup_module_0.run(var_2)
    assert var_3 == var_1
    var_4 = ["/etc/ansible/ansible.cfg"]
    var_5 = lookup_module_0.run(var_4)
    assert len(var_5) == (var_0[0] * var_0[1])


# Generated at 2022-06-25 11:01:38.238866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    var_0 = ['foo', 'bar']
    var_1 = [{'foo': 'bar'}]
    # Test
    for var_2 in range(0, 1000):
        lookup_module_0.run(var_0, var_1)
    # Verification
    assert len(lookup_module_0._display.display) == 0

# Generated at 2022-06-25 11:01:45.934686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    e0 = "AnsibleError('with_nested requires at least one element in the nested list',)"
    try:
        lookup_module_0.run([])
    except AnsibleError as e:
        print("Expected error:", repr(e0))
        print("Actual error:", repr(e))

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:01:54.100637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables=None
    kwargs = {}
    lookup_module_0 = LookupModule()
    set_0 = set()
    lookup_module_0.run(terms, variables, **kwargs)
    del lookup_module_0
    lookup_module_0 = LookupModule()
    set_0 = set()
    lookup_module_0.run(terms, variables, **kwargs)
    del lookup_module_0



# Generated at 2022-06-25 11:02:02.711439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    if var_0:
        var_1 = assertEqual(var_0, [])
        var_1 = assertTrue(var_0, [])
        var_1 = assertIsInstance(var_0, [])
    var_0 = lookup_run([[]])
    if var_0:
        var_1 = assertFalse(var_0, [[]])
        var_1 = assertNotIn(var_0, [[]])
        var_1 = assertIn(var_0, [[]])
    var_0 = lookup_run([[], []])
    if var_0:
        var_1 = assertEqual(var_0, [[], []])
       

# Generated at 2022-06-25 11:02:07.359475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if False:
        # This code constructs a value for var_0
        pass # TODO: construct a value for set_0
    else:
        set_0 = set()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 11:02:08.753963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [set()]
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(terms_0)


# Generated at 2022-06-25 11:02:15.430654
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    terms = []
    variables = {}
    lookup_module_0 = LookupModule()

    # Execute
    var_0 = lookup_module_0.run(terms, variables)

    # Check
    assert len(var_0) == 0

    # Setup
    terms = []
    variables = {}
    lookup_module_0 = LookupModule()

    # Execute
    var_0 = lookup_module_0.run(terms, variables)

    # Check
    assert len(var_0) == 0

    # Setup
    terms = []
    variables = {}
    lookup_module_0 = LookupModule()

    # Execute
    var_0 = lookup_module_0.run(terms, variables)

    # Check
    assert len(var_0) == 0

    # Setup

# Generated at 2022-06-25 11:02:23.046666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
#
# # Unit test for method combine of class LookupModule
# def test_LookupModule_combine():
#     lookup_module_0 = LookupModule()
#     lookup_module_0.combine(arg_0)
#
#
# # Unit test for method flatten of class LookupModule
# def test_LookupModule_flatten():
#     lookup_module_0 = LookupModule()
#     lookup_module_0.flatten(arg_0)
#
#
# # Unit test for method lookup_variables of class LookupModule
# def test_LookupModule_lookup_variables():
#     lookup_module_0 = LookupModule()
#     lookup_module_0.lookup_variables(

# Generated at 2022-06-25 11:02:25.084105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = True
    var_1 = True
    var_2 = True
    lookup_module_0 = LookupModule()
    lookup_module_0.run(var_0, var_1, var_2)

# Generated at 2022-06-25 11:02:27.456293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(set_0, set_0)

# Generated at 2022-06-25 11:02:32.108084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0, variables_0)
    assert not var_0

# Generated at 2022-06-25 11:02:37.296345
# Unit test for method run of class LookupModule
def test_LookupModule_run():  # noqa
    args_0 = {
        "a": 1,
        "b": 2,
    }
    args_1 = {
        "a": 1,
        "b": 2,
    }
    args_2 = {
        "a": 1,
        "b": 2,
    }
    args_3 = {
        "a": 1,
        "b": 2,
    }
    args_4 = {
        "a": 1,
        "b": 2,
    }
    args_5 = {
        "a": 1,
        "b": 2,
    }
    args_6 = {
        "a": 1,
        "b": 2,
    }
    args_7 = {
        "a": 1,
        "b": 2,
    }
    args_

# Generated at 2022-06-25 11:02:45.729549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:02:49.018452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    lookup_module_0._lookup_variables = mock.MagicMock(return_value=list())
    var_0 = lookup_module_0.run(list(), dict())
    assert var_0 == [list()]

# Generated at 2022-06-25 11:03:04.567519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule(
        set_undefined_variables=[],
        set_available_variables=[
            ['set_0', 'set', (
                1,
                2,
                3,
                4,
                5,
                6
            )],
            ['set_1', 'set', (
                1,
                2,
                3,
                4,
                5,
                6
            )],
        ],
    )

    # Call method
    result = lookup_run.run(
        terms=[['set_0'], ['set_1']],
    )

# Generated at 2022-06-25 11:03:06.823385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()

    if lookup_module_0.run(set_0):
        assert True
    else:
        assert False



# Generated at 2022-06-25 11:03:08.431188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(set_0)

# Generated at 2022-06-25 11:03:09.377276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:03:15.608780
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a simple case
    lookup_module1 = LookupModule()
    terms1 = [["a", "b", "c"], ["1", "2"]]
    result1 = [["a1", "a2"], ["b1", "b2"], ["c1", "c2"]]
    assert(lookup_module1.run(terms1) == result1)

    # Test with a multiple variable case
    lookup_module2 = LookupModule()
    terms2 = [["a", "b", "c"], ["1", "2"], ["x", "y"]]

# Generated at 2022-06-25 11:03:19.102411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)


# Generated at 2022-06-25 11:03:22.381158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(set_0)


# Generated at 2022-06-25 11:03:23.930175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    foo_0 = LookupModule()
    var_0 = bar_0()
    var_1 = foo_0.run(var_0)

# Generated at 2022-06-25 11:03:33.566403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # This is a test for error condition in the run method
  # with input args: [], {}, {}
  # returns: []
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(set_0)
  # This is a test for error condition in the run method
  # with input args: [], {}, {}
  # returns: []
    set_1 = set()
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(set_1)
  # This is a test for error condition in the run method
  # with input args: [], {}, {}
  # returns: []
    set_2 = set()
    lookup_module_2 = LookupModule()
    var_2 = lookup_