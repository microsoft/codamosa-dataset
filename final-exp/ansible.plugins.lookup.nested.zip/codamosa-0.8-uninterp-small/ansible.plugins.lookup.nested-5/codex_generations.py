

# Generated at 2022-06-25 10:53:36.464925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['foo', 'bar', 'baz'], ['x', 'y', 'z']]
    var_0 = None
    try:
        test = lookup_module_0.run(terms_0, var_0)
    except AnsibleError as ae:
        print(ae)
        assert(len(ae.message) > 1)


# Generated at 2022-06-25 10:53:46.232399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_2_terms_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    test_case_2_terms_1 = []

# Generated at 2022-06-25 10:53:49.823547
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    x = lookup_module_0.run([['a', 'b'], ['1', '2', '3']])
    assert x == [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3']]
    x = lookup_module_0.run([['a', 'b'], ['1', '2', '3'], ['x', 'y']])

# Generated at 2022-06-25 10:53:51.736990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert  isinstance (lookup_module_0.run([],{}),list)


# Generated at 2022-06-25 10:53:56.940659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_3 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]

    result = lookup_module_2.run(terms_3, variables=None)
    assert result == [('alice', 'clientdb'), ('alice', 'employeedb'), ('alice', 'providerdb'), ('bob', 'clientdb'), ('bob', 'employeedb'), ('bob', 'providerdb')]


# Generated at 2022-06-25 10:54:01.146284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms = None

    lookup_module_0.run(terms, variables=None, **kwargs)


# Generated at 2022-06-25 10:54:10.754154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n***Testing LookupModule.run()***\n")
    lookup_module = LookupModule()
    terms = [['a', 'b', 'c'], ['1', '2', '3'], ['@', '#', '$']]
    results = lookup_module.run(terms)
    print("Type: %s" % type(results))
    print("Length: %s\n" % len(results))
    i = 0
    for res in results:
        print("result[%s]: %s" % (i, res))
        i += 1
    print("\n")
    assert len(results) == 9

# Generated at 2022-06-25 10:54:12.983067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(['web', 'db'], {})
    assert isinstance(result_0, list)
    assert result_0 == [
        ['web', 'db'],
    ]

# Generated at 2022-06-25 10:54:20.930321
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_LookupModule = LookupModule()
    result = test_LookupModule.run("users", variables={u'users': [[u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb']]})
    assert result == [["alice", "clientdb"], ["alice", "employeedb"], ["alice", "providerdb"], ["bob", "clientdb"], ["bob", "employeedb"], ["bob", "providerdb"]], result

# More complex test

# Generated at 2022-06-25 10:54:31.377014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module_0.run([])
    with pytest.raises(AnsibleUndefinedVariable):
        lookup_module_0.run([["foo", "bar"], ["{{ undefined_var }}", "baz"]])
    result = lookup_module_0.run([["foo", "bar"], ["baz", "qux"], ["corge", "", "grault"]])
    assert isinstance(result, list)
    assert len(result) == 12
    assert result[0] == ["foo", "baz", "corge"]
    assert result[1] == ["foo", "baz", "grault"]
    assert result[2] == ["foo", "qux", "corge"]

# Generated at 2022-06-25 10:54:40.408145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    lookup_module_0._listify = False
    lookup_module_0.run(['foo', 'bar'], variables=None, **{})
    assert lookup_module_0._templar == None
    assert lookup_module_0._loader == None
    assert lookup_module_0._listify is False


# Generated at 2022-06-25 10:54:48.318729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    global test_case_0
    test_case_0[0] = lookup_module_0.run([['a', 'b', 'c']], {})
    test_case_0[1] = lookup_module_0.run([[['a', 'b']], ['c', 'd', 'e']], {})
    test_case_0[2] = lookup_module_0.run([[['a', 1], ['b', 2]], [['c', 3], ['d', 4], ['e', 5]], [['f', 6], ['g', 7]]], {})
    assert test_case_0[0] == [['a'], ['b'], ['c']]

# Generated at 2022-06-25 10:55:00.719510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_params = \
    [
        [],
        [
            [
                "foo",
                "bar",
                "baz"
            ],
            []
        ],
        [
            [
                "foo"
            ],
            [
                "bar"
            ],
            [
                "baz"
            ]
        ]
    ]

    expected_output = \
    [
        [],
        [
            [
                "foo",
                "bar"
            ],
            [
                "foo",
                "baz"
            ],
            [
                "bar",
                "baz"
            ]
        ],
        [
            [
                "foo",
                "bar",
                "baz"
            ]
        ]
    ]


# Generated at 2022-06-25 10:55:06.224383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    terms = {'terms': 'terms'}
    variables = 'variables'
    kwargs = {'kwargs': 'kwargs'}
    result = lookup_module_run.run(terms, variables, **kwargs)
    assert isinstance(result, list)
    assert result == []


# Generated at 2022-06-25 10:55:13.987502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test environment for each test method
    lookup_module_0 = LookupModule()

    terms_0 = ['l1', 'l2', 'l3']
    variables_0 = {}
    kwargs_0 = {}
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result == [['l1', 'l2', 'l3']]

    terms_1 = ['l1', ['l2', 'l3']]
    variables_1 = {}
    kwargs_1 = {}
    result = lookup_module_0.run(terms_1, variables_1, **kwargs_1)
    assert result == [['l1', 'l2'], ['l1', 'l3']]


# Generated at 2022-06-25 10:55:15.535064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    variables = None
    # Test exception cases
    # Test normal case
    result = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 10:55:22.765485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    my_list_0 = [('a'), ('b')]
    my_list_1 = [('c'), ('d')]
    my_list_2 = [my_list_0, my_list_1]
    my_list_3 = [('e'), ('f')]
    my_list_4 = [my_list_2, my_list_3]

# Generated at 2022-06-25 10:55:29.868605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = {'fail_on_undefined': True, u'terms': {u'_terms': [{u'_text': u'foo'}, {u'_text': u'bar'}]}, u'loader': {u'_ansible_builtin_loader': True}, u'templar': {}, u'variables': {}, u'_ansible_no_log': False}
    kwargs_0 = {'variables': {}, u'_ansible_no_log': False}
    obj_0 = LookupModule(**args_0)
    obj_0.run(**kwargs_0)


# Generated at 2022-06-25 10:55:33.162793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = [
    ]

    variables_0 = {
    }

    result_0 = lookup_module_0.run(my_list_0, variables=variables_0)
    assert result_0 == [
    ]


# Generated at 2022-06-25 10:55:39.029551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_run_0 = LookupModule()

    assert_equal(LookupModule_run_0.run('test'), [{'index': 0, 'item': 'test'}], 'A call to the method run of class LookupModule with args (\'test\') failed.')


# Generated at 2022-06-25 10:55:44.267822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x1 = [[1, 2, 3], [4, 5, 6]]
    result = lookup_module_0.run(x1)
    assert result == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]]

# Generated at 2022-06-25 10:55:47.889533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([["a", "b"], ["1", "2"]], loader=None, variables=None)
    assert result == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2']]


# Generated at 2022-06-25 10:55:57.349696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    my_list.reverse()
    result = []
    if len(my_list) == 0:
        raise AnsibleError("with_nested requires at least one element in the nested list")
    result = my_list.pop()
    while len(my_list) > 0:
        result2 = lookup_module_0._combine(result, my_list.pop())
        result = result2
    new_result = []
    for x in result:
        new_result.append(lookup_module_0._flatten(x))

# Generated at 2022-06-25 10:56:00.143459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 10:56:02.971439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]]
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run(terms)

#  Unit tests for method _combine of class LookupModule

# Generated at 2022-06-25 10:56:08.291747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    terms = [
        [
            "users"
        ],
        [
            "clientdb",
            "employeedb",
            "providerdb"
        ]
    ]
    variables = {}
    result = lookup_instance.run(terms, variables)
    assert result == [
        [
            "users",
            "clientdb"
        ],
        [
            "users",
            "employeedb"
        ],
        [
            "users",
            "providerdb"
        ]
    ], "Test 1 failed"

# Generated at 2022-06-25 10:56:15.638510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_0_0 = []
    args_0_1 = None
    try:
        result_0 = lookup_module_0.run(args_0_0, args_0_1)
    except Exception:
        result_0 = None
    if result_0 is None:
        result_0 = Exception
    if type(result_0) == AnsibleError:
        result_0 = None
    assert result_0 == None


# Generated at 2022-06-25 10:56:17.301783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(lookup_module_0.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]])

# Generated at 2022-06-25 10:56:21.703794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the instance of LookupModule
    lookup_module = LookupModule()

    # Initialize the list of variables

    variables = None

    # Initialize the terms
    terms = "['alice', 'bob']", "['clientdb', 'employeedb', 'providerdb']"

    # Run the run() method
    result = lookup_module.run(terms, variables)
    assert result == [
        ['alice', 'clientdb'],
        ['alice', 'employeedb'],
        ['alice', 'providerdb'],
        ['bob', 'clientdb'],
        ['bob', 'employeedb'],
        ['bob', 'providerdb']]


# Generated at 2022-06-25 10:56:31.636570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  the_list = [ [1,2,3],[4,5],[6,7,8] ]
  assert lookup_module.run(the_list, None) == [ [1,4,6],[1,4,7],[1,4,8],[2,4,6],[2,4,7],[2,4,8],[3,4,6],[3,4,7],[3,4,8],[1,5,6],[1,5,7],[1,5,8],[2,5,6],[2,5,7],[2,5,8],[3,5,6],[3,5,7],[3,5,8] ]
  the_list = [ [1,2,3], [4,5,6] ]

# Generated at 2022-06-25 10:56:34.865123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    kwargs_0 = {}
    ret = lookup_module_0.run(terms_0, **kwargs_0)
    assert ret == []


# Generated at 2022-06-25 10:56:38.491021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = dict()
    args['terms'] = [['var_0']]
    args['variables'] = dict()
    result_0 = lookup_module_0.run(**args)
    assert result_0 == [['var_0']]


# Generated at 2022-06-25 10:56:43.432382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    lookup_module = LookupModule()
    term = ["[ 'alice', 'bob' ]", "[ 'clientdb', 'employeedb', 'providerdb' ]"]
    lookup_module.run(term, variables=None)
  except Exception as e:
    assert False


# Generated at 2022-06-25 10:56:50.832468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = []
    variables_0 = []
    assert lookup_module_1.run(terms_0, variables_0) == []


# Generated at 2022-06-25 10:56:53.374545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters must be list
    assert_raises(AnsibleError, lookup_module_0, 'foo')


# Generated at 2022-06-25 10:57:01.728794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic tests with empty list
    terms = []
    variables = None
    kwargs = {}
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms, variables, **kwargs)
    except AnsibleError as e:
        assert(e.message == "with_nested requires at least one element in the nested list")
    else:
        assert(False)
    # Basic test with empty variables
    terms = [['a', 'b'], ['c', 'd']]
    variables = {}
    kwargs = {}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:57:06.142829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_0()
    test_LookupModule_run_1()
    test_LookupModule_run_2()
    test_LookupModule_run_3()
    test_LookupModule_run_4()
    test_LookupModule_run_5()
    test_LookupModule_run_6()
    test_LookupModule_run_7()


# Generated at 2022-06-25 10:57:10.418038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    foo_1 = []
    foo_2 = []
    assert lookup_module_0.run(foo_1, foo_2) == []

for n in dir():
    if n.startswith('test_'):
        print("Executing %s" % n)
        eval(n)()

# Generated at 2022-06-25 10:57:12.509644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_instance = LookupModule()
    test_LookupModule_run_result = test_LookupModule_run_instance.run([])
    assert type(test_LookupModule_run_result) == list


# Generated at 2022-06-25 10:57:20.863486
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check that the result of LookupModule.run([[1, 2, 3], [a, b, c]]) equals
    #   [[1, a], [1, b], [1, c], [2, a], [2, b], [2, c], [3, a], [3, b], [3, c]]
    assert(LookupModule().run([[1, 2, 3], ['a', 'b', 'c']]) == [[1, 'a'], [1, 'b'], [1, 'c'], [2, 'a'], [2, 'b'], [2, 'c'], [3, 'a'], [3, 'b'], [3, 'c']])



# Generated at 2022-06-25 10:57:27.527422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo', 'bar', 'baz']
    terms_1 = ['foo', 'bar', 'baz']
    result_0 = lookup_module_0.run(terms_0, variables={'foo': 'bar', 'password': 'lookup_password'}, **{'_input_lines': ['lookup_input_lines', 'hi'], 'lookup_input_lines': ['lookup_input_lines', 'hi'], 'lookup_password': 'lookup_password'})
    assert result_0 == []

# Generated at 2022-06-25 10:57:32.768626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # testing lookups
    # assert lookup_module_0.run([]) == []

# Generated at 2022-06-25 10:57:41.301313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([[]]) == [([],)]
    assert lookup_module_0.run([[], []]) == [([], '',), ('', [],)]
    assert lookup_module_0.run([[1], ['a', 'b']]) == [([1], 'a',), ([1], 'b',), ('a', [],), ('b', [],)]
    assert lookup_module_0.run([[1, 2], ['a', 'b']]) == [([1, 2], 'a',), ([1, 2], 'b',), ('a', '1',), ('a', '2',), ('b', '1',), ('b', '2',)]
    assert lookup_

# Generated at 2022-06-25 10:57:48.199518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    results_1 = lookup_module_1.run([['a','b','c']])
    assert results_1 == [['a'],['b'],['c']]
    results_2 = lookup_module_1.run([['a','b','c'],['1','2','3']])
    assert results_2 == [['a','1'],['a','2'],['a','3'],['b','1'],['b','2'],['b','3'],['c','1'],['c','2'],['c','3']]
    results_3 = lookup_module_1.run([['a','b','c'],['1','2','3'],['x','y','z']])

# Generated at 2022-06-25 10:57:50.720645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(['[bar]'], {'foo': 'bar'})
    assert result == [['bar']]


# Generated at 2022-06-25 10:57:55.795925
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # input
    terms = [[1, 2], [3, 4]]
    result = LookupModule.run(lookup_module_0, terms)
    assert result == [[1, 3], [1, 4], [2, 3], [2, 4]]

# Generated at 2022-06-25 10:58:05.002324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_terms_1 = [['a', 'b'], ['1', '2', '3'], ['a1', 'a2', 'b1', 'b2', 'b3']]
    test_variables_1 = dict()
    test_run_1 = lookup_module_1.run(test_terms_1, test_variables_1)

# Generated at 2022-06-25 10:58:12.438754
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input parameters that are marked as 'input' are input only and are not modifiable.
    # Input parameters that are marked as 'input-output' are modifiable and are used as
    # both input parameters and output parameters.

    test_file = 'test_file'
    test_input_0 = []
    test_input_1 = []
    test_input_2 = []
    test_input_3 = []
    test_input_4 = []
    test_input_5 = []
    test_input_6 = []
    test_input_7 = []
    test_input_8 = []
    test_input_9 = []
    test_input_10 = []
    test_input_11 = []
    test_input_12 = []
    test_input_13 = []
    test_input_14 = []
   

# Generated at 2022-06-25 10:58:21.972711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_dict = {
      u'terms': [
        [
          u'alice',
          u'bob'
        ],
        [
          u'clientdb',
          u'employeedb',
          u'providerdb'
        ]
      ],
      u'variables': {
        u'inventory_hostname': u'myhost',
        u'inventory_hostname_short': u'myhost'
      }
    }
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:58:32.612223
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:58:43.477569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up
    lookup_module = LookupModule()
    my_list = [
        [ "a", "b", "c", "d" ],
    ]
    args = [
        my_list,
    ]
    kwargs = {
    }
    expected_result = [
        [ "a" ],
        [ "b" ],
        [ "c" ],
        [ "d" ],
    ]

    # exercise
    result = lookup_module.run(*args, **kwargs)

    # verify
    assert expected_result == result
    # cleanup - none necessary


# Generated at 2022-06-25 10:58:51.797841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct=None)
    lookup_module_0._templar = DummyTemplar()
    lookup_module_0._loader = DummyLoader()
    lookup_module_0._connection = DummyConnection()
    lookup_module_0._play_context = DummyPlayContext()
    lookup_module_0._display = DummyDisplay()
    lookup_module_0._task = DummyTask()
    lookup_module_0._loader.list_collection_paths = lambda loader: []
    lookup_module_0._action = DummyAction()
    #Verify the method returns the correct value
    assert lookup_module_0.run([[['item_0_0']]], variables=None) == [['item_0_0']]

# Generated at 2022-06-25 10:59:01.399743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        [
            'alice',
            'bob',
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb',
        ],
    ]
    kwargs_0 = {
        'variables': {
            'my_var': 'hello world',
        },
    }

# Generated at 2022-06-25 10:59:12.630513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['users', 'dbs']
    def_value = None

# Generated at 2022-06-25 10:59:16.743001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run_result = lookup_module.run(["foo"], ["bar"])
    assert lookup_module_run_result == []

# Generated at 2022-06-25 10:59:21.303863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = MockTemplar()
    lookup_module_0._loader = MockLoader({})
    terms_0 = ['alice', 'bob', 'carol', 'david']
    variables_0 = None
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == [[['alice', 'carol'], ['bob', 'carol'], ['alice', 'david'], ['bob', 'david']], [['alice', 'carol'], ['bob', 'carol'], ['alice', 'david'], ['bob', 'david']]]


# Generated at 2022-06-25 10:59:23.063686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([["Alice", "Bob"], ["A", "B"]], {"var": "value"})



# Generated at 2022-06-25 10:59:27.008717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test LookupModule.run')


# Generated at 2022-06-25 10:59:34.521790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_result_0 = LookupModule().run(['[1,2,3]','[4,5,6]','[7,8,9]'])

# Generated at 2022-06-25 10:59:38.418974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = None
    try:
        lookup_module_1.run(terms_1, variables_1)
    except Exception as e:
        assert isinstance(e, AnsibleError)
    else:
        assert False


# Generated at 2022-06-25 10:59:50.522747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[[1, 2], [3, 4]], variables=None, **{}) == [[1, 3], [1, 4], [2, 3], [2, 4]]
    
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[[1, 2], [3]], variables=None, **{}) == [[1, 3], [2, 3]]
    
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:59:56.957508
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    result = lookup_module_0._combine([1, 2, 3], ['a', 'b', 'c'])
    assert result[0] == [1, 'a']
    assert result[1] == [2, 'b']
    assert result[2] == [3, 'c']




# Generated at 2022-06-25 11:00:00.026721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run(['a','b','c','d','e','f','g'])


# Generated at 2022-06-25 11:00:10.910074
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:00:18.168023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    def mock_templar(self):
        return Templar(loader=loader, variables=dict(var_0='var_0_value'))

    loader = DictDataLoader({
        'lookup_nested.yml': """---
"{{ [range(0,3)] }}"
""",
    })

    original_unfrackpath_noop = LookupModule._unfrackpath_noop


# Generated at 2022-06-25 11:00:27.263469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == []

    lookup_module = LookupModule()
    assert lookup_module.run(0, variables) == []

    lookup_module = LookupModule()
    assert lookup_module.run([0, 1, 2], variables) == [[0], [1], [2]]

    lookup_module = LookupModule()
    assert lookup_module.run([[0], [1], [2]], variables) == [[0], [1], [2]]

    lookup_module = LookupModule()
    assert lookup_module.run([[0, 1], [2, 3]], variables) == [[0, 2], [0, 3], [1, 2], [1, 3]]

    lookup_

# Generated at 2022-06-25 11:00:30.724884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
      lookup_module = LookupModule()
      lookup_module.run([['a','b'],['c','d']])


# Generated at 2022-06-25 11:00:41.293293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Case 0: No elements in nested list

    print(lookup_module_1.run([], {}))
    print("Passed test case 0")
    # Case 1: Elements of nested list are scalars
    print(lookup_module_1.run([['a', 'b'], [1, 2, 3]], {}))
    print("Passed test case 1")
    # Case 2: Elements of nested list are lists
    print(lookup_module_1.run([['a', 'b'], [['a', 'b'], [1, 2, 3]]], {}))
    print("Passed test case 2")
    # Case 3: Elements of nested list are lists and scalars

# Generated at 2022-06-25 11:00:47.089830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    #test 0
    terms_0 = ['a', 'b', 'c']
    assert_0 = ['ac', 'bc', 'ab', 'bb', 'cb', 'ba', 'bb', 'ca', 'ab', 'bb', 'cb']
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == assert_0, "assertion error test 0"



# Generated at 2022-06-25 11:00:54.740361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['a', 'b'], ['c', 'd']]
    assert lookup_module_0.run(terms_0) == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]
    terms_0 = [['a', 'b'], ['c']]
    assert lookup_module_0.run(terms_0) == [['a', 'c'], ['b', 'c']]
    terms_0 = [['a'], ['c', 'd']]
    assert lookup_module_0.run(terms_0) == [['a', 'c'], ['a', 'd']]


# Generated at 2022-06-25 11:01:04.293382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        {
            '0': 'alice',
            '1': 'bob',
            '2': 'jill',
            '3': 'mike',
            '4': 'pat',
            '5': 'sam',
            '6': 'sue'
        }, {
            '0': 'clientdb',
            '1': 'employeedb',
            '2': 'providerdb'
        }
    ]

# Generated at 2022-06-25 11:01:07.192873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_module.run([])

# Generated at 2022-06-25 11:01:17.516720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run([])
    str_1 = lookup_module_0.run([[['[test_LookupModule_run]', 'test_0']], ['test_1']])
    str_2 = lookup_module_0.run([[['test_LookupModule_run'], ['test_0']], ['test_1']])
    assert type(str_0) == list, 'The return value of method run of class LookupModule is incorrect, expected: <list>, actual: %s' % type(str_0)
    assert str_0 == [], 'The return value of method run of class LookupModule is incorrect, expected: [], actual: %s' % str_0

# Generated at 2022-06-25 11:01:21.162480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[u'clientdb', u'employeedb', u'providerdb'], [u'alice', u'bob']], {}) == [[u'alice', u'clientdb'], [u'alice', u'employeedb'], [u'alice', u'providerdb'], [u'bob', u'clientdb'], [u'bob', u'employeedb'], [u'bob', u'providerdb']]


# Generated at 2022-06-25 11:01:24.131586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    print(lookup_module_1.run([[['a','b','c','d','e','f'],[1,2,3,4,5]],[[1,2,3,4,5],[10,20,30]]]))


# Generated at 2022-06-25 11:01:32.477151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    variables = None
    kwargs = {}
    expected = [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    result = lookup_module_1.run(terms, variables, **kwargs)
    assert result == expected


# Generated at 2022-06-25 11:01:37.994542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            "test0",
            "test1"
        ],
        [
            "test2",
            "test3"
        ]
    ]
    variables = dict(
        test0="test0.0",
        test1="test0.1",
        test2="test1.0",
        test3="test3.0"
    )
    result = LookupModule().run(terms, variables)
    assert result == ["test0.0", "test0.1"], "Unexpected result from LookupModule().run()"


# Generated at 2022-06-25 11:01:45.450501
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import the mock package
    from tests.mock import patch
    from tests.mock import Mock

    # create an instance of the lookup module
    lookup_module = LookupModule()

    # mock the templar attributes (used in the __init__ method)
    lookup_module._templar = Mock()
    lookup_module._loader = Mock()

    terms = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]

    # values returned by the mock
    lookup_module._templar.template.return_value = 'alice'

    # call the run method
    result = lookup_module.run(terms)

    # assert the result

# Generated at 2022-06-25 11:01:48.134459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()

  # Call method run with positional argument 'terms'
  positional_parameters = [['foo']]
  try:
    lookup_module_0.run(positional_parameters)
  except TypeError as e:
    assert(type(e) == TypeError)


# Generated at 2022-06-25 11:01:56.130777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = (["test-00", "test-01", "test-02", "test-03", "test-04", "test-05", "test-06"],)
    result_0 = lookup_module_0.run(terms=term_0)
    assert result_0 == [['test-00'], ['test-01'], ['test-02'], ['test-03'], ['test-04'], ['test-05'], ['test-06']]


# Generated at 2022-06-25 11:02:01.339368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0.run([[]])
    lookup_module_1.run([[[], []]])

# Generated at 2022-06-25 11:02:07.131220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  input0 = ["foo","bar"]
  expected_output = [('foo', 'bar')]

  output = lookup_module.run(input0,["foo"]) 
  assert output == expected_output

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:02:12.482136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['alice'], ['bob'], ['employeedb']]
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == [['alice', 'employeedb'],
                      ['bob', 'employeedb']]


# Generated at 2022-06-25 11:02:18.251979
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    terms_1 = [['a', 'b'], ['x', 'y']]
    terms_1_copy = terms_1[:]
    result_1 = lookup_module_1.run(terms=terms_1_copy, variables=None, **{})
    assert result_1 == [['a', 'x'], ['a', 'y'], ['b', 'x'], ['b', 'y']]


# Generated at 2022-06-25 11:02:23.689015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = None
    lookup_module._templar = None
    terms = [['a', 'b'], ['0', '1', '2']]
    variables = {}
    retval = lookup_module.run(terms, variables)
    assert retval == [['a', '0'], ['a', '1'], ['a', '2'], ['b', '0'], ['b', '1'], ['b', '2']]

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:02:27.219209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['[u"apples", u"oranges", u"bananas"]', '[u"red", u"green", u"blue"]'], variables=None)

test_LookupModule_run()

# Generated at 2022-06-25 11:02:36.416563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = [["{{foo}}"], ["{{bar}}"]]
    list_2 = [["a","b"],["c","d"]]
    list_3 = [["a","b"],["{{bar}}"]]
    list_4 = [["a","b"],["{{foobar}}"]]
    lookup_module_0 = LookupModule()
    results = []
    try:
        results = lookup_module_0.run(list_1)
    except Exception as e:
        exception_int1 = isinstance(e, AnsibleUndefinedVariable)
        exception_int2 = isinstance(e, AnsibleError)
        results_int1 = len(results)==0
        results_int2 = e.message=="One of the nested variables was undefined. The error was: 'foobar' is undefined"

# Generated at 2022-06-25 11:02:42.325660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']])


# Generated at 2022-06-25 11:02:51.693749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_list = lookup_module_1.run([[['Alice', 'Bob'], ['Carol', 'Dave', 'Eric']], [['Manitoba', 'Ontario', 'Quebec']]], None)
    assert my_list == [['Alice', 'Manitoba'], ['Alice', 'Ontario'], ['Alice', 'Quebec'], ['Bob', 'Manitoba'], ['Bob', 'Ontario'], ['Bob', 'Quebec'], ['Carol', 'Manitoba'], ['Carol', 'Ontario'], ['Carol', 'Quebec'], ['Dave', 'Manitoba'], ['Dave', 'Ontario'], ['Dave', 'Quebec'], ['Eric', 'Manitoba'], ['Eric', 'Ontario'], ['Eric', 'Quebec']]

# Generated at 2022-06-25 11:02:58.573527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "pytest"
    variables = "pytest"
    result = lookup_module_0.run(terms, variables)
#------------------------------------------------------------------
# Expected values
#------------------------------------------------------------------
    expected_result = []
#------------------------------------------------------------------
# Verification of expected result
#------------------------------------------------------------------
    assert expected_result == result, "Expected: %s , but got: %s" % (expected_result, result)


# Generated at 2022-06-25 11:03:03.564105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:03:10.342803
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_instance = LookupModule()
    lookup_term = [
        [
            'element0_0', 'element0_1'
        ],
        [
            'element1_0', 'element1_1'
        ]
    ]
    lookup_result = {
        '_raw': [
            [
                'element0_0', 'element0_1'
            ],
            [
                'element1_0', 'element1_1'
            ]
        ]
    }
    result = lookup_instance.run(lookup_term, lookup_result)

# Generated at 2022-06-25 11:03:15.049038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Tests whether correct answer is being retrieved
    """
    lookup_module_0 = LookupModule()
    terms_0 = (
        [
            [
                'ansible'
            ]
        ],
        [['community', 'core']]
    )
    variables_0 = {}
    variables_0['variable'] = list(terms_0)

    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == [['ansible', 'community'], ['ansible', 'core']]



# Generated at 2022-06-25 11:03:24.617335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = {'_raw': [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]}
    kwargs_0 = {'fail_on_undefined': False, 'variables': {}}
    results_0 = [('alice', 'clientdb'), ('alice', 'employeedb'), ('alice', 'providerdb'), ('bob', 'clientdb'), ('bob', 'employeedb'), ('bob', 'providerdb')]
    assert lookup_module_0.run(terms_0, **kwargs_0) == results_0


# Generated at 2022-06-25 11:03:29.105325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([[1,2], [3,4]])
    assert result == [(1,3), (1,4), (2,3), (2,4)]
