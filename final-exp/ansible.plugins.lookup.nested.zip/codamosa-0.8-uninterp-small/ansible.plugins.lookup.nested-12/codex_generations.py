

# Generated at 2022-06-25 10:53:36.381952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    # Set the following instance variables for calling a protected method
    lookup_module_0._templar = Dummy()
    lookup_module_0._loader = Dummy()
    terms = [1, 2, 3]
    variables = {'var': 2}
    # Invoking the method directly
    try:
        result = lookup_module_0.run(terms, variables)
    except Exception as exception:
        # Raised as expected
        print(str(exception))
    else:
        # Didn't raise as expected
        raise Exception("Didn't raise as expected")
    terms = [1, 2, 3]
    variables = {}
    # Invoking the method directly

# Generated at 2022-06-25 10:53:43.960104
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

#    terms = ["[ 'user1','user2','user3' ]", "[ 'db1','db2','db3' ]"]
    terms = [ [ "user1","user2","user3" ], [ "db1","db2","db3" ] ]
#    variables = None
    dict_param_0 = dict()
    dict_param_0['test_key_0'] = 'test_value_0'
    dict_param_0['test_key_1'] = 'test_value_1'
    dict_param_0['test_key_2'] = 'test_value_2'
    dict_param_0['test_key_3'] = 'test_value_3'
    variables = dict_param_0

# Generated at 2022-06-25 10:53:54.909026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    arguments_dict_1 = {}
    arguments_dict_1['terms'] = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]

# Generated at 2022-06-25 10:53:57.950518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.environment = dict()
    terms_0 = "somethong"
    lookup_module_0.run(terms_0, variables=dict())

# Generated at 2022-06-25 10:54:08.562320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['a', 'b', 'c'], variables={}, **{'_raw': True}) == [['a'], ['b'], ['c']]
    assert lookup_module_0.run(terms=['a', 'b', 'c'], variables={}, **{'_raw': True, 'freeform': 'True'}) == [['a'], ['b'], ['c']]
    assert lookup_module_0.run(terms=['[a,b,c]', '[d,e,f]'], variables={}, **{'_raw': True}) == [['a', 'b', 'c'], ['d', 'e', 'f']]

# Generated at 2022-06-25 10:54:17.817644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Input params list
    input_params = [ [ 'foo-', 'bar-', 'baz-' ], [ 'a', 'b', 'c' ] ]

    expected_result = [
       ['foo-a', 'bar-a', 'baz-a'],
       ['foo-b', 'bar-b', 'baz-b'],
       ['foo-c', 'bar-c', 'baz-c'],
    ]
    # Actual output of the lookup module
    actual_result = lookup_module_0.run(input_params)

    # Assert the expected output vs actual output
    assert actual_result == expected_result


# Generated at 2022-06-25 10:54:26.895673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for function run
    lookup_module_0 = LookupModule()
    # case 0
    test_terms_0 = [
        [0, 1, 2, 3],
        [4, 5, 6, 7],
        [8, 9, 10, 11],
    ]

# Generated at 2022-06-25 10:54:34.940754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = [ ("{{ a }}" , "{{ b }}" , "{{ c }}" , "{{ d }}" , "{{ e }}" , "{{ f }}") ]
    y = dict()
    y["a"] = [ "1" , "2" , "3" ]
    y["b"] = [ "4" , "5" ]
    y["c"] = [ "6" ]
    y["d"] = [ "7" ]
    y["e"] = [ "8" ]
    y["f"] = [ "9" ]
    result = lookup_module_0.run(x, y)

# Generated at 2022-06-25 10:54:39.377899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_0()
    test_LookupModule_run_1()
    test_LookupModule_run_2()
    test_LookupModule_run_3()
    test_LookupModule_run_4()
    test_LookupModule_run_5()
    test_LookupModule_run_6()
    test_LookupModule_run_7()



# Generated at 2022-06-25 10:54:43.283726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['test_value_0', 'test_value_1'], 'test_variables_0') == ['test_value_0', 'test_value_1']


# Generated at 2022-06-25 10:54:52.844613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test using a bare list
    assert list(lookup_module_0.run([ [ 'user1', 'user2' ], [ 'a' ] ])) == [['user1', 'a'], ['user2', 'a']]
    # Test using a jinja template
    assert list(lookup_module_0.run(["{{ ['user1','user2'] }}","{{ ['a','b'] }}"], dict(ansible_lsb=dict(distrib_codename='foo')))) == [['user1', 'a'], ['user2', 'a'], ['user1', 'b'], ['user2', 'b']]


# Generated at 2022-06-25 10:54:58.764481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_0 = lookup_module_1.run(terms=['alice', 'bob'], variables='')
    assert result_0 == [['alice'], ['bob']]
    result_1 = lookup_module_1.run(terms=['alice', 'bob'], variables='')
    assert result_1 == [['alice'], ['bob']]

# Generated at 2022-06-25 10:55:01.980520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Gets the LookupModule object
    lookup_module = LookupModule()
    # Gets the arguments to the run method
    terms = [["key1", "key2"], [1, 2, 3]]
    variables = None
    result = lookup_module.run(terms, variables)
    assert result == [['key1', 1], ['key1', 2], ['key1', 3], ['key2', 1], ['key2', 2], ['key2', 3]]

# Generated at 2022-06-25 10:55:13.010361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    arg_1 = {}
    ret_2 = lookup_module_0.run(arg_0, arg_1)
    print(ret_2)
    print("")
    arg_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ],
        [
            'slot1',
            'slot2'
        ]
    ]
    arg_1 = {}
    ret_2 = lookup_module_0.run

# Generated at 2022-06-25 10:55:19.327810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run([[], []])
    result_2 = lookup_module_1.run([['1', '2'], [True, False]])
    result_3 = lookup_module_1.run([[1, 2, 3, 4], [True, False]])
    expected_1 = []
    expected_2 = [['1', True], ['1', False], ['2', True], ['2', False]]
    expected_3 = [[1, True], [1, False], [2, True], [2, False], [3, True], [3, False], [4, True], [4, False]]

# Generated at 2022-06-25 10:55:28.449629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

# Generated at 2022-06-25 10:55:36.120736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test case for method run of class LookupModule
    """

    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run([["foo", "bar", "baz"], ["one"], ["two", "three"]])
    result_expected_0 = [['foo', 'one', 'two'], ['foo', 'one', 'three'], ['bar', 'one', 'two'], ['bar', 'one', 'three'], ['baz', 'one', 'two'], ['baz', 'one', 'three']]
    assert result_0 == result_expected_0

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:55:43.858639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    f = 'tests/test0.yml'
    with open(f, 'r') as file:
        doc = yaml.load(file)
        terms = doc['terms']
        variables = doc['variables']
        kwargs = doc['kwargs']
        ret = lookup_module.run(terms, variables, **kwargs)
        assert doc['expected'] == ret, "Test failed"
    f = 'tests/test1.yml'
    with open(f, 'r') as file:
        doc = yaml.load(file)
        terms = doc['terms']
        variables = doc['variables']
        kwargs = doc['kwargs']
        ret = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:55:52.388771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]) == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

# Generated at 2022-06-25 10:56:00.750613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a1 = [["a", "b", "c"], [1, 2, 3]]
    #
    # Case 1: no variables in the input list
    # Expected Result: [('a', 1), ('b', 1), ('c', 1), ('a', 2), ('b', 2), ('c', 2), ('a', 3), ('b', 3), ('c', 3)]
    #
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(a1) == [('a', 1), ('b', 1), ('c', 1), ('a', 2), ('b', 2), ('c', 2), ('a', 3), ('b', 3), ('c', 3)]
    # Case 2: one variables in the input list
    # Expected Result: same as case 1

# Generated at 2022-06-25 10:56:08.336439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    t = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module._templar.template = lambda x: x
    result = lookup_module.run(t)
    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]


# Generated at 2022-06-25 10:56:17.281679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module_1._templar = 'templar'
    lookup_module_1._loader = 'loader'
    result = lookup_module_1.run(terms=terms_1)
    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]


# Generated at 2022-06-25 10:56:25.179615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters for function run
    lookup_module_1 = LookupModule()
    terms = [['a'], ['b', 'c']]

    # Testing if an exception is raised and if exception message is as expected
    try:
        lookup_module_1.run(terms)
    except AnsibleError as e:
        assert e.message == "with_nested requires at least one element in the nested list"

    terms = [['a'], ['b', 'c'], ['d', 'e', 'f']]

    # Testing if an exception is raised and if exception message is as expected
    try:
        lookup_module_1.run(terms)
    except AnsibleError as e:
        assert e.message == "One of the nested variables was undefined. The error was: 'a' is undefined"


# Generated at 2022-06-25 10:56:29.942890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["[u'webservers']", "[u'databases']"]
    lookup_module_1.run(terms_1)

# Generated at 2022-06-25 10:56:38.063569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _lookup_variables(self, terms, variables):
        results = []
        for x in terms:
            try:
                intermediate = listify_lookup_plugin_terms(x, templar=self._templar, loader=self._loader, fail_on_undefined=True)
            except UndefinedError as e:
                raise AnsibleUndefinedVariable("One of the nested variables was undefined. The error was: %s" % e)
            results.append(intermediate)
        return results
    lookup_module_0 = LookupModule()
    lookup_module_0._lookup_variables = _lookup_variables
    class _self_0:
        def _combine(self, result, my_list_pop):
            return result
        def _flatten(self, x):
            return x
   

# Generated at 2022-06-25 10:56:46.325027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = [
        [
            'foo',
            'bar'
        ],
        [
            'baz',
            'quux'
        ]
    ]

    # this is the expected result from the run method
    expected_result = [
        [
            'foo',
            'baz'
        ],
        [
            'foo',
            'quux'
        ],
        [
            'bar',
            'baz'
        ],
        [
            'bar',
            'quux'
        ]
    ]

    # test the run method of LookupModule
    result = lookup_module.run(terms=terms)

    assert(result == expected_result)



# Generated at 2022-06-25 10:56:49.018840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_r = LookupModule()
    result = lookup_module_r.run(terms = [], variables = None, **kwargs)
    assert result == None


# Generated at 2022-06-25 10:56:52.058956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = []
    result_0 = lookup_module_1.run(terms=list_1)
    assert result_0 == []
    assert result_0 == []


# Generated at 2022-06-25 10:56:55.292155
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_1 = []

    result = lookup_module_0.run(terms=terms_1)
    assert result == []



# Generated at 2022-06-25 10:56:58.742040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = "templar"
    lookup_module._loader = "loader"
    my_list = []
    result = lookup_module.run(my_list)
    assert result is None


# Generated at 2022-06-25 10:57:08.134158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()

  param0 = [['alice'], ['bob'], ['clientdb', 'employeedb', 'providerdb']]
  param1 = None
  result = lookup_module.run(param0, param1)
  assert result == [
    ['alice', 'clientdb'], ['alice', 'emplyeedb'], ['alice', 'providerdb'],
    ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb'],
  ]

# Generated at 2022-06-25 10:57:09.262477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert list == type(LookupModule.run())

# Generated at 2022-06-25 10:57:19.212297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['A', 'B'], {}) == [['A', 'B']]
    assert lookup_module_0.run(['A', 'B'], {}) == lookup_module_0.run([['A'], ['B']], {})
    assert lookup_module_0.run(['A', ['B']], {}) == [['A', 'B']]
    assert lookup_module_0.run(['A', ['B']], {}) == lookup_module_0.run([['A'], ['B']], {})
    assert lookup_module_0.run([['A'], 'B'], {}) == [['A', 'B']]

# Generated at 2022-06-25 10:57:23.675854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run([["a"], ["b"]]) == [["a", "b"]]


# Generated at 2022-06-25 10:57:29.308452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_args = []
    test_args.append([['A', 'B', 'C'], ['1', '2']])
    ret_val = lookup_module._combine(test_args[0][0], test_args[0][1])
    assert ret_val == [['A', '1'], ['A', '2'], ['B', '1'], ['B', '2'], ['C', '1'], ['C', '2']]

    test_args = []
    test_args.append([['A', 'B', 'C'], ['1', '2'], ['x', 'y']])
    ret_val = lookup_module._combine(test_args[0][0], test_args[0][1])

# Generated at 2022-06-25 10:57:36.727730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case = {
        "input": {
            "terms": [
            ],
            "variables": {
            },
        },
        "output" : { "return": None }
    }
    answer = test_LookupModule_run_method( test_case )
    assert check_results( test_case, answer, "with_nested_errors.csv")


# Generated at 2022-06-25 10:57:38.625096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [1, 2, 3]
    lookup_module_0 = LookupModule()

    result = lookup_module_0.run(my_list)
    assert result == [ [1], [2], [3] ]


# Generated at 2022-06-25 10:57:46.885357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    loop_0 = [ '(µ)', 'v', 'z', '?', 'K', 'Z']
    lookup_module_0.run(loop_0, shell='My', paths=[ 'U'], variables={ 'Z': 'C'})
    lookup_module_0.run(loop_0, paths=[ 'Y', 'o'])
    lookup_module_0.run(loop_0, paths=[ 'b'], variables={ 'c': 'h', 'M': 'H'})
    lookup_module_0.run(loop_0, paths=[ 'U'], variables={ 'Y': 'E', 'f': 'u'})
    lookup_module_0.run(loop_0, paths=[ 'R', 'C', 'E', 'e', 'h'])
    lookup

# Generated at 2022-06-25 10:57:57.166941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [['a', 'b', 'c'], ['d', 'e', 'f']]
    my_list_1 = ['g', 'h', 'i']
    my_list_2 = ['j', 'k', 'l']
    my_list_3 = ['m', 'n', 'o']
    my_list_4 = ['p', 'q', 'r']
    my_list_5 = [my_list_2, my_list_3, my_list_4]
    my_list_6 = [my_list_1, my_list_5]
    my_list_7 = [my_list, my_list_6]
    result = lookup_module_0.run(my_list_7)

# Generated at 2022-06-25 10:58:03.908418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    variables_0 = {
        'foo': 'bar',
        'answer': 42
    }

# Generated at 2022-06-25 10:58:11.249712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['[[1,2,3],[4,5],[6,7],[8]]']
    variables = None
    assert lookup_module.run(terms, variables) == [[1,4,6,8],[2,4,6,8],[3,4,6,8],[1,5,6,8],[2,5,6,8],[3,5,6,8]]


# Generated at 2022-06-25 10:58:16.826441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(terms=[], variables={}, **{} )
    assert result_1 == []


# Generated at 2022-06-25 10:58:20.199397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [["foo"], ["bar"]]
    variables = {}
    expected = [["foo", "bar"]]
    actual = lookup_module_0.run(terms,variables)
    assert actual==expected




# Generated at 2022-06-25 10:58:26.468041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input = [[1, 2, 3], ['a', 'b', 'c']]
    expected_output = [[1, 'a'], [1, 'b'], [1, 'c'], [2, 'a'], [2, 'b'], [2, 'c'], [3, 'a'], [3, 'b'], [3, 'c']]
    lookup_module = LookupModule()
    actual_output = lookup_module.run(input)

    assert actual_output == expected_output
    assert isinstance(actual_output, list)


# Generated at 2022-06-25 10:58:31.623479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([[1,2],[3,4],[5,6]])
    assert result == [[1,3,5],[1,3,6],[1,4,5],[1,4,6],[2,3,5],[2,3,6],[2,4,5],[2,4,6]]

# Generated at 2022-06-25 10:58:41.759967
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # instantiate LookupModule
    lookup_module_0 = LookupModule()

    # set needed params
    terms = [
        [
            "2.3.3.3",
            "2.3.3.4",
            "1.1.1.1"
        ],
        [
            "2.2.2.2",
            "1.1.1.2"
        ]
    ]
    variables = {}

    # run method
    result = lookup_module_0.run(terms=terms, variables=variables)

    # validate results

# Generated at 2022-06-25 10:58:48.202049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    execute_method_0 = Helpers._gen_args([[['foo'], ['bar'], ['baz']]], [])
    assert execute_method_0 == [[['foo', 'bar', 'baz']]]

# Generated at 2022-06-25 10:58:50.506761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  # LookupModule.run(terms, variables, **kwargs) requires 2 arguments (1 given)
  args = []
  kwargs = {}
  with pytest.raises(Exception):
      lookup_module.run(*args, **kwargs)

# Generated at 2022-06-25 10:58:52.236906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run( [["a"], ["b","c"]], {} )
    assert result == [["a","b"], ["a","c"]]


# Generated at 2022-06-25 10:58:58.892427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        ['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog'],
        ['green', 'yellow', 'blue', 'red', 'black', 'white']
    ]
    variables_0 = {'cidr': '192.168.3.0/24', 'var': 'value', 'name': 'example.org', 'site': 'example.org'}
    kwargs_0 = {}
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 10:59:04.544591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [["a", "b"], ["c", "d"]]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms)
    assert isinstance(result, list)


# Generated at 2022-06-25 10:59:10.027877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_options = {'_terms': [
            [
                'alice', 'bob'
            ],
            [
                'clientdb', 'employeedb', 'providerdb'
            ]
        ]
    }
    result = lookup_module.run(terms=[
            [
                'alice', 'bob'
            ],
            [
                'clientdb', 'employeedb', 'providerdb'
            ]
        ], variables=None, **lookup_options)
    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]


# Generated at 2022-06-25 10:59:14.330953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    assert type(lookup_module_run_0.run([[u'alice'], [u'bob'], [u'clientdb', u'employeedb', u'providerdb'], [u'foo']], variables=None)) == type([])

# Generated at 2022-06-25 10:59:19.731036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms_1 = [
        [ 'a', 'b', 'c' ],
        [ 1, 2, 3 ],
    ]
    result_1 = lookup_module_1.run(terms_1)
    assert result_1 == [
            [ 'a', 1 ],
            [ 'a', 2 ],
            [ 'a', 3 ],
            [ 'b', 1 ],
            [ 'b', 2 ],
            [ 'b', 3 ],
            [ 'c', 1 ],
            [ 'c', 2 ],
            [ 'c', 3 ],
        ]


# Generated at 2022-06-25 10:59:26.076818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_result = lookup_module_1.run([[['a', 'b'], ['c', 'd']], ['e', 'f']])
    assert my_result == [['a', 'c', 'e'], ['a', 'c', 'f'], ['a', 'd', 'e'], ['a', 'd', 'f'], ['b', 'c', 'e'], ['b', 'c', 'f'], ['b', 'd', 'e'], ['b', 'd', 'f']], "Should be equal"

# Generated at 2022-06-25 10:59:28.328981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = [["ptichka", "mamont"], ["passwd", "pwd"]]
    lookup_module = lookup_module_0.run(x)
    assert lookup_module == [["ptichka", "passwd"], ["ptichka", "pwd"], ["mamont", "passwd"], ["mamont", "pwd"]]

# Generated at 2022-06-25 10:59:32.704454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (("incorrect parameters passed") == LookupModule.run("arg1", "arg2"))

# Generated at 2022-06-25 10:59:38.638773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Arrange
    terms = [
        [
            "stuff"
        ],
        [
            "one",
            "two"
        ]
    ]
    variables = None
    kwargs = {}

    # Act
    result = lookup_module.run(terms, variables, **kwargs)

    # Assert
    assert "stuff" in result[0]
    assert "stuff" in result[1]
    assert "one" in result[2]
    assert "one" in result[3]
    assert "two" in result[4]
    assert "two" in result[5]
    assert len(result) == 6


if __name__ == '__main__':

    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:59:46.553194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test I(run) method of class LookupModule """

    lookup_module = LookupModule()
    assert lookup_module.run([[['foo'], ['bar']], [['baz'], ['meh']]]) == [['foo', 'baz'], ['foo', 'meh'], ['bar', 'baz'], ['bar', 'meh']]

# Generated at 2022-06-25 10:59:51.314561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = [u'hello']
    my_list_1 = [u'hello']
    my_list_2 = [u'hello']
    my_list_3 = [u'hello']
    my_list_4 = [u'hello']
    my_list_5 = [u'hello']
    my_list_6 = [u'hello']
    my_list_7 = [u'hello']
    my_list_8 = [u'hello']
    my_list_9 = [u'hello']
    my_list_10 = [u'hello']
    my_list_11 = [u'hello']
    my_list_12 = [u'hello']
    my_list_13 = [u'hello']
    my_list_

# Generated at 2022-06-25 11:00:02.198853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing the 'run' method of class LookupModule.")

    from ansible.template import Templar

    my_vars = {}
    my_templar = Templar(loader=None, variables=my_vars)

    my_obj = LookupModule()

    my_args = ["foo", "bar", "baz"]
    my_kwargs = {}

    res = my_obj.run(terms=my_args, variables=my_vars, templar=my_templar, **my_kwargs)
    print("res is %s" % res)
    assert res[0][0] == "foo" and res[0][1] == "bar" and res[0][2] == "baz"

    print("Done testing the 'run' method of class LookupModule.")


# Generated at 2022-06-25 11:00:07.196385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['', '']
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == ['', '']

# Generated at 2022-06-25 11:00:10.262579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(["[u'artifactory_host', u'artifactory_port']", "[u'artifactory', u'artifactory-db']"], {})
    assert result == [[u'artifactory_host', u'artifactory'], [u'artifactory_port', u'artifactory'], [u'artifactory_host', u'artifactory-db'], [u'artifactory_port', u'artifactory-db']], result



# Generated at 2022-06-25 11:00:11.480922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=[])
    assert result == []


# Generated at 2022-06-25 11:00:14.801709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    using_vars_0 =  {"lookup_terms": ["{{test_1}}", "{{test_2}}"], "lookup_variables": {"test_1": ["a", "b"], "test_2": ["c", "d"]}}
    result = lookup_module_0.run(using_vars_0["lookup_terms"], variables=using_vars_0["lookup_variables"])
    assert result == [["a", "c"], ["a", "d"], ["b", "c"], ["b", "d"]]

# Generated at 2022-06-25 11:00:16.395188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._combine()
    lookup_module_0._flatten()
    lookup_module_0._lookup_variables()
    lookup_module_0.run()


# Generated at 2022-06-25 11:00:24.950665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    class MockTemplar:
        def template(self, x, variables=None, **kwargs):
            return x
        def is_template(self, x, variables=None, **kwargs):
            return False
    lookup_module_0._templar = MockTemplar()
    lookup_module_0._loader = None

    # run with a normal set of inputs
    result_0 = lookup_module_0.run([ 'foo' ], None)
    assert result_0 == [ 'foo' ]

    # run with a more complex set of inputs
    result_1 = lookup_module_0.run([ 'foo', 'bar', 'baz' ], None)
    assert result_1 == [ 'foo', 'bar', 'baz' ]

    # run with a more complex set

# Generated at 2022-06-25 11:00:25.721209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 11:00:28.194373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = lookup_module_0.run(['1', '2'])
    assert my_list_0 == [['1', '2']]
    #  '1 2'


# Generated at 2022-06-25 11:00:30.584481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_1 = []
    dict_2 = {}
    list_of_list_3 = lookup_module_0.run(list_1, dict_2)
    assert list_of_list_3 == None # Run only returns a result if an error is raised.



# Generated at 2022-06-25 11:00:41.333569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_module_0 = LookupModule()
    # Create an instance of class Mapping
    mapping_0 = Mapping()
    # Assign instance of Mapping to 'dict' of lookup_module_0
    lookup_module_0.dict = mapping_0
    # Call the method run of class LookupModule on arguments
    # Uncomment the following lines to check the result of calling this method
    print(lookup_module_0.run())


# Generated at 2022-06-25 11:00:44.343003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0_run = LookupModule()
    dict_0 = {}
    var_0 = lookup_module_0_run.run(dict_0)


# Generated at 2022-06-25 11:00:49.227495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    x_0 = lookup_run(dict_0)
    assert(x_0 == 'foo')


# Generated at 2022-06-25 11:00:53.491133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [["test0", ["test1"]], ["test2", "test3"]]
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == [["test0", "test2"], ["test0", "test3"], ["test1", "test2"], ["test1", "test3"]]


# Generated at 2022-06-25 11:00:57.772516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['foo', 'bar']
    dict_0 = {}
    assert_raises(AnsibleError, lookup_run, (list_0, dict_0))
    list_1 = ['foo', 'bar', 'baz']
    dict_1 = {}
    assert_raises(AnsibleError, lookup_run, (list_1, dict_1))


# Generated at 2022-06-25 11:01:01.507267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    assert lookup_module_0.run(dict_0) == None, 'test_LookupModule_run did not return the expected value'
    assert lookup_module_0.run('test') == None, 'test_LookupModule_run did not return the expected value'
    return "ok"


# Generated at 2022-06-25 11:01:11.696560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x0 = LookupModule()
    x1 = [('foo',),('bar',),('baz',)]
    x2 = dict()
    x3 = x0.run(x1,x2)
    assert x3 == ['foo', 'bar', 'baz']
    x4 = [('foo', 'bar'),('foo', 'baz'),('bar', 'baz')]
    x5 = x0.run(x4,x2)
    assert x5 == [['foo', 'bar'], ['foo', 'baz'], ['bar', 'baz']]
    x6 = [('foo', 'bar'),('bar', 'baz')]
    x7 = x0.run(x6,x2)
    assert x7 == [['foo', 'bar'], ['bar', 'baz']]
   

# Generated at 2022-06-25 11:01:19.493912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_0['cmd'] = 'git ls-files'
    dict_0['_terms'] = ['ansible/modules/core', 'ansible/modules/extras']
    dict_0['_original_file'] = 'ansible/modules/core'
    dict_0['ansible_ssh_user'] = 'vagrant'


# Generated at 2022-06-25 11:01:21.657351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = list()
    var_2 = list()
    lookup_module = LookupModule()
    lookup_module.run(var_1, var_2)


# Generated at 2022-06-25 11:01:31.033058
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameter testcase_0 of method run
    dict_0 = dict()
    dict_0['a'] = ['b', 'c']
    dict_0['b'] = ['d', 'e']
    dict_0['c'] = ['f', 'g']
    testcase_0 = dict_0
    # Expected result of method run (testcase_0)
    expected_result_0 = [['b', 'd'], ['b', 'e'], ['c', 'd'], ['c', 'e']]
    assert expected_result_0 == LookupModule.run(dict_0)



# Generated at 2022-06-25 11:01:36.755254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["var_0", "dict_0"], dict_0)

# Generated at 2022-06-25 11:01:40.071340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = test_terms_with_nested
    var_0 = lookup_module_0._lookup_variables(terms_0)
    result_0 = lookup_module_0.run(terms_0, var_0)
    assert result_0 == test_terms_with_nested_result


# Generated at 2022-06-25 11:01:42.562674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_arg_0 = []
    dict_0 = {}
    var_0 = lookup_module_0.run(list_arg_0, dict_0)
    #print("var_0 = " + str(var_0))


# Generated at 2022-06-25 11:01:45.965368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v0 = []
    dict_1 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(v0, dict_1)

# Generated at 2022-06-25 11:01:57.685381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    list_0 = []
    dict_0 = {}
    list_1 = []
    list_1.append(list_0)
    list_1.append(list_0)
    var_0 = lookup_run(list_1)
    list_2 = []
    list_2.append(list_0)
    list_2.append(list_0)
    list_2.append(list_0)
    var_1 = lookup_run(list_2)
    list_3 = []
    list_3.append(list_0)
    var_2 = lookup_run(list_3)
    list_4 = []
    list_4.append(list_0)

# Generated at 2022-06-25 11:02:05.325367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default scenario
    lookup_module_1 = LookupModule()
    dict_1 = {'with_nested' : [['alice','bob'],['clientdb','employeedb','providerdb']]}
    expected_output_1 = [['alice', 'clientdb'],['alice', 'employeedb'],['alice', 'providerdb'],['bob', 'clientdb'],['bob', 'employeedb'],['bob', 'providerdb']]
    var_1 = lookup_run(dict_1)
    if var_1 == expected_output_1 :
        pass_1 = True
    else :
        pass_1 = False

    # Test with scenario not covered in above code

# Generated at 2022-06-25 11:02:13.408601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"param_0": LookupModule()}
    param_0 = dict_0.get("param_0")


# Generated at 2022-06-25 11:02:21.778654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 11:02:30.648930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    list_1 = lookup_module_0.run(list_0, dict_0)
    assert_equal(list_1, [])
    list_2 = []
    dict_1 = {}
    list_3 = lookup_module_0.run(list_2, dict_1)
    assert_equal(list_3, [])
    list_4 = []
    dict_2 = {}
    list_5 = lookup_module_0.run(list_4, dict_2)
    assert_equal(list_5, [])
    list_6 = []
    dict_3 = {}
    list_7 = lookup_module_0.run(list_6, dict_3)

# Generated at 2022-06-25 11:02:36.019728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(dict_0)
    return


# Generated at 2022-06-25 11:02:42.633566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.run(["a"], [{}])
    lookup_module_0.run(["a", "b"], [{}])



# Generated at 2022-06-25 11:02:51.147385
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # - name: here, 'users' contains the above list of employees
    #   mysql_user:
    #     name: "{{ item[0] }}"
    #     priv: "{{ item[1] }}.*:ALL"
    #     append_privs: yes
    #     password: "foo"
    #   with_nested:
    #     - "{{ users }}"
    #     - [ 'clientdb', 'employeedb', 'providerdb' ]

    terms = [
        "{{ users }}",
        [ 'clientdb', 'employeedb', 'providerdb' ]
    ]

    variables = {
        "users": [
            "alice",
            "bob"
        ]
    }

    lookup_module_0 = LookupModule()
    result = lookup_module_0._look

# Generated at 2022-06-25 11:02:52.089389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []


# Generated at 2022-06-25 11:02:56.181877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0)


# Generated at 2022-06-25 11:02:58.473093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
        print("\nPass\n")
    except:
        print("\nFail\n")

# Generated at 2022-06-25 11:03:03.745047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run in {(['dns_servers', 'dns_zones'],), (['dns_servers', 'dns_zones', 'dns_zones'],), (['dns_servers', 'dns_zones', 'dns_servers'])}


# Generated at 2022-06-25 11:03:09.915396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    lookup_module_0._available_variables = None
    var_0 = ['1','2','3']
    var_1 = '2'
    var_3 = ['3','4','5']
    var_4 = ['5','6','7']
    var_5 = ['9','0','1']
    var_6 = '1'
    var_2 = lookup_module_0.run([var_0,var_1,var_3,var_4,var_5,var_6])
    print('list is: ', var_2)

# Generated at 2022-06-25 11:03:13.344483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = []
    variables_1 = {}
    result_0 = lookup_module_0.run(terms_1,variables_1)
    assert result_0 == []
    assert_exception(AnsibleError, lambda: lookup_module_0.run(terms_1,variables_1))

# Generated at 2022-06-25 11:03:22.841041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock.MagicMock for LookupBase
    mock_lookup_base_0 = mock.MagicMock()
    # Instantiate LookupModule with LookupBase
    lookup_module_0 = LookupModule(mock_lookup_base_0)
    # Create a mock.MagicMock for ListifyMixin
    mock_listify_mixin_0 = mock.MagicMock()
    # Instantiate LookupModule with ListifyMixin
    lookup_module_0 = LookupModule(mock_listify_mixin_0)
    # Create a mock.MagicMock for None
    mock_none_0 = mock.MagicMock()
    # Instantiate LookupModule with None
    lookup_module_0 = LookupModule(mock_none_0)
    # Create a mock.MagicMock for

# Generated at 2022-06-25 11:03:24.106180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    str_0 = lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:03:36.468541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(terms=[])
    lookup_module_2 = LookupModule()
    result_2 = lookup_module_2.run(terms=[])
    assert 'result_2' in locals()
    assert result_2 == result_1
    lookup_module_3 = LookupModule()
    result_3 = lookup_module_3.run(terms=[])
    assert 'result_3' in locals()
    assert result_3 == result_1
    lookup_module_4 = LookupModule()
    result_4 = lookup_module_4.run(terms=[])
    assert 'result_4' in locals()
    assert result_4 == result_1
    lookup_module_5 = LookupModule()
    result_5 = lookup_module