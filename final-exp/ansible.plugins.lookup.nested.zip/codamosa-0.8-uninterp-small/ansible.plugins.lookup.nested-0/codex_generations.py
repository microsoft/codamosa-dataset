

# Generated at 2022-06-25 10:53:40.282055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    words_0 = [u'pam_user_name']
    assert lookup_module_0.run(words_0)[0][0] == 'pam_user_name'
    words_1 = [['fred', 'barney'], ['wilma', 'betty'], ['george', 'jane']]
    assert lookup_module_0.run(words_1)[0][0] == ['wilma', 'betty', 'george']
    words_2 = [['fred', 'barney'], ['wilma', 'betty'], ['george', 'jane']]
    assert lookup_module_0.run(words_2)[1][0] == ['wilma', 'betty', 'jane']

# Generated at 2022-06-25 10:53:44.172909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['[ [ foo, bar ], [ 1, 2 ] ]', '[ [ 3, 4 ] ]']
    variables = None
    x = LookupModule().run(terms, variables)
    assert x == [['foo', 'bar', 3, 4], ['foo', 'bar', 3, 4]]

# Generated at 2022-06-25 10:53:48.599546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = []
    my_list.reverse()
    result = []
    result = my_list.pop()
    test_case_0()
    test_case_1()
    test_LookupModule_run()
    test_LookupModule_run()


# Generated at 2022-06-25 10:53:51.735701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with a real variable
    result = lookup_module_0.run([["$var1"], ["$var2"]], {"var1": 1, "var2": 2}, **{})
    assert result == [[1, 1], [2, 2]]


# Generated at 2022-06-25 10:54:01.093486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    #Test 0
    # input:
    #    terms:
    #      - '[ [ 'michael', 'mike' ], [ 'the', 'big' ], [ 'kahuna' ] ]'
    # expected_output:
    #    [
    #      [ 'michael', 'the', 'kahuna' ],
    #      [ 'mike', 'the', 'kahuna' ],
    #      [ 'michael', 'big', 'kahuna' ],
    #      [ 'mike', 'big', 'kahuna' ]
    #    ]
    #
    #   NOTE:  This test is failing when run against the main code in this module,
    #          however, it passes when run against the code in 'test_results_0.py'
    #          which

# Generated at 2022-06-25 10:54:10.238837
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    test_params_0 = [
        [
            [
                'paris',
                'london',
            ],
            [
                'a',
                'b',
                'c',
            ],
        ],
    ]
    test_params_1 = [
        [
            [
                'paris',
                'london',
                'rome',
            ],
            [
                'a',
                'b',
                'c',
            ],
        ],
    ]
    test_params_2 = [
        [
            [
                'a',
                'b',
                'c',
            ],
            [
                'paris',
                'london',
                'rome',
            ],
        ],
    ]
    test_params_3

# Generated at 2022-06-25 10:54:19.047124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 10:54:28.501687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms0 = [[[1], [2], [3], [4]], [[5], [6], [7], [8]], [[9], [10], [11], [12]]]
    result = LookupModule().run(terms0)

# Generated at 2022-06-25 10:54:30.436309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([], None)
# test_LookupModule_run()



# Generated at 2022-06-25 10:54:39.050848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:54:43.457907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_list_2 = []
    new_result_4 = lookup_module_1.run(my_list_2)

# Generated at 2022-06-25 10:54:49.157975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(LookupModule, [], {}) == []


# Generated at 2022-06-25 10:54:57.943298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_variables = {}
    input_terms = [[['1'], ['2', '3']], [['4'], ['5', '6']]]
    expected_result = [['1', '4'], ['1', '5'], ['1', '6'], ['2', '4'], ['2', '5'], ['2', '6'], ['3', '4'], ['3', '5'], ['3', '6']]
    try:
        actual_result = LookupModule.run(LookupModule, input_terms, input_variables)
    except Exception as e:
        pytest.fail("Exception: " + str(e))
    assert expected_result == actual_result, "%s != %s" % (expected_result, actual_result)


# Generated at 2022-06-25 10:55:06.696654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run([[1], [2], [3]]) == [
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3]
    ]

    assert lookup_module.run([[1, 3], [2]]) == [
        [1, 2],
        [3, 2]
    ]

    assert lookup_module.run([[1, 3], [2], [7]]) == [
        [1, 2, 7],
        [3, 2, 7]
    ]


# Generated at 2022-06-25 10:55:17.291907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'a',
            'b',
            'c'
        ],
        [
            1,
            2,
            3
        ],
        [
            'one',
            'two',
            'three'
        ],
        [
            'do',
            're',
            'mi'
        ]
    ]
    variables_1 = dict()
    result = lookup_module_0.run(terms_0, variables_1)
    assert result[0][0] == 'a'
    assert result[0][1] == 1
    assert result[0][2] == 'one'
    assert result[0][3] == 'do'
    assert result[1][0] == 'a'

# Generated at 2022-06-25 10:55:27.717501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [
      [
        'alice',
        'bob'
      ],
      [
        'clientdb',
        'employeedb',
        'providerdb'
      ]
    ]
    variables = {
      'ansible_fqdn': 'localhost',
      'ansible_hostname': 'localhost'
    }
    result = lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 10:55:35.524484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: nothing is actually called here

    lookup_module_1 = LookupModule()
    terms_1 = None
    variables_1 = None
    kwargs_1 = {'var': 'var_1'}

    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == [
    ]

    lookup_module_2 = LookupModule()
    terms_2 = None
    variables_2 = None
    kwargs_2 = {'var': 'var_2'}

    assert lookup_module_2.run(terms_2, variables_2, **kwargs_2) == [
    ]

    lookup_module_3 = LookupModule()
    terms_3 = None
    variables_3 = None

# Generated at 2022-06-25 10:55:38.185630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [["ansible"], ["ansible"], ["ansible"]]
    lookup_module_0.run(terms)


# Generated at 2022-06-25 10:55:41.557199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    result = lookup_module_0.run(terms_0)
    assert result == []

# Generated at 2022-06-25 10:55:45.099049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []

# Generated at 2022-06-25 10:55:54.291809
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Setup test variables
    # setup_0
    terms_setup_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    variables_setup_0 = None
    kwarg_success_setup_0 = {'key': 'value'}

    # Setup test configuration

    # Execute test methods

    # Assert return value of method run
    assert lookup_module_1.run(terms_setup_0, variables_setup_0, **kwarg_success_setup_0)

# Generated at 2022-06-25 10:55:58.605978
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = [{'name': 'test',
                      'description': 'description',
                      'short_description': 'short description',
                      'options': {'foo': {'description': 'description', 'required': False}},
                      'examples': 'examples',
                      'return': 'return'}]
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run(lookup_module)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:56:06.478980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	lookup_module = LookupModule()
	assert lookup_module.run() == NotImplementedError
	assert lookup_module.run(['test1','test2']) == NotImplementedError
	assert lookup_module.run([['test1','test2']]) == NotImplementedError
	assert lookup_module.run([[['test1','test2']],['test3','test4']]) == NotImplementedError
	assert lookup_module.run([['test1','test2'],['test3','test4'],['test5','test6']]) == NotImplementedError
	assert lookup_module.run(['test1','test2','test3']) == NotImplementedError
	assert lookup_module.run([['test1','test2'],['test3','test4']]) == Not

# Generated at 2022-06-25 10:56:13.274675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  terms_2 = []
  variables_3 = None
  kwargs_4 = {'_raw': [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]}
  assert lookup_module_1.run(terms_2, variables_3, **kwargs_4) == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]


# Generated at 2022-06-25 10:56:20.192045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb']], [])
    assert lookup_module_0.run([[u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb']], '{{ users }}')

# vim: set filetype=python tabstop=4 shiftwidth=4 softtabstop=4 expandtab :

# Generated at 2022-06-25 10:56:21.694047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run()) == 0

# Generated at 2022-06-25 10:56:28.739733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        [
            'foo',
            'bar',
            'baz',
        ],
        [
            'x',
            'y',
            'z',
        ],
    ]

# Generated at 2022-06-25 10:56:37.850168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    terms_0 = ['var_0', 'var_1', 'var_2']
    terms_1 = ['var_3', 'var_4', 'var_5']
    terms_2 = ['var_6', 'var_7', 'var_8']
    terms_3 = ['var_9', 'var_10', 'var_11']
    terms_xx = [terms_0, terms_1, terms_2, terms_3]
    terms_xx2 = [terms_0, terms_1, terms_2, terms_3]
    # Redefine method run to fake the call to self._combine, which is tested separately
    def run_fake(self, terms, variables=None, **kwargs):
        my_

# Generated at 2022-06-25 10:56:43.135052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _terms = [ [ 'a', 'b' ], [ 1, 2, 3 ] ]
    _variables = None
    _kwargs = { 'other': None }
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(_terms, _variables, **_kwargs)


# Generated at 2022-06-25 10:56:46.714003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test starting of the execution of the method with wrong parameter
    # LookupModule.run() called with incorrect number of parameters
    try:
        lookup_module_0.run()
    except TypeError as e:
        print("There is an error in calling the method: {0}".format(str(e)))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:56:58.220437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_1 = lookup_module_0.run([['a', 'b', 'c'], ['1', '2', '3']])
    if len(str_1) != 9:
        raise Exception("Test 1.1 failed")
    if str_1[0] != ['a', '1']:
        raise Exception("Test 1.2 failed")
    if str_1[-1] != ['c', '3']:
        raise Exception("Test 1.3 failed")
    str_1 = lookup_module_0.run([['a', 'b', 'c'], ['1', '2', '3'], ['I', 'II', 'III']])
    if len(str_1) != 27:
        raise Exception("Test 2.1 failed")

# Generated at 2022-06-25 10:57:01.830297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=None, variables=None) == [], "If terms is None, then return an empty list"


# Generated at 2022-06-25 10:57:04.987169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({ 'i': 1, 'j': 2, 'k': 3, 'l': 4 })
    terms_1 = []
    lookup_module_1.run(terms_1)


# Generated at 2022-06-25 10:57:11.925159
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    
    # Test the case where an error is thrown.
    arguments = [2,3]
    try:
        lookup_module.run(arguments)
    except Exception as e:
        assert e.args[0] == "with_nested requires at least one element in the nested list"
        print("Test case 0 passed.")
    else:
        print("Test case 0 failed.")


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:57:20.972734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "abcde"
    my_list_0 = [terms_0]
    my_list_0.reverse()
    result_0 = []
    if len(my_list_0) == 0:
        raise AnsibleError("with_nested requires at least one element in the nested list")
    result_0 = my_list_0.pop()
    while len(my_list_0) > 0:
        result_1 = lookup_module_0._combine(result_0, my_list_0.pop())
        result_0 = result_1
    new_result_0 = []
    for x_0 in result_0:
        new_result_0.append(lookup_module_0._flatten(x_0))
    assert new_

# Generated at 2022-06-25 10:57:27.146062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['[1, 2, 3]', '[ "a", "b", "c" ]']

    try:
        lookup_module.run(terms, variables=None)
    except AnsibleError as e:
        assert str(e) == "with_nested requires at least one element in the nested list"
    except Exception as e:
        assert False, "Unexpected exception raised: %s" % e

    terms = ['[1, 2, 3]', '[ "a", "b", "c" ]', '[ 4, 5 ]']
    result = lookup_module.run(terms, variables=None)


# Generated at 2022-06-25 10:57:35.645648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [('xyz', 'abc', '1', '2'), ('3', '4', '5', '6', '7'), ('8', '9'), ('a', 'b', 'c')]
    expected = [['xyz', 'abc', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c']]
    output = lookup_module_0.run(terms, variables=None)
    assert output == expected


# Generated at 2022-06-25 10:57:43.438043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

  # Test with a valid value, to validate the behaviour of the run method
  # when all the variables were previously defined via the LookupModule.run method
  lookup_module.set_options({'_terms': ['{{item}}.*'],
                             '_raw': [['alice', 'bob'],
                                      ['clientdb', 'employeedb', 'providerdb']],
                             'item': 'test'})
  item = lookup_module.run()

  # The unittest must validate the expected value and the type of the output
  assert item[0] == ['test.*'] and item[1] == ['test.*']

# Generated at 2022-06-25 10:57:53.354327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Tests with undefined variables
    with pytest.raises(AnsibleUndefinedVariable):
        assert lookup_module_0.run([[1, 2], [3], [4, 5]], {})
    # Tests with normal input
    assert lookup_module_0.run([[1, 2], [3], [4, 5]], {}) == [[1, 3, 4], [1, 3, 5], [2, 3, 4], [2, 3, 5]]

# Generated at 2022-06-25 10:57:55.231715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['asdf', 'qwer'])
    assert result == [['asdf', 'qwer']]


# Generated at 2022-06-25 10:58:01.090487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ ['foo', 'bar', 'baz'], ['a', 'b', 'c'], ['1', '2', '3'] ]
    variables = {}
    test_LookupModule = LookupModule()

# Generated at 2022-06-25 10:58:11.430450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule([], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [])

# Generated at 2022-06-25 10:58:21.896305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["foo", "bar"]
    expect_0 = None
    actual_0 = lookup_module_0.run(terms_0)
    try:
        assert actual_0 == expect_0
    except:
        print(actual_0)
        print(expect_0)

    lookup_module_1 = LookupModule()
    terms_1 = ["foo", ["bar_0", "bar_1"]]
    expect_1 = None
    actual_1 = lookup_module_1.run(terms_1)
    try:
        assert actual_1 == expect_1
    except:
        print(actual_1)
        print(expect_1)

    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:58:28.736781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([['- {foo: bar}'], ['[1, 2, 3]']])
    assert result == [[{'foo': 'bar'}, 1], [{'foo': 'bar'}, 2], [{'foo': 'bar'}, 3]]


# Generated at 2022-06-25 10:58:30.621297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    rf0 = lookup_module_0.run(None)
    assert rf0 == []

# Generated at 2022-06-25 10:58:33.140712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()


# Generated at 2022-06-25 10:58:42.504810
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # making a lookup module object
    lookup_module = LookupModule()

    # validating test setup
    assert lookup_module is not None

    # validating test data
    assert lookup_module.run(terms=[[['a', 'b', 'c'], ['1', '2', '3']], [1, 2, 3]], variables=None) == \
        [['a', 1, 2, 3], ['b', 1, 2, 3], ['c', 1, 2, 3]]

    # validating test data

# Generated at 2022-06-25 10:58:50.775817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # testing positive case value
    lookup_module_0 = LookupModule()
    terms_0 = ["[ 'alice', 'bob' ]", "[ 'clientdb', 'employeedb', 'providerdb' ]"]
    kwargs_0 = {'variables': None}
    assert lookup_module_0.run(terms_0, variables=None, **kwargs_0) == [["alice", "clientdb"], ["alice", "employeedb"], ["alice", "providerdb"], ["bob", "clientdb"], ["bob", "employeedb"], ["bob", "providerdb"]]

# Generated at 2022-06-25 10:58:52.506932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Call:test_LookupModule_run")
    lookup_module = LookupModule()
    lookup_module.run([['a', 'b'], ['1', '2', '3']])


# Generated at 2022-06-25 10:58:59.619926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'dummy'
    str_1 = 'dummy'
    terms_0 = [str_1]
    terms_1 = [str_1]
    terms_0.reverse()
    result_0 = []
    if len(terms_0) == 0:
        raise AnsibleError("with_nested requires at least one element in the nested list")
    result_0 = terms_0.pop()
    while len(terms_0) > 0:
        result_1 = lookup_module_0._combine(result_0, terms_0.pop())
        result_0 = result_1
    new_result_0 = []
    for x in result_0:
        new_result_0.append(lookup_module_0._flatten(x))

# Generated at 2022-06-25 10:59:05.662457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'{{ users }}']
    result = lookup_module_0.run(terms)
    assert len(result) == 1
    assert result[0] == [u'alice', u'bob']


# Generated at 2022-06-25 10:59:14.409572
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # BEGIN-SNIPPET: LookupModule_run
    lookup_module_run = LookupModule()
    result = lookup_module_run.run([])
    assert result == []

    lookup_module_run = LookupModule()
    result = lookup_module_run.run([['a'], ['b']])
    assert result == [['a', 'b']]

    lookup_module_run = LookupModule()
    result = lookup_module_run.run([['a', 'b'], ['c']])
    assert result == [['a', 'c'], ['b', 'c']]

    lookup_module_run = LookupModule()
    result = lookup_module_run.run([['a'], ['b', 'c']])

# Generated at 2022-06-25 10:59:19.783222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_case_0 = [{
                }]
    if lookup_module_1.run(test_case_0[0]) != 'writable':
        raise AssertionError()

    if lookup_module_1.run(test_case_0[0], variables={'test_var': 'RED'}) != 'RED':
        raise AssertionError()

    if lookup_module_1.run(test_case_0[0], variables={'test_var': 'GREEN'}) != 'GREEN':
        raise AssertionError()


# Generated at 2022-06-25 10:59:24.196346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['1', '-1', '20', '-20']
    kwargs_0 = {}
    var_0 = lookup_module_0.run(terms_0, **kwargs_0)
    test_module_0 = "['1-1', '1-20', '20-1', '20-20']"
    assert var_0 == test_module_0, "Test case failed: test_LookupModule_run"

# Generated at 2022-06-25 10:59:30.045014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([[1], [2]]) == [[1, 2]]
    assert lookup_module.run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]
    assert lookup_module.run(['foo']) == [['foo']]
    assert lookup_module.run([['foo']]) == [['foo']]
    assert lookup_module.run(['foo', ['bar']]) == [['foo', 'bar']]
    assert lookup_module.run(['foo', ['bar', 'baz']]) == [['foo', 'bar'], ['foo', 'baz']]

# Generated at 2022-06-25 10:59:32.243240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = []
    expected_result = []

    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(params)
    assert result == expected_result



# Generated at 2022-06-25 10:59:37.654902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["[ 'alice', 'bob' ]", "[ 'clientdb', 'employeedb', 'providerdb' ]"]
    variables_0 = ""
    expected_0 = [["alice", "clientdb"], ["alice", "employeedb"], ["alice", "providerdb"], ["bob", "clientdb"], ["bob", "employeedb"], ["bob", "providerdb"]]
    actual_0 = lookup_module_0.run(terms_0, variables_0, )
    assert actual_0 == expected_0


# Generated at 2022-06-25 10:59:45.862280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule::run()
    """
    lookup_module = LookupModule()
    my_list = [ [1, 2, 3], [4, 5, 6] ]
    ret = lookup_module.run(my_list, None)
    assert ret[0] == [ 1, 4 ]
    assert ret[1] == [ 1, 5 ]
    assert ret[2] == [ 1, 6 ]
    assert ret[3] == [ 2, 4 ]
    assert ret[4] == [ 2, 5 ]
    assert ret[5] == [ 2, 6 ]
    assert ret[6] == [ 3, 4 ]
    assert ret[7] == [ 3, 5 ]
    assert ret[8] == [ 3, 6 ]
    return ret


# Generated at 2022-06-25 10:59:47.652314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    r = lookup_module.run([[1,2,3], [4,5,6]])
    assert r == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]]

# Generated at 2022-06-25 10:59:52.761015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    plugin_options_0 = dict()
    plugin_options_0['_raw'] = True
    plugin_options_0['_terms'] = ['[ [ "foo" ], [ "bar" ] ]']
    terms_0 = []
    terms_0.append('[ [ "foo" ], [ "bar" ] ]')
    obj_0 = lookup_module_0.run(terms_0,plugin_options_0)
    print(obj_0)

# Testing without arguments
test_case_0()
# Testing with arguments
test_LookupModule_run()

# Generated at 2022-06-25 11:00:01.302454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == "", "lookup_module_0.run() returned the wrong value."
    assert lookup_module_0.run() == "", "lookup_module_0.run() returned the wrong value."
    assert lookup_module_0.run() == "", "lookup_module_0.run() returned the wrong value."

# Generated at 2022-06-25 11:00:09.218942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run([[['a'],['b']],[['c'],['d']],[[1],[2]]], {})
    assert results ==  [['a', 'c', 1], ['a', 'c', 2], ['a', 'd', 1], ['a', 'd', 2], ['b', 'c', 1], ['b', 'c', 2], ['b', 'd', 1], ['b', 'd', 2]]

# Generated at 2022-06-25 11:00:15.957763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_1 = LookupModule()
   result = lookup_module_1.run(["{{a}}", "{{b}}"], {"a": [1, 2], "b": [3, 4]})
   assert result == [["1", "3"], ["1", "4"], ["2", "3"], ["2", "4"]]


# Generated at 2022-06-25 11:00:18.815228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([])
    return

# Generated at 2022-06-25 11:00:26.231433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    lookup_plugin_options_0 = {}
    lookup_plugin_options_1 = {}
    lookup_plugin_options_0['terms'] = ['bob', 'alice', 'charlie']
    lookup_plugin_options_0['variables'] = {}
    lookup_plugin_options_1['terms'] = [['bob', 'alice', 'charlie'], ['bob', 'alice', 'charlie']]
    lookup_plugin_options_1['variables'] = {}

    # Test case 0
    expected_result_0 = [['bob', 'bob'], ['alice', 'alice'], ['charlie', 'charlie']]
    result_0 = lookup_module_obj.run(**lookup_plugin_options_0)

# Generated at 2022-06-25 11:00:30.162917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:00:40.323464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    #
    # Test case for 'run' with 3 arguments
    #
    lst_1 = []
    lst_1_1 = lookup_module_1.run(lst_1)
    assert lst_1_1 == []
    #
    lst_2 = ['bar']
    lst_2_1 = lookup_module_1.run(lst_2)
    assert lst_2_1 == [['bar']]
    #
    lst_3 = ['bar', 'baz']
    lst_3_1 = lookup_module_1.run(lst_3)
    assert lst_3_1 == [['bar', 'baz']]
    #
    lst_4 = ['foo', 'bar', 'baz']


# Generated at 2022-06-25 11:00:44.727373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    lookup_module_obj.run("[ 'alice', 'bob' ]", "[ 'clientdb', 'employeedb', 'providerdb' ]")
    lookup_module_obj.run("[ 'clientdb', 'employeedb', 'providerdb' ]", "[ 'alice', 'bob' ]")
    lookup_module_obj.run("[ 'clientdb', 'employeedb', 'providerdb' ]", "[ 'alice', 'bob' ]", "[ 'clientdb', 'employeedb', 'providerdb' ]")

# Generated at 2022-06-25 11:00:54.530713
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms = [
        [
            "{{ users }}"
        ],
        [
            "clientdb",
            "employeedb",
            "providerdb"
        ]
    ]

    variables = {
        "users": [
            "alice",
            "bob"
        ]
    }

    expected = [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

    result = lookup_module_0.run(terms, variables)

    assert result == expected



# Generated at 2022-06-25 11:01:03.990384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    test_case_0_input_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    test_case_0_expected_output_0 = [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

    test_case_0_output_0 = lookup_module_0.run(terms=test_case_0_input_0)

    eq_(test_case_0_expected_output_0, test_case_0_output_0, msg="test case 0 failed")

# Generated at 2022-06-25 11:01:17.351154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = [
        [
            [1, 2, 3],
            [4, 5, 6]
        ],
        [
            [7, 8, 9],
            [10, 11, 12]
        ]
    ]
    result = lookup_module_0.run(my_list_0)
    assert len(result) == 4
    assert result[0] == [1, 2, 3, 7, 8, 9]
    assert result[1] == [1, 2, 3, 10, 11, 12]
    assert result[2] == [4, 5, 6, 7, 8, 9]
    assert result[3] == [4, 5, 6, 10, 11, 12]


# Generated at 2022-06-25 11:01:27.203441
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Path for the data file for test method run of class LookupModule
    data_file_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'run_input.json')

    # Read the contents of the data file for test method run of class LookupModule
    with open(data_file_path) as run_input_data_file:
        run_input_data = run_input_data_file.read()

    # Deserialize the data from JSON file
    run_input = json.loads(run_input_data)

    # Get the terms from the JSON object
    terms = run_input['terms']

    # Get the parameters from the JSON object
    variables = run_input['variables']

    # Make the lookup plugin object
    lookup_module = LookupModule()

    # Call

# Generated at 2022-06-25 11:01:32.686760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[['a', 'b', 'c'], ['1', '2', '3']])


# Generated at 2022-06-25 11:01:38.466032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lists_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    expected_result_0 = [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    lookup_module_0 = LookupModule()
    actual_result_0 = lookup_module_0.run(my_lists_0)
    assert actual_result_0 == expected_result_0

# Generated at 2022-06-25 11:01:45.485769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t1 = 'a'
    t2 = 'b'
    t3 = 'c'
    t4 = 'd'
    t5 = 'e'
    t6 = 'f'
    t7 = 'g'
    terms = [t1, t2, t3, t4, t5, t6, t7]
    lookup_module_1 = LookupModule()
    lookup_module_1_result = lookup_module_1.run(terms)

# Generated at 2022-06-25 11:01:50.405567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_terms_1 = []
    test_terms_1.append(["4", "5"])
    test_terms_1.append(["6", "7"])
    test_terms_1.append(["8", "9"])
    lookup_module_1._templar.available_variables = dict()
    test_result_1 = lookup_module_1.run(terms=test_terms_1)

# Generated at 2022-06-25 11:02:00.919164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([[1], [2], [3]]) == [[1, 2, 3]]
    assert lookup_module.run([[1, 2, 3], [4, 5, 6]]) == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]]
    assert lookup_module.run([['hoy', 'hi'], ['how', 'are', 'you']]) == [['hoy', 'how'], ['hoy', 'are'], ['hoy', 'you'], ['hi', 'how'], ['hi', 'are'], ['hi', 'you']]

# Generated at 2022-06-25 11:02:08.077418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['item1', 'item2'], ['itemA', 'itemB']]
    result = []
    result.append(['item1', 'itemA'])
    result.append(['item1', 'itemB'])
    result.append(['item2', 'itemA'])
    result.append(['item2', 'itemB'])

    lookup_module = LookupModule()
    assert result == lookup_module.run(terms)
    # assert False # let us know if the test fails

# Generated at 2022-06-25 11:02:12.144697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([[]]) == [[]]
    assert lookup_module_1.run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]

# Generated at 2022-06-25 11:02:17.186836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert [["a"],["b"],["c"],["d"],["e"],["f"],["g"],["h"],["i"],["j"]] == lookup_module.run(terms=[["a","b","c","d","e"],["f","g","h","i","j"]], variables=None, **kwargs)


# Generated at 2022-06-25 11:02:27.149203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['[[1, 2], [3, 4]]']
    variables_0 = None
    kwargs_0 = {'terse': False, '_ansible_check_mode': False, '_ansible_step': None, '_ansible_cur_task': None, '_ansible_no_log': False, '_ansible_debug': False, 'verbosity': 0, '_ansible_verbosity': 0, '_ansible_selinux_special_fs': [u'/sys/fs/selinux', u'/sys/fs/selinux/null', u'/sys/fs/selinux/user', u'/sys/fs/selinux/booleans']}

# Generated at 2022-06-25 11:02:31.095851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert True == False


# Generated at 2022-06-25 11:02:39.846588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        [
            "{{ foo }}",
            "{{ bar }}"
        ],
        [
            "{{ baz }}",
            "{{ foobar }}"
        ]
    ]
    variables = dict(
        foo="foo",
        bar="bar",
        baz="baz",
        foobar="foobar",
    )
    results = [
        [
            "foo",
            "bar"
        ],
        [
            "baz",
            "foobar"
        ]
    ]
    assert lookup_module._lookup_variables(terms, variables) == results

# Generated at 2022-06-25 11:02:43.414393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'])
    assert len(result) == 676


# Generated at 2022-06-25 11:02:45.224902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(terms, variables)
    res = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:02:48.890201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo', 'bar']
    result_0 = lookup_module_0.run(terms_0, None)
    assert result_0 == [['foo'], ['bar']]



# Generated at 2022-06-25 11:02:56.578668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    arg_0 = [['apache', 'nginx'], ['httpd', 'iss6', 'openlitespeed']]
    arg_1 = {}
    result = lookup_module_1.run(arg_0, arg_1)
    assert result == [['apache', 'httpd'], ['apache', 'iss6'], ['apache', 'openlitespeed'], ['nginx', 'httpd'], ['nginx', 'iss6'], ['nginx', 'openlitespeed']]

# Generated at 2022-06-25 11:03:00.599405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1, LookupModule)

# Generated at 2022-06-25 11:03:03.244654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:03:10.154722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['{{ foo }}', '{{ bar }}'], 'variables'), list) is True
    assert lookup_module_0.run(['{{ foo }}', '{{ bar }}'], 'variables') == []
    assert isinstance(lookup_module_0.run(['{{ foo }}', '{{ bar }}'], {'bar': 'List element 1', 'foo': 'List element 0'}), list) is True
    assert lookup_module_0.run(['{{ foo }}', '{{ bar }}'], {'bar': 'List element 1', 'foo': 'List element 0'}) == [['List element 0'], ['List element 1']]

# Generated at 2022-06-25 11:03:19.083389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert  len(lookup_module_0.run()) == 0

# Generated at 2022-06-25 11:03:21.277024
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Call method run of class LookupModule with args to test
    result = LookupModule.run(*args)
    # Test if  result is not None
    assert result is not None, "Expected result to not be None"



# Generated at 2022-06-25 11:03:22.785933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run([], variables={})
    assert var_1 == []


# Generated at 2022-06-25 11:03:24.055811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = b''
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:03:28.186962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = ['foo', 'bar']
    var_2 = ['baz', ['cat', 'dog'], 'monkey']
    var_3 = ['boom', 'bam', 'bap', ['bix', 'box', 'bex']]
    var_4 = ['qux', 'quz', 'qug', ['qui', 'quv', 'qub']]
    var_5 = [['foo', 'bar'], 'baz', ['cat', 'dog'], 'monkey']
    var_6 = [['foo', 'bar'], 'baz', [['cat', 'dog'], 'monkey']]

# Generated at 2022-06-25 11:03:33.688493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fail_on_undefined_0 = None
    undefined_error_0 = None
    variables_0 = None
    terms_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, variables_0, fail_on_undefined=fail_on_undefined_0)
