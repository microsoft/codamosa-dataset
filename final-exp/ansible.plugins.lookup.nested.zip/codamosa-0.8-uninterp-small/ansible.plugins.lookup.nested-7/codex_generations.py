

# Generated at 2022-06-25 10:53:35.632114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    input_2 = []
    variables_2 = {}
    result_2 = lookup_module_2.run(input_2, variables_2)
    assert result_2 == [], 'Expected [""], got %s' % result_2


# Generated at 2022-06-25 10:53:40.245266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["", "", ""]
    args_0 = dict({})
    kwargs_0 = dict({})
    try:
        lookup_module_0.run(terms_0, **kwargs_0)
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")


# Generated at 2022-06-25 10:53:43.259691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['A'])
    assert result == (['A'])


# Generated at 2022-06-25 10:53:52.402952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # empty list case
    lookup_module.set_environment({})
    results = lookup_module.run([])
    assert results == []

    lookup_module.set_environment({})
    lookup_module.set_loader(None)
    lookup_module.set_templar(None)
    terms = [
        [
            'a', 'b'
        ], [
            1, 2, 3
        ]
    ]
    results = lookup_module.run(terms)
    assert results == [
        ['a', 1], ['a', 2], ['a', 3], ['b', 1], ['b', 2], ['b', 3]
    ]

    lookup_module.set_environment({})
    lookup_module.set_loader(None)
    lookup_module.set_templ

# Generated at 2022-06-25 10:53:55.574924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['foo','bar','baz']
    lookup.run(terms)

# Generated at 2022-06-25 10:54:03.795781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_LookupModule_run_0 = '''
---
- hosts: localhost
  tasks:
    - debug:
        msg: "{{ lookup('nested', ['1', '2', '3'] ) }}"
    - debug:
        msg: "{{ lookup('nested', ['1', '2', '3'], ['a', 'b', 'c'] ) }}"
    - debug:
        msg: "{{ lookup('nested', ['a', 'b', 'c'], ['1', '2', '3'] ) }}"
    - debug:
        msg: "{{ lookup('nested', [ [ 'a', 'b', 'c' ], [ '1', '2', '3' ] ] ) }}"
  '''

# Generated at 2022-06-25 10:54:05.729271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    assert lookup_module_0.run(terms) == []


# Generated at 2022-06-25 10:54:07.749608
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    res = lookup_module_0.run([['a'], ['b']], dict())

    assert res == [['a', 'b']]

# Generated at 2022-06-25 10:54:13.979376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    given_0 = [u[u'_raw']]
    given_1 = {u'_original_file': u'playbooks/library/nested.yaml'}
    expected_0 = [u[u'_raw']]
    expected_1 = []
    expected_2 = []
    expected_3 = []
    expected_4 = []
    expected_5 = []
    expected_6 = []
    expected_7 = []
    expected_8 = []
    expected_9 = []
    expected_10 = []
    expected_11 = []
    expected_12 = []
    expected_13 = []
    expected_14 = []
    expected_15 = []
    expected_16 = []
    expected_17 = []
    expected_18 = []
    expected_19 = []

    lookup_module_0 = Look

# Generated at 2022-06-25 10:54:21.114602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dictAll = dict()
    dictAll["_terms"] = [["foo", "bar"], ["baz", "bam"]]
    lookup_module_1 = LookupModule()
    res = lookup_module_1.run(variables=dictAll)
    assert res == [["foo", "baz"], ["foo", "bam"], ["bar", "baz"], ["bar", "bam"]]


# Generated at 2022-06-25 10:54:32.953495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = list()
    terms_0.append(list())
    terms_0.append(list())
    terms_0[0].append("user")
    terms_0[1].append("user")
    terms_0[1].append("password")
    variables_0 = dict()
    variables_0["client_ip"] = "192.168.0.11"
    variables_0["user"] = "vagrant"
    variables_0["password"] = "vagrant"
    variables_0["host_name"] = "host.domain.tld"
    subset_0 = lookup_module_0.run(terms_0, variables_0)
    assert subset_0 == [['user', 'user', 'password'], ['user', []]]

# Unit test

# Generated at 2022-06-25 10:54:35.304972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    result_0 = lookup_module_0.run([])
    assert result_0 == [], "Expected {}, got {}".format([], result_0)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:54:38.598236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = []
    my_list = [["adam", "bob"], ["one", "two"]]
    lookup_module_0.run(my_list, variables=None)
    assert result == []


# Generated at 2022-06-25 10:54:42.291023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = []
    terms_0 = my_list_0
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []


# Generated at 2022-06-25 10:54:47.680665
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:54:52.886168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    result = lu.run(terms)
    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    print('')
    print('result: ', result)
    print('test_LookupModule_run() passed')


test_LookupModule_run()



# Generated at 2022-06-25 10:54:54.916458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:55:01.702067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:55:05.494543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing
    lookup_module_0 = LookupModule()
    # Getting the list of arguments
    params = ["_raw"]
    arg_0 = params[0]
    # Calling the method
    result = lookup_module_0.run(arg_0)
    assert result == None

# Generated at 2022-06-25 10:55:08.385113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        terms = [['a2'], ['a1', 'a2', 'a3']]
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms)
    except Exception as e:
        print(str(e))
    else:
        pass



# Generated at 2022-06-25 10:55:17.646897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0  = []
  lookup_module_0 = LookupModule()
  var_1 = lookup_module_0.run(var_0)
  try:
    assert var_1
  except AssertionError as ar:
    #print var_1
    print ("Expected", "AnsibleError('with_nested requires at least one element in the nested list',)", "observed", "AnsibleError('with_nested requires at least one element in the nested list',)", var_1)
    raise ar


# Generated at 2022-06-25 10:55:21.170657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 10:55:23.165575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:55:31.397940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Here we patch the LookupBase.get_basedir method to return the directory of this module so the relative templating works
    # I wish there was a better way to do this, but I can't see any other way.
    lookup_module_0.get_basedir = lambda: os.path.dirname(os.path.abspath(__file__))

    # test_case_0

# Generated at 2022-06-25 10:55:41.233463
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Assuming following 'terms'
    terms = [
        [
            [
                'a',
                'b'
            ],
            [
                'c',
                'd'
            ]
        ],
        [
            [
                'e',
                'f'
            ],
            [
                'g',
                'h'
            ]
        ]
    ]


# Generated at 2022-06-25 10:55:47.039224
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # unit test:
  # Run with empty list
  var_0 = []
  lookup_module_0 = LookupModule()
  var_1 = lookup_module_0.run(var_0)
  assert(var_1 == [])

  # unit test:
  # Run with nested list
  var_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'], [['john', 'mark'], [['dave'], ['joe']]]]
  lookup_module_0 = LookupModule()
  var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 10:55:49.252903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)

    assert result is not None



# Generated at 2022-06-25 10:55:51.071847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 10:55:53.784163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:55:55.792731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    assert isinstance(var_1, list)

# Generated at 2022-06-25 10:56:00.062831
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = []
    variables = []
    kwargs = {}

    lookup = LookupModule()
    lookup.run(terms, variables, kwargs)


# Generated at 2022-06-25 10:56:04.903599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    var_2 = lookup_module_0.run(var_0)
    assert var_1 == var_2


# Generated at 2022-06-25 10:56:11.028023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    var = lookup.run([[['a', 'b'], ['1', '2']], [['c', 'd'], ['3', '4']]])

# Generated at 2022-06-25 10:56:12.178123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 10:56:16.440849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    at0 = []
    at1 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    assert test_run(at0, at1) == True


# Generated at 2022-06-25 10:56:19.845979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0._lookup_variables(var_0)
    var_2 = []
    var_3 = lookup_module_0.run(var_2, var_1)


# Generated at 2022-06-25 10:56:26.311382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = listify_lookup_plugin_terms('test/ansible/vars/myfile.yaml', templar=self._templar, loader=self._loader, fail_on_undefined=True)
    var_0 = [var_0]
    var_1 = [listify_lookup_plugin_terms('test/ansible/vars/myfile.yaml', templar=self._templar, loader=self._loader, fail_on_undefined=True)]
    var_2 = lookup_module_0.run(var_0, var_1)


# Generated at 2022-06-25 10:56:27.837220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 10:56:34.819682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = []
    var_1.append('梁')
    var_1.append('建国')
    var_2 = []
    var_2.append('梁')
    var_2.append('上')
    var_2.append('桥')
    var_3 = []
    var_3.append(var_1)
    var_3.append(var_2)
    var_0 = lookup_module_0.run(var_3)

# Generated at 2022-06-25 10:56:39.452138
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        lookup_module_0 = LookupModule()
        var_0 = []
        var_1 = lookup_module_0.run(var_0)
        raise Exception("expected exception: %s" % AnsibleError)
    except AnsibleError:
        pass


# Generated at 2022-06-25 10:56:47.368124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        [
            [
                [
                    'alice',
                    'bob'
                ],
                [
                    'clientdb',
                    'employeedb',
                    'providerdb'
                ]
            ]
        ]
    ]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == [
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]

test_case_0()

# Generated at 2022-06-25 10:56:54.188829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up object
    lookup_module_0 = LookupModule()
    var_0 = [["{{ test_var }}"]]
    if (var_0 == None):
        pytest.skip('Cannot look up variables as vars are unset')
    # set up context
    set_0 = {}
    set_0["test_var"] = "bar"
    # invoke run() method
    result = lookup_module_0.run(var_0[0], set_0)
    # assertions
    assert result == [[["text", "text"]]]
    # cleanup function
    # cleanup function
    # cleanup function
    # cleanup function
    lookup_module_0 = None


# Generated at 2022-06-25 10:56:56.160153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = []
    assert lookup_module.run(var) == []


# Generated at 2022-06-25 10:57:03.516291
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:57:05.564938
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = { } # dict
    var_1 = [] # list

    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 10:57:11.879427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    if isinstance(var_1, list):
        var_3 = var_1[0]
        if isinstance(var_3, list):
            var_5 = var_3[0]
            if isinstance(var_5, list):
                var_7 = var_5[0]
    assert var_7 == 'a'


# Generated at 2022-06-25 10:57:20.937268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [ ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'], ['0','1','2','3','4','5','6','7','8','9'] ]
    var_1 = LookupModule()
    var_2 = var_1.run(var_0)

# Generated at 2022-06-25 10:57:24.730913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["foo"], ["bar"]]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:57:30.771383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # lookups/nested.py:90: _combine
    var_0 = []
    # lookups/nested.py:87: _flatten
    var_1 = []
    var_2 = []
    # lookups/nested.py:90: _combine
    var_3 = []
    var_4 = 0

    try:
        var_5 = lookup_module_0.run(var_0)
    except Exception as e:
        var_5 = None

    assert var_5 == var_1

    try:
        var_6 = lookup_module_0.run(var_2)
    except Exception as e:
        var_6 = None

    assert var_6 == var_3

# Generated at 2022-06-25 10:57:38.985292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["a", "b", "c"],["1", "2", "3"]]
    var_1 = lookup_run(var_0)
    var_2 = [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3'], ['c', '1'], ['c', '2'], ['c', '3']]
    assert var_1 == var_2


# Generated at 2022-06-25 10:57:43.954674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [0, 1, 2, 3]
    var_0 = test_data_0()
    test_data_1()
    var_0 = [0, 1, 2, 3]
    var_0 = test_data_0()
    test_data_1()


# Generated at 2022-06-25 10:57:55.984483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = _lookup_variables(terms,variables)
    vars_1 = []
    vars_2 = vars_0[:]
    vars_3 = vars_2.reverse()
    vars_4 = []
    try:
        vars_5 = len(vars_0)
    except Exception as e_2:
        vars_6 = e_2
    else:
        vars_7 = type(vars_6)
        vars_8 = issubclass(vars_7,object)
        if vars_8:
            try:
                vars_9 = vars_6.__init__
            except Exception as e_3:
                vars_10 = e_3
            else:
                vars_11 = type(vars_10)


# Generated at 2022-06-25 10:58:05.019982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_with_nested = LookupModule()
    vars_run_0 = []
    var_0 = test_with_nested.run(vars_run_0)
    vars_run_1 = ["item_0", "item_1"]
    var_1 = test_with_nested.run(vars_run_1)
    vars_run_2 = ["item_0"]
    var_2 = test_with_nested.run(vars_run_2)
    vars_run_3 = ["item_0", "item_1"]
    var_3 = test_with_nested.run(vars_run_3)
    vars_run_4 = []
    var_4 = test_with_nested.run(vars_run_4)
    vars_

# Generated at 2022-06-25 10:58:11.847031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == []


    var_0 = [
        ['bar,bar2,bar3'],
        ['foo', 'baz'],
    ]
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)

    assert var_1 == [
        ['foo', 'bar,bar2,bar3'],
        ['baz', 'bar,bar2,bar3'],
    ]


# Check if the file was executed directly
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 10:58:17.485515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_12 = LookupModule()
    var_2 = []
    var_3 = lookup_run(var_2)
    # looking for `assert_equal(expected, actual)`
    # assert_equal(var_4, var_3)



# Generated at 2022-06-25 10:58:19.405147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 == []


# Generated at 2022-06-25 10:58:27.481072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ["*"]

# Generated at 2022-06-25 10:58:36.114790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    import pytest
    var_0 = []
    try:
        lookup_run(var_0)
    except AnsibleError as e:
        if "with_nested" in e.message:
            pass
        else:
            raise AssertionError("Exception message does not match the expected value")
    except Exception as e:
        raise AssertionError("Other exception raised: " + str(e))
    except:
        raise AssertionError("Other exception raised")


# Generated at 2022-06-25 10:58:40.522789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['foo']
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == [['foo']]



# Generated at 2022-06-25 10:58:41.535338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 10:58:48.831756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = []
    var_1 = lookup_module.run(var_0)

    assert isinstance(var_1, list), "Expected a list"
    assert len(var_1) == 0, "Expected 0 items got %d" % len(var_1)


# Generated at 2022-06-25 10:58:50.559268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 == var_0


# Generated at 2022-06-25 10:58:52.099522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = []
    var_3 = lookup_module_1.run(var_2)


# Generated at 2022-06-25 10:58:53.976605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = []
    var_1.append(var_0)
    var_2 = lookup_run(var_1)


# Generated at 2022-06-25 10:58:55.127386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 10:58:56.451783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = LookupModule()
    assert var_1.run(var_0) == []


# Generated at 2022-06-25 10:59:02.063659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        [
            {
                'value': 'ansible_ssh_host',
                'key': 'ansible_ssh_host'
            },
            {
                'value': 'ansible_ssh_port',
                'key': 'ansible_ssh_port'
            }
        ],
        [
            'ansible_ssh_host',
            'ansible_ssh_port'
        ]
    ]
    var_1 = lookup_module_0._lookup_variables(var_0, {})
    var_2 = []
    var_3 = lookup_module_0.run(var_1, var_2)

# Generated at 2022-06-25 10:59:03.849428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 == var_0


# Generated at 2022-06-25 10:59:09.529123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_3 = []
    var_4 = []
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)
    var_4.append(var_3)

# Generated at 2022-06-25 10:59:13.989538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        [
            "foo"
            "bar"
        ],
        [
            "foo2"
            "bar2"
        ]
    ]
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)
    if var_2 != (
                [
                    "foo"
                    "bar"
                    "foo2"
                    "bar2"
                ]
    ):
        raise AssertionError()

    var_3 = []
    var_4 = lookup_run(var_3)
    if var_4 != (
            (
                [],
            )
    ):
        raise AssertionError()


# Generated at 2022-06-25 10:59:17.705676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["foo"], ["bar"]]
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 10:59:27.084197
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with undefined values for the 'terms' parameter
    var_0 = None
    var_1 = None
    with pytest.raises(AnsibleUndefinedVariable):
        var_1 = LookupModule().run(var_0)

    # Test with undefined values for the 'terms[0]' parameter
    var_0 = [None]
    var_1 = None
    with pytest.raises(AnsibleUndefinedVariable):
        var_1 = LookupModule().run(var_0)

    # Test with undefined values for the 'terms[1]' parameter
    var_0 = [["a","b"], None]
    var_1 = None
    with pytest.raises(AnsibleUndefinedVariable):
        var_1 = LookupModule().run(var_0)

    # Test with undefined values for the '

# Generated at 2022-06-25 10:59:31.556652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [('a', 'b'), ('a', 'c'), ('d', 'b'), ('d', 'c')]
    var_1 = LookupModule()
    var_2 = var_1.run(var_0, loader=None, templar=None)
    assert var_2 == [('a', 'b'), ('a', 'c'), ('d', 'b'), ('d', 'c')]

# Generated at 2022-06-25 10:59:37.725693
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = ['foo', 'bar']
    var_1 = []
    var_2 = lookup_module_0.run(var_0, var_1)
    assert var_2 == []

    lookup_module_1 = LookupModule()
    var_3 = ['foo', 'bar']
    var_4 = ['baz', 'quux']
    var_5 = lookup_module_1.run(var_3, var_4)
    assert var_5 == ['foobaz', 'foobaz']

    lookup_module_2 = LookupModule()
    var_6 = ['foo', 'bar']
    var_7 = ['baz', 'quux']
    var_8 = lookup_module_2.run(var_6, var_7)
   

# Generated at 2022-06-25 10:59:43.437794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = Mock()
    lookup_module_0._loader = Mock()
    var_0 = 0
    var_1 = lookup_run(var_0)
    assert var_1 == 'Variable "var_0" is undefined.'


# Generated at 2022-06-25 10:59:53.172416
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:00:01.740808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = []
    var_2 = []
    var_2.append('foo')
    var_2.append('bar')
    var_2.append('baz')
    var_1.append(var_2)
    var_2 = []
    var_2.append('a')
    var_2.append('b')
    var_2.append('c')
    var_1.append(var_2)
    var_2 = []
    var_2.append('x')
    var_2.append('y')
    var_2.append('z')
    var_1.append(var_2)
    var_0 = lookup_run(var_1)

# Generated at 2022-06-25 11:00:06.780632
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with no parameters

    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)



# Generated at 2022-06-25 11:00:08.223727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = []
    var_1 = lookup_run(var)

# Generated at 2022-06-25 11:00:14.703375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert len(var_1) == 1


# Generated at 2022-06-25 11:00:22.351547
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:00:23.674537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:00:26.437757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [['foo'], ['bar', 'baz']]
    var_1 = lookup_run(var_0)
    assert var_1 == [['foo', 'bar'], ['foo', 'baz']]

# Generated at 2022-06-25 11:00:29.544115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:00:31.605939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)


# Test with a minimum of two elements in nested list

# Generated at 2022-06-25 11:00:42.492519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize test
    lookup_module_class = LookupModule()
    # Test with empty list
    var_0 = []
    lookup_module_class.run(var_0)
    # Test with single list
    var_1 = ["a", "b"]
    lookup_module_class.run(var_1)
    # Test with multiple lists
    var_2 = [["a", "b"], ["c", "d"]]
    lookup_module_class.run(var_2)
    # Test with multiple lists with multiple elements
    var_3 = [["a", "b", "c"], ["c", "d"]]
    lookup_module_class.run(var_3)
    # Test with multiple lists with multiple elements

# Generated at 2022-06-25 11:00:45.662753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)
    assert var_1 is None


# Generated at 2022-06-25 11:00:48.407105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup_module = lookup
    terms = []
    variables = {}
    kwargs = {}
    var_1 = lookup_module.run(terms, variables, **kwargs)

# Method _lookup_variables of class LookupModule

# Generated at 2022-06-25 11:00:51.194170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    if not  var_1:
        raise Exception('Incorrect return value from LookupModule.run')


# Generated at 2022-06-25 11:00:55.624772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module_0._flatten = MagicMock(side_effect=test_flatten)
    lookup_module_1 = lookup_module_0._combine([[('alice', 'clientdb'), ('alice', 'employeedb'), ('alice', 'providerdb')], [('bob', 'clientdb'), ('bob', 'employeedb'), ('bob', 'providerdb')]], [['alice', 'bob']])
    assert lookup_module_0._flatten == lookup_module_1


# Generated at 2022-06-25 11:01:00.699072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:01:06.379361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 == []

# Generated at 2022-06-25 11:01:08.807931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert type(var_1) is list


# Generated at 2022-06-25 11:01:17.613769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        [
            'alice',
            'bob',
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb',
        ],
    ]
    var_1 = {
        'ansible_check_mode': False,
        'ansible_host': '127.0.0.1',
        'ansible_inventory_hostname': 'ansible_host',
        'ansible_playbook_python': '/usr/bin/python3',
        'ansible_verbosity': 0,
    }
    var_2 = lookup_run(var_0, var_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:01:19.150712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    with pytest.raises(AnsibleError):
        var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:01:21.471229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 11:01:23.610774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['clientdb', 'employeedb', 'providerdb']
    var_1 = lookup_run(var_0)



# Generated at 2022-06-25 11:01:33.469734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        [
            [
                'a',
                'b'
            ],
            [
                '1',
                '2'
            ],
            [
                'I',
                'II'
            ]
        ]
    ]

# Generated at 2022-06-25 11:01:35.254495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 11:01:36.972952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = []
    var_3 = lookup_run(var_2)



# Generated at 2022-06-25 11:01:42.501664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = []
  var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:01:45.965916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 is not None


# Generated at 2022-06-25 11:01:49.811151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert var_1 == []

# Generated at 2022-06-25 11:02:00.436338
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:02:03.603907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True
# TODO: Implement test_LookupModule_run


# Generated at 2022-06-25 11:02:07.540698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["foo"], ["bar"]]
    var_1 = [["foo"], ["bar"]]
    var_2 = lookup_run(var_1)
    var_0.sort()
    var_2.sort()
    assert var_0 == var_2


# Generated at 2022-06-25 11:02:11.780540
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize the class
    lookup_module_0 = LookupModule()

    # Initialize the variable
    var_0 = []

    # Call the method
    lookup_run_0 = lookup_module_0.run(var_0)



# Generated at 2022-06-25 11:02:20.093147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = []
    var_3 = []
    var_4 = []
    var_3.append(var_4)
    var_2.append(var_3)
    var_3 = []
    var_4 = []
    var_5 = None
    var_4.append(var_5)
    var_5 = None
    var_4.append(var_5)
    var_5 = None
    var_4.append(var_5)
    var_3.append(var_4)
    var_2.append(var_3)
    var_1 = lookup_run(var_2)


# Generated at 2022-06-25 11:02:26.264284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Tests:
    # ['a']
    # [['a']]
    # [['a'], ['b']]
    # [['a', 'b'], ['c']]

    var_0 = lookup_module_0.run(terms=['a'])
    assert var_0 == ['a']

    var_0 = lookup_module_0.run(terms=['a'])
    assert var_0 == ['a']

    var_0 = lookup_module_0.run(terms=['a'])
    assert var_0 == ['a']

    var_0 = lookup_module_0.run(terms=['a'])
    assert var_0 == ['a']

# Generated at 2022-06-25 11:02:35.046081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = get_attr_value(var_0, "run", "")
    var_2 = None
    var_3 = lookup_run(var_2)
    var_3 = append(var_3, var_0)
    var_3 = append(var_3, var_1)
    var_3 = append(var_3, var_0)
    var_3 = append(var_3, var_1)
    var_3 = get_attr_value(var_3, "run", "", "values")
    var_4 = get_attr_value(var_3, "type", "")
    var_4 = append(var_4, var_3)
    var_4 = get_attr_value(var_4, "__call__", "")
    var

# Generated at 2022-06-25 11:02:43.228280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0._lookup_variables(var_0, None)
    assert var_1 is None
    var_1 = lookup_module_0.run(var_0, None)
    assert var_1 is None

# Generated at 2022-06-25 11:02:49.268924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert expected_0 == var_1
    var_2 = lookup_run(var_1)
    assert expected_1 == var_2
    var_3 = lookup_run(var_2)
    assert expected_2 == var_3

# Generated at 2022-06-25 11:02:50.403556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    # Case 0
    test_case_0()


# Generated at 2022-06-25 11:02:55.020884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = []
    var_3 = lookup_run(var_2)


# Generated at 2022-06-25 11:02:57.864127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    assert len(var_1) == 0



# Generated at 2022-06-25 11:03:06.003010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_1 = [
        {
            'id': '1',
            'vars': {
                'name': 'test1',
            },
        },
        {
            'id': '2',
            'vars': {
                'name': 'test2',
            },
        },
    ]
    var_2 = [
        '%(id)s-%(name)s',
        '%(id)s-%(name)s',
    ]
    var_3 = lookup_run(var_1, var_2)

    assert var_3 == [
        [
            '1-test1',
            '2-test2',
        ],
        [
            '1-test1',
            '2-test2',
        ],
    ]

# Generated at 2022-06-25 11:03:09.520784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)
    if var_1 in [{"_list": ["a", "b"]}, [["a"], ["b"]]]:
        var_2 = True
    else:
        var_2 = False
    assert var_2


# Generated at 2022-06-25 11:03:12.171598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_calls()
    var_2 = lookup_run(var_0)
    assert var_2 == ([] if var_1 is None else var_1)


# Generated at 2022-06-25 11:03:19.287993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    terms_0 = lookup_module_0._combine()

    # Invocation
    var_0 = lookup_module_0.run(terms_0)

    # Check for the failure
    assert var_0 == []

    # Teardown
    del lookup_module_0



# Generated at 2022-06-25 11:03:22.796286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)
    # Test case for undefined variables
    lookup_module_1 = LookupModule()
    var_2 = [
        [
            'foo', 'foo'
        ]
    ]
    var_3 = lookup_module_1.run(var_2)


# Generated at 2022-06-25 11:03:28.363073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_run(var_0)


# Generated at 2022-06-25 11:03:34.967559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = ['[ a, b, c]', '[ 1, 2]']
    var_1 = lookup_module.run(var)
    assert var_1 == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2'], ['c', '1'], ['c', '2']], "Testing result of run method of LookupModule when list size is same"
