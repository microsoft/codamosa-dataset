

# Generated at 2022-06-25 10:53:39.893324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    kwargs_0 = {}
    kwargs_1 = {}
    lookup_module_0._templar = kwargs_1
    terms_0 = []
    terms_1 = []
    terms_0.append(terms_1)
    terms_2 = []
    terms_2.append("users")
    terms_0.append(terms_2)
    variables = {}
    variables['users'] = []
    variables['users'].append("alice")
    variables['users'].append("bob")
    variables['users'].append("joe")
    variables['users'].append("jim")
    variables['clientdb'] = 'clientdb'
    variables['employeedb'] = 'employeedb'

# Generated at 2022-06-25 10:53:49.815825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input params
    terms = [[['a', 'b'], ['A', 'B'], ['1', '2']], [['a', 'b'], ['A', 'B'], ['1', '2']]]

    # Output params

# Generated at 2022-06-25 10:53:53.467391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    my_lookup_module_run_method = lookup_module.run
    my_lookup_module_run_method(terms=[['test1', 'test2', 'test3'], ['a', 'b', 'c']],
                                variables={})


# Generated at 2022-06-25 10:53:55.748158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['term1', 'term2']
    result = lookup_module.run(terms, {})
    assert(type(result) == type([]))

# Generated at 2022-06-25 10:53:58.345773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = []
    lookup_module_run_output = LookupModule().run(terms, variables)
    assert lookup_module_run_output == []


# Generated at 2022-06-25 10:54:02.998573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()
    test_terms_0 = "{{lookup_nested_list}}"
    test_variables_0 = {}
    result_0 = lookup_module_0.run(["{{lookup_nested_list}}"], {})
    assert result_0[0] == ['a', 'b', 'c', 'd', 'e', 'f', 'g']



# Generated at 2022-06-25 10:54:10.625543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ok
    args_0 = {
        'terms': [{
            '_raw': [
                "{{ foo }}",
                "{{ bar }}"
            ]
        }],
        'variables': {
            'bar': "qux",
            'foo': "quux"
        }
    }
    kwargs_0 = {}
    expected_0 = [
        [
            'quux',
            'qux'
        ]
    ]
    returned_0 = LookupModule().run(**args_0)
    assert returned_0 == expected_0

    # ok

# Generated at 2022-06-25 10:54:16.428659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    terms = ['a', 'b', 'c']
    variables = None
    assert lookup_module_0.run(terms, variables) == [['a', 'b', 'c']]


# Generated at 2022-06-25 10:54:20.444676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["foo", "bar"], {'item': 'foo', 'bar': 'foo'}) == ['foo', 'bar']


# Generated at 2022-06-25 10:54:26.125010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    input_var_1 = 'foo'
    result_1 = lookup_module_1.run(input_var_1)
    assert result_1 == ['foo']


# Generated at 2022-06-25 10:54:31.929495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([[[['a', 'b'], ['c', 'd']], ['e', 'f']]]) == [['a', 'b', 'e'], ['a', 'b', 'f'], ['c', 'd', 'e'], ['c', 'd', 'f']]


# Generated at 2022-06-25 10:54:36.619107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    new_result = lookup_module_0.run([['localhost', 'otherhost'], ['a', 'b'], ['1', '2']])
    assert new_result == [['localhost', 'a', '1'], ['localhost', 'b', '1'], ['otherhost', 'a', '2'], ['otherhost', 'b', '2']]

# Generated at 2022-06-25 10:54:47.330233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = {}

    #
    # !!!!! ATTENTION !!!!!
    # ALL THE VARIABLES ARE OVERRIDDEN BY MOCKED VARIABLES
    #
    # mock input variables here
    # /home/ansible/ansible/hacking/test-module -m /home/ansible/ansible/lib/ansible/modules/net_tools/basics/nxos_static_routes.py -a '{"provider": {"password": "TRUE", "username": "TRUE", "host": "TRUE", "transport": "TRUE", "vendor": "TRUE", "authorize": "TRUE", "ssh_keyfile": "TRUE"}}'
    # /home/ansible/ansible/hacking/test-module -m /home/ansible/ansible/

# Generated at 2022-06-25 10:54:51.545695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  args = (
    ([['a', 'b'], [1, 2]], None),
    {},
  )
  kwargs = {}
  expected_result = [['a', 1], ['a', 2], ['b', 1], ['b', 2]]
  actual_result = lookup.run(*args, **kwargs)
  assert expected_result == actual_result


# Generated at 2022-06-25 10:54:58.424868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({'_raw': 'test_value_1'})
    assert lookup_module_1.run([]) == []
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options({'_raw': 'test_value_2'})
    assert lookup_module_2.run([]) == []
    lookup_module_3 = LookupModule()
    lookup_module_3.set_options({'_raw': 'test_value_3'})
    assert lookup_module_3.run([]) == []
    lookup_module_4 = LookupModule()
    lookup_module_4.set_options({'_raw': 'test_value_4'})
    assert lookup_module_4.run([]) == []

# Generated at 2022-06-25 10:55:09.014181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [['a']]
    variables_1 = {}
    results = lookup_module_1.run(terms_1, variables_1)
    assert results == [['a']]

    lookup_module_2 = LookupModule()
    terms_2 = [['a', 'b', 'c'], ['1', '2', '3', '4']]
    variables_2 = {}
    results = lookup_module_2.run(terms_2, variables_2)

# Generated at 2022-06-25 10:55:19.540607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Arguments
    # terms =
    # variables =
    # kwargs =
    # Returns
    new_result = []
    # begin-snippet: run
    terms = [
            [['a','b','c'],['d','e','f'],['g','h','i']],
            [[1],[2],[3],[4]]
        ]
    result = lookup_module_1.run(terms, variables=None, **kwargs)
    # end-snippet
    # expected_result =
    for x in result:
        new_result.append(lookup_module_1._flatten(x))

# Generated at 2022-06-25 10:55:26.316186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup_module_0 = LookupModule()
    terms = []
    variables = {}

    # Act
    result_0 = lookup_module_0.run(terms, variables)

    # Assert
    assert result_0 == [], 'result_0 is {}'.format(result_0)



# Generated at 2022-06-25 10:55:30.949281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x = [['foo', 'bar'], ['baz', 'test']]
    print(lookup_module_0.run(x, None))


# Generated at 2022-06-25 10:55:40.678504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [['alice'], ['bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module = LookupModule()
    result = lookup_module.run(my_list)
    assert (result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']])
    my_list = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    result = lookup_module.run(my_list)

# Generated at 2022-06-25 10:55:48.394936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    expected = [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    with_nested = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    observed = lookup_module_0.run(with_nested, variables=None)
    assert expected == observed

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:55:52.803041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given:
    lookup_module_1 = LookupModule()
    terms_1 = ['a', 'b', 'c']
    # When:
    result_1 = lookup_module_1.run(terms_1)
    # Then:
    expected_1 = [['a', 'b', 'c']]
    assert result_1 == expected_1


# Generated at 2022-06-25 10:55:54.343502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([""],[])
    assert result == []


# Generated at 2022-06-25 10:56:03.048459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = []
    terms = my_list
    variables = None
    kwargs = {}
    # Test a corner case where result would be an empty list
    assert lookup_module_0.run(terms, variables, **kwargs) == []
    # Test normal list
    my_list = ["A", "B", "C"]
    terms = my_list
    # Test a corner case where result would be a list of one list
    assert lookup_module_0.run(terms, variables, **kwargs) == [["A", "B", "C"]]


# Generated at 2022-06-25 10:56:05.001843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run("terms", "variables")
    assert isinstance(result, list)


# Generated at 2022-06-25 10:56:10.110261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    assert lookup_module_0.run(terms_0)
    assert lookup_module_0.run(terms_0) == [['alice', 'clientdb'], ['alice',
        'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob',
        'employeedb'], ['bob', 'providerdb']]

# Generated at 2022-06-25 10:56:18.223637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {'_raw': [['alice', 'bob'],
        ['clientdb', 'employeedb', 'providerdb']], 'terms': ['alice', 'bob', 'clientdb', 'employeedb', 'providerdb']}
    lookup_module_run_ret = None
    try:
        lookup_module_run_ret = LookupModule('', {})
    except AnsibleUndefinedVariable as e:
        lookup_module_run_ret = e

    assert lookup_module_run_ret.msg or lookup_module_run_ret.terms


# Generated at 2022-06-25 10:56:23.171602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = [1,2,3]
    my_list_1 = [4,5,6]
    ret = lookup_module_0._combine(my_list_0, my_list_1)
    assert(ret == [[1,4],[1,5],[1,6],[2,4],[2,5],[2,6],[3,4],[3,5],[3,6]])


# Generated at 2022-06-25 10:56:28.815125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms = [['a', 'b'], ['x', 'y', 'z']]
    result = lookup_module_1.run(terms)
    assert result == [['a', 'x'], ['a', 'y'], ['a', 'z'], ['b', 'x'], ['b', 'y'], ['b', 'z']]


# Generated at 2022-06-25 10:56:37.849692
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test with a set of terms defined as variables:
    terms = ['tuples_0', 'tuples_1']
    nested_vars = {
        'tuples_0': [
            'item_00',
            'item_01',
            'item_02'
        ],
        'tuples_1': [
            'item_10',
            'item_11',
            'item_12'
        ]
    }


# Generated at 2022-06-25 10:56:47.106300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_obj = LookupModule()
  terms_test = [
    [
      'a',
      'b'
    ],
    [
      'c',
      'd'
    ]
  ]
  variables_test = {}
  result = lookup_module_obj.run(terms_test,variables_test)
  assert result == [
    [
      'a',
      'c'
    ],
    [
      'a',
      'd'
    ],
    [
      'b',
      'c'
    ],
    [
      'b',
      'd'
    ]
  ]
  return

# Generated at 2022-06-25 10:56:52.949829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    argument_0 = [0, 1, 2, 3, 'a', 'b', 'c', 'd']
    argument_1 = None
    argument_2 = None
    return_value = lookup_module_0.run(argument_0, argument_1, argument_2)
    assert return_value == [0, 1, 2, 'a', 3, 'b', 'c', 'd']


# Generated at 2022-06-25 10:56:57.798676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['foo', 'bar'], ['one', 'two']]
    variables = None
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(terms, variables)
    assert [(['one', 'foo'],), (['one', 'bar'],), (['two', 'foo'],), (['two', 'bar'],)] == result_1


# Generated at 2022-06-25 10:56:59.936346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    res = LookupModule.run([[1,2,3], [4,5,6], [7,8,9]])
    raise Exception("Unsupported")


# Generated at 2022-06-25 10:57:01.757765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._lookup_variables(terms="INPUT", variables="variables")


# Generated at 2022-06-25 10:57:06.822515
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    data = [{u'_raw': [u'foo', u'bar']}]
    data_copy = copy.deepcopy(data)
    terms_0 = [u'foo', u'bar']

    # data is modified by shallow copy
    lookup_module_0 = LookupModule()

    return_value_0 = lookup_module_0.run(terms_0, data)

    assert return_value_0[0] == [u'foo', u'bar']

# Generated at 2022-06-25 10:57:16.989112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   input_vars = { "a": 1, "b": 2, "c": 3, "A": 2, "B": 3, "C": 1 }
   lookup_options = { 'terms': [ "['A','B','C']", "['a','b','c']" ] }
   expected = [ [ 'A', 'a' ], [ 'A', 'b' ], [ 'A', 'c' ], [ 'B', 'a' ], [ 'B', 'b' ], [ 'B', 'c' ], [ 'C', 'a' ], [ 'C', 'b' ], [ 'C', 'c' ]]
   assert expected == lookup_module_0.run(terms=lookup_options['terms'], variables=input_vars, **lookup_options)


test_Look

# Generated at 2022-06-25 10:57:18.594226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([], {}) == []



# Generated at 2022-06-25 10:57:26.890872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([['a', 'b', 'c'], [1, 2, 3, 4]], [])
    assert result == [['a', 1], ['b', 1], ['c', 1], ['a', 2], ['b', 2], ['c', 2], ['a', 3], ['b', 3], ['c', 3], ['a', 4], ['b', 4], ['c', 4]]
    result = lookup_module_0.run(['a', 'b', 'c'], [])
    assert result == ['a', 'b', 'c']
    result = lookup_module_0.run([], [])
    assert result == []

# Generated at 2022-06-25 10:57:37.757694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_plugin_options = dict()
    test_lookup_plugin_options['_raw'] = []
    test_terms = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    test_variables = dict()
    test_module_name = 'nested'
    test_module_args = dict()
    test_tmp_path = ''
    try:
        LookupModule.run(LookupModule(), test_terms, test_variables, **test_lookup_plugin_options)
    except Exception as exception:
        if isinstance(exception, AnsibleUndefinedVariable):
            pass
        else:
            raise

# Generated at 2022-06-25 10:57:40.928944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert [] == lookup_module_0.run([[]], {})

# Generated at 2022-06-25 10:57:46.820530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list = [
        [1, 2, 3],
        [4, 5, 6, 7]]
    # Call method run with parameters:
    # my_list = [
    #     [1, 2, 3],
    #     [4, 5, 6, 7]]
    assert lookup_module_0.run(my_list) == [
        [1, 4],
        [1, 5],
        [1, 6],
        [1, 7],
        [2, 4],
        [2, 5],
        [2, 6],
        [2, 7],
        [3, 4],
        [3, 5],
        [3, 6],
        [3, 7]]


# Generated at 2022-06-25 10:57:57.095213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    def test_case_1(lookup_module_1):
        test__loader_1 = None
        def test__templar_1(x, **kwargs):
            assert isinstance(x, str)
            return u'bar' if isinstance(x, str) else x
        lookup_module_1._loader = test__loader_1
        lookup_module_1._templar = test__templar_1
        lookup_module_1._announce_deprecations(dict())
        assert lookup_module_1.run([['foo', 'bar']]) == [['foo', 'bar']]

# Generated at 2022-06-25 10:57:58.874113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    params_0 = []
    assert lookup_module_1.run(params_0, []) == []


# Generated at 2022-06-25 10:58:02.330701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["{{ e }}"]
    variables_0 = None
    try:
        result_0 = lookup_module_0.run(terms_0, variables_0)
    except AnsibleUndefinedVariable as e:
        print(e)
    assert result_0 == [["e"]]


# Generated at 2022-06-25 10:58:11.517507
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup the Mocking
    lookup_module_0 = LookupModule()

    # Set the expected result
    expected_result = [
        [u'alice', u'clientdb'],
        [u'alice', u'employeedb'],
        [u'alice', u'providerdb'],
        [u'bob', u'clientdb'],
        [u'bob', u'employeedb'],
        [u'bob', u'providerdb']
    ]

    # Call the function to test
    actual_result = lookup_module_0.run(
        ["['alice', 'bob']", "['clientdb', 'employeedb', 'providerdb']"]
    )

    # Assert the result
    assert actual_result == expected_result

# Generated at 2022-06-25 10:58:21.884489
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # yaml input
    terms_0 = [
                  [
                    'alice',
                    'bob'
                  ],
                  [
                    'clientdb',
                    'employeedb',
                    'providerdb'
                  ]
               ]

    variables_0 = {}

    # Run the method run of class LookupModule with arguments terms_0 and variables_0
    result = lookup_module_0.run(terms_0, variables_0)

    # Tests the result
    assert(['alice', 'clientdb'] in result)
    assert(['alice', 'employeedb'] in result)
    assert(['alice', 'providerdb'] in result)
    assert(['bob', 'clientdb'] in result)

# Generated at 2022-06-25 10:58:31.528277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb']]
    ret = lookup_module_0.run(terms_0, None)
    assert ret == [[u'alice', u'clientdb'], [u'bob', u'clientdb'], [u'alice', u'employeedb'], [u'bob', u'employeedb'], [u'alice', u'providerdb'], [u'bob', u'providerdb']]


# Generated at 2022-06-25 10:58:34.511477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    result = lookup_module_0.run(terms_0)
    assert result == []

# Generated at 2022-06-25 10:58:42.908897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_item_0 = [['a', 'b'], ['c', 'd']]
    my_item_1 = None
    lookup_module_1 = LookupModule()
    my_result_1 = lookup_module_1.run(my_item_0, my_item_1)
    assert my_result_1 == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]
    my_item_2 = [1, 2, 3]
    lookup_module_2 = LookupModule()
    my_result_2 = lookup_module_2.run(my_item_2, my_item_1)
    assert my_result_2 == [[1], [2], [3]]



# Generated at 2022-06-25 10:58:48.448656
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initiating object
    lookup_module_obj = LookupModule()

    # Calling run method
    lookup_module_obj.run(terms=['[\'2017-08-31\', \'2018-09-30\']', '[100, 101]'])

# Generated at 2022-06-25 10:58:50.390831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([['test_value_1', 'test_value_2']]) == [['test_value_1', 'test_value_2']]


# Generated at 2022-06-25 10:58:52.984097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    expected = [['a1', 'b1'], ['a1', 'b2'], ['a2', 'b1'], ['a2', 'b2']]
    actual = lookup_module_0.run([['a1', 'a2'], ['b1', 'b2']])
    assert actual == expected


# Generated at 2022-06-25 10:58:58.793509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule().run(["foo", "bar", "baz"], [1,2,3]), list)
    assert LookupModule().run(["foo", "bar", "baz"], [1,2,3]) == [['foo', 1], ['bar', 1], ['baz', 1], ['foo', 2], ['bar', 2], ['baz', 2], ['foo', 3], ['bar', 3], ['baz', 3]]

# Generated at 2022-06-25 10:59:02.900917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    x_0 = [
        [
            '{"i" : ["1", "2", "3"]}'
        ],
        [
            '{ "j" : ["6", "7", "8"]}'
        ]
    ]
    x_0_0 = lookup_module_0.run(terms=x_0)


# Generated at 2022-06-25 10:59:08.829082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tst setup
    lookup_module = LookupModule()

    list_of_terms = []
    list_of_terms.append([[1, 2], [3, 4], [5, 6]])
    list_of_terms.append([[7, 8], [9, 10], [11, 12]])

    # Test execution
    result = lookup_module.run(list_of_terms)

    # Test Postcondtions
    assert result[0] == [1, 2, 7, 8]
    assert result[1] == [1, 2, 9, 10]
    assert result[2] == [1, 2, 11, 12]
    assert result[3] == [3, 4, 7, 8]
    assert result[4] == [3, 4, 9, 10]

# Generated at 2022-06-25 10:59:12.912923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [["a", "b", "c"], [1, 2, 3]]
    terms_result = [["a", "b", "c"], [1, 2, 3]]
    variables = None
    variables_result = None
    kwargs = {}
    kwargs_result = {}
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert (result == [['a', 'b', 'c', 1], ['a', 'b', 'c', 2], ['a', 'b', 'c', 3], ['b', 'c', 1, 2], ['b', 'c', 1, 3], ['b', 'c', 2, 3], ['c', 1, 2, 3]])
    assert (terms == terms_result)

# Generated at 2022-06-25 10:59:20.428252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        terms=[
            ['foo', 'bar', 'baz'],
            ['a', 'b', 'c'],
            ['a', 'b', 'c']
        ],
        variables=None,
        **{}
    )

    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(**args)


# Generated at 2022-06-25 10:59:22.994646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
# TODO: remove the try/except and capture the AnsibleError:
    try:
        lookup_module_0.run([])
    except AnsibleError:
        pass


# Generated at 2022-06-25 10:59:28.263595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['', '', ''])
    assert result == [[], [], []]


# Generated at 2022-06-25 10:59:34.204682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run([])
# if the assert fails, the test has failed.
    assert True



# Generated at 2022-06-25 10:59:41.415569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
# all items are list, if only one element, test it seperately
    assert lookup_module_0._combine([1,2],['a','b']) == [[1,'a'],[1,'b'],[2,'a'],[2,'b']]
    assert lookup_module_0._combine([1,2],['a']) == [[1, 'a'], [2, 'a']]
    assert lookup_module_0._combine([1],['a','b']) == [[1,'a'],[1,'b']]

# Generated at 2022-06-25 10:59:45.815316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_01 = LookupModule()
    assert isinstance(lookup_module_01, LookupModule)
    ansible_mod_builtins = {
        'foo': 'bar',
        'a': 'b',
        'o': 'k',
        'd': 'f',
        'l': 'm',
        'deeply': {'nested': 'var'},
        'list': ['val1', 'val2'],
        'complex': [(1, 2), {'foo': 'bar'}],
        'null': None
    }
    lookup_module_01_result = lookup_module_01.run([ ['foo', 'bar', 'foobar'], [ 'a', 'b', 'c'], [ 'o', 'k', 'l'] ], ansible_mod_builtins)
    assert lookup

# Generated at 2022-06-25 10:59:53.303678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(None, _connection=None, **{'_ansible_check_mode': 'True'})
    except AnsibleError as ae:
        pass

    try:
        lookup_module_1.run(['foo'], _connection=None, **{'_ansible_check_mode': 'True'})
    except AnsibleError as ae:
        pass

    try:
        lookup_module_1.run([['foo'], ['bar']], _connection=None, **{'_ansible_check_mode': 'True'})
    except AnsibleError as ae:
        pass

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:59:55.188652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No idea how to test this code path...
    pass

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 11:00:01.166376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = list()
    terms_0.append(['1', '2'])
    terms_0.append(['A', 'B'])
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms_0)
    assert result[0] == {'1', 'A'}
    assert result[1] == {'1', 'B'}
    assert result[2] == {'2', 'A'}
    assert result[3] == {'2', 'B'}

# Generated at 2022-06-25 11:00:06.667848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:00:10.973730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = [1, 2, 3]
    b = [1, 2, 3]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([a, b])
    assert result == [[1, 1], [1, 2], [1, 3], [2, 1], [2, 2], [2, 3], [3, 1], [3, 2], [3, 3]]


# Generated at 2022-06-25 11:00:12.973722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x_0 = []
    y_0 = 'lookup_plugin.run'
    lookup_module_0 = LookupModule()
    z_0 = lookup_module_0.run(x_0, y_0)
    return (z_0)


# Generated at 2022-06-25 11:00:17.932058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([ ['a'], ['b'] ]) == [ ['a', 'b'] ]

# Generated at 2022-06-25 11:00:22.153991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [ 5, 6, 7 ]
    list_1 = [ 1, 2, 3 ]
    list_2 = [ 4, 8, 9 ]
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_2)
    lookup_module_0.run(list_0, list_1)

# Generated at 2022-06-25 11:00:24.100502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        LookupModule().run()
    except Exception as e:
        assert(type(e) == TypeError)
        assert(str(e) == "run() missing 1 required positional argument: 'terms'")


# Generated at 2022-06-25 11:00:26.299406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0)
    list_1 = []
    lookup_module_0.run(list_1)

# Generated at 2022-06-25 11:00:30.541936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    test_var_0 = [{},{}]
    var_1 = [{},{}]
    assert var_0 == var_1


# Generated at 2022-06-25 11:00:31.900650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    assert False


# Generated at 2022-06-25 11:00:36.154322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(list_0) == None
    assert lookup_module_0.run(list_0) == None
    assert lookup_module_0.run(list_0) == None


# Generated at 2022-06-25 11:00:40.660391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []

    lookup_instance_0 = LookupModule()
    try:
        result_0 = lookup_instance_0.run(list_0)
    except AnsibleError as error_0:
        raise error_0


# Generated at 2022-06-25 11:00:49.124777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    lookup_run_0 = lookup_module_0.run(list_0)
    assert lookup_run_0 == [], "Failed assert lookup_run_0 == []"
    list_1 = []
    lookup_module_1 = LookupModule()
    lookup_run_1 = lookup_module_1.run(list_1)
    assert lookup_run_1 == [], "Failed assert lookup_run_1 == []"
    list_2 = []
    lookup_module_2 = LookupModule()
    lookup_run_2 = lookup_module_2.run(list_2)
    assert lookup_run_2 == [], "Failed assert lookup_run_2 == []"
    list_3 = []
    lookup_module_3

# Generated at 2022-06-25 11:00:50.064862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:00:55.618835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['db1', 'db2', 'db3']
    dict_0 = {}
    dict_0['list_0'] = list_0
    list_1 = [{}]
    dict_0['list_1'] = list_1
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 11:00:59.856480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['9']
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 11:01:01.479122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run")
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0)
    return


# Generated at 2022-06-25 11:01:06.726209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
#

# Generated at 2022-06-25 11:01:13.712921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [["foo","bar"]]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    print("var_0: " + str(var_0))
    assert var_0 == [['foo'], ['bar']]


# Generated at 2022-06-25 11:01:15.837056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()

    try:
        lookup_module_0.run(list_0)

    except AnsibleError as e:
        pass



# Generated at 2022-06-25 11:01:23.775787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    host_name = 'host_name'
    var_0 = LookupModule()
    list_0 = []
    list_1 = []
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_1['inventory_hostname'] = host_name
    dict_2['inventory_hostname'] = host_name
    dict_3['inventory_hostname'] = host_name
    list_0.append(dict_1)
    list_0.append(dict_2)
    list_1.append(dict_3)
    assert (var_0.run(list_0, list_1, terms=[], variables=[]) == list_0)


unit_test()

main()

# Generated at 2022-06-25 11:01:28.904624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)


# Generated at 2022-06-25 11:01:38.171826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Store all provided input as list of lists
    list_0 = []
    terms_0 = list_0
    list_1 = [1, 2, 3]
    list_2 = ['a', 'b']
    list_3 = [[1.1, 1.2], [2.1, 2.2, 2.3], [3.1, 3.2, 3.3]]
    terms_1 = [list_1, list_2, list_3]
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(terms_0)
    assert var_0 == []
    var_1 = lookup_run(terms_1)

# Generated at 2022-06-25 11:01:45.469739
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:01:50.765045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.utils.unsafe_proxy import AnsibleUnsafeText

  fixture_0 = [ [ 'foo' ], [ 'bar' ] ]
  lookup_module_0 = LookupModule()
  var_1 = lookup_module_0.run(fixture_0, [], {},
    inject=None,
    templar=None,
    loader=None,
    wantlist=True
  )
  assert var_1 == [ ['foo','bar'] ], "Expected: %s, Actual: %s" % ('[[\'foo\',\'bar\']]', var_1)

   # Even though the actual name is "foo",
   # when we look it up in the variables dictionary,
   # it should not be escaped
  variables_0 = {}
  variables_0['foo'] = 'bar'

# Generated at 2022-06-25 11:01:55.919086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    var_0 = lookup_run(terms_0)


# Generated at 2022-06-25 11:02:03.231343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    this_terms = ['test_value_0', 'test_value_1']
    this_variables = {'test_value_0': 'test_value_2', 'test_value_3': 'test_value_4'}
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(this_terms, this_variables)
    assert result == ['test_value_2', 'test_value_3', 'test_value_0', 'test_value_1']

# Generated at 2022-06-25 11:02:12.882124
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:02:16.917000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    with pytest.raises(UndefinedError) as e_0:
        lookup_run(list_0)
    with pytest.raises(AnsibleUndefinedVariable) as e_1:
        lookup_run(list_0)

# Generated at 2022-06-25 11:02:18.883247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:02:25.835011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    obj_0 = lookup_module_0.run(list_0)
    if obj_0 is not None:
        raise AssertionError
    # test for object returned from run
    list_1 = [list_0]
    obj_1 = lookup_module_0.run(list_1)
    if obj_1 is None:
        raise AssertionError
    if obj_1 != [[]]:
        raise AssertionError
    list_2 = [list_0, list_0]
    obj_2 = lookup_module_0.run(list_2)
    if obj_2 is None:
        raise AssertionError
    if obj_2 != [[]]:
        raise AssertionError

# Generated at 2022-06-25 11:02:29.095192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    assert len(var_0) == 1
    assert var_0[0] == [u"foo"]



# Generated at 2022-06-25 11:02:31.991023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['a']
    lookup_module_0 = LookupModule()
    return lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:02:40.361044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    assert var_0 == None

    list_1 = []
    lookup_module_1 = LookupModule()
    try:
        var_1 = lookup_run(list_1)
        self.fail("AnsibleError not raised in run")
    except AnsibleError:
        pass

    list_2 = []
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(list_2)
    assert var_2 == None


# Generated at 2022-06-25 11:02:42.672906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['foo']
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    print(var_0)


# Generated at 2022-06-25 11:02:48.880454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    var_1 = lookup_module_2.run(terms=var_0, variables=var_0, kwargs=var_0)
    assert var_1 == var_0

if __name__ == '__main__':
    #test_case_0()
    test_case_1()

# Generated at 2022-06-25 11:02:57.975273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a mock object
    lookup_module_0 = LookupModule()
    list_0 = []
    # Call method run
    var_0 = getattr(lookup_module_0, 'run')(list_0)
    assert isinstance(var_0, list) is True
    assert var_0 == []
    list_0 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    # Call method run
    var_0 = getattr(lookup_module_0, 'run')(list_0)
    assert isinstance(var_0, list) is True

# Generated at 2022-06-25 11:03:05.525594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    terms = list_0

    my_list = terms[:]
    my_list.reverse()
    result = []
    if len(my_list) == 0:
        raise AnsibleError("with_nested requires at least one element in the nested list")
    result = my_list.pop()
    while len(my_list) > 0:
        result2 = self._combine(result, my_list.pop())
        result = result2
    new_result = []
    for x in result:
        new_result.append(self._flatten(x))
    return new_result

    assert True
    #assert isinstance(var_0, list)


# Generated at 2022-06-25 11:03:08.137172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    assert (var_0 == lookup_run(list_0))


# Generated at 2022-06-25 11:03:13.123624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [['alice'], ['bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == [('alice', 'clientdb'), ('bob', 'clientdb'), ('alice', 'employeedb'), ('bob', 'employeedb'), ('alice', 'providerdb'), ('bob', 'providerdb')]


# Generated at 2022-06-25 11:03:16.819395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['foo', 'bar']
    var_0 = lookup_module_0.run(term_0)


# Generated at 2022-06-25 11:03:24.041919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['item_0', 'item_1', 'item_2']
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    check_0_0 = ['item_0', 'item_1', 'item_2']
    check_0_1 = var_0[0]
    check_0_2 = len(check_0_1)
    check_0_3 = len(check_0_0)
    check_0_4 = len(var_0)
    assert_equal(check_0_2, check_0_3, (check_0_1, check_0_0))
    assert_equal(check_0_4, 1, var_0)
    list_1 = ['item_0', 'item_1']
    list_2

# Generated at 2022-06-25 11:03:30.487096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['clientdb', 'employeedb', 'providerdb']
    var_1 = ['alice', 'bob']
    var_2 = lookup_module_0.run(var_0, var_1)
    assert 'case 0' == var_2