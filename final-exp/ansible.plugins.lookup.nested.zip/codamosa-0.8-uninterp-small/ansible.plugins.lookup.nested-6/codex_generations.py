

# Generated at 2022-06-25 10:53:36.293191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = ["a", "b", "c"]
    list_1 = [list_0, list_0]
    list_2 = [list_1, list_1]
    result = lookup_module_0.run(list_2)
    assert len(result) == 36

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:53:45.563597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = []
    dict_1 = {}
    dict_1["terms"] = terms_0
    dict_1["variables"] = dict_0
    dict_2 = {}
    for key_0 in dict_1.keys():
        dict_2[key_0] = dict_1[key_0]
    dict_2["kwargs"] = dict_1
    with pytest.raises(AnsibleError):
        lookup_module_0.run(*(), **dict_2)
# Test function run
# Input:
#       terms: [ [ [ [ 'a' ] , [ 'b' ] , [ 'c' ] ] , [ [ '1' ] , [ '2' ] , [ '3' ] ]

# Generated at 2022-06-25 10:53:49.218753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = []
    variables_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **dict_0)


# Generated at 2022-06-25 10:53:57.213477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        '_templar': '_templar',
        '_loader': '_loader',
    }
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0._combine(list_1=[
        [
            'alice',
            'bob'
        ]
    ], list_0=[
        'clientdb',
        'employeedb',
        'providerdb'
    ])
    lookup_module_0._find_nested_elements(list_0=['alice', 'bob'])
    lookup_module_0._lookup_variables(terms='_terms', variables='_variables')
    lookup_module_0._flatten(list_0=['alice', 'bob'])

# Generated at 2022-06-25 10:54:08.489206
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:54:14.902413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = []
    dict_1 = {}
    list_1 = lookup_module_0.run(list_0, dict_1)
    assert len(list_1) == 0


# Generated at 2022-06-25 10:54:25.294788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No parameters
    lookup_module_0 = LookupModule()
    try:
        result_0 = lookup_module_0.run(["foo", "bar"], {})
        raise ValueError('Exception not thrown')
    except AnsibleError as exception_0:
        pass
    # No parameters
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run([["foo", "bar"], ["baz", "bar"], ["foo", "foo"]], {})
    assert result_1 == [["foo", "bar", "baz"], ["foo", "bar", "foo"]]


# Generated at 2022-06-25 10:54:31.014723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)

    # This statement will fail with a TypeError if the method run is not returning a list
    assert isinstance(lookup_module_0.run(**dict_0), list)

# Generated at 2022-06-25 10:54:36.072838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"terms": [[["x", "y", "z"], ["t", "u", "v"]]], "variables": {"hostvars": {}}, "loader": "",
              "templar": "", "variables": {}}
    lookup_module_0 = LookupModule(**dict_0)
    result = lookup_module_0.run('', **dict_0)
    assert result == []


# Generated at 2022-06-25 10:54:40.556608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'run_once': False}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = ['b', 'a']
    dict_1 = {}
    list_1 = [lookup_module_0.run(list_0, dict_1)]
    assert list_1 == [[['b'], ['a']]]

# Generated at 2022-06-25 10:54:50.888146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    dict_1 = {}
    dict_1['_list'] = []
    dict_1['_list'].append('joe1')
    dict_1['_list'].append('joe2')
    dict_1['_list'].append('joe3')
    dict_1['_list'].append('joe4')
    dict_1['_list'].append('joe5')
    dict_1['_list'].append('joe6')
    dict_1['_list'].append('joe7')
    dict_1['_list'].append('joe8')
    dict_2 = {}
    dict_2['_list'] = []

# Generated at 2022-06-25 10:54:57.830643
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:55:02.705163
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_2 = {}
    lookup_module_2 = LookupModule(**dict_2)

    assert lookup_module_2.run([[1], [2], [3]]) == [
        [1, 2, 3]
    ]

    assert lookup_module_2.run([[1, 2], [3], ['a']]) == [
        [1, 3, 'a'],
        [2, 3, 'a']
    ]

    assert lookup_module_2.run([['1', '2'], ['3'], ['a', 'b']]) == [
        ['1', '3', 'a'],
        ['2', '3', 'a'],
        ['1', '3', 'b'],
        ['2', '3', 'b']
    ]


# Generated at 2022-06-25 10:55:08.093333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_arg_0 = "['a', 'b', 'c']"
    list_arg_0 = [("a"), ("b"), ("c")]
    dict_arg_0 = {"test": list_arg_0}
    result_1 = lookup_module_0.run(str_arg_0, dict_arg_0)
    assert result_1 == [("[u'a']"), ("[u'b']"), ("[u'c']")]


# Generated at 2022-06-25 10:55:15.462495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'basedir': './ssl', 'user': 'vagrant'}
    lookup_module_0 = LookupModule(**dict_0)
    dict_1 = {}
    ret_val_0 = lookup_module_0.run(['keyfile.pem'], variables=dict_1)
    assert ret_val_0 == ['./ssl/keyfile.pem']


# Generated at 2022-06-25 10:55:20.748496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    params = ['[3, 4]', '[1, 2]']
    kwargs = {'fail_on_undefined': True}
    result = lookup_module_0.run(params, **kwargs)
    assert result == [[1, 2, 3, 4], [1, 2, 3, 4]]


# Generated at 2022-06-25 10:55:28.568928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['ansible_default_ipv4.address'], ['ansible_all_ipv4_addresses']]

    ret_0 = lookup_module_0.run(terms_0)
    assert ret_0 == [['ansible_default_ipv4.address', 'ansible_all_ipv4_addresses']]

    ret_1 = lookup_module_0.run(terms_0, variables={'ansible_default_ipv4': {'address': 'foo'}, 'ansible_all_ipv4_addresses': 'bar'})
    assert ret_1 == [['foo', 'bar']]

# Generated at 2022-06-25 10:55:31.588643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = test_case_0()
    dict_0 = {}
    dict_1 = {}

    dict_1['variables'] = dict_0
    assert lookup_module_0.run(**dict_1) == [0]

# Generated at 2022-06-25 10:55:38.266061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Function return values
    resp = [
        [
            'alice',
            'clientdb'
        ],
        [
            'alice',
            'employeedb'
        ],
        [
            'alice',
            'providerdb'
        ],
        [
            'bob',
            'clientdb'
        ],
        [
            'bob',
            'employeedb'
        ],
        [
            'bob',
            'providerdb'
        ]
    ]

# Generated at 2022-06-25 10:55:41.348045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_args_0 = []
    result = LookupModule.run(module_args_0)
    assert result is None


# Generated at 2022-06-25 10:55:55.425812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    dummy_var_0 = "abc"
    dummy_var_1 = "def"
    dummy_var_2 = "ghi"
    dummy_var_3 = "jkl"
    dummy_var_4 = "mno"
    dummy_var_5 = "pqr"
    dummy_var_6 = "stu"
    dummy_var_7 = "vwx"
    dummy_var_8 = "yz"


# Generated at 2022-06-25 10:56:05.077343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run with empty lists"""
    var_0 = []
    var_1 = []
    obj = LookupModule()
    # Testing nested with empty lists
    try:
        result = obj.run(['',''], [])
    except AnsibleError as e:
        assert str(e) == "One of the nested variables was undefined. The error was: 'list object' has no attribute u''", "Error raised for empty lists"
    # Testing nested with one empty list
    try:
        result = obj.run(['',''], ['username: alice'])
    except AnsibleError as e:
        assert str(e) == "One of the nested variables was undefined. The error was: 'list object' has no attribute u''", "Error raised for one empty list"
    # Testing nested with one non-empty list

# Generated at 2022-06-25 10:56:07.348172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    case_0 = LookupModule([],{})
    case_0.run(var_0)

# Generated at 2022-06-25 10:56:09.510619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    assert test_obj.run("arg_0", "arg_1") == "nested return value"

# Generated at 2022-06-25 10:56:11.654563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    test_case_0()
    lookup_plugin.run(terms=var_0)


test_LookupModule_run()

# Generated at 2022-06-25 10:56:22.008106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = ['alice', 'bob', 'john']
    var_2 = ['clientdb', 'employeedb', 'providerdb']
    var_3 = [var_1, var_2]
    var_4 = [var_3, var_0]
    var_5 = LookupModule()
    try:
        var_5.run(var_4)
    except AnsibleUndefinedVariable:
        pass
    else:
        raise AssertionError("AnsibleUndefinedVariable not raised")

    var_4 = [var_1, var_2, var_0]
    var_5 = LookupModule()

# Generated at 2022-06-25 10:56:22.829134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:56:24.471628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = []
    lookup_module = LookupModule()
    assert lookup_module.run(var) == []


# Generated at 2022-06-25 10:56:31.975068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    var_0 = [["a"], ["b1", "b2", "b3"], ["c1", "c2"]]
    var_1 = {'a': 'a', 'b': 'b1'}
    var_1 = f._lookup_variables(var_0, var_1)
    print(var_1)
    print(type(var_1))
    print(len(var_1))

test_LookupModule_run()



# Generated at 2022-06-25 10:56:37.614637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    test_case_0(var_0)

    terms = var_0

    result = LookupModule().run(terms, None)

    assert (result) == None


# Generated at 2022-06-25 10:56:43.303153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []

    lookup = LookupModule()

    lookup.run(var_0)

# Generated at 2022-06-25 10:56:48.541506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = AnsibleError("with_nested requires at least one element in the nested list")
    var_2 = [ var_1 ]
    try:
        LookupModule.run( var_0 )
        assert False
    except AnsibleError as var_3:
        assert var_3 == var_1
    var_4 = [ var_1 ]
    try:
        LookupModule.run( var_4 )
        assert False
    except AnsibleError as var_3:
        assert var_3 == var_1
    var_5 = [ var_1 ]
    try:
        LookupModule.run( var_5 )
        assert False
    except AnsibleError as var_3:
        assert var_3 == var_1
    var_6 = []

# Generated at 2022-06-25 10:56:50.036769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    run(self, var_0)

# Generated at 2022-06-25 10:56:53.158932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test case # 0:")
    lookup = LookupModule()
    var_0 = []
    var_1 = lookup.run(var_0)
    assert(var_1 == var_0)


# Generated at 2022-06-25 10:57:01.596898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    var_1 = []
    var_2 = None
    var_3 = {}

    my_obj = LookupModule()
    result = my_obj.run(var_0, var_1, var_2, var_3)
    print(result)


# Generated at 2022-06-25 10:57:10.376867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # all empty

    var_0 = []
    res_0 = []
    ans_0 = var_0

    res_0 = lookup.run(var_0, )
    assert res_0 == ans_0

    # all non-empty

    var_1 = [['a', 'b'], ['c'], ['d', 'e', 'f'], ['g']]
    res_1 = []

# Generated at 2022-06-25 10:57:18.964777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = var_0[:]
    var_1.reverse()
    result = []
    if len(var_0) == 0:
        raise AnsibleError("with_nested requires at least one element in the nested list")
    result = var_1.pop()
    while len(var_1) > 0:
        result2 = var_1.pop()
        for x in result:
            for x2 in result2:
                result.append(x.append(x2))
        result = result2
    new_result = []
    for x in result:
        new_result.append(x)
    return new_result

# Generated at 2022-06-25 10:57:19.744538
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:57:24.222303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_input = []
    my_variables = {}
    my_expected = []
    my_actual = LookupModule().run(my_input, my_variables)
    assert my_actual == my_expected


# Generated at 2022-06-25 10:57:27.416758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    var_0 = [["db1","db2","db3"],["user1","user2","user3"]]
    var_1 = {}
    var_1 = {}
    var_2 = {}
    var_2 = {}
    module.run(var_0, var_1, var_2)


# Generated at 2022-06-25 10:57:36.558982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [('var_0', 'var_0', "list"), ('var_1', 'var_1', "list"), ('var_2', 'var_2', "list")]
    var_1 = []
    var_0 = LookupModule()
    var_2 = var_0.run(var_1)
    assert var_2 == var_2


# Generated at 2022-06-25 10:57:39.320320
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    var_0 = []
    assert lookup_module.run(var_0) == []


# Generated at 2022-06-25 10:57:42.150273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms='echo', variables='') == ['echo']
    assert lookup_module.run(terms='echo', variables='') == ['echo']
    assert lookup_module.run(terms='echo', variables='') == ['echo']

# Generated at 2022-06-25 10:57:43.404377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = None
    kwargs = {}
    assert()


# Generated at 2022-06-25 10:57:55.946734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    var_5 = []
    var_6 = ansible_local.AnsibleModuleStub(order=1)
    var_7 = type(u'\ufeff', (object,), {})()
    var_8 = ansible_local.AnsibleModuleStub(order=1)
    var_9 = ansible_local.AnsibleModuleStub(order=0)
    var_10 = ansible_local.AnsibleModuleStub(order=1)
    var_11 = ansible_local.AnsibleModuleStub(order=1)
    var_12 = []
    var_13 = []
    var_14 = []

# Generated at 2022-06-25 10:57:59.546794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    assert lm.run(var_0) == []

# Generated at 2022-06-25 10:58:02.411443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['test_item_1', 'test_item_0']]
    args = dict()
    kwargs = dict()

    look = LookupModule()
    result = look.run(terms, None, **kwargs)

    assert result == [['test_item_1', 'test_item_0']]


# Generated at 2022-06-25 10:58:08.028827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    lookup = LookupModule()
    test_terms = [ '0', '1', '2' ]
    test_result = lookup.run(test_terms, loader)
    assert test_result[0] == [ '0', '1', '2' ]


# Generated at 2022-06-25 10:58:11.710428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [u'alice', u'bob']
    var_1 = [u'clientdb', u'employeedb', u'providerdb']
    var_2 = []
    var_2.append(var_0)
    var_2.append(var_1)
    var_3 = LookupModule()
    var_3.run(var_2)


# Generated at 2022-06-25 10:58:16.279903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_type = LookupModule()
    var_0 = []

    assert lookup_type.run(var_0) == []

# Generated at 2022-06-25 10:58:27.421671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [ ['a','b','c','d','e','f'] , ['1','2','3','4'] ] # _raw
    var_2 = [ var_1 ] # parameter lookup _raw
    var_3 = None # self.run(var_2,var_3)
    # var_4 = [[('a', '1'), ('a', '2'), ('a', '3'), ('a', '4'), ('b', '1'), ('b', '2'), ('b', '3'), ('b', '4'), ('c', '1'), ('c', '2'), ('c', '3'), ('c', '4'), ('d', '1'), ('d', '2'), ('d', '3'), ('d', '4'), ('e', '1'), ('e', '2'), ('e', '3'), ('e', '4'), ('f

# Generated at 2022-06-25 10:58:30.078719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_instance = LookupModule()
    result_0 = lookup_instance.run(var_0)
    print(result_0)



# Generated at 2022-06-25 10:58:35.804086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._loader = "mock_loader"
    lookup._templar = "mock_templar"

    # test_case_0()
    result = lookup.run(var_0)
    assert result == [], "'with_nested' requires at least one element in the nested list"

# Generated at 2022-06-25 10:58:40.169957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(var_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:58:49.108498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupObject = LookupModule()

# Generated at 2022-06-25 10:58:53.695792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = LookupModule()
    result_0 = lookup_0.run(var_0)
    assert result_0 is not None

# Coding example

# Generated at 2022-06-25 10:58:59.956095
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Invoke method
    var_return = test_case_0.run([], {'vars': {}},)
    # Test Assertions
    assert var_return == [], 'The returned value should be [], instead it was: {}'.format(var_return)


# Generated at 2022-06-25 10:59:02.040619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_instance = LookupModule()
    assert test_instance.run(var_0) == []

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:59:09.330526
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Instantiate the module
    module = LookupModule()

    # **********************************************************

    terms = [
        [
            'user1',
            'user2',
            'user3',
            'user4'
        ],
        [
            'group1',
            'group2',
            'group3'
        ]
    ]

    module.run(terms)

    return


# Generated at 2022-06-25 10:59:10.142120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0()

# Generated at 2022-06-25 10:59:16.257138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    for x_0 in var_0:
        assert True




# Generated at 2022-06-25 10:59:18.983752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ['foo', 'bar']
    var_1 = ['bar', 'baz']
    var_2 = [var_0, var_1]
    lm = LookupModule()
    lm.run(var_2)


# Generated at 2022-06-25 10:59:25.140324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()
    var_0 = []
    module_1 = LookupModule()
    var_1 = []
    var_2 = None
    var_3 = module_1.run(var_1, var_2)
    var_4 = module_0.run(var_0, var_2)
    assert var_4 == var_3


# Generated at 2022-06-25 10:59:30.667733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_mock = ['']
    my_mock.append('')
    my_mock.append('')
    my_mock.append('')
    my_mock.append('')
    my_mock.append('')
    my_mock[0] = 'variable_0'
    my_mock[1] = 'variable_1'
    my_mock[2] = 'variable_2'
    my_mock[3] = 'variable_3'
    my_mock[4] = 'variable_4'
    my_mock[5] = 'variable_5'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case

# Generated at 2022-06-25 10:59:33.770974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = list()
    var_0 = []
    terms.append(var_0)
    var_1 = []
    terms.append(var_1)

    result = lookup.run(terms)
    assert result == []
    assert result == lookup.run(terms)


# Generated at 2022-06-25 10:59:39.341715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [ [ 'alice', 'bob' ], [ 'clientdb', 'employeedb', 'providerdb' ] ]
    var_2 = [ 'alice', 'bob' ]
    var_3 = [ 'clientdb', 'employeedb', 'providerdb' ]
    var_4 = None
    var_5 = { }
    var_6 = [ [ 'alice', 'clientdb' ], [ 'alice', 'employeedb' ], [ 'alice', 'providerdb' ], [ 'bob', 'clientdb' ], [ 'bob', 'employeedb' ], [ 'bob', 'providerdb' ] ]
    obj_7 = LookupModule()
    obj_8 = LookupModule()

# Generated at 2022-06-25 10:59:44.009975
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #setup
    look = LookupModule()

    # test result
    assert look.run([]) == []
    assert look.run(['{}', '{}']) == []

    # test result
    assert look.run(['{}','{}','{}']) == []

    # test result
    assert look.run(['{"0": "a"}']) == [['a']]

    # test result
    assert look.run(['{"0": "a"}', '{"0": "a"}']) == [['a', 'a']]

    # test result
    assert look.run(['{"0": "a", "1": "b"}']) == [['a', 'b']]

    # test result

# Generated at 2022-06-25 10:59:51.124526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_0.append(var_1)
    var_1.append(var_2)
    var_3.append(var_0)
    var_2.append(var_3)

    try:
        test_result = LookupModule.run(var_0, var_1)
    except Exception:
        raise AssertionError("Unexpected Exception")

# Generated at 2022-06-25 11:00:01.276471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [{'a': 0}, {'b': 1}, {'c': 2}]
    var_2 = [{'d': 3}, {'e': 4}, {'f': 5}]
    var_3 = LookupModule()
    result = var_3.run([var_1, var_2])
    assert result == [{'a': 0, 'd': 3}, {'a': 0, 'e': 4}, {'a': 0, 'f': 5}, {'b': 1, 'd': 3}, {'b': 1, 'e': 4}, {'b': 1, 'f': 5}, {'c': 2, 'd': 3}, {'c': 2, 'e': 4}, {'c': 2, 'f': 5}]


# Generated at 2022-06-25 11:00:07.595290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.parsing.yaml.objects import AnsibleUnicode

  # set up
  lm = LookupModule()
  terms = [[], []]

  # test
  result = lm.run(terms)

  # assert
  assert isinstance(result, list)


# Generated at 2022-06-25 11:00:12.197081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader('/dummy/path/to/ansible/modules')
    lookup_module.set_templar('/dummy/path/to/ansible/module_utils')

    # Test with no given arguments
    result = lookup_module.run([])
    assert result is None

# Generated at 2022-06-25 11:00:14.762287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    terms_1 = (var_0, )
    var_2 = None
    test_0 = LookupModule()
    test_0.run(terms_1, var_2)


# Generated at 2022-06-25 11:00:19.584710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  Given
    terms = [var_0]
    variables = None

    #  When
    result = LookupModule.run(terms, variables)

    #  Then
    assert result is None


# Generated at 2022-06-25 11:00:22.320951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = [var_0, var_1]
    var_3 = LookupModule()
    var_4 = var_3.run(var_2)
    print(var_4)


# Generated at 2022-06-25 11:00:24.939140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    obj = LookupModule()
    result = obj.run(var_0)
    assert result == None

if __name__ == '__main__':
    result = test_LookupModule_run()
    assert result == None

# Generated at 2022-06-25 11:00:27.812217
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_input_0 = ["{{ my_var1 }}", "{{ my_var2 }}", "{{ my_var3 }}"]
    test_input_1 = None
    test_input_2 = None
    test_input_3 = None

    result = LookupModule().run(test_input_0, test_input_1)
    assert type(result) == list

# Generated at 2022-06-25 11:00:32.637815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [u'alice', u'bob']
    var_2 = [u'clientdb', u'employeedb', u'providerdb']
    var_3 = [u'alice', u'clientdb']
    var_4 = [u'alice', u'employeedb']
    var_5 = [u'alice', u'providerdb']
    var_6 = [u'bob', u'clientdb']
    var_7 = [u'bob', u'employeedb']
    var_8 = [u'bob', u'providerdb']
    var_9 = [var_3, var_4, var_5, var_6, var_7, var_8]
    var_10 = LookupModule()

# Generated at 2022-06-25 11:00:43.864614
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [ 'alice', 'bob' ]
    variables = None

    #mock_templar = MagicMock(name='templar')
    #mock_templar.template.return_value = 'alice'
    #mock_loader = MagicMock(name='loader')
    #mock_loader.load.return_value = 'alice'

    mock_LookupBase = MagicMock(name='LookupBase')
    mock_LookupBase._templar = 'alice'
    mock_LookupBase._loader = 'bob'
    mock_LookupBase._combine = 'alice'
    mock_LookupBase._flatten = 'bob'

    expected_result = ['alice', 'bob']

# Generated at 2022-06-25 11:00:54.705843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()

    assert t.run([]) == [[]]
    assert t.run([ [], [], [], [] ]) == [[]]
    assert t.run([ [1, 2], [], [], [] ]) == [[1, 2]]
    assert t.run([ [], [3, 4], [], [] ]) == [[3, 4]]
    assert t.run([ [], [], [5, 6], [] ]) == [[5, 6]]
    assert t.run([ [], [], [], [7, 8] ]) == [[7, 8]]
    assert t.run([ [1, 2], [3, 4], [], [] ]) == [[1, 2], [3, 4]]
    assert t.run([ [1, 2], [], [5, 6], [] ]) == [[1, 2], [5, 6]]
   

# Generated at 2022-06-25 11:01:01.139032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    var_0 = yaml.load('''
-   [   'alice',
        'bob'
    ]
-   [   'clientdb',
        'employeedb',
        'providerdb'
    ]
''')
    var_1 = {"ansible_fact_a": "A"}
    x.run(var_0, var_1)
    # Test case where all possible combinations are valid
    var_2 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    var_3 = {"ansible_fact_a": "A"}
    x.run(var_2, var_3)
    # Test case

# Generated at 2022-06-25 11:01:07.977252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # User input bug test case
    var_10 = [
      {
        'vlan_id': '10',
        'ipv4_addrs': [
          '192.168.10.1/24',
          '192.168.11.1/24'
        ]
      },
      {
        'vlan_id': '11',
        'ipv4_addrs': [
          '192.168.20.1/24',
          '192.168.21.1/24'
        ]
      }
    ]
    args_list_5 = []
    args_list_5.append('{{ item.vlan_id }}')
    args_list_5.append('{{ ansible_host }}')
    args_list_5.append('{{ item.vlan_id }}')
    args_

# Generated at 2022-06-25 11:01:14.117112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule._templar = mock_templar()
    lookupModule._loader = mock_loader()
    lookupModule._combine = mock_combine()
    lookupModule._flatten = mock_flatten()
    terms = []
    variables = None
    ret = lookupModule.run(terms, variables)

    assert ret is None


# Generated at 2022-06-25 11:01:16.225031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = []
    test_case_0_result = lookup_module.run(['var_0'])
    assert test_case_0_result is None

# Generated at 2022-06-25 11:01:19.643671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with arguments
    results = lookup_module.run(terms=[var_0])

    # Check for expected result
    expected = "VALUE"
    assert(expected == results)


# Generated at 2022-06-25 11:01:24.578806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_0.append([u'alice', u'bob'])
    var_0.append([u'clientdb', u'employeedb', u'providerdb'])
    var_1 = [[[u'alice', u'clientdb'], [u'alice', u'employeedb'], [u'alice', u'providerdb'], [u'bob', u'clientdb'], [u'bob', u'employeedb'], [u'bob', u'providerdb']]]
    var_2 = []
    var_2.append([u'alice', u'bob'])
    var_2.append([u'clientdb', u'employeedb', u'providerdb'])

# Generated at 2022-06-25 11:01:29.915897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = {"item": ["alice", "clientdb"], "item": ["alice", "employeedb"], "item": ["alice", "providerdb"], "item": ["bob", "clientdb"], "item": ["bob", "employeedb"], "item": ["bob", "providerdb"]}
    var_2 = []
    var_3 = {"item": ["alice", "clientdb"], "item": ["alice", "employeedb"], "item": ["alice", "providerdb"], "item": ["bob", "clientdb"], "item": ["bob", "employeedb"], "item": ["bob", "providerdb"]}
    var_4 = []

# Generated at 2022-06-25 11:01:36.295877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    var_0 = [["alice"], ["bob"], ["clientdb", "employeedb", "providerdb"]]
    var_0 = f.run(var_0)
    print(var_0)
    assert var_0 == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]



# Generated at 2022-06-25 11:01:44.647481
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var_0 = ['a', 'b']
    var_1 = ['c', 'd']
    var_2 = ['e', 'f']
    var_3 = []
    for var_4 in var_0:
        for var_5 in var_1:
            for var_6 in var_2:
                var_3.append([var_4, var_5, var_6])
    print(var_3)
    assert var_3 == [['a', 'c', 'e'], ['a', 'c', 'f'], ['a', 'd', 'e'], ['a', 'd', 'f'], ['b', 'c', 'e'], ['b', 'c', 'f'], ['b', 'd', 'e'], ['b', 'd', 'f']]


# Generated at 2022-06-25 11:01:49.312097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [["alice", "bob"], ["clientdb", "employeedb", "providerdb"]]
    var_x = LookupModule.run(var_0)
    assert var_x == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

if __name__ == "__main__":
    if "test_case_0" == sys.argv[1]:
        test_case_0()
    elif "test_LookupModule_run" == sys.argv[1]:
        test_LookupModule_run()

# Generated at 2022-06-25 11:02:00.131004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # for now create the input here, but may be needed to read from a file....
    var_0 = ['alice', 'bob']
    var_1 = ['clientdb', 'employeedb', 'providerdb']
    var_2 = [var_0, var_1]

    if True:
        print("Testing run")
        lm = LookupModule()
        print("Running lookup plugin for %s" % str(var_2))
        result = lm.run(var_2, {})
        print("The result is %s" % str(result))

# Generated at 2022-06-25 11:02:07.188806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    runner = unittest.TextTestRunner()
    suite = unittest.TestSuite()
    # suite.addTest(unittest.TestLoader().loadTestsFromTestCase(LookupModuleTest))
    # runner.run(suite)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:02:10.073637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = var_0
    l = LookupModule()
    l.run(terms)

# Generated at 2022-06-25 11:02:20.164355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 11:02:23.829313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    var_5 = []
    var_6 = []
    var_7 = []
    var_8 = []
    # expects 0 args
    # return value is a list
    return var_0


# Generated at 2022-06-25 11:02:31.997016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var_0 = []
    test_var_1 = []
    test_var_2 = []
    test_var_3 = []
    test_var_4 = []
    test_var_5 = []
    test_var_6 = []
    test_var_7 = []
    test_var_8 = []
    t = LookupModule()
    test_var_0 = t.run(terms=test_var_3, variables=test_var_4, **test_var_5)
    test_var_1 = t.run(terms=test_var_2, variables=test_var_4, **test_var_5)
    test_var_2 = t.run(terms=test_var_1, variables=test_var_4, **test_var_5)
    test_var_

# Generated at 2022-06-25 11:02:37.234431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = ""
  var_1 = []
  var_2 = [ 'a', 'b', 'c', 'd', 'e' ]
  var_3 = [ [ '1', '2' ], [ '3', '4', '5' ], [ '6', '7' ] ]
  var_4 = [ [ '1', '2' ], [ '3', '4' ] ]
  var_5 = [ [ '1', '2' ], None, None, None ]
  var_6 = [ [ '1', '2' ], None, [ '3', 4 ] ]
  var_7 = [ [ '1', '2' ], [ '3', '4' ], None, [ '5', '6' ] ]
  var_8 = [ '1', '2', '3', '4' ]
  var_9

# Generated at 2022-06-25 11:02:40.165582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True


# Generated at 2022-06-25 11:02:45.390813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_list = [("test", [("test2:")])]
    print("")
    print("Testing", "LookupModule.run", "...")
    print("Test case 0 ...")
    try:
        result = LookupModule().run(my_list, variables=None, **kwargs)
        print("Expected:", ["test", "test2:"])
        print("Actual  :", result)
    except:
        print("An exception occurred!")
        return -1
    print("Done!")
    return 0


# Generated at 2022-06-25 11:02:48.369439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []

    # Instantiate the parent
    var_1 = LookupModule(var_0)
    var_1.run(var_0)

    print('Test OK')

# Generated at 2022-06-25 11:02:54.817221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = [var_0]
    var_2 = [var_1,var_1]
    var_3 = [var_2,var_2]
    l = LookupModule()
    l.run(var_3)


# Generated at 2022-06-25 11:03:01.520314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    lookup_module_0 = LookupModule(**var_0)
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_3 = lookup_module_0.run(var_1, var_2, **var_3)
    assert var_3 == []


# Generated at 2022-06-25 11:03:07.966096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = {}
    lookup_module_1 = LookupModule(**var_2)

    var_3 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    var_4 = {}
    lookup_module_1 = LookupModule(**var_4)
    var_5 = lookup_module_1.run(var_3, **var_4)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:03:14.766700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = {u'terms': [[u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb']]}
    args_1 = {u'variables': {}}
    args_2 = {}
    expected_0 = [[u'alice', u'clientdb'], [u'alice', u'employeedb'], [u'alice', u'providerdb'], [u'bob', u'clientdb'], [u'bob', u'employeedb'], [u'bob', u'providerdb']]
    result_0 = LookupModule.run(args_0, args_1, args_2)
    assert result_0 == expected_0


# Generated at 2022-06-25 11:03:22.141290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    lookup_module_0 = LookupModule(**var_0)
    var_0 = object()
    var_1 = object()
    var_1 = lookup_module_0.run(var_0, var_1, **var_0)
    return var_1


# Generated at 2022-06-25 11:03:23.956777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    lookup_module_0 = LookupModule(**var_0)
    var_1 = lookup_module_0.run(**var_0)

# Generated at 2022-06-25 11:03:33.566155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = {
        'name': 'alice',
        'password': 'foo',
        'append_privs': True,
        'priv': 'clientdb.*:ALL',
    }
    var_3 = {
        'name': 'alice',
        'password': 'foo',
        'append_privs': True,
        'priv': 'employeedb.*:ALL',
    }
    var_4 = {
        'name': 'alice',
        'password': 'foo',
        'append_privs': True,
        'priv': 'providerdb.*:ALL',
    }
    var_5 = {
        'name': 'bob',
        'password': 'foo',
        'append_privs': True,
        'priv': 'clientdb.*:ALL',
    }
   