

# Generated at 2022-06-25 10:53:33.650853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar =  None
    lookup_module._loader =  None
    terms = None
    variables = None
    kwargs = None
    assert lookup_module.run(terms, variables, **kwargs) is None

# Generated at 2022-06-25 10:53:38.813036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_test_terms_0 = [['test_my_test_terms_0__0'], ['test_my_test_terms_0__1'], ['test_my_test_terms_0__2']]
    my_test_variables_0 = None
    lookup_module_0_return = lookup_module_0.run(my_test_terms_0, variables=my_test_variables_0)
    assert lookup_module_0_return == [['test_my_test_terms_0__0', 'test_my_test_terms_0__1', 'test_my_test_terms_0__2']], lookup_module_0_return


# Generated at 2022-06-25 10:53:44.019174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        '',
        [
            '',
            [
                '',
                [
                    '',
                ],
            ],
        ],
    ]
    results_0 = lookup_module_0.run(terms)
    assert results_0 == [
        ['', '', '', ''],
    ]

# Generated at 2022-06-25 10:53:54.947500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data0 = [[[u'student-01', u'student-02', u'student-03', u'student-04', u'student-05', u'student-06', u'student-07', u'student-08', u'student-09', u'student-10']], [[u'module-01', u'module-02', u'module-03', u'module-04', u'module-05', u'module-06', u'module-07', u'module-08', u'module-09', u'module-10']]]
    data1 = dict()
    lookup_module_var = LookupModule()
    result = lookup_module_var._lookup_variables(data0, data1)

# Generated at 2022-06-25 10:54:03.126183
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        [
            "{{ item[0] }}",
            "{{ item[1] }}",
        ],
        [
            "{{ users }}",
            "{{ groups }}",
        ]
    ]

    variables = {
        "item": [
            "i1",
            "i2",
        ],
        "users": [
            "u1",
            "u2",
        ],
        "groups": [
            "g1",
            "g2",
        ],
    }


# Generated at 2022-06-25 10:54:10.742775
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # the following test should succeed
    lookup_module_1 = LookupModule()
    assert [["one", "two"], ["three", "four"], ["5", "6"], ["7", "8"]] == lookup_module_1.run([["one", "two"], ["3", "4"], ["5", "6"], ["7", "8"]], "", "")
    assert [["one", "three"], ["one", "four"], ["two", "three"], ["two", "four"]] == lookup_module_1.run([["one", "two"], ["three", "four"]], "", "")

# Generated at 2022-06-25 10:54:19.104438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    lookup_module_0._combine = 'get'
    lookup_module_0._flatten = 'get'
    lookup_module_0._loader = 'get'
    lookup_module_0._templar = 'get'
    variables_0 = []
    result_0 = lookup_module_0.run(terms_0, variables_0)
    lookup_module_1 = LookupModule()
    terms_1 = [{}, {}]
    lookup_module_1._combine = 'get'
    lookup_module_1._flatten = 'get'
    lookup_module_1._loader = 'get'
    lookup_module_1._templar = 'get'
    variables_1 = []
    result_1 = lookup_module_

# Generated at 2022-06-25 10:54:20.595478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    test_case_0()

    assert True

# Generated at 2022-06-25 10:54:31.141477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:54:38.035958
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    args = [ [ 'alice', 'bob' ], [ 'clientdb', 'employeedb', 'providerdb' ] ]
    assert lookup_module_0.run((args), variables=None, **dict()) == [
            [ 'alice', 'clientdb' ],
            [ 'alice', 'employeedb' ],
            [ 'alice', 'providerdb' ],
            [ 'bob', 'clientdb' ],
            [ 'bob', 'employeedb' ],
            [ 'bob', 'providerdb' ],
    ]

# Generated at 2022-06-25 10:54:47.948491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arguments = [[[['1', '2'], ['3', '4']], [['5', '6'], ['7', '8']]], None]
    arguments_0 = [[[['1', '2'], ['3', '4']], [['5', '6'], ['7', '8']]], None]
    arguments_1 = [[[['1', '2'], ['3', '4']], [['5', '6'], ['7', '8']]], None]
    arguments_3 = [[[['1', '2'], ['3', '4']], [['5', '6'], ['7', '8']]], None]

# Generated at 2022-06-25 10:54:58.242289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Extract and setup parameters
    terms_0 = [[u"{{foo}}", u"1", u"2", u"3", u"4", u"5"], [u"a", u"b", u"c", u"d", u"e", u"f"]]
    variables_0 = {}

    # Execute the run() method
    result_0 = LookupModule().run(terms_0, variables_0)

    # Check the result
    assert isinstance(result_0, list)
    assert len(result_0) == 6
    assert isinstance(result_0[0], list)
    assert result_0[0] == [u"{{foo}}", u"a"]
    assert isinstance(result_0[1], list)

# Generated at 2022-06-25 10:55:05.531697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    list_0 = list()
    dict_0 = dict()
    dict_0['key'] = 'value'
    list_0.append(dict_0)
    list_0.append('value')

    result_0 = lookup_module_0.run(list_0)

    assert result_0[0][0]['key'] == 'value'



# Generated at 2022-06-25 10:55:12.931815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = []
    try:
        result_0 = lookup_module_0.run(terms_0, variables_0)
    except AnsibleError as exc:
        assert 'with_nested requires at least one element in the nested list' in exc.message
        assert type(exc) == AnsibleError
    else:
        raise Exception('An error should have been thrown.')


# Generated at 2022-06-25 10:55:14.904754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['alice', 'bob']
    lookup_module_0.run(terms)

# Generated at 2022-06-25 10:55:22.744266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_list_0 = ['foo', 'bar', 'baz']
    my_list_1 = ['foo', 'bar', 'baz']
    result_0 = lookup_module_1.run(my_list_0, my_list_1)
    result_1 = lookup_module_1.run(my_list_0, my_list_1)
    result_2 = lookup_module_1.run(my_list_0, my_list_1)
    result_3 = lookup_module_1.run(my_list_0, my_list_1)
    result_4 = lookup_module_1.run(my_list_0, my_list_1)

# Generated at 2022-06-25 10:55:25.334930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    t_1 = [["a"], ["b"]]
    assert lookup_module_1.run(t_1) == [["a", "b"]]


# Generated at 2022-06-25 10:55:33.658244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'a', 'b'
        ], [
            'x', 'y'
        ]
    ]
    parameters_0 = {}
    parameters_0['variables'] = variables_0
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms_0, parameters_0)

    # negative test - empty list
    lookup_module_0 = LookupModule()
    terms = []
    parameters_0 = {}
    parameters_0['variables'] = variables_0
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms_0, parameters_0)

    # negative test - not enough list
    lookup_module_0 = LookupModule()
   

# Generated at 2022-06-25 10:55:40.728239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [[1], [2, 3], [4, 5, 6]]
    variables = {}
    with_nested_0 = lookup_module_0.run(terms, variables)
    assert with_nested_0 == [[1, 2, 4], [1, 2, 5], [1, 2, 6], [1, 3, 4], [1, 3, 5], [1, 3, 6]]

# Generated at 2022-06-25 10:55:41.778899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    lookup_module_instance.run()

# Generated at 2022-06-25 10:55:46.624463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run is None

# Testcase for class LookupModule_test_case_0

# Generated at 2022-06-25 10:55:50.751018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(['abc', 'def'], [])
    assert result_0 == []


# Generated at 2022-06-25 10:55:57.457269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    variables_0 = {
        'foo': 'bar',
        'boo': 'baz'
    }
    result_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 10:56:07.000200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_basedir = Mock(return_value='/etc/ansible/roles/role_under_test/vars')
    lookup_module_0._templar = Mock()
    lookup_module_0._loader = Mock()
    lookup_module_0._loader.list_directory = Mock(return_value=['main.yml'])
    lookup_module_0.run(['foo', [['bar', 'baz']]], ['a', 'b'], _terms=[['foo', [['bar', 'baz']]]])


# Generated at 2022-06-25 10:56:10.182275
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_1 = [ '{{ my_first_var }}', '{{ my_second_var }}' ]

    test_run_1 = LookupModule().run(terms_1)

    assert test_run_1 == terms_1

# Generated at 2022-06-25 10:56:20.507269
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:56:27.929096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x1 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    lookup_module_1 = LookupModule()
    l1 = lookup_module_1.run(x1, variables=None, **None)
    assert l1 == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]
    x2 = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb'], ['r', 'w', 'x']]
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:56:37.795414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lookup_module_0 = LookupModule()

    # Test for an edge case for which a combination of two lists with elements ['a','b'] present in
    # the first list and elements ['1','2','3'] are present in the second list of arguments to the run method
    # The edge case is the method will be able to handle the case when the first list has more elements than
    # the second list. eg.,
    # Given: first list has more elements than the second list
    #        first list = [ 'a', 'b', 'c', 'd' ]
    #        second list = [ '1', '2' ]
    # Expected Result: [ ['a', '1'], ['a', '2'], ['b', '1'], ['b', '2'], ['c', '1'], ['c', '2'], ['d

# Generated at 2022-06-25 10:56:46.521418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    test_run_1 = lookup_module_1.run(terms=[['a', 'b'], ['1', '2']])
    assert test_run_1 == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2']]

    lookup_module_2 = LookupModule()

    test_run_2 = lookup_module_2.run(terms=[['a'], ['1', '2'], ['y']])
    assert test_run_2 == [['a', '1', 'y'], ['a', '2', 'y']]

    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 10:56:56.354022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

# Generated at 2022-06-25 10:57:04.379044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ##########################################
    # Unit test the lookup run method in the case where terms is a non empty list
    #
    result = lookup_module_0.run([[]])
    assert result == [[]]

    result = lookup_module_0.run([[1]])
    assert result == [[1]]

    result = lookup_module_0.run([["abc"]])
    assert result == [["abc"]]

    result = lookup_module_0.run([["{{foo}}"]])
    assert result == [["{{foo}}"]]

    result = lookup_module_0.run([[], []])
    assert result == [[]]

    result = lookup_module_0.run([[], [1]])
    assert result == [[1]]

    result = lookup_module_

# Generated at 2022-06-25 10:57:10.868317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[]]
    variables = {'_raw': [['a'], ['b', 'c'], ['d', 'e', 'f']]}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == [['a', 'b', 'd'], ['a', 'b', 'e'], ['a', 'b', 'f'], ['a', 'c', 'd'], ['a', 'c', 'e'], ['a', 'c', 'f']]

# Generated at 2022-06-25 10:57:20.295505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = (
        {
            'a': ['b', 'c'],
            'd': ['e', 'f'],
            },
        {
            'g': ['h', 'i'],
            'j': ['k', 'l'],
            },
        {
            'm': ['n', 'o'],
            'p': ['q', 'r'],
        },
    )
    variables_0 = {
        'a': ['b', 'c'],
        'd': ['e', 'f'],
        'g': ['h', 'i'],
        'j': ['k', 'l'],
        'm': ['n', 'o'],
        'p': ['q', 'r'],
    }
    result = lookup_

# Generated at 2022-06-25 10:57:24.621439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Calling run method of LookupModule class object passing an empty list and an empty dictionary as parameters
    result = lookup_module.run([], {})
    assert result == [], "Not an empty list"


# Generated at 2022-06-25 10:57:29.580369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'alice',
            'bob'
        ],
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]
    variables_0 = object
    expected = lookup_module_0.run(terms_0, variables_0)
    assert expected == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

# Generated at 2022-06-25 10:57:37.757445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms_0 = (('alice', 'bob'), ('clientdb', 'employeedb', 'providerdb'))
  variables_0 = {'foo': 'bar'}
  kwargs_0 = {'foo': 'bar'}
  result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
  assert result_0 is not None


# Generated at 2022-06-25 10:57:40.580167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [['1'], ['2'], ['3', '4']]
    assert LookupModule().run(terms) == [['1', '2', '3'], ['1', '2', '4']]


# Generated at 2022-06-25 10:57:46.751403
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.parsing.dataloader

    lookup_module = LookupModule()
    loader = ansible.parsing.dataloader.DataLoader()
    templar = ansible.utils.template.Templar(loader=loader)

    terms = [
        [1, 2, 3],
        [4, 5, 6]
    ]
    result = lookup_module.run(terms, templar=templar, loader=loader)
    assert result[0][0] == 1 and result[1][0] == 1 and result[2][0] == 2 and result[3][0] == 2 and result[0][1] == 4 and result[1][1] == 5


# Generated at 2022-06-25 10:57:57.062107
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # from ansible.utils.listify import listify_lookup_plugin_terms
    # from jinja2.exceptions import UndefinedError
    # result = listify_lookup_plugin_terms(terms, templar=self._templar, loader=self._loader)

    # We do this to allow the test to vary the terms passed in
    lookup_module_1 = LookupModule()
    terms = [ [ 'a', 'b', 'c'], [ '1', '2' ], [ 'x', 'y', 'z' ] ]
    result = lookup_module_1.run(terms)


# Generated at 2022-06-25 10:58:03.830781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = {}
    result_1['_list'] = [
        [ u'a', u'b' ],
        [ u'c', u'd' ],
        [ u'e', u'f' ]
    ]
    result_2 = {}
    result_2['_list'] = [
        [ u'a', u'c' ],
        [ u'a', u'd' ],
        [ u'a', u'e' ],
        [ u'a', u'f' ],
        [ u'b', u'c' ],
        [ u'b', u'd' ],
        [ u'b', u'e' ],
        [ u'b', u'f' ]
    ]
    result_3 = {}

# Generated at 2022-06-25 10:58:14.197035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([['foo', 'bar'], ['a', 'b', 'c']]) == [['foo', 'a'], ['foo', 'b'], ['foo', 'c'], ['bar', 'a'], ['bar', 'b'], ['bar', 'c']]

# Generated at 2022-06-25 10:58:22.531817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arguments = [
        {
            "terms": [
                [
                    [
                        "app1"
                    ],
                    [
                        "app2"
                    ]
                ],
                [
                    "tomcat-1",
                    "tomcat-2"
                ]
            ]
        }
    ]

    responses = [
        [
            [
                "app1",
                "tomcat-1"
            ],
            [
                "app1",
                "tomcat-2"
            ],
            [
                "app2",
                "tomcat-1"
            ],
            [
                "app2",
                "tomcat-2"
            ]
        ]
    ]

    for (arguments, response) in zip(arguments, responses):
        lookup_module = LookupModule()
        assert lookup

# Generated at 2022-06-25 10:58:28.055691
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  lookup_module_0 = LookupModule()
  lookup_module_0._templar = Undefined()
  lookup_module_0._loader = Undefined()
  lookup_module_0.run([[{"foo":"bar"},{"baz":"boz"}]])




# Generated at 2022-06-25 10:58:31.683467
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup test case
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:58:41.788821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    lookup_module_0 = LookupModule()
    _list_0 = [
        '{{item_0}}',
        '{{item_1}}'
    ]
    item_cache = {
        'item_0:0': 'alice',
        'item_1:0': 'clientdb',
        'item_0:1': 'bob',
        'item_1:1': 'employeedb',
        'item_0:2': 'charlie',
        'item_1:2': 'providerdb'
    }
    _list_1 = [
        'alice',
        'bob',
        'charlie'
    ]

# Generated at 2022-06-25 10:58:48.189873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run([], {}, [])
    assert result == []


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:58:57.842265
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:59:01.463607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    assert lookup_module_run.run([[['foo'], ['bar']], [1, 2, 3]]) == [['foo', 1], ['foo', 2], ['foo', 3], ['bar', 1], ['bar', 2], ['bar', 3]]

# Generated at 2022-06-25 10:59:08.166478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = [["foo", "bar"], ["baz", "bam"]]
    result = lookup_module_0.run(args)
    assert result == [["foo", "baz"], ["foo", "bam"], ["bar", "baz"], ["bar", "bam"]]


# Generated at 2022-06-25 10:59:12.598632
# Unit test for method run of class LookupModule
def test_LookupModule_run():


    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    # Parameters that you set up for test.
    my_list = list()
    my_list.append('test')
    result = lookup_module_0.run(my_list, None)
    assert result == [['test']]


# Generated at 2022-06-25 10:59:17.505025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [["foo","bar"],["baz","bam"]]
    result = lookup_module_0.run(terms)
    assert result == [["foo","baz"],["foo","bam"],["bar","baz"],["bar","bam"]]

# Generated at 2022-06-25 10:59:27.066125
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case with one element in the list
    nested_list = [ ['alpha', 'bravo'] ]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(nested_list)
    assert result == [ ['alpha'], ['bravo'] ]

    # Test case with two elements in the list
    nested_list = [ ['alpha', 'bravo'], ['charlie', 'delta'] ]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(nested_list)
    assert result == [ ['alpha', 'charlie'], ['alpha', 'delta'], ['bravo', 'charlie'], ['bravo', 'delta']]

    # Test case with three elements in the list

# Generated at 2022-06-25 10:59:31.467124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (LookupModule().run([['foo', 'bar', 'baz'], ['biz', 'boz']]) == [[['foo', 'biz'], ['foo', 'boz']],
                                                                               [['bar', 'biz'], ['bar', 'boz']],
                                                                               [['baz', 'biz'], ['baz', 'boz']]])


# Generated at 2022-06-25 10:59:34.720456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            "{{ users }}",
            [
                "clientdb",
                "employeedb",
                "providerdb"
            ]
        ]
    ]
    expected = []
    result = lookup_module_0.run(terms_0)
    assert result == expected


# Generated at 2022-06-25 10:59:43.055394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = DummyTemplar()
    lookup_module_0._loader = DummyLoader()
    lookup_module_0.run([[u'alice', u'bob'], [u'clientdb', u'employeedb', u'providerdb']])

# This is a test case for issue https://github.com/ansible/ansible/issues/6072

# Generated at 2022-06-25 10:59:49.745108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0=None
    result_0 = lookup_module_0.run(terms_0,variables_0)
    return result_0

if __name__ == '__main__':
    print(test_LookupModule_run())

# Generated at 2022-06-25 10:59:55.068283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except Exception as err:
        assert str(err) == "with_nested requires at least one element in the nested list"


# Generated at 2022-06-25 10:59:59.096973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [["foo","bar"]]
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == [['foo'], ['bar']]


# Generated at 2022-06-25 11:00:00.975577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = []
    assert lookup_module_1.run(terms) == []


# Generated at 2022-06-25 11:00:07.633751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = []
    result = lookup_module_0.run(my_list_0)
    assert isinstance(result, list)
    assert (result == [])

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:00:11.772102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms = []
  variables = None
  kwargs = {}
  assert lookup_module_0.run(terms,variables,**kwargs) == []


# Generated at 2022-06-25 11:00:13.950012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Running test for method run")
    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError) as exc:
        lookup_module_0.run([])
    assert str(exc.value) == "with_nested requires at least one element in the nested list"


# Generated at 2022-06-25 11:00:21.633583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(UndefinedError) as err:
        lookup_module_0.run([[u'{{users}}', u'{{dbs}}'], [u'{{users}}', u'{{dbs}}']])
    assert err.value.message == 'One of the nested variables was undefined. The error was: ' \
                                'AnsibleUndefinedVariable: One or more undefined variables: ' \
                                '\'dict object\' has no attribute \'users\''

# Generated at 2022-06-25 11:00:23.901264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[1, 2, 3], ['a', 'b', 'c']]
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)
    return



# Generated at 2022-06-25 11:00:27.415633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['[ "foo", "bar" ]', '[ "a", "b", "c" ]']) == [['foo', 'a'], ['foo', 'b'], ['foo', 'c'], ['bar', 'a'], ['bar', 'b'], ['bar', 'c']]

# Generated at 2022-06-25 11:00:32.367438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
                [1, 2, 3],
                [4, 5, 6],
                [7, 8, 9]
            ]

# Generated at 2022-06-25 11:00:38.280318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_list_0 = []
    terms_0 = my_list_0
    variables_0 = None
    kwargs_0 = None
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert(len(var_0) == 0)


# Generated at 2022-06-25 11:00:39.261901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule.run, object)

# Generated at 2022-06-25 11:00:48.252429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []
    assert lookup_module_1.run([[]]) == []
    assert lookup_module_1.run([[],[]]) == []
    assert lookup_module_1.run([[[]]]) == []
    assert lookup_module_1.run([['a']]) == [['a']]
    assert lookup_module_1.run([['a','b']]) == [['a'],['b']]
    assert lookup_module_1.run([['a','b'],['c']]) == [['a','c'],['b','c']]

# Generated at 2022-06-25 11:00:48.787691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass


# Generated at 2022-06-25 11:00:58.149570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_module_0.run(bytes_0)
    var_1 = lookup_module_0._lookup_variables(bytes_0)
    var_2 = lookup_module_0._combine(var_0, var_1)
    var_3 = lookup_module_0._flatten(var_2)
    assert var_0 == [], var_0
    assert var_1 == [], var_1
    assert var_2 == [], var_2
    assert var_3 == [], var_3


# Generated at 2022-06-25 11:00:58.643538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:01:01.562456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    lookup_run(bytes_0)

# Generated at 2022-06-25 11:01:09.372718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_module_0.run(bytes_0)
    assert var_0 == [([1, 2],), ([1, 2],)]


# Generated at 2022-06-25 11:01:12.836183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)
    # Test using expected exception AnsibleError(msg)
    try:
        var_1 = lookup_module_0.run(bytes_0)
        if True:
            raise Exception("AnsibleError not raised")
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:01:13.749693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:01:16.979939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0)



# Generated at 2022-06-25 11:01:24.693258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)
    print(var_0)


# Generated at 2022-06-25 11:01:31.712732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(None, None)
    assert isinstance(var_0, tuple)
    assert var_0 == ()


# Generated at 2022-06-25 11:01:36.311960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    list_0 = []
    assert_equal(lookup_run(bytes_0, list_0), None)


# Generated at 2022-06-25 11:01:42.697221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)

# Generated at 2022-06-25 11:01:46.916299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)


# Generated at 2022-06-25 11:01:51.601478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)


# Generated at 2022-06-25 11:02:01.836980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:02:06.381154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xf7\x94\x90\xe7\x80\xbf\x1f\xaa\xf7\x1a\x95q\xc8%\xf4\xfc\xc0\x0f\x1d\x1f\x08\xd5` \xb8\xef\x1d\x11\xff\xbf\x04\xb9\xe9\x97\x12\xd1\x0e\xb1\x91\xe3\xdf\x15\x13\xf9'
    var_0 = lookup_run(bytes_0)


# Generated at 2022-06-25 11:02:15.290337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {'lookup_module_0': 'lookup_module_0'}

# Generated at 2022-06-25 11:02:18.535976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [u'1', u'2', u'3']
    variables = None
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables)
    assert result == [[u'1', u'2', u'3']]


# Generated at 2022-06-25 11:02:21.959257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_10 = LookupModule()
    bytes_10 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_10 = lookup_run(bytes_10)



# Generated at 2022-06-25 11:02:26.670152
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)

    lookup_module_0.run(terms, variables=None, **kwargs)
    for x in terms:
        intermediate = listify_lookup_plugin_terms(x, templar=self._templar, loader=self._loader, fail_on_undefined=True)


# Generated at 2022-06-25 11:02:32.955468
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    bytes_0 = b'\x15\xb4\x1a\xfa\x8e\xd3\x9a\x16\x0c\x95\xcfE\xd7\x0b\x0b\xcc\x9c\xd1\xf8\xed\x1d'
    var = lookup_run(bytes_0)


# Generated at 2022-06-25 11:02:44.578084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    bytes_1 = b'\xd3\x05\xc8\xbaCBD\xa5\x16\xb5\x94\x10\x0c\x12l\x13'
    dict_2 = dict()
    dict_2['foo_2'] = bytes_1
    dict_1 = dict()
    dict_1['vars_1'] = dict_2
    var_1 = lookup_run(list([list([list(['foo_2'])])]), dict_1)


# Generated at 2022-06-25 11:02:51.121725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [u'\u00e1\u00e9\u00ed\u00f3\u00fa', 1, 4, 9, 16]
    list_1 = [u'\u0434\u0435\u0451\u0434\u0435\u0451']
    str_0 = '\xea\xcb\x88\x10\x5c\xa5\t\xafJ\xaa)Q\xcd\xd0\x1f'
    var_0 = lookup_module_0.run(list_0, list_1, str_0)
    str_1 = '\xca\x97\xb9\x11\xce\x0f\xdd\x12\x16'
    str

# Generated at 2022-06-25 11:02:52.985697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)



# Generated at 2022-06-25 11:03:02.406231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [["api", "app", "db"], ["aws", "gce"], ["ansible-localhost"]]
    variables = {}
    result = LookupModule.run(terms, variables=variables)
    assert result == [["api", "aws", "ansible-localhost"], ["api", "gce", "ansible-localhost"], ["app", "aws", "ansible-localhost"], ["app", "gce", "ansible-localhost"], ["db", "aws", "ansible-localhost"], ["db", "gce", "ansible-localhost"]]


# Generated at 2022-06-25 11:03:04.923757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_1 = b'\x86\x0f\x0e9\xfb\xb2\x16\xe0\xe5\x94\\\xc0\xb5\x82\x9c\x16\x1aR\x1b'
    var_1 = lookup_run(bytes_1)


# Generated at 2022-06-25 11:03:06.079157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # TODO: Do each test in a seperate method
    pass



# Generated at 2022-06-25 11:03:10.532412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)
    assert var_0 == [b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9']


# Generated at 2022-06-25 11:03:14.601108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ [ 'alice', 'bob' ], [ 'clientdb', 'employeedb', 'providerdb' ] ]
    result = run(terms)
    assert result == [ [ 'alice', 'clientdb' ], [ 'bob', 'employeedb' ], [ 'alice', 'providerdb' ], [ 'bob', 'clientdb' ], [ 'alice', 'employeedb' ], [ 'bob', 'providerdb' ] ]


# Generated at 2022-06-25 11:03:23.821203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tst_data = {
        '_raw': [
            [
                'a',
                'b',
                'c'
            ],
            [
                ['foo', 'bar', 'baz'],
                ['one', 'two', 'three'],
            ],
        ]
    }
    obj = LookupModule()
    value = obj.run(tst_data['_raw'], tst_data)


# Generated at 2022-06-25 11:03:32.116583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xc9\xbf\x19\xdf\xc1\xec\x1eh\xdd\xe7\xc2Mv\x96k\xb9'
    var_0 = lookup_run(bytes_0)
    var_1 = lookup_module_0.run(var_0)
    assert '[[1, 2, 3], [4, 5, 6], [7, 8, 9]]' in var_1
