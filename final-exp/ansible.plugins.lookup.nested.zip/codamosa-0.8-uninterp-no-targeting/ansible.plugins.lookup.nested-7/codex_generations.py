

# Generated at 2022-06-21 06:14:28.093514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with more that one entry in the term
    term = [['a', 'b', 'c'], ['1', '2', '3', '4']]
    result = LookupModule().run(term, variables=None, **{})
    assert result == [['a', '1'], ['b', '1'], ['c', '1'], ['a', '2'], ['b', '2'], ['c', '2'], ['a', '3'], ['b', '3'], ['c', '3'], ['a', '4'], ['b', '4'], ['c', '4']], result

# Test with one entry in the term
    term = [['a', 'b', 'c']]
    result = LookupModule().run(term, variables=None, **{})

# Generated at 2022-06-21 06:14:39.936795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parse terms
    terms = [
        '{{ users }}',
        [
            'clientdb',
            'employeedb',
            'providerdb'
        ]
    ]

    # Expected results
    expected_result = [
        [
            'alice',
            'clientdb'
        ],
        [
            'alice',
            'employeedb'
        ],
        [
            'alice',
            'providerdb'
        ],
        [
            'bob',
            'clientdb'
        ],
        [
            'bob',
            'employeedb'
        ],
        [
            'bob',
            'providerdb'
        ]
    ]

    # Variables that can be used during the tests

# Generated at 2022-06-21 06:14:41.478222
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:14:43.383056
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:14:52.342193
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Minimal test for method run
    my_list = [ ['a', 'b'], ['1', '2'], ['i', 'ii'] ]
    lookup_module = LookupModule()
    test_result = lookup_module.run(my_list, dict())
    assert test_result == [['a', '1', 'i'], ['a', '1', 'ii'], ['a', '2', 'i'], ['a', '2', 'ii'], ['b', '1', 'i'], ['b', '1', 'ii'], ['b', '2', 'i'], ['b', '2', 'ii']], \
        "with_items test failed"


# Generated at 2022-06-21 06:14:55.362730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    nested = LookupModule()
    assert nested
    # Test instatiation of LookupModule


# Generated at 2022-06-21 06:15:03.954386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule_run is a method of LookupModule class
    lookup_module_obj = LookupModule()

    terms = [["alice", "bob", "john"],["clientdb", "employeedb", "providerdb"]]
    result = lookup_module_obj.run(terms, variables = None, **kwargs)

    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb'], ['john', 'clientdb'], ['john', 'employeedb'], ['john', 'providerdb']], "test_LookupModule_run() failed"

if __name__ == '__main__':
    test_Lookup

# Generated at 2022-06-21 06:15:10.303018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()

    mod.set_runner( dict(
        inventory = dict(
            hosts = dict(
                localhost = dict(
                    ansible_connection = "local"
                )
            ),
            groups = dict(
                all = dict(
                    hosts = dict(
                        localhost = dict()
                    )
                )
            )
        )
    ) )
    assert mod.run(["foo"], dict(foo="boo")) == "boo"
    assert mod.run(["foo"], dict()) == None
    assert mod.run([], dict()) == None
    assert mod.run([["foo1","bar1"], ["foo2","bar2"]], dict()) == [["foo1", "bar1"], ["foo2", "bar2"]]

# Generated at 2022-06-21 06:15:13.962222
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Needed to make sure nested is imported
    from ansible.plugins.lookup import nested
    lookup_module = nested.LookupModule()

# Generated at 2022-06-21 06:15:15.934147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(None,None)

# Generated at 2022-06-21 06:15:18.713775
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test will fail if the following raises an exception
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:15:28.044845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    terms = [ ['alice', 'bob'] , ['clientdb', 'employeedb', 'providerdb'] ]
    result = [ ['alice', 'clientdb'] , ['alice', 'employeedb'] , ['alice', 'providerdb'] , ['bob', 'clientdb'] , ['bob', 'employeedb'] , ['bob', 'providerdb'] ]
    assert (test_lookup.run(terms) == result)

# Generated at 2022-06-21 06:15:40.765329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    # test 1
    result = lookup_instance.run([[['http_port'], ['https_port']]])
    assert result == [['http_port'], ['https_port']]
    # test 2
    result = lookup_instance.run([['http_port'], ['https_port']])
    assert result == [['http_port', 'https_port']]
    # test 3
    result = lookup_instance.run([[[1,2],[3,4]], ['http_port'], ['https_port']])
    assert result == [[[1, 2, 'http_port'], [1, 2, 'https_port']], [[3, 4, 'http_port'], [3, 4, 'https_port']]]

# Generated at 2022-06-21 06:15:52.684426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  """
  Test method run of class LookupModule
  """
  # Test with an empty list as input
  lookup = LookupModule()
  terms = []
  variables = {}
  with pytest.raises(AnsibleError, match="with_nested requires at least one element in the nested list"):
    lookup.run(terms, variables)

  # Test with a single list as input
  lookup = LookupModule()
  terms = [['a', 'b']]
  variables = {}
  assert lookup.run(terms, variables) == [['a'], ['b']]

  # Test with nested lists as input
  lookup = LookupModule()
  terms = [['a', 'b'], ['c', 'd'], ['e', 'f']]
  variables = {}
  assert lookup.run(terms, variables)

# Generated at 2022-06-21 06:16:00.125829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_obj = LookupModule()
    result = LookupModule_obj.run([[1, 2], [3, 4]])
    assert result == [[1, 3], [1, 4], [2, 3], [2, 4]]

    # empty nested list
    result = LookupModule_obj.run([[]])
    assert result == []

    # one element
    result = LookupModule_obj.run([[1, 2], [3], [4, 5]])
    assert result == [[1, 3, 4], [1, 3, 5], [2, 3, 4], [2, 3, 5]]

    # single element
    result = LookupModule_obj.run([[1]])
    assert result == [[1]]

    # nested list

# Generated at 2022-06-21 06:16:01.432911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 06:16:14.015903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([ ['a','b'], [1,2] ])
    assert result == [ ['a', 1], ['a', 2], ['b', 1], ['b', 2] ], result

    result = LookupModule().run([ ['a','b'], [1,2], [3,4] ])
    assert result == [ ['a', 1, 3], ['a', 1, 4], ['a', 2, 3], ['a', 2, 4], ['b', 1, 3], ['b', 1, 4], ['b', 2, 3], ['b', 2, 4] ], result

    result = LookupModule().run([ ['a','b'], [1,2,3], [3,4] ])

# Generated at 2022-06-21 06:16:22.105990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms = [
        [
            "nas_host_1",
            "nas_host_2"
        ],
        [
            "nas_pool_1",
            "nas_pool_2"
        ],
        [
            "nas_share_1",
            "nas_share_2"
        ]
    ]
    result = lookup_obj.run(terms)

# Generated at 2022-06-21 06:16:23.535224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:16:34.515574
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        # the first constructor argument is expected to be `loader`,
        # the second constructor argument is expected to be `templar`
        # it is wired in `ansible/plugins/lookup/__init__.py`
        lookup_module = LookupModule(None, None)
        result = lookup_module.run(["{{undefined_var}}"], None)
        assert result == [['undefined_var']]
        result = lookup_module.run([["{{undefined_var}}"]], None)
        assert result == [['undefined_var']]
    except AnsibleError as e:
        print("Unexepcted end of AnsibleError exception for undefined var: %s" % str(e))
        assert False
    assert True


# Generated at 2022-06-21 06:16:40.535631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    my_list = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    result = lookup_module.run(my_list)
    print(result)
    assert result == [
        ['alice', 'clientdb'],
        ['alice', 'employeedb'],
        ['alice', 'providerdb'],
        ['bob', 'clientdb'],
        ['bob', 'employeedb'],
        ['bob', 'providerdb']
    ], "LookupModule.run has failed"


# Generated at 2022-06-21 06:16:53.080501
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_object = LookupModule()

    # ValueError exception is raised when you pass an empty list to pop()
    # method of the list class
    with pytest.raises(ValueError):
        test_object.run([])

    # AnsibleError exception is raised when nested parameters do not
    # have elements in the nested list
    with pytest.raises(AnsibleError):
        test_object.run(
            [],
            dict(
                ansible_nested=[
                    {}
                ]
            )
        )

    # AnsibleError exception is raised when nested parameters do not
    # have elements in the nested list

# Generated at 2022-06-21 06:16:55.065119
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:17:00.952504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run([ ['a', 'b', 'c'], [1, 2, 3] ]) == [ ['a', 1], ['a', 2], ['a', 3], ['b', 1], ['b', 2], ['b', 3], ['c', 1], ['c', 2], ['c', 3] ]

# test_LookupModule_run('no input')

# Generated at 2022-06-21 06:17:04.413331
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()

# Unit tests for _lookup_variables. All of the element in terms are list.

# Generated at 2022-06-21 06:17:11.792423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup._combine([1,2], ['a','b'])
    assert result == [[1, 'a'], [2, 'a'], [1, 'b'], [2, 'b']]
    result = lookup._combine([1], ['a','b'])
    assert result == [[1, 'a'], [1, 'b']]
    result = lookup._combine([1], ['a'])
    assert result == [[1, 'a']]
    result = lookup._combine([1,2], ['a'])
    assert result == [[1, 'a'], [2, 'a']]


# Generated at 2022-06-21 06:17:12.705023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True


# Generated at 2022-06-21 06:17:21.259357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    l = LookupModule()
    l.set_options({'_raw': [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]})
    if PY3:
        result = l.run(['_raw'], variables={})
    else:
        result = l.run(['_raw'], variables={})

    assert result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'],
                      ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

# Generated at 2022-06-21 06:17:23.669446
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:17:25.021774
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()



# Generated at 2022-06-21 06:17:32.226726
# Unit test for constructor of class LookupModule
def test_LookupModule():
  l = LookupModule()
  assert isinstance(l, LookupModule)

# # Test the run method on a simple list
# def test_lookup_module_run():
#   result = []
#   l = LookupModule()
#   result = l.run([['a','b'],['c','d']])
#   assert result == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]
#
# # Test the run method on a simple list with a variable
# def test_lookup_module_run_variable():
#   l = LookupModule()
#   result = l.run([['a','b'],['{{ test }}']], dict(test='c'))
#   assert result == [['a', 'c'], ['b',

# Generated at 2022-06-21 06:17:34.280188
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-21 06:17:35.792198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 06:17:37.832430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:17:39.011348
# Unit test for constructor of class LookupModule
def test_LookupModule():
  l = LookupModule()

# Generated at 2022-06-21 06:17:50.508188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems

    nested_data = [
        [u'a', u'b'],
        [1, 2, 3]
    ]

    # Unit test result
    expected_result = [
        [u'a', 1],
        [u'a', 2],
        [u'a', 3],
        [u'b', 1],
        [u'b', 2],
        [u'b', 3]
    ]

    test_class = LookupModule()
    my_result = test_class.run(terms=nested_data)

    # Test if result is the expected list length
    assert len(my_result) is len(expected_result)

    # Test if resul is the expected list
    assert my_result == expected_result

# Generated at 2022-06-21 06:17:58.291055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inputLists = [['a', 'b'], ['c', 'd']]
    local_list = [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]
    l = LookupModule()
    l.run(inputLists)
    output = l.run(inputLists)
    assert(output == local_list)
    return



# Generated at 2022-06-21 06:18:00.561214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    lm = LookupModule()
    assert isinstance(lm, LookupBase)


# Generated at 2022-06-21 06:18:02.415099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run(None, {}, **{})

# Generated at 2022-06-21 06:18:09.640894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Test method run of class LookupModule by populating a list
    # and applying with_nested to outer elements
    print('')
    print('Test Case 1:')
    user_list = ['user1', 'user2', 'user3']
    db_list = ['db1', 'db2', 'db3']
    nested_list = [user_list, db_list]
    nested = LookupModule()
    print('Before running with_nested: {}'.format(nested_list))
    print('After running with_nested: {}'.format(nested.run(nested_list)))


# Generated at 2022-06-21 06:18:17.132650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda x: "."
    terms = [[1,2,3],['a','b']]
    result = l.run(terms)
    assert result == [[1,'a'],[1,'b'],[2,'a'],[2,'b'],[3,'a'],[3,'b']]


# Generated at 2022-06-21 06:18:19.562113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    my_list = [["user1", "user2"], ["db1", "db2"]]
    result = lookup_module.run(my_list)
    assert result == [["user1", "db1"], ["user1", "db2"], ["user2", "db1"], ["user2", "db2"]]

# Generated at 2022-06-21 06:18:30.340434
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("***Begin Test***")
    sample_list1 = ['alice', 'bob']
    sample_list2 = ['clientdb', 'employeedb', 'providerdb']
    sample_list3 = ['alice', 'bob', 'clientdb', 'employeedb', 'providerdb']
    lookup_result = LookupModule().run([sample_list1, sample_list2])
    assert isinstance(lookup_result, list)
    assert lookup_result == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], \
                             ['bob', 'employeedb'], ['bob', 'providerdb']]
    print("***End Test***")

# Generated at 2022-06-21 06:18:33.381234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:18:38.403123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests:
    # with_nested:
    #   - ["A", "B"]
    #   - ["a", "b", "c"]
    # should return [["Aa", "Ab", "Ac"], ["Ba", "Bb", "Bc"]]
    lookup_module = LookupModule()
    result = lookup_module.run([["A", "B"], ["a", "b", "c"]], None, None)
    assert result == [["Aa", "Ab", "Ac"], ["Ba", "Bb", "Bc"]]

# Generated at 2022-06-21 06:18:48.980673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    templar = Templar(loader=None, variables={})
    lookup_module = LookupModule(loader=None, templar=templar)
    # Act
    result = lookup_module.run([[1, 2, 3], [4, 5, 6], [7, 8, 9]], {})
    # Assert
    assert result == [[4, 7], [4, 8], [4, 9], [5, 7], [5, 8], [5, 9], [6, 7], [6, 8], [6, 9]]



# Generated at 2022-06-21 06:18:59.166560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    result = lookup._lookup_variables([[['a','b'],['c','d']],[['e','f'],['g','h']]],None)
    assert result == [['a','b','c','d'],['e','f','g','h']]
    result = lookup._combine([['a','b'],['c','d']],['e','f'])
    assert result == [['a', 'b', 'e'], ['a', 'b', 'f'], ['c', 'd', 'e'], ['c', 'd', 'f']]
    result = lookup._combine([['a'],['c'],['d']],['e'])
    assert result == [['a', 'e'], ['c', 'e'], ['d', 'e']]

# Generated at 2022-06-21 06:19:05.576107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [[1, 2], [3, 4]]
    assert lookup.run(terms) == [[3, 1], [3, 2], [4, 1], [4, 2]]
    terms = [1, 2]
    assert lookup.run(terms) == [1, 2]

# Generated at 2022-06-21 06:19:13.030757
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

    # Check that an error is raised if no terms are passed to the lookup
    try:
        l.run([])
    except AnsibleError as e:
        assert "with_nested requires at least one element in the nested list" in str(e)

    # Check that the cross product is computed correctly
    assert l.run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]

    # Check that empty lists are ignored
    assert l.run([[], [3, 4]]) == [[3], [4]]
    assert l.run([[1], []]) == []

    # Check that scalars are not nested into lists
    assert l.run([[1], 2]) == [[1, 2]]

    # Check that nested

# Generated at 2022-06-21 06:19:25.282695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a set of nested list
    lookup_module = LookupModule()
    test_list = [
        [ "this", "that", "other" ],
        [ "one", "two", "three" ],
    ]
    result = lookup_module.run(terms=test_list, variables=None, **{})
    assert [["this", "one"], ["this", "two"], ["this", "three"], ["that", "one"], ["that", "two"], ["that", "three"], ["other", "one"], ["other", "two"],
            ["other", "three"]] == result

    # Test with a two elements list, first one a list and second one a string (not a list)
    test_list = [
        [ "one", "two", "three" ],
        "four"
    ]
    result = lookup_

# Generated at 2022-06-21 06:19:32.690401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    inputlist = [
      [ "alice", "bob" ],
      [ "clientdb", "employeedb", "providerdb" ]
    ]
    result = module.run(inputlist)
    expected_result = [
      [ 'alice', 'clientdb' ],
      [ 'alice', 'employeedb' ],
      [ 'alice', 'providerdb' ],
      [ 'bob', 'clientdb' ],
      [ 'bob', 'employeedb' ],
      [ 'bob', 'providerdb' ]
    ]
    assert result == expected_result


# Generated at 2022-06-21 06:19:35.350817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:19:42.880291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test function for module LookupModule

    Parameters
    ----------
    terms : list of expression elements
    variables : list of variables
    kwargs : additional arguments

    Returns
    -------
    nothing
    """
    module = LookupModule()
    test_terms = [['alice','bob'],['clientdb','providerdb','employeedb']]
    test_variables = {}
    test_kwargs = {}

    result = module.run(test_terms,test_variables,**test_kwargs)
    expected_result = [['alice', 'clientdb'], ['alice', 'providerdb'], ['alice', 'employeedb'],
                       ['bob', 'clientdb'], ['bob', 'providerdb'], ['bob', 'employeedb']]

# Generated at 2022-06-21 06:19:43.543842
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:19:51.114576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with_nested:
    #
    # Test 1:
    #
    # Nested lists of a single item each
    #
    # Expected output:
    #
    # [['a1', 'a2'], ['b1', 'b2']]
    #

    lookup_obj = LookupModule()
    terms = [['a1', 'a2'], ['b1', 'b2']]

    result = lookup_obj.run(terms)
    assert result == [['a1', 'b1'], ['a1', 'b2'], ['a2', 'b1'], ['a2', 'b2']]

    #
    # Test 2:
    #
    # Nested lists of two items
    #
    # Expected output:
    #
    # [['a1', '

# Generated at 2022-06-21 06:19:54.873483
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Check that LookupModule class can be instantiated"""
    lookup_module_object = LookupModule()
    assert lookup_module_object != None

# Generated at 2022-06-21 06:20:03.958402
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_params = { "terms": [
            [ 'alice', 'bob' ],
            [ 'clientdb', 'employeedb', 'providerdb' ]
        ],
        'variables': {},
        '_templar': None,
        '_loader': None
    }
    l = LookupModule(**lookup_params)
    assert l is not None
    assert l.run(**lookup_params) == [['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb']]

# Unit test to test function run() of class LookupModule

# Generated at 2022-06-21 06:20:14.404966
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a new instance of LookupModule
    lm = LookupModule()

    # Create a simple list with the first element a string, the rest a list
    test_terms = [
        'first',
        ['second', 'third']
    ]

    # Expect the call to lm.run() to return a flat list
    assert lm.run(test_terms) == [
        'first', 'second', 'third'
    ]

    # Create another list with the first element a list, the second element a string, the rest a list
    test_terms = [
        ['first', 'first_and_a_half'],
        'second',
        ['third', 'third_and_a_half']
    ]

    # Expect the call to lm.run() to return a flat list

# Generated at 2022-06-21 06:20:15.582433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()



# Generated at 2022-06-21 06:20:16.537294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()


# Generated at 2022-06-21 06:20:18.987728
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule



# Generated at 2022-06-21 06:20:29.312503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with variable
    lookup_plugin = LookupModule()
    terms = [
                [
                    'alice',
                    'bob',
                    '{{ myvar}}'
                ],
                [
                    'clientdb',
                    'employeedb',
                    'providerdb'
                ]
            ]

    myvar = 'curt'
    variables = {'myvar': myvar}

    result = lookup_plugin.run(terms, variables)

# Generated at 2022-06-21 06:20:40.872018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    lockup_module = LookupModule()
    terms = [["a","b","c"],["1","2","3"],["x","y","z"]]
    result = lockup_module.run(terms)
    assert(len(result) == 9)
    assert(["a","1","x"] in result)
    assert(["a","1","y"] in result)
    assert(["a","1","z"] in result)
    assert(["a","2","x"] in result)
    assert(["a","2","y"] in result)
    assert(["a","2","z"] in result)
    assert(["a","3","x"] in result)
    assert(["a","3","y"] in result)

# Generated at 2022-06-21 06:20:43.718594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def _test_empty(lm):
        try:
            lm.run([])
            assert False
        except AnsibleError:
            assert True

    _test_empty(LookupModule())

# Generated at 2022-06-21 06:20:44.486292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()



# Generated at 2022-06-21 06:20:53.754615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that a simple example works
    templar = DummyTemplar()
    loader = DummyLoader()
    user_list = [
        [ "alice", "bob" ],
        [ "clientdb", "employeedb", "providerdb" ],
    ]
    lookup_instance = LookupModule(templar=templar, loader=loader)
    result = lookup_instance.run(terms=user_list, variables=dict())
    # pprint.pprint(result)
    assert result == [
            ["alice", "clientdb"],
            ["alice", "employeedb"],
            ["alice", "providerdb"],
            ["bob", "clientdb"],
            ["bob", "employeedb"],
            ["bob", "providerdb"],
        ]

    # Test that

# Generated at 2022-06-21 06:20:56.339073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = __import__('ansible.plugins.lookup.nested')
    LookupModule = getattr(module, 'LookupModule')
    LookupModule()


# Generated at 2022-06-21 06:21:01.087082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        'foo',
        'bar',
        'baz',
    ]

    result = [
        ['foo'],
        ['bar'],
        ['baz'],
    ]
    instance = LookupModule()
    assert instance._lookup_variables(terms, {}) == result

# Generated at 2022-06-21 06:21:11.465157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method LookupModule.run"""

# Generated at 2022-06-21 06:21:16.153814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# this is taken from the with_items/flat.py lookup plugin in Ansible
# as it is not in the public API (yet?)

# Generated at 2022-06-21 06:21:18.891905
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print (LookupModule())

# Generated at 2022-06-21 06:21:25.699088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    x = [['alice', 'bob'], ['clientdb', 'employeedb', 'providerdb']]
    results = l.run(x)

    assert len(results) == 6
    assert ['alice', 'clientdb'] in results
    assert ['alice', 'employeedb'] in results
    assert ['alice', 'providerdb'] in results
    assert ['bob', 'clientdb'] in results
    assert ['bob', 'employeedb'] in results
    assert ['bob', 'providerdb'] in results

# Generated at 2022-06-21 06:21:37.643457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test of method run in class LookupModule"""
    print("Test of method run in class LookupModule")

    # External library imports
    import ansible.plugins.lookup.nested
    import os

    # Creating an instance of class LookupModule
    lm = ansible.plugins.lookup.nested.LookupModule()

    # Creating test input
    # with_nested:
        # - [ 'alice', 'bob' ]
        # - [ 'clientdb', 'employeedb', 'providerdb' ]
    l1 = [ 'alice', 'bob' ]
    l2 = [ 'clientdb', 'employeedb', 'providerdb' ]

    # Getting expected result
    file_path = os.path.dirname(os.path.realpath(__file__))
    file_path

# Generated at 2022-06-21 06:21:39.556467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert cls != None

# Generated at 2022-06-21 06:21:45.328382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = [['a','b','c'],[1,2,3]]
    result = lookup_module.run(terms)

    assert result == [['a',1],['a',2],['a',3],['b',1],['b',2],['b',3],['c',1],['c',2],['c',3]], "Result is not correct, it returns: %s " % result

# Generated at 2022-06-21 06:21:54.013446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiation of class LookupModule
    lookup_module = LookupModule()
    #
    terms = [
        [
            {'output': '{{ foo }}'},
            {'output': '{{ bar }}'},
            {'output': '{{ baz }}'},
        ],
        [
            'foo1',
            'bar1',
        ],
        [
            'foo2',
            'bar2',
            'baz2',
            'bax2',
        ],
    ]
    #
    # Call of method run
    result = lookup_module.run(terms, variables=dict(
        foo='foo',
        bar='bar',
        baz='baz',
    ))
    assert result[0] == {'output': 'foo'}

# Generated at 2022-06-21 06:21:55.447513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 06:22:05.957583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myLookup = LookupModule()
    myLookup.get_basedir = lambda: '~/'

# Generated at 2022-06-21 06:22:13.893095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [["A1","A2","A3"],["B1","B2","B3","B4","B5"],["C1","C2"]]
    result = lookup_module.run(terms)

# Generated at 2022-06-21 06:22:23.726759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    # List of 1 element
    my_list = [['alice']]
    nested = LookupModule()
    result = nested.run(terms=my_list)
    assert result == [['alice']]

    # Test 2
    # List of 2 elements
    my_list = [['alice'], ['secret']]
    nested = LookupModule()
    result = nested.run(terms=my_list)
    assert result == [['alice', 'secret']]

    # Test 3
    # List of 2 elements of 1 element
    my_list = [['alice'], ['secret']]
    nested = LookupModule()
    result = nested.run(terms=my_list)
    assert result == [['alice', 'secret']]

    # Test 4
    # List of list of

# Generated at 2022-06-21 06:22:29.208932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class LookupModuleTester(LookupModule):
        def _combine(self, a, b):
            return [a,b]
        def _flatten(self, a):
            return a
    return LookupModuleTester

# Generated at 2022-06-21 06:22:29.832606
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:22:31.349947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance



# Generated at 2022-06-21 06:22:41.853302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with_nested parameters
    nested_lists1 = [["a", "b", "c"], ["1", "2", "3"]]
    nested_lists2 = [["a", "b", "c"]]
    nested_lists3 = []
    lookup_params1 = [nested_lists1, "xyz"]
    lookup_params2 = [nested_lists2, "xyz"]
    lookup_params3 = [nested_lists3, "xyz"]
    # expected results
    expected_result1 = [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3'], ['c', '1'], ['c', '2'], ['c', '3']]

# Generated at 2022-06-21 06:22:43.737441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # look up module is created.
    LookupModule()



# Generated at 2022-06-21 06:22:54.924209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({})
    terms = [["1", "2", "3"], ["a","b","c"], ["x", "y", "z"]]
    result = l.run(terms)

# Generated at 2022-06-21 06:23:02.899711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
             [
              [ "admin", "guest" ],
              [ "all", "user" ]
             ],
             [
              [ "read", "write" ],
              [ "execute" ]
             ]
    ]
    look = LookupModule()
    result = look.run(terms)

# Generated at 2022-06-21 06:23:05.469852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_list = ['a', 'b', 'c']
    assert my_list is not None



# Generated at 2022-06-21 06:23:12.928673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            'alice', 'bob'
        ],
        [
            'clientdb', 'employeedb', 'providerdb'
        ]
    ]
    test = LookupModule()
    test_return = test.run(terms)
    assert test_return == [
        [
            'alice', 'clientdb'
        ],
        [
            'alice', 'employeedb'
        ],
        [
            'alice', 'providerdb'
        ],
        [
            'bob', 'clientdb'
        ],
        [
            'bob', 'employeedb'
        ],
        [
            'bob', 'providerdb'
        ]
    ]



# Generated at 2022-06-21 06:23:14.015309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-21 06:23:17.410669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 06:23:19.683384
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-21 06:23:22.730661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule """
    lookup_module = LookupModule()
    terms = [["demo1"], ["demo2"]]
    result = lookup_module.run(terms)
    assert result is not None



# Generated at 2022-06-21 06:23:24.633446
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None



# Generated at 2022-06-21 06:23:26.584714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None, "Class LookupModule should be object not None"


# Generated at 2022-06-21 06:23:30.314658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    input_list = [['a', 'b'], ['1', '2']]
    expected_output = [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2']]
    actual_output = lookup_module.run(input_list)
    assert actual_output == expected_output



# Generated at 2022-06-21 06:23:41.423481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = [ ['a','b','c'],[1,2,3],[0,1] ]
    result = module.run(terms, None)
    assert result == [['a', 0], ['a', 1], ['b', 0], ['b', 1], ['c', 0], ['c', 1]]

    # 2 dimensional with one empty list
    terms = [ ['a','b','c'],[] ]
    result = module.run(terms, None)
    assert result == [['a'], ['b'], ['c']]

    # expected empty result
    terms = [ [],[],[] ]
    result = module.run(terms, None)
    assert result == []

    # empty list
    terms = []
    result = module.run(terms, None)
    assert result == []

    # 3

# Generated at 2022-06-21 06:23:51.410809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    prog = 'nested'
    test = LookupModule(None)
    test._templar = None
    test._loader = None
    term_list = [
        [
            [['test1', 'test2', 'test3'], ['test4', 'test5', 'test6']],
            [
                [['test7'], ['test8']],
                [['test9']],
            ],
            [[['test10', 'test11']]]
        ]
    ]
    result = test.run(term_list)

# Generated at 2022-06-21 06:23:58.525971
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Given
    import __builtin__
    class DummyModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            self.called = True
            self.fail_args = args
            self.fail_kwargs = kwargs

    class AnsibleMock(object):
        def __init__(self):
            self.run_errors = {
                'fail_json.called': False,
            }
    __builtin__.module = DummyModule()
    __builtin__.ansible = AnsibleMock()


# Generated at 2022-06-21 06:24:06.792477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule._combine([1],[2])== [[1, 2]]
    assert LookupModule._combine([1, 2], [3, 4]) == [[1, 3], [1, 4], [2, 3], [2, 4]]
    assert LookupModule._combine([[1, 2]], [3, 4]) == [[1, 2, 3], [1, 2, 4]]
    assert LookupModule._combine([[1, 2, 3]], [4]) == [[1, 2, 3, 4]]
    assert LookupModule._combine([[1, 2, 3]], [4, 5]) == [[1, 2, 3, 4], [1, 2, 3, 5]]

# Generated at 2022-06-21 06:24:19.231221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fl = LookupModule()
    result = fl.run([['test1', 'test2'], ['test3', 'test4']])
    assert(result == [[u'test1', u'test3'], [u'test1', u'test4'], [u'test2', u'test3'], [u'test2', u'test4']])
    # Test with list of objects (e.g. Jinja2)
    result = fl.run([['test1', 'test2'], {u'test3': 3}, ['test4', 'test5']])