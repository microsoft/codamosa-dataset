

# Generated at 2022-06-21 06:14:14.265407
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()


# Generated at 2022-06-21 06:14:15.666811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)


# Generated at 2022-06-21 06:14:25.469023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [ [ 'alice' , 'bob' ], [ 'clientdb', 'employeedb', 'providerdb' ]]
    return_val = lookup.run(terms)
    assert return_val == [ ['alice', 'clientdb'], ['alice', 'employeedb'], ['alice', 'providerdb'],
                           ['bob', 'clientdb'], ['bob', 'employeedb'], ['bob', 'providerdb'] ]


# Generated at 2022-06-21 06:14:26.504497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:14:28.063233
# Unit test for constructor of class LookupModule
def test_LookupModule():
    r = LookupModule()
    assert r is not None

# Generated at 2022-06-21 06:14:39.936340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   # Arrange
   # Create list of list of strings to use as input to run method
   list_of_list_of_string = [
                                [ 'alice', 'bob' ],
                                [ 'clientdb', 'employeedb', 'providerdb' ]
                             ]

   lookup_module = LookupModule()

   # Act
   actual_result = lookup_module.run(list_of_list_of_string)

   # Assert
   expected_result = [
                        ['alice', 'clientdb'],
                        ['alice', 'employeedb'],
                        ['alice', 'providerdb'],
                        ['bob', 'clientdb'],
                        ['bob', 'employeedb'],
                        ['bob', 'providerdb']
                     ]

   assert actual_result == expected_result

# Generated at 2022-06-21 06:14:42.026136
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module.run([['a','b','c'],['d','e','f']]))

# Generated at 2022-06-21 06:14:52.458935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assertEqual to check result equals expected result
    # assertNotEqual to check result doesn't equal unexpected result
    # assertRaises to check if an exception is raised (and if so, if the exception matches a given exception)
    # assertTrue to check that an expression is true
    # assertFalse to check that an expression is false
    # assertIsInstance to check if a given object is an instance of a given class
    # assertDictContainsSubset to check if a given dict is a superset of another given dict

    module = LookupModule()
    # Test if an exception is raised (and if so, if the exception matches a given exception)
    assertRaises(AnsibleError, module.run, [])


# Generated at 2022-06-21 06:14:55.520677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == LookupModule().run([[1,2,3]])[0]


# Unit tests for combine

# Generated at 2022-06-21 06:15:04.426675
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create test variables
    ans_var = { 'ans_var' : ['one', 'two', 'three'] }

    # Create test data
    test_list = [ [ 'a', 'b', 'c' ] , [ '1', '2', '3' ] ]

    # Create instance of LookupModule
    lookup_instance = LookupModule()

    # Create expected results
    expected_result = [ ['a', '1'], ['b', '1'], ['c', '1'], ['a', '2'], ['b', '2'], ['c', '2'], ['a', '3'], ['b', '3'], ['c', '3'] ]

    # Test LookupModule._combine method
    actual_result = lookup_instance._combine(test_list[0], test_list[1])


# Generated at 2022-06-21 06:15:11.190596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule(loader=None,templar=None,shared_loader_obj=None).run([['1','2','3'],['a','b']])
    assert result == [['1', 'a'], ['1', 'b'], ['2', 'a'], ['2', 'b'], ['3', 'a'], ['3', 'b']], "Failed to compose a proper list"

# Generated at 2022-06-21 06:15:21.068448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
      Test case to demonstrate the functionality of method run
    '''

    terms = ['[a,b,c]','[1,2,3]']
    lookup_result = LookupModule().run(terms)
    assert lookup_result == [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3'], ['c', '1'], ['c', '2'], ['c', '3']]

    terms = ['[a,b,c]']
    lookup_result = LookupModule().run(terms)
    assert lookup_result == [['a'], ['b'], ['c']]

# Generated at 2022-06-21 06:15:22.625143
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()


# Generated at 2022-06-21 06:15:31.342589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        ['Alice', 'Bob', 'Carol'],
        ['ClientDB', 'EmployeeDB', 'ProviderDB'],
        [5,6,7,8,9]
    ]


# Generated at 2022-06-21 06:15:40.098416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_name = 'nested'
    lookup_name = 'nested'
    lookup = LookupModule(basedir=None, runner=None, verbosity=0, all_vars=None, runner_vars=None, templar=None, vault_password=None,
                          loader=None, paths=None, module_name=module_name, lookup_name=lookup_name)
    assert lookup.module_name == module_name
    assert lookup.lookup_name == lookup_name

# Generated at 2022-06-21 06:15:50.783724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    terms = [
        "{{ lookup('env', 'HOME') }}/{{ ansible_distribution }}",
        "{{ lookup('env', 'HOME') }}/{{ ansible_distribution_release }}"
    ]
    env = os.environ
    env.update({
        'HOME': '/home/ansible',
        'ansible_distribution': 'debian',
        'ansible_distribution_release': 'jessie'
    })
    result = L.run(terms, variables=env)
    expected_result = [
        ['/home/ansible/debian', '/home/ansible/jessie']
    ]
    assert result == expected_result


# Generated at 2022-06-21 06:16:03.149590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule - Compose a list of lists with nested lists"""
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.vault import VaultLib

    terms=[['monday', 'tuesday', 'wednesday'], ['morning', 'afternoon']]

    lookup_module = LookupModule()
    result = lookup_module.run(terms)

    assert result == [['monday', 'morning'], ['monday', 'afternoon'], ['tuesday', 'morning'], ['tuesday', 'afternoon'], ['wednesday', 'morning'], ['wednesday', 'afternoon']]

    lookup_module = LookupModule()
    result = lookup_module.run([[1, 2, 3, 4, 5]])


# Generated at 2022-06-21 06:16:06.426014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    argument_spec = dict(
        _raw=dict(required=True),
    )
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:16:07.258326
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:16:15.882354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    result = lm.run([[1, 2], [3, 4]], variables=dict())
    assert result == [[1, 3], [1, 4], [2, 3], [2, 4]]

    result = lm.run([[1, 2], ['a', 'b']], variables=dict())
    assert result == [[1, 'a'], [1, 'b'], [2, 'a'], [2, 'b']]

    result = lm.run([[1, 2], ['a'], [3, 4]], variables=dict())
    assert result == [[1, 'a', 3], [1, 'a', 4], [2, 'a', 3], [2, 'a', 4]]


# Generated at 2022-06-21 06:16:27.187178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    input = [["a","b"],["1","2","3"],["I","II"]]
    real_result = lm.run(input)
    expected_result = [['a', '1', 'I'], ['a', '1', 'II'], ['a', '2', 'I'], ['a', '2', 'II'], ['a', '3', 'I'], ['a', '3', 'II'], ['b', '1', 'I'], ['b', '1', 'II'], ['b', '2', 'I'], ['b', '2', 'II'], ['b', '3', 'I'], ['b', '3', 'II']]
    assert real_result == expected_result


# Generated at 2022-06-21 06:16:31.006302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with undefined variables
    terms = [["{{ user }}"], ["dbserver1", "dbserver2", "dbserver3"]]
    variables = {"user": "carl"}

    test_obj = LookupModule()
    result = test_obj.run(terms, variables)
    # As the user variable is defined inside of the nested list, no error will be raised
    assert result == [["carl", "dbserver1"], ["carl", "dbserver2"], ["carl", "dbserver3"]]

    variables = {}
    test_obj = LookupModule()
    try:
        test_obj.run(terms, variables)
        assert False
    except AnsibleUndefinedVariable:
        assert True

    # The next test will check if a single nested list is correctly converted to a list of lists
    terms

# Generated at 2022-06-21 06:16:35.366868
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.module_utils.six.moves import StringIO

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    lookup_under_test = LookupModule()

    yaml_text = StringIO("""
        - name: give users access to multiple databases
          mysql_user:
            name: "{{ item[0] }}"
            priv: "{{ item[1] }}.*:ALL"
            append_privs: yes
            password: "foo"
          with_nested:
            - [ 'alice', 'bob' ]
            - [ 'clientdb', 'employeedb', 'providerdb' ]
    """)
    vault_pass = 'asdf'

# Generated at 2022-06-21 06:16:45.619454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run method of LookupModule
    """
    # pylint: disable=protected-access
    obj = LookupModule()
    terms = [[1, 2, 3], [11, 12, 13], [21, 22, 23]]

# Generated at 2022-06-21 06:16:55.155161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([['a'], ['b', 'c']]) == [['a', 'b'], ['a', 'c']]
    assert module.run([['a'], ['b', 'c'], ['d']]) == [['a', 'b', 'd'], ['a', 'c', 'd']]
    assert module.run([['a'], ['b', 'c'], ['d', 'e']]) == [['a', 'b', 'd'], ['a', 'b', 'e'], ['a', 'c', 'd'], ['a', 'c', 'e']]
    assert module.run([['a'], [], ['d', 'e']]) == [['a', 'd'], ['a', 'e']]

# Generated at 2022-06-21 06:16:56.702167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 06:16:58.975277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    km = LookupModule()
    km.run([[2, 3], [4, 5, 6]])

# Generated at 2022-06-21 06:17:07.509843
# Unit test for constructor of class LookupModule
def test_LookupModule():
    src = '''
        - name: test
          hosts: localhost
          gather_facts: no
          connection: local
          tasks:
            - name: Test
              debug:
                msg: "{{ item }}"
              with_nested:
                - [ 'Hello', 'My' ]
                - [ 'World', "what's" ]
                - [ 'up' ]
    '''
    mod = LookupModule()
    mod.run([src])

# Generated at 2022-06-21 06:17:10.528862
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Construct an object of class LookupModule
    lookup_obj = LookupModule()
    assert lookup_obj



# Generated at 2022-06-21 06:17:11.395697
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 06:17:16.575616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:17:22.933135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        [ 'alice', 'bob' ],
        [ 'clientdb', 'employeedb', 'providerdb' ]
    ]

    try:
        lookup._lookup_variables(terms, None)
    except AnsibleUndefinedVariable as e:
        assert False, 'Test LookupModule._lookup_variables method - Exception raised: ' + e.message

    result = lookup.run(terms)

    assert len(result) == 6, 'Test LookupModule.run method - value not expected. Expected 6, got ' + str(len(result))

# Generated at 2022-06-21 06:17:28.900726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    # Test input for nested function
    test_terms = [
        ["a", "b", "c"],
        ["1", "2"],
        ["d", "e"]
    ]
    test_variables = []
    result_nested = module.run(test_terms, test_variables)

# Generated at 2022-06-21 06:17:40.970308
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:17:49.509654
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert len(l.run([[['a'], ['b'], ['c']], [['1'], ['2']]])) == 6
    assert len(l.run([[['a'], ['b'], ['c']]])) == 3
    assert len(l.run([[[1], [2], [3]], [['a'], ['b']]])) == 6
    assert len(l.run([[[1], ['a']], [[2], ['b']]])) == 2


# Unit tests for _combine function of class LookupModule

# Generated at 2022-06-21 06:17:56.798074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    my_list = [['a', 'b', 'c'], ['d', 'e'], 'f']
    l._combine(my_list[0], my_list[1])
    l._combine(my_list[1], my_list[0])
    l._flatten(my_list[1])

# Generated at 2022-06-21 06:17:58.248788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None



# Generated at 2022-06-21 06:18:06.606984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    terms = [[["a", "b"], ["c", "d"]], ["x", "y"]]
    result = lm.run(terms)
    assert result == [['ax', 'ay'], ['bx', 'by'], ['cx', 'cy'], ['dx', 'dy']]

    terms = [[["a", "b"], ["c", "d"]], ["x", "y", "z"]]
    result = lm.run(terms)
    assert result == [['ax', 'ay', 'az'], ['bx', 'by', 'bz'], ['cx', 'cy', 'cz'], ['dx', 'dy', 'dz']]

# Generated at 2022-06-21 06:18:08.077926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()
    pass

# Generated at 2022-06-21 06:18:11.563358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]



# Generated at 2022-06-21 06:18:19.783738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    temp = LookupModule()
    assert temp.run([['Alice', 'Bob'], ['foo', 'bar']]) == [['Alice', 'foo'], ['Alice', 'bar'], ['Bob', 'foo'], ['Bob', 'bar']]
    assert temp.run([[1, 2], [3, 4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]

# Generated at 2022-06-21 06:18:21.202870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:18:31.278242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # test class LookupModule
    obj = LookupModule()

    # test the function _flatten
    list1 = [1, 2, [3, 4]]
    list2 = obj._flatten(list1)
    assert list2 == [1, 2, 3, 4]

    # test the function _combine
    list3 = ['a', 'b']
    list4 = ['c', 'd', 'e']
    list5 = obj._combine(list3, list4)
    assert list5 == [['a', 'c'], ['a', 'd'], ['a', 'e'], ['b', 'c'], ['b', 'd'], ['b', 'e']]

    # test the function _lookup_variables

# Generated at 2022-06-21 06:18:37.363283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run([], None, **{})
    except AnsibleError as e:
        assert e.message == "with_nested requires at least one element in the nested list"
    else:
        raise Exception("AnsibleError was not raised")


# Generated at 2022-06-21 06:18:47.224642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([[1,2],[3,4]]) == [[1, 3], [1, 4], [2, 3], [2, 4]]
    assert module.run([[1,2],['a','b','c']]) == [[1, 'a'], [1, 'b'], [1, 'c'], [2, 'a'], [2, 'b'], [2, 'c']]


# Generated at 2022-06-21 06:18:58.451734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()

    assert L.run([[[1]],[[2]]]) == [[1,2]]
    assert L.run([[[1]],[[2]],[[3]]]) == [[1,2,3]]
    assert L.run([[[1,11]],[[2]],[[3]]]) == [[1,2,3],[11,2,3]]
    assert L.run([[[1,11]],[[2,22]],[[3,33]]]) == [[1,2,3],[1,22,3],[11,2,3],[11,22,3],[1,2,33],[1,22,33],[11,2,33],[11,22,33]]


# Generated at 2022-06-21 06:19:10.762496
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = [['a', 'b', 'c'], [1, 2, 3], ['x', 'y', 'z']]

# Generated at 2022-06-21 06:19:15.581626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    terms = ['127.0.0.1', '192.168.1.10']
    l = LookupModule(terms)
    assert l is not None


# Generated at 2022-06-21 06:19:22.095804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            "Alice",
            "Bob",
            "Charlie",
        ],
        [
            "clientdb",
            "employeedb",
            "providerdb",
        ],
    ]
    x = LookupModule()
    print(x.run(terms))

if __name__ == '__main__':
    args = ["Alice", "clientdb", "Bob", "employeedb", "Charlie", "providerdb"]
    test_LookupModule_run()

# Generated at 2022-06-21 06:19:31.673915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myLookupModule = LookupModule()
    myLookupModule.run(['[ ["foo","bar","baz"], ["apples","oranges","lemons"] ]'])
    output = [
        ['foo', 'apples'],
        ['bar', 'apples'],
        ['baz', 'apples'],
        ['foo', 'oranges'],
        ['bar', 'oranges'],
        ['baz', 'oranges'],
        ['foo', 'lemons'],
        ['bar', 'lemons'],
        ['baz', 'lemons'],
    ]
    assert myLookupModule.run(['[ ["foo","bar","baz"], ["apples","oranges","lemons"] ]']) == output

# Generated at 2022-06-21 06:19:42.758374
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()

    terms = [
              [],
              []
            ]
    with pytest.raises(AnsibleError):
        lookup_module.run(None, terms)

    terms = [
              [
                [1,2,3]
              ],
              []
            ]
    assert lookup_module.run(None, terms) == [[1, 2, 3]]

    terms = [
              [
                [1,2,3]
              ],
              [
                [4,5,6]
              ]
            ]
    assert lookup_module.run(None, terms) == [
                                                [1, 2, 3, 4],
                                                [1, 2, 3, 5],
                                                [1, 2, 3, 6]
                                            ]


# Generated at 2022-06-21 06:19:48.725533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Method run of class LookupModule
    L = LookupModule()
    l = [["user1", "user2"], ["db1", "db2"]]
    result = L.run(l, {})
    #  Expected result
    l_run = [['user1', 'db1'], ['user1', 'db2'], ['user2', 'db1'], ['user2', 'db2']]
    print(result)
    print(l_run)
    assert(result == l_run)

# Generated at 2022-06-21 06:19:52.210493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Unit tests for method _lookup_variables

# Generated at 2022-06-21 06:20:02.839383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(["foo","bar","zap","blam"], None)
    assert result == [['foo', 'bar', 'zap', 'blam']]
    result = lookup_module.run([[1,2],[3,4]], None)
    assert result == [[1,3],[1,4],[2,3],[2,4]]
    result = lookup_module.run([[1,2],[3,4],[5,6]], None)
    assert result == [[1,3,5],[1,3,6],[1,4,5],[1,4,6],[2,3,5],[2,3,6],[2,4,5],[2,4,6]]


# Generated at 2022-06-21 06:20:11.942507
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test passing a string to constructor
    test = LookupModule("foo")
    assert test is not None

    # Test passing a function to constructor
    def test_run(terms, variables=None, **kwargs):
        pass
    test = LookupModule(test_run)
    assert test is not None

    # Test passing a function to constructor with a single argument
    test = LookupModule(test_run, "foo")
    assert test is not None

    # Test passing a function to constructor with multiple arguments
    test = LookupModule(test_run, "foo", ["bar", "baz"])
    assert test is not None

# Generated at 2022-06-21 06:20:18.921965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule.

    :return: Nothing.
    '''

    import __builtin__ as builtins

    module = LookupModule()

    the_list = list(['a', 'b'])
    the_list2 = list(['x', 'y'])
    the_list3 = list(['1', '2'])
    terms = list([the_list, the_list2, the_list3])

    def _lookup_variables(terms, variables):
        return terms

    def _combine(result, my_list):
        results = []
        for a in result:
            for b in my_list:
                results.append(a + b)
        return results

    def _flatten(x):
        return x


# Generated at 2022-06-21 06:20:20.426997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# unit test for function _lookup_variables

# Generated at 2022-06-21 06:20:30.292008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    my_lookup._templar = None
    my_lookup._loader = None
    term = ["a", "b", "c"]
    my_list = [term, term]
    my_list2 = my_list[:]
    result = my_lookup.run(my_list)
    assert len(result) == len(term) * len(term), "'run' does not do proper cartesian product"
    for x in result:
        assert len(x) == len(my_list), ":'run' does not combine the lists properly"
    assert result[0] == ['a', 'a']
    result2 = my_lookup.run(my_list2 + my_list)

# Generated at 2022-06-21 06:20:41.455430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    r = l.run([[1, 2], [3, 4]])
    assert(r == ['1', '3', '2', '4'])
    r = l.run([[1, 2], [3, 4], [5, 6, 7]])
    assert(r == ['1', '3', '5', '2', '4', '6', '1', '3', '7', '2', '4', '6', '1', '3', '5', '2', '4', '7'])  # noqa
    r = l.run([[1, 2], [3, 4], [5, 6, 7], [8, 9, 10]])

# Generated at 2022-06-21 06:20:50.499578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    my_loader = DataLoader()
    my_terms = [["A", "B", "C", "D"], ["E", "F"]]
    my_combine = LookupModule()
    my_combine._templar = 'DummyTemplar'
    my_combine._loader = 'DummyLoader'
    my_result = my_combine.run(my_terms)
    assert my_result == [['A', 'E'], ['A', 'F'], ['B', 'E'], ['B', 'F'], ['C', 'E'], ['C', 'F'], ['D', 'E'], ['D', 'F']], "The generated result is not correct"


# Generated at 2022-06-21 06:20:57.911568
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dummy = {'dummy': None}
    lookup_instance = LookupModule()
    assert lookup_instance._templar is not None
    assert lookup_instance._loader is not None
    assert lookup_instance._loader.get_basedir(dummy) is None


# Generated at 2022-06-21 06:21:06.773804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['a', 'b'])
    assert result == [['a'], ['b']]
    result = LookupModule().run(['a', 'b', 'c'])
    assert result == [['a', 'b'], ['a', 'c'], ['b', 'c']]
    result = LookupModule().run(['a', 'b', 'c', 'd'])
    assert result == [['a', 'b', 'c'], ['a', 'b', 'd'], ['a', 'c', 'd'], ['b', 'c', 'd']]

# Generated at 2022-06-21 06:21:15.158750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initializing the LookupModule class
    path = os.path.dirname(os.path.realpath(__file__))
    data_path = os.path.join(path, '../../../../lib/ansible/plugins/lookup/data')
    lookup_module = LookupModule()
    lookup_module.set_options({'_data_path': data_path})

    # initializing test variables
    terms = "[['foo','bar','baz'],['hello','world','mars'],['one','two','three']]"
    variables = {}

    # testing the run method
    result = lookup_module.run(terms, variables)

# Generated at 2022-06-21 06:21:17.038269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = ["stackoverflow", "stackoverflow"]
    assert (test == [None])

    test2 = ["stackoverflow", "stackoverflow"]
    assert (test2 == [None])


# Generated at 2022-06-21 06:21:18.112320
# Unit test for constructor of class LookupModule
def test_LookupModule():
  l = LookupModule()

# Generated at 2022-06-21 06:21:27.062917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test
    from ansible.plugins.loader import lookup_loader
    lookup_loader._lookup_plugins = {'compose_list': LookupModule}
    from ansible.vars import VariableManager
    from ansible.playbook import Play

    variable_manager = VariableManager()
    play_context = dict()
    play = Play().load({}, variable_manager=variable_manager, loader=None)
    lookup = lookup_loader.get('compose_list', play=play, variable_manager=variable_manager, loader=None)

    terms=[[1,2,3],[4,5,6]]
    result=lookup.run(terms)


# Generated at 2022-06-21 06:21:39.388570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    connection = Connection('localhost')
    value = {'name': 'tom', 'age': 25, 'class': '1'}
    value1 = {'name': 'jerry', 'age': 20, 'class': '2'}

    list_lookup = LookupModule()
    list_lookup.set_options({'_terms': [[value, value1], ['name', 'class']]})

    result = list_lookup.run('', {}, connection=connection, module=module)


# Generated at 2022-06-21 06:21:41.018899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:21:51.030270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given: a list of lists, and in one of the lists is non-existent variable
    terms = [
      [ "{{ temp_var1 }}", "{{ temp_var2 }}"],
      [ "{{ temp_var3 }}", "{{ temp_var4 }}"],
    ]
    # And: Assign the list of list to class attribute _terms
    lookup_plugin = LookupModule()
    lookup_plugin._terms = terms
    lookup_plugin._templar = None
    # When: call method _lookup_variables
    try:
        lookup_plugin._lookup_variables(terms, {})
    # Then: AnsibleUndefinedVariable exception is raised
    except AnsibleUndefinedVariable:
        assert True
    # Given: a list of lists

# Generated at 2022-06-21 06:22:02.593752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Nesting 3 lists

    # test with 3 list of the same length
    lookup_module = LookupModule()
    terms = [['a1', 'a2'], ['b1', 'b2'], ['c1', 'c2']]
    result = lookup_module.run(terms)
    assert [["a1", "b1", "c1"], ["a1", "b1", "c2"], ["a1", "b2", "c1"], ["a1", "b2", "c2"],
            ["a2", "b1", "c1"], ["a2", "b1", "c2"], ["a2", "b2", "c1"], ["a2", "b2", "c2"]] == result

    # test with 3 list of the different length
    lookup_module = LookupModule()
   

# Generated at 2022-06-21 06:22:21.383881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print()
    print('##### Test of run method #####')
    print()
    m = LookupModule()

    # With simple list
    print('Result with simple list')
    terms = [['a', 'b', 'c'], ['1', '2']]
    res = m.run(terms)
    for item in res:
        print(item)

    # With set
    print('\nResult with set')
    terms = [['a', 'b', 'c'], {'1', '2'}]
    res = m.run(terms)
    for item in res:
        print(item)

    # With string
    print('\nResult with string')
    terms = [['a', 'b', 'c'], '1']
    res = m.run(terms)

# Generated at 2022-06-21 06:22:30.015828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run([['a', 'b'], ['c'], ['d', 'e', 'f']]) == [[['a', 'c', 'd'],
                                                            ['a', 'c', 'e'],
                                                            ['a', 'c', 'f'],
                                                            ['b', 'c', 'd'],
                                                            ['b', 'c', 'e'],
                                                            ['b', 'c', 'f']]]

# Generated at 2022-06-21 06:22:40.810437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([[1, 2], [3, 4, 5]]) == [[1, 3], [1, 4], [1, 5], [2, 3], [2, 4], [2, 5]]

# Generated at 2022-06-21 06:22:51.401987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([[1, 2, 3], [4, 5, 6]])
    assert result == [[1, 4], [1, 5], [1, 6], [2, 4], [2, 5], [2, 6], [3, 4], [3, 5], [3, 6]]
    result = LookupModule().run([['a', 'b'], [1, 2, 3], [4, 5, 6], ['x', 'y', 'z']])

# Generated at 2022-06-21 06:22:53.282768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    #assert l.run('foo') == 'bar'


#test_LookupModule();

# Generated at 2022-06-21 06:23:01.642578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create object to call method on it
    lookup_module = LookupModule()
    # create object to pass to method
    terms = [['a','b','c'], [1,2,3], ['one','two','three','four']]

    result = lookup_module.run(terms)
    assert result == [
        ['a', 1, 'one'],
        ['b', 1, 'two'],
        ['c', 1, 'three'],
        ['a', 2, 'one'],
        ['b', 2, 'two'],
        ['c', 2, 'three'],
        ['a', 3, 'one'],
        ['b', 3, 'two'],
        ['c', 3, 'three']
    ]


# Generated at 2022-06-21 06:23:11.414927
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input data for the test
    terms = [['a', 'b'], ['1', '2', '3']]
    variables = None
    kwargs = {}

    # Create an instance of class LookupModule
    lookup_plugin = LookupModule()

    result = lookup_plugin.run(terms, variables, **kwargs)

    # Check type of the result
    assert(type(result) == list)
    
    # Check the result
    for row in result:
        assert(type(row) == list)
        assert(len(row) == 2)
    assert(result == [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3']])

# Generated at 2022-06-21 06:23:17.933860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    my_list = [
                ['abc', '123', 'xyz'],
                ['alice', 'bob', 'james']
               ]
    terms = lookup_module._lookup_variables(my_list, {})
    assert [
            ['abc', '123', 'xyz'],
            ['alice', 'bob', 'james']
           ] == terms


# Generated at 2022-06-21 06:23:27.179936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([['a', 'b'], ['1', '2']]) == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2']]
    assert lookup.run([['a', 'b'], ['1', '2', '3']]) == [['a', '1'], ['a', '2'], ['a', '3'], ['b', '1'], ['b', '2'], ['b', '3']]
    assert lookup.run([['a', 'b'], [], ['c']]) == [['a', 'c'], ['b', 'c']]
    assert lookup.run([[], [], []]) == [[]]
    assert lookup.run([]) == []

# Generated at 2022-06-21 06:23:28.520841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-21 06:23:44.552675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:23:55.124139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_object = LookupModule()
    assert my_object.run([[["a", "b"], ["c", "d"]]]) == [['a', 'c'], ['a', 'd'], ['b', 'c'], ['b', 'd']]
    assert my_object.run([[["a", "b"], ["c", "d"]], [["1", "2"]]]) == [['a', 'c', '1'], ['a', 'c', '2'], ['a', 'd', '1'], ['a', 'd', '2'], ['b', 'c', '1'], ['b', 'c', '2'], ['b', 'd', '1'], ['b', 'd', '2']]

# Generated at 2022-06-21 06:23:56.169997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:24:05.535046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check if function returns empty list when given an empty list
    empty_list = []
    lookup_module = LookupModule()
    empty_result = lookup_module.run(empty_list)
    assert empty_result == []

    # Check if function returns correct result when not given an empty list
    nonempty_list = [['alice', 'bob'], ['clientdb', 'providerdb']]
    nonempty_result = lookup_module.run(nonempty_list)
    assert nonempty_result == [['alice', 'clientdb'], ['alice', 'providerdb'], ['bob', 'clientdb'], ['bob', 'providerdb']]

    # Check if function returns correct result when given a nested empty list

# Generated at 2022-06-21 06:24:06.181915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:24:08.122856
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 06:24:18.840571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_nested = LookupModule()
    result = lookup_nested.run([["a", "b", "c"], [1, 2, 3], ["p", "q", "r"]], None)
    assert result == [
        [1, 'a', 'p'],
        [2, 'a', 'q'],
        [3, 'a', 'r'],
        [1, 'b', 'p'],
        [2, 'b', 'q'],
        [3, 'b', 'r'],
        [1, 'c', 'p'],
        [2, 'c', 'q'],
        [3, 'c', 'r']
    ]

    result = lookup_nested.run([["a", "b", "c"], ["p", "q", "r"]], None)
   