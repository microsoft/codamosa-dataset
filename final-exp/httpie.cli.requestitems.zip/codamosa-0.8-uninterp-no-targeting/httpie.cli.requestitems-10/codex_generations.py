

# Generated at 2022-06-21 13:29:37.433211
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('testkey:value')
    actual_value = process_header_arg(arg)
    expected_value = 'value'
    assert(actual_value == expected_value)



# Generated at 2022-06-21 13:29:42.583423
# Unit test for function load_json
def test_load_json():
    test_json = "{\n  \"a\": \"b\"\n}"
    result = load_json(KeyValueArg("test","test"),test_json)
    assert(result == {"a":"b"})

# Generated at 2022-06-21 13:29:46.791189
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg

    query_param = KeyValueArg(orig="a=b&c=d", sep="=", key="a", value="b&c=d")
    result = process_query_param_arg(query_param)
    assert result == "b&c=d"


# Generated at 2022-06-21 13:29:49.550127
# Unit test for function process_header_arg
def test_process_header_arg():
    args = KeyValueArg('header', 'header_value')
    assert process_header_arg(args) == 'header_value'


# Generated at 2022-06-21 13:29:50.960086
# Unit test for function process_header_arg
def test_process_header_arg():
    # Test for Right input
    arg = KeyValueArg(sep=SEPARATOR_HEADER,key='key',value='value')
    assert process_header_arg(arg) == arg.value


# Generated at 2022-06-21 13:29:54.132170
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.parser import KeyValueArg
    arg = KeyValueArg(name='param', orig='name=3', sep='=')
    result = process_query_param_arg(arg)
    assert result == '3'

# Generated at 2022-06-21 13:29:56.669302
# Unit test for function process_header_arg
def test_process_header_arg():
    # Given
    arg = KeyValueArg('k', 'v', SEPARATOR_HEADER)

    # When
    actual = process_header_arg(arg)
    expected = 'v'

    # Then
    assert actual == expected


# Generated at 2022-06-21 13:30:07.471627
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    a1 = KeyValueArg(key='a', value=True, sep=';')
    a2 = KeyValueArg(key='b', value=True, sep='&')
    a3 = KeyValueArg(key='c', value=True, sep=':')
    a4 = KeyValueArg(key='d', value=True, sep='@')
    a5 = KeyValueArg(key='e', value=True, sep='<')

    argList = [a1, a2, a3, a4, a5]
    expect_headers = RequestHeadersDict()
    expect_params = RequestQueryParamsDict()
    expect_data = RequestJSONDataDict()
    expect_files = RequestFilesDict()


# Generated at 2022-06-21 13:30:19.352991
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:30:21.464878
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg(KeyValueArg('f:=', 'test.txt')) == 'Test file contents\n'

# Generated at 2022-06-21 13:30:28.849458
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    print(process_query_param_arg(KeyValueArg(sep='=', key='name', value='111')))



# Generated at 2022-06-21 13:30:33.770034
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    path = './file.txt'
    f = open('./file.txt', 'rb')
    filename = f.name
    mime_type = get_content_type(filename)
    assert process_file_upload_arg(KeyValueArg(path, '', ':')) == (filename, f, mime_type)



# Generated at 2022-06-21 13:30:39.536884
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg
    kvArg = KeyValueArg(key='data.1', value='~/data/sample.json', sep=':')
    assert(process_data_embed_raw_json_file_arg(kvArg) == {'Name': 'Elva'})


# Generated at 2022-06-21 13:30:44.565206
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args = [KeyValueArg('filename', 'SEPARATOR_FILE_UPLOAD', './file.png')]
    for arg in args:
        result = process_file_upload_arg(arg)
        print(result)

if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-21 13:30:48.630128
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('Header: value', 'Header', 'value', ':')
    assert process_header_arg(arg) == 'value'

    arg = KeyValueArg('Header', 'Header', '', ':')
    assert process_header_arg(arg) is None



# Generated at 2022-06-21 13:30:50.872092
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test_arg = KeyValueArg('key=value', '=', 'key', 'value')
    result = process_query_param_arg(test_arg)
    assert result == 'value'

# Generated at 2022-06-21 13:30:53.872658
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('example.txt', ';', 'example')
    assert load_text_file(item) == 'this is a test\n'

# Generated at 2022-06-21 13:31:06.513578
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():

    test_data = [
        {
            'expected': ('file', 'string content', 'text/plain'),
            'value': 'file',
        },
        {
            'expected': ('file', 'string content', 'text/plain'),
            'value': 'file;',
        },
        {
            'expected': ('file', 'string content', 'text/plain'),
            'value': 'file;text/plain',
        },
        {
            'expected': ('file', 'string content', 'text/plain'),
            'value': 'file;text/plain;',
        },
        {
            'expected': ('file', 'string content', 'text/plain'),
            'value': 'file;;text/plain',
        },
    ]


# Generated at 2022-06-21 13:31:12.978380
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:31:16.330286
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
#    file_name = "D:/github/httpie/httpie/cli/argtypes.py"
    file_name = "D:/httpie/argtypes.py"
    arg = KeyValueArg("@"+file_name)
    assert process_data_embed_file_contents_arg(arg) == load_text_file(arg)


# Generated at 2022-06-21 13:31:36.261440
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(
        key = "Authorization",
        value = "Bearer aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        orig = "Authorization: Bearer aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        sep=":",
        orig_key="Authorization",
        orig_sep=":",
        orig_value=" Bearer aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
    )
    value = process_header_arg(arg)
    assert value == "Bearer aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"


# Generated at 2022-06-21 13:31:43.632246
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key = 'json'
    value = 'test/test.json'
    # Create a KeyValueArg with SEPARATOR_DATA_EMBED_FILE_CONTENTS
    arg = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, key, value)
    assert process_data_embed_file_contents_arg(arg) == "{\n    \"message\": \"hello world\"\n}"



# Generated at 2022-06-21 13:31:50.587466
# Unit test for function load_text_file
def test_load_text_file():
    input_path = '~/abc.txt'
    item = KeyValueArg(
        ('-d', input_path),
        '',
        '',
        '',
        '',
        True,
        None,
        None,
    )
    result = load_text_file(item)
    print("result is %s" % result)


if __name__ == '__main__':
    test_load_text_file()

# Generated at 2022-06-21 13:31:55.613928
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        'Content-Type',
        'text/plain',
        '@test.txt',
        'Content-Type=@test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS
    )
    assert process_data_embed_file_contents_arg(arg) == 'Hello world!'



# Generated at 2022-06-21 13:31:57.706468
# Unit test for constructor of class RequestItems
def test_RequestItems():
    print('Test constructor of class RequestItems')
    request_items = RequestItems.from_args([KeyValueArg('header_name: header_value;')])
    print(request_items.headers)

# Generated at 2022-06-21 13:32:10.351169
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert RequestItems.from_args(
        [KeyValueArg(
            '-H', 'header', 'key',
            'value'
        )],
        as_form=False
    )

    assert RequestItems.from_args(
        [KeyValueArg(
            '-d', 'data', 'key',
            'value'
        )],
        as_form=False
    )

    assert RequestItems.from_args(
        [KeyValueArg(
            '-F', 'file', 'key',
            'value'
        )],
        as_form=False
    )

    assert RequestItems.from_args(
        [KeyValueArg(
            '-p', 'params', 'key',
            'value'
        )],
        as_form=False
    )


# Generated at 2022-06-21 13:32:13.905587
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    req_item = process_query_param_arg(KeyValueArg('k1', 'v1', ':'))
    assert req_item == 'v1'


# Generated at 2022-06-21 13:32:16.266163
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY,
                      key='TestKey',
                      value='TestValue')
    assert process_empty_header_arg(arg) == 'TestValue'

# Generated at 2022-06-21 13:32:18.169366
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg(orig='data-raw-json-embed:abc')
    load_text_file(arg)

# Generated at 2022-06-21 13:32:30.060043
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:33:36.923855
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg('a', 'b')) == ['b']
    assert process_data_raw_json_embed_arg(KeyValueArg('a', 'true')) == [True]
    assert process_data_raw_json_embed_arg(KeyValueArg('a', '123')) == [123]
    assert process_data_raw_json_embed_arg(KeyValueArg('a', '[1, 2, 3]')) == [1, 2, 3]
    assert process_data_raw_json_embed_arg(KeyValueArg('a', '{"b": "c"}')) == {"b": "c"}

# Generated at 2022-06-21 13:33:41.562398
# Unit test for function load_text_file
def test_load_text_file():
    if not os.path.exists("example.txt"):
        f = open("example.txt","w+")
        f.write("ABC")   
        f.close()
    expect = "ABC"
    reality = load_text_file("example.txt")
    assert expect == reality
    

# Generated at 2022-06-21 13:33:43.450524
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('sep', 'key', 'value')
    print(process_data_embed_file_contents_arg(arg))



# Generated at 2022-06-21 13:33:45.383507
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("Key;", "")
    if process_empty_header_arg(arg) != "":
        assert False
    else:
        assert True



# Generated at 2022-06-21 13:33:48.264992
# Unit test for function process_header_arg
def test_process_header_arg():
    a = KeyValueArg(sep=SEPARATOR_HEADER, key='Content-Type', value='text/html')
    b = process_header_arg(a)
    assert b is not None
    assert b == a.value

# Generated at 2022-06-21 13:33:53.452571
# Unit test for function process_header_arg
def test_process_header_arg():
    # normal input
    arg = KeyValueArg("x=y", "x" ,"=", "y", False)
    assert process_header_arg(arg) == "y"
    # header without value
    arg = KeyValueArg("x", "x" ,"=", "", False)
    assert process_header_arg(arg) == None
    # header without key
    arg = KeyValueArg("=y", "" ,"=", "y", False)
    assert process_header_arg(arg) == "y"

# Generated at 2022-06-21 13:33:57.714709
# Unit test for function load_json
def test_load_json():
    data = '{"a": 1, "b": 2}'
    assert load_json(None, data) == {"a": 1, "b": 2}



# Generated at 2022-06-21 13:34:02.519479
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    sep = SEPARATOR_FILE_UPLOAD
    filename = 'test.txt'
    mime_type = 'text/plain'
    value = process_file_upload_arg(KeyValueArg(sep, filename))

    assert value[0] == 'test.txt'
    assert value[1] is not None
    assert value[2] == 'text/plain'

# Generated at 2022-06-21 13:34:05.500635
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    request_item_args = [
        KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, "key", "value")
    ]
    RequestItems.from_args(request_item_args)
    assert True

# Generated at 2022-06-21 13:34:09.210031
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(key='Authorization', sep=':', value='Basic abc')
    result = process_header_arg(arg)
    assert result == arg.value


# Generated at 2022-06-21 13:36:30.715088
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(('', ''), 'data-embed:' , './data_embed.txt', '')
    result = process_data_embed_file_contents_arg(arg)
    assert result == 'data embed test'

# Generated at 2022-06-21 13:36:35.527108
# Unit test for function load_json
def test_load_json():
    try:
        assert load_json('x=x', '{"x": "y"}') == {"x": "y"}
        assert load_json('x=x', '"x"') == "x"
        assert load_json('x=x', '"x') == '"x'
    except ValueError as e:
        assert True

# Generated at 2022-06-21 13:36:38.419700
# Unit test for function load_text_file
def test_load_text_file():
    load_text_file(KeyValueArg('data-embed@/home/httpie/a.txt', 'data-embed@/home/httpie/a.txt', 'data-embed', '/home/httpie/a.txt'))



# Generated at 2022-06-21 13:36:41.460934
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Case 1: no argument
    items = RequestItems()
    assert items.headers == {}
    assert items.data == {}
    assert items.files == {}
    assert items.params == {}
    assert items.multipart_data == {}

# Generated at 2022-06-21 13:36:46.754892
# Unit test for constructor of class RequestItems
def test_RequestItems():
    item = [("header", "value"), ("query_param", "value"), ("data", "value"),
            ("file", "value")]
    items = RequestItems.from_args(item)
    assert items.headers["header"] == "value"
    assert items.params["query_param"] == "value"
    assert items.data["data"] == "value"
    assert items.files["file"] == ("value", None, None)


# Generated at 2022-06-21 13:36:50.913051
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(key="name", sep=':', value="jeff"))=="jeff"
    assert process_header_arg(KeyValueArg(key="name", sep=':', value="")) == None
    assert process_header_arg(KeyValueArg(key="name", sep=':', value=None))==None


# Generated at 2022-06-21 13:36:53.813839
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = [KeyValueArg(None, 'separator', 'key', 'value', None)]
    RequestItems.from_args(request_item_args)

# Generated at 2022-06-21 13:36:56.161452
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('test_key', 'filename')
    assert process_data_embed_file_contents_arg(arg) == "I'm a file content"


# Generated at 2022-06-21 13:36:58.709179
# Unit test for function load_text_file
def test_load_text_file():
    kv_arg = KeyValueArg("user;", "Josie")
    result = load_text_file(kv_arg)
    assert result, "Josie"
    

# Generated at 2022-06-21 13:37:00.929720
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(SEPARATOR_HEADER_EMPTY,
                      'Accept',
                      'accept/json')
    print(process_empty_header_arg(arg))

