

# Generated at 2022-06-21 13:29:48.453272
# Unit test for function load_text_file
def test_load_text_file():
    path = '/home/041294/Documents/snack.txt'
    try:
        with open(os.path.expanduser(path), 'rb') as f:
            f.read().decode()
    except IOError as e:
        print('"%s": %s' % (path, e))
        assert False
    except UnicodeDecodeError:
        print('"%s": cannot embed the content of "%s",'
            ' not a UTF8 or ASCII-encoded text file'
            % (path , path))
        assert False
    else:
        assert True


test_load_text_file()

# Generated at 2022-06-21 13:29:53.128624
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(key=None, sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='./test_file/test_data_embed_raw_json_file_arg.json')
    result = process_data_embed_raw_json_file_arg(item)
    print(result)

# Generated at 2022-06-21 13:29:55.157545
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key="SINGER", value="Sia", sep="[")
    result = process_query_param_arg(arg)
    expected = "Sia"
    assert result == expected



# Generated at 2022-06-21 13:29:59.369106
# Unit test for constructor of class RequestItems
def test_RequestItems():
    r = RequestItems(as_form=False)
    assert isinstance(r.headers, RequestHeadersDict)
    assert isinstance(r.data, RequestJSONDataDict)
    assert isinstance(r.files, RequestFilesDict)
    assert isinstance(r.params, RequestQueryParamsDict)
    assert isinstance(r.multipart_data, MultipartRequestDataDict)

# Generated at 2022-06-21 13:30:08.543625
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    data_dict = {}
    data_dict['a'] = "\u00c5\u00c3ok\u00c3\u00e6\u00c3\u00a5"
    with open("/tmp/httpie_data_file_utf8", "w") as f:
        f.write(data_dict['a'])
    arg = KeyValueArg('embed', '/tmp/httpie_data_file_utf8')
    data = process_data_embed_file_contents_arg(arg)
    assert data == "\xc5\xc3ok\xc3\xe6\xc3\xa5"
    print(data)


# Generated at 2022-06-21 13:30:12.345225
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='test_key', sep='', value='test_value')
    assert process_query_param_arg(arg) == 'test_value'

# Generated at 2022-06-21 13:30:22.721586
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Check when empty
    request_item_args = []
    r = RequestItems.from_args(request_item_args,as_form=False)
    assert len(r.headers) == 0
    assert len(r.data) == 0
    assert len(r.files) == 0
    assert len(r.params) == 0
    assert len(r.multipart_data) == 0
    

    # Check when has headers
    request_item_args = []
    request_item_args.append(KeyValueArg("User-Agent",None,SEPARATOR_HEADER))
    request_item_args.append(KeyValueArg("Location","http://www.tutorialspoint.com",SEPARATOR_HEADER))

# Generated at 2022-06-21 13:30:25.156525
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('a=b')
    value = process_data_raw_json_embed_arg(arg)
    print(value)
    pass
    

# Generated at 2022-06-21 13:30:28.880116
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg()
    arg.orig = '-F'
    arg.sep = '-F'
    arg.key = ''
    arg.value = '/usr/a.txt'
    res = process_file_upload_arg(arg)
    assert res[0] == 'a.txt'
    assert res[1].read().decode() == 'a'

# Generated at 2022-06-21 13:30:40.716481
# Unit test for function load_json
def test_load_json():
    path = 'JSON_FILE'

    test_success_1 = '{"a": 1, "b": 2}'
    assert load_json(KeyValueArg('', '', '', '', ''), test_success_1) == {'a': 1, 'b': 2}

    test_success_2 = '{"a": 1, "b": 2}{"a": 1, "b": 2}'
    with pytest.raises(ParseError):
        load_json(KeyValueArg('', '', '', '', ''), test_success_2)

    test_success_3 = '{"a": 1, "b": 2}'
    assert load_json(KeyValueArg('', path, '', '', ''), test_success_3) == {'a': 1, 'b': 2}

    test_success_4

# Generated at 2022-06-21 13:30:52.498654
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg_string = "user=jack"
    arg = KeyValueArg(arg_string)
    value = process_data_item_arg(arg)
    assert value == "jack"

    arg_string = 'user={"name": "jack", "age": 18}'
    arg = KeyValueArg(arg_string)
    value = process_data_item_arg(arg)
    assert value == '{"name": "jack", "age": 18}'

# Generated at 2022-06-21 13:31:05.965142
# Unit test for function load_json
def test_load_json():
    assert load_json(KeyValueArg("json_data","k1","v1"),'{"k1":"v1"}') == {"k1":"v1"}
    assert load_json(KeyValueArg("json_data","k2","v2"),'{"k2":"v2"}') == {"k2":"v2"}
    assert load_json(KeyValueArg("json_data","k3","v3"),'{"k3":"v3"}') == {"k3":"v3"}
    assert load_json(KeyValueArg("json_data","k4","v4"),'{"k4":"v4"}') == {"k4":"v4"}
    assert load_json(KeyValueArg("json_data","k5","v5"),'{"k5":"v5"}') == {"k5":"v5"}

# Generated at 2022-06-21 13:31:09.135297
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = []
    ri = RequestItems.from_args(request_item_args)
    assert isinstance(ri, RequestItems)



# Generated at 2022-06-21 13:31:12.116696
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    import pytest

    func = process_data_embed_file_contents_arg
    arg = KeyValueArg('data@file.txt')
    arg.value = './test.txt'
    assert func(arg) == 'ww'



# Generated at 2022-06-21 13:31:23.555855
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems()

# Generated at 2022-06-21 13:31:29.981029
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('Authorization', sep=SEPARATOR_HEADER_EMPTY)
    process_empty_header_arg(arg)

    arg = KeyValueArg('Authorization;Bearer abc123', sep=SEPARATOR_HEADER_EMPTY)
    with pytest.raises(ParseError):
        process_empty_header_arg(arg)

# Generated at 2022-06-21 13:31:37.549912
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # key=value
    arg = KeyValueArg(orig=None, key=None, value='{"foo":"bar"}', sep=None)
    value = process_data_raw_json_embed_arg(arg)
    assert value == {'foo': 'bar'}

    # key="value"
    arg = KeyValueArg(orig=None, key=None, value="""{"foo":"bar"}""", sep=None)
    value = process_data_raw_json_embed_arg(arg)
    assert value == {'foo': 'bar'}

    # key=value, value is a list
    arg = KeyValueArg(orig=None, key=None, value='["foo","bar"]', sep=None)
    value = process_data_raw_json_embed_arg(arg)

# Generated at 2022-06-21 13:31:49.207387
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key = 'test_name'
    value = '/tmp/test_data.csv'
    as_form = False
    as_form_args = False
    sep = SEPARATOR_DATA_EMBED_FILE_CONTENTS
    test_request_args = [
        KeyValueArg(key=key, value=value,
                    orig=key+sep+value,
                    param_sep=False, sep=sep,
                    as_form=as_form, as_form_args=as_form_args),
    ]

    try:
        result = RequestItems.from_args(test_request_args, as_form=as_form).data[key]
        print(result)
    except ParseError as e:
        print(e)

# Generated at 2022-06-21 13:31:53.770291
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    json_str = '{"name":"httpie","version":1.0}'
    print(process_data_raw_json_embed_arg(KeyValueArg('', '', json_str)))

if __name__ == '__main__':
    test_process_data_raw_json_embed_arg()

# Generated at 2022-06-21 13:31:56.470872
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():

    arg = KeyValueArg(sep = ':=', key = 'test', orig = 'test:=test', value = '{"test":"test"}')
    actual = process_data_raw_json_embed_arg(arg)
    assert actual == {"test":"test"}

    arg = KeyValueArg(sep = ':=', key = 'test', orig = 'test:=[]', value = '[]')
    actual = process_data_raw_json_embed_arg(arg)
    assert actual == []

# Generated at 2022-06-21 13:32:09.681556
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER, "Content-Type",
                                          "application/json")) == "application/json"
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER, "Content-Type", None)) is None



# Generated at 2022-06-21 13:32:16.637846
# Unit test for function load_text_file
def test_load_text_file():
    print(load_text_file(KeyValueArg(orig='name', sep='==', key='name', value='/Users/kevin/Desktop/httpie-master/examples/example_request.json')))
    print(load_text_file(KeyValueArg(orig='name', sep='==', key='name', value='/Users/kevin/Desktop/httpie-master/examples/example_request.txt')))



# Generated at 2022-06-21 13:32:20.555873
# Unit test for function process_header_arg
def test_process_header_arg():
    raw = 'key:value'
    item = KeyValueArg(raw)
    assert process_header_arg(item) == item.value

if __name__ == '__main__':
    test_process_header_arg()

# Generated at 2022-06-21 13:32:29.033228
# Unit test for function load_text_file
def test_load_text_file():
    expected = 'Test text file'
    # Create temp text file
    test_data = tempfile.NamedTemporaryFile(mode='w', delete=False)
    try:
        test_data.write(expected)
        test_data.close()
        # Load text file and assert
        actual = load_text_file(KeyValueArg(None, None, value=test_data.name))
        assert actual == expected
    finally:
        # Cleanup temp text file
        test_data.close()
        os.unlink(test_data.name)

# Generated at 2022-06-21 13:32:31.864463
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg("H", "lo", "Head", "value")
    assert(process_header_arg(arg) == "value")


# Generated at 2022-06-21 13:32:35.943715
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(key=None, sep=None, orig=None, value=r'{"key1": "value1", "key2": "value2"}')
    process_data_embed_raw_json_file_arg(item)

# Generated at 2022-06-21 13:32:41.103494
# Unit test for function load_text_file
def test_load_text_file():
    with open('/tmp/testfile.txt', 'wb') as f:
        f.write('hello world'.encode())
    arg = KeyValueArg(sep='@', key=None, value='/tmp/testfile.txt')
    print(load_text_file(arg))

if __name__ == '__main__':
    test_load_text_file()

# Generated at 2022-06-21 13:32:49.278562
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:33:01.370963
# Unit test for function load_text_file
def test_load_text_file():
    from io import StringIO
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    path =  StringIO('中文')
    with open('test.txt', 'w') as f:
        f.write(path.getvalue())
    path = 'test.txt'
    try:
        with open(path, 'rb') as f:
            text = f.read().decode()
        assert  text == '中文'
    except IOError as e:
        raise ParseError('"%s": %s' % (path, e))

# Generated at 2022-06-21 13:33:09.941913
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:33:30.173335
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('-d', '', './test/resources/index.html')
    assert load_text_file(item) == '<html>\n</html>\n'

# Generated at 2022-06-21 13:33:35.255086
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file()
    except ParseError as e:
        # parseError is an exception
        print('len(sys.argv) = %d' % (len(sys.argv)))
        print('sys.argv[0] = %s' % (sys.argv[0]))
        print('ParseError: %s' % (e))
        print('try help...')

# Generated at 2022-06-21 13:33:39.951305
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
  arg = KeyValueArg(orig="hello",key="hello", sep='=', value="hello_value")
  assert process_data_embed_file_contents_arg(arg) == "hello_value"

# Generated at 2022-06-21 13:33:48.857868
# Unit test for function load_json
def test_load_json():
    request_item_arg = KeyValueArg('data-raw-json', '{"a":1,"b":2,"c":3}')
    value = load_json(request_item_arg, request_item_arg.value)
    assert value == {"a":1, "b":2, "c":3}

    request_item_arg = KeyValueArg('data-raw-json', None)
    value = load_json(request_item_arg, "{}")
    assert value == {}

    request_item_arg = KeyValueArg('data-raw-json', None)
    value = load_json(request_item_arg, "[]")
    assert value == []

    request_item_arg = KeyValueArg('data-raw-json', None)
    value = load_json(request_item_arg, "null")
   

# Generated at 2022-06-21 13:33:55.453941
# Unit test for function load_text_file
def test_load_text_file():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_file_path = os.path.join(test_dir, "test_files", "test_text_file.txt")

    target_content = "this is just a test file content\n"

    arg = KeyValueArg(None, None, test_file_path)
    result = load_text_file(arg)
    assert result == target_content

# Generated at 2022-06-21 13:34:00.709833
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    try:
        with open("test.txt", "w") as f:
            f.write("test")
        f.close()
        f = open('test.txt', 'r')
        f.close()
        assert process_data_embed_file_contents_arg(KeyValueArg("@test.txt", "@")) == "test"
    except FileNotFoundError:
        assert False

# Generated at 2022-06-21 13:34:05.141850
# Unit test for function process_header_arg
def test_process_header_arg():
    arg1 = KeyValueArg('k1', 'v1', 'k1:v1', SEPARATOR_HEADER)
    assert process_header_arg(arg1) == 'v1'

    arg2 = KeyValueArg('k2', '', 'k2:', SEPARATOR_HEADER)
    assert process_header_arg(arg2) == ''

    arg3 = KeyValueArg('k3', '', 'k3', SEPARATOR_HEADER)
    assert process_header_arg(arg3) == ''



# Generated at 2022-06-21 13:34:08.518246
# Unit test for function process_header_arg
def test_process_header_arg():
    args = KeyValueArg("header: value", "header", "value", ": ")
    assert process_header_arg(args) == "value"


# Generated at 2022-06-21 13:34:09.412490
# Unit test for constructor of class RequestItems
def test_RequestItems():
    pass


# Generated at 2022-06-21 13:34:17.026655
# Unit test for constructor of class RequestItems
def test_RequestItems():
    form = True
    headers = RequestHeadersDict()
    data = RequestDataDict() if form else RequestJSONDataDict()
    files = RequestFilesDict()
    params = RequestQueryParamsDict()
    multipart_data = MultipartRequestDataDict()
    assert (headers, data, files, params, multipart_data) == (RequestItems(form).headers, RequestItems(form).data, RequestItems(form).files, RequestItems(form).params, RequestItems(form).multipart_data)

# Generated at 2022-06-21 13:34:49.647616
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json1 = '''
    {
        "inner":
            {
                "next_1": 40,
                "next_2": 80
            },
        "outer_1": 10,
        "outer_2": 20
    }
    '''
    json2 = '''
    [
        {
            "name": "Bob",
            "age": 20
        },
        {
            "name": "John",
            "age": 30
        }
    ]
    '''
    json3 = '''
    [
        [
            {
                "name": "Bob",
                "age": 20
            },
            {
                "name": "John",
                "age": 30
            }
        ]
    ]
    '''

# Generated at 2022-06-21 13:34:53.061790
# Unit test for constructor of class RequestItems
def test_RequestItems():
    arg = KeyValueArg('helloworld', key='aaa', sep='ddd', orig_str='e')
    list = [arg]
    req = RequestItems.from_args(list)
    print(req.headers)


# Generated at 2022-06-21 13:34:57.922228
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request = RequestItems()
    assert request.headers == {}
    assert request.data == {}
    assert request.files == {}
    assert request.params == {}
    assert request.multipart_data == {}
    assert hasattr(request, 'headers')
    assert hasattr(request, 'data')
    assert hasattr(request, 'files')
    assert hasattr(request, 'params')
    assert hasattr(request, 'multipart_data')

# Generated at 2022-06-21 13:34:58.465508
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert True

# Generated at 2022-06-21 13:35:04.546336
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # prepare
    from httpie.cli import parse_items
    data_item_arg = KeyValueArg('test.txt')
    data_item_arg.sep = SEPARATOR_DATA_EMBED_FILE_CONTENTS
    data_item_arg.value = 'test.txt'
    # execute
    items = parse_items([data_item_arg], as_form=False)
    # verify
    assert items.data['test.txt'] == 'embed file text'



# Generated at 2022-06-21 13:35:09.611275
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='key1',value='value1',orig='key1=value1')
    assert process_query_param_arg(arg) == 'value1'
    arg = KeyValueArg(key='key1',value='',orig='key1')
    assert process_query_param_arg(arg) == ''


# Generated at 2022-06-21 13:35:14.901998
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(key=None, sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, value=None)
    result_text = "Hello World"

    with patch('httpie.cli.argtypes.load_text_file', return_value=result_text):
        assert process_data_embed_file_contents_arg(arg) == result_text


# Generated at 2022-06-21 13:35:18.237119
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    key = 'key'
    value = 'value'
    query_arg = KeyValueArg(key=key, sep=SEPARATOR_QUERY_PARAM, value=value, orig='{}:{}'.format(key, value))
    assert process_query_param_arg(query_arg) == value



# Generated at 2022-06-21 13:35:24.498221
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():

    def testcase_process_empty_header_arg(arg):
        try:
            return process_empty_header_arg(arg)
        except ParseError as e:
            return e

    # Nominal case
    # =============

    # Empty header
    key = 'Content-Type'
    sep = SEPARATOR_HEADER_EMPTY
    value = ''
    arg = KeyValueArg(key=key, sep=sep, value=value, orig=key + sep + value)
    assert testcase_process_empty_header_arg(arg) == arg.value

    # Special case
    # =============

    # Invalid item
    key = 'Content-Type'
    sep = SEPARATOR_HEADER_EMPTY
    value = 'application/json'

# Generated at 2022-06-21 13:35:30.812245
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_RAW_JSON,
        key='content-type',
        value='application/json',
    )
    value = load_json(arg, '{"id": 1}')
    assert value == {"id": 1}

    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='content-type',
        value='application/json',
    )
    value = load_json(arg, '{"id": 1}')
    assert value == {"id": 1}


# Generated at 2022-06-21 13:35:52.197417
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    res = process_data_item_arg(KeyValueArg(None, "key","value"))
    if res != "value":
        print("test_process_data_item_arg 1 failed.")

test_process_data_item_arg()


# Generated at 2022-06-21 13:35:55.052226
# Unit test for constructor of class RequestItems
def test_RequestItems():
    object = RequestItems(False)
    assert object.headers == {}
    assert object.data == {}
    assert object.files == {}
    assert object.params == {}
    assert object.multipart_data == {}



# Generated at 2022-06-21 13:35:58.205519
# Unit test for function load_text_file
def test_load_text_file():
    path = "./test_load_text_file.txt"
    request = KeyValueArg(SEPARATOR_DATA_RAW_JSON,"key", "value")
    request.value = path
    result = load_text_file(request)
    f = open(path, "r")
    expected = f.read()
    f.close()
    assert result==expected


# Generated at 2022-06-21 13:36:07.922870
# Unit test for function process_header_arg
def test_process_header_arg():
    # Test case 1:
    header = KeyValueArg(orig='accept', sep='', key='accept', value='application/json')
    assert process_header_arg(header) == 'application/json'
    assert header.key == 'accept'
    assert header.value == 'application/json'
    assert header.orig == 'accept'
    assert header.sep == ''

    # Test case 2:
    header = KeyValueArg(orig='json', sep='', key='json', value='true')
    assert process_header_arg(header) == 'true'
    assert header.key == 'json'
    assert header.value == 'true'
    assert header.orig == 'json'
    assert header.sep == ''


# Generated at 2022-06-21 13:36:10.757932
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(key=None, sep=SEPARATOR_HEADER_EMPTY, orig=SEPARATOR_HEADER_EMPTY, value=None)
    assert process_empty_header_arg(arg) == ""



# Generated at 2022-06-21 13:36:12.554892
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("", "", "")
    result = load_text_file(item)
    assert result == ""


# Generated at 2022-06-21 13:36:15.768850
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_item = KeyValueArg("-F", "file.txt", "image/jpeg")
    filename, f, mime_type = process_file_upload_arg(test_item)

    assert filename == "file.txt"
    assert mime_type == "image/jpeg"

# Generated at 2022-06-21 13:36:20.614071
# Unit test for function load_json
def test_load_json():

    contents = '{ "a": 1, "b": 2 }'
    arg = '-d'
    try:
        json_output = load_json(arg, contents)
    except ValueError:
        print("Test load_json() - Failed")
        return False
    print(json_output)
    print("Test load_json() - Passed")
    return True


# Generated at 2022-06-21 13:36:22.553472
# Unit test for function process_header_arg
def test_process_header_arg():
    header = KeyValueArg("header-key: value")
    assert process_header_arg(header) == "value"


# Generated at 2022-06-21 13:36:29.880413
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = [
        KeyValueArg("headers", "Accept: application/json"),
        KeyValueArg("headers", "Cache-Control: no-cache"),
        KeyValueArg("querystring", "pretty=1"),
        KeyValueArg("querystring", "name=hello"),
        KeyValueArg("files", "file;type=text/plain"),
        KeyValueArg("data", ""),
        KeyValueArg("data", ""),
        KeyValueArg("data", "<@>"),
        KeyValueArg("data", "@")
    ]
    request_items = RequestItems.from_args(request_item_args)
    assert request_items

# Generated at 2022-06-21 13:37:16.786854
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-21 13:37:19.382409
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(key="Content-Type", value="application/json", sep=";")
    value = process_empty_header_arg(arg)
    assert value == "application/json"


# Generated at 2022-06-21 13:37:24.669319
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    data = {'a': 'b'}
    filename = 'test_file.json'
    with open(filename, 'w') as file:
        json.dump(data, file)
    arg = KeyValueArg('-d', '@' + filename)
    assert data == process_data_embed_raw_json_file_arg(arg)
    os.remove(filename)

# Generated at 2022-06-21 13:37:36.219024
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = [KeyValueArg(1, 2, 3,"headers"),
                         KeyValueArg(1, 2, 3,"headers"),
                         KeyValueArg(1, 2, 3,"empty_headers"),
                         KeyValueArg(1, 2, 3,"params"),
                         KeyValueArg(1, 2, 3,"files"),
                         KeyValueArg(1, 2, 3,"data"),
                         KeyValueArg(1, 2, 3,"embed_file"),
                         KeyValueArg(1, 2, 3,"embed_raw_json"),
                         KeyValueArg(1, 2, 3,"embed_file_raw_json")]
    request_items = RequestItems.from_args(request_item_args)
    expected = RequestItems()
    expected.headers = [KeyValueArg(1, 2, 3,"headers")]

# Generated at 2022-06-21 13:37:38.517991
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(arg=KeyValueArg('arg', 'value')) == 'value'


# Generated at 2022-06-21 13:37:43.565452
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg1 = KeyValueArg('Header;')
    arg2 = KeyValueArg('Header;value')
    assert process_empty_header_arg(arg1) == ''
    try:
        process_empty_header_arg(arg2)
    except ParseError as e:
        assert str(e).startswith('Invalid item')
        return
    assert False

# Generated at 2022-06-21 13:37:54.361706
# Unit test for function load_text_file
def test_load_text_file():
    # Basic testing
    test_file = './tmp_test.txt'
    with open(test_file, 'w') as f:
        f.write('test file')
    try:
        assert load_text_file(KeyValueArg(None, '-d', None, test_file)) == 'test file'
    finally:
        os.remove(test_file)

    # Testing file which doesn't exist
    try:
        load_text_file(KeyValueArg(None, '-d', None, './tmp_no_exists.txt'))
    except ParseError as e:
        # We expect an exception to occur
        assert "'./tmp_no_exists.txt': No such file or directory" in str(e)

# Generated at 2022-06-21 13:37:59.647160
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = '/Users/luoxi/Downloads/images/file_upload.txt;image/png'
    file_content = process_file_upload_arg(arg)
    print(file_content[1].read())
    print(file_content)

if __name__ == "__main__":
    test_process_file_upload_arg()

# Generated at 2022-06-21 13:38:09.142749
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    json_data = []
    json_data.append(KeyValueArg(
        key='name',
        sep=SEPARATOR_DATA_RAW_JSON,
        value='{"name":"Jack"}',
        orig='name@{"name":"jack"}'))
    json_data.append(KeyValueArg(
        key='age',
        sep=SEPARATOR_DATA_RAW_JSON,
        value='{"age":18}',
        orig='age@{"age":18}'))
    json_data.append(KeyValueArg(
        key='sex',
        sep=SEPARATOR_DATA_RAW_JSON,
        value='{"sex":"male"}',
        orig='sex@{"sex":"male"}'))
    req_items = RequestItems.from_args(json_data)
    actual_data = {}
    actual_

# Generated at 2022-06-21 13:38:12.537665
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg('Header-With-Empty-Value;'))
        assert True
    except ParseError:
        assert False
    
    try:
        process_empty_header_arg(KeyValueArg('Header-With-Empty-Value;', 'value'))
        assert False
    except ParseError:
        assert True