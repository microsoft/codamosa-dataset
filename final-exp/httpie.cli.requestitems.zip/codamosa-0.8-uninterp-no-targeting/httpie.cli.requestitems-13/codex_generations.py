

# Generated at 2022-06-21 13:29:36.442490
# Unit test for function load_json
def test_load_json():
    try:
        load_json({"test":"test"})
    except ParseError as e:
        print(e)
    

# Generated at 2022-06-21 13:29:42.889777
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    class KeyValueArg:
        def __init__(self, value):
            self.orig = value

    assert process_data_raw_json_embed_arg(KeyValueArg('{"1":1}')) == {"1": 1}
    assert process_data_raw_json_embed_arg(KeyValueArg('{"1":"1"}')) == {"1": "1"}
    assert process_data_raw_json_embed_arg(KeyValueArg('{"1":[1,2]}')) == {"1": [1,2]}
    assert process_data_raw_json_embed_arg(KeyValueArg('{"1":{"2":2}}')) == {"1": {"2": 2}}

    try:
        process_data_raw_json_embed_arg(KeyValueArg('{"1'))
    except ParseError:
        pass

# Generated at 2022-06-21 13:29:44.546961
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    process_data_embed_file_contents_arg("xyz:@examples/post-binary-file.bin")

# Generated at 2022-06-21 13:29:48.527864
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER, "key", "value")) == "value"
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER, "key")) == None
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER_EMPTY, "key")) == ""
    # TODO: This is actually a bug in the httpie library. When we set a header with an empty value,
    # it doesn't show up, but it doesn't raise an error either.
    # assert process_header_arg(KeyValueArg(SEPARATOR_HEADER_EMPTY, "key", "value")) == ""

# Generated at 2022-06-21 13:29:52.058200
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg('key', 'value', 'orig')
    contents = '[1, 2, 3]'
    print(load_json(arg, contents))
    assert load_json(arg, contents) == [1, 2, 3]

# Generated at 2022-06-21 13:29:54.452355
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(sep="!", key="bar", value="toto")
    assert process_data_item_arg(arg) == "toto"


# Generated at 2022-06-21 13:30:01.933664
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_path = "test_images/test.jpg"
    data = SEPARATOR_FILE_UPLOAD + " " + file_path

    # create a fake sys.argv for stdin
    sys.argv = [""]
    sys.argv.append(data)
    # create fake stdin
    stdin = sys.stdin
    sys.stdin = io.StringIO(data)
    arg = argparser.parse_args()[0]

    filename, f, mime_type = process_file_upload_arg(arg)


test_process_file_upload_arg()

# Generated at 2022-06-21 13:30:02.734294
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    pass

# Generated at 2022-06-21 13:30:05.450702
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test = KeyValueArg(key='test', value='1', sep=':')
    assert process_data_item_arg(test) == '1'


# Generated at 2022-06-21 13:30:07.755944
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('-H', 'X-Test: test')) == 'test'


# Generated at 2022-06-21 13:30:21.001585
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        'sep',
        'k',
        'v',
        'orig'
    )
    # arg.sep = ';'
    # arg.key = 'k'
    # arg.value = 'v'
    # arg.orig = 'orig'
    results = process_data_embed_file_contents_arg(arg)
    print(results)


test_process_data_embed_file_contents_arg()

# Generated at 2022-06-21 13:30:24.171940
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    query_param_test_arg = KeyValueArg('test:test', 'test', 'test', 'test')
    if process_query_param_arg(query_param_test_arg) == 'test':
        pass
    else:
        assert False



# Generated at 2022-06-21 13:30:25.197716
# Unit test for constructor of class RequestItems
def test_RequestItems():
	assert callable(RequestItems)


# Generated at 2022-06-21 13:30:27.839764
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    print("Unit test for function process_file_upload_arg")
    kv = KeyValueArg('http://localhost/test/test.html', 'image.jpg', 'avatar.jpg')
    print(process_file_upload_arg(kv))

# Generated at 2022-06-21 13:30:37.835244
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    item = KeyValueArg(
        sep='@',
        orig='@test.txt',
        key='test.txt',
        value='test.txt'
    )
    path = os.path.join(os.getcwd(), item.value)
    filename, f, mime_type = process_file_upload_arg(item)
    # print(f)
    # f.close()
    assert filename == 'test.txt'
    assert f.name == 'data/test.txt'
    assert mime_type == None
    # mime_type = get_content_type(filename)
    # assert mime_type == 'text/plain'



# Generated at 2022-06-21 13:30:41.548931
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # Create a Key value arg to pass in
    arg = KeyValueArg(orig='Header;', sep=';', key='Header', value=None)
    assert process_empty_header_arg(arg) == None


# Generated at 2022-06-21 13:30:47.127867
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='k',
        value="a.txt;text/plain"
    )
    result = process_file_upload_arg(arg)
    assert result[0] == 'a.txt'
    assert result[1].read() == b'a'
    assert result[2] == 'text/plain'

# Generated at 2022-06-21 13:30:49.182233
# Unit test for function load_json
def test_load_json():
    print(load_json({"name":"tom"}))

if __name__ == '__main__':
    test_load_json()

# Generated at 2022-06-21 13:30:50.472390
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg("Header;")) == ""
    

# Generated at 2022-06-21 13:31:03.165947
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg("k1=v1", "=", "k1", "v1")
    assert process_data_embed_raw_json_file_arg(arg) == "v1"
    arg = KeyValueArg("k1=v2", ":=", "k1", "v2")
    assert process_data_embed_raw_json_file_arg(arg) == "v2"
    arg = KeyValueArg("k1@filename.txt", "@", "k1", "filename.txt")
    assert process_data_embed_raw_json_file_arg(arg) == "content1\n"

# Generated at 2022-06-21 13:31:20.179495
# Unit test for function load_text_file
def test_load_text_file():
    path = __file__
    with open(path, 'rb') as f:
        content = f.read().decode()
        print(content)


# Generated at 2022-06-21 13:31:23.661656
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_arg = ['data','key','=','value']
    test_arg = KeyValueArg(*test_arg)
    assert process_data_item_arg(test_arg) == 'value'

# Generated at 2022-06-21 13:31:33.666944
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg(key="name", value="John", orig="name=John")) == "John"
    assert process_data_item_arg(KeyValueArg(key="name", value="JOHN", orig="name=JOHN")) == "JOHN"
    assert process_data_item_arg(KeyValueArg(key="name", value="Name", orig="name=Name")) == "Name"
    assert process_data_item_arg(KeyValueArg(key="name", value="Name", orig="name=Name")) != "name"
    assert process_data_item_arg(KeyValueArg(key="name", value="Name", orig="name=Name")) != 0


# Generated at 2022-06-21 13:31:41.380017
# Unit test for function load_text_file
def test_load_text_file():
    fp = open("file.txt","w")
    fp.write("This is test file")
    fp.close()
    KeyValueArg.value = 'file.txt'
    KeyValueArg.orig = 'file.txt'
    load_text_file(KeyValueArg)
    assert os.path.exists('file.txt') == True
    os.remove('file.txt')
    assert os.path.exists('file.txt') == False


# Generated at 2022-06-21 13:31:46.121005
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # Create a KeyValueArg instance
    value = 'I\'m a string'
    arg = KeyValueArg('Input data', sep=':', value=value)
    assert process_data_embed_file_contents_arg(arg) == value


# Generated at 2022-06-21 13:31:56.131564
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    test_arg = KeyValueArg(SEPARATOR_HEADER_EMPTY, None)
    expected = None
    assert process_empty_header_arg(test_arg) == expected
    test_arg = KeyValueArg(SEPARATOR_HEADER_EMPTY, "")
    assert process_empty_header_arg(test_arg) == expected
    test_arg = KeyValueArg(SEPARATOR_HEADER_EMPTY, ":")
    assert process_empty_header_arg(test_arg) == expected
    test_arg = KeyValueArg(SEPARATOR_HEADER_EMPTY, "test")
    with pytest.raises(ParseError):
        process_empty_header_arg(test_arg)


# Generated at 2022-06-21 13:31:57.516309
# Unit test for function load_text_file
def test_load_text_file():
    a = load_text_file("\r\n")
    assert(a == "\r\n")


# Generated at 2022-06-21 13:32:04.581911
# Unit test for function process_header_arg
def test_process_header_arg():
    """
    test for process_header_arg
    """
    arg = KeyValueArg('k:v')
    arg.key = 'k'
    arg.sep = ':'
    arg.value = 'v'
    assert process_header_arg(arg) == 'v'
    arg.value = ''
    assert process_header_arg(arg) is None


# Generated at 2022-06-21 13:32:13.911436
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli import parser
    import json
    import random
    import string
    from httpie.cli.utils import u

    def random_string(string_length=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(string_length))

    args = [
        '-X', 'POST',
        'http://localhost/',
        ':name:=:value:'
    ]
    args = parser.parse_args(args)
    request_items = RequestItems.from_args(args.items, as_form=False)
    u(json.dumps(request_items.to_dict()))

# Generated at 2022-06-21 13:32:18.379894
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key='data', value='file.csv')
    assert process_data_embed_file_contents_arg(arg) == 'id,name\n1,name1\n2,name2\n'

# Generated at 2022-06-21 13:32:57.437297
# Unit test for function process_header_arg
def test_process_header_arg():
    process_header_arg(KeyValueArg('header', 'key', 'value', SEPARATOR_HEADER))


# Generated at 2022-06-21 13:33:06.511601
# Unit test for function load_json
def test_load_json():
    load_json(None, '231')
    load_json(None, '"231"')
    load_json(None, '"23\\n1"')
    load_json(None, 'true')
    load_json(None, 'false')
    load_json(None, '{"a": 1, "b": "c"}')
    load_json(None, '{}')
    with pytest.raises(ParseError):
        load_json(None, '"231')
    with pytest.raises(ParseError):
        load_json(None, '[1, 2, 3, 4')
    with pytest.raises(ParseError):
        load_json(None, '{"a": 1, 23: 42}')

# Generated at 2022-06-21 13:33:09.840459
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(orig='header:value', key='header', value='value', sep=':')) == 'value'
    assert process_header_arg(KeyValueArg(orig='header:', key='header', value='', sep=':')) is None


# Generated at 2022-06-21 13:33:12.337396
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('test', 'key', 'testvalue')
    assert process_data_embed_raw_json_file_arg(arg) == 'testvalue'

# Generated at 2022-06-21 13:33:19.827329
# Unit test for function load_json
def test_load_json():
    value = load_json({'orig':'src/httpie/cli/dicts.py', 'value':'value'}, 
                     '{"a": "-a", "b": "b"}')
    print(value)
    assert value == {"a": "-a", "b": "b"}
    print(value)
    #print(list(value.keys()))
    #print(list(value.values()))

if __name__ == "__main__":
    test_load_json()

# Generated at 2022-06-21 13:33:22.712443
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg("Host", "google.com", ':', None)
    assert process_header_arg(arg) == 'google.com'


# Generated at 2022-06-21 13:33:23.431333
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    pass



# Generated at 2022-06-21 13:33:26.381040
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(orig="--data data.json", key="data", sep="=", value="data.json")
    expected = {"name": "John Doe"}
    assert process_data_embed_raw_json_file_arg(item) == expected

# Generated at 2022-06-21 13:33:36.227503
# Unit test for function load_text_file
def test_load_text_file():
    raw_json = '''
    {
    "group1":{
        "baz":"value2",
        "foo2":"value2"
    },
    "group2":{
        "baz":"value3",
        "foo2":"value4"
    }
}
    '''
    a = KeyValueArg(
        'name', 'raw_json',
        orig='name<raw_json',
        sep='<',
        key='name',
        value=raw_json,
    )
    loaded_json = load_json(a, raw_json)
    assert loaded_json['group1']['baz'] == "value2"
    assert loaded_json['group1']['foo2'] == "value2"
    assert loaded_json['group2']['baz'] == "value3"

# Generated at 2022-06-21 13:33:46.401644
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # pdffile
    pdffile_filename = './Samples/sample.pdf'
    pdffile_file_content = open(pdffile_filename, 'rb').read().decode()
    pdffile_keyvalue_arg = KeyValueArg('pdffile', pdffile_filename, ';')
    pdffile_value = process_data_embed_file_contents_arg(pdffile_keyvalue_arg)
    assert pdffile_value == pdffile_file_content
    print('[pass] test_process_data_embed_file_contents_arg: pdffile')

    # textfile
    textfile_filename = './Samples/sample.txt'
    textfile_file_content = open(textfile_filename, 'r').read()

# Generated at 2022-06-21 13:35:00.246351
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('key', '', 'value')
    assert process_data_item_arg(arg) == 'value'


# Generated at 2022-06-21 13:35:06.310988
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_path = 'json.txt'
    try:
        f = open(os.path.expanduser(json_path), 'rb')
        json_data = f.read().decode()
    except IOError as e:
        raise ParseError('"%s": %s' % (json_path, e))
    except UnicodeDecodeError:
        raise ParseError(
            '"%s": cannot embed the content of "%s",'
            ' not a UTF8 or ASCII-encoded text file'
            % (json_path, json_path)
        )

    try:
        parsed_json = load_json_preserve_order(json_data)
    except ValueError as e:
        raise ParseError('"%s": %s' % (json_path, e))

    #print(pars

# Generated at 2022-06-21 13:35:09.507969
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(SEPARATOR_QUERY_PARAM, '')
    print(process_query_param_arg(arg))


# test_process_query_param_arg()

# Generated at 2022-06-21 13:35:15.891145
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    key = './test/test_cli.py'
    value = './test/test_cli.py'
    f = open(value, 'rb')
    mime_type = get_content_type(key)
    filename = key
    kv = KeyValueArg(SEPARATOR_FILE_UPLOAD, key=key, value=value)

    assert(process_file_upload_arg(kv) == (filename, f, mime_type))


# Generated at 2022-06-21 13:35:25.701567
# Unit test for function process_header_arg
def test_process_header_arg():
    # type: () -> None
    test_dict_1 = {"X-Test": "test"}
    test_dict_2 = {"X-Test": ""}
    test_dict_3 = {"X-Test": None}

    arg_1 = KeyValueArg(key="X-Test", value="test")
    arg_2 = KeyValueArg(key="X-Test", value="", sep=": ")
    arg_3 = KeyValueArg(key="X-Test", value="", sep=":; ")

    assert test_dict_1 == {"X-Test": process_header_arg(arg_1)}
    assert test_dict_2 == {"X-Test": process_header_arg(arg_2)}
    assert test_dict_3 == {"X-Test": process_header_arg(arg_3)}

# Generated at 2022-06-21 13:35:28.557185
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_arg = KeyValueArg(['key', 'B;value'], 'B;key=value')
    value = process_data_item_arg(test_arg)
    assert value == 'value'



# Generated at 2022-06-21 13:35:38.635297
# Unit test for function load_text_file
def test_load_text_file():
    # Test normal usage
    test_str = "This is a test string"
    test_file = open("__test_file", "w")
    test_file.write(test_str)
    test_file.close()
    item = KeyValueArg(SEPARATOR_DATA_RAW_JSON, None, "__test_file")
    assert load_text_file(item) == test_str

    # Test file does not exist
    item = KeyValueArg(SEPARATOR_DATA_RAW_JSON, None, "__not_exist_file")
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == "\"__not_exist_file\": [Errno 2] No such file or directory: '__not_exist_file'"
    else:
        raise Exception

# Generated at 2022-06-21 13:35:45.250582
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Create test file named test.txt with content 'test' in current dir
    testfile = open('test.txt', 'w')
    testfile.write('test')
    testfile.close()
    # Check if file is created
    if os.path.isfile('test.txt'):
        # Check if content is 'test'
        assert process_file_upload_arg(KeyValueArg(
            'test.txt',
            'test.txt',
            '@')
        )[0] == 'test.txt'
    # Clean up test file
    os.remove('test.txt')

# Generated at 2022-06-21 13:35:47.084441
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # Given
    h = KeyValueArg(b"Header;",h)
    
    # When
    x = process_empty_header_arg(h)

    # Then
    assert x == None

# Generated at 2022-06-21 13:35:52.574767
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="head", sep="&", value='filename.txt')
    assert process_file_upload_arg(arg) == ("filename.txt", "f", "get_content_type")
    arg = KeyValueArg(key="head", sep="&", value='filename.txt&image/png')
    assert process_file_upload_arg(arg) == ("filename.txt", "f", "image/png")


# Generated at 2022-06-21 13:37:04.042141
# Unit test for constructor of class RequestItems
def test_RequestItems():
    cli_args = [
        KeyValueArg('key1', 'val1', u';', u'key1;val1'),
        KeyValueArg('key2', 'val2', u'@', u'key2@val2')
    ]
    RequestItems.from_args(cli_args)

# Generated at 2022-06-21 13:37:06.732551
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    kvarg = KeyValueArg('data', 'a=1&b=2', SEPARATOR_DATA_STRING)
    assert process_data_item_arg(kvarg) == 'a=1&b=2'



# Generated at 2022-06-21 13:37:16.666581
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test.txt")) == "abcdefg"
    assert load_text_file(KeyValueArg("test1.txt")) == "abcdefg"
    assert load_text_file(KeyValueArg("test2.txt")) == "abcdefg"
    assert load_text_file(KeyValueArg("test3.txt")) == '''"1","2"
    "3","4"'''
    assert load_text_file(KeyValueArg("test4.txt")) == '''"1","2"
    "3","4"'''
    assert load_text_file(KeyValueArg("test5.txt")) == '''"1","2"
    "3","4"'''

# Generated at 2022-06-21 13:37:19.266362
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key = "A"
    value = "B"
    arg = KeyValueArg(key, value)
    assert process_data_embed_file_contents_arg(arg) == "B"


# Generated at 2022-06-21 13:37:26.087232
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg("file", "filename", SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == "filename"
    assert mime_type == None

    arg = KeyValueArg("file", "filename|text/plain", SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == "filename"
    assert mime_type == "text/plain"

# Generated at 2022-06-21 13:37:29.420618
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(key='data', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, value='~/sample.txt')
    print(process_data_embed_file_contents_arg(arg))
    

# Generated at 2022-06-21 13:37:41.704564
# Unit test for function load_json
def test_load_json():
    import sys
    from httpie.cli.parser import parse_args
    from httpie.cli.debug import configure_logging
    import logging
    import json

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    configure_logging()

    # Test with jsonkv argument
    args = parse_args(['@test_load_json.json'])
    request_items = RequestItems.from_args(list(args.items))
    print('#1')
    print(json.dumps(request_items.data, indent=4))
    # {"key1": "value1", "key2": "value2"}

    # Test with json embedded in the string argument
    args = parse_args(['key=@test_load_json.json'])

# Generated at 2022-06-21 13:37:44.570214
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('key', 'value', '%s=%s' % ('key', 'value'))
    assert process_data_item_arg(arg) == 'value'


# Generated at 2022-06-21 13:37:46.695390
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    item = KeyValueArg('a=b')
    assert process_query_param_arg(item) == 'b'



# Generated at 2022-06-21 13:37:51.664672
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    from httpie.cli.args import KeyValueArg
    item = KeyValueArg("name=John", "name")
    test_result = process_data_item_arg(item)
    assert test_result == "John"

