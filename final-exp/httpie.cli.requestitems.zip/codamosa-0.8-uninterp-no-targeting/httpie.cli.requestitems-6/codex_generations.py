

# Generated at 2022-06-21 13:29:45.385425
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    file_path = "./test_data_raw_json_file.json"
    arg = KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, file_path, file_path)
    print(process_data_embed_raw_json_file_arg(arg))


if __name__ == '__main__':
    test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-21 13:29:55.645521
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():

    # Error
    # 1. non-exist file
    try:
        process_data_embed_file_contents_arg(
            KeyValueArg(['-f'], '', 'x', 'test.txt'))
    except ParseError as e:
        assert(str(e) == '"x": [Errno 2] No such file or directory: \'test.txt\'')

    # 2. not a UTF8 or ASCII-encoded text file

# Generated at 2022-06-21 13:29:57.764875
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('header', 'value')) == 'value'
    assert process_header_arg(KeyValueArg('header', None)) == None


# Generated at 2022-06-21 13:30:05.954659
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    a="abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc"
    filename='tmp'
    f=open(filename,'w+')
    f.write(a)
    f.close()
    b="a;@"+filename
    k=KeyValueArg(key="a",value=filename,sep="@")
    assert process_data_embed_file_contents_arg(k)==a

test_process_data_embed_file_contents_arg()

# Generated at 2022-06-21 13:30:13.067826
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:30:20.542195
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(sep=";", key="TestKey1", value="TestValue1")
    assert process_empty_header_arg(arg) == "TestValue1"
    arg = KeyValueArg(sep=";", key="TestKey2", value="")
    with pytest.raises(ParseError):
        process_empty_header_arg(arg)
    arg = KeyValueArg(sep=";", key="TestKey3", value=None)
    assert process_empty_header_arg(arg) == ""

# Generated at 2022-06-21 13:30:25.488817
# Unit test for function process_header_arg
def test_process_header_arg():
    # Test 1: test with a string
    print("TEST: process_header_arg with a string")
    result = process_header_arg("Authorization: Bearer test_token")
    assert result == "test_token", "Result is {}".format(result)

    # Test 2: test with an empty string
    print("TEST: process_header_arg with an empty string")
    result = process_header_arg("Authorization:")
    assert result is None, "Result is {}".format(result)


# Generated at 2022-06-21 13:30:27.367328
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_args = [KeyValueArg(value='test.json', sep='=@')]
    result = process_data_embed_file_contents_arg(test_args[0])
    print(result)

# Generated at 2022-06-21 13:30:29.997813
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg("--data-embed-raw-json-file", "foo", ";")) == "foo"

# Generated at 2022-06-21 13:30:36.917241
# Unit test for constructor of class RequestItems
def test_RequestItems():
    requestitems = RequestItems()
    assert(type(requestitems.headers) == RequestHeadersDict)
    assert(type(requestitems.data) == RequestJSONDataDict)
    assert(type(requestitems.files) == RequestFilesDict)
    assert(type(requestitems.params) == RequestQueryParamsDict)
    assert(type(requestitems.multipart_data) == MultipartRequestDataDict)


# Generated at 2022-06-21 13:31:03.806953
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestQueryParamsDict
    from httpie.cli.dicts import RequestFilesDict
    from httpie.cli.dicts import MultipartRequestDataDict


    class RequestItems:
        def __init__(self, as_form=False):
            self.headers = RequestHeadersDict()
            self.data = RequestDataDict() if as_form else RequestJSONDataDict()
            self.files = RequestFilesDict()
            self.params = RequestQueryParamsDict()
            # To preserve the order of fields in file upload multipart requests.
            self.multipart_data

# Generated at 2022-06-21 13:31:08.530249
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(':=', "test", "{'a':'b'}")
    contents = "{'a':'b'}"
    result = load_json(arg, contents)
    assert(result['a'] == 'b')

# Generated at 2022-06-21 13:31:16.332815
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    file_header = 'Content-Disposition: form-data; name="key1"'

    # test for content with only 1 line
    data_file = io.StringIO("line1")
    data_file.seek(0)

    result = process_data_embed_file_contents_arg(KeyValueArg(":", "key1"))
    assert result == "line1"

    # test for content with multiple lines
    data_file = io.StringIO("line1\nline2\nline3")
    data_file.seek(0)

    result = process_data_embed_file_contents_arg(KeyValueArg(":", "key1"))
    assert result == "line1\nline2\nline3"

    # test for content with multiple lines and file headers

# Generated at 2022-06-21 13:31:28.987500
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Verify that constructor works correctly
    items = RequestItems()
    assert isinstance(items.headers, RequestHeadersDict)
    assert isinstance(items.data, RequestJSONDataDict)
    assert isinstance(items.files, RequestFilesDict)
    assert isinstance(items.params, RequestQueryParamsDict)
    assert isinstance(items.multipart_data, MultipartRequestDataDict)

    items = RequestItems(as_form=True)
    assert isinstance(items.headers, RequestHeadersDict)
    assert isinstance(items.data, RequestDataDict)
    assert isinstance(items.files, RequestFilesDict)
    assert isinstance(items.params, RequestQueryParamsDict)
    assert isinstance(items.multipart_data, MultipartRequestDataDict)



# Generated at 2022-06-21 13:31:37.084968
# Unit test for function process_header_arg
def test_process_header_arg():
    assert 'asdasd' == process_header_arg(KeyValueArg('AsdAsd', 'asdasd'))
    assert 'asdasd' == process_header_arg(KeyValueArg('AsdAsd', 'asdasd', ';'))
    assert 'asdasd' == process_header_arg(KeyValueArg('AsdAsd', 'asdasd', ':'))
    assert None == process_header_arg(KeyValueArg('AsdAsd', None, ';'))
    assert None == process_header_arg(KeyValueArg('AsdAsd', None, ':'))
    assert '' == process_header_arg(KeyValueArg('AsdAsd', '', ';'))

# Generated at 2022-06-21 13:31:47.624501
# Unit test for function load_text_file
def test_load_text_file():
    from io import StringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        path = "http://www.google.com"
        contents = load_text_file(path)
        out.seek(0)
        sys.stdout.flush()
        output = out.read()
        result = output.split("\n")[1]
        assert result == "<HTML><HEAD><meta http-equiv=\"content-type\" content=\"text/html;charset=utf-8\">"
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-21 13:31:53.203286
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie import clients
    arg = KeyValueArg("test", "test_arg", "test_value")
    client = clients.HTTPie([]).config
    assert process_data_item_arg(arg) == "test_value"
    assert process_data_item_arg(arg) is not None


# Generated at 2022-06-21 13:31:55.609461
# Unit test for function load_json
def test_load_json():
    # Test for the case when json file is not in the right format
    json_value = load_json(None, "abc")
    assert json_value == "abc"

# Generated at 2022-06-21 13:31:59.251306
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    r = RequestItems()
    r.data = process_data_embed_file_contents_arg("test=C:\\users\\\"Test Name\"\\appdata\\local\\programs\\python\\python37-32\\Lib\\site-packages\\httpie\\cli\\test_request_items.py")
    print(r.data)

# Generated at 2022-06-21 13:32:00.810947
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg("k;v")
    r = process_data_raw_json_embed_arg(arg)
    assert(r == dict(k="v"))

# Generated at 2022-06-21 13:32:16.560870
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # test normal scenario
    arg1 = KeyValueArg(
        sep=SEPARATOR_HEADER_EMPTY,
        key='Content-Type',
        value='',
        orig='Content-Type;'
    )
    value_processed_arg1 = process_empty_header_arg(arg1)
    assert value_processed_arg1 == ''

    # test exception
    arg2 = KeyValueArg(
        sep=SEPARATOR_HEADER_EMPTY,
        key='Content-Type',
        value='value_present',
        orig='Content-Type;value_present'
    )
    with pytest.raises(ParseError):
        value_processed_arg2 = process_empty_header_arg(arg2)

# Generated at 2022-06-21 13:32:25.079043
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    test_arg_empty = KeyValueArg(
        key='Accept',
        orig='Accept;',
        sep=';'
    )
    assert process_empty_header_arg(test_arg_empty) == ''
    test_arg_not_empty = KeyValueArg(
        key='Accept',
        orig='Accept;test',
        sep=';'
    )

    with pytest.raises(ParseError):
        process_empty_header_arg(test_arg_not_empty)

# Generated at 2022-06-21 13:32:30.671684
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # test for ascii file
    item = KeyValueArg("input", "key1", "val1")
    assert(process_data_embed_file_contents_arg(item) == "val1")

    # test for non-ascii file
    item = KeyValueArg("input", "key1", "val1")
    assert(process_data_embed_file_contents_arg(item) == "val1")


# Generated at 2022-06-21 13:32:32.004030
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg("") == ""


# Generated at 2022-06-21 13:32:36.483089
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_QUERY_PARAM,
        key='limit',
        value=50,
        orig='limit:50',
    )

    result = process_query_param_arg(arg)
    assert result == 50




# Generated at 2022-06-21 13:32:40.919262
# Unit test for function load_text_file
def test_load_text_file():
    with pytest.raises(ParseError):
        load_text_file(KeyValueArg('a', 'b'))
        load_text_file(KeyValueArg('file', "filedoesnotexist.txt"))
    load_text_file(KeyValueArg('file', "test.txt"))

# Generated at 2022-06-21 13:32:44.330918
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg
    # test1 no value
    arg_test1 = KeyValueArg(key='id', sep='==', orig='id==',value='')
    assert process_query_param_arg(arg_test1) == ''

# Generated at 2022-06-21 13:32:48.211261
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    kv_arg = KeyValueArg('', '?k1=v1', SEPARATOR_QUERY_PARAM)
    assert('v1' == process_query_param_arg(kv_arg))
    assert('key' == process_query_param_arg(KeyValueArg('', '?key=', SEPARATOR_QUERY_PARAM)))


# Generated at 2022-06-21 13:32:54.734991
# Unit test for function load_json
def test_load_json():
    assert load_json(KeyValueArg(None, None, None), '{"a":"b"}') == {"a":"b"}
    assert load_json(KeyValueArg(None, None, None), '{"a":"b", "c": 1}') == {"a":"b", "c": 1}
    assert load_json(KeyValueArg(None, None, None), '{"a":"b", "c": [1, 2, 3]}') == {"a":"b", "c": [1, 2, 3]}



# Generated at 2022-06-21 13:33:02.767365
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from argparse import Namespace
    from httpie.cli.parser import parse_items

    args = Namespace(
        data=[
            KeyValueArg(
                sep=SEPARATOR_DATA_RAW_JSON,
                key=None,
                value='{ "hello": "world" }',
                orig="'@{ \"hello\": \"world\" }'",
            ),
        ],
    )
    items = parse_items(args)
    assert items['data'] == { "hello": "world"}

# Generated at 2022-06-21 13:33:18.364693
# Unit test for function load_json
def test_load_json():
    pass

# Generated at 2022-06-21 13:33:21.696346
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg(None, 'key', 'value'))


# Generated at 2022-06-21 13:33:26.992787
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key_sep = 'data_embed_file_contents_arg'
    arg = KeyValueArg(key_sep, separator_set={";"})
    arg.key = 'data_embed_file_contents_arg'
    arg.sep = ';'
    arg.value = 'request.json'
    assert process_data_embed_file_contents_arg(arg) == '{"name":"httpie"}'

# Generated at 2022-06-21 13:33:36.350822
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_dict = [
        {'name': 'LiuXiaoFab', 'age': 6, 'gender': 'Male', 'location': 'China'},
        {'name': 'LiuXiaoLiang', 'age': 11, 'gender': 'Male', 'location': 'China'},
        {'name': 'ZhangXueXue', 'age': 6, 'gender': 'Female', 'location': 'China'},
        {'name': 'LiXueXue', 'age': 3, 'gender': 'Female', 'location': 'China'}
    ]
    filename = 'test_dict.txt'
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(json.dumps(test_dict, sort_keys=True))

# Generated at 2022-06-21 13:33:39.950520
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key='', orig='', sep='', value='')
    assert process_data_item_arg(arg) == ''


# Generated at 2022-06-21 13:33:48.856497
# Unit test for constructor of class RequestItems
def test_RequestItems():
    import pytest
    from httpie.cli import argparser
    # single header
    args = argparser.parse_args("http://www.google.com/ -H Content-Type:application/json".split(" "))
    request_items = RequestItems.from_args(args.items)
    assert request_items.headers.get("Content-Type") == "application/json"
    # multiple headers
    args = argparser.parse_args("http://www.google.com/ -H Content-Type:application/json -H language:en".split(" "))
    request_items = RequestItems.from_args(args.items)
    assert request_items.headers.get("Content-Type") == "application/json"
    assert request_items.headers.get("language") == "en"
    # single query
    args = argparser

# Generated at 2022-06-21 13:33:50.962592
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    kva = KeyValueArg(key=None, value='{"key":"value"}', sep='=')
    res = process_data_raw_json_embed_arg(kva)
    assert res == {"key":"value"}


# Generated at 2022-06-21 13:33:55.050082
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg(KeyValueArg(
        '@fixture/httpbin', '@', '@fixture/httpbin')) == '{"args": {}, "headers": {}}'



# Generated at 2022-06-21 13:34:01.396613
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import (
    RequestHeadersDict
    )
    from httpie.cli.exceptions import ParseError

    instance = RequestHeadersDict()
    arg = KeyValueArg("test;","testdata")
    try:
        process_empty_header_arg(arg)
    except ParseError as e:
        print("ParseError:" + str(e))


# Generated at 2022-06-21 13:34:07.381862
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    
    # Case 1: String value
    arg = KeyValueArg(orig='Host:', sep=';', key='Host', value='')
    try:
        process_empty_header_arg(arg)
    except ParseError:
        assert arg.value == '', "Empty value should not raise ParseError"
    
    
    # Case 2: Non-empty string value
    arg = KeyValueArg(orig='Host:www.baidu.com', sep=';', key='Host', value='www.baidu.com')
    try:
        process_empty_header_arg(arg)
    except ParseError:
        assert arg.value == '', "Non-empty value should raise ParseError"
        
test_process_empty_header_arg()

# Generated at 2022-06-21 13:35:21.632513
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    json_string = '{"a": 1}'
    json_dict = {'a': 1}
    json_string_with_arg = '--data-raw-json ' + json_string
    item = KeyValueArg.from_parts(json_string_with_arg, sep=' ')
    assert process_data_raw_json_embed_arg(item) == json_dict
    assert process_data_raw_json_embed_arg(item) == json_dict

# Generated at 2022-06-21 13:35:25.465883
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    expected = {'b': {'b-1': 2}, 'c': 'c', 'a': 1}
    value = process_data_embed_raw_json_file_arg(KeyValueArg('', '', '', 'test.json'))  # type: ignore
    assert value == expected

# Generated at 2022-06-21 13:35:32.635414
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key1 = "item_1"
    key2 = "item_2"
    value1 = "file_value_1"
    value2 = "file_value_2"
    value3 = "file_value_3"
    value4 = "file_value_4"
    value5 = "file_value_5"
    value6 = "file_value_6"
    value7 = "file_value_7"
    value8 = "file_value_8"

    json_value1 = "json_value_1"
    json_value2 = "json_value_2"
    json_value3 = "json_value_3"

    file1 = 'temp_file'
    with open(file1, 'w') as f:
        f.write(value1)


# Generated at 2022-06-21 13:35:37.366969
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    testcase = (
        KeyValueArg(
            key='name',
            sep=SEPARATOR_DATA_STRING,
            value='value',
            orig=':'
        ),
        "value"
    )

    assert process_data_item_arg(testcase[0]) == testcase[1]


# Generated at 2022-06-21 13:35:44.036606
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_path = os.path.dirname(__file__)
    filename = os.path.join(file_path, 'request_items.py')
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value=filename)
    file_name, file_object, mime_type = process_file_upload_arg(arg)
    assert file_name == 'request_items.py'
    assert mime_type == 'text/x-python'
    assert isinstance(file_object, IO)
    file_object.close()


# Generated at 2022-06-21 13:35:46.755421
# Unit test for function load_text_file
def test_load_text_file():
    item_arg = KeyValueArg(orig="key2",sep=";",key="key2",value="../key2.txt")
    assert load_text_file(item_arg) == b"hello world 2\n"


# Generated at 2022-06-21 13:35:48.443980
# Unit test for function load_json
def test_load_json():
    assert load_json('a', '{ "a": 1, "b": 2 }') == { "a": 1, "b": 2 }



# Generated at 2022-06-21 13:35:52.881577
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(sep=SEPARATOR_QUERY_PARAM, key='key', value='value')
    if process_query_param_arg(arg)!='value':
        raise AssertionError('Query param value should be equal value')
    if process_query_param_arg(arg) == 'invalid_value':
        raise AssertionError('Query param value should not be equal invalid_value')

# Generated at 2022-06-21 13:35:54.963247
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(orig="foo=bar", key="foo", sep="=", value="bar")
    assert(process_data_item_arg(arg) == "bar")


# Generated at 2022-06-21 13:36:00.093544
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    header_value = ''
    header_key = 'header_key'
    arg = KeyValueArg(header_key, header_value, '', '')
    try:
        process_empty_header_arg(arg)
    except ParseError:
        assert False, 'Invalid response from function process_empty_header_arg()'

    header_value = 'xyz'
    arg = KeyValueArg(header_key, header_value, '', '')
    try:
        process_empty_header_arg(arg)
        assert False, 'Invalid response from function process_empty_header_arg()'
    except ParseError:
        pass



# Generated at 2022-06-21 13:37:02.929752
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg('key', 'value')) == 'value'


# Generated at 2022-06-21 13:37:13.523540
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.parser import KeyValueArg

    # test empty dict
    key_value_item_1 = "-d {""}"
    item_1 = KeyValueArg.parse(key_value_item_1)
    assert process_data_raw_json_embed_arg(item_1) == {}

    # test empty list
    key_value_item_2 = "-d []"
    item_2 = KeyValueArg.parse(key_value_item_2)
    assert process_data_raw_json_embed_arg(item_2) == []

    # test normal dict
    key_value_item_3 = r'-d {"city": "London", "street": "Main"}'
    item_3 = KeyValueArg.parse(key_value_item_3)
    assert process_data_raw_json_embed

# Generated at 2022-06-21 13:37:16.966357
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_request_item = KeyValueArg(
        'request_item',
        '@',
        '@test.txt',
        'request_item',
    )
    assert process_data_embed_file_contents_arg(test_request_item) == "test data\n"

# Generated at 2022-06-21 13:37:23.698729
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(':', '', '',)
    assert process_empty_header_arg(arg) == ''
    arg = KeyValueArg(':', '', '', '0')
    assert process_empty_header_arg(arg) == '0'
    arg = KeyValueArg(':', '', '', '1')
    assert process_empty_header_arg(arg) == '1' 
    arg = KeyValueArg(':', '', '', 0)
    assert process_empty_header_arg(arg) == '0'
    arg = KeyValueArg(':', '', '', 1)
    assert process_empty_header_arg(arg) == '1'

# Generated at 2022-06-21 13:37:34.639469
# Unit test for function load_text_file
def test_load_text_file():
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    # When file is created, it is closed.
    temp_file = open(temp_file.name, 'w', encoding='utf-8')
    temp_file.write('Test load_text_file')
    temp_file.close()
    request_item_args = [KeyValueArg('load_text_file', 'File',
                                     '.%s%s' % (SEPARATOR_DATA_EMBED_FILE_CONTENTS, temp_file.name))]
    request_items = RequestItems.from_args(request_item_args=request_item_args)
    os.remove(temp_file.name)
    return request_items.data

# Generated at 2022-06-21 13:37:38.560046
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(sep='Header',key='k',value='v')) == 'v'
    assert process_header_arg(KeyValueArg(sep='Header',key='k',value='')) is None

# Generated at 2022-06-21 13:37:45.360321
# Unit test for function process_header_arg
def test_process_header_arg():
    # Check case with value
    h_arg_with_value = KeyValueArg(sep=SEPARATOR_HEADER, orig='h=value', key='h', value='value')
    assert process_header_arg(h_arg_with_value) == 'value'
    # Check case with null value
    h_arg_with_no_value = KeyValueArg(sep=SEPARATOR_HEADER, orig='h', key='h', value=None)
    assert process_header_arg(h_arg_with_no_value) == None



# Generated at 2022-06-21 13:37:47.935259
# Unit test for function process_header_arg
def test_process_header_arg():
    args = KeyValueArg("k: v")
    assert process_header_arg(args) == "v"


# Generated at 2022-06-21 13:37:52.029342
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg('Header1;') == process_header_arg('Header1=')
    assert process_empty_header_arg('Header2;') == process_header_arg('Header2')

# Generated at 2022-06-21 13:37:58.242892
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    path = os.getcwd()+"/tests/data/test.txt"
    expected_value = "Hello world"
    data_item_arg = KeyValueArg("", "", "", "", "", "")
    data_item_arg.value = path
    result = process_data_embed_file_contents_arg(data_item_arg)
    assert result == expected_value