

# Generated at 2022-06-21 13:29:45.105690
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # create a new KeyValueArg
    arg = KeyValueArg('name=httpie', 'name', 'httpie', '=')
    # call the method with the argument
    result = process_query_param_arg(arg)
    # test that the result is correct
    assert result == 'httpie'



# Generated at 2022-06-21 13:29:49.701551
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(orig="json", key="json", sep='', value='{"k":123}')
    contents = '{"k":123}'
    try:
        load_json(arg, contents)
    except ValueError:
        assert False
    finally:
        assert True



# Generated at 2022-06-21 13:29:51.852799
# Unit test for constructor of class RequestItems
def test_RequestItems():
    '''
    Test the constructor of the RequestItems class.
    '''
    res = RequestItems.from_args([], True)
    assert isinstance(res, RequestItems)
    assert isinstance(res.data, RequestDataDict)
    assert isinstance(res.multipart_data, MultipartRequestDataDict)
    assert isinstance(res.params, RequestQueryParamsDict)



# Generated at 2022-06-21 13:29:54.269359
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_arg = KeyValueArg()
    test_arg.value = "test_value"
    assert process_data_item_arg(test_arg) == test_arg.value

# Generated at 2022-06-21 13:29:55.896636
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg("a=b") == "b"


# Generated at 2022-06-21 13:30:00.954945
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg1 = KeyValueArg(key='upload', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg1) == ('test.txt', open('test.txt', 'rb'), 'application/octet-stream')
    arg2 = KeyValueArg(key='upload', value='test.txt;image/jpeg', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg2) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')

# Generated at 2022-06-21 13:30:05.177319
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(
        key='key',
        value='value',
        orig='key=value',
        sep=SEPARATOR_QUERY_PARAM,
    )
    assert process_query_param_arg(arg) == 'value'


# Generated at 2022-06-21 13:30:08.273671
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(orig='header:value', key='header', value='value', sep=':')
    assert (process_header_arg(arg) == 'value')


# Generated at 2022-06-21 13:30:16.068088
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key = None,
        value = '{"key":"value"}',
        sep = SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig = '@file.json',
        sep_orig = SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )
    actual = process_data_embed_raw_json_file_arg(arg)
    expected = {"key":"value"}
    assert actual == expected



# Generated at 2022-06-21 13:30:24.961699
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:30:40.827143
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('foo', 'bar')
    try:
        load_json(arg, 'asdfasdf')
    except ParseError:
        pass

# Generated at 2022-06-21 13:30:43.776758
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg=KeyValueArg('data', '{"e":"1"}')
    process_data_raw_json_embed_arg(arg)

# Generated at 2022-06-21 13:30:47.165912
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    process_data_item_arg(KeyValueArg(key="a", value="a", sep=SEPARATOR_DATA_STRING, orig="a=a"))
    with pytest.raises(ParseError):
        process_data_item_arg(KeyValueArg(key="a", value="a", sep=SEPARATOR_DATA_STRING, orig="a==a"))



# Generated at 2022-06-21 13:30:48.874491
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg(1, "", "", "", "", "")
    item.key = "f"
    item.value = "1"
    process_data_raw_json_embed_arg(item)

# Generated at 2022-06-21 13:30:50.435587
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg("a", "value")) == 'value'


# Generated at 2022-06-21 13:30:54.560056
# Unit test for function load_text_file
def test_load_text_file():
    from io import BytesIO
    from unittest import mock

    m = mock.mock_open()
    with mock.patch('httpie.cli.dicts.open', m, create=True):
        m.return_value.__enter__.return_value = BytesIO(b'unicode: \xe5\xe4\xf6')
        value = load_text_file(KeyValueArg("header", "filePath"))
        assert value == "unicode: åäö"

# Generated at 2022-06-21 13:30:56.741142
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg("-d test=test")) == "test=test"

# Generated at 2022-06-21 13:31:00.576132
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(orig='name=value', key='name', sep='=', value='value')
    result = process_data_item_arg(arg)
    assert result == 'value'

# Generated at 2022-06-21 13:31:04.639810
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    req = RequestItems()
    arg = KeyValueArg('', '', 'Header;', 'Header: ;')
    req.headers = process_empty_header_arg(arg)
    assert (req.headers['Header'] == '')

# Generated at 2022-06-21 13:31:10.494491
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    json_str = '{"a":"b"}'
    arg = KeyValueArg(key='', sep='=', value=json_str, orig=json_str)
    result = process_data_raw_json_embed_arg(arg)
    assert type(result) is dict
    assert len(result) == 1
    assert 'a' in result



# Generated at 2022-06-21 13:31:42.343714
# Unit test for function process_header_arg
def test_process_header_arg():
    # An existing header
    assert 'Accept' == process_header_arg(KeyValueArg('Accept', '*/*'))

    # A header that doesn't exist
    assert None == process_header_arg(KeyValueArg('Accept1', '*/*'))

# An existing header

# Generated at 2022-06-21 13:31:47.250751
# Unit test for function load_text_file
def test_load_text_file():
    from httpie.cli.dicts import RequestDataDict

    d = RequestDataDict()
    d["data"] = load_text_file("@hello.txt")
    print(d)
    d["json"] = load_json("@hello.json")
    print(d)

# Generated at 2022-06-21 13:31:50.056095
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    value = process_data_raw_json_embed_arg(KeyValueArg('', '', 'a', '{"a":1}'))
    assert value == {"a": 1}

# Generated at 2022-06-21 13:31:53.769010
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    instance = RequestItems()
    arg = KeyValueArg(key = "test_file", value="test.py")
    process_file_upload_arg(arg)
    instance.files[arg.key] = arg.value



# Generated at 2022-06-21 13:31:58.126947
# Unit test for function load_text_file
def test_load_text_file():
    from tempfile import NamedTemporaryFile
    from os import remove

    with NamedTemporaryFile(mode='wb', delete=False) as temp:
        temp.write(b'hello')
        filename = temp.name
    file_obj = load_text_file(KeyValueArg(orig='', key='', value=filename))
    remove(filename)
    assert file_obj == 'hello'

# Generated at 2022-06-21 13:32:05.630496
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    print("Test process_data_item_arg")
    arg = KeyValueArg("key", "value", "data")
    assert 'key' == arg.key
    assert 'value' == arg.value
    assert 'data' == arg.sep
    assert 'key=value' == arg.orig
    assert process_data_item_arg(arg) == "value"
    print("PASSED")


# Generated at 2022-06-21 13:32:09.327053
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(key='', sep='=', orig='=@json_data', value='@json_data')
    assert isinstance(process_data_embed_raw_json_file_arg(item), dict)



# Generated at 2022-06-21 13:32:12.838261
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    query_param_arg = KeyValueArg('key=value', 'key', '=', 'value')
    assert 'value' == process_query_param_arg(query_param_arg)


# Generated at 2022-06-21 13:32:17.416502
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(':content-type', 'json', ':content-type=json')) == 'json'
    assert process_header_arg(KeyValueArg(':content-type', None, ':content-type')) is None



# Generated at 2022-06-21 13:32:18.895590
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert type(RequestItems()) is RequestItems


# Generated at 2022-06-21 13:33:15.750120
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    actual = process_query_param_arg(KeyValueArg('key', 'value', ''))
    assert actual == 'value'

# Generated at 2022-06-21 13:33:18.533025
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args = KeyValueArg('a', 'b', 'c', 'd')
    assert process_file_upload_arg(args) == ('a', 'b', 'c')

# Generated at 2022-06-21 13:33:22.712757
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg(
        orig='@Json', sep='@Json', key='Json', value='json.json'))



# Generated at 2022-06-21 13:33:26.494095
# Unit test for function process_header_arg
def test_process_header_arg():
    key = 'some-key'
    value = 'some-value'
    arg = KeyValueArg('%s: %s' % (key, value))
    assert process_header_arg(arg) is not None

    arg = KeyValueArg('%s:' % key)
    assert process_header_arg(arg) is None


# Generated at 2022-06-21 13:33:29.948110
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('', separator='<', name='', value='test.json', orig='< test.json')
    assert process_data_embed_file_contents_arg(arg) == '{}\n'


# Generated at 2022-06-21 13:33:33.681072
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems.from_args([KeyValueArg('a','b'), KeyValueArg('c','d')], as_form=False)
    assert items.params.get('a') == 'b'
    assert items.params.get('c') == 'd'

# Generated at 2022-06-21 13:33:36.350593
# Unit test for function load_json
def test_load_json():
    assert load_json(None, '{"a": "test"}') == {'a': 'test'}
    assert load_json(None, '{"b": "test"}') == {'b': 'test'}

# Generated at 2022-06-21 13:33:41.030894
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    key = 'key'
    value = 'value'
    sep = SEPARATOR_FILE_UPLOAD
    arg = KeyValueArg(key, value, sep)
    res = process_file_upload_arg(arg)
    print("res="+str(res))



# Generated at 2022-06-21 13:33:44.727206
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg("a", SEPARATOR_DATA_EMBED_RAW_JSON_FILE, "test_file")
    json_dict = process_data_embed_raw_json_file_arg(arg)
    assert "test_file" == json_dict["filename"]
    assert "file content" == json_dict["content"]
    assert "file content" == json_dict["properties"]["detail"]

# Generated at 2022-06-21 13:33:48.095244
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(orig='embedfile', sep='==>', key='', value='~/Downloads/test.txt')
    print(process_data_embed_file_contents_arg(arg))
    # arg = KeyValueArg(orig='embedfile', sep='==>', key='', value='/test.txt')
    # print(process_data_embed_file_contents_arg(arg))


# Generated at 2022-06-21 13:34:59.287675
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg1 = KeyValueArg(
        key='key',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        value='value'
    )
    arg2 = KeyValueArg(
        key='key',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        value='etc/test_data/utf8.txt'
    )
    assert process_data_embed_file_contents_arg(arg1) == 'value'
    assert process_data_embed_file_contents_arg(arg2) == '你好，世界\n'

# Generated at 2022-06-21 13:35:00.604124
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('foo', "baz")) == 'baz'

# Generated at 2022-06-21 13:35:02.283168
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('a-header;', ';')) is ''

# Generated at 2022-06-21 13:35:11.147025
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test"
    mime_type = "mime"
    file_open_return = "file content"

    def mock_file_open_rb(filename, mime_type):
        return "file content"

    arg = KeyValueArg('key', 'value', 'sep')
    arg.value = "{}{}{}".format(filename, SEPARATOR_FILE_UPLOAD_TYPE, mime_type)

    with mock.patch('builtins.open', mock_file_open_rb):
        assert process_file_upload_arg(arg) == (filename, file_open_return, mime_type)

# Generated at 2022-06-21 13:35:17.138951
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(
        "Header key",
        "Header Value",
        "Header key:Header Value"
    )) == "Header Value"
    assert process_header_arg(KeyValueArg(
        "Header key",
        "",
        "Header key:"
    )) == ""
    assert process_header_arg(KeyValueArg(
        "Header key",
        None,
        "Header key"
    )) is None



# Generated at 2022-06-21 13:35:19.725480
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    input = KeyValueArg("arg-name", SEPARATOR_DATA_EMBED_FILE_CONTENTS, "arg-value")
    assert process_data_embed_file_contents_arg(input) == "file-contents"


# Generated at 2022-06-21 13:35:23.690189
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Create a mock argument to run the function
    arg = KeyValueArg(key="foo", sep="=", value='/home/mock_file_foo.txt')
    # Calling the function to test
    # Return_value is the file contents of /home/mock_file_foo.txt
    return_value = process_file_upload_arg(arg)
    # Assert if the function returns the file contents of the file that is passed in
    assert return_value[2] == "text/plain"

# Generated at 2022-06-21 13:35:25.834293
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('a=b')
    assert process_query_param_arg(arg) == 'b'



# Generated at 2022-06-21 13:35:28.021672
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='README.md', sep='=')
    print(load_text_file(item))

# Generated at 2022-06-21 13:35:38.203846
# Unit test for function load_json
def test_load_json():
    assert load_json_preserve_order('{"a":1,"b":2,"c":3}') == \
        {"a": 1, "b": 2, "c": 3}
    assert load_json_preserve_order('{"a":1,"b":2,"c":{"d":"e"},"f":[1,2,3]}') == \
        {"a": 1, "b": 2, "c": {"d": "e"}, "f": [1, 2, 3]}

# Generated at 2022-06-21 13:38:46.708927
# Unit test for function load_json
def test_load_json():
    assert load_json(arg=KeyValueArg(orig='', sep='', key='', value=''), contents='{"a": "a"}') == {'a': 'a'}



# Generated at 2022-06-21 13:38:51.356562
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg('header', ';', 'key', 'value')
    assert process_header_arg(header_arg) == 'value'
    header_arg = KeyValueArg('header', ';', 'key', '')
    assert process_header_arg(header_arg) == ''


# Generated at 2022-06-21 13:38:58.812170
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    fp = BytesIO(b'contents')
    rv = process_file_upload_arg(KeyValueArg(None, 'test;', None))
    assert rv[0] == 'test'
    assert rv[2] == 'text/plain'
    rv = process_file_upload_arg(KeyValueArg(None, 'test;text/ascii', None))
    assert rv[0] == 'test'
    assert rv[2] == 'text/ascii'
    rv = process_file_upload_arg(KeyValueArg(None, '@test;text/ascii', None))
    assert rv[0] == 'test'
    assert rv[2] == 'text/ascii'

# Generated at 2022-06-21 13:39:01.513026
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('Header:value')
    assert process_header_arg(arg) == 'value'



# Generated at 2022-06-21 13:39:04.861668
# Unit test for function load_text_file
def test_load_text_file():
    item=KeyValueArg(orig='test;', sep=';', key='test', value='test.py')

    assert load_text_file(item) == """# Test file"""

# Generated at 2022-06-21 13:39:09.638529
# Unit test for function load_json
def test_load_json():
    json_data = '[{"name": "Epictetus","age": 55,"city": "Hierapolis"},{"name": "Seneca","age": 65,"city": "Rome"}]'
    print(load_json('test', json_data))
    json_data = '{"1": 1, "2": 2, "3": 3}'
    print(load_json('test', json_data))


# Generated at 2022-06-21 13:39:12.145209
# Unit test for function load_text_file
def test_load_text_file():
    class FakeArg(object):
        def __init__(self, orig, value):
            self.orig = orig
            self.value = value
    text = load_text_file(FakeArg("test1", 'test.txt'))
    assert text == "123\n456\n789"
    text = load_text_file(FakeArg("test1", 'test2.txt'))
    assert text == "test2"
    text = load_text_file(FakeArg("test1", 'test3.txt'))
    assert text == "test3"

# Generated at 2022-06-21 13:39:18.367921
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # as_form
    test_request_items = RequestItems(as_form=True)
    assert isinstance(test_request_items.data, RequestDataDict)

    # not as_form
    test_request_items = RequestItems(as_form=False)
    assert isinstance(test_request_items.data, RequestJSONDataDict)

    # from_args
    from httpie.cli.argtypes import KeyValueArg

# Generated at 2022-06-21 13:39:21.285323
# Unit test for function load_json
def test_load_json():
    request_item = KeyValueArg('key1', 'data-raw-json', '{"key2":"value2"}')
    value = load_json(request_item, request_item.value)
    assert(value["key2"] == "value2")

# Generated at 2022-06-21 13:39:24.643115
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(sep='', key='', value='')
    with pytest.raises(ParseError):
        load_text_file(item)