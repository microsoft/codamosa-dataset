

# Generated at 2022-06-21 13:29:39.922088
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg("Header;Value", "Header", "Value", ";"))
        assert False
    except ParseError:
        assert True

    try:
        process_empty_header_arg(KeyValueArg("Header;", "Header", "", ";"))
        assert True
    except ParseError:
        assert False

# Generated at 2022-06-21 13:29:44.148000
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(
        key='data1',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='httpie/templates/test.json'
    )
    process_data_embed_raw_json_file_arg(item)

# Generated at 2022-06-21 13:29:54.452987
# Unit test for function load_json
def test_load_json():
    from httpie.cli.argtypes import KeyValueArg
    arg = KeyValueArg(key='test', value='test', sep='=', orig='test=test')
    res1 = load_json(arg, '{ "test": "test" }')
    assert isinstance(res1, dict)

    res2 = load_json(arg, '"test"')
    assert isinstance(res2, str)

    res3 = load_json(arg, '123')
    assert isinstance(res3, int)

    res4 = load_json(arg, '[1,2,3]')
    assert isinstance(res4, list)

    res5 = load_json(arg, 'true')
    assert isinstance(res5, bool)

    res6 = load_json(arg, 'null')
    assert res6 is None

# Generated at 2022-06-21 13:30:04.719594
# Unit test for function load_json
def test_load_json():
    try:
        load_json('1', '"hello')
    except ParseError as error:
        assert str(error) == '"1": Unterminated string starting at: line 1 column 6 (char 5)'
    try:
        load_json('1', '"hello"')
    except ParseError as error:
        assert str(error) == "Expecting property name enclosed in double quotes"
    try:
        load_json('1', "'hello'")
    except ParseError as error:
        assert str(error) == "Expecting property name enclosed in double quotes"
    try:
        load_json('1', "['hello']")
    except ParseError as error:
        assert str(error) == "Expecting property name enclosed in double quotes"

# Generated at 2022-06-21 13:30:11.500370
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    headers = RequestHeadersDict()
    instance = RequestItems()

    # from_args
    result_instance = RequestItems.from_args([
        KeyValueArg('Header:', 'value'),
        KeyValueArg('Header', ''),
        KeyValueArg('Header;', '')
    ], as_form=True)
    result_instance.headers.pop('Header')

    assert instance.headers == result_instance.headers

    # process_empty_header_arg
    arg = KeyValueArg('Header', '')
    instance.headers['Header'] = process_empty_header_arg(arg)

    assert instance.headers == headers


# Generated at 2022-06-21 13:30:22.262961
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:30:23.217042
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems()


# Generated at 2022-06-21 13:30:29.164582
# Unit test for constructor of class RequestItems
def test_RequestItems():
    args = [
        KeyValueArg(orig='a', sep='', key='a', value='1'),
        KeyValueArg(orig='b', sep='', key='b', value='2'),
        KeyValueArg(orig='c', sep='', key='c', value='3'),
        KeyValueArg(orig='d', sep='', key='d', value='4'),
        KeyValueArg(orig='e', sep='', key='e', value='5'),
        KeyValueArg(orig='f', sep='', key='f', value='6'),
        KeyValueArg(orig='g', sep='', key='g', value='7'),
        KeyValueArg(orig='h', sep='', key='h', value='8'),
        KeyValueArg(orig='i', sep='', key='i', value='9'),
    ]
    #

# Generated at 2022-06-21 13:30:32.095826
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    kv_arg = KeyValueArg(sep='=', key=None, value='a=1')
    assert process_data_item_arg(kv_arg) == 'a=1'

# Generated at 2022-06-21 13:30:35.530660
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg('abc')
    arg.value = ''
    str1 = load_json(arg, arg.value)
    assert str1 == ''


# Generated at 2022-06-21 13:30:55.514327
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import SEPARATOR_DATA_RAW_JSON
    request_item_arg = KeyValueArg(0, 'name', 'John', SEPARATOR_DATA_RAW_JSON)
    response = process_data_raw_json_embed_arg(request_item_arg)
    assert response == "John"



# Generated at 2022-06-21 13:30:59.390171
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(None, 'test', 'test')) == 'test'
    assert process_header_arg(KeyValueArg(None, 'test', None)) == None


# Generated at 2022-06-21 13:31:03.899067
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('header', 'value', 'header:value')
    assert process_header_arg(arg) == 'value'
    
    arg = KeyValueArg('header', '', 'header;')
    assert process_header_arg(arg) is None


# Generated at 2022-06-21 13:31:05.294014
# Unit test for function load_json
def test_load_json():
    assert load_json(KeyValueArg(
        '--data',
        '{}',
        '--data',
        '{}'
    ),
    '{}') == {}



# Generated at 2022-06-21 13:31:06.825320
# Unit test for function load_json
def test_load_json():
    json_string = '{"name":"John", "age":30}'
    should_be_python_object = load_json(None, json_string)
    print(should_be_python_object)


# Generated at 2022-06-21 13:31:07.164852
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    pass

# Generated at 2022-06-21 13:31:08.895735
# Unit test for function load_text_file
def test_load_text_file():
    a=KeyValueArg('test', '@test')
    assert load_text_file(a) == "testing"

# Generated at 2022-06-21 13:31:16.545737
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems(as_form=False)
    assert isinstance(instance.headers, RequestHeadersDict)
    assert not isinstance(instance.params, RequestDataDict)
    assert not isinstance(instance.params, RequestJSONDataDict)
    assert isinstance(instance.params, RequestQueryParamsDict)
    assert isinstance(instance.data, RequestJSONDataDict)
    assert not isinstance(instance.data, RequestDataDict)
    assert not isinstance(instance.multipart_data, RequestDataDict)
    assert not isinstance(instance.multipart_data, RequestJSONDataDict)
    assert isinstance(instance.multipart_data, MultipartRequestDataDict)
    assert not isinstance(instance.files, RequestDataDict)

# Generated at 2022-06-21 13:31:25.671525
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Test case 1: with only filename and mime_type
    arg = KeyValueArg(key="key1", value="filename1")
    result = process_file_upload_arg(arg)
    assert result[0] == "filename1"
    assert result[1] == "text/plain"

    # Test case 2: with filename and mime_type
    arg = KeyValueArg(key="key1", value="filename2;mime_type2")
    result = process_file_upload_arg(arg)
    assert result[0] == "filename2"
    assert result[1] == "mime_type2"

# Generated at 2022-06-21 13:31:35.678676
# Unit test for function load_json
def test_load_json():
    assert load_json(None, "1") == 1
    assert load_json(None, "true") == True
    assert load_json(None, "false") == False
    assert load_json(None, '["a", "b"]') == ["a", "b"]
    assert load_json(None, "{'hi': 'hello'}") == {'hi': 'hello'}
    assert load_json(None, "a string") == "a string"
    # To avoid invalid inputs in the form of "a\n"
    assert load_json(None, "a\x00") == "a\x00"
    assert load_json(None, '"\\u1234"') == "\\u1234"

# Generated at 2022-06-21 13:31:52.055080
# Unit test for function load_text_file
def test_load_text_file():
    path = "file.txt"
    try:
        with open(os.path.expanduser(path), 'rb') as f:
            return f.read().decode()
    except IOError as e:
        raise ParseError('"%s": %s' % (path, e))
    except UnicodeDecodeError:
        raise ParseError(
            '"%s": cannot embed the content of "%s",'
            ' not a UTF8 or ASCII-encoded text file'
            % (path, path)
        )

test_load_text_file()

# Generated at 2022-06-21 13:31:55.049813
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('test=test')) == 'test'
    assert process_data_item_arg(KeyValueArg('test=test=test')) == 'test=test'
    assert process_data_item_arg(KeyValueArg('test=test&test')) == 'test&test'
    assert process_data_item_arg(KeyValueArg('test=test&test=')) == 'test&test='


# Generated at 2022-06-21 13:31:56.563744
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(SEPARATOR_QUERY_PARAM, 'key', 'value')
    assert process_query_param_arg(arg) == 'value'

# Generated at 2022-06-21 13:32:04.227039
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems.from_args([], as_form=True)
    assert(isinstance(instance.data, RequestDataDict))
    assert(isinstance(instance.files, RequestFilesDict))
    assert(isinstance(instance.headers, RequestHeadersDict))
    assert(isinstance(instance.multipart_data, MultipartRequestDataDict))
    assert(isinstance(instance.params, RequestQueryParamsDict))

# Generated at 2022-06-21 13:32:06.329695
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('key', 'value')
    assert process_header_arg(arg) == 'value'

# Generated at 2022-06-21 13:32:09.036050
# Unit test for function process_header_arg
def test_process_header_arg():
    h = KeyValueArg(key = "Content-Type", value="application/json", sep=":")
    assert process_header_arg(h) == "application/json"


# Generated at 2022-06-21 13:32:13.910802
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('foo@bar.txt', '', SEPARATOR_FILE_UPLOAD)
    value = process_file_upload_arg(arg)
    assert isinstance(value, tuple)
    assert len(value) == 3
    assert value[0] == 'bar.txt'
    assert value[1].name == 'bar.txt'
    assert value[1].mode == 'rb'


# Generated at 2022-06-21 13:32:26.292669
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    fp = '~/test.py'
    mime_type = 'text/plain'
    filepath = ('%s%s%s') % (fp, SEPARATOR_FILE_UPLOAD_TYPE, mime_type)
    test_arg = KeyValueArg()
    test_arg.key = 'file'
    test_arg.value = filepath
    test_arg.orig = (SEPARATOR_FILE_UPLOAD + test_arg.key) % test_arg.value
    test_arg.sep = SEPARATOR_FILE_UPLOAD

    # call function process_file_upload_arg in httpie-0.9.9\httpie\cli\argtypes.py
    result = process_file_upload_arg(test_arg)
    print(result)


# Generated at 2022-06-21 13:32:36.530320
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:32:42.436217
# Unit test for function load_json
def test_load_json():
    content = '{"my_favorite_color": {"fav_color": "blue"}, "fav_number": 1}'
    r = load_json(KeyValueArg("fav_number", 1, None), content)
    assert r == {"fav_color": "blue"}
    r = load_json(KeyValueArg("my_favorite_color", None, None), content)
    assert r == {"fav_number": 1}



# Generated at 2022-06-21 13:33:04.978697
# Unit test for function load_text_file
def test_load_text_file():
    f = "/tmp/test_file"
    with open(f, "w") as fp:
        fp.write("hello world")

    s = load_text_file(KeyValueArg("body", ";", f))
    assert s == "hello world"

    os.remove(f)

# Generated at 2022-06-21 13:33:08.114348
# Unit test for function process_header_arg
def test_process_header_arg():
    test_args = ["-k", "Get','Post','Delete','Put','Option']"]
    test_arg = KeyValueArg(test_args)
    assert process_header_arg(test_arg) == "Get','Post','Delete','Put','Option'"


# Generated at 2022-06-21 13:33:14.493976
# Unit test for function load_json
def test_load_json():
    assert load_json_preserve_order('{"a": 1}') == {'a': 1}
    assert load_json_preserve_order('["a"]') == ['a']
    assert load_json_preserve_order('1') == 1
    assert load_json_preserve_order('true') == True
    assert load_json_preserve_order('false') == False
    assert load_json_preserve_order('"a"') == 'a'
    assert load_json_preserve_order('{"a":1,"b":2,"c":3}') == {'a': 1, 'b': 2, 'c': 3}
    assert load_json_preserve_order('{"a":1,"b":2,"c":3}') != {'a': 1, 'c': 3, 'b': 2}


# Generated at 2022-06-21 13:33:16.421459
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg("arg", "value")) == "value"



# Generated at 2022-06-21 13:33:21.964630
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        orig="mykey=@myfile.txt",
        sep="=",
        key="mykey",
        value="@myfile.txt",
    )

    assert process_data_embed_file_contents_arg(arg) == "this is my file\n"


# Generated at 2022-06-21 13:33:27.561076
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = [KeyValueArg('p', 'sep', 'val')]
    as_form=False
    reques_items = RequestItems.from_args(request_item_args,as_form)
    assert reques_items.headers == {'p': 'sep'}
    assert reques_items.params == {'p': 'sep'}
    assert reques_items.files == {'p': ('val', None, None)}
    assert reques_items.data == {'p': {'val': None}}

# Generated at 2022-06-21 13:33:33.145689
# Unit test for function process_header_arg
def test_process_header_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import SEPARATOR_HEADER
    kv_arg = KeyValueArg(
        sep=SEPARATOR_HEADER,
        key="Content-Type",
        value="application/json",
        orig="Content-Type:application/json")
    ret = process_header_arg(kv_arg)
    assert ret == "application/json"


# Generated at 2022-06-21 13:33:37.108915
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    import pytest
    with pytest.raises(ParseError):
        process_empty_header_arg(KeyValueArg("cookie","a=b",separator=SEPARATOR_HEADER_EMPTY))

    assert process_empty_header_arg(KeyValueArg("cookie",None,separator=SEPARATOR_HEADER_EMPTY))==""

# Generated at 2022-06-21 13:33:39.729866
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('', '-F', 'a.c', '--123', '',)
    a = process_file_upload_arg(arg)
    print(a)


if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-21 13:33:46.342215
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-21 13:34:10.304957
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key=None, sep=SEPARATOR_FILE_UPLOAD, value='test.json')
    assert process_file_upload_arg(arg) == ('test.json', open('test.json', 'rb'), get_content_type(arg.value))



# Generated at 2022-06-21 13:34:11.490698
# Unit test for function load_json
def test_load_json():
    from httpie.cli.argtypes import KeyValueArg
    load_json("a:b", "a")


# Generated at 2022-06-21 13:34:13.990791
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_arg = KeyValueArg('-d', '@test.json', None)
    data_embed_file_contents_arg = process_data_embed_file_contents_arg(test_arg)
    assert isinstance(data_embed_file_contents_arg, str)


# Generated at 2022-06-21 13:34:17.527768
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test_arg=KeyValueArg(
        sep=SEPARATOR_QUERY_PARAM,
        orig="a=b",
        key="a",
        value="b"
    )
    assert process_query_param_arg(test_arg)=="b"

# Generated at 2022-06-21 13:34:20.150135
# Unit test for function load_json
def test_load_json():
    data = load_json(KeyValueArg('text', 'text'), '{"hello": "world"}')
    assert data == {"hello": "world"}

# Generated at 2022-06-21 13:34:29.531790
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    """Ensure that process_data_raw_json_embed_arg is functioning as expected.

    The function parse key=value string and return JSON object.
    It should work both for string and numbers.
    """
    from httpie.cli.argtypes import KeyValueArg

    arg_val = 'key=value'
    arg = KeyValueArg(**{'orig': '', 'sep': '=', 'key': 'key', 'value': arg_val})
    obj = process_data_raw_json_embed_arg(arg)
    assert obj == 'value'

    arg_val = 'key=12'
    arg = KeyValueArg(**{'orig': '', 'sep': '=', 'key': 'key', 'value': arg_val})
    obj = process_data_raw_json_embed_arg(arg)

# Generated at 2022-06-21 13:34:33.264560
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("Header;", "", None)
    assert process_empty_header_arg(arg) == ""

    arg = KeyValueArg("Header;", "a", None)
    with pytest.raises(ParseError):
        process_empty_header_arg(arg)

# Generated at 2022-06-21 13:34:37.160377
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    from httpie.cli.argtypes import KeyValueArg
    kv = KeyValueArg('Header;', 'Header', '', ';')
    print(process_empty_header_arg(kv))


# Generated at 2022-06-21 13:34:40.821038
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key=None,
        value='/Users/macuser/Desktop/test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='/Users/macuser/Desktop/test.txt',
    )
    _, f, _ = process_file_upload_arg(arg)
    assert f.readable()

# Generated at 2022-06-21 13:34:43.813864
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    a = """{\"foo\":\"bar\", \"baz\":1}"""
    b = process_data_embed_raw_json_file_arg(a)
    print(b)
# Test of function process_data_embed_raw_json_file_arg:
# print(test_process_data_embed_raw_json_file_arg())

# Generated at 2022-06-21 13:35:22.750886
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    class mock_arg():
        def __init__(self):
            self.value = 'test.txt'

    arg = mock_arg()
    assert process_data_embed_file_contents_arg(arg) == 'test'



# Generated at 2022-06-21 13:35:25.042385
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig=None, sep=None, key=None, value="{'a':'b'}")
    assert process_data_raw_json_embed_arg(arg) == {'a': 'b'}
# process_data_raw_json_embed_arg()


# Generated at 2022-06-21 13:35:32.409036
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    import io
    import json
    contents = '{"a":5}'
    item = KeyValueArg(key='data', value=contents, sep=":=")
    assert process_data_embed_raw_json_file_arg(item) == json.loads(contents)
    contents = '{invalid: json}'
    item = KeyValueArg(key='data', value=contents, sep=":=")
    try:
        process_data_embed_raw_json_file_arg(item)
    except ParseError:
        pass
    else:
        assert False, "expected ParseError"
    contents = """[{
    "a": 5,
    "b":
        [1, 2, 3]
}]"""

# Generated at 2022-06-21 13:35:35.195244
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(sep='@', key=None, value='test.txt')
    assert process_data_embed_file_contents_arg(arg) == 'test'


# Generated at 2022-06-21 13:35:41.704209
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    path = '/Users/bravodavid/PycharmProjects/temp/args.txt'
    with open(path, 'rb') as f:
        # content = f.read().decode()
        content = f.read()
    key = 1
    sep = '@'
    value = './args.txt'
    orig = '@./args.txt'
    item = KeyValueArg(key, sep, value, orig)
    value = process_data_embed_file_contents_arg(item)

    print('Hello world!')

# Generated at 2022-06-21 13:35:43.994473
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('-d@filename.txt', "content")
    assert process_data_embed_file_contents_arg(arg) == "content"

# Generated at 2022-06-21 13:35:45.209032
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    x = process_data_item_arg('k:v')

# Generated at 2022-06-21 13:35:45.721598
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    pass

# Generated at 2022-06-21 13:35:49.910198
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg(
        sep=SEPARATOR_HEADER,
        key='user',
        value='michael.jackson',
        orig='user:michael.jackson'
    )
    assert process_header_arg(header_arg) == 'michael.jackson'



# Generated at 2022-06-21 13:35:53.437055
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    """
    Test for function process_file_upload_arg
    """

    tst = KeyValueArg()
    tst.value = "/tmp/test"
    tst.sep = SEPARATOR_FILE_UPLOAD

    assert len(process_file_upload_arg(tst)) == 3


# Generated at 2022-06-21 13:37:18.612450
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='key',
        value='/home/user/testing.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "key": "value",
        "key1": "value1",
        "key2": "value2"
    }
    assert process_data_embed_raw_json_file_arg(arg) == {
        "key": "value",
        "key1": "value1",
        "key2": "value2"
    }

# Generated at 2022-06-21 13:37:21.985751
# Unit test for function load_text_file
def test_load_text_file():
    path = "/Users/liu/Downloads/test"
    item = KeyValueArg(key="test", orig="test", sep="@", value=path)
    assert b"test" in load_text_file(item)

if __name__ == '__main__':
    test_load_text_file()

# Generated at 2022-06-21 13:37:23.828854
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    a = KeyValueArg('test;test', 'test')
    result = process_query_param_arg(a)
    assert result == 'test'


# Generated at 2022-06-21 13:37:27.922267
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
  test_string = "C:\\Users\\nipu\\Desktop\\test_file.py"
  arg = KeyValueArg(test_string, test_string)
  actual_output = process_file_upload_arg(arg)

# Generated at 2022-06-21 13:37:29.760334
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(None) == None

# Generated at 2022-06-21 13:37:35.890351
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    input = KeyValueArg(sep='=', key=None, orig='p=value', value='value',
                        is_flag=False, is_data=True, is_file=False,
                        is_flag_value=None)
    result = process_data_item_arg(input)
    assert result == 'value'


# Generated at 2022-06-21 13:37:38.603523
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('test;test','test')
    assert process_query_param_arg(arg) == 'test'


# Generated at 2022-06-21 13:37:46.981896
# Unit test for constructor of class RequestItems
def test_RequestItems():
    as_form = False
    item1 = KeyValueArg(SEPARATOR_HEADER, 'A', 'B')
    item2 = KeyValueArg(SEPARATOR_HEADER_EMPTY, 'C', 'D')
    item3 = KeyValueArg(SEPARATOR_QUERY_PARAM, 'E', 'F')
    item4 = KeyValueArg(SEPARATOR_FILE_UPLOAD, 'G', 'H')
    item5 = KeyValueArg(SEPARATOR_DATA_STRING, 'I', 'J')
    item6 = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, 'K', 'L')
    item7 = KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'M', 'N')

# Generated at 2022-06-21 13:37:59.535239
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    from httpie.cli.argtypes import KeyValueArg
    import tempfile
    import itertools
    def process_file_upload_arg(arg: KeyValueArg) -> Tuple[str, IO, str]:
        parts = arg.value.split(SEPARATOR_FILE_UPLOAD_TYPE)
        filename = parts[0]
        mime_type = parts[1] if len(parts) > 1 else None
        try:
            f = open(filename, 'rb')
        except IOError as e:
            raise ParseError('"%s": %s' % (arg.orig, e))
        return (
            os.path.basename(filename),
            f,
            mime_type or get_content_type(filename),
        )


# Generated at 2022-06-21 13:38:09.031716
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key_value_arg_1 = KeyValueArg('key1;@path/to/embed/file.txt')
    key_value_arg_2 = KeyValueArg('--data;key2;@path/to/embed/file.py')
    key_value_arg_3 = KeyValueArg('--data;key3;@path/to/embed/file.txt')
    key_value_arg_4 = KeyValueArg('--data;key4;@path/to/embed/file.py')

    print(process_data_embed_file_contents_arg(key_value_arg_1))
    print(process_data_embed_file_contents_arg(key_value_arg_2))
    print(process_data_embed_file_contents_arg(key_value_arg_3))