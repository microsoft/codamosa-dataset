

# Generated at 2022-06-21 13:29:49.599745
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.argtypes import KeyValueArg
    assert process_data_raw_json_embed_arg(KeyValueArg('foo', 'bar', '=')) == 'bar'
    assert process_data_raw_json_embed_arg(KeyValueArg('foo', 'false', '=')) == False
    assert process_data_raw_json_embed_arg(KeyValueArg('foo', '[1,2,3]', '=')) == [1,2,3]

    # Test to raise error when parse a content with an error JSON format
    try:
        process_data_raw_json_embed_arg(KeyValueArg('foo', '{ "foo": "not_closed"', '='))
    except ParseError:
        True
    else:
        False

# Generated at 2022-06-21 13:29:54.040192
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg("file", SEPARATOR_FILE_UPLOAD, "header",
                      "", value="~/foo/bar.txt")
    key, file, file_type = process_file_upload_arg(arg)

    print(key)
    print(file.name)
    print(file_type)
    file.close()

# Generated at 2022-06-21 13:29:57.293160
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg
    arg1 = KeyValueArg(orig="name=value", sep="=", key="name", value="value")
    assert process_query_param_arg(arg1) == "value"


# Generated at 2022-06-21 13:30:08.226964
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = [
        {
            'sep': ':',
            'key': 'Content-Type',
            'value': 'application/json'
        },
        {
            'sep': '@',
            'key': 's',
            'value': 'json'
        },
        {
            'sep': '=',
            'key': 'data',
            'value': '''
            {
                "type": "json",
                "data": []
            }
            '''
        },
        {
            'sep': '@',
            'key': 'upload',
            'value': 'type:text'
        }
    ]
    res = RequestItems.from_args(request_item_args)
    print(res.headers)
    print(res.data)
   

# Generated at 2022-06-21 13:30:13.226321
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
        arg = KeyValueArg('data', 'raw', '{"test": "aaaa"}')
        value = load_json(arg, arg.value)
        print(value)


if __name__ == '__main__':
        test_process_data_raw_json_embed_arg()

# Generated at 2022-06-21 13:30:23.370437
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg(arg='-d', sep='=', key=None, value='{"name":"John","age":30,"car":null}')
    assert process_data_raw_json_embed_arg(item) == {"name":"John","age":30,"car":None}

    item = KeyValueArg(arg='-d', sep='=', key=None, value='{"name":"John","age":30}')
    assert process_data_raw_json_embed_arg(item) == {"name":"John","age":30}

    item = KeyValueArg(arg='-d', sep='=', key=None, value='{"name":"John","age":null,"car":null}')
    assert process_data_raw_json_embed_arg(item) == {"name":"John","age":None,"car":None}

# Generated at 2022-06-21 13:30:25.850065
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():

    args = KeyValueArg("Header;", "Header;","Header;")
    value = process_empty_header_arg(args)
    assert(value == "")

# Generated at 2022-06-21 13:30:29.397850
# Unit test for function load_json
def test_load_json():
    file_path = './test.json'
    with open(file_path) as json_file:
        test_file = json_file.read()
    file_key = "data"
    test_arg = KeyValueArg(file_key, test_file, SEPARATOR_DATA_RAW_JSON)
    data = load_json(test_arg, test_file)
    reference_dict = load_json_preserve_order(test_file)
    assert data == reference_dict



# Generated at 2022-06-21 13:30:34.196184
# Unit test for function load_json
def test_load_json():
    # Set
    arg = KeyValueArg(orig='a:1:b:2',sep=':',key='a',value='1')
    contents = '{"a":1,"b":2}'
    # Assert
    assert {'a': 1, 'b': 2} == load_json(arg, contents)

# Generated at 2022-06-21 13:30:36.369783
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    header_arg = KeyValueArg('', '')
    assert process_empty_header_arg(header_arg) == ''

# Generated at 2022-06-21 13:30:50.924612
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('1', 'data.txt')) == ''

# Generated at 2022-06-21 13:31:03.899703
# Unit test for function load_text_file
def test_load_text_file():
    # case 1
    try:
        load_text_file(KeyValueArg(arg="k1=v1", key="k1", sep="=", value="v1"))
        raise AssertionError("case 1: wrong KeyValueArg, should raise ValueError")
    except ValueError:
        pass
        
    # case 2
    assert load_text_file(KeyValueArg(arg="Header1:value1", key="Header1", sep=":", value="value1")) == "value1"
    
    # case 3
    try:
        load_text_file(KeyValueArg(arg="k2=:v2", key="k2", sep="=", value=":v2"))
        raise AssertionError("case 3: wrong KeyValueArg, should raise ValueError")
    except ValueError:
        pass
        


# Generated at 2022-06-21 13:31:09.121017
# Unit test for function load_text_file
def test_load_text_file():
    # Init an argument of KeyValueArg
    item = KeyValueArg()
    item.orig = "arg1"
    item.value = "arg_value"

    # Check whether load_text_file return a str it expects
    assert(isinstance(load_text_file(item), str))


# Generated at 2022-06-21 13:31:16.643322
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.constants import SEPARATOR_DATA_RAW_JSON

    # mock httpie.cli.constants.SEPARATOR_DATA_RAW_JSON
    SEPARATOR_DATA_RAW_JSON = '='

    # Normal case
    arg1 = KeyValueArg("a", "=", "1", "a=1")
    result1 = process_data_raw_json_embed_arg(arg1)
    assert result1 == 1

    # Empty argument
    arg2 = KeyValueArg("a", "=", "", "a=")
    result2 = process_data_raw_json_embed_arg(arg2)
    assert result2 == ""

    # Invalid value
    arg3 = KeyValueArg("a", "=", "a", "a=a")

# Generated at 2022-06-21 13:31:18.427156
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg("foo=bar") == "bar"

# Generated at 2022-06-21 13:31:30.746456
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import httpie.cli.argtypes as argtypes
    from httpie.cli.exceptions import ParseError

# Generated at 2022-06-21 13:31:32.435247
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    #simple assertion test
    assert process_empty_header_arg(KeyValueArg('key', '', ';')) == ''

# Generated at 2022-06-21 13:31:36.712574
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_HEADER_EMPTY,
        orig='Header;',
        key='Header',
        value=None,
    )
    result = process_empty_header_arg(arg)
    assert result == arg.value


# Generated at 2022-06-21 13:31:42.984759
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test_item_arg_list = [
        KeyValueArg(SEPARATOR_QUERY_PARAM, "key1", "value1")
    ]
    test_request_item = RequestItems.from_args(test_item_arg_list)
    for key, value in test_request_item.params.items():
        assert isinstance(value, str)


# Generated at 2022-06-21 13:31:48.270430
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg("Header", "WrongValue", "Header:WrongValue"))
    except ParseError as e:
        print("Exception Name: ", type(e))
        print("Exception Arguments: ", e.args)
        print("Exception Message: ", e)

# Generated at 2022-06-21 13:32:09.481204
# Unit test for function load_text_file
def test_load_text_file():
    # Test function can get file content
    with open(os.path.expanduser('~/.ssh/known_hosts'), 'rb') as f:
        content = f.read().decode()
        assert load_text_file(arg=KeyValueArg(
            sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
            orig="data-binary @~/.ssh/known_hosts",
            key="data",
            value='~/.ssh/known_hosts')) == content



# Generated at 2022-06-21 13:32:11.940478
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('arg', 'value', '')
    assert process_data_raw_json_embed_arg(arg) == 'value'


# Generated at 2022-06-21 13:32:15.045349
# Unit test for function load_json
def test_load_json():
    assert load_json(None, '{"a": "hello", "b": "world"}') == {'a': 'hello', 'b': 'world'}

# Generated at 2022-06-21 13:32:17.716746
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(SEPARATOR_QUERY_PARAM, "action=install", "action=install")
    print(process_query_param_arg(arg))


# Generated at 2022-06-21 13:32:20.420284
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg("?x", "y", "?")
    assert process_query_param_arg(arg) == "y"


# Generated at 2022-06-21 13:32:30.268496
# Unit test for function load_text_file
def test_load_text_file():
    import io
    import sys
    import os
    # Save the reference to the
    # original stdout
    old_stdout = sys.stdout
    # Create a StringIO object
    result = io.StringIO()
    # Set the sys.stdout to our StringIO object
    sys.stdout = result
    # Call the function
    load_text_file_example = RequestItems()
    load_text_file_example.load_text_file('test.txt')
    # Get the result
    result_string = result.getvalue()
    # Clean up
    sys.stdout = old_stdout
    # Print the result
    print(result_string)

# Generated at 2022-06-21 13:32:34.618491
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('head', 'head', 'head')) == 'head'
    assert process_header_arg(KeyValueArg('head', 'head', [''])) is None
    assert KeyValueArg.from_arg(':').key == ':'



# Generated at 2022-06-21 13:32:38.754645
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg('', '', '', '', '', '')
    contents = '{"foo": "bar"}'
    assert load_json(arg, contents) == {"foo": "bar"}

    contents = '{"foo": [1, 2, 3]}'
    assert load_json(arg, contents) == {"foo": [1, 2, 3]}

    arg = KeyValueArg('', '', '', '', '', '')
    contents = '{"foo": "bar'
    try:
        load_json(arg, contents)
    except ParseError as e:
        assert e.args[0] == '"": Expecting property name enclosed in double quotes: line 1 column 9 (char 8)'
    else:
        assert False, "Did not raise ParseError"


# Generated at 2022-06-21 13:32:40.303145
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file("") == ""
    assert load_text_file("c:\\") == ""



# Generated at 2022-06-21 13:32:44.782202
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data = '[1,2,3]'
    key_value_arg = KeyValueArg(key=None, value=data, orig=data, sep=SEPARATOR_DATA_RAW_JSON)
    json_data = process_data_raw_json_embed_arg(key_value_arg)
    assert 'json_data' == json_data


# Generated at 2022-06-21 13:33:22.894637
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='email',sep=SEPARATOR_QUERY_PARAM,value='test@example.com')
    value = process_query_param_arg(arg)
    assert value == 'test@example.com'

# Generated at 2022-06-21 13:33:30.381807
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_data = [
        (SEPARATOR_FILE_UPLOAD + 'test.txt', 'test.txt', None, 'test.txt'),
        (SEPARATOR_FILE_UPLOAD + 'test.txt@text/html', 'test.txt', 'text/html', 'test.txt'),
        (SEPARATOR_FILE_UPLOAD + 'test', 'test', None, 'test')
    ]

    for data in test_data:
        arg = KeyValueArg(data[0])
        res = process_file_upload_arg(arg)
        assert res[0] == data[1], 'filename is not match'
        assert res[2] == data[2], 'mime_type is not match'
        assert type(res[1]) is fil

# Generated at 2022-06-21 13:33:32.289100
# Unit test for function process_header_arg
def test_process_header_arg():
    result = process_header_arg(KeyValueArg(
        key='TestKey',
        value='TestValue',
        sep=SEPARATOR_HEADER,
        orig='TestOrig'
    ))
    assert result == 'TestValue'


# Generated at 2022-06-21 13:33:37.254282
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    class asdf():
        attr = 'asdf'
    d = asdf()
    arg = KeyValueArg(d,'asdf','asdf',None,None)
    print(process_data_item_arg(arg))


# Generated at 2022-06-21 13:33:46.776293
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    list1 = [KeyValueArg('k-1', 'v-1', SEPARATOR_QUERY_PARAM),
             KeyValueArg('k-2', 'v-2', SEPARATOR_QUERY_PARAM),
             KeyValueArg('k-3', 'v-3', SEPARATOR_QUERY_PARAM),]
    arg1 = KeyValueArg('k-1', 'v-1', SEPARATOR_QUERY_PARAM)
    arg2 = KeyValueArg('k-2', 'v-2', SEPARATOR_QUERY_PARAM)
    arg3 = KeyValueArg('k-3', 'v-3', SEPARATOR_QUERY_PARAM)
    result1 = process_query_param_arg(arg1)
    assert result1 == 'v-1'
    result2 = process_query_

# Generated at 2022-06-21 13:33:48.959749
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(key='-H', value='Accept: application/json', sep=':', orig='Accept: application/json')
    assert process_header_arg(arg) == 'application/json'



# Generated at 2022-06-21 13:33:50.478617
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key = 'data', value = 'value')
    eq_(process_data_item_arg(arg), 'value')

# Generated at 2022-06-21 13:34:02.075101
# Unit test for function load_json
def test_load_json():
    json_dict = {'a':'b'}
    json_dict_str = '{"a": "b"}'
    # Case json_dict
    assert load_json(KeyValueArg('', '', ''), '{}') == {}
    assert load_json(KeyValueArg('', '', ''), json_dict) == json_dict
    assert load_json(KeyValueArg('', '', ''), json_dict_str) == json_dict
    # Case json_list
    assert load_json(KeyValueArg('', '', ''), '[]') == []
    assert load_json(KeyValueArg('', '', ''), '[1, 2]') == [1,2]
    # Case json
    assert load_json(KeyValueArg('', '', ''), '{}') == {}

# Generated at 2022-06-21 13:34:09.255101
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg("name:value")
    process_data_embed_raw_json_file_arg(item)
    item = KeyValueArg("name:@value")
    process_data_embed_raw_json_file_arg(item)
    item = KeyValueArg("name:=value")
    process_data_embed_raw_json_file_arg(item)
    item = KeyValueArg("name:=@value")
    process_data_embed_raw_json_file_arg(item)


# Generated at 2022-06-21 13:34:10.181335
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    pass



# Generated at 2022-06-21 13:36:15.762628
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import filecmp
    # test 1
    filename = "output.txt"
    mime_type = "text"
    path = "./tests/output.txt"

    testarg = KeyValueArg('output.txt',SEPARATOR_FILE_UPLOAD, 'output.txt')
    assert process_file_upload_arg(testarg) == (filename, open(path, 'rb'), mime_type)
    # test 2
    filename = "output.txt"
    mime_type = "text"
    path = "./tests/output.txt"

    testarg = KeyValueArg('output.txt',SEPARATOR_FILE_UPLOAD, 'output.txt,text')
    assert process_file_upload_arg(testarg) == (filename, open(path, 'rb'), mime_type)
    # test 3

# Generated at 2022-06-21 13:36:25.238702
# Unit test for constructor of class RequestItems
def test_RequestItems():
    headers = RequestHeadersDict()
    headers["key1"] = "value1"
    headers["key2"] = "value2"
    headers["key3"] = "value3"

    data = RequestJSONDataDict()
    data["key1"] = "value1"
    data["key2"] = "value2"
    data["key3"] = "value3"

    files = RequestFilesDict()
    files["key1"] = "value1"
    files["key2"] = "value2"
    files["key3"] = "value3"

    params = RequestQueryParamsDict()
    params["key1"] = "value1"
    params["key2"] = "value2"
    params["key3"] = "value3"

    request = RequestItems(as_form=False)

    request

# Generated at 2022-06-21 13:36:29.917307
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    value = process_data_raw_json_embed_arg("a:b")
    print("a:b", value)
    value = process_data_raw_json_embed_arg("[1,2]")
    print("[1,2]", value)
    value = process_data_raw_json_embed_arg('{"a":1}')
    print('{"a":1}', value)



# Generated at 2022-06-21 13:36:36.101477
# Unit test for constructor of class RequestItems
def test_RequestItems():
    list_of_arg = [KeyValueArg('k1', 'v1', SEPARATOR_HEADER, 'k1:v1'),
                   KeyValueArg('k2', 'v2', SEPARATOR_HEADER, 'k2:v2')]
    expected_headers = {'k1': 'v1', 'k2': 'v2'}
    assert RequestItems.from_args(list_of_arg).headers == expected_headers


# Generated at 2022-06-21 13:36:38.843731
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    from httpie.cli.argtypes import KeyValueArg
    dummy_arg = KeyValueArg(orig=':', key='', value='', sep=':')
    assert process_empty_header_arg(dummy_arg) is ''

# Generated at 2022-06-21 13:36:41.867964
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('-H', 'Authorization', 'Bearer')) == 'Bearer'
    assert process_header_arg(KeyValueArg('-H', 'Authorization', None)) == None



# Generated at 2022-06-21 13:36:46.824610
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(b'foo', b'filename')
    assert process_file_upload_arg(arg) == (os.path.basename(arg.value), None, None)
    arg = KeyValueArg(b'foo', b'filename;type')
    assert process_file_upload_arg(arg) == (os.path.basename(arg.value), None, b'type')

# Generated at 2022-06-21 13:36:49.158606
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    temp_arg = KeyValueArg(key='test', sep='test_sep', value='test_value')
    assert process_query_param_arg(temp_arg) == 'test_value'

# Generated at 2022-06-21 13:36:52.026531
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.argtypes import KeyValueArg
    arg = KeyValueArg('key1', 'value1', SEPARATOR_DATA_RAW_JSON)
    process_data_raw_json_embed_arg(arg)


# Generated at 2022-06-21 13:36:58.030761
# Unit test for function load_text_file
def test_load_text_file():
    val = load_text_file(KeyValueArg('', '../test/test_data.txt'))
    assert isinstance(val, str)
    val = load_text_file(KeyValueArg('', '../test/test_data.bad'))
    assert isinstance(val, str)
    val = load_text_file(KeyValueArg('', '../test/test_data.bad2'))
    assert isinstance(val, str)