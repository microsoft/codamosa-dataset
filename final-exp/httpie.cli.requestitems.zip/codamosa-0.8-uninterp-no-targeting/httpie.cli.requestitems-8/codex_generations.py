

# Generated at 2022-06-21 13:29:40.870522
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    separator = SEPARATOR_FILE_UPLOAD
    file_path = 'httpie/cli/utils/sample.txt'
    file = process_file_upload_arg(KeyValueArg(separator, 'file', file_path))
    file_type = file[2]
    file_content = file[0]

    assert file_type == 'text/plain'
    assert file_content == 'sample text'


# Generated at 2022-06-21 13:29:43.847163
# Unit test for function load_json
def test_load_json():
    original = {'name':'John', 'age':30, 'cars':['Ford', 'BMW', 'Fiat']}
    assert load_json(None, json.dumps(original)) == original

# Generated at 2022-06-21 13:29:49.502323
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(orig="Header:", key="Header", sep=":", value=None)
    header = process_empty_header_arg(arg)
    assert header is None

    arg = KeyValueArg(orig="Header:xxx", key="Header", sep=":", value="xxx")
    with pytest.raises(ParseError):
        header = process_empty_header_arg(arg)


# Generated at 2022-06-21 13:29:54.719923
# Unit test for function load_text_file
def test_load_text_file():
    filename = "pom.xml"
    f = open(filename,'r')
    contents = f.read()
    arg = KeyValueArg(filename,filename)
    result = load_text_file(arg)
    print(result)
    file = open("pom.xml",'r')
    assert result == contents

if __name__ == "__main__":
    test_load_text_file()

# Generated at 2022-06-21 13:29:57.880287
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(
        'name',
        SEPARATOR_DATA_STRING,
        'Jane Doe',
        'name=Jane Doe',
    )

    assert process_data_item_arg(arg) == 'Jane Doe'



# Generated at 2022-06-21 13:30:03.742601
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg.from_pair('data-raw-json;', '{ "name": "John", "age": 35 }')
    contents = '{ "name": "John", "age": 35 }'
    result = load_json(item, contents)
    assert isinstance(result, dict)
    assert result['name'] == 'John'
    assert result['age'] == 35

# Generated at 2022-06-21 13:30:07.650021
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from httpie.cli.parser import KeyValueArg
    arg = KeyValueArg('k', 'v', 'sep')
    ret = process_data_embed_file_contents_arg(arg)
    assert(ret == 'v')

# Generated at 2022-06-21 13:30:10.333199
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('', '', '', 'query_param', 'key', 'value', 'value'))=='value'
    assert load_text_file(KeyValueArg('', '', '', 'query_param', 'key', 'value', 'value'))=='value'

if __name__=='__main__':
    test_load_text_file()

# Generated at 2022-06-21 13:30:21.597454
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert "this is a test" == process_data_embed_file_contents_arg(KeyValueArg("test.in", "this is a test", "="))
    assert "this is a test" == process_data_embed_file_contents_arg(KeyValueArg("test.in", "this is a test", ":"))
    assert "\"this is a test\"" == process_data_embed_file_contents_arg(KeyValueArg("test.in", "\"this is a test\"", ":"))
    assert "this is a test" == process_data_embed_file_contents_arg(KeyValueArg("test.in", "this is a test", "="))

# Generated at 2022-06-21 13:30:25.364650
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    expected_arg = KeyValueArg(
        sep=SEPARATOR_HEADER_EMPTY,
        orig='Foo;',
        key='Foo',
        value=''
    )
    result = process_empty_header_arg(expected_arg)
    assert result == expected_arg.value

# Generated at 2022-06-21 13:30:39.808767
# Unit test for function load_json
def test_load_json():
    jsonstr = '{"key1":[1,2,"a"],"key2": {"key21": {"key211": ["x", "y"]}}}'
    value = load_json('arg', jsonstr)
    assert type(value) == dict, \
        "value must be a dict"
    assert value == {
        'key1': [1, 2, 'a'],
        'key2': {
            'key21': {
                'key211': ['x', 'y']
            }}}

# Generated at 2022-06-21 13:30:42.737541
# Unit test for function process_header_arg
def test_process_header_arg():
    header = KeyValueArg('header1', 'value1')
    header_test = process_header_arg(header)
    assert header_test == 'value1'


# Generated at 2022-06-21 13:30:45.854086
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('Foo', ':', 'Bar')
    value = process_data_raw_json_embed_arg(arg)
    assert value == 'Bar'


# Generated at 2022-06-21 13:30:52.462373
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # TODO: Just a test to make sure the load_json function works
    #       This does not test the functionality of the actual method
    #       itself.
    # The unit test for the method itself should be done in a way where it
    # doesn't rely on the load_json function working properly.
    request_items = RequestItems()
    args = [KeyValueArg('key', SEPARATOR_DATA_EMBED_RAW_JSON_FILE, 'test.json')]
    RequestItems.from_args(args, request_items)
    assert request_items.data['key'] == {'test': 'test'}

# Generated at 2022-06-21 13:30:59.553375
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from argparse import Namespace

    test_item = KeyValueArg(orig='test.json',
            key='test',
            value='tests/data/test.json',
            sep='=')
    
    expected = {
        "key": "value"
    }

    assert process_data_embed_raw_json_file_arg(test_item) == expected

# Generated at 2022-06-21 13:31:07.579828
# Unit test for function load_json
def test_load_json():
    # Testing for invalid json
    arg = KeyValueArg(key=None, sep=None, value='foo')
    contents = 'bad_json'
    try:
        load_json(arg, contents)
        assert False
    except ValueError:
        pass
    # Testing for valid json
    arg = KeyValueArg(key=None, sep=None, value='foo')
    contents = '{"x": "y"}'
    load_json(arg, contents)
    assert True

# Generated at 2022-06-21 13:31:12.679356
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig='-d', sep='-d', key='', value='{"a":1,"b":2,"c":3}')
    expect = {"a":1,"b":2,"c":3}
    assert process_data_raw_json_embed_arg(arg) == expect
    print("test pass")

if __name__ == "__main__":
    test_process_data_raw_json_embed_arg()

# Generated at 2022-06-21 13:31:19.342646
# Unit test for function process_header_arg
def test_process_header_arg():
    test_cases = [
        ("""-H "key" -H "key:""" , """key: """
        ),
        ("""-H "key" -H 'key:""" , """key: """
        ),
        ('"""', '"""')
    ]
    for test_case in test_cases:
        request_item_arg, expected = test_case
        actual = process_header_arg(request_item_arg)
        assert expected == actual

# Generated at 2022-06-21 13:31:24.695452
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(key = '', value = '', sep = SEPARATOR_HEADER_EMPTY)
    assert process_header_arg(arg) == None

    arg.sep = SEPARATOR_HEADER
    arg.value = 'value'
    assert process_header_arg(arg) == 'value'


# Generated at 2022-06-21 13:31:27.838341
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(None, None, None, '{"foo": "bar"}')) is not None
    return

# Generated at 2022-06-21 13:31:47.731731
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    class FakeArg:
        def __init__(self, value):
            self.value = value
            self.orig = value

    input = {
        'file_embed': FakeArg('haha.txt'),
        'valid_file': FakeArg('python3.8-slim.Dockerfile'),
        'empty': FakeArg(''),
        'exist': FakeArg('.vscode/settings.json'),
        'invalid_file': FakeArg('non_exist/file.txt')
    }

# Generated at 2022-06-21 13:31:54.053246
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_file_path = "./src/httpie/test/json_data/test1.json"
    json_file_content = {'a': 'b'}
    result = process_data_embed_raw_json_file_arg(KeyValueArg(json_file_path,'raw_json_file'))
    assert result == json_file_content


test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-21 13:31:58.911892
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    k = KeyValueArg(orig = '@',
                    sep = SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
                    key = '@',
                    value = './input.json')
    print(process_data_embed_raw_json_file_arg(k))
    #{'name': '', 'age': 100, 'isStudent': True, 'subjects': ['Math', 'English', 'CS']}


# Generated at 2022-06-21 13:32:02.667186
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data_1 = KeyValueArg('key', 'value', ':')
    assert process_data_item_arg(data_1) == 'value'


# Generated at 2022-06-21 13:32:13.242801
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg1 = KeyValueArg(key='Authorization', sep=':', value='123456')
    data1 = process_data_raw_json_embed_arg(arg1)
    assert data1 == '123456'

    arg2 = KeyValueArg(key='Authorization', sep=':', value='{"username": "test", "password": "test"}')
    data2 = process_data_raw_json_embed_arg(arg2)
    assert data2['username'] == 'test'
    assert data2['password'] == 'test'

    arg3 = KeyValueArg(key='Authorization', sep=':', value='true')
    data3 = process_data_raw_json_embed_arg(arg3)
    assert data3 == True


# Generated at 2022-06-21 13:32:16.846314
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test = process_data_embed_raw_json_file_arg(arg = KeyValueArg('test', '@test.json'))
    print(test)
    assert test == 'test'


# Generated at 2022-06-21 13:32:20.373107
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    print(process_data_embed_raw_json_file_arg(KeyValueArg('foo', 'test.json')))

test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-21 13:32:30.557147
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('filename.txt', 'test@test.org', '@')
    assert process_file_upload_arg(arg) == ('test@test.org', 'filename.txt', None)

    arg = KeyValueArg('filename.txt', 'test@test.org;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test@test.org', 'filename.txt', 'text/plain')

    # Test if error thrown for no file path
    arg = KeyValueArg('filename.txt', 'test@test.org;text/plain', '@')
    with pytest.raises(ParseError):
        process_file_upload_arg(arg)


# Generated at 2022-06-21 13:32:38.773591
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg.from_str('--json=@/home/mengfei/x.json', '--json')) == {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3",
            "key4": {
                "key5": "value5",
                "key6": "value6",
                "key7": {
                    "key8": "value8"
                }
            }
        }



# Generated at 2022-06-21 13:32:40.172414
# Unit test for function load_json
def test_load_json():
    process_data_raw_json_embed_arg(arg="a: b")

# Generated at 2022-06-21 13:33:01.156170
# Unit test for function process_header_arg
def test_process_header_arg():
    try:
        assert process_header_arg('') == None
    except:
        pass


# Generated at 2022-06-21 13:33:09.810745
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(SEPARATOR_DATA_STRING, "key", "value")
    assert process_data_item_arg(arg) == arg.value
    arg = KeyValueArg(SEPARATOR_DATA_STRING, "key", '{"variants.0.field_id": "Numeric", "variants.0.value": "123"}')
    assert process_data_item_arg(arg) == arg.value
    arg = KeyValueArg(SEPARATOR_DATA_STRING, "key", '{"variants.0.field_id": "Numeric", "variants.0.value": "123", "variants.1.field_id": "Price", "variants.1.value": "100.0"}')
    assert process_data_item_arg(arg) == arg.value
    arg = KeyValue

# Generated at 2022-06-21 13:33:12.296560
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('', '', '', '', '', '{}')
    process_data_embed_file_contents_arg(arg)


# Generated at 2022-06-21 13:33:14.619022
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg()
    arg.value = "foo.txt"
    arg.orig = "foo.txt"
    load_text_file(arg)


# Generated at 2022-06-21 13:33:20.913304
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        '-d',
        SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='',
        value='{"a": "b"}'
    )
    expected = {'a': 'b'}
    result1 = process_data_embed_raw_json_file_arg(arg)
    assert result1 == expected



# Generated at 2022-06-21 13:33:29.244705
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    import os
    import httpie.cli.argtypes
    result = httpie.cli.argtypes.process_data_embed_raw_json_file_arg(
        httpie.cli.argtypes.KeyValueArg(
            argname='data',
            key=None,
            sep=httpie.cli.constants.SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
            value='{"a": 123}'
        )
    )
    assert result == {"a": 123}


# Generated at 2022-06-21 13:33:31.410313
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('K1', 'V1', sep=SEPARATOR_DATA_RAW_JSON)
    assert(process_data_raw_json_embed_arg(arg) == "V1")


# Generated at 2022-06-21 13:33:34.219927
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(0, '--file', '/home/user/file.txt', '--file;/home/user/file.txt')
    assert load_text_file(item) == '\n'


# Generated at 2022-06-21 13:33:35.070335
# Unit test for function load_json
def test_load_json():
    # TODO: 完成测试
    pass

# Generated at 2022-06-21 13:33:39.080779
# Unit test for function load_json
def test_load_json():
    assert load_json(arg = "a", contents = "{'a' : 'b'}") == {'a' : 'b'}



# Generated at 2022-06-21 13:33:56.092488
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg.from_arg('key=value')
    assert process_data_item_arg(arg) == 'value'

# Generated at 2022-06-21 13:34:05.866286
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-21 13:34:11.691258
# Unit test for constructor of class RequestItems
def test_RequestItems():
	request_items = RequestItems()
	assert request_items.headers == RequestHeadersDict()
	assert request_items.data == RequestJSONDataDict()
	assert request_items.files == RequestFilesDict()
	assert request_items.params == RequestQueryParamsDict()
	assert request_items.multipart_data == MultipartRequestDataDict()

# Generated at 2022-06-21 13:34:15.034488
# Unit test for constructor of class RequestItems
def test_RequestItems():
    data = [KeyValueArg(key="key2", value='value2', sep=';')]
    a = RequestItems.from_args(data)
    a.headers["key2"] = "value2"
    assert a.headers['key2'] == "value2"


test_RequestItems()

# Generated at 2022-06-21 13:34:19.761747
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg_with_key = KeyValueArg('k', 'v', 'k', 'v', ';')
    try:
        process_data_raw_json_embed_arg(arg_with_key)
        assert False
    except ParseError as e:
        assert str(e) == '"k": Expecting value'

# Generated at 2022-06-21 13:34:21.343201
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('test', 'test')) == 'test'

# Generated at 2022-06-21 13:34:30.912004
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    args = [
        KeyValueArg('header', SEPARATOR_HEADER, 'user', '1'),
        KeyValueArg('header', SEPARATOR_HEADER, 'password', '123456'),
        KeyValueArg('data', SEPARATOR_DATA_EMBED_FILE_CONTENTS, 'file', './data.json'),
        KeyValueArg('file', SEPARATOR_FILE_UPLOAD, 'file', './data.json')
    ]
    request_items = RequestItems.from_args(args, False)
    assert request_items.data['file'] == '{"name":"jack","age":18}'

# Generated at 2022-06-21 13:34:35.735905
# Unit test for function load_text_file
def test_load_text_file():
    from tempfile import NamedTemporaryFile
    from httpie.cli import parse_items
    with NamedTemporaryFile('w+b', encoding='utf8') as f:
        f.write('žluťoučký koníček'.encode())
        f.flush()
        items = parse_items(['@' + f.name], 'data')
        assert items[0].value == 'žluťoučký koníček'

# Generated at 2022-06-21 13:34:38.357347
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    args = KeyValueArg('arg_value', InitialValue('arg_value'))
    value = process_data_item_arg(args)
    assert value == args.value

# Generated at 2022-06-21 13:34:45.820336
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:35:25.032625
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # Test an empty header
    arg = KeyValueArg('header;', '', 'header;')
    assert process_empty_header_arg(arg) == ''

    # Test a non-empty header
    arg = KeyValueArg('header;', 'foo=bar', 'header;foo=bar')
    try:
        process_empty_header_arg(arg)
        assert False
    except ParseError as e:
        assert "Invalid item" in str(e)

# Generated at 2022-06-21 13:35:26.204690
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    print(process_file_upload_arg(KeyValueArg('', 'foo.txt', '', "baz.pdf")))



# Generated at 2022-06-21 13:35:32.708680
# Unit test for function load_text_file
def test_load_text_file():
    if os.path.exists('./test_load_text_file.txt'):
        os.remove('./test_load_text_file.txt')
    try:
        f = open('./test_load_text_file.txt','w') 
        item = KeyValueArg(orig="./test_load_text_file.txt",key=None,sep=None,value="./test_load_text_file.txt") 
        contents = load_text_file(item)
        assert contents == 'this is a test'
    finally:
        f.close()
        if os.path.exists('./test_load_text_file.txt'):
            os.remove('./test_load_text_file.txt')

# Generated at 2022-06-21 13:35:35.148261
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg("", "", "data", "abc", "abc", False)
    assert "abc" == process_data_item_arg(arg)
    

# Generated at 2022-06-21 13:35:44.413196
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_data_embed_file_contents_arg = [
        'testdata/test-curl-form.json',
        'testdata/test-curl-json.json',
        'testdata/test-curl-raw-json.json',
        'testdata/test-httpie.json',
        'testdata/test-httpie-post.json',
        'testdata/test-input-form.json',
        'testdata/test-input-json.json',
        'testdata/test-input-rawjson.json',
        'testdata/test-pretty.json',
        'testdata/test-pretty-post.json',
        'testdata/test-raw-json.json',
        'testdata/test-raw-post.json'
    ]


# Generated at 2022-06-21 13:35:46.279238
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(parser.parse_kv("Header;Value"))
    except ParseError:
        print("not ok")
    else:
        print("ok")


# Generated at 2022-06-21 13:35:48.752157
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(SEPARATOR_QUERY_PARAM, 'key', 'value')
    assert process_query_param_arg(arg) == 'value'


# Generated at 2022-06-21 13:35:53.483963
# Unit test for function load_text_file
def test_load_text_file():
    # Content of test_file.txt
    contents = 'Hello, World!\n'
    # File to be loaded
    test_file = './test_file.txt'
    # Read content of file
    with open(os.path.expanduser(test_file), 'rb') as f:
        real_contents = f.read().decode()

    assert real_contents == contents


# Generated at 2022-06-21 13:35:54.743883
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    value = "name=carl"
    assert process_data_item_arg(value) == "carl"

# Generated at 2022-06-21 13:36:01.187738
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # GIVEN an arg object
    arg = KeyValueArg(orig=SEPARATOR_DATA_EMBED_FILE_CONTENTS + 'file_name', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key=None, value='file_name')
    
    # WHEN calling process_data_embed_file_contents_arg
    result = process_data_embed_file_contents_arg(arg)

    # THEN result is a string
    assert type(result) is str

# Generated at 2022-06-21 13:36:39.849661
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    import httpie.cli.argtypes
    import httpie.cli.constants
    import httpie.cli.dicts
    import httpie.cli.exceptions
    import httpie.cli.items
    import httpie.utils
    import os
    import pytest
    import typing
    # Skip test if no module httpie
    if not pytest.importorskip("httpie"):
        return
    # Test "no" arg
    no_args: List[httpie.cli.argtypes.KeyValueArg]=[]
    with pytest.raises(httpie.cli.exceptions.ParseError):
        httpie.cli.items.process_query_param_arg(no_args)

# Generated at 2022-06-21 13:36:42.056978
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('', '', '', 'application/json', '{"k": "v"}')
    process_data_raw_json_embed_arg(arg)

# Generated at 2022-06-21 13:36:47.983889
# Unit test for function process_header_arg
def test_process_header_arg():
    """
    Function name: test_process_header_arg
    Purpose: Unit test for the function process_header_arg
    Parameters: None
    Return: No return
    """
    arg = KeyValueArg(["Header"], ":", "", "Header:", 0)
    assert process_header_arg(arg) == ""
    arg = KeyValueArg(["Header"], ":", "value", "Header:value", 0)
    assert process_header_arg(arg) == "value"


# Generated at 2022-06-21 13:36:57.453312
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('foo', 'bar', '-d', 'data:')
    assert process_data_raw_json_embed_arg(arg) == 'bar'

    arg = KeyValueArg('foo', '"bar"', '-d', 'data:')
    assert process_data_raw_json_embed_arg(arg) == 'bar'

    arg = KeyValueArg('foo', '["bar"]', '-d', 'data:')
    assert process_data_raw_json_embed_arg(arg) == ['bar']

    arg = KeyValueArg('foo', '{"foo": "bar"}', '-d', 'data:')
    assert process_data_raw_json_embed_arg(arg) == {"foo": "bar"}


# Generated at 2022-06-21 13:36:59.717452
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(key='a', sep=':', value='b')
    result = process_header_arg(arg)
    assert result is not None
    assert result == 'b'


# Generated at 2022-06-21 13:37:03.405993
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    test_case1 = KeyValueArg("a", "b", "a:b")
    assert(process_data_raw_json_embed_arg(test_case1) == "b")
    test_case2 = KeyValueArg("a", "", "a:")
    assert(process_data_raw_json_embed_arg(test_case2) == "")
    
    

# Generated at 2022-06-21 13:37:08.297013
# Unit test for function load_json
def test_load_json():
    test = "tests/data/testjson.json"
    file_open = open(test,"r")
    contents = file_open.read()
    file_open.close()
    key = KeyValueArg("--data")
    key.value = contents
    key.orig = "--data"
    assert("test_load_json" == load_json(key, contents)["test"])


# Generated at 2022-06-21 13:37:18.418520
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    item = KeyValueArg(key='name', value='test.txt', sep='@@')
    result = process_data_embed_file_contents_arg(item)
    assert result == 'hello'

    item = KeyValueArg(key='name', value='no_such_file.txt', sep='@@')
    try:
        result = process_data_embed_file_contents_arg(item)
    except ParseError as e:
        assert str(e) == '"name": No such file or directory'
        print(str(e))

    item = KeyValueArg(key='name', value='test_not_utf8.txt', sep='@@')

# Generated at 2022-06-21 13:37:21.505426
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg("data", "value1", ";")
    assert process_data_item_arg(arg) == "value1"
    arg = KeyValueArg("data", "", ";")
    assert process_data_item_arg(arg) is ""

# Generated at 2022-06-21 13:37:23.665330
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg()
    arg.orig = 'arg.orig'
    arg.value = 'arg.value'

    result = load_json(arg, 'not json string')
    assert result == 'not json string'

# Generated at 2022-06-21 13:39:20.360935
# Unit test for function process_header_arg
def test_process_header_arg():
    from httpie.cli.argtypes import KeyValueArg
    assert process_header_arg(KeyValueArg('H: v')) == 'v'
    assert process_header_arg(KeyValueArg('H:')) is None
    assert process_header_arg(KeyValueArg('H;')) is None

if __name__ == "__main__":
    test_process_header_arg()

# Generated at 2022-06-21 13:39:24.700844
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="", value=':/home/david/Documents/research/project_paper/mypaper.pdf', sep=':')
    expected_file_name = "mypaper.pdf"
    expected_mime_type = "application/pdf"
    mime_type, file_name = process_file_upload_arg(arg)
    assert(file_name == expected_file_name)
    assert(mime_type == expected_mime_type)

if __name__ == "__main__":
    test_process_file_upload_arg()