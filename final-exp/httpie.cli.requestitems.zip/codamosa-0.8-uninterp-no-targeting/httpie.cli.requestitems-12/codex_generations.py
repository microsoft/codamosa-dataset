

# Generated at 2022-06-21 13:29:39.432615
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    upload_arg = KeyValueArg(
        'SEPARATOR_FILE_UPLOAD',
        'filename',
        '../test/post.txt',
        '../test/post.txt',
    )
    result = process_file_upload_arg(upload_arg)
    assert result[0] == 'post.txt'
    assert result[1].read() == (
        '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ\n'
    )
    assert result[2] == 'text/plain'

# Generated at 2022-06-21 13:29:50.638583
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # As form
    obj = RequestItems(True)
    assert isinstance(obj.data, RequestDataDict)
    assert isinstance(obj.headers, RequestHeadersDict)
    assert isinstance(obj.files, RequestFilesDict)
    assert isinstance(obj.params, RequestQueryParamsDict)

    # As json
    obj = RequestItems(False)
    assert isinstance(obj.data, RequestJSONDataDict)
    assert isinstance(obj.headers, RequestHeadersDict)
    assert isinstance(obj.files, RequestFilesDict)
    assert isinstance(obj.params, RequestQueryParamsDict)

    # Test from_args

# Generated at 2022-06-21 13:29:55.727964
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import SEPARATOR_DATA_STRING
    d = {'key': 'value'}
    l = [KeyValueArg(key=None, sep=SEPARATOR_DATA_STRING, value='key=value')]
    result = RequestItems.from_args(l, True).data
    assert result == d


# Generated at 2022-06-21 13:30:05.363137
# Unit test for function load_json
def test_load_json():
    from httpie.cli import arguments
    # Test correct
    arg = arguments.KeyValueArg('/a;d=', 'func|name')
    value = load_json(arg, '{"name": "nicolas"}')
    assert value == {'name': 'nicolas'}, 'test_load_json failed'
    # Test incorrect
    arg = arguments.KeyValueArg('/a;d=', 'func|name')
    try:
        load_json(arg, '{"name": "nicolas')
        assert False, 'test_load_json failed'
    except ParseError:
        assert True
    except ValueError:
        assert False, 'test_load_json failed'

# Generated at 2022-06-21 13:30:07.525526
# Unit test for function load_json
def test_load_json():
    test_load_json_correct()
    test_load_json_error()


# Generated at 2022-06-21 13:30:17.490494
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    fileFullPath = "/var/tmp/test.txt"
    fileName = "test.txt"
    expectedMimeType = "text/plain"
    fileHandle = open(fileFullPath, 'rb')
    arg = KeyValueArg("", "", "", "", "")
    arg.key = "test"
    arg.value = fileFullPath

    result = process_file_upload_arg(arg)
    assert isinstance(result, tuple)
    assert len(result) == 3
    assert result[0] == fileName
    assert result[1].name == fileFullPath
    assert result[2] == expectedMimeType



# Generated at 2022-06-21 13:30:21.134686
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    request_item_args = [KeyValueArg('test_key=test_value', 'test_key', 'test_value')]
    instance = RequestItems.from_args(request_item_args)
    assert instance.params['test_key'] == 'test_value'

# Generated at 2022-06-21 13:30:22.676235
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    response = process_data_item_arg('key=value')
    assert response == 'value'


# Generated at 2022-06-21 13:30:25.441903
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file('test')
        assert False
    except ParseError as e:
        assert str(e) == '"test": No such file or directory'

# Generated at 2022-06-21 13:30:27.476780
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg(
        '@abc.json', '@abc.json', '@')) == {"hello": "world"}

# Generated at 2022-06-21 13:30:38.410566
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('k1', 'v1', None)
    ret = process_query_param_arg(arg)
    assert ret == 'v1'

if __name__ == '__main__':
    test_process_query_param_arg()

# Generated at 2022-06-21 13:30:40.498385
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    item = KeyValueArg("a:1")
    print(process_data_item_arg(item))


# Generated at 2022-06-21 13:30:45.034390
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@', key='@', sep='@', value='data.json')
    print(process_data_embed_raw_json_file_arg(arg))
    # {'a': 1, 'b': 'bb', 'c': [1, 2]}



# Generated at 2022-06-21 13:30:46.652542
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(('', 'test_file.txt'), 'test_file.txt', '', ';')) == '\nTest\tFile\n'

# Generated at 2022-06-21 13:30:48.145414
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    key, value = process_query_param_arg(KeyValueArg("key", "value"))
    assert key == "key"
    assert value == "value"



# Generated at 2022-06-21 13:30:50.241817
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg.from_arg(';')) == ''
    assert process_empty_header_arg(KeyValueArg.from_arg(';=a')) == ''

# Generated at 2022-06-21 13:30:51.496355
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = [('key', 'value')]
    process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-21 13:31:01.827234
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item_args = [KeyValueArg(':', ':', '{"foo": "bar"}')]
    request_items = RequestItems.from_args(item_args)
    assert(request_items.data['foo'] == "bar")
    item_args = [KeyValueArg(':', ':', '{"foo": ["bar", "bar2"]}')]
    request_items = RequestItems.from_args(item_args)
    assert(request_items.data['foo'][0] == "bar")
    assert(request_items.data['foo'][1] == "bar2")

# Generated at 2022-06-21 13:31:08.436863
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('data1', 'value1', SEPARATOR_DATA_STRING)) == 'value1'
    assert process_data_item_arg(KeyValueArg('data2', 'value2', SEPARATOR_DATA_STRING)) == 'value2'

test_process_data_item_arg()


# Generated at 2022-06-21 13:31:11.628118
# Unit test for function load_json
def test_load_json():
    json_str = "{\"key\": \"value\", \"another\": 123}"
    json_obj = load_json(KeyValueArg(key=None, value=json_str, sep='json'), json_str)
    assert json_obj['key']=="value"
    assert json_obj['another']==123

# Generated at 2022-06-21 13:31:21.170450
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(key="body", value="{\"hello\": \"world\"}", sep="@")
    assert process_data_embed_raw_json_file_arg(item) == {'hello': 'world'}

# Generated at 2022-06-21 13:31:23.203712
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args = KeyValueArg(KeyValueArg("--", "text.txt"), "text.txt")
    assert(process_file_upload_arg(args) == ("text.txt", open("text.txt", "rb"), "text/plain"))

# Generated at 2022-06-21 13:31:26.748398
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg(orig="Header:=",sep=':',key='Header',value=':'))
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-21 13:31:32.941312
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    """
    Test function process_file_upload_arg
    """
    print('test_process_file_upload_arg')
    arg = KeyValueArg(
        '--form',
        'file@/tmp/test.json',
    )
    print(process_file_upload_arg(arg))


if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-21 13:31:45.574682
# Unit test for function load_json
def test_load_json():
    assert load_json({'orig': 'key=value'}, '"value"') == 'value'
    assert load_json({'orig': 'key=value'}, '"string"') == 'string'
    assert load_json({'orig': 'key=value'}, 'true') == True
    assert load_json({'orig': 'key=value'}, 'fasle') == False
    assert load_json({'orig': 'key=value'}, '1') == 1
    assert load_json({'orig': 'key=value'}, '1.1') == 1.1
    assert load_json({'orig': 'key=value'}, '[1,2,3]') == [1, 2, 3]

# Generated at 2022-06-21 13:31:49.068670
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems()
    assert items.headers == {}
    assert items.data == {}
    assert items.files == {}
    assert items.params == {}
    assert items.multipart_data == {}



# Generated at 2022-06-21 13:31:55.121660
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data_item_raw_json = 'a'+ SEPARATOR_DATA_RAW_JSON + '"{\\"a\\":1,\\"b\\":2}"';
    arg = KeyValueArg(data_item_raw_json, 'a', SEPARATOR_DATA_RAW_JSON, '"{\\"a\\":1,\\"b\\":2}"');
    process_data_raw_json_embed_arg(arg);

# Generated at 2022-06-21 13:31:58.648056
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    print(process_data_embed_file_contents_arg(KeyValueArg(None, 'file', './test/test.json', None, None, None)))
    print(process_data_embed_file_contents_arg(KeyValueArg(None, 'file', '', None, None, None)))


# Generated at 2022-06-21 13:32:01.153746
# Unit test for function load_text_file
def test_load_text_file():
    try:
        contents = load_text_file(KeyValueArg("a", "test.txt"))
        print("test_load_text_file PASSED")
    except Exception as e:
        print("test_load_text_file FAILED")
        print(e)


# Generated at 2022-06-21 13:32:06.957193
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key='header', value='')
    assert process_empty_header_arg(arg) == ''
    arg = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key='header', value='Cat')
    assert process_empty_header_arg(arg) == 'Cat'

# Generated at 2022-06-21 13:32:30.706727
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.argtypes import KeyValueArg

    arg = KeyValueArg(None, 'data', 'key: value', ':')
    assert process_data_raw_json_embed_arg(arg) == {'key': 'value'}

    arg = KeyValueArg(None, 'data', 'key: {"key": "value"}', ':')
    assert process_data_raw_json_embed_arg(arg) == {'key': {'key': 'value'}}

    arg = KeyValueArg(None, 'data', 'key: [1, 2]', ':')
    assert process_data_raw_json_embed_arg(arg) == {'key': [1, 2]}

    arg = KeyValueArg(None, 'data', 'key: true', ':')
    assert process_data_raw_json

# Generated at 2022-06-21 13:32:33.388181
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('H', 'v')) == 'v'
    assert process_header_arg(KeyValueArg('H', '')) is None



# Generated at 2022-06-21 13:32:36.435559
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # arg.value is empty
    arg = KeyValueArg("-H", "", "", "")
    assert process_empty_header_arg(arg) == ""

# Generated at 2022-06-21 13:32:39.382895
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('a')) == None
    assert process_header_arg(KeyValueArg('a=abc')) == 'abc'


# Generated at 2022-06-21 13:32:42.180142
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    # Test of multiple fields
    arg = KeyValueArg(orig="key=value", key="key", value="value", sep="=")
    assert process_data_item_arg(arg) == "value"

# Generated at 2022-06-21 13:32:47.673267
# Unit test for function process_header_arg
def test_process_header_arg():
    arg_non_empty = KeyValueArg('Header:value', 'Header', ':', 'value')
    assert process_header_arg(arg_non_empty) == 'value'
    arg_empty = KeyValueArg('Header:', 'Header', ':', '')
    assert process_header_arg(arg_empty) is None
    arg_no_value = KeyValueArg('Header', 'Header', '', '')
    assert process_header_arg(arg_no_value) is None


# Generated at 2022-06-21 13:32:53.874581
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():

    with pytest.raises(ParseError) as exec_info:
        process_empty_header_arg(KeyValueArg(key='bazz', value='foo', orig='bazz:foo'))
    assert str(exec_info.value) == 'Invalid item "bazz:foo" (to specify an empty header use `Header;`)'

    result = process_empty_header_arg(KeyValueArg(key='bazz', value='', orig='bazz'))
    assert result == ''


# Generated at 2022-06-21 13:33:03.115105
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test_cases = [
        {
            "name": "test_process_query_param_arg",
            "query_param": "foo",
            "result": "foo"
        },
        {
            "name": "test_process_query_param_arg",
            "query_param": "foo=bar",
            "result": "foo=bar"
        }
    ]

    for test_case in test_cases:
        result = process_query_param_arg(test_case["query_param"])
        assert(result == test_case["result"])


# Generated at 2022-06-21 13:33:11.128975
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import (
    SEPARATORS_GROUP_MULTIPART, SEPARATOR_DATA_EMBED_FILE_CONTENTS,
    SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
    SEPARATOR_DATA_RAW_JSON, SEPARATOR_DATA_STRING, SEPARATOR_FILE_UPLOAD,
    SEPARATOR_FILE_UPLOAD_TYPE, SEPARATOR_HEADER, SEPARATOR_HEADER_EMPTY,
    SEPARATOR_QUERY_PARAM,
)

# Generated at 2022-06-21 13:33:13.924932
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
	arg = KeyValueArg.from_arg_string('foo=bar')
	value = process_data_item_arg(arg)
	print(value)
	assert value == 'bar'


# Generated at 2022-06-21 13:33:29.514618
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(("Key", "value")) == "value"



# Generated at 2022-06-21 13:33:33.949919
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # setup
    item = KeyValueArg('key', ';', '/json/path')
    # actions
    value = process_data_embed_raw_json_file_arg(item)
    # assertions
    assert value is not None
    assert value['id'] == '01234567-89ab-cdef-0123-456789abcdef'

# Generated at 2022-06-21 13:33:37.183440
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data_item_arg = KeyValueArg(
        '', '', '', 'data.json', '{"name": "Wei"}', ';', ';'
    )
    result = process_data_item_arg(data_item_arg)
    assert "Wei" in result

# Generated at 2022-06-21 13:33:41.689966
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():

  response = process_file_upload_arg(KeyValueArg(0, "file", "tmp/data/curl.txt"))

  assert response == ('curl.txt', ('/Users/jd/Documents/projects/httpie/tests/tmp/data/curl.txt', 'rb', 2), None)

# Generated at 2022-06-21 13:33:45.340570
# Unit test for function load_text_file
def test_load_text_file():
    import os
    os.chdir('/mnt/c/Users/lchen/Documents/GitHub/httpie/')
    arg = KeyValueArg('body', 'Content', 'Content-Type;text/html;')
    print(load_text_file(arg))
test_load_text_file()

# Generated at 2022-06-21 13:33:52.347436
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_value = '/path/to/file:image/png'
    arg = argparse.Namespace(key=None, sep=SEPARATOR_FILE_UPLOAD, value=file_upload_value, orig=None)
    assert process_file_upload_arg(arg) == ('file', open('/path/to/file', 'rb'), 'image/png')

    file_upload_value = '/path/to/file'
    arg = argparse.Namespace(key=None, sep=SEPARATOR_FILE_UPLOAD, value=file_upload_value, orig=None)
    assert process_file_upload_arg(arg) == ('file', open('/path/to/file', 'rb'), get_content_type('/path/to/file'))

# Generated at 2022-06-21 13:34:02.748099
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    def check_value(in_val: str, out_val: JSONType) -> None:
        class MockArg:
            def __init__(self, value: str):
                self.value = value
                self.orig = value

        arg = MockArg(in_val)
        assert process_data_raw_json_embed_arg(arg) == out_val
    check_value('key1=1&key2=2', {"key1": 1, "key2": 2})
    check_value('"a string"',   "a string")
    check_value('1',            1)
    check_value('{"1": "1", "2": "2"}', {"1": "1", "2": "2"})

# Generated at 2022-06-21 13:34:07.799266
# Unit test for function process_header_arg
def test_process_header_arg():
    # Test when there is a value
    arg = KeyValueArg('key', ':', 'value')
    assert process_header_arg(arg) == arg.value
    # Test when there is no value
    arg = KeyValueArg('key', ':', '')
    assert process_header_arg(arg) == arg.value


# Generated at 2022-06-21 13:34:14.753400
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    input_string = "post \"https://www.yahoo.com\" test=1"
    input_string2 = "post \"https://www.yahoo.com\" test=1 test2=2"
    input_list = input_string.split()
    input_list2 = input_string2.split()
    print(input_list)

    print(process_data_item_arg(input_list[2]))
    print(process_data_item_arg(input_list2[2]))
    print(process_data_item_arg(input_list2[3]))


# Generated at 2022-06-21 13:34:20.553904
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    print('Testing function process_data_embed_file_contents_arg')
    from httpie.cli import parse_items
    from httpie.cli.argtypes import KeyValueArg

    arg_str = '@../test_file/test_post.txt'
    arg = KeyValueArg(arg_str)

    parse_items.test_process_data_embed_file_contents_arg(arg)



# Generated at 2022-06-21 13:34:47.451805
# Unit test for constructor of class RequestItems
def test_RequestItems():
    a = RequestItems()
    a_str = str(a)
    assert a_str == 'RequestItems(headers=RequestHeadersDict(), data=RequestJSONDataDict(), files=RequestFilesDict(), params=RequestQueryParamsDict(), multipart_data=MultipartRequestDataDict())'
    assert type(a.headers) == RequestHeadersDict
    assert type(a.data) == RequestJSONDataDict
    assert type(a.files) == RequestFilesDict
    assert type(a.params) == RequestQueryParamsDict
    assert type(a.multipart_data) == MultipartRequestDataDict
    a = RequestItems(as_form=True)
    a_str = str(a)

# Generated at 2022-06-21 13:34:50.803691
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
  key = SEPARATOR_DATA_STRING
  value = 'foo=bar'
  item = KeyValueArg(key, value)
  assert process_data_item_arg(item) == value

# Generated at 2022-06-21 13:34:59.512201
# Unit test for constructor of class RequestItems

# Generated at 2022-06-21 13:35:01.489417
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(sep="?", key ="foo", value="bar")
    assert process_query_param_arg(arg) == "bar"

# Generated at 2022-06-21 13:35:06.075344
# Unit test for function load_text_file
def test_load_text_file():
    temp_file = open("test_file", "w")
    temp_file.write("Hello")
    temp_file.close()

    arg = KeyValueArg("name", "test_file", "@")
    contents = load_text_file(arg)

    assert contents == "Hello"
    os.remove("test_file")

# Generated at 2022-06-21 13:35:10.117476
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    input = KeyValueArg(key='test',
                        value='test',
                        sep=SEPARATOR_QUERY_PARAM)
    output = process_query_param_arg(input)
    assert output == 'test'


# Generated at 2022-06-21 13:35:13.127923
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('key', 'value', 'sep')
    try:
        load_text_file(item)
    except ParseError as e:
        print(e)


# Generated at 2022-06-21 13:35:16.870985
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="name", key='name', value='../test_resource/testfile.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    value = load_text_file(item)
    assert value == 'test file content'

# Generated at 2022-06-21 13:35:20.189614
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig='', key=None, sep='=', value='{"key1": "value1"}')
    assert process_data_raw_json_embed_arg(arg) == {"key1": "value1"}


# Generated at 2022-06-21 13:35:24.271249
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file('request.txt') == 'GET / HTTP/1.1\nHost: example.com\nAccept-Encoding: gzip, deflate\nAccept: */*\nUser-Agent: python-requests/2.21.0\n\n'

# Generated at 2022-06-21 13:35:44.998677
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import json
    import io
    import unittest
    from httpie.compat import str

    test_data = [
        {"foo": "bar", "baz": "qux"},
        {"foo": 1, "baz": 2},
        {"foo": True, "baz": False},
    ]
    for value in test_data:
        raw_json = str(json.dumps(value))
        file_like_obj1 = io.StringIO(raw_json)
        assert process_data_raw_json_embed_arg(KeyValueArg('test', raw_json, None)) == value

# Generated at 2022-06-21 13:35:47.687753
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,key='key',value='/Users/jiao/PycharmProjects/httpie/test/test.txt')
    result = process_data_embed_file_contents_arg(arg)
    assert result == 'hello,world'


# Generated at 2022-06-21 13:35:51.276463
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('header;', '', '', '')
    assert process_empty_header_arg(arg) == ''

if __name__ == '__main__':
    test_process_empty_header_arg()

# Generated at 2022-06-21 13:35:53.573305
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(key='Content-type', sep="$", value="application/json")
    header = process_header_arg(arg)
    assert header == 'application/json'


# Generated at 2022-06-21 13:35:55.557858
# Unit test for function process_header_arg
def test_process_header_arg():
    test_item = KeyValueArg(sep="Header", key="Authorization", value="Basic 1234")
    assert process_header_arg(test_item) == "Basic 1234"


# Generated at 2022-06-21 13:36:05.931357
# Unit test for function load_json
def test_load_json():
    # Test case 1
    dict_string = '{"name":"John", "age":30, "car":null}'
    dict_json = load_json("dict_string_1", dict_string)

    if dict_json['name'] == "John" and dict_json['age'] == 30 and dict_json['car'] is None:
        if dict_json['name'] == dict_json['name'] and dict_json['age'] == dict_json['age'] and dict_json['car'] == dict_json['car']:
            print("Unit test passed!")

    # Test case 2
    dict_string = '{"name": "John", "age": 30, "car": null}'
    dict_json = load_json("dict_string_2", dict_string)


# Generated at 2022-06-21 13:36:14.381932
# Unit test for function load_json
def test_load_json():
    test_arg = {"orig": "", "value": "1"}
    assert load_json(test_arg, '1') == 1
    test_arg = {"orig": "", "value": "a"}
    assert load_json(test_arg, 'a') == "a"
    test_arg = {"orig": "", "value": "'a'"}
    with pytest.raises(ParseError):
        load_json(test_arg, "'a'")
    test_arg = {"orig": "", "value": "[1,2,3]"}
    assert load_json(test_arg, "[1,2,3]") == [1, 2, 3]
    test_arg = {"orig": "", "value": "['a', 'b']"}

# Generated at 2022-06-21 13:36:19.984039
# Unit test for function process_header_arg
def test_process_header_arg():
    # Process header
    _header_value = process_header_arg(KeyValueArg('Content-Type', 'text/html'))
    # The value of header is 'text/html'
    assert _header_value == 'text/html'
    # Process header with value as None
    _header_empty = process_header_arg(KeyValueArg('Content-Type', ''))
    # The value of header is None
    assert _header_empty is None



# Generated at 2022-06-21 13:36:26.604516
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    file_name = r"D:\workspace\GitHub\httpie\test_data\data.file"
    with open(file_name, 'w') as file_data:
        file_data.write('http://www.example.com/')
    data_item = KeyValueArg(sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key='test',
                            value=file_name)
    print(process_data_embed_file_contents_arg(data_item))
    os.remove(file_name)



# Generated at 2022-06-21 13:36:31.216662
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg=KeyValueArg('-F','m:mime-type;filename')
    assert process_file_upload_arg(arg) == ('filename',open(filename,'rb'),'mime-type')
    arg=KeyValueArg('-F','filename')
    assert process_file_upload_arg(arg) == ('filename',open(filename,'rb'),'application/octet-stream')

# Generated at 2022-06-21 13:37:13.565592
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(orig='--data', key='data', value=None, sep=':')
    contents = str()
    value = load_json(arg, contents)
    assert not value

# Generated at 2022-06-21 13:37:15.080875
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg("foo=bar")
    assert process_query_param_arg(arg) == "bar"


# Generated at 2022-06-21 13:37:18.657009
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    request_items = RequestItems.from_args([KeyValueArg(
        orig='param1=value1',
        key='param1',
        value='value1',
        sep='&',
        end='='
    )])
    assert request_items.params['param1'] == 'value1'

# Generated at 2022-06-21 13:37:25.933893
# Unit test for function load_text_file
def test_load_text_file():
    # test file name
    file_name = "test.txt"
    test_text_file = open(file_name, "w")
    test_text_file.write("testing text file")
    test_text_file.close()

    item = KeyValueArg(None, "test", None, None)
    item.value = file_name
    item.orig = file_name

    # should return string "testing text file"
    assert load_text_file(item) == "testing text file"

    os.remove(file_name)

    # test file name
    file_name = "test.txt"
    test_text_file = open(file_name, "wb")
    test_text_file.write(b"\x00")
    test_text_file.close()


# Generated at 2022-06-21 13:37:30.449666
# Unit test for function load_json
def test_load_json():
    assert load_json({"key1": "value1"}) == {"key1": "value1"}
    assert load_json(["value1", "value2"]) == ["value1", "value2"]
    assert load_json(1) == 1
    assert load_json("value") == "value"

# Generated at 2022-06-21 13:37:34.740542
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    query_param = KeyValueArg('foo', 'bar', '=')
    result = process_query_param_arg(query_param)
    assert result == 'bar'

test_process_query_param_arg()

# Generated at 2022-06-21 13:37:36.582117
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg(key='k', value='v', sep="?")) == 'v'

# Generated at 2022-06-21 13:37:41.589307
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import (
        SEPARATOR_FILE_UPLOAD_TYPE,
    )
    arg = KeyValueArg(
        orig = "--form",
        key = "--form",
        sep = "=",
        value = ": ",
    )
    filename = "tests/data/upload_raw.json"
    parts = filename.split(SEPARATOR_FILE_UPLOAD_TYPE)
    basename = "upload_raw.json"
    # mime_type = parts[1] if len(parts) > 1 else None
    # assert(mime_type == None)
    f = open(os.path.expanduser(filename), 'rb')

# Generated at 2022-06-21 13:37:48.243925
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=';',
        key='test',
        value='testfile.txt;text/plain',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'testfile.txt'
    assert f.read() == b'foo\n'
    assert mime_type == 'text/plain'
    # Missing content type
    arg = KeyValueArg(
        sep=';',
        key='test',
        value='testfile.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'testfile.txt'
    assert f.read() == b'foo\n'
    assert mime_type == 'text/plain'
    # No file

# Generated at 2022-06-21 13:37:50.992685
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@test.txt')) == 'this is testing file'

# Generated at 2022-06-21 13:38:37.185463
# Unit test for constructor of class RequestItems
def test_RequestItems():
    args = [KeyValueArg('foo', 'bar'), KeyValueArg('foo', 'bar2')]
    request_items = RequestItems.from_args(args)
    assert request_items.data["foo"]
    assert request_items.data["foo"] == 'bar'
    args = [KeyValueArg('foo', 'bar'), KeyValueArg('foo', 'bar2'), KeyValueArg('bar', '123')]
    request_items = RequestItems.from_args(args)
    assert request_items.data["foo"]
    assert request_items.data["foo"] == 'bar'
    assert request_items.data["bar"]
    assert request_items.data["bar"] == '123'
    assert request_items.params["foo"]
    assert request_items.params["foo"] == 'bar'

# Generated at 2022-06-21 13:38:38.869829
# Unit test for function load_text_file
def test_load_text_file():
    contents = load_text_file(item='data@test.txt')
    #print(contents)

# Generated at 2022-06-21 13:38:43.714887
# Unit test for constructor of class RequestItems
def test_RequestItems():
    args = [
        KeyValueArg(sep='', key='', value='1'),
        KeyValueArg(sep='', key='', value='2'),
        KeyValueArg(sep='', key='', value='4'),
    ]
    request_items = RequestItems.from_args(args)
    assert request_items.data[''] == '4'

# Generated at 2022-06-21 13:38:46.332406
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    data = process_data_embed_raw_json_file_arg(KeyValueArg('f', 'file_name'))
    assert data == {}

# Generated at 2022-06-21 13:38:55.992397
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():

    # Try to embed a file that does not exist.
    arg = KeyValueArg(
        orig='file-missing;@/tmp/nosuchfile.txt',
        key='file-missing',
        value='@/tmp/nosuchfile.txt',
        sep=';'
    )
    try:
        process_data_embed_file_contents_arg(arg)
    except ParseError as e:
        assert 'No such file or directory:' in str(e)

    # Try to embed a file that is not text.
    arg = KeyValueArg(
        orig='file-not-text;@/tmp/test.bin',
        key='file-not-text',
        value='@/tmp/test.bin',
        sep=';'
    )

# Generated at 2022-06-21 13:39:01.794610
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg(None, None, "key=value")) == "value"
    assert process_query_param_arg(KeyValueArg(None, None, "key=")) == ""
    assert process_query_param_arg(KeyValueArg(None, None, "key")) == ""

if __name__ == '__main__':
    test_process_query_param_arg()

# Generated at 2022-06-21 13:39:05.894074
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    if __name__ == '__main__':
        arg = KeyValueArg(orig='test', key='test', value='testvalue', sep=';')
        print(process_data_embed_raw_json_file_arg(arg))

# Generated at 2022-06-21 13:39:07.972967
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg(KeyValueArg('file', 'test.py')) == 'import unittest\n'

# Generated at 2022-06-21 13:39:10.387702
# Unit test for function process_header_arg
def test_process_header_arg():
    input_arg = KeyValueArg(KeyValueArg(orig="header:value", sep=":", key="header", value="value"))
    assert process_header_arg(input_arg) == "value"


# Generated at 2022-06-21 13:39:11.185689
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # type: () -> None
    pass