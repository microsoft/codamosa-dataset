

# Generated at 2022-06-21 13:29:46.381889
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg_value = None
    arg_sep = SEPARATOR_HEADER_EMPTY
    arg = KeyValueArg(arg_sep, "key", arg_value, "key")
    v = process_empty_header_arg(arg)
    assert v == None

    arg_value = "value"
    arg = KeyValueArg(arg_sep, "key", arg_value, "key;value")
    try:
        v = process_empty_header_arg(arg)
        assert False
    except Exception:
        assert True


# Generated at 2022-06-21 13:29:53.073437
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    path_to_file = "./tmp-json"
    line_to_write = '{"name": "httpie1.0"}'
    with open(path_to_file, "w") as f:
        f.write(line_to_write)
    arg = KeyValueArg("--data-raw-json", path_to_file)
    assert process_data_embed_raw_json_file_arg(arg) == \
           load_json(arg, line_to_write)

# Generated at 2022-06-21 13:30:00.764928
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    augmented_func_name = 'httpie.cli.requestitems.process_file_upload_arg'
    myfile = "hello"
    myfile_type = "plain/text"
    
    full_name = augmented_func_name + "('hello;plain/text')"
    assert process_file_upload_arg(full_name) == (os.path.basename(myfile), f, myfile_type)
    
    full_name = augmented_func_name + "('hello')"
    assert process_file_upload_arg(full_name) == (os.path.basename(myfile), f, mime_type or get_content_type(filename))
    

# Generated at 2022-06-21 13:30:05.806865
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    key = '--foo'
    value = 'bar'
    result_value = 'bar'

    kv_arg = KeyValueArg(key, value, '--foo{}bar'.format(SEPARATOR_DATA_STRING))

    assert process_data_item_arg(kv_arg) == result_value


# Generated at 2022-06-21 13:30:12.701401
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(orig=None,sep=None,key=None,value=None)
    arg.orig = "param.txt"
    arg.value = "/Users/test/test.txt"
    filename,f,content_type = process_file_upload_arg(arg)
    assert filename == "test.txt"
    assert content_type == "text/plain"
    assert "test" in f.readline()


# Generated at 2022-06-21 13:30:19.805569
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'foo'
    mime_type = 'application/json'
    try:
        f = open(os.path.expanduser(filename), 'rb')
    except IOError as e:
        raise ParseError('"%s": %s' % (filename, e))
    (basename, file, content_type) = process_file_upload_arg(filename+';'+mime_type)

if __name__ == "__main__":
    test_process_file_upload_arg()

# Generated at 2022-06-21 13:30:23.189835
# Unit test for function load_text_file
def test_load_text_file():
    request_item_string = '@1.txt'
    parts = request_item_string.split('@')
    item = KeyValueArg(parts[0], parts[1])
    assert load_text_file(item) == 'London\n'


# Generated at 2022-06-21 13:30:25.690292
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    query_param_arg = KeyValueArg('b=2')
    assert process_query_param_arg(query_param_arg) == '2'


# Generated at 2022-06-21 13:30:28.263873
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    args = KeyValueArg(
        sep=SEPARATOR_QUERY_PARAM,
        key='arg1',
        value='val1'
    )
    assert process_query_param_arg(args) == 'val1'


# Generated at 2022-06-21 13:30:31.439983
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(name=None, key=None, value="test")
    arg.sep = SEPARATOR_DATA_STRING
    s = process_data_item_arg(arg)
    print(s)


# Generated at 2022-06-21 13:30:43.001259
# Unit test for function process_header_arg
def test_process_header_arg():
    headers = process_header_arg('test_header:test_value')
    assert headers is not None



# Generated at 2022-06-21 13:30:46.895165
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg(orig = 'data@file.txt', sep = SEPARATOR_DATA_EMBED_FILE_CONTENTS, key = 'data', value = 'file.txt')
    data = load_text_file(arg)
    assert data == 'test'


# Generated at 2022-06-21 13:30:55.878477
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import io
    import tempfile

    # create a temporary file
    file = tempfile.NamedTemporaryFile(mode='w+b', delete=False)
    try:
        # write to file
        file.write(b'hello world')
        # check if data exists
        file.seek(0)
        assert file.read() == b'hello world'
        # return name of the file
        filepath = file.name
    finally:
        file.close()
    # create an arg with value as absolute path of file
    arg = KeyValueArg("file", filepath, "=", True)
    # process the arg
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == "test_process_file_upload_arg.txt"

# Generated at 2022-06-21 13:31:02.872545
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg(sep=';', key='Name', value=None)) == None

    try:
        assert process_empty_header_arg(KeyValueArg(sep=';', key='Name', value='Value'))
    except ParseError as e:
        assert str(e) == 'Invalid item "Name;Value" (to specify an empty header use `Header;`)'

# Generated at 2022-06-21 13:31:11.762709
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg1 = KeyValueArg("file@test.txt", "file@test.txt")
    arg2 = KeyValueArg("file@test.txt;image/png", "file@test.txt;image/png")
    assert process_file_upload_arg(arg1) == ("test.txt", open(os.path.expanduser("test.txt"), 'rb'), None)
    assert process_file_upload_arg(arg2) == ("test.txt", open(os.path.expanduser("test.txt"), 'rb'), "image/png")
if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-21 13:31:14.139967
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(orig = "Header: value")) == "value"
    print("test_process_header_arg passed")


# Generated at 2022-06-21 13:31:18.527198
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key="uname", value="bob", sep=SEPARATOR_DATA_STRING, orig="uname=bob")
    assert(process_data_item_arg(arg) == "bob")

# Generated at 2022-06-21 13:31:29.610895
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems.from_args(['k1=v1', 'k2=v2'])
    assert hasattr(instance, 'data')
    assert hasattr(instance, 'headers')
    assert hasattr(instance, 'files')
    assert hasattr(instance, 'params')
    assert hasattr(instance, 'multipart_data')
    assert isinstance(instance.data, RequestDataDict)
    assert isinstance(instance.headers, RequestHeadersDict)
    assert isinstance(instance.files, RequestFilesDict)
    assert isinstance(instance.params, RequestQueryParamsDict)
    assert isinstance(instance.multipart_data, MultipartRequestDataDict)


# Generated at 2022-06-21 13:31:34.881063
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # case 1
    arg = KeyValueArg(sep=";", key=":status", value=None)
    value = process_empty_header_arg(arg)
    assert value == ""

    # case 2
    arg = KeyValueArg(sep=";", key=":status", value="200")
    try:
        value = process_empty_header_arg(arg)
    except ParseError as e:
        assert "Invalid item" in e.msg

# Generated at 2022-06-21 13:31:47.826828
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-21 13:32:06.590749
# Unit test for function process_header_arg
def test_process_header_arg():
    arg_test = KeyValueArg.make('test_sep', 'test_key', 'test_value')
    assert process_header_arg(arg_test) == 'test_value'



# Generated at 2022-06-21 13:32:15.809805
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # testing class constructor
    assert len(RequestItems()) == 4
    assert len(RequestItems(as_form=True)) == 4
    # testing from_args function
    assert len(RequestItems.from_args([])) == 4
    assert len(RequestItems.from_args([]).multipart_data) == 0
    assert len(RequestItems.from_args([KeyValueArg(SEPARATOR_HEADER, 'a1', 'v1')])) == 4
    assert len(RequestItems.from_args(
        [KeyValueArg(SEPARATOR_HEADER, 'a1', 'v1')]).multipart_data) == 0
    assert len(RequestItems.from_args(
        [KeyValueArg(SEPARATOR_HEADER, 'a1', 'v1')]).headers) == 1

# Generated at 2022-06-21 13:32:21.008587
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_args = []
    item = KeyValueArg('--data_embed_file_contents', "~/test.txt")
    test_args.append(item)
    req_items = RequestItems.from_args(test_args)
    assert req_items.data == {"~/test.txt": "test"}


# Generated at 2022-06-21 13:32:28.241287
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # given
    key = 'key'
    value = 'raw json value'
    request_item_args = [KeyValueArg(orig='{\"key\": \"value\"}', key='key', value='raw json value', sep='=')]
    instance = RequestItems.from_args(request_item_args, as_form=False)
    # when
    value = process_data_raw_json_embed_arg(arg=instance.data)
    # then
    assert value == {key: value}

    # given
    request_item_args = [KeyValueArg(orig='{\"key\": \"value\"}', key='key', value='', sep='=')]
    instance = RequestItems.from_args(request_item_args, as_form=False)
    # when
    value = process_data_raw_json

# Generated at 2022-06-21 13:32:30.964787
# Unit test for function load_json
def test_load_json():
    assert load_json("a", "{'a':'b'}") == {'a':'b'}

load_json("a", "{'a':'b'}")

# Generated at 2022-06-21 13:32:32.660761
# Unit test for constructor of class RequestItems
def test_RequestItems():
    ri = RequestItems(as_form=False)
    assert isinstance(ri, RequestItems)



# Generated at 2022-06-21 13:32:38.220596
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(None, None, None, None, None)
    arg.value = "testvalue"
    arg.key = "testheader"
    arg.sep = "testsep"
    arg.orig = "testorig"
    assert process_data_item_arg(arg) == "testvalue"


# Generated at 2022-06-21 13:32:40.812702
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg('name', 'data', SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(item) == 'data'

# Generated at 2022-06-21 13:32:43.203003
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    file_arg = KeyValueArg('@/dev/null/', '@', 'dev/null')
    assert process_data_embed_file_contents_arg(file_arg) == ''

# Generated at 2022-06-21 13:32:45.809283
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    from httpie.cli.argtypes import KeyValueArg
    a = KeyValueArg("key", "value", "key=value")
    assert process_data_item_arg(a) == "value"



# Generated at 2022-06-21 13:33:27.569495
# Unit test for constructor of class RequestItems
def test_RequestItems():
    arg1 = KeyValueArg('SEPARATOR_HEADER', 'name', 'sagar')
    arg2 = KeyValueArg('SEPARATOR_QUERY_PARAM', 'age', '26')
    arg3 = KeyValueArg('SEPARATOR_DATA_STRING', 'city', 'Pune')
    assert RequestItems.from_args([arg1, arg2, arg3]).headers == {'name': 'sagar'}
    assert RequestItems.from_args([arg1, arg2, arg3]).params == {'age': '26'}
    assert RequestItems.from_args([arg1, arg2, arg3]).data == {'city': 'Pune'}


# Generated at 2022-06-21 13:33:34.909990
# Unit test for function load_json
def test_load_json():
    from httpie.cli.argtypes import Unicode
    json = Unicode(value='{ "a": "b" }')
    list = load_json(None, json)
    assert list == {"a": "b"}
    json = Unicode(value='{ "a": "b", "1": "2" }')
    list = load_json(None, json)
    assert list == {"a": "b", "1": "2"}
    json = Unicode(value="{ 'a': 'b' }")
    list = load_json(None, json)
    assert list == {"a": "b"}

# Generated at 2022-06-21 13:33:43.348519
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    f = open("C:\\Users\\user\\Desktop\\TestFolderEmpty\\pdftest.txt", 'rb')
    name = os.path.basename("C:\\Users\\user\\Desktop\\TestFolderEmpty\\pdftest.txt")
    print(SEPARATOR_FILE_UPLOAD + name + ';')
    value = SEPARATOR_FILE_UPLOAD + name + ';'
    arg = KeyValueArg('', '', '', value)
    print(process_file_upload_arg(arg))
    f.close()

# Generated at 2022-06-21 13:33:49.324908
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestFilesDict
    args =[]
    args.append(KeyValueArg('FILE@','/home/naren/Desktop/3.jpg'))
    args.append(KeyValueArg('FILE@','/home/naren/Desktop/2.jpg',':'))
    request=RequestItems()
    rules: Dict[str, Tuple[Callable, dict]] = {
            SEPARATOR_FILE_UPLOAD: (
                process_file_upload_arg,
                request.files,
            )
        }
    for arg in args:
        processor_func, target_dict = rules[arg.sep]
        value = processor_func(arg)
        target_dict[arg.key] = value

# Generated at 2022-06-21 13:33:52.299289
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg('http://localhost:9200', 'POST', ';', 'data', '{"name": "James"}')
    value = load_json(arg, arg.value)
    # AssertionError: assert None != {"name": "James"}
    assert value != None

# Generated at 2022-06-21 13:33:56.298384
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('style=ubuntu', 'style', '=', 'style', 'ubuntu')
    assert process_query_param_arg(arg) == 'ubuntu'

# Generated at 2022-06-21 13:34:05.715180
# Unit test for function load_json
def test_load_json():
  """Unit test for function load_json(arg: KeyValueArg, contents: str) -> JSONType
  """
  from httpie.cli.argtypes import KeyValueArg
  from pprint import pprint
  arg = KeyValueArg("foo", "bar")
  content = """{"bar":"baz","foo":123.456,"test":true}"""
  expected = {"foo": 123.456, "bar": "baz", "test": True}
  output = load_json(arg, content)
  if output != expected:
    print("Error in load_json(%s, %s)" % (arg, content))
    print("Expected:")
    pprint(expected)
    print("Actual:")
    pprint(output)
  else:
    print("Test passed successfully")

# Generated at 2022-06-21 13:34:11.856504
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.argtypes import KeyValueArg
    from utils import get_httpbin_url
    arg = KeyValueArg("json_value")
    arg.key = "json_value"
    arg.orig = "json_value=1"
    arg.sep = ":"
    arg.value = "1"
    process_data_raw_json_embed_arg(arg)



# Generated at 2022-06-21 13:34:13.990165
# Unit test for function process_header_arg
def test_process_header_arg():
    h = process_header_arg(KeyValueArg(orig='a:1', key='a', sep=':', value='1'))
    assert h=='1'



# Generated at 2022-06-21 13:34:23.716859
# Unit test for constructor of class RequestItems
def test_RequestItems():
    headers_dict = RequestHeadersDict()
    data_dict = MultipartRequestDataDict()
    files_dict = RequestFilesDict()
    params_dict = RequestQueryParamsDict()
    headers_dict["Content-Type"] = "application/json"
    data_dict["data"] = 1
    params_dict["pram1"] = 1

# Generated at 2022-06-21 13:35:45.334180
# Unit test for function process_header_arg
def test_process_header_arg():
    # test for an empty header name
    try:
        process_header_arg(KeyValueArg('', ';', 'value'))
    except ParseError as e:
        assert str(e) == "Invalid header name ''"
    # test for header with no value
    assert process_header_arg(KeyValueArg('Header-Name', ':', '')) is None
    # test for header with no value, but end with colon
    assert process_header_arg(KeyValueArg('Header-Name:', ':', '')) is None
    # test for header with no name
    try:
        process_header_arg(KeyValueArg('', '', 'value'))
    except ParseError as e:
        assert str(e) == 'Invalid header name ""'
    # test for header with no name, but end with colon

# Generated at 2022-06-21 13:35:49.428319
# Unit test for function load_text_file
def test_load_text_file():
    file_path = "./file/file.txt"
    with open(file_path) as f:
        file_content = f.read()
    result = load_text_file(KeyValueArg('./file/file.txt'))
    assert result == file_content


# Generated at 2022-06-21 13:35:52.920543
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    with pytest.raises(ParseError):
        process_empty_header_arg(KeyValueArg(key=None, value=None, sep=None, orig=None))
    assert process_empty_header_arg(KeyValueArg(key=None, value="", sep=None, orig=None)) == ""

# Generated at 2022-06-21 13:35:54.742616
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
	assert process_query_param_arg(KeyValueArg(None, 'key', 'value', SEPARATOR_QUERY_PARAM)) == 'value'


# Generated at 2022-06-21 13:35:58.214076
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(separator=";;;;", key="C:/Users/anran/Desktop/test_a.txt",
                       value="C:/Users/anran/Desktop/test_a.txt")
    assert load_text_file(item) == "\n"

# Generated at 2022-06-21 13:36:03.361665
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    key = "foo"
    value = "bar"
    key_value_arg = KeyValueArg('-d', key, value, '=', None)
    value_json = process_data_raw_json_embed_arg(key_value_arg)
    assert value_json == value
    assert type(value_json) == str

# Generated at 2022-06-21 13:36:12.366288
# Unit test for function load_text_file
def test_load_text_file():
    #path = "/home/jwk/Downloads/httpie-1.0.1/COPYING"
    path = "./data/COPYING" # NOTE: relative path to this file
    item = KeyValueArg(key="", sep=SEPARATOR_HEADER, value=path, orig=path) 
    text = load_text_file(item)
    print("File: '{0}' read as below:\n{1}".format(path, text))
    print("File length: {0}".format(len(text)))
    print("Type of text: {0}".format(type(text)))
    print("Contents of text: {0}".format(repr(text)))

    assert len(text) > 1000
    assert isinstance(text, str)


# Generated at 2022-06-21 13:36:21.186859
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    import os
    import sys
    import httpie.cli
    from httpie.cli import RequestItems
    from httpie.cli.argtypes import KeyValueArg

    with open('filename', 'w') as f:
        #  {"key1": "value1", "key2": "value2", }
        f.write('{"key1": "value1", "key2": "value2", }')

    arg = KeyValueArg('key1&@filename', 'key1', '@filename', '')
    assert process_data_embed_raw_json_file_arg(arg) == {
        'key1': {
            'key1': 'value1',
            'key2': 'value2',
        }
    }
    os.remove('filename')



# Generated at 2022-06-21 13:36:23.490423
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    kva = KeyValueArg('name', 'value', ';')
    assert process_data_item_arg(kva) == 'value'



# Generated at 2022-06-21 13:36:26.712171
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key='', orig='', value=None
    )

    assert process_data_embed_file_contents_arg(arg) == ''


# Generated at 2022-06-21 13:39:01.108533
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    param_string = "key=value"
    param_key_value_arg = KeyValueArg(SEPARATOR_QUERY_PARAM, param_string)
    assert process_query_param_arg(param_key_value_arg) == param_string



# Generated at 2022-06-21 13:39:03.433103
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('key', 'value', separator='key')
    process_header_arg(arg) == arg.value


# Generated at 2022-06-21 13:39:10.493415
# Unit test for constructor of class RequestItems
def test_RequestItems():
    response = RequestItems()
    print(type(response))
    print(type(response.multipart_data))
    print(type(response.data))
    print(type(response.files))
    print(type(response.params))
    print(type(response.headers))
    print(type(response.data)=={})
    print(type(response.files)=={})
    print(type(response.params)=={})
    print(type(response.headers)=={})
    print(type(response.multipart_data)=={})



# Generated at 2022-06-21 13:39:13.362913
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    raw_json_embed_arg = KeyValueArg('raw_json_embed_arg', 'param;/tmp/httpie_test.json')
    assert process_data_embed_raw_json_file_arg(raw_json_embed_arg) == {"name": "test_json"}

# Generated at 2022-06-21 13:39:16.421368
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.dicts import RequestJSONDataDict
    from httpie.cli.parser import KeyValueArg

    arg = KeyValueArg("json", "key", "--json@file.json")
    json = process_data_embed_raw_json_file_arg(arg)
    assert isinstance(json, dict)
    assert len(json) == 2
    assert json["key"] == "value"

# Generated at 2022-06-21 13:39:20.789955
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(item='name=ruiyuan', raw=None, orig='name=ruiyuan', key='name', sep='=', value='ruiyuan')
    assert process_query_param_arg(arg) == 'ruiyuan'


if __name__ == '__main__':
    test_process_query_param_arg()
    print('Test passed!')

# Generated at 2022-06-21 13:39:22.885296
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(key='', sep='', value='2')
    output = process_data_embed_file_contents_arg(arg)
    expected_output = '2'
    assert output == expected_output
