

# Generated at 2022-06-21 13:29:41.542329
# Unit test for function load_json
def test_load_json():
    load_json('', '[1,2,3]')

# Generated at 2022-06-21 13:29:46.555431
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Test constructor of class
    assert RequestItems.from_args(request_item_args=[KeyValueArg(
                key='', sep='', value='', orig='')])

    # Test constructor of class with form
    assert RequestItems.from_args(request_item_args=[KeyValueArg(
        key='', sep='', value='', orig='')], as_form=True)



# Generated at 2022-06-21 13:29:51.366408
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(None, 'key', '{}')) == {}
    assert process_data_raw_json_embed_arg(KeyValueArg(None, 'key', '{"a":1}')) == {"a": 1}



# Generated at 2022-06-21 13:29:53.448795
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    (key, value) = process_query_param_arg(('a', 'b'))
    assert key == 'a'
    assert value == 'b'

# Generated at 2022-06-21 13:30:00.979583
# Unit test for function load_json
def test_load_json():
    assert load_json('', '{ "A":"B" }') == { "A": "B" }
    assert load_json('', '{"A":"B"}') == { "A": "B" }
    assert load_json('', '{"A": "B"}') == { "A": "B" }
    assert load_json('', '{"A":"B", "C": "D"}') == { "A": "B", "C": "D" }
    assert load_json('', '{"A": "B", "C": "D"}') == { "A": "B", "C": "D" }
    assert load_json('', '{"A": "B","C": "D"}') == { "A": "B", "C": "D" }

# Generated at 2022-06-21 13:30:04.342774
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    args = KeyValueArg(sep=';', orig='header;', key='header', value=None)
    res = process_empty_header_arg(args)
    print(res)

# Generated at 2022-06-21 13:30:07.235607
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('foo', 'bar', 'baz')
    assert (None, None, None) == process_file_upload_arg(arg)

# Generated at 2022-06-21 13:30:12.473885
# Unit test for constructor of class RequestItems
def test_RequestItems():
    expected_response_data = {'key1': 'value1', 'key2': 'value2'}
    expected_response_params = {'query1': 'value1', 'query2': 'value2'}
    expected_response_headers = {'header1': 'value1', 'header2': 'value2'}
    expected_response_files = {'file1': 'value1', 'file2': 'value2'}
    expected_response_multipart = {'mp1': 'value1', 'mp2': 'value2'}
    instance = RequestItems()
    instance.data['key1'] = 'value1'
    instance.data['key2'] = 'value2'
    instance.params['query1'] = 'value1'
    instance.params['query2'] = 'value2'
    instance.headers

# Generated at 2022-06-21 13:30:15.450672
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test_item = KeyValueArg(key='content', value='{"app_secret":"123456", "location":"SG", "notification_on":"1"}', sep='==')
    assert process_query_param_arg(test_item) == '{"app_secret":"123456", "location":"SG", "notification_on":"1"}'

# Generated at 2022-06-21 13:30:19.032757
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(None, None, None, None, None, None, None)
    item.value = "./test_meta.py"
    contents = load_text_file(item)
    print(contents)



# Generated at 2022-06-21 13:30:31.138095
# Unit test for function load_text_file
def test_load_text_file():
    from httpie.cli.constants import SEPARATOR_DATA_EMBED_FILE_CONTENTS
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli import request_items
    from typing import Dict
    from io import BytesIO

    # Create dict that maps the argument to the expected output.

# Generated at 2022-06-21 13:30:38.994339
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # file_path contains dict
    file_path = '/Users/jinsungpark/Documents/httpie/test_data.json'
    contents = load_text_file(file_path)
    value = load_json(file_path, contents)
    assert isinstance(value, dict)
    print('value: ', value)
    assert all(key in value for key in ('id', 'name', 'email', 'username'))
    
    

# Generated at 2022-06-21 13:30:46.565514
# Unit test for function load_json
def test_load_json():
    url = 'https://httpbin.org/anything'
    input_json = {"foo": "bar"}
    expected_result = json.loads(json.dumps(input_json, sort_keys=True))
    json_bytes = json.dumps(input_json).encode('utf-8')
    
    with mock.patch('httpie.cli.request.load_json_preserve_order', return_value=expected_result):
        assert load_json(url, json_bytes) == expected_result


# Generated at 2022-06-21 13:30:51.230771
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    input = 'filename.txt;text/plain'
    output = process_file_upload_arg(KeyValueArg(input))
    # print(output)
    assert output[0] == 'filename.txt'
    assert output[2] == 'text/plain'

    input = 'filename.txt'
    output = process_file_upload_arg(KeyValueArg(input))
    # print(output)
    assert output[0] == 'filename.txt'
    assert output[2] == 'text/plain'

test_process_file_upload_arg()

# Generated at 2022-06-21 13:30:55.856567
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test 1: Raise exception if json string is invalid and not empty
    try:
        process_data_raw_json_embed_arg(KeyValueArg(
            'key', 'data', '', 'value', SEPARATOR_DATA_RAW_JSON, 'value'
        ))
    except ParseError:
        pass

    # Test 2: Return None if json string is empty
    ret = process_data_raw_json_embed_arg(KeyValueArg(
        'key', 'data', '', '', SEPARATOR_DATA_RAW_JSON, 'value'
    ))
    assert ret is None

    # Test 3: Return json object if json string is valid

# Generated at 2022-06-21 13:30:58.857715
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Test 1
    assert RequestItems() is not None
    # Test 2
    assert RequestItems(as_form=False) is not None
    # Test 3
    assert RequestItems.from_args(request_item_args=None, as_form=False) is not None
    assert RequestItems.from_args(request_item_args=[], as_form=False) is not None
    assert RequestItems.from_args(request_item_args=['a', 'b', 'c'], as_form=False) is not None

# Generated at 2022-06-21 13:31:10.334702
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert type(RequestItems(True).multipart_data) == MultipartRequestDataDict
    assert type(RequestItems().multipart_data) == MultipartRequestDataDict
    assert type(RequestItems(True).files) == RequestFilesDict
    assert type(RequestItems().files) == RequestFilesDict
    assert type(RequestItems(True).params) == RequestQueryParamsDict
    assert type(RequestItems().params) == RequestQueryParamsDict
    assert type(RequestItems(True).data) == RequestDataDict
    assert type(RequestItems().data) == RequestJSONDataDict
    assert type(RequestItems(True).headers) == RequestHeadersDict
    assert type(RequestItems().headers) == RequestHeadersDict



# Generated at 2022-06-21 13:31:21.170821
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-21 13:31:21.700319
# Unit test for constructor of class RequestItems
def test_RequestItems():
    pass

# Generated at 2022-06-21 13:31:31.627412
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        key='foo',
        value='C:\\Users\\Administrator\\AppData\\Local\\Temp\\2'
              '\\tmp3lg00_su\\requests\\certs\\0_www.baidu.com.pem',
        sep='@@',
        orig='@@C:\\Users\\Administrator\\AppData\\Local\\Temp\\2'
             '\\tmp3lg00_su\\requests\\certs\\0_www.baidu.com.pem',
    )

    value = process_data_embed_file_contents_arg(arg)
    print(value)


# Generated at 2022-06-21 13:31:43.892918
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    keywords = [
        '-d',
        '@/Users/jagrati/Downloads/my_file.json',
    ]
    request_item_args = [KeyValueArg(keywords, i) for i, keyword in enumerate(keywords)]
    request = RequestItems.from_args(request_item_args)
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(request.data)

# Generated at 2022-06-21 13:31:49.521759
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg('data', 'data:')
    jsonObj = load_json(arg, '{"data": "1"}')
    assert jsonObj['data'] == '1'
    jsonObj = load_json(arg, '[{"data": "1"}]')
    assert jsonObj[0]['data'] == '1'

# Generated at 2022-06-21 13:31:53.675258
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    x = KeyValueArg(key='', value = '', sep = SEPARATOR_HEADER_EMPTY)
    y = process_empty_header_arg(x)
    return y


if __name__ == '__main__':
    print(test_process_empty_header_arg())

# Generated at 2022-06-21 13:31:55.315720
# Unit test for constructor of class RequestItems
def test_RequestItems():
    a = RequestItems()
    assert type(a) == RequestItems
    assert type(a.headers) == RequestHeadersDict
    assert type(a.data) == RequestJSONDataDict

# Generated at 2022-06-21 13:31:56.617419
# Unit test for function load_text_file
def test_load_text_file():
    with pytest.raises(ParseError):
        load_text_file(KeyValueArg("-d '","'"))


# Generated at 2022-06-21 13:32:01.959966
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    expected = ('test.json', open('test.json','rb'), 'application/json')
    actual = process_file_upload_arg(KeyValueArg('', SEPARATOR_FILE_UPLOAD, 'test.json', 'application/json'))
    assert expected == actual

# Generated at 2022-06-21 13:32:12.762375
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    parser = argparse.ArgumentParser(prog='http')
    parser.add_argument('foo', action='store_true')
    parser.add_argument('-b')
    parser.add_argument('-j')
    parser.add_argument('-H')
    parser.add_argument('-a')
    args = parser.parse_args(['-H', 'Authorization: token TOKEN'])
    args_dict = vars(args)

    assert process_data_item_arg(KeyValueArg.from_parts('-H', 'Authorization: token TOKEN', args_dict)) == 'Authorization: token TOKEN'
    assert process_data_item_arg(KeyValueArg.from_parts('-a', 'token TOKEN', args_dict)) == 'token TOKEN'



# Generated at 2022-06-21 13:32:16.947854
# Unit test for function load_text_file
def test_load_text_file():
    assert "contents" == load_text_file(KeyValueArg("key", "contents", "="))
    assert "contents2" == load_text_file(KeyValueArg("key", "contents2", "="))

# Generated at 2022-06-21 13:32:21.249680
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg('Authorization', 'abc'))
        assert False
    except ParseError as pe:
        assert pe.args[0] == 'Invalid item "Authorization:abc" (to specify an empty header use `Header;`)'

# Generated at 2022-06-21 13:32:25.287010
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    qparamArg = KeyValueArg('qparam', '1', None, None, None)
    assert process_query_param_arg(qparamArg) == '1'



# Generated at 2022-06-21 13:32:44.741856
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    '''test_process_file_upload_arg'''
    from httpie.cli.constants import SEPARATOR_FILE_UPLOAD_TYPE
    from httpie.cli.argtypes import KeyValueArg
    from os.path import expanduser
    from httpie import get_content_type
    from httpie.utils import (get_content_type)
    from typing import Tuple, IO
    from pytest import raises
    from httpie.cli.exceptions import ParseError

    processor_func = process_file_upload_arg
    mime_type = get_content_type
    #path = expanduser

# Generated at 2022-06-21 13:32:48.023439
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # test with empty content
    # process_data_embed_raw_json_file_arg(arg)
    arg = "test;test.json"
    KeyValueArg(SEPARATOR_HEADER, arg.split(";")[0], arg.split(";")[1], arg)



# Generated at 2022-06-21 13:32:50.741772
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(key='X', value=None, orig="X")) is None
    assert process_header_arg(KeyValueArg(key='X', value='1', orig="X:1")) == '1'


# Generated at 2022-06-21 13:33:00.424115
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # json_str = '{"temp_json":"test_json"}'
    # path = '/Users/huangzixi/Downloads/test.json'
    path = 'bmx_data_caculate.json'
    with open(os.path.expanduser(path), 'r') as f:
        json_str = json.load(f)
        print(json_str)
    print(process_data_embed_raw_json_file_arg(path))
    return None


if __name__ == '__main__':
    test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-21 13:33:04.429751
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('key=val')
    assert process_data_item_arg(arg) == 'val'
    msg = 'Invalid item "key=val". Value should not be empty'
    try: 
         process_data_item_arg(arg)
    except ParseError as e:
         print(e)

# Generated at 2022-06-21 13:33:06.303749
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_header_arg(arg) == arg.value


# Generated at 2022-06-21 13:33:13.282286
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg
    s = "declared_url=%E4%BD%A0%E8%A6%81%E4%BB%80%E4%B9%88%3F%20%E9%9C%80%E8%A6%81%E4%BB%80%E4%B9%88%3F%20%E8%BF%99%E7%A7%8D%E8%A6%81%E6%B1%82%E5%B0%B1%E6%98%AF%E5%A6%82%E6%AD%A2%3F"
    arg = KeyValueArg(None, None, None, s)
    ret = process_query_param_arg(arg)

# Generated at 2022-06-21 13:33:24.782651
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    """
    Case 1: Test function process_query_param_arg with normal input
    Expected result: "http://httpbin.org/get?q=11"
    """
    # arrange
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import SEPARATOR_QUERY_PARAM
    expected = "http://httpbin.org/get?q=11"
    request_item_args = [KeyValueArg(SEPARATOR_QUERY_PARAM, 'q', '11', None)]
    # action
    instance = RequestItems.from_args(request_item_args)
    # assert
    assert instance.params == {"q": "11"}


# Generated at 2022-06-21 13:33:26.567856
# Unit test for function load_text_file
def test_load_text_file():
    test_item_arg = KeyValueArg('key', 'value')
    assert load_text_file(test_item_arg) == 'value'

# Generated at 2022-06-21 13:33:36.310698
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    """Test for function process_data_raw_json_embed_arg."""
    test_data = load_json_preserve_order('{"test":"test"}')
    test_request_items = RequestItems()
    test_target_dict = test_request_items.data
    test_arg = KeyValueArg(
                    sep=SEPARATOR_DATA_RAW_JSON,
                    key="test",
                    value=test_data,
                    orig="test",
                )
    print(test_data)
    print(test_arg.value)
    print(test_arg.key)
    test_target_dict[test_arg.key] = process_data_raw_json_embed_arg(test_arg)
    print(test_target_dict[test_arg.key])

test_process_data_raw_json_

# Generated at 2022-06-21 13:33:47.888918
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file('"abc.txt"') == 'abc'

# Generated at 2022-06-21 13:33:49.184719
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    value = load_json_preserve_order("{'a':'b'}")
    return value

# Generated at 2022-06-21 13:33:50.329693
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg("test.txt")) == ("test.txt", 'rb', None)

# Generated at 2022-06-21 13:33:55.388152
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    expected = [
        ('filename.txt', "hello world"),
        ('filename.txt', "hello world"),
        ('filename.txt', "hello world"),
        ("""filename.txt;type=application/json""", "hello world"),
        ("""filename.txt;type=application/json""", "hello world"),
        ("""filename.txt;type=application/json""", ""),
    ]

    for test_filename, test_contents in expected:
        with open('test.txt', 'w') as f:
            f.write(test_contents)
        arg = KeyValueArg('', '', '', '', '', test_filename)
        process_file_upload_result = process_file_upload_arg(arg)
        os.remove('test.txt')

# Generated at 2022-06-21 13:33:58.442059
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    item = KeyValueArg()
    item.value = "123"
    ret = process_data_item_arg(item)
    assert(ret == "123")

# Generated at 2022-06-21 13:34:00.541730
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    process_data_raw_json_embed_arg(KeyValueArg('a=true', 'a', 'true'))


# Generated at 2022-06-21 13:34:03.272376
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = process_data_embed_file_contents_arg(KeyValueArg(key = "data", value = "./test_data.txt", orig = "data:=./test_data.txt", sep = ":"))
    print(arg)
#test_process_data_embed_file_contents_arg()

# Generated at 2022-06-21 13:34:05.427995
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(None, "key", "value")
    assert process_data_raw_json_embed_arg(arg) == arg.value


# Generated at 2022-06-21 13:34:10.669044
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    request_item_args = [KeyValueArg(
        sep = SEPARATOR_QUERY_PARAM,
        key = 'key',
        value = 'value',
        orig = 'key=value'
    )]
    instance = RequestItems()
    rules: Dict[str, Tuple[Callable, dict]] = {
        SEPARATOR_QUERY_PARAM: (
            process_query_param_arg,
            instance.params,
        ),
    }
    for arg in request_item_args:
        processor_func, target_dict = rules[arg.sep]
        value = processor_func(arg)
        target_dict[arg.key] = value
        assert target_dict['key'] == 'value'

# Generated at 2022-06-21 13:34:15.438423
# Unit test for constructor of class RequestItems
def test_RequestItems():
    args = [KeyValueArg('headers', 'Headers', ';', 'headers'), KeyValueArg('data', 'body', '=', 'data')]
    request_items = RequestItems.from_args(args)

    assert request_items.headers['headers'] == ''
    assert request_items.data['data'] == 'data'
    assert request_items.multipart_data['data'] == 'data'



# Generated at 2022-06-21 13:34:40.260181
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test.txt'
    mime_type = 'text/plain'
    f = open(os.path.expanduser(filename), 'rb')
    result = process_file_upload_arg(arg=KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='',
        value='test.txt'
    ))
    assert result == (os.path.basename(filename), f, mime_type or get_content_type(filename))

# Generated at 2022-06-21 13:34:41.500725
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # ToDo
    pass

# Generated at 2022-06-21 13:34:45.236207
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert isinstance(RequestItems().headers, RequestHeadersDict)
    assert isinstance(RequestItems().data, RequestJSONDataDict)
    assert isinstance(RequestItems().files, RequestFilesDict)
    assert isinstance(RequestItems().params, RequestQueryParamsDict)
    assert isinstance(RequestItems().multipart_data, MultipartRequestDataDict)



# Generated at 2022-06-21 13:34:51.742284
# Unit test for function load_json
def test_load_json():
    # normal json file
    assert load_json(0, '{"a":1}') == {"a":1}
    # invalid json file
    try:
        load_json(0, '{"a":1')
        assert False
    except ParseError:
        assert True
    # Empty json
    try:
        load_json(0, '')
        assert False
    except ParseError:
        assert True


# Generated at 2022-06-21 13:34:58.600991
# Unit test for function load_text_file
def test_load_text_file():
    file = "test"
    if os.path.exists(file):
        os.remove(file)

    f = open(file, "w")
    f.write("Test File")
    f.close()

    try:
        load_text_file(KeyValueArg(""))
    except ParseError:
        pass

    try:
        load_text_file(KeyValueArg("", "", "", "", "", "fake"))
    except ParseError:
        pass

    assert load_text_file(KeyValueArg("", "", "", "", "", file)) == "Test File"

    os.remove(file)

# Generated at 2022-06-21 13:35:08.310873
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = './testupload.txt'
    mime_type = 'text/plain'
    arg = KeyValueArg('upload', ':'.join([filename, mime_type]), '-F')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert(filename == 'testupload.txt')
    assert(mime_type == 'text/plain')
    assert(f.read() == b'uppload test content')

    mime_type = None
    arg = KeyValueArg('upload', filename, '-F')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert(filename == 'testupload.txt')
    assert(mime_type == 'text/plain')
    assert(f.read() == b'uppload test content')

# Generated at 2022-06-21 13:35:10.169391
# Unit test for function load_json
def test_load_json():
    assert load_json(None, '{"name": 1}') == {"name": 1}

# Generated at 2022-06-21 13:35:13.173525
# Unit test for function load_text_file
def test_load_text_file():
    data = load_text_file(arg=KeyValueArg(orig='name:kevin', sep=':', key='name', value='kevin'))
    print(data)


# Generated at 2022-06-21 13:35:21.401597
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # test json file is valid
    assert process_data_embed_raw_json_file_arg(KeyValueArg("file", "test.json")) == {"foo": "bar"}
    # test empty file
    try:
        process_data_embed_raw_json_file_arg(KeyValueArg("file", "empty.json"))
        assert False
    except ParseError:
        pass
    # test json file is not valid
    try:
        process_data_embed_raw_json_file_arg(KeyValueArg("file", "invalid.json"))
        assert False
    except ParseError:
        pass
    # test file is not json file

# Generated at 2022-06-21 13:35:30.478851
# Unit test for function load_json
def test_load_json():
    j = load_json(KeyValueArg('test'), '{"test": 1}')
    assert isinstance(j, dict)
    assert j == {"test": 1}

    # Test JSON with arrays
    j = load_json(KeyValueArg('test'), '{"test": [1,2,3]}')
    assert isinstance(j, dict)
    assert isinstance(j["test"], list)
    assert j == {"test": [1, 2, 3]}

    # Test empty JSON
    j = load_json(KeyValueArg('test'), '{}')
    assert isinstance(j, dict)
    assert j == {}

    # Test sorting of JSON
    j = load_json(KeyValueArg('test'), '{"b":2,"a":1,"c":3}')
    assert isinstance(j, dict)

# Generated at 2022-06-21 13:36:03.915882
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg("testKey=testValue", "=")
    value = process_data_item_arg(arg)
    assert value == "testValue"

# Generated at 2022-06-21 13:36:09.685751
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    print('testing function process_file_upload_arg()...')
    arg = KeyValueArg('filename.json;json', SEPARATOR_FILE_UPLOAD)
    filename, file_handle, mime_type = process_file_upload_arg(arg)
    print('filename = %s, mime_type = %s' % (filename, mime_type))
    assert filename == 'filename.json'
    assert mime_type == 'json'



# Generated at 2022-06-21 13:36:12.778775
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(
        key=None,
        value='value',
        sep=SEPARATOR_QUERY_PARAM,
        orig='value',
    )
    value = process_query_param_arg(arg)
    assert value == 'value'

# Generated at 2022-06-21 13:36:22.088222
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg1 = KeyValueArg(key='', sep=SEPARATOR_HEADER_EMPTY, value='')
    arg2 = KeyValueArg(key='', sep=SEPARATOR_HEADER_EMPTY, value=None)
    arg3 = KeyValueArg(key='Accept-Encoding', sep=SEPARATOR_HEADER_EMPTY, value='utf-8, *')
    arg4 = KeyValueArg(key='', sep=SEPARATOR_HEADER_EMPTY, value=1)
    arg5 = KeyValueArg(key='', sep=SEPARATOR_HEADER_EMPTY, value=True)
    assert process_empty_header_arg(arg1) == ''
    assert process_empty_header_arg(arg2) == ''
    with pytest.raises(ParseError) as excinfo:
        process

# Generated at 2022-06-21 13:36:25.874486
# Unit test for function load_json
def test_load_json():
    contents = '''
    {
      "numbers": [
        1,
        2
      ],
      "string": "foo bar baz"
    }
    '''
    assert load_json(arg, contents) == {"numbers": [1,2], "string": "foo bar baz"}

# Generated at 2022-06-21 13:36:34.034956
# Unit test for function load_json
def test_load_json():
    import json
    value = {"name": "jerry", "age": 30, "is_admin": True,
             "hobby": ["jogging", "reading", "swimming"],
             "friends": {"tom": {"age": 25, "is_admin": False,
                                 "hobby": ["football", "basketball"]},
                         "jack": {"age": 30, "is_admin": True,
                                  "hobby": ["jogging", "reading"]}}}
    json_str = json.dumps(value)
    result = load_json(KeyValueArg('','=json_str'), json_str)
    assert value == result



# Generated at 2022-06-21 13:36:36.548194
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    json_data = process_data_item_arg(KeyValueArg("data","{\"a\":\"b\"}"))
    assert json_data == "{\"a\":\"b\"}"


# Generated at 2022-06-21 13:36:38.908767
# Unit test for function load_text_file
def test_load_text_file():
    contents = load_text_file("/Users/mao/Desktop/tutorial/httpie/httpie-0.11.1/httpie/cli/argtypes.py")
    print(contents)

# Generated at 2022-06-21 13:36:42.331093
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('abc;', 'abc')) == ''
    try:
        process_empty_header_arg(KeyValueArg('abc;bcd', 'abc'))
        assert False, 'Should throw exception because of value'
    except ParseError:
        pass

# Generated at 2022-06-21 13:36:45.617177
# Unit test for constructor of class RequestItems
def test_RequestItems():
    k = RequestItems()
    assert k.headers == {}
    assert k.data == {}
    assert k.files == {}
    assert k.params == {}
    assert k.multipart_data == {}


# Generated at 2022-06-21 13:38:25.595591
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg('h', 'a', 'b')
    assert process_header_arg(header_arg) == 'b'
    header_arg = KeyValueArg('h', 'a', None)
    assert process_header_arg(header_arg) is None



# Generated at 2022-06-21 13:38:29.705856
# Unit test for constructor of class RequestItems
def test_RequestItems():
    as_form = True
    request_item_args = ['a=2', 'b=3', 'c=4']
    request_instance = RequestItems.from_args(request_item_args, as_form)
    assert request_instance.data.a == 2


# Generated at 2022-06-21 13:38:34.303309
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = {'key': 'jak', 'value': '{"a":"b","c":["d",4]}', 'orig': 'jak: "{\\"a\\":\\"b\\",\\"c\\":[\\"d\\",4]}"'}
    x=process_data_raw_json_embed_arg(arg)
    print(x)
    assert x == {'a': 'b', 'c': ['d', 4]}



# Generated at 2022-06-21 13:38:36.332289
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg("name:smith")
    assert(process_header_arg(arg) == "smith")


# Generated at 2022-06-21 13:38:46.381680
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg="tests/requests/file_upload.json:json"
    handle = open(file_upload_arg, 'r')
    # Get the file name and the file type fron the text file
    file_upload_arg = handle.readline().rstrip()
    file_type = handle.readline().rstrip()
    # Get the file name and the file type from "file_upload_arg"
    parts = file_upload_arg.split(":")
    file_name = parts[0]
    mime_type = parts[1] if len(parts) > 1 else None
    # open the file

# Generated at 2022-06-21 13:38:49.788768
# Unit test for function load_json
def test_load_json():
    json_content = """{
    "id": 1,
    "name": "John"}
    """
    assert load_json(
        "", json_content) == {"id": 1, "name": "John"}

# Generated at 2022-06-21 13:38:55.877209
# Unit test for constructor of class RequestItems
def test_RequestItems():
    args = [KeyValueArg(key="Content-Type",value= "application/json",sep=":"),KeyValueArg(key= "X-Client-ID",value="3",sep=":"),KeyValueArg(key="limit", value="1", sep="="),KeyValueArg(key="limit", value="2", sep="=")]
    request_items = RequestItems.from_args(args)
    
    return request_items.headers,request_items.data,request_items.params,request_items.multipart_data



# Generated at 2022-06-21 13:38:59.816051
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert RequestItems(as_form=False).data.__class__.__name__ == 'RequestJSONDataDict'
    assert RequestItems(as_form=True).data.__class__.__name__ == 'RequestDataDict'

# Generated at 2022-06-21 13:39:01.932326
# Unit test for function load_text_file
def test_load_text_file():
    assert(len(load_text_file("/Users/mymac/Documents/Tasks/task1.txt").split("\n"))==3)

# Generated at 2022-06-21 13:39:05.603362
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file("")
    except ParseError as e:
        assert 1

if __name__ == '__main__':
    test_load_text_file()