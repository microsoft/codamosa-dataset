

# Generated at 2022-06-21 13:29:37.534836
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('', '', '')) == ''
    assert process_empty_header_arg(KeyValueArg('', '', 'abc')) == ''
    assert process_empty_header_arg(KeyValueArg('', '', ';')) == ''



# Generated at 2022-06-21 13:29:41.348243
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
  item = KeyValueArg('key', 'value')
  assert process_data_item_arg(item) == 'value'

# Generated at 2022-06-21 13:29:51.685268
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    request_item_args = [
        KeyValueArg("foo", "bar"),
        KeyValueArg("bool", "true"),
        KeyValueArg("int", "1"),
        KeyValueArg("float", "1.1"),
        KeyValueArg("list", "1,2,3"),
        KeyValueArg("dict", "foo:bar,baz:qux"),
    ]

    args = RequestItems.from_args(request_item_args)
    assert args.data['foo'] == 'bar'
    assert args.data['bool'] == 'True'
    assert args.data['int'] == '1'
    assert args.data['float'] == '1.1'
    assert args.data['list'] == '1,2,3'

# Generated at 2022-06-21 13:29:54.853484
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg1 = KeyValueArg(key='user', sep=SEPARATOR_QUERY_PARAM, value='1')
    assert process_query_param_arg(arg1) == '1'

from unittest import main



# Generated at 2022-06-21 13:29:59.127739
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    a = KeyValueArg('key', SEPARATOR_HEADER_EMPTY, 'val')
    b = KeyValueArg('key', SEPARATOR_HEADER_EMPTY, '')
    c = KeyValueArg('key', SEPARATOR_HEADER_EMPTY, 'value')
    try:
        process_empty_header_arg(a)
        assert False
    except ParseError as e:
        assert True

# Generated at 2022-06-21 13:30:01.189460
# Unit test for function load_text_file
def test_load_text_file():
  assert load_text_file(KeyValueArg('', '', 'hello')) == 'hello'

# Generated at 2022-06-21 13:30:10.457439
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    raw_data = "key1: value1, key2: value2"
    item = KeyValueArg(raw_data, ':', 'raw')
    try:
        assert process_data_raw_json_embed_arg(item) == {"key1": "value1", "key2": "value2"}
    except ParseError:
        pass
    try:
        raw_data = "key1: value1, key2: value2 key3: value3"
        item = KeyValueArg(raw_data, ':', 'raw')
        process_data_raw_json_embed_arg(item) == {"key1": "value1", "key2": "value2", "key3": "value3"}
    except ParseError:
        pass

# Generated at 2022-06-21 13:30:11.668745
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('-d', 'test_key', 'test_value')
    assert process_data_item_arg(arg) == "test_value"

# Generated at 2022-06-21 13:30:18.144513
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import SEPARATOR_FILE_UPLOAD
    from httpie.cli.constants import SEPARATOR_HEADER
    from httpie.cli.constants import SEPARATOR_QUERY_PARAM
    from httpie.cli.dicts import RequestJSONDataDict
    # Constructor of class RequestItems
    # __init__(self, as_form=False):

    items = RequestItems()
    items = RequestItems(as_form=True)
    # @classmethod from_args(cls, request_item_args: List[KeyValueArg],
    # as_form=False) -> 'RequestItems':

# Generated at 2022-06-21 13:30:26.145033
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'C:/work/httpie/httpie/cli/__init__.py'
    real_mime_type = 'text/x-python'
    embed_filename = 'httpie/cli/__init__.py'
    embed_mime_type = 'text/x-python'

    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, 'foo', filename)
    arg_embed = KeyValueArg(SEPARATOR_FILE_UPLOAD, 'bar', embed_filename)
    arg_embed_type = KeyValueArg(SEPARATOR_FILE_UPLOAD, 'bar', filename + SEPARATOR_FILE_UPLOAD_TYPE + 'text/plain')


# Generated at 2022-06-21 13:30:38.471966
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a.txt')) == 'a'
    assert load_text_file(KeyValueArg(':a.txt')) == 'a'
    assert load_text_file(KeyValueArg(':a.txt:')) == 'a'

# Generated at 2022-06-21 13:30:41.926742
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(
        'data',
        'value',
        SEPARATOR_DATA_STRING,
    )
    assert(process_data_item_arg(arg) == 'value')


# Generated at 2022-06-21 13:30:47.451230
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key = "file"
    value = "data.json"
    arg = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, key, value)
    data = process_data_embed_file_contents_arg(arg)
    assert data == "{\"name\": \"John\", \"age\": 30, \"car\": null}"
    assert data == load_text_file(arg)



# Generated at 2022-06-21 13:30:49.596115
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(';', 'key', 'value')
    caught = False
    try:
        process_empty_header_arg(arg)
    except ParseError:
        caught = True
    assert caught

# Generated at 2022-06-21 13:30:54.478116
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_file = "test.txt"
    with open(test_file, 'w') as f:
        f.write("test")
    arg = KeyValueArg(value='test.txt', key='foo', sep="=", orig=None)
    print(process_data_embed_file_contents_arg(arg))


# Generated at 2022-06-21 13:31:01.682966
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    raw_json_string = '{"name":"jason", "age":"24"}'
    kv_arg = KeyValueArg(raw_json_string, SEPARATOR_DATA_RAW_JSON, orig=raw_json_string)
    actual_result = process_data_raw_json_embed_arg(kv_arg)
    expected_result = {"name":"jason", "age":"24"}
    assert actual_result == expected_result


# Generated at 2022-06-21 13:31:06.509041
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg(key='', value='', sep=':')) == ''
    assert process_data_item_arg(KeyValueArg(key='', value='hola', sep=':')) == 'hola'



# Generated at 2022-06-21 13:31:10.533704
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(key=None, sep=None, orig=None, value="{'a': 'b'}")
    contents = "{'a': 'b'}"
    value = load_json(arg, contents)
    assert value == {'a': 'b'}

# Generated at 2022-06-21 13:31:14.230001
# Unit test for constructor of class RequestItems
def test_RequestItems():
    headers = RequestHeadersDict()
    data = RequestJSONDataDict()
    files = RequestFilesDict()
    params = RequestQueryParamsDict()
    multipart_data = MultipartRequestDataDict()

    assert headers
    assert data
    assert files
    assert params
    assert multipart_data

# Generated at 2022-06-21 13:31:19.567927
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import io
    my_file = io.BytesIO(b"contents")
    expected = ('filename', my_file, "image/jpeg")
    my_arg = KeyValueArg('file', 'filename')
    assert process_file_upload_arg(my_arg) == expected



# Generated at 2022-06-21 13:31:36.289383
# Unit test for function process_header_arg

# Generated at 2022-06-21 13:31:47.353901
# Unit test for function process_header_arg
def test_process_header_arg():
    from httpie.cli.argtypes import KeyValueArg

    user_agent_header = KeyValueArg('user-agent', 'httpie python')
    accept_json_header = KeyValueArg('accept', 'application/json')
    accept_header = KeyValueArg('accept', '')
    cookie_header = KeyValueArg('cookie', 'test=test_value')

    assert process_header_arg(user_agent_header) == 'httpie python'
    assert process_header_arg(accept_json_header) == 'application/json'
    assert process_header_arg(accept_header) == ''
    assert process_header_arg(cookie_header) == 'test=test_value'

# Generated at 2022-06-21 13:31:57.523288
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import argparse

    arg = argparse.Namespace(orig='', sep='=', key='__test__', value='{"test":12,"test2":{"subtest1":12,"subtest2":[13,14,15]}}')
    value = process_data_raw_json_embed_arg(arg)
    assert value == {"test":12,"test2":{"subtest1":12,"subtest2":[13,14,15]}}

    arg = argparse.Namespace(orig='', sep='=', key='__test__', value='{"test":12,"test2":{"subtest1":12,"subtest2":[13,14,15,}]}')
    try:
        process_data_raw_json_embed_arg(arg)
    except ParseError as e:
        assert 'Expecting property name' in str(e)



# Generated at 2022-06-21 13:32:02.170797
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(key="aaa", value="{aaa:1}", sep=SEPARATOR_DATA_RAW_JSON)) == {'aaa':1}


# Generated at 2022-06-21 13:32:07.858025
# Unit test for function process_header_arg
def test_process_header_arg():
    # valid input
    output = process_header_arg(KeyValueArg(key='', value='', sep=''))
    assert output == None
    # invalid input
    try:
        process_header_arg(KeyValueArg(key='', value='', sep='a'))
    except ParseError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 13:32:12.699454
# Unit test for function load_json
def test_load_json():
    # This function should return an ordered dictionary
    # load_json_preserve_order() always return an ordered dictionary
    # test_load_json tests both load_json() and load_json_preserve_order()
    from collections import OrderedDict
    assert isinstance(load_json(None, '{"z": 1, "a": 2}'), OrderedDict)

# Generated at 2022-06-21 13:32:16.895869
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('file', '/home/nn/Downloads/test.txt', '==')
    res = process_data_embed_file_contents_arg(arg)
    assert res == 'This is a test file\n'


# Generated at 2022-06-21 13:32:24.334039
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('Header;', 'key', None, '')
    assert process_empty_header_arg(arg) == ''
    arg = KeyValueArg('Header;', 'key', None, 'value')
    with pytest.raises(ParseError) as excinfo:
        process_empty_header_arg(arg)
    assert excinfo.value.message == 'Invalid item "Header:value"'


# Generated at 2022-06-21 13:32:28.241263
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # Create the arg containing the info for the empty header to be added
    from httpie.cli.argtypes import KeyValueArg
    arg = KeyValueArg(';', 'testheader2', '', '')

    # Assert that the value returned by process_header_arg should be an empty string
    assert process_empty_header_arg(arg) == ''

# Generated at 2022-06-21 13:32:36.341430
# Unit test for function load_text_file
def test_load_text_file():
    text = '''

[general]
Abstract = true
Authors = John Doe and Jane Doe

[file "file1.txt"]
Authors = Jane Doe
'''
    cwd = os.getcwd()
    filename = os.path.join(cwd, "test.toml")
    with open(filename, "w") as f:
        f.write(text)

    item = KeyValueArg('test_arg', ':', 'test.toml')
    contents = load_text_file(item)

    assert(text == contents)
    os.remove(filename)

# Generated at 2022-06-21 13:32:59.150953
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('Header;Test')
    headers = process_header_arg(arg)
    assert headers is None


# Generated at 2022-06-21 13:33:02.988561
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('name:qianqian')) == 'qianqian'
    assert process_header_arg(KeyValueArg('name:')) == None
    assert process_header_arg(KeyValueArg('name')) == None


# Generated at 2022-06-21 13:33:11.066540
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    f, mime_type = process_file_upload_arg(KeyValueArg('user_files', 'afile.jpg'))
    assert(mime_type == 'image/jpeg')
    f, mime_type = process_file_upload_arg(KeyValueArg('user_files', 'afile.jpg|'))
    assert(mime_type == 'image/jpeg')
    f, mime_type = process_file_upload_arg(KeyValueArg('user_files', 'afile.jpg|image/jpeg'))
    assert(mime_type == 'image/jpeg')
    f, mime_type = process_file_upload_arg(KeyValueArg('user_files', 'afile.jpg|image/png'))
    assert(mime_type == 'image/png')

# Generated at 2022-06-21 13:33:22.437467
# Unit test for function load_json
def test_load_json():
    a = [1, 2, 3, 4, 5]
    b = "test\ntest2\ntest3"
    a = load_json(a, b)
    print(a)

    # d = {"test" : 1, "test2": 2}
    # d_json = json.dumps(d)
    # print(d_json)

    # f_json = open("test.json", "w", encoding='utf-8')
    # json.dump(d, f_json)
    # f_json.close()
    # f_json = open("test.json", "r", encoding='utf-8')
    # d_json_loaded = json.load(f_json)
    # print(d_json_loaded)
    # f_json.close()

    # f = open("test.

# Generated at 2022-06-21 13:33:30.252065
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    args = KeyValueArg(
        key=None,
        value=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig=None
    )

    # value=None
    result = process_data_embed_raw_json_file_arg(args)
    assert result == None, f"Wrong value {result} returned."

    # value='{}'
    args.value = '{}'
    result = process_data_embed_raw_json_file_arg(args)
    assert result == {}, f"Wrong value {result} returned."

    # value='{"key": "value"}'
    args.value = '{"key": "value"}'
    result = process_data_embed_raw_json_file_arg(args)

# Generated at 2022-06-21 13:33:30.711923
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    pass

# Generated at 2022-06-21 13:33:33.861447
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('--form','filename','','SEPARATOR_DATA_EMBED_FILE_CONTENTS')
    assert process_data_embed_file_contents_arg(arg) == 'test'


# Generated at 2022-06-21 13:33:36.184776
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(orig='Header;', key='Header', sep=';', value='')
    assert process_empty_header_arg(arg) == ''

# Generated at 2022-06-21 13:33:41.649551
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = [KeyValueArg('header:value','header;value')]
    instance = RequestItems.from_args(request_item_args)
    assert instance.headers.get('header') == 'value'
    assert instance.data.get('header') == None
    assert instance.params.get('header') == None

# Generated at 2022-06-21 13:33:42.198471
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert 1 == 1

# Generated at 2022-06-21 13:34:00.990208
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_items = RequestItems.from_args([
            KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'name=value')])
    assert request_items.data['name'] == 'value'


# Generated at 2022-06-21 13:34:02.453238
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert 'foo' == process_query_param_arg(KeyValueArg('foo=bar', 'foo', 'bar', '='))

# Generated at 2022-06-21 13:34:04.393897
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_QUERY_PARAM)
    assert process_query_param_arg(arg) == 'value'


# Generated at 2022-06-21 13:34:10.188331
# Unit test for function process_data_item_arg

# Generated at 2022-06-21 13:34:14.392449
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    filename = 'F:\\projects\\httpie\\.gitignore'
    arg = KeyValueArg(key=None, key_orig=None, sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, value=filename, value_orig=filename, orig=None)
    assert process_data_embed_file_contents_arg(arg) is not None

# Generated at 2022-06-21 13:34:18.727136
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    test_arg = KeyValueArg(
        sep=SEPARATOR_DATA_RAW_JSON,
        key=None,
        value='{"test":42}',
        orig='{"test":42}')
    assert process_data_raw_json_embed_arg(test_arg) == {"test":42}

# Generated at 2022-06-21 13:34:22.748048
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    result = process_file_upload_arg(KeyValueArg(orig='-F',key='',value='C:\\Program Files\\Python37\\file',sep='-F'))
    assert(result == ('file',open('C:\\Program Files\\Python37\\file','rb'),'application/octet-stream'))

# Generated at 2022-06-21 13:34:25.498577
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    args = KeyValueArg('sep', 'key', '{\"a\":\"b\"}')
    assert(process_data_embed_raw_json_file_arg(args) == {'a':'b'})


# Generated at 2022-06-21 13:34:28.361802
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_arg = KeyValueArg('', '', '', '')
    assert process_file_upload_arg(test_arg) == ('', [], None)

# Generated at 2022-06-21 13:34:33.191186
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    result = load_json(None, '{"foo": "bar"}')
    #print("result: ", result)
    assert result == {"foo": "bar"}
    print("test_process_data_embed_raw_json_file_arg completed successfully")

if __name__ == "__main__":
    test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-21 13:35:19.868901
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
	item = KeyValueArg("Header1;")
	assert process_empty_header_arg(item) == ""
	item = KeyValueArg("Header1;value")
	assert process_empty_header_arg(item) == "value"


# Generated at 2022-06-21 13:35:24.676186
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('header;', 'key', 'value', 'header;key:value')
    with pytest.raises(ParseError):
        process_empty_header_arg(arg)
    arg = KeyValueArg('header;', 'key', None, 'header;key')
    assert process_empty_header_arg(arg) == None

# Generated at 2022-06-21 13:35:27.368084
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('filename.txt', 'filename.txt')
    assert process_file_upload_arg(arg) == ('filename.txt', 'filename.txt', None)



# Generated at 2022-06-21 13:35:32.094285
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_arg = KeyValueArg(key='search', value='value', sep=':')
    assert process_data_item_arg(test_arg) == 'value'
    print('test_process_data_item_arg passed!')


if __name__ == '__main__':
    test_process_data_item_arg()

# Generated at 2022-06-21 13:35:41.522550
# Unit test for function process_header_arg
def test_process_header_arg():
    '''
    Test function process_header_arg
    
    '''
    # Arrange
    arg_header_1: KeyValueArg = KeyValueArg(':', '', '')
    arg_header_2: KeyValueArg = KeyValueArg(':=', '', 'value')
    arg_header_3: KeyValueArg = KeyValueArg(':= ', '', 'value')
    arg_header_4: KeyValueArg = KeyValueArg(':=value', '', '')

    # Assert
    assert process_header_arg(arg_header_1) is None
    assert process_header_arg(arg_header_2) == 'value'
    assert process_header_arg(arg_header_3) == 'value'
    assert process_header_arg(arg_header_4) == 'value'


#

# Generated at 2022-06-21 13:35:49.012088
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg as arg

    a = arg('/Users/t/Desktop/b.json', key='@', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    b = arg('', key='@', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    try:
        a1 = process_data_embed_raw_json_file_arg(a)
        b1 = process_data_embed_raw_json_file_arg(b)
    except ParseError as e:
        print (e)
    else:
        print(a1, b1)

test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-21 13:35:51.360586
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    string = "username=John"
    argument = KeyValueArg(string)
    assert (process_data_item_arg(argument) == string)


# Generated at 2022-06-21 13:35:58.147422
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert (process_data_raw_json_embed_arg(KeyValueArg('', '', '{}')) == {})
    assert (process_data_raw_json_embed_arg(KeyValueArg('', '', '{"key1":"value1"}')) == {"key1":"value1"})
    assert (process_data_raw_json_embed_arg(KeyValueArg('', '', '{"key1":"value1","key2":"value2","key3":"value3"}')) == {"key1":"value1","key2":"value2","key3":"value3"})

# Generated at 2022-06-21 13:35:59.889821
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(sep=SEPARATOR_DATA_STRING, key='encoded', value='value')
    assert 'value' == process_data_item_arg(arg)

# Generated at 2022-06-21 13:36:09.604952
# Unit test for function load_json
def test_load_json():
    # Testing the load_json function
    # create a file to read from
    test_json = open("test_json.json", "w")
    # write to file
    test_json.write("{\"httpie\": \"cli\"}")
    # close the file
    test_json.close()
    # open file
    test_json = open("test_json.json", 'r')
    # testing the load_json function
    # result is expected to be a dictionary
    result = load_json("test_json.json", test_json.read())
    # the result should be a dictionary
    assert (type(result) == dict)
    # close the file
    test_json.close()
    # delete the test_json file we created
    os.remove("test_json.json")

# Generated at 2022-06-21 13:38:36.440934
# Unit test for function load_json
def test_load_json():
    print("Running test_load_json")
    json_str = '{"a": "1", "b": "2"}'
    assert load_json(None, json_str) == {"a": "1", "b": "2"}
    assert type(load_json(None, json_str)) == dict

if __name__ == "__main__":
    test_load_json()

# Generated at 2022-06-21 13:38:39.959348
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_arg = KeyValueArg(key='name', value='Костя', sep='=')
    test_data_item_arg = process_data_item_arg(test_arg)
    assert test_data_item_arg == 'Костя'

# Generated at 2022-06-21 13:38:46.380524
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg('key', 'value', ':')
    assert process_header_arg(header_arg) == 'value'
    header_arg_kv = KeyValueArg('key', 'value', ':')
    assert process_header_arg(header_arg_kv) == 'value'
    header_arg_k = KeyValueArg('key', '', ':')
    assert process_header_arg(header_arg_k) == ''


# Generated at 2022-06-21 13:38:50.722976
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = '1.txt'
    f = open(os.path.expanduser(filename), 'rb')
    assert (filename, f, get_content_type(filename)) == process_file_upload_arg(KeyValueArg('file', '1.txt'))

# Generated at 2022-06-21 13:38:58.465940
# Unit test for function load_json
def test_load_json():
    # Unit test for function load_json
    load_json_str = '{"a": "b"}'
    load_json_explanation = 'Simple json string with one key-value pair'
    assert (load_json_preserve_order(load_json_str) == json.loads(load_json_str, object_pairs_hook=OrderedDict))
    try:
        load_json_non_json_str = '{"a": "b" c}'
        load_json_non_json_explanation = 'Simple non-json string with one key-value pair'
        load_json_preserve_order(load_json_non_json_str)
    except ValueError:
        load_json_non_json_str
        load_json_non_json_explanation

test_load_json

# Generated at 2022-06-21 13:39:09.603286
# Unit test for function load_text_file
def test_load_text_file():
    """
    Unit test for function load_text_file
    """
    # test reading a file
    item = KeyValueArg('test', 'test', 'test')
    file = load_text_file(item)
    with open('test', 'r') as f:
        assert file.rstrip('\r\n') == f.read().rstrip('\r\n')
    # test with a wrong path
    item = KeyValueArg('test', 'test2', 'test2')
    try:
        file = load_text_file(item)
    except ParseError as e:
        assert 1  # existence of this assert asserts that expected error has been caught
    # test with a non-UTF8 file
    item = KeyValueArg('test', 'test4', 'test4')

# Generated at 2022-06-21 13:39:13.825171
# Unit test for function process_header_arg
def test_process_header_arg():
    sep = SEPARATOR_HEADER
    mock_value = 'Hello'
    mock_kv_args = mock_kv_args = KeyValueArg(
        key=mock_value, separator=sep, value=mock_value, orig=f'{mock_value}{sep}{mock_value}'
    )
    assert process_header_arg(mock_kv_args) == mock_value


# Generated at 2022-06-21 13:39:19.971602
# Unit test for function load_json
def test_load_json():
    # Test load_json
    str_1 = '[1, 2, 3]'
    assert load_json(KeyValueArg(None, None, None, 'test', str_1), str_1) == [1, 2, 3]
    str_1 = '{"a": "b"}'
    assert load_json(KeyValueArg(None, None, None, 'test', str_1), str_1) == {'a': 'b'}
    str_1 = '{"a": {"b": "c"}}'
    assert load_json(KeyValueArg(None, None, None, 'test', str_1), str_1) == {'a': {'b': 'c'}}

    # Test if load_json can load empty string
    str_1 = ''