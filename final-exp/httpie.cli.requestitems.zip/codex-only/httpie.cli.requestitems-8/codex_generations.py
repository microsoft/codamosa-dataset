

# Generated at 2022-06-23 18:47:57.970652
# Unit test for function load_json
def test_load_json():
    contents = '{"a":1}'
    arg = KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'a', contents)
    assert load_json(arg, contents) == {'a': 1}

    contents = '{"a":1,"b":2,"c":{"ca":1,"cb":2}}'
    arg = KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'c', contents)
    assert load_json(arg, contents) == {'ca': 1, 'cb': 2}

# Generated at 2022-06-23 18:48:00.595608
# Unit test for function load_text_file
def test_load_text_file():
    data = load_text_file(KeyValueArg('hello'))
    assert (data == 'hello')

# Generated at 2022-06-23 18:48:03.811398
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(orig='-d', key='', sep='=', value='123')
    assert '123' == process_data_item_arg(arg)


# Generated at 2022-06-23 18:48:08.002422
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    with pytest.raises(ParseError):
        process_empty_header_arg(KeyValueArg(
            'header', '', '', SEPARATOR_HEADER_EMPTY
        ))



# Generated at 2022-06-23 18:48:14.229644
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(sep=':',key='Authorization',value='Basic dXNlcjpwYXNzd29yZA==')
    assert process_header_arg(arg) == 'Basic dXNlcjpwYXNzd29yZA=='
    arg = KeyValueArg(sep=':', key='Authorization', value='')
    assert process_header_arg(arg) == ''


# Generated at 2022-06-23 18:48:21.490670
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    json_string = '{"a":10, "b":20}'
    data_item_arg1 = KeyValueArg("data", json_string)
    data_item_arg2 = KeyValueArg("data", "10")
    print(process_query_param_arg(data_item_arg1))
    print(process_query_param_arg(data_item_arg2))


# Generated at 2022-06-23 18:48:24.503030
# Unit test for function load_json
def test_load_json():
    items = [
        ("""{"name": "value"}""",)
    ]
    for i in items:
        print(load_json(i[0]))

# Generated at 2022-06-23 18:48:29.898748
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_items = RequestItems(True)
    assert isinstance(request_items.headers, RequestHeadersDict)
    assert isinstance(request_items.data, RequestDataDict)
    assert isinstance(request_items.files, RequestFilesDict)
    assert isinstance(request_items.params, RequestQueryParamsDict)


# Generated at 2022-06-23 18:48:37.098507
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg()
    arg.orig = 'json=@E:/GitRepo/httpie/tests/fixtures/1.json'
    arg.value = 'E:/GitRepo/httpie/tests/fixtures/1.json'
    arg.sep = SEPARATOR_FILE_UPLOAD
    arg.key = 'json'
    assert process_file_upload_arg(arg) == ('1.json', open('E:/GitRepo/httpie/tests/fixtures/1.json', 'rb'), 'text/plain')



# Generated at 2022-06-23 18:48:40.606401
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('test=@test/datas/test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-23 18:48:48.966925
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request = RequestItems.from_args([
        KeyValueArg.from_arg('key1', 'value1', ':'),
        KeyValueArg.from_arg('key2', 'value2', ':'),
        KeyValueArg.from_arg('key3', 'value3', ':'),
    ])
    print(request.headers)
    print(request.data)
    print(request.files)
    print(request.params)
    print(request.multipart_data)


if __name__ == '__main__':
    test_RequestItems()

# Generated at 2022-06-23 18:48:50.887238
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("*;", "key", value=None)
    assert process_empty_header_arg(arg) == ""

# Generated at 2022-06-23 18:48:53.206382
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    # Given
    arg = KeyValueArg('s1=v1')

    # When
    str = process_data_item_arg(arg)

    # Then
    assert str == 'v1'


# Generated at 2022-06-23 18:49:04.233703
# Unit test for function load_json
def test_load_json():
    json_dict = {
        'key': 'value',
        'end_of_loop': 'true'
    }
    json_str = json.dumps(json_dict)
    assert load_json(None, json_str)
    json_dict = {
        'key': 'value',
        'end_of_loop': True
    }
    json_str = json.dumps(json_dict)
    assert load_json(None, json_str)
    json_dict = {
        'key': 'value',
        'end_of_loop': 1
    }
    json_str = json.dumps(json_dict)
    assert load_json(None, json_str)

# Generated at 2022-06-23 18:49:06.778719
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    test_item = KeyValueArg('Accept;', 'application/json')
    assert process_empty_header_arg(test_item) == 'application/json'

# Generated at 2022-06-23 18:49:12.099371
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestDataDict
    file = "new_file.txt"
    test_embed_file_contents_arg = KeyValueArg("@", file, file, file)
    data_dict = RequestDataDict()
    process_data_embed_file_contents_arg(test_embed_file_contents_arg)
    return


# Generated at 2022-06-23 18:49:14.658430
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg(key='key', value='value')) == 'value'


# Generated at 2022-06-23 18:49:18.009061
# Unit test for function load_json
def test_load_json():
    actual = load_json("test", '{ "a": "test" }')
    expected = {"a": "test"}
    assert actual == expected


# Generated at 2022-06-23 18:49:21.752478
# Unit test for function process_header_arg
def test_process_header_arg():
    header = RequestItems.from_args(
        [KeyValueArg('header1', 'value1', '', 'header1:value1')])
    assert header.headers['header1'] == 'value1'



# Generated at 2022-06-23 18:49:24.522052
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("", SEPARATOR_HEADER_EMPTY, "")
    assert process_empty_header_arg(arg) == ""

# Generated at 2022-06-23 18:49:28.804558
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    kvarg = KeyValueArg("test_key", "test_value", "test_orig")
    kvarg.value = "test_value"
    expected_ = "test_value"

    res_ = process_data_embed_file_contents_arg(kvarg)
    assert res_ == expected_

# Generated at 2022-06-23 18:49:31.097215
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('name', 'value')
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == 'value'

# Generated at 2022-06-23 18:49:38.293230
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(key=None, sep=':', value='{"name": "foo"}')) == {'name': 'foo'}
    assert process_data_raw_json_embed_arg(KeyValueArg(key=None, sep=':', value='{"name": "foo", "name2": "foo2"}')) == {'name': 'foo', 'name2': 'foo2'}
    assert process_data_raw_json_embed_arg(KeyValueArg(key=None, sep=':', value='{"name": "foo", "name2": ["foo2", "foo3", "foo4"]}')) == {'name': 'foo', 'name2': ['foo2', 'foo3', 'foo4']}
    assert process_data_raw_json_embed_

# Generated at 2022-06-23 18:49:47.852095
# Unit test for function process_header_arg
def test_process_header_arg():
    test1 = KeyValueArg(orig='X-API-KEY', sep='Header:', key='Header', value='abc', sep_name='Header')
    assert process_header_arg(test1) == 'abc'
    test2 = KeyValueArg(orig='X-API-KEY', sep='Header:', key='Header', value='', sep_name='Header')
    assert process_header_arg(test2) == ''
    test3 = KeyValueArg(orig='X-API-KEY', sep='Header:', key='Header', value=None, sep_name='Header')
    assert process_header_arg(test3) == None


# Generated at 2022-06-23 18:49:52.711129
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='data-binary@~/Documents/data.json', key='data-binary', value='~/Documents/data.json', sep='@')
    assert load_text_file(item) == '{"name": "test"}\n'

# Generated at 2022-06-23 18:49:59.066480
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg1 = KeyValueArg(orig='Header;', key='Header',
                       value=None, sep=':')
    arg2 = KeyValueArg(orig='Header:value', key='Header',
                       value='value', sep=':')
    assert process_empty_header_arg(arg1) == ''
    try:
        process_empty_header_arg(arg2)
        assert False
    except ParseError:
        assert True


# Generated at 2022-06-23 18:50:08.648092
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Normal json string
    item = KeyValueArg('', 'key', '{"k1": 1}')
    assert process_data_raw_json_embed_arg(item) == {"k1": 1}

    # Malformed json string
    item = KeyValueArg('', 'key', '{"k1": 1')
    try:
        process_data_raw_json_embed_arg(item)
    except ParseError as e:
        assert e.args[0] == '"key": Unterminated string starting at: line 1 column 8 (char 7)'

    # Empty json string
    item = KeyValueArg('', 'key', '{}')
    assert process_data_raw_json_embed_arg(item) == {}

    # Empty value
    item = KeyValueArg('', 'key', '')
    assert process_data

# Generated at 2022-06-23 18:50:14.665745
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('--data', '@/home/navneet/git/httpie/test_data/embed_text_file.txt', '@')
    assert process_data_embed_file_contents_arg(arg) == "hello world"
    arg = KeyValueArg('--data', '@/home/navneet/git/httpie/test_data/embed_utf8_file.txt', '@')
    assert process_data_embed_file_contents_arg(arg) == "hello world"
    arg = KeyValueArg('--data', '@/home/navneet/git/httpie/test_data/embed_ascii_file.txt', '@')
    assert process_data_embed_file_contents_arg(arg) == "hello world"

# Generated at 2022-06-23 18:50:21.065074
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # test case 1
    assert process_data_embed_file_contents_arg(
        KeyValueArg('@', 'input.txt', 'input.txt')
    ) == '1234567'

    # test case 2
    assert process_data_embed_file_contents_arg(
        KeyValueArg('@', 'input1.txt', 'input1.txt')
    ) == '123456'

    # test case 3
    assert process_data_embed_file_contents_arg(
        KeyValueArg('@', 'input2.txt', 'input2.txt')
    ) == '123456789'

    # test case 4

# Generated at 2022-06-23 18:50:31.901506
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg('a', 'a', 'a')) == 'a'
    assert process_data_raw_json_embed_arg(KeyValueArg('a', '["a"]', 'a')) == \
        ['a']
    assert process_data_raw_json_embed_arg(KeyValueArg('a', '[{"a":"b"}]',
                                                   'a')) == [{'a': 'b'}]
    assert process_data_raw_json_embed_arg(KeyValueArg('a', '{"a":"b"}', 'a')) == \
        {'a': 'b'}

# Generated at 2022-06-23 18:50:35.335395
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('k', 'v', '-F', 'v')
    assert process_data_embed_raw_json_file_arg(arg) == 'v'

# Generated at 2022-06-23 18:50:39.381713
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='test_name', value='test_value', sep='?')
    query_param = process_query_param_arg(arg)
    assert query_param == 'test_value'


# Generated at 2022-06-23 18:50:40.835007
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg("name", "value", ";")
    assert process_query_param_arg(arg) == arg.value

# Generated at 2022-06-23 18:50:52.466445
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():

    def dict_equal(dict1 , dict2):
        return dict1.items() == dict2.items()

    def test(args, expected_result):
        request_items = RequestItems()
        request_items.data = process_data_embed_file_contents_arg(args)
        assert dict_equal(request_items.data, expected_result)
        print("test passed")
    
    arg = KeyValueArg('', 'user;', 'user;', 'name;', '"httpie"')
    expected_result = {'user': {'name': '"httpie"'}}
    
    test(arg, expected_result)

test_process_data_embed_file_contents_arg()

# Generated at 2022-06-23 18:50:58.851770
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    path_file = "./unittest/test.txt"
    content = b"Hello World!"
    expected = (
        os.path.basename(path_file),
        BytesIO(content),
        None
    )
    with open(path_file, "wb") as f:
        f.write(content)

    class KeyValueArg:
        def __init__(self, value):
            self.value = value
            self.orig = value
        
    arg = KeyValueArg(path_file)
    assert process_file_upload_arg(arg) == expected

# Generated at 2022-06-23 18:51:03.766212
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    query_param = "query_param"
    expected_value = "param"
    arg = KeyValueArg(query_param, expected_value, SEPARATOR_QUERY_PARAM)
    assert process_query_param_arg(arg) == expected_value


# Generated at 2022-06-23 18:51:16.411289
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(key="foo", value="bar", sep="=")) == "bar"
    assert type(process_data_raw_json_embed_arg(KeyValueArg(key="foo", value="true", sep="="))) is bool
    assert process_data_raw_json_embed_arg(KeyValueArg(key="foo", value="1", sep="=")) == 1
    assert process_data_raw_json_embed_arg(KeyValueArg(key="foo", value="null", sep="=")) is None
    assert type(process_data_raw_json_embed_arg(KeyValueArg(key="foo", value="[]", sep="="))) is list

# Generated at 2022-06-23 18:51:24.557446
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    item1 = KeyValueArg(':')
    a = process_empty_header_arg(item1)
    assert(a == '')
    # Parse error if value is not empty
    item2 = KeyValueArg('a:')
    with pytest.raises(ParseError) as excinfo:
        process_empty_header_arg(item2)
    assert('Invalid item "a:" '
          '(to specify an empty header use `Header;`)'
          in str(excinfo.value))

# Generated at 2022-06-23 18:51:27.282283
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert load_json(KeyValueArg("key","value"), "{\"a\":1,\"b\":2}") == {'a': 1, 'b': 2}

# Generated at 2022-06-23 18:51:32.258200
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # arg = argparse.Namespace(key='foo', value='bar', orig='foo=bar', sep='=')
    arg = argparse.Namespace(key='foo', value='bar', orig='foo=bar', sep='=')
    assert process_query_param_arg(arg) == 'bar'


# Generated at 2022-06-23 18:51:34.865910
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    key = "foo"
    value = "bar"
    arg = KeyValueArg(key, value, None, None)
    assert process_query_param_arg(arg) == value

# Generated at 2022-06-23 18:51:36.813425
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('Header;', '', 'Header;')) == ''

# Generated at 2022-06-23 18:51:40.773065
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "user/meow", "meow/woof/man")
    process_file_upload_arg(arg)

if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-23 18:51:42.747517
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(SEPARATOR_QUERY_PARAM, "name", "value")

    result = process_query_param_arg(arg)

    assert result == "value"


# Generated at 2022-06-23 18:51:43.936466
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(";", "", "")
    process_empty_header_arg(arg)


# Generated at 2022-06-23 18:51:48.545337
# Unit test for constructor of class RequestItems
def test_RequestItems():
    headers = RequestHeadersDict()
    headers['Content-Type'] = 'application/json'
    data = RequestDataDict()
    data['test'] = 'test1'
    print(data)
    files = RequestFilesDict()
    params = RequestQueryParamsDict()
    multipart_data = MultipartRequestDataDict()
    request_item = RequestItems(False)
    request_item.headers = headers
    request_item.data = data
    request_item.files = files
    request_item.params = params
    request_item.multipart_data = multipart_data
    print(request_item)


# Generated at 2022-06-23 18:51:55.859615
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test for valid json
    arg1 = KeyValueArg('data', '{}', ';')
    assert process_data_raw_json_embed_arg(arg1) == {}

    # Test for invalid json
    arg2 = KeyValueArg('data', '{', ';')
    try:
        process_data_raw_json_embed_arg(arg2)
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-23 18:51:58.072633
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('name','john')
    assert process_data_item_arg(arg)=='john'

# Generated at 2022-06-23 18:51:58.840194
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert RequestItems()

# Generated at 2022-06-23 18:52:01.320874
# Unit test for function load_text_file
def test_load_text_file():
    data = load_text_file(arg.KeyValueArg("", "test.txt"))
    assert data == "test"

 # Unit test for function load_text_file

# Generated at 2022-06-23 18:52:04.439317
# Unit test for function process_header_arg
def test_process_header_arg():
    request_items = RequestItems()
    arg = KeyValueArg("-H", "Content-Type", "text/html")
    process_header_arg(arg)
    assert request_items.headers["Content-Type"] == "text/html"  


# Generated at 2022-06-23 18:52:08.768566
# Unit test for function load_text_file
def test_load_text_file():
    test_json = '{"test": "value", "test2": "value2"}'

    result = load_text_file(KeyValueArg(0, '--data', test_json))
    expected = '{"test": "value", "test2": "value2"}'

    assert(result == expected)

# Generated at 2022-06-23 18:52:16.387402
# Unit test for function load_json
def test_load_json():
    from os.path import dirname, abspath, join
    from httpie.cli.constants import SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    from httpie.cli.argtypes import KeyValueArg

    test_file_path = join(dirname(abspath(__file__)), '../test_data/test.json')
    item = KeyValueArg("test", SEPARATOR_DATA_EMBED_RAW_JSON_FILE, test_file_path)
    test_json = load_json(item, test_file_path)
    assert test_json == {
        'hello': 'world',
        'httpie': 'is',
        'awesome': '!!!!',
        'new_field': 'new_value'
    }

# Generated at 2022-06-23 18:52:19.223482
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    query_param_arg = 'user=tom&password=123'
    print(process_query_param_arg(query_param_arg))


# Generated at 2022-06-23 18:52:29.500358
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    """
    The parameters in unit test are the same as process_data_raw_json_embed_arg()
    :return:
    """
    # The expected value is {"a":1,"b":2}
    arg=KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON, key='', value='{"a":1,"b":2}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1,"b":2}

    # The expected value is {"b":2,"a":1,"c":3}
    arg = KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON, key='', value='{"b":2,"a":1,"c":3}')

# Generated at 2022-06-23 18:52:33.212928
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # fail with value
    try:
        process_empty_header_arg(KeyValueArg('Header;value', ';'))
        assert False
    except ParseError:
        pass
    # success with no value
    assert process_empty_header_arg(KeyValueArg('Header;', ';')) is ''

# Generated at 2022-06-23 18:52:37.534300
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'file.txt', None)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world!\n'

# Generated at 2022-06-23 18:52:39.182895
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(b'Header;', b'Header;')
    assert process_empty_header_arg(arg) == ''

# Generated at 2022-06-23 18:52:41.738850
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    """
    TODO: Automate unit test
    :return:
    """
    val = process_data_embed_raw_json_file_arg(KeyValueArg("@C:\\Users\\rrayasta\\Desktop\\test\\test.json", "@"))
    print("JSON: " + str(val))



# Generated at 2022-06-23 18:52:45.413102
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    data_item = KeyValueArg(
        'data',
        '@',
        'D://Users//Administrator//Desktop//data.txt'
    )
    assert process_data_embed_file_contents_arg(data_item) == 'hello world'

# Generated at 2022-06-23 18:52:50.178234
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('@', '{}')
    assert process_data_embed_raw_json_file_arg(arg) == {}

    arg = KeyValueArg('@', 'test.txt')
    assert process_data_embed_raw_json_file_arg(arg) == 'ddd'



# Generated at 2022-06-23 18:52:53.293334
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(sep='?', key='enable_logging', value='true')
    ret = process_query_param_arg(arg)
    assert(ret == 'true')

# Generated at 2022-06-23 18:52:59.489095
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg('filename', 'logo.png')
        ) == ('logo.png', '', 'image/png')
    assert process_file_upload_arg(KeyValueArg('filename', 'logo.png:text/plain')
        ) == ('logo.png', '', 'text/plain')

test_process_file_upload_arg()

# Generated at 2022-06-23 18:53:09.203390
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import pytest
    t = []
    t.append(KeyValueArg(sep=u'=', key=u'a', value=u'b'))

    good_json = u'{"a":["b","c"]}'
    t.append(KeyValueArg(sep=u'=', key=u'a',value=good_json))
    t.append(KeyValueArg(sep=u'@', key=u'a',value=good_json))
    t.append(KeyValueArg(sep=u'~', key=u'a',value=good_json))

    bad_json = u'{"a":["b",'
    t.append(KeyValueArg(sep=u'=', key=u'a',value=bad_json))

# Generated at 2022-06-23 18:53:10.593940
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    process_data_item_arg(KeyValueArg(SEPARATOR_DATA_STRING, 'key', 'value'))


# Generated at 2022-06-23 18:53:21.193702
# Unit test for function load_text_file

# Generated at 2022-06-23 18:53:29.516807
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Test for headers
    assert RequestItems().headers == {}
    assert RequestItems(as_form=True).headers == {}

    # Test for data
    assert RequestItems().data == {}
    assert RequestItems(as_form=True).data == {}

    # Test for files
    assert RequestItems().files == {}
    assert RequestItems(as_form=True).files == {}

    # Test for params
    assert RequestItems().params == {}
    assert RequestItems(as_form=True).params == {}

    # Test for multipart_data
    assert RequestItems().multipart_data == {}
    assert RequestItems(as_form=True).multipart_data == {}



# Generated at 2022-06-23 18:53:36.839710
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    item_args: List[KeyValueArg] = []
    item_args.append(KeyValueArg(
        'Authorization', '', 'Request Header'))
    item_args.append(KeyValueArg(
        'Content-Type', '', 'Request Header'))
    item_args.append(KeyValueArg(
        'Accept', '', 'Request Header'))
    process_data_embed_file_contents_arg(item_args[0])

    item_args: List[KeyValueArg] = []
    item_args.append(KeyValueArg(
        'Authorization', '', 'Request Header'))
    item_args.append(KeyValueArg(
        'Content-Type', '', 'Request Header'))
    item_args.append(KeyValueArg(
        'Accept', '', 'Request Header'))


# Generated at 2022-06-23 18:53:39.774844
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(str('a'),str('123'), str('='), str('a=123'))
    print(process_data_embed_raw_json_file_arg(arg))


# Generated at 2022-06-23 18:53:41.481604
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('k', ';f', 'k;f')) == 'k;f'

# Generated at 2022-06-23 18:53:44.221662
# Unit test for function load_json
def test_load_json():
    try:
        load_json({"name":"value"}, '{"2": 3}')
        assert False
    except ParseError as e:
        assert "Invalid item" in str(e)


# Generated at 2022-06-23 18:53:47.240617
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert RequestItems(as_form=False) == RequestItems()

# Generated at 2022-06-23 18:53:57.382617
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    _test_data = '''
    {
        "input": "https://github.com/jkbrzt/httpie/issues?page=1",
        "output": "https://github.com/jkbrzt/httpie/issues%3Fpage%3D1"
    }
'''
    _result = True
    result = False
    arg = KeyValueArg(key="null", sep="=j", value=_test_data)
    try:
        value = process_data_raw_json_embed_arg(arg)
    except Exception as e:
        pass

# Generated at 2022-06-23 18:54:00.849466
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    item = KeyValueArg(':', 'key', 'value')
    process_data_embed_file_contents_arg(item)

# Generated at 2022-06-23 18:54:03.593967
# Unit test for function process_header_arg
def test_process_header_arg():
    # Given
    arg = KeyValueArg(sep='Header:', key='Accept', value='text/html')

    # When
    actual = process_header_arg(arg)

    # Then
    assert actual == 'text/html'



# Generated at 2022-06-23 18:54:14.081118
# Unit test for constructor of class RequestItems
def test_RequestItems():
    '''
    Test the constructor
    :return:
    '''
    request_items = RequestItems()
    assert isinstance(request_items.headers, RequestHeadersDict)
    assert isinstance(request_items.data, RequestJSONDataDict)
    assert isinstance(request_items.files, RequestFilesDict)
    assert isinstance(request_items.params, RequestQueryParamsDict)
    assert isinstance(request_items.multipart_data, MultipartRequestDataDict)


test_RequestItems()
test_RequestItems.counter = 0
test_RequestItems.passed = 0



# Generated at 2022-06-23 18:54:16.462637
# Unit test for function process_header_arg
def test_process_header_arg():
    request_item_args_instance = process_header_arg(KeyValueArg('accept', 'application/json', ';'))
    assert isinstance(request_item_args_instance, str)

# Generated at 2022-06-23 18:54:19.766550
# Unit test for constructor of class RequestItems
def test_RequestItems():
    a = RequestItems(as_form=False)
    assert a.headers == RequestHeadersDict()
    assert a.data == RequestJSONDataDict()
    assert a.files == RequestFilesDict()
    assert a.params == RequestQueryParamsDict()
    assert a.multipart_data == MultipartRequestDataDict()

# Generated at 2022-06-23 18:54:28.449185
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    test_case_list = ["", " ", "{", "{ a : 1 }", "[", "[1]", "abc"]
    expected_result = []
    actual_result = []
    for test_case in test_case_list:
        try:
            assert process_data_raw_json_embed_arg(
                KeyValueArg(
                    'key',
                    test_case,
                    'SEPARATOR_DATA_RAW_JSON',
                )
            ) == expected_result
        except ParseError:
            actual_result.append(True)
        else:
            actual_result.append(False)
    assert actual_result == expected_result



# Generated at 2022-06-23 18:54:32.640475
# Unit test for function process_header_arg
def test_process_header_arg(): 
    assert process_header_arg(KeyValueArg(sep=SEPARATOR_HEADER, key='header',
        value=None)) == None
    assert process_header_arg(KeyValueArg(sep=SEPARATOR_HEADER, key='header',
        value='value')) == 'value'


# Generated at 2022-06-23 18:54:34.791616
# Unit test for function process_header_arg
def test_process_header_arg():
    h = process_header_arg('name: value')
    assert h == 'value'



# Generated at 2022-06-23 18:54:46.892357
# Unit test for function load_json

# Generated at 2022-06-23 18:54:59.919604
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    import json
    import sys, os
    sys.path.append(sys.path[0]+'/../')
    os.environ['HTTPIE_NO_CONFIG'] = '1'
    from httpie.cli.parser import parse_items
    parsed = parse_items([\
        '--form',\
        '--data',\
        '@file1.txt',\
    ])
    assert parsed.args.data_string is None
    assert parsed.args.form_string is None
    assert parsed.args.files is None
    assert len(parsed.args.data) == 1
    assert parsed.args.data.get("@file1.txt") == "This is a test file content"
    assert parsed.args.data.get("@file2.txt") is None

# Generated at 2022-06-23 18:55:11.735160
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename: str = "./dir/filename.csv"
    mimeType: str = "text/csv"

    result: Tuple[str, IO, str] = process_file_upload_arg(
        KeyValueArg(
            arg=filename,
            key=filename,
            value=filename,
            sep=SEPARATOR_FILE_UPLOAD,
            orig=f"{filename}"
        )
    )

    assert result[0] == "filename.csv"
    assert result[2] == get_content_type(filename)


# Generated at 2022-06-23 18:55:15.552581
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('-H', '', ';', 'dummy')
    try:
        process_empty_header_arg(arg)
    except ParseError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 18:55:18.465149
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('-H', 'header', 'value')
    assert process_header_arg(arg) == 'value'
    arg = KeyValueArg('-H', 'header', '')
    assert process_header_arg(arg) == ''
    arg = KeyValueArg('-H', 'header', None)
    assert process_header_arg(arg) == None


# Generated at 2022-06-23 18:55:20.276150
# Unit test for function process_header_arg
def test_process_header_arg():
    s = process_header_arg(KeyValueArg(key='ssss', value='vvvv', sep=':', orig='ssss:vvvv'))
    assert s == 'vvvv'

# Generated at 2022-06-23 18:55:22.953311
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test_val = 'val'
    arg = KeyValueArg('key', test_val, '==')
    assert process_query_param_arg(arg) == test_val


# Generated at 2022-06-23 18:55:27.089617
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON, key='key', value='"value"')
    value = process_data_raw_json_embed_arg(arg)
    assert value == "value"


# Generated at 2022-06-23 18:55:29.324780
# Unit test for function load_text_file
def test_load_text_file():
    args = KeyValueArg('post', '@post.txt', '@')
    assert load_text_file(args) == '{"title": "foo", "body": "bar", "userId": 1}\n'


# Generated at 2022-06-23 18:55:35.813368
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg1 = KeyValueArg(key='foo', value='bar', sep=':', orig='foo:bar')
    assert process_query_param_arg(arg1) == 'bar'

    arg2 = KeyValueArg(key='foo', value='', sep=':', orig='foo:')
    assert process_query_param_arg(arg2) == ''



# Generated at 2022-06-23 18:55:38.132741
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():    
    arg = KeyValueArg("some_header;", "some_value")
    assert "some_value" == process_empty_header_arg(arg)

# Generated at 2022-06-23 18:55:42.096082
# Unit test for function load_json
def test_load_json():
    request_item_args: List[KeyValueArg] = []
    request_item_args.append(KeyValueArg(orig='test', sep='=', key='test', value='test'))
    value = request_item_args[0]
    contents = 'test'
    content = load_json(value, contents)
    assert  content == 'test'

# Generated at 2022-06-23 18:55:46.443442
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(arg=KeyValueArg(key="key", value="value")) == "value"

if __name__ == "__main__":
    test_process_header_arg()

# Generated at 2022-06-23 18:55:49.208395
# Unit test for constructor of class RequestItems
def test_RequestItems():
    t = [KeyValueArg('name', 'admin', '=')]
    i = RequestItems.from_args(t)
    assert i.headers['name'] == 'admin'
    assert i.data == {}

# Generated at 2022-06-23 18:55:59.747524
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # test for function load_text_file
    # ParseError
    path = '../-/'
    item = KeyValueArg(None, '', '-d', path)
    try:
        load_text_file(item)
    except ParseError:
        pass
    else:
        assert False
    # UnicodeDecodeError
    path = '../httpie.1'
    item = KeyValueArg(None, '', '-d', path)
    try:
        load_text_file(item)
    except ParseError:
        pass
    else:
        assert False
    # normal test
    path = '../testdata/chinese.txt'
    item = KeyValueArg(None, '', '-d', path)

# Generated at 2022-06-23 18:56:06.305417
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg('Header;value'))
        pytest.fail('ParseError is expected!')
    except ParseError:
        pass
    assert process_empty_header_arg(KeyValueArg('Header;')) is None
    try:
        process_empty_header_arg(KeyValueArg('Header', ''))
        pytest.fail('ParseError is expected!')
    except ParseError:
        pass

# Generated at 2022-06-23 18:56:09.149725
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg(orig='Header;', sep=';', key='Header', value=None)) is ''


# Generated at 2022-06-23 18:56:11.733905
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('start=1')
    assert(process_query_param_arg(arg) == '1')


# Generated at 2022-06-23 18:56:15.804643
# Unit test for function process_header_arg
def test_process_header_arg():
    header = process_header_arg(KeyValueArg(key='key', value='value', sep=':'))
    assert header == 'value'
    header = process_header_arg(KeyValueArg(key='key', value=None, sep=':'))
    assert header == None


# Generated at 2022-06-23 18:56:18.005775
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('data', 'testData')
    assert process_data_item_arg(arg) == 'testData'

# Generated at 2022-06-23 18:56:24.030142
# Unit test for function load_json
def test_load_json():
    input_json = '{"foo": 1}'
    expected_json = json.loads(input_json)
    actual_json = load_json(KeyValueArg(1, 'foo', input_json), input_json)
    assert expected_json == actual_json, \
        "Error: expected: {}, but got: {}".format(expected_json, actual_json)

# Generated at 2022-06-23 18:56:27.170633
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    result = process_data_item_arg(KeyValueArg("name", "Harcourt"))
    assert result == "Harcourt"


# Generated at 2022-06-23 18:56:30.430708
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    item = KeyValueArg("test", "this is a test", "-f")
    actual = process_data_embed_file_contents_arg(item)
    assert actual == "this is a test"


# Generated at 2022-06-23 18:56:33.300826
# Unit test for function load_text_file
def test_load_text_file():
    assert process_data_embed_raw_json_file_arg("'{}'") == {}

# Generated at 2022-06-23 18:56:41.003008
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    raw_data='b;a.txt;{"a": "c"}'
    args = shlex.split(raw_data)
    assert args == ['b;a.txt;{"a": "c"}']
    request_items = RequestItems.from_args(
        [KeyValueArg(*arg.partition('=')) for arg in args]
    )
    assert request_items.data.get('b') == '{"a": "c"}'
    assert request_items.multipart_data == MultipartRequestDataDict()


# Generated at 2022-06-23 18:56:45.362416
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    d = RequestItems()
    arg = KeyValueArg(key='data', value='{"foo": "bar"}', sep='=')
    result = process_data_raw_json_embed_arg(arg)
    assert result == {"foo": "bar"}

# Generated at 2022-06-23 18:56:48.671053
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg1 = KeyValueArg("key; value", ";")
    assert process_data_item_arg(arg1) == "value"

    arg2 = KeyValueArg("key; \"value\"", ";")
    assert process_data_item_arg(arg2) == "value"



# Generated at 2022-06-23 18:56:53.064832
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-23 18:56:54.830574
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    pass


# Generated at 2022-06-23 18:57:00.475864
# Unit test for function process_header_arg
def test_process_header_arg():
    temp_arg = KeyValueArg('key1', 'value1', '=', 'key1=value1')
    assert process_header_arg(temp_arg) == 'value1'
    temp_arg = KeyValueArg('key1', '', '=', 'key1=')
    assert process_header_arg(temp_arg) == ''


# Generated at 2022-06-23 18:57:02.126263
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    try:
        process_query_param_arg(KeyValueArg('x=y'))
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-23 18:57:13.155566
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import io
    arg = KeyValueArg('field', 'file_upload', 'file_name;mime_type')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file_name'
    assert mime_type == 'mime_type'
    assert isinstance(f, io.BufferedReader)
    arg = KeyValueArg('field', 'file_upload', 'file_name')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file_name'
    assert mime_type is None
    assert isinstance(f, io.BufferedReader)

# Generated at 2022-06-23 18:57:14.524585
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg('abc') == 'abc'

# Generated at 2022-06-23 18:57:22.243495
# Unit test for function process_data_item_arg

# Generated at 2022-06-23 18:57:23.738149
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("", "", "", "", "")
    assert load_text_file(item) == ""


# Generated at 2022-06-23 18:57:26.099160
# Unit test for function load_json
def test_load_json():
    assert load_json(None, "{\"a\" : \"b\"}") == {"a":"b"}
    assert load_json(None, "[{\"a\" : \"b\"}]") == [{"a":"b"}]


# Generated at 2022-06-23 18:57:29.409989
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg('foo', 'Header', 'value'))
    except ParseError as err:
        assert 'Invalid item "foo:Header:value"' in str(err)
    else:
        assert False



# Generated at 2022-06-23 18:57:34.478288
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('test.txt', '=.\\test.txt')
    result = process_data_embed_file_contents_arg(arg)
    assert result == 'This is a test file for function test_process_data_embed_file_contents_arg.\n'



# Generated at 2022-06-23 18:57:41.050921
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "bar", "foo.txt")
    result = process_file_upload_arg(arg)
    assert(tuple) == type(result)
    assert(2) == len(result)
    assert(type(result[0])) == type(result[1]) == type(result[2])



# Generated at 2022-06-23 18:57:43.765885
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    header_arg = KeyValueArg(b'Header;', b'', b'Header')
    header_value = process_empty_header_arg(header_arg)
    assert header_value == b''



# Generated at 2022-06-23 18:57:47.391087
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('sep=:', 'key', 'value')
    process_data_embed_file_contents_arg(arg)

# Generated at 2022-06-23 18:57:54.226334
# Unit test for function load_text_file
def test_load_text_file():
    sample_data = ['a', 'b', 'c', 'd']
    input_data = ['e', 'f', 'g', 'h']
    # Create file
    with open('sample_file.txt', 'w') as f:
        for item in sample_data:
            f.write(item)
    # Run function
    output_data = load_text_file(input_data)
    # Assert result
    assert(output_data == ''.join(sample_data))
    # Delete file
    os.remove('sample_file.txt')