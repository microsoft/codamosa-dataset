

# Generated at 2022-06-23 18:47:48.410230
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('somekey: somevalue')) == 'somevalue'
    assert process_header_arg(KeyValueArg('somekey:')) is None
    assert process_header_arg(KeyValueArg('somekey')) is None


# Generated at 2022-06-23 18:47:52.544487
# Unit test for function load_text_file
def test_load_text_file():
    filename = 't/httpie/test_request.py'
    text = load_text_file(KeyValueArg("embed", filename))
    print(text)
    print(len(text))

# Generated at 2022-06-23 18:47:56.502083
# Unit test for function load_json
def test_load_json():
    assert load_json(None, "a") == "a"
    assert load_json(None, "{\"k1\": \"a\"}") == {"k1": "a"}
    assert load_json(None, "[1,2]") == [1,2]


# Generated at 2022-06-23 18:48:02.099150
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # Test case 1
    arg = KeyValueArg(None, 'hello', 'key', 'value')
    assert (process_query_param_arg(arg) == 'value')

    # Test case 2
    arg = KeyValueArg(None, 'hello', 'key', None)
    assert (process_query_param_arg(arg) == None)

    # Test case 3
    arg = KeyValueArg(None, 'hello', 'key', 'value1')
    assert (process_query_param_arg(arg) == 'value1')


# Generated at 2022-06-23 18:48:14.129549
# Unit test for function load_text_file
def test_load_text_file():
    path = '/Users/xiaoya/Desktop/httpie-0.5.0/test_file.txt'
    item = KeyValueArg(path, '', '')
    returned_contents = load_text_file(item)
    with open(path, 'r') as f:
        print(f.read())
        print(returned_contents)
        assert f.read() == returned_contents

# Generated at 2022-06-23 18:48:22.441559
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_item_args = [
        KeyValueArg('data', '{"a": "b", "c": {"d": "e"}}', '', '=')
    ]
    items = RequestItems()
    data = {}
    for arg in request_item_args:
        value = process_data_raw_json_embed_arg(arg)
        data[arg.key] = value

    assert data['data'] == {"a": "b", "c": {"d": "e"}}

# Generated at 2022-06-23 18:48:31.058438
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test 1: function returns a string
    request_item = {'testString': 'testString'}
    request_item_args = [KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, 'test', 'testString')]
    request = RequestItems.from_args(request_item_args)
    assert request.data == request_item

    # Test 2: function returns a list
    request_item = {'testList': ['testList1', 'testList2']}
    request_item_args = [KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, 'test', '["testList1", "testList2"]')]
    request = RequestItems.from_args(request_item_args)
    assert request.data == request_item

    # Test 3:

# Generated at 2022-06-23 18:48:33.862312
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('key', 'value', 'sep')
    assert load_text_file(item) == 'value'

# Generated at 2022-06-23 18:48:41.735583
# Unit test for function load_json
def test_load_json():
    arg = argparse.Namespace(orig=(SEPARATOR_DATA_RAW_JSON + 'key=[1,2]'))
    actual = load_json(arg, arg.orig[1:])
    expected = [1, 2]
    assert actual == expected
 
    arg = argparse.Namespace(orig=(SEPARATOR_DATA_RAW_JSON + 'key={"a": 1}'))
    actual = load_json(arg, arg.orig[1:])
    expected = {"a": 1}
    assert actual == expected


# Generated at 2022-06-23 18:48:46.864663
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg("Header;")) == ''
    with pytest.raises(ParseError) as excinfo:
        process_empty_header_arg(KeyValueArg("Header:Value"))
    assert 'Invalid item "Header:Value"' in str(excinfo.value)

# Generated at 2022-06-23 18:48:49.714008
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    key = 'key'
    value = 'value'
    actual = process_data_item_arg(KeyValueArg(key, value, ':'))
    expected = value
    assert actual == expected


# Generated at 2022-06-23 18:48:54.317826
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    path = ('/Users/arvinderkang/Desktop/'
            'Software Engineering/httpie/example.json')
    item = KeyValueArg(path, None, None, None)
    expected_output = ('{\n'
                       '    "a": 1,\n'
                       '    "b": "foo"\n'
                       '}\n')
    assert process_data_embed_file_contents_arg(item) == expected_output


# Generated at 2022-06-23 18:48:59.893725
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(key=None, value="httpie/cli/__init__.py", sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    actual_result = process_data_embed_file_contents_arg(arg)
    assert actual_result.startswith("from __future__ import absolute_import")



# Generated at 2022-06-23 18:49:05.741659
# Unit test for function load_json
def test_load_json():
    assert load_json({'orig': 'jsonfile: test_resources/test_load_json.json'}, '''{
    "foo": "bar",
    "baz": [
        "qux",
        "quxx"
    ]
}''') == {
        "foo": "bar",
        "baz": [
            "qux",
            "quxx"
        ]
    }

# Generated at 2022-06-23 18:49:12.099037
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('', '', '', '')
    assert process_data_item_arg(arg) == ''

    arg = KeyValueArg(':', '', '', '')
    assert process_data_item_arg(arg) == ''

    arg = KeyValueArg(':', '', 'key', '')
    assert process_data_item_arg(arg) == ''

    arg = KeyValueArg(':', '', 'key', 'value')
    assert process_data_item_arg(arg) == 'value'


# Generated at 2022-06-23 18:49:22.362366
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import httpie.cli.argtypes as argtypes
    import tempfile
    tmp = tempfile.NamedTemporaryFile()
    tmp.write(b'Test Test Test Test Test')
    tmp.flush()
    tmp.seek(0)
    arg = argtypes.KeyValueArg(
        'TestFile.txt',
        'TestFile.txt',
        'FormFile;TestFile.txt',
        'FormFile;TestFile.txt'
    )
    assert process_file_upload_arg(arg) == (
        'TestFile.txt',
        tmp.file,
        None,
    )
    tmp.close()

# Generated at 2022-06-23 18:49:23.945895
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(sep = SEPARATOR_HEADER, key= 'authorization', value='token')) == 'token'


# Generated at 2022-06-23 18:49:26.075859
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('test', 'value')
    assert process_data_item_arg(arg) == 'value'

# Generated at 2022-06-23 18:49:34.099470
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Input
    first = KeyValueArg('key', 'value', ';', True)
    second = KeyValueArg('key', '{ "data": "value"}', ':', False)

    # Expected output
    first_expected_output = {'key': 'value'}
    second_expected_output = {'key': {'data': 'value'}}

    # Actual output
    first_actual_output = process_data_raw_json_embed_arg(first)
    second_actual_output = process_data_raw_json_embed_arg(second)

    # Compare actual output to expected output
    assert first_expected_output == first_actual_output
    assert second_expected_output == second_actual_output


# Generated at 2022-06-23 18:49:35.289883
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('hello=world.txt', '', '')) == 'hello world'

# Generated at 2022-06-23 18:49:38.266104
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    param = KeyValueArg('sep', 'key', 'value')
    assert process_query_param_arg(param) == 'value'

# Generated at 2022-06-23 18:49:41.821416
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
	arg = KeyValueArg(key='key', value='value', sep='=', orig='key=value')

	actual = process_query_param_arg(arg)
	expected = 'value'

	assert actual == expected


# Generated at 2022-06-23 18:49:48.019543
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data_item_arguments = KeyValueArg(
        arg='order_item',
        sep=SEPARATOR_DATA_RAW_JSON,
        key='order_item',
        value='{"name": "request-bin", "count": 1.5}',
    )
    print(process_data_raw_json_embed_arg(data_item_arguments))


# Generated at 2022-06-23 18:49:57.471578
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    from httpie.cli.constants import (
        SEPARATOR_FILE_UPLOAD,
        SEPARATOR_FILE_UPLOAD_TYPE,
    )
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "file.txt")
    assert process_file_upload_arg(arg) == ("file.txt", 'rb', "text/plain")
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "file.txt;image/png")
    assert process_file_upload_arg(arg) == ("file.txt", 'rb', "image/png")


# Generated at 2022-06-23 18:50:06.233890
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg1 = KeyValueArg(None, 'test.txt', None, None)
    arg2 = KeyValueArg(None, 'test2.txt', None, None)
    arg3 = KeyValueArg('test3.txt', None, None, None)


# Generated at 2022-06-23 18:50:11.673101
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
   assert process_data_item_arg(KeyValueArg('key', 'value', 'key=value')) == 'value'
   assert process_data_item_arg(KeyValueArg('key', '', 'key=')) == ''
   assert process_data_item_arg(KeyValueArg('key', '', 'key==')) == ''
   assert process_data_item_arg(KeyValueArg('key', 'value', 'key==value')) == '=value'


# Generated at 2022-06-23 18:50:14.355837
# Unit test for function load_text_file
def test_load_text_file():
    test = "~/nonexistentfile.txt"
    value = load_text_file(test)
    assert value is None

# Generated at 2022-06-23 18:50:20.433824
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    print("Loading test and expected file")
    # Open the files as bytes to compare directly the result with the expected value
    file_expected = open("tests/unit/test_data/process_data_embed_raw_json_file_arg_expected.py", "rb")
    file_test = open("tests/unit/test_data/process_data_embed_raw_json_file_arg_test.py", "rb")
    assert file_test.read() == file_expected.read()

# Generated at 2022-06-23 18:50:31.024289
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:50:33.576373
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    origin = "my-data"
    item = KeyValueArg(None, SEPARATOR_DATA_STRING, None, origin)
    assert process_data_item_arg(item) == origin

# Generated at 2022-06-23 18:50:41.206949
# Unit test for function process_header_arg
def test_process_header_arg():
    header = KeyValueArg('name', 'Hello World', SEPARATOR_HEADER)
    header_none = KeyValueArg('name', '', SEPARATOR_HEADER)
    header_empty = KeyValueArg('name', 'Hello World', SEPARATOR_HEADER_EMPTY)
    header_empty_none = KeyValueArg('name', '', SEPARATOR_HEADER_EMPTY)

    assert process_header_arg(header) == 'Hello World'
    assert process_header_arg(header_empty) == 'Hello World'
    assert process_header_arg(header_none) is None
    assert process_header_arg(header_empty_none) is None


# Generated at 2022-06-23 18:50:47.496192
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    class A():
        def __init__(self):
            self.sep = SEPARATOR_DATA_EMBED_FILE_CONTENTS
            self.key = "asdf"
            self.value = ""
            self.orig = ""

    a = A()
    process_data_embed_file_contents_arg(a)

# Generated at 2022-06-23 18:50:57.814872
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = []
    request_item_args.append(KeyValueArg(key="Header", sep=";", value="Header"))
    request_item_args.append(KeyValueArg(key="Header2", sep=";", value="Header2"))
    request_item_args.append(KeyValueArg(key="Param", sep="&", value="Param"))
    request_item_args.append(KeyValueArg(key="Data", sep="=", value="Data"))
    request_item_args.append(KeyValueArg(key="File", sep="@", value="File"))
    request_items = RequestItems.from_args(request_item_args)
    assert(request_items.headers['Header'] == "Header")
    assert(request_items.headers['Header2'] == "Header2")

# Generated at 2022-06-23 18:50:59.650937
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    pass


# Generated at 2022-06-23 18:51:03.858161
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('test_data', "{" "\"test1\":" "\"value1\"}")
    res = process_data_embed_raw_json_file_arg(arg)
    assert(res ==  {"test1": "value1"})

# Generated at 2022-06-23 18:51:11.345498
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    filename = '/home/sunny/Documents/personal/httpie/httpie/__main__.py'
    with open(os.path.expanduser(filename), 'rb') as f:
        contents = f.read().decode()
    test_value = load_json(filename, contents)
    assert isinstance(test_value, dict)
    assert '__version__' in test_value
    assert '__all__' in test_value

# Generated at 2022-06-23 18:51:16.739533
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg(
        key=None,
        value='{"1": {"2": {"3": "4"}}}}',
        sep=SEPARATOR_DATA_RAW_JSON
    )
    assert {'1': {'2': {'3': '4'}}} == process_data_raw_json_embed_arg(item)

# Generated at 2022-06-23 18:51:19.168035
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert "test" == process_data_item_arg(KeyValueArg("first", "test"))



# Generated at 2022-06-23 18:51:23.447577
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    """ test_process_data_raw_json_embed_arg """
    arg = KeyValueArg('sep', 'key=value')
    ret = process_data_raw_json_embed_arg(arg)
    assert ret == 'value'

# Generated at 2022-06-23 18:51:27.963877
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    content = process_data_embed_file_contents_arg(KeyValueArg('@request.json', './request.json'))
    content = json.loads(content)
    print(content)


if __name__ == '__main__':
    test_process_data_embed_file_contents_arg()

# Generated at 2022-06-23 18:51:38.249552
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg.parse(
        'json;'
        '{'
        '   "aaa": "bbb",'
        '   "ccc": {"ddd": "eee"},'
        '   "fff": [1, 2, 3]'
        '}'
    )) == {
        "aaa": "bbb",
        "ccc": {"ddd": "eee"},
        "fff": [1, 2, 3],
    }

# Generated at 2022-06-23 18:51:47.126440
# Unit test for function load_json
def test_load_json():
    assert load_json('abc', 'abc') == 'abc'
    assert load_json('123', '123') == '123'
    assert load_json('true', 'true') == 'true'
    assert load_json('false', 'false') == 'false'
    assert load_json('[]', '[]') == '[]'
    assert load_json('{}', '{}') == '{}'
    # will load as string
    assert load_json('123.4', '123.4') == '123.4'
    assert load_json('123e4', '123e4') == '123e4'
    assert load_json('123e-4', '123e-4') == '123e-4'

# Generated at 2022-06-23 18:51:51.969177
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    kv = KeyValueArg()
    kv.sep = SEPARATOR_DATA_STRING
    kv.value = "value"
    kv.key = "key"
    assert process_data_item_arg(kv) == "value"


# Generated at 2022-06-23 18:51:58.331208
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    # GIVEN a JSON object
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_STRING,
        key="",
        value='{"msg": "this is a test"}'
    )

    # WHEN the function is processed
    result = process_data_item_arg(arg)

    # THEN the function should return the value
    assert(result == '{"msg": "this is a test"}')

# Generated at 2022-06-23 18:52:00.960164
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg(argstr='key', sep=':', key='key', value='value')) == 'value'



# Generated at 2022-06-23 18:52:11.743625
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    from httpie.cli.argtypes import KeyValueArg
    data = "A;B;"
    test_data = KeyValueArg(data)
    try:
        process_empty_header_arg(test_data)
    except ParseError as e:
        assert(str(e)=='Invalid item "A;B;" (to specify an empty header use `Header;`)')
    else:
        assert(False)
    data = "A;"
    test_data = KeyValueArg(data)
    assert(process_empty_header_arg(test_data)=='')
    data = "A"
    test_data = KeyValueArg(data)

# Generated at 2022-06-23 18:52:14.481454
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    request_arg = KeyValueArg(key='key1', value='value1', sep=':', orig='key:value')
    assert process_query_param_arg(request_arg) == "value1"

# Generated at 2022-06-23 18:52:24.148067
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(sep=SEPARATOR_FILE_UPLOAD,
                      key='file',
                      value='test.txt')
    assert type(process_file_upload_arg(arg)[0]) == str
    assert type(process_file_upload_arg(arg)[1]) == bytes
    assert type(process_file_upload_arg(arg)[2]) == str
    arg = KeyValueArg(sep=SEPARATOR_FILE_UPLOAD,
                      key='file',
                      value='test.txt:image/png')
    assert type(process_file_upload_arg(arg)[0]) == str
    assert type(process_file_upload_arg(arg)[1]) == bytes
    assert type(process_file_upload_arg(arg)[2]) == str

# Generated at 2022-06-23 18:52:29.212519
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    keyval = [
        KeyValueArg(key="key", value="value"),
        KeyValueArg(key="key2", value="value2")
    ]
    request = RequestItems.from_args(keyval)
    assert request.data.get("key") == "value"
    assert request.data.get("key2") == "value2"


# Generated at 2022-06-23 18:52:32.805828
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():  #pylint: disable=W0612
    arg = KeyValueArg(None, ';', None, None)
    process_empty_header_arg(arg)


# Generated at 2022-06-23 18:52:37.106471
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    kv = KeyValueArg('', 'embed', 'foo.json')
    data = load_json(kv, '{"a": 1, "b": "two"}')
    assert data == {u'a': 1, u'b': u'two'}



# Generated at 2022-06-23 18:52:40.609166
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('Header;', ';', '', '')) == ''
    with pytest.raises(ParseError):
        process_empty_header_arg(KeyValueArg('Header;', ';', '123', 'Header;123'))



# Generated at 2022-06-23 18:52:44.341593
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    kv = KeyValueArg('a', 'b', 'a:b')
    # Check whether the process_data_raw_json_embed_arg() returns a string value
    assert type(process_data_raw_json_embed_arg(kv)) == str



# Generated at 2022-06-23 18:52:54.441881
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_list = [
        KeyValueArg(Separator.DATA_RAW_JSON, "key1", 'value'),
        KeyValueArg(Separator.DATA_RAW_JSON, "key2", 'value2'),
        KeyValueArg(Separator.DATA_RAW_JSON, "key3", 'value3'),
    ]

    request_items = RequestItems.from_args(request_list)
    json_data = request_items.data.data

    assert(json_data.pop('key1') == 'value')
    assert(json_data.pop('key2') == 'value2')
    assert(json_data.pop('key3') == 'value3')

# Generated at 2022-06-23 18:53:03.078202
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    json_data = """{
        "a": 1,
        "b": "str",
        "c": true,
        "d": null,
        "e": ["foo", 123, {}, [], false, 1.23],
        "f": {"foo": "bar", "bar": "baz"}
    }"""

    result = process_data_raw_json_embed_arg(
        KeyValueArg(
            key=None,
            value=None,
            sep=SEPARATOR_DATA_RAW_JSON,
            orig=json_data
        )
    )

# Generated at 2022-06-23 18:53:06.604983
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_HEADER_EMPTY,
        value='',
        orig='Arg1;'
    )
    assert process_empty_header_arg(arg) == ''

# Generated at 2022-06-23 18:53:16.171422
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import io
    import os
    import pytest
    from httpie.cli.argtypes import KeyValueArg

    data = [
        (("foo@/dev/stdin",), "foo", os.path.abspath("/dev/stdin"), "application/octet-stream"),
        (("foo@https://example.com/",), "foo", "https://example.com/", "application/octet-stream"),
        (("foo@https://example.com/;type",), "foo", "https://example.com/", "type")
    ]

    for args, filename, file_path, mime_type in data:
        print("Testing args: ", args)
        # Create an arg with '@' separator
        arg = KeyValueArg(clean_key_value_arg(args)[0])
        # Create

# Generated at 2022-06-23 18:53:22.509115
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_items = RequestItems.from_args([KeyValueArg('Accept', 'application/json')])
    assert(request_items.headers['Accept'] == 'application/json')
    assert(request_items.headers['User-Agent'] == None)
    assert(request_items.data == {})
    assert(request_items.files == {})
    assert(request_items.params == {})
    assert(request_items.multipart_data == {})

# Generated at 2022-06-23 18:53:31.186380
# Unit test for function load_json
def test_load_json():
    r"""Test the function load_json."""
    import pytest

    test_data = [
        ('{"a":1}', {"a": 1}),
        ('\u00a5', ValueError),
        ('[1,2,3]', [1, 2, 3]),
        ('{"a":1, "b":2}', {"a": 1, "b": 2}),
    ]
    for value, expected in test_data:
        actual = load_json(KeyValueArg(value), value)
        if expected == ValueError:
            with pytest.raises(ValueError):
                load_json(KeyValueArg(value), value)
        else:
            assert actual == expected
    print('unit test pass')

# Generated at 2022-06-23 18:53:33.862374
# Unit test for function load_text_file
def test_load_text_file():
    assert(load_text_file(KeyValueArg('text','/tmp/httpie/test.txt')) == "Hello World\n")

# Generated at 2022-06-23 18:53:35.729672
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('"page"==100')
    assert process_query_param_arg(arg) == '100'

# Generated at 2022-06-23 18:53:42.124354
# Unit test for function load_json
def test_load_json():
    arg = arg_parse_error = None
    contents = '{"name":"Tuan N. Phan"}'
    try:
        value = load_json(arg, contents)
        assert value == {'name': 'Tuan N. Phan'}
    except ParseError as e:
        arg_parse_error = e

    try:
        value = load_json(arg, '{}')
        assert value == {}
    except ParseError as e:
        arg_parse_error = e

    try:
        value = load_json(arg, '{"name":{"first":"Tuan", "last":"Phan"}}')
        assert value == {'name': {'first': 'Tuan', 'last': 'Phan'}}
    except ParseError as e:
        arg_parse_error = e


# Generated at 2022-06-23 18:53:44.825803
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    from httpie.cli.argtypes import KeyValueArg
    assert process_data_item_arg(KeyValueArg('a=b')) == 'b'

# Generated at 2022-06-23 18:53:51.029220
# Unit test for function process_header_arg
def test_process_header_arg():
    # Arrange
    expected = {'name': 'value'}
    # Act
    actual = process_header_arg(KeyValueArg.from_str('name: value'))
    # Assert
    assert actual == expected
    assert actual != process_header_arg(KeyValueArg.from_str(':'))


# Generated at 2022-06-23 18:53:59.372231
# Unit test for function load_json
def test_load_json():
    import json
    print(json.dumps(load_json_preserve_order('{"a":1,' 
                                              '"b":2,' 
                                              '"c":3}'),indent=2))
    print(json.dumps(load_json_preserve_order('{"a":1,' 
                                              '"b":{"d":4,' 
                                                   '"e":5}, ' 
                                              '"c":3}'),indent=2))
    print(json.dumps(load_json_preserve_order('{"a":1,' 
                                              '"b":[6,7,8], ' 
                                              '"c":3}'),indent=2))

# Generated at 2022-06-23 18:54:06.069534
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    a = RequestItems()
    assert process_query_param_arg(KeyValueArg('', '', 'key')) == 'key'
    assert process_query_param_arg(KeyValueArg('', '', 'key;')) == None
    assert process_query_param_arg(KeyValueArg('', '', 'key;value')) == None
    assert process_query_param_arg(KeyValueArg('', '', '@file')) == '@file'
    assert process_query_param_arg(KeyValueArg('', '', 'key;@file')) == '@file'

# Generated at 2022-06-23 18:54:13.256224
# Unit test for function load_json
def test_load_json():
    item = KeyValueArg(None, "key", "value", "--data", None)
    contents = "{'my': {'json': 'object'}"
    with pytest.raises(ParseError):
        load_json(item,contents)
    contents = '{"my": {"json": "object"}}'
    loaded_json = load_json(item,contents)
    assert loaded_json == json.loads(contents)

# Generated at 2022-06-23 18:54:20.761682
# Unit test for constructor of class RequestItems
def test_RequestItems():
    data = key.value = '{ "key" : "val" }'
    what = key.key = 'what'
    headers = key.sep = SEPARATOR_HEADER
    data = key.key = 'data'
    value = key.value = 'val'
    foo = key.key = 'foo'
    bar = key.value = 'bar'
    key = key.sep = SEPARATOR_QUERY_PARAM
    file = key.key = 'file'
    baz = key.value = 'baz'
    key = key.sep = SEPARATOR_FILE_UPLOAD
    request_item_args = [data, headers, value, foo, bar, key, file, baz]
    requestItems = RequestItems.from_args(request_item_args)

# Generated at 2022-06-23 18:54:24.360001
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import json
    import io
    import pytest
    input = io.StringIO('{"a":10}')
    content = input.read()
    output = process_data_raw_json_embed_arg(content)
    assert output == {"a": 10}



# Generated at 2022-06-23 18:54:29.154045
# Unit test for function load_text_file
def test_load_text_file():
    mock_load_text_file = load_text_file('mock_load_text_file')
    with open('mock_load_text_file', 'w') as f:
        json.dump({'mock': 'loading text file'}, f)
    assert mock_load_text_file['mock'] == 'loading text file'


# Generated at 2022-06-23 18:54:31.225191
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    args=KeyValueArg('Header;','Hello')
    assert process_empty_header_arg(args)==None


# Generated at 2022-06-23 18:54:34.034291
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key_value_arg = KeyValueArg("1", "value")
    assert process_data_embed_file_contents_arg(key_value_arg) == "value"


# Generated at 2022-06-23 18:54:46.741092
# Unit test for function load_text_file
def test_load_text_file():
    key = 'test'
    value = 'test'
    request_item = KeyValueArg(key=key, value=value, sep='=')
    assert request_item.key == key
    assert request_item.value == value
    assert process_data_item_arg(request_item) == value
    key = 'test'
    value = ''
    request_item = KeyValueArg(key=key, value=value, sep='=')
    assert request_item.key == key
    assert request_item.value == value
    assert process_data_item_arg(request_item) == value
    key = 'test'
    value = 'test'
    sep = ':'
    request_item = KeyValueArg(key=key, value=value, sep=sep)
    assert request_item.key == key

# Generated at 2022-06-23 18:54:49.627439
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    process_data_raw_json_embed_arg("")

test_process_data_raw_json_embed_arg()

# Generated at 2022-06-23 18:54:57.093335
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg()
    arg.orig = '{"key": "value"}'
    arg.value = load_text_file(arg)
    arg.key = arg.value
    arg.sep = SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    rst = process_data_embed_raw_json_file_arg(arg)
    assert type(rst) == dict
    assert rst == {'key': 'value'}

# Generated at 2022-06-23 18:55:00.124643
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='key:value', key=None, value='value', sep=None)
    item.value = './test_load_text_file.txt'
    assert '{"key": "value"}' == load_text_file(item)

# Generated at 2022-06-23 18:55:11.142704
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestHeadersDict
    # test item with form request
    items = RequestItems.from_args([
        KeyValueArg(orig='foo=bar', sep='=', key='foo', value='bar'),
        KeyValueArg(orig='baz', sep='=', key='baz', value=None),
    ])
    # test item with json request
    items = RequestItems.from_args([
        KeyValueArg(orig='foo=bar', sep='=', key='foo', value='bar'),
        KeyValueArg(orig='baz', sep='=', key='baz', value=None),
    ], False)



# Generated at 2022-06-23 18:55:14.100724
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, 'data', None)) == 'data'

# Generated at 2022-06-23 18:55:19.565718
# Unit test for function load_text_file
def test_load_text_file():
    file_name = '../cli/tests/fixtures/text_file.sh'
    with open(os.path.expanduser(file_name), 'rb') as f:
        assert f.read().decode() == load_text_file(
            KeyValueArg(key='foo', sep='=', value=file_name, orig=file_name)
        )

# Generated at 2022-06-23 18:55:22.757653
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        'key',
        '-d',
        '@',
        'arg.value'
    )
    print(process_data_embed_file_contents_arg(arg))


# Generated at 2022-06-23 18:55:26.549880
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(arg='a=b') == 'b'
    assert process_header_arg(arg='a') == None
    assert process_header_arg(arg='a=') == ''


# Generated at 2022-06-23 18:55:31.580774
# Unit test for function process_header_arg
def test_process_header_arg():
    # If a header contains value
    header_arg1 = KeyValueArg(":cookie", "name=john")
    assert(process_header_arg(header_arg1)) == "name=john"
    
    # If a header doesn't contain any value
    header_arg2 = KeyValueArg(":content-type")
    assert(process_header_arg(header_arg2)) == None



# Generated at 2022-06-23 18:55:35.918742
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    a = KeyValueArg(0, "--data", "foo", "bar")
    assert(process_data_item_arg(a) == "foo")    
    assert(a.value == "foo")


# Generated at 2022-06-23 18:55:38.232008
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg('test')
    except ParseError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 18:55:42.701576
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg('data', '{"a": 1}', 'data')
    value = process_data_raw_json_embed_arg(item)
    print(value)


if __name__ == '__main__':
    test_process_data_raw_json_embed_arg()

# Generated at 2022-06-23 18:55:50.292609
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    def dict_of_values(arg_name, arg_value):
        return {
            'orig': arg_name,
            'key': None,
            'sep': None,
            'value': arg_value,
        }

    data_value1 = {
        'test_key': 'test_value',
        'test_key2': 'test_value2',
        'test_key3': 'test_value3',
    }
    test_data = [
        (dict_of_values("test_key", "test_value"), "test_value"),
        (dict_of_values("test_key", "test_value2"), "test_value2"),
        (dict_of_values("test_key", "test_value3"), "test_value3"),
    ]


# Generated at 2022-06-23 18:55:58.787008
# Unit test for function load_json
def test_load_json():
    #print("RUNNING TEST FOR load_json()")
    from httpie.input import KeyValueArg
    from httpie.cli.dicts import RequestDataDict
    
    # test base case
    #print("TEST #1")
    string = '{"foo": "bar"}'
    kvarg = KeyValueArg(string, 'arg')
    test_kv = load_json(kvarg, string)
    assert test_kv == {'foo': 'bar'}

    # test case with spaces
    #print("TEST #2")
    string = '{"foo": "bar"}'
    kvarg = KeyValueArg(string)
    test_kv = load_json(kvarg, string)
    assert test_kv == {'foo': 'bar'}

    # test case with empty

# Generated at 2022-06-23 18:56:00.626546
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    ret = process_data_item_arg('foo=bar')
    assert(ret == 'bar')

# Generated at 2022-06-23 18:56:05.620855
# Unit test for function process_header_arg
def test_process_header_arg():
    args = KeyValueArg(b'Header:value', 'Header', 'Header:value', ':', 'Header', 'value')
    assert process_header_arg(args) == 'value'
    args = KeyValueArg(b'Header;', 'Header', 'Header;', ';', 'Header', '')
    assert process_header_arg(args) == None

# Generated at 2022-06-23 18:56:15.380182
# Unit test for function load_json
def test_load_json():
    item = KeyValueArg('')
    value = load_json(item, '{ "a": "b", "c": [1,2,3] }')
    assert value == {'a': 'b', 'c': [1, 2, 3]}
    # Test that an exception is thrown on invalid json
    try:
        value = load_json(item, '{ "a": "b", "c": [1,2,3}')
        assert False
    except Exception as e:
        assert True
    # Test that an exception is thrown on invalid json
    try:
        value = load_json(item, 'This is not json')
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-23 18:56:18.416825
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(separator=':', key='Authorization', value='Bearer abc123')
    x = process_data_embed_raw_json_file_arg(arg)
    print(x)
    assert x == 'abc123'

# Generated at 2022-06-23 18:56:26.468889
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    filename = "sample.json"
    filedata = '{"key1":"value1","key2":"value2"}'
    try:
        f = open(filename, "w+")
        f.write(filedata)
    except IOError as e:
        print('"%s": %s' % (arg.orig, e))
    KeyValArg = collections.namedtuple('KeyValueArg', ['value', 'orig'])
    arg = KeyValArg(filename, filedata)
    assert process_data_embed_file_contents_arg(arg) == filedata

# Generated at 2022-06-23 18:56:28.504376
# Unit test for function load_text_file
def test_load_text_file():
    # For functional code coverage
    load_text_file(KeyValueArg('', '', '', ''))

# Generated at 2022-06-23 18:56:40.704903
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg_file_upload = KeyValueArg(
        'test.jpg',
        SEPARATOR_FILE_UPLOAD,
        'test.jpg',
        SEPARATOR_FILE_UPLOAD,
        'test.jpg',
    )
    arg_file_upload_with_type = KeyValueArg(
        'test.jpg:image/jpeg',
        SEPARATOR_FILE_UPLOAD,
        'test.jpg',
        SEPARATOR_FILE_UPLOAD,
        'test.jpg:image/jpeg',
    )

# Generated at 2022-06-23 18:56:45.913986
# Unit test for function load_json
def test_load_json():
    # this is a basic test for function load_json(),
    # there will be more unit tests in test.py
    arg = KeyValueArg('foo', 'bar', ';')
    content = '{"foo": "bar"}'
    assert load_json(arg, content) == {"foo": "bar"}

# Generated at 2022-06-23 18:56:47.669901
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(0, 'Content-Type', 'application/json')) == 'application/json'


# Generated at 2022-06-23 18:56:51.346956
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    args = KeyValueArg("Header;", "", "")
    process_empty_header_arg(args)
    args = KeyValueArg("Header;", "123", "")
    with pytest.raises(ParseError):
        process_empty_header_arg(args)

# Generated at 2022-06-23 18:57:02.815545
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    print(process_data_raw_json_embed_arg(KeyValueArg(orig="--data-raw-json", key="-d", sep="=", value='{"name": "test"}')))
    print(process_data_raw_json_embed_arg(KeyValueArg(orig="--data-raw-json", key="-d", sep="=", value='["name", "test"]')))
    print(process_data_raw_json_embed_arg(KeyValueArg(orig="--data-raw-json", key="-d", sep="=", value='name: test')))
    print(process_data_raw_json_embed_arg(KeyValueArg(orig="--data-raw-json", key="-d", sep="=", value='test')))


# Generated at 2022-06-23 18:57:12.599133
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'some_file.txt'
    mime_type = 'text/plain'
    f = open(os.path.expanduser(filename), 'rb')
    assert process_file_upload_arg(KeyValueArg(filename, 'file@'+filename+';'+mime_type, 'file@'+filename+';'+mime_type)) == (
        os.path.basename(filename),
        f,
        mime_type,
    )


if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-23 18:57:15.442812
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(orig='Item', key='Item', sep=';', value='Item')
    try:
        value = process_empty_header_arg(arg)
    except ParseError:
        value = None
    assert value is None


# Generated at 2022-06-23 18:57:16.004529
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    return "hello"

# Generated at 2022-06-23 18:57:21.106622
# Unit test for function load_text_file
def test_load_text_file():
    separator_data_string = '='
    arg = KeyValueArg(separator_data_string, '=', 'foo', 'bar')
    assert load_text_file(arg) == 'bar'

# Generated at 2022-06-23 18:57:23.393479
# Unit test for constructor of class RequestItems
def test_RequestItems():
    item = RequestItems()
    print(item.headers)
    print(item.params)
    print(item.data)
    print(item.files)
    print(item.multipart_data)

#test_RequestItems()

# Generated at 2022-06-23 18:57:26.003719
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    line = "--form test.txt"
    arg = KeyValueArg.parse(line)
    print(arg)
    print(process_file_upload_arg(arg))


if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-23 18:57:31.831960
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Generate random json file
    import json, uuid
    data = {"employeeid": uuid.uuid4().int, "employeename": 'name' + str(uuid.uuid4().int)}
    json = json.dumps(data)
    file_name = 'test.json'
    file = open(file_name,'w') 
    file.write(json) 
    file.close() 
    process_data_raw_json_embed_arg(file)

# Generated at 2022-06-23 18:57:35.866942
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # headers, data, files, params, multipart_data
    requestItems = RequestItems()
    assert requestItems.headers != None
    assert requestItems.data != None
    assert requestItems.files != None
    assert requestItems.params != None
    assert requestItems.multipart_data != None

test_RequestItems()

# Generated at 2022-06-23 18:57:39.780260
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    value = 'test_value'
    arg = KeyValueArg(
        '-d', 'key', value
    )
    assert process_data_item_arg(arg) == value



# Generated at 2022-06-23 18:57:44.974247
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("k1", "v1", ":")
    try:
        process_empty_header_arg(arg)
    except ParseError as e:
        assert str(e) == 'Invalid item "k1:v1" (to specify an empty header use `Header;`)'
    
# unit test for function process_data_embed_file_contents_arg

# Generated at 2022-06-23 18:57:52.276841
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg
    
    input = KeyValueArg(orig = "foo=@a.txt",
    key = "foo",
    sep = "=",
    value = "a.txt",
    sep_used = "=",
    value_orig ="@a.txt")

    a = process_data_embed_raw_json_file_arg(input)
    assert a == {"name" : "jack" , "age" : 12}