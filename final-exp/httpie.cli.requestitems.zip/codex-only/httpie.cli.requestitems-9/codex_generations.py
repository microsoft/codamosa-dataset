

# Generated at 2022-06-23 18:47:49.896740
# Unit test for function load_text_file
def test_load_text_file():
    file = 'local/__init__.py'
    text = load_text_file(file)
    assert text[:12] == 'from .core import '
    assert text[-2:] == '\n'

# Generated at 2022-06-23 18:47:59.714531
# Unit test for function load_text_file
def test_load_text_file():
    path = "/home/user/file.txt"
    file_contents = "file contents"

    class Item:
        def __init__(self):
            self.value = path
            self.orig = path

    expected_contents = file_contents.encode()

    def mock_open(path, mode):
        file = mock.mock_open(read_data=expected_contents)
        file.return_value.read.return_value = expected_contents
        return file(path, mode)

    with mock.patch("builtins.open", mock_open):
        contents = load_text_file(Item())

    assert contents == file_contents

# Generated at 2022-06-23 18:48:04.244076
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('key' , 'value', ':')
    assert process_header_arg(arg) == 'value'
    arg = KeyValueArg('key' , None, ':')
    assert process_header_arg(arg) == None

# Generated at 2022-06-23 18:48:14.377266
# Unit test for function load_json
def test_load_json():
    data_raw_json = '{"a": "b"}'
    data = load_json('', data_raw_json)
    assert data == {"a":"b"}

    data_raw_json = '{"a": "b","c": "d"}'
    data = load_json('', data_raw_json)
    assert data == {"a": "b", "c": "d"}

    data_raw_json = '[{"a": "b"},{"c": "d"}]'
    data = load_json('', data_raw_json)
    assert data == [{"a": "b"}, {"c": "d"}]

# test for function load_text_file

# Generated at 2022-06-23 18:48:21.129450
# Unit test for function load_text_file
def test_load_text_file():
    f = open("test_file.txt","w")
    f.write("This is a test text file")
    f.close()
    item = KeyValueArg("@test_file.txt",None,"test_file.txt")
    assert load_text_file(item) == "This is a test text file"
    os.remove("test_file.txt")

# Generated at 2022-06-23 18:48:25.784763
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    # process_data_item_arg test
    print(process_data_item_arg(KeyValueArg(key='key', sep=':', value='value')))
    print(process_data_item_arg(KeyValueArg(key='test', sep=':', value='test')))


# Generated at 2022-06-23 18:48:30.636164
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key='username', sep='=', value='admin')
    assert 'admin' == process_data_item_arg(arg)
    arg = KeyValueArg(key='username', sep='=', value='admi')
    assert 'admi' == process_data_item_arg(arg)

# Generated at 2022-06-23 18:48:42.351512
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestJSONDataDict
    from httpie.cli.exceptions import ParseError
    from json import loads
    from unittest.mock import patch, mock_open

    argument = KeyValueArg("data", "=", "file.json")
    json_string = """
        {
            "name": "John",
            "age": 30,
            "cars": [
                { "name": "Ford", "models": ["Fiesta", "Focus", "Mustang"] },
                { "name": "BMW", "models": ["320", "X3", "X5"] },
                { "name": "Fiat", "models": ["500", "Panda"] }
            ]
        }"""


# Generated at 2022-06-23 18:48:47.876420
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    from tempfile import NamedTemporaryFile

    file_size = 1000

    # Create a temporary file
    temp_file = NamedTemporaryFile(delete = False)
    temp_file.write(bytes(file_size))
    temp_file.close()

    # Test process_file_upload_arg
    arg = KeyValueArg(b'file;', b'@' + temp_file.name, None)
    filename, f, mime_type = process_file_upload_arg(arg)
    uploaded_size = sum(1 for _ in f)
    assert(filename == os.path.basename(temp_file.name))
    assert(uploaded_size == file_size)

# Generated at 2022-06-23 18:48:50.658947
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg(KeyValueArg(value="@test.json")) == '{\n  "a": 1,\n  "b": 2\n}'

# Generated at 2022-06-23 18:48:53.869929
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_arg = KeyValueArg('test_separator', 'test_key', 'test_value', 'test_orig')
    assert process_data_item_arg(test_arg) == 'test_value'


# Generated at 2022-06-23 18:48:55.834505
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('key =value1')
    value = process_query_param_arg(arg)
    assert value == "value1"

# Generated at 2022-06-23 18:48:59.123282
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("")
    with pytest.raises(ParseError):
        load_text_file(item)
    item.value = "README.md"
    load_text_file(item)

# Generated at 2022-06-23 18:49:09.931600
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import httpie.cli.argtypes as argtypes
    from httpie.cli.constants import SEPARATOR_DATA_RAW_JSON
    import httpie.cli.dicts as dicts


    class Fake(argtypes.KeyValueArg):
        pass

    fake = Fake()
    fake.key = "Red"
    fake.value = "[1,2,3]"
    fake.orig = "[1,2,3]"
    fake.sep = SEPARATOR_DATA_RAW_JSON
    value = process_data_raw_json_embed_arg(fake)
    ret = dicts.RequestJSONDataDict(value)

    expected = '[1, 2, 3]'
    actual = ret["Red"]

    assert actual == expected, "actual: {}, expected: {}".format(actual, expected)


# Generated at 2022-06-23 18:49:14.507806
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    args = KeyValueArg(orig="::file: /temp/test.json",
                       key=":",
                       value="/temp/test.json",
                       sep="::",
                       type="file")
    data = process_data_embed_raw_json_file_arg(args)
    assert data

# Generated at 2022-06-23 18:49:17.954822
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg("name", "value", ",")
    value = load_json(arg, arg.value)
    assert value == "value"


# Generated at 2022-06-23 18:49:27.739365
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    os.environ['TERMINAL_COLUMNS'] = "10"
    arg1 = 'test_data/test1.json'
    expected1 = '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    actual1 = process_data_embed_raw_json_file_arg(arg1)
    assert expected1 == actual1

    arg2 = 'test_data/test2.json'
    expected2 = {"a": 1, "b": 2, "c": 3}
    actual2 = process_data_embed_raw_json_file_arg(arg2)
    assert expected2 == actual2

# Generated at 2022-06-23 18:49:31.407312
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg("key", "value", None)
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == 'value'

# Generated at 2022-06-23 18:49:33.433868
# Unit test for function load_text_file
def test_load_text_file():
    # Act
    line = load_text_file(KeyValueArg('', 'HelloWorld'))

    # Assert
    assert line == 'HelloWorld'



# Generated at 2022-06-23 18:49:37.569165
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(SEPARATOR_HEADER_EMPTY, '', '');
    assert(process_empty_header_arg(arg) == '')

    arg = KeyValueArg(SEPARATOR_HEADER_EMPTY, '', 'value');
    try:
        process_empty_header_arg(arg)
        assert(1 == 0)
    except ParseError as e:
        assert(str(e) == 'Invalid item ":" (to specify an empty header use `Header;`)')

# Generated at 2022-06-23 18:49:39.451567
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key="Test-Empty-Header", value="")
    assert process_empty_header_arg(arg) == ""

# Generated at 2022-06-23 18:49:41.388506
# Unit test for function load_json
def test_load_json():
    load_json(KeyValueArg('a', 'b', ':'), '{"a":1}')



# Generated at 2022-06-23 18:49:52.655142
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'README.md'
    mime_type = 'application/octet-stream'
    filename_plus_mime_type = '{};{}'.format(filename, mime_type)
    assert ('README.md', open(os.path.expanduser(filename), 'rb'), mime_type) == process_file_upload_arg(
        KeyValueArg(None, ':', 'f', filename_plus_mime_type)
    )
    assert ('README.md', open(os.path.expanduser(filename), 'rb'), None) == process_file_upload_arg(
        KeyValueArg(None, ':', 'f', filename)
    )



# Generated at 2022-06-23 18:49:55.740614
# Unit test for function load_text_file
def test_load_text_file():
    import httpie.cli.args
    arg = httpie.cli.args.KeyValueArg('name', 'value')
    print(load_text_file(arg))

# Generated at 2022-06-23 18:50:00.624016
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    item = KeyValueArg('Header;') # should be decoded into `Header`
    assert process_empty_header_arg(item) is None

    item = KeyValueArg('Header;value') # should raise an exception
    try:
        process_empty_header_arg(item)
    except ParseError:
        pass
    else:
        raise AssertionError('test failed')

# Generated at 2022-06-23 18:50:04.161576
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems()
    assert instance.headers == {}
    assert instance.data == {}
    assert instance.files == {}
    assert instance.params == {}
    assert instance.multipart_data == {}


#Unit test for "from_args" method of class RequestItems

# Generated at 2022-06-23 18:50:06.252893
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('hello', 'world')
    assert 'world' == process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-23 18:50:15.364119
# Unit test for function load_json

# Generated at 2022-06-23 18:50:25.990814
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    filename = 'test.json'
    with open(filename, 'w') as f:
        f.write('{"name": "httpie"}')

    arg = KeyValueArg('name', SEPARATOR_DATA_EMBED_RAW_JSON_FILE, filename)
    assert process_data_embed_raw_json_file_arg(arg) == {'name': 'httpie'}

    with open(filename, 'w') as f:
        f.write('{"name": "httpie", "1": 1, "empty": "", "empty2": ""}')

    arg = KeyValueArg('name', SEPARATOR_DATA_EMBED_RAW_JSON_FILE, filename)

# Generated at 2022-06-23 18:50:27.423332
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert RequestItems

#Unit tests for method from_args of class RequestItems

# Generated at 2022-06-23 18:50:31.540575
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('a', 'b', ';')
    assert process_header_arg(arg) == 'b'
    arg = KeyValueArg('a', '', ';')
    assert process_header_arg(arg) is None


# Generated at 2022-06-23 18:50:32.969236
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    item = KeyValueArg('k', 'v', 'k==v')
    assert 'v' == process_query_param_arg(item)

# Generated at 2022-06-23 18:50:35.764911
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key=None, value=None, sep=None, orig=None)
    assert isinstance(arg, KeyValueArg)



# Generated at 2022-06-23 18:50:41.417886
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems()
    assert isinstance(items.headers, RequestHeadersDict)
    assert isinstance(items.data, RequestJSONDataDict)
    assert isinstance(items.files, RequestFilesDict)
    assert isinstance(items.params, RequestQueryParamsDict)
    assert isinstance(items.multipart_data, MultipartRequestDataDict)

print('Test class RequestItems successfully')

# Generated at 2022-06-23 18:50:49.979584
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = []
    arg.append(KeyValueArg(sep=SEPARATOR_QUERY_PARAM, key='query', value='haha'))
    arg.append(KeyValueArg(sep=SEPARATOR_QUERY_PARAM, key='hello', value='world'))
    test_obj = RequestItems.from_args(arg)
    assert test_obj.params['query'] == 'haha'
    assert test_obj.params['hello'] == 'world'



# Generated at 2022-06-23 18:50:53.134412
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='data', sep='=', orig='data=test.json', value='test.json')
    process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-23 18:51:01.435770
# Unit test for function load_json
def test_load_json():
    from . import test_parse
    expected = {
        'name': 'Jack',
        'age': 26,
        'is_employee': True

    }

    test_case = {
        'name': 'Jack',
        'age': '26',
        'is_employee': 'True'
    }

    for key in expected:
        assert expected[key] == test_parse(test_case)[key]

# Generated at 2022-06-23 18:51:03.946349
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = '--data'
    value = '{"key":"value"}'
    assert process_data_raw_json_embed_arg(arg,value) == {"key":"value"}

# Generated at 2022-06-23 18:51:10.111051
# Unit test for function load_text_file
def test_load_text_file():
    # test to make sure that path is correctly processed
    # to handle symbolic links
    path = '/path/to/file.txt'
    path_abs = os.path.abspath(path)
    path_abs_processed = os.path.expanduser(path)
    assert path_abs == path_abs_processed

# Generated at 2022-06-23 18:51:11.807007
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    result = process_data_embed_file_contents_arg(KeyValueArg('@testFile;'))
    print(result)

# Generated at 2022-06-23 18:51:14.398739
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(':', ':', '')
    assert process_empty_header_arg(arg) == ''

# Generated at 2022-06-23 18:51:18.274522
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg(
        key='User-Agent',
        value='httpie',
        orig='User-Agent',
        sep=':'
    )
    assert process_header_arg(header_arg) == 'httpie'



# Generated at 2022-06-23 18:51:21.341843
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    l=[KeyValueArg('text', 'Test.txt', '@')]
    assert process_data_embed_file_contents_arg(l[0]) == 'Testing\n'

# Generated at 2022-06-23 18:51:23.369401
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('foo=bar')
    assert 'bar' == process_query_param_arg(arg)


# Generated at 2022-06-23 18:51:27.229928
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('foo'+SEPARATOR_DATA_EMBED_FILE_CONTENTS+'bar', '', '', '')
    assert process_data_embed_file_contents_arg(arg) is not None

# Generated at 2022-06-23 18:51:36.042615
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    parse_error_list = [
        "test.txt",
        "test.3f2e2ef2.txt",
        "test.txt.csv",
        "test.pl",
        "test.ps1",
        "test.py",
        "test.sh",
        "test.json",
        "test.xml",
        "test.yaml",
    ]
    for item in parse_error_list:
        try:
            process_data_embed_file_contents_arg(item)
        except ParseError:
            pass
        except Exception as e:
            print(e)
            assert False, "invalid input"

# Generated at 2022-06-23 18:51:39.383358
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    key = 'k'
    value = 'v'
    arg = KeyValueArg(key, value, None)
    assert process_data_item_arg(arg) == value


# Generated at 2022-06-23 18:51:47.823539
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    print(process_query_param_arg(KeyValueArg(None, None, "bar", '=')))
    print(process_query_param_arg(KeyValueArg(None, None, "foo", '=')))
    print(process_query_param_arg(KeyValueArg(None, None, "s1", '=')))
    print(process_query_param_arg(KeyValueArg(None, None, "s2", '=')))
    print(process_query_param_arg(KeyValueArg(None, None, "s3", '=')))
    print(process_query_param_arg(KeyValueArg(None, None, "s4", '=')))
    print(process_query_param_arg(KeyValueArg(None, None, "bar", ':')))

# Generated at 2022-06-23 18:51:55.098529
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    line='@{"data": [{"id": 123, "name": "wc"}]}'
    arg = KeyValueArg(
        orig='',
        sep='=',
        key='data',
        value='{"data": [{"id": 123, "name": "wc"}]}'
    )
    assert process_data_embed_raw_json_file_arg(arg) == [{'id': 123, 'name': 'wc'}]

# Generated at 2022-06-23 18:51:58.662454
# Unit test for function process_header_arg
def test_process_header_arg():
    # default value
    assert process_header_arg(KeyValueArg('a', ':')) == None
    # some value
    assert process_header_arg(KeyValueArg('a', ':b')) == 'b'


# Generated at 2022-06-23 18:52:06.352175
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file = './test/data/test_file.txt'
    mime_type = 'plain/text'
    data = b'I am a test file :-)\n'

    item = KeyValueArg(SEPARATOR_FILE_UPLOAD, file, None, None)
    filename, f, mime_type = process_file_upload_arg(item)

    assert(filename == 'test_file.txt')
    assert(f.read() == data)
    assert(mime_type == get_content_type(file))


# Generated at 2022-06-23 18:52:08.108425
# Unit test for function load_json
def test_load_json():
    assert load_json(KeyValueArg(None, '', ''), '{"a": 1}') == {"a": 1}


# Generated at 2022-06-23 18:52:10.421864
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    contents = process_data_embed_file_contents_arg('file.jpg')
    assert contents == 'dummycontent'

# Generated at 2022-06-23 18:52:13.488171
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # What input produces the output?
    arg = KeyValueArg(sep='', key='', orig='', value='')
    contents = arg.value
    value = load_json(arg, contents)
    assert value == ''

# Generated at 2022-06-23 18:52:21.162274
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.cli.items import RequestItems
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestJSONDataDict
    # as form
    request_item_args = [
        KeyValueArg(
            key="src",
            value="/home/admin_025/rq.py",
            sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
            orig="src=@/home/admin_025/rq.py"
        )
    ]
    request_items = RequestItems.from_args(request_item_args, as_form=True)
    assert isinstance(request_items.data, RequestDataDict)

# Generated at 2022-06-23 18:52:32.913066
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    import argparse
    # Test when file exists
    json_file_name = "test.json"
    json_file = open(json_file_name, "w+")
    json_file.write("""{"1":"a","2":"b"}""")
    json_file.close()
    arg = argparse.Namespace(
        headers=None,
        form=None,
        data=None,
        files=None,
        params=None,
        json=None,
        auth=None,
        url=None,
        method=None,
        key="",
        value=json_file_name,
        sep="",
        orig=json_file_name,
        verify=False)

    result = process_data_embed_file_contents_arg(arg)

# Generated at 2022-06-23 18:52:39.429330
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    with open('test_data_embed_raw_json_file_arg.json', 'w') as f:
        json.dump({"a": 1}, f)
    arg = KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, "test",
                      'test_data_embed_raw_json_file_arg.json')
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1}

test_process_data_embed_raw_json_file_arg()


# Generated at 2022-06-23 18:52:41.109654
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('k', 'v')) == 'v'

# Generated at 2022-06-23 18:52:48.826225
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_file_name = "arg.json"
    json_data = '{"a":1}'
    json_file = open(json_file_name, 'w+')
    json_file.write(json_data)
    json_file.seek(0)
    json_arg = KeyValueArg()
    json_arg.value = json_file_name
    json_data_ret_val = process_data_embed_raw_json_file_arg(json_arg)
    assert json_data_ret_val == json.loads(json_data)
    os.remove(json_file_name)

# Generated at 2022-06-23 18:52:59.648627
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    path = "./test_files/test.json"
    # Open the file and read the data
    f = open(path, 'rb')
    f_data = f.read()
    f.close()

    # Give the filename and the separator
    argument = KeyValueArg("", ";", path)
    # Call the function
    filename, f_processed, mime_type = process_file_upload_arg(argument)

    # Compare the file names
    assert(os.path.basename(path) == filename)
    # compare the file data
    assert(f_data == f_processed.read())
    # compare the content-type
    assert(get_content_type(path) == mime_type)

# Generated at 2022-06-23 18:53:11.223514
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # There are 2 rules, they are:
    # - process_header_arg
    # - process_empty_header_arg
    # - process_query_param_arg
    # - process_file_upload_arg
    # - process_data_item_arg
    # - process_data_embed_file_contents_arg
    # - process_data_raw_json_embed_arg
    # - process_data_embed_raw_json_file_arg

    # test process_header_arg
    # If there is a value
    test_header_arg1 = KeyValueArg(sep=SEPARATOR_HEADER, key='test_header_arg1', value='value')
    assert process_header_arg(test_header_arg1) == 'value'

    # If there is no value
    test_header_arg

# Generated at 2022-06-23 18:53:19.483866
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    class arg():
        sep = ';'
        key = ''
        value = ''
        orig = ''
    arg.value = "./tests/fixtures/test.json"
    assert process_data_embed_file_contents_arg(arg) == '{}\n'
    arg.value = "./tests/fixtures/test_include.json"
    assert process_data_embed_file_contents_arg(arg) == '{}\n'
    arg.value = "./tests/fixtures/test_include_circular.json"
    assert process_data_embed_file_contents_arg(arg) == '{}\n'
    arg.value = "./tests/fixtures/test_include_not_exists.json"
    with pytest.raises(ParseError):
        process_data_

# Generated at 2022-06-23 18:53:21.092104
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file('test.txt') == 'test_content'



# Generated at 2022-06-23 18:53:23.454428
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file(KeyValueArg('a', 'no_such_file'))
        assert False
    except ParseError as _:
        pass

    assert 'a\n' == load_text_file(KeyValueArg('a', '/dev/null'))

# Generated at 2022-06-23 18:53:28.073165
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(key='test', sep='=', value='test.json')
    result = process_data_embed_file_contents_arg(arg)
    assert result == '{"test":"successful"}'


# Generated at 2022-06-23 18:53:29.763262
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('a=b')
    processed = process_data_item_arg(arg)
    assert processed == arg.value

# Generated at 2022-06-23 18:53:40.546594
# Unit test for function process_query_param_arg
def test_process_query_param_arg():

    request_item_args = [KeyValueArg(key='test',
                                     sep=SEPARATOR_QUERY_PARAM,
                                     value='test_value')]
    assert 'test_value' == process_query_param_arg(request_item_args[0])

    request_item_args = [KeyValueArg(key='test',
                                     sep=SEPARATOR_QUERY_PARAM,
                                     value='123')]
    assert '123' == process_query_param_arg(request_item_args[0])

    request_item_args = [KeyValueArg(key='test',
                                     sep=SEPARATOR_QUERY_PARAM,
                                     value='True')]
    assert 'True' == process_query_param_arg(request_item_args[0])



# Generated at 2022-06-23 18:53:44.536107
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # Test invalid
    try:
        process_query_param_arg(KeyValueArg(
            key='key1',
            value=None
        ))
        assert False
    except ParseError:
        pass

    # Test valid
    assert process_query_param_arg(KeyValueArg(
        key='key1',
        value='value1'
    )) == 'value1'

# Generated at 2022-06-23 18:53:49.948861
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('abc', 'abc', SEPARATOR_HEADER, 0)) == 'abc'
    assert process_header_arg(KeyValueArg('abc', '', SEPARATOR_HEADER, 0)) == ''


# Generated at 2022-06-23 18:53:52.929343
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep=';=', value='/test/test.txt')
    print(load_text_file(item))

test_load_text_file()

# Generated at 2022-06-23 18:53:55.494410
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('key', 'value', ';')
    print(process_data_item_arg(arg))


# Generated at 2022-06-23 18:54:07.463680
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:54:14.557657
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg(SEPARATOR_QUERY_PARAM, "key", "value")) == 'value'
    assert process_query_param_arg(KeyValueArg(SEPARATOR_QUERY_PARAM, "key", 'value')) == 'value'
    assert process_query_param_arg(KeyValueArg(SEPARATOR_QUERY_PARAM, 'key', 'value')) == 'value'


# Generated at 2022-06-23 18:54:16.869963
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
     arg = KeyValueArg(sep=SEPARATOR_QUERY_PARAM,key="some",value="someval")
     assert process_query_param_arg(arg) == 'someval'


# Generated at 2022-06-23 18:54:21.490179
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('X-API-Token', '123')
    assert process_header_arg(arg) == '123'
    arg = KeyValueArg('X-API-Token', '')
    assert process_header_arg(arg) == ''
    arg = KeyValueArg('X-API-Token', None)
    assert process_header_arg(arg) == None


# Generated at 2022-06-23 18:54:27.767548
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    import json
    from httpie.cli.argtypes import KeyValueArg
    # Test for normal cases
    arg1 = KeyValueArg(orig='test1', sep='&', key='test1', value='123')
    arg2 = KeyValueArg(orig='test2', sep='&', key='test2', value='abc')
    assert process_query_param_arg(arg1) == '123'
    assert process_query_param_arg(arg2) == 'abc'


# Generated at 2022-06-23 18:54:35.718171
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert(process_query_param_arg(KeyValueArg('k1=v1', '=', 'k1', 'v1')) == 'v1')
    assert(process_query_param_arg(KeyValueArg('k2', '=', 'k2', '')) == '')
    assert(process_query_param_arg(KeyValueArg('k3=', '=', 'k3', '')) == '')
    assert(process_query_param_arg(KeyValueArg('k4', '=', 'k4', None)) == '')
    assert(process_query_param_arg(KeyValueArg('k5=', '=', 'k5', None)) == '')



# Generated at 2022-06-23 18:54:41.877078
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg(
        'key',
        'value',
        False,
        'orig',
        None,
        'SEPARATOR_DATA_RAW_JSON',
    )
    value = load_json(item, item.value)
    assert value == 'value'
    assert type(value) == str


# Generated at 2022-06-23 18:54:47.496555
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.utils import RequestItems
    args = [KeyValueArg('Header;', 'value')]
    try:
        RequestItems.from_args(args)
    except ParseError as e:
        assert str(e) == 'Invalid item "Header;value" (to specify an empty header use `Header;`)'
    else:
        raise Exception("Did not raise an exception")

# Generated at 2022-06-23 18:55:00.392871
# Unit test for function load_json
def test_load_json():
    a = KeyValueArg("1","a")
    b = KeyValueArg("2","a")
    c = KeyValueArg("3","a")
    d = KeyValueArg("4","a")
    value = load_json(a,"{'a':1}")
    assert value == {'a':1}
    value = load_json(b,"{'a':1, 'b':[1,2,3]}")
    assert value == {'a':1, 'b':[1,2,3]}
    value = load_json(c,"{'a':1, 'b':[1,2,3], 'c': {'aa':1, 'bb': [1,2,3]}}")

# Generated at 2022-06-23 18:55:05.192626
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    kv = KeyValueArg('', 'Header;', 'key', 'value')
    try:
        process_empty_header_arg(kv)
        assert False
    except ParseError as e:
        assert str(e) == 'Invalid item "key=value" (to specify an empty header use `Header;`)'

# Generated at 2022-06-23 18:55:11.289614
# Unit test for function load_text_file
def test_load_text_file():
    filename = "data.txt"
    file = open(filename, "w")
    file.write("I am a data file")
    file.close()
    item_text = KeyValueArg("data", "data.txt", "@")
    assert (load_text_file(item_text) == "I am a data file")
    os.remove("data.txt")


# Generated at 2022-06-23 18:55:22.512153
# Unit test for function process_header_arg

# Generated at 2022-06-23 18:55:25.129014
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg("key", "value")) == "value"


# Generated at 2022-06-23 18:55:28.922378
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(orig="key; value", key="key", value="value", sep=';')
    contents = '{"name": "John Doe"}'
    value = load_json(arg, contents)
    assert value["name"] == "John Doe"
    try:
        value = load_json(arg, "{")
    except ParseError:
        pass
    assert value == 1

# Generated at 2022-06-23 18:55:38.430603
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    full_path = os.path.abspath(__file__)
    expected = (os.path.basename(full_path), open(full_path, 'rb'), None)
    actual = RequestItems.process_file_upload_arg(
        KeyValueArg('', SEPARATOR_FILE_UPLOAD, full_path, '')
    )
    assert expected[0] == actual[0]
    assert expected[1].read() == actual[1].read()
    assert expected[2] == actual[2]


if __name__ == '__main__':
    test_process_file_upload_arg()

# Generated at 2022-06-23 18:55:44.303294
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = 'test'
    value = 123
    argv = [f'{arg}:{SEPARATOR_DATA_RAW_JSON}{value}']
    args = httpie.cli.parser.parse_args(argv)

    request_items = RequestItems()
    request_items.data.update(
                process_data_raw_json_embed_arg(args.items[0])
                )
    assert request_items.data[arg] == value

# Generated at 2022-06-23 18:55:46.271587
# Unit test for function load_json
def test_load_json():
    assert load_json(KeyValueArg(''), '{"a": 1}') == {'a': 1}



# Generated at 2022-06-23 18:55:50.633588
# Unit test for constructor of class RequestItems
def test_RequestItems():
	ResponseItems = RequestItems(as_form=False)

	assert ResponseItems.headers == {}
	assert ResponseItems.data == {}
	assert ResponseItems.files == {}
	assert ResponseItems.params == {}
	assert ResponseItems.multipart_data == {}

	# test from_args
	RequestItems_args = {'headers': {}, 'params': {}, 'data': {}}
	assert ResponseItems.from_args(RequestItems_args) == {'headers': {}, 'params': {}, 'data': {}}

# Generated at 2022-06-23 18:56:00.065352
# Unit test for constructor of class RequestItems
def test_RequestItems():
    test_arg = []
    for key, value in [('key1', 'value1'), ('key2', 'value2'), ('key3', None), ('key4', 'value4')]:
        item = KeyValueArg(key, value)
        test_arg.append(item)
    request_items = RequestItems.from_args(test_arg)

    assert request_items.headers['key1'] == 'value1'
    assert request_items.headers['key2'] == 'value2'
    # assert request_items.headers['key3'] is None
    assert request_items.headers['key4'] == 'value4'


if __name__ == '__main__':
    test_RequestItems()

# Generated at 2022-06-23 18:56:02.932690
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    try:
        process_data_item_arg("test_item")
    except TypeError:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-23 18:56:07.418773
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = process_empty_header_arg(KeyValueArg('Header;', '', 'Header;'))
    assert arg == ''
    arg = process_empty_header_arg(KeyValueArg('Header;', 'da', 'Header;'))
    assert arg == ''

# Generated at 2022-06-23 18:56:13.238927
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    t1 = KeyValueArg('bearer', '', sep=SEPARATOR_HEADER_EMPTY)
    assert process_empty_header_arg(t1) == ''

    # Invalid input should raise exception.
    try:
        process_empty_header_arg(KeyValueArg('bearer', 'a', sep=SEPARATOR_HEADER_EMPTY))
    except ParseError:
        pass

# Generated at 2022-06-23 18:56:21.610046
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg('', '', SEPARATOR_DATA_RAW_JSON, '{"id":"100"}')) == {'id': '100'}
    assert process_data_raw_json_embed_arg(KeyValueArg('', '', SEPARATOR_DATA_RAW_JSON, '["id","100"]')) == ['id', '100']
    assert process_data_raw_json_embed_arg(KeyValueArg('', '', SEPARATOR_DATA_RAW_JSON, '["id","100",{"id": "100"}]')) == ['id', '100', {'id': '100'}]

# Generated at 2022-06-23 18:56:26.338672
# Unit test for function process_header_arg
def test_process_header_arg():
    key_value = KeyValueArg('sep:key=value', 'sep', 'key', 'value')
    assert 'value' == process_header_arg(key_value)

    key_value = KeyValueArg('sep:key', 'sep', 'key', '')
    assert None == process_header_arg(key_value)


# Generated at 2022-06-23 18:56:30.660261
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # Given
    request_item_args = [KeyValueArg("data", "embed", "~/data.json")]

    # When
    result = RequestItems.from_args(request_item_args)

    # Then
    assert result.data["data"] == "embed"
    assert result.data.get("d") is None



# Generated at 2022-06-23 18:56:33.986739
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg("foo","/tmp/a.txt")
    print(process_data_embed_file_contents_arg(arg))


# Generated at 2022-06-23 18:56:40.911630
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    request_items = RequestItems()
    request_items.headers = {
        'content-type': 'application/x-www-form-urlencoded'
    }
    request_items.data = {
        'name': 'tianyin'
    }
    assert request_items.headers['content-type'] == 'application/x-www-form-urlencoded'
    assert request_items.data['name'] == 'tianyin'

# Generated at 2022-06-23 18:56:47.494668
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg("header", "HEADER_VALUE")
    arg.sep = ":"
    arg.value = ":home/f/t/json.json"
    # assert process_data_embed_raw_json_file_arg(arg) == '{"JSON": "JSON"}'
    assert process_data_embed_raw_json_file_arg(arg) == {"JSON": "JSON"}



# Generated at 2022-06-23 18:56:50.197316
# Unit test for constructor of class RequestItems
def test_RequestItems():
    with pytest.raises(ParseError):
        RequestItems.from_args(
            [KeyValueArg(orig='Header;', key='X', value=None, sep=';')])

# Generated at 2022-06-23 18:56:53.958725
# Unit test for function load_json
def test_load_json():
    assert (load_json(KeyValueArg('abcd', 'abcd'), '{"a": 1, "b": 2}')) == {"a": 1, "b": 2}

# Generated at 2022-06-23 18:57:04.560294
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Create a new instance of class RequestItems
    req = RequestItems()

    # Add data to the request
    req.headers['Host'] = '127.0.0.1:5000'
    req.headers['Accept'] = 'application/json'
    req.data['username'] = 'admin'
    req.data['password'] = 'admin'

    # Create a new http request using the RequestItems instance
    response = requests.post('http://127.0.0.1:5000/login',
                             headers=req.headers,
                             data=req.data)

    # Get the response and check if the data sent was correct
    assert response.status_code == 200
    json_response = response.json()
    assert json_response['message'] == 'logged in as admin'



# Generated at 2022-06-23 18:57:08.017662
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('name', 'lisi', 'lisi')
    assert process_header_arg(arg) == 'lisi'


# Generated at 2022-06-23 18:57:16.565968
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg1 = KeyValueArg(SEPARATOR_FILE_UPLOAD, "name", "filename.txt", "filename.txt")
    arg2 = KeyValueArg(SEPARATOR_FILE_UPLOAD_TYPE, "name", "filename.txt;type/text", "filename.txt;type/text")
    assert process_file_upload_arg(arg1) == ("filename.txt", open(os.path.expanduser("filename.txt"), 'rb'), None)
    assert process_file_upload_arg(arg2) == ("filename.txt", open(os.path.expanduser("filename.txt"), 'rb'), "type/text")


# Generated at 2022-06-23 18:57:27.555815
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg("foo.txt", "bar", "--files")
    assert process_file_upload_arg(arg) == ("foo.txt", "bar", None)
    arg = KeyValueArg("foo.txt", "bar", "-f")
    assert process_file_upload_arg(arg) == ("foo.txt", "bar", None)
    arg = KeyValueArg("foo.txt;text/plain", "bar", "--files")
    assert process_file_upload_arg(arg) == ("foo.txt", "bar", "text/plain")
    arg = KeyValueArg("foo.txt;text/plain", "bar", "-f")
    assert process_file_upload_arg(arg) == ("foo.txt", "bar", "text/plain")

# Generated at 2022-06-23 18:57:36.134405
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    """
    Test case for process_data_embed_file_contents_arg function
    """
    arg = KeyValueArg(key="file", sep="@", value="text_file.txt")
    arg.orig = arg.key + arg.sep + arg.value
    with open("text_file.txt", "w") as file:
        file.write("This is a text file")
    assert process_data_embed_file_contents_arg(arg) == "This is a text file"
    os.remove("text_file.txt")


# Generated at 2022-06-23 18:57:40.038560
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('x', 'val')) == 'val'
    assert process_data_item_arg(KeyValueArg('x', 'val')) == 'val'


# Generated at 2022-06-23 18:57:41.431317
# Unit test for function load_json
def test_load_json():
    assert load_json('a', '1') == 1



# Generated at 2022-06-23 18:57:46.255471
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + os.path.sep + "test.txt"
    value = '%s' % file_path
    arg = KeyValueArg('key', SEPARATOR_FILE_UPLOAD, value)
    process_file_upload_arg(arg)

# Generated at 2022-06-23 18:57:50.189903
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # test for initialization with default values
    request_items = RequestItems(as_form=False)
    assert request_items.data.__class__.__name__ == "RequestJSONDataDict", "test for initialization failed"

    # test for initialization for form-data structure
    request_items = RequestItems(as_form=True)
    assert request_items.data.__class__.__name__ == "RequestDataDict", "test for initialization failed"