

# Generated at 2022-06-23 18:48:01.866792
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('b', 'test_embed.txt', None)) == 'test_embed_string\n'
    with pytest.raises(ParseError) as excinfo:
        load_text_file(KeyValueArg('b', 'test_embed.bin', None))
    assert ': cannot embed the content of "test_embed.bin",' in str(excinfo.value)
    with pytest.raises(ParseError) as excinfo:
        load_text_file(KeyValueArg('b', 'test_embed_not_exist.txt', None))
    assert ': [Errno 2] No such file or directory: "test_embed_not_exist.txt"' in str(excinfo.value)


# Generated at 2022-06-23 18:48:05.561786
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    parsed = process_data_raw_json_embed_arg(KeyValueArg('{key:value}'))
    assert parsed == {'key': 'value'}


# Generated at 2022-06-23 18:48:07.742482
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg("foo=bar") == "bar"


# Generated at 2022-06-23 18:48:16.342622
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test for a JSON item
    assert isinstance(process_data_raw_json_embed_arg(
        KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON,
                    key='testKey',
                    value='{"test": "test"}',
                    orig='testKey:={"test": "test"}')
    ), dict)
    # Test for a non-JSON item
    with pytest.raises(ParseError):
        process_data_raw_json_embed_arg(
            KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON,
                        key='testKey',
                        value='test',
                        orig='testKey:=test')
        )

# Generated at 2022-06-23 18:48:28.334275
# Unit test for function load_json
def test_load_json():
    try:
        value = load_json(arg=KeyValueArg(key='testJson', value='{ "test1": "test1Value", "test2": "test2Value" }', sep='='), contents='{ "test1": "test1Value", "test2": "test2Value" }')
        assert str(value) == "{'test1': 'test1Value', 'test2': 'test2Value'}"
    except ParseError as e:
        assert str(e) == 'testJson: { "test1": "test1Value", "test2": "test2Value" }'

# Generated at 2022-06-23 18:48:39.898424
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='para1', value='value1', orig='para1=value1', sep='=')
    assert('value1' == process_query_param_arg(arg))
    arg = KeyValueArg(key='para1', value='value1', orig='para1:value1', sep=':')
    assert('value1' == process_query_param_arg(arg))
    assert(process_query_param_arg(
        KeyValueArg(key='para1', value='value1', orig='para1', sep='=')) == '')
    assert(process_query_param_arg(
        KeyValueArg(key='para1', value='', orig='para1=', sep='=')) == '')

# Generated at 2022-06-23 18:48:42.891727
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg
    test1 = KeyValueArg('a', "foo")
    assert process_query_param_arg(test1) == "foo"

# Generated at 2022-06-23 18:48:46.217660
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg('', '', '', '{"a":1}')) == {"a":1}

# Generated at 2022-06-23 18:48:48.380575
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('Header','value')
    result = process_header_arg(arg)
    assert result is None


# Generated at 2022-06-23 18:48:55.413083
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Create cases for unit test
    case1 = KeyValueArg(
        key="foo",
        value="'bar'",
        orig="foo='bar'",
        sep=SEPARATOR_DATA_RAW_JSON,
    )

    # Generate expected results
    expected_result = {
        "foo":"bar"
    }

    # Get result for each test case
    result = process_data_embed_raw_json_file_arg(case1)
    # Check the result with expected results
    assert result == expected_result


# Generated at 2022-06-23 18:49:03.744122
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import os
    from httpie.cli.constants import SEPARATOR_FILE_UPLOAD_TYPE
    from httpie.cli.argtypes import KeyValueArg
    arg = KeyValueArg("", "out.txt;text/html")
    arg.sep = SEPARATOR_FILE_UPLOAD
    arg.value = "out.txt;text/html"
    (name, f, content_type) = process_file_upload_arg(arg)
    assert name == "['out.txt']"
    assert content_type == "text/html"
    assert f == os.path.expanduser("out.txt")

# Generated at 2022-06-23 18:49:08.042176
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg.parse('a=b')
    assert process_data_embed_raw_json_file_arg(
        item
    ) == 'b'
    item = KeyValueArg.parse('a@filename.json')
    assert process_data_embed_raw_json_file_arg(
        item
    ) == {'a': 'b'}

# Generated at 2022-06-23 18:49:11.085370
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('Header', 'value')
    assert process_header_arg(arg) == 'value'
    arg.value = None
    assert process_header_arg(arg) == ''


# Generated at 2022-06-23 18:49:23.480005
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    test_arg_value = "foo"
    test_arg_key = "a"
    test_arg_sep = SEPARATOR_HEADER_EMPTY
    test_arg_orig = test_arg_key + test_arg_sep + test_arg_value
    test_header_arg = KeyValueArg(test_arg_key, test_arg_sep, test_arg_value, test_arg_orig)

    # process_empty_header_arg should raise ParseError as value is expected to be None
    raised_exception = False
    try:
        process_empty_header_arg(test_header_arg)
    except ParseError:
        raised_exception = True
    assert raised_exception

    test_arg_value = None
    test_arg_orig = test_arg_key + test_

# Generated at 2022-06-23 18:49:28.120673
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_items = RequestItems()
    assert request_items.headers     == {}
    assert request_items.data        == {}
    assert request_items.files       == {}
    assert request_items.params      == {}
    assert request_items.multipart_data == {}


# Generated at 2022-06-23 18:49:33.877493
# Unit test for function load_json
def test_load_json():
    from httpie.cli.argtypes import KeyValueArg
    json = '{"a":1, "b":2}'
    arg = KeyValueArg(key='d', sep=':', orig='d:c', value=json)
    assert load_json(arg, json) == {"a": 1, "b": 2}
    json = '{"a":1, "b":2'
    arg = KeyValueArg(key='d', sep=':', orig='d:c', value=json)
    assert load_json(arg, json) == None



# Generated at 2022-06-23 18:49:36.827430
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filepath = 'C:\\Users\\21779\\Desktop\\python.txt'
    filename = 'python.txt'
    mime_type = 'text/plain'
    arg = KeyValueArg(value=filepath, key=filename, sep='@')
    result = process_file_upload_arg(arg)
    assert result[0] == filename
    assert result[1]
    assert result[2] == mime_type

# Generated at 2022-06-23 18:49:41.496755
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg('filename', 'tests/httpbin/sample_response_body.json')) == load_json_preserve_order(load_text_file(KeyValueArg('filename', 'tests/httpbin/sample_response_body.json')))

# Generated at 2022-06-23 18:49:45.851863
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data = '{"a": "b"}'
    arg = KeyValueArg("-d", data, "", "")
    assert process_data_raw_json_embed_arg(arg) == {'a': "b"}


# Generated at 2022-06-23 18:49:54.860554
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('f:@file_temp', 'f', '@file_temp', 'file_temp', None)
    assert process_data_embed_file_contents_arg(arg) == 'embedding'
    arg = KeyValueArg('f:@filedoesnotexist', 'f', '@filedoesnotexist',
                      'filedoesnotexist', None)
    try:
        process_data_embed_file_contents_arg(arg)
        assert False
    except ParseError:
        assert True



# Generated at 2022-06-23 18:50:06.070658
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import (
        SEPARATOR_DATA_RAW_JSON, SEPARATOR_DATA_STRING, SEPARATOR_FILE_UPLOAD,
        SEPARATOR_FILE_UPLOAD_TYPE, SEPARATOR_HEADER, SEPARATOR_HEADER_EMPTY,
        SEPARATOR_QUERY_PARAM,
    )
    from httpie.cli.dicts import (
        MultipartRequestDataDict, RequestDataDict, RequestFilesDict,
        RequestHeadersDict, RequestJSONDataDict,
        RequestQueryParamsDict,
    )
    instance=RequestItems()

# Generated at 2022-06-23 18:50:15.197110
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    sep = SEPARATOR_FILE_UPLOAD + SEPARATOR_FILE_UPLOAD_TYPE
    filename = 'filename'
    file_contents = b'file contents'
    mime_type = 'mime_type'

    # Test 1: No Mime type
    with tempfile.NamedTemporaryFile() as f:
        f.write(file_contents)
        f.flush()
        assert (file_contents, f, get_content_type(filename)) == process_file_upload_arg(
            KeyValueArg(sep, filename, mime_type=None)
        )
    # Test 2: Mime type
    with tempfile.NamedTemporaryFile() as f:
        f.write(file_contents)
        f.flush()

# Generated at 2022-06-23 18:50:24.786860
# Unit test for function load_text_file
def test_load_text_file():
    import json
    import datetime
    import dateutil.parser
    actual_result = load_text_file(
        KeyValueArg(sep=":", key="@", value="data.json"))
    assert isinstance(actual_result, str)
    assert actual_result is not None
    expected_dict = json.loads(actual_result)
    assert expected_dict["person"]["name"] == "John Doe"
    assert expected_dict["person"]["birthday"] == \
        dateutil.parser.parse("1990-01-01T00:00:00")
    assert expected_dict["person"]["score"] == 1.0
    assert expected_dict["person"]["active"] is True

# Generated at 2022-06-23 18:50:28.916113
# Unit test for function load_json
def test_load_json():
    assert load_json({'sep': '', 'orig': '', 'key': '', 'value': '{"a": "b", "c": [1, 2, 3]}'}) == \
           {'a': "b", "c": [1, 2, 3]}

# Generated at 2022-06-23 18:50:34.279696
# Unit test for function load_json
def test_load_json():
    try:
        load_json('1','{"foo":{"bar":12},"baz":true,"qux":["one","two"]}')
    except ValueError as e:
        raise ParseError('"%s": %s' % ('1', e))

# Generated at 2022-06-23 18:50:36.849421
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg('Header:Y') == 'Y'
    assert process_header_arg('Header:') == None


# Generated at 2022-06-23 18:50:41.302652
# Unit test for function load_text_file
def test_load_text_file():
    print("Test : Load file contents of the file passed")
    contents = load_text_file("resources/sample.txt")
    if contents is None:
        print("Could not load the file contents of the file passed")
    else:
        print("File contents of the file passed: {}".format(contents))


# Generated at 2022-06-23 18:50:47.134880
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('header', 'Content-Type', '')
    assert process_header_arg(arg) == ''

    arg = KeyValueArg('header', 'Content-Type', 'application/json')
    assert process_header_arg(arg) == 'application/json'


# Generated at 2022-06-23 18:50:48.842649
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file("test.txt") == "this a test txt!"

# Generated at 2022-06-23 18:50:50.846393
# Unit test for function load_json
def test_load_json():
    assert load_json('a:1', '{') == {'a': 1}

# Generated at 2022-06-23 18:50:52.363400
# Unit test for function load_json
def test_load_json():
    load_json(KeyValueArg('a', 'test', '='), 'test')

# Generated at 2022-06-23 18:50:56.307560
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('Header;', 'Header', ';')) == ''

    try:
        process_empty_header_arg(KeyValueArg('Header:test', 'Header', ':'))
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-23 18:51:07.064472
# Unit test for constructor of class RequestItems
def test_RequestItems():
    r = RequestItems.from_args([KeyValueArg('-H content-type:application/json')])
    assert isinstance(r.headers, RequestHeadersDict)
    assert isinstance(r.data, RequestJSONDataDict)
    assert isinstance(r.files, RequestFilesDict)
    assert isinstance(r.params, RequestQueryParamsDict)

    r = RequestItems.from_args([KeyValueArg('-H content-type:application/x-www-form-urlencoded')])
    assert isinstance(r.headers, RequestHeadersDict)
    assert isinstance(r.data, RequestDataDict)
    assert isinstance(r.files, RequestFilesDict)
    assert isinstance(r.params, RequestQueryParamsDict)

# Generated at 2022-06-23 18:51:13.327869
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # Test case
    arg = KeyValueArg(key='Header', sep=';', value='')
    # Get result
    result = process_empty_header_arg(arg)
    # Expected result:
    expected_result = ''
    assert result == expected_result, "Actual value is: " + result
    print('Test for function process_empty_header_arg PASSED')



# Generated at 2022-06-23 18:51:15.965921
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg(KeyValueArg('', '', "filename.txt")) == "filename.txt"

# Generated at 2022-06-23 18:51:18.657083
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg("Header:abc")
    assert process_header_arg(arg) == "abc"



# Generated at 2022-06-23 18:51:24.651853
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg('raw_json_path', 'test.json')) == {
        'id': 1,
        'username': "haha",
        'password': "123456",
        'gender': "male",
        'gender1': "male",
        'name': "xiaoming",
        'age': 22
    }

# Generated at 2022-06-23 18:51:28.285973
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key=None, sep=SEPARATOR_DATA_STRING, value='testdata')
    assert process_data_item_arg(arg) == 'testdata'


# Generated at 2022-06-23 18:51:31.396124
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    item = KeyValueArg(orig="key=value", key="key", value="value", sep="=")
    return process_data_item_arg(item)


# Generated at 2022-06-23 18:51:34.995611
# Unit test for function process_header_arg
def test_process_header_arg():
    a = process_header_arg(KeyValueArg('Authorization', 'abcdefg'))
    b = process_header_arg(KeyValueArg('Accept', ''))
    assert a == 'abcdefg'
    assert b == ''

# Generated at 2022-06-23 18:51:44.960334
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(None, None, 'a;b', 'c')) == 'c'
    assert process_data_raw_json_embed_arg(KeyValueArg(None, None, 'a;b', 'c,d')) == 'c,d'
    assert process_data_raw_json_embed_arg(KeyValueArg(None, None, 'a;b', '1')) == 1
    assert process_data_raw_json_embed_arg(KeyValueArg(None, None, 'a;b', '1.1')) == 1.1
    assert process_data_raw_json_embed_arg(KeyValueArg(None, None, 'a;b', 't')) == True

# Generated at 2022-06-23 18:51:48.349628
# Unit test for function load_json
def test_load_json():
    assert load_json({"foo": 1, "bar": 2}, '{"bar": 2, "foo": 1}') == {"bar": 2, "foo": 1}

# Generated at 2022-06-23 18:51:58.711713
# Unit test for function load_json
def test_load_json():
    import json
    import httpie.cli.dicts
    x = httpie.cli.dicts.KeyValueArg(';', 'foo', 'bar')
    y1 = '{"key": "value"}'
    y2 = '{"key": "value", "key2": "value2"}'
    y3 = '{"key": "value", "key2": {}}'
    assert json.loads(load_json(x, y1)) == json.loads(y1)
    assert json.loads(load_json(x, y2)) == json.loads(y2)
    assert json.loads(load_json(x, y3)) == json.loads(y3)

# Generated at 2022-06-23 18:52:09.443846
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    json_str = """
{
  "name": "httpie",
  "description": "a CLI, cURL-like tool for humans",
  "keywords": ["cli", "http", "api", "curl"],
  "homepage": "https://httpie.org",
  "license": "BSD",
}
"""
    json_file = open("test.json", "w")
    json_file.write(json_str)
    json_file.close()
    json_file = open("test.json", "r")


# Generated at 2022-06-23 18:52:12.369441
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # This code is for Unit testing
    arg = KeyValueArg("key", "value", "SEPARATOR")
    assert False == process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-23 18:52:14.746880
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    return process_data_raw_json_embed_arg({'orig': 'orig', 'value': '{"a":1, "c":3}'})



# Generated at 2022-06-23 18:52:24.404572
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    a1 = KeyValueArg(key='b', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='c.json')
    a2 = KeyValueArg(key='d', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='1')

    a3 = KeyValueArg(key='b', sep=SEPARATOR_DATA_STRING, value='c.json')
    a4 = KeyValueArg(key='d', sep=SEPARATOR_DATA_STRING, value='1')

    assert process_data_embed_raw_json_file_arg(a1) == {'b': 'hehe'}
    assert process_data_embed_raw_json_file_arg(a2) == {'d': 1}
    assert process_data_raw_json_embed_

# Generated at 2022-06-23 18:52:27.701306
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(key='User-Agent', value=None, sep=SEPARATOR_HEADER_EMPTY, orig='User-Agent;')
    value = process_empty_header_arg(arg)

    assert value == ''

# Generated at 2022-06-23 18:52:29.726850
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("", SEPARATOR_HEADER_EMPTY, "")
    assert process_empty_header_arg(arg) == ""

# Generated at 2022-06-23 18:52:35.008030
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    """test for function process_empty_header_arg"""
    arg = KeyValueArg('Header', '', '', ';')
    assert process_empty_header_arg(arg)==''
    arg = KeyValueArg('Header', '', '', ';')
    assert process_empty_header_arg(arg)==''


# Generated at 2022-06-23 18:52:39.636146
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, "foo", "test.json")

    if(process_data_embed_raw_json_file_arg(arg)["foo"] != "foo"):
        print("Test failed")
    else:
        print("Test passed")

test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-23 18:52:42.757030
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(key="key",value="value",sep=":")
    assert process_header_arg(arg) == "value"


# Generated at 2022-06-23 18:52:47.526710
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert (
        process_file_upload_arg(KeyValueArg(
            "FILE",
            "path/to/file",
            sep=SEPARATOR_FILE_UPLOAD))
        == ("file", open("path/to/file", 'rb'), None)
    )

# Generated at 2022-06-23 18:52:49.952253
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    args = KeyValueArg('key=value')
    assert process_query_param_arg(args) == 'value'



# Generated at 2022-06-23 18:52:54.391740
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(key="header", value=None, orig="header", sep="+")
    ret = process_empty_header_arg(arg)
    print(ret)


if __name__ == "__main__":
    test_process_empty_header_arg()

# Generated at 2022-06-23 18:52:55.309195
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert True

# Generated at 2022-06-23 18:52:58.356493
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('Key', 'Value', 'Key=Value')
    assert process_data_item_arg(arg) == 'Value'


# Generated at 2022-06-23 18:53:00.487385
# Unit test for function load_text_file
def test_load_text_file():
    contents = load_text_file(KeyValueArg(orig="-f", key="-f", sep="-f", value="test.txt"))
    assert contents == "This is a test file"


# Generated at 2022-06-23 18:53:11.587947
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args_with_content_type = KeyValueArg(
        key='key',
        value='/path;httpie/tests/data/request_data/unicode.json',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='@/path;httpie/tests/data/request_data/unicode.json',
        is_list=False
    )
    filename, file_content, mime_type = process_file_upload_arg(
        args_with_content_type)
    assert filename == 'unicode.json', 'failed'
    assert mime_type == 'httpie/tests/data/request_data/unicode.json', 'failed'


# Generated at 2022-06-23 18:53:19.733598
# Unit test for function process_header_arg
def test_process_header_arg():
    # """Simple test for function process_header_arg"""
    print("Unit test for function process_header_arg")
    a=KeyValueArg(key="a",sep=":",value="value",orig="a:value")
    print("Processing a:value -> %s"%(process_header_arg(a)))
    b = KeyValueArg(key="b", sep=":", value=None, orig="b:")
    print("Processing b: -> %s" % (process_header_arg(b)))
    b = KeyValueArg(key="b", sep=":", value="", orig="b:")
    print("Processing b: -> %s" % (process_header_arg(b)))
    
if __name__ == "__main__":
    test_process_header_arg()

# Generated at 2022-06-23 18:53:29.736303
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg('', '@filename.txt')) == (
        'filename.txt',
        open(os.path.expanduser('@filename.txt'),'rb'),
        None
    )
    arg = KeyValueArg('', '@filename.txt')
    assert process_file_upload_arg(arg) == (
        'filename.txt',
        open(os.path.expanduser(arg.value),'rb'),
        None
    )
    arg = KeyValueArg('', '@filename.txt#text/html')
    assert process_file_upload_arg(arg) == (
        'filename.txt',
        open(os.path.expanduser(arg.value[:arg.value.find('#')]),'rb'),
        'text/html'
    )

# Generated at 2022-06-23 18:53:40.502532
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg(orig='Data_Embed_File_Contents;{}'.format(__file__), sep='Data_Embed_File_Contents', key='', value=__file__)
    # test bin file
    try:
        load_text_file(arg)
    except ParseError as e:
        print('Parse error: {}'.format(e))
    arg = KeyValueArg(orig='Data_Embed_File_Contents;{}'.format('/etc/fstab'), sep='Data_Embed_File_Contents', key='', value='/etc/fstab')
    assert(load_text_file(arg) is not '')
    # test non-existed file

# Generated at 2022-06-23 18:53:42.989012
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    my_file = "input.json"
    data = process_data_embed_raw_json_file_arg(my_file)
    print(data)
    assert True



# Generated at 2022-06-23 18:53:46.787912
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('header:value')
    assert process_header_arg(arg) == 'value'



# Generated at 2022-06-23 18:53:51.034786
# Unit test for function process_header_arg
def test_process_header_arg():
    # Arrange
    arg: KeyValueArg = KeyValueArg(':', 'a', 'b')
   
    # Act
    actual_return = process_header_arg(arg)
   
    # Assert
    assert actual_return == 'b'


# Generated at 2022-06-23 18:53:53.144953
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("Header", "", "Header;")
    process_empty_header_arg(arg)



# Generated at 2022-06-23 18:53:55.364399
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    a = KeyValueArg('test', 'test', 'test')
    load_text_file(a)

# Generated at 2022-06-23 18:53:59.974448
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(
        key='A', sep=':', value='', orig='A:')) == ''



# Generated at 2022-06-23 18:54:08.862990
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestJSONDataDict

    # request_item_args: List[KeyValueArg]
    request_item_args = [
        KeyValueArg(key='name', value='gg', sep=':'),
        KeyValueArg(key='age', value='18', sep='=')
    ]
    as_form=False
    request_items = RequestItems.from_args(request_item_args, as_form)
    assert isinstance(request_items.headers, RequestHeadersDict)
    assert isinstance(request_items.data, RequestDataDict)

# Generated at 2022-06-23 18:54:14.777617
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(
        '-f',
        'data.json',
        None,
        SEPARATOR_DATA_EMBED_FILE_CONTENTS
    )) == '''{
  "arr": [1, 2, 3],
    "obj": {
        "bool": true
    },
    "str": "hello world"
}'''



# Generated at 2022-06-23 18:54:18.750214
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    args = [
        KeyValueArg(
            sep=SEPARATOR_HEADER_EMPTY,
            key="testKey",
            value="testValue",
            orig="-H testValue;",
            option_flags=None
        )
    ]
    try:
        RequestItems.from_args(args)
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-23 18:54:22.240107
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('key', 'value')
    assert('value' == process_data_item_arg(arg))


# Generated at 2022-06-23 18:54:26.345318
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='file',
        value='test.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    print(value)
    

# Generated at 2022-06-23 18:54:29.942242
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg(KeyValueArg(key='file', value='./test/cloud.json', sep=':')) == '{"application": {"name": "cloud"}}'


# Generated at 2022-06-23 18:54:37.440571
# Unit test for function load_text_file
def test_load_text_file():
    from httpie.cli.constants import SEPARATOR_DATA_EMBED_FILE_CONTENTS
    from httpie.cli.argtypes import KeyValueArg

    item = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        key='data',
        value='./data/test_load_text_file.txt',
        orig='data@test_load_text_file.txt',
    )
    text = load_text_file(item)
    assert len(text) > 0
    with open(item.value, 'rb') as f:
        assert f.read().decode() == text


# Generated at 2022-06-23 18:54:48.446695
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # pass correct test data
    result = RequestItems.from_args(request_item_args=[KeyValueArg(key="k", value="v", sep=";")])
    assert result.headers.get("k") == "v"
    assert result.data.get("k") == None
    assert result.files.get("k") == None
    assert result.params.get("k") == None
    # test with head
    result = RequestItems.from_args(request_item_args=[KeyValueArg(key="k", value="v", sep=":")])
    assert result.headers.get("k") == "v"
    assert result.data.get("k") == None
    assert result.files.get("k") == None
    assert result.params.get("k") == None
    # test with query
    result = Request

# Generated at 2022-06-23 18:54:51.456453
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg("file:at.txt@type:text/plain")
    filename, f, mime_type = process_file_upload_arg(file_upload_arg)
    assert filename == "at.txt"
    assert mime_type == "text/plain"

# Generated at 2022-06-23 18:54:54.147122
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    key_value_arg = KeyValueArg('k', 'v')
    assert process_data_item_arg(key_value_arg) == 'v'

# Generated at 2022-06-23 18:55:05.955129
# Unit test for constructor of class RequestItems
def test_RequestItems():
    req = RequestItems()
    req.headers['Content-Length'] = '256'
    req.data['name'] = 'Alice'
    req.params['name'] = 'Alice'
    req.files['file'] = ('/home/photos/photo.png', 'image/png')
    assert(req.headers == RequestHeadersDict({'Content-Length': '256'}))
    assert(req.data == RequestDataDict({'name': 'Alice'}))
    assert(req.files == RequestFilesDict({'file': ('/home/photos/photo.png', 'image/png')}))
    assert(req.multipart_data == MultipartRequestDataDict({'name': 'Alice', 'file': ('/home/photos/photo.png', 'image/png')}))

# Generated at 2022-06-23 18:55:08.728824
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('foo=bar')
    assert process_data_item_arg(arg) == 'bar'


# Generated at 2022-06-23 18:55:11.648608
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(orig='foo', key='foo', sep='=', value='bar')
    assert "bar" == process_data_item_arg(arg)



# Generated at 2022-06-23 18:55:12.718373
# Unit test for constructor of class RequestItems
def test_RequestItems():
    pass


# Generated at 2022-06-23 18:55:18.453640
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = "content-file\\@py\\@/home/httpie/httpie/tests/data/sample.json"
    file_path = "/home/httpie/httpie/tests/data/sample.json"
    assert process_data_embed_file_contents_arg(arg) == load_text_file(file_path)



# Generated at 2022-06-23 18:55:21.339377
# Unit test for function process_header_arg
def test_process_header_arg():
    result = process_header_arg(KeyValueArg(separator=SEPARATOR_HEADER, key=None, value=None))
    assert result is None

    result = process_header_arg(KeyValueArg(separator=SEPARATOR_HEADER, key=None, value='value'))
    assert result == 'value'


# Generated at 2022-06-23 18:55:25.129607
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('orig','value')
    path = item.value
    with open(path, 'r') as f:
        return f.read().decode()
    assert True

# Generated at 2022-06-23 18:55:27.951404
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = {"key": "Authorization", "value": "github.com/get-httpie", "sep": ":", "orig": "Authorization: github.com/get-httpie"}
    arg = KeyValueArg(**arg)
    value = process_query_param_arg(arg)
    assert value == "github.com/get-httpie"


# Generated at 2022-06-23 18:55:35.756536
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:55:39.228060
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg(sep='Header', key='test_header', value='test_value')
    header = process_header_arg(header_arg)
    assert header == 'test_value'


# Generated at 2022-06-23 18:55:43.010576
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    item = KeyValueArg("--data", "value", "hello=world", ":")
    print("The test item is: ")
    print(item)
    print("The value of test item is: ")
    print(process_data_item_arg(item))


# Generated at 2022-06-23 18:55:49.164307
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    yaml_file = './tests/test.yaml'
    yaml_arg = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, '.', yaml_file)
    test_content = process_data_embed_file_contents_arg(yaml_arg)
    assert test_content == '''
name: John Smith
#job: [Developer, Manager]
age: 27
'''

# Generated at 2022-06-23 18:55:53.131978
# Unit test for function load_json
def test_load_json():
    json_str = '[{"a": 1, "b": 2}, {"a": 3}]'
    data1 = load_json(None, json_str)
    data2 = json.loads(json_str)
    assert data1 == data2
    assert data1["a"] == data2["a"]
    assert data1["b"] == data2["b"]

# Generated at 2022-06-23 18:55:55.382601
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(';', 'file', 'test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'username': 'testuser'}

# Generated at 2022-06-23 18:55:57.329299
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg("cookie","test=test")
    assert process_header_arg(arg) == "test=test"


# Generated at 2022-06-23 18:56:09.237316
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Smoke test
    process_file_upload_arg(KeyValueArg('name', 'SEPARATOR_FILE_UPLOAD', 'value'))

    # Test without content_type
    file_path = os.path.join(os.getcwd() + "/data/upload_file_without_content_type.txt")
    upload_file_without_type = process_file_upload_arg(KeyValueArg('name', 'SEPARATOR_FILE_UPLOAD', file_path))
    assert "upload_file_without_content_type.txt" == upload_file_without_type[0]
    assert "text/plain" == upload_file_without_type[2]

    # Test with content_type

# Generated at 2022-06-23 18:56:14.527303
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    f = open(os.path.expanduser('~/git-repo/httpie/httpie/__main__.py'), 'rb')
    result = process_file_upload_arg(KeyValueArg('file', "~/git-repo/httpie/httpie/__main__.py"))
    assert result[0] == '__main__.py'
    assert f == result[1]
    assert result[2] == 'text/x-python'
    f.close()

# Generated at 2022-06-23 18:56:20.552789
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "file.ext"
    f = open(os.path.expanduser(filename), 'rb')
    mime_type = "text/text"

    result = process_file_upload_arg(filename, f, mime_type)
    assert len(result) == 3
    assert result[0] == "file.ext"
    assert result[2] == "text/text"

# Generated at 2022-06-23 18:56:22.776197
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg('key=@/Users/tangso/Desktop/file.txt') == '123'

# Generated at 2022-06-23 18:56:30.404093
# Unit test for function process_file_upload_arg

# Generated at 2022-06-23 18:56:36.697538
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg1 = KeyValueArg('@','key','value')
    value1 = process_data_embed_raw_json_file_arg(arg1)
    print(value1)
    arg2 = KeyValueArg('@','key2','value2')
    value2 = process_data_embed_raw_json_file_arg(arg2)
    print(value2)

# Generated at 2022-06-23 18:56:44.901959
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    itemDict = dict()
    key1 = "name"
    itemDict[key1] = "bob"
    key2 = "age"
    itemDict[key2] = "15"
    key3 = "gender"
    itemDict[key3] = "male"

    itemList = list()
    itemList.append(itemDict)
    itemList.append(itemDict)
    itemList.append(itemDict)

    itemDict2 = dict()
    key1 = "id"
    itemDict2[key1] = 1
    key2 = "result"
    itemDict2[key2] = itemList

    arg = KeyValueArg(key='name', sep='=', value='bob')
    item = parse_line(arg, True)


# Generated at 2022-06-23 18:56:48.020229
# Unit test for function load_text_file
def test_load_text_file():
    file = '../package.json'
    item = {"key": "data", "value": file, "sep": SEPARATOR_DATA_EMBED_FILE_CONTENTS}
    key = KeyValueArg(**item)
    load_text_file(key)

# Generated at 2022-06-23 18:56:52.168751
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    print('Test process_data_embed_file_contents_arg')
    arg = KeyValueArg('name', 'input.txt', None, None)
    print('input')
    print('{}'.format(arg.value))
    print(process_data_embed_file_contents_arg(arg))


# Generated at 2022-06-23 18:56:56.793886
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig='test', sep=SEPARATOR_DATA_RAW_JSON, key='test', value='test')
    result = process_data_raw_json_embed_arg(arg)
    assert result == 'test'

# Generated at 2022-06-23 18:57:00.464781
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        '', '', '', '', '', ''
    )
    try:
        assert load_text_file(item) == 'son\n'
    except:
        print('load text file error')



# Generated at 2022-06-23 18:57:03.027006
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(None) == None
    assert process_data_item_arg(KeyValueArg(None, 'foo', 'bar')) == 'bar'

# Generated at 2022-06-23 18:57:05.243491
# Unit test for function load_text_file
def test_load_text_file():
    load_text_file("1.txt")

# Generated at 2022-06-23 18:57:06.316378
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('Header', '')) == ''



# Generated at 2022-06-23 18:57:08.813470
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('key1', 'val1')) == 'val1'


# Generated at 2022-06-23 18:57:15.103173
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_item_args = [
        KeyValueArg('Content-Type;application/json', 'Content-Type', 'application/json', ';'),
        KeyValueArg('HEADER;Header-Name', 'HEADER', 'Header-Name', ';'),
    ]

    request_items = RequestItems.from_args(request_item_args)
    print(request_items.headers)

if __name__=="__main__":
    test_RequestItems()

# Generated at 2022-06-23 18:57:17.737024
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg(key='file_name', value='file1.txt', orig='file_name:file1.txt')
    res = load_text_file(arg)
    print(res)

# Generated at 2022-06-23 18:57:27.380241
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # Test for wrong input
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.exceptions import ParseError
    from httpie.cli.helpers import RequestItems
    from httpie.cli.constants import SEPARATOR_QUERY_PARAM
    request_item_args = []
    request_item_args.append(KeyValueArg(
            key='test',
            value='test',
            sep=SEPARATOR_QUERY_PARAM,
            orig='test'))
    try:
        RequestItems.from_args(request_item_args)
    except ParseError:
        return False
    else:
        return True

# Generated at 2022-06-23 18:57:31.520297
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(orig="Content-Type=multipart/form-data;")
    arg.key = "Content-Type"
    arg.sep = "="
    arg.value = "multipart/form-data"
    assert process_data_item_arg(arg) == "multipart/form-data"


# Generated at 2022-06-23 18:57:35.217994
# Unit test for function process_header_arg
def test_process_header_arg():
    example_arg = KeyValueArg('-t')
    assert process_header_arg(example_arg) == None
    example_arg = KeyValueArg('-t', 'text')
    assert process_header_arg(example_arg) == 'text'


# Generated at 2022-06-23 18:57:39.394309
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert('this is a test file' == (process_data_embed_file_contents_arg(KeyValueArg('data-raw-json', '< test_files/test_file_for_arg'))))


# Generated at 2022-06-23 18:57:43.153296
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg('key={"test":"test"}', '=', 'key', '{"test":"test"}')
    contents = '{"test":"test"}'
    assert load_json(arg, contents) == json.loads('{"test":"test"}')

# Generated at 2022-06-23 18:57:48.516977
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    header_arg = KeyValueArg("Header;", "")
    header_arg.sep = SEPARATOR_HEADER_EMPTY
    header_arg.key = "Header"

    assert process_empty_header_arg(header_arg) == ""

    header_arg.value = "value"
    try:
        process_empty_header_arg(header_arg)
        raise Exception("Did not raise ParseError")
    except ParseError:
        pass

# Generated at 2022-06-23 18:57:52.854723
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg('key'))
    except ParseError as e:
        assert str(e) == 'Invalid item "key" (to specify an empty header use `Header;`)'
    else:
        assert False