

# Generated at 2022-06-23 18:47:57.882314
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = 'Content-Type: application/json'
    headers = {}
    key = arg.split(':')[0]
    value = arg.split(':')[1].strip()
    headers[key] = value
    assert headers == {'Content-Type': 'application/json'}
    arg = 'Content-Type:'
    headers[key] = arg.split(':')[1].strip()
    assert headers == {'Content-Type': ''}


# Generated at 2022-06-23 18:48:01.035539
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('Location;')
    assert process_empty_header_arg(arg) is None
    arg = KeyValueArg('Location;www.google.com')
    with pytest.raises(ParseError):
        process_empty_header_arg(arg)

# Generated at 2022-06-23 18:48:03.249561
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    temp = process_data_item_arg(['123', '1234'])
    assert temp == '1234'

# Generated at 2022-06-23 18:48:14.700123
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # create a dictionary with different argument separator
    dummyRequest = {'Header': 'value1', 'Header;': '', ':path': '/', ':query:': '', 'data': 'hello', '@': 'foo.txt','data@': 'bar.json', 'data;': 'world'}
    testRequestItem = RequestItems(dummyRequest, False)

    # assert if dictionary is created
    assert testRequestItem.headers == {'Header': 'value1', 'Header': ''}
    assert testRequestItem.params == {':path': '/', ':query:': ''}
    assert testRequestItem.files == {'@': 'foo.txt'}
    assert testRequestItem.data == {'data': 'hello', 'data': 'bar.json', 'data': 'world'}

# Generated at 2022-06-23 18:48:18.957078
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(key='test', value='test', sep=SEPARATOR_HEADER_EMPTY)
    result = process_empty_header_arg(arg)
    assert result == 'test'


# Generated at 2022-06-23 18:48:22.648621
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    print("Testing for process_data_item_arg()...")
    result= process_data_item_arg("-d", "a=b")
    assert result == "a=b"


# Generated at 2022-06-23 18:48:27.892809
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_items = RequestItems()
    assert request_items.headers is not None
    assert request_items.data is not None
    assert request_items.files is not None
    assert request_items.params is not None
    assert request_items.multipart_data is not None

# Generated at 2022-06-23 18:48:31.916849
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg(
        'file-upload',
        'C:\\Users\\jwang\\jdata\\jie.JPG',
        '-file-upload',
        'C:\\Users\\jwang\\jdata\\jie.JPG',
    )
    r = process_file_upload_arg(file_upload_arg)
    assert r[0] == 'jie.JPG' and r[2] == 'image/jpeg'

# Generated at 2022-06-23 18:48:36.380237
# Unit test for function load_json
def test_load_json():
    # Testing JSON string
    assert load_json('{"j":"a"}') == {"j":"a"}

    # Testing JSON path
    json_path = r'C:\Users\Dora\PycharmProjects\httpie\req_res\test_json'
    assert load_json(json_path) == {"j":"a"}

# Generated at 2022-06-23 18:48:44.709755
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg
    import os
    file_name = os.path.join(os.getcwd(),'test_process_data_embed_raw_json_file_arg.json')
    with open(file_name,'w') as f:
        f.write('{"123":"456"}')
    arg = KeyValueArg('@' +file_name)
    assert(process_data_embed_raw_json_file_arg(arg) == {"123":"456"})
    os.remove(file_name)

# Generated at 2022-06-23 18:48:47.498263
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(",", "a", "1")
    r = process_query_param_arg(arg)
    assert(r == "1")


# Generated at 2022-06-23 18:48:51.221211
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = "/home/user/image.jpg"
    SEPARATOR_FILE_UPLOAD = "="
    arg = KeyValueArg(file_upload_arg, SEPARATOR_FILE_UPLOAD)
    print(process_file_upload_arg(arg))


# Generated at 2022-06-23 18:48:58.196334
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    expected_output = {"foo": "bar"}
    # As specified in the function, arg.value can take in two types
    # of values. In this case, it is of type string
    # To test the other type, set it to a dictionary
    input_file = "example.json"
    with open(input_file, "w+") as f:
        f.write('{"foo": "bar"}')
    key_value_arg = KeyValueArg(key='', value=input_file, orig='example.json')
    assert process_data_embed_raw_json_file_arg(key_value_arg) == expected_output


# Generated at 2022-06-23 18:49:08.654609
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from .parse import process_data_raw_json_embed_arg
    arg1 = KeyValueArg('sep', 'key', '"value"')
    arg2 = KeyValueArg('sep', 'key', '[1, 2, 3]')
    arg3 = KeyValueArg('sep', 'key', '{"name": "value"}')
    assert process_data_raw_json_embed_arg(arg1) == 'value'
    assert process_data_raw_json_embed_arg(arg2) == [1, 2, 3]
    assert process_data_raw_json_embed_arg(arg3) == {"name": "value"}

# Generated at 2022-06-23 18:49:14.158090
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # case with valid input:
    sample_arg = KeyValueArg(sep=SEPARATOR_QUERY_PARAM, key='my_key', value='my_value')
    
    assert process_query_param_arg(sample_arg) == 'my_value'

    # case with invalid input:
    sample_bad_arg = KeyValueArg(sep=SEPARATOR_QUERY_PARAM, key='my_key', value=None)
    with pytest.raises(ParseError) as e:
        process_query_param_arg(sample_bad_arg)


# Generated at 2022-06-23 18:49:17.605352
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # ParseError ValueError
    result = process_query_param_arg(KeyValueArg(None, 'key1', ';val1'))
    print(result)

# Generated at 2022-06-23 18:49:23.377178
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # TODO: set features: as_form, as_form_urlencoded
    request_items = RequestItems()
    print(request_items.headers)
    print(request_items.data)
    print(request_items.files)
    print(request_items.params)
    print(request_items.multipart_data)


# Generated at 2022-06-23 18:49:31.818161
# Unit test for function load_json
def test_load_json():
    try:
        load_json(arg=KeyValueArg('a=b'), contents='{}')
    except ParseError:
        assert False
    try:
        load_json(arg=KeyValueArg('a=b'), contents='foo')
        assert False
    except ParseError:
        pass
    try:
        load_json(arg=KeyValueArg('a=b'), contents='{1,2}')
        assert False
    except ParseError:
        pass
    try:
        load_json(arg=KeyValueArg('a=b'), contents='{"foo": "bar"}')
        assert True
    except ParseError:
        assert False

# Generated at 2022-06-23 18:49:34.216986
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(orig='name=Joe', key='name', sep='', value='Joe')
    assert process_data_item_arg(arg) == 'Joe'

# Generated at 2022-06-23 18:49:36.223111
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='q', value='Python', sep='=')
    assert process_query_param_arg(arg) == 'Python'



# Generated at 2022-06-23 18:49:43.278915
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(
        sep=SEPARATOR_HEADER,
        key='foo',
        value='bar',
        orig='foo:bar'
    )) == 'bar'
    # assert process_header_arg(KeyValueArg(
    #     sep=SEPARATOR_HEADER,
    #     key='foo',
    #     value=None,
    #     orig='foo;'
    # )) == None



# Generated at 2022-06-23 18:49:46.960549
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg1 = KeyValueArg('a;')
    arg2 = KeyValueArg('a;b')
    # test without error
    process_empty_header_arg(arg1)
    # test with error
    with pytest.raises(ParseError):
        process_empty_header_arg(arg2)

# Generated at 2022-06-23 18:49:52.202456
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(None, 'a', 'b')) == 'b'
    assert process_header_arg(KeyValueArg(None, 'a', None)) is None
    assert process_header_arg(KeyValueArg(None, 'a', '')) == ''
    assert process_header_arg(KeyValueArg(None, 'a', '""')) is None


# Generated at 2022-06-23 18:49:55.489304
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    filename_test = './test_raw_json.txt'
    process_data_embed_file_contents_arg(KeyValueArg(sep='=', key='', value='\'' + filename_test + '\''))


if __name__ == '__main__':
    test_process_data_embed_file_contents_arg()

# Generated at 2022-06-23 18:49:56.912389
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('key: value')
    header = process_header_arg(arg)
    assert header == 'value'



# Generated at 2022-06-23 18:50:04.002771
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg_subj = {
        "key": 'json_field[key1]',
        "value": 'json_field[value1]',
        "orig": 'json_field[key1]=json_field[value1]',
        "sep": '=',
    }
    arg = KeyValueArg(**arg_subj)
    res = process_data_embed_raw_json_file_arg(arg)
    assert res == "json_field[value1]"

# Generated at 2022-06-23 18:50:07.664067
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg()
    arg.key = "name"
    arg.value= '{"name": "liza", "age": 30}'
    name = process_data_raw_json_embed_arg(arg)
    assert name == {"name": "liza", "age": 30}


# Generated at 2022-06-23 18:50:09.866483
# Unit test for function load_json
def test_load_json():
    js = load_json(None, '[{"a":1}]')
    if js[0]['a'] != 1:
        raise Exception('test_load_json failed')

# Generated at 2022-06-23 18:50:21.328984
# Unit test for function load_text_file
def test_load_text_file():
    sample_test_file1 = os.path.dirname(__file__) + '/test_files/text_sample_file'
    sample_test_file2 = os.path.dirname(__file__) + '/test_files/text_sample_file2'
    assert load_text_file(KeyValueArg("-d", '@'+sample_test_file1)) == "This is a text file"
    assert load_text_file(KeyValueArg("-d", '@'+sample_test_file2)) == "This is a text file2"
    sample_test_file3 = os.path.dirname(__file__) + '/test_files/json_sample_file'

# Generated at 2022-06-23 18:50:25.454977
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON, key=None, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}

# Generated at 2022-06-23 18:50:30.001769
# Unit test for function process_header_arg
def test_process_header_arg():
    ok_arg = KeyValueArg('a', 'b')
    assert process_header_arg(ok_arg) == 'b'

    error_arg = KeyValueArg('a', 'b;')
    with pytest.raises(ParseError):
        process_header_arg(error_arg)

# Generated at 2022-06-23 18:50:39.703632
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_items = RequestItems()
    assert request_items.headers == {}
    assert request_items.data == {}
    assert request_items.files == {}
    assert request_items.params == {}
    assert request_items.multipart_data == {}


    request_items = RequestItems(as_form=True)
    assert request_items.headers == {}
    assert request_items.data == {}
    assert request_items.files == {}
    assert request_items.params == {}
    assert request_items.multipart_data == {}


# Generated at 2022-06-23 18:50:43.354270
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig="d;a=b", key="a", sep="=", value="b")
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-23 18:50:48.731875
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # 	Processing a file upload arg
    file = "httpie/http.py"
    file_sep, filename, mime_type = process_file_upload_arg(file)
    assert file_sep == ";filename="
    assert filename == file
    assert mime_type == "file"

# Generated at 2022-06-23 18:50:51.995924
# Unit test for function load_text_file
def test_load_text_file():
    out = process_data_embed_file_contents_arg(KeyValueArg('name','test_header.txt',';','test_header.txt'))
    assert out == 'test_value\n'

# Generated at 2022-06-23 18:50:52.848421
# Unit test for function load_text_file
def test_load_text_file():
    assert True

# Generated at 2022-06-23 18:50:57.006646
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    kva = KeyValueArg(key='key', value='value', orig='key=value', sep='=')
    assert 'value' == process_query_param_arg(kva)


# Generated at 2022-06-23 18:51:07.679496
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():

    # Test case: when data is a json file
    arg = KeyValueArg(':', 'data', '{"name":"John"}')
    assert process_data_embed_file_contents_arg(arg) == '{"name":"John"}'

    # Test case: when data is a file with no extension
    arg = KeyValueArg(':', 'data', 'testFile.txt')
    assert process_data_embed_file_contents_arg(arg) == ''

    # Test case: when data is a json file with spaces
    arg = KeyValueArg(':', 'data', '"test file with spaces.json"')
    assert process_data_embed_file_contents_arg(arg) == '{"name":"John"}'

    # Test case: when data is a normal file

# Generated at 2022-06-23 18:51:19.900486
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data = '{"top":"0"}'
    arg = KeyValueArg(data, ';', '', '')
    assert process_data_item_arg(arg) == data
    data = '{"top":"0", "child": {"child_top": "1"}}'
    arg = KeyValueArg(data, ';', '', '')
    assert process_data_item_arg(arg) == data

# Command Line Test
# http -f POST http://httpbin.org/post top=value
# http -f POST http://httpbin.org/post top=value child={"child_top":"1"}
# http -f --json POST http://httpbin.org/post top=value child={"child_top":"1"}
# http -f --json POST http://httpbin.org/post top=value child_top=1


# Generated at 2022-06-23 18:51:32.098193
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('sep', 'key', '"json"')
    assert process_data_raw_json_embed_arg(arg) == '"json"'
    # Unit test for function process_data_raw_json_embed_arg
    try:
        process_data_raw_json_embed_arg(KeyValueArg('sep', 'key', '"json"'))
    except ParseError as e:
        assert str(e) == '"key": Expecting value'
    else:
        assert False

    try:
        process_data_raw_json_embed_arg(KeyValueArg('sep', 'key', '"json'))
    except ParseError as e:
        assert str(e) == '"key": Expecting , delimiter:'


# Generated at 2022-06-23 18:51:34.725737
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    param = process_query_param_arg(arg=KeyValueArg(key="name", value="hello", sep=":"))
    print(param)


# Generated at 2022-06-23 18:51:35.659498
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    pass



# Generated at 2022-06-23 18:51:44.413450
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    """ Unit test for function process_data_item_arg.
    """
    try:
        # test normal case
        arg = KeyValueArg(key='', value='value', orig='', sep=SEPARATOR_DATA_STRING, sep_key_value='')
        item_value = process_data_item_arg(arg)
        assert item_value == 'value'
    except ParseError:
        # test abnormal case
        arg = KeyValueArg(key='', value='', orig='', sep=SEPARATOR_DATA_STRING, sep_key_value='')
        with raises(ParseError):
            item_value = process_data_item_arg(arg)



# Generated at 2022-06-23 18:51:46.205888
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    pass
    # process_data_embed_raw_json_file_arg()
    # process_data_embed_raw_json_file_arg()

# Generated at 2022-06-23 18:51:48.608362
# Unit test for function process_header_arg
def test_process_header_arg():
    test_dict = {SEPARATOR_HEADER: "test"}
    assert process_header_arg(test_dict) == "test"


# Generated at 2022-06-23 18:51:54.198547
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # arrange
    arg = KeyValueArg('key', 'file.json', SEPARATOR_DATA_EMBED_RAW_JSON_FILE)

    # act
    value = process_data_embed_raw_json_file_arg(arg)

    # assert
    assert value == {'a': 'b'}



# Generated at 2022-06-23 18:52:04.226210
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems(as_form=False)
    assert items.headers == {}
    assert items.data == {}
    assert items.files == {}
    assert items.params == {}
    assert items.multipart_data == {}

    try:
        arg = KeyValueArg('header', SEPARATOR_HEADER, "val")
        RequestItems.from_args([arg])
    except ParseError:
        pass

    arg = KeyValueArg('header', SEPARATOR_HEADER_EMPTY, None)
    items = RequestItems.from_args([arg])
    print(items)

    arg = KeyValueArg('q', SEPARATOR_QUERY_PARAM, "val")
    items = RequestItems.from_args([arg])


# Generated at 2022-06-23 18:52:05.431817
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    pass



# Generated at 2022-06-23 18:52:14.515864
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data_string1 = '{"jane":"sam1"}'
    data_string2 = '{"jane":"sam", "bob": 1}'
    arg1 = KeyValueArg("-d", "", data_string1, "")
    arg2 = KeyValueArg("-d", "", data_string2, "")
    value_returned_parsed_string1 = {'jane': 'sam1'}
    value_returned_parsed_string2 = {'jane': 'sam', 'bob': 1}
    assert process_data_raw_json_embed_arg(arg1) == value_returned_parsed_string1
    assert process_data_raw_json_embed_arg(arg2) == value_returned_parsed_string2


# Generated at 2022-06-23 18:52:18.695692
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg(0, '', '', '')) == ''
    assert process_data_item_arg(KeyValueArg(0, '', 'abc', '')) == 'abc'

# Generated at 2022-06-23 18:52:24.424500
# Unit test for function process_header_arg
def test_process_header_arg():
    # Test case to check for correct string.
    value = "some-value"
    assert process_header_arg(KeyValueArg("-H", "key", value, "key:"+value, SEPARATOR_HEADER)) == value
    # Test case to check for None
    value = None
    assert process_header_arg(KeyValueArg("-H", "key", value, "key", SEPARATOR_HEADER)) == value


# Generated at 2022-06-23 18:52:27.340555
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert (RequestItems("request_item_args","as_form") ==
            "RequestItems(request_item_args, as_form)")



# Generated at 2022-06-23 18:52:29.671600
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key=None, value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert(process_file_upload_arg(arg) == ('test.txt', open('test.txt','rb'), 'text/plain'))

# Generated at 2022-06-23 18:52:38.509253
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request = RequestItems()

# Generated at 2022-06-23 18:52:41.034664
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('key', 'value', SEPARATOR_DATA_STRING)) == 'value'


# Generated at 2022-06-23 18:52:46.277676
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    value = {"haha": "value"}
    with open('temp.txt', 'w') as f:
        json.dump(value, f)

    arg = KeyValueArg("haha", "temp.txt")
    test_value = process_data_embed_raw_json_file_arg(arg)
    print(test_value)
    os.remove('temp.txt')


# Generated at 2022-06-23 18:52:55.391246
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg1 = KeyValueArg(
        '', '', '', '', '',
        sep='@',
        key='',
        orig='@/tmp/1.txt',
        value='/tmp/1.txt'
    )
    arg2 = KeyValueArg(
        '', '', '', '', '',
        sep='@',
        key='',
        orig='@/tmp/1.txt;text/plain',
        value='/tmp/1.txt;text/plain'
    )
    arg3 = KeyValueArg(
        '', '', '', '', '',
        sep='@',
        key='',
        orig='@/tmp/1.txt;',
        value='/tmp/1.txt;'
    )

    print(process_file_upload_arg(arg1))


# Generated at 2022-06-23 18:52:58.108638
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("this is a file", "test.txt", ";")) == "this is a file"

# Generated at 2022-06-23 18:53:05.060317
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    dirname = os.path.dirname(os.path.abspath(__name__))
    path = os.path.join(dirname, 'test.json')
    arg = KeyValueArg('', path, path)
    result = process_data_embed_raw_json_file_arg(arg)
    if result != {'hello': 'world'}:
        raise ValueError('Load JSON file is not correct')


if __name__ == '__main__':
    test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-23 18:53:09.597104
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg('header', 'Header', '')
    assert process_header_arg(header_arg) is None

    header_arg = KeyValueArg('header', 'Header', 'Value')
    assert process_header_arg(header_arg) == 'Value'


# Generated at 2022-06-23 18:53:10.975376
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('key', 'value', 'sep')) == 'value'


# Generated at 2022-06-23 18:53:19.299097
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg('filename.txt', 'filename.txt')
    assert process_file_upload_arg(file_upload_arg) == ('filename.txt', open('filename.txt', 'rb'), None)

    file_upload_arg_with_mime_type = KeyValueArg('filename.txt', 'filename.txt;text/csv')
    assert process_file_upload_arg(file_upload_arg_with_mime_type) == ('filename.txt', open('filename.txt', 'rb'), 'text/csv')

    file_upload_arg_with_mime_type = KeyValueArg('filename.txt', 'filename.txt;image/png')

# Generated at 2022-06-23 18:53:21.762815
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    content = process_data_embed_file_contents_arg("file://~/testfile.txt")
    assert(content == "hi")

# Generated at 2022-06-23 18:53:24.572084
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='foo', sep=SEPARATOR_QUERY_PARAM, value='bar')
    assert (process_query_param_arg(arg) == 'bar')

# Generated at 2022-06-23 18:53:26.978617
# Unit test for function load_text_file
def test_load_text_file():
    assert 2==2, "test_load_text_file ... OK"


# Generated at 2022-06-23 18:53:29.952529
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    print('Testing functon process_data_item_arg')
    arg = KeyValueArg('--data', 'name=john', SEPARATOR_DATA_STRING)
    value = process_data_item_arg(arg)
    assert value == 'name=john'



# Generated at 2022-06-23 18:53:37.323800
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
  test1 = KeyValueArg("", "", "a=1", "")
  test2 = KeyValueArg("", "", "b=2", "")
  items = RequestItems()
  items.data = {}
  process_data_item_arg(test1) == "1"
  process_data_item_arg(test2) == "2"

  test3 = KeyValueArg("", "", "a", "")
  process_data_item_arg(test3) == "a"

# Generated at 2022-06-23 18:53:40.228535
# Unit test for function load_text_file
def test_load_text_file():
    content_from_file: str = load_text_file(KeyValueArg('filename', 'samples/sample_text.txt', ':'))
    assert content_from_file == 'Sample Content'

# Generated at 2022-06-23 18:53:47.538377
# Unit test for function load_json
def test_load_json():
    # Load json from string:
    json_str = """{
        "name": "John",
        "age": 36,
    }"""
    json_data = load_json(arg=KeyValueArg(key="", value=json_str, sep=""), contents=json_str)
    assert json_data["name"] == "John"
    assert json_data["age"] == 36

    # Load json from file:
    temp_file = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 18:53:57.567691
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Test regular case
    arg = KeyValueArg('index.html', SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'index.html'
    assert mime_type == 'text/html'

    # Test when file does not exist
    with pytest.raises(ParseError):
        arg = KeyValueArg('index.html', SEPARATOR_FILE_UPLOAD)
        process_file_upload_arg(arg)

    # Test when file is empty
    arg = KeyValueArg('', SEPARATOR_FILE_UPLOAD)
    with pytest.raises(ParseError):
        process_file_upload_arg(arg)

    # Test case with MIME type

# Generated at 2022-06-23 18:53:59.210455
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('a', 'b')
    assert process_query_param_arg(arg) == arg.value

# Generated at 2022-06-23 18:54:01.452423
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(SEPARATOR_HEADER_EMPTY, None, None)
    assert process_empty_header_arg(arg) == ''

# Generated at 2022-06-23 18:54:07.922234
# Unit test for function load_text_file
def test_load_text_file():
    expect_content = [b'hello', b'world']
    with open('./dummy', 'wb') as f:
        f.write(b'hello\nworld')
    assert load_text_file(KeyValueArg('', '', './dummy')) == expect_content
    os.remove('./dummy')

# Generated at 2022-06-23 18:54:11.394876
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    t = process_query_param_arg(KeyValueArg('--data', 'username=sdl&password=123'))
    assert t == 'username=sdl&password=123'

# Generated at 2022-06-23 18:54:12.382222
# Unit test for function load_json
def test_load_json():
    test_dict = load_json(2,"test")
    #check for ValueError
    assert isinstance(test_dict, dict)

# Generated at 2022-06-23 18:54:14.960083
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg("img", "0.png", "img=0.png")
    print(process_file_upload_arg(arg))


# Generated at 2022-06-23 18:54:16.964012
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('Content-Type', 'application/json')) == 'application/json'


# Generated at 2022-06-23 18:54:18.315140
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert "Hello" == process_query_param_arg(KeyValueArg(key="a", sep=SEPARATOR_QUERY_PARAM, value="Hello"))

# Generated at 2022-06-23 18:54:25.145693
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('key', 'value')) == 'value'
    assert process_data_item_arg(KeyValueArg('key', '')) == ''
    assert process_data_item_arg(KeyValueArg('key', None)) == ''
    assert process_data_item_arg(KeyValueArg('key', '/file/path')) == '/file/path'


# Generated at 2022-06-23 18:54:31.750857
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    import os
    import httpie

    directory = os.path.dirname(os.path.realpath(httpie.__file__))
    test_input_file = os.path.join(directory, "tests", "fixtures", "test_raw_json_data.json")

    test_arg = KeyValueArg('embed', '', '', '', test_input_file)
    assert process_data_embed_raw_json_file_arg(test_arg) == {"a": "b"}

# Generated at 2022-06-23 18:54:34.948614
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(orig='key=value', key='key', value='value', sep='=')
    assert process_data_item_arg(arg) == 'value'


# Generated at 2022-06-23 18:54:42.657320
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    a = KeyValueArg(
        key = None,
        value = '{"a": 1, "b": 2}',
        sep = '=',
        orig = '{a=1, b=2}',
        is_form = True
    )
    assert process_data_embed_raw_json_file_arg(a) == {"a": 1, "b": 2}
    a = KeyValueArg(
        key = None,
        value = '{"a": 1, "b": 3}',
        sep = '=',
        orig = '{a=1, b=3}',
        is_form = True
    )
    assert process_data_embed_raw_json_file_arg(a) != {"a": 1, "b": 2}

# Generated at 2022-06-23 18:54:46.740631
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        value='value',
        orig='key=value',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )
    value = process_data_embed_raw_json_file_arg(arg)
    print(value)

# Generated at 2022-06-23 18:54:49.191884
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('Header;')) == None

# Generated at 2022-06-23 18:55:00.115011
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg(KeyValueArg('Header;', "a"))
    except ParseError as e:
        assert e.message == 'Invalid item "Header;" ' \
               '(to specify an empty header use `Header;`)'

    try:
        process_empty_header_arg(KeyValueArg('header;', "a"))
    except ParseError as e:
        assert e.message == 'Invalid item "header;" ' \
               '(to specify an empty header use `header;`)'
    assert process_empty_header_arg(KeyValueArg('Header;', "")) == ""
    assert process_empty_header_arg(KeyValueArg('header;', "")) == ""

# Generated at 2022-06-23 18:55:03.196852
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg("a=b")=="b"
    assert process_query_param_arg("a=1")=="1"


# Generated at 2022-06-23 18:55:03.828189
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    pass

# Generated at 2022-06-23 18:55:10.711471
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    file_name = "./data.json"
    with open(file_name, "w") as f:
        data = {
            "Key": "Value"
        }
        f.write("{}".format(data))

    arg = KeyValueArg("data", data=None, sep="=", orig=file_name)
    print(process_data_embed_raw_json_file_arg(arg))


# Generated at 2022-06-23 18:55:21.971598
# Unit test for constructor of class RequestItems
def test_RequestItems():
    parser = argparse.ArgumentParser()
    parser.add_argument('--header')
    parser.add_argument('--query-param')
    parser.add_argument('--file-upload')
    parser.add_argument('--data-string')
    parser.add_argument('--data-embed-file-contents')
    args = parser.parse_args()
    request_item_args = [
        KeyValueArg('header', 'value'),
        KeyValueArg('query-param', 'value'),
        KeyValueArg('file-upload', 'value'),
        KeyValueArg('data-string', 'value'),
        KeyValueArg('data-embed-file-contents', 'value'),
    ]
    request_items = RequestItems.from_args(request_item_args)

# Generated at 2022-06-23 18:55:24.381650
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    input = 'key:value'
    expected = 'value'
    actual = process_data_item_arg(input)
    assert actual == expected, 'Failed to parse "%s"' % input


# Generated at 2022-06-23 18:55:27.784750
# Unit test for function load_json
def test_load_json():
    assert load_json(None, "{'a':1}") == {'a': 1}
    assert load_json(None, '{"a":1}') == {'a': 1}
    try:
        load_json(None, '{a:1}')
        assert False
    except ParseError:
        assert True


# Generated at 2022-06-23 18:55:40.329713
# Unit test for function load_json
def test_load_json():
    test_input = '[{"a": "i", "b": "j"}, {"a": "k", "b": "l"}]'
    expected = [{'a': 'i', 'b': 'j'}, {'a': 'k', 'b': 'l'}]
    actual = load_json({'orig': '', 'value': test_input}, test_input)
    assert expected == actual
    test_input = '[{"a": "i", "b": "j"}, {"a": "k", "b": "l"}]'
    expected = [{'a': 'i', 'b': 'j'}, {'a': 'k', 'b': 'l'}]
    actual = load_json({'orig': '', 'value': test_input}, test_input)
    assert expected == actual



# Generated at 2022-06-23 18:55:48.928775
# Unit test for function load_json
def test_load_json():
    JSONType = Union[str, bool, int, list, dict]

    content = '[{"name": "wenshao", "age": 30, "hobbies": ["reading", "gym"], \
        "height": 1.82, "weight": 84, "married": false}]'

    arg = KeyValueArg('user', 'file', '=[json]', '[json]')
    value = load_json(arg, content)
    assert value == [{"name": "wenshao", "age": 30, "hobbies": ["reading", "gym"],
        "height": 1.82, "weight": 84, "married": False}]

    file_path = './test_data.json'
    arg = KeyValueArg('user', 'file', '=@' + file_path, '=@' + file_path)

# Generated at 2022-06-23 18:55:53.210040
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('h')
    try:
        process_empty_header_arg(arg)
    except ParseError as e:
        print(e)

    arg = KeyValueArg('h', value='some value')
    try:
        process_empty_header_arg(arg)
    except ParseError as e:
        print(e)



# Generated at 2022-06-23 18:55:55.489741
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="file_a", value="my_file.txt", sep="@")
    out = process_file_upload_arg(arg)
    assert out == ('my_file.txt', open('my_file.txt', 'rb'), 'text/plain')



# Generated at 2022-06-23 18:56:03.289825
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # test {"aaa":1, "bbb":2}
    test_arg = KeyValueArg('aaa', '1', SEPARATOR_DATA_RAW_JSON)
    assert(isinstance(process_data_raw_json_embed_arg(test_arg), dict))
    assert(process_data_raw_json_embed_arg(test_arg)['aaa'] == 1)
    test_arg = KeyValueArg('bbb', '2', SEPARATOR_DATA_RAW_JSON)
    assert(isinstance(process_data_raw_json_embed_arg(test_arg), dict))
    assert(process_data_raw_json_embed_arg(test_arg)['bbb'] == 2)

    # test {1}
    test_arg = KeyValueArg('', '1', SEPARATOR_DATA_RAW_JSON)

# Generated at 2022-06-23 18:56:07.103717
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    kwarg = KeyValueArg('', '', SEPARATOR_DATA_EMBED_RAW_JSON_FILE, './test.json')
    assert isinstance(process_data_embed_raw_json_file_arg(kwarg), dict)

# Generated at 2022-06-23 18:56:15.631240
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg(
        'foo.txt', 'File(%s)' % 'foo/bar.txt', 'File', '%s' % 'foo/bar.txt')) == ('bar.txt', open('foo/bar.txt'), None)
    assert process_file_upload_arg(KeyValueArg(
        'foo.txt', 'File(%s)' % 'foo/bar.txt;image/png', 'File', '%s' % 'foo/bar.txt;image/png')) == (
           'bar.txt', open('foo/bar.txt'), 'image/png')


# Generated at 2022-06-23 18:56:21.192566
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    original_value = "this is a test"
    arg0 = KeyValueArg(key="in_0", value=original_value, orig="in_0=" + original_value, sep=';')
    process_value = process_data_item_arg(arg0)
    assert process_value == original_value

# Generated at 2022-06-23 18:56:26.978286
# Unit test for function load_text_file
def test_load_text_file():
    with open('testfile.txt', 'w') as f:
        f.write('This is line 1\n'
                'This is line 2\n'
                'This is line 3\n')
    item = KeyValueArg(None, None, None, '~/testfile.txt')
    actual = load_text_file(item)
    assert actual == 'This is line 1\nThis is line 2\nThis is line 3\n'
    os.remove('testfile.txt')

# Generated at 2022-06-23 18:56:28.077014
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    process_query_param_arg(1)

# Generated at 2022-06-23 18:56:32.565956
# Unit test for function process_header_arg
def test_process_header_arg():
    # make an arg object
    arg = KeyValueArg('X-GitHub-OTP', sep=":", key='X-GitHub-OTP', value='required;')
    print(process_header_arg(arg))


# Generated at 2022-06-23 18:56:42.269716
# Unit test for function load_json
def test_load_json():
    json_string_1 = '{"glossary": {"title": "example glossary", "GlossDiv": {"title": "S"}}}'
    json_result_1 = {"glossary": {"title": "example glossary", "GlossDiv": {"title": "S"}}}
    assert load_json(json_string_1) == json_result_1

    # If the string contains a non-existing key, the function will return an error
    json_string_2 = '{"glossary": {"title": "example glossary", "GlossDiv": {"title": "S"}, "GlossList": "error"}}'
    try:
        load_json(json_string_2)
    except ValueError:
        assert True



# Generated at 2022-06-23 18:56:45.861844
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, 'x', 'README.md')) == open('../README.md', 'r').read()

# Generated at 2022-06-23 18:56:47.729449
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg("abc", "abc")) == "abc"


# Generated at 2022-06-23 18:56:50.765957
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    args = [KeyValueArg(None, "a", "1", "a=1")]
    result = RequestItems.from_args(args)
    assert result.data == {"a": "1"}

# Generated at 2022-06-23 18:57:00.369587
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    # [[url, key, value, expected]]
    test_cases = [
        ["http://httpbin.org/get?a=b&c=d", "a", "b", "b"],
        ["http://httpbin.org/get?a=b&c=d", "c", "d", "d"]
    ]

    for test in test_cases:
        arg = KeyValueArg(test[0])
        arg.key = test[1]
        arg.value = test[2]
        actual = process_query_param_arg(arg)
        assert actual == test[3]



# Generated at 2022-06-23 18:57:04.199289
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # Arrange
    arg = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key="key", value="value")

    # Act
    actual = process_empty_header_arg(arg)

    # Assert
    expected = arg.value
    assert actual == expected



# Generated at 2022-06-23 18:57:13.734214
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    import os
    import json
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.items import process_data_embed_file_contents_arg 
    json_file=os.path.join(os.getcwd(),'test/test_file.json')
    arg = KeyValueArg(orig='filename', key=None, sep='==', value=json_file)
    result = process_data_embed_file_contents_arg(arg)
    assert result == '{"abc": "abc_value", "123": 123}'
    assert type(json.loads(result))==dict

# Generated at 2022-06-23 18:57:17.330368
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    def test(arg: KeyValueArg, expected: str) -> None:
        assert process_data_embed_file_contents_arg(arg) == expected
    arg = KeyValueArg("name:=data.txt")
    expected = "abc"
    test(arg, expected)


# Generated at 2022-06-23 18:57:21.205319
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg("q", "param=value")
    assert process_query_param_arg(arg) == "param=value"

# Generated at 2022-06-23 18:57:22.565835
# Unit test for function load_text_file
def test_load_text_file():
    result = load_text_file('')
    assert (result == 'hello world')

# Generated at 2022-06-23 18:57:27.807471
# Unit test for function process_header_arg
def test_process_header_arg():
    assert 'a' == process_header_arg(KeyValueArg('Header', 'a', ':'))
    assert "'a'" == process_header_arg(KeyValueArg("Header", "'a'", ':'))
    assert None == process_header_arg(KeyValueArg("Header", "", ":"))


# Generated at 2022-06-23 18:57:34.247676
# Unit test for function load_json
def test_load_json():
    # test for invalid json
    try:
        val = load_json('invalid', '{"key":"value", in "dict"')
        print(val)
        assert False
    except ParseError:
        assert True
    # test for valid json
    val = load_json('valid', '{"key":"value"}')
    assert val == {'key': 'value'}

# Generated at 2022-06-23 18:57:36.950008
# Unit test for function load_json
def test_load_json():
    assert load_json(None, '{"username": "jay", "password": "123456"}') == {'username': 'jay', 'password': '123456'}

test_load_json()

# Generated at 2022-06-23 18:57:41.514561
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(None, None, None, None, None)
    item.value = "test.txt"
    item.orig = 'test.txt'
    result = load_text_file(item)
    assert result == "Hello World"


# Generated at 2022-06-23 18:57:49.887199
# Unit test for constructor of class RequestItems
def test_RequestItems():
    key = "name"
    value = "httpie"
    ri = RequestItems()
    # Test the constructor of class RequestItems
    # and function init_items in file cli/dicts.py
    assert isinstance(ri.headers, RequestHeadersDict)
    assert isinstance(ri.data, RequestJSONDataDict)
    assert isinstance(ri.files, RequestFilesDict)
    assert isinstance(ri.params, RequestQueryParamsDict)
    # Test constructor of class RequestItems
    # and function from_args in file cli/dicts.py
    ri = RequestItems.from_args([KeyValueArg(key, value, ":")])
    assert ri.headers == {key: value}
    assert ri.data == {key: value}
    assert ri.files == {}


# Generated at 2022-06-23 18:57:52.529827
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    args = KeyValueArg("key", "value")
    assert('value' == process_query_param_arg(args))
