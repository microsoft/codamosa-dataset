

# Generated at 2022-06-23 18:47:57.086298
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # unit test for post type
    original_request_item_args = \
    [
        KeyValueArg(key='token', value='1234', orig='token:1234', sep=':'),
        KeyValueArg(key='db', value='users', orig='db:users', sep=':'),
        KeyValueArg(key='user', value='{ "name": "alice", "id": 23 }', orig='user:{ "name": "alice", "id": 23 }', sep='=')
    ]

# Generated at 2022-06-23 18:48:01.760441
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file_('/home/xyz') == (
        "cannot embed the content of \"/home/xyz\", not a UTF8 or ASCII-encoded text file"
    )

# Generated at 2022-06-23 18:48:04.294550
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    instance = process_empty_header_arg(KeyValueArg(None, None, ''))
    assert instance is not None


# Generated at 2022-06-23 18:48:09.608487
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_arg = KeyValueArg(
        'file',
        'test.json',
        '=',
        SEPARATOR_FILE_UPLOAD
    )
    returned_mime_type = process_file_upload_arg(test_arg)[2]
    assert returned_mime_type == 'application/json'

# Generated at 2022-06-23 18:48:14.471428
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems.from_args([KeyValueArg(key="header1",
                                               value="header1value",
                                               sep=":")])
    assert items.headers["header1"] == "header1value"
    assert items.data == {}
    assert items.files == {}
    assert items.params == {}



# Generated at 2022-06-23 18:48:25.145735
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    print(process_data_raw_json_embed_arg(KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'a', '"b"')))
    print(process_data_raw_json_embed_arg(KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'c', '1')))
    print(process_data_raw_json_embed_arg(KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'd', '[1, 2, 3]')))
    print(process_data_raw_json_embed_arg(KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'e', '{"a": 1, "b": 2}')))



# Generated at 2022-06-23 18:48:27.860266
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('path', '--path', 'test_path')
    file_content = load_text_file(item)
    assert(file_content == 'This is a test file')

# Generated at 2022-06-23 18:48:39.405382
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # test_load_json
    arg = KeyValueArg(key="name", value="myname", orig="name=myname", sep="=")
    value = load_json_preserve_order(arg.value)
    assert value == 'myname'

    # with non-existing file
    arg = KeyValueArg(key="name", value="non-existing", orig="name=non-existing", sep="=")
    try:
        load_json(arg, False)
    except ParseError as e:
        assert str(e) == '"name=non-existing": Failed to load "non-existing"'

    # with invalid json file
    arg = KeyValueArg(key="name", value="invalid_json.json", orig="name=invalid_json.json", sep="=")

# Generated at 2022-06-23 18:48:40.661155
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    pass


# Generated at 2022-06-23 18:48:42.703197
# Unit test for function load_text_file
def test_load_text_file():
    # arrange
    name_arg = KeyValueArg('a=b')
    # action
    assert load_text_file(name_arg) == 'b'


# Generated at 2022-06-23 18:48:53.465168
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test1 = RequestItems.from_args([KeyValueArg(
        'key1', 'value1', 'key1=value1')])
    assert test1.params == {'key1': 'value1'}
    assert test1.data == {}
    assert test1.headers == {}
    assert test1.files == {}
    assert test1.multipart_data == {}
    test2 = RequestItems.from_args([KeyValueArg(
        'key2', 'value2', 'key2=value2')])
    assert test2.params == {'key2': 'value2'}
    assert test2.data == {}
    assert test2.headers == {}
    assert test2.files == {}
    assert test2.multipart_data == {}



# Generated at 2022-06-23 18:48:55.875992
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('file','temp.txt')
    load_text_file(item)


# Generated at 2022-06-23 18:48:58.746716
# Unit test for function process_header_arg
def test_process_header_arg():
    header = "property of header"
    header_arg = KeyValueArg(None, header, header)
    assert header == process_header_arg(header_arg)


# Generated at 2022-06-23 18:49:02.934027
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(orig="abc", key="abc", sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, value="../data/data.json")
    result = process_data_embed_file_contents_arg(arg)
    assert result == '{"a": 1, "b": 2}'

# Generated at 2022-06-23 18:49:06.609795
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg
    result = process_query_param_arg(KeyValueArg('key1', 'val1', 'key1=val1'))
    print(result)


# Generated at 2022-06-23 18:49:11.479471
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(orig=':', key='', value='', sep=':')

    result = "abcd\n"
    f = open(os.path.expanduser('~/test'), 'w')
    f.write(result)
    f.close()
    assert process_data_embed_file_contents_arg(arg) == result



# Generated at 2022-06-23 18:49:14.889958
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    print("test_process_query_param_arging")
    print(process_query_param_arg(KeyValueArg('name','value','')))


# Generated at 2022-06-23 18:49:26.930224
# Unit test for function load_json
def test_load_json():

    assert load_json(None, '{"a": "b"}') == {"a": "b"}
    assert load_json(None, '1') == 1
    assert load_json(None, '"abc"') == 'abc'
    assert load_json(None, 'true') == True
    assert load_json(None, 'false') == False
    assert load_json(None, '[]') == []
    assert load_json(None, 'null') == None
    assert load_json(None, '{"a": {"b": 1}}') == {"a": {"b": 1}}
    assert load_json(None, '[1,2,3]') == [1,2,3]

    e = None
    try:
        load_json(None, '"abc"')
    except ParseError as e:
        pass


# Generated at 2022-06-23 18:49:35.125892
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args = []
    args.append("C://Users//tclsz.IMPACT//Desktop//test.txt")
    args.append("C://Users//tclsz.IMPACT//Desktop//test.txt;image/jpg")
    args.append("C://Users//tclsz.IMPACT//Desktop//test.txt;;")
    args.append("C://Users//tclsz.IMPACT//Desktop//test.txt;image/jpg;")
    for arg in args:
        parts = arg.split(';')
        filename = parts[0]
        mime_type = parts[1] if len(parts) > 1 else None

# Generated at 2022-06-23 18:49:39.275244
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    result = process_data_embed_raw_json_file_arg(KeyValueArg("test",
                                                              "/Users/test/testFile.txt"))
    # Expected result is a dictionary
    assert isinstance(result, dict)

# Generated at 2022-06-23 18:49:42.522968
# Unit test for function process_header_arg
def test_process_header_arg():
	a = process_header_arg('Content-Type')
	b = process_header_arg('User-Agent')
	assert a == 'Content-Type'
	assert b == 'User-Agent'

# Generated at 2022-06-23 18:49:45.311829
# Unit test for function process_header_arg
def test_process_header_arg():
    raw_input = KeyValueArg("key", "value", "{sep}")
    assert process_header_arg(raw_input) == "value"



# Generated at 2022-06-23 18:49:58.061049
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # test for true case
    # as_form = False
    as_form = False
    instance = RequestItems(as_form)
    assert isinstance(instance.headers , RequestHeadersDict)
    assert isinstance(instance.data, RequestJSONDataDict)
    assert isinstance(instance.files, RequestFilesDict)
    assert isinstance(instance.params, RequestQueryParamsDict)
    assert isinstance(instance.multipart_data, MultipartRequestDataDict)

    # as_form = True
    as_form = True
    instance = RequestItems(as_form)
    assert isinstance(instance.headers, RequestHeadersDict)
    assert isinstance(instance.data, RequestDataDict)
    assert isinstance(instance.files, RequestFilesDict)

# Generated at 2022-06-23 18:50:08.175320
# Unit test for function load_json
def test_load_json():
    json_str = '{"a": "b"}'
    assert load_json(None, json_str) == {"a": "b"}

    json_str = '{"a": "b", "c": "d"}'
    assert load_json(None, json_str) == {"a": "b", "c": "d"}

    json_str = '{"a": 1234}'
    assert load_json(None, json_str) == {"a": 1234}

    json_str = '{"a": false}'
    assert load_json(None, json_str) == {"a": False}

    json_str = '{"a": true}'
    assert load_json(None, json_str) == {"a": True}


# Generated at 2022-06-23 18:50:11.336832
# Unit test for function load_json
def test_load_json():
    assert load_json("test", '{"a": 1, "b": 2.0, "c": [1, 2], "d": true}') == \
        {"a": 1, "b": 2.0, "c": [1, 2], "d": True}

# Generated at 2022-06-23 18:50:17.244090
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    p1 = KeyValueArg('param1', 'value1', ';')
    assert process_query_param_arg(p1) == 'value1'
    try:
        p2 = KeyValueArg('param1', 'value1', ':')
        assert process_query_param_arg(p2) == 'value1'
    except ParseError as e:
        print(e)



# Generated at 2022-06-23 18:50:22.989873
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems(as_form=False)
    assert isinstance(instance.files, RequestFilesDict)
    assert isinstance(instance.data, RequestJSONDataDict)
    assert isinstance(instance.headers, RequestHeadersDict)
    assert isinstance(instance.multipart_data, MultipartRequestDataDict)
    assert isinstance(instance.params, RequestQueryParamsDict)

# Generated at 2022-06-23 18:50:25.158459
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg("--header","key:value")) == "value"


# Generated at 2022-06-23 18:50:27.816078
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    x = process_data_raw_json_embed_arg(KeyValueArg('key' + SEPARATOR_DATA_RAW_JSON + 'value'))
    assert x == 'value'

# Generated at 2022-06-23 18:50:32.231028
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import json
    jsonObj = json.loads('{"name":"John", "age":30, "car":null}')
    jsonStr = json.dumps(jsonObj)
    value = '{"name":"John", "age":30, "car":null}'
    assert jsonStr == value

# Generated at 2022-06-23 18:50:38.385142
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(arg=KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key='content-type', value=None)) is None
    try:
        process_empty_header_arg(arg=KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key='content-type', value='json'))
    except ParseError as e:
        assert str(e) == 'Invalid item "content-type:json" (to specify an empty header use `Header;`)'

# Generated at 2022-06-23 18:50:43.498059
# Unit test for function load_json
def test_load_json():
    str = '{"a":"b"}'
    json = load_json(str)
    assert json == {"a":"b"}

    str = '{"a":[1,2,3]}'
    json = load_json(str)
    assert json == {"a":[1,2,3]}

    str = '[1,2,3]'
    json = load_json(str)
    assert json == [1,2,3]
    print ("test_load_json pass!")

# Generated at 2022-06-23 18:50:49.820834
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(['somekey'], '{"somevalue":"valuefromstuff"}')) == {"somevalue": "valuefromstuff"}
# This is the only one of the functions in this file that is callable
# externally, so only we test this one, as it then calls all the others
# and they are implicitly tested by the above test.


# Generated at 2022-06-23 18:50:55.993847
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # normal case
    item = KeyValueArg(SEPARATOR_HEADER_EMPTY, 'a', 'b')
    print(process_empty_header_arg(item))
    # raise exception
    try:
        item = KeyValueArg(SEPARATOR_HEADER_EMPTY, 'a', 'b')
        process_empty_header_arg(item)
    except ParseError as e:
        print(e)


# Generated at 2022-06-23 18:51:05.788015
# Unit test for function load_json
def test_load_json():
    import io
    import json
    json_file = '''{
    "fiile_stnd-alone_1": [
        "file-stand-alone-content-1",
        "file-stand-alone-content-2"
    ],
    "file_stand-alone_2": [
        "file-stand-alone-content-1",
        "file-stand-alone-content-2",
        "file-stand-alone-content-3"
    ]
    }'''
    f = io.StringIO(json_file)
    print(f.name)
    print(load_json("test_load_json", json.load(f)))


# Generated at 2022-06-23 18:51:07.300113
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('name', '')) == ''
    

# Generated at 2022-06-23 18:51:16.456543
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_value = process_data_embed_raw_json_file_arg(
        KeyValueArg(
            'raw-json',
            '@L2.json',
            '@L2.json',
        )
    )
    assert type(test_value) == dict
    assert test_value['L2'] == {'L3': ['L3-1', 'L3-2', 'L3-3']}
    assert test_value['L1'] == {'L2': {'L3': ['L3-1', 'L3-2', 'L3-3']}}

# Generated at 2022-06-23 18:51:28.811385
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg('key', 'value', '=')) == 'value'
    assert process_query_param_arg(KeyValueArg('key', 'lyrics=cake', '=')) == 'lyrics=cake'
    # Adding spaces around the separator is allowed
    assert process_query_param_arg(KeyValueArg('key', 'name=your mother', '= ')) == 'name=your mother'
    assert process_query_param_arg(KeyValueArg('key', 'name = your mother', ' = ')) == 'name = your mother'
    assert process_query_param_arg(KeyValueArg('key', ' ', '=')) == ''
    # Separator does not need to be the last character

# Generated at 2022-06-23 18:51:38.486965
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import pytest
    from io import BytesIO
    testfile = BytesIO(b'0123456789')
    filename = 'filename'
    filetype = 'file_type/file'
    upload = process_file_upload_arg(KeyValueArg(filename, filename + SEPARATOR_FILE_UPLOAD + filetype))
    assert upload == ('filename', testfile, 'file_type/file')
    pytest.raises(ParseError, process_file_upload_arg, KeyValueArg('filename', 'filename' + SEPARATOR_FILE_UPLOAD))
    pytest.raises(ParseError, process_file_upload_arg, KeyValueArg('filename', 'wrongname' + SEPARATOR_FILE_UPLOAD + filetype))

# Generated at 2022-06-23 18:51:41.724901
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    item = KeyValueArg(orig="-f", sep=SEPARATOR_FILE_UPLOAD, key="", value="<folder>/<file>.txt", extras=None)
    result = process_file_upload_arg(item)
    print(result)

# Generated at 2022-06-23 18:51:48.560140
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg('file@/home/file.txt', 'file@')
    file_upload_arg.value = '/home/file.txt'
    file_upload_arg.key = 'file'
    file_upload_arg.sep = '@'
    file_upload_arg.orig = 'file@/home/file.txt'
    t = process_file_upload_arg(file_upload_arg)
    f = open(os.path.expanduser('/home/file.txt'), 'rb')
    mime_type = get_content_type('/home/file.txt')
    assert(t == ('file.txt', f, mime_type))



# Generated at 2022-06-23 18:51:53.298071
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key=None,value='/home/binoy/Pictures/Screenshot from 2019-03-03 18-13-39.png',sep=None,orig=None)
    print(process_file_upload_arg(arg))

# Generated at 2022-06-23 18:51:56.989440
# Unit test for function process_header_arg
def test_process_header_arg():
    string = 'header1:value1'
    arg = KeyValueArg('Header', 'header1', 'value1', string)
    assert process_header_arg(arg) == 'value1'



# Generated at 2022-06-23 18:52:00.771601
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key_value_arg = KeyValueArg('data1', '=', 'testdata.json')
    result = process_data_embed_file_contents_arg(key_value_arg)
    assert result == '{"user": "test"}'

# Generated at 2022-06-23 18:52:04.862456
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    line = 'good'
    arg = KeyValueArg(line)
    arg.value = 'good'
    arg.sep = SEPARATOR_QUERY_PARAM
    assert process_query_param_arg(arg) == 'good'

# Generated at 2022-06-23 18:52:05.645160
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    pass

# Generated at 2022-06-23 18:52:14.641583
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg

# Generated at 2022-06-23 18:52:24.316062
# Unit test for function load_json
def test_load_json():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    json_dict = {
        "alpha": "hello",
        "beta": "world",
        "gamma": 1.234
    }
    data = RequestDataDict()
    data["raw_json_correct"] = load_json(
        KeyValueArg(orig="raw_json_correct", key="raw_json_correct", sep="", value=json_dict),
        json_dict
    )

# Generated at 2022-06-23 18:52:29.414840
# Unit test for function load_json
def test_load_json():
    import pytest
    arg =KeyValueArg('{"name" = "test"}')
    contents = '{"name": "test"}'
    assert load_json(arg, contents) == {"name": "test"}
    arg =KeyValueArg('{"name" = "test"}')
    contents = '{"name": "test"}'
    with pytest.raises(ParseError):
        load_json(arg, contents)

# Generated at 2022-06-23 18:52:33.813298
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    testFile = os.path.join(os.path.dirname(__file__), '..\\test.json')
    arg = 'testFile=@test.json'
    result = process_data_embed_raw_json_file_arg(KeyValueArg(arg, '=', '@'))
    assert result['test'] == 'test'


# Generated at 2022-06-23 18:52:35.525731
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert(process_data_item_arg("abc") == "abc")

# Generated at 2022-06-23 18:52:38.109736
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_data = process_data_embed_raw_json_file_arg(KeyValueArg(
        key=None, value="test.json", sep=None, orig=None))
    assert json_data == {"test": "Hello"}

# Generated at 2022-06-23 18:52:39.777201
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('-d', 'http://localhost/', 'foo')
    path = item.value
    print(item)
    print(path)

# Generated at 2022-06-23 18:52:42.549764
# Unit test for function process_header_arg
def test_process_header_arg():
    kva = KeyValueArg('Header', 'value', 'Header:value')
    assert process_header_arg(kva) == 'value'



# Generated at 2022-06-23 18:52:54.956584
# Unit test for function load_json
def test_load_json():
    # ValueError
    with pytest.raises(ParseError) as excinfo:
        # some invalid json content
        invalid_json_contents = "{"
        load_json(KeyValueArg("", ""), invalid_json_contents)
    assert excinfo.value.err_msg == '"": Expecting property name:'

    # Can successfully load valid json contents
    valid_json_contents = "{\"a\": 1, \"b\": 2}"
    assert load_json(KeyValueArg("", ""), valid_json_contents) == {"a": 1, "b": 2}

    # Can successfully load valid json contents with array
    valid_json_contents_with_array = "[1, 2]"

# Generated at 2022-06-23 18:53:05.667684
# Unit test for function load_json
def test_load_json():
    import json

    # Test loading empty JSON data
    parsed = load_json(
        KeyValueArg(
            'key', '', '/',
            ''
        ),
        ''
    )
    assert json.dumps(parsed) == '{}'

    # Test loading some JSON data
    parsed = load_json(
        KeyValueArg(
            'key', '', '/',
            ''
        ),
        '[1,2]'
    )
    assert json.dumps(parsed) == "[1, 2]"

    # Test error when loading invalid JSON
    try:
        exception_thrown = False
        parsed = load_json(
            KeyValueArg(
                'key', '', '/',
                ''
            ),
            'invalid'
        )
    except ParseError:
        exception_th

# Generated at 2022-06-23 18:53:06.835898
# Unit test for function load_json
def test_load_json():
    pass
    # load_json(arg,contents)

# Generated at 2022-06-23 18:53:10.993965
# Unit test for function load_json
def test_load_json():
    try:
        load_json(load_json, "{'abc':'abc'}")
    except ParseError as e:
        assert True

    assert load_json(load_json, "{'abc':['abc', 123]}") == {'abc':['abc', 123]}


# Generated at 2022-06-23 18:53:19.330461
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli import parser
    from httpie.cli.parser import KeyValueArg

# Generated at 2022-06-23 18:53:21.568242
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg('test', 'raw_json', '{"a": "b"}')
    result = load_json(arg, arg.value)
    assert isinstance(result, dict)
    assert result == {"a": "b"}

# Generated at 2022-06-23 18:53:28.494232
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item1 = KeyValueArg('@test.json', '@test.json')
    result1 = process_data_embed_raw_json_file_arg(item1)
    # print(result1)
    assert result1 == {'a':1}

    item2 = KeyValueArg('id=@test.json', 'id=@test.json')
    result2 = process_data_embed_raw_json_file_arg(item2)
    assert result2 == {'a': 1}

# Generated at 2022-06-23 18:53:33.243360
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from io import StringIO
    from pygments import formatters, highlight, lexers

    f = StringIO()
    JSONLexer = lexers.get_lexer_by_name("json")
    lf = formatters.get_formatter_by_name("terminal")

    with open('ExchangeInfo.json', 'r') as file:
        data = file.read().replace('\n', '')

    data = highlight(data, JSONLexer, lf)
    with open('ExchangeInfo.json', 'w') as file:
        file.write(data)

# Generated at 2022-06-23 18:53:36.710940
# Unit test for function process_header_arg
def test_process_header_arg():
    item = RequestItems()
    header_arg = KeyValueArg(':')
    header_arg.key = 't'
    header_arg.value = 'val'
    header_arg.orig = 't:val'
    item.headers = process_header_arg(header_arg)
    assert item.headers == {'t': 'val'}


# Generated at 2022-06-23 18:53:40.002256
# Unit test for function process_header_arg
def test_process_header_arg():
    h1 = KeyValueArg("abc", "def")
    h2 = KeyValueArg("hehe", "")
    assert process_header_arg(h1) == "def"
    assert process_header_arg(h2) == ""


# Generated at 2022-06-23 18:53:42.590575
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = KeyValueArg(SEPARATOR_HEADER, 'Content-Type', 'application/json') 
    assert process_header_arg(header_arg) == 'application/json'


# Generated at 2022-06-23 18:53:55.277996
# Unit test for function load_json
def test_load_json():
    """
    Test function load_json()
    """
    data = """{
        "name": "A_Z",
        "age": 18,
        "children": [
            {"name": "B_Z"}
        ]
    }"""
    json_data = load_json(data)
    assert(type(json_data) == dict)
    assert(type(json_data['name']) == str)
    assert(type(json_data['children']) == list)
    assert(type(json_data['children'][0]) == dict)
    assert(type(json_data['children'][0]['name']) == str)
    assert(json_data['name'] == 'A_Z')
    assert(json_data['age'] == 18)

# Generated at 2022-06-23 18:53:59.452085
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    process_data_embed_raw_json_file_arg('test.json')

# Generated at 2022-06-23 18:54:01.488375
# Unit test for function load_text_file
def test_load_text_file():
    item= load_text_file("D:\\files\\test.txt")
    print(item)

# Generated at 2022-06-23 18:54:03.262757
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    print (process_data_embed_file_contents_arg(KeyValueArg('@', 'logs/june_cloudtrail.json')))

# Generated at 2022-06-23 18:54:04.477109
# Unit test for function load_text_file
def test_load_text_file():
    load_text_file("test")

# Generated at 2022-06-23 18:54:07.551099
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('name=httpie')
    assert process_query_param_arg(arg) == 'httpie'

# Generated at 2022-06-23 18:54:18.034312
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('header', 'Authorization')) == 'Authorization'
    assert process_header_arg(KeyValueArg('header', 'Authorization', False)) == 'Authorization'
    assert process_header_arg(KeyValueArg('header', 'Accept', False)) == 'Accept'
    assert process_header_arg(KeyValueArg('header', 'accept', False)) == 'accept'

    assert process_header_arg(KeyValueArg('header', 'accept', True)) == 'Accept'
    assert process_header_arg(KeyValueArg('header', 'Accept', True)) == 'Accept'
    assert process_header_arg(KeyValueArg('header', 'authorization', True)) == 'Authorization'
    assert process_header_arg(KeyValueArg('header', 'Authorization', True)) == 'Authorization'



# Generated at 2022-06-23 18:54:25.645529
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_item_args = """
        --form '' : '[1,2,3]'
        """
    args = shlex.split(request_item_args)
    args_parser = ArgumentsParser()
    args = args_parser.parse_args(args)
    print(args.items)
    print(args.items.data)
    for i in args.items.data.items():
        print(i)
test_process_data_raw_json_embed_arg()

# Generated at 2022-06-23 18:54:32.271818
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    result = process_empty_header_arg(KeyValueArg("--header", sep=SEPARATOR_HEADER_EMPTY, key="header"))
    assert(result == "")

    try:
        process_empty_header_arg(KeyValueArg("--header", "value", sep=SEPARATOR_HEADER_EMPTY, key="header"))
    except ParseError as e:
        assert(str(e) == "Invalid item \"--header value\" (to specify an empty header use `Header;`)")

# Generated at 2022-06-23 18:54:36.247343
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('data', '{"key": "value"}', '=')  # type: ignore
    value = process_data_raw_json_embed_arg(arg)
    print(type(value))
    print(value)
    assert value == {'key': 'value'}



# Generated at 2022-06-23 18:54:39.008192
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems()

    items = RequestItems.from_args([])



# Generated at 2022-06-23 18:54:41.601616
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    input = 'Accept;'
    expected_output = ''
    actual = process_empty_header_arg(input)
    assert actual == expected_output

# Generated at 2022-06-23 18:54:44.540030
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    test_item = KeyValueArg(
        sep=SEPARATOR_QUERY_PARAM,
        key=None,
        orig=None,
        value="test_value",
    )
    assert process_query_param_arg(test_item) == test_item.value


# Generated at 2022-06-23 18:54:46.275759
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    header = KeyValueArg(':', 'Header', '')
    assert '' == process_empty_header_arg(header)

# Generated at 2022-06-23 18:54:47.928004
# Unit test for constructor of class RequestItems
def test_RequestItems():
  ritems = RequestItems.from_args([])
  assert isinstance(ritems, object)

# Generated at 2022-06-23 18:54:53.130279
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg("Header;")
        raise Exception("Expected ParseError")
    except ParseError as e:
        assert "Invalid item" in e.args[0]

    assert process_empty_header_arg("Header") == ""


# Generated at 2022-06-23 18:54:55.511097
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    result = process_data_item_arg(KeyValueArg("test", "test"))
    assert result == "test"

# Generated at 2022-06-23 18:54:57.971519
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg('a') is True
    assert process_empty_header_arg(';') is False


# Generated at 2022-06-23 18:55:00.700448
# Unit test for function load_text_file
def test_load_text_file():
    # Load regular text file
    path = 'httpie/cli/constants.py'
    with open(os.path.expanduser(path), 'rb') as f:
        result = f.read().decode()

    assert result == load_text_file(arg=None)

# Generated at 2022-06-23 18:55:03.471953
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'data/test.txt'
    mime_type = 'text/plain'
    file_arg = KeyValueArg(None, filename, None, None, None)
    assert process_file_upload_arg(file_arg) == ('test.txt', open(filename), mime_type)

# Generated at 2022-06-23 18:55:15.854046
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_json_data_dict = RequestJSONDataDict()
    assert request_json_data_dict == {}
    assert not request_json_data_dict
    assert request_json_data_dict == []
    assert not request_json_data_dict
    assert request_json_data_dict == ''
    assert not request_json_data_dict
    assert request_json_data_dict == None
    assert not request_json_data_dict

    request_json_data_dict["a"] = "1"
    assert request_json_data_dict != None
    assert not request_json_data_dict == None
    assert request_json_data_dict != []
    assert not request_json_data_dict == []
    assert request_json_data_dict != ''
    assert not request_json_data_dict == ''


# Generated at 2022-06-23 18:55:19.845497
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = process_data_embed_file_contents_arg(KeyValueArg('data-binary=@testData', '@testData', '=', 'testData'))
    assert b'12345\n' == arg.encode('utf-8')



# Generated at 2022-06-23 18:55:29.090268
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data = {'name': 'John', 'age': 30}
    json_str = json.dumps(data)

    pair_key_value = {
        "key": "data",
        "value": json_str,
        "orig": "data=<json_str>",
        "sep": SEPARATOR_DATA_RAW_JSON
    }
    arg = KeyValueArg(**pair_key_value)
    value = process_data_raw_json_embed_arg(arg)
    assert isinstance(value, dict)
    assert data == value, "Value '{}' is not equal to '{}'".format(data, value)

# Generated at 2022-06-23 18:55:31.907469
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg(';Foo')) == ''
    assert process_empty_header_arg(KeyValueArg(';Bar')) == ''

# Generated at 2022-06-23 18:55:35.451848
# Unit test for function process_header_arg
def test_process_header_arg():
    item = KeyValueArg('header', 'num_players', '10')
    assert process_header_arg(item) == '10'


# Generated at 2022-06-23 18:55:43.769015
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    request = RequestItems()
    key_value_arg = KeyValueArg('key', 'value', '=')
    file_upload_arg = KeyValueArg('key', 'value', '@@')
    assert(process_header_arg(key_value_arg) == 'value')
    assert(process_empty_header_arg(key_value_arg) == 'value')
    assert(process_query_param_arg(key_value_arg) == 'value')
    assert(process_file_upload_arg(file_upload_arg) == ('value', file_upload_arg, 'application/octet-stream'))
    assert(process_data_item_arg(key_value_arg) == 'value')

# Generated at 2022-06-23 18:55:46.039411
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    actual = process_data_item_arg(KeyValueArg(None, "key", "value"))
    expected = "value"
    assert actual == expected


# Generated at 2022-06-23 18:55:49.079536
# Unit test for function process_header_arg
def test_process_header_arg():
    args = KeyValueArg('Content-Type', 'text/html')
    assert process_header_arg(args) == 'text/html'

    args = KeyValueArg('Content-Type', 'text/html', ':')
    assert process_header_arg(args) == 'text/html'

# Generated at 2022-06-23 18:55:57.484059
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_case_1 = KeyValueArg('@test.txt', '{"key": "value"}')
    assert process_data_embed_raw_json_file_arg(test_case_1) == {'key': 'value'}
    test_case_2 = KeyValueArg('@test.txt', '[{"key": "value"}]')
    assert process_data_embed_raw_json_file_arg(test_case_2) == [{'key': 'value'}]
    test_case_3 = KeyValueArg('@test.txt', 'wrong_json')
    try:
        process_data_embed_raw_json_file_arg(test_case_3)
    except ParseError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 18:55:59.247541
# Unit test for function load_json
def test_load_json():
    a = load_json("a", "a")
    assert a == "a"

# Generated at 2022-06-23 18:56:04.022373
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.png"

    arg = KeyValueArg(
        "test.png",
        "test",
        "123"
    )

    result = process_file_upload_arg(arg)
    assert result[2] == get_content_type(filename), "Incorect MIME type"

# Generated at 2022-06-23 18:56:07.745787
# Unit test for function load_text_file
def test_load_text_file():
    file_path = "demo.txt"
    arg = KeyValueArg(file_path)
    assert (load_text_file(arg) == "I am a demo file\n")


# Generated at 2022-06-23 18:56:10.337616
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(b'a=b')
    assert process_data_item_arg(arg) == 'b'


# Generated at 2022-06-23 18:56:13.384424
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    path = "file.json"
    arg = KeyValueArg(path, SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    process_data_embed_file_contents_arg(arg)

# Generated at 2022-06-23 18:56:15.005930
# Unit test for function load_json
def test_load_json():
    value = load_json({"key": "value"})
    value == {"key": "value"}




# Generated at 2022-06-23 18:56:17.424283
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('data', 'this is data', SEPARATOR_DATA_STRING)
    assert 'this is data' == process_data_item_arg(arg)

# Generated at 2022-06-23 18:56:23.676855
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    input_data = [
        {
            "arg": KeyValueArg(
                key='employee',
                value='john',
                sep=SEPARATOR_QUERY_PARAM,
                orig='employee=john',
            ),
            "expected": 'john'
        },
        {
            "arg": KeyValueArg(
                key='employee',
                value=None,
                sep=SEPARATOR_QUERY_PARAM,
                orig='employee',
            ),
            "expected": ''
        },
    ]

    for item in input_data:
        actual = process_query_param_arg(item["arg"])
        assert item["expected"] == actual


# Generated at 2022-06-23 18:56:30.963829
# Unit test for function process_header_arg
def test_process_header_arg():
    r1 = process_header_arg(KeyValueArg('-H', 'Content-Type:text/html'))
    r2 = process_header_arg(KeyValueArg('-H', 'Content-Type'))
    assert(r1 == r2)

    try:
        r3 = process_header_arg(KeyValueArg('-H', 'Content-Type:text:html'))
        assert(r3 == False)
    except ParseError:
        assert(True)
    else:
        assert(False)



# Generated at 2022-06-23 18:56:38.419151
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        key='test_name',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='Test_key:@test_value.txt',
        value='test_value.txt'
    )
    result = process_data_embed_file_contents_arg(arg)

    assert(result == 'Hello World!\n')


# Generated at 2022-06-23 18:56:46.995376
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    path = os.path.expanduser("~/tmp/test.txt")
    f = open(path, 'w')
    f.write("Hello")
    f.close()
    value = process_data_embed_file_contents_arg(KeyValueArg(key="",value=path,sep="="))
    assert "Hello"==value, "File not loaded"
    os.remove(path)


# Generated at 2022-06-23 18:56:49.252174
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file("test.txt")
    except Exception as e:
        print("Test load text file failed:")
        print(e)
        assert False
    print("Test load text file success")


# Generated at 2022-06-23 18:56:51.963058
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    h = process_empty_header_arg(KeyValueArg("", SEPARATOR_HEADER_EMPTY, "", ""))

# Generated at 2022-06-23 18:57:00.836878
# Unit test for function load_json
def test_load_json():
    from httpie.cli.argtypes import KeyValueArg
    arg = KeyValueArg(key=None, sep=None, orig='"test"', value='"test"')
    content = '{"a":"b"}'
    assert load_json(arg,content) == {"a":"b"}
    content = '{"a":"b", "c":"d"}'
    assert load_json(arg,content) == {"a":"b", "c":"d"}
    content = '["a","b", "b"]'
    assert load_json(arg,content) == ['a','b', 'b']

# Generated at 2022-06-23 18:57:03.026804
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("--data", "embed_file_contents", "Hello world", "-")) == "Hello world"

# Generated at 2022-06-23 18:57:07.428229
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(['--', '-b', 'foo=bar'])
    assert process_query_param_arg(arg) == 'foo=bar'

# Generated at 2022-06-23 18:57:17.589513
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert isinstance(RequestItems.from_args([]), RequestItems)
    assert isinstance(RequestItems.from_args([], as_form=True).data, RequestDataDict)
    assert isinstance(RequestItems.from_args([]).data, RequestJSONDataDict)
    assert isinstance(RequestItems.from_args([]).headers, RequestHeadersDict)
    assert isinstance(RequestItems.from_args([]).files, RequestFilesDict)
    assert isinstance(RequestItems.from_args([]).params, RequestQueryParamsDict)
    assert isinstance(RequestItems.from_args([]).multipart_data, MultipartRequestDataDict)

# Generated at 2022-06-23 18:57:28.684850
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_values = [
        (
            'file.ext',
            'file.ext',
            None,
        ),
        (
            'file.ext;',
            'file.ext',
            '',
        ),
        (
            'file.ext;image/png',
            'file.ext',
            'image/png',
        ),
        (
            'file.ext;;image/png',
            'file.ext',
            'image/png',
        ),
    ]
    for arg, expected_filename, expected_media_type in test_values:
        kva = KeyValueArg('file@', arg, '')
        filename, f, media_type = process_file_upload_arg(kva)
        assert filename == expected_filename
        assert f != None
        assert media_type == expected_

# Generated at 2022-06-23 18:57:38.665796
# Unit test for function load_text_file
def test_load_text_file():
    # If a text file is not UTF-8 or ASCII-encoded, it should raise an error
    with pytest.raises(ParseError):
        load_text_file(KeyValueArg('file', 'some_file.txt'))

    # If a text file is UTF-8, it should return its contents
    file = io.TextIOWrapper(io.BytesIO(b'1'), encoding='utf-8')
    assert load_text_file(KeyValueArg('file', 'some_file.txt')) == file.read()

    with pytest.raises(ParseError):
        load_text_file(KeyValueArg('file', 'some_file.txt'))

# Generated at 2022-06-23 18:57:41.306258
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    func = process_empty_header_arg
    assert func('key:') == ''
    with pytest.raises(ParseError):
        func('key:val')

# Generated at 2022-06-23 18:57:45.565899
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg("aaa","\"str\"")
    assert process_data_raw_json_embed_arg(arg) == "str"

    arg = KeyValueArg("aaa","{\"key\":\"value\"}")
    assert process_data_raw_json_embed_arg(arg) == {"key":"value"}

# Generated at 2022-06-23 18:57:47.513691
# Unit test for function load_json
def test_load_json():
    test = load_json(arg = '', contents = '{"a":1, "b":2}')
    assert test == {"a":1, "b":2}