

# Generated at 2022-06-23 18:47:53.773186
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(None, SEPARATOR_QUERY_PARAM, 'a', 'c')
    assert process_query_param_arg(arg) == 'c'


# Generated at 2022-06-23 18:47:58.941799
# Unit test for function process_header_arg
def test_process_header_arg():
    import httpie.cli
    header_arg = httpie.cli.KeyValueArg("Accept-Encoding", "gzip", ";")
    assert process_header_arg(header_arg) == "gzip"
    header_arg = httpie.cli.KeyValueArg("Accept-Encoding", None, ";")
    assert process_header_arg(header_arg) is None


# Generated at 2022-06-23 18:48:01.855800
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("embed","C:\\Users\\david\\Desktop\\valid.json")
    assert("{\r\n \"name\": \"David\",\r\n \"age\": 20\r\n}" == load_text_file(item))


# Generated at 2022-06-23 18:48:05.501558
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('Header', ';', '', 'Header')
    result = process_data_embed_raw_json_file_arg(arg)
    print(result)

# Generated at 2022-06-23 18:48:13.306285
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    args = {"sep":"=","key":"","value":"F:/workspace/httpie/httpie/test/test_data/test.txt","orig":"F:/workspace/httpie/httpie/test/test_data/test.txt","orig_key":"","orig_value":"F:/workspace/httpie/httpie/test/test_data/test.txt"}
    arg = KeyValueArg(**args)
    content =  process_data_embed_file_contents_arg(arg)
    print(content)


# Generated at 2022-06-23 18:48:19.752888
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_item_args = []
    request_item_args.append(KeyValueArg('ProgrammingLanguage;filename=programming_language.json', ';'))
    req_items = RequestItems.from_args(request_item_args)
    assert req_items.multipart_data['ProgrammingLanguage'] == {
                                                              "languages": [
                                                                {
                                                                  "name": "C",
                                                                  "type-safe": "false"
                                                                },
                                                                {
                                                                  "name": "Haskell",
                                                                  "type-safe": "true"
                                                                }
                                                              ]
                                                            }

# Generated at 2022-06-23 18:48:25.871035
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file("/opt/data.txt")
    assert load_text_file("/opt/data.json")
    assert load_text_file("C:\\data_file.txt")
    assert load_text_file("C:\\data_file.json")
    assert load_text_file("data.txt")
    assert load_text_file("data.json")


# Generated at 2022-06-23 18:48:32.537618
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('filename', 'SEPARATOR_FILE_UPLOAD')
    assert process_file_upload_arg(arg) == ('filename', open('filename', 'rb'), None)
    arg = KeyValueArg('filename', 'SEPARATOR_FILE_UPLOAD_TYPE')
    assert process_file_upload_arg(arg) == ('filename', open('filename', 'rb'), 'SEPARATOR_FILE_UPLOAD_TYPE')
    arg = KeyValueArg('filename', 'SEPARATOR_FILE_UPLOAD_TYPE;SEPARATOR_FILE_UPLOAD_TYPE')
    assert process_file_upload_arg(arg) == ('filename', open('filename', 'rb'), 'SEPARATOR_FILE_UPLOAD_TYPE')


# Generated at 2022-06-23 18:48:37.054036
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('name', 'value', ':')
    arg1 = KeyValueArg('name', 'value', '--')
    assert process_data_item_arg(arg) == 'value'
    assert process_data_item_arg(arg1) == 'value'



# Generated at 2022-06-23 18:48:46.758392
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg(
        sep = SEPARATOR_HEADER_EMPTY,
        key = 'Foo',
        value = '',
        orig = 'Foo;'
        )) == ''
    try:
        process_empty_header_arg(KeyValueArg(
            sep = SEPARATOR_HEADER_EMPTY,
            key = 'Foo',
            value = 'Bar',
            orig = 'Foo;Bar'
        ))
    except ParseError:
        return
    raise AssertionError('test_process_empty_header_arg failed')

assert test_process_empty_header_arg()

# Generated at 2022-06-23 18:48:48.907397
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(key='key', value='value', orig='key=value')
    assert process_query_param_arg(arg) == 'value'

# Generated at 2022-06-23 18:48:52.973404
# Unit test for function process_header_arg
def test_process_header_arg():
    try:
        key = 'Content-Type'
        value = 'application/json'
        arg = KeyValueArg(key,value)
        assert process_header_arg(arg) == value
    except ParseError:
        assert 1 == 2



# Generated at 2022-06-23 18:48:57.307342
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    try:
        process_data_embed_raw_json_file_arg(arg=KeyValueArg(
          key='a', sep=':', orig=':', value='a.json'))
    except Exception as e:
        print(e)

# Generated at 2022-06-23 18:48:59.028523
# Unit test for function process_header_arg
def test_process_header_arg():
    arg=KeyValueArg('Header', 'value')
    value=process_header_arg(arg)
    assert 'value'== value


# Generated at 2022-06-23 18:49:09.388980
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key=None, sep=' : ', orig=' : a', value='a')
    assert process_data_raw_json_embed_arg(arg) == "a"
    arg = KeyValueArg(key=None, sep=' : ', orig=' : a', value='{"a": "b"}')
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}
    arg = KeyValueArg(key=None, sep=' : ', orig=' : a', value='{"a": "b", "c": "d"}')
    assert process_data_raw_json_embed_arg(arg) == {"a": "b", "c": "d"}
    arg = KeyValueArg(key=None, sep=' : ', orig=' : a', value='[1]')
    assert process_data_

# Generated at 2022-06-23 18:49:12.938994
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.argtypes import KeyValueArg
    item = KeyValueArg('data', '{"foo": "bar"}', 'data', '=')
    v = process_data_raw_json_embed_arg(item)
    assert v == {'foo': 'bar'}

# Generated at 2022-06-23 18:49:19.307439
# Unit test for function process_header_arg
def test_process_header_arg():
    keyValueArg = KeyValueArg()
    keyValueArg.key = 'testcase'
    keyValueArg.sep = SEPARATOR_HEADER
    keyValueArg.value = 'case'
    # call function
    value = process_header_arg(keyValueArg)
    # assert result
    assert value == 'case'

# Generated at 2022-06-23 18:49:30.243167
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg(
        key='',
        value='{"test_key_1":"test_value_1"}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test_file.json'
    )
    # Test the case where the JSON file is not existent
    try:
        process_data_embed_raw_json_file_arg(test_arg)
    except ParseError as e:
        assert e.args[0] == '"@test_file.json": No such file or directory'
    # Test the case where the JSON file is not valid json
    test_arg.value = "Invalid JSON"

# Generated at 2022-06-23 18:49:36.078471
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    file_path = 'test_process_data_embed_file_contents_arg.txt'
    file = open(file_path, 'w')
    file.write('test_process_data_embed_file_contents_arg')
    file.close()
    arg = KeyValueArg(None, None, None, file_path, None)
    assert process_data_embed_file_contents_arg(arg) == 'test_process_data_embed_file_contents_arg'


# Generated at 2022-06-23 18:49:44.236250
# Unit test for function process_header_arg
def test_process_header_arg():
    header = process_header_arg(KeyValueArg(SEPARATOR_HEADER, 'test', 'value'))
    assert header == 'test:value\n'
    header = process_header_arg(KeyValueArg(SEPARATOR_FILE_UPLOAD, 'test', 'value'))
    assert header == 'test:value\n'
    header = process_header_arg(KeyValueArg(SEPARATOR_HEADER_EMPTY, 'test', 'value'))
    assert header == 'test:value\n'


# Generated at 2022-06-23 18:49:50.228940
# Unit test for function load_text_file
def test_load_text_file():
    args = [KeyValueArg('', '', '', 'file', "test.txt")]
    result = process_data_embed_file_contents_arg(args[0])
    with open("test.txt", "r") as myfile:
        data = myfile.read()
    assert result == data


# Generated at 2022-06-23 18:49:53.147666
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('SomeKey', 'SomeValue', '=')
    assert process_data_embed_file_contents_arg(arg) == 'SomeValue'


# Generated at 2022-06-23 18:50:03.869413
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    jsonfile = open('/home/wangchao/pycharm_project/httpie/httpie/tests/data/battery.json', 'rb')
    json_str = jsonfile.read()
    json_str = json_str.decode()
    json_dict = {}
    data = []
    json_dict['data'] = data
    json_dict['data'].append(json_str)
    json_dict['data'].append(json_str)
    print(type(json_dict))
    print(json.dumps(json_dict, indent=4))

    jsonfile1 = open('/home/wangchao/pycharm_project/httpie/httpie/tests/data/cache.json', 'rb')
    json_str1 = jsonfile1.read()
    json_str1 = json

# Generated at 2022-06-23 18:50:09.319276
# Unit test for function load_json
def test_load_json():
    json_content1 = '{"a":"b", "c":true, "d":1}'
    json_content2 = '{"a":123, "b":456, "c":789}'
    assert load_json("", json_content1) == {"a":"b", "c":True, "d":1}
    assert load_json("", json_content2) == {"a":123, "b":456, "c":789}

# Generated at 2022-06-23 18:50:21.121161
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg_0 = KeyValueArg('-X', 'POST', '-d', '@pytest.json', None, 'POST', '@pytest.json')
    arg_1 = KeyValueArg('-X', 'PUT', '-d', '@pytest.json', None, 'PUT', '@pytest.json')
    arg_2 = KeyValueArg('-X', 'PATCH', '-d', '@pytest.json', None, 'PATCH', '@pytest.json')
    arg_3 = KeyValueArg('-X', 'GET', '-d', '@pytest.json', None, 'GET', '@pytest.json')

# Generated at 2022-06-23 18:50:26.308400
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems()
    assert items.headers == RequestHeadersDict()
    assert items.data == RequestDataDict()
    assert items.files == RequestFilesDict()
    assert items.params == RequestQueryParamsDict()
    assert items.multipart_data == MultipartRequestDataDict()


# Generated at 2022-06-23 18:50:32.084506
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    test_arg = KeyValueArg(key='', value='', sep=SEPARATOR_HEADER_EMPTY)
    assert process_empty_header_arg(test_arg) == ''
    test_arg = KeyValueArg(key='', value='NonEmpty', sep=SEPARATOR_HEADER_EMPTY)
    with pytest.raises(ParseError):
        assert process_empty_header_arg(test_arg)

# Generated at 2022-06-23 18:50:42.912926
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    local_path = os.path.abspath('.')
    filename = os.path.join(local_path, 'requests.py')
    upload_arg = '@' + filename
    arg = KeyValueArg(upload_arg)
    file_tuple = process_file_upload_arg(arg)
    assert file_tuple[0] == ('requests.py')
    assert os.path.isfile(file_tuple[1].name)

    upload_arg = '/tmp/test_file.txt@'
    upload_arg = upload_arg + filename + ';text/plain'
    arg = KeyValueArg(upload_arg)
    file_tuple = process_file_upload_arg(arg)
    assert file_tuple[0] == 'test_file.txt'

# Generated at 2022-06-23 18:50:47.233873
# Unit test for function load_text_file
def test_load_text_file():
    from httpie.cli.argtypes import KeyValueArg
    arg = KeyValueArg()
    arg.value = 'data.txt'
    s = load_text_file(arg)
    s == "hello"


# Generated at 2022-06-23 18:50:51.168209
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(None, None, None)
    contents = '{"a": "b", "c": {"d": 2}}'
    assert load_json(arg, contents) == {"a": "b", "c": {"d": 2}}



# Generated at 2022-06-23 18:50:51.788043
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    pass

# Generated at 2022-06-23 18:50:55.847503
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    def test_equal(full_arg, expect_value):
        actual_value = process_data_item_arg(KeyValueArg(full_arg))
        assert actual_value == expect_value, "for arg: " + full_arg

    test_equal('foo=bar', 'bar')

# Generated at 2022-06-23 18:51:01.051930
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    try:
        process_empty_header_arg("Accept;")
    except ParseError:
        assert False
    try:
        process_empty_header_arg("Accept;Application/json")
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-23 18:51:08.342258
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    request_item_args = [
        KeyValueArg(
            key='key1',
            value='~/Desktop/HTTP-API-Testing-with-HTTPie/httpie/tests/data/json_order.json',
            sep='=',
            orig='key1=~/Desktop/HTTP-API-Testing-with-HTTPie/httpie/tests/data/json_order.json',
        )
    ]
    as_form = False
    request_items = RequestItems.from_args(request_item_args, as_form=as_form)
    assert request_items.data.get('key1') == {
        'a': 1,
        'b': 2,
        'c': 3
    }

# Generated at 2022-06-23 18:51:10.042822
# Unit test for function load_json
def test_load_json():
    string = '{"key":"value"}'
    assert load_json(KeyValueArg('key', SEPARATOR_QUERY_PARAM, string), string) == {'key': 'value'}


# Generated at 2022-06-23 18:51:12.004219
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(orig = 'key:value', key='key', value='value', sep=':')
    assert process_header_arg(arg) == 'value'


# Generated at 2022-06-23 18:51:14.016577
# Unit test for constructor of class RequestItems
def test_RequestItems():
    cls = RequestItems
    instance = cls(as_form=False)

# Generated at 2022-06-23 18:51:18.990648
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    #test file name only
    process_file_upload_arg(KeyValueArg('file_name_only',';','test.txt'))
    #test file name with subtype
    process_file_upload_arg(KeyValueArg('file_name_subtype','[','test.txt[subtype]'))

# Generated at 2022-06-23 18:51:24.085060
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg =  KeyValueArg()
    arg.key = "username"
    arg.value = "/Users/zhiyzhang/Documents/zhiyzhang.txt"
    arg.sep = "=="
    print(process_data_embed_file_contents_arg(arg))


# Generated at 2022-06-23 18:51:26.183871
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("-d", "./httpie/tests/file1.txt", None)) == "file1\n"

# Generated at 2022-06-23 18:51:31.345811
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg=KeyValueArg('-k','--json;hello.json', '--json', 'sep', 'value')
    res=process_file_upload_arg(arg)
    assert res==('hello.json', open(os.path.expanduser('hello.json'), 'rb') ,"application/octet-stream")

# Generated at 2022-06-23 18:51:36.323750
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    path = "tmp/foo.txt"
    with open(path, 'wb') as f:
        f.write("File content")
    output = process_data_embed_file_contents_arg(KeyValueArg(
        "Data@",
        path,
        "Data@" + path,
        "Data@"
    ))
    assert output == "File content"

# Generated at 2022-06-23 18:51:39.969485
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='test.json', sep='<@', key='json', value='test.json')
    data = process_data_embed_raw_json_file_arg(arg)
    print(data)


if __name__ == "__main__":
    test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-23 18:51:42.749713
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="file", sep=SEPARATOR_FILE_UPLOAD, value="~/text.txt")
    print(process_file_upload_arg(arg))


# Generated at 2022-06-23 18:51:53.680315
# Unit test for constructor of class RequestItems
def test_RequestItems():
    s = '{"a":1}'

# Generated at 2022-06-23 18:51:56.368267
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg(key=None, sep=None, value='value')) == 'value'


# Generated at 2022-06-23 18:51:59.222960
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    key = 'key'
    value = 'value'
    args = [KeyValueArg(key, value, ':'),]
    assert process_data_item_arg(args[0]) == value


# Generated at 2022-06-23 18:52:08.813924
# Unit test for function load_text_file
def test_load_text_file():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='r+') as f:
        f.write("hello world")
        f.flush()
        content = load_text_file(KeyValueArg("test_file", "test_file", f.name, ""))
        assert content == "hello world"
        f.seek(0)
        f.truncate()
        f.write("hello world, from a text file")
        f.flush()
        content = load_text_file(KeyValueArg("test_file2", "test_file2", f.name, ""))
        assert content == "hello world, from a text file"
        f.close()



# Generated at 2022-06-23 18:52:11.382056
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg('', 'abc.txt', 'abc.txt')) == ('abc.txt', open('abc.txt', 'rb'), 'text/plain')

# Generated at 2022-06-23 18:52:14.079541
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg
    # key is hello, value is world
    assert("world" == process_query_param_arg(KeyValueArg("hello=world")))


# Generated at 2022-06-23 18:52:17.390854
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems.from_args([KeyValueArg('header', 'key', 'value'), KeyValueArg('query', 'key2', 'value2')])
    assert items.headers['key'] == 'value'
    assert items.params['key2'] == 'value2'

# Generated at 2022-06-23 18:52:21.208834
# Unit test for function process_header_arg
def test_process_header_arg():
    """Test for function process_header_arg."""
    assert 'abc' == process_header_arg(KeyValueArg(sep=':', key='a', value='abc'))
    assert None == process_header_arg(KeyValueArg(sep=':', key='a', value=None))

# Generated at 2022-06-23 18:52:27.084112
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    result = process_data_embed_raw_json_file_arg(KeyValueArg("-d=@data_embed.json"))
    assert result["foo"] == "bar"
    assert result["baz"] == "qux"
    assert result["nested"] == {"hello": "world"}
    assert result["arr"] == [1, 2, 3]


# Generated at 2022-06-23 18:52:33.222993
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(None,None, None, None, None)
    arg.orig = 'test.json'
    arg.value = '{"a":"1", "b":"2"}'
    test_dict = process_data_embed_raw_json_file_arg(arg)
    assert test_dict['a'] == "1"
    assert test_dict['b'] == "2"


# Generated at 2022-06-23 18:52:37.827946
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    """
    Tests the process_data_embed_file_contents_arg
    """

    actual = process_data_embed_file_contents_arg()
    expected = ""
    try:
        assert actual == expected
    except AssertionError:
        print("\nExpected: ", expected, "\nResult: ", actual)


# Generated at 2022-06-23 18:52:43.214964
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    import os
    print(os.path.abspath('.'))
    data = KeyValueArg(key='data_key', value='~/PycharmProjects/httpie-plugin-alibabaCloud/httpie-plugin-alibabaCloud/data00.json', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    data_value = process_data_embed_file_contents_arg(data)
    # check whether it is a dict.
    assert isinstance(data_value, dict)
    # check the value of key: "intvalue"
    assert data_value["intvalue"] == 123344444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444

# Generated at 2022-06-23 18:52:50.709316
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    class KeyValueArg:
        def __init__(self, sep, value, key, orig):
            self.sep = sep
            self.value = value
            self.key = key
            self.orig = orig

    a = KeyValueArg(
        SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        '{ "a": "1", "b": "2" }',
        'key',
        'key:"{ "a": "1", "b": "2" }"'
    )
    print(process_data_embed_raw_json_file_arg(a))


# Generated at 2022-06-23 18:52:54.950393
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('--data', '@./tests/data/file-upload-test#1.txt', ':')
    value = process_data_embed_file_contents_arg(arg)
    assert value == 'http://localhost:5000/'


# Generated at 2022-06-23 18:53:05.667369
# Unit test for function process_header_arg
def test_process_header_arg():
    args = ["-H", "name:value"]
    kargs = KeyValueArg.parse(args[1:])
    assert process_header_arg(kargs[0]) == kargs[0].value
    args = ["-H", "name:"]
    kargs = KeyValueArg.parse(args[1:])
    assert process_header_arg(kargs[0]) == kargs[0].value
    args = ["-H", "name"]
    kargs = KeyValueArg.parse(args[1:])
    assert process_header_arg(kargs[0]) == None
    args = ["-H", "name:"]
    kargs = KeyValueArg.parse(args[1:])
    assert process_header_arg(kargs[0]) == kargs[0].value

# Generated at 2022-06-23 18:53:09.160351
# Unit test for function process_header_arg
def test_process_header_arg():
    # Create a key-value pair:
    header_arg = KeyValueArg(":", "Authorization")
    # Match the output of process_header_arg to the expected value:
    return process_header_arg(header_arg) == "Authorization"


# Generated at 2022-06-23 18:53:18.048679
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item1 = KeyValueArg(key=None, value="{}", sep=SEPARATOR_DATA_RAW_JSON, orig="SEPARATOR_DATA_RAW_JSON: {}")
    item2 = KeyValueArg(key=None, value="abc", sep=SEPARATOR_DATA_RAW_JSON, orig="SEPARATOR_DATA_RAW_JSON: abc")
    item3 = KeyValueArg(key=None, value="[1,2,3]", sep=SEPARATOR_DATA_RAW_JSON, orig="SEPARATOR_DATA_RAW_JSON: [1,2,3]")

# Generated at 2022-06-23 18:53:20.878030
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg1 = KeyValueArg('x', 'y', SEPARATOR_DATA_STRING)
    assert process_data_item_arg(arg1) == 'y'

# Generated at 2022-06-23 18:53:26.022496
# Unit test for function load_json
def test_load_json():
    # from pudb import set_trace; set_trace()
    arg = KeyValueArg('', '', '', SEPARATOR_DATA_EMBED_RAW_JSON_FILE, '{}')
    try:
        json_data = load_json(arg, arg.value)
        print("Passed")
    except ParseError as e:
        print("Failed")

# Generated at 2022-06-23 18:53:29.691063
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(key='header_name', sep=SEPARATOR_HEADER_EMPTY)
    arg.value = ''
    assert process_empty_header_arg(arg) == ''

    arg.value = 'value'
    assert process_empty_header_arg(arg) is None


# Generated at 2022-06-23 18:53:34.563461
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems(as_form=True)
    assert type(instance.headers) is RequestHeadersDict
    assert type(instance.data) is RequestDataDict
    assert type(instance.files) is RequestFilesDict
    assert type(instance.params) is RequestQueryParamsDict

# Generated at 2022-06-23 18:53:37.225640
# Unit test for function load_text_file
def test_load_text_file():
    print("test_load_text_file")
    assert type(load_text_file(object)) == str
    print("Done test_load_text_file\n")


# Generated at 2022-06-23 18:53:39.775155
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="test", key="key", sep="sep", value="value")
    expected = "test"
    assert load_text_file(item) == expected

# Generated at 2022-06-23 18:53:42.386595
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg('json-file', '{ "key": "value" }', 'json-file')
    test_result = process_data_embed_raw_json_file_arg(test_arg)
    test_expected_result = { 'key': 'value' }

    assert test_result == test_expected_result

# Generated at 2022-06-23 18:53:52.361332
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    test_args = [
        "test:test"
        "test:",
        ":test"
    ]
    pass

    # This test is surprisingly not working
    # Need to investigate further
    #
    # for arg in test_args:
    #     try:
    #         process_empty_header_arg(arg)
    #     except ParseError:
    #         pass
    #     else:
    #         raise ParseError("Parse Error should've been thrown \
    #                          for inputs {}".format(test_args))


# Unit Test for function process_header_arg

# Generated at 2022-06-23 18:54:02.167793
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_file_suffix_sep = ': '
    test_file_suffix = 'test_suffix'
    test_file_name = 'test_file_name'
    test_file_name_with_suffix = test_file_name + test_file_suffix_sep + test_file_suffix
    res_filename, res_file, res_type = process_file_upload_arg(KeyValueArg('header','@'+test_file_name_with_suffix))
    assert res_filename == test_file_name
    assert res_file.name.endswith(test_file_name)
    assert res_type is None

    test_file_name = 'test_file_name'
    test_file_name_with_suffix = test_file_name + test_file_suff

# Generated at 2022-06-23 18:54:15.052118
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert len(RequestItems.from_args([KeyValueArg(SEPARATOR_QUERY_PARAM, 'k1', 'v1')]).params) == 1
    assert len(RequestItems.from_args([KeyValueArg(SEPARATOR_QUERY_PARAM, 'k1', 'v1')]).headers) == 0
    assert len(RequestItems.from_args([KeyValueArg(SEPARATOR_QUERY_PARAM, 'k1', 'v1')]).data) == 0
    assert len(RequestItems.from_args([KeyValueArg(SEPARATOR_HEADER, 'k1', 'v1')]).params) == 0
    assert len(RequestItems.from_args([KeyValueArg(SEPARATOR_HEADER, 'k1', 'v1')]).headers) == 1

# Generated at 2022-06-23 18:54:17.155391
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(
        KeyValueArg(orig='name', key='name', sep=':', value='david')) == 'david'



# Generated at 2022-06-23 18:54:23.576387
# Unit test for constructor of class RequestItems
def test_RequestItems():
    as_form = True
    request_item_args: List[KeyValueArg] = []
    query_string = "a=1&b=2"
    for i in query_string.split("&"):
        request_item_args.append(KeyValueArg(
            key=i.split("=")[0], value=i.split("=")[1], sep="&"))

    request_items = RequestItems.from_args(request_item_args)
    print(request_items.data)
    print(request_items.multipart_data)

# Generated at 2022-06-23 18:54:31.995923
# Unit test for constructor of class RequestItems
def test_RequestItems():
    hi = RequestItems()
    hi.headers['header1'] = 'header1'
    assert hi.headers['header1'] == 'header1'
    hi.params['param1'] = 'param1'
    assert hi.params['param1'] == 'param1'
    hi.multipart_data['md1'] = 'md1'
    assert hi.multipart_data['md1'] == 'md1'
    hi.data['data1'] = 'data1'
    assert hi.data['data1'] == 'data1'
    hi.files['file1'] = 'file1'
    assert hi.files['file1'] == 'file1'


# Generated at 2022-06-23 18:54:34.505228
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('key', 'value', '=')) == 'value'



# Generated at 2022-06-23 18:54:46.786766
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_item_args = []
    request_item_args.append(KeyValueArg(
        'foo', 'bar', SEPARATOR_DATA_RAW_JSON))
    request_item_args.append(KeyValueArg(
        'foo', '42', SEPARATOR_DATA_RAW_JSON))
    request_item_args.append(KeyValueArg(
        'foo', '{"quux": "quux_value"}', SEPARATOR_DATA_RAW_JSON))
    request_items = RequestItems.from_args(request_item_args, as_form=False)
    assert {'foo': 'bar'} == request_items.data
    assert {'foo': 42} == request_items.data
    assert {'foo': {'quux': 'quux_value'}} == request_items.data

# Generated at 2022-06-23 18:54:59.931935
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:55:08.729269
# Unit test for function load_text_file
def test_load_text_file():
    filepath = '~/Documents'
    try:
        with open(os.path.expanduser(filepath), 'rb') as f:
            return f.read().decode()
    except IOError as e:
        raise ParseError('"%s": %s' % (filepath, e))
    except UnicodeDecodeError:
        raise ParseError(
            '"%s": cannot embed the content of "%s",'
            ' not a UTF8 or ASCII-encoded text file'
            % (filepath, filepath)
        )


# Generated at 2022-06-23 18:55:18.767482
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items1 = RequestItems.from_args([KeyValueArg("Header-1","value-1")])
    items2 = RequestItems.from_args([KeyValueArg("Header-2","value-2")])
    items3 = RequestItems.from_args([KeyValueArg("query-param-1","value-1")])
    items4 = RequestItems.from_args([KeyValueArg("data","value-1")])
    items5 = RequestItems.from_args([KeyValueArg("file","value-1")])
    print(items1)
    print(items2)
    print(items3)
    print(items4)
    print(items5)


# Generated at 2022-06-23 18:55:29.719814
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # list
    a = process_data_raw_json_embed_arg(KeyValueArg('data', '["a", "b", "c"]'))
    assert type(a) == list
    assert a[0] == 'a'
    assert a[1] == 'b'
    assert a[2] == 'c'
    # dict
    b = process_data_raw_json_embed_arg(KeyValueArg('data', '{"a":"aa", "b":"bb", "c":"cc"}'))
    assert type(b) == dict
    assert b['a'] == 'aa'
    assert b['b'] == 'bb'
    assert b['c'] == 'cc'
    # int
    c = process_data_raw_json_embed_arg(KeyValueArg('data', '100'))
    assert type

# Generated at 2022-06-23 18:55:40.403855
# Unit test for function load_text_file
def test_load_text_file():
    from os.path import expanduser, dirname
    from inspect import getsourcefile
    file_path = dirname(expanduser(getsourcefile(lambda: 0)))
    try:
        print(load_text_file(KeyValueArg('',"test.txt")))
        assert "\n" == load_text_file(KeyValueArg('',"test.txt"))

    except IOError as e:
        raise ParseError('"%s": %s' % ("test.txt", e))
    except UnicodeDecodeError:
        raise ParseError(
            '"%s": cannot embed the content of "%s",'
            ' not a UTF8 or ASCII-encoded text file'
            % ("test.txt", "test.txt")
        )

# Generated at 2022-06-23 18:55:43.703262
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(KeyValueArg(b'data@raw.json', b'[{"key": "value"}]')) == [{'key': 'value'}]



# Generated at 2022-06-23 18:55:46.959728
# Unit test for function load_text_file
def test_load_text_file():
    # This test works because the directory "test" is located in the same directory as this script is located.
    print(load_text_file(KeyValueArg('test', 'test/test.txt')))


# Generated at 2022-06-23 18:55:50.383353
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    obj = RequestItems()
    arg = KeyValueArg(key='name', orig='name=foo', sep=SEPARATOR_DATA_RAW_JSON, value='foo')
    assert obj.process_data_raw_json_embed_arg(arg) == 'foo'

# Generated at 2022-06-23 18:56:00.775071
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
        file_upload_arg1 = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/foo.txt')
        file_upload_arg2 = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/bar.txt; text/plain')
        file_upload_arg3 = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/bar.txt; text/plain;')
        file_upload_arg4 = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/bar.txt;')
        process_file_upload_arg(file_upload_arg1)
        process_file_upload_arg(file_upload_arg2)
        process_file_upload_

# Generated at 2022-06-23 18:56:12.430942
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie import http
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import (
        SEPARATOR_HEADER, SEPARATOR_HEADER_EMPTY, SEPARATOR_QUERY_PARAM,
        SEPARATOR_FILE_UPLOAD, SEPARATOR_DATA_STRING,
        SEPARATOR_DATA_EMBED_FILE_CONTENTS, SEPARATOR_DATA_RAW_JSON,
        SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )


# Generated at 2022-06-23 18:56:15.144129
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('foo', 'data@')
    arg.value = "file.txt"
    assert process_data_embed_file_contents_arg(arg) == "abc"


# Generated at 2022-06-23 18:56:16.857446
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    print(process_data_item_arg(KeyValueArg(key="name", value="a")))

# Generated at 2022-06-23 18:56:22.134493
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    class KeyValueArg:
        orig = "test"

    foo = {'a': 1, 'b': 2}

    test_file_name = "test.txt"
    f = open(test_file_name, 'w')
    f.write(json.dumps(foo))
    f.close()

    with open(test_file_name) as f:
        args = process_data_embed_raw_json_file_arg(KeyValueArg)
        print(json.dumps(args))

    os.remove(test_file_name)

# Generated at 2022-06-23 18:56:25.811000
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    class arg:
        sep = '='
        key = 'mykey'
        value = 'myvalue'
        orig = 'mykey=myorig'

    http_arg = process_data_embed_file_contents_arg(arg)
    assert http_arg == 'myvalue'

# Generated at 2022-06-23 18:56:28.205272
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    example = [1,2,3]
    original = example
    result = process_data_item_arg(arg.value)
    assert example == result

# Generated at 2022-06-23 18:56:40.405322
# Unit test for function load_json
def test_load_json():
    from httpie.compat import json
    import io

    test_case = [
        (
            '{ "foo" : "bar" }',
            {"foo" : "bar"}
        ), (
            '[1, 2, 3]',
            [1, 2, 3]
        ), (
            '{}',
            {}
        ), (
            '123',
            123
        ), (
            '[1, 2, [30, 31]]',
            [1, 2, [30, 31]]
        )
    ]

    for (test_input, test_output) in test_case:
        assert load_json(
            KeyValueArg(
                '',
                '',
                '',
                ''
            ),
            test_input
        ) == test_output

    # Test error

# Generated at 2022-06-23 18:56:51.692894
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:56:58.225473
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    print("Test for function process_data_embed_file_contents_arg()")
    args_list = [
        KeyValueArg(orig='@example.json', key='', sep='@', value='example.json')
    ]
    request_items = RequestItems.from_args(args_list)
    print(request_items.multipart_data)


# Generated at 2022-06-23 18:57:01.924482
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    data = load_json(KeyValueArg('haha', '../../test/test_data/test.json'), '../../test/test_data/test.json')
    assert data == {"name": "test", "a": {"b": {"c": [1, 2]}}}


# Generated at 2022-06-23 18:57:06.685326
# Unit test for function process_header_arg
def test_process_header_arg():
    print('\nUnit test for function process_header_arg')
    arg = KeyValueArg('--header', 'key:value')
    print(process_header_arg(arg))



# Generated at 2022-06-23 18:57:13.791764
# Unit test for constructor of class RequestItems
def test_RequestItems():
    r = RequestItems()
    assert isinstance(r.headers, RequestHeadersDict)
    assert isinstance(r.data, RequestJSONDataDict)
    assert isinstance(r.files, RequestFilesDict)
    assert isinstance(r.params, RequestQueryParamsDict)
    assert isinstance(r.multipart_data, MultipartRequestDataDict)
    r.headers['Accept'] = 'application/json'
    assert r.headers['Accept'] == 'application/json'



# Generated at 2022-06-23 18:57:16.702139
# Unit test for constructor of class RequestItems
def test_RequestItems():
    args = [KeyValueArg('Header', 'key', value='value')]
    instance = RequestItems.from_args(args)
    print(instance)



# Generated at 2022-06-23 18:57:22.149693
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('myTestHeader', 'myTestVal', False, ':')
    print(process_header_arg(arg))
    arg = KeyValueArg('myTestHeader', '', False, ':')
    print(process_header_arg(arg))


# Generated at 2022-06-23 18:57:28.517333
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    request_item_args = []
    request_item_args.append(KeyValueArg('file1.txt', 'file1.txt', ':'))
    items = RequestItems.from_args(request_item_args)
    assert items.files['file1.txt'][0] == 'file1.txt'
    assert items.files['file1.txt'][1].read().decode() == 'content of file1.txt'
    assert items.files['file1.txt'][2] == 'application/octet-stream'

# Generated at 2022-06-23 18:57:31.618723
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg((':', 'foo:bar'))
    assert process_header_arg(arg) == 'bar'

# Generated at 2022-06-23 18:57:41.318944
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # no file to open
    arg1 = KeyValueArg(orig='embed@/tmp/test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key='embed', value='/tmp/test.txt')
    # File is not readable
    arg2 = KeyValueArg(orig='embed@test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key='embed', value='test.txt')
    # File is readable
    arg3 = KeyValueArg(orig='embed@__init__.py', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key='embed', value='__init__.py')

# Generated at 2022-06-23 18:57:44.315201
# Unit test for function load_json
def test_load_json():
    import httpie.cli.argtypes as argtypes
    input = argtypes.KeyValueArg(
        'a', 'b', ['a', 'b'],  '--a', 'b', '--a', 'b'
    )
    actual = argtypes.load_json(input, "{'a':'b'}")
    expected = {'a':'b'}
    assert actual == expected


# Generated at 2022-06-23 18:57:48.072451
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    process_query_param_arg(KeyValueArg(key="name", value="bob", sep=SEPARATOR_QUERY_PARAM)) == 'bob'


# Generated at 2022-06-23 18:57:48.950706
# Unit test for function process_header_arg
def test_process_header_arg():
    # TODO
    assert True

# Generated at 2022-06-23 18:57:53.039434
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    query_param_arg = KeyValueArg()
    query_param_arg.set_query_param_arg("query-param", "test_value", None)
    assert(process_query_param_arg(query_param_arg) == "test_value")
