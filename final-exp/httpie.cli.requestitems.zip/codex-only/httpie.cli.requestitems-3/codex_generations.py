

# Generated at 2022-06-23 18:47:56.946072
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Arrange
    arg = KeyValueArg(sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, key="abc", value="abc.json")
    filename = os.path.join(os.path.dirname(__file__), "test_data", "abc.json")
    f = open(filename, 'r')
    data = json.load(f, object_pairs_hook=OrderedDict)
    original_data = {"foo": "bar", "a": data}
    expected_dict = OrderedDict([('foo', 'bar'), ('a', data)])

    # Assert
    assert expected_dict == process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-23 18:48:10.223093
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg(orig='key', sep=':', key='key', value='"test_key": "test_value"')
    assert process_data_raw_json_embed_arg(item) == {"test_key" : "test_value"}
    item = KeyValueArg(orig='key', sep=':', key='key', value='{"test_key": "test_value"}')
    assert process_data_raw_json_embed_arg(item) == {"test_key" : "test_value"}
    item = KeyValueArg(orig='key', sep=':', key='key', value='["test", "value"]')
    assert process_data_raw_json_embed_arg(item) == ["test", "value"]

# Generated at 2022-06-23 18:48:15.990461
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    """Test if the only argument is a separator, return a empty string."""
    arg = KeyValueArg('Header;')
    assert process_empty_header_arg(arg) == ''
    try:
        process_empty_header_arg(KeyValueArg('Header:Value'))
        assert False
    except ParseError as e:
        assert str(e) == 'Invalid item "Header:Value" (to specify an empty header use `Header;`)'

# Generated at 2022-06-23 18:48:21.600882
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    try:
        arg = KeyValueArg.parse('file@~/abc.txt')
        f = process_file_upload_arg(arg)
        file_name = f[0]
        file_type = f[2]
    except ParseError as e:
        print(e)

# Generated at 2022-06-23 18:48:29.683067
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # | GIVEN |
    class Arg(object):
        def __init__(self, key: str, value: str, orig: str, sep: str):
            self.key = key
            self.value = value
            self.orig = orig
            self.sep = sep

    test_values = [
        # Arg(key=, value=, orig=, sep=),
        Arg(key=None, value='/path/to/file', orig=None, sep=None),
    ]

    for arg in test_values:
        # | WHEN |
        process_data_embed_raw_json_file_arg(arg)

        # | THEN |



# Generated at 2022-06-23 18:48:32.896658
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    try:
        process_data_embed_file_contents_arg(KeyValueArg("file", "foo"))
    except ParseError as e:
        print(e)

# Generated at 2022-06-23 18:48:35.985745
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data_ = process_data_raw_json_embed_arg(KeyValueArg(None, None, None, None, None, None, 'foo', 'bar', '{'))
    assert data_ == {"foo" : "bar"}

# Generated at 2022-06-23 18:48:47.734566
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    key_value_arg = KeyValueArg('-d', 'a=1')
    print (process_data_raw_json_embed_arg(key_value_arg))
    key_value_arg = KeyValueArg('-d', '{"a": "1"}')
    print (process_data_raw_json_embed_arg(key_value_arg))
    key_value_arg = KeyValueArg('-d', 'a=1&a=2')
    print (process_data_raw_json_embed_arg(key_value_arg))
    key_value_arg = KeyValueArg('-d', 'ba')
    print (process_data_raw_json_embed_arg(key_value_arg))

if __name__ == '__main__':
    test_process_data_raw_json_embed_arg

# Generated at 2022-06-23 18:48:55.736568
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # for test without file upload, only headers, data and params are used.
    request_item_args = [
        KeyValueArg(sep=SEPARATOR_HEADER, key="content-type", value="application/json"),
        KeyValueArg(sep=SEPARATOR_HEADER, key="Accept", value="application/json"),
        KeyValueArg(sep=SEPARATOR_QUERY_PARAM, key="name", value="yanying"),
        KeyValueArg(sep=SEPARATOR_DATA_STRING, key="age", value="19")
    ]
    ri = RequestItems.from_args(request_item_args)
    print(ri)
    # for test with file upload, all fields are used.

# Generated at 2022-06-23 18:48:58.651489
# Unit test for function load_text_file
def test_load_text_file():
    text_data = ''
    ri = RequestItems('text_data')
    assert ri.data['text_data'] == text_data


# Generated at 2022-06-23 18:49:02.037028
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    name = 'name'
    value = 'value'
    kwargs = {'name': name, 'value': value}
    arg = KeyValueArg(**kwargs)
    assert process_data_item_arg(arg) == arg.value

# Generated at 2022-06-23 18:49:06.914847
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    item = KeyValueArg(SEPARATOR_HEADER_EMPTY, "", "")
    assert process_empty_header_arg(item) is None
    wrong_item = KeyValueArg(SEPARATOR_HEADER_EMPTY, "", "something")
    with pytest.raises(ParseError):
        process_empty_header_arg(wrong_item)

# Generated at 2022-06-23 18:49:09.191504
# Unit test for function load_text_file
def test_load_text_file():
    # assert load_text_file("") == "Hello world"
    assert load_text_file("") == ""


# Generated at 2022-06-23 18:49:11.560045
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('=', 'key', 'value')
    expected = 'value'
    actual = process_data_item_arg(arg)
    assert expected == actual

# Generated at 2022-06-23 18:49:24.022664
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Write a test file
    with open("test.txt", "w") as f:
        f.write("hello world")
    f = open("test.txt", "rb")
    # Test process a correct file, with correct file name, content file and content type
    arg = KeyValueArg("\"test.txt\":@test.txt:text/html")
    assert process_file_upload_arg(arg) == ("test.txt", f, "text/html")
    # Test process a correct file, with correct file name, content file but with empty content type
    arg = KeyValueArg("\"test.txt\":@test.txt")
    assert process_file_upload_arg(arg) == ("test.txt", f, None)
    # Test process a correct file, with correct file name and content file, with empty content type
    arg = KeyValue

# Generated at 2022-06-23 18:49:27.807310
# Unit test for function load_text_file
def test_load_text_file():
    myfile = KeyValueArg("", "", "", "", "", "", "")
    myfile.value = "httpie/cli/exceptions.py"
    output = load_text_file(myfile)
    assert("class ExitStatus" in output)



# Generated at 2022-06-23 18:49:32.264245
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    request_items = RequestItems()
    print(process_query_param_arg(request_items, "key", "value"))
    #assert process_query_param_arg(request_items, "key", "value") == "value"

# Generated at 2022-06-23 18:49:37.021145
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key="-F",
        orig="-F",
        sep="=",
        value="samples/sample_file.json"
    )
    process_file_upload_arg(arg) == (
        'sample_file.json',
        open(os.path.expanduser('samples/sample_file.json')),
        'text/plain'
    )


# Generated at 2022-06-23 18:49:39.987527
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    a = KeyValueArg('--data', '1', '=')
    assert(process_data_item_arg(a) == '1')


# Generated at 2022-06-23 18:49:45.451672
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
  arg = KeyValueArg("Header;", "")
  assert process_empty_header_arg(arg) == ""

  arg2 = KeyValueArg("Header;", "abc")
  try:
    value = process_empty_header_arg(arg2)
    assert False, "Value should have value None. Value currently {}".format(value)
  except ParseError as e:
    pass

# Generated at 2022-06-23 18:49:48.878636
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="", value=r'{"key":"value"}', orig="", sep="")
    result = ("key", "value")
    assert process_data_embed_raw_json_file_arg(arg) == result

# Generated at 2022-06-23 18:49:52.384464
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('key', 'value')
    assert process_data_embed_file_contents_arg(arg) == 'value'


# Generated at 2022-06-23 18:49:54.756718
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert (process_query_param_arg(KeyValueArg(None, 'hello', '', '')) == 'hello')


# Generated at 2022-06-23 18:49:58.636422
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    expected = (
        'mytxtfile',
        open('mytxtfile'),
        'txt'
        )
    actual = process_file_upload_arg(KeyValueArg(None, ';', 'mytxtfile'))
    assert expected == actual

# Generated at 2022-06-23 18:50:00.025241
# Unit test for function load_json
def test_load_json():
    value = load_json()

# Generated at 2022-06-23 18:50:04.611049
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(
        '',
        SEPARATOR_DATA_RAW_JSON,
        '',
        '{"class": "buyer, user", "count": 1, "name": "John Walker"}'
    )
    datadict = process_data_raw_json_embed_arg(arg)
    assert datadict == json.loads(arg.value)



# Generated at 2022-06-23 18:50:07.106943
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(
        KeyValueArg(sep='=', key='', value='value')
    ) == 'value'



# Generated at 2022-06-23 18:50:16.094817
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:50:18.217569
# Unit test for function process_header_arg
def test_process_header_arg():
    a = KeyValueArg('--header', 'Content-Type', 'application/json')
    assert process_header_arg(a) == 'application/json'

# Generated at 2022-06-23 18:50:20.337037
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg("key=value")
    assert process_query_param_arg(arg) == "value"



# Generated at 2022-06-23 18:50:30.940908
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_items_1 = RequestItems.from_args([KeyValueArg(orig="key=value", sep=":", key="key", value="value")])
    request_items_2 = RequestItems.from_args(
        [KeyValueArg(orig="key=value", sep=":", key="key", value="value")],
        as_form=True
    )
    assert request_items_1.data["key"] == "value" and request_items_2.data["key"] == '"value"'
    request_items_3 = RequestItems.from_args([KeyValueArg(orig="key=value", sep=";", key="key", value="value")])
    assert request_items_3.headers["key"] == "value"

# Generated at 2022-06-23 18:50:38.949660
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    x = {'a':'b', 'c':'d'}
    with open("test_file.json", 'w') as outfile:
        json.dump(x, outfile)
    arg = KeyValueArg("test_file.json", "", "")
    json_file_contents = process_data_embed_raw_json_file_arg(arg)
    assert json_file_contents == {'a':'b', 'c':'d'}



# Generated at 2022-06-23 18:50:46.873702
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    request_item = RequestItems()
    arg = KeyValueArg(
        'Header',
        'SeparatorHeader',
        'SeparatorHeader',
        'KeyValue',
        'Value'
    )
    assert process_data_item_arg(arg) == 'Value'
    assert request_item.headers == {}
    assert request_item.data == {}
    assert request_item.files == {}
    assert request_item.params == {}
    assert request_item.multipart_data == {}



# Generated at 2022-06-23 18:50:49.490893
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    json_data = load_json(arg, arg.value)
    assert json_data == {"a": "b", "c": "d"}

# Generated at 2022-06-23 18:50:58.694881
# Unit test for function load_json
def test_load_json():
    import json
    str_json = '{"age":1,"name":"John"}'
    result = load_json(None, str_json)
    assert json.dumps(result, sort_keys=False) == '{"age":1,"name":"John"}'

    str_json = '{"age":1,"name":"\"John\""}'
    result = load_json(None, str_json)
    assert json.dumps(result, sort_keys=False) == '{"age":1,"name":"\"John\""}'

    str_json = '{"age":1,"name":"\'John\'"}'
    result = load_json(None, str_json)
    assert json.dumps(result, sort_keys=False) == '{"age":1,"name":"\'John\'"}'


# Generated at 2022-06-23 18:51:02.182700
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    request_item_args = [KeyValueArg('Header;','')]
    assert  RequestItems.from_args(request_item_args)


# Generated at 2022-06-23 18:51:09.401657
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = tst_obj.parse_items([
        'key;@../data/test_file_data.txt'
    ])
    # The contents of the file is "abc"
    assert process_data_embed_file_contents_arg(arg[0]) == 'abc'
    # Test cases with bad input
    # The file path is not correct
    with pytest.raises(ArgumentParserError):
        arg = tst_obj.parse_items([
            'key;@../data/test_file_data_not_exist.txt'
        ])
        process_data_embed_file_contents_arg(arg[0])
    # The file path is not a text file

# Generated at 2022-06-23 18:51:10.958757
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('foo', 'bar')
    process_header_arg(arg)



# Generated at 2022-06-23 18:51:14.294462
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('foo=bar@test_data.txt')
    assert process_data_embed_file_contents_arg(arg) == 'value1'



# Generated at 2022-06-23 18:51:23.289764
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # When called with a KeyValueArg that has raw JSON, it returns the JSON value
    key_value_arg_with_raw_json_string = KeyValueArg(
        key='data',
        sep=SEPARATOR_DATA_RAW_JSON,
        value='{"hello": "world"}'
    )
    raw_json_from_arg = process_data_raw_json_embed_arg(key_value_arg_with_raw_json_string)
    assert 'hello' in raw_json_from_arg
    assert 'world' == raw_json_from_arg['hello']

# Generated at 2022-06-23 18:51:28.455015
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # python3 -c 'from httpie.cli.input import process_data_embed_file_contents_arg; print(process_data_embed_file_contents_arg(["a","b"]))'
    assert process_data_embed_file_contents_arg(["a","b"]) == None


# Generated at 2022-06-23 18:51:30.729689
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    ret = process_data_item_arg("testest")
    assert ret == "testest"


# Generated at 2022-06-23 18:51:33.136028
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('key:value')
    assert process_header_arg(arg) == 'value'


# Generated at 2022-06-23 18:51:41.243674
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('data@', '/Users/lei/Documents/GitHub/httpie/tests/json/arrays.json')
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == [1, 2, 3]

    arg = KeyValueArg('data@', '/Users/lei/Documents/GitHub/httpie/tests/json/empty.json')
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {}

    arg = KeyValueArg('data@', '/Users/lei/Documents/GitHub/httpie/tests/json/unicode.json')
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 'ä'}



# Generated at 2022-06-23 18:51:44.484872
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg1 = KeyValueArg("name", "jenny")
    print(process_query_param_arg(arg1))

    arg2 = KeyValueArg("name", "jenny", False, False, False, '&')
    print(process_query_param_arg(arg2))


if __name__ == '__main__':
    test_process_query_param_arg()

# Generated at 2022-06-23 18:51:48.503517
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    item = KeyValueArg('-d', '@test_data.txt')
    contents = process_data_embed_file_contents_arg(item)
    assert contents == 'Hello'



# Generated at 2022-06-23 18:51:57.804477
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems()
    items.headers = {'h1': 'header1', 'h2': 'header2'}
    items.data = {'d1': 'data1', 'd2': 'data2'}
    items.files = {'f1': 'file1', 'f2': 'file2'}
    items.params = {'p1': 'param1', 'p2': 'param2'}
    items.multipart_data = {'m1': 'multipart1', 'm2': 'multipart2'}


# Generated at 2022-06-23 18:52:03.308860
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('--header', 'header;', 'header;', 'header;')
    assert process_empty_header_arg(arg) == ''
    arg = KeyValueArg('--header', 'header;abc', 'header;abc', 'abc')
    with pytest.raises(ParseError):
        assert process_empty_header_arg(arg)

# Generated at 2022-06-23 18:52:05.371838
# Unit test for function process_header_arg
def test_process_header_arg():
    result = process_header_arg("Header:value")
    assert result == "value"

# Generated at 2022-06-23 18:52:08.339720
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg("fakedata;/tmp/testfile.txt")
    contents = process_data_embed_file_contents_arg(arg)
    assert contents == u"hello world"

# Generated at 2022-06-23 18:52:17.856888
# Unit test for function load_json
def test_load_json():
    a = KeyValueArg('a', 'a')
    a.value = '{"key": "value"}'
    assert load_json(a, a.value) == {"key": "value"}
    b = KeyValueArg('b', 'b')
    b.value = '[1, 2, 3]'
    assert load_json(b, b.value) == [1, 2, 3]
    c = KeyValueArg('c', 'c')
    c.value = '123'
    assert load_json(c, c.value) == 123
    d = KeyValueArg('d', 'd')
    d.value = 'true'
    assert load_json(d, d.value) == True
    e = KeyValueArg('d', 'd')
    e.value = '"string"'

# Generated at 2022-06-23 18:52:23.370693
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('arg', 'arg', '')) == ''
    assert process_data_item_arg(KeyValueArg('arg;', 'arg;', '')) == ''
    assert process_data_item_arg(KeyValueArg('arg', 'arg', 'value')) == 'value'
    assert process_data_item_arg(KeyValueArg('arg;', 'arg;', 'value')) == 'value'

# Generated at 2022-06-23 18:52:33.468180
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file('/Users/salesforce/PycharmProjects/httpie/tests/foo.json')
        load_text_file('/Users/salesforce/PycharmProjects/httpie/tests/foo.txt')
        load_text_file('/Users/salesforce/PycharmProjects/httpie/tests/foo.jpg')
        load_text_file('/Users/salesforce/PycharmProjects/httpie/tests/foo.html')
        load_text_file('/Users/salesforce/PycharmProjects/httpie/tests/foo.csv')
    except Exception as e:
        print(e)



# Generated at 2022-06-23 18:52:41.510668
# Unit test for constructor of class RequestItems
def test_RequestItems():
    data = '''[
        {
          "id": 5,
          "username": "naifu",
        },
        {
          "id": 1,
          "username": "user",
        }
    ]'''
    request_items = RequestItems.from_args([
        KeyValueArg(
            '-H', 'Content-Type: application/json',
            'header["Content-Type"]="application/json"',
            'header', 'Content-Type: application/json'
        ),
        KeyValueArg(
            '-d', data,
            'data[""]=["{\n        \"id\"..."]',
            'data', data,
        )
    ])
    assert(request_items.headers['Content-Type'] == 'application/json')

# Generated at 2022-06-23 18:52:50.227474
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    processed_file_info = process_file_upload_arg(KeyValueArg(':',
                                                              'file_path',
                                                              'file_name.txt;text/plain'))
    file = processed_file_info[1]
    mime_type = processed_file_info[2]
    assert processed_file_info[0] == 'file_name.txt'
    assert mime_type == 'text/plain'
    assert file.read().decode() == 'Simple text file content'

# Generated at 2022-06-23 18:52:57.097357
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data = {"dob":"2020-09-17"}
    arg = KeyValueArg(None, "data", SEPARATOR_DATA_STRING, data)

    actual = process_data_item_arg(arg)
    print(actual)
    expected = {'dob': '2020-09-17'}

    assert actual == expected


if __name__ == "__main__":
    test_process_data_item_arg()

# Generated at 2022-06-23 18:53:07.362500
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # test case 1: normal case
    request_item_args = [
        KeyValueArg(
            key='header1',
            value='value',
            sep=SEPARATOR_HEADER,
            orig='header1:value'
        ),
        KeyValueArg(
            key='header2',
            value='',
            sep=SEPARATOR_HEADER_EMPTY,
            orig='header2;'
        )
    ]
    request_items = RequestItems.from_args(request_item_args)
    assert request_items.headers == {
        'header1': 'value',
        'header2': None
    }
    # test case 2: exception case

# Generated at 2022-06-23 18:53:10.374622
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data_arg = process_data_item_arg(arg=KeyValueArg('foo', 'bar'))
    assert isinstance(data_arg, str) is True
    assert data_arg == 'bar'


# Generated at 2022-06-23 18:53:17.369523
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    keys_values = ['a','b','c']
    request_item_args = []
    for key_value in keys_values:
        request_item_args.append(KeyValueArg(
            key=key_value,
            value=key_value,
            sep=SEPARATOR_QUERY_PARAM))
    request_items = RequestItems.from_args(request_item_args)
    for key in request_items.params:
        assert key == request_items.params[key]


# Generated at 2022-06-23 18:53:17.951340
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    pass

# Generated at 2022-06-23 18:53:23.362601
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg('test_file.json', '%test', '%test:@test_file.json')
    value = process_data_embed_raw_json_file_arg(test_arg)
    assert value == {
        "test-key-1": "test-value-1",
        "test-key-2": "test-value-2"
    }

# Generated at 2022-06-23 18:53:28.915536
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(':', 'test:', 'test', '@')
    assert process_data_embed_raw_json_file_arg(arg) == ''
    arg = KeyValueArg(':', 'test:', 'test', '')
    process_data_embed_raw_json_file_arg(arg)



# Generated at 2022-06-23 18:53:32.297328
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg_value = process_data_embed_raw_json_file_arg(KeyValueArg('key', '{"name": "value"}'))
    assert arg_value == {"name": "value"}


# Generated at 2022-06-23 18:53:35.066136
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(None, None, None, None, None, None)
    arg.orig = ""
    assert process_data_embed_file_contents_arg(arg) == ""

# Generated at 2022-06-23 18:53:37.719174
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg.from_arg(
        '-f', 'foo:bar:baz')) == ('foo', 'bar', 'baz')

# Generated at 2022-06-23 18:53:40.146708
# Unit test for function load_text_file
def test_load_text_file():
    text_file_name = "pom.xml"
    file_path = "../../" + text_file_name
    item = KeyValueArg(key=None, sep=":", value=file_path, orig=None)
    assert load_text_file(item)

# Generated at 2022-06-23 18:53:45.458467
# Unit test for function load_text_file
def test_load_text_file():
    # Create a file for testing
    test_file_name = "test_file.txt"
    test_file_content = "This is a test file for function load_text_file"
    file_test = open(test_file_name, "w+")
    file_test.write(test_file_content)
    file_test.close()
    # Get the content of the file
    test_load_text_file = load_text_file(test_file_name)
    # Compare the content of the file and the content returned by function load_text_file
    assert test_load_text_file == test_file_content
    # Remove the testing file
    os.remove(test_file_name)

# Generated at 2022-06-23 18:53:50.285285
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(
        'H', 'Accept', 'application/json'
    )) == 'application/json'
    assert process_header_arg(KeyValueArg(
        'H', '-', None
    )) is None


# Generated at 2022-06-23 18:53:53.191793
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    """
    call function process_query_param_arg
    """
    args = ['Key1', 'Value1']
    process_query_param_arg(KeyValueArg(args, 0))


# Generated at 2022-06-23 18:53:58.195191
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    key = "foo"
    value = "/path/to/file.txt"
    sep = ";type=text/html"
    arg = KeyValueArg(key, value, sep)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == "file.txt"
    assert f.read().decode() == "Foobar"
    assert mime_type == "text/html"

# Generated at 2022-06-23 18:54:05.000594
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    a = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key="test_key")
    assert process_empty_header_arg(a) == ""
    a = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key="test_key", value="test_value")
    with pytest.raises(ParseError) as excinfo:
        process_empty_header_arg(a)
    assert "invalid" in str(excinfo.value).lower()


# Generated at 2022-06-23 18:54:16.631617
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    a = KeyValueArg(orig='test orig')
    a.value = 'test value'
    r = process_data_raw_json_embed_arg(a)
    assert r == 'test value'

    # Raise ParseError if the content is invalid json
    a.value = '{"name":"value"'
    try:
        r = process_data_raw_json_embed_arg(a)
    except ParseError as e:
        assert e == 'test orig: Extra data: line 1 column 13 - line 1 column 13 (char 12 - 12)'

    # Raise ParseError if the content is empty
    a.value = ''

# Generated at 2022-06-23 18:54:21.723514
# Unit test for function load_json
def test_load_json():
    print(load_json(load_json_preserve_order(
        "{'name':'joshua'}")), {'name': 'joshua'})

# Generated at 2022-06-23 18:54:24.088148
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(
        'embed', '@test-file.txt', '@test-file.txt')) == 'test content'


# Generated at 2022-06-23 18:54:26.727780
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER, 'Accept', 'text/html')) == 'text/html'


# Generated at 2022-06-23 18:54:29.985678
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    i = KeyValueArg(orig="X;{\"a\": \"b\"}", sep=";", key="X", value="{\"a\": \"b\"}")
    assert process_data_raw_json_embed_arg(i) == {"a": "b"}


# Generated at 2022-06-23 18:54:38.626819
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from httpie.cli.argtypes import KeyValueArg
    arg = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, "name", "testfile.txt")
    # if can load file correctly
    assert process_data_embed_file_contents_arg(arg) == "test"
    # if not a text file
    arg2 = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, "name", "testfile.png")

# Generated at 2022-06-23 18:54:44.914703
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_file_path = os.path.join(os.path.dirname(__file__), 'json_number.json')
    json_file_object = open(json_file_path, 'rb')
    arg = KeyValueArg(None, SEPARATOR_DATA_EMBED_RAW_JSON_FILE, 'key', 'value')
    assert process_data_embed_raw_json_file_arg(arg) == 1

# Generated at 2022-06-23 18:54:47.718816
# Unit test for function load_text_file
def test_load_text_file():
    pwd = os.path.dirname(os.path.abspath(__file__))
    path = pwd+"/../../test/data/test.txt"
    item = KeyV

# Generated at 2022-06-23 18:54:48.883573
# Unit test for constructor of class RequestItems
def test_RequestItems():
    pass

# Generated at 2022-06-23 18:54:52.869927
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    key_value_arg = KeyValueArg("a", "b")
    value = process_data_item_arg(key_value_arg)
    assert value == "b", "Value should be b"

# Generated at 2022-06-23 18:54:55.662942
# Unit test for function load_text_file
def test_load_text_file():
    item_arg = KeyValueArg('data-ascii', ';', 'hello world')
    assert(load_text_file(item_arg) == 'hello world')



# Generated at 2022-06-23 18:55:01.886790
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(orig='key1;', key='key1', value='value1', sep=';')
    try:
        process_empty_header_arg(arg)
        assert False
    except ParseError as e:
        assert e.error == 'Invalid item "key1;value1"' \
            ' (to specify an empty header use `Header;`)'


# Generated at 2022-06-23 18:55:05.084223
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    result = process_query_param_arg(KeyValueArg(orig='test=test', sep='=', key='test', value='test'))
    assert result == 'test'



# Generated at 2022-06-23 18:55:07.548096
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg('a', 'b')) == 'b'


# Generated at 2022-06-23 18:55:19.334399
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.cli.argtypes import KeyValueArg
    a = KeyValueArg("abc", "abc", "abc")
    assert process_data_raw_json_embed_arg(a) == 'abc'
    b = KeyValueArg("abc", "", "")
    assert process_data_raw_json_embed_arg(b) == ''
    c = KeyValueArg("abc", "\'abc\'", "\'abc\'")
    assert process_data_raw_json_embed_arg(c) == 'abc'
    d = KeyValueArg("abc", "[1,2]", "[1,2]")
    assert process_data_raw_json_embed_arg(d) == [1, 2]

# Generated at 2022-06-23 18:55:21.467479
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    input = 'Host;'
    output = next(iter(RequestItems.from_args([KeyValueArg(input)]).headers))
    assert output == 'Host'

# Generated at 2022-06-23 18:55:24.831561
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg = process_header_arg("Token xxxxx")
    assert header_arg == "Token xxxxx"


# Generated at 2022-06-23 18:55:30.863903
# Unit test for function load_json
def test_load_json():
    test = KeyValueArg(
        'Content-Type;application/json;',
        'Content-Type', 'application/json;', ';',
    )
    data = '{"name": "John", "age": 30}'
    data = load_json(test, data)
    assert data["name"] == "John", "Value is not correct"
    assert data["age"] == 30, "Value is not correct"


# Generated at 2022-06-23 18:55:39.016687
# Unit test for function process_header_arg
def test_process_header_arg():
    # param 'arg' is not a KeyValueArg
    try:
        process_header_arg(None)
        assert False
    except Exception as e:
        assert str(e) == 'arg should be a instance of httpie.cli.argtypes.KeyValueArg'

    # param 'arg' is invalid
    try:
        process_header_arg(KeyValueArg(None, None, None))
        assert False
    except Exception as e:
        assert str(e) == 'Invalid param sep or key or value'

    # nothing is expected before or after ':'
    arg = KeyValueArg(SEPARATOR_HEADER, '', '')
    assert process_header_arg(arg) == ''
    arg = KeyValueArg(SEPARATOR_HEADER, ' ', '')
    assert process_header_arg(arg) == ' '

# Generated at 2022-06-23 18:55:44.176243
# Unit test for function process_header_arg
def test_process_header_arg():
    arg1 = KeyValueArg('-H', 'Authorization: Token')
    assert process_header_arg(arg1) == 'Token'
    arg2 = KeyValueArg('-H', 'Authorization;')
    assert process_header_arg(arg2) == ''
    arg3 = KeyValueArg('-H', 'Authorization:')
    assert process_header_arg(arg3) == None


# Generated at 2022-06-23 18:55:47.282274
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    key = "key"
    value = "value"
    arg = KeyValueArg(key, value)
    assert process_data_raw_json_embed_arg(arg) == value



# Generated at 2022-06-23 18:55:51.027929
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    test_args = KeyValueArg('test_data', "--form", "a=b")
    x = process_data_raw_json_embed_arg(test_args)
    print(x)

if __name__ == '__main__':
    test_process_data_raw_json_embed_arg()

# Generated at 2022-06-23 18:56:00.105458
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    #  Basic Object
    try:
        process_data_raw_json_embed_arg(KeyValueArg('raw-json', '{"foo" : "bar"}'))
    except:
        assert False, 'Expected no exception'

    #  Array Object
    try:
        process_data_raw_json_embed_arg(KeyValueArg('raw-json', '[{"foo" : "bar"}]'))
    except:
        assert False, 'Expected no exception'

    #  Invalid JSON
    try:
        process_data_raw_json_embed_arg(KeyValueArg('raw-json', '{"foo" : "bar"}]'))
        assert False, 'Expected exception'
    except:
        pass

# Generated at 2022-06-23 18:56:02.553991
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg('-d', "key=value", None)) == "key=value"

# Generated at 2022-06-23 18:56:07.499715
# Unit test for function load_text_file
def test_load_text_file():
    path = "C:\\Users\\user\\Documents\\GitHub\\httpie\\tests\\data\\auth_basic.json"
    result = load_text_file(path)
    print("result is : " + str(result))

if __name__ == "__main__":
    test_load_text_file()

# Generated at 2022-06-23 18:56:10.466972
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert isinstance(RequestItems.from_args([KeyValueArg(SEPARATOR_HEADER, name='name', value='value')]), RequestItems)


# Generated at 2022-06-23 18:56:17.467605
# Unit test for function load_json
def test_load_json():
    assert load_json(KeyValueArg("",""), "") == ""
    assert load_json(KeyValueArg("",""), "[]") == []
    assert load_json(KeyValueArg("",""), "{}") == {}
    assert load_json(KeyValueArg("",""), "{\"a\":1}") == {"a":1}
    assert load_json(KeyValueArg("",""), "[\"a\",1]") == ["a",1]
    assert load_json(KeyValueArg("",""), "{\"a\":{}, \"b\":[]}") == {"a":{}, "b":[]}

# Generated at 2022-06-23 18:56:27.916028
# Unit test for constructor of class RequestItems
def test_RequestItems():
    item_args = [KeyValueArg('header1', 'value1', ':'), 
                KeyValueArg('header2', None, ';'), 
                KeyValueArg('header3', 'value3', ':'),
                KeyValueArg('para1', 'value1', '?'),
                KeyValueArg('para2', None, '?'),
                KeyValueArg('para3', 'value3', '?'),
                KeyValueArg('data', 'value_data', '='),
                KeyValueArg('embed', 'value_embed', '@'),
                KeyValueArg('file', 'httpbin.py', '<')]
    request_items = RequestItems.from_args(item_args)
    print(request_items.headers)
    print(request_items.data)
    print(request_items.params)


# Generated at 2022-06-23 18:56:33.677564
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # Test for valid parsing
    arg = KeyValueArg('User-Agent;')
    assert process_empty_header_arg(arg) is None

    # Test for exception
    arg = KeyValueArg('User-Agent,test')
    try:
        process_empty_header_arg(arg)
        assert False
    except ParseError:
        assert True

# Generated at 2022-06-23 18:56:41.259513
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    header = KeyValueArg(
        key=None,
        value=None,
        sep=SEPARATOR_HEADER_EMPTY,
        orig=''
    )
    assert process_empty_header_arg(header) == ''
    header = KeyValueArg(
        key=None,
        value='value',
        sep=SEPARATOR_HEADER_EMPTY,
        orig=''
    )
    with pytest.raises(ParseError):
        process_empty_header_arg(header)



# Generated at 2022-06-23 18:56:47.214243
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg_with_value = KeyValueArg("Key:value", "Key", ":", "value")
    assert process_empty_header_arg(arg_with_value) == "value"
    arg_without_value = KeyValueArg("Key;", "Key", ";", "")
    assert process_empty_header_arg(arg_without_value) == ""

# Generated at 2022-06-23 18:56:49.921046
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    try:
        process_data_raw_json_embed_arg(None)
    except Exception as e:
        assert type(e) is TypeError, 'exception is not TypeError'

# Generated at 2022-06-23 18:56:53.046886
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('key', 'value')
    actual = process_query_param_arg(arg)
    assert actual == 'value'

# Generated at 2022-06-23 18:57:03.286537
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from httpie.cli.parser import KeyValueArg
    from httpie.cli.argtypes import KeyValue_AnyValue

    file_content = process_data_embed_file_contents_arg(KeyValueArg(
                                'file', '@', 'testdata.json'))
    expected_content = {
        "array": [1, 2, 3],
        "boolean": False,
        "color": "#ffffff",
        "null": None,
        "number": 123,
        "object": {"a": "b", "c": "d", "e": "f"},
        "string": "Hello World"
    }
    assert expected_content == load_json_preserve_order(file_content)

# Generated at 2022-06-23 18:57:09.294555
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    """
    Test function process_data_embed_file_contents_arg
    """
    assert process_data_embed_file_contents_arg(KeyValueArg(
        'arg',
        ':',
        '@/root/this.txt'
    )) == "asdasdasd"

# Generated at 2022-06-23 18:57:11.656566
# Unit test for function load_text_file
def test_load_text_file():
    text_file = load_text_file('test.txt')
    #assert text_file == 'testing'
    print(text_file)

# Generated at 2022-06-23 18:57:14.965568
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    value = process_data_embed_raw_json_file_arg(KeyValueArg('', 'data_file_path.json', ''))
    assert value == {u'x': u'1', u'y': u'2'}


# Generated at 2022-06-23 18:57:20.995678
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():

    a = KeyValueArg(orig='key:')
    process_header_arg(a) == "key:"

    b = KeyValueArg(orig='key:value')
    process_header_arg(b) == "key:value"

    c = KeyValueArg(orig=';', value='somevalue')
    process_header_arg(c) == "somevalue"

    d = KeyValueArg(orig=';', value='')
    process_header_arg(d) == ""

    e = KeyValueArg(orig=';', value=None)
    process_header_arg(e) == ""

# Generated at 2022-06-23 18:57:25.392310
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
  arg = KeyValueArg(orig='tomcat; test.json;', sep=';', key='tomcat', value='test.json')
  assert type(process_data_embed_raw_json_file_arg(arg)) == JSONType


if __name__ == '__main__':
  test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-23 18:57:36.700265
# Unit test for constructor of class RequestItems
def test_RequestItems():
    defaultSeparators = (
        SEPARATOR_HEADER,
        SEPARATOR_HEADER_EMPTY,
        SEPARATOR_DATA_STRING,
        SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        SEPARATOR_FILE_UPLOAD,
    )
    for sep in defaultSeparators:
        fullArg = KeyValueArg.from_arg(f"foo{sep}bar")
        test = RequestItems.from_args([fullArg], False)
        assert str(test.data) == "{'foo': 'bar'}"

    # process_header_arg testing
    fullArg = KeyValueArg.from_arg(f"foo{SEPARATOR_HEADER}bar")
    test = RequestItems.from_args([fullArg], False)

# Generated at 2022-06-23 18:57:40.761839
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg('test;test','test;test')
    assert process_file_upload_arg(file_upload_arg) == process_file_upload_arg(file_upload_arg)

# Generated at 2022-06-23 18:57:42.783904
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('key;', 'value', 'key;value')) == None


# Generated at 2022-06-23 18:57:47.339559
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args = {
        'sep': '@',
        'key': 'image',
        'orig': 'image@image.jpg',
        'value': 'image.jpg',
        'sep_index': 4,
    }
    arg = KeyValueArg(**args)
    ans = process_file_upload_arg(arg)
    assert ans[0] == 'image.jpg'

# Generated at 2022-06-23 18:57:48.833615
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg("foo", "bar") == "bar"