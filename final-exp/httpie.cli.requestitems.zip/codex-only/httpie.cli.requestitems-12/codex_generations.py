

# Generated at 2022-06-23 18:48:00.918391
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key = 'key1',value = 'value1',sep = SEPARATOR_DATA_RAW_JSON,orig = 'key1:value1')
    assert process_data_raw_json_embed_arg(arg) == 'value1'

    arg = KeyValueArg(key = 'key2',value = '"value2"',sep = SEPARATOR_DATA_RAW_JSON,orig = 'key2:"value2"')
    assert process_data_raw_json_embed_arg(arg) == 'value2'

    arg = KeyValueArg(key = 'key3',value = '[1,2]',sep = SEPARATOR_DATA_RAW_JSON,orig = 'key3:[1,2]')
    assert process_data_raw_json_embed_arg(arg) == [1,2]

# Generated at 2022-06-23 18:48:08.002581
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from httpie.cli.parser import KeyValueArg
    file_name = __file__
    print(file_name)
    test_arg = KeyValueArg(file_name, "=")
    value = process_data_embed_file_contents_arg(test_arg)
    print(value)


if __name__ == '__main__':
    test_process_data_embed_file_contents_arg()

# Generated at 2022-06-23 18:48:10.528546
# Unit test for function load_json
def test_load_json():
    print(load_json(1, '{ "key1" : "value1" }'))
    print(load_json(1, '{ "key1" : "value1", "key2" : "value2" }'))

# Generated at 2022-06-23 18:48:18.863853
# Unit test for function process_file_upload_arg

# Generated at 2022-06-23 18:48:21.076628
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    return process_data_raw_json_embed_arg("{'a': 'b'}")



# Generated at 2022-06-23 18:48:23.205482
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg("a", "b")
    assert process_query_param_arg(arg) == "b"

# Generated at 2022-06-23 18:48:30.854054
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg(
        sep = SEPARATOR_DATA_RAW_JSON,
        key = 'name',
        value = '["alice","bob"]'
    )
    try:
        load_json(arg, contents='["alice","bob"]')
    except ValueError as e:
        print(e)

    try:
        load_json(arg, contents='["alice","bob"')
    except ValueError as e:
        print(e)

# Generated at 2022-06-23 18:48:38.106465
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(source="", orig="Header;", separator=';', key='Header', value="")
    header: Optional[str] = process_empty_header_arg(arg)
    assert header == ""

    arg.value = "value"
    try:
        process_empty_header_arg(arg)
        assert False
    except ParseError as e:
        assert str(e) == 'Invalid item "Header;value" (to specify an empty header use `Header;`)'

# Generated at 2022-06-23 18:48:46.062509
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    """
    For https://github.com/jakubroztocil/httpie/issues/1260,
    this function is used to test whether the error message when
    parsing an empty http header has been improved.
    """
    arg = KeyValueArg(sep=';', orig='Header;')
    try:
        process_empty_header_arg(arg)
    except ParseError as e:
        print(e)
    else:
        assert False, 'ParseError not raised'

# Generated at 2022-06-23 18:48:49.179251
# Unit test for function load_json
def test_load_json():
    item = KeyValueArg("--item", '{"1":1}', "")
    result = load_json(item, item.value)
    assert result == {'1':1}

# Generated at 2022-06-23 18:48:57.944448
# Unit test for constructor of class RequestItems
def test_RequestItems():
    item1 = KeyValueArg(orig="-H", key="Accept", value="application/json", sep="-H")
    item2 = KeyValueArg(orig="-H", key="Connection", value="keep-alive", sep="-H")
    item3 = KeyValueArg(orig="-H", key="Cache-Control", value="no-cache", sep="-H")
    item4 = KeyValueArg(orig="-H", key="Accept", value="text/html,application/xhtml+xml,application/xml;q=0.9", sep="-H")
    request_item_args = [item1, item2, item3, item4]
    RequestItems.from_args(request_item_args, as_form=False)

# Generated at 2022-06-23 18:48:59.665726
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("test", "a.txt")
    load_text_file(item)

# Generated at 2022-06-23 18:49:10.083290
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # as_form=False
    request_items = RequestItems(as_form=False)
    assert isinstance(request_items.data, RequestJSONDataDict)
    assert isinstance(request_items.params, RequestQueryParamsDict)
    assert isinstance(request_items.headers, RequestHeadersDict)
    assert isinstance(request_items.files, RequestFilesDict)

    # as_form=True
    request_items = RequestItems(as_form=True)
    assert isinstance(request_items.data, RequestDataDict)
    assert isinstance(request_items.params, RequestQueryParamsDict)
    assert isinstance(request_items.headers, RequestHeadersDict)
    assert isinstance(request_items.files, RequestFilesDict)

# Generated at 2022-06-23 18:49:18.322240
# Unit test for function load_json
def test_load_json():
    assert load_json("abc", "abc") == "abc"
    assert load_json("123", "123") == 123
    assert load_json("true", "true") == True
    assert load_json("false", "false") == False
    assert load_json("null", "null") == None
    assert load_json("{}", "{}") == {}
    assert load_json("[]", "[]") == []
    assert load_json("{\"key\":\"value\"}", '{"key":"value"}') == {'key': 'value'}

# Generated at 2022-06-23 18:49:26.431686
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():

    # get argument from main 
    main_args = main.parse_args(
        args=[
            '--print=all',
            'example.com',
            'X-header;'
        ]
    )

    # process empty header arg
    request_items = RequestItems.from_args(
        request_item_args=main_args.items,
        as_form=main_args.form,
    )

    # check header
    assert(request_items.headers['X-header'] == '')



# Generated at 2022-06-23 18:49:31.942126
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    requestItemArg = KeyValueArg()
    requestItemArg.key = "data"
    requestItemArg.sep = SEPARATOR_DATA_STRING
    requestItemArg.value = "foo"
    requestItemArg.orig = "data=foo"

    ret = process_data_item_arg(requestItemArg)
    assert ret == "foo"

# Generated at 2022-06-23 18:49:38.109995
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # test file contents
    test_value = 'test'
    # test file name
    test_filename = 'test.txt'

    # create test file
    f = open(test_filename, 'w')
    f.write(test_value)
    f.close()

    # create test arg
    test_arg = KeyValueArg('test', test_filename, ';', 'test; test.txt')

    result = process_data_embed_file_contents_arg(test_arg)

    # delete test file
    os.remove(test_filename)

    assert result == test_value

# Generated at 2022-06-23 18:49:42.704819
# Unit test for constructor of class RequestItems
def test_RequestItems():
    requestItems = RequestItems()
    assert isinstance(requestItems.headers, RequestHeadersDict)
    assert isinstance(requestItems.data, RequestJSONDataDict)
    assert isinstance(requestItems.files, RequestFilesDict)
    assert isinstance(requestItems.params, RequestQueryParamsDict)
    assert isinstance(requestItems.multipart_data, MultipartRequestDataDict)

    requestItems = RequestItems(as_form=True)
    assert isinstance(requestItems.headers, RequestHeadersDict)
    assert isinstance(requestItems.data, RequestDataDict)
    assert isinstance(requestItems.files, RequestFilesDict)
    assert isinstance(requestItems.params, RequestQueryParamsDict)

# Generated at 2022-06-23 18:49:48.076530
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(key="id", value='./id.json', orig='id@./id.json', sep='@')
    test_result = process_data_embed_file_contents_arg(arg)
    assert test_result == '820006113700\n'


# Generated at 2022-06-23 18:49:53.811636
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.core import MainRequest
    
    ri = RequestItems.from_args(None, None)
    assert isinstance(ri, RequestItems)
    
    riArgs = RequestItems.from_args(MainRequest(stdin=None, argv=None, env=None).args,)
    assert isinstance(riArgs, RequestItems)

# Generated at 2022-06-23 18:50:04.391137
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('_;password.txt', '"password.txt"')) == "testing\n"
    assert load_text_file(KeyValueArg('_;password.txt', 'password.txt')) == "testing\n"
    assert load_text_file(KeyValueArg('_;password.txt', 'tests/password.txt')) == "testing\n"
    assert load_text_file(KeyValueArg('_;password.txt', '~/httpie/tests/password.txt')) == "testing\n"
    
    # UnicodeDecodeError
    try:
        load_text_file(KeyValueArg('_;password.txt', 'tests/images/Screen Shot 2017-05-25 at 11.51.13.png'))
    except ParseError as err:
        assert str

# Generated at 2022-06-23 18:50:07.625434
# Unit test for function load_json
def test_load_json():
    testarg=KeyValueArg(1, 'key', 'value')
    testjson_str = '{"json_key": "json_value"}'
    assert(dict == type(load_json(testarg, testjson_str)))


# Generated at 2022-06-23 18:50:10.780628
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    process_data_embed_file_contents_arg(KeyValueArg('@', "./test_parse.py"))
    with pytest.raises(ParseError):
        process_data_embed_file_contents_arg(KeyValueArg('@', "./test_wrong.py"))

# Generated at 2022-06-23 18:50:21.566954
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:50:25.307703
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # function process_empty_header_arg(arg: KeyValueArg) -> str:
    test = KeyValueArg('','')
    a = process_empty_header_arg(test)
    assert a == ''

# Generated at 2022-06-23 18:50:35.691042
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    test_input = [
        ('a', '1', '{"a": 1}'),
     #   ('a', '{"a":}', "{'a':}"),
        ('a', '{"a": 1}', '{"a": 1}'),
        ('a', '{"a": {"a": 1}}', '{"a": {"a": 1}}'),
        ('a', '{"a": {"a": 1, "b": 2}}', '{"a": {"a": 1, "b": 2}}'),
        ('a', '{"a": ["a", "b"]}', '{"a": ["a", "b"]}'),
    ]
    for k, v, expected in test_input:
        arg = KeyValueArg(k, '=', v, '-d', 'a=1')
        assert process_data_raw_json_

# Generated at 2022-06-23 18:50:40.414052
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file@/Users/duonghung86/Desktop/Testfile.txt')
    assert process_file_upload_arg(arg) == ('Testfile.txt', open('/Users/duonghung86/Desktop/Testfile.txt', 'rb'), 'text/plain')



# Generated at 2022-06-23 18:50:45.198815
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('a', 'b')
    result = process_data_item_arg(arg)
    result1 = process_data_item_arg(arg)
    assert result == result1


# Generated at 2022-06-23 18:50:54.729058
# Unit test for function load_text_file
def test_load_text_file():
    file_path = 'test_dir/test.txt'
    item = KeyValueArg('d', file_path)
    assert load_text_file(item) == 'It\'s a test!'

    file_path = 'test_dir/test_error1.txt'
    item = KeyValueArg('d', file_path)
    try:
        load_text_file(item)
        assert False
    except ParseError:
        assert True
    file_path = 'test_dir/test_error2.txt'
    item = KeyValueArg('d', file_path)
    try:
        load_text_file(item)
        assert False
    except ParseError:
        assert True



# Generated at 2022-06-23 18:51:00.520037
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='Cookie', sep=SEPARATOR_FILE_UPLOAD, value='cookie_file.txt')
    value = process_file_upload_arg(arg)
    assert value == ('cookie_file.txt', f, get_content_type('cookie_file.txt'))



# Generated at 2022-06-23 18:51:08.796895
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(None, "JSON", "[1,2,3]", None, None, -1)) == [1,2,3]
    assert process_data_raw_json_embed_arg(KeyValueArg(None, "JSON", "{\"a\":[1,2,3],\"b\":{\"c\":\"d\"}}", None, None, -1)) == {"a":[1,2,3], "b": {"c": "d"}}
    #assert process_data_raw_json_embed_arg(KeyValueArg(None, "JSON", "{\"a\":[1,2,3],\"b\":{\"c\":\"d\"}}", None, None, -1))  == [1,2,3]
    #assert process_data_raw_json_embed_arg

# Generated at 2022-06-23 18:51:10.958263
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    test_arg = KeyValueArg(orig = "My-Header;", key = "My-Header", sep = ";", value = None)
    assert process_empty_header_arg(test_arg) == None

# Generated at 2022-06-23 18:51:20.321632
# Unit test for function process_header_arg
def test_process_header_arg():
    arg1 = KeyValueArg('test:test1')
    assert process_header_arg(arg1) == 'test1'
    arg2 = KeyValueArg('test:')
    assert process_header_arg(arg2) is None
    arg3 = KeyValueArg('test;"')
    assert process_header_arg(arg3) is None
    arg4 = KeyValueArg('test;test1')
    assert process_header_arg(arg4) is None
    arg5 = KeyValueArg('test;;"test1")')
    assert process_header_arg(arg5) is None


# Generated at 2022-06-23 18:51:32.522673
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test for valid json
    json_string = '{"test": 1}'
    json_string_orig = 'json@' + json_string
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_RAW_JSON,
        key='json',
        orig=json_string_orig,
        value=json_string,
    )
    res_json = process_data_raw_json_embed_arg(arg)
    assert isinstance(res_json, dict)
    assert res_json == {"test": 1}

    # Test for no valid json
    json_string = '{"test: 1}'
    json_string_orig = 'json@' + json_string

# Generated at 2022-06-23 18:51:38.986420
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg1 = KeyValueArg('', '', '', '', '', '', '', '')
    arg1.key = 'a'
    arg1.value = '1'
    arg1.orig = '{}'
    process_data_raw_json_embed_arg(arg1)

# Generated at 2022-06-23 18:51:40.761905
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('foo', 'bar', '?', '?foo=bar')
    assert process_query_param_arg(arg) == 'bar'



# Generated at 2022-06-23 18:51:42.206789
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg(KeyValueArg(None, None, None, 'test1', 'test')) == 'test'

# Generated at 2022-06-23 18:51:52.492738
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    try:
        from httpie.cli.dicts import RequestJSONDataDict
    except:
        from httpie.cli.dicts import RequestDataDict as RequestJSONDataDict
    j = {"name": "foo"}

    value = process_data_raw_json_embed_arg(None, json.dumps(j))
    assert isinstance(value, RequestJSONDataDict)
    assert value == j

    value = process_data_raw_json_embed_arg(None, str(j))
    assert isinstance(value, RequestJSONDataDict)
    assert value == j

    try:
        process_data_raw_json_embed_arg(None, "{")
    except ParseError:
        pass


# Generated at 2022-06-23 18:51:57.626631
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    args = KeyValueArg(
        "", "", "", "", "", "", "", "", "",
        'name', 'value', 'data'
    )
    if process_data_item_arg(args) != 'value':
        print('Test process_data_item_arg Fail')



# Generated at 2022-06-23 18:51:59.914379
# Unit test for constructor of class RequestItems
def test_RequestItems():
    from httpie.cli.argtypes import KeyValueArg
    assert RequestItems([KeyValueArg('name', 'value')]) is not None

# Generated at 2022-06-23 18:52:03.782838
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('foo', 'bar')
    expected = 'bar'
    actual = process_header_arg(arg)
    print(actual)
    assert expected == actual
    assert type(actual) is str


# Generated at 2022-06-23 18:52:07.830293
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = RequestItems.process_data_raw_json_embed_arg(
        '{"name":"bibi","age":123}'
    )
    assert type(arg) == dict
    assert arg["name"] == "bibi"
    assert arg["age"] == 123

# Generated at 2022-06-23 18:52:11.832518
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    key = "key"
    value = "value"
    keyvalue_arg = KeyValueArg(key, value, SEPARATOR_DATA_STRING)
    test_result = process_data_item_arg(keyvalue_arg)
    assert test_result == value


# Generated at 2022-06-23 18:52:14.214965
# Unit test for function load_text_file
def test_load_text_file():
    res = load_text_file("../test.txt")
    print(res)
    assert res == "test"

test_load_text_file()


# Generated at 2022-06-23 18:52:16.121024
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    assert process_data_item_arg(KeyValueArg(sep='', key='abc', value='abc')) == 'abc'

# Generated at 2022-06-23 18:52:18.204826
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg('key', 'value', 'key:value')
    assert process_query_param_arg(arg) == 'value'

# Generated at 2022-06-23 18:52:22.051538
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        value=":/foo/bar"
    )
    print(process_data_embed_file_contents_arg(arg))

# Generated at 2022-06-23 18:52:24.381034
# Unit test for constructor of class RequestItems
def test_RequestItems():
    arg = KeyValueArg()
    arg.sep = 'Header;'
    arg.key = 'Host'

    request_item_args = [arg]
    request_items = RequestItems.from_args(request_item_args)
    assert request_items.headers["Host"] == None

# Generated at 2022-06-23 18:52:35.625709
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import tempfile

    # create a temporary file for testing 
    temp_file = tempfile.NamedTemporaryFile(mode='w+')
    temp_file.write('Hello World\n')
    temp_file.seek(0)

    # check if it's the same file
    assert process_file_upload_arg('foo;bar', temp_file.name) == (temp_file.name, temp_file, 'bar')

    # check if it's the same file but with missing mime_type
    assert process_file_upload_arg('foo', temp_file.name) == (temp_file.name, temp_file, 'text/plain')
    
    # check if this function throws an exception when file doesn't exist

# Generated at 2022-06-23 18:52:37.929942
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    q = KeyValueArg(sep=SEPARATOR_QUERY_PARAM, key='k', value='v')
    assert process_query_param_arg(q) == 'v'

# Generated at 2022-06-23 18:52:41.304507
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_name = "httpie/testdata/file.txt"
    file_upload_arg = KeyValueArg('file', file_name, SEPARATOR_FILE_UPLOAD, "")
    value = process_file_upload_arg(file_upload_arg)
    file_txt = open(file_name)
    assert file_txt.read() == value[1].read()

# Generated at 2022-06-23 18:52:46.617721
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg()
    arg.orig = ''
    arg.sep = ''
    arg.key = ''
    arg.value = '{"a": "b", "c": "d"}'
    print(load_json(arg, arg.value))


# Generated at 2022-06-23 18:52:58.593659
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
  arg = argparse.Namespace(key = "key1", value = "value1", orig = "key1:value1", sep = 'Header')
  #assert(process_empty_header_arg(arg) == "value1")
  #assert(process_empty_header_arg(arg) != "value2")

  arg = argparse.Namespace(key = "key2", value = "", orig = "key2:", sep = "Header")
  #assert(process_empty_header_arg(arg) == "")
  #assert(process_empty_header_arg(arg) != "value2")

  arg = argparse.Namespace(key = "key3", value = "", orig = "key3;", sep = "Header;")
  #assert(process_empty_header_arg(arg) == "")
  #

# Generated at 2022-06-23 18:53:03.626112
# Unit test for function load_text_file
def test_load_text_file():
    f = open('some_file.txt', 'wb')
    f.write(b'Hello, world')
    f.close()
    test_arg = KeyValueArg(key='=some_file.txt', value='some_file.txt', sep='@')
    result = load_text_file(test_arg)
    assert result == 'Hello, world'

# Generated at 2022-06-23 18:53:04.920310
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file('sample_text_file.txt') == 'Hello world!'

# Generated at 2022-06-23 18:53:10.569621
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg
    test_case_0 = 'foo.json'
    test_arg_0 = KeyValueArg("foo", SEPARATOR_DATA_EMBED_RAW_JSON_FILE, test_case_0)
    actual_0 = process_data_embed_raw_json_file_arg(test_arg_0)
    expected_0 = {'foo':'bar'}
    assert actual_0 == expected_0

# Generated at 2022-06-23 18:53:17.604647
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert ({'key': 'value'} == process_data_raw_json_embed_arg(KeyValueArg(
        key='test', sep=SEPARATOR_DATA_RAW_JSON, value='{"key": "value"}')))
    assert ({'key': 'value'} == process_data_raw_json_embed_arg(KeyValueArg(
        key='test', sep=SEPARATOR_DATA_RAW_JSON, value='{"key": "value"}')))
    assert ({'key': 'value'} == process_data_raw_json_embed_arg(KeyValueArg(
        key='test', sep=SEPARATOR_DATA_RAW_JSON, value=' {"key": "value"} ')))

# Generated at 2022-06-23 18:53:22.024298
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import SEPARATOR_QUERY_PARAM
    arg = KeyValueArg(SEPARATOR_QUERY_PARAM, "name", "value")
    assert process_query_param_arg(arg) == "value"

# Generated at 2022-06-23 18:53:31.456123
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert (RequestItems(as_form=False).data.__class__.mro() == [RequestItems.data.__class__,RequestJSONDataDict])
    assert (RequestItems(as_form=True).data.__class__.mro() == [RequestItems.data.__class__,RequestDataDict])
    assert (RequestItems(as_form=False).files.__class__.mro() == [RequestItems.files.__class__,RequestFilesDict])
    assert (RequestItems(as_form=True).files.__class__.mro() == [RequestItems.files.__class__,RequestFilesDict])
    assert (RequestItems(as_form=False).params.__class__.mro() == [RequestItems.params.__class__,RequestQueryParamsDict])

# Generated at 2022-06-23 18:53:36.622089
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(orig='Header',sep='Header_empty',key='Header',value=None)
    assert not process_empty_header_arg(arg)
    arg = KeyValueArg(orig='Header',sep='Header_empty',key='Header',value='')
    assert not process_empty_header_arg(arg)


# Generated at 2022-06-23 18:53:39.164772
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(sep=";", key="Accept", value="application/json")
    assert process_header_arg(arg) == 'application/json'


# Generated at 2022-06-23 18:53:42.512987
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    path = 'raw_json.json'
    f = open(path, 'rb')

    try:
        item = KeyValueArg('raw_json.json', ':')
        load_json(item, f)
    except ParseError as e:
        print(e)

# Generated at 2022-06-23 18:53:47.783667
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    key_value_arg = KeyValueArg(SEPARATOR_QUERY_PARAM, key="test", value="test")
    assert process_query_param_arg(key_value_arg) == "test"



# Generated at 2022-06-23 18:53:51.947205
# Unit test for function load_text_file
def test_load_text_file():
    result = load_text_file(KeyValueArg(
        '-h',
        'Content-Type',
        'test/plain',
        None,
        'Content-Type',
        'test/plain',
        None))
    assert result == 'test/plain'



# Generated at 2022-06-23 18:53:59.173146
# Unit test for function process_header_arg
def test_process_header_arg():
    pair_list = [
        ('', ('Host', None)),
        ('User-Agent', ('User-Agent', 'Mozilla/5.0')),
        ('Accept', ('Accept', '*')),
        ('Accept-Language', ('Accept-Language', 'zh-CN')),
    ]
    for pair in pair_list:
        arg = KeyValueArg(pair[0], ';')
        header = process_header_arg(arg)
        assert header[0] == pair[1][0]
        assert header[1] == pair[1][1]


# Generated at 2022-06-23 18:54:02.692992
# Unit test for constructor of class RequestItems
def test_RequestItems():
    instance = RequestItems(as_form=False)
    request_item_args = ['args.txt']
    cls = RequestItems.from_args(request_item_args, as_form=False)
    print(cls)

# Generated at 2022-06-23 18:54:09.211253
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_file = open('test.txt', 'w')
    test_file.write('test')
    test_file.close()
    arg = KeyValueArg('-d', '@test.txt')
    assert process_data_embed_file_contents_arg(arg) == 'test'
    os.remove('test.txt')

# Generated at 2022-06-23 18:54:11.759387
# Unit test for function process_header_arg
def test_process_header_arg():
    header_arg: KeyValueArg
    header_arg = KeyValueArg('foo:bar')
    assert process_header_arg(header_arg) == 'bar'
    header_arg = KeyValueArg('foo;')
    assert process_header_arg(header_arg) == ''
    

# Generated at 2022-06-23 18:54:18.147387
# Unit test for function load_json
def test_load_json():
    # This function is a unit test for function load_json(arg, contents)
    # return 0 if it works properly, else return 1
    # test1: contents is a valid json string
    item = KeyValueArg("data", "test", "test")
    contents = '{"a": {"b": [1, 2, 3], "c": null}}'
    try:
        load_json(item, contents)
        return 0
    except ValueError as e:
        return 1
    except UnicodeDecodeError:
        return 1
    
    

# Generated at 2022-06-23 18:54:22.661181
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arguments = "data_item_arg=value"
    expected = "value"

    result = process_data_item_arg(arguments)

    assert(result == expected)


# Generated at 2022-06-23 18:54:27.182670
# Unit test for function load_text_file
def test_load_text_file():
    f = open('data/myfile.txt','w')
    f.write('test')
    f.close()
    items = [KeyValueArg(sep=None, key="test", value='data/myfile.txt', orig="")]
    s = process_data_embed_file_contents_arg(items[0])
    print(s)

# Generated at 2022-06-23 18:54:29.031378
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg('k', 'v', False)
    print(process_data_item_arg(arg))


# Generated at 2022-06-23 18:54:37.696476
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(arg=KeyValueArg(key="key", value="foo.txt", sep=SEPARATOR_FILE_UPLOAD)) == ("foo.txt", open("foo.txt", 'rb'), "text/plain")
    assert process_file_upload_arg(arg=KeyValueArg(key="key", value="foo.txt;", sep=SEPARATOR_FILE_UPLOAD)) == ("foo.txt", open("foo.txt", 'rb'), "text/plain")
    assert process_file_upload_arg(arg=KeyValueArg(key="key", value="foo.txt;text/html", sep=SEPARATOR_FILE_UPLOAD)) == ("foo.txt", open("foo.txt", 'rb'), "text/html")

# Generated at 2022-06-23 18:54:41.318376
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(None, 'key', 'value', 'param')
    assert process_query_param_arg(arg) == 'value'


# Generated at 2022-06-23 18:54:45.199431
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = "--data-raw-json"
    arg_value = '''{"a":"1", "b":"2"}'''
    assert process_data_raw_json_embed_arg(arg, arg_value) == {"a":"1", "b":"2"}

# Generated at 2022-06-23 18:54:47.278406
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    sut = process_data_raw_json_embed_arg("[\"Hello\", \"World\"]")
    assert sut == ["Hello", "World"]

# Generated at 2022-06-23 18:54:50.640874
# Unit test for function load_json
def test_load_json():
    value = load_json(KeyValueArg("test","test"), '{"test": "testvalue"}')
    assert value == {"test": "testvalue"}

# Generated at 2022-06-23 18:55:00.756547
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    path = 'test.json'
    try:
        with open(os.path.expanduser(path), 'rb') as f:
            f.read().decode()
            print('test_process_data_embed_raw_json_file_arg: pass')
    except IOError as e:
        print('test_process_data_embed_raw_json_file_arg: fail', e)
    except UnicodeDecodeError:
        print('test_process_data_embed_raw_json_file_arg: fail',
              'cannot embed the content of "%s",'
              ' not a UTF8 or ASCII-encoded text file'
              % (path))



# Generated at 2022-06-23 18:55:03.513630
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg('test', 'hello', '@')) == ('hello', 'hello', 'hello')

# Generated at 2022-06-23 18:55:07.205125
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    arg = KeyValueArg(SEPARATOR_QUERY_PARAM, 'name', 'name')
    output = process_query_param_arg(arg)
    assert output == 'name'


# Generated at 2022-06-23 18:55:18.667609
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    from httpie.cli.argtypes import KeyValueArg

    arg = KeyValueArg(sep="<", key="foo", value="bar.png < some.json")
    assert process_file_upload_arg(arg) == ('bar.png', open('some.json'), 'application/json')

    arg = KeyValueArg(sep="<", key="foo", value="bar.png < some.json image/png")
    assert process_file_upload_arg(arg) == ('bar.png', open('some.json'), 'image/png')

    arg = KeyValueArg(sep="<", key="foo", value="bar.png")
    assert process_file_upload_arg(arg) == ('bar.png', open('bar.png'), 'image/png')

# Generated at 2022-06-23 18:55:20.819082
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg('data', 'test.json', 'data-k', 'data-v')
    assert process_data_embed_file_contents_arg(arg) == {'data-k': 'data-v'}

# Generated at 2022-06-23 18:55:28.739987
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    data_embed_raw_json_file_arg = KeyValueArg(arg="test_data;test_file.json", key="test_data", sep=";", value="test_file.json")
    load_json_preserve_order_success = {"a":"b"}
    load_json_preserve_order_fail = "asd"
    assert(process_data_embed_raw_json_file_arg(data_embed_raw_json_file_arg) == load_json_preserve_order_fail)

# Generated at 2022-06-23 18:55:37.026148
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON, key=None, value='{}')) == {}
    assert process_data_raw_json_embed_arg(KeyValueArg(sep=SEPARATOR_DATA_RAW_JSON, key=None, value='{"list": [1,2,3]}')) == {'list': [1,2,3]}

test_process_data_raw_json_embed_arg()

# Generated at 2022-06-23 18:55:42.393994
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import json
    assert (
        process_data_raw_json_embed_arg(
            KeyValueArg(
                ':',
                '',
                '',
                '{ "ab": 2, "b": [1, 2, 3] }',
                '{ "ab": 2, "b": [1, 2, 3] }'
            ),
        ) == json.loads('{ "ab": 2, "b": [1, 2, 3] }')
    )

# Generated at 2022-06-23 18:55:52.860152
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    import json
    import jsonschema
    from jsonschema import validate

# Generated at 2022-06-23 18:55:56.227032
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg("Content-Type: text/plain")
    assert process_header_arg(arg) == 'text/plain'
    arg = KeyValueArg("Content-Type: ")
    assert process_header_arg(arg) == None


# Generated at 2022-06-23 18:56:00.926641
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='', orig='')
    assert isinstance(process_data_raw_json_embed_arg(arg), JSONType)

# Generated at 2022-06-23 18:56:01.529378
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    return True

# Generated at 2022-06-23 18:56:08.375259
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    """
    Function name: test_process_data_raw_json_embed_arg
    Description: test function load raw json data
    """
    arg = KeyValueArg(orig=None, sep=SEPARATOR_DATA_RAW_JSON,
                key=None, value='{"name": "Bomber"}')
    assert process_data_raw_json_embed_arg(arg) == {"name": "Bomber"}

# Generated at 2022-06-23 18:56:18.378929
# Unit test for function load_json
def test_load_json():
    assert load_json(None, '{"a": "b"}') == {"a": "b"}
    assert load_json(None, '{"a": 1}') == {"a": 1}
    assert load_json(None, '{"a": [1, 2]}') == {"a": [1, 2]}
    assert load_json(None, '{"a": {"b": "c"}}') == {"a": {"b": "c"}}
    assert load_json(None, '{"a": {"b": [1, 2]}}') == {"a": {"b": [1, 2]}}
    assert load_json(None, '{"a": [{"b": 1}, {"b": 2}]}') == \
        {"a": [{"b": 1}, {"b": 2}]}


# Generated at 2022-06-23 18:56:27.686762
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    f1 = process_data_embed_file_contents_arg(
        KeyValueArg(KeyValueArg.from_str("test").key, KeyValueArg.from_str("test").value, KeyValueArg.from_str("test").sep))
    f2 = process_data_embed_file_contents_arg(
        KeyValueArg(KeyValueArg.from_str("test").key, "data_embed_file_contents_arg.py", KeyValueArg.from_str("test").sep))
    assert f1 == "test"
    assert f2 == open('data_embed_file_contents_arg.py', 'r').read()

# load_text_file



# Generated at 2022-06-23 18:56:30.732649
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_arg = KeyValueArg(orig='test', sep=SEPARATOR_DATA_STRING, key='test', value='test')
    assert process_data_item_arg(test_arg) == 'test'

# Generated at 2022-06-23 18:56:35.277578
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    if (process_data_item_arg("hello")=="hello"):
        print("test_process_data_item_arg pass")
    else:
        print("test_process_data_item_arg fail")


# Generated at 2022-06-23 18:56:38.838041
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('-H', 'name', 'test')
    result = process_header_arg(arg)
    assert result == 'test'


# Generated at 2022-06-23 18:56:48.276183
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_process_file_upload_arg_1()
    test_process_file_upload_arg_2()
    test_process_file_upload_arg_3()
    test_process_file_upload_arg_4()
    test_process_file_upload_arg_5()
    test_process_file_upload_arg_6()
    test_process_file_upload_arg_7()
    test_process_file_upload_arg_8()
    test_process_file_upload_arg_9()

# Generated at 2022-06-23 18:56:51.223485
# Unit test for constructor of class RequestItems
def test_RequestItems():
    #Test Request Items and Request Data
    request_items = RequestItems(True)
    b = 'new'
    request_items.data[b] = b

    assert request_items.data[b] == b


# Generated at 2022-06-23 18:56:55.592698
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(1, 'name', 'goodboy')) == 'goodboy'
    assert process_header_arg(KeyValueArg(1, 'name', '')) is None


# Generated at 2022-06-23 18:56:57.656436
# Unit test for function load_json
def test_load_json():
    load_json(KeyValueArg(key='', value='', sep=''), '{"name":"httpie"}')

# Generated at 2022-06-23 18:57:01.834171
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    header = process_empty_header_arg(KeyValueArg(key="key", orig="key;", sep=";", value=""))
    assert header == ''
    header = process_empty_header_arg(KeyValueArg(key="key", orig="key", sep=":", value=""))
    assert header == ''


# Generated at 2022-06-23 18:57:02.278772
# Unit test for constructor of class RequestItems
def test_RequestItems():
    assert not True

# Generated at 2022-06-23 18:57:09.981446
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_item_args = [KeyValueArg(
        sep=SEPARATOR_DATA_RAW_JSON,
        keyword='',
        key='a',
        value='[12,45]',
        orig='a=[12,45]')]
    request_items = RequestItems.from_args(request_item_args)
    assert request_items.data['a'] == [12, 45]

# Generated at 2022-06-23 18:57:19.281271
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = """~/Downloads/test.json|json"""
    parts = file_upload_arg.split(SEPARATOR_FILE_UPLOAD_TYPE)
    filename = parts[0]
    mime_type = parts[1] if len(parts) > 1 else None
    # return (
    #     os.path.basename(filename),
    #     f,
    #     mime_type or get_content_type(filename),
    # )
    f = open(os.path.expanduser(filename), 'rb')
    value = (
        os.path.basename(filename),
        f,
        mime_type or get_content_type(filename),
    )
    print(value)

test_process_file_upload_arg()

# Generated at 2022-06-23 18:57:29.332608
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    """Test raw json file content load"""
    # unit test data
    """
    {
      "name": "Bob",
      "age": 30,
      "cars": {
        "car1": "Ford",
        "car2": "BMW",
        "car3": "Fiat"
      }
    }
    """
    INPUT = "data-raw-json@~/data.json"
    INPUT_VALUE = "~/data.json"

    arg = KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, 'data-raw-json', INPUT_VALUE)
    result = process_data_embed_raw_json_file_arg(arg).to_json(indent=2)

# Generated at 2022-06-23 18:57:32.259258
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    test_obj = process_data_item_arg(KeyValueArg(sep=SEPARATOR_DATA_STRING, key=None, value="test_value"))
    assert test_obj== "test_value"


# Generated at 2022-06-23 18:57:35.161897
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('value', '{"a":"b"}')
    response = process_data_raw_json_embed_arg(arg)
    assert response == {"a": "b"}


# Generated at 2022-06-23 18:57:43.562434
# Unit test for function load_text_file
def test_load_text_file():
    out = 'xxx'
    out_bytes = str.encode(out)
    t = tempfile.NamedTemporaryFile('w+b')
    t.write(out_bytes)
    t.seek(0, os.SEEK_SET)
    r = load_text_file(KeyValueArg(orig='', key='', value='', sep=''))
    assert r == out
    r = load_text_file(KeyValueArg(orig='', key='', value='', sep=''))
    assert r == out
test_load_text_file()

# Generated at 2022-06-23 18:57:46.291857
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('@/home/mahmoud/test.json', '@')
    assert '{"test":"test"}' == load_text_file(item)

# Generated at 2022-06-23 18:57:49.578515
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    test_raw_json = '{"k1":"v1"}'
    test_arg = KeyValueArg('', '', '', '', test_raw_json, '', '')
    test_result = process_data_raw_json_embed_arg(test_arg)
    assert test_result == '{"k1":"v1"}'


# Generated at 2022-06-23 18:57:57.608964
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg("key", "", "Header;")
    try:
        result = process_empty_header_arg(arg)
    except ParseError:
        pass
    arg = KeyValueArg("key", "value", "Header;")
    try:
        result = process_empty_header_arg(arg)
    except ParseError:
        pass
    arg = KeyValueArg("key", "", "Header;")
    try:
        result = process_empty_header_arg(arg)
        assert result == ""
    except ParseError:
        assert False

