

# Generated at 2022-06-23 18:47:58.231730
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg('Header;', 'Header', '')
    r = process_empty_header_arg(arg)
    assert r is None
    arg2 = KeyValueArg('Header;', 'Header', 'value')
    try:
        r = process_empty_header_arg(arg2)
        assert False
    except ParseError as e:
        assert e.message == 'Invalid item "Header=value" ' \
                            '(to specify an empty header use `Header;`)'


# Generated at 2022-06-23 18:48:08.886214
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig ='', sep = SEPARATOR_DATA_RAW_JSON,
            key = '', value = '{"key1":1,"key2":"2"}')
    assert process_data_raw_json_embed_arg(arg) == {"key1":1,"key2":"2"}
    arg = KeyValueArg(orig ='', sep = SEPARATOR_DATA_RAW_JSON,
            key = '', value = '[1,2,3,4]')
    assert process_data_raw_json_embed_arg(arg) == [1,2,3,4]


# Generated at 2022-06-23 18:48:13.468225
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    data_str = '{"a": "b"}'
    data_str_dict = load_json('', data_str)
    print(data_str_dict)
    assert process_data_raw_json_embed_arg(KeyValueArg('', '', data_str)) == data_str_dict

# Generated at 2022-06-23 18:48:18.183532
# Unit test for function process_header_arg
def test_process_header_arg():
    args = ["header;bjkbjkbk", "header", "name;value"]
    request_item_args = process_args(args)
    items = RequestItems.from_args(request_item_args)
    assert items.headers['name'] == 'value'


# Generated at 2022-06-23 18:48:21.861584
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('header', 'value')) == 'value'
    assert process_header_arg(KeyValueArg('header', 'key:value')) is None


# Generated at 2022-06-23 18:48:24.359878
# Unit test for constructor of class RequestItems
def test_RequestItems():
    print(RequestItems())
    for i in range(4):
        print(RequestItems(as_form=True))



# Generated at 2022-06-23 18:48:28.939959
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    key_value_args = [KeyValueArg(key="", sep="", value="name=Jane")]
    request_items_obj = RequestItems.from_args(key_value_args)
    assert request_items_obj.params["name"] == "Jane"

# Generated at 2022-06-23 18:48:34.327213
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    args = KeyValueArg(key="name", value="", sep=SEPARATOR_HEADER_EMPTY)
    try:
        process_empty_header_arg(args)
    except ParseError:
        assert True
    args = KeyValueArg(key="name", value="", sep=SEPARATOR_HEADER)
    try:
        process_empty_header_arg(args)
    except ParseError:
        assert False


# Generated at 2022-06-23 18:48:37.130227
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(
        key='name',
        sep=SEPARATOR_HEADER,
        orig='name:jack',
        value='jack'
    )
    assert process_header_arg(arg) == 'jack'


# Generated at 2022-06-23 18:48:39.182793
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("../test/test_data/test.txt")
    load_text_file(item)

# Generated at 2022-06-23 18:48:42.681157
# Unit test for function load_json
def test_load_json():
    arg = KeyValueArg("-d", "filename", "")
    contents = "This is a test"
    result = load_json(arg, contents)
    assert result == "This is a test"

# Generated at 2022-06-23 18:48:53.793924
# Unit test for function load_json
def test_load_json():
	jsonString = """
		{
				"user" : [
				{
					"name" : "Bob",
					"age" : "19"
				},
				{
					"name" : "Cindy",
					"age" : "20"
				},
				{
					"name" : "Alice",
					"age" : "18"
				}
			]
		}
		"""

# Generated at 2022-06-23 18:49:05.028688
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    # Test case 1
    args = KeyValueArg('name', "username", '=')
    assert process_data_item_arg(args) == 'username'
    
    # Test case 2
    args = KeyValueArg('password', "123", '=')
    assert process_data_item_arg(args) == '123'

    # Test case 3
    args = KeyValueArg('gender', "female", '=')
    assert process_data_item_arg(args) == 'female'

    # Test case 4
    args = KeyValueArg('address', "HCM City", '=')
    assert process_data_item_arg(args) == 'HCM City'

    # Test case 5
    args = KeyValueArg('age', "23", '=')

# Generated at 2022-06-23 18:49:08.037895
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    req_item = [KeyValueArg("key1", SEPARATOR_DATA_STRING, "value1")]
    req_item_args = RequestItems.from_args(req_item)
    assert req_item_args.data['key1'] == "value1"

# Generated at 2022-06-23 18:49:10.205882
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(['-H', 'Header'])
    assert process_empty_header_arg(arg)

# Generated at 2022-06-23 18:49:13.175297
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_item_args = [KeyValueArg("name", "tom", SEPARATOR_DATA_STRING)]
    items = RequestItems.from_args(request_item_args)
    assert items.data["name"] == "tom"

# Generated at 2022-06-23 18:49:16.086365
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    arg = KeyValueArg(';')
    assert process_empty_header_arg(arg) == None

# Generated at 2022-06-23 18:49:22.685328
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    args = {}
    args['key'] = 'i'
    args['value'] = '1'
    args['orig'] = 'i=1'
    args['sep'] = SEPARATOR_QUERY_PARAM

    key_value_arg = KeyValueArg(**args)
    result = process_query_param_arg(key_value_arg)
    assert result == '1'



# Generated at 2022-06-23 18:49:34.167628
# Unit test for function load_json
def test_load_json():
    test_item = KeyValueArg(None, None, 'file1:=@filepath', '')
    json_str = '{"a":0}'
    res = load_json(test_item, json_str)
    assert res == {'a':0}
    assert type(res) == dict

    json_str = '[1,2,3]'
    res = load_json(test_item, json_str)
    assert res == [1,2,3]
    assert type(res) == list

    test_item = KeyValueArg(None, None, 'file1::@filepath', '')
    res = load_json(test_item, '[1,2,3]')
    assert res == [1, 2, 3]
    assert type(res) == list


# Generated at 2022-06-23 18:49:37.922021
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test normal case:
    arg = KeyValueArg(request_item='{"key": "value"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert(process_data_raw_json_embed_arg(arg) == {"key": "value"})

    # Test invalid json:
    arg = KeyValueArg(request_item='{"key": "value"', sep=SEPARATOR_DATA_RAW_JSON)
    try:
        process_data_raw_json_embed_arg(arg)
    except ParseError:
        pass
    else:
        assert(False)

# Generated at 2022-06-23 18:49:42.601307
# Unit test for constructor of class RequestItems
def test_RequestItems():
    d = {
        'header': ('header', 'header'),
        'empty_header': ('empty_header;', None),
        'query_param': ('query_param', 'query_param'),
        'file_upload': ('file_upload@file.txt', ('file.txt', f, 'text/plain')),
        'data_string': ('data_string', 'data_string'),
        'embed_file_contents': ('embed_file_contents@data.txt', 'data'),
        'raw_json': ('raw_json', {'json': 'data'}),
        'embed_raw_json_file': ('embed_raw_json_file@data.js', {'json': 'data'})
    }
    request_item_args = []
    for item, value in d.items():
        request_item

# Generated at 2022-06-23 18:49:43.848349
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(orig='-d', sep='=', key=None, value='')
    result = process_data_embed_file_contents_arg(arg)
    assert result == ''


# Generated at 2022-06-23 18:49:47.109862
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(process_data_embed_file_contents_arg('tt;~/test/test_1.txt'))


# Generated at 2022-06-23 18:49:55.240102
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Function used to test process_data_raw_json_embed_arg()
    process_data_raw_json_embed_arg(arg=KeyValueArg(orig='{"test": "123"}',
                                                    key='test',
                                                    sep='test',
                                                    value='{"test": "123"}'))

    assert 'test' == KeyValueArg(orig='{"test": "123"}',
                                 key='test',
                                 sep='test',
                                 value='{"test": "123"}').key

# Generated at 2022-06-23 18:49:59.701553
# Unit test for constructor of class RequestItems
def test_RequestItems():
    args = [KeyValueArg(
                key='t',
                value='value',
                sep=SEPARATOR_DATA_STRING
            )
    ]
    request_items = RequestItems.from_args(args)
    assert request_items.data['t'] == 'value'


test_RequestItems()

# Generated at 2022-06-23 18:50:00.335442
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    pass

# Generated at 2022-06-23 18:50:09.808166
# Unit test for function load_json
def test_load_json():
    request_items = RequestItems()

# Generated at 2022-06-23 18:50:14.900460
# Unit test for function load_json
def test_load_json():
    json_string = '{"menu": {"id": "file", "value": "File", "popup": {"menuitem": [{"value": "New", "onclick": "CreateNewDoc()"}, {"value": "Open", "onclick": "OpenDoc()"}, {"value": "Close", "onclick": "CloseDoc()"}]}}}'
    assert isinstance(load_json(None,json_string), dict)



# Generated at 2022-06-23 18:50:17.883337
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg('-H', 'Accept', 'application/json')
    assert 'Accept' == process_header_arg(arg)
    assert 'application/json' == arg.value


# Generated at 2022-06-23 18:50:27.598200
# Unit test for constructor of class RequestItems
def test_RequestItems():
    items = RequestItems()

    items.headers.update({"User-Agent": "CLI"})
    assert items.headers["User-Agent"] == "CLI"

    items.data.update({"data": "data"})
    assert items.data["data"] == "data"

    items.files.update({"files": "files"})
    assert items.files["files"] == "files"

    items.params.update({"params": "params"})
    assert items.params["params"] == "params"

    items.multipart_data.update({"multipart_data": "multipart_data"})
    assert items.multipart_data["multipart_data"] == "multipart_data"

# Testing for constructor of class RequestItems from args

# Generated at 2022-06-23 18:50:31.740151
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    key_value_arg = KeyValueArg(
        orig='key:value',
        sep=':',
        key='key',
        value='value')
    assert process_data_raw_json_embed_arg(key_value_arg) == "value"



# Generated at 2022-06-23 18:50:36.849552
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    obj = {"a" : 1, "b" : 2}
    output = process_data_embed_raw_json_file_arg(
        KeyValueArg(
            key = "obj",
            sep = "@@@",
            value = "D:\\users\\zhao5\\httpie\\tests\\test_data\\test1.json"
        )
    )
    assert obj == output

# Generated at 2022-06-23 18:50:40.669692
# Unit test for constructor of class RequestItems
def test_RequestItems():
        ri = RequestItems()
        print(ri.headers)
        print(ri.data)
        print(ri.params)
        print(ri.multipart_data)


if __name__ == '__main__':
    test_RequestItems();

# Generated at 2022-06-23 18:50:47.812933
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    file_name = "../test-data/test.json"
    json_data = process_data_embed_raw_json_file_arg(KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, "", file_name))
    print(json_data)

test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-23 18:50:51.735000
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER, 'a', 'b')) == 'b'
    assert process_header_arg(KeyValueArg(SEPARATOR_HEADER, 'a', None)) == None


# Generated at 2022-06-23 18:50:59.531382
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Test for args as form
    request_item_args = [KeyValueArg('Content-Type', 'utf-8', ':', ';')]
    request_items = RequestItems.from_args(request_item_args, as_form=True)
    assert request_items.headers['Content-Type'] == 'utf-8'
    assert isinstance(request_items.data, RequestDataDict)
    assert isinstance(request_items.params, RequestQueryParamsDict)
    assert isinstance(request_items.multipart_data, MultipartRequestDataDict)
    assert isinstance(request_items.files, RequestFilesDict)

    # Test for args not as form
    request_item_args2 = [KeyValueArg('Content-Type', 'utf-8', ':', ';')]
    request

# Generated at 2022-06-23 18:51:02.676646
# Unit test for function process_header_arg
def test_process_header_arg():
    result = process_header_arg(KeyValueArg('Content-Type','application/json'))
    assert result=='application/json'
    

# Generated at 2022-06-23 18:51:12.483361
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    pdraf = process_data_embed_raw_json_file_arg
    assert pdraf(KeyValueArg(arg="--data-raw-json-file=test.json", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, key="--data-raw-json-file", value="test.json")) == {"msg": "Hello World"}
    assert pdraf(KeyValueArg(arg="--data-raw-json-file=@test.json", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, key="--data-raw-json-file", value="@test.json")) == {"msg": "Hello World"}

# Generated at 2022-06-23 18:51:25.017489
# Unit test for function load_json
def test_load_json():
    # Test case 1
    arg = KeyValueArg('-f', 'user:demo', SEPARATOR_DATA_RAW_JSON)
    try:
        load_json(arg, '{"user":"demo"}')
    except ValueError:
        assert(False)
    try:
        load_json(arg, '{user:demo}')
    except ValueError:
        assert(True)

    # Test case 2
    arg = KeyValueArg('-f', 'user:demo', SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    try:
        load_json(arg, '{"user":"demo"}')
    except ValueError:
        assert(False)
    try:
        load_json(arg, '{user:demo}')
    except ValueError:
        assert(True)

# Generated at 2022-06-23 18:51:36.323862
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_data = [
        ('test.txt',)
    ]
    test_data_type = [
        str
    ]
    test_arg_data = []
    test_arg_sep_data = []
    for i in range(len(test_data)):
        test_arg_data.append(test_data[i][0])
        test_arg_sep_data.append(SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg_data_iter = zip(test_arg_data, test_arg_sep_data)
    key_value_arg_data = []
    result_data = [
        None
    ]

# Generated at 2022-06-23 18:51:40.773037
# Unit test for function process_header_arg
def test_process_header_arg():
    assert process_header_arg(KeyValueArg('H', 'x', 'H=x')) == 'x'
    assert process_header_arg(KeyValueArg('H', '', 'H')) is None
    assert process_header_arg(KeyValueArg('H', '', 'H=')) == ''


# Generated at 2022-06-23 18:51:44.514911
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args = ["C:/Users/vijay/Desktop/messages.txt", "text/plain"]
    request_item_args = [KeyValueArg('upload;', ';'.join(args))]
    instance = RequestItems.from_args(request_item_args, as_form=False)
    assert instance.files[args[0]] == ('messages.txt', open(args[0], 'rb'), args[1])


# Generated at 2022-06-23 18:51:57.588600
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    fd, data_json = tempfile.mkstemp()
    with open(data_json, 'w') as tmp:
        tmp.write("""{
    "tags": [
        "test_tag_1",
        "test_tag_2"
    ],
    "description": "test_description",
    "name": "test_name",
    "variables": [
        {
            "value": "test_value",
            "key": "test_key"
        }
    ]
}""")
    os.close(fd)

    r = process_data_embed_raw_json_file_arg(KeyValueArg('-d', f"@{data_json}"))
    print(r)
    # repr(r)
    # eval(repr(r))
    assert repr(r) == repr

# Generated at 2022-06-23 18:52:00.236503
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    key_value_arg = KeyValueArg('a=@test')
    assert process_data_embed_file_contents_arg(key_value_arg) == 'test content'

# Generated at 2022-06-23 18:52:09.439333
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    json_data = """
    {
        "b": 100,
        "a": 1,
        "c.d": 300,
        "c": {
            "d": 300
        }
    }
    """
    key = "key"
    origin_value = "data_raw_json"
    key_value_arg = KeyValueArg(key, SEPARATOR_DATA_RAW_JSON, origin_value, json_data)
    value = process_data_raw_json_embed_arg(key_value_arg)
    assert value == {"b":100, "a":1, "c.d":300, "c": { "d": 300}}


# Generated at 2022-06-23 18:52:11.876516
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    result = process_data_item_arg(KeyValueArg(key=None, value='6', sep=SEPARATOR_DATA_STRING))
    assert(result == '6')

# Generated at 2022-06-23 18:52:14.299672
# Unit test for constructor of class RequestItems
def test_RequestItems():
    request_items = RequestItems()
    assert request_items.headers == {}
    assert request_items.data == {}
    assert request_items.files == {}
    assert request_items.params == {}

# Generated at 2022-06-23 18:52:16.263150
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data = process_data_item_arg('foo=bar')
    print(data)

test_process_data_item_arg()

# Generated at 2022-06-23 18:52:21.324836
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test.txt'
    f = open(os.path.expanduser(filename), 'rb')
    mime_type = get_content_type(filename)
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "filename", filename)
    assert process_file_upload_arg(arg) == (os.path.basename(filename), f, mime_type)


# Generated at 2022-06-23 18:52:25.221183
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data = RequestDataDict()
    requestItems = RequestItems()
    requestItem = KeyValueArg(SEPARATOR_DATA_STRING, 'key:value')
    result = process_data_item_arg(requestItem)
    assert result == 'value'

# Generated at 2022-06-23 18:52:30.653095
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg(orig = '--body-data-file-contents', key = '', sep = '=', value = 'test.txt')
    contents = '{"key":"value"}'
    with open('test.txt', 'w') as f:
        f.write(contents)
    assert process_data_embed_file_contents_arg(arg) == contents
    os.remove('test.txt')


# Generated at 2022-06-23 18:52:32.253882
# Unit test for constructor of class RequestItems
def test_RequestItems():
    t = RequestItems(False)
    assert isinstance(t, RequestItems)


# Generated at 2022-06-23 18:52:40.928395
# Unit test for constructor of class RequestItems

# Generated at 2022-06-23 18:52:50.790714
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-23 18:52:58.200856
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    headers = RequestHeadersDict()
    arg = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key="Key1", value="Value1")
    try:
        value = process_empty_header_arg(arg)
    except ParseError as e:
        assert(str(e) == 'Invalid item "Key1:Value1" (to specify an empty header use `Header;`)')
    else:
        assert(False)
    headers["Key1"] = "Value1"
    arg = KeyValueArg(sep=SEPARATOR_HEADER_EMPTY, key="Key1", value="")
    value = process_empty_header_arg(arg)
    assert(value == "")

# Generated at 2022-06-23 18:53:01.416950
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key=None, sep="=", value="name=test", orig="name=test")
    process_data_item_arg(arg) == "test"


# Generated at 2022-06-23 18:53:08.338163
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    class FakeKeyValueArg:
        def __init__(self):
            pass
    
    arg = FakeKeyValueArg()
    arg.orig = "XXX"
    arg.value = "{\"a\": 1, \"b\": 2}"
    process_rst = process_data_embed_raw_json_file_arg(arg)
    assert process_rst == {"a": 1, "b": 2}
    assert process_rst["b"] == 2


# Generated at 2022-06-23 18:53:12.080671
# Unit test for function load_json
def test_load_json():
    test_arg = KeyValueArg(data='a',orig='file.json', sep='=', value='"test_file.json"')
    test_content = '{"a": "test"}'
    assert load_json(test_arg,test_content) == {"a":"test"}

# Generated at 2022-06-23 18:53:17.749304
# Unit test for function load_json
def test_load_json():
    content = '{"a": 1, "b": "abc"}'
    value = load_json(KeyValueArg('data; %s' % content),
                      content)
    assert value["a"] == 1
    assert value["b"] == "abc"
    content = '{"a": 1, "b": {"c": "2", "d": "3"}'
    with pytest.raises(ParseError):
        load_json(KeyValueArg('data; %s' % content),
                  content)

# Generated at 2022-06-23 18:53:28.070755
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    kv_list: List[KeyValueArg] = []
    kv_list.append(KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='first_name',
        value='~/Documents/dir_for_httpie/first_name.json',
    ))
    kv_list.append(KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='last_name',
        value='~/Documents/dir_for_httpie/last_name.json',
    ))
    request_items = RequestItems.from_args(kv_list)
    assert request_items.data['first_name'] == 'John'
    assert request_items.data['last_name'] == 'Doe'

# Generated at 2022-06-23 18:53:35.778684
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    from httpie.cli import KeyValueArg
    from httpie.compat import str
    from types import ModuleType
    from unittest import TestCase

    from httpie.cli import RequestItems
    class test_RequestItems(TestCase):
        def test_process_empty_header_arg(self):
            m = ModuleType('m')
            m.__file__ = '/a/b/test_process_empty_header_arg.py'
            setattr(m, 'test_process_empty_header_arg', test_process_empty_header_arg)
            k1 = KeyValueArg("X-Test-Header1;", "value1")
            k2 = KeyValueArg("X-Test-Header2;", "value2")
            k3 = KeyValueArg("X-Test-Header3;", "")
            k4

# Generated at 2022-06-23 18:53:37.252410
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    args = KeyValueArg('User-Agent;')
    assert process_empty_header_arg(args) == ''

# Generated at 2022-06-23 18:53:39.049868
# Unit test for function process_query_param_arg
def test_process_query_param_arg():
    assert process_query_param_arg(KeyValueArg(0, SEPARATOR_QUERY_PARAM,
                                               "name", "value")) == "value"

# Generated at 2022-06-23 18:53:42.121992
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    key_value_arg = {'key': 'arg1'}
    json_type = [1, 2, 3]
    assert process_data_embed_raw_json_file_arg(key_value_arg) == json_type

# Generated at 2022-06-23 18:53:54.537345
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    path = 'test/test_files/test_files_with_content'
    path0 = 'test_files0.json'
    path1 = 'test_files1.json'
    path2 = 'test_files2.json'
    path3 = 'test_files3.json'
    path4 = 'test_files4.json'
    path5 = 'test_files5.json'
    arg_test_files0 = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value=path0,
        orig=path0
    )

# Generated at 2022-06-23 18:53:59.613885
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    example = {'_test':'data', 'test_array':[{'x':1, 'y':2}, {'x':3, 'y':4}]}
    path = 'test.json'
    with open(path, 'w') as f:
        json.dump(example, f, indent=4)
    arg = KeyValueArg(key='test', value=path, sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == example
    os.remove(path)

# Generated at 2022-06-23 18:54:06.100684
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg("--data", "[1, 2, 3]")) == [1, 2, 3]
    assert process_data_raw_json_embed_arg(KeyValueArg("--data", "foo")) == "foo"
    assert process_data_raw_json_embed_arg(KeyValueArg("--data", "false")) is False
    assert process_data_raw_json_embed_arg(KeyValueArg("--data", "null")) is None
    assert process_data_raw_json_embed_arg(KeyValueArg("--data", "{\"foo\": \"bar\"}")) == {"foo": "bar"}

# Generated at 2022-06-23 18:54:12.389875
# Unit test for constructor of class RequestItems
def test_RequestItems():
    # Test for simple request with no data and no files
    requestItems = RequestItems.from_args([KeyValueArg(
        "Accept", "application/json", ":")])
    assert isinstance(requestItems.headers, RequestHeadersDict)
    assert isinstance(requestItems.data, RequestJSONDataDict)
    assert requestItems.data == {}
    assert isinstance(requestItems.files, RequestFilesDict)
    assert requestItems.files == {}
    assert isinstance(requestItems.params, RequestQueryParamsDict)
    assert requestItems.params == {}
    assert isinstance(requestItems.multipart_data, MultipartRequestDataDict)
    assert requestItems.multipart_data == {}

    # Test for request sending file as data

# Generated at 2022-06-23 18:54:14.659678
# Unit test for function process_header_arg
def test_process_header_arg():
    test_arg = [KeyValueArg("header", "value", ":")]
    test_case = RequestItems.from_args(test_arg)
    keys = list(test_case.headers.keys())
    values = list(test_case.headers.values())
    assert test_case.headers[keys[0]] == values[0]


# Generated at 2022-06-23 18:54:16.975508
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg=KeyValueArg()
    arg.value="hskdghskd"
    arg.key="fbgnhj"
    assert process_data_item_arg(arg)=="hskdghskd"

# Generated at 2022-06-23 18:54:19.121908
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg('a', 'b', 'a:b')
    assert process_data_embed_raw_json_file_arg(item) == item.value

# Generated at 2022-06-23 18:54:22.765815
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg("test_key", "test_value", "test_sep")
    assert process_data_embed_raw_json_file_arg(test_arg) == {"test_key": "test_value"}

# Generated at 2022-06-23 18:54:30.611241
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    input1 = "name=liuyang"
    input2 = "password=liuyang123"
    arg = argparse.Namespace()
    arg.sep = SEPARATOR_DATA_STRING
    arg.key = "name"
    arg.value = "liuyang"
    arg.orig = input1
    assert process_data_item_arg(arg) == "liuyang"
    arg.key = "password"
    arg.value = "liuyang123"
    arg.orig = input2
    assert process_data_item_arg(arg) == "liuyang123"


# Generated at 2022-06-23 18:54:36.161613
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    print("test_process_data_embed_raw_json_file_arg()")
    key = "data"
    value = "book"
    message = json.dumps({key: value})
    arg = KeyValueArg(key, message, "=")
    assert(process_data_embed_raw_json_file_arg(arg) == {key:value})
    print("End of test_process_data_embed_raw_json_file_arg()\n")



# Generated at 2022-06-23 18:54:41.713166
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    test_arg = KeyValueArg('test_data', 'test', 'test_data_embed_file_contents_arg')
    x = process_data_embed_file_contents_arg(test_arg)
    assert x == "test_data_embed_file_contents_arg"


# Generated at 2022-06-23 18:54:44.770070
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('key', '{ "name": "value" }', '', '')
    assert process_data_raw_json_embed_arg(arg) == { "name": "value" }



# Generated at 2022-06-23 18:54:49.780389
# Unit test for function load_json
def test_load_json():
    test_value = '{ "key": "value" }'
    test_value_invalid = "{ 'key': 'value' }"
    print(load_json('',test_value))
    print(load_json('test',test_value_invalid))

if __name__ == '__main__':
    test_load_json()

# Generated at 2022-06-23 18:55:02.234479
# Unit test for function load_text_file
def test_load_text_file():
    from_str = load_text_file(KeyValueArg(SEPARATOR_DATA_STRING, "key", "value"))
    from_file = load_text_file(KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, "key", "./test_files/data_string"))
    from_rawjson = load_text_file(KeyValueArg(SEPARATOR_DATA_RAW_JSON, "key", "./test_files/data_string"))
    from_rawjsonfile = load_text_file(KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, "key", "./test_files/data_string"))

    assert from_str == "value"
    assert from_file == "value\n"
    assert from_rawjson == "value\n"

# Generated at 2022-06-23 18:55:08.674364
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Arrange
    input = {'name': 'Alice', 'age': 20}
    expected = {'name': 'Alice', 'age': 20}

    # Act
    output = process_data_embed_raw_json_file_arg(KeyValueArg(key='name', sep=':', value='name: age', orig=':'))

    # Assert
    assert expected == output



# Generated at 2022-06-23 18:55:12.345311
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file('/unknown')
    except Exception as e:
        assert(e)
    content = load_text_file('./test_load_text_file.py')
    assert(content)


# Generated at 2022-06-23 18:55:16.785639
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    arg = KeyValueArg.objects.create(sep = '@@', key = 'raw', value = 'test.txt')
    assert process_data_embed_file_contents_arg(arg) == 'abc\n'


# Generated at 2022-06-23 18:55:25.799568
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_json = '''[
    {
        "id": 1,
        "username": "admin1",
        "password": "password"
    },
    {
        "id": 2,
        "username": "admin2",
        "password": "password"
    },
    {
        "id": 3,
        "username": "admin3",
        "password": "password"
    }
]'''
    key = "test"
    arg = KeyValueArg(key, test_json, "")
    ret = process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-23 18:55:30.745554
# Unit test for function load_json
def test_load_json():
    json_data = {
        'key': 'value',
        'key2': 'value2'
    }

    arg = KeyValueArg(key='x', value=json_data)
    args = process_data_raw_json_embed_arg(arg)
    assert arg.value == json_data
    assert arg.orig == 'x:key:value,key2:value2'

# Generated at 2022-06-23 18:55:41.128089
# Unit test for function load_json
def test_load_json():
    #print (load_json(arg=1,contents="[1,2,3]"))
    print (load_json(arg=1,contents="{\"a\":\"b\"}"))
    print (load_json(arg=1,contents="{\"a\":\"b\",\"c\":\"d\"}"))
    print (load_json(arg=1,contents='{"a":"b","c":"d"}'))
    print (load_json(arg=1,contents='{"a":"b","c":"d","e":"f"}'))
    print (load_json(arg=1,contents='{"a":"b","c":{"d":"e","f":"g"}}'))

test_load_json()

# Generated at 2022-06-23 18:55:45.711509
# Unit test for function process_header_arg
def test_process_header_arg():
    value = process_header_arg(KeyValueArg(key='name',value='myname'))
    assert value == 'myname'
    value = process_header_arg(KeyValueArg(key='name',value=''))
    assert value is None


# Generated at 2022-06-23 18:55:54.786101
# Unit test for function load_text_file
def test_load_text_file():

    # Test when item is not a text file
    path = '/Users/yiqianduan/Desktop/http-prompt/tests/assets/audio.mp3'
    item = KeyValueArg('file_name', SEPARATOR_FILE_UPLOAD, path)
    try:
        load_text_file(item)
    except ParseError as e:
        assert (e.args[0] == '"file_name=@/Users/yiqianduan/Desktop/http-prompt/tests/assets/audio.mp3": cannot embed the content of "/Users/yiqianduan/Desktop/http-prompt/tests/assets/audio.mp3", not a UTF8 or ASCII-encoded text file')

    # Test when file does not exist

# Generated at 2022-06-23 18:55:56.766966
# Unit test for function process_header_arg
def test_process_header_arg():
    h = {'content-type':'text/html'}
    header = process_header_arg(h)
    assert header == h


# Generated at 2022-06-23 18:56:09.195026
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-23 18:56:13.106670
# Unit test for function process_header_arg
def test_process_header_arg():
    arg = KeyValueArg(sep=SEPARATOR_HEADER, key=SEPARATOR_HEADER, value='10')
    result = process_header_arg(arg)
    assert result == '10'


# Generated at 2022-06-23 18:56:14.837694
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    arg = KeyValueArg(key="foo", sep=":", value="bar")
    assert process_data_item_arg(arg) == "bar"


# Generated at 2022-06-23 18:56:17.251327
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    assert process_data_raw_json_embed_arg(KeyValueArg('a', '{"a":"b"}')) == {"a":"b"}
    

# Generated at 2022-06-23 18:56:24.447379
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestDataDict
    
    arg = KeyValueArg('key=@data.txt', 'key', 'data.txt', '@')
    target_dict = RequestDataDict()
    value = process_data_embed_file_contents_arg(arg)
    target_dict[arg.key] = value
    assert target_dict['key'] == "Testing for FILE CONTENTS"



# Generated at 2022-06-23 18:56:34.376986
# Unit test for function load_json
def test_load_json():
    assert load_json(type(KeyValueArg()), '{"a":1}') == {"a":1}
    assert load_json(type(KeyValueArg()), "{'a':1}") == {"a":1}
    assert load_json(type(KeyValueArg()), '{"a":1, "b":true}') == {"a":1, "b":True}
    assert load_json(type(KeyValueArg()), '{"a":1, "b":false}') == {"a":1, "b":False}
    assert load_json(type(KeyValueArg()), '{"a":1, "b":{"c":3, "d":4}}') == {"a":1,"b":{"c":3, "d":4}}

# Generated at 2022-06-23 18:56:42.371177
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    from httpie.input import KeyValue

    k = KeyValue(orig='{"url": "http://httpie.org"}', key=None, sep=':', value='{"url": "http://httpie.org"}')
    print(process_data_raw_json_embed_arg(k))  # {'url': 'http://httpie.org'}

    j = KeyValue(orig=':{"url": "http://httpie.org"}', key=None, sep=':', value='{"url": "http://httpie.org"}')
    print(process_data_raw_json_embed_arg(j))  # {}

# Generated at 2022-06-23 18:56:47.975347
# Unit test for function process_data_item_arg
def test_process_data_item_arg():
    data_item_arg = KeyValueArg(key='data_item_arg', value='data_value', sep=SEPARATOR_DATA_STRING)
    data_item_result = process_data_item_arg(data_item_arg)
    print(data_item_result)
    assert data_item_result == 'data_value'


# Generated at 2022-06-23 18:56:51.869755
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    import httpie.cli.argtypes as argtypes
    key_value_arg = argtypes.KeyValueArg(orig="test.txt", sep=":", key="test.txt", value="test.txt")
    assert 'test' == process_data_embed_file_contents_arg(key_value_arg)



# Generated at 2022-06-23 18:57:01.834991
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    request_item = KeyValueArg(orig="@C:\\Users\\H168366\\PycharmProjects\\httpie-httpbin-ng\\httpbin\\tests\\fixtures\\cookies.json", sep="@", key="@C:\\Users\\H168366\\PycharmProjects\\httpie-httpbin-ng\\httpbin\\tests\\fixtures\\cookies.json", value="C:\\Users\\H168366\\PycharmProjects\\httpie-httpbin-ng\\httpbin\\tests\\fixtures\\cookies.json")
    content = process_data_embed_file_contents_arg(request_item)
    assert content != None


# Generated at 2022-06-23 18:57:14.223680
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg('/path', 'type=text/html')
    file_upload_arg.sep = SEPARATOR_FILE_UPLOAD

    from httpie.cli.constants import SEPARATOR_FILE_UPLOAD_TYPE
    parts = '/path'.split(SEPARATOR_FILE_UPLOAD_TYPE)
    filename = parts[0]
    mime_type = parts[1] if len(parts) > 1 else None
    try:
        f = open(os.path.expanduser(filename), 'rb')
    except IOError as e:
        raise ParseError('"%s": %s' % (file_upload_arg.orig, e))

# Generated at 2022-06-23 18:57:16.294575
# Unit test for function load_json
def test_load_json():
    assert load_json_preserve_order('{"hello": "world"}') == {'hello': 'world'}

# Generated at 2022-06-23 18:57:25.428186
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    # test_no_value_not_allowed
    with pytest.raises(ParseError):
        process_empty_header_arg(
            KeyValueArg(
                SEPARATOR_HEADER_EMPTY,
                'Header', 'Value',
                KeyValueArg.Type.HEADER,
            )
        )
    # test_no_value_allowed
    assert process_empty_header_arg(
        KeyValueArg(
            SEPARATOR_HEADER_EMPTY,
            'Header', '',
            KeyValueArg.Type.HEADER,
        )
    ) is None

# Generated at 2022-06-23 18:57:33.718185
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-23 18:57:42.917589
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    # Tests that the correct file path is returned and that the function exits as expected
    class KeyValueArg:
        def __init__(self, value):
            self.value = value
            self.orig = value
    assert process_data_embed_file_contents_arg(KeyValueArg("/dir/file.txt")) == \
        "This is a test"
    assert process_data_embed_file_contents_arg(KeyValueArg("/dir/test_test.txt")) == \
        "This is a test with a space"
    assert process_data_embed_file_contents_arg(KeyValueArg("/dir/test.json")) == \
        '{"id": 1, "name": "A green door", "price": 12.50, "tags": ["home", "green"]}'
    assert process_data_embed

# Generated at 2022-06-23 18:57:45.057495
# Unit test for function process_data_embed_file_contents_arg
def test_process_data_embed_file_contents_arg():
    assert process_data_embed_file_contents_arg("test.py", "abc") == abc

# Generated at 2022-06-23 18:57:49.068892
# Unit test for function process_empty_header_arg
def test_process_empty_header_arg():
    assert process_empty_header_arg(KeyValueArg('Header', '')) == ''
    try:
        process_empty_header_arg(KeyValueArg('Header', 'test'))
        assert False
    except ParseError as e:
        assert True
    try:
        process_empty_header_arg(KeyValueArg('Header', True))
        assert False
    except ParseError as e:
        assert True

# Generated at 2022-06-23 18:57:55.004576
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Create args
    arg = argparse.Namespace()
    arg.key = 'test_file'
    arg.sep = ':='