

# Generated at 2022-06-25 18:05:21.151702
# Unit test for function load_text_file
def test_load_text_file():
    """
    Test function load_text_file
    """
    item = KeyValueArg(
        'name',
        'Jane Doe',
        SEPARATOR_FILE_UPLOAD,
        'name=Jane+Doe',
    )
    assert load_text_file(item) == 'Jane Doe'

# Generated at 2022-06-25 18:05:23.659145
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test only one file
    request_items_0 = RequestItems()
    assert process_data_raw_json_embed_arg(KeyValueArg(SEPARATOR_DATA_RAW_JSON, 'a', '{"b":"c"}')) == {'b': 'c'}

# Generated at 2022-06-25 18:05:34.744309
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    KeyValueArg.counter = 0
    test_arg = KeyValueArg('--data', '@testdata.txt', SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    actual_data = process_data_embed_raw_json_file_arg(test_arg)

# Generated at 2022-06-25 18:05:43.073036
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Process file-upload with no mime type specified
    file_upload_no_mime_type_arg = KeyValueArg('mime_type', SEPARATOR_FILE_UPLOAD, 'file.txt')
    assert process_file_upload_arg(file_upload_no_mime_type_arg) == ('file.txt', open('file.txt', 'rb'), 'text/plain')
    # Process file-upload with mime type specified
    file_upload_mime_type_arg = KeyValueArg('mime_type', SEPARATOR_FILE_UPLOAD, 'file.txt'
                                                                                + SEPARATOR_FILE_UPLOAD_TYPE
                                                                                + 'text/html')

# Generated at 2022-06-25 18:05:44.396566
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    process_data_raw_json_embed_arg(KeyValueArg('arg', '{}'))


# Generated at 2022-06-25 18:05:48.975437
# Unit test for function load_text_file
def test_load_text_file():
    filename = "load_text_file_test.txt"
    text_file = open(filename, "w")
    text = "This is a text file."
    text_file.write(text)
    text_file.close()
    check = load_text_file(KeyValueArg("name", "load_text_file_test.txt", ";"))
    os.remove("load_text_file_test.txt")
    assert check == text

# Generated at 2022-06-25 18:05:57.092541
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test case 0
    arg0 = KeyValueArg(
        sep=SEPARATOR_DATA_RAW_JSON,
        key='order_id',
        value='{"order_id": 100, "products": ["Candy"]}',
    )
    expected_value_0 = {"order_id": 100, "products": ["Candy"]}
    actual_value_0 = process_data_raw_json_embed_arg(arg0)
    assert actual_value_0 == expected_value_0
    # Test case 1
    arg1 = KeyValueArg(
        sep=SEPARATOR_DATA_RAW_JSON,
        key='order_id',
        value='{"products": ["Candy", "Chips"], "ber": "fsrfe3r"}',
    )

# Generated at 2022-06-25 18:06:02.500095
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    request_items = RequestItems()
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, 'file.txt', None)
    process_file_upload_arg(arg)

# Generated at 2022-06-25 18:06:12.010271
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = os.path.expanduser("./tests/fixtures/httpbin/ip.json")
    arg_filename = KeyValueArg('file', filename)
    arg_filename.sep = SEPARATOR_FILE_UPLOAD
    arg_filename.orig = arg_filename.key + '=' + filename

    arg_filename_type = KeyValueArg('file', filename + SEPARATOR_FILE_UPLOAD_TYPE + 'text/plain')
    arg_filename_type.sep = SEPARATOR_FILE_UPLOAD
    arg_filename_type.orig = arg_filename_type.key + '=' + filename + SEPARATOR_FILE_UPLOAD_TYPE + 'text/plain'

    expected_output_filename = (os.path.basename(filename), open(filename, 'rb'), None)
    expected_

# Generated at 2022-06-25 18:06:21.478030
# Unit test for function load_text_file
def test_load_text_file():
    with open("/home/khoi/turner_project/data/7027031.json", "rb") as f:
        assert f.read().decode() == load_text_file(KeyValueArg(orig="/home/khoi/turner_project/data/7027031.json", sep="=", key="/home/khoi/turner_project/data/7027031.json", value="/home/khoi/turner_project/data/7027031.json"))

if __name__ == '__main__':
    test_case_0()
    test_load_text_file()

# Generated at 2022-06-25 18:06:42.645237
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Case 1: Input is {'foo': 'bar'}, expected input is {'foo': 'bar'}
    arg = KeyValueArg('foo', SEPARATOR_DATA_RAW_JSON, '{"foo": "bar"}')
    result = process_data_raw_json_embed_arg(arg)
    expected = {'foo': 'bar'}
    assert result == expected

    # Case 2: Input is '[1, 2, 3]', expected input is [1, 2, 3]
    arg = KeyValueArg('foo', SEPARATOR_DATA_RAW_JSON, '[1, 2, 3]')
    result = process_data_raw_json_embed_arg(arg)
    expected = [1, 2, 3]
    assert result == expected

    # Case 3: Input is '"test"', expected input is "test"


# Generated at 2022-06-25 18:06:46.854134
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    a = process_data_embed_raw_json_file_arg(arg=KeyValueArg(orig='./data.json', sep='=@', key=None, value="./data.json"))
    assert a is not None

# Generated at 2022-06-25 18:06:53.748680
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_name = "test.txt"
    f = open(os.path.expanduser(file_name), 'rb')
    test_file_item = KeyValueArg(";", file_name, file_name)
    file_upload_arg = process_file_upload_arg(test_file_item)
    assert (file_name, f, get_content_type(file_name)) == file_upload_arg


# Generated at 2022-06-25 18:06:57.203415
# Unit test for function load_text_file
def test_load_text_file():
    path = "/home/usr/file.txt"
    with open(os.path.expanduser(path), 'rb') as f:
        return f.read().decode()


# Generated at 2022-06-25 18:06:58.798234
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'data')) == 'data'

# Generated at 2022-06-25 18:07:08.054937
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg("--data", "", "data")
    value = process_data_raw_json_embed_arg(item)
    assert value == {}

    item = KeyValueArg("--data", "b", "data")
    value = process_data_raw_json_embed_arg(item)
    assert value == "b"

    item = KeyValueArg("--data", "a", "data")
    value = process_data_raw_json_embed_arg(item)
    assert value == "a"

    item = KeyValueArg("--data", "true", "data")
    value = process_data_raw_json_embed_arg(item)
    assert value == "true"

    item = KeyValueArg("--data", "false", "data")
    value = process_data_raw_json_embed_

# Generated at 2022-06-25 18:07:12.480373
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    request_items_1 = RequestItems()
    process_file_upload_arg_0 = process_file_upload_arg(KeyValueArg(key='httpie', sep='@', value='test_value_1'))


# Generated at 2022-06-25 18:07:16.994914
# Unit test for function load_text_file
def test_load_text_file():
    path = "./data/test_case.json"
    new_item = KeyValueArg("test",path)
    result = load_text_file(new_item)
    assert result == '{"a": 1, "b": 2, "c": 3}\n'


# Generated at 2022-06-25 18:07:23.193781
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    file_path = "file_path.txt"
    sample_input = "H@TTPie;:(file-uploads=\"./requests.py\",)"
    sample_input2 = "H@TTPie;:(file-uploads=\"./requests.py\",./abc.py,)"
    actual_result = process_data_embed_raw_json_file_arg(file_path, sample_input)
    expected_result = process_data_embed_raw_json_file_arg(file_path, sample_input2)

    assert actual_result == expected_result


# Generated at 2022-06-25 18:07:26.914369
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_arg = KeyValueArg(key='a', value='a.txt')
    process_file_upload_arg(file_arg)
    assert len(request_items_0.files) == 1

# Generated at 2022-06-25 18:07:36.150717
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file("test.txt") == "this is a test"


# Generated at 2022-06-25 18:07:44.314817
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_items_0 = RequestItems()
    arg = KeyValueArg(
        'request_item',
        'form-data',
        'request_item.json',
        None,
        None,
        'form-data',
        'request_item.json',
        'form-data:request_item.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {"test": "111"}


# Generated at 2022-06-25 18:07:46.817417
# Unit test for function load_text_file
def test_load_text_file():
    request_items = RequestItems()
    request_items.data = {'a': 'b'}
    assert request_items.data == {'a': 'b'}

# Generated at 2022-06-25 18:07:52.772749
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg: KeyValueArg = KeyValueArg(
        "data_embed_raw_json_file",
        'name;@tests/fixtures/json_with_comments.json',
        'data_embed_raw_json_file',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "field1": "value1",
        "field2": "value2",
    }



# Generated at 2022-06-25 18:07:57.024499
# Unit test for function load_text_file
def test_load_text_file():
    path = 'C:\\Users\\t-sjwong\\Documents\\httpie-test\\test.txt'
    path = os.path.expanduser(path)
    item = KeyValueArg(None, 'href', path)
    assert load_text_file(item) == 'https://www.hongkongairport.com/'


if __name__ == "__main__":
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 18:07:59.342697
# Unit test for function load_text_file
def test_load_text_file():
    result = load_text_file("sample.txt")
    expected_result = "this is sample text"
    assert result == expected_result


# Generated at 2022-06-25 18:08:04.595634
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_items_0 = RequestItems()
    json_arg = KeyValueArg(key="input", value="input.json", sep="@")
    request_items_0.data = process_data_embed_raw_json_file_arg(json_arg)


# Generated at 2022-06-25 18:08:08.690900
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg()
    arg.value = "tests/testdata/test_file"
    arg.orig = "tests/testdata/test_file"
    assert load_text_file(arg) == 'test_data'



# Generated at 2022-06-25 18:08:10.488770
# Unit test for function load_text_file
def test_load_text_file():
    load_text_file(KeyValueArg('X-Haproxy-Header', 'test'))

# Generated at 2022-06-25 18:08:14.751610
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    key = 'key'
    file_name = 'file_name.json'
    request_items = RequestItems()
    result_json = request_items.process_data_embed_raw_json_file_arg(key, file_name)
    assert result_json == load_json(key, load_text_file(key))


# Generated at 2022-06-25 18:08:32.228700
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key=None, sep=':', value='/home/haoyi/test.txt')
    print(load_text_file(item))

# Generated at 2022-06-25 18:08:40.727599
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    request_items = RequestItems.from_args([KeyValueArg(':', ':', '')])
    assert(process_file_upload_arg(KeyValueArg('--form', '@', 'test.txt:txt')) ==
           ('test.txt', open('test.txt', 'rb'), 'text/plain') or
           process_file_upload_arg(KeyValueArg('--form', '@', 'test.html:html')) ==
           ('test.html', open('test.html', 'rb'), 'text/html'))


# Generated at 2022-06-25 18:08:48.766701
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg_0 = KeyValueArg('', '', '', '', '')
    arg_0.value = 'nonexistent file.json'
    arg_0.orig = 'nonexistent file.json'
    arg_1 = KeyValueArg('', '', '', '', '')
    arg_1.value = 'data.json'
    arg_1.orig = 'data.json'
    try:
        process_data_embed_raw_json_file_arg(arg_0)
    except:
        pass
    try:
        process_data_embed_raw_json_file_arg(arg_1)
    except:
        pass



# Generated at 2022-06-25 18:08:55.914185
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    import json
    request_items_0 = RequestItems()
    arg_0 = KeyValueArg("foo;@bar/data.json", "foo", "bar/data.json")
    result_0 = load_json(arg_0, json.dumps([{"foo": "bar" }]))
    print(result_0)
    assert process_data_embed_raw_json_file_arg(arg_0) == result_0

# Generated at 2022-06-25 18:09:02.520004
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_items = RequestItems()
    assert request_items.data == {}
    #Test case for invalid input arg.value
    assert process_data_raw_json_embed_arg(KeyValueArg("", "", "")) == None
    #Test case for valid input arg.value
    rvalue = process_data_raw_json_embed_arg(KeyValueArg("Foo:",":","{}"))
    assert rvalue != None
    assert request_items.data == {"Foo": "{}"}


# Generated at 2022-06-25 18:09:12.705477
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_file_arg_1 = KeyValueArg('@data.json', '', 'json')
    data_item_1 = process_data_embed_raw_json_file_arg(json_file_arg_1)
    assert data_item_1 == {"key1": "value1", "key2": "value2"}

    json_file_arg_2 = KeyValueArg('@data_raw.json', '', 'json')
    data_item_2 = process_data_embed_raw_json_file_arg(json_file_arg_2)
    assert data_item_2 == {"key1": "value1", "key2": "value2"}

    json_file_arg_3 = KeyValueArg('@data_yaml.yml', '', 'json')
    data_item_3 = process_data_

# Generated at 2022-06-25 18:09:21.329615
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    args = ['uploadfile;type']
    request_item_args = [KeyValueArg(arg, SEPARATOR_FILE_UPLOAD) for arg in args]
    instance = RequestItems()
    rules: Dict[str, Tuple[Callable, dict]] = {
        SEPARATOR_FILE_UPLOAD: (
            process_file_upload_arg,
            instance.files,
        ),
    }

    for arg in request_item_args:
        processor_func, target_dict = rules[arg.sep]
        value = processor_func(arg)
        target_dict[arg.key] = value
    assert instance.files['uploadfile'] == ('uploadfile', None, 'type')

# Generated at 2022-06-25 18:09:24.418626
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test case 1:
    assert process_data_raw_json_embed_arg(KeyValueArg('key1','value1')) == 'value1'
    assert process_data_raw_json_embed_arg(KeyValueArg('key2','value2')) == 'value2'


# Generated at 2022-06-25 18:09:29.929954
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg('Content-Type', 'application/json', '', '')
    string = '''{'token':'test', 'email':'test@test.test'}'''
    assert process_data_raw_json_embed_arg(item) == string


# Generated at 2022-06-25 18:09:34.368893
# Unit test for function load_text_file
def test_load_text_file():
    try:
        load_text_file(KeyValueArg(sep=';', key="", value="test.txt"))
        assert False
    except ParseError as e:
        assert str(e) == '"test.txt": [Errno 2] No such file or directory: ' \
                         '\'test.txt\''


# Generated at 2022-06-25 18:10:13.066465
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_items_raw_json_embed_arg = RequestItems()
    request_items_raw_json_embed_arg.data['a'] = process_data_raw_json_embed_arg(
        KeyValueArg(
            orig="a=",
            key='a',
            sep=SEPARATOR_DATA_RAW_JSON,
            value="",
        )
    )

    assert request_items_raw_json_embed_arg.data['a'] == ""


# Generated at 2022-06-25 18:10:14.856232
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('aa=bb')
    load_text_file(item) == 'bb'

# Generated at 2022-06-25 18:10:20.985859
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():  # noqa
    # type: (None) -> [Tuple[str, IO, str]]
    kv = KeyValueArg(
        key='file',
        value='~/tmp/upload.txt',
        sep='@'
    )
    value = process_file_upload_arg(kv)
    assert isinstance(value, tuple)
    assert value[0] == 'upload.txt'
    assert value[1].read() == b'Upload text'
    assert value[2] == 'text/plain'


# Generated at 2022-06-25 18:10:23.930967
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    items = RequestItems()
    sample_arg = KeyValueArg('header', ';', 'value')
    ret_val = process_data_embed_raw_json_file_arg(sample_arg)
    assert ret_val == None


# Generated at 2022-06-25 18:10:32.299938
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    user = 'peter'
    password = '1234'
    a_dict = dict(username=user, password=password)
    a_str = json.dumps(a_dict)
    a_str_with_extra_spaces = json.dumps(a_dict).replace(' ', '  ')
    a_str_with_extra_chars = json.dumps(a_dict).replace(' ', '-')

    value = process_data_raw_json_embed_arg(KeyValueArg(SEPARATOR_DATA_RAW_JSON, '', a_str))
    assert value == a_dict

    value = process_data_raw_json_embed_arg(KeyValueArg(SEPARATOR_DATA_RAW_JSON, '', a_str_with_extra_spaces))
    assert value == a_dict



# Generated at 2022-06-25 18:10:35.366370
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_items_0 = RequestItems()
    arg_0 = KeyValueArg('H', 'key0', 'value0', 'separator0')
    print(process_data_embed_raw_json_file_arg(arg_0))



# Generated at 2022-06-25 18:10:40.401059
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        KeyValueArg.PARSED_SCHEMA,
        "data",
        "=@",
        "data.json",
        None,
        None,
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "string": "bar",
        "number": 1234,
        "boolean": False,
        "array1": [
            "foo",
            42
        ],
        "array2": [
            "foo"
        ],
        "object": {
            "foo": "bar"
        },
        "null": None,
    }


# Generated at 2022-06-25 18:10:52.980635
# Unit test for function load_text_file
def test_load_text_file():
    req_arg_1 = KeyValueArg('-d', '@test.json', SEPARATOR_DATA_EMBED_FILE_CONTENTS, '@test.json')
    req_arg_2 = KeyValueArg('-d', '@test.json', SEPARATOR_DATA_EMBED_FILE_CONTENTS, '@test.json')
    req_arg_3 = KeyValueArg('-d', '@tests/data/httpie/request-data-json.json', SEPARATOR_DATA_EMBED_FILE_CONTENTS, '@tests/data/httpie/request-data-json.json')
    assert(type(load_text_file(req_arg_1)) == str)
    assert(type(load_text_file(req_arg_2)) == str)

# Generated at 2022-06-25 18:10:57.260547
# Unit test for function load_text_file
def test_load_text_file():
    path = "C:/Users/Alex/PycharmProjects/httpie/doc/source/index.rst"
    with open(os.path.expanduser(path), 'rb') as f:
        return f.read().decode()

# Generated at 2022-06-25 18:11:03.596224
# Unit test for function load_text_file
def test_load_text_file():
    load_text_file(KeyValueArg('a', 'b'))
    # Should be an IOError
    with pytest.raises(ParseError):
        load_text_file(KeyValueArg('a', 'b'))
        # Should be a UnicodeDecodeError
        load_text_file(KeyValueArg('a', 'b'))


# Generated at 2022-06-25 18:11:40.170494
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    item = [KeyValueArg(
      key='file',
      sep='@',
      orig='@example.pdf',
      value='example.pdf'
    )]
    temp = RequestItems.from_args(item)
    assert temp.files == {'file': ('example.pdf', open('example.pdf', 'rb'), 'application/pdf')}


# Generated at 2022-06-25 18:11:46.228507
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_item_args = [KeyValueArg("data", "raw_data_0", "=", None)]
    req_json_data_dict = process_data_raw_json_embed_arg(request_item_args[0])
    assert request_item_args[0].value == "raw_data_0"
    assert req_json_data_dict == "raw_data_0"
    print("test_process_data_raw_json_embed_arg: passed")


# Generated at 2022-06-25 18:11:53.941165
# Unit test for function load_text_file
def test_load_text_file():
    # set up the test case
    parts = ["a", "b", "c"]
    with open("test.txt", "w+") as file:
        file.write("This is just a example file\n")
    with open("test.txt", "r") as file:
        expected = file.read()

    # run the function
    output = load_text_file(parts)
    assert output == expected

# run test locally
if __name__ == "__main__":
    test_case_0()
    test_load_text_file()

# Generated at 2022-06-25 18:12:03.863575
# Unit test for function load_text_file
def test_load_text_file():
    file = "c:/Users/Foo/file.txt"
    data = "This is a text file"
    arg = KeyValueArg("", "", "")
    arg.value = file
    arg.orig = file
    arg.sep = SEPARATOR_DATA_EMBED_FILE_CONTENTS

    old_open = open
    def mock_open(filename, mode, *args, **kwargs):
        class MockFile:
            def __init__(self, filename):
                self.filename = filename
                self.data = "This is a text file"

            def read(self):
                return self.data

            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc_val, exc_tb):
                pass

        return MockFile(filename)


# Generated at 2022-06-25 18:12:10.555031
# Unit test for function load_text_file
def test_load_text_file():

    item = KeyValueArg(
        key=None, value="D:\\file.txt", sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS
    )
    assert load_text_file(item) == "This file being loaded"


# Generated at 2022-06-25 18:12:13.462019
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('test', '', '{\"id\":\"test\"}')
    assert process_data_raw_json_embed_arg(arg) == load_json_preserve_order('{\"id\":\"test\"}')


# Generated at 2022-06-25 18:12:18.974218
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    assert process_data_embed_raw_json_file_arg(
        KeyValueArg(
            None,
            None,
            SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
            "test_data_embed_raw_json_file_arg.json",
            None
        )
    ) == {
        "test_key": [
            "test_value"
        ],
        "test_key_2": [
            "test_value_2"
        ]
    }

# Generated at 2022-06-25 18:12:27.048785
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_items = RequestItems()
    arg = KeyValueArg(
        'header',
        0,
        ';',
        'some_header_key',
        True,
        'some_header'
    )
    assert('some_header' == process_data_item_arg(arg))
    assert({'some_header_key': 'some_header'} == request_items.data)

    arg = KeyValueArg(
        'header',
        0,
        ';',
        'some_header_key',
        True,
        '{"some_header" : "some_header"}'
    )
    assert({"some_header" : "some_header"}== process_data_raw_json_embed_arg(arg))

# Generated at 2022-06-25 18:12:35.145800
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test case 1: Simple JSON
    arg1 = KeyValueArg(sep=':', key='data', value='1')
    actual_output1 = process_data_raw_json_embed_arg(arg1)
    expected_output1 = 1

    # Test case 2: More complex JSON
    arg2 = KeyValueArg(sep=':', key='data', value='[[1,2], [3,4]]')
    actual_output2 = process_data_raw_json_embed_arg(arg2)
    expected_output2 = [[1,2], [3,4]]

    # Test case 3: JSON with quotes (single and double)
    arg3 = KeyValueArg(sep=':', key='data', value='{"meta" : "this is a \" test"}')
    actual_output3 = process_data_raw

# Generated at 2022-06-25 18:12:38.670253
# Unit test for function load_text_file
def test_load_text_file():
    path = "./test.txt"
    item = KeyValueArg(orig="data", value=path)
    result = load_text_file(item)
    assert(result == 'this is a unit test')


# Generated at 2022-06-25 18:13:56.867516
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('--form', '=', 'test.txt', 'test_txt')
    a = process_file_upload_arg(arg)
    assert a[0] == 'test_txt'
    assert a[1] == open('test.txt', 'rb')
    assert a[2] == get_content_type('test.txt')

# Generated at 2022-06-25 18:14:03.214571
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    raw_json_embed_arg = KeyValueArg("abc","{\"foo\": [\"hello\", \"world\", 123], \"bar\": \"\"}", ":=")
    assert (process_data_raw_json_embed_arg(raw_json_embed_arg) == {"foo": ["hello", "world", 123], "bar": ""})


# Generated at 2022-06-25 18:14:07.911247
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_items_arg_0 = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_RAW_JSON,
        orig='',
        value=''
    )
    process_data_raw_json_embed_arg(request_items_arg_0)


# Generated at 2022-06-25 18:14:15.450922
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    """
    Test function process_data_embed_raw_json_file_arg
    If a json file is given, its contents are loaded
    """

    # arrange
    data_file_arg = KeyValueArg(
        key='',
        orig='@test.json',
        sep='@',
        value='test.json'
        )
    
    # act
    data_file_contents = process_data_embed_raw_json_file_arg(data_file_arg)
    print(type(data_file_contents))
    print(data_file_arg)
    print(data_file_contents)

    # assert
    assert type(data_file_contents) == dict

test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-25 18:14:20.279395
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_item_args = []
    arg = KeyValueArg(orig="@test.json", sep="=", key="", value="test.json")
    request_item_args.append(arg)
    request_items_0 = RequestItems.from_args(request_item_args)
    assert request_items_0.data == {"test": "json"}


# Generated at 2022-06-25 18:14:29.090879
# Unit test for function load_text_file
def test_load_text_file():
    key_value_arg = KeyValueArg('key', 'value')
    # Load text file from path
    path = os.path.abspath(os.path.dirname(__file__))
    key_value_arg.value = path + "/inputs/test.json"
    try:
        text = load_text_file(key_value_arg)
        assert text == '{"hello":"world"}\n'
    except ParseError:
        assert False

    # Cannot load text file with non-utf-8 or non-ascii encoding
    key_value_arg.value = os.path.abspath(__file__)
    try:
        load_text_file(key_value_arg)
        assert False
    except ParseError:
        assert True
    # Incorrect path
    key_value_

# Generated at 2022-06-25 18:14:31.892765
# Unit test for function load_text_file
def test_load_text_file():
    path = "/Users/julian/Desktop/httpie/samples/sample.txt"
    with open(os.path.expanduser(path), 'rb') as f:
            print(f.read().decode())


# Generated at 2022-06-25 18:14:35.877384
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_items_1 = RequestItems()
    item_0 = KeyValueArg(key=None, value='{"name": "Thomas" }', orig="", sep=SEPARATOR_DATA_RAW_JSON)
    request_items_1.data = process_data_raw_json_embed_arg(item_0)
    assert request_items_1.data['name'] == 'Thomas'


# Generated at 2022-06-25 18:14:38.567514
# Unit test for function load_text_file
def test_load_text_file():
    request_items_1 = RequestItems()
    class test_arg:
        orig="arg"
        value="arg"
    assert request_items_1.load_text_file(test_arg()) == "arg"


# Generated at 2022-06-25 18:14:43.057316
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep = SEPARATOR_FILE_UPLOAD,
        key = "File",
        value = "test/test.txt",
        orig = 'File==test/test.txt'
    )
    result = process_file_upload_arg(arg)
    assert isinstance(result, tuple)
    assert result[0] == "test.txt"
    assert result[1].read().decode("utf-8") == 'Hello world'
    assert result[2] == "text/plain"