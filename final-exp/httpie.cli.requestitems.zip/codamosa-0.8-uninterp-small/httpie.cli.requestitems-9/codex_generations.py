

# Generated at 2022-06-25 18:05:25.580380
# Unit test for function load_text_file
def test_load_text_file():
    test_file = 'test_file.txt'
    f = open(test_file, 'w')
    f.write("test")
    f.close()
    # If a non-encoded text file is provided, the text is properly read from file.
    test_arg = KeyValueArg('test', 'test')
    file_contents = load_text_file(test_arg)
    # Removes test file.
    os.remove(test_file)
    assert file_contents == "test"
    # If a non-text file is provided, a UnicodeDecodeError is raised.
    test_arg = KeyValueArg('test', 'test')
    with pytest.raises(ParseError) as decode_error:
        load_text_file(test_arg)


# Generated at 2022-06-25 18:05:26.939843
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file("test.txt") == "test.txt"

# Generated at 2022-06-25 18:05:31.921674
# Unit test for function load_text_file
def test_load_text_file():
    import os
    os.chdir("/Users/li/Documents/GitHub/httpie/test")
    key_value_arg_0 = KeyValueArg([':', "hi.md"])
    str_0 = load_text_file(key_value_arg_0)
    print(str_0)


# Generated at 2022-06-25 18:05:39.438841
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    key_value_arg_0 = KeyValueArg('-d', '', '', ';')
    key_value_arg_0.orig = "http testserver.com -d '{bool:true, int:3}'"
    key_value_arg_0.key = "-"
    key_value_arg_0.value = "json:"
    key_value_arg_0.sep = ":"
    key_value_arg_0.is_query = False
    key_value_arg_0.is_data = True
    key_value_arg_0.is_file = False
    key_value_arg_0.is_header = False

    json_type_0 = process_data_embed_raw_json_file_arg(key_value_arg_0)
    assert json_type_0.__class

# Generated at 2022-06-25 18:05:41.983208
# Unit test for function load_text_file
def test_load_text_file():
    key_value_arg_0 = None
    str_0 = load_text_file(key_value_arg_0)



# Generated at 2022-06-25 18:05:43.930951
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    key_value_arg_0 = None
    JSONType_0 = process_data_embed_raw_json_file_arg(key_value_arg_0)


# Generated at 2022-06-25 18:05:49.408695
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    key_value_arg_0 = './testfile_json.json'
    str_0 = load_text_file(key_value_arg_0)
    assert isinstance(str_0, str)
    json_0 = load_json(key_value_arg_0, str_0)
    assert isinstance(json_0, str)
    json_1 = process_data_embed_raw_json_file_arg(key_value_arg_0)
    assert json_0 == json_1


# Generated at 2022-06-25 18:05:57.485719
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # test case 1
    key_value_arg_0_1 = KeyValueArg(sep=SEPARATOR_FILE_UPLOAD, orig='@/Users/martin/Downloads/test.pdf', key='file', value='/Users/martin/Downloads/test.pdf')
    result = process_file_upload_arg(key_value_arg_0_1)
    expected = ('test.pdf', (os.path.expanduser(key_value_arg_0_1.value)), None)
    assert result == expected
    # test case 2

# Generated at 2022-06-25 18:06:02.858016
# Unit test for function load_text_file
def test_load_text_file():
    contents_arg_0 = "https://www.google.com"
    str_0 = load_text_file(contents_arg_0)


# Generated at 2022-06-25 18:06:07.028750
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    key_value_arg_0 = KeyValueArg(None, None, u'{"key": "value"}')
    actual_result_0 = process_data_raw_json_embed_arg(key_value_arg_0)
    assert (actual_result_0 == "{'key': 'value'}")

# Generated at 2022-06-25 18:06:21.477897
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_file = RequestItems()
    file_path = os.path.join(os.path.dirname(__file__), '../test-data/test_json_file.json')
    arg = KeyValueArg(separator=']', value=file_path)
    json_file = json_file.process_data_embed_raw_json_file_arg(arg)
    assert json_file == {'test': 'data'}


# Generated at 2022-06-25 18:06:24.891215
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, key='key', value='value')
    assert process_data_embed_raw_json_file_arg(arg) is not None


# Generated at 2022-06-25 18:06:30.441910
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    data_embed_json_file_obj_1 = KeyValueArg(sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
                                              key=None,
                                              orig='@./tests/data/data_embed_json_file_obj_1.json',
                                              value='@./tests/data/data_embed_json_file_obj_1.json')
    value1 = {'foo': 'bar@'}
    assert process_data_embed_raw_json_file_arg(data_embed_json_file_obj_1) == value1



# Generated at 2022-06-25 18:06:38.474280
# Unit test for function load_text_file
def test_load_text_file():
    # Test no value
    assert load_text_file(KeyValueArg('/k/', '', '', '')) == ''
    # Test no file
    with pytest.raises(ParseError):
        load_text_file(KeyValueArg('/k/', 'bad_file', '', ''))
    # Test file read
    assert load_text_file(KeyValueArg('/k/', 'tests/data/file.txt', '', '')) == 'this is a file\n'

# Generated at 2022-06-25 18:06:47.417514
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(
        orig='Content-Type:application/json',
        sep='Content-Type',
        key='application/json',
        value='application/json',
        orig_key='Content-Type',
        orig_value='application/json')
    excepted_result = {
        "Content-Type": "application/json"
    }
    result = process_data_raw_json_embed_arg(arg)
    assert result == excepted_result

if __name__ == "__main__":
    test_case_0()
    test_process_data_raw_json_embed_arg()

# Generated at 2022-06-25 18:06:50.164540
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    mock_arg = KeyValueArg('key1', 'value1')

    result = process_data_embed_raw_json_file_arg(mock_arg)
    assert result == "value1"

# Generated at 2022-06-25 18:06:54.110350
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        '-',
        'abc',
        'abc',
        'abc'
        )

    assert(process_data_embed_raw_json_file_arg(arg) == "abc")

# Generated at 2022-06-25 18:07:05.043318
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg(
        '--form', 'upload_file', 'my_text_file.txt')) == (
        'my_text_file.txt', open('my_text_file.txt', 'rb'), 'text/plain')
    assert process_file_upload_arg(KeyValueArg(
        '--form', 'upload_file', 'my_text_file.txt;')) == (
        'my_text_file.txt', open('my_text_file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-25 18:07:14.709846
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(orig="@test.json")
    item.value="test.json"
    request_items_0 = RequestItems()
    assert process_data_embed_raw_json_file_arg(item) == {'markdown': 'https://guides.github.com/features/mastering-markdown/','username': 'TylorS','awesome': '6','url': 'https://api.github.com/users/TylorS','not-awesome': 'https://www.pleacher.com/mp/mlessons/algebra/logs.html'}


# Generated at 2022-06-25 18:07:21.957652
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    raw_json_data = {
        "firstName": "John",
        "lastName": "Smith",
        "age": 25
    }
    raw_json_data_str = json.dumps(raw_json_data)
    keyValue = KeyValueArg('prefix;', 'data;', raw_json_data_str)
    data_item = process_data_embed_raw_json_file_arg(keyValue)
    assert data_item == raw_json_data


# Generated at 2022-06-25 18:07:41.390336
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(sep='=', key='name', value='value')
    test_1 = process_data_embed_raw_json_file_arg(arg)
    assert test_1 == 'value'

# Generated at 2022-06-25 18:07:51.934162
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    class KeyValueArg:
        def __init__(self, sep, key, value):
            self.sep = sep
            self.key = key
            self.value = value

    my_arg = KeyValueArg("-F", "a.txt", "a.txt")
    res = process_file_upload_arg(my_arg)
    assert res == ('a.txt', open(os.path.expanduser('a.txt'), 'rb'), 'text/plain')

    my_arg = KeyValueArg("-F", "a.txt", "a.txt;text/html")
    res = process_file_upload_arg(my_arg)
    assert res == ('a.txt', open(os.path.expanduser('a.txt'), 'rb'), 'text/html')

    """test with a fake file"""


# Generated at 2022-06-25 18:07:53.532317
# Unit test for function load_text_file
def test_load_text_file():
    # Case 1
    item = KeyValueArg("val", "val", None, None)
    load_text_file(item)



# Generated at 2022-06-25 18:07:56.031937
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg("data", "", "json", '{"field1": "value1"}')
    value_dict = process_data_raw_json_embed_arg(arg)
    assert value_dict['field1'] == 'value1'

# Generated at 2022-06-25 18:07:57.587938
# Unit test for function load_text_file
def test_load_text_file():
    try:
        assert load_text_file(RequestItems()) == None
    except:
        raise


# Generated at 2022-06-25 18:08:10.074325
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Test boundary case 1: file upload without mime type
    # input: 'filename.png'
    # output: ('filename.png', 'file_contents', 'image/png')
    input_test_1 = 'filename.png'
    output_test_1 = ('filename.png', 'file_contents', 'image/png')
    assert process_file_upload_arg(input_test_1) == output_test_1
    # Test normal case 1: file upload with mime type
    # input: 'filename.png', 'image/png'
    # output: ('filename.png', 'file_contents', 'image/png')
    input_test_2 = 'filename.png', 'image/png'
    output_test_2 = ('filename.png', 'file_contents', 'image/png')

# Generated at 2022-06-25 18:08:12.881018
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg.from_arg('@test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), None)



# Generated at 2022-06-25 18:08:14.916411
# Unit test for function load_text_file
def test_load_text_file():
    file = '/test.txt'
    obj = KeyValueArg('test', file)
    assert load_text_file(obj) == 'test'

# Generated at 2022-06-25 18:08:21.638160
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # test case 1
    try:
        request_items_1 = RequestItems()
        arg_1 = KeyValueArg(SEPARATOR_FILE_UPLOAD, 'test')
        process_file_upload_arg(arg_1)
    except ParseError as e:
        print(e)
    # test case 2
    try:
        request_items_2 = RequestItems()
        arg_2 = KeyValueArg(SEPARATOR_FILE_UPLOAD, 'test.mp4')
        process_file_upload_arg(arg_2)
    except ParseError as e:
        print(e)
    # test case 3

# Generated at 2022-06-25 18:08:32.509539
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    request_items = RequestItems()

    # Test case (1)
    try:
        request_items.data['info'] = load_json(None, '{"temperature": 23}')
    except Exception as e:
        print('Error in test case (1): %s' % e)

    # Test case (2)
    try:
        process_data_raw_json_embed_arg(KeyValueArg(None, '-d', None))
    except ParseError as e:
        print('ParseError in test case (2): %s' % e)

    # Test case (3)

# Generated at 2022-06-25 18:09:07.169327
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    process_file_upload_arg(KeyValueArg('Content-Type=application/json', SEPARATOR_FILE_UPLOAD_TYPE, 'application/json'))


# Generated at 2022-06-25 18:09:10.740637
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    path = 'tests/data/colors.json'
    expected = {'red': '#ff0000', 'blue': '#0000ff', 'green': '#00ff00'}
    result = process_data_embed_raw_json_file_arg(KeyValueArg('data', path))
    assert result == expected, "Wrong content or corrupted file"

# Generated at 2022-06-25 18:09:13.719453
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    s = '[{"one": "a"}, {"two": "b"}, {"three": "c"}]'
    data = process_data_embed_raw_json_file_arg("--json=test.json")
    assert data == s

# Generated at 2022-06-25 18:09:17.012248
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("test:test")
    path = "test"
    with open(os.path.expanduser(path), 'rb') as f:
        return f.read().decode()


# Generated at 2022-06-25 18:09:24.112965
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    request_items_0 = RequestItems()
    arg1 = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key=None,
        value='filename',
    )
    arg2 = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key=None,
        value='filename;mimetype',
    )
    assert(process_file_upload_arg(arg1) == ('filename', os.path.expanduser('filename'), 'text/plain'))
    assert(process_file_upload_arg(arg2) == ('filename', os.path.expanduser('filename'), 'mimetype'))

# Generated at 2022-06-25 18:09:35.192963
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():

    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key=None,
        value='/Users/jeffwong/Desktop/SEI-PT/projects/httpie/CODE_OF_CONDUCT.json'
    )

    try:
        contents = load_text_file(arg)
        value = load_json(arg, contents)
        print('arg.value: ', arg.value)
        print('contents: ', contents)
        print('value: ', value)
    except ParseError as e:
        print(e)


if __name__ == "__main__":
    test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-25 18:09:42.383522
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Setup
    request_items_0 = RequestItems()

    input = "http://127.0.0.1:80/post" + SEPARATOR_DATA_EMBED_RAW_JSON_FILE + "./tests/data/data.json"
    test_args = shlex.split(input)
    args = Args()
    args.parse_args(test_args)
    request_items_0.from_args(args.request_items)


# Generated at 2022-06-25 18:09:44.467423
# Unit test for function load_text_file
def test_load_text_file():
    request_items_1 = RequestItems()
    assert load_text_file(request_items_1) == "load_text_file"


# Generated at 2022-06-25 18:09:45.766681
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file("test.txt") == "test.txt"

# Generated at 2022-06-25 18:09:55.306002
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    item = KeyValueArg('-d{}foo:bar'.format(SEPARATOR_DATA_RAW_JSON), None)
    assert process_data_raw_json_embed_arg(item) == {'foo': 'bar'}
    item = KeyValueArg('-d{}[1,2,3]'.format(SEPARATOR_DATA_RAW_JSON), None)
    assert process_data_raw_json_embed_arg(item) == [1, 2, 3]
    item = KeyValueArg('-d{}true'.format(SEPARATOR_DATA_RAW_JSON), None)
    assert process_data_raw_json_embed_arg(item) == True
    item = KeyValueArg('-d{}null'.format(SEPARATOR_DATA_RAW_JSON), None)
    assert process_data_raw_json

# Generated at 2022-06-25 18:10:36.445515
# Unit test for function load_text_file
def test_load_text_file():
    request_items = RequestItems()
    request_items.data['test'] = process_data_embed_file_contents_arg(
        KeyValueArg(orig='', key='', value='D:\\OneDrive\\Data\\test1.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    )
    print(request_items.data)

# Generated at 2022-06-25 18:10:46.505177
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_item_args_0 = []
    request_item_args_0.append(
        KeyValueArg(
            sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
            orig='@example.json',
            key=None,
            value='example.json',
            sep_key=None,
        )
    )

    requestItems_instance_0 = RequestItems.from_args(request_item_args_0, True)
    assert requestItems_instance_0.data == [('@example.json', {})]



# Generated at 2022-06-25 18:10:49.733181
# Unit test for function load_text_file
def test_load_text_file():
    request_items_1 = RequestItems()
    item = KeyValueArg("#", "@", "abc", "abc")
    load_text_file(item)


# Generated at 2022-06-25 18:10:52.980502
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg("/Users/paul/documents/github/httpie/requirements.txt;application/octet-stream") == ("requirements.txt", f, application/octet-stream)

# Generated at 2022-06-25 18:11:05.095082
# Unit test for function load_text_file
def test_load_text_file():
    # Testing for invalid path
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        value='../test_file.txt',
        orig='test@../test_file.txt')
    with pytest.raises(ParseError):
        load_text_file(arg)

    # Testing for invalid text file
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        value='/tmp/test_file.txt',
        orig='test@/tmp/test_file.txt')
    with open('/tmp/test_file.txt', 'wb') as f:
        f.write(b'\xff')

# Generated at 2022-06-25 18:11:11.820767
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    key_value_arg_0 = KeyValueArg(':', '', '', 'file')
    try:
        actual = process_file_upload_arg(key_value_arg_0)
    except IOError as e:
        raise ParseError('"%s": %s' % (key_value_arg_0.orig, e))
    expected = ('file', f, get_content_type('file'))


# Generated at 2022-06-25 18:11:16.439284
# Unit test for function load_text_file
def test_load_text_file():
    # Set up argument
    arg = KeyValueArg('value', 'd')
    # Call test function
    path = load_text_file(arg)
    # Check result
    assert path == 't'


# Generated at 2022-06-25 18:11:19.986663
# Unit test for function load_text_file
def test_load_text_file():
    input_arg = KeyValueArg('file', './test/http/httpbin_html_utf8.html', ';', '', '')
    actual_text = load_text_file(input_arg)
    actual_type = type(actual_text)
    assert actual_type is str, 'load_text_file returns the wrong type'
    assert len(actual_text) > 0, 'load_text_file returns the wrong value'


# Generated at 2022-06-25 18:11:27.348740
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg: KeyValueArg = KeyValueArg(
        key='Key1',
        sep=SEPARATOR_FILE_UPLOAD,
        value='"/Users/user1/Desktop/CISI/Project/httpie/httpie/output/download.png"',
        orig='"/Users/user1/Desktop/CISI/Project/httpie/httpie/output/download.png"'
    )

    result: Tuple[str, IO, str] = process_file_upload_arg(file_upload_arg)

    assert result[0] == 'download.png'

# Generated at 2022-06-25 18:11:35.363134
# Unit test for function load_text_file
def test_load_text_file():
    # Create a file called test.txt in the current directory
    # Then write some text in it
    # This is for tesing the function load_text_file
    test_file = open("test.txt", "w")
    test_file.write("This is for testing the load_text_file() function")
    test_file.close()
    
    
     # Check the argument
    arg = KeyValueArg('test-key', 'test.txt', ':')
    # If everything goes well, the text in the file should be loaded
    # and returned
    load_text_file(arg)

# Generated at 2022-06-25 18:12:52.515218
# Unit test for function load_text_file
def test_load_text_file():
    load_text_file('')

# Generated at 2022-06-25 18:12:56.215261
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('')
    path = 'test_file.txt'
    item.value = path
    try:
        load_text_file(item)
    except:
        raise ParseError('"%s": %s' % (item.orig, e))


# Generated at 2022-06-25 18:12:58.501482
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg("foo", "test.jpg")) == ("test.jpg", open("test.jpg", "rb"), get_content_type("test.jpg"))


# Generated at 2022-06-25 18:13:02.142926
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    result = process_file_upload_arg(KeyValueArg('file', 'test.txt'))
    assert (result[0] == 'test.txt')
    assert (result[1].name == 'test.txt')
    assert (result[2] == 'text/plain')


# Generated at 2022-06-25 18:13:09.764192
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Setup
    item = KeyValueArg(key=None, sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test/data/test_process_data_embed_raw_json_file_arg.json')

    # Actual
    actual_result = process_data_embed_raw_json_file_arg(item)

    # Expected
    expected_result = {
        'b': 1,
        'a': 0,
        'd': {
            'x': [1, 0],
            'y': 1,
            'z': 'b',
        },
        'c': {
            'a': 'b',
            'c': 2,
            'b': 1,
        },
    }

    assert expected_result == actual_result



# Generated at 2022-06-25 18:13:18.959402
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    """
    Getting valid json data from the provided file path and the function should
    return a dict with the contents.
    """
    request_item_0 = KeyValueArg(
        key='data',
        value='../../data/json_files/json_data_1.json',
        sep='=:'
    )
    data_dict_0 = process_data_embed_raw_json_file_arg(request_item_0)
    assert data_dict_0['name'] == 'foo'
    assert data_dict_0['color'] == 'red'
    data_dict_1 = {
        'name': 'foo',
        'color': 'red'
    }
    assert data_dict_0 == data_dict_1 #Checking whether both the dicts are equal.


# Generated at 2022-06-25 18:13:25.415221
# Unit test for function load_text_file
def test_load_text_file():
    # Test when the file is not empty
    item = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, 'name', 'testfile1.txt')
    assert load_text_file(item) == 'this is a test file\n'

    # Test when the file is empty
    item = KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, 'name', 'testfile2.txt')
    assert load_text_file(item) == ''


# Generated at 2022-06-25 18:13:29.638418
# Unit test for function load_text_file
def test_load_text_file():
    class Object:
        def __init__(self, value):
            self.value = value
            self.orig = value

    assert load_text_file(Object('test_file.txt')) == 'Test file contents\n'
    assert load_text_file(Object('test_file.non_existent')) == None




# Generated at 2022-06-25 18:13:33.444572
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_items = RequestItems()
    json_data = process_data_embed_raw_json_file_arg(
        KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, 'data', 'contents.json'))

    assert json_data == {'a': 1, 'b': 2}
    assert type(json_data) == dict, 'Type of json data is invalid'



# Generated at 2022-06-25 18:13:38.824245
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig=SEPARATOR_DATA_EMBED_FILE_CONTENTS + 'foo',
        key=None,
        value='foo'
    )
    assert load_text_file(item) == 'foo'
