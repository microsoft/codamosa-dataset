

# Generated at 2022-06-25 18:05:21.588244
# Unit test for function load_text_file
def test_load_text_file():
    str_0 = '~[I@5:H^-BO.f:T'
    key_value_arg_0 = module_0.KeyValueArg(str_0, str_0, str_0, str_0)
    _load_text_file(key_value_arg_0)

# Generated at 2022-06-25 18:05:26.509913
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    str_0 = 'n7oat@'
    str_1 = '!_F1Y)C'
    key_value_arg_0 = module_0.KeyValueArg(str_1, str_1, str_0, str_1)
    contents = load_text_file(key_value_arg_0)
    var_0 = load_json(key_value_arg_0, contents)
    var_1 = process_data_embed_raw_json_file_arg(key_value_arg_0)
    assert (var_1 == var_0)


# Generated at 2022-06-25 18:05:28.802767
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    str_0 = module_0.KeyValueArg(str_0, str_0, str_0, str_0)
    var_0 = process_file_upload_arg(str_0)


# Generated at 2022-06-25 18:05:30.827098
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    str_0 = 'd@=z-4'
    key_value_arg_0 = module_0.KeyValueArg(str_0, str_0, str_0, str_0)
    var_0 = load_json(key_value_arg_0, str_0)


# Generated at 2022-06-25 18:05:32.939421
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    str_0 = 'e'
    key_value_arg_0 = module_0.KeyValueArg(str_0, str_0, str_0, str_0)
    var_0 = process_data_raw_json_embed_arg(key_value_arg_0)


# Generated at 2022-06-25 18:05:39.338132
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    # Test JSON file with invalid syntax
    str_0 = 'Wrong JSON syntax'
    key_value_arg_0 = module_0.KeyValueArg(str_0, str_0, str_0, str_0)
    try:
        process_data_raw_json_embed_arg(key_value_arg_0)
    except ParseError as e:
        if "None" in str(e):
            return
        else:
            raise Exception('Test failed')
    else:
        raise Exception('Test failed')
    # Test path to non-existing file
    str_1 = '~[I@5:H^-BO.f:T'
    str_2 = 'h5%c'
    str_3 = 'lE2tB_'
    str_4 = 'e5b'
    str

# Generated at 2022-06-25 18:05:43.895960
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    str_0 = 'u`z{]GJ2mZ(c@}?.I'
    key_value_arg_0 = module_0.KeyValueArg(str_0, str_0, str_0, str_0)
    var_0 = process_data_raw_json_embed_arg(key_value_arg_0)


# Generated at 2022-06-25 18:05:49.087558
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    str_0 = '~[I@5:H^-BO.f:T'
    str_1 = '[::t22sY-;{'
    key_value_arg_0 = module_0.KeyValueArg(str_0, str_0, str_0, str_1)
    request_items_0 = RequestItems.from_args([key_value_arg_0])
    var_0 = process_data_raw_json_embed_arg(key_value_arg_0)


# Generated at 2022-06-25 18:05:57.222981
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    str_1 = 'N1t>vN/$e%*'
    str_2 = 'eA[^T3fq%&'
    key_value_arg_1 = module_0.KeyValueArg(str_1, str_2, str_1, str_1)
    str_3 = 'g:_a&:HGCr;'

    var_1 = process_file_upload_arg(key_value_arg_1)
    # expected index: 0
    var_1[1].write(b'\x00' * 0x1000)
    var_1[1].seek(0)
    var_1[1].read(16)
    # expected index: 1
    var_1[1].seek(0)
    var_1[1].read(16)

    # Unit test for function

# Generated at 2022-06-25 18:06:05.683126
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    path_0 = '3q.Nn}?b|.R'
    key_value_arg_0 = httpie.cli.argtypes.KeyValueArg(':', path_0, path_0, path_0)
    var_0 = process_file_upload_arg(key_value_arg_0)
    var_1 = process_file_upload_arg(key_value_arg_0)


# Generated at 2022-06-25 18:06:16.927711
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-25 18:06:18.644894
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    process_data_embed_raw_json_file_arg()


# Generated at 2022-06-25 18:06:20.404957
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key','value',':')
    process_file_upload_arg(arg)


# Generated at 2022-06-25 18:06:24.185067
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig='test_arg', key='test_key', sep=':' ,value='{"test_key":"test_value"}')
    assert process_data_raw_json_embed_arg(arg) == {'test_key':'test_value'}


# Generated at 2022-06-25 18:06:28.930219
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Unit test for file upload
    request_item_args = [
        KeyValueArg(SEPARATOR_FILE_UPLOAD, '../data/upload/aircraft.json', 'aircraft.json', '', '')
    ]
    request_items = RequestItems.from_args(request_item_args)
    print(request_items.files['aircraft.json'])
    print(type(request_items.files['aircraft.json']))


# Generated at 2022-06-25 18:06:34.076770
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    value1 = load_json(arg="test", contents='{"a":"a","b":"b"}')
    value2 = load_json(arg="test", contents='{"a":"a","b":"b"}')
    assert value1 == value2

# Generated at 2022-06-25 18:06:46.441478
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    #Test no mime_type
    arg = KeyValueArg(key=None, sep=SEPARATOR_FILE_UPLOAD, value='./hello.txt')
    expect = (
        os.path.basename('./hello.txt'),
        open(os.path.expanduser('./hello.txt'), 'rb'),
        None,
    )
    result = process_file_upload_arg(arg)
    assert expect == result

    #Test with mimetype
    arg = KeyValueArg(key=None, sep=SEPARATOR_FILE_UPLOAD, value='./hello.txt;text/plain')

# Generated at 2022-06-25 18:06:58.747392
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_items = RequestItems()
    assert process_data_embed_raw_json_file_arg(KeyValueArg('@/tmp/a.json', SEPARATOR_DATA_EMBED_RAW_JSON_FILE)) == {'key1': 'val1'}
    assert process_data_embed_raw_json_file_arg(KeyValueArg('@/tmp/test_dict.json', SEPARATOR_DATA_EMBED_RAW_JSON_FILE)) == {'member1':{'member2':{'member3':'value'}}}

# Generated at 2022-06-25 18:07:03.319781
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(sep=SEPARATOR_FILE_UPLOAD,key=None,value="httpie/config.py")
    output = process_file_upload_arg(arg)
    expected = ('config.py', open("httpie/config.py"),'text/x-python')
    assert output==expected

# Generated at 2022-06-25 18:07:12.618783
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(SEPARATOR_DATA_STRING, "data", "."+os.sep+"resources"+os.sep+"json"+os.sep+"myjson.json")
    contents = load_text_file(item)
    assert contents == """{\n  "data1": "testic",\n  "data2": [\n    {\n      "data2data1": "testic2"\n    }\n  ]\n}"""


# Generated at 2022-06-25 18:07:29.077127
# Unit test for function load_text_file
def test_load_text_file():
    try:
        request_items_1 = RequestItems()
        load_text_file("tests/unittests_artefacts/embed.txt")
    except ParseError:
        print("test_load_text_file fail")
        assert False
    else:
        assert True
    try:
        request_items_2 = RequestItems()
        load_text_file("tests/unittests_artefacts/embed_large.txt")
    except ParseError:
        print("test_load_text_file fail")
        assert False
    else:
        assert True


# Generated at 2022-06-25 18:07:36.089800
# Unit test for function load_text_file
def test_load_text_file():

    item = KeyValueArg(orig='Content-Type: application/json',
                       param='Content-Type',
                       sep=':',
                       value='application/json')

    try:
        path = item.value
        with open(os.path.expanduser(path), 'rb') as f:
            assert f.read().decode() == 'application/json'
    except IOError as e:
        raise ParseError('"%s": %s' % (item.orig, e))
    except UnicodeDecodeError:
        raise ParseError(
            '"%s": cannot embed the content of "%s",'
            ' not a UTF8 or ASCII-encoded text file'
            % (item.orig, item.value)
        )


# Generated at 2022-06-25 18:07:36.794924
# Unit test for function load_text_file

# Generated at 2022-06-25 18:07:44.132204
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="abc", value="abc.txt" + SEPARATOR_FILE_UPLOAD_TYPE + "text/html")
    assert process_file_upload_arg(arg) == ("abc.txt", open(os.path.expanduser(arg.value.split(SEPARATOR_FILE_UPLOAD_TYPE)[0]), 'rb'), "text/html")


# Generated at 2022-06-25 18:07:51.296828
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
	request_item_args = [
		KeyValueArg(None, '', '', None),
		KeyValueArg('file', '', '=', ''),
		KeyValueArg(':', '', '', None),
		KeyValueArg('data', '', ';', ''),
		KeyValueArg(':', '', '', None),
	]
	request_item = RequestItems.from_args(request_item_args, False)
	assert request_item.files['file'] == '', 'Test 1 failed'

# Generated at 2022-06-25 18:07:55.451066
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    path = "users.json"
    mime_type = 'application/json'
    attempt = ("users.json", path, mime_type)
    assert attempt == process_file_upload_arg(KeyValueArg(
        "user.jason;application/json",
        "user.jason",
        ";",
        "application/json"
    ))


# Generated at 2022-06-25 18:08:00.996674
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    try:
        process_file_upload_arg(KeyValueArg('foo', '', 'f'))
        assert True
    except ParseError:
        assert False

    try:
        process_file_upload_arg(KeyValueArg('@', '', 'f'))
        assert False
    except ParseError:
        assert True


# Generated at 2022-06-25 18:08:12.079345
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    import io

    # Case 0: valid, no optional mime type
    filename = "./data/some_file"
    mime_type = "text/plain"
    expected = ("./data/some_file", io.open(filename, 'rb'), "text/plain")
    arg = KeyValueArg("file@" + filename)
    result = process_file_upload_arg(arg)
    assert expected == result

    # Case 1: valid, mime type specified
    mime_type = "text/plain"
    expected = ("./data/some_file", io.open(filename, 'rb'), "text/plain")
    arg = KeyValueArg("file@" + filename + ";type=text/plain")
    result = process_file_upload_arg(arg)
    assert expected == result

    # Case 2

# Generated at 2022-06-25 18:08:15.930051
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    testArg = KeyValueArg('--form','foo','sep','=','key','foo','value','foo','orig','--form','foo','is_flag',False,'is_posix_shorthand',False)
    assert process_file_upload_arg(testArg) == ('foo',)

# Generated at 2022-06-25 18:08:20.494486
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    request_items_1 = RequestItems()
    process_data_embed_raw_json_file_arg({'orig':'0', 'key':'@', 'value':'{"requests":[{"image":{"content":"hello"},"features":[{"type":"LABEL_DETECTION","maxResults":1}]}]}', 'sep':'@'})



# Generated at 2022-06-25 18:08:39.220402
# Unit test for function load_text_file

# Generated at 2022-06-25 18:08:45.046029
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    value = "tests/data/upload_file.txt"
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "file", value)
    assert process_file_upload_arg(arg) ==\
        (os.path.basename(value), open(os.path.expanduser(value), 'rb'), "text/plain")


# Generated at 2022-06-25 18:08:57.523831
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_data = [
        {
            "example": "name1",
            "test": [
                {
                    "ex": "name2"
                }
            ]
        }
    ]

    # Testing for empty file
    arg = KeyValueArg('', '', '', '', '')
    assert(process_data_embed_raw_json_file_arg(arg) == None)

    # Testing for non-empty file
    arg = KeyValueArg('', '', '', '', SEPARATOR_DATA_EMBED_RAW_JSON_FILE + "example_0.json")
    assert(process_data_embed_raw_json_file_arg(arg) == json_data)


# Generated at 2022-06-25 18:09:02.091775
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    filename = 'example.json'
    arg = KeyValueArg(
        'original-request-item', 'json-file', '%s[@]' % filename, None
    )

    result = process_data_embed_raw_json_file_arg(arg)
    expected = {"a": 1}
    assert result == expected

# Generated at 2022-06-25 18:09:12.415097
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # file path without mime_type
    img_file_path = "../test_img.png"
    # file path with mime_type
    txt_file_path_with_mime_type = "~/httpie_test.txt" + SEPARATOR_FILE_UPLOAD_TYPE + "text/plain"
    # file path with wrong mime_type
    txt_file_path_with_wrong_mime_type = "~/httpie_test.txt" + SEPARATOR_FILE_UPLOAD_TYPE + "wrong_mime_type"

    # file path without mime_type
    input_arg_0 = KeyValueArg(key="test_img_png", sep=SEPARATOR_FILE_UPLOAD, value=img_file_path)
    filename_0, file_0,

# Generated at 2022-06-25 18:09:14.391762
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("@testfile;", "@testfile;")
    assert load_text_file(item) == "testfile"


# Generated at 2022-06-25 18:09:18.039026
# Unit test for function load_text_file
def test_load_text_file():
    request_item_args = [KeyValueArg(key="test", value="test")]
    request_items_0 = RequestItems()
    request_items_0.data['test'] = process_data_item_arg(request_item_args[0])

# Generated at 2022-06-25 18:09:25.820802
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg1 = KeyValueArg("data", "a:b")
    arg2 = KeyValueArg("data", "a:b", "data_1")
    arg3 = KeyValueArg("data", "foo:bar")
    arg4 = KeyValueArg("data", "foo:bar", "data_1")
    test_dict = {"a": "b", "foo": "bar"}
    assert(process_data_embed_raw_json_file_arg(arg1) == test_dict)
    assert(process_data_embed_raw_json_file_arg(arg2) == test_dict)
    assert(process_data_embed_raw_json_file_arg(arg3) == test_dict)
    assert(process_data_embed_raw_json_file_arg(arg4) == test_dict)


# Unit

# Generated at 2022-06-25 18:09:28.917164
# Unit test for function load_text_file
def test_load_text_file():
    print(load_text_file(KeyValueArg('a', 'test.txt')))


# Generated at 2022-06-25 18:09:31.468999
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(sep='++', key='', value='text.txt')
    load_text_file(item)


# Generated at 2022-06-25 18:10:17.448260
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    import tempfile
    from contextlib import contextmanager
    from operator import itemgetter

    class FakeKeyValueArg:
        def __init__(self, value, orig=None):
            self.value = value
            self.orig = orig
        def __str__(self):
            return self.value

    request_items_0 = RequestItems()
    @contextmanager
    def tempfile_ctx(value):
            with tempfile.NamedTemporaryFile('w') as tmp:
                tmp.write(value)
                tmp.flush()
                yield tmp.name

    request_items_0.data['foo'] = 'bar'
    with tempfile_ctx('{"foo": "bar"}') as json_file:
        arg = FakeKeyValueArg(json_file, '<json file>')
        response = process_data_embed

# Generated at 2022-06-25 18:10:26.622249
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
   data_embed_raw_json_file_arg = KeyValueArg(argstr='@data-embed-raw-json-file')
   data_embed_raw_json_file_arg.key ='test_embed_raw_json_file'
   data_embed_raw_json_file_arg.value ='{\"key\":\"value\"}'
   data_embed_raw_json_file_arg.sep = '@'
   data_embed_raw_json_file_arg.orig = data_embed_raw_json_file_arg.key +data_embed_raw_json_file_arg.sep + data_embed_raw_json_file_arg.value
   assert process_data_embed_raw_json_file_arg(data_embed_raw_json_file_arg) == {"key": "value"}



# Generated at 2022-06-25 18:10:31.488466
# Unit test for function load_text_file
def test_load_text_file():
    with open('test.txt', 'wt') as f:
        f.write('test')

    item = KeyValueArg(sep=';', orig=';test.txt', key='', value='test.txt')

    with pytest.raises(ParseError) as excinfo:
        load_text_file(item)
    assert '"test.txt": not a UTF8 or ASCII-encoded text file' in str(excinfo.value)



# Generated at 2022-06-25 18:10:39.268597
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    '''Unit test for function process_file_upload_arg'''
    # test empty filename
    try:
        process_file_upload_arg(KeyValueArg.from_arg('@'))
    except ParseError:
        pass
    else:
        assert False, 'ParseError expected if filename is empty'

    # test non-existing filename
    try:
        process_file_upload_arg(KeyValueArg.from_arg('@does_not_exist'))
    except ParseError:
        pass
    else:
        assert False, \
            'ParseError expected if filename does not exists'

    # test existing filename

# Generated at 2022-06-25 18:10:42.014668
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("@file.txt", "file.txt", "@")
    assert load_text_file(item) == "data"


# Generated at 2022-06-25 18:10:46.347000
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg('', '', 'foo.txt')) == ('foo.txt', open(os.path.expanduser('foo.txt'), 'rb'), None)


# Generated at 2022-06-25 18:10:51.363243
# Unit test for function load_text_file
def test_load_text_file():
    # Case 0: wrong path
    item = KeyValueArg(
        'k0',  # key
        None,  # value
        'v0',  # orig
        SEPARATOR_DATA_EMBED_FILE_CONTENTS,  # sep
    )
    try:
        load_text_file(item)
    except ParseError:
        pass

    # Case 1: correct path
    item = KeyValueArg(
        'k0',  # key
        'httpie/cli/argtypes.py',  # value
        'v0',  # orig
        SEPARATOR_DATA_EMBED_FILE_CONTENTS,  # sep
    )
    try:
        load_text_file(item)
    except ParseError:
        pass



# Generated at 2022-06-25 18:10:55.715559
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg()
    arg.orig = arg.value = arg.key = 'file.txt'
    load_text_file(arg)


# Generated at 2022-06-25 18:11:01.178428
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_case = 'file.json'
    arg = KeyValueArg(None, 'json', test_case, SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    item = process_data_embed_raw_json_file_arg(arg)
    print(item)

# Generated at 2022-06-25 18:11:09.333461
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_path = "httpie/cli/test_data/test.json"
    key = "file_json"
    value = "test.json;application/json"
    output = process_file_upload_arg(KeyValueArg("", key, value))
    file_name = os.path.basename(file_path)
    assert output[0] == file_name
    assert output[2] == "application/json"
    f_output = output[1]
    output_contents = f_output.read().decode("utf-8")
    with open(os.path.expanduser(file_path), "rb") as f:
        contents = f.read().decode("utf-8")
    assert contents == output_contents



# Generated at 2022-06-25 18:11:50.908688
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg()
    # with open(os.path.expanduser('~/test0.txt'), 'wb') as f:
    #     f.write(b'123456789\nabcdefg\nabcdefg\n')
    #     f.write(b'123456789\nabcdefg\nabcdefg\n')
    # with open(os.path.expanduser('~/test1.txt'), 'wb') as f:
    #     f.write(bytes('123456789\nabcdefg\nabcdefg\n', 'utf-8'))
    #     f.write(bytes('123456789\nabcdefg\nabcdefg\n', 'utf-8'))
    # with open(os.path.expanduser('~/test2

# Generated at 2022-06-25 18:11:56.701958
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    import sys
    output_1 = sys.stdout
    process_data_embed_raw_json_file_arg(
        '"src/httpie/tests/data/embed/names.json"', output_1)
    output_2 = sys.stdout
    process_data_embed_raw_json_file_arg(
        '"src/httpie/tests/data/embed/names.json"', output_2)


# Generated at 2022-06-25 18:11:58.920209
# Unit test for function load_text_file
def test_load_text_file():
    filename = ""
    res = load_text_file(filename)
    assert res == None

# Generated at 2022-06-25 18:12:05.532701
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_request_items = RequestItems()
    test_arg = KeyValueArg('key', 'embed-json-file', 'value', 'value', 'embed-json-file')
    test_arg.key = 'key'
    test_arg.value = 'embed-json-file'
    test_arg.sep = 'embed-json-file'
    test_arg.orig = 'key:embed-json-file'
    result = process_data_embed_raw_json_file_arg(test_arg)
    print(result)

test_case_0()
test_process_data_embed_raw_json_file_arg()

# Generated at 2022-06-25 18:12:08.338836
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg('key', 'value', '\0', '')
    assert process_data_embed_raw_json_file_arg(item) is None


# Generated at 2022-06-25 18:12:16.789414
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Testing for absolute path
    test_arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "1.py", "C:/Users/tara/PycharmProjects/Httpie/httpie/1.py\ntext/plain")
    assert process_file_upload_arg(test_arg) == ("1.py", open("C:/Users/tara/PycharmProjects/Httpie/httpie/1.py", "rb"), "text/plain")
    # Testing for relative path
    test_arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "1.py", "httpie/1.py\ntext/plain")
    assert process_file_upload_arg(test_arg) == ("1.py", open("httpie/1.py", "rb"), "text/plain")
   

# Generated at 2022-06-25 18:12:18.974387
# Unit test for function load_text_file
def test_load_text_file():
    request_item_arg_1 = KeyValueArg('data', [''], '')
    load_text_file(request_item_arg_1)


# Generated at 2022-06-25 18:12:23.457423
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    value = process_data_embed_raw_json_file_arg(KeyValueArg())
    expected_value = {}
    if value != expected_value:
        print('test_process_data_embed_raw_json_file_arg failed')
        print('actual value: ' + str(value))
        print('expected value: ' + str(expected_value))


# Generated at 2022-06-25 18:12:27.280572
# Unit test for function load_text_file
def test_load_text_file():
    # Test parameters
    path = "/var/www/index.html"
    
    # We expect the file content to be loaded
    try:
        file = open("test.txt", "r")
    except IOError as e:
        print("Error in load_text_file() test case 0")
    
    content = load_text_file(path)
    assert file.read() == content

# Generated at 2022-06-25 18:12:28.676464
# Unit test for function load_text_file
def test_load_text_file():
    contents = load_text_file(KeyValueArg('param', 'param_value'))

# Generated at 2022-06-25 18:13:14.098041
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        "test_arg",
        "key",
        "value",
        ";",
    )
    expected_result = (
        os.path.basename("test"),
        open(os.path.expanduser("test"), 'rb'),
        get_content_type("test") or None,
    )
    actual_result = process_file_upload_arg(arg)
    assert expected_result == actual_result


# Generated at 2022-06-25 18:13:17.978221
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item_arg_0 = KeyValueArg(key='key_0', value='value_0', sep='sep_0')
    value = process_data_embed_raw_json_file_arg(item_arg_0)
    assert value == 'value_0'

# Generated at 2022-06-25 18:13:21.873357
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, "foo", "a.txt")) == 'abc'
    assert load_text_file(KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, "foo", "b.txt")) == 'def'


# Generated at 2022-06-25 18:13:28.878890
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    test_file = RequestItems.from_args([KeyValueArg(orig='@request_file_upload.txt', key='@request_file_upload.txt', sep=SEPARATOR_FILE_UPLOAD, value='request_file_upload.txt')], as_form=False)
    assert(test_file.files['@request_file_upload.txt'][1].read() == b'Hello')
    test_file.files['@request_file_upload.txt'][1].close()


# Generated at 2022-06-25 18:13:31.883319
# Unit test for function load_text_file
def test_load_text_file():
    key_value_arg = KeyValueArg(key='test_key', sep='test_sep', value='test_value')
    text_file_content = load_text_file(key_value_arg)
    assert type(text_file_content) == str
    assert text_file_content == 'test_value'

# Generated at 2022-06-25 18:13:43.834533
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    kv_arg1 = KeyValueArg(sep='=', key='', value='{"Test":"Data"}')
    kv_arg2 = KeyValueArg(sep='=', key='', value='{"Test":"Data"}')

    text = 'Test file'
    with open('test_file.txt', 'w') as f:
        f.write(text)

    f = open('test_file.txt', 'rb')
    kv_arg3 = KeyValueArg(sep='@', key='', value=f)

    # Tests that process_data_embed_raw_json_file_arg with arg of type KeyValueArg returns a dict
    assert isinstance(process_data_embed_raw_json_file_arg(kv_arg1), dict)
    # Tests that process_data_embed_raw_json_file

# Generated at 2022-06-25 18:13:47.079078
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg("data", "~/httpie/data.json")
    request_data = load_text_file(item)
    assert(len(request_data) > 0)


# Generated at 2022-06-25 18:13:52.993774
# Unit test for function load_text_file
def test_load_text_file():
    f = os.path.join("tests", "data", "file.txt")
    item = KeyValueArg("a", "", f)

    data = load_text_file(item)
    print("Load file test: ", data)
    assert data == "Hello World"


# Generated at 2022-06-25 18:13:57.276981
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    line = "file1.txt"
    arg = KeyValueArg(arg=line, key="file1", sep=";", value="file1.txt")
    file_upload_return = process_file_upload_arg(arg)

    assert file_upload_return[0] == "file1.txt"
    assert file_upload_return[1].closed == False
    assert file_upload_return[2] == "text/plain"

# Generated at 2022-06-25 18:14:03.156402
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    request_items = RequestItems()
    arg_0 = KeyValueArg('file@',
                        './test/test_cli/test_data/test_response.txt')
    filemeta_0 = process_file_upload_arg(arg_0)
    assert filemeta_0 == \
        ("test_response.txt", open(
            os.path.expanduser(arg_0.value), 'rb'), '')
    request_items.files["file"] = filemeta_0

    arg_1 = KeyValueArg('file@',
                        './test/test_cli/test_data/test_response.txt;'
                        'application/json')
    filemeta_1 = process_file_upload_arg(arg_1)