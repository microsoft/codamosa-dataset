

# Generated at 2022-06-17 19:52:03.570696
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:05.385577
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(key='', value='', sep='')) == ''

# Generated at 2022-06-17 19:52:10.175225
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='value',
        orig='key:=@value'
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:52:19.572336
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/path/to/file', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file'
    assert f.read() == b'file contents'
    assert mime_type == 'text/plain'

    arg = KeyValueArg(key='file', value='/path/to/file;image/png', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file'
    assert f.read() == b'file contents'
    assert mime_type == 'image/png'

# Generated at 2022-06-17 19:52:22.383755
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/home/test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:52:30.385146
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        'file',
        'test.txt;image/png',
        '@',
        '@test.txt;image/png',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

# Generated at 2022-06-17 19:52:34.453278
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='/Users/jianxin/Desktop/test.json')
    print(process_data_embed_raw_json_file_arg(arg))


# Generated at 2022-06-17 19:52:40.376098
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')

# Generated at 2022-06-17 19:52:46.573665
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:50.121095
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:00.459421
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1}

# Generated at 2022-06-17 19:53:03.998287
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='data', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:06.613108
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/home/user/file.txt')
    assert load_text_file(item) == 'This is a test file.'

# Generated at 2022-06-17 19:53:11.948555
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='{"a":1, "b":2}',
        orig='data@{"a":1, "b":2}',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:53:13.530644
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@test.txt', '@test.txt')) == 'test'

# Generated at 2022-06-17 19:53:15.358580
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:19.211992
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read().decode() == 'test'


# Generated at 2022-06-17 19:53:24.369445
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:26.227456
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test'

# Generated at 2022-06-17 19:53:29.877847
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:39.508138
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:42.304708
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@/Users/joe/file.txt', '@', '@/Users/joe/file.txt')) == 'This is a test file'

# Generated at 2022-06-17 19:53:48.014110
# Unit test for function load_text_file
def test_load_text_file():
    # Test for valid file
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'
    # Test for invalid file
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test1.txt')
    with pytest.raises(ParseError):
        load_text_file(item)
    # Test for invalid file type
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test2.txt')
    with pytest.raises(ParseError):
        load_text_file(item)


# Generated at 2022-06-17 19:53:57.107175
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('', '', '')
    arg = KeyValueArg(key='', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', '', '')
    arg = KeyValueArg(key='', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', '', '')
    arg = KeyValueArg(key='', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)

# Generated at 2022-06-17 19:54:05.386084
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='/home/user/file.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), None)
    arg = KeyValueArg(key='', value='/home/user/file.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:54:08.446662
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:54:13.386644
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:22.474371
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/home/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/home/test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/home/test.txt;')

# Generated at 2022-06-17 19:54:24.903245
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:27.834754
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:54:38.049752
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:54:40.498015
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', value='value', sep=';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 19:54:49.195868
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('', None, None)

    arg = KeyValueArg(key='', value='file.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', None, None)

    arg = KeyValueArg(key='', value='file.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', None, None)

    arg = KeyValueArg(key='', value='file.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)

# Generated at 2022-06-17 19:54:52.999978
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', value='value', sep=':')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:54:55.297363
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:02.955357
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:55:12.963143
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg(
        'file', './test_file.txt', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(file_upload_arg) == (
        'test_file.txt', open('./test_file.txt', 'rb'), None)

    file_upload_arg = KeyValueArg(
        'file', './test_file.txt;text/plain', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(file_upload_arg) == (
        'test_file.txt', open('./test_file.txt', 'rb'), 'text/plain')

    file_upload_arg = KeyValueArg(
        'file', './test_file.txt;', SEPARATOR_FILE_UPLOAD)


# Generated at 2022-06-17 19:55:22.791416
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;text/html')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/html')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;')

# Generated at 2022-06-17 19:55:23.859694
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:26.594842
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:35.614572
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:38.211214
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/Users/jianzhao/Desktop/test.txt')
    print(load_text_file(item))


# Generated at 2022-06-17 19:55:40.931349
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:45.116765
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('', None, '')


# Generated at 2022-06-17 19:55:53.997358
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(
        key='',
        value='{}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(
        key='',
        value='{"a": "b"}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json

# Generated at 2022-06-17 19:55:58.049266
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:56:07.421373
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt;image/png',
        orig='file@/home/user/file.txt;image/png',
    )

# Generated at 2022-06-17 19:56:11.436818
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig=None,
        value=None
    )
    assert process_data_embed_raw_json_file_arg(arg) is None

# Generated at 2022-06-17 19:56:14.060119
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:17.538735
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')



# Generated at 2022-06-17 19:56:36.942799
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:56:45.103097
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'filename.txt', '@')
    assert process_file_upload_arg(arg) == ('filename.txt', 'file', None)
    arg = KeyValueArg('file', 'filename.txt;type=text/html', '@')
    assert process_file_upload_arg(arg) == ('filename.txt', 'file', 'text/html')
    arg = KeyValueArg('file', 'filename.txt;type=text/html', '@')
    assert process_file_upload_arg(arg) == ('filename.txt', 'file', 'text/html')
    arg = KeyValueArg('file', 'filename.txt;type=text/html', '@')
    assert process_file_upload_arg(arg) == ('filename.txt', 'file', 'text/html')
    arg = Key

# Generated at 2022-06-17 19:56:47.000605
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:00.085712
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/test.txt:image/jpeg', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg(key='file', value='/home/test.txt:', sep=SEPARATOR_FILE_UPLOAD)

# Generated at 2022-06-17 19:57:02.227979
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/tmp/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:06.385620
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:08.658487
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', sep='', value='test.txt')) == 'test\n'

# Generated at 2022-06-17 19:57:11.711169
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(None, None, None, None, 'test.txt')) == 'test'

# Generated at 2022-06-17 19:57:16.641753
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:57:23.375278
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.orig = '@'
    arg.value = '{"a": 1}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1}
    arg.value = '{"a": 1, "b": 2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}
    arg.value = '{"a": 1, "b": [1, 2, 3]}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": [1, 2, 3]}

# Generated at 2022-06-17 19:57:41.809954
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 19:57:43.000625
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:57:47.712792
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        '~/Downloads/test.txt',
        '@',
        '~/Downloads/test.txt',
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open('~/Downloads/test.txt', 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 19:57:52.677736
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', '~/test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('~/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:57.065612
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/home/user/test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:58:01.487108
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:58:05.160847
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'name': 'test'}

# Generated at 2022-06-17 19:58:07.201155
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:08.424347
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='=', key='test', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:10.473806
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('', '', '', '', '')) == ''

# Generated at 2022-06-17 19:58:30.931766
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', 'test.txt', None)
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', 'test.txt', 'image/png')

# Generated at 2022-06-17 19:58:35.102422
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:58:38.146775
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig=''
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:58:40.035300
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:58:42.183680
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:54.429969
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:58:57.818493
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:00.115997
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key=None, value='/Users/yueyue/Desktop/test.txt', sep=None, orig=None)
    print(load_text_file(item))

# Generated at 2022-06-17 19:59:07.677742
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

# Generated at 2022-06-17 19:59:12.270247
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:59:34.938695
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(key='', value='test.txt', sep='')) == 'test\n'

# Generated at 2022-06-17 19:59:42.828085
# Unit test for function load_text_file
def test_load_text_file():
    # Test for load_text_file
    # Test for normal case
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test\n'
    # Test for non-existing file
    try:
        load_text_file(KeyValueArg('test', 'test.txt1'))
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test.txt1\''
    # Test for non-text file
    try:
        load_text_file(KeyValueArg('test', 'test.png'))
    except ParseError as e:
        assert str(e) == '"test": cannot embed the content of "test.png", not a UTF8 or ASCII-encoded text file'


# Generated at 2022-06-17 19:59:44.657648
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(key='', value='test.txt', sep='=')) == 'test'

# Generated at 2022-06-17 19:59:46.826480
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:59:55.882243
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(
        key='',
        value='{}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(
        key='',
        value='{"a":1}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_

# Generated at 2022-06-17 20:00:01.497779
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test.txt'
    mime_type = 'text/plain'
    f = open(os.path.expanduser(filename), 'rb')
    assert process_file_upload_arg(KeyValueArg(filename, filename)) == (
        os.path.basename(filename),
        f,
        mime_type or get_content_type(filename),
    )


# Generated at 2022-06-17 20:00:04.162528
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:12.446311
# Unit test for function load_text_file

# Generated at 2022-06-17 20:00:15.613465
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        value='value',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 20:00:17.057757
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:01:19.620400
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/tmp/test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 20:01:24.371391
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:01:25.579951
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:01:29.692298
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='data@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:01:32.833717
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:01:34.868733
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test'


# Generated at 2022-06-17 20:01:36.661585
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:43.851798
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file', 'test.txt;text/html', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')

# Generated at 2022-06-17 20:01:47.648343
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:01:50.228967
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'