

# Generated at 2022-06-17 19:52:06.508349
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_RAW_JSON,
        value='{"a": 1, "b": 2}',
        orig='',
    )
    assert process_data_raw_json_embed_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:52:10.488659
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": "b"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:52:20.177318
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Test case 1
    arg = KeyValueArg(key='file', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    # Test case 2
    arg = KeyValueArg(key='file', sep='@', value='test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

    # Test case 3
    arg = KeyValueArg(key='file', sep='@', value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    # Test case 4
    arg = KeyValue

# Generated at 2022-06-17 19:52:26.209141
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:52:30.166843
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:33.058917
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@test.json', sep='@', key='', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 'b'}

# Generated at 2022-06-17 19:52:37.910672
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:47.495111
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg("test.txt", "test.txt")
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), None)
    arg = KeyValueArg("test.txt", "test.txt;text/plain")
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "text/plain")
    arg = KeyValueArg("test.txt", "test.txt;")
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "")


# Generated at 2022-06-17 19:52:54.517591
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test 1
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/joe/Desktop/test.json',
        orig='@/Users/joe/Desktop/test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2}

    # Test 2
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/joe/Desktop/test.json',
        orig='@/Users/joe/Desktop/test.json'
    )
    result = process_data_embed_raw_json_file_

# Generated at 2022-06-17 19:52:59.691998
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:15.098103
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(orig='@test.json', sep='@', key='', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}
    # Test for invalid json file
    arg = KeyValueArg(orig='@test.json', sep='@', key='', value='test1.json')
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"@test.json": Expecting value: line 1 column 1 (char 0)'
    # Test for invalid json file path
    arg = KeyValueArg(orig='@test.json', sep='@', key='', value='test2.json')

# Generated at 2022-06-17 19:53:18.474997
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/Users/yunfeng/Desktop/test.txt')
    print(load_text_file(item))

# Generated at 2022-06-17 19:53:23.325175
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test_data.json',
        orig=''
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:25.558005
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:36.988519
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.value = '{"a":1}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1}
    arg.value = '{"a":1, "b":2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1, "b":2}
    arg.value = '{"a":1, "b":2, "c":3}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1, "b":2, "c":3}

# Generated at 2022-06-17 19:53:40.735379
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:53:43.940836
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:45.385026
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:49.124453
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '', '', '')
    arg.value = '{"a":1}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1}

# Generated at 2022-06-17 19:53:54.345296
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg(
        'file',
        'test.txt',
        SEPARATOR_FILE_UPLOAD,
    )
    assert process_file_upload_arg(file_upload_arg) == (
        'test.txt',
        open(os.path.expanduser('test.txt'), 'rb'),
        'text/plain',
    )

    file_upload_arg = KeyValueArg(
        'file',
        'test.txt;text/html',
        SEPARATOR_FILE_UPLOAD,
    )
    assert process_file_upload_arg(file_upload_arg) == (
        'test.txt',
        open(os.path.expanduser('test.txt'), 'rb'),
        'text/html',
    )

# Generated at 2022-06-17 19:54:08.434496
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'test'
    f.close()

    arg = KeyValueArg(key='', value='/tmp/test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/png'
    assert f.read() == b'test'
    f.close()


# Generated at 2022-06-17 19:54:11.706886
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep='')
    item.value = 'test.txt'
    item.orig = 'test.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:17.622430
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'foo.txt', '@')
    assert process_file_upload_arg(arg) == ('foo.txt', open('foo.txt', 'rb'), None)

    arg = KeyValueArg('file', 'foo.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('foo.txt', open('foo.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:54:21.656578
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:25.144960
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:54:28.831714
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@test.json', key='@test.json', sep='@', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:31.474980
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:35.724555
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:54:38.633818
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="test", key="test", sep=":", value="test.txt")
    assert load_text_file(item) == "test"

# Generated at 2022-06-17 19:54:40.828724
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('@test.txt', '@test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:52.155544
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test\n'


# Generated at 2022-06-17 19:55:00.870411
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(
        key='',
        value='test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@test.txt'
    )
    assert load_text_file(item) == 'test\n'

    # Test for file not found
    item = KeyValueArg(
        key='',
        value='test_not_found.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@test_not_found.txt'
    )

# Generated at 2022-06-17 19:55:05.014021
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:08.216426
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', value='value', sep=';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 19:55:16.686714
# Unit test for function load_text_file

# Generated at 2022-06-17 19:55:22.063531
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/png')

# Generated at 2022-06-17 19:55:30.154964
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt',
        value='/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt;image/png',
        value='/home/user/file.txt;image/png',
    )

# Generated at 2022-06-17 19:55:34.562554
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:37.557819
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:42.019673
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/joe/Desktop/test.json',
        orig='@/Users/joe/Desktop/test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:55:53.143382
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:56.091635
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', sep='@', key='@', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:55:59.537962
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/home/user/file.txt')
    assert load_text_file(item) == 'file content'

# Generated at 2022-06-17 19:56:02.251417
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', key='', value='test.txt', sep='@')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:09.285996
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg(
        key='file',
        value='/home/user/file.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt'
    )
    file_upload_arg_with_type = KeyValueArg(
        key='file',
        value='/home/user/file.txt;text/plain',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt;text/plain'
    )
    assert process_file_upload_arg(file_upload_arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:56:11.641652
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:16.665768
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read().decode() == 'test'


# Generated at 2022-06-17 19:56:19.630687
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig="", key="", sep="", value="test.txt")) == "test\n"

# Generated at 2022-06-17 19:56:28.674872
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/test.txt;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:56:39.286944
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'file.txt', '@')
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'file.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'file.txt;', '@')
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'file.txt;text/plain;', '@')

# Generated at 2022-06-17 19:57:00.479427
# Unit test for function load_text_file
def test_load_text_file():
    test_file = 'test_file.txt'
    test_file_content = 'test file content'
    with open(test_file, 'w') as f:
        f.write(test_file_content)
    assert load_text_file(KeyValueArg('', '', '', test_file)) == test_file_content
    os.remove(test_file)

# Generated at 2022-06-17 19:57:02.275743
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig="test", sep="=", key="test", value="test.txt")) == "test"

# Generated at 2022-06-17 19:57:14.751788
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:57:18.918242
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '')
    arg.key = 'test'
    arg.value = '{"a": 1, "b": 2}'
    arg.orig = 'test={"a": 1, "b": 2}'
    arg.sep = SEPARATOR_DATA_RAW_JSON
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:57:20.382412
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', value='test', sep=';')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:25.027297
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/lucas/Documents/test.json',
        orig='@/Users/lucas/Documents/test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {
        "name": "Lucas",
        "age": "24",
        "gender": "male",
        "hobbies": [
            "coding",
            "reading",
            "gaming"
        ]
    }

# Generated at 2022-06-17 19:57:27.863747
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:33.885642
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        value='/home/user/test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/test.txt',
    )
    result = process_file_upload_arg(arg)
    assert result == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:37.250412
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:38.733351
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:57:59.637357
# Unit test for function load_text_file
def test_load_text_file():
    path = "test.txt"
    with open(os.path.expanduser(path), 'wb') as f:
        f.write(b"hello world")
    item = KeyValueArg(key="test", value="test.txt", sep="@")
    assert load_text_file(item) == "hello world"
    os.remove(path)


# Generated at 2022-06-17 19:58:03.639077
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:09.167276
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:14.196219
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:58:16.080876
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:19.443980
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '', '', '', '', '')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:21.837419
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        key='test',
        value='test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@test.txt',
    )
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:30.576846
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test.txt'
    mime_type = 'text/plain'
    arg = KeyValueArg(sep=SEPARATOR_FILE_UPLOAD, key='test', value=filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type)
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), mime_type)
    arg = KeyValueArg(sep=SEPARATOR_FILE_UPLOAD, key='test', value=filename)
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:34.460756
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:40.146265
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:59:08.924116
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')



# Generated at 2022-06-17 19:59:13.130051
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:16.867693
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:22.485457
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='key',
        value='value',
        orig='key:=@value',
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:59:26.030799
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(test_arg) == {'test': 'test'}

# Generated at 2022-06-17 19:59:30.627284
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:35.199676
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read().decode() == 'test'

# Generated at 2022-06-17 19:59:38.340492
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:41.459079
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:53.256956
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/home/user/file.txt;image/png',
        orig='file@/home/user/file.txt;image/png',
    )

# Generated at 2022-06-17 20:00:34.254285
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')

# Generated at 2022-06-17 20:00:35.576738
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test'

# Generated at 2022-06-17 20:00:40.120546
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:00:44.745503
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:00:52.253162
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:00:56.095414
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='a', key='a', value='a', sep='a')) == 'a'

# Generated at 2022-06-17 20:01:00.603037
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='test',
        value='test.json',
        orig='test@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'key': 'value'}

# Generated at 2022-06-17 20:01:03.052198
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', key='', sep='', value='/home/joe/test.txt')) == 'This is a test file\n'

# Generated at 2022-06-17 20:01:08.034945
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 20:01:12.779823
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        key='test',
        value='test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@test.txt'
    )
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:43.565434
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:01:45.399910
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:01:51.233033
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="file", value="test.txt", sep="@")
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "text/plain")


# Generated at 2022-06-17 20:01:59.776890
# Unit test for function load_text_file