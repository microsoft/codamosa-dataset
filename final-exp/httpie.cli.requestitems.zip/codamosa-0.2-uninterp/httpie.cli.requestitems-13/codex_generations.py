

# Generated at 2022-06-17 19:52:04.810138
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:52:09.844295
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 19:52:13.973629
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '', '', '', '')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:18.942983
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'

# Generated at 2022-06-17 19:52:23.278581
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'name': 'test'}

# Generated at 2022-06-17 19:52:27.804881
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:30.837452
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/tmp/test.txt')
    assert load_text_file(item) == 'test\n'


# Generated at 2022-06-17 19:52:34.337763
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key=None, sep=SEPARATOR_DATA_RAW_JSON, value='{"a": 1}')
    assert process_data_raw_json_embed_arg(arg) == {'a': 1}


# Generated at 2022-06-17 19:52:44.550704
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;')

# Generated at 2022-06-17 19:52:48.274561
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg("file@/home/user/file.txt")
    assert process_file_upload_arg(arg) == ("file.txt", open("/home/user/file.txt", "rb"), "text/plain")

# Generated at 2022-06-17 19:53:05.565519
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test/fixtures/test_json_file.json',
        orig='@test/fixtures/test_json_file.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3"
    }

    # Test for invalid json file

# Generated at 2022-06-17 19:53:10.984978
# Unit test for function load_text_file
def test_load_text_file():
    # Test for case of success
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'
    # Test for case of failure
    item = KeyValueArg('test', 'test', 'test')
    try:
        load_text_file(item)
    except ParseError:
        assert True
    else:
        assert False


# Generated at 2022-06-17 19:53:15.938015
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:19.220648
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:53:29.149806
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == ''
    arg = KeyValueArg(key='', value='{}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {}
    arg = KeyValueArg(key='', value='[]', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == []
    arg = KeyValueArg(key='', value='"a"', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == 'a'

# Generated at 2022-06-17 19:53:31.809950
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', sep='', key='', value='test.txt')) == 'hello world\n'

# Generated at 2022-06-17 19:53:36.153228
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:44.341129
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:52.759630
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": "b"}')
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": "b"}')
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": "b"}')
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": "b"}')

# Generated at 2022-06-17 19:53:55.373427
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-17 19:54:11.948098
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt',
        orig='test@test.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'

# Generated at 2022-06-17 19:54:15.457904
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:24.177368
# Unit test for function load_text_file
def test_load_text_file():
    # Test for a valid file
    item = KeyValueArg('test', 'test.txt', 'test.txt')
    assert load_text_file(item) == 'test'
    # Test for a non-existent file
    item = KeyValueArg('test', 'test1.txt', 'test1.txt')
    try:
        load_text_file(item)
    except ParseError:
        assert True
    # Test for a non-text file
    item = KeyValueArg('test', 'test2.png', 'test2.png')
    try:
        load_text_file(item)
    except ParseError:
        assert True


# Generated at 2022-06-17 19:54:28.186339
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.value = '{"a": 1, "b": 2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}


# Generated at 2022-06-17 19:54:30.257655
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test')) == 'test'

# Generated at 2022-06-17 19:54:41.045586
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;')

# Generated at 2022-06-17 19:54:47.112074
# Unit test for function load_text_file

# Generated at 2022-06-17 19:54:50.365481
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == 'test'

# Generated at 2022-06-17 19:54:59.915600
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/file.txt', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/file.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', value='/home/user/file.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:03.068982
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='=', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:18.949040
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/test.txt;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:23.543505
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:26.724289
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="", value="", sep="")
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:39.313446
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_FILE_UPLOAD,
        orig='@/tmp/test.txt',
        value='/tmp/test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_FILE_UPLOAD,
        orig='@/tmp/test.txt:text/plain',
        value='/tmp/test.txt:text/plain'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:42.014504
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:45.799335
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:47.115993
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:56.575381
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/tmp/test.txt',
        orig='file@/tmp/test.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'

# Generated at 2022-06-17 19:55:59.590514
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:07.996837
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html;', '@')

# Generated at 2022-06-17 19:56:27.705761
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')

# Generated at 2022-06-17 19:56:32.707013
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'foo.txt', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('foo.txt', open('foo.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'foo.txt;text/html', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('foo.txt', open('foo.txt', 'rb'), 'text/html')


# Generated at 2022-06-17 19:56:37.992134
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'

# Generated at 2022-06-17 19:56:41.399076
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:56:43.459170
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:47.280188
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.key = 'data'
    arg.value = '{"a": "b"}'
    arg.sep = '='
    assert process_data_embed_raw_json_file_arg(arg) == {"a": "b"}


# Generated at 2022-06-17 19:56:52.431488
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {"test": "test"}

# Generated at 2022-06-17 19:56:56.922562
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:57:00.557409
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:05.050609
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test_data.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:57:22.170991
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('name', 'value', ';')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:57:26.113094
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="key", value="value", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == "value"

# Generated at 2022-06-17 19:57:36.969317
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 19:57:40.036692
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:44.326958
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "foo": "bar",
        "baz": "qux",
        "nested": {
            "a": "b",
            "c": "d"
        },
        "empty": ""
    }

# Generated at 2022-06-17 19:57:48.590749
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 19:57:51.402489
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:57:55.800770
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:58.329062
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', key='', sep='', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:58:02.990746
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 19:58:29.925563
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:58:33.719797
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:58:37.208855
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:38.460360
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:43.078801
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key="key",
        value="value",
        sep=";",
        orig="key;value",
    )
    assert process_file_upload_arg(arg) == ("value", "key", None)
    arg = KeyValueArg(
        key="key",
        value="value;value2",
        sep=";",
        orig="key;value;value2",
    )
    assert process_file_upload_arg(arg) == ("value", "key", "value2")

# Generated at 2022-06-17 19:58:48.743582
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='data@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:59.053731
# Unit test for function load_text_file
def test_load_text_file():
    # test for normal case
    item = KeyValueArg(
        '-d',
        '@/Users/jian/Desktop/test.txt',
        '@/Users/jian/Desktop/test.txt',
        '@',
        '@/Users/jian/Desktop/test.txt',
    )
    assert load_text_file(item) == 'test'

    # test for error case
    item = KeyValueArg(
        '-d',
        '@/Users/jian/Desktop/test.txt',
        '@/Users/jian/Desktop/test.txt',
        '@',
        '@/Users/jian/Desktop/test.txt',
    )
    try:
        load_text_file(item)
    except ParseError:
        assert True

# Generated at 2022-06-17 19:59:10.100561
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep='')
    item.value = 'test_data/test_file.txt'
    item.orig = 'test_data/test_file.txt'
    assert load_text_file(item) == 'test_file_content\n'
    item.value = 'test_data/test_file_not_exist.txt'
    item.orig = 'test_data/test_file_not_exist.txt'
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test_data/test_file_not_exist.txt": [Errno 2] No such file or directory: \'test_data/test_file_not_exist.txt\''

# Generated at 2022-06-17 19:59:13.679125
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:15.993216
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:00:06.831507
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:00:08.098946
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:18.305437
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', value='/home/test.txt;', sep=SEPARATOR_FILE_UPLOAD)

# Generated at 2022-06-17 20:00:20.931677
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', key='', value='test.txt', sep='')) == 'test'

# Generated at 2022-06-17 20:00:24.284585
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:00:29.994308
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt',
        orig='test@test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 20:00:36.529335
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/path/to/file', sep='@')
    assert process_file_upload_arg(arg) == ('file', open('/path/to/file', 'rb'), None)

    arg = KeyValueArg(key='file', value='/path/to/file;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('file', open('/path/to/file', 'rb'), 'text/plain')

    arg = KeyValueArg(key='file', value='/path/to/file;', sep='@')
    assert process_file_upload_arg(arg) == ('file', open('/path/to/file', 'rb'), '')


# Generated at 2022-06-17 20:00:48.562894
# Unit test for function load_text_file

# Generated at 2022-06-17 20:00:51.941898
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', key='', sep='', value='test.txt')) == 'test\n'

# Generated at 2022-06-17 20:01:02.878112
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')