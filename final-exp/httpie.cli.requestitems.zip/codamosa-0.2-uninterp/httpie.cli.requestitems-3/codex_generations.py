

# Generated at 2022-06-17 19:51:57.344513
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:08.357427
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg(
        key='file',
        value='/home/user/file.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt',
    )
    file_upload_arg_with_type = KeyValueArg(
        key='file',
        value='/home/user/file.txt;text/plain',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt;text/plain',
    )
    assert process_file_upload_arg(file_upload_arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )
    assert process_file_upload_arg

# Generated at 2022-06-17 19:52:16.466294
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg('test', 'test.json', ':')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

    # Test for invalid json file
    arg = KeyValueArg('test', 'test.txt', ':')
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"test:test.txt": Expecting value: line 1 column 1 (char 0)'

    # Test for invalid json file path
    arg = KeyValueArg('test', 'test1.json', ':')

# Generated at 2022-06-17 19:52:20.664976
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:52:23.547492
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:25.022245
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:52:31.836751
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')

# Generated at 2022-06-17 19:52:39.668715
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='{"a": 1, "b": [1, 2, 3], "c": {"d": "e"}}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        'a': 1,
        'b': [1, 2, 3],
        'c': {'d': 'e'}
    }

# Generated at 2022-06-17 19:52:43.928378
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    print(process_file_upload_arg(arg))


# Generated at 2022-06-17 19:52:49.004417
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key=None, sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'key': 'value'}

# Generated at 2022-06-17 19:53:02.208916
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:53:04.757591
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:08.428346
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": "b"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}


# Generated at 2022-06-17 19:53:11.404921
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:18.730018
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        '-F',
        'file=@/home/user/file.txt',
        'file',
        '@/home/user/file.txt',
        '=',
        '@',
    )
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:21.814637
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', sep='=', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:53:25.026049
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:28.118426
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', sep='', key='', value='/Users/jie/Desktop/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:30.628065
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='',
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:53:37.209394
# Unit test for function load_text_file
def test_load_text_file():
    # Test for file not found
    try:
        load_text_file(KeyValueArg(key='', value='', orig='', sep=''))
    except ParseError as e:
        assert str(e) == '"": [Errno 2] No such file or directory: \'\''

    # Test for non-UTF8 or ASCII-encoded text file
    try:
        load_text_file(KeyValueArg(key='', value='', orig='', sep=''))
    except ParseError as e:
        assert str(e) == '"": cannot embed the content of "", not a UTF8 or ASCII-encoded text file'

# Generated at 2022-06-17 19:53:53.269454
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:53:56.814413
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/Users/yunzhe/Desktop/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:58.971583
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', sep='=', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:54:01.023969
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:02.871225
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('a', 'b', 'c')
    assert process_data_embed_raw_json_file_arg(arg) == 'c'

# Generated at 2022-06-17 19:54:08.500542
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:19.244579
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('test.txt', 'test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('test.txt', 'test.txt;text/html')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('test.txt', 'test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('test.txt', 'test.txt;text/html;')

# Generated at 2022-06-17 19:54:27.181323
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@test.txt',
        value='test.txt'
    )
    assert load_text_file(item) == 'test'

    # Test for file not found
    item = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@test.txt',
        value='test1.txt'
    )
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"@test.txt": [Errno 2] No such file or directory: \'test1.txt\''

    # Test for not

# Generated at 2022-06-17 19:54:37.519671
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:54:42.247630
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        value='test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:55:05.955539
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    arg.value = 'test.txt'
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg.value = 'test.txt;image/png'
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg.value = 'test.txt;'
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg.value = 'test.txt;;'

# Generated at 2022-06-17 19:55:09.192464
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:55:14.283575
# Unit test for function load_text_file
def test_load_text_file():
    # Create a file
    f = open("test.txt", "w+")
    f.write("This is a test file")
    f.close()
    # Test load_text_file function
    item = KeyValueArg(orig="test.txt", sep="@", key="test.txt", value="test.txt")
    assert load_text_file(item) == "This is a test file"
    # Delete the file
    os.remove("test.txt")


# Generated at 2022-06-17 19:55:17.160180
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='--data-raw', key='data-raw', sep='=', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:21.714789
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '')
    arg.key = 'foo'
    arg.value = 'bar'
    arg.orig = 'foo=bar'
    arg.sep = '='
    arg.orig_sep = '='
    arg.orig_key = 'foo'
    arg.orig_value = 'bar'
    assert process_data_embed_raw_json_file_arg(arg) == 'bar'

# Generated at 2022-06-17 19:55:25.886333
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:29.999333
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:33.494890
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:35.548624
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:55:37.556789
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="", sep="", key="", value="")
    assert load_text_file(item) == ""

# Generated at 2022-06-17 19:55:56.694579
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='', orig='')
    process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-17 19:55:59.740139
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('', '', '', '', '', '', '', '', '', '')) == ''

# Generated at 2022-06-17 19:56:08.098571
# Unit test for function load_text_file
def test_load_text_file():
    # Test case 1:
    # Input:
    #   item = KeyValueArg(orig='@test.txt', key='@test.txt', sep='@', value='test.txt')
    # Expected output:
    #   'test'
    item = KeyValueArg(orig='@test.txt', key='@test.txt', sep='@', value='test.txt')
    assert load_text_file(item) == 'test'

    # Test case 2:
    # Input:
    #   item = KeyValueArg(orig='@test.txt', key='@test.txt', sep='@', value='test.txt')
    # Expected output:
    #   'test'
    item = KeyValueArg(orig='@test.txt', key='@test.txt', sep='@', value='test.txt')


# Generated at 2022-06-17 19:56:09.584776
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:12.949720
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '', '')
    item.value = 'test_file.txt'
    assert load_text_file(item) == 'test_file_content'

# Generated at 2022-06-17 19:56:15.782673
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@/Users/zhaoyang/Desktop/test.txt')) == 'test'

# Generated at 2022-06-17 19:56:20.467010
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='data', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:56:21.846029
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:30.045153
# Unit test for function load_text_file
def test_load_text_file():
    # Test for file that does not exist
    item = KeyValueArg(
        key='test',
        value='/tmp/test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@/tmp/test.txt',
    )
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"@/tmp/test.txt": [Errno 2] No such file or directory: \'/tmp/test.txt\''
    # Test for file that exists
    item = KeyValueArg(
        key='test',
        value='/tmp/test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@/tmp/test.txt',
    )
   

# Generated at 2022-06-17 19:56:34.020547
# Unit test for function load_text_file
def test_load_text_file():
    from httpie.cli.argtypes import KeyValueArg
    item = KeyValueArg(orig="-d", sep="-d", key="", value="C:\\Users\\Administrator\\Desktop\\test.txt")
    assert load_text_file(item) == "test"

# Generated at 2022-06-17 19:57:01.017413
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='test', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:05.707918
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep='')
    item.value = 'test_file.txt'
    item.orig = 'test_file.txt'
    assert load_text_file(item) == 'test_file.txt'


# Generated at 2022-06-17 19:57:07.282851
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test')) == 'test'

# Generated at 2022-06-17 19:57:11.110197
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:14.790685
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test_data/test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:57:17.037003
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', key='', value='', sep='')) == ''

# Generated at 2022-06-17 19:57:23.711210
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 19:57:27.622170
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='value')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:57:38.774580
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/tmp/test.txt;image/jpeg', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg(key='file', value='/tmp/test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), '')

# Generated at 2022-06-17 19:57:45.242083
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test/data/test.json',
        orig='@test/data/test.json'
    )

# Generated at 2022-06-17 19:58:35.743918
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test", "test.txt")) == "test"

# Generated at 2022-06-17 19:58:38.739702
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '')
    item.value = './test/test_load_text_file.txt'
    assert load_text_file(item) == 'test_load_text_file'

# Generated at 2022-06-17 19:58:41.661308
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:58:53.978550
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:58:56.578894
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:59:04.123946
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg(key='file', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:59:07.678596
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/home/user/file.txt')
    assert load_text_file(item) == 'This is a text file.\n'

# Generated at 2022-06-17 19:59:18.331683
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(key='', value='test_data/test_json.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

    # Test for invalid json file
    arg = KeyValueArg(key='', value='test_data/test_json_invalid.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    with pytest.raises(ParseError):
        process_data_embed_raw_json_file_arg(arg)

    # Test for non-existing file

# Generated at 2022-06-17 19:59:28.161456
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;text/plain')
    assert process_file_upload_arg(arg) == ('value', 'value', 'text/plain')
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;text/plain;')
    assert process_file_upload_

# Generated at 2022-06-17 19:59:37.771395
# Unit test for function load_text_file