

# Generated at 2022-06-17 19:52:06.248899
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:52:07.802439
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig="", key="", sep="", value="test.txt")) == "test"

# Generated at 2022-06-17 19:52:09.554455
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:52:14.421284
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:52:25.670512
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/jpeg', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/jpeg;', '@')

# Generated at 2022-06-17 19:52:28.944603
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:52:39.438390
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(
        key='test',
        value='test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='test@test.txt'
    )
    assert load_text_file(item) == 'test'

    # Test for file not exist
    item = KeyValueArg(
        key='test',
        value='test1.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='test@test1.txt'
    )
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test@test1.txt": [Errno 2] No such file or directory: \'test1.txt\''



# Generated at 2022-06-17 19:52:45.261839
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:54.987900
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.value = '{"key": "value"}'
    assert process_data_embed_raw_json_file_arg(arg) == {"key": "value"}
    arg.value = '{"key": "value", "key2": "value2"}'
    assert process_data_embed_raw_json_file_arg(arg) == {"key": "value", "key2": "value2"}
    arg.value = '{"key": "value", "key2": "value2", "key3": "value3"}'
    assert process_data_embed_raw_json_file_arg(arg) == {"key": "value", "key2": "value2", "key3": "value3"}

# Generated at 2022-06-17 19:53:01.402198
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:53:15.898869
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {}

    arg = KeyValueArg(key='', value='{}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {}

    arg = KeyValueArg(key='', value='{"a": 1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}

    arg = KeyValueArg(key='', value='{"a": 1, "b": 2}', sep=SEPARATOR_DATA_RAW_JSON)

# Generated at 2022-06-17 19:53:19.800011
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": 1}')
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}


# Generated at 2022-06-17 19:53:28.751039
# Unit test for function load_text_file
def test_load_text_file():
    # Create a temporary file
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b"Hello World")
    f.close()

    # Test

# Generated at 2022-06-17 19:53:31.077850
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:33.220388
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": 1}')
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}

# Generated at 2022-06-17 19:53:34.777994
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:37.708820
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('key', 'value', ';')
    value = process_data_raw_json_embed_arg(arg)
    assert value == 'value'


# Generated at 2022-06-17 19:53:41.471983
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}


# Generated at 2022-06-17 19:53:43.365352
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:45.416535
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:53:56.281792
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:00.163532
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:02.911089
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:08.948435
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test_data/test.json',
        orig='test@test_data/test.json',
    )
    assert process_data_embed_raw_json_file_arg(test_arg) == {'test': 'test'}

# Generated at 2022-06-17 19:54:19.593615
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 19:54:25.415031
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file@/home/user/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file@/home/user/file.txt;image/jpeg')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/jpeg')


# Generated at 2022-06-17 19:54:28.670469
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:32.134203
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='data@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:34.035176
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'a.txt')) == 'a'

# Generated at 2022-06-17 19:54:37.441472
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('filename', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:54:56.173621
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        sep='@',
        value='test.json',
        orig='data@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:58.289612
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test_data/test.txt', '=')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:55:06.619978
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/file.txt', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/file.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', value='/home/user/file.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:09.361756
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test.txt', 'test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:12.049057
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:14.489309
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg("test", "test.json", ":")
    assert process_data_embed_raw_json_file_arg(test_arg) == {"test": "test"}

# Generated at 2022-06-17 19:55:20.057438
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt',
        value='/home/user/file.txt'
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain'
    )

# Generated at 2022-06-17 19:55:25.892283
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/test.txt',
        orig='file@/home/user/test.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'Hello World'

# Generated at 2022-06-17 19:55:30.813129
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:55:35.151469
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}


# Generated at 2022-06-17 19:56:02.968964
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt;image/png',
        orig='file@/home/user/file.txt;image/png',
    )

# Generated at 2022-06-17 19:56:06.008414
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:11.116766
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'This is a test file.\n'

# Generated at 2022-06-17 19:56:16.040563
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.txt"
    mime_type = "text/plain"
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "test.txt", "test.txt;text/plain")
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), mime_type)

# Generated at 2022-06-17 19:56:26.495761
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/plain;', sep='@')

# Generated at 2022-06-17 19:56:29.051421
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read().decode() == 'test\n'

# Generated at 2022-06-17 19:56:39.601395
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='testdata/test.json',
        orig='@testdata/test.json',
    )

# Generated at 2022-06-17 19:56:42.754618
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='-d', sep='=', key=None, value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:47.920183
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', './test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('./test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', './test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('./test.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 19:56:52.022004
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    arg.value = 'test.txt'
    assert process_file_upload_arg(arg) == ('test.txt', '', '')
    arg.value = 'test.txt;image/png'
    assert process_file_upload_arg(arg) == ('test.txt', '', 'image/png')

# Generated at 2022-06-17 19:57:40.903327
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="", value="", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:43.267462
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:57:45.804167
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:49.592548
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:54.362192
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:58.918557
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:58:07.586633
# Unit test for function load_text_file

# Generated at 2022-06-17 19:58:11.670811
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:14.612006
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='test.txt')
    assert load_text_file(item) == 'Hello world\n'

# Generated at 2022-06-17 19:58:19.091500
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:58:51.881192
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('filename.txt', 'filename.txt')
    assert process_file_upload_arg(arg) == ('filename.txt', open('filename.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:53.293167
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:55.258547
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('--data', '@test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:59.237287
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='test',
        value='test.json',
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:59:03.035970
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='file', sep='@', key='file', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:07.720113
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='value',
        orig='key:=@value'
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:59:11.662605
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='--data-raw', key='', value='@test.txt', sep='=')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:14.757828
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg("filename", "test.txt", ":")
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "text/plain")

# Generated at 2022-06-17 19:59:16.864891
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key=None, sep=None, orig=None, value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:20.438613
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='key',
        value='value'
    )
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 20:00:39.042126
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:00:48.817866
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test.txt'
    mime_type = 'text/plain'
    f = open(os.path.expanduser(filename), 'rb')
    assert process_file_upload_arg(KeyValueArg(filename, filename)) == (
        os.path.basename(filename),
        f,
        mime_type or get_content_type(filename),
    )
    assert process_file_upload_arg(KeyValueArg(filename, filename + ';' + mime_type)) == (
        os.path.basename(filename),
        f,
        mime_type or get_content_type(filename),
    )


# Generated at 2022-06-17 20:01:01.577178
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg('file', 'test.txt;text/plain', '@')

# Generated at 2022-06-17 20:01:11.225520
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')

# Generated at 2022-06-17 20:01:21.919257
# Unit test for function load_text_file

# Generated at 2022-06-17 20:01:26.456384
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='{"a": "b"}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@{"a": "b"}',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 20:01:28.007736
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(None, None, 'test.txt')) == 'test'

# Generated at 2022-06-17 20:01:31.870066
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 20:01:35.316409
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:01:39.438144
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'file content'