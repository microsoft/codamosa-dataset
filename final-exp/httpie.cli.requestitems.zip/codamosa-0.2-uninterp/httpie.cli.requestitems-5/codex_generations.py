

# Generated at 2022-06-17 19:52:05.731103
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', value='test.txt', sep='=')) == 'test'

# Generated at 2022-06-17 19:52:10.139912
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@test.json', sep='@', key='', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}


# Generated at 2022-06-17 19:52:16.364042
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt',
        orig='test@test.txt',
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open(os.path.expanduser('test.txt'), 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 19:52:27.491979
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(key='', value='test_data/test.json', sep='=')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

    # Test for invalid json file
    arg = KeyValueArg(key='', value='test_data/test_invalid.json', sep='=')
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError:
        assert True
    else:
        assert False

    # Test for non-json file
    arg = KeyValueArg(key='', value='test_data/test_non_json.txt', sep='=')

# Generated at 2022-06-17 19:52:30.583872
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@/home/user/test.txt', sep='@', key='', value='/home/user/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:40.488715
# Unit test for function load_text_file

# Generated at 2022-06-17 19:52:44.984048
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:52:51.021797
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

# Generated at 2022-06-17 19:52:52.710476
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(None, None, None, 'test.txt')) == 'test'

# Generated at 2022-06-17 19:52:59.849053
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt',
        orig='test@test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt;image/jpeg',
        orig='test@test.txt;image/jpeg'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')

# Generated at 2022-06-17 19:53:08.281311
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:16.371959
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt'
    )
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt;image/png',
        orig='file@/home/user/file.txt;image/png'
    )

# Generated at 2022-06-17 19:53:25.973044
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(key='file', value='/tmp/test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/png'
    assert f.read() == b'hello world'
    f.close()

# Generated at 2022-06-17 19:53:29.664286
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": 1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}

# Generated at 2022-06-17 19:53:32.508475
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('data', '@test.json', '@')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:43.178120
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/path/to/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/path/to/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/path/to/file.txt;image/png')
    assert process_file_upload_arg(arg) == ('file.txt', open('/path/to/file.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/path/to/file.txt;')

# Generated at 2022-06-17 19:53:47.072893
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": "b"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:53:51.580279
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:55.271275
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": "b"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:53:58.337874
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('', '', '')


# Generated at 2022-06-17 19:54:13.772506
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/yunfeng/Desktop/test.json',
        orig='@/Users/yunfeng/Desktop/test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:22.529096
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'Hello World!'
    f.close()

    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/home/user/file.txt;text/plain',
        orig='file@/home/user/file.txt;text/plain',
    )

# Generated at 2022-06-17 19:54:30.049663
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        value='/Users/joe/Documents/test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/Users/joe/Documents/test.txt'
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open('/Users/joe/Documents/test.txt', 'rb'),
        'text/plain'
    )

# Generated at 2022-06-17 19:54:41.282415
# Unit test for function load_text_file
def test_load_text_file():
    # Test case 1: file exists and is a text file
    item = KeyValueArg('test.txt', 'test.txt', '=')
    assert load_text_file(item) == 'test'

    # Test case 2: file exists and is not a text file
    item = KeyValueArg('test.png', 'test.png', '=')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test.png": cannot embed the content of "test.png", not a UTF8 or ASCII-encoded text file'

    # Test case 3: file does not exist
    item = KeyValueArg('test.txt', 'test.txt', '=')

# Generated at 2022-06-17 19:54:50.408285
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), None)
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')

# Generated at 2022-06-17 19:54:56.013386
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='value'
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:54:58.245411
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', value='test.txt', sep='=')) == 'test'

# Generated at 2022-06-17 19:55:06.561494
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:55:10.634812
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:55:11.878601
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:23.725311
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:26.002805
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:32.228050
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test_data/test_json.json',
        orig='@test_data/test_json.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2}



# Generated at 2022-06-17 19:55:36.654217
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')



# Generated at 2022-06-17 19:55:37.957127
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:43.777014
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)

    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;')
    assert process_file_upload_arg(arg) == ('value', 'value', None)

    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;mime_type')
    assert process_file_upload_arg(arg) == ('value', 'value', 'mime_type')

# Generated at 2022-06-17 19:55:52.002405
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    expected = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    assert process_data_embed_raw_json_file_arg(arg) == expected

# Generated at 2022-06-17 19:55:56.822638
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:56:02.407229
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '')
    arg.key = 'test'
    arg.value = 'test'
    arg.orig = 'test'
    arg.sep = ':'
    assert process_data_embed_raw_json_file_arg(arg) == 'test'

# Generated at 2022-06-17 19:56:14.685873
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt',
        orig='file@/tmp/test.txt',
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open('/tmp/test.txt', 'rb'),
        'text/plain',
    )
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt;image/png',
        orig='file@/tmp/test.txt;image/png',
    )

# Generated at 2022-06-17 19:56:23.327844
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:31.238602
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:56:33.701055
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="", key="", sep="", value="")
    assert load_text_file(item) == ""

# Generated at 2022-06-17 19:56:35.882382
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', key='', sep='', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:56:39.006202
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='')
    item.value = './test_data/test.txt'
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:56:40.918951
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:42.419195
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:43.753512
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:51.688150
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
   

# Generated at 2022-06-17 19:57:00.916413
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'key4': 'value4',
            'key5': 'value5',
            'key6': {
                'key7': 'value7',
                'key8': 'value8'
            }
        }
    }

# Generated at 2022-06-17 19:57:21.601285
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 19:57:24.785796
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='=', key='test', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:26.080662
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:57:31.974699
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg(key='key', value='value;type', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:57:38.002855
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

# Generated at 2022-06-17 19:57:39.895844
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', sep='', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:57:44.451074
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 19:57:50.753690
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key=None, value='{"a":1}', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1}

# Generated at 2022-06-17 19:57:56.304507
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt;text/plain',
        orig='file@/home/user/file.txt;text/plain',
    )

# Generated at 2022-06-17 19:58:03.596171
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'

    arg = KeyValueArg(key='file', value='/tmp/test.txt;image/jpeg', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/jpeg'

# Generated at 2022-06-17 19:58:18.187146
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:23.419488
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:27.095383
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:58:28.683757
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:34.465299
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt',
        orig='test@test.txt',
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open(os.path.expanduser('test.txt'), 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 19:58:42.717034
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;')

# Generated at 2022-06-17 19:58:47.053526
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:52.049616
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep='')
    item.value = 'test_file.txt'
    item.orig = 'test_file.txt'
    assert load_text_file(item) == 'This is a test file.\n'

# Generated at 2022-06-17 19:58:57.686680
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='test',
        value='test.json',
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:58:59.800332
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:59:37.797944
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/png')

    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;')

# Generated at 2022-06-17 19:59:39.297734
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:43.668191
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:59:45.699619
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('key', 'value', ';')
    assert load_text_file(item) == 'value'

# Generated at 2022-06-17 19:59:47.892074
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test", "test.txt")) == "test"


# Generated at 2022-06-17 19:59:50.998031
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:55.726811
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:59.782756
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:00:04.679420
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 20:00:09.702615
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_upload_arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_FILE_UPLOAD,
        orig='@/tmp/test.txt',
        value='/tmp/test.txt',
    )
    assert process_file_upload_arg(file_upload_arg) == (
        'test.txt',
        open('/tmp/test.txt', 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 20:00:44.971674
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 20:00:47.605710
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '')
    item.value = 'test_file.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:00.953963
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test_data/test_json.json',
        orig='@test_data/test_json.json'
    )

# Generated at 2022-06-17 20:01:06.685476
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='{"a": "b"}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 20:01:16.199245
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test.txt'
    mime_type = 'text/plain'
    arg = KeyValueArg(key='test', value=filename, sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == (os.path.basename(filename), open(filename, 'rb'), mime_type)
    arg = KeyValueArg(key='test', value=filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type, sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == (os.path.basename(filename), open(filename, 'rb'), mime_type)

# Generated at 2022-06-17 20:01:27.205902
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '', '', '', '', '')
    arg.key = 'key'
    arg.value = 'value'
    arg.orig = 'orig'
    arg.sep = 'sep'
    arg.orig_sep = 'orig_sep'
    arg.orig_key = 'orig_key'
    arg.orig_value = 'orig_value'
    arg.is_flag = 'is_flag'
    arg.is_key_value = 'is_key_value'
    arg.is_key_only = 'is_key_only'
    arg.is_value_only = 'is_value_only'
    arg.is_empty_value = 'is_empty_value'
    arg.is_value_required

# Generated at 2022-06-17 20:01:29.117340
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', key='', sep='', value='test.txt')) == 'test'

# Generated at 2022-06-17 20:01:32.601495
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {"test": "test"}

# Generated at 2022-06-17 20:01:35.521460
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='-d', key='', value='/Users/jian/Desktop/test.txt', sep='-d')
    print(load_text_file(item))


# Generated at 2022-06-17 20:01:38.311099
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='~/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('~/test.txt', 'rb'), 'text/plain')