

# Generated at 2022-06-17 19:52:04.881142
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:52:10.981460
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:52:20.363268
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')

# Generated at 2022-06-17 19:52:23.501903
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:52:27.933788
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig=''
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:52:29.272660
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:52:31.718103
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 19:52:35.339138
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": "b"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:52:44.387030
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # test for normal case
    arg = KeyValueArg('test', 'test.json', '=@')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}
    # test for wrong file name
    arg = KeyValueArg('test', 'test.json1', '=@')
    with pytest.raises(ParseError):
        process_data_embed_raw_json_file_arg(arg)
    # test for wrong json format
    arg = KeyValueArg('test', 'test_wrong.json', '=@')
    with pytest.raises(ParseError):
        process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-17 19:52:49.469964
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='', orig_key='', orig_value='')
    item.value = './test_data/test_file.txt'
    assert load_text_file(item) == 'test file'

# Generated at 2022-06-17 19:52:58.129918
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a":1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}

# Generated at 2022-06-17 19:53:02.084146
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg('key', 'value;type', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:53:12.312548
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('', '', '', '', '', '')
    arg.key = 'key'
    arg.value = 'value'
    arg.orig = 'key:value'
    arg.sep = SEPARATOR_DATA_RAW_JSON
    assert process_data_raw_json_embed_arg(arg) == 'value'
    arg.value = '{"key":"value"}'
    assert process_data_raw_json_embed_arg(arg) == {'key': 'value'}
    arg.value = '{"key":"value", "key2":"value2"}'
    assert process_data_raw_json_embed_arg(arg) == {'key': 'value', 'key2': 'value2'}

# Generated at 2022-06-17 19:53:20.024664
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig=''
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "name": "John",
        "age": 30,
        "cars": [
            {"name": "Ford", "models": ["Fiesta", "Focus", "Mustang"]},
            {"name": "BMW", "models": ["320", "X3", "X5"]},
            {"name": "Fiat", "models": ["500", "Panda"]}
        ]
    }

    # Test for invalid json file

# Generated at 2022-06-17 19:53:23.991914
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 'b'}

# Generated at 2022-06-17 19:53:27.324112
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a":1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a":1}

# Generated at 2022-06-17 19:53:33.092285
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:36.382168
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}

# Generated at 2022-06-17 19:53:40.987667
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.txt"
    mime_type = "text/plain"
    arg = KeyValueArg(filename, SEPARATOR_FILE_UPLOAD, filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type)
    result = process_file_upload_arg(arg)
    assert result[0] == "test.txt"
    assert result[2] == "text/plain"


# Generated at 2022-06-17 19:53:42.807824
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:00.175369
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:03.835799
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:54:05.422551
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:08.070114
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a":1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:54:12.181015
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {"key1": "value1", "key2": "value2"}

# Generated at 2022-06-17 19:54:14.904336
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:18.008602
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:20.403358
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:25.661176
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:28.522017
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep='', orig='')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:55:26.582379
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:30.049125
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:41.377607
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(key='file', value='/tmp/test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/png'
    assert f.read() == b'hello world'
    f.close()


# Generated at 2022-06-17 19:55:45.594813
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('data', '@test.json', '@')
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:54.196351
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        'a': 1,
        'b': 2,
        'c': 3
    }

# Generated at 2022-06-17 19:55:56.543306
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:02.100035
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'test'


# Generated at 2022-06-17 19:56:04.324997
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test\n'


# Generated at 2022-06-17 19:56:06.076979
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='value')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:56:09.945844
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:56:44.251579
# Unit test for function load_text_file
def test_load_text_file():
    path = "./test_data/test_load_text_file.txt"
    item = KeyValueArg(key="", value=path, sep="", orig="")
    contents = load_text_file(item)
    assert contents == "test_load_text_file"


# Generated at 2022-06-17 19:56:58.355391
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('filename', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('filename', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('filename', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('filename', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 19:57:00.479249
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@test.txt', '@test.txt')) == 'test'

# Generated at 2022-06-17 19:57:01.916569
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:14.501068
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:57:17.127865
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:20.337462
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:26.037083
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 19:57:31.594115
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:57:41.206088
# Unit test for function load_text_file
def test_load_text_file():
    # Test for a valid file
    item = KeyValueArg(key='test', value='test.txt', sep='=')
    assert load_text_file(item) == 'This is a test file'

    # Test for a file that does not exist
    item = KeyValueArg(key='test', value='test2.txt', sep='=')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test=test2.txt": [Errno 2] No such file or directory: \'test2.txt\''

    # Test for a file that is not a text file
    item = KeyValueArg(key='test', value='test3.png', sep='=')

# Generated at 2022-06-17 19:58:12.564018
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:14.477610
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@test.txt', '@test.txt')) == 'test'

# Generated at 2022-06-17 19:58:16.353035
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:28.463265
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:58:31.563793
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:35.453342
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt',
        orig='test@test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:37.607281
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:58:38.866525
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('key', 'value')) == 'value'

# Generated at 2022-06-17 19:58:40.286437
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(key='', value='', sep='')) == ''

# Generated at 2022-06-17 19:58:43.424322
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@/Users/joe/test.txt', key='', sep='@', value='/Users/joe/test.txt')) == 'test\n'

# Generated at 2022-06-17 19:59:15.953601
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '', '', '', '', '', '')
    item.orig = 'test'
    item.value = 'test'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:19.257556
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/tmp/test.txt',
        orig='test@/tmp/test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:22.666665
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="", key="", sep="", value="")
    assert load_text_file(item) == ""

# Generated at 2022-06-17 19:59:25.817385
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@test.json', key='', sep='@', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:28.972104
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:33.659473
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        value='test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:59:34.859355
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("@test.txt")) == "test"

# Generated at 2022-06-17 19:59:37.318309
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep=';', key='test', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:40.868299
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:47.253255
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:00:55.481675
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', value='test', sep='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:00:56.430715
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:59.445804
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:01:09.825073
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 20:01:18.604169
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.value = './test_data/test_json_data.json'
    assert process_data_embed_raw_json_file_arg(arg) == {
        'name': 'John',
        'age': 30,
        'cars': [
            {'name': 'Ford', 'models': ['Fiesta', 'Focus', 'Mustang']},
            {'name': 'BMW', 'models': ['320', 'X3', 'X5']},
            {'name': 'Fiat', 'models': ['500', 'Panda']}
        ]
    }

# Generated at 2022-06-17 20:01:28.632015
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 20:01:31.761540
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', sep='', key='', value='/Users/zhaoyang/Desktop/test.txt')
    print(load_text_file(item))


# Generated at 2022-06-17 20:01:39.039736
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'file.txt', '@')
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'file.txt;image/jpeg', '@')
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg('file', 'file.txt;', '@')
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'file.txt;;', '@')

# Generated at 2022-06-17 20:01:42.495599
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('a', 'b', 'c')
    assert process_data_embed_raw_json_file_arg(arg) == 'c'

# Generated at 2022-06-17 20:01:45.603175
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='test.txt',
        orig='test@test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')