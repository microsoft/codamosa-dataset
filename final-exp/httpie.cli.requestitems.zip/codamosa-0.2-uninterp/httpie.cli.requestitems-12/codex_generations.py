

# Generated at 2022-06-17 19:52:02.088346
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:52:05.587329
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a":1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:52:09.289213
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": 1}')
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}

# Generated at 2022-06-17 19:52:11.874760
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:18.544844
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')


# Generated at 2022-06-17 19:52:22.919037
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:29.165614
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')

# Generated at 2022-06-17 19:52:39.629991
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep='', orig='')
    item.value = 'test_data/test_data.txt'
    assert load_text_file(item) == 'test_data\n'
    item.value = 'test_data/test_data.json'
    assert load_text_file(item) == '{"a": 1, "b": 2}\n'
    item.value = 'test_data/test_data.json'
    assert load_text_file(item) == '{"a": 1, "b": 2}\n'
    item.value = 'test_data/test_data.json'
    assert load_text_file(item) == '{"a": 1, "b": 2}\n'
    item.value = 'test_data/test_data.json'

# Generated at 2022-06-17 19:52:45.470436
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:49.107353
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:52:59.328647
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_RAW_JSON,
        orig='@test.json',
        value='{"a": "b"}'
    )
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:53:02.769455
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='data', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:06.422481
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:53:10.051318
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:12.264178
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, value='/Users/mengxin/Desktop/test.txt')
    print(load_text_file(item))

# Generated at 2022-06-17 19:53:14.450778
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', 'sep')
    assert process_file_upload_arg(arg) == ('key', 'value', 'sep')

# Generated at 2022-06-17 19:53:19.349136
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:23.048797
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a":1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:53:25.572686
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:53:36.994244
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:54:06.014074
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="test", sep="test", key="test", value="test")
    assert load_text_file(item) == "test"

# Generated at 2022-06-17 19:54:13.552043
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='file.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='file.txt;application/json', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', open('file.txt', 'rb'), 'application/json')


# Generated at 2022-06-17 19:54:15.486321
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:20.417740
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:54:23.426665
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:25.820153
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:30.140286
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:32.890159
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:36.316317
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:38.668640
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='{}')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:57.124955
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:03.649006
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;image/jpeg', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')


# Generated at 2022-06-17 19:55:06.857475
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:16.056147
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:55:21.350421
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:55:23.497092
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', value='test', sep='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:28.176736
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        value='/tmp/test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/tmp/test.txt'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'

# Generated at 2022-06-17 19:55:40.359111
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html;', '@')

# Generated at 2022-06-17 19:55:44.621464
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:49.044625
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:56:40.715752
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:56:43.324762
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:47.206001
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.txt"
    mime_type = "text/plain"
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "test.txt", "test.txt;text/plain")
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), mime_type)


# Generated at 2022-06-17 19:57:00.206638
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:03.254020
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='value')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:57:16.190541
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:57:22.968780
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file@/tmp/foo.txt')
    assert process_file_upload_arg(arg) == ('foo.txt', open('/tmp/foo.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file@/tmp/foo.txt;text/html')
    assert process_file_upload_arg(arg) == ('foo.txt', open('/tmp/foo.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file@/tmp/foo.txt;')
    assert process_file_upload_arg(arg) == ('foo.txt', open('/tmp/foo.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file@/tmp/foo.txt;text/html;')

# Generated at 2022-06-17 19:57:26.766719
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:37.851573
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:57:39.421049
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:15.462601
# Unit test for function load_text_file
def test_load_text_file():
    # Create a file with content
    f = open("test.txt", "w+")
    f.write("Hello World")
    f.close()

    # Load the file
    item = KeyValueArg('', '', '', '', '', '', '', '', '', '')
    item.value = 'test.txt'
    item.orig = 'test.txt'
    assert load_text_file(item) == 'Hello World'

    # Remove the file
    os.remove("test.txt")

# Generated at 2022-06-17 19:58:19.983982
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="", key="", sep="", value="")
    item.value = "./test_data/test_load_text_file.txt"
    assert load_text_file(item) == "This is a test file for load_text_file function."

# Generated at 2022-06-17 19:58:30.539507
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/home/user/test.json',
        orig='@/home/user/test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "name": "John",
        "age": 30,
        "cars": [
            {"name": "Ford", "models": ["Fiesta", "Focus", "Mustang"]},
            {"name": "BMW", "models": ["320", "X3", "X5"]},
            {"name": "Fiat", "models": ["500", "Panda"]}
        ]
    }

# Generated at 2022-06-17 19:58:34.100027
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:39.661164
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file.txt',
        value='/path/to/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/path/to/file.txt', 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 19:58:42.508140
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:47.739161
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg('key', 'value;type', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:58:58.349199
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="", value="", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(key="", value="{}", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(key="", value="{\"a\":\"b\"}", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:59:09.326207
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html;', '@')

# Generated at 2022-06-17 19:59:15.150491
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:52.906601
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.value = '{"a": 1, "b": 2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}


# Generated at 2022-06-17 19:59:56.244885
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:59.264822
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:04.463935
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 20:00:06.527204
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')) == 'test'

# Generated at 2022-06-17 20:00:14.894454
# Unit test for function load_text_file

# Generated at 2022-06-17 20:00:22.680410
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '')
    arg.key = 'key'
    arg.value = 'value'
    arg.orig = 'orig'
    arg.sep = 'sep'
    arg.raw = 'raw'
    arg.orig_key = 'orig_key'
    arg.orig_value = 'orig_value'
    arg.is_flag = 'is_flag'
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 20:00:26.561703
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 20:00:27.846992
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:31.200485
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_FILE_UPLOAD)
    result = process_file_upload_arg(arg)
    assert result == ('value', 'rb', None)

# Generated at 2022-06-17 20:01:29.791384
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', sep='', key='', value='/Users/julian/Documents/httpie/httpie/cli/__init__.py')

# Generated at 2022-06-17 20:01:33.225281
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'name': 'test'}

# Generated at 2022-06-17 20:01:38.895220
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='test@/tmp/test.txt',
        value='/tmp/test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 20:01:43.639686
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:01:45.517164
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:54.432812
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='{"a": 1, "b": 2}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@{"a": 1, "b": 2}',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}