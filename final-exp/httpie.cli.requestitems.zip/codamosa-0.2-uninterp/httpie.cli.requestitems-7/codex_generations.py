

# Generated at 2022-06-17 19:52:08.994940
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:18.859149
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(
        key='test',
        value='test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

    # Test for invalid json file
    arg = KeyValueArg(
        key='test',
        value='test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@test.json'
    )
    with pytest.raises(ParseError):
        process_data_embed_raw_json_file_arg(arg)



# Generated at 2022-06-17 19:52:24.895394
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@/tmp/test.json'
    arg.value = '@/tmp/test.json'
    arg.sep = '@'
    arg.key = ''
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:34.286497
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/user/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/user/file.txt;image/png')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/png')

    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/user/file.txt;')

# Generated at 2022-06-17 19:52:37.858479
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:52:40.336503
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:51.119712
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == ''
    arg = KeyValueArg(key='', value='{}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {}
    arg = KeyValueArg(key='', value='[]', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == []
    arg = KeyValueArg(key='', value='"a"', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == "a"

# Generated at 2022-06-17 19:52:54.710747
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a":1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:52:58.647245
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test_data/test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:53:08.106102
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), None)
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')
    arg = KeyValueArg('file', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 19:53:19.263912
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('-d', '@', 'test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:29.183433
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # test case 1:
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt',
        orig='file@/tmp/test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    # test case 2:
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt;text/html',
        orig='file@/tmp/test.txt;text/html'
    )

# Generated at 2022-06-17 19:53:32.720241
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '')
    item.value = './test_data/test_file.txt'
    assert load_text_file(item) == 'This is a test file.\n'

# Generated at 2022-06-17 19:53:37.947059
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:45.035830
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep='@', value='/home/user/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='key', sep='@', value='/home/user/file.txt;image/png')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 19:53:49.726675
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    test_arg = KeyValueArg(
        key='test_key',
        value='test_value',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test_key:=@test_value'
    )
    assert process_data_embed_raw_json_file_arg(test_arg) == 'test_value'

# Generated at 2022-06-17 19:53:57.635877
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:54:06.547771
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # test for normal case
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == 'value'
    # test for exception case
    arg = KeyValueArg(key='key', value='{"key": "value"', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"key=@value": Expecting property name enclosed in double quotes: line 1 column 2 (char 1)'

# Generated at 2022-06-17 19:54:11.499388
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-17 19:54:17.822787
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.txt"
    mime_type = "text/plain"
    arg = KeyValueArg(filename, SEPARATOR_FILE_UPLOAD, filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type)
    assert process_file_upload_arg(arg) == ("test.txt", open(os.path.expanduser(filename), 'rb'), mime_type)


# Generated at 2022-06-17 19:54:37.134317
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:44.679293
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('-F', 'file=@/home/user/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('-F', 'file=@/home/user/file.txt;type=image/jpeg')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg('-F', 'file=@/home/user/file.txt;type=image/jpeg;')

# Generated at 2022-06-17 19:54:49.513173
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')

# Generated at 2022-06-17 19:54:53.377186
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:54:55.241051
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test", "test.txt")) == "test"

# Generated at 2022-06-17 19:54:58.517844
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        'data',
        '@',
        'test.json',
        '@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:03.557667
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/jianyuan/Documents/GitHub/httpie/tests/data/json/valid.json',
        orig='@/Users/jianyuan/Documents/GitHub/httpie/tests/data/json/valid.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:13.348289
# Unit test for function load_text_file

# Generated at 2022-06-17 19:55:15.043963
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:24.836459
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:56:01.948541
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='',
        value='test.json',
        orig='@test.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {
        "name": "test",
        "age": 18,
        "address": "beijing"
    }

# Generated at 2022-06-17 19:56:04.209924
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('', None, '')

# Generated at 2022-06-17 19:56:09.894534
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'test': 'test'}

# Generated at 2022-06-17 19:56:11.797170
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:16.113450
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg('key', 'value;type', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:56:20.285372
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    item = KeyValueArg(key='', value='', sep='')
    item.value = '{"a": "b"}'
    assert process_data_embed_raw_json_file_arg(item) == {'a': 'b'}

# Generated at 2022-06-17 19:56:29.062165
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
   

# Generated at 2022-06-17 19:56:31.687961
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:56:41.748734
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 19:56:44.887627
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('test.txt', 'test.txt', 'test.txt', ';')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:57:14.672233
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:18.498121
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="--data-raw '{\"name\":\"test\"}'", sep="=", key="", value="{\"name\":\"test\"}")
    assert load_text_file(item) == "{\"name\":\"test\"}"


# Generated at 2022-06-17 19:57:22.839749
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        'a': 1,
        'b': 2,
        'c': 3
    }

# Generated at 2022-06-17 19:57:24.118382
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='test', value='test.txt', sep='=')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:35.506261
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg('test', 'test.txt', 'test.txt')
    assert load_text_file(item) == 'test'

    # Test for file not found
    item = KeyValueArg('test', 'test1.txt', 'test1.txt')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test1.txt\''

    # Test for not a UTF8 or ASCII-encoded text file
    item = KeyValueArg('test', 'test2.txt', 'test2.txt')

# Generated at 2022-06-17 19:57:37.321205
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file', 'test.txt', 'file', 'test.txt', 'file', 'test.txt', 'file', 'test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:39.460925
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:42.031467
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:57:49.673607
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "name": "John",
        "age": 30,
        "cars": [
            {"name": "Ford", "models": ["Fiesta", "Focus", "Mustang"]},
            {"name": "BMW", "models": ["320", "X3", "X5"]},
            {"name": "Fiat", "models": ["500", "Panda"]}
        ]
    }

# Generated at 2022-06-17 19:57:52.366715
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:28.952989
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:33.093173
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:37.690867
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.key = 'test'
    arg.value = '{"a":1}'
    arg.sep = SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1}

# Generated at 2022-06-17 19:58:41.905505
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:58:47.108740
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:48.636959
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:59.015494
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), None)

# Generated at 2022-06-17 19:59:03.942650
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/file.txt', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:59:05.570116
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(None, None, None, None, None)) == None

# Generated at 2022-06-17 19:59:10.707707
# Unit test for function load_text_file
def test_load_text_file():
    file_name = "test_file.txt"
    file_content = "This is a test file"
    file = open(file_name, "w")
    file.write(file_content)
    file.close()
    item = KeyValueArg(file_name, file_name, "")
    assert load_text_file(item) == file_content
    os.remove(file_name)

# Generated at 2022-06-17 20:00:00.616677
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', value='test.txt')) == 'test'

# Generated at 2022-06-17 20:00:05.480531
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', sep='', value='/Users/zhaoyang/Documents/GitHub/httpie/test/data/test_file.txt')
    assert load_text_file(item) == 'test_file_content'


# Generated at 2022-06-17 20:00:13.556257
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt'
    )
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/home/user/file.txt;image/jpeg',
        orig='file@/home/user/file.txt;image/jpeg'
    )

# Generated at 2022-06-17 20:00:16.372088
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=':', value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:00:19.905152
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='test_file.txt')
    assert load_text_file(item) == 'This is a test file.\n'

# Generated at 2022-06-17 20:00:23.357079
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg('key', 'value;type', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 20:00:30.141907
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.value = './test_data/test_json_data.json'
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 20:00:35.207241
# Unit test for function load_text_file
def test_load_text_file():
    # Test for existing file
    item = KeyValueArg('test', 'test.txt', 'test.txt')
    assert load_text_file(item) == 'test'

    # Test for non-existing file
    item = KeyValueArg('test', 'test2.txt', 'test2.txt')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test2.txt\''


# Generated at 2022-06-17 20:00:37.510177
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', sep='', key='', value='test.txt')) == 'test'

# Generated at 2022-06-17 20:00:41.210664
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-17 20:01:39.410400
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:01:43.068236
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="", value="", sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ("", None, "")

# Generated at 2022-06-17 20:01:47.495069
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.txt"
    mime_type = "text/plain"
    arg = KeyValueArg("test.txt;text/plain", "test.txt", ";", "text/plain")
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), mime_type)


# Generated at 2022-06-17 20:01:58.794471
# Unit test for function process_data_embed_raw_json_file_arg