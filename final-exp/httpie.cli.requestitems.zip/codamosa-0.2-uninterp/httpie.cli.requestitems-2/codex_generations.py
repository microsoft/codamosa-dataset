

# Generated at 2022-06-17 19:52:07.110132
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestJSONDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.items import RequestItems
    from httpie.cli.utils import get_response
    from httpie.compat import is_windows
    from httpie.output.streams import get_output_stream
    from httpie.output.streams import write_output
    from httpie.output.writers import get_writer
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPDigestAuth

# Generated at 2022-06-17 19:52:08.500799
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test", "test.txt")) == "test"

# Generated at 2022-06-17 19:52:18.671372
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 19:52:28.986824
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/tmp/test.txt',
        value='/tmp/test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/tmp/test.txt;text/html',
        value='/tmp/test.txt;text/html',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/html')

# Generated at 2022-06-17 19:52:33.216462
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:52:43.836627
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'filename',
        'test.txt',
        '=',
        '@',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(
        'filename',
        'test.txt;image/png',
        '=',
        '@',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/png'
    assert f.read() == b'hello world'
    f.close()


# Generated at 2022-06-17 19:52:46.879802
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:52:51.400759
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}


# Generated at 2022-06-17 19:52:54.958523
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": "b"}')
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:53:01.382160
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {}
    arg = KeyValueArg(key='', value='{}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {}
    arg = KeyValueArg(key='', value='{"a": 1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}
    arg = KeyValueArg(key='', value='{"a": 1, "b": 2}', sep=SEPARATOR_DATA_RAW_JSON)

# Generated at 2022-06-17 19:53:10.560362
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}

# Generated at 2022-06-17 19:53:16.873592
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Test case 1:
    # Input:
    #   arg = KeyValueArg(key='file', sep='@', value='test.txt')
    # Expected:
    #   ('test.txt', <_io.BufferedReader name='test.txt'>, 'text/plain')
    arg = KeyValueArg(key='file', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    # Test case 2:
    # Input:
    #   arg = KeyValueArg(key='file', sep='@', value='test.txt;text/plain')
    # Expected:
    #   ('test.txt', <_io.BufferedReader name='test.txt'>, 'text/plain')


# Generated at 2022-06-17 19:53:26.007487
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg('key', 'value;type', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')
    arg = KeyValueArg('key', 'value;type;', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')
    arg = KeyValueArg('key', 'value;type;', ';')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')
    arg = KeyValueArg('key', 'value;type;', ';')

# Generated at 2022-06-17 19:53:36.988194
# Unit test for function load_text_file
def test_load_text_file():
    # Test for a valid file
    item = KeyValueArg(orig='@test.txt', sep='@', key='@', value='test.txt')
    assert load_text_file(item) == 'This is a test file\n'
    # Test for an invalid file
    item = KeyValueArg(orig='@test.txt', sep='@', key='@', value='invalid.txt')
    with pytest.raises(ParseError):
        load_text_file(item)
    # Test for a non-text file
    item = KeyValueArg(orig='@test.txt', sep='@', key='@', value='test.png')
    with pytest.raises(ParseError):
        load_text_file(item)


# Generated at 2022-06-17 19:53:40.735235
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:46.639211
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        value='{"a":1, "b":2}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@{"a":1, "b":2}',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1, "b":2}


# Generated at 2022-06-17 19:53:50.825809
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@/Users/joe/test.json',
        value='/Users/joe/test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 'b'}

# Generated at 2022-06-17 19:53:53.145558
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:55.782062
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='test', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:58.232409
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:11.320640
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_RAW_JSON,
        value='{"a": 1, "b": 2}',
        orig='{"a": 1, "b": 2}',
    )
    assert process_data_raw_json_embed_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:54:15.054807
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('key', 'value', 'sep')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:54:16.601718
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:54:23.044209
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3],
        'd': {
            'e': 1,
            'f': 2
        }
    }

# Generated at 2022-06-17 19:54:26.151062
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test', 'test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:36.688664
# Unit test for function load_text_file

# Generated at 2022-06-17 19:54:46.887134
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_RAW_JSON)
    arg.value = '{"a":1}'
    assert process_data_raw_json_embed_arg(arg) == {"a":1}
    arg.value = '{"a":1, "b":2}'
    assert process_data_raw_json_embed_arg(arg) == {"a":1, "b":2}
    arg.value = '{"a":1, "b":2, "c":3}'
    assert process_data_raw_json_embed_arg(arg) == {"a":1, "b":2, "c":3}
    arg.value = '{"a":1, "b":2, "c":3, "d":4}'
    assert process_data_raw

# Generated at 2022-06-17 19:54:52.470516
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:54:55.092513
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:59.382385
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(
        key='',
        value='{"a":1, "b":2}',
        sep=SEPARATOR_DATA_RAW_JSON,
        orig='{"a":1, "b":2}'
    )
    assert process_data_raw_json_embed_arg(arg) == {"a":1, "b":2}

# Generated at 2022-06-17 19:55:18.105553
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:20.421810
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": 1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}

# Generated at 2022-06-17 19:55:24.351539
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:26.532908
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test_data.json', sep='=')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:55:30.001703
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '', '')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:55:32.707016
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test\n'


# Generated at 2022-06-17 19:55:34.972372
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:39.709813
# Unit test for function load_text_file
def test_load_text_file():
    with open('test.txt', 'w') as f:
        f.write('test')
    item = KeyValueArg('test', 'test.txt')
    assert load_text_file(item) == 'test'
    os.remove('test.txt')


# Generated at 2022-06-17 19:55:42.306111
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    test_arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": "b"}')
    assert process_data_raw_json_embed_arg(test_arg) == {"a": "b"}


# Generated at 2022-06-17 19:55:46.519664
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig='test', key='test', sep='=', value='{"test": "test"}')
    assert process_data_raw_json_embed_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:56:15.556232
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')

# Generated at 2022-06-17 19:56:22.922701
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(key='file', value='/tmp/test.txt;text/html', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/html')

# Generated at 2022-06-17 19:56:28.100791
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    contents = load_text_file(item)
    assert contents == 'test'

# Generated at 2022-06-17 19:56:38.851267
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain;', sep='@')

# Generated at 2022-06-17 19:56:43.798745
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.value = '{"a": 1, "b": 2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:56:46.040633
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:49.238009
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:50.898306
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="", value="", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:01.763015
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', open('value', 'rb'), None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', open('value', 'rb'), 'type')
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type;')
    assert process_file_upload_arg(arg) == ('value', open('value', 'rb'), 'type')
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;')
   

# Generated at 2022-06-17 19:57:14.247847
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:57:58.646648
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for normal case
    arg = KeyValueArg(key='test', sep='=', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}
    # Test for abnormal case
    arg = KeyValueArg(key='test', sep='=', value='test.txt')
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError:
        assert True
    else:
        assert False

# Generated at 2022-06-17 19:58:04.153657
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:16.837145
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for file not exist
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='not_exist.json')
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"@not_exist.json": [Errno 2] No such file or directory: \'not_exist.json\''

    # Test for invalid json file
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='invalid.json')

# Generated at 2022-06-17 19:58:19.388615
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:21.408768
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:32.117188
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep='@', value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(key='file', sep='@', value='/tmp/test.txt;image/jpeg')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/jpeg')

    arg = KeyValueArg(key='file', sep='@', value='/tmp/test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:41.188837
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file', 'test.txt;', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:42.597357
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:47.430787
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:52.839688
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        value='value',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='key:=@value',
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:59:29.925163
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test", "test.txt")) == "test"

# Generated at 2022-06-17 19:59:32.420145
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig="test", sep="test", key="test", value="test")
    assert load_text_file(item) == "test"

# Generated at 2022-06-17 19:59:40.902932
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt'
    )
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), None)

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt;text/plain',
        orig='file@/home/user/file.txt;text/plain'
    )
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:59:47.594441
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.key = 'data'
    arg.value = '{"a": "b"}'
    arg.sep = SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    assert process_data_embed_raw_json_file_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:59:50.446545
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:52.741102
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='=', key='test', value='test.txt')
    contents = load_text_file(item)
    assert contents == 'test'

# Generated at 2022-06-17 19:59:54.678740
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('data', '@/home/user/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:00:04.119960
# Unit test for function load_text_file
def test_load_text_file():
    # Test case 1: file exists
    item = KeyValueArg(key='test', value='test.txt', sep=':')
    assert load_text_file(item) == 'test'
    # Test case 2: file does not exist
    item = KeyValueArg(key='test', value='test1.txt', sep=':')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test1.txt": [Errno 2] No such file or directory: \'test1.txt\''
    # Test case 3: file is not a text file
    item = KeyValueArg(key='test', value='test2.png', sep=':')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str

# Generated at 2022-06-17 20:00:08.626632
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt',
        orig='file@/tmp/test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:00:10.959762
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:48.908656
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:00:54.265537
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:01:03.661443
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(key='', value='{}', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}
    arg = KeyValueArg(key='', value='{"a": 1}', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1}

# Generated at 2022-06-17 20:01:12.316439
# Unit test for function load_text_file
def test_load_text_file():
    # Test for file not exist
    try:
        load_text_file(KeyValueArg(orig="test", key="test", value="test"))
    except ParseError as e:
        assert e.args[0] == '"test": [Errno 2] No such file or directory: \'test\''
    # Test for file is not a text file
    try:
        load_text_file(KeyValueArg(orig="test", key="test", value="test.png"))
    except ParseError as e:
        assert e.args[0] == '"test": cannot embed the content of "test.png", not a UTF8 or ASCII-encoded text file'
    # Test for file is a text file

# Generated at 2022-06-17 20:01:16.150996
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:01:23.448461
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 20:01:28.836382
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file',
        value='/path/to/file',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file'
    assert f.read() == b'file contents'
    assert mime_type == 'text/plain'

# Generated at 2022-06-17 20:01:37.357614
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 20:01:44.337330
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="test", value="test.txt", sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "text/plain")
    arg = KeyValueArg(key="test", value="test.txt;text/plain", sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "text/plain")
    arg = KeyValueArg(key="test", value="test.txt;", sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "text/plain")
    arg = KeyValue

# Generated at 2022-06-17 20:01:47.669435
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'