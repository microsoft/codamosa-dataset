

# Generated at 2022-06-17 19:52:05.599246
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:10.049378
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:52:13.412357
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', value='test', sep='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:17.746722
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}


# Generated at 2022-06-17 19:52:28.550530
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file',
        value='/path/to/file'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file'
    assert mime_type == 'application/octet-stream'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file;text/plain',
        value='/path/to/file;text/plain'
    )
    filename, f, mime_type = process_file_upload_arg

# Generated at 2022-06-17 19:52:32.553644
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:52:34.973176
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('test', 'test.json', ':')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:52:38.510723
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/Users/jiawei/Desktop/test.txt')
    print(load_text_file(item))

# Generated at 2022-06-17 19:52:43.876067
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:52:48.093569
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/Users/yunjie/Desktop/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:01.947314
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        value='{"a": 1, "b": 2}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@{"a": 1, "b": 2}'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:53:12.243542
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file.txt',
        value='/path/to/file.txt'
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/path/to/file.txt', 'rb'),
        'text/plain'
    )

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file.txt;image/png',
        value='/path/to/file.txt;image/png'
    )

# Generated at 2022-06-17 19:53:14.735705
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', '~/test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('~/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:18.407996
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        value='test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:53:28.580091
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg('test', 'test.txt', 'test.txt')
    assert load_text_file(item) == 'test'

    # Test for IOError
    item = KeyValueArg('test', 'test.txt', 'test.txt')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test.txt\''

    # Test for UnicodeDecodeError
    item = KeyValueArg('test', 'test.txt', 'test.txt')

# Generated at 2022-06-17 19:53:31.292609
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '', '')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:34.658824
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/jpeg', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')


# Generated at 2022-06-17 19:53:37.681638
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:53:41.427441
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', './test/test_file_upload.txt', '=')
    assert process_file_upload_arg(arg) == ('test_file_upload.txt', open('./test/test_file_upload.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:44.531532
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:54:00.881658
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:03.399589
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('data', '@test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'key': 'value'}

# Generated at 2022-06-17 19:54:06.516236
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', sep='', key='', value='test.txt')) == 'This is a test file.\n'

# Generated at 2022-06-17 19:54:17.622348
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file@/home/user/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file@/home/user/file.txt;image/jpeg')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg('file@/home/user/file.txt;')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file@/home/user/file.txt;;')
   

# Generated at 2022-06-17 19:54:20.327704
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='=', key='test', value='test.txt')
    assert load_text_file(item) == 'test'



# Generated at 2022-06-17 19:54:25.600730
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:32.225406
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='test@/tmp/test.txt',
        value='/tmp/test.txt'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'This is a test file.\n'

# Generated at 2022-06-17 19:54:42.660479
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_FILE_UPLOAD,
        orig='@/path/to/file',
        value='/path/to/file',
    )
    assert process_file_upload_arg(arg) == (
        'file',
        open('/path/to/file', 'rb'),
        'application/octet-stream',
    )

    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_FILE_UPLOAD,
        orig='@/path/to/file.png',
        value='/path/to/file.png',
    )

# Generated at 2022-06-17 19:54:47.188438
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    json_file = '{"key1": "value1", "key2": "value2"}'
    arg = KeyValueArg(key='key1', value=json_file, sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {"key1": "value1", "key2": "value2"}

# Generated at 2022-06-17 19:54:54.567704
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file@/home/user/file.txt',
        'file@',
        'file',
        '/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 19:55:55.599775
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/home/test/test.json',
        orig='data@/home/test/test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "name": "test",
        "age": 18
    }

# Generated at 2022-06-17 19:56:02.353211
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')


# Generated at 2022-06-17 19:56:05.338377
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:10.050844
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        value='test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:56:12.950369
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:15.782859
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:18.072953
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('file', 'test.txt', '@')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:24.070174
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;value')
    assert process_file_upload_arg(arg) == ('value', 'value', 'value')

# Generated at 2022-06-17 19:56:30.539133
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '')
    arg.key = 'key'
    arg.value = 'value'
    arg.orig = 'orig'
    arg.sep = 'sep'
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:56:34.177206
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')



# Generated at 2022-06-17 19:57:03.978325
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('key', 'value', 'sep')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:57:13.825571
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test_file.txt'
    mime_type = 'text/plain'
    arg = KeyValueArg(
        '--form',
        'file@' + filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type,
        'file',
        '@',
        filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type,
    )
    assert process_file_upload_arg(arg) == (
        os.path.basename(filename),
        open(os.path.expanduser(filename), 'rb'),
        mime_type,
    )

# Generated at 2022-06-17 19:57:16.736543
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:57:19.973037
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:57:21.200527
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('a', 'b')
    assert load_text_file(item) == 'b'

# Generated at 2022-06-17 19:57:27.581457
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt',
        value='/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 19:57:31.510042
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:35.557297
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:57:38.367579
# Unit test for function load_text_file
def test_load_text_file():
    path = "./test_file.txt"
    item = KeyValueArg(None, "", "", path)
    assert load_text_file(item) == "This is a test file"


# Generated at 2022-06-17 19:57:41.165437
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@test.json', sep='@', key='', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:58:12.950748
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:17.495356
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        value='value',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='key:=@value',
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:58:22.401932
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='data', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'name': 'test'}

# Generated at 2022-06-17 19:58:29.385302
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='test@/tmp/test.txt',
        value='/tmp/test.txt'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'test'
    f.close()

# Generated at 2022-06-17 19:58:34.337865
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        value='test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='test@test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:37.392740
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='/Users/jianing/Desktop/test.json')
    print(process_data_embed_raw_json_file_arg(arg))


# Generated at 2022-06-17 19:58:41.050241
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='data@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 'b'}

# Generated at 2022-06-17 19:58:44.254239
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='=', key='test', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:47.882920
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:58:52.886088
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:26.031682
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '')
    arg.value = '{"a":1, "b":2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1, "b":2}

# Generated at 2022-06-17 19:59:30.628096
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        key='key',
        value='value'
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:59:31.906501
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:59:34.817619
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:59:38.299827
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:41.898653
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read().decode() == 'test'


# Generated at 2022-06-17 19:59:45.741865
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:59:48.287110
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:51.285725
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:55.852119
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        orig='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:00:35.045822
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:00:46.713999
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 20:00:51.866287
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '')
    item.value = './test_load_text_file.txt'
    assert load_text_file(item) == 'test_load_text_file'

# Generated at 2022-06-17 20:00:54.678779
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test'

# Generated at 2022-06-17 20:00:57.230603
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:59.899883
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:01:01.148062
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:01:03.775807
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='=', key='test', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:08.294996
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:01:11.758885
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:44.679127
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        '~/Downloads/test.txt',
        '@',
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open('~/Downloads/test.txt', 'rb'),
        'text/plain',
    )

# Generated at 2022-06-17 20:01:55.929315
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
