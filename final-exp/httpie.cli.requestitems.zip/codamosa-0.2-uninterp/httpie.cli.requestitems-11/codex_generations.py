

# Generated at 2022-06-17 19:52:05.029720
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@test.txt')) == 'test'

# Generated at 2022-06-17 19:52:09.614800
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:52:14.466630
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'test': 'test'}

# Generated at 2022-06-17 19:52:17.376299
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test.txt', key='test.txt', sep='@', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:23.426589
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;value')
    assert process_file_upload_arg(arg) == ('value', 'value', 'value')

# Generated at 2022-06-17 19:52:27.933613
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='a', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='{"a":1}')
    assert process_data_embed_raw_json_file_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:52:32.906671
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:36.958035
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='data', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='/Users/jianyuan/Desktop/test.json')
    print(process_data_embed_raw_json_file_arg(arg))


# Generated at 2022-06-17 19:52:39.761036
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', '~/test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('~/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:52:50.878155
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )

# Generated at 2022-06-17 19:53:07.983894
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    assert process_file_upload_arg(KeyValueArg(key='', sep='', value='/path/to/file')) == ('file', open('/path/to/file', 'rb'), 'text/plain')
    assert process_file_upload_arg(KeyValueArg(key='', sep='', value='/path/to/file;image/png')) == ('file', open('/path/to/file', 'rb'), 'image/png')
    assert process_file_upload_arg(KeyValueArg(key='', sep='', value='/path/to/file;')) == ('file', open('/path/to/file', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:11.365237
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:18.728159
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:53:20.677399
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@', 'test.txt', 'test.txt')) == 'test'

# Generated at 2022-06-17 19:53:29.022620
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/tmp/test.txt',
        orig='test@/tmp/test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/tmp/test.txt;text/plain',
        orig='test@/tmp/test.txt;text/plain',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:38.140004
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": 1}')
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": 1, "b": 2}')
    assert process_data_raw_json_embed_arg(arg) == {"a": 1, "b": 2}
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a": 1, "b": [1, 2, 3]}')
    assert process_data_raw_json_embed_arg(arg) == {"a": 1, "b": [1, 2, 3]}

# Generated at 2022-06-17 19:53:41.559522
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:42.821019
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:45.153621
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:53:47.370948
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(None, None, None, None, None)) == None

# Generated at 2022-06-17 19:53:56.458347
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:53:58.497924
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a":1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a":1}


# Generated at 2022-06-17 19:54:06.706548
# Unit test for function load_text_file
def test_load_text_file():
    # Test case 1: load a text file
    item = KeyValueArg(orig='@test.txt', sep='@', key='@', value='test.txt')
    assert load_text_file(item) == 'test\n'

    # Test case 2: load a non-text file
    item = KeyValueArg(orig='@test.jpg', sep='@', key='@', value='test.jpg')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"@test.jpg": cannot embed the content of "test.jpg", not a UTF8 or ASCII-encoded text file'


# Generated at 2022-06-17 19:54:08.603728
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'


# Generated at 2022-06-17 19:54:19.320204
# Unit test for function load_text_file

# Generated at 2022-06-17 19:54:27.222863
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;')

# Generated at 2022-06-17 19:54:32.304863
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='test@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:54:35.351779
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', sep='', key='', value='/home/user/file.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:45.369479
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )

# Generated at 2022-06-17 19:54:47.955267
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='=', key='test', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:54:56.599677
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:05.457722
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:55:15.097699
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:55:18.352743
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:20.299000
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', key='', sep='', value='test.txt')
    assert load_text_file(item) == 'Hello World\n'

# Generated at 2022-06-17 19:55:23.545001
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@test.json', key='', sep='@', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:25.596181
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='test', value='test.txt', orig='test.txt', sep=';')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:37.137028
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:55:38.589024
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('key', 'value')) == 'value'

# Generated at 2022-06-17 19:55:41.476911
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:51.861557
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:56.695351
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:56:02.635120
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}


# Generated at 2022-06-17 19:56:07.199717
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:56:11.165392
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:56:19.970971
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/jpeg', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')

# Generated at 2022-06-17 19:56:28.902060
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(orig='', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'
    # Test for IOError
    item = KeyValueArg(orig='', sep='', key='', value='test_not_exist.txt')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"": [Errno 2] No such file or directory: \'test_not_exist.txt\''
    # Test for UnicodeDecodeError
    item = KeyValueArg(orig='', sep='', key='', value='test_binary.txt')

# Generated at 2022-06-17 19:56:39.465533
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:56:41.955074
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('--data', '@test.json', '@')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:56:50.252617
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(orig="test", sep="", key="", value="test_data/test.txt")
    assert load_text_file(item) == "This is a test file.\n"

    # Test for IOError
    item = KeyValueArg(orig="test", sep="", key="", value="test_data/test_not_exist.txt")
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test_data/test_not_exist.txt\''

    # Test for UnicodeDecodeError
    item = KeyValueArg(orig="test", sep="", key="", value="test_data/test_binary.txt")

# Generated at 2022-06-17 19:57:17.117198
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:57:18.652596
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('key', 'value', ';')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:57:23.390284
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 19:57:30.527559
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='{"a": 1, "b": 2}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@{"a": 1, "b": 2}'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:57:33.130438
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(SEPARATOR_DATA_EMBED_RAW_JSON_FILE, 'key', 'value')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:57:36.968695
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:57:39.730179
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:42.418123
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:46.834291
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:57:58.039165
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')

# Generated at 2022-06-17 19:58:17.209552
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test'

# Generated at 2022-06-17 19:58:21.622758
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:58:32.344781
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/file.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/file.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/file.txt;', sep=SEPARATOR_FILE_UPLOAD)

# Generated at 2022-06-17 19:58:39.024558
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')


# Generated at 2022-06-17 19:58:45.197461
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        value='/tmp/test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/tmp/test.txt'
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open('/tmp/test.txt', 'rb'),
        'text/plain'
    )

    arg = KeyValueArg(
        key='file',
        value='/tmp/test.txt;image/png',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/tmp/test.txt;image/png'
    )

# Generated at 2022-06-17 19:58:48.040854
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:58:52.639618
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:53.894029
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:59.169107
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    file_path = "./test_file.txt"
    file_name = "test_file.txt"
    mime_type = "text/plain"
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "key", file_path)
    assert process_file_upload_arg(arg) == (file_name, open(file_path, 'rb'), mime_type)


# Generated at 2022-06-17 19:59:02.939343
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep='@', value='value')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 19:59:27.249236
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 'b'}

# Generated at 2022-06-17 19:59:31.701041
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        'data',
        '@',
        'test.json',
        '@test.json',
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:35.645707
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:38.427089
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:59:41.232809
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1}

# Generated at 2022-06-17 19:59:47.296514
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:59:50.486274
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:52.780857
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', sep='', orig='', value='test_file.txt')
    assert load_text_file(item) == 'test_file_content'

# Generated at 2022-06-17 19:59:56.662429
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.value = './test_data/test_data.json'
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 20:00:05.569144
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 20:00:44.882892
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:00:47.310763
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:50.434104
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(orig='@test.json', sep='@', key='', value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:00:56.929722
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:00:59.026100
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:03.777057
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:01:06.431625
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:01:08.035217
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test'

# Generated at 2022-06-17 20:01:11.538782
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='a.txt', key='a.txt', sep='=', value='a.txt')
    assert load_text_file(item) == 'a.txt'

# Generated at 2022-06-17 20:01:16.924089
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt',
        orig='file@/home/user/file.txt'
    )
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        key='file',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/home/user/file.txt;text/plain',
        orig='file@/home/user/file.txt;text/plain'
    )

# Generated at 2022-06-17 20:01:54.219935
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}