

# Generated at 2022-06-17 19:52:06.763110
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"a": "b"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}
    arg = KeyValueArg(key='', value='{"a": "b", "c": "d"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"a": "b", "c": "d"}
    arg = KeyValueArg(key='', value='{"a": "b", "c": "d", "e": "f"}', sep=SEPARATOR_DATA_RAW_JSON)

# Generated at 2022-06-17 19:52:08.121259
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@', 'test.txt')) == 'test'

# Generated at 2022-06-17 19:52:09.878765
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('', '', '', 'test.txt')) == 'test'

# Generated at 2022-06-17 19:52:13.262670
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:17.693030
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:28.511124
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(key='', value='test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    assert load_text_file(item) == 'This is a test file.\n'

    # Test for file not found
    item = KeyValueArg(key='', value='test_not_found.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"@test_not_found.txt": [Errno 2] No such file or directory: \'test_not_found.txt\''

    # Test for not a text file

# Generated at 2022-06-17 19:52:29.824527
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:52:34.631270
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:38.554786
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', sep='', key='', value='/Users/yunfeng/Desktop/test.txt')
    assert load_text_file(item) == 'hello world'


# Generated at 2022-06-17 19:52:42.995336
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:03.179357
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(key='', value='test.txt', sep='')) == 'test'

# Generated at 2022-06-17 19:53:09.038951
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.txt"
    mime_type = "text/plain"
    arg = KeyValueArg(SEPARATOR_FILE_UPLOAD, "key", filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type)
    assert process_file_upload_arg(arg) == ("test.txt", open(filename, 'rb'), mime_type)


# Generated at 2022-06-17 19:53:16.793922
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Test case 1:
    #   Input:
    #       arg.value = 'file1.txt'
    #   Expected:
    #       return ('file1.txt', f, 'text/plain')
    #           where f is the file object of file1.txt
    arg = KeyValueArg(
        key='file1.txt',
        value='file1.txt',
        sep=SEPARATOR_FILE_UPLOAD
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file1.txt'
    assert mime_type == 'text/plain'
    f.close()

    # Test case 2:
    #   Input:
    #       arg.value = 'file1.txt;image/png'
    #   Expected:
   

# Generated at 2022-06-17 19:53:18.774052
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('data', '@test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:23.951438
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:28.485822
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key="file", value="test.txt", sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ("test.txt", open("test.txt", "rb"), "text/plain")


# Generated at 2022-06-17 19:53:32.259169
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:53:34.779511
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', value='test', sep='test')) == 'test'

# Generated at 2022-06-17 19:53:43.633987
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:53:48.151806
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='data',
        value='@test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:04.444449
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='value')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:54:10.958814
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')

# Generated at 2022-06-17 19:54:13.493534
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:16.565697
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:54:18.396946
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(None, None, 'test.txt', None)) == 'test'

# Generated at 2022-06-17 19:54:22.141930
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:54:28.178451
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:54:32.145937
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@test.txt', '@test.txt')) == 'test\n'
    assert load_text_file(KeyValueArg('@test.txt', '@test.txt')) != 'test'

# Generated at 2022-06-17 19:54:35.464604
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:37.793043
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test_data/test.txt', ':')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:54.345240
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test", "test")) == "test"


# Generated at 2022-06-17 19:54:59.240740
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.key = 'name'
    arg.value = './test_data.json'
    arg.sep = SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'name': 'test_data'}


# Generated at 2022-06-17 19:55:01.159728
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('test', 'test', 'test')
    assert process_data_embed_raw_json_file_arg(arg) == 'test'

# Generated at 2022-06-17 19:55:07.255778
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')

# Generated at 2022-06-17 19:55:09.834389
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('a', 'b', 'c')
    assert process_data_embed_raw_json_file_arg(arg) == 'c'

# Generated at 2022-06-17 19:55:18.306052
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(
        key='',
        value='test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig=''
    )
    assert load_text_file(item) == 'test'

    # Test for file not found
    item = KeyValueArg(
        key='',
        value='test1.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig=''
    )
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"": [Errno 2] No such file or directory: \'test1.txt\''

    # Test for file not text file

# Generated at 2022-06-17 19:55:21.297911
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:23.449256
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(key='', sep='', value='test.txt')) == 'test\n'

# Generated at 2022-06-17 19:55:26.656876
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test_data/test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:28.240368
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:02.303936
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(SEPARATOR_DATA_EMBED_FILE_CONTENTS, 'test.txt', 'test.txt')) == 'test'


# Generated at 2022-06-17 19:56:05.224090
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:56:07.447283
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:56:17.450651
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')

# Generated at 2022-06-17 19:56:23.155674
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:56:29.654627
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:56:33.182244
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:56:42.679502
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:56:46.680910
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:56:54.304818
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    result = process_data_embed_raw_json_file_arg(arg)
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:57:54.399899
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file@/home/user/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:04.357803
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/user/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/user/file.txt;image/png')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/home/user/file.txt;')

# Generated at 2022-06-17 19:58:10.258346
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:16.795749
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', None, None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', None, 'type')


# Generated at 2022-06-17 19:58:22.022194
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:23.903324
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:58:33.873253
# Unit test for function load_text_file

# Generated at 2022-06-17 19:58:36.446849
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="", value="", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:58:39.739174
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:44.833601
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:27.317831
# Unit test for function load_text_file
def test_load_text_file():
    # Test for loading a text file
    item = KeyValueArg(
        key='',
        value='test_data/test_text_file.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig=''
    )
    assert load_text_file(item) == 'This is a test text file.\n'
    # Test for loading a non-text file
    item = KeyValueArg(
        key='',
        value='test_data/test_image.png',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig=''
    )

# Generated at 2022-06-17 19:59:31.701248
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:59:35.175228
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig=''
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:42.975580
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg(key='file', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')

# Generated at 2022-06-17 19:59:53.834981
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:59:55.947097
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '', '')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:59.604575
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:00:10.198634
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 20:00:11.582233
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:18.355924
# Unit test for function load_text_file
def test_load_text_file():
    # Test for valid file
    item = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    assert load_text_file(item) == 'test'

    # Test for invalid file
    item = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test.txt\''


# Generated at 2022-06-17 20:01:20.206959
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:01:22.809390
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='-d', key='', sep='', value='test.txt')
    assert load_text_file(item) == 'hello world'

# Generated at 2022-06-17 20:01:25.791239
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, value='/Users/jian/Desktop/test.txt')
    print(load_text_file(item))


# Generated at 2022-06-17 20:01:27.850654
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 20:01:34.475563
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', value='value;type', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')
    arg = KeyValueArg(key='key', value='value;type;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')
    arg = KeyValueArg(key='key', value='value;type;', sep=SEPARATOR_FILE_UPLOAD)

# Generated at 2022-06-17 20:01:42.750365
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/plain;', '@')

# Generated at 2022-06-17 20:01:44.951124
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('filename', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:01:50.011114
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}