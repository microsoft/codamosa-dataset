

# Generated at 2022-06-17 19:52:09.573573
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:52:15.167376
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='test',
        value='test.json',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='test@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:52:18.832867
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == 'test'

# Generated at 2022-06-17 19:52:23.915263
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'name': 'test'}

# Generated at 2022-06-17 19:52:28.901269
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:33.115324
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:52:34.550840
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:52:39.501748
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='', orig_key='', orig_value='')
    item.value = '../test/test_data/test_file.txt'
    assert load_text_file(item) == 'This is a test file.\n'


# Generated at 2022-06-17 19:52:43.212090
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:52:48.636823
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:03.307955
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('@/home/user/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:07.644748
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '', '', '')
    arg.value = '{"test": "test"}'
    assert process_data_embed_raw_json_file_arg(arg) == {"test": "test"}

# Generated at 2022-06-17 19:53:08.994989
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:10.979066
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', value='test', sep=';')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:53:15.937989
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='value')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:53:20.099246
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='key',
        sep=SEPARATOR_FILE_UPLOAD,
        value='value',
        orig='key:=value',
    )
    assert process_file_upload_arg(arg) == ('value', 'value', None)

# Generated at 2022-06-17 19:53:25.221707
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/joshua/Desktop/test.json',
        orig='@/Users/joshua/Desktop/test.json'
    )
    print(process_data_embed_raw_json_file_arg(arg))


# Generated at 2022-06-17 19:53:36.720985
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 19:53:39.319328
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='--data-raw', key='', sep='=', value='{"a":1}')
    assert load_text_file(item) == '{"a":1}'

# Generated at 2022-06-17 19:53:41.516767
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('a', 'b', 'c')
    assert process_data_embed_raw_json_file_arg(arg) == 'c'

# Generated at 2022-06-17 19:53:50.756548
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:52.898501
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('data', '@test.json', '@')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:53:59.960236
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(key='file', value='/tmp/test.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/png')

# Generated at 2022-06-17 19:54:01.326753
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:03.835700
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('-d', '@/Users/yanyan/Desktop/test.txt')
    print(load_text_file(item))


# Generated at 2022-06-17 19:54:14.911489
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:54:16.430644
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:19.445831
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('', '', '', '', '', '')
    item.value = 'test_file.txt'
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:22.071169
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:26.864147
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', value='value', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:54:35.288376
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:36.792273
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:40.488695
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:54:46.735193
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='/Users/jeffrey/Documents/GitHub/httpie/test/data/raw_json_file.json',
        orig='@/Users/jeffrey/Documents/GitHub/httpie/test/data/raw_json_file.json',
    )

# Generated at 2022-06-17 19:54:51.104431
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:54:52.909708
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:55.143148
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:01.899897
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt',
        orig='file@/tmp/test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt;image/png',
        orig='file@/tmp/test.txt;image/png',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 19:55:05.259804
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='',
        orig=''
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:14.963617
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;text/html;', '@')

# Generated at 2022-06-17 19:55:28.138783
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/jpeg', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:55:31.070661
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:35.614531
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='data', value='{"a": 1}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1}

# Generated at 2022-06-17 19:55:37.970771
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', sep='', key='', value='/home/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:55:41.193246
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'


# Generated at 2022-06-17 19:55:45.430948
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:50.601710
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:55:52.211677
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(key='', value='test.txt', sep='')) == 'test'

# Generated at 2022-06-17 19:55:55.305040
# Unit test for function load_text_file
def test_load_text_file():
    arg = KeyValueArg(key='', value='', sep='', orig='')
    assert load_text_file(arg) == ''

# Generated at 2022-06-17 19:56:05.578581
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/Users/joe/test.txt',
        orig='file@/Users/joe/test.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'This is a test file.\n'
    f.close()

    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/Users/joe/test.txt;image/png',
        orig='file@/Users/joe/test.txt;image/png',
    )


# Generated at 2022-06-17 19:56:20.285701
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('test', 'test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:21.711787
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('-d', '@test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:56:24.520231
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:56:30.602337
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = "test.txt"
    mime_type = "text/plain"
    arg = KeyValueArg(key="", value=filename, sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), mime_type)
    arg = KeyValueArg(key="", value=filename + SEPARATOR_FILE_UPLOAD_TYPE + mime_type, sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), mime_type)


# Generated at 2022-06-17 19:56:34.630340
# Unit test for function load_text_file
def test_load_text_file():
    from httpie.cli.argtypes import KeyValueArg
    item = KeyValueArg(orig="data-raw", key="data-raw", value="test.txt", sep="=")
    assert load_text_file(item) == "test"


# Generated at 2022-06-17 19:56:37.748518
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '', '', '')
    assert process_data_embed_raw_json_file_arg(arg) == None

# Generated at 2022-06-17 19:56:41.783567
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:56:45.264728
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:56:58.686809
# Unit test for function load_text_file
def test_load_text_file():
    # Test for a valid file
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')
    assert load_text_file(item) == 'test'

    # Test for a non-existent file
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test1.txt')
    try:
        load_text_file(item)
        assert False
    except ParseError:
        assert True

    # Test for a non-text file
    item = KeyValueArg(orig='@test.txt', sep='@', key='', value='test2.png')
    try:
        load_text_file(item)
        assert False
    except ParseError:
        assert True



# Generated at 2022-06-17 19:57:02.763440
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 'b'}

# Generated at 2022-06-17 19:57:23.445710
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep='@', value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep='@', value='/tmp/test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep='@', value='/tmp/test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:26.602944
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:31.889329
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@/Users/joe/test.txt',
        value='/Users/joe/test.txt',
    )
    assert load_text_file(item) == 'This is a test file.\n'

# Generated at 2022-06-17 19:57:34.237408
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:57:35.473536
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'Hello World!'


# Generated at 2022-06-17 19:57:38.325603
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    process_data_embed_raw_json_file_arg(arg)

# Generated at 2022-06-17 19:57:45.051121
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    arg.value = 'test_data/valid_json.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

    # Test for invalid json file
    arg.value = 'test_data/invalid_json.json'
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"": test_data/invalid_json.json: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)'
    else:
        assert False

    # Test

# Generated at 2022-06-17 19:57:53.395711
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        value='{"a": 1, "b": 2}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@/tmp/test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:58:03.530559
# Unit test for function load_text_file
def test_load_text_file():
    # Test case 1:
    item = KeyValueArg(orig='test', sep='', key='test', value='test.txt')
    assert load_text_file(item) == 'test'

    # Test case 2:
    item = KeyValueArg(orig='test', sep='', key='test', value='test.txt')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test.txt\''

    # Test case 3:
    item = KeyValueArg(orig='test', sep='', key='test', value='test.txt')

# Generated at 2022-06-17 19:58:12.650061
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')


# Generated at 2022-06-17 19:58:26.797832
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:58:32.723385
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:41.616848
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file@/home/user/file.txt')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file@/home/user/file.txt;image/png')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file@/home/user/file.txt;')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file@/home/user/file.txt;text/plain')


# Generated at 2022-06-17 19:58:53.937489
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;text/plain;', sep='@')

# Generated at 2022-06-17 19:58:57.328247
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:58.890855
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:05.210692
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 19:59:14.773239
# Unit test for function load_text_file

# Generated at 2022-06-17 19:59:17.632144
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        key='test',
        value='test.txt',
        sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS,
        orig='@test.txt'
    )
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:24.905707
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig=None,
        value=None,
    )
    arg.value = './test_data/test_json_file.json'
    assert process_data_embed_raw_json_file_arg(arg) == {
        'a': 1,
        'b': 2,
        'c': 3,
    }


# Generated at 2022-06-17 19:59:47.339870
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:56.181290
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 20:00:05.376596
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 20:00:07.456993
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:00:11.565112
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', 'rb', 'type')

# Generated at 2022-06-17 20:00:15.649508
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='test', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 20:00:25.117325
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', 'test.txt', None)
    arg = KeyValueArg('file', 'test.txt;text/plain', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', 'test.txt', 'text/plain')
    arg = KeyValueArg('file', 'test.txt;', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', 'test.txt', '')
    arg = KeyValueArg('file', 'test.txt;;', SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg)

# Generated at 2022-06-17 20:00:34.342762
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.value = '{"a": 1, "b": 2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}
    arg.value = '{"a": 1, "b": 2'
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"": Expecting property name enclosed in double quotes: line 1 column 2 (char 1)'
    arg.value = '{"a": 1, "b": 2, "c": 3}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-17 20:00:35.504061
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:00:47.337807
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        value='/path/to/file.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file.txt'
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/path/to/file.txt', 'rb'),
        'text/plain'
    )

    arg = KeyValueArg(
        key='file',
        value='/path/to/file.txt;image/jpeg',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/path/to/file.txt;image/jpeg'
    )

# Generated at 2022-06-17 20:01:03.474801
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '')
    arg.key = 'test'
    arg.value = '{"test": "test"}'
    assert process_data_embed_raw_json_file_arg(arg) == {"test": "test"}

# Generated at 2022-06-17 20:01:10.453730
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='key',
        value='value',
        orig='key:=value'
    )
    assert process_file_upload_arg(arg) == ('value', 'value', None)

    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='key',
        value='value;type',
        orig='key:=value;type'
    )
    assert process_file_upload_arg(arg) == ('value', 'value', 'type')

# Generated at 2022-06-17 20:01:12.061263
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:01:14.019309
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="test", value="test.json", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {"test": "test"}

# Generated at 2022-06-17 20:01:24.666178
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(key='', value='test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

    arg = KeyValueArg(key='', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 20:01:28.549030
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:01:37.110012
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 20:01:38.863740
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', sep='@', key='', value='test.txt')) == 'test\n'

# Generated at 2022-06-17 20:01:42.321020
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('-d', '@test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:45.474333
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        '-d',
        '@/Users/yun/Desktop/test.txt',
        '@/Users/yun/Desktop/test.txt',
        '@',
        '/Users/yun/Desktop/test.txt'
    )
    assert load_text_file(item) == 'test'