

# Generated at 2022-06-17 19:52:13.066397
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.value = '{"a": 1, "b": 2}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}
    arg.value = '{"a": 1, "b": 2, "c": {"d": 3}}'
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2, "c": {"d": 3}}
    arg.value = '{"a": 1, "b": 2, "c": [{"d": 3}, {"e": 4}]}'

# Generated at 2022-06-17 19:52:24.123806
# Unit test for function process_data_raw_json_embed_arg

# Generated at 2022-06-17 19:52:27.701267
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_RAW_JSON, value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a": 1}


# Generated at 2022-06-17 19:52:38.339580
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(key='file', value='/tmp/test.txt;image/jpeg', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/jpeg'
    assert f.read() == b'hello world'
    f.close()

   

# Generated at 2022-06-17 19:52:49.695553
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/test.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', value='/home/user/test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), '')
    arg

# Generated at 2022-06-17 19:52:52.915708
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='test', key='test', sep='', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:53:00.489564
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for file not found
    try:
        process_data_embed_raw_json_file_arg(KeyValueArg(key="test", value="test.json", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE))
    except ParseError as e:
        assert str(e) == '"test": [Errno 2] No such file or directory: \'test.json\''

    # Test for invalid json

# Generated at 2022-06-17 19:53:03.676461
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='', value='{"name":"John Doe"}', sep=SEPARATOR_DATA_RAW_JSON)
    assert process_data_raw_json_embed_arg(arg) == {"name":"John Doe"}


# Generated at 2022-06-17 19:53:08.768042
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:53:14.334448
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

# Generated at 2022-06-17 19:53:27.719285
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:38.270424
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(key='file', value='/tmp/test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/html'
    assert f.read() == b'hello world'
    f.close()

# Generated at 2022-06-17 19:53:40.989976
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('', '', '')

# Generated at 2022-06-17 19:53:43.540225
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:53:48.390649
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:59.298817
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:54:03.250734
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep='@', value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:54:14.575080
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key=None,
        value='/home/user/file.txt',
        orig='@/home/user/file.txt',
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'file content'
    f.close()

    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key=None,
        value='/home/user/file.txt;image/png',
        orig='@/home/user/file.txt;image/png',
    )
    filename, f, mime_type = process_

# Generated at 2022-06-17 19:54:16.386814
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:20.900292
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    filename = 'test.txt'
    mime_type = 'text/plain'
    arg = KeyValueArg(filename, '', '', '', '', '', '', '')
    assert process_file_upload_arg(arg) == (filename, open(filename, 'rb'), mime_type)


# Generated at 2022-06-17 19:54:28.379537
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:54:30.979219
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@test.txt', '@test.txt')) == 'test\n'

# Generated at 2022-06-17 19:54:35.448413
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:54:39.231375
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:54:41.908506
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:54:51.879669
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png;', '@')

# Generated at 2022-06-17 19:54:54.345348
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:54:58.104608
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key=None, value='/tmp/test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:55:02.456051
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'Test file'


# Generated at 2022-06-17 19:55:12.622226
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {
        "name": "httpie",
        "description": "cURL for humans",
        "version": "0.9.9",
        "keywords": [
            "http",
            "cli",
            "curl",
            "json",
            "rest"
        ],
        "author": {
            "name": "Jakub Roztocil",
            "email": "jakub@roztocil.co"
        },
        "license": "BSD"
    }

# Generated at 2022-06-17 19:55:22.687948
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:29.231869
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestJSONDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.items import RequestItems
    from httpie.cli.utils import JSONType
    from httpie.utils import load_json_preserve_order
    from typing import Dict, List, Tuple, Union
    import os
    import pytest

    # Test case 1:
    #   - file exists
    #   - file is a text file
    #   - file contains valid json
    #   - file contains a list
    #   - file contains a dictionary
    #   - file contains a string
    #   - file contains a number
    #   - file contains a boolean
    #   - file contains a null
    #   - file

# Generated at 2022-06-17 19:55:41.003201
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='test.txt;image/png', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='file', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')

# Generated at 2022-06-17 19:55:45.586140
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:55:54.209026
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/tmp/test.txt',
        orig='test@/tmp/test.txt'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(
        key='test',
        sep=SEPARATOR_FILE_UPLOAD,
        value='/tmp/test.txt;image/png',
        orig='test@/tmp/test.txt;image/png'
    )

# Generated at 2022-06-17 19:55:56.689297
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('a', 'b', 'c')
    assert process_data_embed_raw_json_file_arg(arg) == 'c'

# Generated at 2022-06-17 19:56:01.442995
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='key',
        value='value',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE
    )
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:56:04.706229
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')



# Generated at 2022-06-17 19:56:15.710580
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 19:56:19.472017
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep='', orig='')
    item.value = 'test.txt'
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:56:37.606406
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/jpeg', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:56:45.477281
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(key='', value='test_data/valid_json.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

    # Test for invalid json file
    arg = KeyValueArg(key='', value='test_data/invalid_json.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"@test_data/invalid_json.json": No JSON object could be decoded'

    # Test for non-existent json

# Generated at 2022-06-17 19:56:49.471995
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:56:57.355596
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/png', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')

# Generated at 2022-06-17 19:57:05.608041
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep='@', value='test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep='@', value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep='@', value='test.txt;text/plain')
    assert process

# Generated at 2022-06-17 19:57:17.380168
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        'file',
        'test.txt;text/plain',
        '@',
        '@test.txt;text/plain'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

    arg = KeyValueArg(
        'file',
        'test.txt;',
        '@',
        '@test.txt;'
    )

# Generated at 2022-06-17 19:57:19.205903
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('data', '@test.json', '@')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:57:22.155371
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('-F', 'filename.txt')
    assert process_file_upload_arg(arg) == ('filename.txt', open('filename.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('-F', 'filename.txt;type=image/jpeg')
    assert process_file_upload_arg(arg) == ('filename.txt', open('filename.txt', 'rb'), 'image/jpeg')


# Generated at 2022-06-17 19:57:25.320429
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/home/user/file.txt')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'file.txt'
    assert mime_type == 'text/plain'
    assert f.read().decode() == 'file content'
    f.close()


# Generated at 2022-06-17 19:57:28.145643
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('test', 'test_data_embed_raw_json_file_arg.json', ':')
    assert process_data_embed_raw_json_file_arg(arg) == {'test': 'test'}

# Generated at 2022-06-17 19:57:46.941601
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:57:56.906348
# Unit test for function load_text_file
def test_load_text_file():
    # Create a temporary file
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b"Hello World")
    f.close()

    # Test
    item = KeyValueArg(None, None, None, None, None, None)
    item.value = f.name
    assert load_text_file(item) == "Hello World"

    # Cleanup
    os.unlink(f.name)

# Generated at 2022-06-17 19:58:01.158134
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='@test.txt', sep='@', key='@test.txt', value='test.txt')) == 'test'

# Generated at 2022-06-17 19:58:03.369846
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('key', 'value', ':')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:58:07.669851
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('', None, None)

# Generated at 2022-06-17 19:58:12.753029
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:20.851684
# Unit test for function process_file_upload_arg

# Generated at 2022-06-17 19:58:27.049194
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        value='{"a": 1, "b": 2}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}

# Generated at 2022-06-17 19:58:33.062458
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test.json',
        orig='@test.json',
    )
    expected = {'a': 1, 'b': 2}
    actual = process_data_embed_raw_json_file_arg(arg)
    assert actual == expected

# Generated at 2022-06-17 19:58:39.348214
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/path/to/file', sep='@')
    assert process_file_upload_arg(arg) == ('file', open('/path/to/file', 'rb'), 'application/octet-stream')
    arg = KeyValueArg(key='file', value='/path/to/file;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('file', open('/path/to/file', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:58:58.629261
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'Hello World'


# Generated at 2022-06-17 19:59:05.394115
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/tmp/test.txt;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/tmp/test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:59:10.281322
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@test.json',
        value='test.json',
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:14.694814
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:59:16.572845
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('a', 'b', 'c')
    assert process_data_embed_raw_json_file_arg(arg) == 'c'

# Generated at 2022-06-17 19:59:27.401978
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    # Test case 1: filename only
    arg = KeyValueArg(
        key='file',
        value='/tmp/test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/tmp/test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

    # Test case 2: filename and mime type
    arg = KeyValueArg(
        key='file',
        value='/tmp/test.txt;image/jpeg',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/tmp/test.txt;image/jpeg'
    )

# Generated at 2022-06-17 19:59:29.884046
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='test', value='test.txt')
    assert load_text_file(item) == 'test\n'

# Generated at 2022-06-17 19:59:32.376037
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:34.943273
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS, orig='')
    assert load_text_file(item) == ''

# Generated at 2022-06-17 19:59:37.735717
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key=None, value='test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:00:22.572295
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:00:27.646563
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 20:00:31.842209
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:00:36.493625
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        value='~/test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@~/test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('~/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:00:47.291604
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', open('value', 'rb'), None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;type')
    assert process_file_upload_arg(arg) == ('value', open('value', 'rb'), 'type')
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;')
    assert process_file_upload_arg(arg) == ('value', open('value', 'rb'), '')


# Generated at 2022-06-17 20:00:50.140891
# Unit test for function load_text_file
def test_load_text_file():
    path = "./test_data/test_load_text_file.txt"
    item = KeyValueArg(path, "", "")
    assert load_text_file(item) == "test_load_text_file"

# Generated at 2022-06-17 20:00:54.348422
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', value='value', sep=';')
    assert process_file_upload_arg(arg) == ('value', 'rb', None)

# Generated at 2022-06-17 20:00:56.491458
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(
        key='',
        sep='',
        orig='',
        value='',
    )
    assert load_text_file(item) == ''

# Generated at 2022-06-17 20:00:57.587450
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test\n'

# Generated at 2022-06-17 20:01:02.694797
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(key='test', value='test.txt', sep='=')
    assert load_text_file(item) == 'test'

    # Test for file not found
    item = KeyValueArg(key='test', value='test1.txt', sep='=')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test=test1.txt": [Errno 2] No such file or directory: \'test1.txt\''

    # Test for not a UTF8 or ASCII-encoded text file
    item = KeyValueArg(key='test', value='test2.txt', sep='=')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str

# Generated at 2022-06-17 20:01:27.782850
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt',
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open('test.txt', 'rb'),
        'text/plain',
    )

    arg = KeyValueArg(
        'file',
        'test.txt;image/png',
        '@',
        '@test.txt;image/png',
    )
    assert process_file_upload_arg(arg) == (
        'test.txt',
        open('test.txt', 'rb'),
        'image/png',
    )

# Generated at 2022-06-17 20:01:34.421551
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(key='', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt;image/png')
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/png'
    assert f.read() == b'hello world'
    f.close()

# Generated at 2022-06-17 20:01:37.973273
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:01:48.586505
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 20:01:53.710180
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:01:56.367693
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key=None, sep=None, orig='', value='/tmp/test.txt')
    assert load_text_file(item) == 'test'