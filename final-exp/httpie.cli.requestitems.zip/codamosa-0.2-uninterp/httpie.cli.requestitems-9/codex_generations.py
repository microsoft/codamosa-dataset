

# Generated at 2022-06-17 19:52:06.463929
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test_data/test_data.json',
        orig='@test_data/test_data.json'
    )

# Generated at 2022-06-17 19:52:09.703595
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:14.553152
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:52:19.165017
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(
        key=None,
        sep=SEPARATOR_DATA_RAW_JSON,
        orig='@raw_json_file',
        value='{"a": "b"}'
    )
    assert process_data_raw_json_embed_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:52:24.875428
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:52:27.275268
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('-d', '@test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:52:38.166265
# Unit test for function load_text_file
def test_load_text_file():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.constants import SEPARATOR_DATA_EMBED_FILE_CONTENTS
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.requestitems import load_text_file
    from httpie.cli.requestitems import process_data_embed_file_contents_arg
    from httpie.cli.requestitems import RequestItems
    from httpie.cli.requestitems import process_data_item_arg
    from httpie.cli.requestitems import process_data_raw_json_embed_arg
    from httpie.cli.requestitems import process_data_embed_raw_json_file_arg
    from httpie.cli.requestitems import process_file_upload

# Generated at 2022-06-17 19:52:49.499539
# Unit test for function load_text_file
def test_load_text_file():
    # Test for load_text_file
    # Test for normal case
    item = KeyValueArg(key='test', value='test.txt', sep='=')
    assert load_text_file(item) == 'test'
    # Test for file not found
    item = KeyValueArg(key='test', value='test1.txt', sep='=')
    try:
        load_text_file(item)
    except ParseError as e:
        assert str(e) == '"test=test1.txt": [Errno 2] No such file or directory: \'test1.txt\''
    # Test for not a UTF8 or ASCII-encoded text file
    item = KeyValueArg(key='test', value='test2.txt', sep='=')

# Generated at 2022-06-17 19:52:57.258319
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/tmp/test.txt;image/jpeg', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'image/jpeg')

# Generated at 2022-06-17 19:53:03.138470
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        value='test_data/test_data.json',
        orig=''
    )
    value = process_data_embed_raw_json_file_arg(arg)
    assert value == {
        "a": 1,
        "b": 2,
        "c": 3
    }

# Generated at 2022-06-17 19:53:11.789240
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(orig='a', key='a', sep='=', value='{"a":1}')
    assert process_data_raw_json_embed_arg(arg) == {"a":1}

# Generated at 2022-06-17 19:53:17.111081
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:53:19.071849
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('@/tmp/test.txt')) == 'test'

# Generated at 2022-06-17 19:53:29.080810
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/test.txt;text/plain', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='file', value='/home/user/test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/user/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:53:32.961547
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key="", sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value="test.json")
    assert process_data_embed_raw_json_file_arg(arg) == {"a": 1, "b": 2}


# Generated at 2022-06-17 19:53:43.444378
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg(key='key', value='value', sep=':')
    assert process_data_raw_json_embed_arg(arg) == 'value'
    arg = KeyValueArg(key='key', value='[1, 2, 3]', sep=':')
    assert process_data_raw_json_embed_arg(arg) == [1, 2, 3]
    arg = KeyValueArg(key='key', value='{"a": 1, "b": 2}', sep=':')
    assert process_data_raw_json_embed_arg(arg) == {'a': 1, 'b': 2}
    arg = KeyValueArg(key='key', value='{"a": 1, "b": 2, "c": [1, 2, 3]}', sep=':')
    assert process_data_raw_json_

# Generated at 2022-06-17 19:53:44.928658
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:53:58.292941
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='test', value='test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;;', sep='@')
    assert process_file_

# Generated at 2022-06-17 19:54:07.635811
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/html', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/html')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValue

# Generated at 2022-06-17 19:54:18.462795
# Unit test for function process_data_raw_json_embed_arg
def test_process_data_raw_json_embed_arg():
    arg = KeyValueArg('a', 'b', 'a:b')
    assert process_data_raw_json_embed_arg(arg) == 'b'
    arg = KeyValueArg('a', '1', 'a:1')
    assert process_data_raw_json_embed_arg(arg) == 1
    arg = KeyValueArg('a', 'true', 'a:true')
    assert process_data_raw_json_embed_arg(arg) == True
    arg = KeyValueArg('a', 'false', 'a:false')
    assert process_data_raw_json_embed_arg(arg) == False
    arg = KeyValueArg('a', 'null', 'a:null')
    assert process_data_raw_json_embed_arg(arg) == None

# Generated at 2022-06-17 19:54:28.085729
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('test', 'test.txt')) == 'test'


# Generated at 2022-06-17 19:54:32.063885
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='value')
    assert process_data_embed_raw_json_file_arg(arg) == 'value'

# Generated at 2022-06-17 19:54:38.046738
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep=SEPARATOR_FILE_UPLOAD)
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'This is a test file\n'
    f.close()

# Generated at 2022-06-17 19:54:47.832374
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep='@', value='test.txt;image/png')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='test', sep='@', value='test.txt;')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', sep='@', value='test.txt;;')
    assert process_file_

# Generated at 2022-06-17 19:54:59.063712
# Unit test for function load_text_file
def test_load_text_file():
    # Test for normal case
    item = KeyValueArg(key='', value='', sep='')
    item.value = './test_data/test_load_text_file.txt'
    item.orig = './test_data/test_load_text_file.txt'
    assert load_text_file(item) == 'test_load_text_file\n'

    # Test for file not exist
    item.value = './test_data/test_load_text_file_not_exist.txt'
    item.orig = './test_data/test_load_text_file_not_exist.txt'

# Generated at 2022-06-17 19:55:03.122558
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(
        key='',
        value='{"a": "b"}',
        sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE,
        orig='@{"a": "b"}'
    )
    assert process_data_embed_raw_json_file_arg(arg) == {"a": "b"}

# Generated at 2022-06-17 19:55:04.806852
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:08.821714
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('test_file', 'test_file.txt', '@')
    assert process_file_upload_arg(arg) == ('test_file.txt', open('test_file.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:11.569104
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:14.691501
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:55:33.490061
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:37.955243
# Unit test for function load_text_file
def test_load_text_file():
    # Test for file not found
    try:
        load_text_file(KeyValueArg(None, None, 'file_not_found', None))
    except ParseError as e:
        assert str(e) == '"file_not_found": [Errno 2] No such file or directory: \'file_not_found\''

    # Test for file is not a text file
    try:
        load_text_file(KeyValueArg(None, None, 'test/httpie/cli/test_request_items.py', None))
    except ParseError as e:
        assert str(e) == '"test/httpie/cli/test_request_items.py": cannot embed the content of "test/httpie/cli/test_request_items.py", not a UTF8 or ASCII-encoded text file'

   

# Generated at 2022-06-17 19:55:41.661740
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/user/file.txt', sep='@')
    assert process_file_upload_arg(arg) == ('file.txt', open('/home/user/file.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:55:44.144249
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 19:55:47.473881
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/tmp/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:55:51.514576
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:56:02.451349
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig='', key='', sep='', value='/Users/jeff/Documents/GitHub/httpie/httpie/cli/__init__.py')) == '"""\nCLI entry point.\n\n"""\nfrom __future__ import unicode_literals\n\nimport os\nimport sys\n\nfrom httpie.cli import main\n\n\ndef main_():\n    """\n    The main entry point.\n\n    """\n    sys.exit(main(sys.argv[1:]))\n\n\nif __name__ == \'__main__\':\n    main_()\n'

# Generated at 2022-06-17 19:56:14.987346
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        'file',
        'test.txt',
        '@',
        '@test.txt'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'text/plain'
    assert f.read() == b'hello world'
    f.close()

    arg = KeyValueArg(
        'file',
        'test.txt;image/png',
        '@',
        '@test.txt;image/png'
    )
    filename, f, mime_type = process_file_upload_arg(arg)
    assert filename == 'test.txt'
    assert mime_type == 'image/png'
    assert f.read() == b'hello world'

# Generated at 2022-06-17 19:56:21.236856
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        sep=SEPARATOR_FILE_UPLOAD,
        key='file',
        value='/tmp/test.txt',
        orig='file@/tmp/test.txt'
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')



# Generated at 2022-06-17 19:56:24.060918
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='', value='/Users/lizhe/Documents/GitHub/httpie/httpie/cli/constants.py', sep='', orig='/Users/lizhe/Documents/GitHub/httpie/httpie/cli/constants.py')
    print(load_text_file(item))


# Generated at 2022-06-17 19:56:38.027350
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg(orig="@test.txt", key="", sep="", value="test.txt")) == "test\n"

# Generated at 2022-06-17 19:56:41.063367
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='', key='', sep='', value='/Users/jianghao/Desktop/test.txt')
    print(load_text_file(item))


# Generated at 2022-06-17 19:56:46.323286
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('test.txt', 'test.txt;text/plain')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('test.txt', 'test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:56:59.715830
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/png', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/png')
    arg = KeyValueArg(key='test', value='test.txt;', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;image/png', sep='@')
    assert process

# Generated at 2022-06-17 19:57:02.340475
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:57:05.604328
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:08.797891
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_DATA_EMBED_FILE_CONTENTS)
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:12.553605
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='/tmp/test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:57:16.357095
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, orig='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:57:18.952000
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='~/test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:57:55.119501
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test_data/test_json.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

    # Test for invalid json file
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test_data/test_json_invalid.json')
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError as e:
        assert str(e) == '"@test_data/test_json_invalid.json": Expecting value: line 1 column 1 (char 0)'



# Generated at 2022-06-17 19:58:03.077124
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value')
    assert process_file_upload_arg(arg) == ('value', 'value', None)
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;mime')
    assert process_file_upload_arg(arg) == ('value', 'value', 'mime')
    arg = KeyValueArg(key='key', sep=SEPARATOR_FILE_UPLOAD, value='value;mime;')
    assert process_file_upload_arg(arg) == ('value', 'value', 'mime')

# Generated at 2022-06-17 19:58:06.124740
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('', '', '', 'test.txt')) == 'test'

# Generated at 2022-06-17 19:58:10.369258
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE, value='test.json')
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:58:13.215604
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='--data-binary @test.txt', key='', value='test.txt', sep='=')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:15.313446
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:17.916159
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', sep='', key='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:58:23.626913
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', sep=SEPARATOR_FILE_UPLOAD, value='/tmp/test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('/tmp/test.txt', 'rb'), 'text/plain')


# Generated at 2022-06-17 19:58:26.462456
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:58:32.687533
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='test',
        value='test.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='test@test.txt',
    )
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 19:59:00.483383
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 19:59:06.578735
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('file', 'test.txt', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;image/jpeg', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'image/jpeg')
    arg = KeyValueArg('file', 'test.txt;', '@')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg('file', 'test.txt;;', '@')

# Generated at 2022-06-17 19:59:18.023873
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    # Test for valid json file
    arg = KeyValueArg(key='', value='test.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}
    # Test for invalid json file
    arg = KeyValueArg(key='', value='test_invalid.json', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    try:
        process_data_embed_raw_json_file_arg(arg)
    except ParseError:
        assert True
    else:
        assert False
    # Test for invalid file path

# Generated at 2022-06-17 19:59:19.923439
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('key', 'value')
    assert load_text_file(item) == 'value'

# Generated at 2022-06-17 19:59:23.496603
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg('--data', '@test_file.txt')
    assert load_text_file(item) == 'test_file_content'

# Generated at 2022-06-17 19:59:29.843224
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', value='test.txt', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;text/plain', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')
    arg = KeyValueArg(key='test', value='test.txt;', sep=SEPARATOR_FILE_UPLOAD)
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), '')

# Generated at 2022-06-17 19:59:39.226560
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(
        key='file',
        value='/home/user/file.txt',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt',
    )
    assert process_file_upload_arg(arg) == (
        'file.txt',
        open('/home/user/file.txt', 'rb'),
        'text/plain',
    )

    arg = KeyValueArg(
        key='file',
        value='/home/user/file.txt;image/png',
        sep=SEPARATOR_FILE_UPLOAD,
        orig='file@/home/user/file.txt;image/png',
    )

# Generated at 2022-06-17 19:59:44.736111
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep='')
    arg.orig = '@test.json'
    arg.value = 'test.json'
    assert process_data_embed_raw_json_file_arg(arg) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:59:47.934767
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 19:59:50.446425
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg(key='', value='', sep=SEPARATOR_DATA_EMBED_RAW_JSON_FILE)
    assert process_data_embed_raw_json_file_arg(arg) == {}

# Generated at 2022-06-17 20:00:59.816826
# Unit test for function load_text_file
def test_load_text_file():
    # Test for file not exist
    try:
        load_text_file(KeyValueArg(orig='@/not_exist', sep='@', key='', value='/not_exist'))
    except ParseError as e:
        assert str(e) == '"@/not_exist": [Errno 2] No such file or directory: \'/not_exist\''

    # Test for file not text

# Generated at 2022-06-17 20:01:02.726029
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='test', sep='@', value='test.txt')
    assert process_file_upload_arg(arg) == ('test.txt', open('test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:01:06.561077
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(orig='test', key='test', sep='', value='test.txt')
    assert load_text_file(item) == 'test'

# Generated at 2022-06-17 20:01:07.755856
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg('a', 'b')) == 'b'

# Generated at 2022-06-17 20:01:18.453965
# Unit test for function process_data_embed_raw_json_file_arg
def test_process_data_embed_raw_json_file_arg():
    arg = KeyValueArg('', '', '', '', '', '', '', '', '', '', '')
    arg.key = 'key'
    arg.value = 'value'
    arg.orig = 'orig'
    arg.sep = 'sep'
    arg.raw = 'raw'
    arg.orig_key = 'orig_key'
    arg.orig_value = 'orig_value'
    arg.orig_sep = 'orig_sep'
    arg.orig_raw = 'orig_raw'
    arg.orig_pair = 'orig_pair'
    arg.orig_pair_raw = 'orig_pair_raw'
    arg.orig_pair_sep = 'orig_pair_sep'

# Generated at 2022-06-17 20:01:28.432528
# Unit test for function process_data_embed_raw_json_file_arg

# Generated at 2022-06-17 20:01:32.562269
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg('key', 'value', 'sep')
    arg.key = 'key'
    arg.value = 'value'
    arg.sep = 'sep'
    arg.orig = 'orig'
    assert process_file_upload_arg(arg) == ('value', 'orig', 'sep')

# Generated at 2022-06-17 20:01:37.677188
# Unit test for function load_text_file
def test_load_text_file():
    item = KeyValueArg(key=None, sep=None, orig=None, value=None)
    item.value = './test_data/test_text_file.txt'
    assert load_text_file(item) == 'This is a test text file.\n'


# Generated at 2022-06-17 20:01:39.751209
# Unit test for function process_file_upload_arg
def test_process_file_upload_arg():
    arg = KeyValueArg(key='file', value='/home/test.txt', sep='@')
    assert process_file_upload_arg(arg) == ('test.txt', open('/home/test.txt', 'rb'), 'text/plain')

# Generated at 2022-06-17 20:01:42.623677
# Unit test for function load_text_file
def test_load_text_file():
    assert load_text_file(KeyValueArg("test", "test.txt")) == "test"