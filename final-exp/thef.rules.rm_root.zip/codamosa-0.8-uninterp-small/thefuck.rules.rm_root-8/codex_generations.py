

# Generated at 2022-06-26 06:39:19.134736
# Unit test for function match
def test_match():
    assert match(b'rm / -rf') == 'rm --no-preserve-root / -rf'
    assert match(b'rm / -rf') != 'rm / -rf'


# Generated at 2022-06-26 06:39:23.594111
# Unit test for function match
def test_match():
    var_1 = None
    var_1 = "rm / --no-preserve-root 2>/dev/null"
    var_2 = match(var_1)
    var_3 = "rm /"
    var_4 = match(var_3)
    var_5 = True
    var_6 = "rm blah blah blah blah blah blah"
    var_7 = match(var_6)


# Generated at 2022-06-26 06:39:25.711609
# Unit test for function match
def test_match():
    assert match(b'sudo rm -rf / --no-preserve-root --help')


# Generated at 2022-06-26 06:39:26.299992
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-26 06:39:29.307184
# Unit test for function get_new_command
def test_get_new_command():
    bytes_0 = b'-'
    var_0 = get_new_command(bytes_0)

# Generated at 2022-06-26 06:39:37.999768
# Unit test for function match
def test_match():
    var_0 = b'rm -rf /'
    assert match(var_0) == False
    var_1 = b'rm -rf /'

# Generated at 2022-06-26 06:39:40.705069
# Unit test for function get_new_command
def test_get_new_command():
    bytes_0 = b'--no-preserve-root'
    str_0 = u'--no-preserve-root'
    retval_0 = get_new_command(bytes_0)
    assert retval_0 == str_0


# Generated at 2022-06-26 06:39:43.504487
# Unit test for function match
def test_match():
    input_0 = b'-rm --no-preserve-root'
    expected_0 = True
    var_0 = match(input_0)
    assert var_0 == expected_0


# Generated at 2022-06-26 06:39:45.166527
# Unit test for function match
def test_match():
    test_case_0()

# Generated at 2022-06-26 06:39:46.844783
# Unit test for function get_new_command
def test_get_new_command():
    bytes_0 = b'-'
    var_0 = get_new_command(bytes_0)

# Generated at 2022-06-26 06:39:53.900992
# Unit test for function get_new_command

# Generated at 2022-06-26 06:40:02.568568
# Unit test for function match
def test_match():
    assert match(Command('rm /', stderr='rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe'))
    assert not match(Command('rm /', stderr='rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe\n', script='sudo rm --no-preserve-root /'))
    assert match(Command('rm /', stderr='rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe', script='sudo rm /'))


# Generated at 2022-06-26 06:40:07.809499
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'rm -rf /usr',u'rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe.')
    assert u'rm -rf /usr --no-preserve-root' == get_new_command(command)

# Generated at 2022-06-26 06:40:16.245330
# Unit test for function match
def test_match():
    command_1 = 'rm -rf /'
    assert match(Command(command=command_1, script=command_1))
    command_2 = 'rm -rf /home'
    assert match(Command(command=command_2, script=command_2)) is False
    command_3 = 'rm -rf /home --no-preserve-root'
    assert match(Command(command=command_3, script=command_3)) is False
    command_4 = 'rm -rf /some/path/some'
    assert match(Command(command=command_4, script=command_4)) is False



# Generated at 2022-06-26 06:40:22.291454
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /'))
    assert match(Command('rm -rf /',
        output='rm: it is dangerous to operate recursively on `/\'\n'
        'rm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('rm -rf /',
        output='rm: it is dangerous to operate recursively on `/\'\n'
        'rm: use --no-preserve-root to override this failsafe'), True)
    assert not match(Command('rm -rf /',
        output='rm: it is dangerous to operate recursively on `/\'\n'
        'rm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('rm -rf /'))
    assert n

# Generated at 2022-06-26 06:40:30.066539
# Unit test for function match
def test_match():
    assert match(Command('rm -rf --no-preserve-root /',
                         'rm: it is dangerous to operate recursively on `/\'\n'
                         'rm: use --no-preserve-root to override this failsafe\n'))
    assert match(sudo_support(Command('rm -rf --no-preserve-root /',
                         'rm: it is dangerous to operate recursively on `/\'\n'
                         'rm: use --no-preserve-root to override this failsafe\n')))
    assert not match(Command('ls -lR', ''))
    assert not match(Command('rm -rf /', ''))


# Generated at 2022-06-26 06:40:33.216619
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': u'rm /', 'output': ''})
    assert get_new_command(command) == 'rm / --no-preserve-root'

# Generated at 2022-06-26 06:40:43.293666
# Unit test for function match
def test_match():
    assert match(Command('rm -r /')) == True
    assert match(Command('rm -r / --no-preserve-root')) == False
    assert match(Command('sudo rm -r /')) == True
    assert match(Command('sudo rm -r / --no-preserve-root')) == False
    assert match(Command('sudo rm -r / --no-preserve-root',
                          'rm: it is dangerous to operate recursively on')) == True


# Generated at 2022-06-26 06:40:46.213022
# Unit test for function match
def test_match():
    assert match(Command('rm /', '', ''))
    assert not match(Command('rm /', '', '', stderr='error'))
    assert not match(Command('rm / --no-preserve-root', '', ''))



# Generated at 2022-06-26 06:40:53.613013
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf /', '', '')) == 'rm -rf / --no-preserve-root'
    assert get_new_command(Command('rm', '', '')) == 'rm --no-preserve-root'
    assert get_new_command(Command('rm -rf /', '', '', 'sudo')) == 'sudo rm -rf / --no-preserve-root'
    assert get_new_command(Command('rm', '', '', 'sudo')) == 'sudo rm --no-preserve-root'


# Generated at 2022-06-26 06:41:00.179785
# Unit test for function match
def test_match():
    script = 'rm -rf /'
    output = 'rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe.'

    assert(match(Script(script, output=output)) == True)


# Generated at 2022-06-26 06:41:01.652794
# Unit test for function match
def test_match():
    assert match(command) is True


# Generated at 2022-06-26 06:41:08.979960
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('sudo rm /')) == 'sudo rm / --no-preserve-root'
    assert get_new_command(Command('sudo rm / --recursive')) == 'sudo rm / --recursive --no-preserve-root'
    assert get_new_command(Command('rm /')) == 'rm / --no-preserve-root'
    assert get_new_command(Command('rm / --recursive')) == 'rm / --recursive --no-preserve-root'

# Generated at 2022-06-26 06:41:13.322019
# Unit test for function match
def test_match():
   command = Command('rm /', output="rm: it is dangerous to operate recursively on '/' (use --no-preserve-root to override)")
   assert match(command)
   command = Command('rm /', output="rm: it is dangerous to operate recursively on '/' (use --no-preserve-root to override)")
   assert not match(command)
   command = Command('rm -t /', output="rm: it is dangerous to operate recursively on '/' (use --no-preserve-root to override)")
   assert match(command)



# Generated at 2022-06-26 06:41:24.627094
# Unit test for function match
def test_match():
    assert match(Command('rm /', stderr='rm: it is dangerous to operate recursively on `/\'\nrm: use --no-preserve-root to override this failsafe'))
    assert match(Command('rm -r /foo bar/', stderr='rm: it is dangerous to operate recursively on `/\'\nrm: use --no-preserve-root to override this failsafe'))
    assert match(Command('rm -rf /foo bar/', stderr='rm: it is dangerous to operate recursively on `/\'\nrm: use --no-preserve-root to override this failsafe'))

# Generated at 2022-06-26 06:41:30.284112
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('sudo rm -rf /home/',
                                   stderr='rm: it is dangerous to operate recursively ...'
                                          'remove \'--no-preserve-root\' if you really want to do this')) == 'sudo rm --no-preserve-root -rf /home/'

# Generated at 2022-06-26 06:41:40.974099
# Unit test for function match
def test_match():
    assert match(ShellCommand("rm *",
                              "rm: it is dangerous to operate recursively on '*'\n" +
                              "rm: use --no-preserve-root to override this failsafe"))
    assert match(ShellCommand("rm --force *",
                              "rmdir: failed to remove '*/*/*/*/test': No such file or directory\n" +
                              "rm: it is dangerous to operate recursively on '*'\n" +
                              "rm: use --no-preserve-root to override this failsafe"))
    assert not match(ShellCommand("rm *",
                                  "rm: it is dangerous to operate recursively on '*'"))

# Generated at 2022-06-26 06:41:45.780571
# Unit test for function match

# Generated at 2022-06-26 06:41:53.531090
# Unit test for function match
def test_match():
    a = 'rm -f asdf/ asdf/asdf/ asdf/asdf/asdf 2>&1'
    b = 'rm: it is dangerous to operate recursively on ‘/’\n'
    c = 'rm: use --no-preserve-root to override this failsafe'
    command = Command(a, b + c)
    assert match(command)

    a = 'ls -la'
    b = 'ls: -la: No such file or directory\n'
    c = 'ls: use --no-preserve-root to override this failsafe'
    command = Command(a, b + c)
    assert not match(command)

    a = 'rm -f asdf/ asdf/asdf/ asdf/asdf/asdf --no-preserve-root 2>&1'


# Generated at 2022-06-26 06:41:57.408933
# Unit test for function get_new_command
def test_get_new_command():
        assert get_new_command(Command('rm -rf / --preserve-root', '')) == 'rm -rf / --preserve-root --no-preserve-root'

# Generated at 2022-06-26 06:42:09.808393
# Unit test for function get_new_command
def test_get_new_command():
    check_output = lambda *args, **kwargs: 'command output'
    call = lambda *args, **kwargs: 0
    command = Command('rm /', '', check_output=check_output, call=call)
    assert get_new_command(command) == 'rm --no-preserve-root /'

# Generated at 2022-06-26 06:42:12.824056
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', '', '', 1))
    assert not match(Command('rm -rf a', '', '', 1))
    assert not match(Command('rm --no-preserve-root -rf /', '', '', 1))

# Generated at 2022-06-26 06:42:17.136382
# Unit test for function match
def test_match():
    assert match(Command('rm /', '', ''))
    assert not match(Command('rm /', '', ''))
    assert match(Command('rm / --no-preserve-root', '', ''))
    assert not match(Command('rm / --no-preserve-root', '', ''))
    assert match(Command('rm / -rf', '', ''))


# Generated at 2022-06-26 06:42:20.037894
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /', '')
    new_command = get_new_command(command)
    assert new_command == 'rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:42:30.731253
# Unit test for function match

# Generated at 2022-06-26 06:42:39.101093
# Unit test for function match
def test_match():
    assert (match(Command(script='rm -rf /',
                         stderr='rm: it is dangerous to operate recursively on '/'',
                         output='rm: use --no-preserve-root to override this failsafe'))
            == True)

# Generated at 2022-06-26 06:42:44.012356
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("rm /", "-rf", "must be superuser.  rm: it is dangerous to operate recursively on '/'  rm: use --no-preserve-root to override this failsafe")
    assert get_new_command(command) == "rm / --no-preserve-root"


# Generated at 2022-06-26 06:42:45.434559
# Unit test for function match
def test_match():
    assert (match(Command('sudo rm /', '', '')))
    assert not (match(Command('ls', '', '')))

# Generated at 2022-06-26 06:42:54.985539
# Unit test for function match
def test_match():
    # Command with a `rm` and the slash `/` is a partner of match
    assert match(Command('rm', 'rm /'))
    # Command with a `rm` and the slash `/` and `--no-preserve-root`
    # set to command is not a partner of match
    assert not match(Command('rm', 'rm / --no-preserve-root'))
    # Command with a `rmdir` and the slash `/` is not a partner of match
    assert not match(Command('rmdir', 'rmdir /'))
    # Command with a `rm` and no slash is not a partner of match
    assert not match(Command('rm', 'rm'))


# Generated at 2022-06-26 06:43:00.683812
# Unit test for function match
def test_match():
    assert match(Command('rm /', output='rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe'))
    assert match(Command('rm /', output='rm: it is dangerous to operate recursively on'))
    assert not match(Command('rm /', output='rm: it is dangerous to operate recursively'))
    assert not match(Command('rm /', output='rm: it is dangerous'))
    assert not match(Command('rm /'))


# Generated at 2022-06-26 06:43:22.039989
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('echo 1') == 'echo 1'
    assert get_new_command('rm / --no-preserve-root') == 'rm / --no-preserve-root'
    assert get_new_command('rm /') == 'rm / --no-preserve-root'
    assert get_new_command('sudo rm / --no-preserve-root') == 'sudo rm / --no-preserve-root'
    assert get_new_command('sudo rm /') == 'sudo rm / --no-preserve-root'

# Generated at 2022-06-26 06:43:26.845000
# Unit test for function match
def test_match():
    command = Command('rm /', '', '', '', '', 0)
    assert match(command)
    command = Command('rm -rf /', '', '', '', '', 0)
    assert match(command)
    command = Command('rm -rf ~/', '', '', '', '', 0)
    assert not match(command)
    command = Command('rm ./', '', '', '', '', 0)
    assert not match(command)


# Generated at 2022-06-26 06:43:30.965235
# Unit test for function match
def test_match():
    assert match(get_command('rm /'))
    assert not match(get_command('rm --no-preserve-root /'))
    assert match(get_command('sudo rm /'))
    assert match(get_command('rm -rf /'))


# Generated at 2022-06-26 06:43:32.635345
# Unit test for function match
def test_match():
    command = Command('rm -rf /', 'rm: refusing to remove '/' directory:')
    assert(match(command))


# Generated at 2022-06-26 06:43:34.861871
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /')
    out = get_new_command(command)
    assert out == 'rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:43:41.880772
# Unit test for function match
def test_match():
    assert not match(Command('ls', ''))
    assert match(Command('rm -r /', '', output='rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe'))
    assert match(Command('rm -r /', '', output='rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe'))


# Generated at 2022-06-26 06:43:43.645147
# Unit test for function match
def test_match():
    cmd = 'rm -rf /'
    assert match(Command(cmd, '/home/user', '', 'test'))


# Generated at 2022-06-26 06:43:53.593787
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', '', '', '', 1))
    assert match(Command('rm -rf --no-preserve-root /', '', '', '', 1))
    assert match(Command('rm -rf /', '', 'rm: it is dangerous to operate recursively on `/\'\n'
                                          'rm: use --no-preserve-root to override this failsafe\n',
                          '', 1))
    assert not match(Command('rm -rf /', '', '', '', 0))
    assert not match(Command('rm -rf /', '', '', '', 1, 1.0))


# Generated at 2022-06-26 06:44:00.340914
# Unit test for function get_new_command
def test_get_new_command():
    command_error = Command('rm /', '')
    assert get_new_command(command_error) == 'rm / --no-preserve-root'
    command_warn = Command('rm .', 'ERROR: rm: missing operand\nTry \'rm --help\' for more information.')
    assert get_new_command(command_warn) == 'rm .'
    command_sudo = Command('sudo rm /', '')
    assert get_new_command(command_sudo) == 'sudo rm / --no-preserve-root'

# Generated at 2022-06-26 06:44:07.415363
# Unit test for function match
def test_match():
    assert match(Command("rm /", output="rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe."))
    assert not match(Command("rm /", output="rm: it is dangerous to operate recursively on '/'\nUse --no- pr eserve-root to override this failsafe."))
    assert not match(Command("rm -f --no-preserve-root /", output="rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe."))
    assert not match(Command("rm -f /", output="rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe."))

# Generated at 2022-06-26 06:44:48.083243
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('rm -rf')
    command2 = Command('rm')
    command3 = Command('rm -rf /')
    command4 = Command('rm /')

    assert get_new_command(command1) == 'rm --no-preserve-root -rf'
    assert get_new_command(command2) == 'rm --no-preserve-root'
    assert get_new_command(command3) == 'rm --no-preserve-root -rf /'
    assert get_new_command(command4) == 'rm --no-preserve-root /'
    assert get_new_command(command4, sudo=True) == 'sudo rm --no-preserve-root /'

# Generated at 2022-06-26 06:44:53.094228
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', '', 'rm: descend into write-protected directory ‘/’? '))
    assert not match(Command('rm -rf /', '', 'rm: descend into write-protected directory ‘/’? '))

# Generated at 2022-06-26 06:45:01.629990
# Unit test for function match
def test_match():
    """ Is the output of the match() function as expected? """
    from tests.utils import Command

    assert match(Command('rm /',
            output='rm: it is dangerous to operate recursively on \'/\'\n'
            'rm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('rm /',
            output='rm: it is dangerous to operate recursively on \'/\'\n'
            'rm: use --no-preserve-root to override this failsafe\n'
            'rm: farse!\n'
            'rm: I like to give you more output that you do not need'))


# Generated at 2022-06-26 06:45:05.725146
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /', 'It is dangerous\n')
    new_command = get_new_command(command)
    assert new_command == 'rm -rf --no-preserve-root /'

    command = Command('rm -rf /usr', 'It is dangerous\n')
    new_command = get_new_command(command)
    assert new_command == 'rm -rf --no-preserve-root /usr'

# Generated at 2022-06-26 06:45:12.344102
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    wrong_command = shell.and_('rm -rf /',
                               "rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe\n")
    new_command = shell.and_('rm -rf --no-preserve-root /',
                             "rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe\n")

    assert get_new_command(wrong_command) == new_command


# Generated at 2022-06-26 06:45:14.828030
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf /', '', '', '', 0, 0)) == 'sudo rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:45:19.747802
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('rm -rf /', '', 'rm: it is dangerous to operate recursively on `/\'\nrm: use --no-preserve-root to override this failsafe\n')) == \
           'rm -rf --no-preserve-root /'

# Generated at 2022-06-26 06:45:23.045676
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /', stderr='rm: it is dangerous to operate recursively on '/'\n'
                                        'rm: use --no-preserve-root to override this failsafe')
    assert get_new_command(command) == 'rm -rf --no-preserve-root /'

# Generated at 2022-06-26 06:45:26.596306
# Unit test for function match
def test_match():
    assert match(Command(script=u'rm /',
                         script_parts=[u'rm', u'/'],
                         output=u'remove symbolic link `/\'?'))
    
    assert not match(Command(script=u'rm /',
                         script_parts=[u'rm', u'/'],
                         output=u'rm: cannot remove `/\': Is a directory'))

# Generated at 2022-06-26 06:45:29.251157
# Unit test for function match
def test_match():
    assert_match(match, 'rm -rf *')
    assert_not_match(match, 'rm -rf * --no-preserve-root')
    assert_not_match(match, 'rm -rf /')
    assert_not_match(match, 'rm -rf * --preserve-root')


# Generated at 2022-06-26 06:46:56.870714
# Unit test for function match
def test_match():
    assert match(Command(script='rm /dir/dir1',
                         output="rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe"))



# Generated at 2022-06-26 06:47:05.227941
# Unit test for function match
def test_match():
    # match returns True when the command contains "rm /"
    assert match(Command('rm /opt/dir', ''))
    # match returns True when the command contains "rm /"
    assert match(Command('rm /opt/dir', ''))
    # match returns True when the command contains "rm /" and "--no-preserve-root" is not in command.script
    assert match(Command('rm /opt/dir --no-preserve-root', ''))
    # match returns False when the command doesn't contain "rm"
    assert not match(Command('rm opt/dir', ''))
    # match returns False when the command doesn't contain "rm /"
    assert not match(Command('rm /opt/dir/', ''))


# Generated at 2022-06-26 06:47:07.662077
# Unit test for function match
def test_match():
    assert match(Command('rm /', '', '', 1))
    assert match(Command('rm /', '', '', 1))
    assert not match(Command('rm', '', '', 1))
    assert not match(Command('', '', '', 1))


# Generated at 2022-06-26 06:47:10.619123
# Unit test for function get_new_command
def test_get_new_command():
    # Initialize command object
    command = Command("rm -rf /", "rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe", "", "", "")
    assert get_new_command(command) == "rm -rf / --no-preserve-root"

# Generated at 2022-06-26 06:47:16.654163
# Unit test for function match
def test_match():
    a_command = Command('rm /', 'rm: /: is a directory')

    assert match(a_command)

    b_command = Command('rm --no-preserve-root /',
                        'rm: /: is a directory')

    assert not match(b_command)

    c_command = Command('rm --no-preserve-root /')

    assert not match(c_command)

    d_command = Command('rm -rf /', 'rm: /: is a directory')

    assert not match(d_command)


# Generated at 2022-06-26 06:47:24.030193
# Unit test for function match
def test_match():
    command = Command('rm --help')
    assert not match(command)
    command = Command('rm -r /')
    assert not match(command)
    command = Command('rm -r / --no-preserve-root')
    assert not match(command)
    command = Command('rm -r /')
    command.output = 'rm: do not remove `/\' or `/home\''
    assert not match(command)
    command = Command('rm -r /')
    command.output = 'rm: do not remove `/\' or `/home\'.  Pass --no-preserve-root to ignore this error.'
    assert match(command)



# Generated at 2022-06-26 06:47:31.176053
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /',
                         stderr='rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('rm -rf /usr',
                             stderr='rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('rm -rf --no-preserve-root /'))

    # Unit test for function get_new_command

# Generated at 2022-06-26 06:47:32.512178
# Unit test for function match
def test_match():
    assert match(Command('rm /'))


# Generated at 2022-06-26 06:47:34.454540
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /')
    assert get_new_command(command) == 'rm -rf --no-preserve-root /'


# Generated at 2022-06-26 06:47:35.806041
# Unit test for function match
def test_match():
    cmd = Command('rm -rf /*', '', '', 0)
    # Should fail
    assert not m