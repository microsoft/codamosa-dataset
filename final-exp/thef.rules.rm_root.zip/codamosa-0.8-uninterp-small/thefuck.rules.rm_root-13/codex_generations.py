

# Generated at 2022-06-26 06:39:18.049539
# Unit test for function get_new_command
def test_get_new_command():
    assert u'${0}^$' == get_new_command(u'$')
    assert u'${0}^$' == get_new_command(u'$')

# Generated at 2022-06-26 06:39:27.327435
# Unit test for function get_new_command

# Generated at 2022-06-26 06:39:29.400358
# Unit test for function get_new_command
def test_get_new_command():
    print('This function is untested')
    assert False

# Generated at 2022-06-26 06:39:34.232091
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'qA'
    str_1 = 'rA'
    str_2 = 'sA'
    str_3 = 'tA'
    var_0 = Command(str_0, str_1, str_2, str_3)
    var_1 = get_new_command(var_0)
    print('\n%s', var_1)


# Generated at 2022-06-26 06:39:41.526227
# Unit test for function match
def test_match():
    assert match(Command('r -\x7f / |grep -v /boot/efi', '', '')) == False
    assert match(Command('rm -rf /', '', '', 'rm: it is dangerous to operate recursively on '/' (same as '/')\nUse --no-preserve-root to override this failsafe')) == True
    assert match('rm -rf /', '', '') == False
    assert match('\x021%L(\x0c?}2`*h(\x0cidQx!tK\x0c\x03\x0eX', '') == False
    assert match('rm -rf /', '', '') == False
    assert match(Command('rm -rf /', '', '')) == False



# Generated at 2022-06-26 06:39:49.644549
# Unit test for function match
def test_match():
    str_0 = '?}2`*h(\x0cidQx!tK'
    var_0 = match(str_0)
    assert var_0 == False
    str_0 = 'q:3<'
    var_1 = match(str_0)
    assert var_1 == True
    str_0 = '?}2`*h(\x0cidQx!tK'
    var_0 = match(str_0)
    assert var_0 == False
    str_0 = 'q:3<'
    var_2 = match(str_0)
    assert var_2 == True


# Generated at 2022-06-26 06:39:51.054712
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'cp -r directoryInCurrentWorkingDirectory /filePath'
    var_0 = get_new_command(str_0)


# Generated at 2022-06-26 06:39:58.840750
# Unit test for function match
def test_match():
    var_0 = match('rm -rf /')
    var_0

    var_1 = match('rm -rf /')
    var_1

    var_2 = match('rm -rf /')
    var_2

    var_3 = match('rm -rf /')
    var_3

    var_4 = match('rm -rf /')
    var_4

    var_5 = match('rm -rf /')
    var_5

    var_6 = match('rm -rf /')
    var_6

    var_7 = match('rm -rf /')
    var_7


# Generated at 2022-06-26 06:40:02.170433
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'rm -rf --no-preserve-root dirname'
    var_0 = get_new_command(str_0)
    assert var_0 == 'rm -rf dirname'

# Generated at 2022-06-26 06:40:04.295493
# Unit test for function match
def test_match():
    test_case_0()

# Generate unit tests for function get_new_command

# Generated at 2022-06-26 06:40:13.792684
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = 'rm <dir>/<dir>/<dir>/<filename>'
    str_0 = ' --no-preserve-root'
    str_1 = ' --no-preserve-root'
    str_2 = ' --no-preserve-root'
    assert not match(var_0)


# Generated at 2022-06-26 06:40:14.623148
# Unit test for function match
def test_match():
    assert match is not None


# Generated at 2022-06-26 06:40:16.318726
# Unit test for function match
def test_match():
    str_0 = 'rm /*'
    out_0 = match(str_0)
    assert out_0 == True


# Generated at 2022-06-26 06:40:22.385982
# Unit test for function get_new_command
def test_get_new_command():

    str_0 = '<,uV7G|tE'
    var_0 = get_new_command(str_0)

    str_0 = '+H,2.xwgC'
    var_1 = get_new_command(str_0)

    str_0 = 'YD?*}\x0cf'
    var_2 = get_new_command(str_0)

    str_0 = 'x*@#,\x7f'
    var_3 = get_new_command(str_0)

    str_0 = 'P(O%|bv`'
    var_4 = get_new_command(str_0)

    str_0 = 'xKM<Q@'
    var_5 = get_new_command(str_0)


# Generated at 2022-06-26 06:40:29.053795
# Unit test for function match
def test_match():
    assert match('rm -rf /') == False
    assert match('rm -rf --no-preserve-root /') == True
    assert match('rm -rf /') == False
    assert match('rm -rf --no-preserve-root /') == True
    assert match('rm -rf /') == False
    assert match('rm -rf --no-preserve-root /') == True
    assert match('rm -rf /') == False
    assert match('rm -rf --no-preserve-root /') == True


# Generated at 2022-06-26 06:40:31.820789
# Unit test for function match
def test_match():
    str_0 = 'q'
    var_0 = match(str_0)
    return var_0


# Generated at 2022-06-26 06:40:33.132992
# Unit test for function match
def test_match():
    assert match(str_0) == var_0


# Generated at 2022-06-26 06:40:37.369257
# Unit test for function match
def test_match():
    assert match('rm -r /')
    assert not match('rm -r')
    assert not match('foo')

# Generated at 2022-06-26 06:40:41.185811
# Unit test for function get_new_command
def test_get_new_command():
    var_8 = u'rm / -rf'
    var_9 = get_new_command(var_8)
    assert var_9 == u'rm / -rf --no-preserve-root'

# Generated at 2022-06-26 06:40:47.431181
# Unit test for function get_new_command
def test_get_new_command():
    var_1 = match('su -c \'rm -rf /\'')
    var_2 = get_new_command('su -c \'rm -rf /\'')
    var_3 = match('sudo rm /')
    var_4 = get_new_command('sudo rm /')
    var_5 = match('rm -rf /')
    var_6 = get_new_command('rm -rf /')


# Generated at 2022-06-26 06:40:54.569232
# Unit test for function match

# Generated at 2022-06-26 06:40:59.668371
# Unit test for function match

# Generated at 2022-06-26 06:41:01.656408
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='rm / -v', output='foo')) == 'rm / -v --no-preserve-root'

# Generated at 2022-06-26 06:41:04.089363
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -r /')
    assert(get_new_command(command) == 'rm -r / --no-preserve-root')



# Generated at 2022-06-26 06:41:07.115450
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf /', '')) \
        == 'rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:41:10.490868
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm -rf /') == 'rm -rf / --no-preserve-root'
    assert get_new_command('sudo rm -rf /') == 'sudo rm -rf / --no-preserve-root'
    assert get_new_command('rm --version') == 'rm --version'

# Generated at 2022-06-26 06:41:14.802198
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="rm /f", stderr=u"rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe")
    assert get_new_command(command) == 'rm /f --no-preserve-root'

# Generated at 2022-06-26 06:41:20.725583
# Unit test for function get_new_command
def test_get_new_command():
    output = '''rm: remove regular file ‘/home/user/test.txt’? '''
    script = 'rm /home/user/test.txt'
    command = Command(script, output)
    assert get_new_command(command) == 'rm --no-preserve-root /home/user/test.txt'

# Generated at 2022-06-26 06:41:30.241224
# Unit test for function match
def test_match():
    """
    Check that that the match function detect the error.
    """
    # Test 1
    command = Command('rm /', 'rm: remove write-protected regular file ‘/’?', '', 1)
    assert match(command)
    # Test 2
    command = Command('rm /', 'rm: remove write-protected regular file ‘/’?', '', 0)
    assert not match(command)


# Generated at 2022-06-26 06:41:35.480921
# Unit test for function match
def test_match():
    #Testing the match function with a case when it should match
    command1 = Command('rm -rf /', '', '', '')
    assert match(command1) == True

    #Testing the match function with a case when it should not match
    command2 = Command('rm /tmp/helloworld', '', '', '')
    assert match(command2) == False


# Generated at 2022-06-26 06:41:42.957699
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm /', '', '')
    assert get_new_command(command) == 'rm --no-preserve-root /'

# Generated at 2022-06-26 06:41:48.193881
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', '', '', '', 1))
    assert not match(Command('rm -rf --no-preserve-root /', '', '', '', 1))
    assert not match(Command('rm -rf /', '', 'rm: it is dangerous to operate recursively on \'root\'', '', 1))
    assert not match(Command('ls -la /', '', '', '', 1))

# Generated at 2022-06-26 06:41:50.751100
# Unit test for function get_new_command
def test_get_new_command():
    command = Script('rm /')
    assert u'rm / --no-preserve-root' == get_new_command(command)



# Generated at 2022-06-26 06:41:59.799204
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', '', 'rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe'))
    assert match(Command('rm -rf /', '', 'rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe\n'))
    assert not match(Command('git commit', '', 'rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe\n'))


# Generated at 2022-06-26 06:42:02.220826
# Unit test for function get_new_command
def test_get_new_command():
    command_test = Command('rm -rf /test')
    assert get_new_command(command_test) == 'rm -rf --no-preserve-root /test'

# Generated at 2022-06-26 06:42:04.801083
# Unit test for function get_new_command
def test_get_new_command():
    matchcommand = Command('sudo rm -rf /',
                           '',
                           'rm: cannot remove ‘/’: Operation not permitted\n')
    assert get_new_command(matchcommand) == 'sudo rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:42:09.032799
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -r /', '')
    assert get_new_command(command) == 'rm -r / --no-preserve-root'
    assert get_new_command(command) != 'rm -r /'

# Generated at 2022-06-26 06:42:12.870111
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /', '', 'rm: it is dangerous to operate recursively on '/'\nrm: use --no-preserve-root to override this failsafe\n')
    assert(get_new_command(command) == "rm -rf / --no-preserve-root")


# Generated at 2022-06-26 06:42:16.865157
# Unit test for function match
def test_match():
    assert match(Command('rm /', '', 'rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('rm /', '', ''))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-26 06:42:18.501050
# Unit test for function match
def test_match():
    command = 'rm /'
    os.system(command)
    assert match(command)

# Generated at 2022-06-26 06:42:33.236598
# Unit test for function match
def test_match():
    checks = [
        ("ls", False),
        ("rm -rf /", False),
        ("rm -rf --no-preserve-root /", False),
        ("rm -rf / --no-preserve-root", False),
        ("rm -rf / --no-preserve-root", True),
        ("rm -rf /", True)
    ]
    for script, output in checks:
        command = Command(script, output)
        assert match(command) == output

# Generated at 2022-06-26 06:42:37.432934
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', '', '', '', 1, 1))
    assert match(Command('sudo rm -rf /', '', '', '', 1, 1))
    assert match(Command('rm -rf -- /', '', '', '', 1, 1))
    assert match(Command('sudo rm -rf -- /', '', '', '', 1, 1))

    assert not match(Command('rm -r /home', '', '', '', 1, 1))
    assert not match(Command('rm -rf --no-preserve-root /', '', '', '', 1, 1))


# Generated at 2022-06-26 06:42:43.969765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm --help') is None
    assert get_new_command('rm -h') is None
    assert get_new_command('rm -rfv --no-preserve-root /').script == 'rm -rfv --no-preserve-root /'
    assert get_new_command('rm -rf --preserve-root /').script == 'rm -rf --no-preserve-root /'
    

# Generated at 2022-06-26 06:42:46.713280
# Unit test for function get_new_command
def test_get_new_command():
    script_parts = ['rm', '/']
    script = 'rm /'
    command = Command(script, script_parts)
    new_command = get_new_command(command)
    assert new_command == 'sudo rm --no-preserve-root /'

# Generated at 2022-06-26 06:42:49.527551
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm / --recursive', None)) == 'rm --no-preserve-root / --recursive'

# Generated at 2022-06-26 06:42:52.358665
# Unit test for function match
def test_match():
    assert match(Command('rm -r / ', 'rm: cannot remove ‘/’: Is a directory\nTry using --no-preserve-root', '', 0))


# Generated at 2022-06-26 06:42:57.982475
# Unit test for function get_new_command
def test_get_new_command():
    command = type('command', (object,),
                   {'script': 'rm {0}', 'script_parts': {'rm', '/'},
                    'output': 'rm: it is dangerous to operate recursively on '/'\nrm: '
                              'use --no-preserve-root to override this failsafe'})
    assert get_new_command(command) == 'rm {0} --no-preserve-root'


enabled_by_default = False

# Generated at 2022-06-26 06:42:59.315530
# Unit test for function match
def test_match():
    assert_match(match, "rm / -rf")
    assert_not_match(match, "rm -rf /")

# Generated at 2022-06-26 06:43:09.215305
# Unit test for function match

# Generated at 2022-06-26 06:43:15.086238
# Unit test for function match
def test_match():
    command = Command('rm /', None)
    assert match(command)
    command = Command('rm', None)
    assert not match(command)
    command = Command('rm -rf /', None)
    assert not match(command)
    command = Command('rm -rf --no-preserve-root /', 'rm: descend into write-protected directory')
    assert match(command)


# Generated at 2022-06-26 06:43:36.271292
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', ''))
    assert not match(Command('ls', ''))
    assert match(Command('rm -rf / --no-preserve-root', ''))


# Generated at 2022-06-26 06:43:41.915934
# Unit test for function match
def test_match():
    assert_true(match(Command('rm /', '', '', '', '')))
    assert_true(match(Command('rm / --no-preserve-root', '', '', '', '')))
    assert_false(match(Command('rm / --no-preserve-root', '', '', '', '')))

# Generated at 2022-06-26 06:43:44.511834
# Unit test for function match
def test_match():
    assert match(script('rm /', output='rm: cannot remove '/' or '/': Is a directory\n'))
    assert match(script('rm /', output='rm: cannot remove / or /: Is a directory\n'))

# Generated at 2022-06-26 06:43:55.056157
# Unit test for function get_new_command
def test_get_new_command():
    # test simple case
    cmd_test = Command('rm -rf /')
    out_1 = 'Try `rm --help\' for more information.'
    out_2 = 'refer to `man rm\' for more help.'
    out_3 = ('If you really want to delete all your files, use `rm -rf /\', '
             'which will not be aborted by this error.')
    cmd_test.output = out_1
    assert get_new_command(cmd_test) == 'rm -rf --no-preserve-root /'
    cmd_test.output = out_2
    assert get_new_command(cmd_test) == 'rm -rf --no-preserve-root /'
    cmd_test.output = out_3

# Generated at 2022-06-26 06:43:59.164981
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf /', '')) == 'rm -rf --no-preserve-root /'
    assert get_new_command(Command('sudo rm -rf /', '')) == 'sudo rm -rf --no-preserve-root /'

# Generated at 2022-06-26 06:44:00.482017
# Unit test for function match
def test_match():
   command = Command('sudo rm -Rf /')
   assert match(command)


# Generated at 2022-06-26 06:44:07.492589
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm /', '', 'rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe')) == 'rm --no-preserve-root /'
    assert get_new_command(Command('rm --no-preserve-root /', '', 'rm: it is dangerous to operate recursively on ‘/’\nrm: use --no-preserve-root to override this failsafe')) == 'rm --no-preserve-root /'

# Generated at 2022-06-26 06:44:16.615602
# Unit test for function match
def test_match():
    command = Command("rm -fr /", "")
    assert(match(command) == True)
    command = Command("rm -fr /", "rm: it is dangerous to operate recursively on '/'\n"
                                   "rm: use --no-preserve-root to override this failsafe")
    assert(match(command) == True)
    command = Command("rm -fr /", "rm: cannot remove '/': Permission denied")
    assert(match(command) == False)
    command = Command("rm -fr /", "rm: cannot remove '/': No such file or directory")
    assert(match(command) == False)
    command = Command("rm -fr /", "rm: missing operand")
    assert(match(command) == False)
    command = Command("rm -fr /", "rm: too many arguments")
   

# Generated at 2022-06-26 06:44:18.623469
# Unit test for function match
def test_match():
    assert match(Command('rm /', '', ''))
    assert match(Command('rm -rf /', '', ''))



# Generated at 2022-06-26 06:44:22.480533
# Unit test for function match
def test_match(): 
    command = Command('rm -r /') 
    assert match(command) 
    command = Command('rm -r --no-preserve-root /') 
    assert not match(command) 
    command = Command('rm -r -d /') 
    assert not match(command) 


# Generated at 2022-06-26 06:45:14.072326
# Unit test for function match
def test_match():
    command = Command('rm -rf /', 'rm: it is dangerous to operate recursively on ‘/’ (same as ‘/’)\n'
                                  "Use --no-preserve-root to override this failsafe\n")
    assert match(command)

    command = Command('rm -rf / --no-preserve-root', 'rm: it is dangerous to operate recursively on ‘/’ (same as ‘/’)\n'
                                                     "Use --no-preserve-root to override this failsafe\n")
    assert not match(command)



# Generated at 2022-06-26 06:45:19.378473
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', '', 'rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe\n'))
    assert not match(Command('rm -rf /', '', 'rm: it is dangerous to operate recursively'))


# Generated at 2022-06-26 06:45:20.912285
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm -rf /') == 'rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:45:27.421987
# Unit test for function match
def test_match():
    assert match(Command('rm /',
                         stderr='rm: it is dangerous to operate recursively on ‘/’'
                                '\nrm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('echo "mik" > /etc/sudoers'))
    assert not match(Command('rm -rf /',
                             stderr='rm: it is dangerous to operate recursively on ‘/’'
                                    '\nrm: use --no-preserve-root to override this failsafe'))
    assert not match(Command('rm /'))
    assert match(Command('rm /', script='sudo rm /'))


# Generated at 2022-06-26 06:45:29.193911
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command.from_string(
            u"rm / --preserve-root")) == u"rm / --no-preserve-root"

# Generated at 2022-06-26 06:45:36.000136
# Unit test for function match
def test_match():
    command1 = Command('rm -rf /')
    command2 = Command('rm -rf /', output='')
    command3 = Command('rm -rf /', output='--no-preserve-root')
    command4 = Command('sudo rm -rf /', output='--no-preserve-root')
    command5 = Command('rm -rf / --no-preserve-root')
    assert match(command1)
    assert not match(command2)
    assert not match(command3)
    assert match(command4)
    assert not match(command5)


# Generated at 2022-06-26 06:45:40.490598
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm -rf /', output='rm: it is dangerous to operate recursively on '/'\nUse --no-preserve-root to override this failsafe.')
    assert get_new_command(command) == 'rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:45:44.179886
# Unit test for function match
def test_match():
    assert match(Command('rm / -rf', ''))
    assert not match(Command('rm / -rf', '', ''))
    assert match(Command('rm / --no-preserve-root -rf', ''))
    assert match(Command('rm / -r --no-preserve-rootf', ''))
    assert match(Command('rm / -r --no-preserve-rootf', '', ''))


# Generated at 2022-06-26 06:45:49.946064
# Unit test for function match
def test_match():
    assert match(Command('rm -r /',
                'rm: it is dangerous to operate recursively on ‘/’\n'
                'rm: use --no-preserve-root to override this message',
                '', True))
    assert not match(Command('rm -r /', '', '', True))


# Generated at 2022-06-26 06:45:55.856263
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', ''))
    assert match(Command('rm -rf test','''
rm: it is dangerous to operate recursively on '/'
rm: use --no-preserve-root to override this failsafe
    '''))
    assert not match(Command('rm -rf /','''
rm: it is dangerous to operate recursively on '/'
rm: use --no-preserve-root to override this failsafe
    '''))
    assert not match(Command('rm -rf test', ''))
    assert not match(Command('mv test', ''))



# Generated at 2022-06-26 06:47:52.543545
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /', output='if you really mean to do it, run: rm -rf --no-preserve-root /'))
    assert not match(Command('rm -rf /', output='test'))
    assert not match(Command('rm -rf /', output='if you really mean to do it, run: rm -rf --no-preserve-root /', script='sudo rm -rf /'))



# Generated at 2022-06-26 06:47:54.554191
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -R /', '')
    assert get_new_command(command) == 'rm -R / --no-preserve-root'


# Generated at 2022-06-26 06:48:00.444919
# Unit test for function match
def test_match():
    assert  match(Command('sudo rm /'))
    assert  match(Command('sudo rm / -R'))
    assert  match(Command('sudo rm / -r'))
    assert  match(Command('sudo rm / -rf'))
    assert not match(Command('sudo rm --no-preserve-root /'))
    assert not match(Command('sudo rm -f'))
    assert not match(Command('rm -r'))



# Generated at 2022-06-26 06:48:02.903460
# Unit test for function match

# Generated at 2022-06-26 06:48:03.811626
# Unit test for function match
def test_match():
    assert match(Command(script='rm /'))


# Generated at 2022-06-26 06:48:12.744438
# Unit test for function match
def test_match():
    assert not match(Command('rm file', '', ''))
    assert match(Command('rm /', '', ''))
    assert match(Command('rm /', '', '', ''))
    assert not match(Command('rm /', '', '--no-preserve-root'))
    assert match(Command('rm /', '', '--preserve-root'))
    assert match(Command('rm /', '', '--preserve-root', ''))
    assert match(Command('rm /', '', '', '--preserve-root'))
    assert match(Command('rm /', '', '--preserve-root', '--preserve-root'))


# Generated at 2022-06-26 06:48:21.558297
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /test', '', '', 1)), \
        'Should return true if rm -rf /test is run and --no-preserve-root not in command'

# Generated at 2022-06-26 06:48:23.476909
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /')
    assert get_new_command(command) == 'rm -rf / --no-preserve-root'

# Generated at 2022-06-26 06:48:24.733064
# Unit test for function match
def test_match():
    command = Command('rm -rf /', '', '', 1, sys.executable)
    assert match(command) == True


# Generated at 2022-06-26 06:48:28.323035
# Unit test for function match
def test_match():
    assert match(command=Command(script='rm -f /var/lib'))
    assert not match(command=Command(script='rm -f /var/lib --no-preserve-root'))
    assert not match(command=Command(script='rm -rf /var/lib'))
    assert not match(command=Command(script='rm -rf'))
    assert not match(command=Command(script='rm -rf /'))
    assert not match(command=Command(script='rm -rf /', output='rm: it is dangerous to operate recursively on '/', use --no-preserve-root to override'))
