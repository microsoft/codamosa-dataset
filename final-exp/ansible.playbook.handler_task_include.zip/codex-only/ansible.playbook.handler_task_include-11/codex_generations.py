

# Generated at 2022-06-23 06:13:42.366593
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  from ansible.inventory.host import Host
  from ansible.inventory.group import Group
  from ansible.vars.manager import VariableManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.task import Task
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.play import Play

  variable_manager = VariableManager()
  loader = DataLoader()
  inventory = Group()
  variable_manager.set_inventory(inventory)
  host = Host(name='testhost.example.com')
  task = Task()
  task.action = 'shell echo hi'
  host.set_variable('ansible_ssh_pass', 'foo')
  play_context = PlayContext(remote_user='johndoe')
  play = Play().load

# Generated at 2022-06-23 06:13:43.795236
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Add test here
    # Example:
    # assertTrue(True)
    assertTrue(True)


# Generated at 2022-06-23 06:13:47.306485
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude.load({'include': 'test_vars.yml', 'ignore_errors': True})
    assert h

# Generated at 2022-06-23 06:13:49.271787
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        handler='name'
    )
    t = HandlerTaskInclude.load(data)
    assert t.name == 'name'

# Generated at 2022-06-23 06:13:52.536408
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h1 = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None,
    )


# Generated at 2022-06-23 06:13:56.751274
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data={'include':{'tasks':'my_tasks.yml'}}
    block=None
    role=None
    task_include=None
    variable_manager=None
    loader=None
    result=HandlerTaskInclude.load(data,block,role,task_include,variable_manager,loader)
    print(result)

# Generated at 2022-06-23 06:14:01.833821
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name     = "myhandler",
        listener = "myhandler_listen"
    )
    
    handler = HandlerTaskInclude.load(data)
    print("handler name: {0}".format(handler.name))
    print("handler listen: {0}".format(handler.listen))

# Generated at 2022-06-23 06:14:07.068286
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude()
    data = dict()
    data['name'] = 'dummy'
    data['include'] = dict()
    data['include']['name'] = 'usr/user/myfile.yml'

    handler = HandlerTaskInclude.load(data=data)

    if str(type(handler)) != "<class 'ansible.playbook.handler.HandlerTaskInclude'>":
        raise RuntimeError("wrong class type")

# Generated at 2022-06-23 06:14:17.766659
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  from ansible.compat.tests import unittest
  from ansible.compat.tests.mock import patch, MagicMock

  class AnsibleModuleUtilsTest(unittest.TestCase):

    def setUp(self):
      pass

    def tearDown(self):
      pass

    @patch.object(TaskInclude, 'load')
    @patch.object(Handler, 'check_options')
    def test_load_call_check_options(self, check_options_mock, load_mock):
      load_mock.return_value = 'dummy'
      handler = HandlerTaskInclude.load('my_from', 'my block', 'my_role', 'my_task_include')
      self.assertTrue(check_options_mock.called)

# Generated at 2022-06-23 06:14:26.027267
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # some dummy data
    data = 'dummy data'
    # initialize class HandlerTaskInclude
    h = HandlerTaskInclude(block=None, role=None, task_include=None)
    # assert if the value returned by constructor is same as what we initialized
    assert h.block is None and h.role is None and h.task_include is None

# Unit test to check the value of the VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-23 06:14:28.176308
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name='a',
        listen='a'
    )
    HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:14:35.670674
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(hti, HandlerTaskInclude) is True
    assert isinstance(hti, Handler) is True
    assert isinstance(hti, TaskInclude) is True
    assert hti.VALID_INCLUDE_KEYWORDS == frozenset(('listen',))

# Test for method load and object HandlerTaskInclude

# Generated at 2022-06-23 06:14:47.881134
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'name': 'test_action',
            'listen': 'test_listen'
            }

    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    
    host = Host(name='localhost')
    group = InventoryManager.get_group(host)
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager())
    task = Task.load(data)

# Generated at 2022-06-23 06:14:58.614508
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_hash

    host = Host(name='myhost')
    host.set_variable('myvar', 'myhost_value')
    host.set_variable('othervar', 'myhost_value')

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.add_host_variable(host, 'myvar')
    variable_manager.add_host_variable(host, 'othervar')


# Generated at 2022-06-23 06:15:00.310946
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    A unit test for method load of class HandlerTaskInclude
    """
    pass

# Generated at 2022-06-23 06:15:11.577756
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    data = {
        'name': 'test',
        'action': {
            'module': 'debug',
            'msg': '{{ test_var }}'
        }
    }
    data_listen = ['test']
    data_block = []
    data_role = []
    data_task_include = []
    data_variable_manager = {
        'test_var': 'hello world'
    }
    data_context = PlayContext()
    data_inventory = InventoryManager('localhost,', loader=Loader())
    data_variable_manager = VariableManager(loader=Loader(), inventory=data_inventory)
    data_

# Generated at 2022-06-23 06:15:12.914379
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   handler=HandlerTaskInclude(handler='test',listen='restart webserver')
   assert handler

# Generated at 2022-06-23 06:15:24.189171
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test Case:
    Check if handler file is loaded properly
        1) Initialize Handler
        2) Check if handler is loaded properly
            - Check if valid handler keywords are loaded
            - Check if handler has been initialized with defaults
    """
    test_data = {'tasks': ['tasks/main.yml']}
    handler = HandlerTaskInclude()
    data = handler.load(test_data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert data.get_name() == 'tasks'
    assert data.get_handler() == ['tasks/main.yml']
    assert data.get_action() == 'include'
    assert data.action == 'include'
    assert data.name == 'tasks'

# Generated at 2022-06-23 06:15:32.378394
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    data = dict(
        None,
        name='test_HandlerTaskInclude_load',
        action=dict(None, module='apt', args=dict(None, name='cowsay'))
    )

    handler = HandlerTaskInclude.load(
        data,
        variable_manager=VariableManager(),
        loader=None
    )

    if not isinstance(handler, HandlerTaskInclude):
        raise Exception("handler not an instance of HandlerTaskInclude")

    return handler

# Generated at 2022-06-23 06:15:42.441429
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    import ansible.inventory.host
    from ansible.playbook.task_include import TaskInclude

    id = u'1'
    block = Block(parent_block=None, role=None)
    task_include = TaskInclude()

    my_handlerTaskInclude = HandlerTaskInclude(block, None, task_include)
    assert my_handlerTaskInclude.id == id
    assert my_handlerTaskInclude.block == block
    assert my_handlerTaskInclude.role == None
    assert my_handlerTaskInclude.task_include == task_include

# Generated at 2022-06-23 06:15:49.851881
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {
        'include': 'other_handler.yml',
        'name': 'task1'
    }
    test_data2 = {
        'include': 'other_handler.yml',
        'name': 'not task1'
    }

    handler = Handler.load(test_data)
    handler2 = Handler.load(test_data2)
    assert handler._attributes['name'] == 'task1'
    assert handler2._attributes['include'] == 'other_handler.yml'



# Generated at 2022-06-23 06:15:57.180156
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load")
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    block = Block()
    block._load_name = 'foo'
    block._parent = 'bar'

    handler = HandlerTaskInclude.load(None, block, role='baz', task_include='qux')

    assert handler._load_name == 'foo'
    assert handler._parent == 'bar'
    assert handler._role == 'baz'
    assert handler._task_include == 'qux'

# Generated at 2022-06-23 06:16:07.152337
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block

    # Create a task to include
    task = TaskInclude()
    task.vars.update({'var1': 'value'})
    task.vars.update({'include_role': 'test_role'})

#     # Create a host to include
#     host = Host('test_host')

    # Create a variable manager to include
    variable_manager = VariableManager()
    variable_manager.set_variables({'var1': 'value'})
    variable_manager.set_inventory(Inventory())

    # Create a loader to include
    loader = DataLoader()

    # Create a role to include
    role = RoleInclude()
    role.name

# Generated at 2022-06-23 06:16:09.923439
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    h.load("include: test.yml")

    # test the listening blocks

# Generated at 2022-06-23 06:16:16.040105
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()
    assert isinstance(x, HandlerTaskInclude)
    assert isinstance(x, Handler)
    assert isinstance(x, TaskInclude)


# Generated at 2022-06-23 06:16:19.249786
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:16:21.472250
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Testing the constructor of class HandlerTaskInclude")
    HandlerTaskInclude(block=None, role=None, task_include=None)
    print("TEST PASSED")


# Generated at 2022-06-23 06:16:32.991298
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    block = {}
    role = {}
    task_include = {}
    variable_manager = {}
    loader = {}
    result = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . #
    # Expected result:
    # {
    #     '_raw_params': '',
    #     '_role': {},
    #     '_task': {
    #         '_attributes': {
    #             'free_form': True
    #         },
    #         '_handler': True,
    #         '_parent': None
    #     },

# Generated at 2022-06-23 06:16:44.262975
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import sys
    import os
    import ansible.parsing.yaml.objects
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    import units.compat.mock as mock
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-23 06:16:49.049830
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # The constructor of class HandlerTaskInclude should be called with
    # two parameters
    hti = HandlerTaskInclude(block=None, role=None)

    # The constructor of HandlerTaskInclude should return a object of class HandlerTaskInclude
    assert isinstance(hti, HandlerTaskInclude) is True

# Generated at 2022-06-23 06:16:50.901949
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test instantiation of class HandlerTaskInclude
    handler = HandlerTaskInclude()


# Generated at 2022-06-23 06:16:51.574237
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:16:59.937581
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = Options(connection='local', module_path=None, forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)
    play_context = PlayContext(remote_addr=None, password=None, port=None, private_key_file=None, timeout=10, shells=options, become_pass=None, connection='ssh', remote_user='root', sudo_user='root', sudo=False, become=False, verbosity=4, check=False)

# Generated at 2022-06-23 06:17:00.504160
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:17:10.079615
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #Test success case
    temp = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert not temp.copy
    assert not temp.links
    assert not temp.run_once
    assert not temp.pre_tasks
    assert not temp.post_tasks
    assert not temp.always_run
    assert not temp.delete_remote_tmp
    assert not temp.verbosity
    assert not temp.when
    #assert not temp.hosts
    assert not temp.roles
    assert not temp.task_includes
    assert not temp.static
    assert not temp.any_errors_fatal
    assert not temp.handlers
    assert not temp.tags
    assert not temp.skips
    assert not temp.environment
    assert not temp.roles_path
    assert not temp.role_

# Generated at 2022-06-23 06:17:20.182515
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    class Object(object):
        pass

    # set up test
    set_up = Object()
    set_up.loader = False
    set_up.block = False
    set_up.role = False
    set_up.task_include = False
    # call test
    test = HandlerTaskInclude(block=set_up.block, role=set_up.role, task_include=set_up.task_include)

    # test results
    assert test.block == set_up.block
    assert test.role == set_up.role
    assert test.task_include == set_up.task_include

# Generated at 2022-06-23 06:17:31.307959
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(
        Inventory(
            host_list=[
                Host(name="host1")
            ],
            group_list=[
                Group(name="group1")
            ],
        )
    )

    def assertEqualHandler(handler, handler_path):
        assert handler.handler_data.get('include') == handler_path
        assert handler.handler_data.get('name') == handler_path

    def assertEqualHandlerWithTag(handler, handler_path, tags):
        assert handler.handler_data.get('include') == handler_path
        assert handler.handler_data.get('name') == handler_path

# Generated at 2022-06-23 06:17:40.644292
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from .mock import patch
    from .mock import Mock

    with patch.object(HandlerTaskInclude, '_load_handlers') as _load_handlers_mock:
        _load_handlers_mock.return_value = '_load_handlers_mock called'
        with patch.object(HandlerTaskInclude, '_load_tasks') as _load_tasks_mock:
            _load_tasks_mock.return_value = '_load_tasks_mock called'
            with patch.object(HandlerTaskInclude, '_load_tags') as _load_tags_mock:
                _load_tags_mock.return_value = '_load_tags_mock called'

# Generated at 2022-06-23 06:17:41.729715
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Code to test load method
    assert False

# Generated at 2022-06-23 06:17:47.735014
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler = t.check_options(
        t.load_data(data, variable_manager=variable_manager, loader=loader),
        data
    )

    assert handler is not None
    assert handler.name == 'test'

# Generated at 2022-06-23 06:17:55.100327
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    # Create target object
    hti = HandlerTaskInclude()

    # Create objects needed by method load
    data = {}
    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()
    loader = None

    # Test method load
    hti.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-23 06:17:59.099372
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    retval = HandlerTaskInclude.load({'name': 'test name', 'listen': 'test listen'})
    assert retval.get_name() == 'test name'
    assert retval.action == 'test listen'

# Generated at 2022-06-23 06:18:09.883881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

    # TODO: Create a data structure that matches the one required by the method load.
    # data = {}

    # TODO: Create a data structure that matches the one required by the method load.
    # block = {}

    # TODO: Create a data structure that matches the one required by the method load.
    # role = {}

    # TODO: Create a data structure that matches the one required by the method load.
    # task_include = {}

    # TODO: Create a data structure that matches the one required by the method load.
    # variable_manager = {}

    # TODO: Create a data structure that matches the one required by the method load.
    # loader = {}

    # handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    # assert (isinstance(handler

# Generated at 2022-06-23 06:18:11.183137
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-23 06:18:21.609815
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "name": "test",
        "include": "test.yml"
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'test'
    assert handler.handler_block.name == 'test'
    assert handler.handler is None
    assert handler.include is not None
    assert handler.handler_name == 'test'

    data = {
        "name": "test",
        "include_tasks": "test.yml"
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.name == 'test'
    assert handler.handler_block.name == 'test'
    assert handler.handler is None
    assert handler.include is not None
    assert handler.handler_name == 'test'

# Generated at 2022-06-23 06:18:22.045423
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    raise NotImplementedError

# Generated at 2022-06-23 06:18:24.606830
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-23 06:18:26.732937
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()

# Generated at 2022-06-23 06:18:38.355125
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # HandlerTaskInclude([block=None, role=None, task_include=None,])
    assert HandlerTaskInclude(block=None, role=None, task_include=None)
    assert HandlerTaskInclude(block='block', role='role', task_include='task_include')

    # HandlerTaskInclude(self)
    # test = HandlerTaskInclude(block=None, role=None, task_include=None)
    # assert test.block is None
    # assert test.role is None
    # assert test.task_include is None
    # assert test is not None
    # assert test == test
    # assert test == HandlerTaskInclude(block=None, role=None, task_include=None)
    # assert test == HandlerTaskInclude(block=None, role=None, task_include=None)
    #

# Generated at 2022-06-23 06:18:43.551049
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_assert(data, result_data, result_check_options):
        t = HandlerTaskInclude()
        handler = t.load(data)
        assert t.data == result_data
        assert handler == result_check_options
    
    test_assert({'name': 'test include handler', 'include': '../../other/main.yml'}, {'name': 'test include handler', 'include': '../../other/main.yml'}, None)

# Generated at 2022-06-23 06:18:45.354749
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.VALID_INCLUDE_KEYWORDS == "PENDING"

# Generated at 2022-06-23 06:18:45.793543
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:58.041969
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/dev/null'])
    variables = VariableManager(loader=loader, inventory=inv_manager)
    data = {
        'include': 'test.yml',
        'include_tasks': 'test.yml',
        'hosts': 'foo',
        'connection': 'local',
        'gather_facts': 'no',
        'name': 'test',
        'any_errors_fatal': 'no',
        'listen': 'test',
        'tags': ['bar']
    }

# Generated at 2022-06-23 06:19:02.490784
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'tasks': [
            {
                'include': 'test.yml'
            },
        ]
    }

    variable_manager = None
    loader = None

    handler_task_include = HandlerTaskInclude()
    handler_task_include.load(data, variable_manager=variable_manager, loader=loader)

    assert True

# Generated at 2022-06-23 06:19:04.204888
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj is not None

# Generated at 2022-06-23 06:19:05.527207
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Todo: Please write unit test
    pass

# Generated at 2022-06-23 06:19:12.086697
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict()
    data['name'] = 'Test Handler Task Include'
    data['include'] = 'foo.yml'
    data['listen'] = 'foo_event'
    data['tags'] = ['foo_tasks']

    handler = HandlerTaskInclude.load(data)
    assert isinstance(handler, Handler)


# Generated at 2022-06-23 06:19:13.951077
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    h = HandlerTaskInclude.load('myfile')

    assert h.name == 'myfile'


# Generated at 2022-06-23 06:19:25.457372
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    block = Block.load(
        {
            'name': 'test block',
            'hosts': 'test_host',
            'tasks': [
                {
                    'name': 'test task',
                }
            ]
        },
        variable_manager=None,
        loader=None
    )
    block.play = None

    task = block.block.pop(0)
    task.block = block

    h = Host(name='test_host')
    h.set_variable('ansible_ssh_host', '10.0.0.1')


# Generated at 2022-06-23 06:19:32.609769
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook import block
    from ansible.playbook.block import Block

    b = Block()
    # 'data' is not a dict.
    # AnsibleError of type 'expecting a dict here' is expected.
    data = 'test'
    try:
        h = HandlerTaskInclude.load(data, block=b)
        assert False
    except AnsibleError as e:
        assert e.message.startswith('expecting a dict here:')

    # 'data' is a dict without 'include' key.
    # AnsibleError of type 'missing required key in include_tasks' is expected.
    data = dict()
    try:
        h = HandlerTaskInclude.load(data, block=b)
        assert False
    except AnsibleError as e:
        assert e.message.start

# Generated at 2022-06-23 06:19:32.980748
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:19:48.572208
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskIncludeLoader
    from ansible.playbook.task_include import TaskIncludeConstructor
    from ansible.playbook.task_include import basedir

    from ansible.inventory.host import Host
    from ansible.template import Templar
    from ansible.vars.clean import merge_hash

    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    from collections import namedtuple


# Generated at 2022-06-23 06:19:49.166780
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert False

# Generated at 2022-06-23 06:19:50.008457
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:19:51.164884
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Ansiballz framework to mock this method
    assert True

# Generated at 2022-06-23 06:19:59.357399
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="name",
        listen="listen",
        not_a_keyword="not_a_keyword"
    )

    result = HandlerTaskInclude.load(data=data)
    assert result.data == data

    data = dict(
        name="name",
        not_a_keyword="not_a_keyword"
    )

    assert HandlerTaskInclude.load(data=data) is None

# Generated at 2022-06-23 06:20:04.309677
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print ("\nTesting load method of HandlerTaskInclude class")
    print ("\nTest case 1")
    data = {
        'name': 'main',
        'include': 'mytask.yml'
    }
    handler = HandlerTaskInclude.load(data)
    assert (handler is not None)


# Generated at 2022-06-23 06:20:14.776414
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.plugins.loader import action_loader
    from ansible.errors import AnsibleParserError

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,'))

    data = dict(
        name='name',
        include_tasks='name',
    )
    block = Block()
    role = Role()

# Generated at 2022-06-23 06:20:15.801018
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #TODO: implement
    pass

# Generated at 2022-06-23 06:20:24.370689
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:20:25.003694
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:20:26.865940
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # test: create with empty data
    HandlerTaskInclude(block=None, role=None, task_include=None)

    # test: create with some data
    HandlerTaskInclude(block=None, role=None, task_include="test1")



# Generated at 2022-06-23 06:20:37.424792
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.script import InventoryScript
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from .handler_base_test import HandlerBaseTest

    dataloc = "./lib/ansible/plugins/tasks/include_role.yml"

    # handler

# Generated at 2022-06-23 06:20:46.680401
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
    except ImportError as e:
        raise AssertionError("ImportError: %s" % e)

    loader = DataLoader()
    variable_manager = VariableManager()

    handler_data = '''
      - name: test handler
        shell: echo "hello world"
        listen: "test-listener"
    '''

    handler_data_with_bad_keywords = '''
      - name: test handler
        shell: echo "hello world"
        listen: "test-listener"
        include_vars:
            file: "not_a_real_file.yml"
    '''

    test_HandlerTaskInclude_load_with_good_data = HandlerTaskInclude

# Generated at 2022-06-23 06:20:55.519066
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # def __init__(self, block=None, role=None, task_include=None):
    t = HandlerTaskInclude(block='tasks', role='some_role')
    assert t.block == 'tasks'
    assert t.role == 'some_role'

    # def __init__(self, block=None, role=None, task_include=None):
    t = HandlerTaskInclude(block='tasks', role='some_role')
    assert t.block == 'tasks'
    assert t.role == 'some_role'


# Generated at 2022-06-23 06:21:02.482515
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleError
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    host = Host(name='test')
    inventory = InventoryManager(loader=loader, sources=None)
    inventory.add_host(host)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host.set_variable('foo', 'bar')

    # missing 'handlers'
    data = {}
    result = HandlerTaskInclud

# Generated at 2022-06-23 06:21:10.358570
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    i = Inventory()
    h = Host(name='example.com')
    i.add_host(h)
    g = Group(name='example_group')
    i.add_group(g)
    g.add_host(h)
    v = VariableManager(loader=None, hosts=i, groups=i.get_groups())

# Generated at 2022-06-23 06:21:12.450229
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)



# Generated at 2022-06-23 06:21:16.560252
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Create a minimal test for HandlerTaskInclude class, for method load
    """
    data = dict(
        include='test.yml'
    )
    handl = HandlerTaskInclude.load(data)
    assert handl._task_blocks == ['test.yml']

# Generated at 2022-06-23 06:21:22.972856
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    block = Block()
    hosts = [
        Host(name="foo"),
        Host(name="bar"),
    ]
    hosts[0].set_variable("ansible_connection", "ssh")
    hosts[1].set_variable("ansible_connection", "local")

    variable_manager = VariableManager()
    variable_manager.set_host_variable(hosts[0], "ansible_ssh_user", "mdehaan")

    block.watch = ["shell"]

# Generated at 2022-06-23 06:21:23.935637
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:21:28.869935
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "include": "some_task",
        "static": "/etc/ansible_static_include"
    }
    # handler = HandlerTaskInclude
    # h = handler.load(data)
    # assert(h.get_name() is "some_task")

# Generated at 2022-06-23 06:21:33.836151
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti.VALID_INCLUDE_KEYWORDS == {'listen', 'listen_children', 'listen_hosts', 'listen_ignore_errors', 'listen_max_loops', 'listen_name', 'listen_notify',
               'listen_options', 'listen_roles', 'listen_tags', 'listen_tasks'}

# Generated at 2022-06-23 06:21:35.145476
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:21:40.417572
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    my_block = Block()
    my_role = Role()
    assert isinstance(my_block, Block)
    assert isinstance(my_role, Role)

    handler_task_include = HandlerTaskInclude(block=my_block, role=my_role)
    assert handler_task_include is not None

# Generated at 2022-06-23 06:21:52.188530
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task

    block = Base()
    role = Task()

    handler = HandlerTaskInclude(block, role)

    assert handler._attributes['always_run'] == False
    assert handler._attributes['delegate_to'] == None
    assert handler._attributes['register'] == None
    assert handler._attributes['ignore_errors'] == False
    assert handler._attributes['listen'] == None
    assert handler._attributes['loop'] == None
    assert handler._attributes['loop_args'] == {}
    assert handler._attributes['loop_control'] == {}
    assert handler._attributes['loop_with_index'] == None
    assert handler._attributes['loop_index'] == None

# Generated at 2022-06-23 06:21:54.662205
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert type(handler) is HandlerTaskInclude


# Generated at 2022-06-23 06:21:57.657358
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=False, role=False, task_include=False)
    assert isinstance(t, HandlerTaskInclude)
    assert isinstance(t, Handler)

# Generated at 2022-06-23 06:21:59.201878
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti

# Generated at 2022-06-23 06:22:10.490074
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import sys
    sys.path.append('C:\\Users\\Yoogesh\\Desktop\\Ansible\\ansible-playbook\\test\\data\\')
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='test_hosts')
    variable_manager.set_inventory(inventory)
    block = Block()
    role = Role()

    handler_taskinclude = HandlerTaskInclude(block=block, role=role)
    print(handler_taskinclude)

# Generated at 2022-06-23 06:22:12.622626
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = Handler()
    handler.load(dict(include='/path/to/file'))
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-23 06:22:23.297226
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test create object HandlerTaskInclude 
    # test object HandlerTaskInclude created successfully
    task = HandlerTaskInclude()
    assert task != None
    print("test_HandlerTaskInclude: ",task)
#
# # Unit test for load function of class HandlerTaskInclude
# def test_load():
#     # test create object HandlerTaskInclude 
#     # test object HandlerTaskInclude created successfully
#     task = HandlerTaskInclude()
#     assert task != None
#     print("test_load: ", task)
# #
# # Unit test for get_vars function of class HandlerTaskInclude
# def test_get_vars():
#     # test create object HandlerTaskInclude 
#     # test object HandlerTaskInclude created successfully
#     task = HandlerTaskInclude()
#     assert task != None
#

# Generated at 2022-06-23 06:22:29.893921
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("")
    t = HandlerTaskInclude()
    test_data = {'include': '../../../playbooks/minimal.yml'}
    handler = t.load(data=test_data)
    assert handler.get_name() == 'include'
    assert handler.get_action() == '../../../playbooks/minimal.yml'
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None



# Generated at 2022-06-23 06:22:38.320814
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

    def _get_variable_manager(host_list, extra_vars=None, passwords=None):
        ''' Build variable manager for specified inventory and vars '''
        from ansible.inventory import Inventory
        from ansible.vars import VariableManager
        from ansible.parsing.dataloader import DataLoader

        if extra_vars is not None:
            loader = DataLoader()
            var_manager = VariableManager()
            var_manager.extra_vars = load_extra_vars(loader=loader, options=extra_vars)
        else:
            var_manager = VariableManager()
            var_manager.extra_vars = {}
        var_manager.combined_v

# Generated at 2022-06-23 06:22:43.579727
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'include': 'main.yml'}
    task_include = TaskInclude.load(data)
    handler = HandlerTaskInclude.load(data, task_include=task_include)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.get_name() == 'main'

# Generated at 2022-06-23 06:22:44.520559
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:22:54.815050
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor with minimum arguments
    data = dict(
        include = 'add_apt_repository',
        name = 'Add the PPA for the latest stable version',
        when = 'ansible_os_family == "Debian"'
    )

    # Instantiation of a new object
    task_include = HandlerTaskInclude.load(
        data, task_include = 'test'
    )

    # Assertion on attributes of the object
    assert task_include.block is None
    assert task_include.role is None
    assert task_include._task is None
    assert task_include._role is None
    assert task_include._block is None
    assert task_include._parent is None
    assert task_include._play is None
    assert task_include._loader is None
    assert task_include.deprecated is False


# Generated at 2022-06-23 06:22:58.173378
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("[+][%s][TESTING] %s" % (__file__, 'test_HandlerTaskInclude_load()'))
    assert 1

# Generated at 2022-06-23 06:22:58.890555
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load() == None

# Generated at 2022-06-23 06:23:06.841936
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    data = dict(
        include='',
        block='',
        role=None,
        task_include=TaskInclude(block=Block(task_include=TaskInclude(block=Block(task_include=TaskInclude()), role=None), role=None), role=None),
        variable_manager=VariableManager(),
        loader=Templar(),
    )

    HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:23:07.425857
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:23:16.408935
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'some_task_name',
        'register': 'some_result'
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.get_name() == 'some_task_name'
    assert 'some_result' == handler.register
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.any_errors_fatal is False
    assert handler.continue_on_error is False
    assert handler.listen is ''

# Generated at 2022-06-23 06:23:17.021720
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:23:18.194682
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj is not None

# Generated at 2022-06-23 06:23:24.638373
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''Unit test for constructor of class HandlerTaskInclude'''
    # Constructor's tests
    data = {
        'name' : 'setup',
        'static' : 'yes',
        'tags' : ['setup', 'always']
    }
    h = HandlerTaskInclude.load(data)

    assert h.get_name() == data['name']
    assert h.get_tags() == data['tags']
    assert h.get_action() == None
    assert h.get_args() == {}
    assert h.get_loop() == None
    assert h.get_until() == None
    assert h.get_notify() == []
    assert h.get_loop_with() == None
    assert h.get_loop_args() == None
    assert h.get_local_action() == False

# Generated at 2022-06-23 06:23:31.239076
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Borrowing this dict from unit test test_task_line_numbers of class TaskInclude
    data = dict(
        name="test task",
        handler=dict(
            name="test handler",
            include="test handler include"
        )
    )

    block = 'some block'

    t = HandlerTaskInclude(block=block)
    handler = t.load(data)

    print('handler: ' + str(handler))
    assert handler.name == "test handler"
    assert handler.include is None