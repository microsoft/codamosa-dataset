

# Generated at 2022-06-23 06:13:43.577394
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # data
    data = {
        'include': 'test.yml',
        'static': '1',
        'forks': '100'
    }
    block = None
    role = None
    task_include = None
    variable_manager=None
    loader=None

    handler =  HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert handler is not None
    assert handler.block == block
    assert handler.role == role
    assert handler.task_include == task_include
    assert handler.static == '1'
    assert handler.forks == '100'
    assert handler.action == 'include'
    assert handler.include_file == 'test.yml'

# Generated at 2022-06-23 06:13:46.491391
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # TODO
    pass

# Generated at 2022-06-23 06:13:48.913171
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.task_include import TaskInclude
    h = HandlerTaskInclude()
    assert isinstance(h, TaskInclude)
    assert isinstance(h, Handler)

# Generated at 2022-06-23 06:13:50.233470
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler != None

# Generated at 2022-06-23 06:13:54.679215
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor of class HandlerTaskInclude
    i = HandlerTaskInclude()
    # Constructor of class Handler
    i = Handler()
    # Constructor of class TaskInclude
    i = TaskInclude()
    # Constructor of class Task
    i = Task()

# Generated at 2022-06-23 06:13:59.820655
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Given
    include_name="include_test"
    include_file="test.yml"
    handler = HandlerTaskInclude(file=include_file)

    assert handler.get_name() == include_name
    assert handler.get_action() == include_file

# Generated at 2022-06-23 06:14:03.932270
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set([
        'tasks', 'handlers', 'vars',
        'defaults', 'facts', 'files',
        'meta', 'tags', 'always', 'changed_when',
        'failed_when', 'block', 'notify', 'listen'
    ])


# Generated at 2022-06-23 06:14:15.056785
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableModule

    data = {
        "name": "test_handler",
        "listen": "test_listen"
    }

    block = None
    role = None
    task_include = None
    variable_manager = VariableManager()
    loader = None

    handler = HandlerTaskInclude.load(
        data=data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )


# Generated at 2022-06-23 06:14:22.595000
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test HandlerTaskInclude's "load" method
    """
    # Test for missing required parameter "handler", expect a TypeError exception
    try:
        handler = HandlerTaskInclude.load(data={'a_keyword': 'value'})

        # Fail the test, if the exception is not thrown
        assert False
    except TypeError as err:
        assert True

    # Test for missing required parameter "data", expect a TypeError exception
    try:
        handler = HandlerTaskInclude.load(handler={'a_handler': 'value'})

        # Fail the test, if the exception is not thrown
        assert False
    except TypeError as err:
        assert True

    # Test for invalid keyword, expect a ValueError exception

# Generated at 2022-06-23 06:14:27.198960
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data=dict(include='test.yml'),
                                      role=dict(),
                                      block=dict(),
                                      task_include=dict(),
                                      variable_manager=dict(),
                                      loader=dict())
    assert handler.block == dict()
    assert handler.role == dic

# Generated at 2022-06-23 06:14:28.013901
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:14:30.034890
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    _ = HandlerTaskInclude()

# Generated at 2022-06-23 06:14:33.531510
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert test.block == None
    assert test.role == None
    assert test.task_include == None

# Generated at 2022-06-23 06:14:35.571537
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)

# Generated at 2022-06-23 06:14:44.404842
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    playbook = PlaybookExecutor(playbooks=['./ansible/test/units/modules/test_playbook.yml'], inventory=inventory, variable_manager=variable_manager, loader=loader, passwords={})

# Generated at 2022-06-23 06:14:44.929530
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:14:45.893321
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    pass

# Generated at 2022-06-23 06:14:47.040739
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True


# Generated at 2022-06-23 06:14:48.952810
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load({'include': 'lost_tasks_handler.yml'})


# Generated at 2022-06-23 06:14:53.936854
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        data=dict(
            include=dict(
                name="test",
                files="/some/path/{{ variable }}"
            )
        ),
        variable_manager=dict(
            variable="files_var",
        ),
        loader=dict(
            variable="files_loader"
        )
    )
    print(handler.name)
    print(handler.files)

# Generated at 2022-06-23 06:15:04.230791
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # create dummy data

# Generated at 2022-06-23 06:15:05.980060
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:15:06.531719
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:15:16.004555
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # initalize variables needed
    data = [{u'block': None, u'role': None, u'task_include': None}]
    block = None
    role = None
    task_include = None

    # create object
    obj = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    # test handler attribute
    assert obj.handler == None

    # test block attribute
    assert obj.block == None

    # test listen attribute
    assert obj.listen == False

    # test loop attribute
    assert obj.loop == None

    # test name attribute
    assert obj.name == None

    # test notify attribute
    assert obj.notify == []

    # test register attribute
    assert obj.register == None

    # test role attribute
    assert obj.role == None

    # test

# Generated at 2022-06-23 06:15:26.164380
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.template
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.inventory.host
    
    # 1.1 create a block
    block = ansible.playbook.block.Block()
    
    # 1.2 create a task
    task = ansible.playbook.task.Task()
    
    # 1.3 add the task to the block
    block.append(task)
    
    # 1.4 create a handler task
    handler_task = HandlerTaskInclude(block, None, task)
    
    # 2. create a play context
    play_context = ansible.playbook.play_context.PlayContext()
    
    # 3. create a host


# Generated at 2022-06-23 06:15:28.390912
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    print(handler.VALID_INCLUDE_KEYWORDS)



# Generated at 2022-06-23 06:15:31.298752
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {
        'include': 'list_all_databases.yml',
        'listen': 'databases_ready',
    }
    test_object = HandlerTaskInclude.load(test_data)
    assert isinstance(test_object, HandlerTaskInclude)

# Generated at 2022-06-23 06:15:33.008410
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-23 06:15:41.856758
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   handler = HandlerTaskInclude()
   assert handler.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))

   # Validate the case where an invalid keyword is used while creating an object
   data = dict(include="xyz")
   try:
       handler.load_data(data=data)
   except ValueError:
       pass

   # Validate the scenario of loading a task which is included in a handler
   data = dict(include="tasks/xyz.yml")
   handler.load_data(data=data)

# Generated at 2022-06-23 06:15:52.652278
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create inventory
    group = Group('group')
    host = Host('host')
    group.add_host(host)

    # Create play
    play = Play()
    play.hosts = group
    play._variable_manager = VariableManager()
    play._variable_manager.extra_vars['hostvars'] = play._variable_manager.get_vars(play=play, host=host)
    play._loader = play._variable_manager._loader

    # Create task
    task = Task()
    task._variable_manager = play._

# Generated at 2022-06-23 06:16:00.144874
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_name = "test_HandlerTaskInclude"
    # data = {'handler_name': 'test_handler_name'}
    data = dict(test_task_config)
    data.update({'handler': 'test_handler_name'})
    handler = HandlerTaskInclude.load(data)
    assert handler.name == data[task_name], "Failed test_HandlerTaskInclude1"
    assert handler.get_block().get_name() == "test_block_name", "Failed test_HandlerTaskInclude2"
    assert handler.get_role().get_name() == "test_role_name", "Failed test_HandlerTaskInclude3"
    assert handler.get_task().get_name() == "test_task_name", "Failed test_HandlerTaskInclude4"

# Generated at 2022-06-23 06:16:06.367203
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(
        {
            'name': 'mock',
            'listen': "start"
        }
    )

    HandlerTaskInclude.load(
        {
            'name': 'mock',
            'tags': "start"
        }
    )


# Generated at 2022-06-23 06:16:07.952250
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task = HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:16:22.563015
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import yaml
    # Test all modules that can be imported
    # import ansible.modules as om
    # modules = om.get_all_modules(module_list=[])
    # Test with a simple handler, which is probably not a valid handler

# Generated at 2022-06-23 06:16:34.056950
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.playbook.task_include as tas
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import os
    import yaml
    vault_pass = 'asd'
    vault = VaultLib(vault_pass)
    loader = AnsibleLoader(None, vault)
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {}
    playbook_path = "../tests/test_handler_task_include.yml"

# Generated at 2022-06-23 06:16:44.699521
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    inventory = Inventory(host_list=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager)


# Generated at 2022-06-23 06:16:45.717554
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a=HandlerTaskInclude()
    #assert 1 == 0


# Generated at 2022-06-23 06:16:54.955479
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook import Play, Playbook, Task

    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory()
    inventory.groups.update({'all': Group()})
    inventory.hosts.update(
        {
            'localhost': Host(name="localhost"),
        }
    )

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    variable_manager.set_host_variable("localhost", "foo", "bar")

# Generated at 2022-06-23 06:16:56.645586
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    d = {'include': 'handler_name'}
    print(HandlerTaskInclude.load(d))

# Generated at 2022-06-23 06:17:02.400455
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """Unit test for method load of class HandlerTaskInclude"""

    # Test 1: simple case
    data = {}
    block = {}
    role = {}
    task_include = {}
    variable_manager = {}
    loader = {}
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert handler.__class__ == HandlerTaskInclude


# Generated at 2022-06-23 06:17:10.898930
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create fake objects
    def fake_load_data(data, variable_manager=None, loader=None):
        return data
    # Create the object with values
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    t.load_data = fake_load_data
    # Create a object fake object
    fake_data = {"name": "TestActionHandler", "listen": "test"}
    handler = t.load(
        fake_data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    # Verify if are the same objects
    assert handler.name == fake_data['name']
    assert handler.listen == fake_data['listen']

# Generated at 2022-06-23 06:17:23.052571
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import os
    import yaml
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    # create mock inventory
    inventory = Inventory(host_list=[])

    # create mock data

# Generated at 2022-06-23 06:17:30.305634
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import PlayBook
    from ansible.inventory import Inventory

    p = PlayBook()

    inventory1 = Inventory('test/test_inventory_1')
    inventory2 = Inventory('test/test_inventory_2')
    p.add_inventory([inventory1, inventory2])

    ht = HandlerTaskInclude(block=None, role=None, task_include=None)
    ht.load(data={'block': 'None', 'role': 'None', 'task_include': 'None'})

    assert ht.block == 'None'
    assert ht.role == 'None'
    assert ht.task_include == 'None'

# Generated at 2022-06-23 06:17:31.524598
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: How to test this method?
    pass

# Generated at 2022-06-23 06:17:40.732321
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    example_data = {}
    with open("tests/integration/targets/include_handler/tasks.yml", "r") as task_file:
        example_data = loader.load(stream=task_file, variable_manager=variable_manager)

    handler = HandlerTaskInclude.load(example_data, variable_manager=variable_manager, loader=loader)
    assert handler._role is None
    assert handler._block is None
    assert handler._loop is None
    assert handler._when is None
    assert handler._any_errors_fatal is None
    assert handler._notify is None
    assert handler._name == "common"

# Generated at 2022-06-23 06:17:50.724367
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import os
    import yaml
    data = yaml.load("""
        name: install nginx and add as a service
        include: nginx_install.yml
        handler:
          - include: nginx_service.yml
            listen: "listen1"
        listen: "listen2"
    """)
    block = Block()
    host_list = InventoryManager(loader=DataLoader(), sources=["localhost"]).get_hosts()
    variable_manager = VariableManager(loader=DataLoader(), host_list=host_list)

# Generated at 2022-06-23 06:17:56.650752
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {
        'tasks': 'tasks/main.yml',
        'listen': 'test'
    }

    handler = HandlerTaskInclude.load(data)

    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == None
    assert handler.static is False
    assert handler.notify == 'test'
    assert handler.tasks == 'tasks/main.yml'
    assert handler.conditional == None

# Generated at 2022-06-23 06:18:08.615819
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name='test test',
        include='asd.yml',
        tags=['test']
    )
    role = None

    _HandlerTaskInclude = HandlerTaskInclude(
        block=None,
        role=role,
        task_include=None
    )

    handler = _HandlerTaskInclude.check_options(
        _HandlerTaskInclude.load_data(data),
        data
    )

    parameters = dict(
        name='test test',
        include='asd.yml',
        tags=['test']
    )

    assert handler.__dict__ == parameters
    assert handler.tags == ['test']
    assert handler.blocks == []
    assert handler.loop is None
    assert handler.notify == []
    assert handler.when == []

# Generated at 2022-06-23 06:18:17.117818
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # block attribute
    block = Block()

    # role attribute
    role = Role()

    # task_include attribute
    task_include = Task()

    # variable_manager attribute
    variable_manager = VariableManager()

    # loader attribute
    loader = None

    # _load_name attribute
    _load_name = 'include'


# Generated at 2022-06-23 06:18:17.948325
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:18:20.221471
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:18:21.022577
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()
    assert True

# Generated at 2022-06-23 06:18:21.520972
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-23 06:18:29.306252
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.inventory
    inventory = ansible.inventory.Inventory(
        ansible.inventory.Host,
        ansible.inventory.Group,
        ansible.inventory.VariableManager()
    )
    inventory.add_host(ansible.inventory.Host(name='localhost'))
    data = {
        'listen': 'test1',
        'include': 'test2'
    }
    h = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )

    handler = h.load(
        data,
        block=None,
        role=None,
        task_include=h,
        variable_manager=None,
        loader=None
    )
    assert type(handler) is HandlerTaskInclude
    assert handler.listen is 'test1'

# Generated at 2022-06-23 06:18:40.608010
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    import os
    from ansible.module_utils._text import to_text

    dataloader = DataLoader()
    inventory = dataloader.load_from_file('/home/adi/ansible/inventory')
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

    role = Role()
    role._parent = Block()

# Generated at 2022-06-23 06:18:42.450488
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler_task_include is not None

# Generated at 2022-06-23 06:18:51.051452
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

# Check if it's possible to load a playbook yaml with an include task that contains a handler

# Note: A handler is a list of tasks that are only executed at the end of a play if they have been notified.
# A handler can be notified by a task or a role.
# https://docs.ansible.com/ansible/playbooks_intro.html#handlers-running-operations-on-change
# It says that handlers are a list of tasks, not sure why it is implemented as a class.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()

# Generated at 2022-06-23 06:18:59.478949
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.inventory.host
    import ansible.playbook.task
    import ansible.utils

    hosts = [ansible.inventory.host.Host(name='test-host')]

    variable_manager = ansible.utils.common.AnsibleModule()
    variable_manager.set_inventory(ansible.inventory.Manager(hosts=hosts))

    task = ansible.playbook.task.Task()
    handler = TaskInclude.load(data={'name': 'test-task-handler'}, block=task, variable_manager=variable_manager)
    print(handler.name)

    print(handler.static_vars)
    handler.static_vars = {'var_name': 'var_val'}
    print(handler.static_vars)

    handler.set_loader(variable_manager)

# Generated at 2022-06-23 06:19:07.127358
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    host = MagicMock()
    block = MagicMock()
    role = MagicMock()
    task_include = MagicMock()
    variable_manager = MagicMock()
    loader = MagicMock()

    data = dict()

    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert handler.data['tasks'][0].data['action']['__ansible_action_copy'] == False

# Generated at 2022-06-23 06:19:15.367310
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    data_dict = {
        'include': 'some_tasks.yml',
        'static': 'no',
        'static': True,
        'tasks': 'tasks',
        'vars': 'vars',
        'tags': ['foo'],
        'ignore_errors': 'yes'
    }

    variable_manager = VariableManager()

# Generated at 2022-06-23 06:19:21.593306
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from modules.handler import HandlerTaskInclude
    from collections import OrderedDict
    t = HandlerTaskInclude()
    ansible_data = OrderedDict({'hosts': 'all', 'tasks': [{'name': 'webservers', 'shell': 'ls'}]})
    t.load(ansible_data)
    assert isinstance(t,HandlerTaskInclude) == True
    #print(t)

# Generated at 2022-06-23 06:19:22.638364
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti

# Generated at 2022-06-23 06:19:28.230700
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
    # play_context = PlayContext()
    # loader = DataLoader()
    # variable_manager = VariableManager()
    #
    # h = HandlerTaskInclude(
    #     loader=loader,
    #     variable_manager=variable_manager,
    #     play_context=play_context
    # )
    #
    # assert h.loader == loader
    # assert h.play_context == play_context
    # assert h.variable_manager == variable_manager

# Generated at 2022-06-23 06:19:30.682360
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    inst = HandlerTaskInclude()
    print(inst.VALID_INCLUDE_KEYWORDS)

# Generated at 2022-06-23 06:19:32.349934
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-23 06:19:41.557137
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t.__doc__ == '''
                A handler is like a regular task, but is run only once, if and when
                the TaskScheduler has determined that the handler should be run
                (usually as a result of the notifying a handler).
                '''

    assert t.action == 'meta'
    assert t.block == None
    assert t.role == None
    assert t.tags == []
    assert t.tasks == []
    assert t.when == '3.0'
    assert t.changed_when == '3.0'
    assert t.failed_when == '3.0'

# Generated at 2022-06-23 06:19:43.317517
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-23 06:19:47.707071
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.__dict__ == {'_loaded_from': None, '_block': None,
                                '_task_include': None, '_parent_role': None,
                                '_role': None, '_dep_chain': None}


# Generated at 2022-06-23 06:19:48.226433
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:56.022126
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.plugins.loader import handler_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    attr_dict = {
        'instance': 'localhost',
        'inventory': [Host(name='localhost')],
        'name': 'localhost',
        'vars': {'abc': '123'},
        'vars_plugins': [HostVars(hostname='localhost')],
    }
    host = Host(**attr_dict)
    play = Play()
    play.hosts = [host]
    play.name = 'localhost'
    role = Role()

# Generated at 2022-06-23 06:20:03.203083
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)
    input_data = {u'include': u'hello_world'}
    hti.check_options(hti.load_data(input_data, variable_manager=None, loader=None), input_data)
    assert hti.get_name() == 'handler'

# Generated at 2022-06-23 06:20:10.343181
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "name": "My handler",
        "hosts": ["all"],
        "listen": "some event",
        "include_tasks": "some_task.yml"
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.block == None
    assert handler.role == None
    assert handler.task_include == None
    assert handler.include_tasks == "some_task.yml"
    assert handler.hosts == ["all"]
    assert handler.listen == "some event"
    assert handler.name == "My handler"

# Generated at 2022-06-23 06:20:18.097162
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash
    import ansible.constants as C
    
    # Initialize objects
    loader = DataLoader()
    variable_manager = VariableManager()
    pb = Playbook()
    pb.vars_prompt = dict(var1='v1', var2='v2')

# Generated at 2022-06-23 06:20:19.162586
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:20:19.812572
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:20:31.663534
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Simple test for handling a task include
    task_include = HandlerTaskInclude.load(data={
        'include': 'hosts_ip.yml',
        'include_tasks': 'tasks.yml',
        'include_vars': 'vars.yml',
        'listen': 'listen.yml'
    })
    assert task_include.get_name() == 'include'
    assert task_include

# Generated at 2022-06-23 06:20:33.314564
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = HandlerTaskInclude()
    assert task is not None

# Generated at 2022-06-23 06:20:39.822920
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Setup variables
    data = dict(a=10)
    variable_manager = 'vm'
    loader = 'ldr'

    # Run the test
    result = HandlerTaskInclude.load(
        data,
        variable_manager=variable_manager,
        loader=loader
    )

    # Verify
    assert result.action

# Generated at 2022-06-23 06:20:46.266703
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # print("\nBefore:")
    # pprint.pprint(locals())
    hti = HandlerTaskInclude()
    # data = dict(include=dict(msg='hello'))
    data = dict(name='test_HandlerTaskInclude_load')
    hti.load(data)
    # print("\nAfter:")
    # pprint.pprint(locals())

    # assert hti.name == 'test_HandlerTaskInclude_load'


if __name__ == "__main__":

    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:20:58.218453
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block

    block = Block(
        parent_block=None,
        role=None,
        task_include=None,
        use_role_vars=False,
        use_role_tasks=False,
        use_role_handlers=False,
        use_role_defs=False,
        include_tasks=None,
        include_files=None,
        include_role=None,
    )

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 06:21:02.129920
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # This class is abstract
    try:
        h = HandlerTaskInclude()
    except TypeError as e:
        assert e.args[0] == "Can't instantiate abstract class HandlerTaskInclude with abstract methods check_options"
    else:
        assert False, "Should raise a TypeError"

# Generated at 2022-06-23 06:21:10.066702
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    test_obj = dict(
        name="HandlerTest",
        listen="test_handler",
        task=dict(include="test_include_tasks")
    )

    handler = HandlerTaskInclude.load(data=test_obj, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:21:19.973301
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.block import Block
  from ansible.playbook.task_include import TaskInclude

  mock_inventory = InventoryManager(loader=DataLoader(), sources='')

  mock_variable_manager = VariableManager(host_list=mock_inventory)

  mock_task_include = TaskInclude()

  # Test with no options
  mock_data = dict()
  handler_task_include = HandlerTaskInclude.load(mock_data, variable_manager=mock_variable_manager, task_include=mock_task_include)

  # Test with valid options

# Generated at 2022-06-23 06:21:28.775846
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    import os
    import sys
    import json

    def get_fixture_path(name):
        return os.path.join(os.path.dirname(__file__), 'fixtures', name)

    def get_fixture(name):
        return open(get_fixture_path(name)).read()

    def get_fixture_json(name):
        return json.loads(get_fixture(name))

    # loading data
    data = get_fixture_json('handler-task-include.json')

    # custom inventory

# Generated at 2022-06-23 06:21:35.603216
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name="foo",
        tasks="bar",
        listen="a,b,c"
    )

    # 不清楚如何 unit test.
    # t = HandlerTaskInclude.load(data)
    # assert data['name'] == t.name
    # assert data['tasks'] == t.tasks
    # assert data['listen'] == t.listen

# Generated at 2022-06-23 06:21:37.025712
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False


# Generated at 2022-06-23 06:21:46.493265
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    fake_loader = DataLoader()
    fake_inventory = Host()
    fake_variablemanager = VariableManager()

    my_data = {'listen': 'yes', 'static': 'all'}
    my_taskinc = TaskInclude.load(my_data, task_include=None, variable_manager=fake_variablemanager, loader=fake_loader)
    assert my_taskinc.static is True
    assert my_taskinc.static_vars is None

    my_data = {'listen': 'no', 'static': 'selected'}

# Generated at 2022-06-23 06:21:47.084208
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:21:55.347759
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    load_data = """
    - name: handler # noqa
      debug:
        msg: "test"
    """

    data = yaml.safe_load(load_data)

    handler = HandlerTaskInclude(block=None, role=None, task_include=None)

    handler = handler.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert handler.name == 'handler'

# Generated at 2022-06-23 06:22:07.749463
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_error_handling(data, error_message):
        try:
            HandlerTaskInclude.load(data)
            raise Exception('An error should have been raised')
        except:
            assert error_message in sys.exc_info()[1].message


    import ansible
    import sys

    data_normal = {
        'include': 'role1',
        'vars': {'foo': 'bar'}
    }

    data_invalid = {
        'include': [],
        'vars': {'foo': 'bar'}
    }

    data_missing_include = {
        'vars': {'foo': 'bar'}
    }

    data_missing_vars = {
        'include': 'role1'
    }


# Generated at 2022-06-23 06:22:14.919187
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Should not throw an exception
    valid_data = [
        dict(
            include='somefile.yml'
        ),
        dict(
            include='/home/someuser/somefile.yml'
        ),
        dict(
            include='somefile.yml',
            name='My Handler'
        ),
        dict(
            include='somefile.yml',
            listen='my_handler'
        )
    ]

    for entry in valid_data:
        HandlerTaskInclude(None, None, entry)

    # Should throw an exception
    invalid_data = [
        dict(
            include='somefile.yml',
            name='My Handler',
            listen='my_handler'
        )
    ]


# Generated at 2022-06-23 06:22:16.520164
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test if HandlerTaskInclude class can be instanciated
    HandlerTaskInclude()


# Generated at 2022-06-23 06:22:19.804683
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(obj, HandlerTaskInclude)



# Generated at 2022-06-23 06:22:23.551813
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'key1': 'value1'}
    task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = task_include.check_options(task_include.load_data(data), data)

    assert handler.action == 'value1'


# Generated at 2022-06-23 06:22:24.396337
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:22:31.221241
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook
    import ansible.plugins.loader

    t = ansible.playbook.HandlerTaskInclude()
    m = ansible.plugins.loader.add_cls('HandlerTaskInclude')
    m.load = ansible.playbook.HandlerTaskInclude().load
    ansible.plugins.loader.add_directory(ansible.__path__[0] + '/plugins')
    assert 'HandlerTaskInclude' in ansible.plugins.loader.all()

    assert False
    #TODO

# Generated at 2022-06-23 06:22:33.835530
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """ this is how we usually test classes in python """
    t = HandlerTaskInclude()
    #assertEqual(t.var1, 1)
    assert(True)

# Generated at 2022-06-23 06:22:37.174391
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_handler = HandlerTaskInclude()
    assert isinstance(my_handler, HandlerTaskInclude)
    assert isinstance(my_handler.VALID_INCLUDE_KEYWORDS, set)
    assert len(my_handler.VALID_INCLUDE_KEYWORDS) == 5

# Generated at 2022-06-23 06:22:38.448903
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None

# Generated at 2022-06-23 06:22:43.709485
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # testing with simple values
    block = None
    role = None
    task_include = None
    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    assert handler is not None
    assert handler.block == block
    assert handler.role == role
    assert handler.task_include == task_include

# Generated at 2022-06-23 06:22:54.397225
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("\n============== Test load of class HandlerTaskInclude")
    from ansible.parsing import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['hosts'])
    variable_manager.set_inventory(inventory)
    # Create data to load
    data = {
        'include': 'foo.yml',
        'static': 'bar.yml',
    }
    t = HandlerTaskInclude()
    handler = t.check_options(
            t.load_data(data, variable_manager=variable_manager, loader=loader),
            data
        )
    handler_dict = handler.get_vars()
    print

# Generated at 2022-06-23 06:23:04.676690
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = '''
    ---
    - include: foo.yml
        name: hello world
    '''
    h = HandlerTaskInclude(block=None, role=None, task_include=None)
    h.load_data(data, variable_manager=None, loader=None)
    assert h.include_role == None
    assert h.include_tasks == 'foo.yml'
    assert h.include_variables == None
    assert h.static == False
    assert h.ignore_errors == False
    assert h.loop == None
    assert h.loop_control == None
    assert h.name == 'hello world'

# Generated at 2022-06-23 06:23:05.664605
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:23:06.981223
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:23:08.349996
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:23:12.537401
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude(block = "someblock", role = "somerole", task_include = "sometask")
    assert task_include is not None, 'HandlerTaskInclude should be an instance'

# Generated at 2022-06-23 06:23:14.229959
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    instance = HandlerTaskInclude()
    assert isinstance(instance, HandlerTaskInclude)

# Generated at 2022-06-23 06:23:23.476752
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # case 1
    data = '''
    - name: Test handler
      foo: 1
      listen: test_handler
      '''
    # execute
    handler1 = HandlerTaskInclude.load(data)
    # verify
    assert handler1.name == 'Test handler'
    assert handler1.listen == 'test_handler'


    # case 2
    data = '''
    - name: Test handler
      foo: 1
      listen: test_handler
      tags:
        - test
      '''
    # execute
    handler2 = HandlerTaskInclude.load(data)
    # verify
    assert handler2.name == 'Test handler'
    assert handler2.listen == 'test_handler'
    assert handler2.tags == ['test']

# Generated at 2022-06-23 06:23:26.914367
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """ Constructor: HandlerTaskInclude()
    """

    h = HandlerTaskInclude()
    assert(isinstance(h, Handler))
    assert(isinstance(h, TaskInclude))

# Generated at 2022-06-23 06:23:30.431956
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_object = HandlerTaskInclude()
    test_data = {
        'include': 'this is a test'
    }

    test_result = HandlerTaskInclude.load(test_data)
    assert test_result.include == 'this is a test'


# Generated at 2022-06-23 06:23:35.143770
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load(
        dict(
            name="handler name",
            listen="foo",
            include="playbook.yml"
        )
    )
    assert handler.name == "handler name"
    assert handler.listen == "foo"
    assert handler.include == ["playbook.yml"]