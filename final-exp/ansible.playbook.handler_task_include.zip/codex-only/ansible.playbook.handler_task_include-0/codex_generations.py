

# Generated at 2022-06-23 06:13:33.430926
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

    assert handler_task_include is not None

# Generated at 2022-06-23 06:13:36.143166
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(
        data={
            'include': 'file1'
        }
    )
    assert handler.include == 'file1'
    assert handler.static is False

# Generated at 2022-06-23 06:13:46.569649
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {
        'name': 'my handler',
        'listen': 'myeventname'
    }
    block = []
    role = None
    task_include = None
    variable_manager = None
    loader = None
    
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.name == 'my handler'
    assert handler.listen == 'myeventname'
    assert not handler.listen_ignore_errors
    assert handler.included_filenames == []
    assert handler.notified_by == []
    assert handler.tags == []
    assert handler.only_if is None
    assert handler.when is None
    assert handler.run_once is False


# Generated at 2022-06-23 06:13:53.500794
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Make new object without input sentence
    test_object = HandlerTaskInclude()

    # Check if object is empty
    assert test_object.block is None
    assert test_object.role is None
    assert test_object.task_include is None

    # Make new object with input data
    test_role = test_object
    test_object = HandlerTaskInclude(block=test_role, role=test_role, task_include=test_role)

    # Check if object is not empty
    assert test_object.block is not None
    assert test_object.role is not None
    assert test_object.task_include is not None


# Generated at 2022-06-23 06:14:04.370136
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    # host
    data_host = {
            'name': 'localhost',
            'address': '127.0.0.1',
            'port': '22',
            'vars': {
                'var1': 'value1'
            }
    }
    host = Host(data_host)

    # role

# Generated at 2022-06-23 06:14:07.184104
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude.load({
        'include': 'test_copy3.yml'
}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:14:17.885996
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 06:14:19.505211
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:14:21.763149
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        handler = HandlerTaskInclude()
    except Exception as e:
        assert False


# Generated at 2022-06-23 06:14:30.990786
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    def _create_task(self):
        return Task()

    Host.setup_task_func = _create_task
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    host_name = 'myhost'
    host = inventory.add_host(host_name)

# Generated at 2022-06-23 06:14:36.116473
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data={"name":"test_HandlerTaskInclude"}
    h = HandlerTaskInclude.load(data)
    h.set_loader(None)
    h.set_block(None)
    h.set_task_include(None)
    a = h.get_name()
    assert a == "test_HandlerTaskInclude"

# Generated at 2022-06-23 06:14:48.296797
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # Creating an AnsibleHost object
    host = Host('test_host')
    # Creating an AnsibleGroup object
    group = Group('test_group')
    # Creating an InventoryManager object
    group.add_host(host)
    inventory = InventoryManager(
        loader=DataLoader(),
        sources=[]
    )
    # Adding a group to the inventory
    inventory.add_group(group)
    inventory.add_host(host)
    # Creating a VariableManager object
    variable_manager = Variable

# Generated at 2022-06-23 06:14:49.801982
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-23 06:14:54.390694
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)

    assert(handler.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS)

# Generated at 2022-06-23 06:14:59.017979
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h._load() is None
    assert h._load_file() is None
    assert h._load_name() is None
    assert h._load_role() is None
    assert h._load_tasks() is None
    assert h._load_tags() is None
    assert h._load_when() is None

# Generated at 2022-06-23 06:15:01.716881
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_playbook = AnsiblePlaybook()
    my_playbook.load()
    assert my_playbook.playbooks == {'name': 'Ansible Playbook'}

# Generated at 2022-06-23 06:15:02.445033
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:15:03.055736
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:04.645514
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include_object = HandlerTaskInclude()
    assert handler_task_include_object != None

# Generated at 2022-06-23 06:15:06.893815
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude();
    assert h is not None

# Generated at 2022-06-23 06:15:12.706729
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Initialize object
    data = dict()
    data['include'] = 'foo.yml'
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    t.check_options(t.load_data(data, variable_manager=None, loader=None), data)

    assert(t.get_name() == "Included")
    assert(len(t.get_tasks()) == 1)

# Generated at 2022-06-23 06:15:21.100453
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "include": {
            "tasks": "tasks/main.yml"
        },
        "listen": "include"
    }

    handler = HandlerTaskInclude.load(data)
    assert handler.action == 'include'
    assert handler.block == None
    assert handler.role == None
    assert handler.tags == None
    assert handler.when == None

    assert handler.included_file is not None
    assert handler.static_include is not None
    assert handler.action == 'include'

# Generated at 2022-06-23 06:15:29.677680
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test with construct as a handler file on a task
    hti1 = HandlerTaskInclude()
    assert hti1.VALID_INCLUDE_KEYWORDS == set(['when', 'listen'])
    assert hti1._load_name == 'include'

    # test with construct as a handler file on a role
    hti2 = HandlerTaskInclude(role='role_name')
    assert hti2.VALID_INCLUDE_KEYWORDS == set(['when', 'listen'])
    assert hti2._load_name == 'include_role'

# Generated at 2022-06-23 06:15:30.394567
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:15:42.429314
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible import constants as C
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    constant_loader = C.CLI()
    constant_loader.set_config_file('/etc/ansible/ansible.cfg')
    constant_loader.parse()
    C.config = constant_loader

    # initial data
    data = dict(
        include_tasks="./tasks/main.yml",
        include_role=dict(
            name="common",
            tags=["web","default"]
        ),
        include_vars=dict(
            file="vars/main.yml"
        )
    )

    # clone initial data


# Generated at 2022-06-23 06:15:45.596159
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert hasattr(t, 'VALID_INCLUDE_KEYWORDS') == True
    assert t.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:15:50.417669
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # data = {
    #     'name': 'My First Handler',
    #     'listen': 'modified_host'
    # }

    result = {}
    print('Result:', result)
    assert result

if __name__ == '__main__':
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:15:58.896961
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "handler_listen.yml": """
- name: test handler 127.0.0.1
  debug: msg="{{ pkey_data }}"
  listen: "test handler {{ pkey_data }}"
  #listen: "test handler {{ pkey_data }}"
        """
    })

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(pkey_data="test")

    host = Host(name="test")
    block = Block()
    task = Task()
    task.set_

# Generated at 2022-06-23 06:16:08.048839
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    
    block = Block(
      parent = None, 
      role = Role(name='test_role',
        tasks=[
          Task(name='test_task',
            action=dict(module='test', args='test')
          )
        ],
      )
    )
    
    
    handlerTaskInclude = HandlerTaskInclude(
      block=block,
      role=block.role,
      task_include=TaskInclude(
        block=block,
        role=block.role,
        task=block.role.get_tasks()[0]
      )
    )

# Generated at 2022-06-23 06:16:08.892529
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude


# Generated at 2022-06-23 06:16:10.673468
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:16:15.364081
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #AnsibleCoreTC.test_HandlerTaskInclude()
    pass


# Generated at 2022-06-23 06:16:16.216210
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:16.768338
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-23 06:16:24.093292
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    dummy_loader = DataLoader()
    dummy_h = Host('dummy_host')
    dummy_play_context = PlayContext()

    dummy_hostvars = HostVars(dummy_loader=dummy_loader, hostname='dummy_host')


# Generated at 2022-06-23 06:16:32.382854
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load: START")

    data = dict(
        include = dict(
            playbook = "test/test.yml"
        )
    )

    from ansible.playbook.task_include import TaskInclude
    t = TaskInclude.load(data)
    assert t, "TaskInclude.load returned None"

    from ansible.playbook.handler import Handler
    t = Handler.load(data)
    assert t, "Handler.load returned None"

    t = HandlerTaskInclude.load(data)
    assert t, "HandlerTaskInclude.load returned None"

    print("test_HandlerTaskInclude_load: END")



# Generated at 2022-06-23 06:16:43.859287
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'listen': 'restart_apache',
            'include': 'common_tasks.yml'}

    HandlerTaskInclude(block=None, role=None, task_include=None)

    # Check valid keywords
    for keyword in ('include', 'include_tasks', 'include_role', 'include_vars', 'include_lines'):
        assert keyword in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

    # Check load
    handler = HandlerTaskInclude.load(data,
                                      block=None,
                                      role=None,
                                      task_include=None,
                                      variable_manager=None,
                                      loader=None)
    assert isinstance(handler, Handler)
    assert 'restart_apache' == handler.listen

# Generated at 2022-06-23 06:16:45.759719
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Function to test load function of class HandlerTaskInclude
    '''
    pass

# Generated at 2022-06-23 06:16:54.985937
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import TemplateVars

    data = {
        'include': 'foo',
        'include_tasks': 'bar'
    }

    play_context = PlayContext()
    task = Task()
    block = Block()
    variable_manager = VariableManager()
    HostVarsVars({'my_var': 'my val'})

# Generated at 2022-06-23 06:17:02.267602
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create objects for inclusion:
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='tests/inventory')
    variable_manager.set_inventory(inventory)
    # Create a fake handler task with specified parameters and check whether the method load returns
    # an object of class HandlerTaskInclude or not
    data = {'tasks': 'tasks/main.yml', 'vars': {'your_name': 'John'}}
    handler = HandlerTaskInclude.load(data, variable_manager=None, loader=loader)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.block == None

# Generated at 2022-06-23 06:17:04.430255
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None
    )

    assert handler_task_include

# Generated at 2022-06-23 06:17:08.015869
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler

# Generated at 2022-06-23 06:17:10.214553
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    hti.load(data=None, block=None, role=None, task_include=TaskInclude)

# Generated at 2022-06-23 06:17:15.256724
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    This is a unit test for the HandlerTaskInclude module
    """
    block = {}
    role = {}
    task_include = {}
    data = {}
    variable_manager = {}
    loader = {}

    handler = HandlerTaskInclude.load(
        data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:17:22.806350
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    VariableManager = None
    Loader = None
    data = dict(include="tasks/main.yml", static="yes")
    handler = HandlerTaskInclude.load(data, variable_manager=VariableManager, loader=Loader)
    assert handler.include is not None
    assert handler._role is None
    assert handler._block is None
    assert handler._task is None
    assert handler._is_role is False
    assert handler._static is True
    assert handler._parent_role is None

    data = dict(include="tasks/main.yml")
    handler = HandlerTaskInclude.load(data, variable_manager=VariableManager, loader=Loader)
    assert handler.include is not None
    assert handler._role is None
    assert handler._block is None
    assert handler._task is None
    assert handler._is_role is False

# Generated at 2022-06-23 06:17:25.469447
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    handler = h.load({"action": "notify", "listen": "xyz"})
    assert handler.action == "notify"

# Generated at 2022-06-23 06:17:27.603673
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler


# Generated at 2022-06-23 06:17:28.579184
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """

    """

    pass

# Generated at 2022-06-23 06:17:38.877719
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    h = Host("localhost")
    p = Play()
    r = Role()
    b = Block()
    t = Task()
    ti = TaskInclude()

    hst = HandlerTaskInclude(block=b, role=r, task_include=ti)

    from ansible.vars import VariableManager
    vm = VariableManager()


# Generated at 2022-06-23 06:17:42.847793
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # handler_task_include = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert False


# Generated at 2022-06-23 06:17:46.947338
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'tasks': [
            {
                'name': 'Test',
                'action': {
                    'module': 'debug',
                    'msg': 'Hello World'
                }
            }
        ]
    }

    _ = HandlerTaskInclude.load(data)


# Generated at 2022-06-23 06:17:50.114841
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create instance of class HandlerTaskInclude
    t = HandlerTaskInclude()

    # Check that each member of the class has an instance
    assert isinstance( t.load_data, object )

# Generated at 2022-06-23 06:17:56.082416
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    print(hti.VALID_INCLUDE_KEYWORDS)
    assert isinstance(hti.VALID_INCLUDE_KEYWORDS, set)
    
    dict_data = dict(
        name='include_tasks'
    )
    hti.load_data(dict_data)
    assert isinstance(hti.static_tasks, list)
    assert len(hti.static_tasks) == 1

# Generated at 2022-06-23 06:18:08.377598
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(('name', 'tasks', 'vars', 'handlers', 'defaults', 'pre_tasks', 'post_tasks', 'when', 'sudo', 'sudo_user', 'listen'))
    assert len(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS) == 12
    assert len(HandlerTaskInclude.VALID_HANDLER_KEYWORDS) == 2
    assert HandlerTaskInclude.VALID_HANDLER_KEYWORDS == set(('name', 'listen'))

    assert HandlerTaskInclude.VALID_RESULT_KEYWORDS == set(('changed', 'failed', 'skipped', 'unreachable', 'msg', 'reboot_required', 'task_start'))

# Generated at 2022-06-23 06:18:11.989706
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler = HandlerTaskInclude()

    assert handler.__class__.__name__ == 'HandlerTaskInclude'
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None

# Generated at 2022-06-23 06:18:14.549752
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # data = {'when': 'nothing'}
    # h = HandlerTaskInclude(data)
    # assert h is not None
    pass


# Generated at 2022-06-23 06:18:24.523171
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import sys
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    print(tmpdir)


# Generated at 2022-06-23 06:18:37.254545
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    HandlerTaskInclude:
    The static method load() is used to construct a new instance of a HandlerTaskInclude.
    """
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    import pprint

    # Setup inventory
    add_all_plugin_dirs()
    inventory = InventoryManager(loader=DataLoader())

# Generated at 2022-06-23 06:18:39.008566
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   handler_task_include_object = HandlerTaskInclude()
   assert handler_task_include_object != None

# Generated at 2022-06-23 06:18:47.737114
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    def __init__(self, block=None, role=None, task_include=None):
        self._block = block
        self._role = role
        self._task_include = task_include

    # ansible-playbook - test include_tasks
    task_incl1 = TaskInclude()
    task_incl1._role_name = 'test-role'
    task_incl1._role_path = '~/.ansible/roles/test-role'
    task_incl1._task_name = 'test-task'
    task_incl1._role = 1
    task_incl1._block = 'test-block'
    task_incl1._task_include = 'test-task.yml'

# Generated at 2022-06-23 06:18:49.948288
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.is_handler_task() is True
    assert handler.VALID_INCLUDE_KEYWORDS == \
        HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-23 06:18:52.782381
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    hti2 = HandlerTaskInclude()
    assert hti.__class__ == hti2.__class__


# Generated at 2022-06-23 06:18:58.117170
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    x = HandlerTaskInclude.load(
        data={
            "include": '{{ role_name.include }}',
            "tags": ['a', 'b', 'c'],
            "listen": "a_listen"
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None)
    assert(x.get_tags() == ['a', 'b', 'c'])


# Generated at 2022-06-23 06:19:00.617107
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        assert HandlerTaskInclude._constructor() is None
    except TypeError:
        raise

# Generated at 2022-06-23 06:19:11.135183
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    """
    Validate the HandlerTaskInclude class and its constructor
    """

    from ansible.playbook.block import Block

    from ansible.playbook.role import Role

    from ansible.parsing.yaml.objects import AnsibleSequence

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import action_loader

    from ansible.plugins.loader import callback_loader

    from ansible.plugins.loader import connection_loader

    from ansible.plugins.loader import filter_loader

    from ansible.plugins.loader import lookups_loader

    from ansible.plugins.loader import strategy_loader

    from ansible.plugins.loader import test_loader

    from ansible.plugins.loader import vars_loader

   

# Generated at 2022-06-23 06:19:13.553159
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    pass # TODO

# Generated at 2022-06-23 06:19:24.758108
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create DataLoader
    options = {"connection": "local"}
    loader = DataLoader()

    # Create VariableManager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create block
    block = Block(None)

    # Create object HandlerTaskInclude
    handler_task_include = HandlerTaskInclude()

    # Define data
    data = {
        'name': 'Ansible Test',
        'include': 'main.yml',
        'tags': ['test', 'include']
    }

    handler_task_include.load(data, block=block, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-23 06:19:29.751733
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        block=dict(name="test_block"),
        role=dict(name="test_role"),
        task_include=dict(name="test_task_include")
    )

    assert handler.VALID_INCLUDE_KEYWORDS == set(('listen',))
    assert handler.block.get("name") == "test_block"
    assert handler.role.get("name") == "test_role"
    assert handler.task_include.get("name") == "test_task_include"

# Generated at 2022-06-23 06:19:38.485176
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    block = Block()
    assembly = Task()
    t = HandlerTaskInclude(block, 
                           role=None, 
                           task_include=assembly)

    assert t is not None, "Failed to create task"

# Generated at 2022-06-23 06:19:39.605795
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load()

# Generated at 2022-06-23 06:19:50.134218
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block = {}
    role = None
    task_include = None
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler = t.check_options(
        t.load_data(data, variable_manager=None, loader=None),
        data
    )
    assert data == {u'include': {u'handlers': u'myhandlers.yml'}}
    assert block == {}
    assert role is None
    assert task_include is None

# Generated at 2022-06-23 06:19:56.758776
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'action_handler',
        'notify': ['handler1']
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert handler is not None

    assert handler.name == 'action_handler'
    assert len(handler.notified_by) == 1
    assert handler.notified_by[0] == 'handler1'

    data = {
        'include': 'action_handler',
        'notify': ['handler1', 'handler2']
    }
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert handler is not None

# Generated at 2022-06-23 06:20:04.908723
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    h = HandlerTaskInclude.load(data={'include':'test.yml'})
    assert h.get_name() == 'name'
    assert h.get_block() == None
    assert h.get_role() == None
    assert h.get_task_include() == None
    assert h.get_action() == 'include'
    assert h.is_block() == False
    assert h.is_role() == False
    assert h.is_task_include() == False

# Generated at 2022-06-23 06:20:15.058827
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    ns = globals()
    ns['HandlerTaskInclude'] = HandlerTaskInclude
    yaml_text = '''
- hosts: localhost
  vars:
    var1: 1
  handlers:
        - name: handler name
          shell: "echo {{var1}}"
'''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = Inventory(loader, [])
    variable_manager = VariableManager()

    play = Play.load(yaml_text, loader=loader, inventory=inventory, variable_manager=variable_manager)


# Generated at 2022-06-23 06:20:16.054991
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-23 06:20:20.457530
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = Host(name = '192.168.1.1')
    handler = HandlerTaskInclude.load({'name': 'test', 'listen': 'a_handler'})
    assert handler.get_name() == 'a_handler'
    assert handler.get_action() == 'test'

# Generated at 2022-06-23 06:20:32.421945
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host = Host(name="test-host")
    inventory = Inventory(loader=DataLoader())
    inventory.add_host(host=host)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()

    block = Block(
        role=Role(),
        task_include=None,
        plays=None,
        parent_block=None,
        role_params=None
    )

    task_include = Task

# Generated at 2022-06-23 06:20:36.641857
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(None, None)
    print(t.VALID_INCLUDE_KEYWORDS)

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:20:38.048687
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude


# Generated at 2022-06-23 06:20:43.945139
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Given
    data = dict(
        include="",
        tags={"my_tag"},
    )

    # When
    handler = HandlerTaskInclude.load(data)

    # Then
    assert handler.include == "", "Attribute include of handler is not set correctly"
    assert handler.tags == {"my_tag"}, "Attribute tags of handler is not set correctly"

# Generated at 2022-06-23 06:20:49.358794
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.mod_args import ModuleArgsParser

    def _yaml2data(yaml):
        data = yaml.encode('utf-8')
        data = yaml_load(data, AnsibleLoader)
        return data

    # Init inventory
    inventory = InventoryManager(loader=None, sources=None,
                                 host_list=[])
    inventory.subset("foo")
    foo_group = Group('foo')
    inventory.add_group(foo_group)
    host = Host("localhost", port=22)

# Generated at 2022-06-23 06:20:50.384671
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:21:01.269535
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import unittest
    import mock
    from ansible.inventory.host import Host

    class AnsibleDict(dict):
        def __init__(self, *args, **kwargs):
            super(AnsibleDict, self).__init__(*args, **kwargs)
            self.A_DICT = dict()

        def get(self, key, *args, **kwargs):
            try:
                return self.__getitem__(key)
            except KeyError:
                if len(args) > 0:
                    return args[0]
                else:
                    return None

        def __getitem__(self, *args, **kwargs):
            key = args[0]

# Generated at 2022-06-23 06:21:01.660784
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:21:02.597245
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task1 = HandlerTaskInclude()
    print(task1)

# test_HandlerTaskInclude()


# Generated at 2022-06-23 06:21:07.296939
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    h = HandlerTaskInclude()
    assert h.check_keys == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-23 06:21:11.182769
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_host = "testhost"
    test_block = "testblock"
    test_role = "testrole"
    test_task_include = "testtaskinclude"
    test_data = "testdata"

    ansible_handler = HandlerTaskInclude(block=test_block, role=test_role, task_include=test_task_include)
    ansible_handler.load(data=test_data)


# Generated at 2022-06-23 06:21:19.250296
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    This isn't really a test, but this serves as a documentation
    and a proof of concept of what you can do with the code in this file
    '''

    # init a task_include
    t = TaskInclude()

    # create a data structure of the keyword arguments to give to the constructor
    data = dict(
        block=None,
        role=None,
        task_include=None
    )

    # create an instance of HandlerTaskInclude
    handler = HandlerTaskInclude(**data)

    # the following should be the same
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:21:21.117856
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler


# Unit test to check valid keywords

# Generated at 2022-06-23 06:21:21.501823
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:21:22.456325
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler != None

# Generated at 2022-06-23 06:21:33.547393
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    host = Host('testhost')

    group = Group('testgroup')
    group.add_host(host)

    inventory = InventoryManager(loader=DataLoader(), sources=None)
    inventory.add_group(group)

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-23 06:21:35.587598
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    t = HandlerTaskInclude()
    handler = t.load(data)
    assert handler



# Generated at 2022-06-23 06:21:45.772705
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Make sure that load does not try to set 'ignore_errors' from a play.
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=None))

    myblock = Block()
    myblock.root_level = True

    mytask = AnsibleMapping()
    mytask['name'] = 'toto'
    mytask['ignore_errors'] = 'true'

    mydata = AnsibleMapping()
    mydata['include'] = mytask


# Generated at 2022-06-23 06:21:46.689650
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True
# HandlerTaskInclude.load = load

# Generated at 2022-06-23 06:21:49.029439
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
    # TODO
    # handler = HandlerTaskInclude.load(data=None)
    # assert handler is not

# Generated at 2022-06-23 06:21:51.928486
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()
    h.load(data={})
    h.load(data={'key': 'value'})


# Generated at 2022-06-23 06:21:54.464415
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Handler(
        block=None,
        role=None,
        task_include=None
    )

# Generated at 2022-06-23 06:21:57.052180
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)

# Generated at 2022-06-23 06:22:09.016480
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Testing method load of class HandlerTaskInclude')
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block
    from ansible.playbook.block import BlockInclude
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 06:22:09.981596
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, 'not implemented'


# Generated at 2022-06-23 06:22:20.065580
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars


    v = VariableManager()
    v.set_inventory(HostVars(
        host_list=[
            Host(name='localhost')
        ]
    ))
    handler_task_include = HandlerTaskInclude(variable_manager=v, loader=None)

# Generated at 2022-06-23 06:22:20.925909
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: to be implemented
    pass

# Generated at 2022-06-23 06:22:22.173974
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Incomplete
    pass

# Generated at 2022-06-23 06:22:33.463783
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import ansible.parsing.yaml.dumper
    import ansible.playbook.play
    import pprint

    inventory_manager=InventoryManager()
    inventory_manager.add_group("test-group")
    group=Group("test-group")
    group.add_host(Host("test-host"))
    inventory_manager.add_group(group)
    variable_manager=VariableManager(inventory_manager)
    variable_manager.extra_vars = {"test":"test"}

# Generated at 2022-06-23 06:22:37.437702
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    fp = 'tests/unit/playbook/v2/test_loader_include_handler.yml'
    print(fp)
    data = dict()
    data.update(listen='all')
    data.update(include=fp)
    print(data)
    # handler = HandlerTaskInclude.load(data)
    # print(handler)


# Generated at 2022-06-23 06:22:49.331896
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.base import PlayBook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    context._tqm = AnsibleTQM(
        inventory=PlayBook().get_inventory(),
        variable_manager=VariableManager(),
        loader=None,
        passwords={},
    )
    block = Task.load(dict(action=dict()), play=None, variable_manager=VariableManager(), loader=None)
    block._parent = Task.load(dict(action=dict(args=dict())), play=None, variable_manager=VariableManager(), loader=None)
    block._

# Generated at 2022-06-23 06:23:05.481716
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    variables = {'variable': 'value'}
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:23:05.858024
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:08.295173
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Unit test of load method

# Generated at 2022-06-23 06:23:20.135136
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    yaml_data = """
- test_handler:
    tags:
    - test
    - test2
    name: test
    notify:
    - test_task
    - test_task2
    listen:
    - test_listen"""
    # from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleError
    # from ansible.inventory.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars.collection import VariableCollection
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-23 06:23:32.118013
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    host = Host(name="test_handler")

    play = Play()
    play.name = "test_play"

    task = Task()
    task.name = "test_task"
    task._role = RoleDefinition()
    task._block = Block()
    task._role.name = "test_role"
    task._block.name = "test_block"
    task._role._play = play
    task._block._play = play
