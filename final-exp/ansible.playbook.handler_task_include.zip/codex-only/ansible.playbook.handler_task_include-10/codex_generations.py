

# Generated at 2022-06-23 06:13:32.792223
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_handler = HandlerTaskInclude()
    assert task_handler is not None

# Generated at 2022-06-23 06:13:36.379634
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include_tasks': 'foo.yml',
        'tags': ['bar', 'baz'],
    }
    t = HandlerTaskInclude(data=data)
    assert t.include is not None
    assert t.tags == ['bar', 'baz']

# Generated at 2022-06-23 06:13:37.211859
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    pass

# Generated at 2022-06-23 06:13:38.120517
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print( HandlerTaskInclude() )

# Generated at 2022-06-23 06:13:39.271439
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    task = HandlerTaskInclude.load(data)
    assert task

# Generated at 2022-06-23 06:13:49.280965
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    h = HandlerTaskInclude.load(
        data={
            'include': 'include.yml', 'listen': 'fail'
        },
        variable_manager={},
        loader={},
    )


# Generated at 2022-06-23 06:14:00.325446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    host = Host(name="hostname")
    host.set_variable('ansible_ssh_host', '10.10.10.10')
    host.set_variable('ansible_ssh_pass', 'password')
    host.set_variable('ansible_ssh_port', 22)
    host.set_variable('ansible_ssh_user', 'username')
    host.set_variable('ansible_ssh_private_key_file', None)
    host.set_variable('ansible_connection', 'ssh')
    host.set_variable('ansible_ssh_common_args', '-o StrictHostKeyChecking=no')
    host.set_variable('ansible_ssh_extra_args', '')
    host.set_variable('ansible_sudo', True)

# Generated at 2022-06-23 06:14:02.797168
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    H = HandlerTaskInclude()
    assert isinstance(H, HandlerTaskInclude)
    assert isinstance(H, Handler)
    assert isinstance(H, TaskInclude)

test_HandlerTaskInclude()

# Generated at 2022-06-23 06:14:04.330367
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a instance of HandlerTaskInclude
    hti = HandlerTaskInclude()

    assert hti is not None

# Generated at 2022-06-23 06:14:08.133774
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#    task_file = 'path/to/task_file.yml'
#    task_data = {'include': task_file}
#    task_include = TaskInclude.load(task_data)
#    hti = HandlerTaskInclude.load(task_data)
#

# Generated at 2022-06-23 06:14:11.046907
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

    assert handler.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS


# Generated at 2022-06-23 06:14:15.159795
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    import json
    print(json.dumps({'ansible_facts': t.__dict__}, indent=4))


if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:14:16.458395
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:14:21.738130
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    example_data = {
        'name': 'Ansible Test',
        'sudo': True,
        'sudo_user': 'root',
        'listen': 'Test',
        'tasks': [
            {'ping': 'pong'},
            {'win_ping': 'pong'},
            {'win_ping': 'pong'}
        ]
    }

    test_obj = HandlerTaskInclude.load(example_data)
    assert test_obj.name == 'Ansible Test'
    assert test_obj.become
    assert test_obj.become_user == 'root'

# Generated at 2022-06-23 06:14:29.181592
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    data = dict(
        include='myrole.yaml',
        include_tasks='myrole.yaml',
        include_role='myrole.yaml',
        include_vars='myrole.yaml',
    )
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)

    assert handler is not None



# Generated at 2022-06-23 06:14:30.127182
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:14:41.526762
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-23 06:14:43.852175
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti is not None

# Generated at 2022-06-23 06:14:47.877416
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task1 = {'include': 'test.yml'}
    task_include = HandlerTaskInclude()
    try:
        task_include.load(task1)
    except:
        assert False, 'task include constructor failed'
    assert True

# Generated at 2022-06-23 06:14:58.617341
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    h = Handler(task=None)
    block = Block(name='foo')
    task = Task()
    task._name = 'foo'
    group = Group()
    host = Host()
    variable_manager = VariableManager()
    loader = DataLoader()

    # test with the full arguments
    handler = HandlerTaskInclude(block=block, role=role, task_include=task, variable_manager=variable_manager, loader=loader)

    # test with

# Generated at 2022-06-23 06:15:09.264277
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    args_list = [
        { "tags":
            [
                [
                    "all"
                ]
            ],
            "block":
            [
                {
                    "when":
                    [
                        [
                            "failed"
                        ]
                    ],
                    "name":
                    [
                        "name"
                    ]
                }
            ],
            "include":
            [
                [
                    "task-files/main.yml"
                ]
            ],
            "type":
            "include",
            "register":
            "my_include_file"
        }
    ]
    obj = HandlerTaskInclude(**args_list)
    assert obj.type == "include"
    assert len(obj.tags) == 1
    assert obj.tags[0] == "all"

# Generated at 2022-06-23 06:15:16.254104
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Unit test for method load of class HandlerTaskInclude
    """

    handler_task_include_obj = HandlerTaskInclude()
    handler = handler_task_include_obj.load('name', 'block', 'role', 'task_include')

    assert handler

    block = Block(handlers=[])
    task = Task()
    role = Role()
    role._role_path = 'role_path'
    block._parent = task
    task._parent = role
    handler = handler_task_include_obj.load('name', block, role, 'task_include')

    assert handler


# Generated at 2022-06-23 06:15:18.768654
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """This is a test function to create class HandlerTaskInclude."""
    handler = HandlerTaskInclude()

# Generated at 2022-06-23 06:15:30.570199
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.parsing.yaml.objects
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    #Create a host
    host = ansible.inventory.host.Host(name="test.example.com")
    #Create a variable manager
    variable_manager = ansible.vars.manager.VariableManager()
    #Create a loader
    loader = DataLoader()
    #Create an empty playbook
    playbook = ansible.playbook.PlayBook()
    ansible.playbook.PlayBook.load = lambda *args, **kwargs: playbook

    #Create a HandlerTaskInclude object

# Generated at 2022-06-23 06:15:35.571827
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a HandlerTaskInclude object instance
    h = HandlerTaskInclude()

    # Verify object is created
    if isinstance(h, HandlerTaskInclude):
        print("Pass")
    else:
        print("Fail")

# Constructor test
test_HandlerTaskInclude()

# Generated at 2022-06-23 06:15:37.603105
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t is not None


# Generated at 2022-06-23 06:15:48.606389
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Given: A HandlerTaskInclude object
    handler = HandlerTaskInclude()

    # When: 'valid_include_keywords' is called
    VALID_INCLUDE_KEYWORDS = HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    NUM_VALID_INCLUDE_KEYWORDS = len(VALID_INCLUDE_KEYWORDS)

    # Then:
    assert handler.VALID_INCLUDE_KEYWORDS == set(['when', 'ignore_errors', 'only_if', 'static', 'listen', 'register', 'delegate_to', 'tags', 'run_once', 'block', 'become_user', 'first_available_file', 'include', 'connection', 'vars', 'remote_user'])
    assert handler.VALID_INCLUDE

# Generated at 2022-06-23 06:15:58.097844
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Make a task which is just a string.
    handler = "shell: /bin/foo"
    role = None

    # Make a base task, with a role and a block, and a handler which is
    # another task.
    base_task = dict(
        handlers=handler,
        block=dict(
            handlers=handler
        ),
        role=dict(
            handlers=handler
        )
    )

    # Make a fake inventory.
    fake_inventory = Inventory(loader=DataLoader())

    # Make a fake loader.
    fake_loader = DataLoader()

    # Make the variable manager.

# Generated at 2022-06-23 06:16:05.838197
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Sample include data
    data = {'handlers': [{'name': 'Custom'}]}

    # Create HandlerTaskInclude object
    t = HandlerTaskInclude()

    # Get an instance of Handler and assert that it is an instance of Handler
    handler = t.load(data)
    assert isinstance(handler, Handler)

    try:
        # Try to load a wrong data and assert that an exception is thrown
        t.load(data={'name': 'Custom'})
        assert False
    except AssertionError as e:
        assert True
    except Exception as e:
        assert False



# Generated at 2022-06-23 06:16:20.425296
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include = dict(
            tasks = dict(
              file = "path/to/handler.yaml",
              static = dict(
                  handler_task = dict(
                      debug = dict(
                          msg = "DEBUG handler task test"
                      )
                  )
              )
            )
        )
    )

    # Expected values
    task_include = []
    handlers = dict(
        handler_task = dict(
            debug = dict(
                msg = "DEBUG handler task test"
            )
        )
    )
    include_tasks = dict(
        file = "path/to/handler.yaml"
    )

    # Test
    handler = HandlerTaskInclude.load(data, task_include=task_include)
    assert handler._handlers == handlers
    assert handler._task_

# Generated at 2022-06-23 06:16:22.520035
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t.__class__.__name__ == 'HandlerTaskInclude', "object should be of class HandlerTaskInclude"

# Generated at 2022-06-23 06:16:30.440608
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = TaskInclude()
    data = dict(
        _raw = dict(
            action = {
                "module": "setup"
            },
            listen = "all"
        )
   )
   # data = dict(
   #      listen = "all"
   #  )
    handlerTaskInclude = HandlerTaskInclude(task_include=task_include)

    handlerTaskInclude.load_data(data)

    assert handlerTaskInclude.get_name() == 'setup'
    assert handlerTaskInclude.loop is None

# Generated at 2022-06-23 06:16:43.491788
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    playbooks = [Playbook.load("./test-data/test_playbooks/handler-task.yml", loader=C.loader)]
    # Playbook._load_roles() will be called in Playbook.load(), it will
    # set Playbook.roles_path, Playbook.roles, Playbook.__roles_definitions and Playbook.__roles_requirements
    # with ansible-roles directory and role information respectively.
    # Therefore, we

# Generated at 2022-06-23 06:16:47.540550
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    try:
        HandlerTaskInclude.load('/test/test', '/test/test')
    except Exception as err:
        print(str(err))

if __name__ == '__main__':
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:16:57.801518
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    HOSTS = [
        "localhost",
        "127.0.0.1",
        "192.168.0.1",
        "www.example.com",
        "example.com",
        "google.com",
        "184.48.228.250",
        "10.0.0.1",
    ]

    #    import json
    #    input_json = {
    #        "hosts": [
    #            "localhost",
    #            "127.0.0.1",
    #            "192.168.0.1",
    #            "www.example.com",
    #            "example.com",
    #            "google.com",
    #            "184.48.228.250",
    #            "10.0.0.1",
    #        ],


# Generated at 2022-06-23 06:17:00.480404
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    blk = Block()
    ro = Role()

    data = dict(
        name = 'Mock Handler',
        listen = 'service name'
    )

    handler = HandlerTaskInclude.load(data, block=blk, role=ro)

# Generated at 2022-06-23 06:17:10.080426
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import Reserved
    from ansible.constants import DEFAULT_HANDLER_NAME

    block =  Block(
        parent=Task(
            name='name',
            action='action',
            task_includes=[],
            role=None,
            play=None,
            hosts=Host('test'),
        ),
    )

    block.block_name = 'block_name'


# Generated at 2022-06-23 06:17:10.762734
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:15.735191
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create variables for testing
    data = dict()
    block = dict()
    role = dict()
    task_include = dict()
    variable_manager = dict()
    loader = dict()

    result = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert result is not None

# Generated at 2022-06-23 06:17:16.332211
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:16.923008
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:17:21.939557
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    role = Role()
    task_include = TaskInclude()

    ht = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    assert ht.block == block
    assert ht.role == role
    assert ht.task_include == task_include


# Generated at 2022-06-23 06:17:22.998154
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()

# Generated at 2022-06-23 06:17:28.314594
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = [
        {'include': 'test.yml',
         'tags': ['test', 'test2'],
         'register': 'step1'}
    ]

    handler = HandlerTaskInclude.load(data)
    assert isinstance(handler, HandlerTaskInclude)

    data = 'test.yml'

    handler = HandlerTaskInclude.load(data)
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-23 06:17:38.691914
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    variables = dict(name="TEST")
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    h = Host(name="TEST")
    g = Group(name="TEST")
    variable_manager = VariableManager(loader=None, variables=variables)
    variable_manager.set_inventory(g.get_inventory())

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task = Task()
    block = Block(tasks=[task])
    bt = HandlerTaskInclude(block=block, role=None, task_include=task)

# Generated at 2022-06-23 06:17:39.918614
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:44.165621
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_data = 'listen: test'
    handler_name = 'listen_test'
    handler_data_dict = {handler_name: handler_data}
    handler = HandlerTaskInclude.load(data=handler_data_dict)

# Generated at 2022-06-23 06:17:54.247291
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.data import AnsibleMapping, AnsibleUnicode

    block = Block()
    role = Role()
    task_include = TaskInclude()
    data = AnsibleMapping({
        'include': AnsibleUnicode('test'),
        'name': AnsibleUnicode('include test')
    })
    handler = HandlerTaskInclude.load(data, block, role, task_include)
    # If there is no assertion error, then test is passed.
    print(handler)

# Generated at 2022-06-23 06:17:56.251086
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t is not None

# Generated at 2022-06-23 06:17:57.080281
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('hello')

# Generated at 2022-06-23 06:18:08.893075
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    init class HandlerTaskInclude
    '''
    x = HandlerTaskInclude()
    data = {"name": "test_name",
            "include": "test_include",
            "listen": "test_listen"}

    # execute method load, it will raise an exception
    # because variable variable_manager is None
    try:
        x.load(data)
    except TypeError as e:
        print(e)

    # execute method load, it will raise an exception
    # because variable loader is None
    try:
        x.load(data, variable_manager='test_variable_manager')
    except TypeError as e:
        print(e)

    data_returned = x.load(data, variable_manager='test_variable_manager', loader='test_loader')
    # print(data_return

# Generated at 2022-06-23 06:18:09.576649
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:10.682050
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(None)

# Generated at 2022-06-23 06:18:14.221257
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude()
    assert isinstance(task_include, HandlerTaskInclude)
    assert isinstance(task_include, Handler)
    assert isinstance(task_include, TaskInclude)

# Generated at 2022-06-23 06:18:24.323632
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a function to call module load method with arguments
    def call_load_args(data):
        HandlerTaskInclude.load(data)

    #
    # Unit test for exception
    #
    # Input arguments for the exception test
    data = {'include': 'dummy_include'}

    # Perform the exception test
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    from ansible.executor.task_queue_manager import TaskQueueManager

    for task_name in data:
        assert task_name in HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
        assert task_name in TaskInclude.VALID_INCLUDE_KEYWORDS

    # Exception test - absolute path
    # AssertionError: Unable to load include file: {

# Generated at 2022-06-23 06:18:36.937392
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:18:39.463410
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    construct = {'static': 'yes'}
    obj = HandlerTaskInclude(block=None, role=None, task_include=None, params=construct)
    assert obj.params == construct

# Generated at 2022-06-23 06:18:40.074417
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-23 06:18:40.906847
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Ansible")

# Generated at 2022-06-23 06:18:42.151079
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:18:42.653851
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:18:51.236463
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    host = Host('h1', 'h1')
    host.set_variable('x', 0)
    hosts = {'h1': host}

    role = Role()
    block = Block()

    h = HandlerTaskInclude.load({
        'include': 'foo.yml',
        'when': 'x==0'
    }, block, role, None, VariableManager(loader=None, hosts=hosts), dict())

    # h = HandlerTaskInclude(block=block, role=role, task_include=None)
    # h.check_options(h.load_data({
    #     'include': 'foo.

# Generated at 2022-06-23 06:18:51.712173
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:54.317037
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Handler as UnitHandler
    from ansible.playbook.block import Block as UnitBlock
    #TODO:
    # t = HandlerTaskInclude(UnitBlock(), None)
    # t.check_options(t, {})
    pass


# Generated at 2022-06-23 06:19:03.432463
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict()
    data['action'] = dict()
    data['action']['__ansible_argspec'] = dict()
    data['action']['__ansible_argspec']['args'] = ['self', 'task_vars']
    data['action']['__ansible_argspec']['kwargs'] = ['host', 'play_context']
    data['action']['__ansible_argspec']['varargs'] = ''
    data['action']['__ansible_argspec']['varkw'] = ''

    h = HandlerTaskInclude.load(data)
    assert h.action.__ansible_argspec['args'] == ['self', 'task_vars']

# Generated at 2022-06-23 06:19:13.245298
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import PlayBook
    from units.mock.loader import DictDataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    with open("data/handler_task.json", "r") as handler_task_data:
        handler_task_data = json.load(handler_task_data)

# Generated at 2022-06-23 06:19:16.669023
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None, "Create an instance of HandlerTaskInclude"

# Generated at 2022-06-23 06:19:18.737388
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    t.check_options(t.load_data(data = dict(foo = 'bar'), variable_manager=None, loader=None),dict(foo = 'bar'))

# Generated at 2022-06-23 06:19:27.868935
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class TestTaskInclude(object):
        def __init__(self, block=None, role=None, task_include=None):
            self.block = block
            self.role = role
            self.task_include = task_include

        def load_data(self, data, variable_manager=None, loader=None):
            return data

        def check_options(self, options, data):
            return options

        def _task_include(self):
            return '_task_include'

    handler_task_include = HandlerTaskInclude(block='block', role='role', task_include=TestTaskInclude())
    data = {'test': 'value_test'}
    variable_manager = {'test': 'value_variable_manager'}
    loader = {'test': 'value_loader'}
    assert handler_

# Generated at 2022-06-23 06:19:38.986903
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import sys
    # import copy
    import unittest2 as unittest
    from ansible import errors
    from ansible.utils.vars import combine_vars

    class TestHandlerTaskInclude(unittest.TestCase):
        def setUp(self):
            self.sys_path = sys.path
            self.test_dir = os.path.dirname(__file__)

            # Make sure we are testing the api we are supposed to be,
            # and not the one loaded from site-packages
            site_pkgs = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            if site_pkgs in sys.path:
                sys.path.remove(site_pkgs)


# Generated at 2022-06-23 06:19:39.666502
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:43.108195
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:19:43.615675
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:53.298373
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task

    block = Block()
    variable_manager = VariableManager()
    loader = variable_manager._loader
    play = Play()
    play._variable_manager = variable_manager
    play._included_files = [IncludedFile()]
    play._included_file._id = 'include_handler.yml'
    block._play = play
    task = Task()
    task._parent = block
    block

# Generated at 2022-06-23 06:19:56.293168
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    handler_task_include = HandlerTaskInclude.load(data)
    assert isinstance(handler_task_include, HandlerTaskInclude)

# Generated at 2022-06-23 06:20:08.543115
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    yaml_data = """
- name: restart apache
  service: name=apache state=restarted
"""
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(yaml_data, block=block, role=role, task_include=task_include,
                                      variable_manager=variable_manager, loader=loader)
    handler = HandlerTaskInclude.load(yaml_data, block=block, role=role, task_include=task_include,
                                      variable_manager=variable_manager, loader=loader)

    # __repr__

# Generated at 2022-06-23 06:20:09.914995
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:20:11.459462
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   HandlerTaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-23 06:20:14.102592
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data_dict = {'listen': 'test_listen'}
    test_handler = HandlerTaskInclude.load(data_dict)
    assert test_handler.listen == 'test_listen'

# Generated at 2022-06-23 06:20:15.039108
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-23 06:20:23.962614
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'block': None,
        'role': None,
        'task_include': None,
        'variable_manager': None,
        'loader': None,
    }
    t = HandlerTaskInclude(block = data['block'], role = data['role'], task_include = data['task_include'])
    res = t.check_options(
        t.load_data(data, variable_manager = data['variable_manager'], loader = data['loader']),
        data
    )

    assert(res.action == data['action'])
    assert(res.attribute == data['attribute'])
    assert(res.val == data['val'])
    assert(res._valid_attrs == data['valid_attrs'])
    assert(res.block == data['block'])

# Generated at 2022-06-23 06:20:24.595755
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:20:35.605301
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    path_to_playbook = "/home/ansible/inventory/ansible/"
    host_a = Host("a", groups=["example"], port=22)
    host_b = Host("b", groups=["example"], port=22)

# Generated at 2022-06-23 06:20:45.561616
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.tags == []
    assert handler.name is None
    assert handler.action is None
    assert handler.args == []
    assert handler.rescue is None
    assert handler.always is None
    assert handler.notify == []
    assert handler.name is None
    assert handler.run_once is None
    assert handler.tasks is None
    assert handler.include_tasks is None
    assert handler.include_roles is None
    assert handler.include_vars is None
    assert handler.static is False
    assert handler.conditionals == []


# Generated at 2022-06-23 06:20:49.533651
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.__bases__[0].__name__ == 'Handler'
    assert HandlerTaskInclude.__bases__[1].__name__ == 'TaskInclude'
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {"listen"}

# Generated at 2022-06-23 06:20:50.895800
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:21:00.791136
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handlerTaskInclude1 = HandlerTaskInclude()
    handlerTaskInclude2 = HandlerTaskInclude()
    assert (handlerTaskInclude1 == handlerTaskInclude2)

    handlerTaskInclude3 = HandlerTaskInclude()
    assert (handlerTaskInclude1 == handlerTaskInclude3)

    handlerTaskInclude2.action_copy['copy'] = ('copy', 'copy')
    assert (handlerTaskInclude1 != handlerTaskInclude2)
    assert (handlerTaskInclude1 != handlerTaskInclude3)
    assert (handlerTaskInclude2 != handlerTaskInclude3)

    handlerTaskInclude1 = HandlerTaskInclude()
    handlerTaskInclude2 = HandlerTaskInclude()
    assert (handlerTaskInclude1 == handlerTaskInclude2)

# Generated at 2022-06-23 06:21:02.887371
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude.load(data=dict(include="some/file.yml", when="test.test == \"true\""), variable_manager=None, loader=None)

# Generated at 2022-06-23 06:21:03.379005
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:21:14.435944
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    t = Task()
    p = Play()
    v = VariableManager()

    # Case 1: Set the handler task include
    t.name = "Test handler task include"
    task_include = HandlerTaskInclude(block=None, role=None, task_include=None)
    task_include.load(dict(block=None, role=None, task_include=None, include='test'), block=None, role=None, task_include=None, variable_manager=v)
    assert task_include.include == 'test'
    assert task_include.block is None
    assert task_include.role is None

# Generated at 2022-06-23 06:21:25.487477
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # load_data is defined in TaskInclude which is inherited by HandlerTaskInclude
    # load_data will set attributes of a handler object

    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.vars.variable_manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    # initialize a Host object
    host = Host(name="test_host")

    # initialize a Block object
    block = Block()

    # initialize VariableManager object
    variable_manager = VariableManager()

    # initialize a DataLoader object
    loader = DataLoader()

    # set data so that the handler object can be created

# Generated at 2022-06-23 06:21:35.553030
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    task = Task()
    task._role = None

    data = {'include': 'some_name'}
    blk  = Block()

    host = Host(name='jumper')
    variable_manager = VariableManager()
    loader = ansible.playbook.role.role_loader.RoleLoader(
        play=None, variable_manager=variable_manager, loader=None)

    taskinclude = TaskInclude()
    handler      = HandlerTaskInclude(task_include=taskinclude)

    handler_taskinclude = HandlerTaskIn

# Generated at 2022-06-23 06:21:40.773746
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = [
        {'handlers': [{'name': 'foo', 'include': 'myhandlers.yml'}]},
        {'tasks': [{'notify': 'foo'}]},
        {'handlers': [{'name': 'foo', 'listen': 'bar'}]}
    ]
    for d in data:
        HandlerTaskInclude.load(d)


# Generated at 2022-06-23 06:21:42.779713
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h=HandlerTaskInclude()
    assert(h.__class__.__name__ == "HandlerTaskInclude")

# Generated at 2022-06-23 06:21:54.903569
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    result = HandlerTaskInclude.load(
        data={'include': 'handlers/main.yml'})
    assert result.filename == 'handlers/main.yml'

    result2 = HandlerTaskInclude.load(
        data={'include': 'handlers/main.yml'},
        task_include=TaskInclude.load(
            data={'include': 'handlers/main.yml'}))

    assert result2
    assert isinstance(result2, HandlerTaskInclude)


# Generated at 2022-06-23 06:22:01.640449
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = [
        {'include': 'listen'},
        {'include': 'listen'},
        {'include': 'listen'}
    ]

    #data = {'include': 'listen'}
    #import pdb; pdb.set_trac()
    handler = HandlerTaskInclude.load(data)

    assert 'listen' == handler.get_name()

# Generated at 2022-06-23 06:22:02.849975
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-23 06:22:12.319107
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    block = Block()
    host = Host()
    variable_manager = VariableManager()
    loader = DataLoader()
    handler = HandlerTaskInclude.load(
        dict(
            include='foo.yml',
            listen='bar'
        ),
        block=block,
        variable_manager=variable_manager,
        loader=loader
    )
    assert handler.handler_block == block
    assert handler.block == block
    assert handler.include_tasks_file == 'foo.yml'
    assert handler.listen == 'bar'
    assert handler.task_include is None

# Generated at 2022-06-23 06:22:16.224348
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test constructor of class HandlerTaskInclude
    handler = HandlerTaskInclude()
    assert handler

# Load test for class HandlerTaskInclude

# Generated at 2022-06-23 06:22:27.726598
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleError
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    def _new_TaskInclude(playbook):
        return TaskInclude(playbook)
    def _new_Block():
        return Block()
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    # AnsibleError
    try:
        handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
        assert False, 'AnsibleError has not been raised'
    except AnsibleError:
        pass
    # _new_TaskInclude returns

# Generated at 2022-06-23 06:22:28.787203
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   assert(HandlerTaskInclude)

# Generated at 2022-06-23 06:22:30.578894
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({'listen': 'test'})


# Generated at 2022-06-23 06:22:38.875460
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    testdata = dict()
    testdata['block'] = None
    testdata['role'] = None
    testdata['task_include'] = None
    h = HandlerTaskInclude(testdata['block'], testdata['role'], testdata['task_include'])
    assert h.block == None
    assert h.role == None
    assert h.task_include == None
    assert h.VALID_INCLUDE_KEYWORDS == set(('listen',))
    with pytest.raises(AssertionError) as excinfo:
        h.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert 'Argument handler is not a dictionary' in str(excinfo.value)

# Generated at 2022-06-23 06:22:42.506506
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t._block == None
    assert t._role == None
    assert t._task_include == None

# Generated at 2022-06-23 06:22:44.885734
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(None)


# Generated at 2022-06-23 06:22:45.953999
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: write test
    assert(False)

# Generated at 2022-06-23 06:22:47.898268
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert(handler != None)

# Generated at 2022-06-23 06:22:54.434703
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include_tasks = 'tasks/ansible-handler-tasks.yml'
    )
    task_include = HandlerTaskInclude.load(data=data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # In this test, we only check that the attribute include_tasks is set properly
    assert task_include.include_tasks == 'tasks/ansible-handler-tasks.yml'



# Generated at 2022-06-23 06:23:06.321046
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = None
    variable_manager = VariableManager()

    host = Host(name="testhost")
    host.set_variable('ansible_user', 'user')
    host.set_variable('ansible_ssh_pass', 'password')
    host

# Generated at 2022-06-23 06:23:15.543247
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("#" * 10, HandlerTaskInclude, "#" * 10)
    print("test_HandlerTaskInclude")

    """ load all available include files """
    handler_task_include = HandlerTaskInclude.load(
        {
            'include': 'all.yml'
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    print("-" * 10, HandlerTaskInclude, "-" * 10)


# Generated at 2022-06-23 06:23:16.197088
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-23 06:23:16.985125
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:22.444503
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        handlers=dict(
            main=dict(
                tasks=dict(
                    include=dict(
                        file="test.yml"
                    )
                )
            )
        )
    )
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = t.load(data)
    assert handler is not None
    assert handler is not None

# Generated at 2022-06-23 06:23:23.040917
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:23.942923
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:29.404678
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    ex_data = {
        'handlers': [
            'notify_handler',
        ],
        'tasks': [
            {
                'debug': {
                    'msg': 'Hello world!'
                }
            }
        ]
    }

    ti = HandlerTaskInclude.load(data=ex_data, variable_manager=None, loader=None)
    print(ti)

# Generated at 2022-06-23 06:23:38.792908
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.included_file import IncludedFile
    
    inventory = Inventory()
    host = Host(name="127.0.0.1")
    inventory.add_host(host)
    group = Group(name="test", hosts=[host], vars={})
    inventory.add_group(group)
    variable_manager = VariableManager(inventory)
    loader = DataLoader()
