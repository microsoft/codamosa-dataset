

# Generated at 2022-06-23 06:13:37.327927
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    hti = HandlerTaskInclude(Handler())
    hti = HandlerTaskInclude(Handler(), task_include=TaskInclude())

    class Test(object):

        def __init__(self, handler=None, task_include=None):
            hti = HandlerTaskInclude(handler, task_include)

    Test()

# Generated at 2022-06-23 06:13:48.140094
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # prepare the arguments
    data = {
        'include                ': 'test.yml',
        'listen                 ': 'testevent',
    }
    block                       = 'test-block'
    role                        = 'test-role'
    task_include                = 'test-task-include'
    variable_manager            = 'test-var-manager'
    loader                      = 'test-loader'

    # call the method to be tested
    objHandlerTaskInclude = HandlerTaskInclude()
    objActual = objHandlerTaskInclude.load(
        data,
        block,
        role,
        task_include,
        variable_manager,
        loader
    )

    assert objActual.block        == block
    assert objActual.role         == role
    assert objActual.task_include == task_include



# Generated at 2022-06-23 06:13:50.432940
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    H = HandlerTaskInclude()
    assert H is not None

# Generated at 2022-06-23 06:13:52.587398
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task = HandlerTaskInclude()
    assert task is not None

# Generated at 2022-06-23 06:14:00.169719
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()

    data = {
        'import_playbook': 'test_import_playbook',
        'listen': 'test_listen'
    }

    result = t.load(data=data)
    assert result.get_name() == 'test_import_playbook'
    assert result.get_handler() == True
    assert result.get_listen() == 'test_listen'
    assert result.get_tasks() == [{
        'import_playbook': 'test_import_playbook',
        'listen': 'test_listen'
    }]

# Generated at 2022-06-23 06:14:08.554592
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    #from ansible.playbook.block import Block
    #from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleAssertionError
    #from ansible.template import Templar

    # Creating fake Group and Host...
    fakeGroup = Group()
    fakeHost = Host()
    fakeGroup.get_hosts().append(fakeHost)
    loader = None
    variable_manager = VariableManager()
    variable_manager.set_inventory(fakeGroup)

    # Creating fake Task...
    fakeTask = Task()

# Generated at 2022-06-23 06:14:12.593886
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Instance of class HandlerTaskInclude
    test_instance = HandlerTaskInclude()
    assert test_instance is not None # object was created successfully
    # check that the object is instance of class HandlerTaskInclude
    assert isinstance(test_instance, HandlerTaskInclude)


# Generated at 2022-06-23 06:14:16.854967
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

HandlerTaskInclude.VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))

if __name__ == '__main__':
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:14:17.363938
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:14:19.520835
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    print(type(handlerTaskInclude))
    print(handlerTaskInclude)

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:14:29.068660
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    task = dict(action=dict(module='debug', args=dict(msg='foo')))

    handler = HandlerTaskInclude.load(task, variable_manager=variable_manager, loader=DataLoader())
    assert isinstance(handler, TaskInclude)
    assert isinstance(handler.tasks, list)
    assert len(handler.tasks) == 1

# Generated at 2022-06-23 06:14:31.135589
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Unit test
    assert True == False # TODO: write this unit test

# Generated at 2022-06-23 06:14:32.501507
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load is not None


# Generated at 2022-06-23 06:14:38.197413
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'main.yml',
        'listen': 'database'
    }

    result = HandlerTaskInclude.load(data)
    assert result.include == 'main.yml'
    assert result.listen == 'database'
    assert result.block is None
    assert result.role is None
    assert result.task_include is None

# Generated at 2022-06-23 06:14:40.303772
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Create a class instance of HandlerTaskInclude
    t = HandlerTaskInclude()

    # TODO

# Generated at 2022-06-23 06:14:41.523258
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Test this
    pass

# Generated at 2022-06-23 06:14:53.165576
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    # construct a block to be used by HandlerTaskInclude

# Generated at 2022-06-23 06:14:53.658504
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:14:57.654261
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include=dict()
    t=HandlerTaskInclude(role=None, block=None, task_include=task_include)
    print(t.task_include)
    assert t.task_include==task_include
    assert t.role==role
    assert t.block==block

# Generated at 2022-06-23 06:15:07.970335
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    This is a functional test for the class and its methods.
    '''
    play_context = dict(
        roles_path=[],
        task_path=None,
        variable_manager = None,
        loader = None,
    )
    block = dict(
        handlers=[],
    )
    role = None
    task_include = None
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    data = dict(
        include=dict(
            file='maint.yml',
            static=False,
            static_playbook=False,
            role=None,
        ),
    )
    # load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):

# Generated at 2022-06-23 06:15:08.984168
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-23 06:15:10.061862
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False



# Generated at 2022-06-23 06:15:11.864830
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(None, None, None)
    assert handler_task_include is not None

# Generated at 2022-06-23 06:15:19.199730
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    HOST_DEFINITIONS = ['localhost']

    inventory = InventoryManager(HOST_DEFINITIONS)
    variable_manager = VariableManager(inventory=inventory)

    b = Block(line_number=1, play=None)
    b.vars = variable_manager.get_vars(play=b._play, task=b)

    data = AnsibleMapping()

    t = TaskInclude()
    ti = TaskInclude.load(data)
    handler = HandlerTaskInclude.load(data, block=b, variable_manager=variable_manager)

# Generated at 2022-06-23 06:15:25.344852
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude(block='block', role='role', task_include='task_include')
    assert handlerTaskInclude.block == 'block'
    assert handlerTaskInclude.role == 'role'
    assert handlerTaskInclude.task_include == 'task_include'
    assert handlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'listen', 'vars', 'tasks', 'block', 'when', 'name', 'with_items'}


# Generated at 2022-06-23 06:15:33.597157
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.playbook.play_context as pc
    import ansible.playbook.task as t
    import ansible.template as tpl
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager

    def mock_play_context(**kwargs):
        ctx = pc.PlayContext()
        for key in kwargs:
            setattr(ctx, key, kwargs[key])
        return ctx

    def mock__load_list_of_tasks(self, attr, ds, task_name, role=None, use_handlers=False):
        handler = t.Task()

# Generated at 2022-06-23 06:15:45.560599
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block

    block = Block()
    role = None
    task_include = None
    variable_manager = None
    loader = None

    data = {
        u'name': u'Batch Account Management',
        u'tags': [u'Batch'],
        u'-include': u'include_test.yml',
        u'listen': u'batch_account_ready',
        u'vars': {
            u'tags': [u'Batch'],
            u'accountName': 'IncludeTest'
            }
        }

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert handler.name == u'batch_account_ready'
    assert handler.tags == [u'Batch']

# Generated at 2022-06-23 06:15:46.274841
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:52.582545
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name = 'test name',
        block = 'test block',
        role = 'test role',
        task_include = 'test task include',
        variable_manager = 'test variable manager',
        loader = 'test loader',
    )
    obj = HandlerTaskInclude(**data)
    obj.check_options('test load data', 'test data')
    obj.load(data)

# Generated at 2022-06-23 06:16:00.080238
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # load
    data = {
        'listen' : 'test_listen',
        'tags'   : ['test_tags'],
        'tasks'  : {
            'task_0' : {
                'name' : 'test_task_0'
            },
            'task_1' : {
                'name' : 'test_task_1'
            }
        }
    }
    tmp_HandlerTaskInclude = HandlerTaskInclude()
    handler = tmp_HandlerTaskInclude.load(data)
    assert handler.listen == ['test_listen']
    assert handler.tags == ['test_tags']
    assert handler.tasks[0].name == 'test_task_0'
    assert handler.tasks[1].name == 'test_task_1'


# Generated at 2022-06-23 06:16:06.713962
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'listen','name','with_items','with_nested','with_first_found','include','static','ignore_errors','when','only_if','tags','run_once','delegate_to','notify','first_available_file','loop_control','poll'}

# Generated at 2022-06-23 06:16:08.616627
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)


# Generated at 2022-06-23 06:16:16.884007
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        name='test',
        hosts=['localhost'],
        tasks=[{'name':'test', 'action':{'module':'shell', 'args':'echo Hello'}}]
    )
    h = HandlerTaskInclude(role='admin', task_include=None)
    assert h != None


# Generated at 2022-06-23 06:16:18.190634
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("Testing HandlerTaskInclude")
    HandlerTaskInclude()

# Generated at 2022-06-23 06:16:24.865887
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_data():
        return {
            'hosts': '{{ foo }}',
            'tasks': [
                {
                    'name': 'debug',
                    'debug': 'msg="{{ foo }} is defined"'
                }
            ]
        }

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    loader = DataLoader()
    inventory = {'foo': 'bar'}
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 06:16:36.046011
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Unit test for method load of class HandlerTaskInclude
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv_obj = Inventory()
    inv_obj.groups = [
        Group("all")
    ]
    inv_obj.hosts = [
        Host("localhost")
    ]
    vm = VariableManager()
    loader = DataLoader()

    data = {
        "name": "listen",
        "block": "test_block_1",
        "listen": "test_listen",
    }


# Generated at 2022-06-23 06:16:39.946851
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data_dict = {
        'block': None,
        'include': 'dummy_playbook.yml',
        'role': None,
        'task_include': None
    }
    HandlerTaskInclude.load(data=data_dict)


# Generated at 2022-06-23 06:16:45.514655
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('\nTest: Loading HandlerTaskInclude')
    data = {'import_playbook': 'other.yml'}
    t = HandlerTaskInclude.load(data, loader=None)
    assert t.include_tasks is not None

# Generated at 2022-06-23 06:16:54.806329
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    loader = DataLoader()
    host = Host(name="TestHost")
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    task_include = HandlerTaskInclude(block=play, role=None, task_include=None)

    # Additional TaskInclude initialisation
    task_include._role

# Generated at 2022-06-23 06:16:59.426213
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'foo.yml',
    }
    vars = [
        'foo.yml',
        'bar.yml',
    ]
    expected = [
        'foo.yml',
        'bar.yml',
    ]
    assert HandlerTaskInclude.load(data, variable_manager = vars) == expected

# Generated at 2022-06-23 06:17:01.468202
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    p = HandlerTaskInclude(None)


# Generated at 2022-06-23 06:17:08.023940
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
#     # Tests for the include kwargs
#     for kwarg in TaskInclude.VALID_INCLUDE_KEYWORDS:
#         result = HandlerTaskInclude.load({kwarg: dict()}, variable_manager=Mock())
#         assert result
#
#     # Tests for the handler kwargs
#     for kwarg in Handler.VALID_HANDLER_KEYWORDS:
#         result = HandlerTaskInclude.load({kwarg: dict()}, variable_manager=Mock())
#         assert result
#
#     # Assert the load method raises an exception for invalid kwargs
#     with pytest.raises(AnsibleError) as execinfo:
#         HandlerTaskInclude.load({'foo': dict()}, variable_manager=Mock())
#     assert 'valid keyword

# Generated at 2022-06-23 06:17:10.667428
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert isinstance(t, Handler)
    assert isinstance(t.VALID_INCLUDE_KEYWORDS, set)


# Generated at 2022-06-23 06:17:11.067881
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:13.072427
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t.VALID_INCLUDE_KEYWORDS == set(['first_available_file', 'listen', 'static'])

# Generated at 2022-06-23 06:17:16.331514
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert t is not None
    assert isinstance(t, HandlerTaskInclude)
    assert isinstance(t, Handler)

# Generated at 2022-06-23 06:17:23.120261
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    
    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='/usr/bin/uptime'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=play_context.variable_manager, loader=play_context.loader)

    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Generated at 2022-06-23 06:17:27.431761
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    args = {}
    args.update({'playbook_dir': 'playbook_dir'})
    args.update({'variable_manager': 'variable_manager'})
    args.update({'loader': 'loader'})
    args.update({'tasks': ['tasks']})
    handler = HandlerTaskInclude.load(args)
    assert handler

# Generated at 2022-06-23 06:17:37.926082
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    host = Host(name="MYHOST")
    parent = Group(name="MYGROUP")
    parent.add_host(host)

    loader = DataLoader()
    group = InventoryParser(loader=loader, groups=[parent])
    variable_manager = VariableManager()

    data = "test.yml"
    block = None
    role = None
    task_include = None
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, \
        variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 06:17:49.481718
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Test the load method of class HandlerTaskInclude
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.base import Base

    # Load data into DirectiveTaskInclude
    base = HandlerTaskInclude.load({
        'name': 'test handler',
        'listen': 'foo'
    }, Base())

    assert (base.get_name() == 'test handler')
    assert (base.get_listen() == 'foo')

    # Load data into DirectiveTaskInclude
    block = HandlerTaskInclude.load({
        'name': 'test handler',
        'listen': 'foo'
    }, Block.load({
        'name': 'Test block'
    }))

    assert (block.get_name() == 'test handler')

# Generated at 2022-06-23 06:17:51.470193
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load('name', block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert handler.name == 'name'

# Generated at 2022-06-23 06:17:52.359733
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-23 06:17:53.405258
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-23 06:17:57.094067
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test the constructor
    t = HandlerTaskInclude()
    assert t is not None
    assert t.action == 'meta'
    assert t.block is None
    assert t.role is None
    assert t.task_include is None
    assert t.dynamic_include is False
    assert t.static_include is False

# Generated at 2022-06-23 06:18:07.549510
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''Unit test for constructor of class HandlerTaskInclude'''
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(('delegate_to', 'freeze_variables', 'loop', 'loop_control', 'name', 'paused', 'register', 'tags', 'until', 'when', 'with_first_found', 'with_items', 'with_nested', 'with_random_choice', 'with_subelements', 'with_together', 'with_fileglob', 'with_sequence', 'with_loop', 'with_inventory_hostnames', 'with_dict', 'listen'))

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:18:14.130385
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include='local_handler.yml',
        listen='restart httpd'
    )
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = t.check_options(
        t.load_data(data),
        data
    )
    assert handler.static is False
    assert handler.listen is not None


# Generated at 2022-06-23 06:18:24.224224
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# class HandlerTaskInclude(HandlerTaskInclude):
#     """
#     Class for a handler task include.
#     """
#     def __init__(self, block=None, role=None, task_include=None, **kwargs):
#         super(HandlerTaskInclude, self).__init__(**kwargs)
#         self._block        = block
#         self._role         = role
#         self._task_include = task_include
#
#         if task_include is not None:
#             self._from_files = task_include._from_files
#
#     def _load_attr(self, ds):
#         result = super(HandlerTaskInclude, self)._load_attr(ds)
#         result._block        = self._block
#         result._role         = self

# Generated at 2022-06-23 06:18:28.347026
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)

test_HandlerTaskInclude()



# Generated at 2022-06-23 06:18:39.949368
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError

    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role

    host = Host('test')
    hostvars = HostVars(host, variables=dict())

    variable_manager = VariableManager()
    variable_manager.set_inventory(hostvars)
    loader = DataLoader()

    block = Block()

    role_include = RoleInclude()


# Generated at 2022-06-23 06:18:48.494601
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    import ansible.constants as C
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    fake_loader = DictDataLoader({
        "delegate-to-host1.yml": "",
        "handler-host1.yml": "",
    })

    def get_hosts(pattern):
        if pattern == 'all':
            return hosts
        elif pattern in ('host1', 'host2'):
            h = Host(pattern)
            h.set_variable('ansible_connection', 'local')

# Generated at 2022-06-23 06:18:56.070660
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler is not None
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.tasks is None
    assert handler.name is None
    assert handler.tags == set()
    assert handler.listen is None

# Generated at 2022-06-23 06:18:57.427695
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-23 06:18:58.400471
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()



# Generated at 2022-06-23 06:19:06.150239
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    from ansible.utils.vars import combine_vars
    import os
    import copy

    context.CLIARGS = {'module_path': os.path.join(os.path.dirname(__file__),
                                                   'modules')}


# Generated at 2022-06-23 06:19:15.649075
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    my_class = HandlerTaskInclude()
    # TODO: add plugin path to config
    my_data = None
    result = my_class.load(my_data)
    assert result == None

    my_data = {
        'include': 'http://example.com/file.yml',
        'vars': {'var': 'value'}
    }
    result = my_class.load(my_data)
    assert result == None

    my_data = {
        'include': 'file.yml',
        'vars': {'var': 'value'}
    }
    result = my_class.load(my_data)
    assert result == None

# Generated at 2022-06-23 06:19:17.181173
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: implement
    pass


# Generated at 2022-06-23 06:19:26.704289
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # test load method of class HandlerTaskInclude
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.variables import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VarsModule
    import sys
    import os

    data = {
        'action': {
            'module': 'apt',
            'name': 'upgrade'
        },
        'handlers': {
            'name': [
                {
                    'action': {
                        'module': 'apt',
                        'name': 'upgrade'
                    }
                }
            ]
        }
    }

    example_host = Host(name="example.com")

# Generated at 2022-06-23 06:19:38.444816
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    data = {'name': 'foo', 'listen': 'bar'}
    handler = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)

    assert handler != None, "handler should not be None"
    assert handler.data != None, "handler.data should not be None"
    assert handler.data.get('name', None) == 'foo', "handler.data['name'] should be 'foo'"
    assert handler.data.get('listen', None) == 'bar', "handler.data['listen'] should be 'bar'"



# Generated at 2022-06-23 06:19:39.127803
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:49.891532
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    class MockHost(object):
        def __init__(self, my_vars=None):
            self._vars = my_vars

        def get_vars(self):
            return self._vars
    my_variable_manager = dict()
    my_loader = dict()
    # First test
    data = dict()
    assert HandlerTaskInclude.load(data, variable_manager=my_variable_manager, loader=my_loader) is None
    assert HandlerTaskInclude.load(data, variable_manager=None, loader=None) is None
    # Second test
    data = dict()
    data['hosts'] = 'all'
    assert HandlerTaskInclude.load(data, variable_manager=my_variable_manager, loader=my_loader) is not None

# Generated at 2022-06-23 06:19:56.611422
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = dict(
        name=None,
        args=None,
        when=None,
        listen=None,
        include=None
    )

    block=None
    role=None
    task_include=None
    variable_manager=None
    loader=None

    hti = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    assert hti

    handler = hti.check_options(
        hti.load_data(data, variable_manager=variable_manager, loader=loader),
        data
    )

    assert handler

    assert handler.name == None

    assert handler.tags == []
    assert handler.when == None
    assert handler.listen == None
    assert handler.notify == []
    assert handler.handler_block.block == None

# Generated at 2022-06-23 06:20:03.370982
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = Handler.load(dict(
        name="handler",
        tags=["tag1", "tag2"],
        include="file1",
        include_hosts="hosts",
        include_tasks="tasks",
        include_vars="vars",
        include_role="role",
        include_task="task",
        listen="name"
    ))

# Generated at 2022-06-23 06:20:04.309953
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 1 == 1

# Generated at 2022-06-23 06:20:06.638161
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

    assert handler_task_include is not None

# Generated at 2022-06-23 06:20:16.079798
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.ini import InventoryParser
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import DataLoader


# Generated at 2022-06-23 06:20:17.186738
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "Test not implemented"

# Generated at 2022-06-23 06:20:18.100446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:20:18.842007
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:20:20.024182
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    a = HandlerTaskInclude
    assert a.load is not None

# Generated at 2022-06-23 06:20:23.750951
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert handler.listen == None

# Generated at 2022-06-23 06:20:35.009775
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    obj_HandlerTaskInclude = HandlerTaskInclude()

    obj_VariableManager = VariableManager()
    obj_DataLoader = DataLoader()

    data = {
        'name': 'a',
        'hosts': 'host1',
        'tasks': [
            {'action': {'module': 'ping'}},
        ]
    }

    obj_VariableManager._fact_cache = {
        'host1': {
            'ansible_all_ipv4_addresses': [
                '192.168.1.2'
            ]
        }
    }

   

# Generated at 2022-06-23 06:20:39.481422
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create an object to test
    object_HandlerTaskInclude = HandlerTaskInclude()
    # Test the type of the object
    # Should be class 'ansible.playbook.handler.HandlerTaskInclude'
    assert(type(object_HandlerTaskInclude) == HandlerTaskInclude)

# Generated at 2022-06-23 06:20:40.517606
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create necessary objects
    handler = HandlerTaskInclude()

# Generated at 2022-06-23 06:20:41.568573
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	test_HandlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-23 06:20:45.773544
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude(loader=None, variable_manager=None, loader_basedir=".", role=None, task_include=None, block=None)
    assert h._loader is None
    assert h._variable_manager is None
    assert h._loader_basedir == '.'
    assert h._role is None
    assert h._task is None
    assert h._block is None

# Generated at 2022-06-23 06:20:57.676988
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    file_loader = DataLoader()
    inventory = InventoryManager(loader=file_loader, sources=["./tests/inventory/dynamic_inventory.py"])

    # We use an empty playbook structure to test the handler load function
    structure = {'hosts': 'all'}

    # Host object only needed for empty role object
    host = inventory.get_host(name="test2")
    role = Role(name="some_role", data=structure, _hosts=host)

    # Add all hosts from the inventory to the variable manager to allow all
    # hosts to be run, since the test inventory has a host

# Generated at 2022-06-23 06:20:59.545136
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.VALID_INCLUDE_KEYWORDS == set(['tags', 'listen'])

# Generated at 2022-06-23 06:21:00.352385
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:21:02.000682
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	h = HandlerTaskInclude()
	assert h.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:21:09.979815
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible import color
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.persistent_lookup_plugin import PersistentIncludeLookupPlugin
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.playbook.play import Play
    import pdb


    def get_hosts_dict(host_list=None):
        ret = {}

# Generated at 2022-06-23 06:21:10.702126
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:21:20.061998
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'listen': 'web_servers'}
    block=None
    role=None
    task_include=None
    variable_manager=None
    loader=None

    handler_task_include=HandlerTaskInclude.load(data, block=block, role=role, 
    task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert handler_task_include.__class__ == HandlerTaskInclude

    # TODO(mnelson): add test for this error case
    # data = {'foo': 'bar'}
    # handler_task_include=HandlerTaskInclude.load(data, block=block, role=role, 
    # task_include=task_include, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:21:30.955921
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from units.mock.inventory import create_inventory
    from units.mock.vars_plugin import VarModule

    p = PlayContext()
    c = create_inventory('localhost')
    loader = DictDataLoader({
        "test.yml": '''
        - hosts: localhost
          tasks:
            - debug:
                msg: hello
                when: true
                '''
    })
    handler_vars = {"test": "var"}


# Generated at 2022-06-23 06:21:33.018442
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block="Testing", role="Testing", task_include="Testing")
    assert isinstance(handler, HandlerTaskInclude)


# Generated at 2022-06-23 06:21:36.444179
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler._block == None
    assert handler._role == None
    assert handler._task_include == None

# Generated at 2022-06-23 06:21:46.239509
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Play
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

    # play = Play().load(dict(
    #     name = "Ansible Play",
    #     hosts = 'localhost',
    #     gather_facts = 'no',
    #     tasks = [
    #         dict(action=dict(module='setup'), register='shell_out'),
    #         dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
   

# Generated at 2022-06-23 06:21:54.055014
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Check for empty args
    handler = HandlerTaskInclude()
    assert handler

    # Check for block and role
    handler = HandlerTaskInclude(block=None, role=None)
    assert handler

    # Check for task
    handler = HandlerTaskInclude(task_include=None)
    assert handler

    # Check for valid args
    handler = HandlerTaskInclude(block=1, role=1, task_include=1)
    assert handler

# Generated at 2022-06-23 06:22:02.236143
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.block import Block

    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.task import Task

    from ansible.vars import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import add_all_plugin_dirs

    from ansible.utils.vars import load_extra_vars

    from ansible.utils.vars import load_options_vars

    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars.manager import VariableManager

    from ansible.module_utils.six import iteritems

    add_all_plugin

# Generated at 2022-06-23 06:22:12.098211
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host       import Host
    from ansible.playbook.block       import Block
    from ansible.playbook.task        import Task
    from ansible.playbook.role        import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.template             import Templar

    host = Host(name='127.0.0.1', port=22)
    host.set_variable('ansible_ssh_pass', 'pass')

    base_vars = host.get_vars()

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(hosts=[host]))
    loader = DataLoader()
    variable_manager.set_loader(loader)

# Generated at 2022-06-23 06:22:21.698802
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=[])
    host = Host(name="localhost")
    inventory.add_host(host=host)

    options = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()

    handler = HandlerTaskInclude.load(data={'include': 'foo'}, block=None, role=None, task_include=None, loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-23 06:22:24.725998
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_object = HandlerTaskInclude()
    test_object.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:22:31.457520
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: construct the data required to load a HandlerTaskInclude object.
    data = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(
        data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader,
    )

    # TODO: test the handler object.

# Generated at 2022-06-23 06:22:39.809711
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager  = VariableManager()
    loader            = variable_manager.get_vars_loader()
    inventory         = InventoryManager(loader=loader, sources='localhost,')

    block = Block()
    role  = Role()
    host  = Host(name='localhost')

    data = {}

    handler = HandlerTaskInclude.load(
                                 data=data,
                                 block=block,
                                 role=role,
                                 task_include=None,
                                 variable_manager=variable_manager,
                                 loader=loader
                             )


# Generated at 2022-06-23 06:22:45.510553
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    taskInclude_obj = create_taskInclude_object()
    variable_manager_obj = variable_manager_create()
    loader_obj = data_loader_create()

    handler_obj = HandlerTaskInclude.load(data = taskInclude_obj, variable_manager = variable_manager_obj, loader = loader_obj)
    assert handler_obj.tasks == taskInclude_obj['tasks']


# Generated at 2022-06-23 06:22:49.919458
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    hti.check_options = lambda x: x
    hti.load_data = lambda x: x

    # data is a dict
    data = {'a': 'b'}
    assert hti.load(data) == data


# Generated at 2022-06-23 06:22:53.423673
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:06.100328
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test all parameters
    handler = HandlerTaskInclude.load({
        'include_tasks': 'file.yml',
        'listen': 'my_handler'
    })

    assert handler._datastore == {
        'include_tasks':  'file.yml',
        'listen': 'my_handler'
    }

    # Test all parameters
    handler = HandlerTaskInclude.load({
        'include_tasks': 'file.yml',
        'listen': 'my_handler'
    }, None, None, None, None, None)

    assert handler._datastore == {
        'include_tasks':  'file.yml',
        'listen': 'my_handler'
    }

    # Test missing 'include_tasks'

# Generated at 2022-06-23 06:23:12.493298
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    kwargs = {
        '_role': None,
        '_block': None,
        '_task_include': None,
    }

    ht = HandlerTaskInclude(**kwargs)
    assert ht is not None

    assert kwargs['_role'] == ht._role
    assert kwargs['_block'] == ht._block
    assert kwargs['_task_include'] == ht._task_include
    assert ht.VALID_INCLUDE_KEYWORDS == ht.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-23 06:23:13.116888
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:14.133739
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.__class__.__name__ == "HandlerTaskInclude"

# Generated at 2022-06-23 06:23:23.684492
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test with a valid include task file
    # data = {
    #     'include': 'tasks/main',
    #     'static': '/etc/foo.builder'
    # }
    # assert HandlerTaskInclude.load(data) is not None
    # Test with an invalid include task file
    data = {
        'include': 'tasks/main',
        # 'static': 'tasks/temporary'
    }
    with pytest.raises(AnsibleParserError):
        handler = HandlerTaskInclude.load(data)


# class HandlerWrapper(object):
#
#     def __init__(self, host, handler):
#         self._block = host
#         self._handler = handler
#         self.name = handler.name
#
#     def evaluate_conditional(self, all_

# Generated at 2022-06-23 06:23:27.460363
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data=dict(
        include=dict(
            name='include-playbook'
        )
    ))
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-23 06:23:31.173922
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("********** Unit test for constructor of class HandlerTaskInclude **********")
    # TODO: implement unit test
    print("\n")


# Generated at 2022-06-23 06:23:33.631716
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert isinstance(handler_task_include, HandlerTaskInclude)