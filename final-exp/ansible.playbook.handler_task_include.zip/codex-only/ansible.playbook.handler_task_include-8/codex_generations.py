

# Generated at 2022-06-23 06:13:36.006738
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_HandlerTaskInclude = HandlerTaskInclude()
    assert my_HandlerTaskInclude.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:13:46.459348
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(['delegate_to', 'freeze_variables', 'loop', 'loop_control', 'name', 'run_once', 'tags', 'until', 'vars', 'when', 'with_first_found', 'with_nested', 'with_sequence', 'with_together', 'with_dict', 'with_items', 'with_fileglob', 'with_lookup', 'with_random_choice', 'with_subelements', 'with_together', 'listen'])

    t = HandlerTaskInclude()

# Generated at 2022-06-23 06:13:49.761680
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handlerTaskInclude.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))

# Generated at 2022-06-23 06:13:57.757077
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block

    data = {
        "include_tasks": "foo.yml",
    }

    block = Block.load(
        data=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    handler = HandlerTaskInclude.load(
        data=data,
        block=block,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    assert handler._includename == "foo.yml"

# Generated at 2022-06-23 06:14:08.134033
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import task_include
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    valid_data = {'include': 'hello'}
    data = valid_data
    block = Block()
    block._parent = Role()
    task_include = task_include.TaskInclude()
    task_include.load(data)
    try:
        handler_task_include = HandlerTaskInclude.load(data, block=block, task_include=task_include)
    except SystemExit:
        handler_task_include = None
    assert type(handler_task_include) is task_include.TaskInclude
    block._parent = Task()

# Generated at 2022-06-23 06:14:11.451229
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler.get_blocks() == []


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:14:20.660919
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.playbook.block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = [Host(name='inventory_hostname')]
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
   

# Generated at 2022-06-23 06:14:23.297078
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = 'cmd'
    load_result = HandlerTaskInclude.load(data)

    assert load_result.action == data


# Generated at 2022-06-23 06:14:28.186050
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'foo'
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = None
    try:
        handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    except:
        pass
    assert(handler)

# Generated at 2022-06-23 06:14:40.353872
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_data = dict(
        name='Test Handler',
        tasks=['foo.yml', 'bar.yml'],
        tags=['always', 'test'],
        when=None
    )
    handler_task = HandlerTaskInclude.load(handler_data)
    assert isinstance(handler_task, Handler)
    # assert isinstance(handler_task, HandlerTaskInclude)
    assert isinstance(handler_task, TaskInclude)

    # Check __init__
    assert handler_task.block is None
    assert handler_task.role is None
    handler_task = HandlerTaskInclude.load(handler_data, block='task', role='role')
    assert handler_task.block == 'task'
    assert handler_task.role == 'role'

    # Check load

# Generated at 2022-06-23 06:14:51.421189
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test for constructor of class HandlerTaskInclude
    data_test = {"name": "apache", "listen": "firewall"}
    data_test1 = {"name": "apache", "listen": "firewall", "tags": ["apache-handler-test"]}
    a = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = a.check_options(a.load_data(data_test, variable_manager=None, loader=None), data_test)
    assert handler.name == "apache"
    handler = a.check_options(a.load_data(data_test1, variable_manager=None, loader=None), data_test1)
    assert handler.name == "apache"

# Generated at 2022-06-23 06:14:52.961182
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:14:57.377289
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        static='all',
        system='unix'
    )
    variable_manager = None
    loader = None
    d = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert d.get_name() == 'include'

# Generated at 2022-06-23 06:14:58.308597
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	pass


# Generated at 2022-06-23 06:15:08.609694
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #Utility for creating a mock
    def dummy_method(obj,*args,**kwargs):
        return True
    
    #Create mocks
    load_data_mock = dummy_method
    check_options_mock = dummy_method

    #Replace method load_data and check_options of the object HandlerTaskInclude with the mocks
    HandlerTaskInclude.load_data = load_data_mock
    HandlerTaskInclude.check_options = check_options_mock

    #Create a instance of HandlerTaskInclude for testing
    handlerTaskInclude = HandlerTaskInclude()

    #Call method load of the instance handlerTaskInclude with mock data
    handlerTaskInclude.load("data",role="role",variable_manager="variable_manager",loader="loader")

    #Assert that methods load_data and check_

# Generated at 2022-06-23 06:15:12.759933
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude()
    test_data = dict(name='Test Handler', listen='test_signal_name', include='tasks/test_handler.yml')
    handler_load = HandlerTaskInclude.load(test_data)
    assert type(handler_load) == HandlerTaskInclude

# Generated at 2022-06-23 06:15:13.350012
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:23.879628
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': "test_path",
        'static': "test_static",
        'name': "test_name",
    }
    t = HandlerTaskInclude.load(data=data)
    assert t.include == "test_path"
    assert t.static == "test_static"
    assert t.name == "test_name"
    assert t.listen == None
    assert t.tags == []
    assert t.when == []
    assert t.delegate_to == None
    assert t.exclude_hosts == []
    assert t.run_once == False
    assert t.loop == []
    assert t.notify == []
    assert t.handlers == []


# Testing load method

# Generated at 2022-06-23 06:15:33.363345
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print()
    print("test_HandlerTaskInclude_load")
    # validates Handler.load, HandlerTaskInclude.load, and Handler._load_tasks
    # this is tested against the _load_tasks_from_role_task_list() in Ansible/playbook/block.py
    # only specifically for this module.
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    # from ansible.inventory.host import Host
    # from ansible.inventory.group import Group


# Generated at 2022-06-23 06:15:43.989820
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = None
    variable_manager.get_vars = lambda host=None: {"hostvars": None}
    variable_manager.get_host_vars.return_value = None
    variable_manager.get_host_vars = lambda host=None: {"hostvars": None}
    variable_manager.get_group_vars.return_value = None
    variable_manager.get_group_vars = lambda group=None: {"groupvars": None}
    variable_manager.get_group_vars = lambda group=None: {"groupvars": None}
    variable_manager.extra_vars.return_value = None
    variable_manager.extra_vars = {"globalvars": None}

    loader = MagicM

# Generated at 2022-06-23 06:15:44.637701
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:55.613143
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    host = Host()
    group = Group()
    group.add_host(host)
    variable_manager.set_inventory(Group())
    variable_manager.set_inventory(host)
    variable_manager.set_inventory(group)
    play_context = PlayContext()
    task_list = [{'test_data': 'test'}]
    task_list1 = [{'test_data_1': 'test1'}]
    play_context.loader = loader


# Generated at 2022-06-23 06:16:06.533639
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory import Host
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler


# Generated at 2022-06-23 06:16:09.859355
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
   task_include = HandlerTaskInclude()
   print(task_include)
   return

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:16:24.443387
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    h = Host(name="host1")
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    # print(t.__dict__)
    assert t._role is None
    assert t._parent is None
    assert t._dep_chain is None
    assert t._loop is None
    assert t._always_run is False
    assert t._loop_control is None
    assert t._any_errors_fatal is False
    assert t._block is None
    assert t._ignore_errors is False
    assert t._tags is None
    assert t._when is None
    assert t._changed_when is None
    assert t._failed_when is None
    assert t._is_handler is True
    assert t._action is None

    assert t._

# Generated at 2022-06-23 06:16:30.084393
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti.VALID_INCLUDE_KEYWORDS == ({'block', 'block:children', 'block-discard', 'block-task', 'free-form', 'import_playbook', 'meta', 'playbook', 'role', 'tasks', 'tasks:children'})

# Generated at 2022-06-23 06:16:42.225968
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    import pytest
    import yaml
    #from ansible.inventory.host import Host

    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-23 06:16:53.480884
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    play_context = PlayContext()
    play_context._set_task_and_variable_override("foo", dict(x=1, y=2))

    loader = "loader"
    play = Play()
    play.connection = "local"
    play.hosts = "127.0.0.1"
    play.remote_user = "guest"
    play.port = 5555
    play.become = False
    play.become

# Generated at 2022-06-23 06:16:56.381474
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    res = HandlerTaskInclude.load(data=data)
    assert res.task_include.filename is None

# Generated at 2022-06-23 06:17:05.971302
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Test using an invalid keyword
    data = {
        "foo": "include_tasks",
        "private": "./private_tasks.yml"
    }
    t = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert t.get_name() == 'include'
    assert t.args == {}

    # Test using a valid keyword
    data = {
        "name": "include_tasks",
        "private": "./private_tasks.yml"
    }
    t = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert t.get_name() == 'include_tasks'

# Generated at 2022-06-23 06:17:16.971097
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    block = None
    role = None
    task_include = None
    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    assert handler != None
    assert handler._attributes == None
    assert handler._name == None
    assert handler._task_include == task_include
    assert handler._role == None
    assert handler._block == block
    assert handler._role == role
    assert handler._task_include == task_include
    assert handler._valid_attrs == TaskInclude.VALID_HANDLER_ATTRIBUTES.union(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS)
    assert handler._included_files == []
    assert handler._loader == None
    assert handler._role_path == None
    assert handler._variable_

# Generated at 2022-06-23 06:17:20.290815
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Handlertaskinclude=HandlerTaskInclude()
    assert Handlertaskinclude is not None


# Generated at 2022-06-23 06:17:20.926389
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:17:28.831748
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    args = dict(
        block=None,
        role=None,
        task_include=None,
        data={'name': 'some_name', 'listen': 'test_handler'},
    )

    h = HandlerTaskInclude.load(**args)
    expected = dict(
        name='some_name',
        module_name='debug',
        args=None,
        listen=['test_handler'],
        tasks=[],
        handlers=[],
        vars=dict(),
        role=None,
        block=None,
        task_include=None,
    )
    assert not h.task_include and h.handlers and h == expected

# Generated at 2022-06-23 06:17:30.629837
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude(block={}, role={}, task_include=None)


# Generated at 2022-06-23 06:17:31.994018
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False, "Not implemented"


# Generated at 2022-06-23 06:17:40.897694
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  print('### Test method load of class HandlerTaskInclude ###')
  print()
  
  # load_data method cannot be tested because it is a method of TaskInclude class and 
  # it uses the following methods of class Namespace which cannot be instantiated by themselves:
  #     * select_attr
  #     * select_attr_pattern
  #     * sequence_get
  #     * sequence_splice
  #     * sequence_slice
  #     * count_of
  #     * getattr
  # These methods are called in the body of method load_data by using the self instance of TaskInclude class
  # For example, when the call self.namespace.sequence_splice is executed
  #     self instance is an instance of class HandlerTaskInclude, then
  #     self.namespace is an instance of class Namespace


# Generated at 2022-06-23 06:17:41.753912
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:17:42.846701
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:17:52.060205
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import yaml
    import os
    import sys


# Generated at 2022-06-23 06:17:54.027862
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    return handler

# Generated at 2022-06-23 06:17:55.872733
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO
    return

# Generated at 2022-06-23 06:18:07.785436
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # create an empty object to store the var_manager
    class DummyVariableManager:
        pass
    variable_manager = DummyVariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.vars_cache = {}
    variable_manager.inventory = None
    variable_manager.loader = None

    # create an empty object to store the loader
    class DummyLoader:
        pass
    loader = DummyLoader()
    loader.path_dwim = None

    # create the test data
    class DummyRole:
        pass
    role = DummyRole()

# Generated at 2022-06-23 06:18:18.611074
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar
    import os
    import pytest

    current_directory = os.path.dirname(__file__)
    test_file = os.path.join(current_directory, 'test_data', 'test_role',
                             'test_task_include.yml')
    assert os.path.isfile(test_file) is True

    host = 'localhost'
    port = 6379
    socket_path = '/tmp/redis.sock'
    selector_type = 'listen'
    register = 'redis_service'
    action_plugin = 'service'
    name = 'redis'
    ignore_errors = True
   

# Generated at 2022-06-23 06:18:23.101535
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({}) == None
    assert HandlerTaskInclude.load({}, None, None) == None
    assert HandlerTaskInclude.load(None) == None
    assert HandlerTaskInclude.load(None, None, None) == None

# Generated at 2022-06-23 06:18:25.056713
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:18:37.484560
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Inventory data
    inventory_data = """
    [all:vars]
    host_var = host_var
    group_var = group_var
    ouside_var = ouside_var
    """

    # Playbook data

# Generated at 2022-06-23 06:18:45.737849
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    print('Executing tests for class HandlerTaskInclude: load method')

    handler = Handler.load({
        'name': 'test_handler',
        'listen': 'test_handler',
        'local_action': {
            'module': 'test',
            'args': 'test'
        }
    })

    assert handler.notified_by

    print('Test succeded')

if __name__ == '__main__':
    import sys
    import pytest
    from io import StringIO
    from unittest.mock import patch

    print('Testing class HandlerTaskInclude')
    sys.exit(pytest.main(['-x', '--capture=no', __file__]))
    # test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:18:47.615809
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=object(), role=object(), task_include=object())
    assert t is not None
    print("Test passed")

# Generated at 2022-06-23 06:18:54.963273
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == ({'tasks', 'handlers', 'pre_tasks', 'post_tasks', 'tags', 'when', 'name', 'vars', 'register', 'environment', 'include_role', 'include_tasks', 'listen', 'run_once'})

    assert HandlerTaskInclude.load({'listen': 'httpd_restarted'}) is not None

# Generated at 2022-06-23 06:19:02.365900
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include' : 'included_file.yml',
    }
    variable_manager = None
    loader = None
    block = None
    role = None
    task_include = None
    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    handler = t.check_options(
        t.load_data(data, variable_manager=variable_manager, loader=loader),
        data
    )
    
    assert handler.block_type == 'rescue'
    assert handler.static is False
    assert isinstance(handler.tasks, list)

# Generated at 2022-06-23 06:19:12.599569
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Host = collections.namedtuple('Host', 'name')

    t = HandlerTaskInclude()

    # Class constructor should set _parent, _role and _block
    assert t._parent == None
    assert t._role == None
    assert t._block == None

    # When role is not provided, _role should be None
    assert t.role == None
    t.role = 'role1'
    assert t.role == 'role1'
    t.role = None
    assert t.role == None

    # When block is not provided, _block should be None
    assert t.block == None
    t.block = 'block1'
    assert t.block == 'block1'
    t.block = None
    assert t.block == None
    
    # _loader is None before calling load()
    assert t._loader == None

# Generated at 2022-06-23 06:19:24.094183
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # data1={"block": object, "role": Role(),"task_include": TaskInclude(),"variable_manager": VariableManager(),"loader": DataLoader()}
    # data2={"variable_manager": VariableManager(),"loader": DataLoader()}
    data1={"block": object}
    data2={"variable_manager": object}

    # constructor1 = HandlerTaskInclude(block=data1["block"], role=data1["role"], task_include=data1["task_include"])
    # constructor2 = HandlerTaskInclude.load(data=data2, block=data1["block"], role=data1["role"], task_include=data1["task_include"], variable_manager=data1["variable_manager"], loader=data1["loader"])

    constructor1 = HandlerTaskInclude(block=data1["block"])

# Generated at 2022-06-23 06:19:25.316318
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include

# Generated at 2022-06-23 06:19:28.577119
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == set(('task', 'static', 'tasks', 'handlers', 'vars', 'pre_tasks', 'post_tasks', 'meta', 'listen'))


# Generated at 2022-06-23 06:19:39.097845
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-23 06:19:42.969961
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # TODO: implement me
    pass

# Generated at 2022-06-23 06:19:45.121795
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert(hti is not None)

# Generated at 2022-06-23 06:19:47.336700
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test without any optional args
    obj = HandlerTaskInclude()
    assert obj


# Generated at 2022-06-23 06:19:49.850319
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'name': {}, 'include': {'include': 'test'}}
    h = HandlerTaskInclude.load(data)
    assert h.include.tasks == ['test']


# Generated at 2022-06-23 06:19:50.375430
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:55.855250
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task

    data = dict(
        name = 'foo',
        handler = 'bar'
    )
    block = []
    role = None
    task_include = TaskInclude(block=block, role=role)
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert isinstance(handler, HandlerTaskInclude)
    assert data['name'] == handler._parent_block.name
    assert data['handler'] == handler.handler

# Generated at 2022-06-23 06:19:58.665979
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_task = {
        'name': 'test'
    }
    mixin = HandlerTaskInclude.load(test_task)
    assert mixin.name == 'test'

# Generated at 2022-06-23 06:20:00.095851
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    b = HandlerTaskInclude()
    assert b is not None

# Generated at 2022-06-23 06:20:09.699165
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    class Mock_Loader():

        def load_role_config_definition(self, role_name):
            return "roledata"

        def load_role_config_definition(self, path):
            return "tasksfile"

    class Mock_VariableManager():
        pass

    class Mock_Block():
        pass

    mock_data = {"include": "tasksfile"}
    include_tasks = HandlerTaskInclude.load(data=mock_data, block=Mock_Block(), role="rolename", task_include="taskinclude", variable_manager=Mock_VariableManager(), loader=Mock_Loader())
    assert include_tasks.get_vars() == "roledata"
    assert include_tasks.get_name() == "tasksfile"

# Generated at 2022-06-23 06:20:17.420368
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    yaml_data = '''
    - name: TEST_HANDLER
      listen: TEST_EVENT
      tags:
        - test_include_handler
      include:
        file: test_include_handler.yml
    '''
    handler = HandlerTaskInclude({'name': 'TEST_HANDLER'}, block=None, role=None, task_include=None)
    handler.load_data({'include':
                        {'file': 'test_include_handler.yml'}
                      }
                     )
    assert(handler.get_name() == 'TEST_HANDLER')
    assert(handler.get_handler_blocks() == [{'include': {'file': 'test_include_handler.yml'}}])



# Generated at 2022-06-23 06:20:19.292535
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None

# Generated at 2022-06-23 06:20:26.541687
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # test empty object (object would not have been created)
    with pytest.raises(SystemExit):
        HandlerTaskInclude.load({})
    # test pre-defined object
    data = {'listen': 'foo'}
    assert HandlerTaskInclude.load(data) is not None
    # test pre-defined object with empty listen
    data = {'listen': ''}
    with pytest.raises(SystemExit):
        HandlerTaskInclude.load(data)


# Generated at 2022-06-23 06:20:28.383517
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
     HandlerTaskInclude.load()

# Generated at 2022-06-23 06:20:35.009805
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test data
    data = {
        'include' : 'somewhere_else.yml',
        'static' : 'y',
        'name' : 'Setup my servers',
        'hosts' : 'all'
    }
    # Test the method returning a HandlerTaskInclude object
    assert HandlerTaskInclude.load(data)
    # Test the object returned is a HandlerTaskInclude object
    assert isinstance(HandlerTaskInclude.load(data), HandlerTaskInclude)



# Generated at 2022-06-23 06:20:35.856195
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:20:44.826412
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars     import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block  import Block

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

    def my_callback():
        print("hello world")

    def my_callback2():
        print("hello world again")

    yaml_data1 = ("""
    - name: test handler
      hosts: all
      tasks:
       - debug: msg='hello'
       - debug: msg='goodbye'
    """)

# Generated at 2022-06-23 06:20:54.767966
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.__module__ == 'ansible.playbook.handler_task_include'
    assert HandlerTaskInclude.__name__ == 'HandlerTaskInclude'
    assert HandlerTaskInclude.__doc__ == '\n    Ansible handler support for `include` statements.\n\n    This class is used to wrap the task include and is primarily used\n    by the `include` statement, not directly by users.\n    '

    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == {'include', 'include_role', 'include_tasks', 'import_role', 'import_tasks', 'listen'}



# Generated at 2022-06-23 06:21:04.044655
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import yaml
    import os

    # Create variable manager
    variable_manager=VariableManager()
    variable_manager._options = {'sudo': 0}

    # Create dataloader
    loader=DataLoader()

    # Create play context
    play_context = PlayContext()

# Generated at 2022-06-23 06:21:06.187324
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Generated at 2022-06-23 06:21:11.982569
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    result = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert result.task_include == None
    assert result.role == None
    assert result.block == None
    assert result.keywords == {'tags'}
    assert result.aliases == []

# Generated at 2022-06-23 06:21:15.853446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.tests.units.test_handler import BaseTestHandlerTaskIncludeLoad
    test_unit = BaseTestHandlerTaskIncludeLoad(methodToCall=HandlerTaskInclude)
    test_unit.run()



# Generated at 2022-06-23 06:21:24.810552
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = dict(
        name="handler",
        include="some_filename",
    )
    block = dict(
        handlers=dict(
            main=data,
        )
    )
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert handler
    assert handler.get_name() == 'handler'
    assert handler.tasks
    assert handler.tasks[0].name == 'include'
    assert handler.tasks[0].get_action() == 'some_filename'

# Generated at 2022-06-23 06:21:30.955216
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HT = HandlerTaskInclude(block=None, role=None, task_include=None)
#     assert HT.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))
    assert HT.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-23 06:21:31.974867
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:21:37.202082
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler_task_include = HandlerTaskInclude()

    data = dict(block=None, role=None, task_include=None)

    HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)



# Generated at 2022-06-23 06:21:44.192399
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'listen': ''}
    handler = HandlerTaskInclude.load(
            data=data,
            block=None,
            role=None,
            task_include=None,
            variable_manager=None,
            loader=None
    )
    assert handler.action == 'include'
    assert handler.name == 'AnsibleHandler'
    assert handler.loop is None
    assert handler.when == 'SUCCESSFUL'
    assert handler.loop_control == {}
    assert handler.notify is None
    assert handler.tags == []

# Generated at 2022-06-23 06:21:48.120983
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        include_tasks = '{{ task_file }}'
    )
    assert HandlerTaskInclude(block=None, role=None, task_include=None).check_options(
        HandlerTaskInclude(block=None, role=None, task_include=None).load_data(data, variable_manager=None, loader=None),
        data
    ).include_tasks == '{{ task_file }}'

# Generated at 2022-06-23 06:21:59.341405
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    # Define a mock for method load_data()
    def mock_load_data(data, variable_manager=None, loader=None):
        pass

    # Define a mock for check_options()
    def mock_check_options(data, d):
        pass

    # Save current load_data and check_options methods
    # to be restored after test
    orig_load_data = HandlerTaskInclude.load_data
    orig_check_options = HandlerTaskInclude.check_options

    # Replace load_data and check_options methods of class HandlerTaskInclude with mock_load_data and mock_check_options
    HandlerTaskInclude.load_data = mock_load_data

# Generated at 2022-06-23 06:22:10.569316
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    myloader = DictDataLoader({
        "foo.yml": """
- shell: echo hello
""",
    })

    myvariable_manager = VariableManager()
    myvariable_manager._fact_cache = {
        "nossh": True,
        "omit": "['127.0.0.1']",
        "ansible_all_ipv4_addresses": ['127.0.0.1'],
        "ansible_ssh_host": '127.0.0.1'
    }
    myvariable_manager.set_inventory(myloader.inventory)

    myplay_context

# Generated at 2022-06-23 06:22:20.528692
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti._parent is None
    assert hti._role is None
    assert hti._block is None
    assert hti._name is None
#    assert hti._local_action is None
#    assert hti._always_run is None
    assert hti._connection is None
#    assert hti._delegate_to is None
    assert hti._listen is None
    assert hti._run_once is False
#    assert hti._delegated_vars is None
#    assert hti._module_vars is None
    assert hti._module_name is None
#    assert hti._module_args is None
    assert hti._module_uri is None
#    assert hti._module_lang is None
#    assert hti._module_set_vars

# Generated at 2022-06-23 06:22:22.512290
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-23 06:22:23.530330
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude({})

# Generated at 2022-06-23 06:22:25.333664
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-23 06:22:26.997739
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None

# Generated at 2022-06-23 06:22:27.962504
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    return None


# Generated at 2022-06-23 06:22:31.261644
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: implement a unit test for this method. This is difficult as the
    #       method makes use of a lot of libraries, so you will have to mock
    #       a lot of other classes first
    pass

# Generated at 2022-06-23 06:22:39.675688
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    import os
    import sys

    current_dir = os.getcwd()

    if current_dir not in sys.path:
        sys.path.append(current_dir)

    host = '127.0.0.1'
    port = 22
    connection = 'ssh'
    username = 'user'
    password = 'password'
    private_key_file = 'id_rsa'
    vault_secrets_file = '~/.vault_pass.txt'


# Generated at 2022-06-23 06:22:44.147771
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_HandlerTaskInclude = HandlerTaskInclude()
    assert isinstance(test_HandlerTaskInclude, HandlerTaskInclude)

test_handler_task_include = HandlerTaskInclude()
test_handler_task_include_data = {'include': 'tags.yml', 'tags': 'test'}

# Generated at 2022-06-23 06:22:44.783417
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:22:54.701958
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Creo un oggetto loader vuoto
    loader={}
    data={'include': 'name', 'static': 'hello'}
    variable_manager={}
    role={}
    task_include={}
    block={}
    handler_task_include=HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler_task_include.include == data['include']
    assert handler_task_include.static == data['static']
    assert handler_task_include.block == block
    assert handler_task_include.role == role
    assert handler_task_include.task_include == task_include
    assert handler_task_include.variable_manager == variable_manager
    assert handler_task_include.loader == loader

# Generated at 2022-06-23 06:22:56.281494
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    hti = HandlerTaskInclude()

# Generated at 2022-06-23 06:23:06.461669
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Load data into dict
    data = dict(
        name='test',
        action="action",
        become="True",
        become_method="sudo",
        become_user="user",
        delegate_to="host",
        environment="env",
        become_flags="flags",
        register="reg",
        any_errors_fatal="fatal",
        changed_when="changed",
        failed_when="failed",
        ignore_errors="True",
        poll="2",
        retries="3",
        run_once="once",
        until="when",
        delay="3"
    )

    block = dict(
        name="test",
        tasks=[]
    )


# Generated at 2022-06-23 06:23:11.549358
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load({})
    assert handler.block == []
    assert handler.role is None
    assert handler.task_include is None
    handler = HandlerTaskInclude.load({}, block=['some block'], role='some role', task_include='some task include')
    assert handler.block == ['some block']
    assert handler.role == 'some role'
    assert handler.task_include == 'some task include'


# Generated at 2022-06-23 06:23:15.337006
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print()
    print(">>>>>>>>>> Unit test for class HandlerTaskInclude <<<<<<<<<<")

    handler_task_include = HandlerTaskInclude()

    print(handler_task_include.VALID_INCLUDE_KEYWORDS)
    print()

# Generated at 2022-06-23 06:23:21.570629
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}

    # No data
    assert HandlerTaskInclude.load(data=data) == None

    # No valid key (when)
    data['when'] = 'test'
    # noinspection PyTypeChecker
    assert HandlerTaskInclude.load(data=data) == None

    # Valid key (listen)
    data['listen'] = 'test'
    # noinspection PyTypeChecker
    assert HandlerTaskInclude.load(data=data) == None

# Generated at 2022-06-23 06:23:24.441458
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    hti.load({'include': 'test.yml'})

# Generated at 2022-06-23 06:23:34.330415
# Unit test for constructor of class HandlerTaskInclude