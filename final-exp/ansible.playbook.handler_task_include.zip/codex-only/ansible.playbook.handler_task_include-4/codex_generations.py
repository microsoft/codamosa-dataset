

# Generated at 2022-06-23 06:13:32.284190
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  pass


# Generated at 2022-06-23 06:13:38.362072
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    data_loader = DataLoader()
    variable_manager = VariableManager()
    h = HandlerTaskInclude.load(
        data={'name': 'test', 'include': 'foo'},
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=data_loader
    )

    assert h is not None


# Generated at 2022-06-23 06:13:49.023526
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    import os
    import sys
    import tempfile
    import pytest

    # Initialize Ansible variables
    loader = DataLoader()
    variable_manager = VariableManager()

    tempfile_path = tempfile.mktemp()
    f = open(tempfile_path, 'w')
    f.close()

    var_list = dict()
    var_list['ansible_user'] = "ansible"
    var_list['ansible_ssh_private_key_file'] = tempfile_path
    var_list['ansible_ssh_private_key_file_ansible'] = tempfile_path
    var_list['ansible_ssh_pass'] = "ansible"
    var_

# Generated at 2022-06-23 06:13:50.721465
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert isinstance(t, Handler)

# Generated at 2022-06-23 06:14:01.099056
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.template import Templar
    t = HandlerTaskInclude()
    # assert t._load_name == 'include', t._load_name
    # assert t._role is None, t._role
    # assert t._parent is None, t._parent
    # assert t._role_name is None, t._role_name
    # assert t._task_include is None, t._task_include
    # assert t._block is None, t._block
    # assert t._dep_chain == [], t._dep_chain
   

# Generated at 2022-06-23 06:14:02.206521
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
# End of unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:14:07.877451
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name=dict(type='list', required=True),
        action=dict(default='include', type='list', required=True),
        args=dict(default='', type='dict'),
    )
    handler = HandlerTaskInclude.load(data)

    assert handler.get_name() == dict(type='list', required=True)
    assert handler.action == dict(default='include', type='list', required=True)
    assert handler.args == dict(default='', type='dict')

# Generated at 2022-06-23 06:14:10.340365
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'include': 'main.yml', 'listen': 'web'}
    handler = HandlerTaskInclude.load(data)
    assert handler

# Generated at 2022-06-23 06:14:19.998626
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a mock object
    mock_loader = {}
    mock_loader['FILE_NAME'] = 'test'
    mock_loader['ALLOW_DUPLICATE'] = False
    mock_loader['CONSTANT_LOADER'] = True
    mock_loader['CACHE'] = False
    mock_loader['_basedir'] = 'basedir'

    mock_vm = {}
    mock_vm['_vars'] = {}

    # Test constructor with default vaules
    hti = HandlerTaskInclude()
    assert hti.static is False
    assert hti.block is None
    assert hti.role is None
    assert hti.task_include is None
    assert hti.statically_loaded is False
    assert hti.name is None
    assert hti.loop is None
    assert hti.when

# Generated at 2022-06-23 06:14:30.197830
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    host = Host(name='localhost')
    host.set_variable('ansible_connection', 'local')

    play = Play().load({'name':'all', 'hosts':'all'}, variable_manager=VariableManager(), loader=None)

    playbook = Playbook().load({'plays':[{'name':'all', 'hosts':'all', 'tasks':[{'include':'foobar'}]}]}, variable_manager=VariableManager(), loader=None)

# Generated at 2022-06-23 06:14:32.105200
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor without arguments
    handlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-23 06:14:36.452757
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    print(t)
    h = t.load(data={}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    print(h)

# Generated at 2022-06-23 06:14:37.700215
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-23 06:14:41.866977
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    values = {'key1': 'value1'}
    handler = HandlerTaskInclude(block=None, role=None, task_include=values)
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include == values


# Generated at 2022-06-23 06:14:49.242612
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:14:58.889409
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.base import Requirement
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    play = Play()
    play_context = PlayContext()
    # This is needed because of handler_task_include.py
    play_context._local_vars = dict()
    play.context = play_context
    play.hosts = Host.__subclasses__()[0]
    play.groups = Group.__subclasses__()[0]
    pc = PlayContext()
    pc.hostvars = dict()
    i = InventoryManager()
    i.set_playbook_basedir(None)
    pc.inventory

# Generated at 2022-06-23 06:15:04.229760
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'hosts': 'localhost',
        'listen': 'notify_handler',
        'tasks': [
            {
                'name': 'test task',
                'debug': {
                    'var': 'res'
                }
            }
        ]
    }
    handler = HandlerTaskInclude.load(data)
    assert handler.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:15:09.839425
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test case 1, constructor
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include.get_name() == "handler"
    assert handler_task_include.get_type() == "handler"
    assert handler_task_include.get_uid()
    assert handler_task_include.get_parent()

# Generated at 2022-06-23 06:15:11.580212
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:13.499664
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None

# Generated at 2022-06-23 06:15:20.422681
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    host = Host("127.0.0.1")
    task = Task()
    task._role_name = "test_role"
    task._role = "test_role"
    handler = HandlerTaskInclude(task, host)
    assert handler._task is task
    assert host._name in handler._hosts

# Generated at 2022-06-23 06:15:24.558678
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    loader = None
    variable_manager = None
    task_include = None
    block = None
    role = None
    data = {'tags': 'test'}
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.tags == ['test']
    assert handler.static is True

# Generated at 2022-06-23 06:15:31.708864
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_varManager = None
    test_loader = None
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    handler = t.check_options(t.load_data({'tasks':'default'}, variable_manager=test_varManager, loader=test_loader),{'tasks':'default'})
    assert handler is not None

# Generated at 2022-06-23 06:15:43.204729
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.parsing.yaml.objects
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.plays import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    import ansible.playbook.task_include
    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources="")
    variable_manager=VariableManager(loader=dataloader, inventory=inventory)
    play_context=PlayContext()

# Generated at 2022-06-23 06:15:48.181087
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': '../main.yml', 'static': 'yes'}
    block = True
    role = False
    task_include = True
    variable_manager = None
    loader = None
    result = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert(isinstance(result, HandlerTaskInclude))

# Generated at 2022-06-23 06:15:48.796699
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	pass

# Generated at 2022-06-23 06:15:49.711070
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-23 06:15:58.771360
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    d=  {
        'delegate_to': '127.0.0.1',
        'remote_user': 'vagrant',
        'become': 'yes',
        'become_user': 'root',
        'listen': 'test_handler',
        'name': 'handler',
        'include': 'test.yml',
        'tags': ['handler'],
        'task': ['test']
    }
    ht = HandlerTaskInclude.load(d)
    assert ht.delegate_to == '127.0.0.1'
    assert ht.remote_user == 'vagrant'
    assert ht.become == 'yes'
    assert ht.become_user == 'root'
    assert ht.listen == 'test_handler'

# Generated at 2022-06-23 06:16:07.238186
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': [
            'common.yml'
        ],
        'include_tasks': [
            'common.yml'
        ],
        'include_role': [
            {
                'role': 'common',
                'name': 'common'
            }
        ],
        'include_vars': [
            'common.yml'
        ],
        'static': [
            'common.yml'
        ],
        'hosts': [
            '1.1.1.1',
            '2.2.2.2',
            '3.3.3.3'
        ]
    }

    assert HandlerTaskInclude.load(data) == None

# Generated at 2022-06-23 06:16:08.774650
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude(block=None, role=None, task_include=None)
    return h

# Generated at 2022-06-23 06:16:09.568121
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:15.970741
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude.load(dict(include="playbook.yml"))
    HandlerTaskInclude.load(dict(include="playbook.yml", listen=True))

# Test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:16:16.478533
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:16:23.920446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    data = {
        "listen": "test_listen",
        "include": "test_include",
        "roles": "test_roles",
        "tasks": "test_tasks"
    }


# Generated at 2022-06-23 06:16:35.272769
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # wrong options
    data = {'tasks': 'tasks', 'notify': 'tasks'}
    assert HandlerTaskInclude.load(data) is None

    # right options: handler
    data = {'handler': 'tasks'}
    handler = HandlerTaskInclude.load(data)
    assert type(handler) is HandlerTaskInclude
    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler._role is None
    assert handler._task is None
    assert handler._parent is None
    assert handler._play is None
    assert handler.template_host is None
    assert handler.template_uid is None
    assert handler._play_context is None
    assert handler.variable_manager is None
    assert handler.play_context is None
    assert handler.shared

# Generated at 2022-06-23 06:16:36.815856
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS



# Generated at 2022-06-23 06:16:40.555596
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host

    t = HandlerTaskInclude()
    assert isinstance(t, HandlerTaskInclude)
    assert isinstance(t, TaskInclude)
    assert isinstance(t, Handler)

# Test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:16:45.430256
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load(dict(include='test.yml'))
    assert HandlerTaskInclude.load(dict(include='test.yml'),'test')
    assert HandlerTaskInclude.load(dict(include='test.yml'),'test',task_include='test')
    assert HandlerTaskInclude.load(dict(include='test.yml'),'test',task_include='test',role='test')

# Generated at 2022-06-23 06:16:49.999763
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    block = Block()
    # FIXME: Remove commented lines
    # task_include = TaskInclude(playbook=playbook)
    # handler = HandlerTaskInclude.load(data=dict(ignore_errors=True))

# Generated at 2022-06-23 06:16:59.121957
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #######################################
    # Test args
    #######################################

    # (1)
    # Test instantiated without args
    # Expecting:
    #   <ansible.playbook.handler.HandlerTaskInclude object at 0x1010b0d30>
    print('(1)')
    hti = HandlerTaskInclude()
    print(type(hti))
    print(hti)
    print()

    # (2)
    # Test instantiated with block and role
    # Expecting:
    #   <ansible.playbook.handler.HandlerTaskInclude object at 0x1010b0d30>
    print('(2)')
    hti = HandlerTaskInclude(block=1, role=2)
    print(type(hti))
    print(hti)
    print()



# Generated at 2022-06-23 06:17:02.483887
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler = HandlerTaskInclude()
    assert handler.VALID_INCLUDE_KEYWORDS == {'name', 'tags', 'tasks', 'notify', 'listen'}

# Generated at 2022-06-23 06:17:11.172878
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars

    test_host = Host(name='host')
    test_host.vars = HostVars(host=test_host, variables={'key1': 'value1'})

    test_group = Group(name='group')
    test_group.hosts.add(test_host)
    test_group.vars = {'key2': 'value2'}

    test_block = Block()

# Generated at 2022-06-23 06:17:12.074481
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude != False

# Generated at 2022-06-23 06:17:24.194164
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    k = HandlerTaskInclude()

# Generated at 2022-06-23 06:17:27.056623
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Test the constructor of class HandlerTaskInclude
    :return: No return
    """
    handler_task_include = HandlerTaskInclude()

    assert handler_task_include is not None

# Generated at 2022-06-23 06:17:37.707174
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print ("Executing test_HandlerTaskInclude_load")
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    testloader = DataLoader()
    testpasswords = dict()
    testinventory = InventoryManager(loader=testloader, sources=['localhost,'])
    testvariableMgr = VariableManager(loader=testloader, inventory=testinventory)
    test_data = {'local_action': {'module': 'debug', 'msg': 'Hello local world!!'}}
    test_handler = HandlerTaskInclude.load(test_data, None, None, None, testvariableMgr, testloader)
    assert test_handler.action == 'debug'
    assert test_handler.loop == None
    assert test_handler

# Generated at 2022-06-23 06:17:48.955800
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Test 1
    class test():
        def __init__(self, data):
            self.data = data

        def get_vars(self, include_hostvars=False):
            return self.data['variable_manager']

    data = {
        'block': 'block',
        'role': 'role',
        'task_include': 'task_include',
        'variable_manager': 'variable_manager',
        'loader': None,
        'file': 'file'
    }

    assert HandlerTaskInclude.load(data) == None

    # Test 2
    class test():
        def __init__(self, data):
            self.data = data

        def get_vars(self, include_hostvars=False):
            return self.data['variable_manager']


# Generated at 2022-06-23 06:17:50.042039
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    return HandlerTaskInclude()

# Generated at 2022-06-23 06:17:55.352583
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)
    data = {'include': 'xyz'}
    handler = t.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert handler._include is not None
    assert handler._include == TaskInclude.load(data)


# Generated at 2022-06-23 06:18:07.353529
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext

    variable_manager = DictDataManager()
    variable_manager.set_variable('a', '1')
    variable_manager.set_variable('b', '2')
    variable_manager.set_variable('c', '3')
    variable_manager.set_variable('d', '4')
    variable_manager.set_variable('e', '5')
    variable_manager.set_variable('f', '6')
    variable_manager.set_variable('g', '7')
    variable_manager.set_variable('h', '8')
    variable_manager.set_variable('i', '9')
    variable_manager.set_variable('j', '10')
    variable_manager.set_variable('k', '11')
    variable_manager.set_variable

# Generated at 2022-06-23 06:18:13.772931
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=None)

    assert t.VALID_INCLUDE_KEYWORDS == set(['static', 'tasks', 'files', 'vars', 'vars_prompt', 'tags', 'when', 'options', 'with_', 'ignore_errors', 'register', 'block', 'handler', 'listen'])

# Generated at 2022-06-23 06:18:15.290932
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert isinstance(HandlerTaskInclude(), HandlerTaskInclude)

# Generated at 2022-06-23 06:18:17.705933
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert(handler)


# Generated at 2022-06-23 06:18:25.891019
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.utils.module_docs as module_docs
    import ansible.playbook.task_include as task_include
    import ansible.playbook.block as block
    import ansible.playbook.role.include as role_include
    import ansible.playbook.play as play
    import ansible.playbook.playbook as playbook

    my_var_manager = playbook.VariableManager()
    my_loader = playbook.Playbook()
    my_block_task_include = task_include.TaskInclude(block=block.Block(), role=role_include.Include(), task_include=task_include.TaskInclude())

    # -----------------------------------
    # ansible.playbook.HandlerTaskInclude
    # -----------------------------------

    # test loading of modules
    module_docs.load_docs()
    my_var_manager

# Generated at 2022-06-23 06:18:28.035518
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-23 06:18:31.020645
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    result = HandlerTaskInclude(1,2,3)
    assert result != None
    if result == None:
        raise Exception("HandlerTaskInclude constructor failed")


# Generated at 2022-06-23 06:18:32.700905
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Handler_object = HandlerTaskInclude()
    assert Handler_object.load == HandlerTaskInclude.load

# Generated at 2022-06-23 06:18:42.941797
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include' : 'somefile.yml',
        'listen' : 'restart apache',
    }
    import ansible.inventory.host
    host = ansible.inventory.host.Host()
    block = 'some block'
    role = 'some role'
    task_include = 'task include'
    h1 = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include)
    assert h1.block == block
    assert h1.role == role
    assert h1.task_include == task_include
    assert h1.static_include is False
    assert h1.delegate_to == None
    assert h1.delegate_facts == None
    assert h1.run_once == False
    assert h1.environment == {}
   

# Generated at 2022-06-23 06:18:44.129090
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert hasattr(obj, 'block')

# Generated at 2022-06-23 06:18:46.008147
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # instantiate HandlerTaskInclude object
    task_include = HandlerTaskInclude()

# unit test for load method

# Generated at 2022-06-23 06:18:53.751182
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    block = Block()
    role = Role()
    task = Task()
    task_include = TaskInclude()
    variable_manager = VariableManager()
    loader = variable_manager._loader

    handler_task_include = HandlerTaskInclude(
            block=block, role=role, task_include=task_include)

    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-23 06:18:57.428437
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    h = HandlerTaskInclude()
    assert h.__class__.__name__ == 'HandlerTaskInclude'

# Generated at 2022-06-23 06:19:04.706811
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # data: contains the source dictionary of the task include
    data = {'include': 'tasks/main.yml'}

    # block: contains the block where the task include is placed
    block = None

    # role: contains the role to which the task include is associated with
    role = None

    # task_include: contains the task include of the current task
    task_include = None

    # variable_manager: contains the variable manager object
    variable_manager = 'variable_manager'

    # loader: contains the loader object
    loader = 'loader'

    HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)



# Generated at 2022-06-23 06:19:06.009221
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude=HandlerTaskInclude()

# Generated at 2022-06-23 06:19:08.439845
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # assert False # TODO: implement your test here
    print('Implement test_HandlerTaskInclude_load')
    raise NotImplementedError


# Generated at 2022-06-23 06:19:15.491129
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Test with valid data
    data_copy = data.copy()
    HandlerTaskInclude.load(data=data_copy)

    # Test with invalid data
    data_copy = data.copy()
    del data_copy['include']
    try:
        HandlerTaskInclude.load(data=data_copy)
    except Exception as err:
        pass
    else:
        raise Exception('Dictionary without \'include\' key should cause a exception')

    
# Testing data
data = {
    'include': {
        'task': 'roles/web/tasks/main.yml',
        'tags': 'webservers'
    }
}

# Testing code
test_HandlerTaskInclude()

# Generated at 2022-06-23 06:19:23.572823
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {u'include': u'other.yml'}
    handler = HandlerTaskInclude.load(data)

    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None
    assert handler.loop is None
    assert handler.with_loop is None
    assert handler.static is False
    assert handler.tags == []
    assert handler.when == []
    assert handler._role_name == None

    assert len(handler.include_tasks) == 1
    assert handler.include_tasks[0]._role_name == None
    assert len(handler.include_handlers) == 0



# Generated at 2022-06-23 06:19:24.069515
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:27.292706
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    inv_path = './inventory/'
    inv = InventoryManager(loader=None, sources=inv_path)
    list_hosts = inv.get_hosts()
    for host in list_hosts:
        print(host)


# Generated at 2022-06-23 06:19:38.987092
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {}
    data["tags"] = ['james']
    data["include"] = 'james_tasks.yml'
    data["static"] = ['hello', 'james']
    data["name"] = 'james'
    data["tasks"] = [{'name': 'james', 'command': 'echo james'}]
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    han = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert han is not None
    assert hasattr(han, '_attributes')
    assert hasattr(han, '_block')
    assert hasattr(han, '_name')
    assert hasattr(han, '_role')


# Generated at 2022-06-23 06:19:40.310125
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 1


# Generated at 2022-06-23 06:19:43.104071
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler

# Generated at 2022-06-23 06:19:52.851349
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test for load method of class HandlerTaskInclude
    """
    import ansible.playbook.handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from .mock import patch
    from .mock import Mock

    ####################################################################################################################
    # Test case 1:
    # Unit test to check load method is working as expected when task_include.load_data return empty list
    ####################################################################################################################

    # fake task_include object with it's load_data method return empty list
    task_include_obj = Mock()
    task_include_obj.load_data.return_value = []

    # fake host object
    host = Host("fake_host")

    # fake group object
    group = Group("fake_group")


# Generated at 2022-06-23 06:19:58.486755
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	h1 = {"handlers": [{"name": "test_handler", "listen": "test_listen"}]}
	t = HandlerTaskInclude.load(h1, None, None, None, None, None)
	assert t.get_name() == "test_handler"
	assert t.get_listen() == "test_listen"

# Generated at 2022-06-23 06:20:02.033617
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {
        'name': 'abc',
        'block': {
            'name': 'abc'
        }
    }
    h = HandlerTaskInclude(data=test_data)
    assert h is not None

    h = HandlerTaskInclude(data=None)
    assert h is not None



# Generated at 2022-06-23 06:20:13.568825
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('HandlerTaskInclude.load()')
    h = HandlerTaskInclude()

    h.include_tasks = './main.yml'
    h.include_role = 'tasks/main.yml'
    h.files = ['./files1.txt', './files2.txt']
    h.handlers = ['./handlers1.yml', './handlers2.yml']
    h.vars = ['./vars1.yml', './vars2.yml']

    assert h.include_tasks == './main.yml'
    assert h.include_role == 'tasks/main.yml'
    assert h.files == ['./files1.txt', './files2.txt']

# Generated at 2022-06-23 06:20:17.188627
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert(HandlerTaskInclude.load({ 'include': 'something', 'name': 'included handler' }) is not None)
    assert(HandlerTaskInclude.load({ 'include': 'something', 'name': 'included handler' }).args is None)

# Generated at 2022-06-23 06:20:23.249430
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # case 1
    HandlerTaskInclude_case1 = HandlerTaskInclude()

    # case 2
    HandlerTaskInclude_case2 = HandlerTaskInclude(block=None, role=None, task_include=None)

    # case 3
    HandlerTaskInclude_case3 = HandlerTaskInclude(block=None, role=None, task_include=None)
    HandlerTaskInclude_case3.load(
        data=None, block=None, role=None, task_include=None,
        variable_manager=None, loader=None
    )

# Generated at 2022-06-23 06:20:34.684955
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import sys
    import os
    import os.path
    script_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(script_dir, "../../../lib"))
    import ansible.utils.module_docs as module_docs

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block


# Generated at 2022-06-23 06:20:45.200411
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    _data = {
        'include_tasks': {
            'file': 'test.yml',
            'name': 'bar'
        },
        'listen': 'bar_changed'
    }

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    role_definition = RoleDefinition.load(
        data={
            'name': 'test',
            'tasks': [_data]
        }
    )

    role = role_definition.get_role_data()

    task = role_definition.get_tasks()[0]
    task_include = task.copy()
    task_include.pop('listen', None)

# Generated at 2022-06-23 06:20:49.534538
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "include": "task"
    }
    block = None
    role = None
    task_include = None
    try:
        HandlerTaskInclude(data, block, role, task_include)
    except:
        assert False, "Failed to create HandlerTaskInclude object"



# Generated at 2022-06-23 06:20:56.393934
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # create HandlerTaskInclude object
    t = HandlerTaskInclude()

# Variable manager is used to load task variables
# Variable manager object is created to test load method
from ansible.vars import VariableManager
variable_manager = VariableManager()

# test load method
t = HandlerTaskInclude()
t.load(None, task_include='test_tasks', variable_manager=variable_manager)

# Generated at 2022-06-23 06:20:58.688720
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # TODO: use pytest.mark.parametrize
    t = HandlerTaskInclude()
    assert isinstance(t, HandlerTaskInclude)

# Generated at 2022-06-23 06:21:00.800906
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.attribute import Attribute
    assert HandlerTaskInclude(Attribute.validate('name', 'test'))

# Generated at 2022-06-23 06:21:02.463583
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': './task_file.yml'
    }
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, variable_manager, loader)
    assert handler is not None

# Generated at 2022-06-23 06:21:08.801968
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    HandlerTaskInclude.load
    '''
    # Test normal case
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block(role=None)
    task_include = TaskInclude(block=Block(name="", role=None))

    # Test the load with input data
    data = {
        "name": "hello",
        "action": "world",
        "when": "true"
    }
    assert HandlerTaskInclude.load(data=data, block=block, role=None, task_include=task_include, variable_manager=VariableManager, loader=DataLoader)._attributes == {}



# Generated at 2022-06-23 06:21:11.108421
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    cls = HandlerTaskInclude()
    assert cls is not None

# Generated at 2022-06-23 06:21:12.296913
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass # TODO: make test



# Generated at 2022-06-23 06:21:13.946501
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Fails because of #12894
    pass

# Generated at 2022-06-23 06:21:19.751377
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    data = { u'name': 'all',
            u'listen': 'deploy_web'
        }
    result = t.load(data)
    assert result.name == 'all'
    assert result.listen == [ 'deploy_web' ]

# Generated at 2022-06-23 06:21:28.638851
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = dict(
        include = '/path/to/main.yaml'
    )
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    assert HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    data = dict(
        include = '{{role_path}}/tasks/main.yaml'
    )
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    assert HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 06:21:33.397728
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include_data = dict(
        include='some_file.yml',
        first_var='some_value'
    )
    handler = HandlerTaskInclude.load(
        data=task_include_data
    )
    print(handler.action)
    print(handler.__dict__)


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:21:38.113515
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude()
    # Test __init__
    assert isinstance(task_include, HandlerTaskInclude)

    # Test load
    task_include.load('test_playbooks/handler_task_include.yml')

# Generated at 2022-06-23 06:21:47.042455
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test the HandlerTaskInclude class load method
    """
    import os
    import sys
    import yaml

    sys.path.append("..")
    from ansible.plugins.loader import find_plugin

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['../../tests/inventory'])
    variable_manager.set_inventory(inventory)

    ident = 'test_HandlerTaskInclude_load'
    if ident in inventory.get_groups():
        inventory.remove_group(ident)

    inventory.add_group(ident)


# Generated at 2022-06-23 06:21:49.032382
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load == HandlerTaskInclude.load

# Generated at 2022-06-23 06:21:49.851167
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:21:55.347158
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = HandlerTaskInclude()
    #assert_equal(task_include.play, None)
    assert task_include.VALID_INCLUDE_KEYWORDS == (TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',)))

# Generated at 2022-06-23 06:21:57.657628
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    inventory = dict()
    t = HandlerTaskInclude(block=inventory, role=inventory, task_include=inventory)
    assert t != None

# Generated at 2022-06-23 06:22:09.686259
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    Host.load(data={'name': 'test_host'})
    block = Block(play=Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [{
            'name': 'test task',
            'include': [{
                'include': 'handler.yml'
            }]
        }]
    }))
    data = {
        'include': 'handler.yml',
        'name': 'handler1'
    }
    handler = HandlerTaskInclude.load(data=data, block=block, role=None, task_include=None, variable_manager=VariableManager(loader=DictDataLoader()), loader=DictDataLoader())
    assert handler is not None

# Generated at 2022-06-23 06:22:11.191149
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print(HandlerTaskInclude.load(data='\n'))

# Generated at 2022-06-23 06:22:21.395530
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    block  = Block()
    string = '''
- name: handler test
  debug: msg="handler test"
  listen: test'''
    data = string.split('\n')
    for i in range(0, len(data)):
        data[i] = data[i].strip()
    handler = HandlerTaskInclude.load(data, block=block, variable_manager=VariableManager())
    assert handler.name == 'handler test'
    assert handler.notify == ['test']

# Generated at 2022-06-23 06:22:24.394963
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    try:
        t.load(dict(include=dict(foo='foo', one='one', two='two')))
    except:
        assert True

# Generated at 2022-06-23 06:22:25.561628
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:22:27.542081
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load({
        'include': './main.yml'
    })

    assert handler.static

# Generated at 2022-06-23 06:22:38.782386
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import load_reserved_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.included_file import IncludedFile
    from ansible.vars.include_vars import IncludeVars
    from ansible.vars.loader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.combine import combine_vars

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()

# Generated at 2022-06-23 06:22:51.075844
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    host = Host(name = 'hostname')
    VariableManager = MagicMock(return_value=host)
    Playbook = MagicMock()
    PlayContext = MagicMock()
    PlayContext.CLIARGS = {'module_path': '/path/to/ansible/modules/'}
    connection = Connection()
    task = Task(
        action=u'/bin/echo "pippo"',
        args={}
    )

    data = {
        'tags': [],
        'listen': ['test'],
        'include': '/tmp/test_handler_include'
    }

    handler = HandlerTaskInclude.load(
        data,
        block=None,
        role=None,
        task_include=task,
        variable_manager=VariableManager,
        loader=None
    )



# Generated at 2022-06-23 06:22:55.689264
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # need to remove the 'argspec', 'deprecated_keywords' key-value pairs back to the 'data' dictionary
    data = {'include': 'listen', 'listen': 'handlers/main.yml', 'argspec': None, 'deprecated_keywords': []}
    handler = HandlerTaskInclude.load(data)
    assert handler.include_file == 'handlers/main.yml'

# Generated at 2022-06-23 06:22:58.797339
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-23 06:23:08.160282
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role_include import RoleInclude

    variable_manager = VariableManager()
    loader = DataLoader()
    host = Host(name="127.0.0.1")


# Generated at 2022-06-23 06:23:20.090297
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    myvariables = dict()
    myinventory = InventoryManager(loader=DataLoader())
    myplay = Play.load(dict(name='testplay', hosts='all'), variable_manager=VariableManager(loader=DataLoader(), variables=dict(name=['localhost'])))
    variable_manager = VariableManager(loader=DataLoader(), variables=myvariables)
    variable_manager.set_inventory(myinventory)


# Generated at 2022-06-23 06:23:21.481066
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.__class__ == HandlerTaskInclude

# Generated at 2022-06-23 06:23:26.339488
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Constructor without parameters
    hti = HandlerTaskInclude()
    assert hti

    # Constructor with valid parameters
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert hti

# Generated at 2022-06-23 06:23:28.001795
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    #TODO: implement unittest for this method
    pass

# Generated at 2022-06-23 06:23:31.785900
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        u'listen': u'create_users',
        u'include': u'create_users.yml',
    }
    assert HandlerTaskInclude.load(data)