

# Generated at 2022-06-23 06:13:42.969232
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    def check_HandlerTaskInclude_init_to_raise_type_error(data):
        try:
            HandlerTaskInclude.load(data=data)
            raise AssertionError("The constructor must raise TypeError error when the parameter '%s' is passed" % (repr(data)))
        except TypeError:
            pass

    check_HandlerTaskInclude_init_to_raise_type_error([])
    check_HandlerTaskInclude_init_to_raise_type_error(['/etc/passwd'])
    check_HandlerTaskInclude_init_to_raise_type_error(set())
    check_HandlerTaskInclude_init_to_raise_type_error({})
    check_HandlerTaskInclude_init_to_raise_type_error(None)


# Generated at 2022-06-23 06:13:47.510266
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_include = 'listen'
    t = HandlerTaskInclude(block=None, role=None, task_include=task_include)
    assert t.task_include == task_include

# Generated at 2022-06-23 06:13:48.551195
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler

# Generated at 2022-06-23 06:13:55.448532
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude.load({'name': 'task1'})
    assert isinstance(t, HandlerTaskInclude)
    assert t.name == 'task1'

    t = HandlerTaskInclude.load({'name': 'task1', 'ignore_errors': False})
    assert isinstance(t, HandlerTaskInclude)
    assert t.name == 'task1'
    assert t.ignore_errors == False

# Generated at 2022-06-23 06:14:01.273829
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="test_HandlerTaskInclude_load",
        # include=dict(
        include="example.yml",
        tasks=["example.yml"],
        # )
    )
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(data, dict(), dict())
    handler = HandlerTaskInclude.load(loader.get_single_data(), loader=loader)
    print(handler)



# Generated at 2022-06-23 06:14:09.269663
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    @precondition: The test requires having a valid yaml file.
    @precondition: It requires having a valid string with a valid handler in order to check if
                   the method works.
    @postcondition: The test ensures that the method load returns a HandlerTaskInclude object.
    '''
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None)

    with open("../../../../../../../tests/test_files/include_handler_test.yaml", 'r') as stream:
        data = yaml.load(stream)
        handler_task_include = HandlerTaskInclude.load(
            data=data["handlers"][0],
            variable_manager=variable_manager,
            loader=None
        )

# Generated at 2022-06-23 06:14:16.992682
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class Dummy1(object):
        pass

    class Dummy2(object):
        pass

    instance = HandlerTaskInclude()
    data = {'name': 'test', 'include': 'tasks/test.yml', 'listen': 'test'}
    variable_manager = Dummy1()
    loader = Dummy2()
    handler = instance.load(data, variable_manager=variable_manager, loader=loader)
    assert handler.name == 'test'
    assert handler.listen == 'test'



# Generated at 2022-06-23 06:14:20.725136
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(name='test_name')

    assert handler_task_include.name == 'test_name'
    assert handler_task_include.block == None
    assert handler_task_include.role == None
    assert handler_task_include.task_include == None
    assert handler_task_include.callbacks == []
    assert handler_task_include.errors == []


# Generated at 2022-06-23 06:14:27.795372
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # create the class
    hti = HandlerTaskInclude()

    # class HandlerTaskInclude has staticmethod load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    # so we can test it by just calling it
    hti_result = HandlerTaskInclude.load()

    # compare the result of the method to the expected result
    match = hti_result == hti
    assert match, "HandlerTaskInclude.load() returned unexpected result."

# Generated at 2022-06-23 06:14:39.629664
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = "This is a HandlerTaskInclude object"
    block = "This is a block"
    role = "This is a role"
    task_include = "This is a task_include"
    variable_manager = "This is a variable_manager"
    loader = "This is a loader"

    item = HandlerTaskInclude.load(data,block,role,task_include,variable_manager,loader)
    assert item
    assert hasattr(item,"data")
    assert hasattr(item,"block")
    assert hasattr(item,"role")
    assert hasattr(item,"task_include")
    assert hasattr(item,"variable_manager")
    assert hasattr(item,"loader")
    assert hasattr(item,"_validate_deprecated_attrs")

# Generated at 2022-06-23 06:14:43.762082
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # This should not raise an exception
    HandlerTaskInclude.load({
        'include': 'test.yml',
        'static': '/some/path/to/a/file',
        'foo': ['a', 'b'],
        'bar': 'baz',
        'name': 'myhandler',
        'listen': ['foo', 'bar']
    }, loader=None)

# Generated at 2022-06-23 06:14:47.823392
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """ Testing method load of class HandlerTaskInclude"""
    pass


    data = {
        'include': 'test.yml',
        'ignore_errors': True
    }

    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    assert HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-23 06:14:57.500525
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Testing load method of class HandlerTaskInclude")
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    data = dict(
        name="test",
        listen="test",
        include="test",
        static="test"
    )

    block = Block(parent=None, role=None, task_include=None)
    role = None
    task_include = None


    # Test with right data

# Generated at 2022-06-23 06:14:58.047778
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass # TODO

# Generated at 2022-06-23 06:15:03.199087
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'include': 'playbook.yml',
        'listen': 'my_handler',
    }

    hti = HandlerTaskInclude.load(data)
    assert hti.include_role == 'playbook.yml'
    assert hti.notify_list == [ 'my_handler' ]
    assert hti.name == 'playbook.yml'

# Generated at 2022-06-23 06:15:04.222893
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """Test load."""
    pass

# Generated at 2022-06-23 06:15:14.841349
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass
#     d = dict(
#         task=dict(
#             name="test task",
#             tags=["tag1"],
#         ),
#         handlers=dict(
#             tasks=HandlerTaskInclude.VALID_INCLUDE_KEYWORDS,
#         ),
#         **PlaybookInclude.shared_loader_obj()
#     )
#     handler = HandlerTaskInclude.load(d)
#     assert handler.name == "test task"
#     assert handler.tags == ["tag1"]
#
#
# def test_HandlerTaskInclude_init_exception():
#     d = dict(
#         task=dict(
#             name="test task",
#             tags=["tag1"],
#             with_items=["{{ test_var }}"]
#         ),
#         handlers

# Generated at 2022-06-23 06:15:25.611491
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import context_objects as co

    variable_manager = VariableManager()
    loader = DataLoader()

    # make sure this works with no hosts specified (either in inventory or in play)
    h = HandlerTaskInclude()
    datastructure = {'include': 'watchers.yml'}
    h.load_data(datastructure)
    result = h.check_options(datastructure, datastructure)

    # make sure this works with no hosts specified (either in inventory or in play)
    h = HandlerTaskInclude()

# Generated at 2022-06-23 06:15:38.681266
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:15:50.781976
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    context._task = None
    context._play = None
    context._play_context = None
    context._connection = None
    context.update = None
    context.prompt = None
    context.remote_addr = None
    context._stdin_file = None
    context.stdin = None
    context.stdout = None
    context.stderr = None
    context.verbosity = None
    context.winrm_connection = None
    context.become = None
    context.become_method = None
    context.become_user = None
    context.diff = None
    context.force_handlers = None
    context.only_tags = None

# Generated at 2022-06-23 06:15:59.212704
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.strategy import StrategyBase

    add_all_plugin_dirs()

    strategy = StrategyBase()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/Users/xuwang/PycharmProjects/devops/ansible_playbook/ansible_playbook/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 06:16:08.205115
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'f': {
            'g': {
                'h_1': 'hbar_1'
            }
        }
    }
    default_vars = variable_manager.get_vars(play=dict(hosts=['localhost']))
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=[os.path.join(os.getcwd(), 'tests', 'test_include_vars.yml')])
    host = inventory.hosts.get('localhost')

    assert len

# Generated at 2022-06-23 06:16:10.334080
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(block=None, role=None, task_include=False)
    assert t is not None


# Generated at 2022-06-23 06:16:11.889418
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)

    assert hti

# Generated at 2022-06-23 06:16:26.999306
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader, module_loader

    loader = DataLoader()
    inv_obj = InventoryManager(loader=loader, sources=['localhost,'])
    host = inv_obj.get_host(Host('localhost'))
    group = inv_obj.add_group(Group('localhost'))
    group.add_host(host)
    inv_obj.add_host(host)


# Generated at 2022-06-23 06:16:37.471680
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    host = Host(name='localhost')
    variable_manager.extra_vars = {}
    inventory._variable_manager = variable_manager
    inventory._add_host(host)
    group = Group(name='all')
    group.add_host(host)
    inventory._add_group(group)


# Generated at 2022-06-23 06:16:42.994934
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'tasks': ['tasks/main.yml'], 'handlers': ['handlers/main.yml']}
    loader = AnsibleLoader(data, None, None)
    variable_manager = VariableManager()
    test_data = {'name': 'tasks/main.yml', 'include': 'tasks/main.yml'}

    test_HandlerTaskInclude = HandlerTaskInclude.load(test_data, None, None, None, variable_manager, loader)
    assert test_HandlerTaskInclude

# Generated at 2022-06-23 06:16:44.856918
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert hti

# Generated at 2022-06-23 06:16:50.511116
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("\n### HandlerTaskInclude ###\n")
    #assert HandlerTaskInclude(block=None, role=None, task_include=TaskInclude())
    print(HandlerTaskInclude.__doc__)
    print(HandlerTaskInclude.load.__doc__)

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:16:51.146006
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:59.696295
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('test start')
    # table = []
    # table = [{'name': u'Install memcached package', 'action': {'__ansible_module__': u'apt', 'name': 'memcached', 'state': u'latest'}, 'when': 'ansible_os_family == "Debian"', 'with_items': []}, {'name': u'Install memcached package', 'action': {'__ansible_module__': u'yum', 'name': 'memcached', 'state': u'latest'}, 'when': 'ansible_os_family == "RedHat"', 'with_items': []}]

    # table = [{'name': u'Install npm package manager', 'action': {'__ansible_module__': u'command', 'chdir': '/usr/bin', 'creates

# Generated at 2022-06-23 06:17:09.179750
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = None
    block = Block(
        task_include=None,
        role=None,
        play_context=play_context,
        variable_manager=variable_manager,
        loader=loader
    )

# Generated at 2022-06-23 06:17:21.334755
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


    # Create Groups
    groupA = Group('groupA')
    groupB = Group('groupB')
    groupC = Group('groupC')
    groupD = Group('groupD')

    # Add groups to groups
    groupA.add_child_group(groupC)
    groupA.add_child_group(groupD)
    groupB.add_child_group(groupD)

    # Create Hosts
    hostA = Host('hostA')
    hostB = Host('hostB')
    hostC = Host('hostC')
    hostD = Host('hostD')

# Generated at 2022-06-23 06:17:25.554403
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:17:36.762895
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    This test checks that the constructor of class HandlerTaskInclude
    does the following when called with the argument --listen=yes
      - Parses the argument and returns a handler object for the --listen argument
      - Does not print anything to STDOUT in the function
      - Has the following class variable values:
        VALID_INCLUDE_KEYWORDS = set(('listen', 'run_once'))
        VALID_INCLUDE_ATTRIBUTES = set(('name', 'tasks', 'handlers'))
        SKIP_VALIDATION = True
        SKIP_METADATA = True
    """
    class DummyBlock(object):
        pass

    class DummyRole(object):
        pass

    class DummyTaskInclude(object):
        pass

    # DummyHandler object that can be

# Generated at 2022-06-23 06:17:47.118096
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.base import Base
    from ansible.inventory.host import Host
    data = dict(
        include="a_task.yml",
        hosts="host1,host2"
    )
    in_data = dict()
    role = None
    block = Host(name="host1")
    task = Base()
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(data, block=block, role=role, task_include=task, variable_manager=variable_manager, loader=loader)
    assert isinstance(handler, HandlerTaskInclude)
    assert handler.block._name == 'host1'
    assert handler.include is None

# Generated at 2022-06-23 06:17:57.236869
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:18:08.969576
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from os.path import join, dirname, abspath


# Generated at 2022-06-23 06:18:16.100349
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	assert HandlerTaskInclude.load(
		data = {
        	'name': 'test',
        	'include': '../tasks/foo.yml',
        	'include_vars': {'key': 'val'}
    	},
    	task_include = TaskInclude(loader=None, play=None, variable_manager=None, templar=None),
    	role = None,
    	block = None,
    	variable_manager = None,
    	loader = None
	)



# Generated at 2022-06-23 06:18:16.802503
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:18:20.795175
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    a = {'include': './foo.yml', 'listen': 'bar'}
    b = HandlerTaskInclude.load(a)
    assert b['include'] == ['./foo.yml']
    assert b['listen'] == 'bar'

# Generated at 2022-06-23 06:18:22.535303
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False # TODO: implement your test here


# Generated at 2022-06-23 06:18:31.868089
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude(None, None, None)

    # Case 1
    data = {}
    data['listen'] = 'test_listen'
    data['include'] = 'test_include'
    result = handler.load(data, 'test_block', 'test_role', 'test_task_include', 'test_variable_manager', 'test_loader')
    assert result.get_name() == 'test_listen'
    assert result.get_action() == 'include'

# Generated at 2022-06-23 06:18:38.805919
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    data = {}
    t.load_data(data, 'my_block', 'my_role', 'my_task_include')
    assert t.block == 'my_block'
    assert t.role == 'my_role'
    assert t.task_include == 'my_task_include'
    assert t.ignore_errors == False
    assert t.when == True

# Generated at 2022-06-23 06:18:41.455318
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: implement this test method
    task_include = HandlerTaskInclude()
    assert True

# Generated at 2022-06-23 06:18:49.185582
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task_include import TaskInclude
    from pytest import raises
    from six import PY3
    from sys import version_info

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task_include_vars import TaskIncludeVars


# Generated at 2022-06-23 06:18:50.046178
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-23 06:18:55.381775
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Make handler_task_include object
    handler_task_include = HandlerTaskInclude()
    # Check handler_task_include is object of HandlerTaskInclude
    assert isinstance(handler_task_include, HandlerTaskInclude)
    # Check handler_task_include is object of Handler and TaskInclude
    assert isinstance(handler_task_include, Handler)
    assert isinstance(handler_task_include, TaskInclude)

# Generated at 2022-06-23 06:19:04.584809
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.vars import VariableManager
    from ansible.template import Templar, Jinja2Template
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # 1. HandlerTaskInclude.load(data)
    # (1) 'block' is None, 'role' is None, 'task_include' is None
    # (2) 'block' is None, 'role' is None, 'task_include' is not None
    # (3) 'block' is not None, 'role' is None, 'task_include' is None
    # (4) 'block' is not None, 'role' is None, 'task

# Generated at 2022-06-23 06:19:06.301328
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block='block', role='role', task_include='task_include')

# Generated at 2022-06-23 06:19:09.377361
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Test_HandlerTaskInclude: Test constructor of class HandlerTaskInclude
    """
    hti = HandlerTaskInclude()

# Generated at 2022-06-23 06:19:09.935975
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:13.988523
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """handler_task_include.py:Test the constructor of HandlerTaskInclude class"""
    block= None
    role=None
    task_include=None
    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)

# Generated at 2022-06-23 06:19:18.309040
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    name = 'test_name'
    handler_task_include = HandlerTaskInclude(name)
    assert handler_task_include.name == name

# Generated at 2022-06-23 06:19:19.310678
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False


# Generated at 2022-06-23 06:19:26.580531
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Create a TaskInclude object which will then be used to
    # pass to HandlerTaskInclude
    t = TaskInclude()
    # Create a sample data object
    data = {}
    # Create a HandlerTaskInclude object
    handler = HandlerTaskInclude.load(data, task_include=t)
    # Check if all the attributes of the handler object
    # are valid
    assert handler._role == None
    assert handler._block == None
    assert handler._task_include == t
    assert handler._task == None
    assert handler._loaded_from == None
    assert handler._parent == None
    assert handler._role_params == None

# Generated at 2022-06-23 06:19:31.456154
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load()

    # def check_options(self, include):
    #     add_ignore_errors = False
    #     if 'ignore_errors' in include:
    #         if include.get('ignore_errors'):
    #             add_ignore_errors = True
    #     include.pop('ignore_errors', None)

    #     super(HandlerTaskInclude, self).check_options(include)

    #     if add_ignore_errors:
    #         self.ignore_errors = True
    #     else:
    #         self.ignore_errors = False


# Generated at 2022-06-23 06:19:33.321474
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:19:44.101767
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        include_tasks='/home/ansible/tasks/nginx.yml',
        listen="start"
    )

    obj = HandlerTaskInclude()
    handler = obj.load(data)

    ans = dict(
        include_tasks='/home/ansible/tasks/nginx.yml',
        listen=["start"]
    )

    assert dict(handler) == ans


# Generated at 2022-06-23 06:19:46.337688
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Running unittest: test_HandlerTaskInclude_load')
    assert(False)

# Generated at 2022-06-23 06:19:54.801589
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    # constructor call
    block = Block(
        parent=None,
        role=None,
        task_include=TaskInclude(
            role=RoleInclude(),
            task=Task()
        )
    )
    handler_task_include = HandlerTaskInclude(
        block=block,
        role=None,
        task_include=TaskInclude(
            role=RoleInclude(),
            task=Task()
        )
    )
    # method call

# Generated at 2022-06-23 06:20:02.202669
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test all argument case
    hHandlerTaskInclude = HandlerTaskInclude(block=None, role=None, task_include=None)

    # check arguments are set properly
    assert hHandlerTaskInclude.block == None
    assert hHandlerTaskInclude.role == None
    assert hHandlerTaskInclude.task_include == None

    # test HandlerTaskInclude without any argument
    hHandlerTaskInclude = HandlerTaskInclude()

    # check arguments are set properly
    assert hHandlerTaskInclude.block == None
    assert hHandlerTaskInclude.role == None
    assert hHandlerTaskInclude.task_include == None


# Generated at 2022-06-23 06:20:11.635395
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    TaskInclude_unit_test = TaskInclude.load(data={
        'include': '../test_playbooks/print_hello.yml',
        'task': [2],
        'name': "test_include"
    })
    task_handler = HandlerTaskInclude.load(data=TaskInclude_unit_test, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(task_handler, HandlerTaskInclude) is True
    assert isinstance(task_handler, Handler) is True
    assert isinstance(task_handler, TaskInclude) is True
    assert task_handler.task.args['task'] == [2]
    assert task_handler.task.name == "test_include"
    assert task_handler.block is None
    assert task_

# Generated at 2022-06-23 06:20:12.152363
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:20:19.334028
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # create object of HandlerTaskInclude
    # we will use 'assertEqual' function to verify that
    # the value we expect is equal to the actual value
    h1 = HandlerTaskInclude()
    assertEqual(h1.VALID_INCLUDE_KEYWORDS, {'tasks', 'vars', 'meta', 'handlers', 'listen'})


test_HandlerTaskInclude()

# Generated at 2022-06-23 06:20:31.025721
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    display = Display()

    # create the building blocks of Ansible infrastructure
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a variable in the variable manager
    variable_manager.set_nonpersistent_facts(dict(foo="bar"))

    # populate the variable manager

# Generated at 2022-06-23 06:20:32.420270
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj is not None


# Generated at 2022-06-23 06:20:34.152474
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    myHandlerTaskInclude = HandlerTaskInclude()


# Generated at 2022-06-23 06:20:40.800562
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'listen': '',
        'name': 'test'
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    handler = HandlerTaskInclude.load(
        data, block, role, task_include, variable_manager, loader
    )
    assert handler.get_name() == 'test'

# Generated at 2022-06-23 06:20:48.274173
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    host = Host(name="testhost")
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')

    data = {
        'include': './tasks/main.yml',
        'listen': 'test',
        'name': 'notify new users'
    }
    task_include = HandlerTaskInclude.load(data,
                variable_manager=variable_manager,
                loader=loader)
    assert task_include.block == None
    assert task_include.role == None
    assert task_include.static == False
    assert task_include.delegate

# Generated at 2022-06-23 06:21:00.089761
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # Create an instance of Task
    t = Task()
    t._role = None

    # Create an instance of HandlerTaskInclude
    h = HandlerTaskInclude(block=None, role=None, task_include=None, only_tags=[])

    play_context = PlayContext()
    play_context.remote_addr = 'localhost'
    play_context.port = 22
    play_context.remote_user = 'user'
    play_context.connection = 'local'
    play_context.network_os = ''
    play_context.timeout = 10
    play_context.become = False
    play_context.become_method = ''
    play_context.become_user = ''
    play_

# Generated at 2022-06-23 06:21:00.715253
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:21:09.116480
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    valid_data_1 = {
        'include': 'foo.yml',
        'name': 'Include foo.yml'
    }
    valid_data_2 = {
        'include': 'foo.yml',
        'name': 'Include foo.yml',
        'when': 'True'
    }

    invalid_data_1 = {
        'include': 'foo.yml',
        'test': 'Include foo.yml'
    }
    invalid_data_2 = {
        'tests': 'foo.yml',
        'name': 'Include foo.yml'
    }

    # Test a valid data
    handler = HandlerTaskInclude.load(valid_data_1, handler=True)
    assert valid_data_1 == handler.get_vars()

    # Test

# Generated at 2022-06-23 06:21:09.785479
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None


# Generated at 2022-06-23 06:21:13.364833
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('\nTest HandlerTaskInclude')
    print('-----HandlerTaskInclude_load-------')

if __name__ == "__main__":
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:21:16.601035
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # handler_task_include = HandlerTaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert True


# Generated at 2022-06-23 06:21:22.995722
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # if: 1 == 2
    def check_handler_data(handler, conditional_expr):
        assert handler.get_name() == 'include test of block 0'
        assert handler.get_all_parents() == []
        assert handler.has_parent() == False
        assert handler.get_loop() == []
        assert handler.get_loop_desc() == ''
        assert handler.get_tags() == []
        assert handler.get_when() == conditional_expr
        assert handler.get_notify() == []
        assert handler.is_import_tasks() == False
        assert handler.is_import_role() == False
        assert handler.is_notify_handler() == False

# Generated at 2022-06-23 06:21:33.800679
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    yml = """
      - name: restart rabbit
        service: name=rabbitmq-server state=restarted
        listen: "rabbit restarts"

      - include: other_handlers.yml
        listen: "rabbit restarts"

      - name: restart memcached
        service: name=memcached state=restarted
        listen: "memcached restarts"
    """
    handler = HandlerTaskInclude.load(data=yml, block=None, role=None, task_include=None,
                                      variable_manager=None, loader=None)
    assert handler is not None
    assert handler._attributes['name'] == 'restart rabbit'
    assert handler._attributes['service'] == {'name': 'rabbitmq-server', 'state': 'restarted'}
    assert handler._att

# Generated at 2022-06-23 06:21:44.896610
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    task_data = dict(
        name="foo",
        include=dict(
            files='bar'
        )
    )

    handler_data = dict(
        name="foo",
        listen="bar",
        include=dict(
            files='bar'
        )
    )

    # Unnamed TaskInclude
    ti = HandlerTaskInclude(block=None, role=None, task_include=None, data=task_data)
    assert ti.name == "foo"
    assert ti.attributes.get('include').get('files') == 'bar'
    assert ti.attributes.get('include').get('type') == 'include'

    # Named TaskInclude

# Generated at 2022-06-23 06:21:50.728509
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def test_proc(data, result):
        def _mock_load(param):
            return None
        HandlerTaskInclude.load = _mock_load
        assert HandlerTaskInclude.load(data) == result

    test_proc({'listen': 'all'}, True)
    test_proc({'listen': 'network'}, True)
    test_proc({'listen': 'system'}, True)
    test_proc({'listen': 'all', 'tags': ['all']}, True)
    test_proc({'listen': 'all', 'tags': None}, True)
    test_proc({'listen': 'network', 'tags': ['all']}, True)
    test_proc({'listen': 'network', 'tags': None}, True)

# Generated at 2022-06-23 06:21:52.916670
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None

# Generated at 2022-06-23 06:21:56.827761
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    filename = 'tasks/test.yaml'
    t = HandlerTaskInclude()
    t.load(data={'ignore_errors': 'yes'}, filename=filename)
    assert(t.filename == filename)
    assert(t.ignore_errors == 'yes')

# Generated at 2022-06-23 06:22:08.763171
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():    
    # Test for a valid handler file
    # 1. Create an instance of class HandlerTaskInclude
    # 2. Read data from file, and store it into an array
    # 3. Check that it returns a valid Handler instance
    # 4. Check that it has the same variables as the file

    t = HandlerTaskInclude()

    # Attempt to load data
    valid_path = "/tmp/ansible_test_valid_handler_file"
    with open(valid_path, 'r') as f: 
        valid_data = f.read()

    valid_handler = t.load(valid_data)
    assert isinstance(valid_handler, Handler)

    assert valid_handler.action.__class__.__name__ == 'ActionModule'
    assert valid_handler.name == "Test handler file"
    assert valid_handler.listen

# Generated at 2022-06-23 06:22:10.192692
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:22:11.357581
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	# TODO: Add unit test
	assert True

# Generated at 2022-06-23 06:22:23.334813
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._vars_per_host  = {}

    block = Block()

    data = {
        'block': 'test_block',
        'include': 'test_task_include',
        'name': 'test_task_name',
        'register': 'test_register',
        'notify': 'notify_test_task',
    }

    task_include = Task()
    task_include._role = None
    task_include._block = block


# Generated at 2022-06-23 06:22:26.266288
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: Add unit test after adding the corresponding class
    t = HandlerTaskInclude()
    assert t.load(data=None, block=None, role='') == False



# Generated at 2022-06-23 06:22:37.500076
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    hostname = 'test'
    groups = {'all': Group(name="all")}
    variables = {}
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_group("all")
    inventory.add_host(host=hostname, group="all")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:22:42.029329
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task

    data = dict(
        name='test_handler',
        tasks=dict(
            test=dict(
                action=dict(
                    module='shell',
                    args='echo hi'
                )
            )
        )
    )
    handler = HandlerTaskInclude.load(data, variable_manager=None, loader=None)
    ht = handler.tasks[0]
    assert type(ht) == Task
    assert ht._role is None
    assert ht._role_name is None
    assert ht._block is None
    assert ht._task_include is None

# Generated at 2022-06-23 06:22:51.128313
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    dat = '''
- name: test handler
  hosts: test
  tasks:
    - debug:
        msg: "Hello world"
'''
    dat2 = '''
- name: test handler
  hosts: test
  tasks:
    - debug:
        msg: "Hello world"
    - foo:
        msg: "Hello world"
  handlers:
    - debug:
      msg: "hello world"
'''
    HandlerTaskInclude.load(dat)
    HandlerTaskInclude.load(dat2)

# Test the constructor with an empty data

# Generated at 2022-06-23 06:22:56.803446
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """ Returns new handler object with appropriate parameters """

    data = { "include": "somefile.yml" }
    block = "block"
    role = "role"
    task_include = "task_include"
    variable_manager = "variable_manager"
    loader = "loader"

    loop = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert loop.block == block
    assert loop.role == role
    assert loop.task_include == task_include


# Generated at 2022-06-23 06:23:07.309884
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        handler=dict(name='test',
                    tasks=['task1', 'task2'],
                    listen=dict(key1='value1')
                    )
    )
    handler = HandlerTaskInclude.load(data, block=None, role=None)
    assert handler.name == 'test'
    assert handler.block is None
    assert handler.role is None
    assert handler.tags == set(['always'])
    assert handler._metadata is None
    assert handler.notify == []
    assert handler.loop is None
    assert handler.when is None
    assert handler.loop_control is None
    assert handler.rescue is []
    assert handler.always is []
    assert handler.run_once is False
    assert handler.tasks == ['task1', 'task2']
    assert handler.cleanup

# Generated at 2022-06-23 06:23:08.351820
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:23:20.137559
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # parser = argparse.ArgumentParser(description='Process some integers.')
    # parser.add_argument('integers', metavar='N', type=int, nargs='+',
    #                     help='an integer for the accumulator')
    # parser.add_argument('--sum', dest='accumulate', action='store_const',
    #                     const=sum, default=max,
    #                     help='sum the integers (default: find the max)')
    #
    # args = parser.parse_args()
    # print(args.accumulate(args.integers))
    h = HandlerTaskInclude.load('', task_include=None, block=None, loader=None, role=None, variable_manager=None)
    print("Test 1: Test created handler")

# Generated at 2022-06-23 06:23:21.573287
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	assert True

# Generated at 2022-06-23 06:23:28.198224
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # post_validation() of class TaskInclude
    block = None
    role = None
    task_include = None
    myHandlerTaskInclude = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    return myHandlerTaskInclude
myHandlerTaskInclude = test_HandlerTaskInclude()
print(myHandlerTaskInclude)


# Generated at 2022-06-23 06:23:36.069998
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = '''---
- name: test handler
  listen: test event
  handler: something
'''
    assert HandlerTaskInclude.load(data) == HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None,
        handler='something',
        listen='test event',
        name='test handler',
        when=None,
        become=None,
        become_user=None,
        delegate_to=None,
        listen_when=None,
        listen_tags=[],
        tags=[],
    )
