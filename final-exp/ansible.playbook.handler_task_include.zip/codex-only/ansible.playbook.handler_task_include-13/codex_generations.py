

# Generated at 2022-06-23 06:13:34.042984
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
  x = HandlerTaskInclude()

# Generated at 2022-06-23 06:13:44.268241
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class DummyInclude(object):
        def __init__(self, search_paths):
            self.search_paths = search_paths
            self.template_dirs = []

    loader = DataLoader()
    variable_manager = VariableManager()
    host = Host('localhost')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    variable_manager.set_inventory(host)

    data = {
        'name': 'foo',
        'include': 'bar',
        'listen': 'foobar'
    }

    include = DummyInclude([])
    handler = HandlerTaskInclude

# Generated at 2022-06-23 06:13:52.053003
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    hti.block = "block"
    hti.role = "role"
    hti.task_include = "task_include"
    #data = {"include_role": "role"}
    #data = {"include_tasks": "role"}
    data = {"listen": "role"}
    #data = {"delegate_to": "role"}
    #data = {"include_role": "role"}
    variable_manager = None
    loader = None
    h = hti.load(data, variable_manager, loader)
    assert h.block == "block"
    assert h.role == "role"
    assert h.task_include == "task_include"
    print (h.get_vars())

# Generated at 2022-06-23 06:14:01.606460
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Set up mock environment
    import ansible.interfaces.playbook_interface as mock_playbook_interface
    import ansible.playbook.task as mock_task
    import ansible.playbook.block as mock_block
    import ansible.playbook.play_context as mock_play_context
    import ansible.playbook.play as mock_play
    import ansible.playbook.task_include as mock_task_include

    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    mock_block = mock_block.Block()
    mock_task = mock_task.Task()

    mock_parent_block = mock_block.Block()
    mock_parent_block._parent = mock_play
    mock_parent_block._role = mock_play

# Generated at 2022-06-23 06:14:02.474000
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:14:03.000209
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:14:05.876417
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude("block", "role", "task_include")

# Generated at 2022-06-23 06:14:16.317273
# Unit test for method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:14:23.736862
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude()
# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ansible.  If not, see <http://www.gnu

# Generated at 2022-06-23 06:14:26.877051
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass
    # host = Host()
    # data = {'include': 'something.yaml'}
    # handler = HandlerTaskInclude.load(data, variable_manager=None)
    # assert handler

# Generated at 2022-06-23 06:14:30.169525
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict()
    handler = HandlerTaskInclude.load(data)
    assert isinstance(handler, HandlerTaskInclude)


# Generated at 2022-06-23 06:14:34.614236
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert t.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert t.block is None
    assert t.role is None
    assert t.task_include is None

# Generated at 2022-06-23 06:14:35.095042
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:14:36.128346
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass



# Generated at 2022-06-23 06:14:38.466391
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
	task_include = HandlerTaskInclude()
	print(type(task_include))
	print(task_include)


# Generated at 2022-06-23 06:14:50.647380
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import tempfile
    import yaml
    from ansible.constants import DEFAULT_HANDLER_TASK_INCLUDE_PATH
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Prepare a fake handler task include file and load it by HandlerTaskInclude.load
    handler_task_include_file = tempfile.mktemp()
    handler_task_include_filename = os.path.basename(handler_task_include_file)

# Generated at 2022-06-23 06:14:53.838246
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    action = HandlerTaskInclude()
    assert isinstance(action, HandlerTaskInclude)

# Generated at 2022-06-23 06:15:04.142866
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:15:14.731866
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print('Test HandlerTaskInclude class')
    new_handler = HandlerTaskInclude()
    new_handler.check_conditional()
    new_handler.check_include_keyword(HandlerTaskInclude.VALID_INCLUDE_KEYWORDS)
    new_handler.conditional = 'check_conditional'
    new_handler.set_loader(None)
    new_handler.evaluate_conditional(None)
    new_handler.has_triggered(None, None)
    new_handler.copy()
    new_handler.copy_data()
    new_handler.vars = ['a','b','c']
    new_handler.tags = ['a','b','c']
    new_handler.notify_when = ['a','b','c']
    print(new_handler.serialize())
    print

# Generated at 2022-06-23 06:15:15.215626
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:15:20.366496
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    """
    Validate the handler task include constructor:
    """
    data = dict(
        handler_name='test_handler',
        tasks=[
            dict(action=dict(module='setup', args=''))
        ]
    )
    handler_task_include = HandlerTaskInclude.load(data)

    assert handler_task_include.__class__.__name__ == 'HandlerTaskInclude'
    assert handler_task_include._role is None
    assert handler_task_include._block is None
    assert handler_task_include._task_include is None
    assert handler_task_include.name == 'test_handler'

# Generated at 2022-06-23 06:15:21.009982
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:21.763746
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:15:32.274949
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # following lines for debugging and testing
    import sys
    import os.path
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))))))
    from ansible.playbook.hosts import Hosts
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    hosts = Hosts()
    host = Host(name='127.0.0.1', port=22)
    hosts.add(host)
    variable_manager = VariableManager(loader=loader, hosts=hosts)


# Generated at 2022-06-23 06:15:42.841498
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        block={"tasks": ["tasks/main.yml"]},
        role="role1",
        task_include={"name": "role1", "static": "yes"}
    )
    handler.static = True
    handler.tags = []
    handler.when = []
    handler.run_once = False
    handler.always_run = True
    handler.auto_resolve = False

    assert handler.get_vars == handler._get_vars
    assert handler.block == {"tasks": ["tasks/main.yml"]}
    assert handler.role == "role1"
    assert handler.task_include == {"name": "role1", "static": "yes"}


# Generated at 2022-06-23 06:15:54.380930
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # arguments for HandlerTaskInclude
    block = None
    role = None
    task_include = None

    # arguments for task_include
    uuid = AnsibleUnicode("uuid")
    variable_manager = None
    loader = None

    host = Host("hostname", task_vars={"ansible_sudo_pass": "password"})

    t = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    t.name = "name"
    t.action = "action"
    t.args = "args"
    t.when = "when"
    t.async_val = "async_val"
    t.poll_inter

# Generated at 2022-06-23 06:16:04.307052
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Arrange
    data = '''
---
- hosts: localhost
  vars:
    myvar: myvalue
  handlers:
    - include: other_handlers.yml
      tags:
        - always
'''

    # Act
    handler = HandlerTaskInclude.load(data)

    # Assert
    assert data is not None
    assert handler.block is not None
    #assert handler.block.name == 'other_handler.yml'
    assert handler.role is not None
    assert handler.tags is not None
    assert len(handler.tags) == 1
    assert handler.tags[0] == 'always'
    assert handler.always is True

# Generated at 2022-06-23 06:16:18.646093
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    print("Constructor check for class HandlerTaskInclude")
    assert hasattr(handler, '_load_role_tasks_from_directive')
    assert hasattr(handler, '_load_tasks_from_directive')
    assert hasattr(handler, '_load_tasks_from_file')
    assert hasattr(handler, '_load_tasks_from_role')
    assert hasattr(handler, '_load_tasks_from_vars_files')
    assert hasattr(handler, '_load_tasks_from_yaml')
    assert hasattr(handler, '_load_tasks_from_yaml_file')
    assert hasattr(handler, '_resolve_file_name')
    assert hasattr(handler, 'load')
    assert hasattr

# Generated at 2022-06-23 06:16:19.139276
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:20.207495
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # check_options
    # load_data
    # load
    pass

# Generated at 2022-06-23 06:16:21.591789
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

# Generated at 2022-06-23 06:16:22.166888
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-23 06:16:26.636085
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        any_errors_fatal=True,
        handlers=['common'],
        listen='test_event'
    )

    handler = HandlerTaskInclude.load(data)

    assert handler.any_errors_fatal is True
    assert handler.handlers == ['common']
    assert handler.listen == 'test_event'

# Generated at 2022-06-23 06:16:37.190413
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # import ansible.constants as C

    # C.HOST_KEY_CHECKING = False

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=["tests/inventory"]))
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    task = {'hosts': 'localhost', 'tasks': [{'debug': {'var': 'hostvars[inventory_hostname]'}}]}

# Generated at 2022-06-23 06:16:39.518433
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    HandlerTaskInclude.load
    '''

    # test load method of HandlerTaskInclude class
    h = HandlerTaskInclude()
    assert h.load(dict(listen='yum-updated')) is not None

# Generated at 2022-06-23 06:16:47.405139
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    data = {
        'name': 'test',
        'include': 'test',
        '_role_include': 'test',
        '_task_include': 'test',
        '_role': 'test',
        '_block': 'test'
    }

    block = Block.load(data, task_include=TaskInclude(), role=Role(), loader=None, variable_manager=None)
    role = Role()
    task = Task.load(data, block=block, role=role, loader=None, variable_manager=None)
    task_include = TaskInclude

# Generated at 2022-06-23 06:16:52.271501
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # data = {
    #     'action': 'foo',
    #     'listen': 'test_listen',
    #     'tags': ['test']
    # }
    # handler = HandlerTaskInclude().load(data)

    # assert handler._role.get_name() == 'test_listen'
    # assert handler._tags == set(['test'])
    pass

# Generated at 2022-06-23 06:16:53.982501
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({
        'include': 'foo.yml'
    })

# Generated at 2022-06-23 06:16:56.149720
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({'a':'b'}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:17:05.753743
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    data = {
        "name": "test",
        "include": "test.yml",
    }

    host = Host("test")
    host = Host(name = "test")
    loader = DataLoader()
    variable_manager = VariableManager()

    handler = HandlerTaskInclude.load(
        data = data,
        block = host,
        role = None,
        task_include = None,
        variable_manager = variable_manager,
        loader = loader)
    assert handler.module_name == "include"
    assert handler.module_args == {
        "free-form": "test.yml",
        "_raw_params": "test.yml"
    }
    assert handler.name

# Generated at 2022-06-23 06:17:07.410991
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:17:18.374741
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    :func:`Handler.load`
    """

    import pytest

    # Test: load HandlerTaskInclude handler
    # Fixture: load
    # Assertion: load HandlerTaskInclude handler
    assert (load(
        data={
            'include': 'tasks/main.yml',
            'listen': 'run-me',
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    ) is not None)


# Generated at 2022-06-23 06:17:22.436175
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude(block=None, role=None, task_include=None)


if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:17:24.195740
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    assert t.load('tests/fixtures/handler.yml') is not None

# Generated at 2022-06-23 06:17:36.616416
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    handler = HandlerTaskInclude()

    assert handler.name != None, "handler name is None"
    assert handler.delegate_to == None, "handler delegate_to is not None"
    assert handler.become == None, "handler become is not None"
    assert handler.become_method == None, "handler become_method is not None"
    assert handler.become_user == None, "handler become_user is not None"
    assert handler

# Generated at 2022-06-23 06:17:37.238744
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:17:38.296158
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True # TODO: implement your test here

# Generated at 2022-06-23 06:17:41.024194
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:17:46.512703
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

    # Invoke class method load to return an instance of HandlerTaskInclude
    handler_test = handler_task_include.load(
        data='',
        block='',
        role='',
        task_include='',
        variable_manager='',
        loader=''
    )
    assert isinstance(handler_test, HandlerTaskInclude)

# Generated at 2022-06-23 06:17:47.008910
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:17:50.489812
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  #TODO: refatorar, teste falha por causa do block, role e variable_manager
  assert HandlerTaskInclude.load({ 'include': 'test.yml' }) is not None



# Generated at 2022-06-23 06:17:51.037373
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:00.829353
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import add_all_plugin_dirs
    import ansible.constants as C
    import unittest
    import os

    class TestHandlerTaskInclude(unittest.TestCase):

        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.groups = ['ungrouped']
            self.inventory = Inventory

# Generated at 2022-06-23 06:18:01.444938
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:08.969906
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude.load(
        data={
            'name': 'foo',
            'include': 'first',
            'listen': 'bar'
        },
        block=None,
        role=None,
        task_include=None
    )

    assert hti.name == 'foo'
    assert hti.include == 'first'
    assert hti.listen == 'bar'
    assert hti.block == None
    assert hti.role == None
    assert hti.task_include == None

# Generated at 2022-06-23 06:18:10.514620
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    handler = HandlerTaskInclude()

    assert handler is not None


# Generated at 2022-06-23 06:18:11.884605
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load({})

# Generated at 2022-06-23 06:18:22.842158
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    # Create a fake Role instance, this is required for the host tasks
    role = Role()
    role._role_path = '/etc/ansible/roles/foo/'

    # Empty play
    play = Play().load({'name': 'fake play',
                        'hosts': 'source_hosts'})

    # Empty task, this is required by the load method
    task = Task()

    # # Empty block, this is required by the load method
    # block = Block()

    # Setup a fake host
    test_host = Host(name="testhost")

    # Setup a fake

# Generated at 2022-06-23 06:18:23.608974
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()

# Generated at 2022-06-23 06:18:31.731932
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # initialize the class HandlerTaskInclude without parameters
    HandlerTaskInclude()
    # initialize the class HandlerTaskInclude with parameters
    HandlerTaskInclude(block=None, role=None, task_include=None)
    # initialize the class HandlerTaskInclude with parameters
    #HandlerTaskInclude(block=None, role=None, task_include=None).check_options(data=None, ds=None)

# Generated at 2022-06-23 06:18:42.652616
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.template.templar import Templar

    inventory = dict(
        host_list = {},
        group_list = {
            'all': Group(name = 'all'),
            'ungrouped': Group(name = 'ungrouped'),
        },
    )

# Generated at 2022-06-23 06:18:48.814338
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    block=None
    role=None
    task_include=None
    data = dict(
        include_tasks=dict(
            file='/tmp/sample.yml',
            tags=['hello','world']
        )
    )

    handler = HandlerTaskInclude.load(data, block, role, task_include)
    assert handler.get_name() == 'include_tasks'
    assert handler.get_file() == '/tmp/sample.yml'
    assert handler.get_args() == dict(tags=['hello','world'])

# Generated at 2022-06-23 06:18:58.603997
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict()
    data['include'] = "{{ some_var }}"
    data['static'] = "some_value"
    data['address'] = "some_address"
    data['name'] = "some_name"
    data['action'] = "some_action"
    data['forks'] = 1
    data['listen'] = "some_value"

    handler = HandlerTaskInclude.load(data)
    assert handler is not None
    assert handler.get_name() == "TASK: [some_name]"
    assert handler.has_triggered() is False
    assert handler.is_valid() is False

    handler.set_loader(None)
    assert handler.get_loader() is None

    handler.set_variable_manager(None)
    assert handler.get_variable_manager() is None

# Generated at 2022-06-23 06:19:09.849541
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=vars_manager, host_list=[])

    handler = HandlerTaskInclude.load(
        {
            'name': 'meta/main.yml',
            'include_vars': {'file': 'meta/vars.yml'},
            'include_tasks': {'name': 'meta/tasks.yml'},
        },
        loader=loader,
        variable_manager=vars_manager,
    )
    h = handler.get_handler(inventory, loader)

    assert handler.include_task is None
    assert handler

# Generated at 2022-06-23 06:19:13.552919
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data='myhandler', block='tasks', role=None, task_include=None, variable_manager=None, loader=None)
    assert handler is not None

# Generated at 2022-06-23 06:19:15.275253
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert True

# Generated at 2022-06-23 06:19:16.431881
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:19:26.168671
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import merge_hash

    # Fake Ansible context
    fake_loader = "fake_loader"
    fake_inventory = InventoryManager(loader=fake_loader, sources=None)
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    fake_play_context = PlayContext()


# Generated at 2022-06-23 06:19:27.334420
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()

# Generated at 2022-06-23 06:19:39.039683
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.block import Handler as BlockHandler
    from ansible.playbook.play import Play

    block = Block()
    play = Play()
    play.handlers = []
    block.play = play
    block.handlers = []

    # test the case where the element is a task
    assert HandlerTaskInclude.load({'listen': 'something'}, block=block) is None
    assert HandlerTaskInclude.load({'listen': 'something'}, block=block, task_include=True)

    # test the case where the element is a handler
    assert HandlerTaskInclude.load({'notify': 'something'}, block=block) is None

# Generated at 2022-06-23 06:19:46.919751
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    host = Host()
    block = []
    role = None
    task_include = None
    data = {
        'include': 'notify_handler'
    }

    handler = HandlerTaskInclude.load(data, block, role, task_include, host.get_vars())
    assert handler is not None

# Generated at 2022-06-23 06:19:47.462411
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:19:47.990781
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude

# Generated at 2022-06-23 06:19:55.852100
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('\n---- test_HandlerTaskInclude_load ----')
    import ansible.playbook
    import ansible.playbook.task_include
    import ansible.playbook.handler

    tqm = ansible.playbook.TaskQueueManager(
        inventory=ansible.inventory.Inventory(host_list=['foo']),
        variable_manager=ansible.playbook.variable_manager.VariableManager(),
        loader=ansible.playbook.loader.PlaybookLoader([])
    )

# Generated at 2022-06-23 06:19:56.474489
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:19:59.752801
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

    assert handler is not None

# Generated at 2022-06-23 06:20:01.582571
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load({'include': 'test.yaml'}, task_include='listen')

# Generated at 2022-06-23 06:20:13.017640
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


    #Inventory
    host = Host(name="localhost", port=22, variables={'ansible_connection': 'local'})
    group = Group(name="all", hosts=[host], variables={})
    inventory = [host, group]

    #VariableManager
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager.set_inventory(inventory)

    #HandlerTaskInclude

# Generated at 2022-06-23 06:20:19.761234
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class FakeTaskInclude:
        def __init__(self):
            self.VALID_INCLUDE_KEYWORDS = ['tasks']
        def check_options(self, task_include, data):
            return task_include
        def load_data(self, data, variable_manager=None, loader=None):
            return data
    test_data = {
        'name': 'myhandler',
        'tasks': [
            { 'action': '/path/to/foo', 'tags': 'bar' }
        ],
        'defaults': {
            'name': 'myhandler',
            'listen': '',
        }
    }
    results = HandlerTaskInclude.load(test_data, task_include=FakeTaskInclude())
    assert results['name'] == 'myhandler'

# Generated at 2022-06-23 06:20:31.599227
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import sys
    import yaml

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 06:20:32.648335
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False

# Generated at 2022-06-23 06:20:36.167882
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude('task_include')

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:20:45.944423
# Unit test for constructor of class HandlerTaskInclude

# Generated at 2022-06-23 06:20:54.665774
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'handlers': [{'name': 'print_success', 'listen': 'print_success'}]}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    print(HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader))

if __name__ == '__main__':
    # Test
    test_HandlerTaskInclude_load()

    print('Module test sucess')

# Generated at 2022-06-23 06:21:03.974974
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os
    import tempfile

    current_directory = os.path.dirname(__file__)

    # create an inventory with some hosts
    test_inventory = tempfile.NamedTemporaryFile()
    test_inventory.write(b'[webservers]\nweb1\nweb2\n[dbservers]\ndb1\ndb2\n')
    test_inventory.flush()

    # create a VariableManager with a few variables
    var_manager = VariableManager()
    var_manager.extra_vars = {'my_var': 'my_value'}
    inventory = InventoryManager(loader=None, sources=[test_inventory.name])
    var_manager.set_inventory(inventory)

   

# Generated at 2022-06-23 06:21:07.706370
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test1: supported keywords
    handler = HandlerTaskInclude.load({'name': 'test', 'action': 'test', 'include': 'test'})
    assert handler is not None

    # test2: unsupported keywords
    handler = HandlerTaskInclude.load({'name': 'test', 'action': 'test', 'include': 'test', 'unsupported': 'test'})
    assert handler is None

# Generated at 2022-06-23 06:21:16.960488
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        handler='main.yml',
    )
    block = []
    role = []
    task_include = []
    variable_manager = []
    loader = []

    handler = HandlerTaskInclude.load(
        data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )

    assert HandlerTaskInclude.__name__ == handler.__class__.__name__



# Generated at 2022-06-23 06:21:19.339131
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    try:
        HandlerTaskInclude()
    except NameError as e:
        assert False, "HandlerTaskInclude() raised NameError unexpectedly!"

# Generated at 2022-06-23 06:21:22.426149
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {
        "include_tasks": "./test.yml",
    }

    handler = HandlerTaskInclude.load(test_data)
    assert handler



# Generated at 2022-06-23 06:21:30.265010
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook import block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Create a Task.
    t = Task()
    t._role = None
    t._parent = 'test'

    # Create a Host object
    h = Host()
    h.name = 'test'
    h.get_vars.side_effect = lambda: {}

    # Create a Block object
    b = block.Block()
    b.vars = dict()
    b._parent = h
    b._role = None

    # Create VariableManager object
    v = Variable

# Generated at 2022-06-23 06:21:32.421855
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert handlerTaskInclude is not None



# Generated at 2022-06-23 06:21:33.477369
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude()

# Generated at 2022-06-23 06:21:38.457859
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()
    data = {
        'name': 'test',
        'include': 'test.yml'
    }

    handler = hti.load(data)

    assert handler.name == 'test'
    assert handler.include == 'test.yml'

# Generated at 2022-06-23 06:21:49.785516
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    h = Host(name='host1')
    g = Group(name='testgroup')
    g.add_host(h)
    i = InventoryManager()
    i.add_group(g)

    test_data = [
        {
            'name': 'sample',
            'include': 'sample.yml'
        }
    ]

    result = HandlerTaskInclude.load(test_data, inventory=i)

    assert isinstance(result, HandlerTaskInclude)
    assert result._valid_attributes['include'] == ['sample.yml']
    assert result._valid_attributes['name'] == 'sample'

# Generated at 2022-06-23 06:21:54.105960
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-23 06:21:55.095387
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()


# Generated at 2022-06-23 06:21:57.544982
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data={'name':'some_name'})
    assert handler.name == 'some_name'

# Generated at 2022-06-23 06:22:09.562602
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.include_task import IncludeTask
    import ansible.constants as C
    import sys
    import yaml

    variable_manager = VariableManager()
    loader = DataLoader()

    # Make sure we're not having any issues with ansible.constants

# Generated at 2022-06-23 06:22:18.714179
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.handler import Handler
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    block = Block(
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_role=None,
        loop=None,
        vars=VariableManager(),
        defaults=VariableManager()
    )
    

# Generated at 2022-06-23 06:22:21.015576
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

print(HandlerTaskInclude.__doc__)


# Generated at 2022-06-23 06:22:22.609426
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-23 06:22:30.462255
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    import pytest

    data = dict()
    data['listen'] = 'true'
    data['name'] = 'name'
    data['include'] = 'include'
    data['tags'] = 'tags'
    data['run_once'] = 'run_once'
    data['when'] = 'task'
    data['local_action'] = 'local_action'

    # Initialization of

# Generated at 2022-06-23 06:22:31.270550
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-23 06:22:39.676553
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.block import Block

    array_var = {}
    variable_manager = DummyVariableManager(array_var)
    loader = DummyDataLoader()

    data = {
      'include': 'test_handler_include'
    }

    block = Block(parent_block=None)
    role = None
    task_include = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert handler is not None
    assert handler.handler_block.block is block
    assert handler.handler_block.role is role
    assert handler.handler_block.task_include is task_include
    assert handler.include_tasks is not None
    assert type(handler.include_tasks) == list

# Generated at 2022-06-23 06:22:41.791752
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data=-1, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:22:50.072202
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    task_include = {'tags': [], 'name': 'Test' }
    data = {'include': 'foo.yml'}
    handler = HandlerTaskInclude.load(data=data, block=None, role=None, task_include=task_include, variable_manager=None, loader=None)
    assert handler.get_name() == 'Test'
    assert handler.tags == []
    handler.load_data(data)
    assert handler.static is True
    assert handler.include_tasks is not None

# Generated at 2022-06-23 06:23:03.758975
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # DEBUG
    import sys
    import pdb
    pdb.Pdb(stdout=sys.__stdout__).set_trace()
    # END DEBUG

    # TODO: mock variables to be stored in variable_manager
    # TODO: mock AnsibleLoader to be returned from loader
    # TODO: mock DataLoader to be returned from AnsibleLoader.get_basedir
    # TODO: mock AnsibleFileIncludeLoader to be returned from DataLoader.get_file_loader

    # TODO: create mock objects for all parameters of method load of class HandlerTaskInclude

    # TODO: call method load of class HandlerTaskInclude

# Generated at 2022-06-23 06:23:10.477419
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    h = Host('name')
    b = Block(hosts=[h])
    t = Task(block=b)
    v = VariableManager()
    hti = HandlerTaskInclude(block=b, task_include=t, variable_manager=v)
    assert hti._block == b

# Generated at 2022-06-23 06:23:17.279728
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    import os
    import sys
    import yaml
    from ansible.module_utils.six import iteritems
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block

    test_dir = os.path.dirname(__file__)
    data_dir = os.path.join(test_dir, 'data')

    results = dict()

    # Load the test data file

# Generated at 2022-06-23 06:23:24.109909
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    H=HandlerTaskInclude()
    # assert H.__doc__!=None
    # assert H.name=="listen"
    # assert H.block== None
    # assert H.role == None
    # assert H.task_include == None
    # assert H._role_name == None
    # assert H._block_name == None

    data = dict(
        include=dict(
            file='/path/to/main.yml',
            _ansible_no_log=True,
            _ansible_verbosity=4,
            _ansible_check_mode=True,
        )
    )
    variable_manager = object()
    loader = object()
    handler = H.load(
        data,
        variable_manager=variable_manager,
        loader=loader
    )

# Generated at 2022-06-23 06:23:27.356199
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load({'include': 'file'}, variable_manager=None, loader=None)
    assert handler.include_file == 'file'

# Generated at 2022-06-23 06:23:30.141757
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler


# Generated at 2022-06-23 06:23:34.893998
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    variable_manager = None
    loader = None
    data = {
        'include': 'main.yml',
        'tags': 'notVital'
    }
    task_include = HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task_include is not None
