

# Generated at 2022-06-23 06:13:36.008319
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load({"action": {"module": "ping"}})
    assert handler.action.module == "ping"
    assert not hasattr(handler, 'task')
    assert handler.block is None
    assert handler.role is None

# Generated at 2022-06-23 06:13:46.459201
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.path import unfrackpath
    from units.mock.loader import DictDataLoader
    data = dict(
        name = "handler_task_include",
        include = dict(
            file = 'handler_task_include.yml'
        )
    )
    variable_manager = VariableManager()
    loader = DataLoader()
    unfrackpath(__file__)

# Generated at 2022-06-23 06:13:54.372228
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()

# Generated at 2022-06-23 06:13:55.666026
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)
    print(handler)

# Generated at 2022-06-23 06:14:06.325237
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_origin

    class Play_unit(Play_origin):
        def __init__(self, play_ds, play_basedir, loader, variable_manager, all_vars, block_list=None):
            self.hosts = ['host1']

    p = Play.load({'name': 'test', 'hosts': 'host1', 'tasks': [
        {'include': 'include_me.yaml'}
    ]}, loader=True, variable_manager=True)

    handler = class_handler(p)
    p_task_include = p._tasks[0]
    assert handler.name == 'include_me.yaml'
    assert handler._role._role_path == p_task_include.role._role_

# Generated at 2022-06-23 06:14:10.741770
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        include = dict(
            name="standard",
            with_items=[]
        ),
        listen="all"
    )
    task = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task.name == 'standard'

# Generated at 2022-06-23 06:14:17.134665
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print ("")
    print ("##### Begin units test_HandlerTaskInclude_load #####")
    print ("")

    ####
    # TODO: Implement your test cases here
    ####
    """
    #Simplest test case
    data = ""
    assert task.load(data) == ""

    data = {}
    task.load(data)
    """

    print ("##### End units test_HandlerTaskInclude_load #####")

# Generated at 2022-06-23 06:14:18.590343
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None,role=None,task_include=None)

# Generated at 2022-06-23 06:14:22.859880
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 0
    # TODO
    # obj = HandlerTaskInclude()
    # args = {}
    # kwargs = {}
    # result = obj.load(*args, **kwargs)
    # assert result == []

# Generated at 2022-06-23 06:14:25.362200
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Test empty constructor
    obj = HandlerTaskInclude()
    assert obj.task_include is None

# Generated at 2022-06-23 06:14:36.856096
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Unit test for a handler with 'include' and 'tags' keywords
    # TaskInclude.check_options method is called with task-include structure as
    # argument
    # VariableManager.extra_vars is called with argument {}

    # Dummy data for a handler with 'include' and 'tags' keywords
    data = {
        'include': 'tasks-main.yml',
        'tags': ['special'],
    }

    # Dummy task-include structure
    task_include = {
        'import_playbook': None,
        'include': 'tasks-main.yml',
        'include_role': None,
        'include_tasks': None,
        'tags': ['special'],
    }

    # Dummy VariableManager object

# Generated at 2022-06-23 06:14:49.167799
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    datastructure = {
        "include": "{{test_file}}"
    }
    handler = HandlerTaskInclude.load(
        data=datastructure,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )
    assert handler.static is False

# Generated at 2022-06-23 06:15:00.744202
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    # Load a host
    host = Host(name='host1')
    host.get_vars = host.get_variables
    # Load a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=DataLoader(), sources=''))
    variable_manager.get_vars(play=dict(vars=dict(key1='value1', key2='value2')))
    variable_manager._fact_cache = dict(facts1='test1', facts2='test2')

# Generated at 2022-06-23 06:15:02.204082
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h is not None

# Generated at 2022-06-23 06:15:12.946445
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    handler_task_include = HandlerTaskInclude()
    handler_task_include.action = "action"
    handler_task_include.name = "name"
    handler_task_include.block = []
    handler_task_include.always_run = True
    handler_task_include.notify = ["value1", "value2"]
    handler_task_include.tags = ["value1", "value2"]
    handler_task_include.when = ["value1", "value2"]
    handler_task_include.async_val = 100
    handler_task_include.poll = 10


# Generated at 2022-06-23 06:15:13.903504
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert HandlerTaskInclude.load_data() == None

# Generated at 2022-06-23 06:15:25.073820
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.handlers.when import When

    data = dict(
        name='test',
        tasks=[
            dict(include='test.yml'),
            dict(include='test2.yml', when='foobar')
        ]
    )

    task = Task.load(data=data)

    assert(task.block is not None)
    assert(len(task.block) == 2)

    task = task.block[0]
    assert(isinstance(task, TaskInclude))
    assert(task.when is None)

    task = task.block[1]
    assert(isinstance(task, TaskInclude))
    assert(isinstance(task.when, When))
    assert(task.when.when == 'foobar')

# Unit

# Generated at 2022-06-23 06:15:27.658157
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    This is a skeleton for the tests for class HandlerTaskInclude.
    '''
    pass

# Generated at 2022-06-23 06:15:41.737852
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test:
        handler:
            include: /tmp/foo.yml
            listen:     "{{ new_variable_name }}"
            foo:        bar
    """
    from ansible import utils
    from ansible.inventory import Inventory
    from ansible.playbook import PlayBook
    from ansible.vars import VariableManager
    from ansible.utils.vars import isidentifier

    options = {
        'module_path': '%s/ansible-modules-core' % os.path.dirname(__file__),
        'listhosts': False,
        'syntax': False,
        'connection': 'local',
        'module_language': 'C',
    }


# Generated at 2022-06-23 06:15:47.216490
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
	a = HandlerTaskInclude()
	assert a.VALID_INCLUDE_KEYWORDS == ('tasks', 'vars', 'handlers', 'defaults', 'pre_tasks', 'post_tasks', 'role', 'listen')
	assert  a.load(data={'include': 'test.yml'}, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:15:56.622712
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    """
    # this is not working from git bash --is it because class Host is not defined?
    h = Host(name="test_host")
    hti.add_host(h)
    """
    assert hti.get_name() is None
    hti.set_name("handler_name")
    assert hti.get_name() == "handler_name"
    hti.notify_always = True
    assert hti.notify_always is True
    hti.notify_on_skipped = True
    assert hti.notify_on_skipped is True
    hti.notify_on_unreachable = True
    assert hti.notify_on_unreachable is True
    hti.notify_on_failed = True
    assert h

# Generated at 2022-06-23 06:16:06.799478
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import ansible.playbook
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.template
    #host = ansible.inventory.host.Host(name="localhost")
    host = "localhost"
    host_vars = {}
    variables = ansible.vars.manager.VariableManager(loader=None)
    variables.extra_vars = host_vars
    variables.options_vars = {}
    #block = ansible.playbook.block.Block()
    block = None
    #play = ansible.playbook.Play()
    play = None
    #task = ansible.playbook.task.Task()
    task = None
    t = HandlerTaskInclude(block=block, play=play, task=task)
    print(t)

# Generated at 2022-06-23 06:16:13.740210
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    f1 = dict(
        name = "add_spoof_iptables",
        listen = "spoof_add_iptables"
    )

    h1 = HandlerTaskInclude.load(f1, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert (h1.name == "add_spoof_iptables")
    assert (h1.listen == "spoof_add_iptables")

    # TODO: need to add test for dicts that are not in the VALID_INCLUDE_KEYWORDS set.
    #       currently, they are simply ignored.

# Generated at 2022-06-23 06:16:22.324580
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    h = Handler(play=None, task=None, handler_block=None, role=None)
    assert isinstance(h, Handler)
    assert isinstance(h, HandlerTaskInclude)


# Generated at 2022-06-23 06:16:31.343924
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    yaml_input = '''- name: add handler to file system
  include: tasks/handlers/main.yml
'''
    task_include_obj = HandlerTaskInclude(block=None, role=None, task_include=None)
    data = task_include_obj.load_data(yaml_input, variable_manager=None, loader=None)
    handler = task_include_obj.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert handler.__class__.__name__ == 'HandlerTaskInclude', 'Unexpected object type %s' % handler.__class__.__name__

# Generated at 2022-06-23 06:16:32.855249
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 06:16:44.225332
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    def function(*args, **kwargs):
        return True
    l = [1, 2]
    d = {'a': 1, 'b': 2}
    data = dict(
        include=d,
        static='test',
    )

    # Non-existing file
    try:
        HandlerTaskInclude.load(data, variable_manager=l, loader=l)
    except AnsibleError as e:
        print("Message:", e.message)

    # Include
    class i:
        def check_options(self, d, data):
            return d
        def load_data(self, d, variable_manager=None, loader=None):
            return True

# Generated at 2022-06-23 06:16:53.829523
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    pwd = os.getcwd()

    current_path = os.path.dirname(os.path.abspath(__file__))
    vars_path = os.path.join(current_path, '../vars')

# Generated at 2022-06-23 06:16:56.421721
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = [ ]
    a = HandlerTaskInclude.load(data=data)
    assert a is not None

# Generated at 2022-06-23 06:17:06.005452
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class MockVariableManager():
        pass

    class MockLoader():
        pass

    class MockInventory():
        pass

    class MockBlock():
        pass

    class MockRole():
        pass

    class MockTaskInclude():
        pass

    include_data = {
        'any_attribute' : 'any_value'
    }

    variable_manager = MockVariableManager()
    loader = MockLoader()
    inventory = MockInventory()
    block = MockBlock()
    role = MockRole()
    task_include = MockTaskInclude()

    handler = HandlerTaskInclude.load(
        include_data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )


# Generated at 2022-06-23 06:17:08.585542
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    print(t)

if __name__ == "__main__":
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:17:20.764981
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    variable_manager = None
    loader = None
    data = {
        'include': './my_tasks.yml',
        'loop': [
            {'fruits': 'apple'},
            {'fruits': 'cherry'},
            {'fruits': 'banana'},
        ],
        'loop_control': {
            'loop_var': 'item'
        },
    }
    block = None
    role = None
    task_include = None
    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)
    assert handler.include is not None
    assert handler.loop is not None
    assert handler.loop_control is not None
    # assert handler.include.include_role is None
    # assert handler.include.include_tasks is not

# Generated at 2022-06-23 06:17:24.490872
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {'include': 'tasks/main.yml'}
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # assert isinstance(result, Handler)

# Generated at 2022-06-23 06:17:31.820614
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''Unit test for constructor of class HandlerTaskInclude'''

    '''
    HandlerTaskInclude.load()
    '''
    # data = dict(
    #     test_str='str',
    #     test_int=0,
    #     test_bool=False,
    #     test_list=[],
    #     test_dict=dict()
    # )
    # handler = HandlerTaskInclude.load(
    #     data,
    #     block=None,
    #     role=None,
    #     task_include=None,
    #     variable_manager=None,
    #     loader=None
    # )
    # assert isinstance(handler, HandlerTaskInclude) == True
    pass

# Generated at 2022-06-23 06:17:40.817086
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        name="test",
        include=dict(
            static="this is static",
            dynamic="{{ babar }}",
            list=["toto", "titi", "tata"],
            dict=dict(foo="bar", hello="world")
        )
    )

    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # create a templar object
    tqm = None
    variables = dict()
    loader = None
    templar = Templar(loader=loader, variables=variables)

    # create a block object
    block = ansible.playbook.block.Block()
    block.vars = dict

# Generated at 2022-06-23 06:17:50.758207
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Variables for test
    data_handlers_path = {
        'name' : 'TestName',
        'include' : 'TestInclude',
        'listen' : 'TestListen'
    }
    block = 'TestBlock'
    role = 'TestRole'
    task_include = 'TestInclude'
    # Start test
    test_object = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    result = test_object.check_options(
        test_object.load_data(data_handlers_path, loader='TestLoader'),
        data_handlers_path
    )
    # Import variables
    if result is None:
        print('Error')

# Generated at 2022-06-23 06:18:00.571332
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # Method load calls method load_data which calls method load_tasks
    # which calls method load_task which calls method _load_tags which
    # calls method _load_args which calls method _load_kwargs which
    # calls method _load_tokens which calls method _load_token which
    # calls method _load_attributes_with_tokens which calls method
    # _load_attributes_with_tokens which calls method _validate_attributes
    # which calls method _validate_one_attribute

    # If a tag is missing from from data then the method _load_attributes_with_tokens
   

# Generated at 2022-06-23 06:18:03.413163
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert hti
    assert type(hti) is HandlerTaskInclude


# Generated at 2022-06-23 06:18:11.883897
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    import os
    import sys
    import yaml
    from collections import namedtuple

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.config.manager import ConfigManager

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.executor.task_queue_manager import TaskQueueManager

    # (1) read configuration
    config = ConfigManager()
    configuration = config.data

    # (2) create variable manager
    variable_manager = VariableManager()

    # (3) create inventory and pass to variable manager
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager.set_inventory(inventory)

    #

# Generated at 2022-06-23 06:18:22.841968
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # import libraries
    import os
    import yaml
    from collections import namedtuple

    # from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # Create test objects
    #
    # -------------------------
    # | VariableManager       |
    # -------------------------
    # |

# Generated at 2022-06-23 06:18:24.849734
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:37.395557
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import os
    import sys
    import inspect
    import ansible.playbook
    import ansible.inventory.host
    import ansible.playbook.task_include
    from six.moves import configparser
    from six.moves import StringIO

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    p = ansible.playbook.Playbook.load(os.path.join(os.path.dirname(__file__), '../../test_data/ansible_playbook/playbook_syntax.yml'), variable_manager=ansible.playbook.variable_manager.VariableManager())
    host = p.get_hosts(pattern='host_pattern_hostname_test')[0]
    cwd = os.path

# Generated at 2022-06-23 06:18:46.350120
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader

    hti = HandlerTaskInclude()

    # assert isinstance(hti, Handler), "HandlerTaskInclude is not a subclass of Handler"
    # assert isinstance(hti, TaskInclude), "HandlerTaskInclude is not a subclass of TaskInclude"

    host = ""
    runner_path = ""
    variable_manager = ""
    loader = DataLoader()
    #assert hti.run(host, runner_path, variable_manager, loader), "Test for 'run' - Failed"

    task_path = ""

# Generated at 2022-06-23 06:18:51.953267
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    block = None
    role = None
    task_include = None
    h = HandlerTaskInclude(block=block, role=role, task_include=task_include)
    assert h is not None

# Generated at 2022-06-23 06:18:52.669653
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:19:04.459420
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create play, host, group and task objects
    ds = dict(name="test", hosts=["127.0.0.1"], tasks=[dict(action=dict(module="command", args="echo hello"))])
    loader = DataLoader()
    play = Play.load(ds, loader=loader)
    host = Host(name="127.0.0.1")
    group = Group(name="test")
    task = play.get_tasks()[0]

    # Create inventory
    inventory = InventoryManager

# Generated at 2022-06-23 06:19:13.929604
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser

    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    from ansible.playbook.include import Include

    from ansible.template import Templar

    # Create a host / group
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Host(loader=loader)
    group = Group(name='test_group')

# Generated at 2022-06-23 06:19:16.667604
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h != None

# Generated at 2022-06-23 06:19:19.823630
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.VALID_INCLUDE_KEYWORDS == HandlerTaskInclude.VALID_INCLUDE_KEYWORDS
    assert h.VALID_INCLUDE_KEYS == HandlerTaskInclude.VALID_INCLUDE_KEYS

    # assert HandlerTaskInclude.load(data=[], block=None, role=None, task_include=None, variable_manager=None, loader=None)
    # test load

# Generated at 2022-06-23 06:19:21.079097
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test = HandlerTaskInclude()
    assert test is not None


# Generated at 2022-06-23 06:19:29.102608
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {"listen": "task1"}

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/root/ansible-new/lib/ansible/inventory/manager.py'])
    variable_manager.set_inventory(inventory)

    play = Play()
    block = Block(play=play)
    role = Role()
    play.role = role


# Generated at 2022-06-23 06:19:34.656337
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleParserError
    from ansible.inventory.host import Host
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    host = Host(name='testhost')
    host.set_variable('var', 'somestring')
    included_file = IncludedFile('includedfile', 'includer')
    task_include = TaskInclude(included_file=included_file)
    task = Task()
    templar = Templar(loader=None, variables={})
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:19:49.603408
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    # Constructor test
    hti = HandlerTaskInclude()
    assert isinstance(hti, HandlerTaskInclude)
    assert isinstance(hti, Handler)
    assert isinstance(hti, TaskInclude)

    # load
    hti = HandlerTaskInclude.load(dict(
        include='abc.yml',
        name='a',
        tags=['a'],
        register='b',
        ignore_errors=False,
        listen='c',
    ))

    assert isinstance(hti.get_name(), AnsibleUnicode)
    assert hti.get_name() == 'a'
    assert hti.has_triggered() is False
    assert hti.listen_name == 'c'


# Generated at 2022-06-23 06:20:01.314735
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    variable_manager._substitution_results = {}

    data = dict(
        name='A handler',
        action='debug',
        debug='yes'
    )

    HandlerTaskInclude.load(data, variable_manager=variable_manager, loader=loader)


#----
# Unit

# Generated at 2022-06-23 06:20:05.005269
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        action=dict(
            module='debug',
            args=dict(msg='Hello world!')
        )
    )
    handler = HandlerTaskInclude.load(data)
    assert handler is not None

# Generated at 2022-06-23 06:20:11.699834
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    #pass
    data = 'main.yml'
    obj = HandlerTaskInclude.load('main.yml')
    print(obj.include_file)
    obj1 = HandlerTaskInclude.load('common.yml')
    print(obj1.include_file)
    obj2 = HandlerTaskInclude.load('common1.yml')
    print(obj2.include_file)

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:20:12.641582
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()

# Generated at 2022-06-23 06:20:17.324795
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
#   data = [{"listen": "key_changed", "name": "Test task", "debug": "var=hostvars[inventory_hostname]"}]
    data = [{"listen": "key_changed", "debug": "var=hostvars[inventory_hostname]"}]
    handler_task_include = HandlerTaskInclude.load(data)
    print(handler_task_include.task)
    if handler_task_include is None:
        raise Exception("Extraction failed")

# Generated at 2022-06-23 06:20:23.622811
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    arguments = dict(
        block = 'TASK_BLOCK_MODIFIERS',
        role = None,
        task_include = None,
    )

    handler = HandlerTaskInclude(**arguments)
    arguments_data = dict(
        listen = 'test_listen',
        name = 'test_name',
    )

    handler.load_data(arguments_data)
    assert handler.listen == 'test_listen'
    assert handler.name == 'test_name'

#Unit test for method check_options of class HandlerTaskInclude

# Generated at 2022-06-23 06:20:25.002934
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude({'name': 'name'})


# Generated at 2022-06-23 06:20:32.583368
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {u'name': u'AnsiballZ_command', u'register': u'ansible_handler'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    result = HandlerTaskInclude.load(data, block=block, role=role, task_include=task_include,
                                     variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:20:44.210649
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Dummy ansible.inventory.host.Host()
    class Host:
        def __init__(self,name):
            self.name = name
    # dummy variables, useless for this test
    variables = {'host1': 'dummy1', 'host2': 'dummy2'}
    # Dummy ansible.playbook.variable_manager.VariableManager()
    class VariableManager:
        def __init__(self,inventory,loader,host=None):
            self.inventory = inventory
            self.loader = loader
        def get_vars(self,host,task):
            return variables

    # Dummy ansible.playbook.loader.Loader()
    class Loader:
        pass

    # Dummy ansible.playbook.block.Block()

# Generated at 2022-06-23 06:20:53.991444
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # task_include class is used as a mock
    data = {u'include': u'routing-options', u'ingore_errors': True}
    expected_result = {
        'include': {
            'name': 'routing-options'
        },
        'ignore_errors': True,
        'name': 'include'
    }
    task_include = TaskInclude(block=None, role=None, task_include=None)
    # load_data method is used as a mock
    task_include.load_data = lambda x, y, z: x
    handler = HandlerTaskInclude.load(data, task_include=task_include)
    assert handler == expected_result

# Generated at 2022-06-23 06:21:00.712174
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    # data = {'include': 'blah.yml', 'name': 'foo', 'when': 'bar'}
    data = {}
    result = HandlerTaskInclude.load(data=data, loader=loader, variable_manager=variable_manager)
    print(result)
    assert False


# Generated at 2022-06-23 06:21:01.578200
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert 1==1


# Generated at 2022-06-23 06:21:05.011190
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        "listen": "httpd",
        "meta": {
            "host": "127.0.0.1"
        }
    }
    result = HandlerTaskInclude.load(data)
    assert result.name == "127.0.0.1"
    assert result.action == "meta"
    assert result.args == {'host': '127.0.0.1'}
    assert result.ignore_errors is False
    assert result.only_if == ''
    assert result.register == ''
    assert result.until == ''
    assert result.notify.__len__() == 0
    assert result.notify_when.__len__() == 0
    assert result.delegate_to == ''
    assert result.become is False
    assert result.become_user == ''
   

# Generated at 2022-06-23 06:21:15.979725
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = '''
- name: handler
- include: handler_include
- handler:
  - name: test_handler
    listen:
    - include_handler_handler_name
'''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    handler = HandlerTaskInclude.load(data, inventory=inventory, variable_manager=variable_manager)
    assert handler.__class__.__name__ == "Handler"

# Generated at 2022-06-23 06:21:24.896910
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    Block = MockBlock()
    Role  = MockRole()
    TaskInclude = MockTaskInclude()
    Handler = MockHandler()
    HandlerTaskInclude = HandlerTaskInclude(block=Block, role=Role, task_include=TaskInclude)

    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == TaskInclude.VALID_INCLUDE_KEYWORDS.union(('listen',))
    assert hasattr(HandlerTaskInclude, 'load')
    assert hasattr(HandlerTaskInclude, '__init__')
    assert hasattr(HandlerTaskInclude, 'check_options')
    assert hasattr(HandlerTaskInclude, 'load_data')


# Generated at 2022-06-23 06:21:32.456921
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    h = HandlerTaskInclude()
    a = Reserved()
    b = VariableManager(loader=None, inventory=None)
    c = AnsibleUnicode(b'message')
    d = Host()
    handler = h.load(a, block=b, role=c, task_include=d)
    return handler

# Generated at 2022-06-23 06:21:37.193710
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # Static method load returns an object of class HandlerTaskInclude
    #  when correct data passed
    from ansible.inventory.host import Host
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.inventory.vars_plugins import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    h = Host(name="test")
    v = AnsibleVaultEncryptedUnicode("test vault")
    hv = HostVars(host=h, vault_password=v)
    pc = PlayContext()
    b = Block()

# Generated at 2022-06-23 06:21:47.607451
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Copy/paste of test_TaskInclude_load
    t = TaskInclude()
    handler = t.load(
        dict(
            name="include",
            include="test.yml"
        )
    )

    assert isinstance(handler, Task)
    assert handler.name == "include"
    assert handler.action == AnsibleUnsafeText(u"test.yml")

    handler = t.load(
        dict(
            include="test.yml"
        )
    )

    assert isinstance(handler, Task)
    assert handler.name == "test.yml"
    assert handler.action == Ans

# Generated at 2022-06-23 06:21:59.047604
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'name': 'handler',
        'include': 'some_task'
    }
    handler = Handler.load(data, loader=None)
    assert isinstance(handler, HandlerTaskInclude)
    assert data['name'] == handler.name
    assert handler.get_safe_name() == 'handler'
    assert handler.listen is None
    assert handler.tags == set()
    assert handler.run_once == False
    assert handler.always_run == False
    assert handler.delegate_to == None
    assert handler.notify == []
    assert handler.poll == 0
    assert handler.register == None
    assert handler.until == []
    assert handler.retries == 3
    assert handler.delay == 0
    assert handler.with_items == []
    assert handler.include == None
    assert handler

# Generated at 2022-06-23 06:22:01.877720
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-23 06:22:05.399780
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Loading handler by using 'load' method of HandlerTaskInclude")


if __name__ == '__main__':
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:22:13.744700
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
#    HandlerTaskInclude(block=None, role=None, task_include=None)
    my_task_include = {
        "include": "tasks/name_of_playbook.yml",
        "static": "/path/to/playbook.yml",
        "name": "name_of_playbook.yml",
        "file": "/path/to/playbook.yml",
        "vars": [
            {
                "test": "test",
                "test2": "test2"
                }
            ],
        "tags": [
            "test",
            "test2"
            ],
        "when": "test",
        "with_items": [
            "test",
            "test2"
            ]
    }

# Generated at 2022-06-23 06:22:19.641750
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {}
    data['name'] = 'Test HandlerTaskInclude'
    data["include"] = ['subhandlers.yml']

    handler = HandlerTaskInclude.load(data)

    assert handler.name == 'Test HandlerTaskInclude'
    assert len(handler.tasks) == 1

# Generated at 2022-06-23 06:22:21.162763
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    HandlerTaskInclude.load(data={"include":"main.yml"}, task_include={"hosts":"all"})

# Generated at 2022-06-23 06:22:23.164712
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None

# Generated at 2022-06-23 06:22:26.128525
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    result = HandlerTaskInclude.load({'name': 'hello task'})
    assert result.get_name() == "hello task", "Handler load method return Handler instance"

# Generated at 2022-06-23 06:22:37.379905
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    def check_constructor(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
        return (handler != None)

    # Tests for 'name' parameter
    assert check_constructor({'name': 'listen'})
    assert check_constructor({'name': 'listen'})
    assert check_constructor({'name': 'listen'})
    assert check_constructor({'name': 'listen'})
    assert check_constructor({'name': 'listen'})

    # Tests for 'name' parameter
    assert not check_constructor({'name': 'some_string'})
    assert not check

# Generated at 2022-06-23 06:22:42.269824
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Check that have function load in class HandlerTaskInclude")
    print("Check class TaskInclude:")
    assert hasattr(TaskInclude, "load"), "no function load in class TaskInclude"
    print("Check class Handler:")
    assert hasattr(Handler, "load"), "no function load in class Handler"


# Generated at 2022-06-23 06:22:53.853573
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    # This requires the mock library to be installed:
        # pip install mock

    # Testing the method load of the class HandlerTaskInclude.

    import sys

    # Add the script's directory to the python path in order to import
    # the module
    sys.path.append("/home/alejandro/Python/ansible/lib/ansible/playbook")

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.ini import InventoryParser

# Generated at 2022-06-23 06:23:00.613558
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        'include': 'test_include.yaml',
        'tags': ['include-test']
    }
    result = HandlerTaskInclude.load(data)
    expected = {
        'include': 'test_include.yaml',
        'tags': [],
        'tasks': []
    }
    assert result == expected


# Generated at 2022-06-23 06:23:02.842538
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert HandlerTaskInclude.load(data={"include": "test.yml"})

# Generated at 2022-06-23 06:23:03.366373
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:04.848937
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()

# Generated at 2022-06-23 06:23:10.236739
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = "test_data1"
    block = "test_block1"
    role = "test_role1"
    task_include = "test_task_include1"
    variable_manager = "test_variable_manager1"
    loader = "test_loader1"

    handler = HandlerTaskInclude(block=block, role=role, task_include=task_include)

    assert handler is not None


# Generated at 2022-06-23 06:23:14.928317
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerObject = HandlerTaskInclude()
    assert HandlerObject.__class__ == HandlerTaskInclude
    assert HandlerObject.VALID_INCLUDE_KEYWORDS == {'block', 'role', 'task', 'tasks', 'tags', 'listen'}

# Generated at 2022-06-23 06:23:22.174763
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude()
    assert obj.__class__.__name__ == 'HandlerTaskInclude'

    #Handlers have no block, so it will be an empty string
    assert obj.block == ''
    assert obj.role is None
    assert obj.task_include is None
    assert obj.loop is None
    assert obj.loop_control is None
    assert obj.static == TaskInclude.static

    obj = HandlerTaskInclude(block='foo', role='bar', task_include='foobar', loop='foo', loop_control='bar')
    assert obj.__class__.__name__ == 'HandlerTaskInclude'

    assert obj.block == 'foo'
    assert obj.role == 'bar'
    assert obj.task_include == 'foobar'
    assert obj.loop == 'foo'
    assert obj

# Generated at 2022-06-23 06:23:33.308471
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    hosts = [
        'localhost'
    ]
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=hosts)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    play.handlers = []
    data = {
      'include': '{{ foo }}',
      'listen': 'tag_fail'
    }
