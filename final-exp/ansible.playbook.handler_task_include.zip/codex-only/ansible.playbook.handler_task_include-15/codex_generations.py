

# Generated at 2022-06-23 06:13:39.086413
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = dict(
        listen = 'TEST_HANDLER_TASK_INCLUDE'
    )
    handler = HandlerTaskInclude.load(data)
    assert handler.listen == 'TEST_HANDLER_TASK_INCLUDE'

# Generated at 2022-06-23 06:13:40.170649
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # Initialize handler
    handler = HandlerTaskInclude()
    assert handler is not None

# Generated at 2022-06-23 06:13:50.569342
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    test_data = {
        'name': 'test_name',
        'include_role': {
            'name': 'test_role',
            'tasks_from': 'foo'
        },
        'tags': ['test_tag'],
        'when': ['test_when'],
        'with_items': ['test_item']
    }

    handler = HandlerTaskInclude.load(test_data, variable_manager=None, loader=None)
    assert handler.name == test_data['name']
    assert handler.block == None
    assert handler.role == None
    assert handler.tags == test_data['tags']
    assert handler.when == test_data['when']
    assert handler.loop == test_data['with_items']


# Generated at 2022-06-23 06:13:52.779519
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()
    assert True



# Generated at 2022-06-23 06:13:56.633578
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    assert HandlerTaskInclude.load(
        data={
            'include': './handler.yml'
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    ) is not None


# Generated at 2022-06-23 06:14:00.837896
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # test constructor
    handler = HandlerTaskInclude(TaskInclude(None))
    # test inherited methods
    handler.load_data(None,None)
    handler.check_options(None,None)

# Generated at 2022-06-23 06:14:02.675264
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("Inside HandlerTaskInclude_load")
    # handler = Handler(None)
    # handler.load(None)



# Generated at 2022-06-23 06:14:03.568046
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    assert False # TODO: implement your test here

# Generated at 2022-06-23 06:14:10.610201
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.plugins.loader import vars_loader, action_loader

    my_play_context = PlayContext()
    my_host = 'host'
    my_inventory = InventoryManager(loader=DictDataLoader({my_host: {'hostvars': {'var5': 5}}}))
    vars_mgr = VariableManager(loader=vars_loader, inventory=my_inventory)

# Generated at 2022-06-23 06:14:20.184826
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    import os
    import yaml
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host = Host(name='localhost')
    group = Group(name='testgroup')
    group.add_host(host)
    inventory = [group]
    play_context = PlayContext()
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager.set_inventory(inventory)

    os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Generated at 2022-06-23 06:14:25.405867
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    error = None

    try:
        # Run method load
        # No error ?!
        assert HandlerTaskInclude.load(None) is not None
    except Exception as e:
        error = str(e)

    # Oups
    assert error is None, error

# Generated at 2022-06-23 06:14:33.945177
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars.manager import VariableManager

    vmanager = VariableManager()
    data = dict(
        name = 'test_value_name',
        listen = 'test_value_listen'
        )

    handler = HandlerTaskInclude(None, None, None)
    result = handler.check_options(
        handler.load_data(data, variable_manager=vmanager, loader=None),
        data
    )

    assert 'test_value_name' == result.name
    assert 'test_value_listen' in result.listen
    assert None == result.tags

# Generated at 2022-06-23 06:14:36.392867
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    my_task = HandlerTaskInclude(block=None, role=None, task_include=None)
    print(my_task)

# Generated at 2022-06-23 06:14:37.609626
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    hti = HandlerTaskInclude()

# Generated at 2022-06-23 06:14:49.802375
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars.manager import VariableManager

    vm = VariableManager()

    test = {
        'handlers': [
            {
                'name': 'test_handler_task_include',
                'listen': 'test_handler_task_include',
                'include': {'task': 'test_task_include.yml'},
            },
        ],
    }

    t = HandlerTaskInclude()
    handler = t.load(data=test['handlers'][0], variable_manager=vm)

    assert handler._role == None
    assert handler._block == None
    assert handler._task_include == None
    assert handler._name == 'test_handler_task_include'
    assert handler._listen == 'test_handler_task_include'
    assert handler._label == None

# Generated at 2022-06-23 06:14:52.075529
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude(None, None, None)

# Test that we can load a yaml file

# Generated at 2022-06-23 06:15:03.008130
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    import ansible.playbook
    import ansible.inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["myansible/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test for the load method
    block = ansible.playbook.Block()
    role = ansible.playbook.Role()
    task_include = ansible.playbook.TaskInclude()

    data = {
        'name': 'notify handlers',
        'listen': 'restart',
    }

    handler_task_include = HandlerTaskInclude.load

# Generated at 2022-06-23 06:15:13.739572
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude.load({
        'include': 'test.yml',
    })

    assert handler.static is False

    assert handler.loop is None
    assert handler.loop_control is None
    assert handler.loop_args is None
    assert handler.listen is None

    assert handler.name == 'test.yml'
    assert handler.action == 'include'
    assert handler.args == {}
    assert handler.delegate_to is None
    assert handler.local_action is False
    assert handler.notify is False
    assert handler.tracks is None
    assert handler.ignore_errors is False
    assert handler.register == ''
    assert handler.when is None
    assert handler.changed_when is None
    assert handler.failed_when is None
    assert handler.always_run is False

# Generated at 2022-06-23 06:15:16.193677
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load(data=None)
    assert handler is not None


# Generated at 2022-06-23 06:15:23.059044
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    '''
    This is a unit test for the constructor of the class HandlerTaskInclude

    This is to test if the constructor of the class HandlerTaskInclude runs.
    :return:
    '''
    # Create a HandlerTaskInclude object
    handler = HandlerTaskInclude()

    # Check if the HandlerTaskInclude object is an instance of Handler and TaskInclude
    assert isinstance(handler, Handler)
    assert isinstance(handler, TaskInclude)



# Generated at 2022-06-23 06:15:28.927332
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    print("**** TEST: test_HandlerTaskInclude() ****")
    obj_handler_task_include = HandlerTaskInclude("block=None", "role=None", "task_include=None")

    print("**** END OF TEST ****")

if __name__ == '__main__':
    test_HandlerTaskInclude()

# Generated at 2022-06-23 06:15:29.956302
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h_task_include = HandlerTaskInclude()
    h_task_include.load()

# Generated at 2022-06-23 06:15:31.276110
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass


# Generated at 2022-06-23 06:15:42.874297
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = '''
- name: Test handler
  listen: "wordpress_started"
  - name: Test task
    debug: msg='{{ hostvars[inventory_hostname]['inventory_dir'] }}'
'''

    import jinja2
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import get_all_plugin_loaders, get_loader
    from ansible.plugins.loader import add_all_plugin_dirs, add_plugin_dir
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:15:54.044749
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # arrange
    data = {"listen": "restart nginx"}
    block = None
    role = None
    task_include = None
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    inventory = Inventory([])
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager.set_inventory(inventory)
    expected_var_manager = VariableManager(loader=DataLoader())
    loader = DataLoader()

    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()

    # act
    result = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    # assert
    assert(result)

# Generated at 2022-06-23 06:15:57.005348
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert handler is not None
    print(handler)

# Generated at 2022-06-23 06:16:07.007626
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Arrange
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('127.0.0.1,'))
    inventory = variable_manager.get_inventory()

    test_host = inventory.get_host(Host('127.0.0.1'))
    block = Block(task_include=Task())
    data = [{'name': 'task1.yaml'}, {'name': 'task2.yaml'}]

    # Act
    handler = HandlerTaskInclude

# Generated at 2022-06-23 06:16:07.572592
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:16:22.121327
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.playbook.block import Block
    from ansible.playbook.block import BlockInclude
    from ansible.playbook.task import Task
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    handler_task_include_class_attributes = dict(HandlerTaskInclude.__dict__)
    handler_task_include_metaclass = type("handler_task_include_metaclass",
                                          (HandlerTaskInclude.__class__,),
                                          handler_task_include_class_attributes,
                                          )

    host_name_test = "host_name_test"

# Generated at 2022-06-23 06:16:33.665831
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    from ansible.module_utils._text import to_text

    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "include.yml": """
- include: '{{ item }}'
  with_items:
    - abc
    - def
"""
    })

    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    task = Task.load

# Generated at 2022-06-23 06:16:44.446224
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.compat.tests.mock import MagicMock

    block = MagicMock(spec=Block)
    role = MagicMock(spec=Role)
    task_include = MagicMock(spec=TaskInclude)

    h = HandlerTaskInclude()

    handler = h.load({
        'include': 'tasks/main.yml',
        'with_items': 'vm_list',
        'when': 'ansible_os_family == "RedHat"'
    }, block=block, role=role, task_include=task_include)


# Generated at 2022-06-23 06:16:51.765610
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import ansible.inventory
    import ansible.playbook.block
    import ansible.playbook.task_include
    import ansible.vars.manager
    import ansible.parsing.dataloader

    data = {'include': 'blah'}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    handler = HandlerTaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-23 06:16:52.445133
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    pass

# Generated at 2022-06-23 06:16:54.511243
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    handler = HandlerTaskInclude.load({'include': 'a_role'})
    assert handler.include == 'a_role'

# Generated at 2022-06-23 06:16:57.400474
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    data = dict()
    data['handler_name'] = 'ping'
    handler = t.load(data)
    assert 'ping' == handler.get_name()

# Generated at 2022-06-23 06:17:07.338791
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    contents = '''
    - include: test_include_1.yml
      first_var: "{{ remote_user }}"
      second_var: "{{ password }}"
      when: (not foo) and (bar != 'test')
      tags:
      - include_tags_1
      - include_tags_2
      listen: "{{ handler_name }}"
    - include: test_include_2.yml
      first_var: "{{ remote_user }}"
      second_var: true
      when: (not foo) and (bar != 'test')
      tags:
      - include_tags_3
      - include_tags_4
      listen: "{{ handler_name }}"
    '''

    config = {}
    parsed = yaml.safe_load(contents)

    #b = Block()
   

# Generated at 2022-06-23 06:17:18.266517
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    import sys
    import os
    
    sys.path.append('../lib')
    sys.path.append('../lib/ansible/inventory')
    sys.path.append('../lib/ansible/playbook')
    sys.path.append('../lib/ansible/utils')
    sys.path.append('../lib/ansible/vars')
    
    from ansible.inventory.host import Host
    h = Host('localhost')
    from ansible.vars import VariableManager
    vm = VariableManager()
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    from ansible.playbook.block import Block
    b = Block( parent_block = None, role = None, task_include = None, use_handlers = False, )
    
    
    data

# Generated at 2022-06-23 06:17:26.671480
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    data = {
        'listen':'redis',
        'name':'mytask',
        'action':'myaction',
        'register':'result'
    }
    block = None
    variable_manager = None
    loader = None
    role = None
    task_include = None
    handler = HandlerTaskInclude.load(data,block,role,
                                      task_include,
                                      variable_manager,
                                      loader)
    print(handler)
    assert handler.name == "mytask"
    assert handler.listen == "redis"


# Generated at 2022-06-23 06:17:27.804002
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    c = HandlerTaskInclude()

# Generated at 2022-06-23 06:17:36.863411
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(
        block = "no_block",
        role = "no_role",
        task_include = "no_task_include"
    )
    assert handler.block == "no_block"
    assert handler.role == "no_role"
    assert handler.task_include == "no_task_include"
    assert handler.always_run == False
    assert handler.changed_when == None
    assert handler.first_available_file == None
    assert handler.name == None
    assert handler.run_once == False
    assert handler.register == None
    assert handler._role_name == None
    assert handler._role_path == None

# Generated at 2022-06-23 06:17:48.100842
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # For initialization of the following variables,
    # see the print of the "The output" part of the test
    # in test_handler_task_include.py
    # Not the best way of testing, but the only one that
    # does not introduce circular dependencies.
    data                                                    = {'one':1, 'two': 'two'}
    block                                                   = None
    role                                                    = None
    task_include                                            = None
    variable_manager                                        = None
    loader                                                  = None
    myhandler                                               = HandlerTaskInclude.load(data=data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    # The output

# Generated at 2022-06-23 06:17:58.164819
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.module_utils._text import to_bytes
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()

    host_1 = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(host_1)

    inventory_loc = loader.set_basedir(os.path.expanduser('~/git-repo/ansible/test/units/inventory/'))
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=inventory_loc+'/hosts')
    variable_manager.set_inventory(inventory)

    a = HandlerTaskInclude()
   

# Generated at 2022-06-23 06:18:09.404797
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = Host("127.0.0.1")
    host.set_variable("ansible_user", "vagrant")
    host.set_variable("ansible_ssh_pass", "vagrant")
    host.set_variable("ansible_connection", "ssh")
    host.set_variable("ansible_ssh_port", 22)
    host.set_variable("ansible_ssh_host", "127.0.0.1")
    datastore = {}

    for h in [host]:
        for key in h.get_vars():
            if h.get_vars()[key] is not None:
                datastore[key] = h.get_vars()[key]
        datastore = dict()


# Generated at 2022-06-23 06:18:15.818907
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    handler = HandlerTaskInclude.load(
        data={"include": "example.yml"},
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    assert handler is not None

    assert handler.block is None
    assert handler.role is None
    assert handler.task_include is None

    assert handler.static is False
    assert handler.name == 'example.yml'

# Generated at 2022-06-23 06:18:24.993363
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import module_loader
    from ansible.template import Templar

    # input variables for constructor test
    block=None
    role=None
    task_include=None
    data = {
        "handler": "test.test",
          "listen": "listen"
        }

    # create required objects
    host = Host("localhost")
    group = Group("all")
    group.add_host(host)
    inventory = InventoryManager(hosts_list=[host], groups_list=[group])
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    loader = DataLoader()


# Generated at 2022-06-23 06:18:26.456774
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler_task_include = HandlerTaskInclude()
    assert handler_task_include is not None


# Generated at 2022-06-23 06:18:28.999663
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()
    assert 'HandlerTaskInclude' == hti.__class__.__name__

# Generated at 2022-06-23 06:18:31.725085
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    t = HandlerTaskInclude()
    HandlerTaskInclude.VALID_INCLUDE_KEYWORDS = set(['tags', 'tasks', 'handlers'])
    tasks = [{"action":{"module":"shell","args":"test"}}]
    handler = HandlerTaskInclude.load(tasks, variable_manager=None, loader=None)
    assert handler.action == tasks[0]["action"]

# Generated at 2022-06-23 06:18:33.062324
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Test for function load of class HandlerTaskInclude')


# Generated at 2022-06-23 06:18:37.793656
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    hti = HandlerTaskInclude()

    assert hti.__class__ == HandlerTaskInclude
    assert hti.block == None
    assert hti.role == None
    assert hti.task_include == None
    assert hti.playbook_context == None

# Generated at 2022-06-23 06:18:43.892183
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.module_utils.six import string_types

    handler = HandlerTaskInclude.load({
        "name": "test",
        "include": "./test.include"
    })

    assert isinstance(handler, HandlerTaskInclude)
    assert isinstance(handler.name, string_types)
    assert isinstance(handler.tags, list)
    assert isinstance(handler.when, string_types)

# Generated at 2022-06-23 06:18:46.094836
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'include': 'somefile.yml'}
    class_object = HandlerTaskInclude()
    assert class_object.load(data)

# Generated at 2022-06-23 06:18:49.411961
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()
    assert True

# Generated at 2022-06-23 06:18:50.262605
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:18:56.145011
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars_vars import HostVarsVars

    h = Host()
    h.name = "localhost"
    h.vars = HostVars(h)
    v = HostVarsVars()
    v.name = "localhost"
    v.vars = AnsibleUnsafeText(u'{"test":{"test_var":1}}')
    h.vars.set_host_variable(v)

# Generated at 2022-06-23 06:18:58.103749
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    include = {'test': 'passed'}
    handler = HandlerTaskInclude.load(include, block=None)
    assert handler._attributes == include

# Generated at 2022-06-23 06:18:59.436087
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # TODO: implement unit test
    pass


# Generated at 2022-06-23 06:19:04.024291
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = dict(
        include="test",
        name="test name"
    )
    handler = HandlerTaskInclude(task_include=TaskInclude(loader=None))
    assert handler.load(data, variable_manager=None,
        loader=None)._attributes["name"] == data["name"]

# Generated at 2022-06-23 06:19:13.067480
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude

    data = {
        'block': Base(),
        'role':  RoleInclude(),
        'task_include':  TaskInclude()
    }

    handlerTaskInclude = HandlerTaskInclude(**data)

    assert handlerTaskInclude.block == data['block']
    assert handlerTaskInclude.role == data['role']
    assert handlerTaskInclude.task_include == data['task_include']
    assert handlerTaskInclude.notify == []
    assert handlerTaskInclude.rescue == []
    assert handlerTaskInclude.always == []

# Generated at 2022-06-23 06:19:17.586629
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    print(handler)

    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    print(handler)

# Generated at 2022-06-23 06:19:18.593035
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    assert False, "Not Implemented Yet"

# Generated at 2022-06-23 06:19:21.298133
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("test_HandlerTaskInclude_load")
    data = {"hosts": "hosts", "name": "name", "tasks": "tasks"}
    HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:19:29.255675
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = 'localhost'
    inventory = 'inventory'
    variable_manager = 'variable_manager'
    loader = 'loader'
    event_handler = 'event_handler'
    connection = 'connection'

    handler_task_include = HandlerTaskInclude();
    handler_task_include.set_loader(loader)
    handler_task_include.set_variable_manager(variable_manager)
    assert handler_task_include.loader == loader
    assert handler_task_include.variable_manager == variable_manager

    block = handler_task_include.block
    role = handler_task_include.role
    task_include = handler_task_include.task_include
    handler_task_include.load()
    handler_task_include.load_data(block, role, task_include, loader, variable_manager)
    handler_

# Generated at 2022-06-23 06:19:39.245166
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext

    playbook_path = os.path.join('test', 'test_handler.yml')
    loader = DataLoader()
    mock_inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    mock_variable_manager = VariableManager()
    mock_variable_manager.set_inventory(mock_inventory)
    mock_play_context = PlayContext(variable_manager=mock_variable_manager, loader=loader)


# Generated at 2022-06-23 06:19:48.070092
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    """
    Test HandlerTaskInclude.load
    """
    handler_task_include = HandlerTaskInclude()

    data = dict({"name":"test_handler_task_include",
                 "tags":['test','handler']
    })

    handler = handler_task_include.load(data)

    assert handler.name == "test_handler_task_include"
    assert handler.tags == ['test','handler']

# Generated at 2022-06-23 06:19:52.131537
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():

    data = {
        "hosts": "{{hosts}}",
        "name": "Test Handler",
        "listen": "Test Task"
    }

    handler = HandlerTaskInclude.load(data)

    # Check if method load returns the correct class type
    assert isinstance(handler, HandlerTaskInclude)

# Generated at 2022-06-23 06:19:56.561769
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    h = HandlerTaskInclude()
    assert h.VALID_INCLUDE_KEYWORDS == set(['name', 'static', 'first_available_file', 'listen'])


# Generated at 2022-06-23 06:20:02.175545
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    obj = HandlerTaskInclude(block='block', role='role', task_include='task_include')
    #assert  obj.VALID_INCLUDE_KEYWORDS == obj.VALID_INCLUDE_KEYWORDS.union(('listen',))

# Generated at 2022-06-23 06:20:13.734394
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.playbook import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from collections import namedtuple
    import os

    dir_path = os.path.dirname(os.path.realpath(__file__))
    FILE = 'dummyfile'
    fp = open(FILE, 'w')
    fp.write('test')
    fp.close()


# Generated at 2022-06-23 06:20:16.544576
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class Cl(object):
        pass
    cl = Cl()
    cl.roles = []
    ht = HandlerTaskInclude(role=cl)
    d = {'listen': 'all', 'tasks': []}
    ht.load(d)

# Generated at 2022-06-23 06:20:21.317628
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():

    # Use an empty dictionary as the argument to pass to the constructor
    handler = HandlerTaskInclude({})

    # Test if the constructor sets the valas as expected
    assert handler._block is None
    assert handler._role is None
    assert handler._task_include is None
    assert handler._static is False
    assert handler._name == 'HandlerTaskInclude'
    assert handler._handler is None

# Generated at 2022-06-23 06:20:23.605987
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    obj = HandlerTaskInclude()
    obj.load('test.yml')

# Generated at 2022-06-23 06:20:24.541250
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    HandlerTaskInclude()


# Generated at 2022-06-23 06:20:30.695443
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    h = HandlerTaskInclude()

    result = HandlerTaskInclude.load({"include_tasks": "playbook.yml"}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    print("Result: {}".format(result))


if __name__ == '__main__':
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:20:33.947042
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    test_data = {
        'include': 'main.yml',
        'foo': 'bar',
        'name': 'handler_name'
    }
    HandlerTaskInclude.load(test_data)

# Generated at 2022-06-23 06:20:36.762511
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  data = {
    'include': 'include-3'
    }
  HandlerTaskInclude.load(data)

# Generated at 2022-06-23 06:20:39.320874
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert handler is not None


# Generated at 2022-06-23 06:20:44.872516
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {
        "name" : "test",
        "listen" : "test-listen",
    }

    task = HandlerTaskInclude.load(data)
    assert task.name == "test", "HandlerTaskInclude name failed."
    assert task.listen == "test-listen", "HandlerTaskInclude listen failed."

# Generated at 2022-06-23 06:20:48.746978
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    t = HandlerTaskInclude()
    assert isinstance(t, Handler)
    assert isinstance(t, TaskInclude)
    assert HandlerTaskInclude.VALID_INCLUDE_KEYWORDS == t.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-23 06:20:59.598918
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print("\n")
    print("Test load HandlerTaskInclude")

    # create inventory
    inventory_hosts_list = [{'host_name': 'host1'}, {'host_name': 'host2'}]
    from ansible.inventory import Inventory
    inventory = Inventory(inventory_hosts_list)

    # create variable manager
    from ansible.vars import VariableManager
    variable_manager = VariableManager()

    # create loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader(None, variable_manager)

    # create HandlerTaskInclude
    handler_task_include = HandlerTaskInclude()


if __name__ == "__main__":
    test_HandlerTaskInclude_load()

# Generated at 2022-06-23 06:21:01.494160
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('unit test for method load of class HandlerTaskInclude')
    assert None == None

# Generated at 2022-06-23 06:21:08.149557
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    play_context.become = True
    variable_manager.extra_vars = {'become_pass': 'pass'}


# Generated at 2022-06-23 06:21:12.048474
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()
    assert isinstance(handler, HandlerTaskInclude)

# Unit tests for the load function of class HandlerTaskInclude

# Generated at 2022-06-23 06:21:17.867895
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {"include": "site.yml", "tags": ["foo", "bar"], "allow_duplicates": True}
    handler = HandlerTaskInclude(data)
    assert handler._attributes["tags"] == ["foo", "bar"]
    assert handler._attributes["include"] == "site.yml"
    assert handler._attributes["allow_duplicates"] is True
    assert handler._attributes["static"] is False

# Generated at 2022-06-23 06:21:27.258504
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    # Arrange
    # Arrange
    class FakeHandler():
        @staticmethod
        def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
            pass
    fn = "./unit_tests/files/handler_task_include_1_load.yaml"
    f = open(fn, 'r')
    data = f.read()
    # Act
    HandlerTaskInclude.VALID_INCLUDE_KEYWORDS = set(['include_tasks', 'include_role', 'host', 'hosts'])
    handler = HandlerTaskInclude.load(data, block=None, role=None, task_include=FakeHandler.load, variable_manager=None, loader=None)

    assert handler.static_handler is not None

# Generated at 2022-06-23 06:21:34.374838
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    (hostvars, groups, group_names) = ({}, {}, [])
    testData = {'include': 'testinclude'}
    
    testHand = HandlerTaskInclude(block=None, role=None, task_include=None)
    testHand.check_options = lambda x,y: 'testreturn1'
    testHand.load_data = lambda x, **kwargs: 'testreturn2'
    returnedHandler = testHand.load(testData, variable_manager=None, loader=None)
    assert returnedHandler == 'testreturn1'
    assert testHand.include_file == 'testreturn2'


# Generated at 2022-06-23 06:21:45.950672
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.errors import AnsibleParserError
    from ansible.inventory import Host, Inventory

    host = Host(name='all')
    host.set_variable('ansible_connection', 'ssh')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    host.set_variable('ansible_ssh_host', '127.0.0.1')
    host.set_variable('ansible_ssh_port', '22')
    host.set_variable('ansible_ssh_user', 'vagrant')
    host.set_variable('ansible_ssh_pass', 'vagrant')
    inventory = Inventory()
    inventory.add_host(host)

    variable_manager = VariableManager(inventory)
    load = DataLoader()

# Generated at 2022-06-23 06:21:57.677283
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    context = PlayContext()
    context._init_vars()

    data = {'name': 'test', 'listen': 'test'}
    hti = HandlerTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=None)
    assert isinstance(hti, HandlerTaskInclude)
    assert hti.action == 'meta'
    assert hti.block is None
    assert hti.loop is None
    assert hti.condition is None
    assert hti.unreach

# Generated at 2022-06-23 06:22:00.161905
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    print('Test for method HandlerTaskInclude.load()')
    assert False

# Generated at 2022-06-23 06:22:04.505961
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    loader = Loader()
    inventory = InventoryManager(loader=loader, sources=["/home/junk/ansible-1.9.2/test/unit/inventory"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    handler = HandlerTaskInclude.load(
        data={
            'include': 'tasks/example.yml',
        },
        block=Block(),
        role=Role(),
        task_include=TaskInclude(),
        variable_manager=variable_manager,
        loader=loader
    )

    assert handler.role is not None

    assert handler.blocks is not None

    assert handler.role_name is None

    assert handler.loop is None

# Generated at 2022-06-23 06:22:07.293237
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    a1 = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert repr(a1) == '<HandlerTaskInclude>'


# Generated at 2022-06-23 06:22:14.706174
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    repr(handler)
    assert handler.VALID_INCLUDE_KEYWORDS == set(('listen',))

    with pytest.raises(Exception):
        handler.check_options(None, {})
    with pytest.raises(Exception):
        handler.check_values(None, {})
    with pytest.raises(Exception):
        handler.listen = None
        handler.listen = ''
    with pytest.raises(Exception):
        handler.name = None
        handler.name = ''
    with pytest.raises(Exception):
        handler.name = 'toto'
        handler.name = 'toto'

# Generated at 2022-06-23 06:22:15.681842
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    host = HandlerTaskInclude()
    assert host != None

# Generated at 2022-06-23 06:22:18.133866
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handlerTaskInclude = HandlerTaskInclude()
    assert isinstance(handlerTaskInclude, HandlerTaskInclude)


# Generated at 2022-06-23 06:22:29.894000
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    class MockVariableManager(object):
        pass
    class MockDataLoader(object):
        pass
    class MockRole(object):
        pass

    # configure Mock objects
    mock_data = dict()
    mock_data['file'] = 'test_file'
    mock_data['name'] = 'test_name'

    # create object under test (uut) and call method load
    uut = HandlerTaskInclude(block=None, role=None, task_include=None)
    result = uut.load(data=mock_data, block=None, role=MockRole(), task_include=None, variable_manager=MockVariableManager(), loader=MockDataLoader())

    # check results of method call
    assert result.name == 'test_name'
    assert result._role is None
    assert result.block is None

# Generated at 2022-06-23 06:22:33.618434
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    data = {'name': 'Handler for ping', 'include': 'ping.yaml', 'listen': 'hello'}
    handler = HandlerTaskInclude.load(data)
    assert handler is not None

# Generated at 2022-06-23 06:22:36.681709
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # HandlerTaskInclude()
    # HandlerTaskInclude(block=block)
    # HandlerTaskInclude(block=block, role=role)
    # HandlerTaskInclude(block=block, role=role, task_include=task_include)
    return True


# Generated at 2022-06-23 06:22:37.581396
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    handler = HandlerTaskInclude()

# Generated at 2022-06-23 06:22:49.529067
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    '''
    Handler validation requires a fake block, role, task_include,
    variable_manager, loader, and data. Fake values are mostly
    literals, except for the fake
   '''

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    from ansible.utils.display import Display

    display = Display()

    fake_loader = DataLoader()
    fake_loader.set_basedir('/example')

    fake_block = Block()
    fake_role = Role()

# Generated at 2022-06-23 06:23:05.486859
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    root_group = Group('all')

    host_0 = Host('localhost', port=22)
    host_0.set_variable('first_var', 'first_value')

    root_group.add_host(host_0)
    inventory = InventoryManager(loader=DataLoader(), sources=[])
    inventory.add_group(root_group)

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-23 06:23:09.694905
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    # check constructor
    handler = HandlerTaskInclude(block=None, role=None, task_include=None)
    assert isinstance(handler, HandlerTaskInclude) == True
    assert isinstance(handler, Handler) == True


# Generated at 2022-06-23 06:23:10.476594
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    x = HandlerTaskInclude()
    assert x

# Generated at 2022-06-23 06:23:14.455960
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
  handler = HandlerTaskInclude.load( dict(action=dict(module='ping')), block=None, role=None, task_include=None, variable_manager=None, loader=None)

  #Test type of handler
  assert isinstance(handler, HandlerTaskInclude)

  #Test type of handler._action
  assert isinstance(handler._action, dict)
  assert isinstance(handler._action['module'], basestring)

# Generated at 2022-06-23 06:23:14.853009
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    pass

# Generated at 2022-06-23 06:23:17.538235
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    block = None
    role = None
    task_include = None
    data = { 'include': ['test_handler'] }
    handler = HandlerTaskInclude.load(data, block, role, task_include)

    # After loading, the data is not empty
    assert data is not None

# Generated at 2022-06-23 06:23:25.835008
# Unit test for method load of class HandlerTaskInclude
def test_HandlerTaskInclude_load():
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    base_loader = lookup_loader()

    # Create inventory
    inventory = Inventory(loader=base_loader)
    inventory.deserialize({
        "_meta": {
            "hostvars": {
                "foohost": {
                    "ansible_ssh_host": "1.2.3.4",
                    "ansible_ssh_port": 22
                }
            }
        },
        "foogroup01": {
            "hosts": ["foohost"]
        }
    })

    # Create variable manager

# Generated at 2022-06-23 06:23:35.520575
# Unit test for constructor of class HandlerTaskInclude
def test_HandlerTaskInclude():
    def load_data(data, variable_manager, loader):
        return TaskInclude.load_data(data, variable_manager=variable_manager, loader=loader)

    hti = HandlerTaskInclude(
        block=None,
        role=None,
        task_include=None,
        load_data=load_data
    )

    assert hti is not None
    assert isinstance(hti, (Handler, TaskInclude))
    assert hti.__class__.__name__ == 'HandlerTaskInclude'

    # noinspection PyProtectedMember
    r = hti._load(dict(include='something.yml'))

    assert r is not None
    assert 'something.yml' in r.include_files
    assert hti.include_files == r.include_files